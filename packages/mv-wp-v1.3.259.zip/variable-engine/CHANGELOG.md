## v1.3.257

- Fixed a restore being marked failed at the final "Restore MV Settings" step even though the database and files restored correctly. The MV settings verification read stale option values after the raw database swap (the autoloaded 'alloptions' cache was not cleared), so it wrongly reported the just-written settings as unverifiable. The cache is now cleared correctly, and — as a safeguard — MV settings portability can no longer fail a restore whose core work already completed; a verification miss is reported as a note and names the affected groups.

## v1.3.256

- Fixed backup import rejection ("incomplete or corrupted (files.restorebase)") for good, including on hosts where the v1.3.255 file lock was silently ignored. Two things now guarantee a package matches its own checksums: the backup job is serialized with a database advisory lock so two overlapping requests can no longer finalize the bundle at once, and the component checksums are recomputed from the files on disk in the same step that packages them, so the recorded size can never disagree with the shipped bytes. New backups made on this version import and restore correctly; backups built by earlier versions must be re-created.

## v1.3.255

- Fixed the backup-import "incomplete or corrupted (files.restorebase)" rejection at its real root. When a slow finalize outlasts the client's request timeout, the client re-issues the job and two executions finalize the bundle at once; the v1.3.254 guard still had a check-then-write race that let the end marker be written more than once. Finalization is now made atomic with an exclusive file lock, so exactly one end marker is written no matter how the requests overlap. New backups made on this version import and restore correctly.
- Fixed backup timestamps showing a wrong relative age (e.g. every backup reading "1h ago" the moment it was made) when the site timezone differs from the viewer's. The site's UTC offset is now used to compute the age.

## v1.3.254

- Fixed backups being rejected on import as "incomplete or corrupted (files.restorebase)". Under concurrent job polling the file bundle's end marker could be written twice, leaving the packaged bundle a few bytes larger than its recorded checksum. Finalization is now idempotent, so the recorded size always matches the packaged bundle. New backups made on this version import and restore correctly; backups built by earlier versions must be re-created.

## v1.3.253

- Backup filenames now use the Mimam's Var plugin version (e.g. v1.3.253) instead of the Recovery module's internal version (v1.0.0-rcNN).
- Import errors now state exactly why a package was rejected — whether a component is the wrong size (truncated) or fails its checksum (altered) — instead of a generic "download did not finish."

## v1.3.252

- Gave CSS Recipes its own Studio rail entry, so it shows the rail and stays reachable while other Studios are open, and stopped it being force-closed when CSS Studio is disabled.
- Bundled the Phosphor duotone icon set (MIT) with the plugin instead of loading it from jsDelivr, so icons no longer depend on a third-party CDN being reachable.
- Fixed Media Studio icons that silently fell back to a generic file glyph (Save metadata, Import, Restore, Insert Media URL, safety notes, and most of the collection icon picker).
- Replaced two icon names that are not in the Phosphor set (`bricks`, `wordpress-logo`), which rendered nothing on the Content Studio editor links.
- Replacing a content image now carries the new attachment's alt text across; it previously read a field the REST attachment does not have and kept the old alt.
- Fixed dynamic tooltips showing the previous label until the element was hovered twice, and made a tooltip repaint in place when its label changes under a stationary pointer (canvas theme toggle).
- Recovery now says a reload is needed when it is re-enabled after the page loaded, instead of appearing to do nothing.
- Fixed post-restore MV settings verification reporting a false failure. It compared the package against the destination outright, but the write is a merge: key order and destination-only keys both read as mismatches, which failed the step for Mimam's Bar and Studio preferences even though every value transferred.

## v1.3.176

- Optimized Media Studio collection query performance by implementing `ve_media_collections_list` Transient caching inside `MediaCollectionManager`, preventing N+1 taxonomy queries during REST lookups.
- Added dynamic WP taxonomy hooks (`created_mv_media_collection`, `edited_mv_media_collection`, `delete_mv_media_collection`, `set_object_terms`) to automatically invalidate the cached collections transient.
- Hardened SVG masonry previews by injecting min-width/height fallbacks to prevent raw SVG files lacking intrinsic dimensions or viewBox definitions from collapsing.

## v1.3.175

- Fixed SVG previews in Media Studio Masonry view by forcing SVG assets to use the original attachment URL before generated thumbnail sizes, preventing SVG helper/plugin placeholder stripes from appearing as line previews.
- Added final masonry SVG containment rules so vector previews sit inside stable card boxes without affecting the working image masonry layout, builder picker insert flow, or AT/Code2Bricks suggestions.

## v1.3.174

- Tightened Media Studio builder picker behavior after v1.3.173 QA.
- Improved builder Masonry view with safer image-first picker filtering, larger/steadier masonry cards, fewer cramped columns, and cover-based thumbnail filling for non-SVG images.
- Made media double-click insertion independent of browser `dblclick` reliability by tracking two close clicks on the same media item, while disabling media dragging in picker mode so drag behavior cannot swallow the insert action.
- Preserved the restored Advanced Themer and Code2Bricks suggestion behavior from v1.3.173.

## v1.3.173
- Fixed Media Studio Masonry view inside Bricks Builder by forcing stable masonry card boxes in nested builder overlays, including SVG/line-art assets that were collapsing into thin strips.
- Changed the Masonry toolbar/dropdown icon to the clearer Columns icon instead of the previous custom masonry icon.
- Fixed double-click media insertion by detecting browser click detail and adding double-click event aliases, so draggable media cards still insert in builder picker mode.
- Restored Mimam's Var's CodeMirror runtime/addons so Advanced Themer, Code2Bricks, and Bricks code editors keep their autocomplete/suggestion behavior. MV's hint styling remains scoped to CSS Studio only, so suggestion styles should no longer leak into other editors.

## v1.3.172
- Reworked the Masonry view icon to a clearer uneven-column masonry symbol.
- Hardened Media Studio masonry cards inside Bricks so very wide/tall assets cannot collapse into thin line cards.
- Fixed the picker insert button so it no longer receives the click event as the media item.
- Fixed the WordPress media-frame bridge callback context so Bricks receives selected media from both Use Selected Media and double-click selection.
- Stopped the picker flow from falling back to copying the media URL when Bricks insertion fails.
- Removed Mimam's Var's global CodeMirror CDN enqueue so CSS Studio no longer overrides Code2Bricks, Advanced Themer, or other builder code editor styling/suggestions. CSS Studio still uses its own fallback editor and will use an existing complete CodeMirror instance when another tool already provides one.

## v1.3.171
- Fixed Media Studio URL import history Clear button styling so it no longer inherits the compact icon-button sizing.
- Stabilized Media Studio Masonry view with explicit media aspect placeholders so thumbnails do not collapse into a thin line before images load.
- Added a dedicated Masonry view icon instead of reusing the grid icon.
- Added builder picker double-click support: double-clicking a media item now inserts/uses the selected media immediately when Media Studio is opened for picking.
- Scoped CSS Studio CodeMirror hint styling and hint containers to the CSS Studio editor so Bricks/native builder code editors and suggestion popups are not affected.

## v1.3.170

### Fixed

- Contained Content Studio rich-editor images so inserted media cannot break the editor/SEO layout.
- Reverted the editor theme control to a compact text toggle.
- Improved Content Studio media picker collection rendering with parent/child indentation and faster prepaint from cached media when switching collections.
- Hid the extra editor note strip and added safer scroll padding above the fixed action area.
- Added final Content Studio layout overrides for toolbar centering, action bar consistency, code blocks, and editor image sizing.


## v1.3.169 - Content Studio Picker + SEO Polish Regression Fix
- Normalized Media Studio masonry SVG sizing and gap handling.
- Restored Content Studio media picker collection list from WP-backed collection maps.
- Tightened Content Studio editor/metadata/SEO layout so sections do not create stray empty bands.
- Improved keyword pill styling, light/dark editor toggle styling, centered editor utility buttons, and SEO check labels.

# v1.3.168 — Content Studio Picker + SEO Editor Refinement

- Fixed Media Studio masonry SVG sizing so small SVG assets fill their masonry column width while preserving natural aspect ratio.
- Upgraded the Content Studio media chooser toward the Media Studio experience with collections, default masonry view, grid/list switching, refresh, search, drag/drop upload, and upload button support.
- Tightened Content Studio editor layout so the content editor remains on the left, meta fields stay on the right, and SEO sections no longer overlap during scroll.
- Centered Clear/Undo/Redo in the content editor toolbar and changed the Light/Dark control to a compact icon toggle.
- Improved focus keyword pills: better contrast, equal padding, and full-height alignment inside the keyword input row.
- Added visible code-block styling for the rich editor.
- Improved SEO check rows with live pass/fail wording and stronger pass/fail styling.
- Calmed the SEO field surface background while keeping the SERP/social previews distinct.

# v1.3.167 — Content Studio Layout + Picker Cleanup

### Fixed

- Tightened SVG masonry cards so SVG previews no longer carry extra visual wrappers or artificial card height/width.
- Reworked Content Studio edit layout so the content editor sits on the left and the post meta panel sits on the right.
- Removed the sticky meta-panel overlap while scrolling the edit form.
- Converted the writing theme control into a real compact toggle.
- Centered Clear/Undo/Redo in the editor toolbar.
- Improved focus keyword pill/input height alignment.
- Polished the MV media picker grid so image cards use consistent usable preview sizes.
- Normalized Content Studio border radius and replaced the dark action-footer block with a quieter panel footer.

## v1.3.166 - Content Studio Media Picker + Editor Layout Polish

### Fixed
- Equalized Media Studio masonry spacing again and removed the dark card background from SVG previews.
- Replaced browser prompt dialogs in the Content Studio rich editor with MV inline dialogs.
- Replaced the default WordPress media chooser in Content Studio SEO/social image fields with a native MV Media Studio picker so Content Studio stays open.
- Added a split Content Studio edit layout with title/status/slug/excerpt on the left and the writing editor on the right.

### Added
- Added a light/dark mode toggle to the Content Studio writing editor.

### Changed
- Tightened oversized SEO/social image URL inputs and focus keyword input height.
- Moved rich-editor utility actions to the far right of the toolbar.

# 1.3.165 - Content Studio Scroll + Masonry Gap Fix

- Fixed Media Studio Masonry spacing so row and column gaps use the same masonry gap token.
- Removed conflicting masonry item margins so vertical spacing is controlled by the masonry column gap only.
- Fixed Content Studio edit mode so the form has a real internal scroll area instead of compressing all sections to fit the modal height.
- Kept the action bar fixed outside the scroll area while the content/SEO/custom-field sections scroll naturally.

# 1.3.162 - Content Studio Writing + SEO Polish

## v1.3.164 — Masonry row gap + Content Studio spacing polish

- Restored visible row spacing in Media Studio Masonry by applying the gap directly to the JS masonry columns and individual cards.
- Reworked the Content Studio edit screen into a roomier structure: metadata panel, larger writing editor, larger SEO workspace, and more breathing space between sections.
- Increased rich editor height and padding so writing no longer feels squeezed.
- Enlarged the Rank Math-style SEO workspace with wider field/preview columns while keeping the live preview/checks on the side.


## v1.3.163 — Content Studio Rank Math workspace + masonry restore

- Restored real Media Studio masonry by using medium/large natural-ratio previews instead of square thumbnails.
- Fixed Media Studio collection expand/collapse persistence so stable collection keys are not overridden by old label-based state.
- Restored the Content Studio rich writing surface even when a post type reports editor support inconsistently.
- Rebuilt the Rank Math area into a two-column SEO workspace with live SERP/social previews, focus keyword pills, checks, social image controls, robots options, schema type, and advanced placeholders that respect free/pro limits.
- General SEO values now update live previews immediately, including slug/permalink changes; Facebook and Twitter previews fall back to general values unless edited directly.


- Optimized Media Studio previews so Masonry no longer asks for full/original image files and images use lazy/async loading outside detail preview.
- Restored visible row spacing in the JS Masonry columns.
- Hardened Media Studio collection tree collapse persistence with stable collection-key storage plus legacy path fallback.
- Replaced the large Content Studio dashboard cards with compact status pills that include counts.
- Added Content Studio table column visibility controls, similar to Media Studio list metadata controls.
- Strengthened Content Studio action icons so the right-side action buttons do not render as empty boxes.
- Hid noisy analytics/plugin meta such as view counters from editable custom fields.
- Expanded the Content Studio rich content editor with H4, underline, strikethrough, code, link, image URL, divider, clear formatting, undo, and redo controls.
- Added editable Rank Math SEO, canonical, robots, Facebook/Open Graph, and Twitter fields inside the Content Studio edit form.
- Added first-pass ACF Options Page discovery and editing under a dedicated Options Pages section in Content Studio.

# 1.3.161 - Content Studio Cleanup + Masonry Stability Polish

- Rebuilt Media Studio Masonry view into JS-distributed columns so the full result set renders vertically instead of showing only the visible slice.
- Made the Media Studio view switcher easier to use with delayed hover close, click toggle, and outside-click dismissal.
- Cleaned Content Studio edit forms by hiding noisy Rank Math internal fields and removing the Advanced WordPress Fields panel from the main Studio flow.
- Hid Plugin/System Types from the Content Studio sidebar for now so the panel stays focused on real content records and custom field groups.
- Increased Content Studio sidebar width to better match the Media Studio adjustment/sidebar feel.
- Forced Content Studio rich-editor text and heading colors to stay readable inside the dark MV UI.
- Restyled Content Studio table actions into primary actions and compact icon actions for a calmer right-side area.

# 1.3.160 - Default Content Types Polish + Masonry Ratio Fix

- Fixed Media Studio Masonry view to preserve image aspect ratios and avoid horizontal scrolling.
- Polished Content Studio default Pages/Posts area with MV-style sidebar groups, dashboard cards, table rows, hover actions, and form inputs.
- Added Rank Math SEO summary data for Pages/Posts in Content Studio.
- Added Bricks post type support detection so Edit in Bricks only appears for post types enabled in Bricks settings.
- Kept WP editor access visible for block/plugin-specific editing.

# v1.3.159 — Media Studio View Fixes + Content CRUD Layer

- Fixed the Media Studio view dropdown so Grid, Masonry, and List render as clear MV-styled menu rows.
- Reworked Masonry View away from CSS multi-column layout so it scrolls top-to-bottom instead of creating horizontal scroll.
- Added richer Content Studio content CRUD: create with title/status/slug/excerpt/content, edit core fields, duplicate as draft, move to Trash, restore from Trash, and permanently delete from Trash.
- Added Content Studio status dashboard cards and status tabs for Active, All, Published, Drafts, Pending, Private, and Trash.
- Added CPT label editing for MV-created ACF/Jet post types, while keeping existing CPT create/delete behavior.
- Added a REST duplicate endpoint for Content Studio posts/CPT entries and strengthened content create/update handling.

# v1.3.158 — Media Studio Filter/Masonry Cleanup

- Cleaned the Media Studio filter popover so search results are visible first and diagnostics no longer cover filtered results.
- Restyled the diagnostics Rescan action as a proper MV button and hid diagnostics while typing in filter search.
- Removed the extra sidebar overview note now that dashboard cards own those stats.
- Added Masonry View as the third media view alongside Grid and List.
- Kept collection tree collapsed/expanded state persisted through the existing Media Studio local preference store.

# v1.3.157 — Media Studio Dashboard Summary Cleanup

- Removed the duplicate bottom-left Total Assets / Storage Used stats card from the Media Studio sidebar.
- Left the top dashboard overview as the single source for total media, storage, missing alt text, unused media, large files, and recent uploads.
- Added a small sidebar note so the sidebar no longer looks like a second dashboard.

# v1.3.156 — Media Studio Safety, Export, Diagnostics

- Fixed the attached collection context menu placement so the Delete row stays inside the rounded menu box.
- Added Media Studio diagnostics endpoint for total size, missing alt, large files, recent uploads, missing files, empty titles, and duplicate filenames.
- Added selected-media ZIP export from the bulk action bar.
- Added usage-aware delete and replace confirmation checks, with detected references shown before destructive action.
- Added rollback history for replace, convert, compress, and rename operations, with restore support from Media Studio.
- Added URL import history storage with success/failure entries and a small recent-imports panel in the URL import preview.

## 1.3.155 - Media Studio tooltip placement fix
- Reworked MV global tooltip positioning so long tooltips are measured/estimated before placement.
- Tooltips now sit fully outside the hovered control, avoid the cursor, and fall back to side placement when there is not enough room above or below.
- Native browser title bubbles continue to be converted into MV-styled tooltips inside the panel.

## 1.3.154 - Media Studio feedback polish

- Removed the duplicate Total Media overview card because total assets and storage already live in the sidebar summary.
- Replaced blocking media-loading whitespace with a non-blocking toast so grid/list content does not jump.
- Added a robust 5-second auto-dismiss for completed Media Studio progress toasts, including unused-image scan completion.
- Improved collection context-menu bottom padding and kept attached-menu arrow support.
- Clarified the bulk Compress tooltip: it rewrites supported selected image files through the WordPress image editor to reduce size, then refreshes metadata.

## 1.3.153 - Media Studio list, filters, bulk actions, and overview polish
- Media Studio: added a compact dashboard/overview strip for total media, missing alt text, unused images, large files, and recent uploads; overview cards activate the matching quality filter.
- Media Studio: polished the filter panel with active filter chips, a save-current-filter flow, and saved custom filter presets stored per browser.
- Media Studio: refined list/table view with sticky headers, selected/checked row states, stronger title/meta cells, thumbnail previews, and drag support from list rows.
- Media Studio: polished bulk actions into a clearer action bar with grouped Add to collection, Compress, Convert, Remove from collection, and Delete actions plus progress toasts.
- Media Studio: added a server-side image compression endpoint for selected image bulk compression.

## 1.3.152 - Media Studio color picker compact polish
- Media Studio: removed the internal scroll from the collection color picker and clamped the full compact popover into view instead.
- Media Studio: cleaned the selected color state so it uses a simple MV-style active ring instead of the dirty double/boxy mark.
- Media Studio: tightened the picker spacing and map height so the color popover fits without feeling unnecessarily tall.
- Native WordPress Media Library replacement remains paused.

## 1.3.151 - Media Studio positioning, scan timeout, and toast polish
- Media Studio: fixed the collection color picker so it opens inside the visible Media Studio panel instead of dropping to the floor/edge.
- Media Studio: fixed the Unused Images scan timeout guard so it actually stops the visible scan state after 35 seconds instead of staying stuck.
- Media Studio: restored the collection context-menu caret and added bottom breathing room so lower menus no longer sit tight against the edge.
- Media Studio: extended MV toast/progress completion visibility to 5 seconds so feedback is readable.

## 1.3.150 - Media Studio scan, color, menu, and ZIP polish
- Media Studio: restyled the collection color picker fields to stay on MV's dark input style instead of using light native-looking inputs.
- Media Studio: removed the dirty check badge from active collection color swatches and replaced it with a cleaner active ring.
- Media Studio: hardened the Unused Images scanner with a frontend stop guard, clearer timeout messaging, and a faster server-side scan path.
- Media Studio: clamped collection context menus with a taller measured height and scroll guard so lower menus no longer get cropped.
- Media Studio: changed ZIP import progress so upload progress caps before extraction, preventing the toast from claiming 99% too early.

## 1.3.149 - Media Studio filter and color picker polish

- Media Studio: polished the collection color picker toward the MV Variable Panel style and removed the duplicate/odd clear swatch, leaving one clear action in the footer.
- Media Studio: added multi-rule quality filters so Missing Alt Text, Unused Images, Recent Uploads, Large Files, shape filters, and size filters can be combined instead of being limited to one active rule.
- Media Studio: stopping/removing the Unused Images filter now clears the visible scan state and ignores stale scan responses, so the UI no longer keeps scanning after the filter is removed.
- Media Studio: added a safety timeout for long unused scans with a useful message to narrow collection/search/type filters and rescan.
- Media Studio: improved ZIP import progress feedback with Uploading ZIP percentage, Extracting ZIP busy state, and final completion feedback.
- Media Studio: refined Usage & replace impact hover styling and added a clearer open affordance on detected usage rows.
- Native WordPress Media Library replacement remains paused.

## 1.3.148 - Media Studio feedback polish

- Media Studio: restored clean metadata panel styling in both admin and builder surfaces, with stronger scoped input/textarea/button rules.
- Media Studio: fixed the collection color popover so it opens beside the clicked action and no native browser/OS color picker is used in this flow.
- Media Studio: moved Delete filter to the top of the filter panel and removed the duplicate shortcode card from Collection Details.
- Media Studio: changed Missing Alt Text and Unused Images long-running operations to use toast/progress feedback instead of replacing the media grid with a large empty busy block.
- Media Studio: optimized the Unused Images scan by batching reference detection across featured images, content, post meta, and options instead of doing one heavy scan per attachment.
- Media Studio: made the Unused Images rescan button disabled while a scan is already running.
- Media Studio: improved replace-file progress with upload/proccessing states and broadcast replaced media updates to other open Media Studio tabs.
- Media Studio: added clearer usage-impact helper copy and padded replace-history layout.
- Native WordPress Media Library replacement remains paused.

## 1.3.147 - Media Studio unused scanner, ZIP import, metadata polish

- Media Studio: replaced the collection custom color browser input with an MV-native color panel, opened beside the clicked menu/action instead of the OS picker.
- Media Studio: added an Unused Images filter backed by a server-side usage scan across featured images, content, post meta, and options.
- Media Studio: added ZIP import into a selected MV collection, with imported files assigned immediately to that collection.
- Media Studio: improved the Missing Alt Text workflow with inline saving and a bulk fill from clean filenames/titles.
- Media Studio: added a collection detail side panel with count, storage size, shortcode, lock/star/color status, quick actions, ZIP import, and collection preview.
- Media Studio: polished attachment details with caption/description editing, explicit save state, URL/tag copy actions, file-size data, and replace history.
- Native WordPress Media Library replacement remains paused.

## v1.3.146

- Media Studio: made starred collections meaningful by pinning them above normal collections and showing a visible star indicator on the collection row.
- Media Studio: replaced the random color-cycling action with a proper color picker modal, preset swatches, custom color input, Apply, Clear, and Cancel actions.
- Media Studio: added explanatory copy to the color picker so collection color is understood as a Media Studio accent only.
- Native WordPress Media Library replacement remains paused and was not touched.
- Plugin version bumped to 1.3.146.

## v1.3.145

- Made the MV media collection taxonomy more explicitly internal/private so SEO plugins should stop treating collection terms as public URLs.
- Persisted locked/starred/color collection metadata to WordPress-backed MV collections.
- Hardened locked collections: lock state now survives refresh/server sync and blocks rename, delete, move, add media, and remove media until unlocked from the context menu.
- Added collection context menu items for Star, Change color, Download all, and Copy gallery shortcode.
- Added Recent Uploads to the Media Studio filter list and renamed Missing Alt to Missing Alt Text.
- Plugin version bumped to 1.3.145.

## v1.3.144
- Media Studio: improved collection drag labels so reorder states now show “Before [collection]” and “After [collection]”.
- Media Studio: made the make-child/nest drop zone easier to reach, so users no longer need to drag far to the right.
- Media Studio: locked collection icons are now static and cannot unlock/open/move the collection by accidental click. Unlock remains available from the right-click menu.
- Plugin version bumped to 1.3.144.

## v1.3.143
- Fixed stale Add Media hover state after cancelled or incomplete media drags.
- Improved collection drag/drop state separation with clear Move Before, Move After, Make Child, and Add Media states.
- Added collection drop-after handling so children can be promoted back to parent level more reliably.
- Fixed nesting insertion so parent/child tree order stays intact after moving collections.
- Made collection list ordering tree-aware so expanded parent children render under their parent instead of breaking when object order changes.
- Kept Media Library replacement paused and full-area MV upload behavior intact.
- Plugin version bumped to 1.3.143.

## v1.3.142
- Locked page/background scrolling while the MV Settings panel is open in admin surfaces.
- Refined Media Studio add-media drop styling: rounded MV-style row, no thick left border, cleaner action pill.
- Fixed collection drag detection so collection reorder/nest states no longer fall back to the add-media drop state.
- Cleared stale media-drag state when starting a collection drag so selected media does not confuse collection reordering.
- Removed native cursor-covering tooltips from collection drag handles.
- Plugin version bumped to 1.3.142.

## v1.3.141
- Media Studio: removed the native browser tooltip from the collection drag handle so the drag hint no longer sits on top of the cursor.
- Media Studio: updated add-media, reorder, and nest drop indicators so each state has a distinct MV-styled visual treatment using the MV green accent instead of the blue temporary styling.
- Media Studio: fixed collection tree movement so dragging a parent into another collection moves the whole subtree, and dragging a child before a top-level collection promotes it back to that level.
- Media Studio: kept full-area MV file upload behavior from v1.3.140 and kept native WordPress Media Library replacement paused.
- Plugin version bumped to 1.3.141.

## v1.3.140
- Restored Media Studio full-area custom upload drop design while keeping native WordPress Media Library replacement paused.
- Removed the capture-phase drag guard that blocked React collection/media drag handlers, restoring collection dragging and drop styling.
- Replaced the aggressive event-blocking WordPress uploader suppression with a passive overlay hider so MV drag interactions can continue working.
- Kept WordPress core blue uploader overlay hidden while Media Studio is open, but allowed MV's own dark upload overlay for real OS file uploads.
- Fixed click-only drag candidates so simple collection clicks do not leave internal drag flags stuck.
- Plugin version bumped to 1.3.140.

## v1.3.139
- Paused native Media Library replacement remains enforced.
- Fixed Media Studio internal drag issue by suppressing WordPress core uploader overlay while Media Studio is open and during MV internal drags.
- Kept upload support restricted to the explicit Media Studio dropzone.
- Hid the auto-sync external folders setting unless an external folder plugin/folder source is detected.
- Removed the extra footer divider line in Settings → Modules.
- Plugin version bumped to 1.3.139.

## v1.3.138
- Paused the native WordPress Media Library replacement again so Media → Library stays on the default WordPress media screen while this flow is rebuilt safely later.
- Removed the runtime setting toggle for native Media Library replacement and replaced it with a paused status badge.
- Disabled the full-page blue file-drop overlay in Media Studio; uploads now rely on the explicit dropzone/upload control while collection/media drag behavior is stabilized.
- Kept drag/drop upload support available through the dropzone, without allowing internal media/collection drags to trigger the full-screen overlay.
- Plugin version bumped to 1.3.138.

## v1.3.137
- Fixed Media Studio runtime setting saves so toggling the native Media Library replacement no longer resets module enable/disable states.
- Hardened Media Studio internal drag detection so collection/media drags do not trigger the full-screen file upload overlay.
- Restored accurate expand/collapse tooltip copy for collection tree toggles.
- Plugin version bumped to 1.3.137.

## v1.3.136
- Fixed Media Studio regression where internal collection/media dragging could still trigger the full-screen “Drop files to upload” overlay.
- Preserved media selections across collection navigation so users can select media from multiple collections before taking batch actions.
- Restored the collection batch bar inside MV collection views by adding the missing `Remove from Collection` handler.
- Added safer removal logic that removes only selected media belonging to the currently open collection and keeps selections from other collections.
- Changed collection branch hover copy to neutral “Toggle children” to avoid wrong expand/collapse tooltips.
- Made the native Media Library replacement legacy switch safer by removing the active class and reloading the Media Library page after switching back.
- Added stronger internal drag detection with custom dataTransfer markers and capture-phase marking.
- Plugin version bumped to 1.3.136.

## v1.3.135
- Fixed Media Studio file-drop overlay so internal collection/media dragging no longer triggers the full-screen upload overlay.
- Restored SEO notices; MV no longer hides Rank Math/SEO notices for internal media collection taxonomy actions.
- Improved collection switching while media is selected: switching collections now clears selection and opens the requested collection with a notice.
- Fixed batch action bar reliability inside individual MV collections and kept Remove from Collection available there.
- Added safer native Media Library replacement close/legacy handling and a close button in the native replacement header.
- Reworked Mimam’s Bar Quick Help into a cleaner flat layout with no gradients, better alignment, and command rows that do not collide.
- Added stronger separation for collection reorder, nesting, and media-add drag states.
- Plugin version bumped to 1.3.135.

## v1.3.134
- Added URL import preview before server download so users can review filename, host, content type, and known file size before importing.
- Kept the 50 MB URL import limit, but now oversized files are blocked at preview when the remote server exposes Content-Length.
- Fixed Media Studio collection manual reordering by switching the collection sort to Manual after drag reorder.
- Improved collection drag/drop indicators with separate states for reorder, make-child/nest, and add-media drops.
- Added right-side drag hover behavior: dragging a collection toward the right side of another collection now previews dropping it as a child.
- Added “Remove from Collection” to the selected-media batch action bar when viewing an MV collection.
- Cleaned the Media Studio collection sidebar separator so the New Collection area no longer appears with double divider lines.
- Added autofocus/select behavior for collection name fields when creating collections.
- Hid external SEO redirect notices generated for the internal mv_media_collection taxonomy after collection rename/delete.
- Improved native Media Library replacement positioning so Media Studio scrolls into view immediately on Media → Library.
- Removed gradients from the MV Quick Help panel and tightened its visual language.
- Plugin version bumped to 1.3.134.

## v1.3.133
- Moved Media Studio URL import into the main toolbar beside Search media so it stays on the same row as search and filters.
- Restyled the URL import input with stronger admin-safe styles so WordPress admin input defaults do not make it appear unstyled.
- Changed the URL import action icon to a Phosphor `cloud-arrow-up` icon and kept the button aligned with MV toolbar controls.
- Added clearer URL import feedback for protected page links such as Pexels video/photo pages and forbidden remote downloads.
- Plugin version bumped to 1.3.133.

## v1.3.132
- Added WordPress-backed MV Media Collections using a dedicated attachment taxonomy so Media Studio collections are no longer only browser/localStorage data.
- Added REST endpoints for listing, creating, updating, deleting, syncing, assigning, and querying Media Studio collections.
- Added automatic migration/sync from existing local Media Studio collections into the WordPress-backed collection system.
- Added loopable media collection output through the `[mv_media_collection]` shortcode and a Bricks-friendly query hook for `mv_media_collection` object-type experiments.
- Re-enabled the native WordPress Media Library replacement toggle and added an instant “Use legacy library” switch inside the Media Studio replacement page.
- Added optional URL-import-to-open-collection support so imported media can land inside the current MV collection.
- Plugin version bumped to 1.3.132.

## v1.3.131
- Antigravity package handoff build. Media Studio work continued from the v1.3.130 state.

## v1.3.130
- **Improved Bulk Targeting Accuracy:** Hardened bulk selection logic by combining results from both Bricks data and canvas DOM. This ensures that mixed elements (e.g. Basic Text set to custom tag `li` vs native list items) are correctly unioned and targeted at the same time without omitting any matches.
- Plugin version bumped to 1.3.130 and Mimam’s Bar module version bumped to 0.3.28.

## v1.3.129
- Added a Mimam’s Bar setting to skip the bulk preview confirmation from Settings → Mimam’s Bar. Bulk commands still use the guarded matching/apply path and still stop above the safety limit.
- Fixed combined selector matching for commands like `all li.bulk-lab__item => data-anim="fade-up"` when Bricks exposes the element type as Basic Text instead of the rendered custom tag.
- Added a safe DOM fallback for class/comma/combined bulk selectors when Bricks element data does not expose enough selector information.
- Updated MV Quick Help again with the new skip-preview setting and clearer combined selector examples.
- Plugin version bumped to 1.3.129 and Mimam’s Bar module version bumped to 0.3.27.

## v1.3.128
- Added combined bulk target support in Mimam’s Bar: `all li.card-item`, `.card.is-featured`, comma groups like `all h2, all p`, and mixed class groups like `.card,.panel-card`.
- Kept bulk matching safe by using Bricks element data first and bounded canvas fallback only where needed.
- Updated the bulk preview wording for combined targets so it describes tag/class/ID combinations clearly.
- Updated the Quick Help panel with clearer Direct Mode, Bulk target, Combined selector, and mode-switch examples.
- Updated the inline example chips in Mimam’s Bar to include combined selector bulk commands.
- Mimam’s Bar module version bumped to 0.3.26.

## v1.3.127
- Improved Mimam’s Bar bulk confirmation wording with clear Target, Action, Scope, and Safety rows.
- Redesigned the bulk confirmation modal with a cleaner premium card layout, stronger visual hierarchy, and clearer primary action label.
- Mimam’s Bar module version bumped to 0.3.25.

## v1.3.126

- Fixed Mimam’s Bar bulk parser getting stuck on commands like `all li => data-anim="fade-up"`, which caused Firefox/Bricks to throw repeated out-of-memory errors before apply could finish.
- Bulk commands now consume the full input after parsing once instead of re-parsing the same `=>` command forever.
- Bulk tag matching now checks Bricks element data before touching the canvas DOM, and the DOM fallback uses a streaming TreeWalker instead of `querySelectorAll` to reduce memory pressure.
- Mimam’s Bar module version bumped to 0.3.24.

## v1.3.125

- Bulk syntax now forces Mimam’s Bar back into Direct mode without clearing the input.
- Page Search/Add Element live search is suspended immediately when the input looks like a bulk command.
- Pending element-search timers are cleared before opening/applying bulk confirmation.
- Bulk commands can now be applied with Enter even if the bar was previously in Search Page mode.
- Reduced the chance of Search Page scans fighting the console-proven bulk writer and causing Firefox/Bricks memory pressure.
- Mimam’s Bar module version bumped to 0.3.23.

## v1.3.124

- Rebuilt bulk apply from the console method that worked on Ahlfigh Bricks page.
- Bulk tag matching now uses canvas rendered `li` IDs and resolves them through the safe Bricks dynamic elements root.
- Removed Vue `toRaw` usage from the bulk ID lookup and light write path.
- Removed automatic full page element pre-scan when Mimam’s Bar opens.
- Disabled command suggestions while typing bulk syntax so Direct mode does not do unrelated selected-element suggestion work.
- Skips target refresh after successful bulk apply to avoid unnecessary selected-element attribute re-rendering.
- Mimam’s Bar module version bumped to 0.3.22.

## v1.3.124
- Hotfixed bulk apply memory path again for `all li => data-anim="fade-up"`.
- Bulk confirmation no longer scans/counts Bricks elements before the user confirms.
- Tag-based bulk matching now tries a canvas DOM ID lookup first, then resolves only those Bricks element IDs.
- Added bounded iterative fallback scanning with a hard guard instead of full cached tree scans.
- Light bulk writer now works on raw element/settings data where possible to reduce Vue reactive setter pressure.

## v1.3.122
- Hotfixed bulk tag matching and bulk attribute writes for commands such as `all li => data-anim="fade-up"`.
- Added lightweight bulk tag matching so `li` targets use Bricks settings/default tags instead of iframe DOM/Vue helper calls.
- Added a lightweight bulk attribute/id writer for simple bulk commands to avoid cloning/stringifying full element settings.
- Bulk apply now marks changed elements once after the batch instead of doing heavy per-element commit work.
- Reduced memory pressure in Firefox/Bricks during bulk preview/apply.

## v1.3.121
- Hotfixed Mimam's Bar bulk apply performance for commands like `all li => data-anim="fade-up"`.
- Removed verbose per-element bulk console logging that could retain large Bricks/Vue objects and exhaust browser memory.
- Stopped forcing a fresh full Bricks tree scan for every bulk preview/apply step.
- Reworked bulk commits to avoid iframe Vue-state crawling and deep equality checks per target.
- Batch invalidates caches and requests Bricks refresh once after bulk apply.

# CHANGELOG.md

## v1.3.82 — Dev

### Fixed
- Fixed the main MV panel boot crash caused by the toast helper being referenced before it was initialized during early module guard setup.
- Restored the normal floating MV launcher and admin-bar launcher target after confirming the panel boots in a real browser engine without falling back to the emergency MV button.

## v1.3.81 — Dev

### Fixed
- Hardened the WordPress admin-bar MV launcher so it binds immediately and through delegated click handling, even when admin footer scripts run after `DOMContentLoaded`.
- Added direct app-side `veToggleVariables` / `veOpenSettings` entry points so the toolbar and emergency controls can open MV without relying only on custom event timing.
- Added a small emergency MV boot button if the panel runtime fails before rendering, including a pre-boot guard for missing Preact/runtime dependencies.

## v1.3.80 — Dev

### Fixed
- Restored the MV floating launcher/speed dial after the native Media Library replacement could leave Media Studio marked open while the popup was not rendered.
- Scoped native Media Library replacement CSS so it no longer treats the whole MV root/backdrop as embedded page content, keeping the settings gear available as the global escape hatch.
- Preserved the embedded Media → Library page replacement while keeping Settings and the speed dial accessible.

## v1.3.79 — Dev

### Fixed
- Reworked Media Studio Masonry to use a direct natural-proportion column flow instead of the manual lane renderer, preventing square-grid fallback, empty guide columns, and non-scrollable masonry panels.
- Strengthened Admin/Builder module deactivation propagation so disabled CSS Studio, Media Studio, Plugin Studio, and Mimam’s Bar states are saved, rebroadcast, and refused/closed across shortcuts, speed dial, global toggles, Mimam’s Bar, and builder media interception.
- Tightened the opt-in native WordPress Media Library replacement so Media → Library embeds MV Media Studio inside the normal admin content area rather than behaving like a popup overlay.
- Corrected tall image preview wrappers so Fit width, Actual size, and Pan/zoom use the full image surface from the real top-left.
- Preserved the working media drag-to-collection path while keeping internal media drags separate from upload drop overlays.

## v1.3.65 — Dev

### Fixed
- Folder-plugin parent folders now count and filter media from all descendant folders, so a parent like `Project Files / Brands` reflects child assets instead of showing `0`.
- Detected folder-plugin rows no longer display the `MV` pill; only MV-owned local collections show `MV`.
- The folder migration modal now uses proper compact MV buttons for Select all and Clear actions instead of tiny link-style controls.

### Changed
- Settings and Media Studio use the same descendant-aware folder counting logic so sidebar counts, settings counts, filtering, and migration previews stay consistent.

## v1.3.64 — Dev

### Changed
- Redesigned the Media Studio folder-plugin integration settings card as a real nested MV tree with leaf-only labels, line guides, folder icons, counts, and quiet `MV` badges.
- Shared Media Studio folder expand/collapse state between the sidebar and Modules settings so the same hierarchy state persists locally after reload.
- Replaced the old external-folder badge language with `MV` across local and external folder rows so migrated and MV-shown folders use one product vocabulary.

### Fixed
- Fixed Modules settings only showing a detected-folder count by making the actual folder hierarchy visible and manageable before migration.
- Removed leftover browser-default/small-text risk in the touched folder migration surfaces.

## v1.3.63 — Dev

### Changed
- Polished Media Studio folder migration layouts so setting rows, action controls, and helper text follow the current MV height and spacing rhythm.
- Added visual line guides to the nested Media Studio sidebar hierarchy tree so sub-collections read as a clear structure rather than a flat list.
- Persisted Media Studio sidebar and Modules settings folder expand/collapse state locally so the tree stays where the user left it after reloads.
- Changed external folder badges to `MV` to match the current product language for MV-managed or migrated folder data.

### Fixed
- Fixed sidebar list node parsing and layout regressions that could break nested folder display.

## v1.3.62 — Dev

### Added
- Folder Hierarchy Display: Render nested collections in a visual hierarchy tree in the sidebar, showing only the leaf names for nested collections, with tree caret toggles to expand/collapse sub-collections and a compact "EXT" badge for external folders to avoid text overlap.
- Folder-Plugin-to-MV Migration UI: Added a folder-plugin migration section under Media Studio settings in Modules settings. Added a clean warning confirmation modal to migrate all detected folders to local collections, toggle hiding of external folders in the sidebar, and confirm action.
- State Synchronization: Real-time event communication between the settings panel and Media Studio for seamless layout updates without page reload.

## v1.3.61 — Dev

### Removed
- Completely removed the codebase languages distribution bar from the settings General tab.


## v1.3.60 — Dev

### Fixed
- Reverted builder panel user interface styling from rem back to px, resolving the 1.6x layout enlargement caused by the WordPress Admin root font-size.
- Fixed settings panel tab container class name and layout to prevent squishing, restoring visibility to all tabs (General, Mimam's Bar, CSS Studio, Modules).
- Relocated codebase languages bar from the Sync sub-panel to the General Settings tab.
- Corrected Notion integration active checks and release notes.


## v1.3.59 — Dev

### Added
- Integrated a GitHub-style languages distribution bar (PHP 78.5%, JS 18.2%, CSS 3.3%) into the builder settings panel to visualize codebase distribution.

### Changed
- Redesigned snapshot cards in the builder panel to look like proper UI cards: Restore and Delete/Archive buttons look like proper clickable actions, spacing is structured, and metadata (Snapshot number, exact timestamp, affected counts) is clear and readable.
- Refactored builder UI styling to use the centralized variable system instead of hardcoded static values.
- Implemented a 10px = 1rem grid rhythm with rem-based margins, padding, and font-sizing, enforcing an 11px (1.1rem) minimum text size boundary.
- Converted the database cleanup action to be unconditionally visible in the Database settings section.

### Fixed
- Fixed category and palette name isolation during Figma/file imports to prevent leakage into fallback options when origin data is empty or generic.

## v1.3.58 — Dev

### Fixed
- Snapshot titles and descriptions are now correctly decoded and rendered in the UI even when the snapshot is flagged as "Unavailable" due to warnings or validation failures.
- Converted the inline "Create recovery point" form into a clean dialog modal shown only when clicking "+ New Snapshot".
- Stale or orphaned generator rows referencing deleted or non-base variables are now automatically identified and deleted during database cleanup to prevent snapshot validation failures.
- General `/sync/apply` and `/sync/drift/apply` imports (from Figma or files) now correctly isolate variables under their own source-named categories and color palettes instead of fallback AT/CF options.
- Fixed empty Description tab in WordPress 'View details' modal by providing explicit HTML sections in the dev manifest.
- Updated plugin row metadata links to display: `Version | By Hebronmimam | View details | User Guide | Support | FAQs | Cheat Sheet`, pointing Hebronmimam to `hebronmimam.com` and User Guide to Notion documentation.

### Reliability
- Updated the verification checklists and ensured all PHP 7.4 compatibility rules are fully validated.

## v1.3.57 — Dev

### Added
- Provenance pills now act as source filters for MV, FILE, Figma, AT, CF, and ACSS.
- Source counts and a source-wide selection action now compose with Category, Color Palette, and text search.
- Sync Drift compares Mimam's Var with the paired Figma collection or Bricks global-variable registry.
- Sync Drift supports previewed Pull and Push plans, explicit conflict rows, snapshot-protected pulls, adapter-owned Bricks pushes, and queued paired-Figma pushes.
- Manual snapshots now support a meaningful title and optional description.

### Changed
- Snapshot cards now explain what each recovery point protects and show the snapshot number, time, source file, and reviewed change count where available.
- JSON, DTCG, Flat, CSS, System Bundle, and Sync Drift imports attach readable context to their automatic pre-import snapshots.
- The Figma companion now publishes a current collection report and processes partial queued Drift pushes without replacing its full WordPress-to-Figma identity map.

### Reliability
- Expanded the core reliability suite to 158 assertions covering snapshot context, composable provenance filtering, source-wide selection, Drift preview/apply contracts, Bricks adapter ownership, and paired Figma reporting.

## v1.3.56 — Dev

### Added
- Native variables now display a compact `MV` provenance pill.
- Generic JSON, DTCG, Flat, and CSS file imports now display a `FILE` provenance pill.

### Changed
- Provenance pills use a quieter neutral surface, softer border, restrained text color, and lower font weight so they support scanning without competing with variable names and values.
- File provenance now follows imported value updates, generated-family repairs, and alias relinks instead of being limited to newly created rows.
- Existing AT, CF, ACSS, and Figma provenance remains distinct and explicit.

### Reliability
- Expanded the core reliability suite to 152 assertions with coverage for DTCG, Flat, Figma collection, Figma handoff, explicit-origin preservation, update propagation, alias relinks, and MV/FILE UI labels.

## v1.3.55 — Dev

### Fixed
- Figma, flat JSON, and framework imports now decide generated-child editability from the active MV generator registry instead of unreliable historical `generator_type` labels.
- Imported/manual family children such as `text-2xl` update in place while preserving their parent, exact token name, value, relationship metadata, and source tag.
- True calculated generator children no longer roll back an otherwise valid import when an external file contains a different child value.

### Changed
- Import Preview now shows calculated child differences as `LOCK` rows with a direct explanation that the base variable or generator settings own the value.
- Protected calculated rows are excluded from the Apply count and safely skipped during normal imports and external migrations.

### Reliability
- Expanded the core reliability suite to 144 assertions with an import scenario matrix covering unchanged rows, base updates, alias relinks, editable imported families, calculated-family protection, repeat-import idempotency, and external verification.

## v1.3.54 — Dev

### Fixed
- Applying an UPDATE to an existing imported generated child no longer routes through the normal editor that blocks generated-variable edits.
- Figma and flat imports now preserve the existing parent relationship and `imported` generator type when updating generated children such as `radius-l`.
- Calculated Color and Fluid generator children remain protected from direct imported-value edits.

### Reliability
- Added regression coverage for parent preservation, imported generator-type preservation, and calculated-family protection.

## v1.3.53 — Dev

### Fixed
- Import Preview no longer proposes `ADD` for an exact generated variable that already exists, including T-shirt family children such as `radius-l` and `text-xl`.
- Applying a Figma handoff or flat import containing existing generated children no longer rolls the complete import back with a duplicate-variable error.
- Explicitly imported generated children still remain excluded from deletion when omitted from a partial import, while changed children preview as updates.

### Reliability
- Added regression coverage for unchanged and changed hyphenated T-shirt generated children.

## v1.3.52 — Dev

### Fixed
- Sync/import validation errors where different dot-notation names (such as `size.text.2xl` and `text.2xl`) would map to the same public CSS custom property (`--text-2xl`) and crash validation.
- Figma plugin exports now calculate and include `public_css_name` and `external_css_name` to enable rename matching during WordPress import.
- WordPress importer now computes robust default fallbacks for `public_css_name` and `external_css_name` if they are missing or empty in flat sync or handoff files.

## v1.3.51 — Dev

### Added
- Direct Figma local-file handoff using a dedicated companion format (`mimams-var-figma-handoff` JSON) exported from the Figma plugin for offline imports.
- Re-styled Figma pairing panel to include an option to export the local handoff file.

### Fixed
- Sync/import now preserves variable alias relationships, mapping incoming Figma variable aliases (which point to parent variables) correctly as `type: 'alias'` and resolving their source links.
- Set imported Figma variables' origin metadata explicitly to `'figma'` to display a clean origin badge.

## v1.3.50 — Dev

### Fixed
- Usage & Impact no longer counts the `bricks_global_variables` definition registry as a real consumer.
- Persisted Bricks references are separated from the currently open Bricks document and display the saved post title plus post ID.
- Generic saved references now appear under Other WordPress storage instead of being mixed with Bricks content.

### Changed
- Single and batch deletion now use a wider MV-styled impact dialog with a clear destructive header, readable token name, contained consumer list, and balanced Keep/Delete actions.
- Navigating from an affected consumer closes the delete confirmation before opening the destination.

### Reliability
- Added regression coverage for registry exclusion, saved Bricks labeling, usage-source separation, and the redesigned delete confirmation.

## v1.3.49 — Dev

### Added
- Variable detail now shows a unified Usage & Impact view covering aliases, Themes, CSS Studio stylesheets, custom CSS Recipes, current Bricks elements, and matching WordPress storage.
- Usage rows navigate directly to the referenced variable, Theme manager, exact CSS Studio stylesheet, CSS Recipe, or Bricks element where supported.
- Variables with no detected consumers are clearly marked Unused.
- Rename, type-change, family relationship, single-delete, and batch-delete surfaces now show affected consumers before changes are applied.

### Changed
- Searchable Family selectors rank exact and prefix token matches above broad substring matches.
- Arrow Up/Down, Home/End, and Enter now navigate and select the highlighted Family option.

### Reliability
- Bricks and CSS Recipe usage scans are lazy and run only when a Usage or Impact surface is opened.
- Added regression coverage for keyboard selection, relevance ranking, usage navigation, unused status, and mutation impact previews.

## v1.3.48 — Dev

### Changed
- Family Destination root, Current family root, and New root selectors now span the full available panel width.
- Family root and child dropdowns now include token-name search with an explicit no-results state.

### Reliability
- Searchable behavior is opt-in to the Family selectors, preserving the dimensions and behavior of compact dropdowns elsewhere.

## v1.3.47 — Dev

### Fixed
- Shift-range checkbox selection no longer highlights variable names and values between the selected rows.
- Family root detection now derives the current family from the selected generated children when they share one parent, instead of falling back to the first family in the dataset.
- Selecting children such as `text-xl` through `text-7xl` now opens Change Root against their actual `text` family.

### Reliability
- Added regression coverage for non-selectable variable rows and selected-child common-parent inference.

## v1.3.46 — Dev

### Fixed
- Select All now visibly checks every matching root and expanded generated-child checkbox instead of updating only the batch count.
- Individual and Shift selection now use the same normalized numeric identity as Select All, preventing string-versus-number ID mismatches.

### Reliability
- All checkbox rendering, selected-row styling, range checks, and Select All state now read from one normalized selected-ID set.
- Regression coverage rejects direct mixed-type row-ID comparisons.

## v1.3.45 — Dev

### Fixed
- The selected-variable review tray now opens automatically when one or more selected variables move outside the current visible list.
- Closing the automatically opened tray remains respected until the hidden selection set changes.

### Changed
- The batch control now says `Review … selected` and shows a hidden-selection count, making its purpose and the missing rows explicit.

## v1.3.44 — Dev

### Fixed
- Variable, generated-child, and Select All checkboxes now render their checked mark through MV-owned styling, preventing Bricks builder CSS from hiding the selected state.
- The selected-count review control now sits above the batch actions instead of consuming horizontal action space.
- The review tray opens above the relocated selected-count control without overlapping it.

### Changed
- Move, Family, Cancel, and Delete now receive the full batch-action row width in narrow panels.

## v1.3.43 — Dev

### Fixed
- Selected root variables and generated children now use a clear MV-accent row state instead of relying on the checkbox alone.
- Batch selection no longer becomes mysterious when selected variables are filtered, collapsed, unloaded, or outside the viewport.
- Stale selections are removed automatically when their variables no longer exist.

### Added
- The selected-count control now opens a review tray listing every selected token.
- The review tray identifies selections outside the current view and supports individual removal or Clear all.

## v1.3.42 — Dev

### Fixed
- Hides the floating batch action bar while the Family subpanel is open.
- Adds checkboxes to expanded generated children so Ungroup and Reparent operate on the intended child rather than its root.
- Opens row-level Manage Family directly in the current family context and limits new-root choices to that family’s children.
- Preselects a clicked child as the candidate new root.

### Added
- Shift-click range selection across the exact visible order of roots and expanded children.
- Focused helper text and checkbox tooltips explaining Shift-range selection.

### Changed
- A selection containing only imported/manual children defaults to Ungroup; Reparent remains available through the Action selector.
- Family-context actions use the current family’s children instead of passing unrelated variables into the operation.

## v1.3.41 — Dev

### Added
- Added previewed manual family management for grouping, ungrouping, reparenting, and changing a family root without re-importing.

### Changed
- Variable names, exact values, CSS names, aliases, source pills, and Theme values remain untouched during relationship changes.
- Color Palette ownership follows the selected family root, while generated children continue inheriting membership.
- The Category tabs strip now reads as one balanced control with an aligned fixed manager lane and contained MV-styled scrollbar.
- Routine update-reactivation and Bricks save/reload checks are now risk-based instead of repeated for unrelated releases.

### Safety
- Added safety snapshots, stale-preview protection, transactional dependency updates, CSS export rollback, and calculated-generator protection.

## v1.3.40 — Dev

### Changed
- Imported T-shirt scales such as `text-xs`, `text-m`, `text-2xl`, `space-*`, `shadow-*`, and `radius-*` now group beneath a clean imported root like generated families while preserving every original token and value.
- Rootless T-shirt families use the `m` child as the initial clean-root value when available and remain manually selectable in Migration Preview.
- Imported T-shirt children display in logical size order from the smallest `xs` step through the largest `xl` step.
- The Category manager action now occupies a fixed area beside the scrollable Category tabs instead of floating over the final tab.

### Fixed
- Dropdown scrollbars now use the shared MV dark track and accent thumb instead of the platform-native scrollbar.
- Category tabs now clip and begin horizontal scrolling before the fixed Category manager action.
- Lone variables ending in `-s`, `-m`, or another recognized scale suffix are not grouped unless sibling evidence confirms a family.

### Documentation
- Added the MV scrollbar rule to the permanent agent and UI quality guidance.

## v1.3.39 — Dev

### Added
- Update checks now report and obey the site's selected Stable, Beta, or Dev channel across both the branded updater and WordPress's native Plugins screen.
- Repeat migration previews with no applicable changes keep a disabled “No changes to apply” control visible.

### Changed
- Development releases now publish to the Dev manifest only; Beta and Stable remain untouched until explicitly promoted.
- Migration Preview uses the panel's main scrollbar instead of a second scrollbar inside Imported family base values.
- Migration actions and the detected-variable summary remain together in a sticky bottom surface.
- Select menus render in a viewport-level layer and automatically open upward when there is not enough room below.
- Imported generated-family children sort naturally by numeric token step rather than by their converted value.

### Fixed
- Update manifests are cached independently by channel and feed URL, preventing one release lane from leaking into another.
- Changing the update channel immediately clears Mimam's Var and WordPress native update caches.
- Imported family roots inherit the AT, CF, or ACSS source pill from their imported children.
- Long imported-family selector labels remain on one line without breaking the card layout.

### Documentation
- Persisted the Dev-first release policy in the agent operating rules, architecture decisions, and release runbook.
- Added/updated tester-facing Mimam's Var onboarding documentation in Notion.

## v1.3.38

### Added
- Migration Preview now shows an Imported family base values section for rootless imported scales. Users can choose which original child supplies the clean root value before Apply.
- Manual imported-family base choices are remembered per source and reused on later migrations.

### Changed
- Rootless imported scales now create a clean root such as `color.mellow-apricot` instead of a synthetic `color.mellow-apricot.base`.
- The `500` child is selected automatically as the initial root value when available; otherwise the closest numbered step is used.
- Imported children remain generated-style organizational children while retaining their exact external names and values.
- Trailing external `base` labels are removed from semantic token names and normalized alias sources, so `color-error-base` imports publicly as `color-error`.

### Fixed
- Diff and Apply no longer recreate `.base` fallback variables when repairing or importing numbered families.
- Repeated migrations preserve the user's selected family root value instead of resetting it to the automatic default.

### Packaging
- The latest verified Figma plugin ZIP is now kept in the Vengine root alongside the latest WordPress install ZIP, with prior root Figma packages archived in `old/`.

## v1.3.37

### Changed
- External migration now derives Color Palette ownership from the selected scanner and AT/CF/ACSS origin metadata instead of trusting only the normalized preview category.
- Imported generated-family rows resolve to their persisted root color before Palette assignment, so the base owns the family while every supplied child value remains unchanged.
- Reusable source Palettes are found by stable name as well as slug, preventing an existing `Bricks / Advanced Themer` Palette from being missed because of earlier slug history.

### Fixed
- Bricks / Advanced Themer migrations no longer allow reviewed root colors to remain in or fall back to Palette One when preview metadata has been normalized.
- Migration Apply now verifies source Palette membership after the final repair pass and rolls back with an explicit error instead of reporting a false success.

## v1.3.36

### Changed
- Color and protected Uncategorized tabs now expose the same right-click Category menu as user Categories, with Rename and Remove shown in a disabled state to communicate that system organization cannot be changed.
- Advanced Themer colors use the stable reusable Color Palette name `Bricks / Advanced Themer`; an earlier `Advanced Themer` source Palette is reused and relabeled instead of duplicated.

### Fixed
- Category context menus now render in a viewport-level layer, clamp within the visible window, and no longer clip against the horizontally scrolling tab strip.
- The global pointer handler no longer removes the Category menu before Rename or Remove receives its click event.
- Category Rename and Remove use dedicated POST actions, restoring reliable operation on WordPress environments that interfere with PUT or DELETE requests.
- External migration now reconciles Palette ownership for every reviewed incoming root color, including unchanged, updated, and newly imported rows, instead of considering only rows represented in the variable diff.

## v1.3.35

### Added
- Right-click (context) menu on user Category tabs in the builder panel with quick Rename and Remove actions (system-protected tabs like Uncategorized are excluded).
- Modals for renaming and deleting Categories directly from the tabs bar.

### Fixed
- Color migration palette placement attempted to include imported/updated colors in their source-named Color Palette; v1.3.36 completes this by reconciling every reviewed incoming root color.

## v1.3.34

### Added
- Non-color variables now use independent user-managed Categories instead of token-derived namespace tabs. Existing variables start in protected `Uncategorized`, while users can create, rename, delete, and batch-assign categories without changing token names or CSS.
- External migrations create source categories for Advanced Themer, Core Framework, and Automatic.css, and imported rows display compact `AT`, `CF`, or `ACSS` origin pills.
- Snapshots now have a dedicated header action and preserve variable Categories and source-origin metadata.

### Changed
- Snapshots have been removed from Sync so backup and rollback are available directly from the main Variable Engine toolbar.
- The migration source cards, callout, badges, result cards, and actions no longer use decorative icons.
- MV System Bundles now carry Categories and origin labels alongside variables, generators, Themes, and Color Palettes.

### Fixed
- Imported colors are assigned to a reusable source-named Color Palette before general Palette repair can claim them for Palette One.
- Multi-source migration creates separate source Palettes and Categories instead of collapsing imported variables into a generic destination.
- Full variable editing no longer references a removed namespace-prefix field.

## v1.3.33

### Changed
- Bricks / Advanced Themer migration now reads only the registered global-variable collection and no longer harvests Bricks theme-style settings as fake variables such as `general-settings-*`.
- Registered Mimam's Var mirrors are always excluded from Bricks migration. Core Framework and Automatic.css registry mirrors are excluded when their owning engines are detected, while an orphaned registry copy remains available as a fallback when its engine is absent.
- Imported numeric and dark/light/tint families such as `bg-body-5`, `bg-body-10`, and `bg-body-d-1` are grouped beneath their detected base variable like generated children.

### Fixed
- Imported family children retain the exact values supplied by Advanced Themer instead of being recalculated from the base.
- Previously imported flat family rows can be repaired into nested imported-child relationships without a blocking TYPE change.

## v1.3.32

### Fixed
- Imported CSS color values now appear in Color even when their semantic names are dotless families such as `bg-body-*`, `bg-surface-*`, or `border-primary`.
- Color Palette eligibility now recognizes strict hex, RGB/RGBA, HSL/HSLA, HWB, LAB/LCH, OKLAB/OKLCH, `color()`, and `color-mix()` values without relying only on the `color` namespace.
- Updating to this version repairs Palette membership for previously imported unowned color-valued variables.

## v1.3.31

### Fixed
- External migration now creates missing imported alias and generated sources recursively with their reviewed relationship type instead of temporarily storing them as base variables.
- Alias chains such as `section-title-to-content` → `space-grid-gap` → its source now survive post-Apply verification without a false type mismatch rollback.
- New imported aliases can no longer inherit stale generated-base state from a previous change in the same migration loop.
- Circular imported source relationships are stopped with a specific error instead of recursing indefinitely.

## v1.3.30

### Changed
- External migration verifies the reviewed rows directly against stored variables after Apply, checking canonical values, alias/generated types, and source relationships.
- Verification errors now identify the exact affected token and expected versus stored state inside the migration panel.

### Fixed
- Post-migration verification no longer reuses the broad general import diff, which could treat destination-only variables or acceptable inferred generated topology as an unresolved reviewed change and roll back a valid import.
- The generic repeated migration rollback now has actionable diagnostics if any genuine persistence mismatch remains.

## v1.3.29

### Changed
- MV interface text now has a 10px minimum across the Variable Panel, migration UI, studios, helper text, badges, metadata, and Mimam's Bar styling. This follows the product's 10px = 1rem design convention.
- External migration Preview canonicalizes incoming dimension values through the same 10px-root rem conversion used by variable storage.

### Fixed
- A reviewed value such as external `10` now previews and verifies as `1rem` instead of being stored as `1rem` and then falsely compared against `10`.
- Large Advanced Themer migrations no longer roll back with “imported variables did not match the reviewed preview” solely because of expected px/rem normalization.

## v1.3.28

### Changed
- Color is now the only category automatically retained during external migration. Non-color framework paths are flattened into portable tokens in the general Base line, such as `bricks.border.primary` becoming `border-primary`; users can add their own categories later.
- Dotless variables display under Base instead of creating a tab named after each token.
- Long migration requests continue server-side if the builder panel closes and receive the WordPress admin memory allowance plus a bounded execution window.

### Fixed
- External migration defers per-variable generated CSS writes and performs one final verified export, removing hundreds of redundant full-file rewrites from large imports.
- Migration success now requires every reviewed affected name to exist after the transaction.
- Network/server failures are caught and shown in the migration panel; the header progress state says Failed instead of falsely saying Complete.
- The migration panel closes as soon as a verified successful response arrives, before the variable list refresh begins.

## v1.3.27

### Changed
- External Bricks, Advanced Themer, Core Framework, and Automatic.css imports now remove storage/source wrappers and derive semantic names from the variable itself. Examples include `base.font` becoming `font`, `bricks.border.primary` becoming `border.primary`, and a color-valued `brickstheme.brand.primary` becoming `color.brand.primary`.
- Imported aliases retain a mapping to their original external CSS custom-property names so source normalization does not break `var()` relationships.
- Variable rows, generated children, detail panels, edit panels, and generator panels now show the complete public CSS token name without dot notation or a leading `--`.
- Large variable namespaces render in batches of 100 with an explicit Load More action.

### Fixed
- Builder variable mirroring now coalesces overlapping refreshes, skips unchanged frame/provider updates, and avoids repeated multi-stage retries.
- Variable refresh events are debounced and background polling is less aggressive, reducing panel lag and freezes on large installations.

## v1.3.26

### Changed
- After external migration, the panel waits for the authoritative variable reload, opens the namespace containing the first affected variable, and only then reports completion.
- Namespace tabs now explain on hover that they come from the first segment of variable names.

### Fixed
- Concurrent cross-frame variable refresh requests can no longer let an older response overwrite newer imported data in the panel.
- External migrations now appear in Mimam's Var immediately without requiring a page reload.

### Clarified
- Variable tabs are derived namespaces, not separately stored folders. A namespace is added through a variable's category, and it disappears automatically when no variables remain in it.

## v1.3.25

### Changed
- External migration Apply now uses the exact prepared variable payload that the user reviewed instead of discarding it and rescanning the source independently.
- Successful migration feedback includes the number of changes actually written.

### Fixed
- External migration can no longer report success when it wrote zero variables.
- After Apply, the server re-diffs the reviewed payload against Mimam's Var. If intended changes remain, the safety snapshot is restored and the operation reports a verification failure instead of a false success.
- External migration preview, apply, verification, metrics, and tests now share one definition of applicable non-deletion changes.

## v1.3.24

### Changed
- Rebuilt Migrate Variables around a stronger MV-dark visual hierarchy inspired by the supplied reference: framed information callout, icon medallions, source-specific Phosphor duotone icons, compact status badges, icon-led actions, reconciled result cards, warning callout, and a clearer change list.
- Migration preview now uses one server-owned count model for detected, ready, new, changed, skipped, and unchanged rows. The Apply button uses the exact same ready count.
- Phosphor duotone icons are the default icon language for new and touched MV controls, badges, callouts, statuses, and actions wherever a meaningful icon exists.

### Fixed
- In-panel updates now preserve and explicitly restore the plugin's previous activation scope after installation, including normal site activation and multisite network activation.
- External migration assigns only newly added colors to the source-named imported palette. Existing colors and aliases keep their current palette ownership.
- Preview and Apply maintain independent loading labels and never show the other action's loading state.

## v1.3.23

### Changed
- Improved the visual aesthetics of the Migrate Variables sub-panel: added a dark, glassmorphic layout for source cards and callouts, replaced loud background colors with premium callouts/alerts, and added distinct, styled badges for migration actions and statuses.
- The preview summary math now includes type changes, relationship changes, and repairs in the "changed" count, perfectly aligning the summary count with the Apply button count.

### Fixed
- External migrations now tolerate and skip CSS custom property conflicts (e.g., when two different names map to the same CSS custom property like `text.base` and `size.text.base`) and report them as warnings, preventing a single clash from failing the entire migration.
- Fixed the button loading states sharing the same boolean variable, ensuring the Scan button shows "Scanning..." and the Apply button shows "Applying..." independently and cleanly.

## v1.3.22

### Added
- Plugin updates can now be installed directly inside Mimam's Var through WordPress's native plugin upgrader.
- After an in-panel update succeeds, a branded confirmation dialog offers **Refresh Now** or **Later** so the newly installed runtime is loaded intentionally.
- External migration previews now report unresolved source aliases as explicit skipped warnings.

### Changed
- Long-operation progress now appears inside the header of the active MV panel, with a stable operation label, staged percentage, waiting ceiling, and clear 100% completion state inspired by the RestoreBase panel pattern.

### Fixed
- A stale Bricks or Advanced Themer alias whose source no longer exists no longer blocks hundreds of otherwise valid migration rows.
- Alias chains that depend on an unresolved external alias are skipped together, while resolvable aliases continue through preview and apply normally.
- The Settings update action and shared update notices no longer redirect away to the WordPress updater screen.

## v1.3.21

### Changed
- Long-operation progress now tracks only known time-consuming work instead of every Mimam's Var API request.
- The progress bar advances once toward a waiting point, holds calmly while server work continues, then fills to completion without restarting or repeatedly sweeping.

### Fixed
- Post-operation refresh requests no longer replace the active progress label or restart the progress animation.
- External migration treats a safe base or static variable becoming an alias with an explicit source as a LINK change instead of blocking it as a manual type change.
- Generated variables remain protected from direct type conversion and still require manual review when an import attempts to turn one into an alias.

## v1.3.20

### Added
- Added a shared branded progress bar for Mimam's Var API work that lasts longer than a brief interaction.
- Progress feedback identifies common operations such as scanning or importing external variables, preparing or restoring a System Bundle, creating or restoring snapshots, generating variables, and updating Themes or Color Palettes.
- Quick requests complete without flashing the progress surface; longer requests show an honest indeterminate bar and a short completion state.

### Changed
- Successful external migration, token import, System Bundle apply, and snapshot restore now refresh builder variable stylesheets and runtime consumers immediately.
- System Bundle LINK guidance now covers both alias and generated source relationships.

### Fixed
- External migration carries public CSS names through reconciliation, preventing alternate stored forms such as `color.color.2` and `color.color-2` from being imported as conflicting custom properties.
- External migration preserves detected alias rows with empty stored values and deduplicates scanned variables by their public CSS identity.
- System Bundle LINK application now preserves generated relationships instead of attempting to convert or edit generated variables through the locked normal update path.
- Generated value updates carry their explicit source and generator type, avoiding name-derived parent guesses during apply.

## v1.3.19

### Added
- External migration from Bricks / Advanced Themer, Core Framework, and Automatic.css now creates a new source-named Color Palette and places imported color variables and resolved color aliases inside it.
- External `var(--token-name)` values are imported as real alias relationships instead of static text values.
- External migration now creates a complete safety snapshot even when token values already match and only Palette ownership changes.

### Changed
- System Bundle and token import preview rows now use a readable two-line layout with wrapping names, values, and relationship details.
- LINK rows show the complete old and new source names, while UPDATE rows show the complete old and new values without hard character truncation.

### Fixed
- System Bundle generated-child repairs now use the bundle's explicit source variable instead of guessing a parent from the child's name.
- Snapshot recovery now accepts semantic aliases such as `design.*` as Color Palette members when their source chain resolves to a Color variable.
- The failed-recovery combination reported in v1.3.18—generated variable conflict followed by invalid color-palette membership—no longer follows those incorrect repair paths.

## v1.3.18

### Added
- Added the MV System Bundle as the complete portable WordPress-to-WordPress handoff format.
- System Bundles preserve variables, generated children, aliases, generator configurations, Themes, active Theme, Color Palettes, memberships, ordering, and generated CSS behavior without carrying source-site database IDs.
- Added dedicated System Bundle export, preview, and apply REST routes plus automatic bundle detection in Sync import.
- Added preview rows for generator, Theme, and Palette changes alongside existing ADD, UPDATE, LINK, and DELETE variable changes.

### Changed
- Sync export now distinguishes the complete System Bundle from interoperability exports such as DTCG, Flat, Figma JSON, and CSS.
- Portable imports reconnect relationships by stable variable names, create a complete safety snapshot first, and automatically restore it if a later import phase fails.
- Skip deletions now also preserves destination-only generators, Themes, Color Palettes, and memberships during System Bundle updates.
- Release packaging now excludes local `.bak` and `.tmp` development artifacts.

### Fixed
- Generated children are applied before aliases, allowing aliases that point to generated tokens to transfer safely between installations.
- Portable bundle validation rejects duplicate Palette memberships, invalid relationship sources, unsupported generator ownership, empty Palette state, and generated-child Palette membership.

## v1.3.17

### Fixed
- Fixed batch actions overlay background color by changing it to `#1b1b1b` (replacing the blueish slate shade) to match the native dark glassmorphic MV product identity.
- Oriented the batch actions target palette dropdown menu to open upwards instead of downwards, ensuring it remains fully visible within the panel viewport and doesn't collide with the status bar.
- Added custom button border-radius overrides for the upward-opening dropdown when active to maintain geometric layout integrity.

## v1.3.16

### Fixed
- Fixed HTML5 drag-and-drop reordering for both variables and palettes in sandboxed environments (like Bricks Builder) by reading the active drag state variables (`draggingVarId` and `draggingPaletteId`) rather than relying on browser `dataTransfer` APIs.
- Resolved batch actions overlay (`.ve-studio-batch-overlay`) design and alignment bugs by overriding standard centering translations (`transform: none!important`), enforcing non-wrapping text (`white-space: nowrap!important`), and assigning an explicit layout width and responsive padding to the target palette dropdown SelectMenu.

## v1.3.15

### Fixed
- Fixed variable drag-and-drop reordering persistence by sorting the `bases` array by position first in the client-side `useMemo` block.
- Implemented the missing floating batch actions overlay (`.ve-studio-batch-overlay`) inside the main panel, appearing at the bottom when checkboxes are checked.
- Added a batch delete confirmation modal (`ConfirmModal`) to prevent accidental mass deletion of variables.
- Fixed Theme/Palette switcher pill styling by setting `width: 100%` and `display: flex` centering on switcher buttons so they span the container width symmetrically.

## v1.3.14

### Added
- Implemented HTML5 drag-and-drop reordering for variables in the tree list, preserving positions via the new `position` database column and POST `/variables/reorder` REST API endpoint.
- Implements HTML5 drag-and-drop reordering for color palettes in the palette manager, calling POST `/color-palettes/reorder` to serialize palette positions.
- Added bulk selection checkboxes next to variable rows in the tree view and a select-all header bar.
- Added a floating batch actions overlay (`.ve-studio-batch-overlay`) at the bottom of the panel showing selected count with batch delete (with confirmation) and batch move (with target palette selector).

### Changed
- Redesigned the Theme/Palette switcher into a capsule pill control (`.ve-color-kind-switch`).
- Removed dropdown labels (`Theme` and `Palette` text span) from select rows to allow selectors to span the full width.
- Styled the active palette/theme current banner to be transparent (`.ve-palette-current` with `padding: 4px 0` and no background/border).

### Fixed
- Removed the header palette shortcut icon button from the header action buttons row (`.ve-hdr-a`).

## v1.3.13

### Changed
- Replaced the stacked Theme and Palette selectors with a compact two-mode switch so only the active Theme or Palette control is shown at a time.
- Theme and Palette selectors now share a fixed label column and begin at the same horizontal position.
- Standardized normal product inputs and branded select controls on the shared 38px control height across the Variable panel and standalone product surfaces.
- Theme and Palette create/rename fields, License Key, search, transfer dialogs, and their adjacent primary action buttons now use the standard control rhythm.

### Fixed
- Removed remaining 24px and 30px inline input-height overrides that bypassed the product control token.
- Preserved specialized heights for checkboxes, radios, color sliders, file inputs, icon controls, and multiline textareas.

## v1.3.12

### Changed
- Color Palette management now expands inline beneath the Palette selector, matching the established Theme manager interaction instead of sliding into a separate panel.
- The header Color Palettes shortcut now opens the Color tab and expands the inline manager.

### Fixed
- Semantic aliases such as `design.*` that resolve through a Color source are now recognized as palette-eligible colors.
- Color aliases appear in the Color tab for palette organization and gain Move to Palette, Copy to Palette, and palette-aware Duplicate actions without changing their stored name, CSS custom property, or source relationship.
- Upgrade membership repair now assigns existing semantic color aliases to Palette One and removes only genuinely invalid memberships.

## v1.3.11

### Added
- Added true user-created Color Palettes as organizational containers for actual Color variables.
- Existing installations migrate their current root colors and aliases into a renameable `Palette One`; generated children inherit their base variable's palette.
- Added an `All Colors` view plus palette filtering under the Color tab.
- Added palette-aware Color creation, Move to Palette, Copy to Palette, palette duplication with independent color copies, inline rename, and safe deletion previews.
- Populated palette deletion can move colors to another palette or explicitly delete the palette and its color/dependency tree through custom confirmation UI.
- Snapshot state version 3 now preserves themes, palettes, memberships, variables, generators, and dependencies together.

### Changed
- Corrected the previous value-layer feature to **Themes** while preserving its existing WordPress options and legacy `/palettes` REST routes for compatibility.
- Added correctly named `/themes` routes and separate `/color-palettes` routes.
- Theme switching continues to affect CSS, Bricks, Code2Bricks, and exports; palette selection affects organization only.

### Fixed
- Imported, migrated, and cleanup-repaired Color variables are assigned to a valid palette without giving generated children independent memberships.
- Color duplication preserves custom-theme values and optional generated children.

### Pending
- Palette drag-and-drop, bulk selection, and manual color ordering remain later interaction phases.

## v1.3.10

### Added
- Added a variable duplication confirmation modal popup (confirmDuplicate) before duplicating a variable to prevent accidental copy creations.

### Changed
- Redesigned active palette and theme card styles with premium duotone palette icon and clean dark card styling, removing the old gradient dot and olive background.

### Fixed
- Fixed input field height alignment for General Settings License Key input (30px), palette sub-panel creation input (30px), and palette sub-panel inline rename input (24px) to align with their action buttons.

## v1.3.09

### Added
- Integrated the full Color Palettes manager inline inside the Color namespace tab. Clicking the sliders/caret toggle next to the palette dropdown expands the palette creation, list, duplication, inline renaming, and deletion interface directly under the tabs.

### Fixed
- Fixed variable row actions (Edit, Duplicate, Delete) in the variable tree list by declaring all the missing handler functions (`hDup`, `hDel`, `cfmDel`, `hCreated`, `tgExp`, `allCats`) in the main `Panel()` component, resolving the console reference errors.

## v1.3.08

### Fixed
- Fixed variable row click handler (`hSel` ReferenceError) so clicking any variable or child variable shows its details card at the bottom.
- Fixed Color namespace tab switching by implementing the `activatePalette` handler and resolving the `ReferenceError: activatePalette is not defined` during Preact render.
- Modifies the `Detail` component to display basic variable metadata immediately rather than blocking render while dependencies are loaded.
- Styled the General Settings "License key" input field (Image 1) to match the dark premium input styling instead of defaulting to a native white box.
- Implemented real-time cross-frame synchronization: any variable change (CRUD) or settings update is automatically broadcast to all frames/windows via `builderRuntimeWindows()` so all open panels refresh instantly without page reload.

## v1.3.07

### Added
- Added a General setting option to show/hide the "All" tab in the variables list.

### Fixed
- Fixed the Preact rendering crash when switching to the **Color** namespace tab by properly declaring the palettesData state and activatePalette handler in the parent panel component.
- Aligned the header action icons row to the left (matching the search input and tabs) by changing the left padding offset from `48px` to `16px`.

## v1.3.06

### Added
- Added a quick palette switcher dropdown inside the Color namespace tab. This allows the user to switch the active color palette instantly from the main view.

### Fixed
- Styled the palette creation and rename inputs in the Palette panel to match the premium dark theme instead of defaulting to white native inputs.

## v1.3.05

### Added
- Added Color Palettes phase 1 under the new palette toolbar action.
- Added palette creation from the active color set, instant activation, duplication, inline renaming, and confirmed deletion.
- Custom palettes keep public token names stable while overriding effective color values in the variable API, generated CSS, Bricks mirroring, Code2Bricks, and DTCG/Flat/Figma/CSS exports.
- Editing a Color variable while a custom palette is active updates that palette instead of overwriting Default; existing generated color children are recalculated from the edited palette base.
- Palette overrides follow base/generated variable renames and are removed with deleted variables.

### Fixed
- Rebuilt variable row actions around explicit open state and the toolbar panel control's 220ms hover-intent close behavior, with the menu anchored at the far-right edge.

### Pending
- Palette snapshot/import payload support and selector-scoped frontend palette switching remain later phases.

## v1.3.04

### Changed
- Variable actions now appear when hovering or keyboard-focusing anywhere on the variable row and remain anchored to the row's right edge.
- Snapshot entries now use descriptive labels such as “Manual backup,” “Before import,” “Before database cleanup,” and “Before snapshot restore,” with the snapshot number and timestamp shown separately.

## v1.3.03

### Added
- Added a clear JSON/CSS import drop zone that displays “Drop file here” while a compatible file is held over it and previews the dropped file before applying anything.
- Added concise import guidance for DTCG, Flat, Figma JSON, and CSS files.

### Fixed
- Restored generated children to a single indented tree beneath their base variable instead of allowing the list to split into a second column.
- Confined variable row actions to the visible swatch/icon hover boundary, keeping them hidden over empty row space while preserving a clickable action bridge.
- Changed JSON and CSS export filenames to include the current WordPress site name, export format, and date.
- Displays alias source changes as explicit old-source to new-source LINK rows and applies supported relationship changes transactionally.

### Planned
- Defined palettes as alternate value layers over stable color-token identities; implementation is intentionally reserved for a dedicated module phase.

## v1.3.02

### Added
- Added unsaved color previewing in the Bricks canvas while editing a color variable; closing the editor without saving removes the temporary preview.

### Fixed
- Recursively discovers nested builder iframe runtimes, reapplies the runtime variable layer after iframe loads, and keeps retrying even when Code2Bricks is already available so custom-property values resolve on the canvas.
- Marks the builder-only runtime variable layer as authoritative so stale Bricks styles cannot mask the current Mimam's Var value.
- Automatically recognizes exact `var(--token)` and `--token` static values as aliases in WordPress, while resolving string and numeric database IDs consistently in the builder.
- Hides the category selector while editing a static variable because the existing namespace is retained.
- Reveals variable row actions only after the pointer enters the variable swatch/icon, instead of activating from the hidden action area.

## v1.3.01

### Added
- Added Tab key autocomplete support to `VarRefInput` in the static value field.
- Added recursive `resolvedVariableValue` helper to fully resolve colors, sizes, swatches, and values for alias variables in lists and autocomplete.

### Fixed
- Added `_nc` cache-buster query parameters to variable list REST requests to ensure value updates propagate to the builder canvas instantly on save.
- Automatically closes the Media Studio panel upon successful asset selection and insertion into Bricks controls.
- Propagates click intent to `createFrame` inside the `wp.media` wrapper to ensure picking state resolves correctly.
- Pre-filled inline editor and full editor in `EditSub` with `css_value` instead of empty string for alias variables, and auto-detects type updates on inline edit save.

## v1.3.00

### Added
- Merged the separate "Alias" mode into "Static" mode. Typing `--` or `var(` in the static value field triggers autocomplete suggestions of existing variables, which automatically transitions the variable's type to `alias` on save.
- Dynamically injects a `:root` style tag on mutation into both the main document and iframe canvas window so newly created variable values resolve instantly in Code2Bricks and Bricks without editor reloads.

### Fixed
- Replaced the timeout polling wrapper with a property getter/setter wrapper on `runtime.wp.media` to immediately intercept Bricks image selectors without race conditions.
- Simplified pointerdown click tracking to register media selection intent for any element outside the Vengine panel and native media modal, bypassing fragile class guessing.
- Corrected the fluid scale generator trigger bug by removing the automatic popup showing when fixed/static variables are created.
- Extended the PHP `VariableManager::update()` method to accept and write `type` and `source_id` edits and correctly register/deregister relations in the dependency graph.

## v1.2.129

### Added
- Added an Alias mode to the variable creation panel with an explicit source-variable selector and a preview of the resulting `var(--token)` reference.
- Added builder UI tokens for the shared accent, surfaces, borders, text, danger state, and 38px control-height rhythm.

### Fixed
- Reconciled MV variables into every accessible Bricks/Code2Bricks runtime at builder startup and after mutations, including direct provider population so autocomplete does not depend on a stylesheet scan or a later focus refresh.
- Rebuilt the Media Studio replacement around Bricks' actual `wp.media` request and selection callback, allowing Bricks to receive the selected attachment through its native control path while leaving navigation clicks untouched.
- Forced search, variable-name, fixed-value, and related single-line controls to the shared 38px product input height.
- Prevented small fluid scales from producing duplicate rounded child names such as two `import-delete.2` rows.

## v1.2.128

### Fixed
- Mirrored MV-owned public tokens into Bricks global variables through the Bricks adapter so Code2Bricks can discover them, while preserving external variable ownership and removing only stale MV mirror rows.
- Refreshed the in-memory Bricks variable list and Code2Bricks provider immediately after variable mutations.
- Restored Media Studio replacement behavior for media-specific Bricks controls without reintroducing sidebar-navigation interception.
- Matched the HEX and channel value fields to the standard 38px input height.

## v1.2.127

### Fixed
- Normalized user-entered variable-name spaces to hyphens, allowed CSS-safe hyphens in stored variable segments, and kept internal dot separators out of the variable-name UI.
- Added horizontal padding to the HEX/RGB/HSL/OKLCH format controls.
- Refreshed the selected variable immediately after inline value saves instead of requiring the user to leave and reselect it.
- Reloaded generated `variables.css` after variable mutations so already-open Bricks tools such as Code2Bricks can discover newly created variables.
- Narrowed the Bricks Media Studio trigger bridge to explicit media controls so sidebar navigation icons no longer open Media Studio.
- Changed snapshots to capture variables, stable IDs, dependencies, and generator configuration as one versioned state.
- Made snapshot rollback transactional, recovery-snapshot-backed, and explicit about legacy snapshots that cannot restore generated relationships safely.
- Marked incomplete legacy snapshots as unavailable in the Snapshots UI instead of offering a misleading Restore action.
- Prevented imports from applying when their required pre-import safety snapshot cannot be created.
- Rejected duplicate names before variable rename writes and stopped recording rename history when the database update fails.
- Made generated variable CSS writes atomic and deduplicated declarations by public CSS name.
- Rejected create/rename operations that would make two stored variables resolve to the same public CSS custom property.
- Added CSS-name collision diagnostics and deduplicated legacy JSON/Figma exports by the newest stored variable row.
- Preserved valid single-segment tokens in DTCG export instead of silently omitting them.
- Made import application transactional: any failed change, CSS write, or sync-log write rolls the complete import back.
- Blocked unsupported type-change imports before mutation and added a custom confirmation before applying import deletions.
- Prevented generators from converting unrelated existing variables into generated children when names or public CSS names collide.
- Added checked generator database writes, duplicate-generator prevention, transactional attach/detach, and explicit regeneration failures.
- Made variable create, update, and delete operations transactional, including dependency, generator-regeneration, and generated-CSS writes.
- Replaced the delete-then-create generator UI flow with one transactional generator replacement, preserving the old scale if the new configuration fails.
- Surfaced generator, duplicate, and delete API failures instead of showing false success messages.
- Preserved generated-variable IDs during generator replacement and blocked removal of generated tokens that still have downstream alias/dependency usage.
- Made forced variable deletion traverse the complete dependency tree instead of leaving grandchildren with missing sources.
- Added a complete pre-cleanup snapshot and one transaction around duplicate/orphan/stale-variable cleanup, generator recovery, regeneration, and CSS export.
- Preserved alias source names in flat and DTCG exports and restored alias relationships when importing into a new variable set.
- Normalized flat import metadata instead of passing unvalidated relationship fields straight through.
- Added import preflight validation for duplicate names, public CSS collisions, missing/self-referencing alias sources, and conflicts with existing variables.
- Made source-relationship changes visible in import diffs and blocked them for explicit manual review instead of silently relinking variables.
- Changed rename propagation from substring replacement to exact CSS custom-property token matching, preventing a rename such as `--brand` from altering `--brand-alt`.
- Surfaced rename-propagation warnings after a successful variable rename.
- Prevented database read or JSON encoding failures from being stored as successful snapshots.
- Added pre-rollback snapshot structure checks for duplicate identities, invalid dependency rows, and malformed generator rows while still allowing an exact safety capture of a database that needs cleanup.
- Prevented alias relationship round trips from producing false value updates and exported an alias source's resolved value to Figma.
- Separated manually resolved CSS-name conflicts from automatic cleanup issues and stopped cleanup failures from showing a false success toast.
- Converted unexpected rename-propagation failures into visible warnings while keeping the successful core rename intact.
- Remapped source IDs, generators, and dependency edges to the kept row before database cleanup removes older duplicate variable records.
- Added diagnostics for broken alias sources, missing dependency links, and orphan dependency rows.
- Extended cleanup to repair valid alias/generated dependency links, remove generated rows whose source is gone, and delete orphan dependency records while leaving ambiguous aliases for manual relinking.
- Prevented cleanup from deleting orphan generated variables that still serve downstream dependents; those cases are now flagged for manual review.
- Added a recoverable backup-swap fallback for atomic generated-CSS replacement on hosts where `rename()` cannot overwrite an existing file directly.
- Corrected existing dependency edges when their stored relation type is stale and required imported generated-variable edge registration to succeed.
- Extended snapshot structure validation to reject duplicate dependency and generator IDs before rollback.
- Preserved generated child IDs across base-variable renames by matching owned color/scale children through stable generator suffixes and renaming those rows in place.
- Rejected snapshots whose alias/generated sources, dependency edges, or generator owners do not exist in the captured variable state, and stopped rollback before mutation when its database transaction cannot start.
- Refreshed alias CSS references inside variable rename transactions so source and generated-token renames cannot leave `var(--old-name)` declarations behind.
- Made viewport-driven fluid-variable recompilation transactional and surfaced database, CSS-write, and commit failures without retaining the new viewport settings.
- Made CSS import previews reconcile public CSS names back to unambiguous stored variable identities and infer simple `var(--token)` alias relationships.
- Expanded import previews to show and block unsupported type/source relationship changes before application.
- Surfaced direct sync-log database write failures instead of returning false success.
- Applied identity validation to legacy base-only snapshots and surfaced failures when stale generated dependency edges cannot be removed.

## v1.2.126

### Fixed
- Synchronized every fresh MV update check into WordPress's native `update_plugins` site transient so the first refresh no longer merely primes a later update display.
- Added a pre-render fresh manifest check on the WordPress Plugins and Updates screens, preventing stale six-hour manifest data from requiring a second refresh.
- Removed the 120ms restore gate and the additional panel entrance animation from hidden floating Elements/Structure restoration; the panel now rebuilds immediately at its validated saved geometry.

## v1.2.125

### Fixed
- Applied pending floating-panel restore geometry synchronously during shell creation, before the browser can paint the temporary reconstructed position.
- Removed the early delayed position correction that allowed the panel to flash near the bottom before moving to its saved location; retained a later fallback only for unusually delayed Bricks mounts.

## v1.2.124

### Fixed
- Kept an immutable hide-time geometry snapshot for floating Elements and Structure panels so shell reconstruction and width-preset initialization cannot overwrite the position and size that restore must use.
- Preserved pending restore metadata during normal floating-panel persistence, then cleared the one-time snapshot only after the rebuilt shell successfully receives it.

## v1.2.123

### Fixed
- Positioned the compact Bricks panel-preference control immediately before Undo instead of leaving it detached after Save.
- Added hover intent and a cursor bridge to the compact panel-control popover so it remains open while the pointer moves from the toolbar icon into the dialog.
- Saved floating Elements and Structure geometry at hide time and reapplied it on restore, clamping oversized or off-screen positions into the current viewport.

## v1.2.122

### Added
- Added account-backed UI preference storage through WordPress user meta so panel modes, positions, Builder Tools settings, CSS Studio preferences, Media Studio view preferences, and update skips can follow the logged-in account across browser sessions.
- Added the update-available notice to the main panel, its nested views, all standalone Studio panels, Settings, Help, and Mimam's Bar.

### Changed
- Consolidated the Bricks toolbar Elements and Structure controls into one compact MV panel-control icon with a branded hover/focus popover for dock, float, and hide actions.
- Corrected the WordPress plugin author name to `Hebronmimam`.

### Fixed
- Preserved whether Elements or Structure was floating or docked before hiding, so its restore icon returns it to the same mode.
- Kept toolbar control popovers stable instead of rebuilding their DOM while the panel state is unchanged.

## v1.2.121

### Changed
- Made the release workflow stricter by documenting the Notion Release Notes page as a required release step and backfill target.
- Recorded the fixed `left`/`top` floating-panel drag model as the default pattern for future MV floating surfaces.

### Fixed
- Made floating shell Wide and Max presets expand the inner Bricks panel subtree instead of leaving empty shell space beside a fixed-width panel.
- Moved floating shell header tooltips below the size/dock/hide controls so they no longer sit directly on top of the hovered icon.
- Changed Elements and Structure hide behavior to create separate restore icons near the MV control area, so hidden panels can animate down to a small icon and restore from their own icon.

## v1.2.120

### Changed
- Replaced the floating shell S/M/L/XL size language with MV-owned Narrow, Balanced, Wide, and Max presets.
- Updated floating shell dock, float, and hide icons so the controls read as Mimam's Var UI instead of mirroring the reference floating-panel plugin.

### Fixed
- Made Wide and Max floating shell presets apply larger real widths and persist those widths.
- Added Structure-specific floating shell spacing and toggle visibility rules so Bricks row expand/caret controls can remain visible and clickable while floating.

## v1.2.119

### Fixed
- Fixed Builder Tools floating Elements and Structure shells so the active shell wrapper is not removed by the stale-panel cleanup pass immediately after toggling float.
- Tightened vertical centering for the Bricks toolbar MV Elements and Structure mode controls.
- Reverted Media Studio collection context menus to Studio-relative row anchoring and refined lower-row clamping so menus stay attached to the clicked collection without drifting across the viewport.

## v1.2.118

### Changed
- Reworked Builder Tools floating Elements and Structure into MV-owned floating shells with custom headers, S/M/L/XL width presets, dock/hide controls, and Bricks toolbar panel mode controls.
- Set floating panel opacity default to 100% and migrated the old 78% default once for existing installs that had not changed it manually.

### Fixed
- Kept native Bricks Structure markup inside the floating shell so row expand/caret controls remain visible and clickable without opening Media Studio.
- Restored floating panels through the shell cleanup path so dock/hide state changes do not leave orphan wrappers or stale inline styles.
- Improved Media Studio collection context menus by anchoring them with viewport-fixed row geometry and a pointer that follows the clicked row, including lower sidebar rows.

## v1.2.117

### Fixed
- Stabilized Builder Tools floating Structure/Elements cleanup by removing inactive float root classes before restoring docked panel styles.
- Stopped floating Structure from wrapping Bricks internals in an MV layout wrapper, reducing dock-restore glitches.
- Scoped floating-panel button layout overrides to panel headers so Structure row expand/caret controls are not affected.
- Broadened floating Structure expand/caret visibility rules while keeping them scoped to Structure rows.
- Re-centered Media Studio collection context-menu pointers around the clicked row, including lower sidebar rows.

## v1.2.116

### Changed
- CSS Studio keeps the Variable Panel surface, but the stylesheet settings area is more compact and the CSS editor fills the remaining panel height.
- Media Studio collection menus now anchor inside the Studio layout context instead of relying on an unpositioned ancestor.

### Fixed
- Kept Bricks Structure expand/caret controls visible and clickable while the Structure panel is floating.
- Added targeted cleanup for disabled floating Structure/Elements panels so disabling one panel can restore its Bricks docked state even if another Builder Tools panel remains active.
- Further softened floating Structure/Elements shadows to avoid a glowing/pulsing feel.
- Made Rank Math internal links processed, Rank Math analytic object ID, and Rank Math SEO score read-only in Content Studio.

## v1.2.115

### Changed
- Added named UI surface styles to the AI UI rules so future work can refer to Variable Panel, Wide Studio, Medium Studio, and Sidecar Editor consistently.
- Changed CSS Studio back to the narrow Variable Panel style instead of the wide Studio modal style.

### Fixed
- Prevented Bricks Structure panel clicks from being captured by the Media Studio picker interceptor.
- Fixed CSS variable autocomplete so bare `--token` completions wrap as `var(--token)` unless the cursor is already inside `var(...)`.
- Improved Media Studio collection context menu anchoring by positioning from the clicked collection row instead of centering the menu over nearby rows.
- Added floating-panel style snapshot/restore cleanup so disabling floating Structure or Elements can return Bricks panels closer to their native docked state.
- Restored MV-created floating header wrappers during cleanup so Structure/Elements headers do not keep altered markup after disabling float.
- Repositioned the Elements floating drag handle inside the panel header and kept the Structure minimize control in the header row.
- Kept Structure expand/caret controls visible while floating and removed animated shadow transitions that made floating panels feel like they were pulsing.

## v1.2.114

### Added
- Added safe Content Studio REST endpoints to preview and apply a JetEngine-to-ACF mirror migration without deleting JetEngine data.
- Added local Figma dev sync documentation for using a reachable HTTPS tunnel URL instead of `localhost`.

### Changed
- Content Studio now separates Rank Math custom fields into their own section so SEO metadata is not mixed into general custom fields.
- Content Studio preserves richer custom-field/meta values for editing, including JSON-friendly complex values.
- CSS Studio now combines the stylesheet settings and editor into one studio panel instead of using the old detached sidecar layout.
- CSS autocomplete now wraps bare `--token` completions in `var(...)` unless the cursor is already inside a `var()` context.
- Studio input heights were tightened toward the shared 38px rhythm.

### Fixed
- Tightened CSS Recipes editor/form spacing and kept recipe actions below the editor.
- Reworked CSS Studio sizing overrides so it no longer inherits stale compact sidecar CSS.
- Improved Media Studio context-menu anchoring so menus align from the clicked collection row instead of the row above.
- Further stabilized floating Structure/Elements panel manual positions after drag/drop and kept the Structure shortcut rail hidden.
- Centered the Elements panel floating drag handle vertically in its header and moved the Structure minimize control to the far header edge.

## v1.2.113

### Changed
- Lowered floating Bricks Structure and Elements panels beneath Advanced Themer popovers while keeping MV Studio panels above normal admin/builder surfaces.
- Added common logical CSS properties to CSS Studio validation and autocomplete support.
- Content Studio now hides the WordPress content editor when a post type does not support default content and surfaces detected custom fields/meta in the in-studio editor.

### Fixed
- Reworked floating Structure/Elements dragging to update fixed `left`/`top` during drag instead of applying a temporary transform and snapping on drop.
- Prevented active CSS and rich-content editors from re-syncing external values while typing, reducing cursor jumps to the start of the editor.
- Tightened CSS Recipes layout so shortcode prefix/input spacing is clean and recipe action buttons sit directly under the editor.
- Centered the Media Studio collection context-menu pointer on the clicked row and kept the menu clamped inside the Studio panel.
- Added a settings-panel fallback so Settings no longer stays on a permanent loading state if the settings request fails.
- Refined floating Structure/Elements handle sizing, spacing, and z-index so the handles feel less intrusive.

## v1.2.112

### Changed
- Upgraded Content Studio's in-studio content field to a lightweight WordPress-like rich editor with paragraph, heading, list, bold/italic, and quote controls.
- Made Media Studio reopen faster by reusing an in-memory media/folder cache while refreshing data in the background.

### Fixed
- Tightened CSS Recipes form/editor sizing so recipe preview and new-recipe states use the full available editor width consistently.
- Re-anchored Media Studio collection context menus to the clicked collection row edge while keeping the menu clamped inside the Studio viewport.
- Replaced the floating Builder Tools drag handle icon with an inline SVG handle and removed the unwanted handle tooltip pseudo-element.
- Persisted floating panel width and clamped Structure restore/drag positions to reduce jumping and prevent panels from leaving the viewport.
- Scoped Bricks panel styling overrides to MV floating-panel states so Builder Tools CSS does not leak into unrelated Bricks/site UI.
- Applied the requested floating Structure spacing of `2rem` padding and `2rem` gap.

## v1.2.111

### Changed
- Removed the temporary MV Structure shortcut rail from the active Builder Tools UI and settings until the shortcut system is redesigned later.
- Moved CSS Studio's Save & Compile action to the code editor sidecar so compiling stays attached to the stylesheet being edited.
- Upgraded CSS Recipes editing to use the same CSS editor surface as CSS Studio, including recipe edit/cancel state and autocomplete sources.
- Reworked Content Studio's in-studio editor to use the full available workspace with sticky actions and an Advanced WordPress fields section.

### Fixed
- Added cleanup for MV Structure wrappers so docking the Structure panel can restore Bricks' default layout more reliably.
- Improved floating Structure and Elements drag handle styling and placement.
- Anchored Media Studio collection context menus inside the Studio panel so transformed panel positioning no longer pushes menus away from the clicked collection row.
- Reduced 1Password/autofill interference on CSS recipe name and shortcode fields.

## v1.2.110

### Changed
- Moved CSS recipe discovery out of CSS Studio so the stylesheet editor no longer shows recipe shortcode rows or recipe scope controls.
- Changed CSS Recipes Studio to list shortcodes only; clicking a shortcode loads its generated CSS into the recipe editor.
- Auto-prefixes new recipe shortcodes with `@` so users type only the shortcode name.
- Reworked Builder Tools Structure shortcut handling to use MV's owned fixed rail instead of moving external Bricks or Advanced Themer rails.

### Fixed
- Expanded Content Studio "Edit in Studio" so it can save core WordPress edit fields including title, slug, status, content, excerpt, parent/order, featured image ID, comments, pings, and template metadata.
- Re-anchored Media Studio collection context menus beside the clicked collection row and clamped them to the viewport.
- Added a local settings backup write for Builder Tools panel preferences to reduce future update-related settings loss.

## v1.2.109

### Fixed
- Removed CSS Studio from the large Studio modal sizing rules so the compact settings panel and code editor sidecar stay beside each other.
- Added explicit CSS Recipes centering and width rules so the Recipes Studio no longer opens stretched or clipped offscreen.
- Fixed Content Studio "Edit in Studio" by moving its save handler back into the Content Studio scope.
- Anchored Media Studio collection context menus to the actual pointer position and clamped them inside the viewport.
- Made MV-owned Media Studio collections draggable from the row as well as the handle, while detected folder-plugin collections now show a read-only lock affordance.
- Stabilized the Builder Tools Structure shortcut rail by mounting it to the Structure panel instead of positioning it as a separate fixed element during drag.

## v1.2.108

### Fixed
- Restored CSS Studio to the compact MV panel sizing with the code editor sidecar placed beside the main settings panel.
- Fixed Media Studio folder-plugin collection counts so detected folders show the same item count as the filtered gallery.
- Changed Media Studio sub-collection creation from an inline bottom-of-list form to a focused modal.
- Made Media Studio Bricks picker mode close after a successful insert or copy fallback.
- Scoped Media Studio conversion progress to the selected asset so another asset no longer inherits the converting state.
- Made Content Studio input heights match action buttons and made Edit in Studio start from pointer-down for more reliable in-panel editing.
- Stabilized Builder Tools floating handles and Structure shortcut rail visibility while dragging.
- Smoothed the toast countdown ring animation and prevented older toast timers from hiding newer messages.

### Changed
- Media Studio collection rows now label MV-owned collections versus detected folder-plugin collections, show sub-collection indentation, and expose drag only through an explicit handle.
- CSS Recipes now uses a centered studio width instead of stretching to the full available viewport.
- Added an agent UI-memory rule for clearly labelling MV-owned data versus adapter-detected data.

## v1.2.107

### Added
- Added an MV-styled right-click context menu for Media Studio collections.
- Added local Media Studio collection rename, remove, sub-collection creation, drag-to-reorder, and Shift-drop nesting.

### Fixed
- Fixed CSS Studio panel placement by excluding CSS Studio and CSS Recipes from the generic standalone-panel transform override.

### Changed
- Kept the update ZIP filename short as `mv-wp-v1.2.107.zip` while preserving the internal `variable-engine` plugin folder required by WordPress updates.

## v1.2.106

### Added
- Added a dedicated CSS Recipes Studio panel for managing reusable CSS shortcodes that autocomplete inside CSS Studio.

### Fixed
- Restored the floating Elements panel drag handle even when no Bricks element is selected.
- Lowered Builder Tools floating Elements, Structure, rail, tooltip, and minimized-restore layers below MV Studio overlays.
- Stabilized Structure shortcut rail dragging by clearing rail transforms and transitions after drag.
- Added a Bricks media-selection handoff so Media Studio can insert the chosen media URL into the originating Bricks control, with a copy fallback when no writable control is exposed.
- Changed Media Studio file conversion to show converting/converted toasts without switching the full Studio into a loading state.
- Made Content Studio clear stale rows immediately when switching sections and made Edit in Studio open the inline edit form more reliably.

### Changed
- Clarified the General setting label for single-panel versus multiple-panel behavior.

## v1.2.105

### Fixed
- Added file type metadata to Media Studio attachment details beside dimensions and size.
- Reworked Plugin Directory result cards so grid and list views align consistently.
- Fixed Plugin Studio navigation so installed-plugin filters switch back from Plugin Directory content instead of only changing the header.
- Fixed Content Studio navigation races so slower previous requests cannot repaint Pages after clicking another type.
- Reset Content Studio transient row/edit state when switching content groups.
- Changed Content Studio edit links to use server-provided Bricks links when available.
- Clamped floating Builder Tools panels to the viewport after drag, resize, and settings changes.
- Prevented dragging the floating Elements panel from moving the Structure shortcut rail.

## v1.2.104

### Added
- Plugin Directory browsing now has its own Plugin Studio sidebar section with preloaded popular plugins.
- Plugin Directory results now support grid/list views and display plugin icons when WordPress.org provides them.

### Fixed
- Restored CSS Studio to the slimmer MV panel sizing so the code editor area is visible again.
- Filtered duplicate default Pages/Posts out of the Content Studio custom post type list.
- Hid Advanced Themer/options-page field groups from Content Studio field-group lists.
- Made Content Studio field rows editable in Studio instead of only deletable.
- Improved branded focus styling so Studio inputs do not show the browser's blue focus ring.
- Broadened Bricks image/SVG/media/background click detection so Media Studio opens from more Bricks selector controls.
- Reduced Structure/Elements hide-versus-float conflicts by applying builder panel state classes to both document roots.

### Changed
- Plugin Studio directory search now fills the available result height and uses more readable plugin card text.
- The multiple-panel option is now labelled as Panel behavior with helper text in General settings.

## v1.2.103

### Added
- Plugin Studio can now search the WordPress.org plugin directory and install plugins directly from Studio.
- Plugin Studio can now upload plugin ZIP files from Studio.
- Added a General setting to allow either one MV panel at a time or multiple Studio panels at once.
- Added toast countdown ring animation so temporary messages show their remaining display time.

### Fixed
- Improved Plugin Studio text contrast so plugin descriptions and authors remain readable in the dark UI.
- Lowered MV panel and Builder Tools z-index layers so native WordPress/Bricks modals can appear above MV panels.
- Broadened the Bricks media-control bridge so common image, SVG, media, and background selectors open Media Studio instead of the default media library.
- Prevented Structure/Elements panel hide settings from hiding panels that are also configured to float.
- Improved Content Studio labels so in-Studio editing and Bricks editing are clearly separated.
- Expanded Content Studio metadata detection for ACF and JetEngine CPT definitions that are not exposed through normal registered post types.

### Changed
- Shortened the update package filename to the `mv-wp-vX.Y.Z.zip` format while keeping the internal WordPress plugin folder as `variable-engine`.

## v1.2.102

### Fixed
- Fixed Plugin Studio and CSS Studio standalone centering by excluding both Studio panels from the older utility-panel transform rule and including them in the center-screen Studio CSS block.
- Added outside-click closing behavior for Plugin Studio so it behaves like the other Studio panels.
- Replaced remaining native Settings and Modules checkboxes with the shared MV checkbox component for consistent styling across admin and builder.
- Added a lightweight Bricks media-control bridge that opens Media Studio from common Bricks image/media controls without mutating Bricks save state directly.

### Changed
- The v1.2.102 package includes the v1.2.101 Studio polish pass plus the final centering, checkbox, and media-control bridge fixes.

## v1.2.101

### Added
- Added Plugin Studio as a Builder Tools module for plugin listing, filtering, activation/deactivation, auto-update toggles, native update links, and inactive plugin deletion.
- Media Studio now supports batch deselect, in-modal new collection creation from a selection, and selected-asset collection membership display with an explicit add-to-collection action.
- Media Studio now has a branded media rename confirmation flow with title-only and file-URL rename options.
- Content Studio now supports in-studio title, slug, and status editing for content rows.

### Fixed
- Hardened Media Studio grid rendering with fixed grid tracks and stable media card dimensions to prevent asset overlap.
- Fixed folder collection membership refresh by including detected folder data in the collection filter dependencies.
- Preserved FileBird parent-folder relationships when detected, allowing sub-collections to appear instead of flattening all folders.
- Improved Content Studio grouping so default content, true custom post types, plugin/system types, and field groups are separated and can be hidden or shown.
- Replaced remaining native selects and checkbox lists in Studio forms with MV-styled controls.
- Restored CSS Studio workspace sizing inside the large studio shell.
- Rebuilt the MV-owned structure shortcut rail to use Phosphor icon classes and readable tooltip labels instead of copied shortcut letters.

### Changed
- Applied lean MV-styled scrollbars and consistent control heights across Studio surfaces.
- Clarified Media Studio replace/convert action labels and tooltips.

## v1.2.100

### Added
- Media Studio now loads media through paginated WordPress media requests instead of stopping at the first 60 items.
- Media Studio now reads supported media-folder plugin data through the existing folder endpoint and exposes detected folders as system collections.
- Media Studio now supports Ctrl/Cmd-click toggling and Shift-click range selection in grid and list views.
- Media Studio batch "Add to Collection" now opens a branded chooser and can route items into existing local collections or detected folder-plugin collections.
- Media Studio collection names can use slash paths for sub-collections, and the icon picker now loads the full local Phosphor duotone catalog for searchable icon selection.
- Media Studio now has replace-file and image-conversion actions for selected assets.
- Builder Tools adds a setting to use an MV-owned shortcut rail beside the floated Structure panel.

### Fixed
- Content Studio route calls now use the registered `variable-engine/v1` namespace, fixing empty/slow content loading caused by the old `ve/v1` path.
- Removed the redundant Content Hub title in Content Studio.
- Media Studio grid cards now use fixed grid tracks, internal selection rings, and no hover scaling to prevent overlap.
- Media Studio type/sort controls now use the branded custom select menu instead of native dropdowns.
- Media Studio file-name fields, font-file previews, dropzone behavior, and full-screen drag/drop feedback were restyled to match the product UI.
- Builder Tools delays Structure floating until Bricks loading/preloader screens are gone.
- Structure panel handle/resize tooltips now render above the panel chrome instead of being clipped below it.
- Figma pairing state is now stamped to the current Figma file identity so older/shared storage cannot make unrelated files appear paired to the same site.
- Dark UI surfaces were pulled back toward the product's black/charcoal palette instead of drifting blue.

## v1.2.99

### Added
- Media Studio: Added dynamic collection creation with a Phosphor duotone icon picker grid, allowing custom-defined collections instead of hardcoded defaults.
- Media Studio: Added MIME type filter dropdown (`all`, `image`, `video`, `audio`, `application`) next to search, along with persistent sort dropdown (Newest, A-Z, Largest).
- Media Studio: Implemented a transparency grid background (`.ve-checker-bg`) for images with transparent backgrounds in the gallery, list view, and attachment details preview.
- Media Studio: Replaced browser `confirm()` calls for deleting media and batch deletes with custom `ConfirmModal` overlays.
- Content Studio: Replaced browser `confirm()` calls for deleting posts, CPTs, field groups, and fields with custom `ConfirmModal` overlays.

### Fixed
- Media Studio: Removed the redundant "Asset Manager" sidebar title.
- Media Studio: Removed hardcoded "Testimonials" and "Team" collections, migrating any existing client lists to dynamic keys.
- Media Studio: Fixed preview pane switching latency (keyed details sidebar on selected item ID to force re-mount).
- Media Studio: Fixed selection highlight styling to prevent grid item overlap in gallery mode.
- Media Studio: Aligned file name field height, padding, and font family in the details sidebar.

## v1.2.98

### Added
- Content Studio: Guarded CPT and Field creation triggers and dropdown selections by provider activity (ACF/JetEngine) and set active provider defaults dynamically on load.

### Fixed
- Drag Freeze: Stabilized structure panel dragging by removing pointerup/mouseup propagation swallowing in `settings-manager.js`, allowing standard browser and builder drag cleanup to complete correctly.
- Centering: Fixed widescreen centering offsets for Content Studio and Media Studio by excluding them from the runtime injected `transform: none` rule in `builder-panel.js` and raising selector specificity in `builder.css`.
- Performance: Optimized the `globalPanelDOMObserver` MutationObserver by implementing a fast pre-filter to bypass queries on routine/minor builder DOM changes.

### Documentation
- Hardened the Antigravity/Codex operating layer with explicit agent quality, UI quality, validation, and release-runbook rules.
- Added canonical docs for agent quality gates, UI standards, and release packaging.
- Updated the setup script to prefer the current checked-in docs instead of regenerating stale weaker templates.

## v1.2.97

### Added
- Reintroduced post-v1.2.93 feature work in a syntax-valid state.
- Modules settings panel deactivation tab to turn off CSS Studio, Mimam's Bar, Content Studio, and Media Studio.
- Speed-dial FAB menu visibility logic: hides the FAB completely when any panel is open.
- Centered widescreen layouts (max-width: 1920px, height: 80dvh) for Content Studio CPT categories and Media Studio 3-column designs.
- Alt-text auto-save on blur, image dimensions, insert URL, and Copy HTML tag features in Media Studio.
- Multi-select batch actions (Add to collection, Compress, Delete) in Media Studio.

### Fixed
- Fixed settings reset on plugin update using robust direct `localStorage` fallbacks in `settings-manager.js`.
- Configured Mimam's Bar module to completely bypass asset enqueuing when deactivated.

## v1.2.96

### Fixed
- Recovery release based on the last confirmed working `v1.2.93` codebase.
- Removed the broken `v1.2.94`/`v1.2.95` JavaScript package line from the stable update path.
- Restored a syntax-valid WordPress panel package while keeping Content Studio and Media Studio at their last verified `v1.2.93` behavior.

### Notes
- The `v1.2.94` Content/Media Studio redesign and `v1.2.95` Modules settings work are intentionally held back for re-implementation in smaller verified slices.

## v1.2.95

### Added
- Added a "Modules" settings tab inside the Unified Settings Panel to let users deactivate individual tools (CSS Studio, Mimam's Bar, Content Studio, and Media Studio).
- Deactivating a tool immediately hides its icon/item from the speed-dial FAB menu and auto-closes any of its open panels.
- Configured Mimam's Bar to completely bypass asset enqueuing when deactivated.
- Organized the workspace root by moving utility script files (`update_notion_*.js`, `read_roadmap.py`, etc.) into a dedicated `scripts/` directory.

### Fixed
- Fixed FAB speed-dial visibility: the floating FAB menu icon now hides completely when any panel (Settings, Help, CSS Studio, Content Studio, Media Studio, or the main bar) is open.

## v1.2.94

### Added
- Upgraded Content Studio and Media Studio layouts to centered widescreen layouts (max-width: 1920px, height: 80dvh) that disable drag/float/dock controls.
- Added Content Studio sidebar navigation categories (Default CPTs, Custom Post Types, and Custom Field Groups) with a detailed tabular list displaying ID, Title, Slug, Status Badge (clickable to toggle), and dates.
- Added Media Studio three-column design layout (left sidebar collections, middle gallery/list layout modes, and right attachment details sidecar).
- Integrated Alt Text auto-save on blur, image dimensions, insert URL copy, and HTML tag copy in Media Studio sidecar.
- Added multi-select batch actions bar (Add to collection, Compress, and Delete) at the bottom of Media Studio.
- Styled all studio inputs, textareas, and dropdown selects with dark glassmorphic styling.

### Fixed
- Fixed settings reset on update by writing direct localStorage fallbacks in `settings-manager.js` storage functions.

## v1.2.93

### Fixed
- Fixed a bug in the Content Studio where selecting the "Content Type" (Page or Post) in the dropdown immediately redirected the user away and defaulted the created type to Post. It now uses a dedicated local state `contentType` and functions correctly.

## v1.2.92

### Added
- Implemented **Content Studio** floating panel to manage pages and posts, support search, quick-toggle status (Publish/Draft), and quick-create new pages/posts with a direct "Edit in Bricks" setup.
- Implemented **Media Studio** floating panel functioning as a premium, glassmorphic WordPress Media Gallery replacement with search, drag-and-drop file uploading, attachment details, and link/HTML copies.
- Added dedicated speed-dial FAB tray icons for the new Content Studio (`ph-file-text`) and Media Studio (`ph-image`).

### Fixed
- Fixed floated structure panel disappearing bug by bypassing bounding client rect height checks on exact matches, maintaining floating state when minimized or natively toggled.
- Fixed shortcut rail positioning by locking width to `44px` with compact padding, and attaching a style MutationObserver to shield positioning from Advanced Themer script overrides.

## v1.2.91

### Added
- Styled Advanced Themer shortcut tooltip balloons (`.brxc-shortcut-balloon`) to match the dark glassmorphic theme and elevated their `z-index` to `2147483015` to prevent rendering behind floated panels.
- Upgraded floated panels' resize indicators (`.mimams-bar-float-resize`) to render as a fully rounded centered pill handle that dynamically expands and glows with `#baf400` color on hover.

### Fixed
- Implemented a DOM `MutationObserver` on `document.body` to listen for additions of structure panel or shortcut rail nodes and synchronize them in real-time, preventing misalignment when Bricks or Advanced Themer detaches and re-appends them.

## v1.2.90

### Fixed
- Hotfixed a critical browser freezing and lag issue affecting standard WordPress Admin screens and the Bricks builder, caused by an infinite MutationObserver loop in the speed-dial FAB repositioning effect (`useEffect` inside `builder-panel.js`).
- Optimized the FAB position MutationObserver to run only when at least one side panel is open, completely bypassing body element observation on standard closed-state dashboard pages.
- Configured the observer to ignore mutations triggered on the speed-dial FAB itself (`fab.contains(m.target)`), ensuring layout mutations do not trigger recursive observer callbacks.

## v1.2.89

### Added
- Moved CSS Studio settings (SCSS Mode toggle, priority drag-and-drop sources list, index rebuild operations, and instructions) to a dedicated **"CSS Studio"** tab inside the main unified settings panel.
- Implemented real-time synchronization between the main settings panel and the CSS Studio editor using a custom event-driven observer pattern (`ve-css-settings-changed`).
- Implemented dynamic positioning for the speed-dial FAB wrap: it now remains visible when panels are open and automatically slides to the left edge of the active panel (or to the right edge if the panel is docked left), adjusting sub-menu and tooltip alignments accordingly.
- Speed-dial FAB icon now toggles the main panel on click (`sO(prev => !prev)` instead of `sO(true)`).

### Fixed
- Repaired floated structure panel detection in `isReasonableSidePanel`: exact class/ID selectors bypass size and position checks, ensuring the panel is correctly recognized, cached, and floated even when temporarily collapsed to `width: 0 !important` by CSS rules.

## v1.2.88

### Added
- Minimize button tooltip text updated to `"Minimize structure panel"`.

### Fixed
- Fixed macOS Genie minimization transition by capturing active panel coordinates right before minimization and adding transition delays to `visibility: hidden` (prevents instant opacity cutoffs and glitches).
- Fixed floating structure panel self-disappearing bug by enhancing `MutationObserver` checks to detect inline `display: none` resets and missing coordinate properties while ignoring active drag/resize operations.
- Fixed shortcut rail sync by dynamically querying the rail element in drag listeners if the node is detached/re-created by Bricks/Advanced Themer.
- Aligned shortcut rail position margin to a consistent `16px` everywhere.
- Fixed custom tooltip clipping and stacking by elevating the rail `z-index` to `2147483005` (with tooltips at `2147483010`) and applying `overflow: visible !important` to the rail and all of its descendants.

## v1.2.87

### Added
- Caches the shortcut rail DOM reference when dragging starts rather than querying the DOM repeatedly.
- Sets custom tooltip attribute `data-tooltip` to say "Minimize structure panel" on the minimize button.

### Fixed
- Fixed macOS Genie minimization transition by removing inline `transform: none !important` locking styles when minimized and drag-end cleans up.
- Fixed floating panel glitching/disappearing-on-own behavior by simplifying MutationObserver style loops (observes only `position`).
- Fixed custom tooltips display order by elevating shortcut rail z-index to `2147483004` (higher than structure panel `2147483002`).
- Fixed clipping of custom tooltips inside container components by setting `overflow: visible !important` on `[data-tooltip]` elements.

## v1.2.86

### Added
- Implemented smooth macOS-style Genie minimization scale and translate transitions for the floating structure panel and the rail.
- Added custom HTML tooltips (`data-tooltip`) styled like the bottom speed-dial tooltips to replace browser-default ones.
- Added drag transition bypass on the shortcut rail to prevent layout lag or misalignment during drag.

### Fixed
- Fixed stuck standalone panels (Settings, Help, CSS Studio) by styling their closed state (opacity 0, visibility hidden, pointer-events none, scale 0.9).
- Synchronized dragging offsets and aligned spacing margin to a consistent 16px between the structure panel and the shortcut rail.
- Increased default visibility and contrast of shortcut rail icons for better readability.

## v1.2.85

### Fixed
- Hotfixed a syntax error in settings-manager.js (removed extra closing brace at line 442) which broke JavaScript execution and caused settings to reset to default on reload.

## v1.2.84

### Fixed
- Fixed floating structure panel minimize/restore button functionality so it collapses and restores reliably on click.
- Stopped pointerdown event propagation on the minimize button to prevent builder drag handlers from intercepting the action.
- Enforced high-specificity CSS overrides targeting ID selectors (e.g. `#bricks-structure.mimams-bar-structure-minimized`) and the floating structure rail to prevent style resets during element inspection.

## v1.2.83

### Added
- Added lazy-mounted keep-alive state tracking for panels.
- Added mutual exclusion behavior between all open panels so that opening one closes another.
- Added scale-in/out visual transitions for standalone panels.
- Disabled standalone panel draggability while retaining handles.
- Styled standalone panel float handles to match the Variable panel, and applied a modern dot-pattern radial resize gripper.
- Applied brand color `#baf400` to Advanced Themer shortcut icons and hid empty shortcut wrappers in floating mode.
- Added dynamic semantic `ul` wrapper correction for Advanced Themer shortcut items.

### Fixed
- Clamped docked layout heights and positions on WP Admin load to prevent offscreen/misplaced panels.
- Resolved settings close button container height overflow via `flex: 1; min-height: 0`.
- Optimized query/variable name lowercasing for improved fuzzy search performance.
- Implemented a `MutationObserver` on floated panels to restore layout styles dynamically under inspector mutations.
- Intercepted pointerdown, mousedown, and click events on `.mimams-bar-toggle-button` in the capture phase to toggle Mimam's Bar and prevent duplicate open triggers.

## v1.2.82

### Fixed
- Fixed standalone panel heights (Settings, Help, CSS Studio) to dynamically match the Variable panel state (docked vs. floating) down to the pixel, removing hardcoded important heights.
- Repaired the structure panel minimize button SVG coordinates and attributes, resolving the malformed diagonal slash.
- Resolved Bricks and Advanced Themer shortcut rail positioning overlap and synchronization issues by applying explicit physical positioning and sizing overrides (`left`, `right: auto`, `top`, `bottom: auto`, `height` with `!important`).

## v1.2.81

### Fixed
- Matched Settings, Help, and CSS Studio standalone panel heights with the Variable panel exactly down to the pixel.
- Fixed CSS Studio editor sidecar visibility and layout clipping by removing nested scrollable containment.
- Fixed mutual exclusion of open panels so that multiple standalone panels can remain open at the same time.
- Synchronized BricksExtras and Advanced Themer shortcut rails in real-time on structure panel drag and resize.
- Fixed broken structure panel drag handle grab icon and positioned the minimize button as a header sibling.

## v1.2.80

### Added
- Implemented structure panel minimize/restore button interactions. Clicking the minimize button collapses the panel to a tree icon next to the bottom-right speed-dial, and clicking the restore button restores it.
- Enabled responsive sidecar placement for the CSS Studio sidecar (renders direct sibling outside scrollable `.ve-body`).

### Fixed
- Matched standalone panel heights (Settings, Help, CSS Studio) with the Variable panel.
- Fixed CSS Studio settings layout overlap and duplicate headers.
- Fixed BricksExtras shortcut container overlap by dynamically positioning it with a 16px space gap on the side of the structure panel, extracting it to the document body to prevent container containment clipping.
- Raised structure panel z-index to `2147483002` to render above canvas components.
- Fixed update transient caching by unsetting the stale response key in the updater cache.

## v1.2.79

### Fixed
- Restored pointer interaction (`pointer-events: auto !important`) on all standalone panels (Settings, Help, CSS Studio), allowing click, drag, and scroll operations instead of clicking through.
- Fixed the sticky "update available" notification issue by hooking into `upgrader_process_complete` and purging WordPress's plugin updates cache transient immediately after updates complete.

## v1.2.78

### Fixed
- Fixed bug where standalone panels (Settings, Help, CSS Studio) opened outside the viewport boundaries to the right.
- Excluded WordPress update pages (`update.php`, `update-core.php`) from loading the speed-dial menu assets to prevent centered floating icon visual issues.

## v1.2.77

### Added
- Consolidated settings: General/Vengine and Mimam's Bar settings are now unified inside a single standalone Settings panel using tabbed navigation.
- Extracted CSS Studio from the main command console into a standalone premium floating panel, toggled directly by the code icon in the bottom-right speed-dial menu.
- Enabled the speed-dial FAB menu and all floating panels (Settings, Help, CSS Studio) to render and function on standard WordPress Admin screens in addition to the Bricks builder.
- Implemented global click-outside-to-close behavior: clicking outside any standalone panel or command console automatically closes it.

### Fixed
- Fixed scrolling inside the floated Bricks structure panel by establishing correct flexbox height inheritance rules on nested panels.
- Standardized settings label text to "Undock Mimam's Bar and remember position".

## v1.2.76

### Added
- Extracted Settings and Help panels from the main Mimam's Bar command console into standalone floating windows.
- Added a Help icon (`ph('question')`) to the bottom-right speed-dial menu.
- Connected speed-dial menu clicks to directly toggle Settings and Help standalone panels.
- Enabled drag position management on standalone panels independently of the main bar's docking settings.
## v1.2.75

### Added
- Implemented a 'Deselect Element' shortcut for Bricks Builder, defaulting to Esc or Shift+D via settings.
- Refined the bottom-right hub into an intentional speed-dial menu that expands on hover.
- Added new settings to hide or show Vengine and Mimam's Bar icons from the Bricks top toolbar, dynamically clearing clutter.

## v1.2.74

### Fixed
- Replaced the hardcoded pixel-based initialization height for floating panels with a dynamic `70dvh` CSS value to keep the interface deeply responsive without constant recalibrations.
- Injected a dedicated `.mimams-bar-structure-wrapper` directly into the DOM to seamlessly group `#bricks-panel-header`, `.panel-content`, and `#brxcStructureTopContainer` within the Structure panel to maintain clean flex and grid behavior.
- Disabled transitions completely (`transition: none !important`) on floating host wrappers to outright kill any remaining native FOUC animations from Bricks.
- Scoped `#bricks-panel-header` `nowrap` explicitly to `#bricks-panel-elements` to ensure the structure panel continues to correctly wrap its header elements down.

### Fixed
- Enforced 70% window height explicitly for the floating structure panel to match the elements panel identically.
- Overhauled the early FOUC prevention script to instantly inject classes directly onto `<html>` before the body even paints, completely eliminating the brief docked flash on page load.
- Grouped the panel drag handle and `.title` element together in the DOM, forcing `.actions` underneath via flex wrapping for a cleaner header layout.
- Standardized the `#bricks-panel-search` input height so it strictly matches the height of its placeholder, resolving awkward vertical sizing.

### Fixed
- Eliminated the FOUC (Flash of Unstyled Content) where panels glitched in docked mode before switching to float on page load. A MutationObserver early script now seamlessly applies the floating classes as the body renders.
- Corrected `#bricks-panel-header` padding to ensure consistent spacing and aligned the drag handle perfectly horizontally on the same line as the header content.
- Ensured the Structure panel respects its native content height when floating instead of erroneously expanding to full screen height.
- Added a 2rem spacing gap before the BricksExtras shortcut container in the structure panel and aligned its items to the center.

### Fixed
- Fixed elements panel initializing with a short height by using window.innerHeight minus 100px.
- Unhid the structure panel header when floated, making the drag handle visible again.
- Removed the "Elements" and "Structure" text from the drag handles to prevent redundant "mimams bar floating panel" labels.
- Removed the 38px padding block start from floating panels and reset BricksExtras shortcut container padding to zero.

## v1.2.70

### Fixed

- Resolved the elements panel glitching on hide/unhide while floating by fixing the wrapper detection logic (`findPanelFromNode`) in `findElementsPanel`.
- Prevented the structure panel from losing its floating height when the browser resizes (e.g., opening Inspector) by explicitly setting `height` and `max-height` inline properties.
- Relocated the float drag handle inside the native Bricks panel headers.
- Replaced the online Phosphor icon with the local duotone SVG `dots-six-vertical-duotone.svg` for better styling.

## v1.2.69

### Fixed

- Resolved UI "freezes and lags" by removing forced heavy DOM scans during panel state retries in `settings-manager.js`.
- Fixed panel toggle glitches where Bricks panel widths would fall to 0, causing the detector to lose track and flicker.
- Re-introduced a safe wrapper bounding box logic (`markSafeHosts`) to collapse intermediate Bricks host wrappers, fixing "ghost background" when floating panels.

## v1.2.68

### Changed

- Re-wrote `builder.css` panel logic to use native Bricks ID selectors instead of tracking dynamic classes with JS.
- Replaced JS bounds-checking logic (`markFloatingHostChain`) with CSS-only visibility states based on `body` classes.

### Fixed

- Fixed floating panel bounds issues causing visual ghosting/flicker.
- Fixed the update manifest to resolve WordPress infinite update loop (bumped from v1.2.64 to v1.2.65, now correctly pointing to v1.2.68).

## Unreleased

### Added

- Added Vengine Agent OS folder structure and documentation files.

### Changed

- Updated `build.py` and manifest to `v1.2.66`.
- Redesigned floating panel UI drag handle to properly match the visual design of the main `.baqa-panel` header, adding left alignment, padding, and neon green panel titles (c01 fix).

### Fixed

- Hiding the Elements panel now correctly collapses its native wrapper completely (c02 fix). Fixed the `markFloatingHostChain` loop logic that was un-marking hidden elements due to `width: 0`, and added `opacity: 0`/`overflow: hidden` to ensure no grey background remains.
- **HOTFIX (v1.2.65)**: `VE_VERSION` constant on line 17 was still `1.2.64` while the header said `1.2.65`, causing an infinite WordPress update loop. Both now read `1.2.65`.

### Notes

- Future Antigravity agents should update this file after implementation work.
