<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Backup\PackageCipher;

defined( 'ABSPATH' ) || exit;

final class RestoreWorkspace {
    public function create( string $snapshot_key ): array {
        $workspace_key = 'workspace-' . sanitize_file_name( $snapshot_key ) . '-' . gmdate( 'Ymd-His' );
        $path = LocalStorage::ensure_workspace_dir( $workspace_key );

        return [
            'ok'            => is_dir( $path ) && is_writable( $path ),
            'workspace_key' => $workspace_key,
            'path'          => $path,
            'extracted'     => trailingslashit( $path ) . 'extracted/',
            'database'      => trailingslashit( $path ) . 'database/',
            'files'         => trailingslashit( $path ) . 'files/',
            'plans'         => trailingslashit( $path ) . 'plans/',
            'message'       => is_dir( $path ) && is_writable( $path ) ? 'Temporary restore workspace created.' : 'Temporary restore workspace could not be created.',
        ];
    }

    public function extract_package( string $package_path, array $workspace, string $passphrase = '' ): array {
        if ( ! class_exists( '\ZipArchive' ) ) {
            return [ 'ok' => false, 'message' => 'ZipArchive is required to inspect RestoreBase packages.', 'entries' => [] ];
        }

        $target = isset( $workspace['extracted'] ) ? (string) $workspace['extracted'] : '';
        if ( '' === $target ) {
            return [ 'ok' => false, 'message' => 'Restore workspace extraction folder is missing.', 'entries' => [] ];
        }
        if ( ! is_dir( $target ) ) {
            wp_mkdir_p( $target );
        }
        if ( ! is_dir( $target ) || ! is_writable( $target ) ) {
            return [ 'ok' => false, 'message' => 'Restore workspace extraction folder is not writable.', 'entries' => [] ];
        }

        // Transparently decrypt an encrypted package to a temp file before extraction.
        $resolved = PackageCipher::resolve_readable( $package_path, isset( $workspace['path'] ) ? (string) $workspace['path'] : $target, $passphrase );
        if ( empty( $resolved['ok'] ) ) {
            return [ 'ok' => false, 'message' => (string) $resolved['message'], 'entries' => [], 'encrypted' => true, 'needs_passphrase' => ! empty( $resolved['needs_passphrase'] ) ];
        }
        $package_path = (string) $resolved['path'];
        $decrypted_temp = ! empty( $resolved['temp'] ) ? $package_path : '';

        $zip = new \ZipArchive();
        if ( true !== $zip->open( $package_path ) ) {
            if ( '' !== $decrypted_temp ) {
                @unlink( $decrypted_temp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
            }
            return [ 'ok' => false, 'message' => 'RestoreBase package could not be opened.', 'entries' => [] ];
        }

        $allowed = [ 'manifest.json', 'database.sql', 'file-inventory.json', 'files.restorebase', 'files.zip', 'checksums.json' ];
        $existing = [];
        foreach ( $allowed as $entry ) {
            if ( false !== $zip->locateName( $entry ) ) {
                $existing[] = $entry;
            }
        }

        // Extract package members to disk with ZipArchive instead of loading files.zip into PHP memory.
        // This is much faster and avoids memory pressure on big backups.
        $extracted = empty( $existing ) ? false : @$zip->extractTo( trailingslashit( $target ), $existing ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

        // If the host refuses multi-entry extraction, fall back to streaming one entry at a time.
        if ( true !== $extracted ) {
            foreach ( $existing as $entry ) {
                $destination = trailingslashit( $target ) . $entry;
                $stream = $zip->getStream( $entry );
                if ( ! is_resource( $stream ) ) {
                    continue;
                }
                $out = @fopen( $destination, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged
                if ( is_resource( $out ) ) {
                    while ( ! feof( $stream ) ) {
                        $chunk = fread( $stream, 1024 * 1024 );
                        if ( false === $chunk ) {
                            break;
                        }
                        fwrite( $out, $chunk );
                    }
                    fclose( $out );
                }
                fclose( $stream );
            }
        }

        $zip->close();

        if ( '' !== $decrypted_temp ) {
            @unlink( $decrypted_temp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
        }

        $entries = [];
        foreach ( $existing as $entry ) {
            $destination = trailingslashit( $target ) . $entry;
            if ( ! file_exists( $destination ) ) {
                continue;
            }
            $entries[ $entry ] = [
                'path' => $destination,
                'size' => (int) filesize( $destination ),
                'hash' => is_readable( $destination ) ? (string) hash_file( 'sha256', $destination ) : '',
            ];
        }

        return [
            'ok'      => isset( $entries['manifest.json'] ),
            'message' => isset( $entries['manifest.json'] ) ? 'Package metadata extracted to restore workspace.' : 'Package manifest was not found during workspace extraction.',
            'entries' => $entries,
            'fast_extract' => true,
            'method'  => true === $extracted ? 'ziparchive_extract_to' : 'stream_fallback',
        ];
    }
}