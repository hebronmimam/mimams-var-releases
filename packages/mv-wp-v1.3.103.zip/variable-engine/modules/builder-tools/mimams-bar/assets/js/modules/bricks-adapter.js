(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;

  var Core = window.MimamsBarCore || {};
  var labels = Core.labels || {};
  var MAX_BULK_TARGETS = Core.MAX_BULK_TARGETS || 40;
  var log = Core.log || function () {};
  var makeId = Core.makeId || function () { return 'baqa_' + Math.random().toString(36).slice(2, 9); };

  var BricksAdapter = {
    _manualSelection: null,
    _globalsCache: null,
    _globalsCacheAt: 0,
    _allElementsCache: null,
    _allElementsCacheAt: 0,
    _defaultElementTags: {
      'list-item': 'li',
      'list': 'ul',
      'link': 'a',
      'text-link': 'a',
      'heading': 'h2',
      'section': 'section',
      'container': 'div',
      'block': 'div',
      'div': 'div',
      'image': 'img',
      'video': 'video',
      'button': 'button',
      'icon': 'i',
      'svg': 'svg',
      'form': 'form',
      'nav': 'nav',
      'nav-nestable': 'nav'
    },
    getVueGlobals: function () {
      var now = Date.now ? Date.now() : new Date().getTime();
      if (this._globalsCache && now - this._globalsCacheAt < 650) return this._globalsCache;
      var roots = ['.brx-body', '#bricks-builder', '#brx-builder', '#bricks-panel', 'body'];
      for (var i = 0; i < roots.length; i++) {
        var node = document.querySelector(roots[i]);
        if (node && node.__vue_app__ && node.__vue_app__.config) {
          this._globalsCache = node.__vue_app__.config.globalProperties || null;
          this._globalsCacheAt = now;
          return this._globalsCache;
        }
      }
      this._globalsCache = null;
      this._globalsCacheAt = now;
      return null;
    },

    getState: function () {
      var globals = this.getVueGlobals();
      return globals && globals.$_state ? globals.$_state : null;
    },

    findElementInList: function (id, list) {
      if (!id || !Array.isArray(list)) return null;
      for (var i = 0; i < list.length; i++) {
        var item = list[i];
        if (!item) continue;
        if (item.id === id || item.instanceId === id) return item;
        if (Array.isArray(item.children)) {
          var found = this.findElementInList(id, item.children);
          if (found) return found;
        }
      }
      return null;
    },

    getSelectedElementIdFromDom: function () {
      var selected = document.querySelector('[data-id].selected, [data-id].active, .bricks-draggable-item.selected[data-id], .bricks-draggable-item.active[data-id]');
      return selected ? selected.getAttribute('data-id') : null;
    },

    getManualSelection: function () {
      var manual = this._manualSelection;
      if (!manual || !manual.id) return null;
      // Keep manual search selection long enough for Direct commands, but do
      // not let it override real user selection forever.
      if (Date.now && manual.time && Date.now() - manual.time > 15000) return null;
      var root = this.getMutableElementsRoot ? this.getMutableElementsRoot() : [];
      var found = this.findElementInList(manual.id, root) || manual.element;
      return found && found.id ? found : null;
    },

    getSelectedElement: function () {
      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      var element = null;

      if (state) {
        if (Array.isArray(state.selectedElements) && state.selectedElements.length === 1) {
          element = state.selectedElements[0];
        } else if (state.activeElement && state.activeElement.id) {
          element = state.activeElement;
        }
      }

      if (!element) {
        var id = this.getSelectedElementIdFromDom();
        var dynamicElements = globals && globals.$_dynamicElements && globals.$_dynamicElements.value ? globals.$_dynamicElements.value : null;
        element = this.findElementInList(id, dynamicElements) || this.findElementInList(id, window.bricksData && window.bricksData.elements);
      }

      var manual = this.getManualSelection();
      if (manual && this._manualSelection && this._manualSelection.time && Date.now && Date.now() - this._manualSelection.time < 1800) {
        element = manual;
      }
      if (!element) element = manual;

      return element && element.id ? element : null;
    },

    cssEscape: function (value) {
      value = String(value || '');
      if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);
      return value.replace(/[^a-zA-Z0-9_-]/g, '\\$&');
    },

    findStructureNode: function (id) {
      id = String(id || '').trim();
      if (!id) return null;
      var safe = this.cssEscape(id);
      var selectors = [
        '#bricks-structure [data-id="' + safe + '"]',
        '#bricks-structure-resizable [data-id="' + safe + '"]',
        '.bricks-structure [data-id="' + safe + '"]',
        '.brx-structure [data-id="' + safe + '"]',
        '#brx-structure [data-id="' + safe + '"]',
        '[data-panel="structure"] [data-id="' + safe + '"]',
        '[data-element-id="' + safe + '"]',
        '[data-bricks-id="' + safe + '"]',
        '[data-builder-id="' + safe + '"]',
        '[data-object-id="' + safe + '"]',
        '.bricks-draggable-item[data-id="' + safe + '"]',
        '[data-id="' + safe + '"]'
      ];

      for (var i = 0; i < selectors.length; i++) {
        var node = document.querySelector(selectors[i]);
        if (!node) continue;
        if (node.closest && node.closest('.baqa-panel')) continue;
        return node;
      }
      return null;
    },

    focusElementInStructure: function (element, options) {
      options = options || {};
      if (!element || !element.id) return false;
      var node = this.findStructureNode(element.id);
      if (!node) return false;

      try {
        if (typeof node.scrollIntoView === 'function') node.scrollIntoView({ block: 'center', inline: 'nearest' });
      } catch (e) {
        try { node.scrollIntoView(); } catch (e2) {}
      }

      if (options.click === false) return true;

      try {
        var clickable = node.closest && node.closest('[data-id]') ? node.closest('[data-id]') : node;
        clickable.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
      } catch (e3) {
        try { node.click(); } catch (e4) {}
      }

      return true;
    },

    selectElement: function (element, options) {
      options = options || {};
      if (!element || !element.id) return false;
      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      var selected = false;
      this._manualSelection = { id: element.id, element: element, time: Date.now ? Date.now() : new Date().getTime() };

      // v1.2.54: Bricks uses activeId + setActiveElement() as the real single
      // selection pipeline. Older builds only changed local/manual state, which
      // made the bar target update without the Structure panel actually selecting.
      try {
        if (state) {
          state.activeId = element.id;
          state.activeElement = element;
          state.selectedElement = element;
          state.selectedElements = [];
          state.selectedElementSettings = this.clone(element.settings || {});
          state.activePanel = 'element';
          selected = true;
        }
      } catch (e) { log('selectElement state update failed', e); }

      try {
        if (globals && typeof globals.$_setActiveElement === 'function') {
          globals.$_setActiveElement();
          selected = true;
        }
      } catch (eSet) { log('selectElement setActiveElement helper failed', eSet); }

      try {
        if (globals && typeof globals.$_selectElement === 'function') {
          var fakeEvent = { ctrlKey: false, metaKey: false, shiftKey: false, stopPropagation: function () {}, preventDefault: function () {} };
          globals.$_selectElement(fakeEvent, element.id);
          selected = true;
        }
      } catch (e2) { log('selectElement selectElements helper failed', e2); }

      if (options.focusStructure !== false) {
        try {
          this.focusElementInStructure(element, { click: false });
          selected = true;
        } catch (e3) { log('focusElementInStructure failed', e3); }
      }

      return selected;
    },

    deselectElement: function () {
      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      var deselected = false;
      this._manualSelection = null;

      try {
        if (state) {
          state.activeId = null;
          state.activeElement = null;
          state.selectedElement = null;
          state.selectedElements = [];
          state.selectedElementSettings = {};
          state.activePanel = 'structure';
          deselected = true;
        }
      } catch (e) { log('deselectElement state update failed', e); }

      try {
        if (globals && typeof globals.$_setActiveElement === 'function') {
          globals.$_setActiveElement(null);
          deselected = true;
        }
      } catch (eSet) { log('deselectElement setActiveElement helper failed', eSet); }
      
      // Cleanup DOM just in case Vue missed it
      try {
        var selectedNodes = document.querySelectorAll('.bricks-structure-item.active, .bricks-structure-item.selected, [data-id].active, [data-id].selected');
        for (var i = 0; i < selectedNodes.length; i++) {
          selectedNodes[i].classList.remove('active', 'selected', 'is-active', 'is-selected');
        }
      } catch (e) {}

      return deselected;
    },

    splitClassString: function (value) {
      if (!value) return [];
      if (Array.isArray(value)) {
        return value.reduce(function (all, item) {
          return all.concat(BricksAdapter.splitClassString(item));
        }, []);
      }
      if (typeof value === 'object') {
        if (value.name) return [String(value.name)];
        if (value.value) return BricksAdapter.splitClassString(value.value);
        return [];
      }
      return String(value).trim().split(/\s+/).filter(Boolean);
    },

    getGlobalClasses: function () {
      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      return state && Array.isArray(state.globalClasses) ? state.globalClasses : [];
    },

    _globalClassNameMapCache: null,
    _globalClassNameMapCacheAt: 0,
    getGlobalClassNameMap: function () {
      var now = Date.now ? Date.now() : new Date().getTime();
      if (this._globalClassNameMapCache && now - this._globalClassNameMapCacheAt < 650) {
        return this._globalClassNameMapCache;
      }

      var classes = this.getGlobalClasses();
      var map = {};

      classes.forEach(function (item) {
        if (item && item.id && item.name) {
          map[item.id] = item.name;
        }
      });

      this._globalClassNameMapCache = map;
      this._globalClassNameMapCacheAt = now;
      return map;
    },

    findGlobalClassByName: function (name) {
      name = String(name || '').replace(/^\./, '').trim();
      if (!name) return null;

      var classes = this.getGlobalClasses();
      for (var i = 0; i < classes.length; i++) {
        if (classes[i] && classes[i].name === name) return classes[i];
      }

      return null;
    },

    findGlobalClassById: function (id) {
      id = String(id || '').trim();
      if (!id) return null;

      var classes = this.getGlobalClasses();
      for (var i = 0; i < classes.length; i++) {
        if (classes[i] && classes[i].id === id) return classes[i];
      }

      return null;
    },

    createGlobalClass: function (name) {
      name = String(name || '').replace(/^\./, '').trim();
      if (!name) return null;

      var existing = this.findGlobalClassByName(name);
      if (existing) return existing;

      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      if (!state) return null;

      if (!Array.isArray(state.globalClasses)) state.globalClasses = [];

      var id = '';
      try {
        if (globals && typeof globals.$_generateId === 'function') {
          id = globals.$_generateId();
        }
      } catch (e) { log('global class id generation failed', e); }

      if (!id) id = makeId();

      var item = { id: id, name: name, settings: {} };
      state.globalClasses.push(item);

      // Bricks uses this post message after creating global classes. Keep it
      // best-effort so the class manager/chips know about the new class.
      try {
        if (globals && typeof globals.$_postMessage === 'function') {
          globals.$_postMessage({ key: 'globalClassesNew', value: JSON.stringify([item]) });
        }
      } catch (e2) { log('globalClassesNew postMessage failed', e2); }

      return item;
    },

    getElementClasses: function (element) {
      if (!element || !element.settings) return [];

      var settings = element.settings;
      var classNames = [];
      var globalMap = this.getGlobalClassNameMap();

      // Bricks renders global classes first and then the manual CSS classes.
      // Keep that order so the Target row reflects the final class flow.
      if (Array.isArray(settings._cssGlobalClasses)) {
        settings._cssGlobalClasses.forEach(function (classId) {
          var name = globalMap[classId] || classId;
          if (name) classNames.push(String(name));
        });
      }

      classNames = classNames.concat(this.splitClassString(settings._cssClasses));

      return classNames.filter(function (name, index, list) {
        return name && list.indexOf(name) === index;
      });
    },

    getElementCssId: function (element) {
      var settings = element && element.settings ? element.settings : {};
      if (settings._cssId) return String(settings._cssId);
      if (settings.cssId) return String(settings.cssId);
      return '';
    },

    getElementIdentity: function (element) {
      return {
        id: this.getElementCssId(element),
        classes: this.getElementClasses(element)
      };
    },

    getElementCustomLabel: function (element) {
      if (!element) return '';
      var settings = element.settings || {};
      var candidates = [
        element.label, element.title, element.customLabel, element.structureLabel, element.adminLabel, element.nameLabel,
        settings.label, settings._label, settings.customLabel, settings._customLabel, settings.adminLabel, settings._adminLabel,
        settings._cssCustomLabel, settings._structureLabel, settings.structureLabel, settings.elementLabel, settings._elementLabel
      ];
      for (var i = 0; i < candidates.length; i++) {
        var value = String(candidates[i] || '').trim();
        if (value && value !== String(element.name || '').trim()) return value;
      }
      return '';
    },

    getElementDisplayType: function (element) {
      if (!element) return 'Element';
      return String(element.name || element.element || element.tag || element.type || element.label || 'Element');
    },

    getElementFullLabel: function (element) {
      if (!element) return 'No element selected';

      var parts = [];
      var type = this.getElementDisplayType(element);
      var customLabel = this.getElementCustomLabel(element);
      var classes = this.getElementClasses(element);
      var cssId = this.getElementCssId(element);

      parts.push(String(type));
      if (customLabel) parts.push('“' + customLabel + '”');
      if (cssId) parts.push('#' + cssId);
      if (classes.length) {
        parts.push(classes.map(function (className) { return '.' + className; }).join(' '));
      }
      parts.push('· Bricks ID: ' + String(element.id));

      return parts.join(' ');
    },

    getElementLabel: function (element) {
      if (!element) return 'No element selected';

      var parts = [];
      var type = this.getElementDisplayType(element);
      var customLabel = this.getElementCustomLabel(element);
      var classes = this.getElementClasses(element);
      var cssId = this.getElementCssId(element);

      parts.push(String(type));
      if (customLabel) parts.push('“' + customLabel + '”');
      if (cssId) parts.push('#' + cssId);
      if (classes.length) {
        parts.push(classes.length === 1 ? '.' + classes[0] : classes.length + ' classes');
      }
      parts.push('· Bricks ID: ' + String(element.id));

      return parts.join(' ');
    },

    isCanvasEventTarget: function (target) {
      if (!target || target === document) return false;
      if (target.tagName === 'IFRAME') return true;
      if (!target.closest) return false;

      var directCanvas = target.closest('iframe, #bricks-builder-iframe, .bricks-builder-iframe, .brx-iframe, #brx-iframe, #bricks-builder-canvas, #brx-canvas, .bricks-canvas, .brx-canvas, #bricks-preview, #brx-preview, .bricks-preview, .brx-preview, .brx-body, #brx-content');
      if (directCanvas) return true;

      var node = target;
      while (node && node !== document && node.nodeType === 1) {
        var id = String(node.id || '').toLowerCase();
        var className = String(node.className || '').toLowerCase();
        if (id.indexOf('canvas') !== -1 || id.indexOf('iframe') !== -1 || id.indexOf('preview') !== -1) return true;
        if (className.indexOf('canvas') !== -1 || className.indexOf('iframe') !== -1 || className.indexOf('preview') !== -1) return true;
        node = node.parentNode;
      }

      return false;
    },

    isCanvasElementTarget: function (target) {
      if (!target || target.nodeType !== 1) return false;
      if (!target.closest) return false;

      var elementNode = target.closest('[id^="brxe-"], [data-id], [data-brx-id], [data-element-id], [data-builder-element-id], .bricks-draggable-root, .brx-draggable-root');
      if (!elementNode) return false;

      var tag = String(elementNode.tagName || '').toLowerCase();
      if (tag === 'html' || tag === 'body') return false;

      return true;
    },

    normalizeAttributes: function (settings) {
      var list = settings && Array.isArray(settings._attributes) ? settings._attributes.slice() : [];
      return list.filter(function (item) { return item && item.name; }).map(function (item) {
        return {
          id: item.id || makeId(),
          name: String(item.name),
          value: item.value == null ? '' : String(item.value)
        };
      });
    },

    getElementAttributes: function (element) {
      if (!element || !element.settings) return [];
      return this.normalizeAttributes(element.settings);
    },

    walkElements: function (list, callback, visited) {
      if (!Array.isArray(list)) return;
      visited = visited || (typeof Set !== 'undefined' ? new Set() : []);
      for (var i = 0; i < list.length; i++) {
        var item = list[i];
        if (!item || typeof item !== 'object') continue;
        
        // Retrieve rawItem for visited tracking to prevent proxy vs raw mismatch loops
        var rawItem = BricksAdapter._toRaw ? BricksAdapter._toRaw(item) : item;
        if (typeof Set !== 'undefined') {
          if (visited.has(rawItem)) continue;
          visited.add(rawItem);
        } else {
          if (visited.indexOf(rawItem) !== -1) continue;
          visited.push(rawItem);
        }
        
        callback(item);
        var children = item.children;
        if (Array.isArray(children)) {
          // Strip reactivity from children array if possible
          var rawChildren = BricksAdapter._toRaw ? BricksAdapter._toRaw(children) : children;
          BricksAdapter.walkElements(rawChildren || children, callback, visited);
        }
      }
    },

    _toRaw: function (value) {
      // Vue 3 toRaw strips reactive proxies so property access does not
      // trigger watchers/dependency tracking.  Without this, walking a
      // large element tree causes a CPU-bound getter storm that freezes
      // the browser.
      if (typeof window.Vue !== 'undefined' && typeof window.Vue.toRaw === 'function') return window.Vue.toRaw(value);
      if (typeof window.toRaw === 'function') return window.toRaw(value);
      // Bricks exposes Vue on the app instance
      try {
        var globals = this._globalsCache;
        if (globals && globals.$_app && globals.$_app.__vue_app__) {
          var vue = globals.$_app.__vue_app__;
          if (vue.config && vue.config.globalProperties && typeof vue.config.globalProperties.$toRaw === 'function') {
            return vue.config.globalProperties.$toRaw(value);
          }
        }
      } catch (e) {}
      // Vue 3 marks reactive objects with __v_raw
      if (value && typeof value === 'object' && value.__v_raw) return value.__v_raw;
      return value;
    },

    getMutableElementsRoot: function () {
      var globals = this.getVueGlobals();
      if (globals && globals.$_dynamicElements && globals.$_dynamicElements.value) {
        var raw = this._toRaw(globals.$_dynamicElements.value);
        return raw || globals.$_dynamicElements.value;
      }
      if (window.bricksData && Array.isArray(window.bricksData.elements)) {
        return window.bricksData.elements;
      }
      return [];
    },

    getAllElements: function (options) {
      options = options || {};
      var now = Date.now ? Date.now() : new Date().getTime();
      if (!options.fresh && this._allElementsCache && now - this._allElementsCacheAt < 900) {
        return this._allElementsCache;
      }
      var items = [];
      var root = this.getMutableElementsRoot();
      var self = this;
      this.walkElements(root, function (item) {
        if (!item) return;
        // Strip Vue reactive proxy from each element so later property
        // reads (tag, settings, classes) do not trigger dependency storms.
        var raw = self._toRaw(item);
        if (raw && raw.id) items.push(raw);
        else if (item.id) items.push(item);
      });
      this._allElementsCache = items;
      this._allElementsCacheAt = now;
      return items;
    },

    getBricksElementConfigs: function () {
      var data = window.bricksData && window.bricksData.elements ? window.bricksData.elements : {};
      return Object.keys(data).map(function (name) {
        var item = data[name] || {};
        return {
          name: name,
          label: item.label || item.title || item.name || name,
          category: item.category || item.group || '',
          icon: item.icon || ''
        };
      }).filter(function (item) {
        return item && item.name;
      });
    },

    addBricksElement: function (name, options) {
      options = options || {};
      name = String(name || '').trim();
      if (!name) return { ok: false, reason: 'missing-element-name' };

      var globals = this.getVueGlobals();
      if (!globals || typeof globals.$_addNewElement !== 'function') {
        return { ok: false, reason: 'add-helper-missing' };
      }

      var elementConfig = options.config || {};
      var payloadElement = { name: name };

      try {
        var fullConfig = window.bricksData && window.bricksData.elements && window.bricksData.elements[name]
          ? window.bricksData.elements[name]
          : null;
        if (fullConfig && typeof fullConfig === 'object' && !Array.isArray(fullConfig)) {
          payloadElement = this.clone(fullConfig);
          payloadElement.name = name;
        }
      } catch (e0) {}

      if (elementConfig && elementConfig.label && !payloadElement.label) {
        payloadElement.label = elementConfig.label;
      }

      var payload = { element: payloadElement, keepLabel: false };
      if (typeof options.parent !== 'undefined') payload.parent = options.parent;
      if (typeof options.index !== 'undefined') payload.index = options.index;

      try {
        var eventLike = options.event || { shiftKey: true, preventDefault: function () {}, stopPropagation: function () {} };
        var added = globals.$_addNewElement(payload, eventLike, true);
        if (added && added.id) {
          this._allElementsCache = null;
          try { this.selectElement(added); } catch (e) {}
          return { ok: true, element: added };
        }
        return { ok: true, element: this.getSelectedElement() };
      } catch (e2) {
        log('addBricksElement failed', e2);
        return { ok: false, reason: 'add-failed', error: e2 };
      }
    },

    getElementTagName: function (element) {
      if (!element) return '';
      var rawSettings = element.settings;
      if (rawSettings && this._toRaw) rawSettings = this._toRaw(rawSettings);
      var settings = rawSettings || {};
      
      // 1. Check settings custom tag overrides (e.g., custom tags set by user)
      var candidates = [settings.tag, settings._tag, settings.htmlTag, settings._htmlTag, settings.tagName, element.tag, element.htmlTag];
      for (var i = 0; i < candidates.length; i++) {
        var value = String(candidates[i] || '').trim().toLowerCase();
        if (!value) continue;
        if (/^(section|div|article|main|header|footer|figure|img|h1|h2|h3|h4|h5|h6|p|span|a|button|ul|ol|li|form|input|textarea|nav)$/.test(value)) {
          return value;
        }
      }
      
      // 2. Check default tag mapping for Bricks element types (e.g., list-item defaults to li, list to ul)
      var name = String(element.name || '').trim().toLowerCase();
      if (this._defaultElementTags && this._defaultElementTags[name]) {
        return this._defaultElementTags[name];
      }
      
      // 3. Fallback to name/label
      return name || String(element.label || '').trim().toLowerCase();
    },

    describeBulkTarget: function (target) {
      if (!target) return 'unknown target';
      if (target.mode === 'tag') return 'all ' + target.value;
      if (target.mode === 'class') return '.' + target.value;
      if (target.mode === 'id') return '#' + target.value;
      if (target.mode === 'type') return 'type:' + target.value;
      return target.mode + ':' + target.value;
    },

    matchesBulkTarget: function (element, target) {
      if (!element || !target) return false;
      var value = String(target.value || '').trim();
      if (!value) return false;

      if (target.mode === 'tag') {
        var tagLower = value.toLowerCase();
        if (this.getElementTagName(element) === tagLower) return true;
        // Also match against the Bricks element type name so
        // "all section" finds Section elements, "all div" finds Div, etc.
        var elName = String(element.name || '').trim().toLowerCase();
        if (elName && elName === tagLower) return true;
        // Match custom label (user-renamed elements)
        var elLabel = String(element.label || '').trim().toLowerCase();
        if (elLabel && elLabel === tagLower) return true;
        return false;
      }

      if (target.mode === 'class') {
        return this.getElementClasses(element).indexOf(value.replace(/^\./, '')) !== -1;
      }

      if (target.mode === 'id') {
        return this.getElementCssId(element) === value.replace(/^#/, '');
      }

      if (target.mode === 'type') {
        var type = String(element.name || element.label || element.element || element.type || '').trim().toLowerCase();
        return type === value.toLowerCase();
      }

      return false;
    },

    findBulkTargets: function (target) {
      var self = this;
      return this.getAllElements().filter(function (element) {
        return self.matchesBulkTarget(element, target);
      });
    },

    applyAttributes: function (operations) {
      var ops = this.normalizeOperations(operations);
      var bulkOps = ops.filter(function (op) { return op && op.type === 'bulk-apply'; });

      if (bulkOps.length) {
        return this.applyBulkOperations(bulkOps);
      }

      var element = this.getSelectedElement();
      if (!element) return { ok: false, reason: 'no-selection' };

      return this.applyOperationsToElement(element, ops);
    },

    normalizeOperations: function (operations) {
      var ops = Array.isArray(operations) ? operations : [];
      return ops.map(function (op) {
        if (op && op.type) return op;
        return { type: 'set', name: op && op.name, value: op && op.value };
      }).filter(function (op) {
        return op && (
          op.type === 'set' ||
          op.type === 'rename' ||
          op.type === 'delete-attribute' ||
          op.type === 'set-id' ||
          op.type === 'add-class' ||
          op.type === 'remove-class' ||
          op.type === 'rename-class' ||
          op.type === 'delete-global-class' ||
          op.type === 'bulk-apply'
        );
      });
    },

    applyBulkOperations: function (bulkOps) {
      var self = this;
      var total = 0;
      var summaries = [];

      for (var i = 0; i < bulkOps.length; i++) {
        var bulk = bulkOps[i];
        if (!bulk.confirmed) {
          return { ok: false, reason: 'bulk-needs-confirmation', bulk: bulk };
        }

        var targets = this.findBulkTargets(bulk.target);
        if (!targets.length) {
          return { ok: false, reason: 'no-bulk-targets', target: this.describeBulkTarget(bulk.target) };
        }

        if (targets.length > MAX_BULK_TARGETS) {
          return { ok: false, reason: 'too-many-bulk-targets', target: this.describeBulkTarget(bulk.target), count: targets.length, max: MAX_BULK_TARGETS };
        }

        var innerOps = this.normalizeOperations(bulk.ops || []);
        innerOps = innerOps.filter(function (op) { return op.type !== 'bulk-apply' && op.type !== 'delete-global-class'; });
        if (!innerOps.length) {
          return { ok: false, reason: 'empty-bulk-command', target: this.describeBulkTarget(bulk.target) };
        }

        for (var targetIndex = 0; targetIndex < targets.length; targetIndex++) {
          var result = self.applyOperationsToElement(targets[targetIndex], innerOps, { silent: true, bulk: true });
          if (!result.ok) return result;
          total++;
        }

        summaries.push({ target: this.describeBulkTarget(bulk.target), count: targets.length });
      }

      try {
        var globals = self.getVueGlobals();
        var state = globals && globals.$_state ? globals.$_state : null;
        if (globals && typeof globals.$_rerenderControls === 'function') {
          globals.$_rerenderControls();
        } else if (state) {
          state.rerenderControls = (state.rerenderControls || 0) + 1;
        }
      } catch (e) { log('bulk final refresh failed', e); }

      return { ok: true, bulkCount: total, bulkSummaries: summaries };
    },

    applyOperationsToElement: function (element, operations, options) {
      options = options || {};
      if (!element) return { ok: false, reason: 'no-selection' };

      if (!element.settings || typeof element.settings !== 'object') {
        element.settings = {};
      }

      var ops = this.normalizeOperations(operations);
      var currentSettings = element.settings && typeof element.settings === 'object' ? element.settings : {};
      // Strip Vue reactivity before cloning so property reads don't trigger getter storms
      if (this._toRaw) currentSettings = this._toRaw(currentSettings) || currentSettings;
      var nextSettings = this.clone(currentSettings);
      var next = this.normalizeAttributes(nextSettings);
      var manualClasses = this.splitClassString(nextSettings._cssClasses);
      var globalClassIds = Array.isArray(nextSettings._cssGlobalClasses) ? nextSettings._cssGlobalClasses.slice() : [];
      var self = this;

      function findIndexByName(name) {
        for (var i = 0; i < next.length; i++) {
          if (next[i] && next[i].name === name) return i;
        }
        return -1;
      }

      function normalizeClassName(value) {
        return String(value || '').replace(/^\./, '').trim();
      }

      function hasManualClass(name) {
        return manualClasses.indexOf(name) !== -1;
      }

      function removeManualClass(name) {
        name = normalizeClassName(name);
        manualClasses = manualClasses.filter(function (item) { return item !== name; });
      }

      function getGlobalClassNameById(id) {
        var item = self.findGlobalClassById(id);
        return item && item.name ? String(item.name) : '';
      }

      function addGlobalClass(name) {
        name = normalizeClassName(name);
        if (!name) return false;

        var item = self.createGlobalClass(name);
        if (!item || !item.id) return false;

        if (globalClassIds.indexOf(item.id) === -1) {
          globalClassIds.push(item.id);
        }

        removeManualClass(name);
        return true;
      }

      function removeGlobalClass(name) {
        name = normalizeClassName(name);
        var found = false;

        globalClassIds = globalClassIds.filter(function (id) {
          var match = getGlobalClassNameById(id) === name || String(id) === name;
          if (match) found = true;
          return !match;
        });

        if (hasManualClass(name)) {
          removeManualClass(name);
          found = true;
        }

        return found;
      }

      function renameGlobalClassOnElement(from, to) {
        from = normalizeClassName(from);
        to = normalizeClassName(to);
        if (!from || !to) return false;

        var removed = removeGlobalClass(from);
        if (!removed) return false;
        addGlobalClass(to);
        return true;
      }

      function removeClassReferencesFromAllElements(classId, className) {
        var roots = self.getMutableElementsRoot();
        self.walkElements(roots, function (item) {
          if (!item.settings || typeof item.settings !== 'object') return;

          if (Array.isArray(item.settings._cssGlobalClasses)) {
            item.settings._cssGlobalClasses = item.settings._cssGlobalClasses.filter(function (id) {
              return id !== classId;
            });
          }

          var itemManual = self.splitClassString(item.settings._cssClasses);
          if (itemManual.length) {
            item.settings._cssClasses = itemManual.filter(function (manualName) {
              return manualName !== className;
            }).join(' ');
          }
        });
      }

      function deleteGlobalClassEverywhere(names, confirmed) {
        names = Array.isArray(names) ? names : [names];
        names = names.map(normalizeClassName).filter(Boolean).filter(function (name, index, list) {
          return list.indexOf(name) === index;
        });

        if (!names.length) return { ok: false, reason: 'missing-global-class', name: '' };
        if (!confirmed) return { ok: false, reason: 'global-delete-needs-confirmation', name: names[0], names: names };

        var state = self.getState();
        if (!state || !Array.isArray(state.globalClasses)) {
          return { ok: false, reason: 'missing-global-class', name: names.join(', '), names: names };
        }

        var missing = [];
        var idsToRemove = [];
        var classItems = [];

        names.forEach(function (name) {
          var item = self.findGlobalClassByName(name);
          if (!item || !item.id) {
            missing.push(name);
            return;
          }
          idsToRemove.push(item.id);
          classItems.push({ id: item.id, name: name });
        });

        if (missing.length) {
          return { ok: false, reason: 'missing-global-class', name: missing.join(', '), names: missing };
        }

        state.globalClasses = state.globalClasses.filter(function (globalClass) {
          return !(globalClass && idsToRemove.indexOf(globalClass.id) !== -1);
        });

        classItems.forEach(function (item) {
          globalClassIds = globalClassIds.filter(function (id) { return id !== item.id; });
          removeManualClass(item.name);
          removeClassReferencesFromAllElements(item.id, item.name);
        });

        try {
          var globals = self.getVueGlobals();
          if (globals && typeof globals.$_postMessage === 'function') {
            globals.$_postMessage({ key: 'globalClasses', value: JSON.stringify(state.globalClasses) });
          }
        } catch (e) { log('global class delete postMessage failed', e); }

        return { ok: true, names: names };
      }

      for (var i = 0; i < ops.length; i++) {
        var op = ops[i];

        if (op.type === 'set') {
          var setIndex = findIndexByName(op.name);
          if (setIndex >= 0) {
            next[setIndex].value = op.value == null ? '' : String(op.value);
          } else {
            next.push({ id: makeId(), name: op.name, value: op.value == null ? '' : String(op.value) });
          }
          continue;
        }

        if (op.type === 'delete-attribute') {
          var namesToDelete = Array.isArray(op.names) ? op.names : [op.name];
          var normalizedNames = namesToDelete.map(function (name) { return String(name || '').trim(); }).filter(Boolean);
          var beforeLength = next.length;
          next = next.filter(function (attr) {
            return normalizedNames.indexOf(attr.name) === -1;
          });
          if (beforeLength === next.length) {
            return { ok: false, reason: 'missing-delete-attribute', name: normalizedNames.join(', ') };
          }
          continue;
        }

        if (op.type === 'set-id') {
          nextSettings._cssId = String(op.value || '').replace(/^#/, '').trim();
          continue;
        }

        if (op.type === 'add-class') {
          addGlobalClass(op.name);
          continue;
        }

        if (op.type === 'remove-class') {
          removeGlobalClass(op.name);
          continue;
        }

        if (op.type === 'rename-class') {
          if (!renameGlobalClassOnElement(op.from, op.to)) {
            return { ok: false, reason: 'missing-class-source', name: op.from };
          }
          continue;
        }

        if (op.type === 'delete-global-class') {
          var deleteResult = deleteGlobalClassEverywhere(op.names || op.name, !!op.confirmed);
          if (!deleteResult.ok) return deleteResult;
          continue;
        }

        if (op.type === 'rename') {
          var fromIndex = findIndexByName(op.from);
          if (fromIndex < 0) {
            return { ok: false, reason: 'missing-rename-source', name: op.from };
          }

          var toIndex = findIndexByName(op.to);
          var source = next[fromIndex];
          var nextValue = op.hasValue ? (op.value == null ? '' : String(op.value)) : source.value;

          if (toIndex >= 0 && toIndex !== fromIndex) {
            next[toIndex].value = nextValue;
            next.splice(fromIndex, 1);
          } else {
            source.name = op.to;
            source.value = nextValue;
          }
        }
      }

      nextSettings._attributes = next;
      nextSettings._cssClasses = manualClasses.join(' ');
      nextSettings._cssGlobalClasses = globalClassIds.filter(function (id, index, list) {
        return id && list.indexOf(id) === index;
      });

      this.commitSettings(element, nextSettings, currentSettings, options);
      return { ok: true, element: element };
    },

    clone: function (value) {
      if (!value || typeof value !== 'object') return {};
      var copy = {};
      for (var key in value) {
        if (!Object.prototype.hasOwnProperty.call(value, key)) continue;
        var val = value[key];
        if (Array.isArray(val)) {
          copy[key] = val.map(function (item) {
            if (item && typeof item === 'object') {
              var itemCopy = {};
              for (var k in item) {
                if (Object.prototype.hasOwnProperty.call(item, k)) {
                  itemCopy[k] = item[k];
                }
              }
              return itemCopy;
            }
            return item;
          });
        } else if (val && typeof val === 'object') {
          var objCopy = {};
          for (var k in val) {
            if (Object.prototype.hasOwnProperty.call(val, k)) {
              objCopy[k] = val[k];
            }
          }
          copy[key] = objCopy;
        } else {
          copy[key] = val;
        }
      }
      return copy;
    },

    commitSettings: function (element, nextSettings, oldSettings, options) {
      options = options || {};
      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      var committedViaBricks = false;

      if (options.bulk) {
        if (!element.settings || typeof element.settings !== 'object') {
          element.settings = {};
        }
        for (var key in nextSettings) {
          if (Object.prototype.hasOwnProperty.call(nextSettings, key)) {
            element.settings[key] = nextSettings[key];
          }
        }
        for (var key in element.settings) {
          if (Object.prototype.hasOwnProperty.call(element.settings, key) && !Object.prototype.hasOwnProperty.call(nextSettings, key)) {
            delete element.settings[key];
          }
        }
        this._allElementsCache = null;
        return;
      }

      // Important: do not set Bricks' internal unsavedChanges manually. In Bricks
      // 2.x that value is an array, and forcing it to a boolean can break save.
      // Instead, push the change through Bricks' own selectedElementSettings flow,
      // which is what the native controls use to mark/save changes.
      try {
        if (state && Array.isArray(state.selectedElements) && state.selectedElements.length) {
          var isAlreadySelected = state.selectedElements.some(function (selected) {
            return selected && selected.id === element.id;
          });

          if (!isAlreadySelected) {
            state.selectedElements = [element];
          }

          state.selectedElementSettings = this.clone(nextSettings);
          committedViaBricks = true;
        }
      } catch (e) { log('selectedElementSettings commit failed', e); }

      // Fallback for unusual Bricks states where selectedElementSettings is not
      // available. Avoid dirty-state mutation; only update the central element and
      // rerender. This keeps the builder from saving corrupted runtime state.
      if (!committedViaBricks) {
        try {
          element.settings = this.clone(nextSettings);
          if (globals && typeof globals.$_selectedElementsSetSettings === 'function') {
            globals.$_selectedElementsSetSettings(this.clone(nextSettings), this.clone(oldSettings || {}));
            committedViaBricks = true;
          }
        } catch (e2) { log('selectedElementsSetSettings fallback failed', e2); }
      }

      try {
        if (globals && typeof globals.$_rerenderControls === 'function') {
          globals.$_rerenderControls();
        } else if (state) {
          state.rerenderControls = (state.rerenderControls || 0) + 1;
        }
      } catch (e3) { log('controls refresh failed', e3); }

      if (!options.silent) {
        try {
          if (globals && typeof globals.$_showMessage === 'function') {
            globals.$_showMessage(labels.applied || 'Attributes applied.');
          }
        } catch (e4) { log('showMessage failed', e4); }
      }

      this._allElementsCache = null;

      try {
        window.dispatchEvent(new CustomEvent('baqa:attributes-applied', { detail: { element: element } }));
      } catch (e5) { /* noop */ }
    }
  };


  window.MimamsBarBricksAdapter = BricksAdapter;
})();
