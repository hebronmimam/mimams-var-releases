<?php

namespace VE\API;

use VE\Core\VariableManager;
use VE\Core\DependencyGraph;
use VE\Core\CssExporter;
use VE\Core\RenamePropagationManager;
use VE\Core\ThemeManager;
use VE\Core\ColorPaletteManager;
use VE\Database\Schema;
use VE\Sync\SnapshotManager;

defined( 'ABSPATH' ) || exit;

class VariableController {

    private VariableManager $manager;

    public function __construct() {
        $this->manager = new VariableManager();
    }

    /* ── LIST / SEARCH ───────────────────────────────────────────────── */

    public function list_variables( \WP_REST_Request $request ): \WP_REST_Response {
        $args = [];

        if ( $request->get_param( 'namespace' ) ) {
            $args['namespace'] = $request->get_param( 'namespace' );
        }
        if ( $request->get_param( 'type' ) ) {
            $args['type'] = $request->get_param( 'type' );
        }
        if ( $request->get_param( 'category_slug' ) ) {
            $args['category_slug'] = $request->get_param( 'category_slug' );
        }

        $variables = ( new ThemeManager() )->apply_to_variables( $this->manager->get_all( $args ) );
        $variables = ( new ColorPaletteManager() )->annotate_variables( $variables );

        // Figma and sync UIs should display one current record per variable name.
        // Older builds could leave duplicate rows in the DB after repeated sync tests,
        // so expose a safe deduped view without deleting user data.
        if ( filter_var( $request->get_param( 'dedupe' ), FILTER_VALIDATE_BOOLEAN ) ) {
            $variables = $this->dedupe_by_name( $variables );
        }

        return new \WP_REST_Response( $variables, 200 );
    }

    private function dedupe_by_name( array $variables ): array {
        $map = [];
        foreach ( $variables as $variable ) {
            $name = $variable['name'] ?? '';
            if ( ! $name ) {
                continue;
            }

            // Keep the highest id as the newest/current row when duplicates exist.
            if ( ! isset( $map[ $name ] ) || (int) ( $variable['id'] ?? 0 ) > (int) ( $map[ $name ]['id'] ?? 0 ) ) {
                $map[ $name ] = $variable;
            }
        }

        $deduped = array_values( $map );
        usort( $deduped, static function ( $a, $b ) {
            return strcmp( $a['name'] ?? '', $b['name'] ?? '' );
        } );

        return $deduped;
    }

    public function search_variables( \WP_REST_Request $request ): \WP_REST_Response {
        $query   = $request->get_param( 'q' ) ?? '';
        $limit   = (int) ( $request->get_param( 'limit' ) ?? 50 );
        $results = ( new ThemeManager() )->apply_to_variables( $this->manager->search( $query, $limit ) );
        $results = ( new ColorPaletteManager() )->annotate_variables( $results );

        return new \WP_REST_Response( $results, 200 );
    }



    /* ── STATS / CLEANUP ───────────────────────────────────────────── */

    public function stats_variables( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;

        $var_table = Schema::table( 'variables' );
        $dep_table = Schema::table( 'dependencies' );
        $gen_table = Schema::table( 'generators' );

        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$var_table}" );
        $base = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$var_table} WHERE type = %s", 'base' ) );
        $generated = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$var_table} WHERE type = %s", 'generated' ) );
        $alias = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$var_table} WHERE type = %s", 'alias' ) );

        $duplicate_names = $wpdb->get_results(
            "SELECT name, COUNT(*) AS count FROM {$var_table} GROUP BY name HAVING COUNT(*) > 1 ORDER BY count DESC, name ASC",
            ARRAY_A
        );

        $orphan_generated = (int) $wpdb->get_var(
            "SELECT COUNT(*)
             FROM {$var_table} v
             LEFT JOIN {$var_table} source ON source.id = v.source_id
             WHERE v.type = 'generated'
               AND (v.source_id IS NULL OR v.source_id = 0 OR source.id IS NULL)
               AND NOT EXISTS (SELECT 1 FROM {$dep_table} child_dep WHERE child_dep.parent_id = v.id)"
        );
        $blocked_orphan_generated = (int) $wpdb->get_var(
            "SELECT COUNT(*)
             FROM {$var_table} v
             LEFT JOIN {$var_table} source ON source.id = v.source_id
             WHERE v.type = 'generated'
               AND (v.source_id IS NULL OR v.source_id = 0 OR source.id IS NULL)
               AND EXISTS (SELECT 1 FROM {$dep_table} child_dep WHERE child_dep.parent_id = v.id)"
        );
        $broken_aliases = (int) $wpdb->get_var(
            "SELECT COUNT(*)
             FROM {$var_table} v
             LEFT JOIN {$var_table} source ON source.id = v.source_id
             WHERE v.type = 'alias'
               AND (v.source_id IS NULL OR v.source_id = 0 OR source.id IS NULL)"
        );
        $missing_dependencies = (int) $wpdb->get_var(
            "SELECT COUNT(*)
             FROM {$var_table} v
             INNER JOIN {$var_table} source ON source.id = v.source_id
             LEFT JOIN {$dep_table} d ON d.parent_id = v.source_id AND d.child_id = v.id
             WHERE v.type IN ('generated','alias')
               AND v.source_id IS NOT NULL
               AND v.source_id > 0
               AND d.id IS NULL"
        );
        $orphan_dependencies = (int) $wpdb->get_var(
            "SELECT COUNT(*)
             FROM {$dep_table} d
             LEFT JOIN {$var_table} parent ON parent.id = d.parent_id
             LEFT JOIN {$var_table} child ON child.id = d.child_id
             WHERE parent.id IS NULL OR child.id IS NULL"
        );

        $expected_names = $this->expected_generated_names();
        $expected_count = count( $expected_names );
        $expected_lookup = array_fill_keys( $expected_names, true );
        $active_pairs = $this->active_generator_pairs();

        $stale_generated = 0;
        $generated_rows = $wpdb->get_results( "SELECT name, source_id, generator_type FROM {$var_table} WHERE type = 'generated'", ARRAY_A ) ?: [];
        foreach ( $generated_rows as $row ) {
            $name = $row['name'] ?? '';
            $pair = (int) ( $row['source_id'] ?? 0 ) . '|' . (string) ( $row['generator_type'] ?? '' );
            if ( $name && isset( $active_pairs[ $pair ] ) && ! isset( $expected_lookup[ $name ] ) ) {
                $stale_generated++;
            }
        }

        $older_generators = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$gen_table} g
             INNER JOIN (
                SELECT variable_id, type, MAX(id) AS keep_id, COUNT(*) AS cnt
                FROM {$gen_table}
                GROUP BY variable_id, type
                HAVING COUNT(*) > 1
             ) x ON x.variable_id = g.variable_id AND x.type = g.type
             WHERE g.id <> x.keep_id"
        );

        $namespaces = $wpdb->get_results(
            "SELECT namespace, COUNT(*) AS count FROM {$var_table} GROUP BY namespace ORDER BY namespace ASC",
            ARRAY_A
        );

        $all = $this->manager->get_all();
        $deduped = $this->dedupe_by_name( $all );
        $public_names = [];
        $public_name_conflicts = [];
        foreach ( $all as $variable ) {
            $css_name = $this->manager->to_css_name( (string) ( $variable['name'] ?? '' ) );
            if ( isset( $public_names[ $css_name ] ) && $public_names[ $css_name ] !== ( $variable['name'] ?? '' ) ) {
                if ( ! isset( $public_name_conflicts[ $css_name ] ) ) {
                    $public_name_conflicts[ $css_name ] = [ $public_names[ $css_name ] ];
                }
                $public_name_conflicts[ $css_name ][] = (string) ( $variable['name'] ?? '' );
            } else {
                $public_names[ $css_name ] = (string) ( $variable['name'] ?? '' );
            }
        }
        foreach ( $public_name_conflicts as &$conflict_names ) {
            $conflict_names = array_values( array_unique( $conflict_names ) );
        }
        unset( $conflict_names );

        return new \WP_REST_Response( [
            'total'             => $total,
            'deduped_total'     => count( $deduped ),
            'base'              => $base,
            'generated'         => $generated,
            'alias'             => $alias,
            'duplicate_names'   => $duplicate_names,
            'duplicate_count'   => count( $duplicate_names ),
            'orphan_generated'  => $orphan_generated,
            'blocked_orphan_generated' => $blocked_orphan_generated,
            'broken_aliases'    => $broken_aliases,
            'missing_dependencies' => $missing_dependencies,
            'orphan_dependencies' => $orphan_dependencies,
            'stale_generated'   => $stale_generated,
            'expected_generated'=> $expected_count,
            'older_generators'  => $older_generators,
            'public_name_conflicts' => $public_name_conflicts,
            'public_name_conflict_count' => count( $public_name_conflicts ),
            'namespaces'        => $namespaces,
        ], 200 );
    }

    private function expected_generated_names(): array {
        global $wpdb;
        $gen_table = Schema::table( 'generators' );

        // Only the newest generator for each base-variable/type pair is considered active.
        $generators = $wpdb->get_results(
            "SELECT g.* FROM {$gen_table} g
             INNER JOIN (
                SELECT variable_id, type, MAX(id) AS keep_id
                FROM {$gen_table}
                GROUP BY variable_id, type
             ) x ON x.keep_id = g.id
             WHERE g.active = 1
             ORDER BY g.variable_id ASC, g.id ASC",
            ARRAY_A
        ) ?: [];

        $names = [];
        foreach ( $generators as $gen ) {
            $base = $this->manager->get( (int) $gen['variable_id'] );
            if ( ! $base ) {
                continue;
            }
            $type = $gen['type'] ?? '';
            $config = json_decode( $gen['config'] ?? '[]', true ) ?: [];

            if ( 'color' === $type ) {
                $handler = new \VE\Core\Generators\ColorGenerator();
            } elseif ( in_array( $type, [ 'spacing', 'typography', 'radius', 'size' ], true ) ) {
                $handler = new \VE\Core\Generators\FluidScaleGenerator();
            } else {
                continue;
            }

            foreach ( $handler->generate( $base, $config ) as $item ) {
                if ( ! empty( $item['name'] ) ) {
                    $names[] = $item['name'];
                }
            }
        }

        return array_values( array_unique( $names ) );
    }

    private function active_generator_pairs(): array {
        global $wpdb;
        $gen_table = Schema::table( 'generators' );
        $rows = $wpdb->get_results(
            "SELECT variable_id, type FROM {$gen_table} WHERE active = 1",
            ARRAY_A
        ) ?: [];

        $pairs = [];
        foreach ( $rows as $row ) {
            $pairs[ (int) ( $row['variable_id'] ?? 0 ) . '|' . (string) ( $row['type'] ?? '' ) ] = true;
        }

        return $pairs;
    }


    /**
     * Recover missing generator records from existing generated variable names.
     *
     * During early development builds, generated rows could survive while their
     * generator/dependency records were removed or never written correctly. A
     * cleanup should preserve the user's current generation intent where it can
     * be safely inferred, then rebuild the rows from fresh generator records.
     */
    private function ensure_rebuildable_generators_from_existing_rows() {
        global $wpdb;

        $var_table = Schema::table( 'variables' );
        $gen_table = Schema::table( 'generators' );
        $dep_table = Schema::table( 'dependencies' );

        $base_rows = $wpdb->get_results(
            "SELECT * FROM {$var_table} WHERE type = 'base' ORDER BY id ASC",
            ARRAY_A
        ) ?: [];

        $created = 0;

        foreach ( $base_rows as $base ) {
            $base_id   = (int) ( $base['id'] ?? 0 );
            $base_name = (string) ( $base['name'] ?? '' );
            if ( ! $base_id || ! $base_name ) {
                continue;
            }

            // If this base already has an active generator, don't guess over it.
            $has_active = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$gen_table} WHERE variable_id = %d AND active = 1",
                $base_id
            ) );
            if ( $has_active > 0 ) {
                continue;
            }

            $like = $wpdb->esc_like( $base_name . '.' ) . '%';
            $children = $wpdb->get_results( $wpdb->prepare(
                "SELECT id, name, generator_type, source_id FROM {$var_table}
                 WHERE type = 'generated'
                   AND (source_id = %d OR name LIKE %s)
                 ORDER BY name ASC",
                $base_id,
                $like
            ), ARRAY_A ) ?: [];

            if ( empty( $children ) ) {
                continue;
            }

            $tints = 0;
            $shades = 0;
            $alphas = 0;

            foreach ( $children as $child ) {
                $name = (string) ( $child['name'] ?? '' );
                if ( preg_match( '/^' . preg_quote( $base_name, '/' ) . '\\.l\\.(\\d+)$/', $name, $m ) ) {
                    $tints = max( $tints, (int) $m[1] );
                } elseif ( preg_match( '/^' . preg_quote( $base_name, '/' ) . '\\.d\\.(\\d+)$/', $name, $m ) ) {
                    $shades = max( $shades, (int) $m[1] );
                } elseif ( preg_match( '/^' . preg_quote( $base_name, '/' ) . '\\.t\\.(\\d+)$/', $name, $m ) ) {
                    $alphas = max( $alphas, (int) $m[1] );
                }
            }

            if ( $tints || $shades || $alphas ) {
                $config = [
                    'tint_count'    => $tints,
                    'shade_count'   => $shades,
                    'include_alpha' => $alphas > 0,
                    'alpha_count'   => $alphas,
                    'recovered'     => true,
                ];

                $inserted = $wpdb->insert( $gen_table, [
                    'variable_id' => $base_id,
                    'type'        => 'color',
                    'config'      => wp_json_encode( $config ),
                    'active'      => 1,
                ], [ '%d', '%s', '%s', '%d' ] );
                if ( false === $inserted ) {
                    return new \WP_Error( 've_cleanup_recovery_failed', $wpdb->last_error ?: 'Could not recover a generator record.', [ 'status' => 500 ] );
                }

                $created++;

                // Repair dependencies for rows that are still valid children.
                foreach ( $children as $child ) {
                    $child_id = (int) ( $child['id'] ?? 0 );
                    if ( $child_id ) {
                        if ( ! ( new DependencyGraph() )->register( $base_id, $child_id, 'generated' ) ) {
                            return new \WP_Error( 've_cleanup_recovery_failed', 'Could not recover a generated-variable dependency.', [ 'status' => 500 ] );
                        }
                    }
                }
            }
        }

        return $created;
    }

    public function cleanup_variables( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;

        $var_table = Schema::table( 'variables' );
        $dep_table = Schema::table( 'dependencies' );
        $gen_table = Schema::table( 'generators' );

        $snapshot_id = ( new SnapshotManager() )->create( 'pre_cleanup' );
        if ( is_wp_error( $snapshot_id ) ) {
            return new \WP_REST_Response(
                [ 'code' => $snapshot_id->get_error_code(), 'message' => $snapshot_id->get_error_message() ],
                (int) ( $snapshot_id->get_error_data()['status'] ?? 500 )
            );
        }
        if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
            return new \WP_REST_Response(
                [ 'code' => 've_cleanup_transaction_failed', 'message' => $wpdb->last_error ?: 'Could not start cleanup safely.', 'snapshot_id' => $snapshot_id ],
                500
            );
        }

        try {
        $before = $this->stats_variables( $request )->get_data();
        $recovered_generators = $this->ensure_rebuildable_generators_from_existing_rows();
        if ( is_wp_error( $recovered_generators ) ) {
            throw new \RuntimeException( $recovered_generators->get_error_message() );
        }
        $deleted_ids = [];
        $deleted_generators = 0;

        // 1) Remove older duplicate rows, keeping the newest/highest id for each variable name.
        $duplicate_rows = $wpdb->get_results(
            "SELECT id, name FROM {$var_table} WHERE name IN (
                SELECT name FROM (SELECT name FROM {$var_table} GROUP BY name HAVING COUNT(*) > 1) dup
            ) ORDER BY name ASC, id DESC",
            ARRAY_A
        );

        $seen_names = [];
        foreach ( $duplicate_rows as $row ) {
            $name = $row['name'] ?? '';
            $id   = (int) ( $row['id'] ?? 0 );
            if ( ! $name || ! $id ) {
                continue;
            }
            if ( isset( $seen_names[ $name ] ) ) {
                $remapped = $this->remap_duplicate_variable_id( $id, (int) $seen_names[ $name ] );
                if ( is_wp_error( $remapped ) ) {
                    throw new \RuntimeException( $remapped->get_error_message() );
                }
                $deleted_ids[] = $id;
            } else {
                $seen_names[ $name ] = $id;
            }
        }

        // 2) Keep only the newest generator per base-variable/type pair.
        $old_generator_ids = $wpdb->get_col(
            "SELECT g.id FROM {$gen_table} g
             INNER JOIN (
                SELECT variable_id, type, MAX(id) AS keep_id, COUNT(*) AS cnt
                FROM {$gen_table}
                GROUP BY variable_id, type
                HAVING COUNT(*) > 1
             ) x ON x.variable_id = g.variable_id AND x.type = g.type
             WHERE g.id <> x.keep_id"
        ) ?: [];

        if ( $old_generator_ids ) {
            $old_generator_ids = array_values( array_unique( array_map( 'absint', $old_generator_ids ) ) );
            $placeholders = implode( ',', array_fill( 0, count( $old_generator_ids ), '%d' ) );
            if ( false === $wpdb->query( $wpdb->prepare( "DELETE FROM {$gen_table} WHERE id IN ({$placeholders})", $old_generator_ids ) ) ) {
                throw new \RuntimeException( $wpdb->last_error ?: 'Could not remove older generator records.' );
            }
            $deleted_generators = count( $old_generator_ids );
        }

        // 3) Repair or remove generated rows that are not connected to a parent dependency.
        $repairable_orphans = $wpdb->get_results(
            "SELECT v.id, v.source_id, v.type
             FROM {$var_table} v
             INNER JOIN {$var_table} source ON source.id = v.source_id
             LEFT JOIN {$dep_table} d ON d.parent_id = v.source_id AND d.child_id = v.id
             WHERE v.type IN ('generated','alias')
               AND v.source_id IS NOT NULL
               AND v.source_id > 0
               AND d.id IS NULL",
            ARRAY_A
        ) ?: [];
        foreach ( $repairable_orphans as $row ) {
            if ( ! ( new DependencyGraph() )->register( (int) $row['source_id'], (int) $row['id'], (string) $row['type'] ) ) {
                throw new \RuntimeException( 'Could not repair a variable dependency.' );
            }
        }

        $orphan_ids = $wpdb->get_col(
            "SELECT v.id
             FROM {$var_table} v
             LEFT JOIN {$var_table} source ON source.id = v.source_id
             WHERE v.type = 'generated'
               AND (v.source_id IS NULL OR v.source_id = 0 OR source.id IS NULL)
               AND NOT EXISTS (SELECT 1 FROM {$dep_table} child_dep WHERE child_dep.parent_id = v.id)"
        ) ?: [];
        foreach ( $orphan_ids as $id ) {
            $deleted_ids[] = (int) $id;
        }

        $orphan_dependency_ids = $wpdb->get_col(
            "SELECT d.id
             FROM {$dep_table} d
             LEFT JOIN {$var_table} parent ON parent.id = d.parent_id
             LEFT JOIN {$var_table} child ON child.id = d.child_id
             WHERE parent.id IS NULL OR child.id IS NULL"
        ) ?: [];
        if ( $orphan_dependency_ids ) {
            $orphan_dependency_ids = array_values( array_unique( array_map( 'absint', $orphan_dependency_ids ) ) );
            $placeholders = implode( ',', array_fill( 0, count( $orphan_dependency_ids ), '%d' ) );
            if ( false === $wpdb->query( $wpdb->prepare( "DELETE FROM {$dep_table} WHERE id IN ({$placeholders})", $orphan_dependency_ids ) ) ) {
                throw new \RuntimeException( $wpdb->last_error ?: 'Could not remove orphan dependency rows.' );
            }
        }

        // 4) Remove stale generated rows whose names are no longer produced by the current generators.
        $expected_names = $this->expected_generated_names();
        $expected_lookup = array_fill_keys( $expected_names, true );
        $active_pairs = $this->active_generator_pairs();
        $generated_rows = $wpdb->get_results( "SELECT id, name, source_id, generator_type FROM {$var_table} WHERE type = 'generated'", ARRAY_A ) ?: [];
        foreach ( $generated_rows as $row ) {
            $name = $row['name'] ?? '';
            $id = (int) ( $row['id'] ?? 0 );
            $pair = (int) ( $row['source_id'] ?? 0 ) . '|' . (string) ( $row['generator_type'] ?? '' );
            if ( $id && $name && isset( $active_pairs[ $pair ] ) && ! isset( $expected_lookup[ $name ] ) ) {
                $deleted_ids[] = $id;
            }
        }

        $deleted_ids = array_values( array_unique( array_filter( array_map( 'absint', $deleted_ids ) ) ) );

        if ( $deleted_ids ) {
            $placeholders = implode( ',', array_fill( 0, count( $deleted_ids ), '%d' ) );
            if (
                false === $wpdb->query( $wpdb->prepare( "DELETE FROM {$dep_table} WHERE parent_id IN ({$placeholders}) OR child_id IN ({$placeholders})", array_merge( $deleted_ids, $deleted_ids ) ) )
                || false === $wpdb->query( $wpdb->prepare( "DELETE FROM {$gen_table} WHERE variable_id IN ({$placeholders})", $deleted_ids ) )
                || false === $wpdb->query( $wpdb->prepare( "DELETE FROM {$var_table} WHERE id IN ({$placeholders})", $deleted_ids ) )
            ) {
                throw new \RuntimeException( $wpdb->last_error ?: 'Could not remove invalid variable records.' );
            }
        }

        // 5) Re-run the kept generators so missing current generated rows are recreated.
        $kept_variable_ids = $wpdb->get_col( "SELECT DISTINCT variable_id FROM {$gen_table} WHERE active = 1" ) ?: [];
        foreach ( $kept_variable_ids as $variable_id ) {
            $regenerated = ( new \VE\Core\GeneratorEngine() )->regenerate( (int) $variable_id, false );
            if ( is_wp_error( $regenerated ) ) {
                throw new \RuntimeException( $regenerated->get_error_message() );
            }
        }

        ( new ColorPaletteManager() )->repair_memberships();

        if ( ! ( new CssExporter() )->export() ) {
            throw new \RuntimeException( 'Cleanup could not write the generated CSS file.' );
        }

        $after = $this->stats_variables( $request )->get_data();
        if ( false === $wpdb->query( 'COMMIT' ) ) {
            throw new \RuntimeException( $wpdb->last_error ?: 'Could not commit the cleanup.' );
        }

        return new \WP_REST_Response( [
            'deleted' => count( $deleted_ids ),
            'deleted_generators' => $deleted_generators,
            'recovered_generators' => $recovered_generators,
            'deleted_ids' => $deleted_ids,
            'snapshot_id' => $snapshot_id,
            'before' => $before,
            'after' => $after,
        ], 200 );
        } catch ( \Throwable $e ) {
            $wpdb->query( 'ROLLBACK' );
            ( new CssExporter() )->export();
            return new \WP_REST_Response(
                [
                    'code' => 've_cleanup_failed',
                    'message' => 'Cleanup failed and no database changes were kept. ' . $e->getMessage(),
                    'snapshot_id' => $snapshot_id,
                ],
                500
            );
        }
    }

    private function remap_duplicate_variable_id( int $old_id, int $keep_id ) {
        global $wpdb;

        if ( $old_id <= 0 || $keep_id <= 0 || $old_id === $keep_id ) {
            return true;
        }

        $var_table = Schema::table( 'variables' );
        $dep_table = Schema::table( 'dependencies' );
        $gen_table = Schema::table( 'generators' );
        $dependencies = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$dep_table} WHERE parent_id = %d OR child_id = %d ORDER BY id ASC",
            $old_id,
            $old_id
        ), ARRAY_A ) ?: [];

        foreach ( $dependencies as $dependency ) {
            $parent_id = (int) $dependency['parent_id'] === $old_id ? $keep_id : (int) $dependency['parent_id'];
            $child_id = (int) $dependency['child_id'] === $old_id ? $keep_id : (int) $dependency['child_id'];
            if ( $parent_id !== $child_id && ! ( new DependencyGraph() )->register( $parent_id, $child_id, (string) $dependency['relation'] ) ) {
                return new \WP_Error( 've_cleanup_remap_failed', 'Could not preserve a dependency while merging duplicate variables.', [ 'status' => 500 ] );
            }
            if ( false === $wpdb->delete( $dep_table, [ 'id' => (int) $dependency['id'] ] ) ) {
                return new \WP_Error( 've_cleanup_remap_failed', $wpdb->last_error ?: 'Could not remove an obsolete duplicate dependency.', [ 'status' => 500 ] );
            }
        }

        if (
            false === $wpdb->update( $var_table, [ 'source_id' => $keep_id ], [ 'source_id' => $old_id ], [ '%d' ], [ '%d' ] )
            || false === $wpdb->update( $gen_table, [ 'variable_id' => $keep_id ], [ 'variable_id' => $old_id ], [ '%d' ], [ '%d' ] )
        ) {
            return new \WP_Error( 've_cleanup_remap_failed', $wpdb->last_error ?: 'Could not preserve relationships while merging duplicate variables.', [ 'status' => 500 ] );
        }

        return true;
    }


    /* ── GET ONE ─────────────────────────────────────────────────────── */

    public function get_variable( \WP_REST_Request $request ) {
        $id  = (int) $request->get_param( 'id' );
        $var = $this->manager->get( $id );

        if ( ! $var ) {
            return new \WP_Error( 've_not_found', 'Variable not found.', [ 'status' => 404 ] );
        }

        $effective = ( new ThemeManager() )->apply_to_variables( [ $var ] );
        $var = $effective[0] ?? $var;
        $annotated = ( new ColorPaletteManager() )->annotate_variables( [ $var ] );
        $var = $annotated[0] ?? $var;

        // Attach dependency info.
        $graph              = new DependencyGraph();
        $var['dependents']  = $graph->get_dependents( $id );
        $var['depends_on']  = $graph->get_dependencies( $id );

        return new \WP_REST_Response( $var, 200 );
    }

    /* ── CREATE ──────────────────────────────────────────────────────── */

    public function create_variable( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $palette_id = isset( $data['palette_id'] ) ? (int) $data['palette_id'] : 0;
        unset( $data['palette_id'] );
        $result = $this->manager->create( $data );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        $color_palettes = new ColorPaletteManager();
        if ( $color_palettes->is_color_variable( $result ) && 'generated' !== (string) ( $result['type'] ?? '' ) ) {
            if ( $palette_id <= 0 ) {
                $palette_id = $color_palettes->first_id();
            }
            if ( $palette_id > 0 ) {
                $assigned = $color_palettes->assign( (int) $result['id'], $palette_id );
                if ( is_wp_error( $assigned ) ) {
                    $this->manager->delete( (int) $result['id'], true );
                    return $assigned;
                }
                $annotated = $color_palettes->annotate_variables( [ $result ] );
                $result = $annotated[0] ?? $result;
            }
        }

        return new \WP_REST_Response( $result, 201 );
    }


    /* ── RENAME IMPACT / PROPAGATION ─────────────────────────────────── */
    public function rename_preview( \WP_REST_Request $request ) {
        $id=(int)$request->get_param('id');$new_name=VariableManager::normalize_name((string)$request->get_param('new_name'));$existing=$this->manager->get($id);
        if(!$existing)return new \WP_Error('ve_not_found','Variable not found.',['status'=>404]);
        if(!$new_name||$new_name===$existing['name'])return new \WP_REST_Response(['old_name'=>$existing['name'],'new_name'=>$new_name,'impact'=>['total_matches'=>0,'locations'=>[]]],200);
        if(!preg_match(VariableManager::NAME_PATTERN,$new_name))return new \WP_Error('ve_invalid_name','Variable names may use lowercase letters, numbers, and hyphens.',['status'=>400]);
        try {
            $mappings = $this->build_rename_mappings( $existing['name'], $new_name, $id );
            $impact   = ( new RenamePropagationManager( $mappings ) )->preview();
        } catch ( \Throwable $e ) {
            return new \WP_REST_Response([
                'old_name' => $existing['name'],
                'new_name' => $new_name,
                'mappings' => [],
                'impact'   => [ 'total_matches' => 0, 'locations' => [] ],
                'warning'  => 'Impact preview could not complete safely: ' . $e->getMessage(),
            ], 200);
        }
        return new \WP_REST_Response(['old_name'=>$existing['name'],'new_name'=>$new_name,'mappings'=>$mappings,'impact'=>$impact],200);
    }
    private function build_rename_mappings(string $old_name,string $new_name,int $id):array{global $wpdb;$table=Schema::table('variables');$vm=new VariableManager();$maps=[RenamePropagationManager::css_mapping_for_names($old_name,$new_name)];$children=$wpdb->get_results($wpdb->prepare("SELECT name FROM {$table} WHERE type='generated' AND source_id=%d ORDER BY id ASC",$id),ARRAY_A);foreach($children as $ch){$old=(string)($ch['name']??'');if(!$old)continue;$new=$this->guess_renamed_child($old,$old_name,$new_name);if($new&&$new!==$old)$maps[]=['old'=>$vm->to_css_name($old),'new'=>$vm->to_css_name($new)];}return $this->unique_mappings($maps);}    
    private function guess_renamed_child(string $child,string $old_name,string $new_name):string{if(0===strncmp($child,$old_name.'.',strlen($old_name)+1))return $new_name.substr($child,strlen($old_name));$parts=explode('.',$new_name);$family=end($parts);if(preg_match('/\.(\d+(?:\.\d+)?)$/',$child,$m))return $family.'.'.$m[1];if(preg_match('/\.([ldt])\.(\d+)$/',$child,$m))return $new_name.'.'.$m[1].'.'.$m[2];return $child;}
    private function unique_mappings(array $maps):array{$out=[];$seen=[];foreach($maps as $m){if(empty($m['old'])||empty($m['new'])||$m['old']===$m['new'])continue;$k=$m['old'].'=>'.$m['new'];if(isset($seen[$k]))continue;$seen[$k]=true;$out[]=$m;}return $out;}


    private function remember_rename_history( int $id, string $old_name, string $new_name ): void {
        if ( $old_name === $new_name ) {
            return;
        }

        $old_public = ltrim( $this->manager->to_css_name( $old_name ), '-' );
        $new_public = ltrim( $this->manager->to_css_name( $new_name ), '-' );
        if ( ! $old_public || $old_public === $new_public ) {
            return;
        }

        $history = get_option( 've_variable_rename_history', [] );
        if ( ! is_array( $history ) ) {
            $history = [];
        }

        $key = (string) $id;
        $list = isset( $history[ $key ] ) && is_array( $history[ $key ] ) ? $history[ $key ] : [];
        array_unshift( $list, $old_public );
        $list = array_values( array_unique( array_filter( $list ) ) );
        $history[ $key ] = array_slice( $list, 0, 10 );

        update_option( 've_variable_rename_history', $history, false );
    }

    /* ── UPDATE ──────────────────────────────────────────────────────── */

    public function update_variable( \WP_REST_Request $request ) {
        $id   = (int) $request->get_param( 'id' );
        $data = $request->get_json_params();
        $old  = $this->manager->get( $id );
        $maps = [];

        $palette_manager = new ThemeManager();
        $palette_value_update = $old
            && ! empty( $data['palette_value'] )
            && $palette_manager->is_custom_active()
            && 'color' === (string) ( $old['namespace'] ?? '' )
            && 'alias' !== (string) ( $old['type'] ?? '' )
            && array_key_exists( 'value', $data )
            && empty( $data['name'] )
            && ( empty( $data['type'] ) || 'base' === $data['type'] )
            && empty( $data['source_id'] );
        unset( $data['palette_value'] );
        if ( $palette_value_update ) {
            $result = $palette_manager->set_color_value( $old, (string) $data['value'] );
            return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 200 );
        }

        $new_name = ! empty( $data['name'] ) ? VariableManager::normalize_name( (string) $data['name'] ) : '';
        $is_rename = $old && $new_name && $new_name !== ( $old['name'] ?? '' );

        if ( $is_rename ) {
            if ( ! empty( $data['propagate_usages'] ) ) {
                $maps = $this->build_rename_mappings( (string) $old['name'], $new_name, $id );
            }
        }

        $result = $this->manager->update( $id, $data );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        if ( $is_rename ) {
            $this->remember_rename_history( $id, (string) $old['name'], $new_name );
            $palette_manager->rename_variable( (string) $old['name'], $new_name );
        }

        if ( ! empty( $maps ) ) {
            try {
                $result['rename_impact'] = ( new RenamePropagationManager( $maps ) )->apply();
            } catch ( \Throwable $e ) {
                $result['rename_impact'] = [
                    'total_matches' => 0,
                    'updated_records' => 0,
                    'locations' => [],
                    'warnings' => [ 'Usage propagation could not complete: ' . $e->getMessage() ],
                ];
            }
        }

        $color_palettes = new ColorPaletteManager();
        $color_palettes->reconcile_variable( $id );
        $annotated = $color_palettes->annotate_variables( [ $result ] );
        $result = $annotated[0] ?? $result;

        return new \WP_REST_Response( $result, 200 );
    }

    /* ── DELETE ──────────────────────────────────────────────────────── */

    public function delete_variable( \WP_REST_Request $request ) {
        $id    = (int) $request->get_param( 'id' );
        $force = (bool) $request->get_param( 'force' );
        $existing = $this->manager->get( $id );
        $result = $this->manager->delete( $id, $force );

        if ( is_wp_error( $result ) ) {
            return $result;
        }
        if ( $existing ) {
            ( new ThemeManager() )->delete_variable( (string) $existing['name'] );
            ( new ColorPaletteManager() )->remove_variable( (int) $existing['id'] );
        }

        return new \WP_REST_Response( [ 'deleted' => true, 'id' => $id ], 200 );
    }

    public function reorder_variables( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $ids = isset( $data['ids'] ) && is_array( $data['ids'] ) ? array_map( 'intval', $data['ids'] ) : [];
        if ( empty( $ids ) ) {
            return new \WP_Error( 've_reorder_missing_ids', 'No IDs provided.', [ 'status' => 400 ] );
        }
        $result = $this->manager->reorder( $ids );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function batch_delete_variables( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $ids = isset( $data['ids'] ) && is_array( $data['ids'] ) ? array_map( 'intval', $data['ids'] ) : [];
        $force = ! empty( $data['force'] );
        if ( empty( $ids ) ) {
            return new \WP_Error( 've_batch_delete_missing_ids', 'No IDs provided.', [ 'status' => 400 ] );
        }

        $result = $this->manager->batch_delete( $ids, $force );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        foreach ( $ids as $id ) {
            ( new ColorPaletteManager() )->remove_variable( (int) $id );
        }

        return new \WP_REST_Response( [ 'deleted' => true, 'ids' => $ids ], 200 );
    }
}
