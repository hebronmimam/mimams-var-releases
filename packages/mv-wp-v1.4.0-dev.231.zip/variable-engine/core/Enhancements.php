<?php
/**
 * Enhancement Studio (C1, direction 2): optional improvements to WordPress
 * itself, each switched on on purpose, each loading nothing while it is off.
 *
 * The first is the owner's own: "that should be our first enhancement" -
 * WordPress admin notices as a floating stack of toasts (their snippet, "HM -
 * WordPress Admin Notices -> Floating Toasts"). It loads in wp-admin only,
 * never on the site's pages, and only for the accounts it is on for.
 *
 * @package VariableEngine
 */

namespace VE\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Enhancements {

    public const OPTION      = 've_enhancements';
    public const NATIVE_META = 've_admin_toasts_native';

    /** What exists. A card is shown only for something that works. */
    public static function registry(): array {
        return [
            'admin_toasts' => [
                'id'       => 'admin_toasts',
                'name'     => 'Floating admin notices',
                'category' => 'Notifications',
                'scope'    => 'wp-admin',
                'icon'     => 'bell-ringing',
                'summary'  => 'WordPress notices float in a calm stack instead of pushing the page down. Success and info leave on their own; warnings and errors stay until you dismiss them.',
            ],
        ];
    }

    public static function defaults(): array {
        return [
            'master'  => true,
            'enabled' => [ 'admin_toasts' => false ],
            'opts'    => [
                'admin_toasts' => [
                    'scope'            => 'everyone', // or 'me'
                    'owner'            => 0,
                    'position'         => 'tr',       // tr, tl, br, bl
                    'duration'         => 10,         // seconds, 3-20
                    'persist_critical' => true,
                    'native_choice'    => true,
                ],
            ],
        ];
    }

    public static function settings(): array {
        $saved = get_option( self::OPTION, [] );
        $saved = is_array( $saved ) ? $saved : [];
        $d     = self::defaults();
        $out   = [
            'master'  => array_key_exists( 'master', $saved ) ? (bool) $saved['master'] : $d['master'],
            'enabled' => array_merge( $d['enabled'], array_map( 'boolval', (array) ( $saved['enabled'] ?? [] ) ) ),
            'opts'    => $d['opts'],
        ];
        foreach ( $d['opts'] as $id => $defaults ) {
            $out['opts'][ $id ] = array_merge( $defaults, (array) ( $saved['opts'][ $id ] ?? [] ) );
        }
        $out['enabled'] = array_intersect_key( $out['enabled'], self::registry() );
        return $out;
    }

    /** Merge a partial change, clean every value, and store it. */
    public static function save( array $change ): array {
        $s = self::settings();
        if ( array_key_exists( 'master', $change ) ) {
            $s['master'] = (bool) $change['master'];
        }
        foreach ( (array) ( $change['enabled'] ?? [] ) as $id => $on ) {
            if ( isset( self::registry()[ $id ] ) ) {
                $s['enabled'][ $id ] = (bool) $on;
            }
        }
        $o = (array) ( $change['opts']['admin_toasts'] ?? [] );
        $t = &$s['opts']['admin_toasts'];
        if ( isset( $o['scope'] ) && in_array( $o['scope'], [ 'everyone', 'me' ], true ) ) {
            $t['scope'] = $o['scope'];
            $t['owner'] = 'me' === $o['scope'] ? get_current_user_id() : 0;
        }
        if ( isset( $o['position'] ) && in_array( $o['position'], [ 'tr', 'tl', 'br', 'bl' ], true ) ) {
            $t['position'] = $o['position'];
        }
        if ( isset( $o['duration'] ) ) {
            $t['duration'] = max( 3, min( 20, (int) $o['duration'] ) );
        }
        foreach ( [ 'persist_critical', 'native_choice' ] as $flag ) {
            if ( array_key_exists( $flag, $o ) ) {
                $t[ $flag ] = (bool) $o[ $flag ];
            }
        }
        unset( $t );
        update_option( self::OPTION, $s, false );
        return self::payload();
    }

    /** What the Studio shows, including this account's own choice. */
    public static function payload(): array {
        $s = self::settings();
        return [
            'registry'   => array_values( self::registry() ),
            'settings'   => $s,
            'can_manage' => current_user_can( 'manage_options' ),
            'me'       => [
                'id'     => get_current_user_id(),
                'native' => (bool) get_user_meta( get_current_user_id(), self::NATIVE_META, true ),
                'active' => self::toasts_on_for( get_current_user_id() ),
            ],
        ];
    }

    public static function set_native( bool $native ): array {
        if ( $native ) {
            update_user_meta( get_current_user_id(), self::NATIVE_META, 1 );
        } else {
            delete_user_meta( get_current_user_id(), self::NATIVE_META );
        }
        return self::payload();
    }

    /** Whether floating notices run for this account. */
    public static function toasts_on_for( int $user_id ): bool {
        $s = self::settings();
        $t = $s['opts']['admin_toasts'];
        if ( ! $user_id || ! $s['master'] || empty( $s['enabled']['admin_toasts'] ) ) {
            return false;
        }
        if ( 'me' === $t['scope'] && (int) $t['owner'] !== $user_id ) {
            return false;
        }
        return ! ( $t['native_choice'] && get_user_meta( $user_id, self::NATIVE_META, true ) );
    }

    /* ── loading, wp-admin only ─────────────────────────────────────── */

    public static function register(): void {
        add_action( 'admin_enqueue_scripts', [ self::class, 'enqueue_admin' ], 1 );
    }

    public static function enqueue_admin(): void {
        if ( ! is_admin() || wp_doing_ajax() || ! self::toasts_on_for( get_current_user_id() ) ) {
            return;
        }
        $t   = self::settings()['opts']['admin_toasts'];
        $ver = defined( 'VE_VERSION' ) ? VE_VERSION : '1';
        wp_enqueue_style( 've-admin-toasts', VE_URL . 'assets/css/admin-toasts.css', [], $ver );
        wp_enqueue_script( 've-admin-toasts', VE_URL . 'assets/js/admin-toasts.js', [], $ver, true );
        wp_add_inline_script( 've-admin-toasts', 'window.veAdminToastsConfig=' . wp_json_encode( [
            'position' => $t['position'],
            'duration' => (int) $t['duration'],
            'persist'  => (bool) $t['persist_critical'],
        ] ) . ';', 'before' );
        // Hidden before the page paints, so a notice never flashes in the flow
        // first - and let go after 3s if the stack never started, so a notice
        // can never be lost to a script that failed.
        wp_register_script( 've-admin-toasts-early', '', [], $ver, false );
        wp_enqueue_script( 've-admin-toasts-early' );
        wp_add_inline_script( 've-admin-toasts-early', "document.documentElement.classList.add('ve-toasts-on');setTimeout(function(){if(!window.__veToastsReady)document.documentElement.classList.remove('ve-toasts-on');},3000);" );
    }
}
