(function(){
'use strict';
/* Mimam's Var - the four studios, fetched the first time one is opened.
 *
 * 538 KB, and none of it is needed to draw the tool rail, which is all most
 * wp-admin pages ever show. These functions used to sit in builder-panel.js
 * and read their helpers straight out of that closure; they cannot any more,
 * so the panel hands the closure across on window.__VE.shared.
 *
 * The list below is fixed. scripts/check-v1-3-519-lazy-studios.js fails if a
 * studio reaches for something the panel does not pass, because a missing
 * helper does not show up here - it shows up when the owner opens the studio.
 */
var S=window.__VE&&window.__VE.shared;
if(!S){console.error('Mimam\u2019s Var: studios.js loaded before the panel');return;}
var h=S.h,render=S.render,Fragment=S.Fragment,useState=S.useState,useEffect=S.useEffect,useRef=S.useRef,useMemo=S.useMemo,useCallback=S.useCallback,useLayoutEffect=S.useLayoutEffect,CFG=S.CFG,api=S.api,ph=S.ph,rm=S.rm,restEndpoint=S.restEndpoint,COLL_ICONS=S.COLL_ICONS,CheckControl=S.CheckControl,ConfirmModal=S.ConfirmModal,ContentMediaPicker=S.ContentMediaPicker,MVInlineColorPicker=S.MVInlineColorPicker,MediaCtxMenu=S.MediaCtxMenu,MediaVideoPlayer=S.MediaVideoPlayer,MediaVideoThumbnail=S.MediaVideoThumbnail,RichContentEditor=S.RichContentEditor,SelectMenu=S.SelectMenu,ToggleControl=S.ToggleControl,VE_MEDIA_CACHE=S.VE_MEDIA_CACHE,VE_MEDIA_CACHE_KEY=S.VE_MEDIA_CACHE_KEY,clrAlpha=S.clrAlpha,clrToHex=S.clrToHex,collectFolderMediaIds=S.collectFolderMediaIds,contentTitleSlug=S.contentTitleSlug,defaultContentImportMapping=S.defaultContentImportMapping,ensureFontToolsRuntime=S.ensureFontToolsRuntime,fontNameText=S.fontNameText,fontWeightLabel=S.fontWeightLabel,headerSafeFilename=S.headerSafeFilename,hexWithAlpha=S.hexWithAlpha,keepInsideBounds=S.keepInsideBounds,loadMediaCollapsedPaths=S.loadMediaCollapsedPaths,parseContentImportText=S.parseContentImportText,persistMediaCollapsedPaths=S.persistMediaCollapsedPaths,persistUserPreference=S.persistUserPreference,prefetchMediaLibrary=S.prefetchMediaLibrary,publishMediaCache=S.publishMediaCache,subscribeMediaCache=S.subscribeMediaCache,MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED=S.MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED;
function ContentStudioSub({ onClose, flash }) {
  const [meta, setMeta] = useState({ cpts: [], field_groups: [], option_pages: [], authors: [], taxonomies: {}, acf_active: false, jet_active: false });
  const [activeNav, setActiveNav] = useState(() => { try { return localStorage.getItem('ve_cs_nav') || 'page'; } catch (e) { return 'page'; } });
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [contentStatusFilter, setContentStatusFilter] = useState(() => localStorage.getItem('ve_content_status_filter') || 'active');
  const [createDraft, setCreateDraft] = useState({ title: '', slug: '', slugManuallyEdited: false, status: 'draft', content: '', excerpt: '' });
  const [visibleContentGroups, setVisibleContentGroups] = useState(() => {
    const defaults = { default: true, custom: true, taxonomies: true, options: true, system: false, fields: true };
    try {
      const parsed = JSON.parse(localStorage.getItem('ve_content_visible_groups_v2') || 'null');
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? { ...defaults, ...parsed } : defaults;
    } catch (e) { return defaults; }
  });
  // When set, the main area shows a list of that category's items (#8). The section
  // caret still toggles collapse; clicking the section label opens this list.
  const [categoryView, setCategoryView] = useState(null);
  const [catSearch, setCatSearch] = useState('');
  // Content Studio view modes (List / Cards / Board / Calendar) — approved from the mock.
  const [contentView, setContentView] = useState(() => { try { return localStorage.getItem('ve_content_view') || 'list'; } catch (e) { return 'list'; } });
  // Focus mode: while a hover preview is open, push the rest of Content Studio back so
  // the card is the only thing competing for attention. The card is mounted on <body>,
  // outside the studio, so it stays perfectly sharp while the studio behind it recedes.
  const [contentFocus, setContentFocus] = useState(() => { try { return localStorage.getItem('ve_content_focus') === '1'; } catch (e) { return false; } });
  const [contentFocusStyle, setContentFocusStyle] = useState(() => { try { return localStorage.getItem('ve_content_focus_style') || 'blur'; } catch (e) { return 'blur'; } });
  const [contentFocusMenu, setContentFocusMenu] = useState(false);
  const toggleContentFocus = () => setContentFocus(v => { const n = !v; try { localStorage.setItem('ve_content_focus', n ? '1' : '0'); } catch (e) {} return n; });
  const chooseContentFocusStyle = v => { setContentFocusStyle(v); try { localStorage.setItem('ve_content_focus_style', v); } catch (e) {} };
  const chooseContentView = v => { setContentView(v); try { localStorage.setItem('ve_content_view', v); } catch (e) {} };
  const [contentCalRef, setContentCalRef] = useState(() => new Date());
  const [contentCalMode, setContentCalMode] = useState('month');
  // Hover preview card is rendered into a body-level node so a transformed panel
  // ancestor can't clip it or offset its fixed positioning.
  const hoverElRef = useRef(null);
  useEffect(() => {
    // Any click (e.g. opening the post) or scroll dismisses the preview immediately,
    // so it can't linger over the editor after navigating away from the list.
    const hide = () => { if (hoverElRef.current) hoverElRef.current.style.display = 'none'; };
    document.addEventListener('click', hide, true);
    document.addEventListener('scroll', hide, true);
    window.addEventListener('resize', hide);
    return () => {
      document.removeEventListener('click', hide, true);
      document.removeEventListener('scroll', hide, true);
      window.removeEventListener('resize', hide);
      if (hoverElRef.current) { hoverElRef.current.remove(); hoverElRef.current = null; }
    };
  }, []);
  const [contentColumnPanelOpen, setContentColumnPanelOpen] = useState(false);
  const [contentColumns, setContentColumns] = useState(() => {
    const defaults = { id: true, slug: true, status: true, created: true, modified: true, seo: true, actions: true };
    try {
      const parsed = JSON.parse(localStorage.getItem('ve_content_table_columns') || 'null');
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? { ...defaults, ...parsed } : defaults;
    } catch (e) { return defaults; }
  });
  const [editingPost, setEditingPost] = useState(null);
  const [rankMathLiveAnalysis, setRankMathLiveAnalysis] = useState({ key: '', id: 0, score: null, status: 'idle' });
  const csRootRef = useRef(null);
  const readContentStudioDefaultTheme = () => { try { return localStorage.getItem('ve_content_studio_default_theme') || localStorage.getItem('ve_content_editor_theme') || 'dark'; } catch (e) { return 'dark'; } };
  const [csTheme, setCsTheme] = useState(readContentStudioDefaultTheme);
  const applyCsTheme = mode => {
    const next = mode === 'light' ? 'light' : 'dark';
    setCsTheme(next);
    try { localStorage.setItem('ve_content_editor_theme', next); } catch (e) {}
  };
  const renderContentThemeToggle = () => h('div',{class:'ve-rich-theme-toggle ve-content-theme-toggle',role:'group','aria-label':'Editor theme'},
    h('button',{type:'button',class:'ve-rich-theme-seg'+(csTheme==='light'?' on':''),'aria-pressed':csTheme==='light'?'true':'false',title:'Light theme',onClick:()=>applyCsTheme('light')},ph('sun'),h('span',null,'Light')),
    h('button',{type:'button',class:'ve-rich-theme-seg'+(csTheme==='dark'?' on':''),'aria-pressed':csTheme==='dark'?'true':'false',title:'Dark theme',onClick:()=>applyCsTheme('dark')},ph('moon'),h('span',null,'Dark'))
  );
  useEffect(() => {
    const panel = csRootRef.current && csRootRef.current.closest('.ve-standalone-panel');
    // The global tool-icon rail lives outside the panel, so it can't inherit .ve-cs-light.
    // Flag the body when the Content Studio editor is in light mode so the rail can follow.
    const railLight = !!editingPost && csTheme === 'light';
    document.body.classList.toggle('ve-cs-rail-light', railLight);
    if (panel) {
      if (editingPost) panel.setAttribute('data-cs-theme', csTheme);
      else panel.removeAttribute('data-cs-theme');
    }
    return () => {
      document.body.classList.remove('ve-cs-rail-light');
      if (panel) panel.removeAttribute('data-cs-theme');
    };
  }, [csTheme, editingPost]);
  const [contentImportOpen,setContentImportOpen]=useState(false);
  const [contentImportStep,setContentImportStep]=useState(0);
  const [contentImportFile,setContentImportFile]=useState(null);
  const [contentImportMapping,setContentImportMapping]=useState({});
  const [contentImportOptions,setContentImportOptions]=useState({post_type:'post',status:'draft',author:0,match_slug:true,import_media:true,update_existing:false});
  const [contentImportPreview,setContentImportPreview]=useState(null);
  const [contentImportConfirmation,setContentImportConfirmation]=useState('');
  const [contentImportRunning,setContentImportRunning]=useState(false);
  const [contentImportResult,setContentImportResult]=useState(null);
  const [contentImportError,setContentImportError]=useState('');
  const [contentImportDragging,setContentImportDragging]=useState(false);
  const contentImportFileRef=useRef(null);
  const [contentMediaPicker, setContentMediaPicker] = useState(null);
  const [contentEditorRailTab,setContentEditorRailTab]=useState('publish');
  const [contentEditorFocus,setContentEditorFocus]=useState(false);
  const [contentEditorSelection,setContentEditorSelection]=useState('');
  const [contentSelectedBlock,setContentSelectedBlock]=useState(null);
  const [contentEditorPreview,setContentEditorPreview]=useState(false);
  const [contentEditorDevice,setContentEditorDevice]=useState('desktop');
  const [contentEditorSaveState,setContentEditorSaveState]=useState('saved');
  const [contentOutlineCollapsed,setContentOutlineCollapsed]=useState(false);
  const [contentCollapsedRows,setContentCollapsedRows]=useState({});
  const [contentOutlineSearchOpen,setContentOutlineSearchOpen]=useState(false);
  const [contentOutlineQuery,setContentOutlineQuery]=useState('');
  const [contentAddBlockOpen,setContentAddBlockOpen]=useState(false);
  const [contentDraggedBlock,setContentDraggedBlock]=useState(null);
  const [contentDropTarget,setContentDropTarget]=useState(null);
  const [pendingContentImageDelete,setPendingContentImageDelete]=useState(false);
  const contentAddBlockRef=useRef(null);
  const contentPreviewWheelRef=useRef(0);
  useEffect(()=>{
    if(!contentAddBlockOpen)return;
    const close=event=>{if(contentAddBlockRef.current&&!contentAddBlockRef.current.contains(event.target))setContentAddBlockOpen(false);};
    document.addEventListener('pointerdown',close,true);
    return()=>document.removeEventListener('pointerdown',close,true);
  },[contentAddBlockOpen]);
  const contentEditorOutline=useMemo(()=>{
    if(!editingPost)return[];
    const rows=[{id:'title',label:editingPost.titleText||'Untitled',icon:'text-h-one',type:'Title',depth:0}];
    if(editingPost.excerpt)rows.push({id:'excerpt',label:'Excerpt',icon:'quotes',type:'Field',depth:0});
    const html=String(editingPost.content||'');
    rows.push({id:'content',label:'Body content',icon:'article',type:'Editor',depth:0});
    if(typeof DOMParser!=='undefined'&&html){
      try{
        const doc=new DOMParser().parseFromString('<main>'+html+'</main>','text/html');
        const root=doc.body.firstElementChild;
        const labels={p:'Paragraph',blockquote:'Quote',pre:'Code',ul:'Bulleted list',ol:'Numbered list',li:'List item',hr:'Divider',section:'Section',article:'Article',div:'Group',figure:'Image'};
        const icons={p:'paragraph',blockquote:'quotes',pre:'code',ul:'list-bullets',ol:'list-numbers',li:'list-dashes',hr:'minus',section:'square-half',article:'article',div:'squares-four',figure:'image'};
        const headingStack=[];
        let rowCount=0;
        const addNodeRow=(node,path,depth,draggable,skipListChildren)=>{
          if(!node||rowCount>=96)return;
          const tag=String(node.tagName||'').toLowerCase();
          const isImage=tag==='img'||tag==='figure'||!!node.querySelector?.(':scope > img');
          const heading=/^h[1-6]$/.test(tag);
          const text=(node.textContent||'').replace(/\s+/g,' ').trim();
          const label=isImage?(node.getAttribute('alt')||node.querySelector?.('img')?.getAttribute('alt')||'Image'):((tag==='ul'||tag==='ol')?(labels[tag]||'List'):(text||labels[tag]||'Content block'));
          rows.push({id:'block-'+path.join('-'),label,icon:isImage?'image':heading?'text-h':(icons[tag]||'square'),type:isImage?'Image':heading?('Heading '+tag.slice(1)):(labels[tag]||'Block'),tag,depth,nodeIndex:path[0],nodePath:path,draggable:!!draggable});
          rowCount++;
          if((tag==='ul'||tag==='ol')&&!skipListChildren){
            Array.from(node.children||[]).forEach((child,index)=>{
              if(String(child.tagName||'').toLowerCase()==='li')addNodeRow(child,path.concat(index),depth+1,false);
            });
          }else if(['section','article','div'].includes(tag)){
            Array.from(node.children||[]).forEach((child,index)=>addNodeRow(child,path.concat(index),depth+1,false));
          }
        };
        const children=Array.from(root?.children||[]).slice(0,64);
        for(let index=0;index<children.length;index++){
          const node=children[index];
          const tag=String(node.tagName||'').toLowerCase();
          if(/^h[1-6]$/.test(tag)){
            const level=parseInt(tag.slice(1),10);
            while(headingStack.length&&headingStack[headingStack.length-1].level>=level)headingStack.pop();
            const depth=1+headingStack.length;
            addNodeRow(node,[index],depth,true);
            headingStack.push({level,depth});
            continue;
          }
          const depth=headingStack.length?headingStack[headingStack.length-1].depth+1:1;
          if(tag==='ul'||tag==='ol'){
            const grouped=[];
            let cursor=index;
            while(cursor<children.length&&String(children[cursor]?.tagName||'').toLowerCase()===tag){grouped.push({node:children[cursor],index:cursor});cursor++;}
            const itemCount=grouped.reduce((count,entry)=>count+Array.from(entry.node.children||[]).filter(child=>String(child.tagName||'').toLowerCase()==='li').length,0);
            addNodeRow(node,[index],depth,grouped.length===1,true);
            const parent=rows[rows.length-1];
            if(parent){parent.label=labels[tag];parent.groupedPaths=grouped.map(entry=>[entry.index]);parent.itemCount=itemCount;}
            grouped.forEach(entry=>Array.from(entry.node.children||[]).forEach((child,childIndex)=>{
              if(String(child.tagName||'').toLowerCase()==='li')addNodeRow(child,[entry.index,childIndex],depth+1,false);
            }));
            index=cursor-1;
            continue;
          }
          addNodeRow(node,[index],depth,true);
        }
      }catch(e){}
    }
    return rows.map((row,index)=>({...row,hasChildren:!!rows[index+1]&&rows[index+1].depth>row.depth}));
  },[editingPost?.titleText,editingPost?.content,editingPost?.excerpt]);
  const visibleContentEditorOutline=useMemo(()=>{
    const query=contentOutlineQuery.trim().toLowerCase();
    if(query)return contentEditorOutline.filter(row=>String(row.label||'').toLowerCase().includes(query)||String(row.type||'').toLowerCase().includes(query));
    if(contentOutlineCollapsed)return contentEditorOutline.filter(row=>row.depth===0);
    const hiddenParents=[];
    return contentEditorOutline.filter(row=>{
      while(hiddenParents.length&&hiddenParents[hiddenParents.length-1].depth>=row.depth)hiddenParents.pop();
      const hidden=hiddenParents.length>0;
      if(!hidden&&row.hasChildren&&contentCollapsedRows[row.id])hiddenParents.push({id:row.id,depth:row.depth});
      return !hidden;
    });
  },[contentEditorOutline,contentOutlineCollapsed,contentOutlineQuery,contentCollapsedRows]);
  const contentSurface=()=>document.querySelector('.ve-content-editor-redesign .ve-rich-surface');
  const setContentPreviewMode=next=>{
    const enabled=!!next;
    contentPreviewWheelRef.current=0;
    if(enabled){
      const surface=contentSurface();
      surface?.querySelectorAll?.('.ve-rich-selected-block').forEach(node=>{
        node.classList.remove('ve-rich-selected-block');
        node.removeAttribute('data-ve-block-label');
        if(!node.getAttribute('class'))node.removeAttribute('class');
      });
      setContentSelectedBlock(null);
      setContentEditorSelection('');
    }
    setContentEditorPreview(enabled);
  };
  const contentNodeForRow=row=>{
    if(!row)return null;
    let node=contentSurface();
    const path=Array.isArray(row?.nodePath)?row.nodePath:[Number(row?.nodeIndex)||0];
    for(const index of path){node=node?.children?.[index];if(!node)break;}
    return node||null;
  };
  const toggleContentOutlineRow=row=>{
    if(!row?.hasChildren)return;
    setContentCollapsedRows(current=>({...current,[row.id]:!current[row.id]}));
  };
  const openContentOutlineContext=(event,row)=>{
    const node=contentNodeForRow(row);
    if(!node)return;
    event.preventDefault();
    event.stopPropagation();
    node.dispatchEvent(new MouseEvent('contextmenu',{bubbles:true,cancelable:true,clientX:event.clientX,clientY:event.clientY}));
  };
  const selectedContentNode=()=>{
    const row=contentEditorOutline.find(item=>item.id===contentEditorSelection);
    if(row&&Array.isArray(row.nodePath))return contentNodeForRow(row);
    return contentSurface()?.querySelector?.('.ve-rich-selected-block')||null;
  };
  const selectedContentImage=()=>{
    const node=selectedContentNode();
    if(!node)return null;
    return String(node.tagName||'').toLowerCase()==='img'?node:node.querySelector?.('img')||null;
  };
  const refreshSelectedContentNode=node=>{
    const surface=contentSurface();
    if(!surface||!node)return;
    surface.dispatchEvent(new Event('input',{bubbles:true}));
    setContentEditorSaveState('dirty');
    setTimeout(()=>node.dispatchEvent(new MouseEvent('click',{bubbles:true})),0);
  };
  const replaceSelectedContentImage=()=>{
    const image=selectedContentImage();
    if(!image)return;
    openContentMediaPicker('Replace content image',(url,item)=>{
      const target=selectedContentImage()||image;
      if(!url||!contentSurface()?.contains(target))return;
      target.src=String(url);
      // The picker returns a raw REST attachment, which carries alt_text, not alt.
      if(item)target.setAttribute('alt',String(item.alt_text||item.alt||''));
      refreshSelectedContentNode(target);
    });
  };
  const updateSelectedContentImageAlt=value=>{
    const image=selectedContentImage();
    if(!image)return;
    image.setAttribute('alt',String(value||''));
    refreshSelectedContentNode(image);
  };
  const deleteSelectedContentImage=()=>{
    const node=selectedContentNode();
    if(!node)return;
    node.remove();
    const surface=contentSurface();
    surface?.dispatchEvent(new Event('input',{bubbles:true}));
    setContentEditorSaveState('dirty');
    setContentSelectedBlock(null);
    setContentEditorSelection('content');
    setPendingContentImageDelete(false);
  };
  const insertContentSnippet=(snippet,afterNode=null)=>{
    const surface=contentSurface();
    if(surface){
      const canInsertAfter=afterNode&&surface.contains(afterNode)&&afterNode!==surface;
      if(canInsertAfter)afterNode.insertAdjacentHTML('afterend',snippet);
      else surface.insertAdjacentHTML('beforeend',snippet);
      const inserted=canInsertAfter?afterNode.nextElementSibling:surface.lastElementChild;
      surface.dispatchEvent(new Event('input',{bubbles:true}));
      setTimeout(()=>{
        surface.focus();
        if(inserted){inserted.dispatchEvent(new MouseEvent('click',{bubbles:true}));inserted.scrollIntoView({block:'nearest',behavior:'smooth'});}
      },0);
      return;
    }
    setEditingPost(current=>current?({...current,content:String(current.content||'')+snippet}):current);
  };
  const contentBlockSnippets={
    paragraph:'<p><br></p>',heading:'<h2>New heading</h2>',quote:'<blockquote>Write a quote…</blockquote>',code:'<pre><code>// Write code here</code></pre>',bullets:'<ul><li>List item</li></ul>',numbers:'<ol><li>List item</li></ol>',divider:'<hr>'
  };
  const appendContentBlock=(type='paragraph')=>{
    if(type==='image'){
      setContentAddBlockOpen(false);
      openContentMediaPicker('Add image block',url=>{if(!url)return;setContentEditorSaveState('dirty');insertContentSnippet('<figure><img src="'+String(url).replace(/"/g,'&quot;')+'" alt=""></figure>');});
      return;
    }
    setContentEditorSaveState('dirty');
    setContentEditorSelection('content');
    setContentSelectedBlock(null);
    setContentAddBlockOpen(false);
    insertContentSnippet(contentBlockSnippets[type]||contentBlockSnippets.paragraph);
  };
  const insertContentBlockAfterSelection=(type='paragraph')=>{
    const selected=selectedContentNode();
    if(type==='image'){
      openContentMediaPicker('Add image below selected block',(url,item)=>{
        if(!url)return;
        const alt=String(item?.alt_text||item?.alt||'').replace(/"/g,'&quot;');
        setContentEditorSaveState('dirty');
        insertContentSnippet('<figure><img src="'+String(url).replace(/"/g,'&quot;')+'" alt="'+alt+'"></figure>',selected);
      });
      return;
    }
    setContentEditorSaveState('dirty');
    insertContentSnippet(contentBlockSnippets[type]||contentBlockSnippets.paragraph,selected);
  };
  const mutateSelectedContentBlock=action=>{
    const surface=contentSurface();
    const node=selectedContentNode();
    if(!surface||!node||!surface.contains(node))return;
    let next=node;
    if(action==='duplicate'){
      next=node.cloneNode(true);
      next.classList.remove('ve-rich-selected-block');
      next.removeAttribute('data-ve-block-label');
      node.after(next);
    }else if(action==='up'&&node.previousElementSibling){
      node.previousElementSibling.before(node);
    }else if(action==='down'&&node.nextElementSibling){
      node.nextElementSibling.after(node);
    }else if(action==='delete'){
      next=node.nextElementSibling||node.previousElementSibling;
      node.remove();
    }else{
      return;
    }
    surface.dispatchEvent(new Event('input',{bubbles:true}));
    setContentEditorSaveState('dirty');
    if(action==='delete'&&!next){
      setContentSelectedBlock(null);
      setContentEditorSelection('content');
      return;
    }
    setTimeout(()=>{if(next&&surface.contains(next)){next.dispatchEvent(new MouseEvent('click',{bubbles:true}));next.scrollIntoView({block:'nearest',behavior:'smooth'});}},0);
  };
  const appendContentParagraph=()=>appendContentBlock('paragraph');
  const scrollContentPreview=event=>{
    if(!contentEditorPreview)return;
    const canvas=event.currentTarget;
    if(!canvas||canvas.scrollHeight<=canvas.clientHeight)return;
    contentPreviewWheelRef.current+=Number(event.deltaY)||0;
    const delta=Math.trunc(contentPreviewWheelRef.current);
    event.preventDefault();
    event.stopPropagation();
    if(!delta)return;
    contentPreviewWheelRef.current-=delta;
    const max=Math.max(0,canvas.scrollHeight-canvas.clientHeight);
    const next=Math.max(0,Math.min(max,canvas.scrollTop+delta));
    canvas.scrollTop=next;
    if(next===0||next===max)contentPreviewWheelRef.current=0;
  };
  const selectContentOutlineRow=row=>{
    if(!row)return;
    setContentSelectedBlock(null);
    setContentEditorSelection(row.id);
    if(row.id==='title'||row.id==='excerpt'){
      setContentEditorRailTab('publish');
      setTimeout(()=>document.querySelector(row.id==='title'?'.ve-content-title-fields input':'.ve-content-title-fields textarea')?.focus(),0);
      return;
    }
    if(row.id==='content'){
      setContentEditorRailTab('block');
      setTimeout(()=>document.querySelector('.ve-content-editor-redesign .ve-rich-surface')?.focus(),0);
      return;
    }
    setContentEditorRailTab('block');
    setTimeout(()=>{
      const node=contentNodeForRow(row);
      if(node){node.dispatchEvent(new MouseEvent('click',{bubbles:true}));node.scrollIntoView({block:'nearest',behavior:'smooth'});}
    },0);
  };
  const reorderContentBlocks=(from,to)=>{
    if(!Number.isInteger(from)||!Number.isInteger(to)||from===to)return;
    const surface=contentSurface();
    const blocks=surface?Array.from(surface.children):[];
    if(!surface||!blocks[from]||!blocks[to])return;
    const moving=blocks[from];
    if(from<to)blocks[to].after(moving);else blocks[to].before(moving);
    surface.dispatchEvent(new Event('input',{bubbles:true}));
    setContentEditorSaveState('dirty');
    setContentEditorSelection('block-'+to);
    setTimeout(()=>{moving.dispatchEvent(new MouseEvent('click',{bubbles:true}));moving.scrollIntoView({block:'nearest',behavior:'smooth'});},0);
  };
  const contentBlockGroups=[
    {label:'Text',items:[['paragraph','paragraph','Paragraph'],['heading','text-h-two','Heading'],['quote','quotes','Quote'],['code','code','Code']]},
    {label:'Lists',items:[['bullets','list-bullets','Bulleted list'],['numbers','list-numbers','Numbered list']]},
    {label:'Media',items:[['image','image','Image'],['divider','minus','Divider']]}
  ];
  /* ===== ACF Live Preview builder =====
     Renders the field group as the screen a writer will actually see: click a field to
     edit it in the drawer, insert between fields, reorder, duplicate, delete. Edits are
     held in `items` and persisted through the ACF API on Save. */
  const [fgSel, setFgSel] = useState(0);
  const [fgTab, setFgTab] = useState('general');
  const [fgSaving, setFgSaving] = useState(false);
  const [fgDirty, setFgDirty] = useState(false);
  const FG_TYPES = [
    ['Basic', ['text', 'textarea', 'number', 'range', 'email', 'url', 'password']],
    ['Content', ['image', 'file', 'wysiwyg', 'oembed', 'gallery']],
    ['Choice', ['select', 'checkbox', 'radio', 'button_group', 'true_false']],
    ['Relational', ['link', 'post_object', 'page_link', 'relationship', 'taxonomy', 'user']],
    ['Advanced', ['google_map', 'date_picker', 'time_picker', 'color_picker']],
    ['Layout', ['message', 'accordion', 'tab', 'group', 'repeater', 'flexible_content', 'clone']]
  ];
  const fgMutate = updater => {
    setItems(prev => {
      const next = updater(prev.slice());
      return next;
    });
    setFgDirty(true);
  };
  const fgPreviewControl = field => {
    const t = String(field.type || 'text');
    if (t === 'image' || t === 'gallery') return h('div', { class: 've-fg-fake ve-fg-img' }, t === 'image' ? 'Select image' : 'Add images');
    if (t === 'textarea' || t === 'wysiwyg') return h('div', { class: 've-fg-fake ve-fg-area' });
    if (t === 'relationship' || t === 'post_object' || t === 'page_link') return h('div', { class: 've-fg-fake' }, 'Search & select…');
    if (t === 'true_false') return h('div', { class: 've-fg-tf' }, h('span', { class: 've-fg-swm' }), h('span', null, 'Off'));
    if (t === 'repeater' || t === 'flexible_content') return h('div', null,
      h('div', { class: 've-fg-rep' }, '⋮⋮  Row 1'), h('div', { class: 've-fg-rep' }, '⋮⋮  Row 2'),
      h('div', { class: 've-fg-repadd' }, '+ Add row'));
    if (t === 'select' || t === 'radio' || t === 'button_group' || t === 'checkbox') return h('div', { class: 've-fg-fake' }, 'Choose an option ▾');
    if (t === 'color_picker') return h('div', { class: 've-fg-fake' }, h('span', { class: 've-fg-swatch' }), '#baf400');
    if (t === 'date_picker' || t === 'time_picker') return h('div', { class: 've-fg-fake' }, 'Pick a value');
    return h('div', { class: 've-fg-fake' }, field.placeholder || 'Enter a value');
  };
  const saveFieldGroupFields = async () => {
    const group = (meta.field_groups || []).find(g => g.id === activeNav);
    if (!group) return;
    setFgSaving(true);
    try {
      const gm = fgMeta || {};
      const res = await api.u('acf/field-group/' + encodeURIComponent(group.id), {
        ...(gm.location ? { location: gm.location } : {}),
        ...(gm.style !== undefined ? { style: gm.style } : {}),
        ...(gm.position !== undefined ? { position: gm.position } : {}),
        ...(gm.label_placement !== undefined ? { label_placement: gm.label_placement } : {}),
        ...(gm.instruction_placement !== undefined ? { instruction_placement: gm.instruction_placement } : {}),
        ...(gm.menu_order !== undefined ? { menu_order: gm.menu_order } : {}),
        ...(gm.hide_on_screen !== undefined ? { hide_on_screen: gm.hide_on_screen } : {}),
        ...(gm.active !== undefined ? { active: gm.active } : {}),
        ...(gm.show_in_rest !== undefined ? { show_in_rest: gm.show_in_rest } : {}),
        ...(gm.description !== undefined ? { description: gm.description } : {}),
        ...(gm.label !== undefined ? { label: gm.label } : {}),
        fields: items.map(f => ({
          key: f.key || '',
          label: f.label || '',
          name: f.name || '',
          type: f.type || 'text',
          required: !!f.required,
          instructions: f.instructions || '',
          placeholder: f.placeholder || '',
          default_value: f.default_value || '',
          maxlength: f.maxlength || '',
          wrapper: f.wrapper || { width: '', class: '', id: '' }
        }))
      });
      if (res?.code || res?.available === false) {
        flash(res.message || 'The field group could not be saved.');
      } else {
        if (Array.isArray(res?.fields)) setItems(res.fields);
        setFgMeta(null);
        setFgDirty(false);
        flash('Field group saved.');
        loadMeta && loadMeta();
      }
    } catch (e) {
      flash(e?.message || 'The field group could not be saved.');
    }
    setFgSaving(false);
  };
  const renderFgDrawer = () => {
    const field = items[fgSel];
    const tabs = [['general', 'General'], ['validation', 'Validation'], ['presentation', 'Presentation']];
    return h('div', { class: 've-fg-drawer' },
      h('div', { class: 've-fg-dh' },
        h('div', { class: 've-fg-dt' }, field ? (field.label || '(no label)') : 'No field'),
        h('div', { class: 've-fg-ds' }, field ? ((field.name || '—') + ' · ' + (field.type || 'text')) : '—')
      ),
      h('div', { class: 've-fg-dtabs' }, tabs.map(t => h('button', {
        key: t[0], type: 'button', class: fgTab === t[0] ? 'on' : '', onClick: () => setFgTab(t[0])
      }, t[1]))),
      h('div', { class: 've-fg-dbody' },
        !field ? h('div', { class: 've-fg-empty' }, 'Select a field in the preview, or use “+ insert field”.') :
        fgTab === 'general' ? h('div', null,
          h('label', { class: 've-fg-k' }, 'Field type'),
          h(SelectMenu, {
            className: 've-studio-select', searchable: true, value: field.type || 'text',
            options: FG_TYPES.reduce((acc, grp) => acc.concat(grp[1].map(t => ({ value: t, label: grp[0] + ' · ' + t.replace(/_/g, ' ') }))), []),
            onChange: v => fgMutate(list => { list[fgSel] = { ...list[fgSel], type: v }; return list; })
          }),
          h('label', { class: 've-fg-k', style: 'margin-top:11px' }, 'Field label'),
          h('input', {
            class: 've-studio-input', value: field.label || '',
            onInput: e => { const v = e.target.value; fgMutate(list => { list[fgSel] = { ...list[fgSel], label: v }; return list; }); }
          }),
          h('label', { class: 've-fg-k', style: 'margin-top:11px' }, 'Field name'),
          h('input', {
            class: 've-studio-input', style: 'font-family:monospace', value: field.name || '',
            onInput: e => { const v = e.target.value; fgMutate(list => { list[fgSel] = { ...list[fgSel], name: v }; return list; }); }
          }),
          h('label', { class: 've-fg-k', style: 'margin-top:11px' }, 'Default value'),
          h('input', {
            class: 've-studio-input', value: field.default_value || '',
            onInput: e => { const v = e.target.value; fgMutate(list => { list[fgSel] = { ...list[fgSel], default_value: v }; return list; }); }
          })
        ) :
        fgTab === 'validation' ? h('div', null,
          h('div', { class: 've-fg-tg' },
            h('div', null, h('div', { class: 've-fg-tl' }, 'Required'), h('div', { class: 've-fg-ts' }, 'Must have a value before saving.')),
            h(ToggleControl, {
              checked: !!field.required,
              onChange: v => fgMutate(list => { list[fgSel] = { ...list[fgSel], required: v }; return list; })
            })
          ),
          h('label', { class: 've-fg-k', style: 'margin-top:11px' }, 'Character limit'),
          h('input', {
            class: 've-studio-input', placeholder: '0', value: field.maxlength || '',
            onInput: e => { const v = e.target.value; fgMutate(list => { list[fgSel] = { ...list[fgSel], maxlength: v }; return list; }); }
          })
        ) :
        h('div', null,
          h('label', { class: 've-fg-k' }, 'Instructions'),
          h('textarea', {
            class: 've-studio-input', rows: 3, value: field.instructions || '',
            onInput: e => { const v = e.target.value; fgMutate(list => { list[fgSel] = { ...list[fgSel], instructions: v }; return list; }); }
          }),
          h('label', { class: 've-fg-k', style: 'margin-top:11px' }, 'Placeholder'),
          h('input', {
            class: 've-studio-input', value: field.placeholder || '',
            onInput: e => { const v = e.target.value; fgMutate(list => { list[fgSel] = { ...list[fgSel], placeholder: v }; return list; }); }
          }),
          h('label', { class: 've-fg-k', style: 'margin-top:11px' }, 'Width (%)'),
          h('input', {
            class: 've-studio-input', placeholder: '100', value: (field.wrapper && field.wrapper.width) || '',
            onInput: e => { const v = e.target.value; fgMutate(list => { list[fgSel] = { ...list[fgSel], wrapper: { ...(list[fgSel].wrapper || {}), width: v } }; return list; }); }
          })
        )
      )
    );
  };
  /* ===== Field group Settings — mirrors ACF's own Location / Presentation /
     Group Settings card so nothing is missing versus the native screen. ===== */
  const [fgView, setFgView] = useState('fields');
  const [fgMeta, setFgMeta] = useState(null);
  const FG_HIDE_ON_SCREEN = [
    ['permalink', 'Permalink'], ['the_content', 'Content Editor'], ['excerpt', 'Excerpt'],
    ['discussion', 'Discussion'], ['comments', 'Comments'], ['revisions', 'Revisions'],
    ['slug', 'Slug'], ['author', 'Author'], ['format', 'Format'],
    ['page_attributes', 'Page Attributes'], ['featured_image', 'Featured Image'],
    ['categories', 'Categories'], ['tags', 'Tags'], ['send-trackbacks', 'Send Trackbacks']
  ];
  const FG_RULE_PARAMS = [
    ['post_type', 'Post Type'], ['post_template', 'Post Template'], ['post_status', 'Post Status'],
    ['post_category', 'Post Category'], ['post_format', 'Post Format'], ['post_taxonomy', 'Post Taxonomy'],
    ['page_template', 'Page Template'], ['page_type', 'Page Type'], ['page_parent', 'Page Parent'],
    ['current_user', 'Current User'], ['current_user_role', 'Current User Role'],
    ['user_form', 'User Form'], ['user_role', 'User Role'],
    ['taxonomy', 'Taxonomy'], ['attachment', 'Attachment'], ['comment', 'Comment'],
    ['widget', 'Widget'], ['nav_menu', 'Menu'], ['nav_menu_item', 'Menu Item'], ['block', 'Block'],
    ['options_page', 'Options Page']
  ];
  const fgGroupMeta = () => fgMeta || (meta.field_groups || []).find(g => g.id === activeNav) || {};
  const fgSetMeta = patch => { setFgMeta(prev => ({ ...(prev || fgGroupMeta()), ...patch })); setFgDirty(true); };
  const fgLocation = () => {
    const loc = fgGroupMeta().location;
    return Array.isArray(loc) && loc.length ? loc : [[{ param: 'post_type', operator: '==', value: 'post' }]];
  };
  const fgSetLocation = next => fgSetMeta({ location: next });
  const fgHidden = () => {
    const list = fgGroupMeta().hide_on_screen;
    return Array.isArray(list) ? list : [];
  };
  // Known values for the rule types we can resolve locally; anything else stays free text.
  const fgRuleValueOptions = param => {
    if (param === 'post_type') {
      return [...defaultCpts, ...contentCpts].map(pt => [pt.name, (pt.label || pt.name) + ' (' + pt.name + ')']);
    }
    if (param === 'post_status') {
      return [['publish', 'Published'], ['draft', 'Draft'], ['pending', 'Pending'], ['private', 'Private'], ['future', 'Scheduled']];
    }
    if (param === 'page_type') {
      return [['front_page', 'Front Page'], ['posts_page', 'Posts Page'], ['top_level', 'Top Level Page'], ['parent', 'Parent Page'], ['child', 'Child Page']];
    }
    if (param === 'current_user_role' || param === 'user_role') {
      return [['administrator', 'Administrator'], ['editor', 'Editor'], ['author', 'Author'], ['contributor', 'Contributor'], ['subscriber', 'Subscriber']];
    }
    if (param === 'user_form') {
      return [['add', 'Add'], ['edit', 'Edit'], ['register', 'Register']];
    }
    return null;
  };
  const fgSeg = (value, current, onPick) => h('div', { class: 've-fg-seg' }, value.map(opt => h('button', {
    type: 'button', key: opt[0], class: current === opt[0] ? 'on' : '', onClick: () => onPick(opt[0])
  }, opt[1])));

  const renderFgLocation = () => {
    const groups = fgLocation();
    return h('div', { class: 've-fg-pane' },
      h('p', { class: 've-fg-lead' }, 'Show this field group if'),
      groups.map((rules, gi) => h('div', { class: 've-fg-rulegroup', key: 'rg-' + gi },
        rules.map((rule, ri) => h('div', { key: 'r-' + ri },
          ri > 0 && h('div', { class: 've-fg-and' }, 'AND'),
          h('div', { class: 've-fg-rule' },
            h(SelectMenu, { className: 've-studio-select', searchable: true, value: rule.param || 'post_type',
              options: FG_RULE_PARAMS.map(pr => ({ value: pr[0], label: pr[1] })),
              onChange: v => { const next = groups.map(g => g.slice()); next[gi][ri] = { ...next[gi][ri], param: v }; fgSetLocation(next); }
            }),
            h(SelectMenu, { className: 've-studio-select', value: rule.operator || '==',
              options: [{ value: '==', label: 'is equal to' }, { value: '!=', label: 'is not equal to' }],
              onChange: v => { const next = groups.map(g => g.slice()); next[gi][ri] = { ...next[gi][ri], operator: v }; fgSetLocation(next); }
            }),
            (function () {
              const opts = fgRuleValueOptions(rule.param || 'post_type');
              const setVal = v => { const next = groups.map(g => g.slice()); next[gi][ri] = { ...next[gi][ri], value: v }; fgSetLocation(next); };
              return opts
                ? h(SelectMenu, { className: 've-studio-select', searchable: opts.length > 8, value: rule.value || opts[0][0],
                    options: opts.map(o => ({ value: o[0], label: o[1] })), onChange: setVal })
                : h('input', { class: 've-studio-input', value: rule.value || '', placeholder: 'value',
                    onInput: e => setVal(e.target.value) });
            })(),
            h('button', { type: 'button', class: 've-btn ve-btn-g ve-btn-s', title: 'Remove rule',
              onClick: () => { const next = groups.map(g => g.slice()); next[gi].splice(ri, 1); fgSetLocation(next.filter(g => g.length)); }
            }, ph('trash'))
          )
        )),
        h('button', { type: 'button', class: 've-fg-addrule',
          onClick: () => { const next = groups.map(g => g.slice()); next[gi].push({ param: 'post_type', operator: '==', value: 'post' }); fgSetLocation(next); }
        }, '+ Add rule (AND)')
      )),
      h('div', { class: 've-fg-or' }, h('span', null, 'OR')),
      h('button', { type: 'button', class: 've-btn ve-btn-g ve-btn-s',
        onClick: () => fgSetLocation(groups.concat([[{ param: 'post_type', operator: '==', value: 'post' }]]))
      }, '+ Add rule group')
    );
  };

  const renderFgPresentation = () => {
    const g = fgGroupMeta();
    const row = (label, control, help) => h('div', { class: 've-fg-row' },
      h('label', { class: 've-fg-k' }, label), control,
      help ? h('div', { class: 've-fg-help' }, help) : null);
    return h('div', { class: 've-fg-pane ve-fg-two' },
      h('div', { class: 've-fg-rows' },
        row('Style', fgSeg([['default', 'Standard (WP metabox)'], ['seamless', 'Seamless (no metabox)']], g.style || 'default', v => fgSetMeta({ style: v }))),
        row('Position', fgSeg([['acf_after_title', 'High (after title)'], ['normal', 'Normal (after content)'], ['side', 'Side']], g.position || 'normal', v => fgSetMeta({ position: v }))),
        row('Label placement', fgSeg([['top', 'Top aligned'], ['left', 'Left aligned']], g.label_placement || 'top', v => fgSetMeta({ label_placement: v }))),
        row('Instruction placement', fgSeg([['label', 'Below labels'], ['field', 'Below fields']], g.instruction_placement || 'label', v => fgSetMeta({ instruction_placement: v }))),
        row('Order No.', h('input', { class: 've-studio-input', type: 'number', style: 'max-width:120px', value: String(g.menu_order || 0),
          onInput: e => fgSetMeta({ menu_order: e.target.value }) }), 'Field groups with a lower order appear first.')
      ),
      h('div', null,
        h('label', { class: 've-fg-k' }, 'Hide on screen'),
        h('div', { class: 've-fg-help', style: 'margin:-2px 0 8px' }, 'Remove standard WordPress controls wherever this group appears.'),
        h('div', { class: 've-fg-checks' }, FG_HIDE_ON_SCREEN.map(item => {
          const on = fgHidden().indexOf(item[0]) !== -1;
          return h('button', { type: 'button', key: item[0], role: 'switch', 'aria-checked': on ? 'true' : 'false', class: 've-fg-check' + (on ? ' on' : ''),
            onClick: () => { const list = fgHidden().slice(); const i = list.indexOf(item[0]); if (i === -1) list.push(item[0]); else list.splice(i, 1); fgSetMeta({ hide_on_screen: list }); }
          }, h('span', { class: 've-fg-check-lbl' }, item[1]), h('span', { class: 've-fg-box', 'aria-hidden': 'true' }));
        }))
      )
    );
  };

  const renderFgGroupSettings = () => {
    const g = fgGroupMeta();
    return h('div', { class: 've-fg-pane' },
      h('div', { class: 've-fg-tg' },
        h('div', null, h('div', { class: 've-fg-tl' }, 'Active'), h('div', { class: 've-fg-ts' }, 'Apply this group to matching content.')),
        h(ToggleControl, { checked: g.active !== false, onChange: v => fgSetMeta({ active: v }) })
      ),
      h('div', { class: 've-fg-tg' },
        h('div', null, h('div', { class: 've-fg-tl' }, 'Show in REST API'), h('div', { class: 've-fg-ts' }, 'Expose field values to REST consumers.')),
        h(ToggleControl, { checked: !!g.show_in_rest, onChange: v => fgSetMeta({ show_in_rest: v }) })
      ),
      h('label', { class: 've-fg-k', style: 'margin-top:12px' }, 'Description'),
      h('input', { class: 've-studio-input', value: g.description || '', placeholder: 'Shown in the field group list',
        onInput: e => fgSetMeta({ description: e.target.value }) }),
      h('label', { class: 've-fg-k', style: 'margin-top:12px' }, 'Display title'),
      h('input', { class: 've-studio-input', value: g.label || '', placeholder: 'Optional title shown on the edit screen',
        onInput: e => fgSetMeta({ label: e.target.value }) }),
      h('div', { class: 've-fg-help' }, 'Used for the metabox title instead of the field group title.')
    );
  };

  const renderFieldGroupBuilder = () => {
    const insert = at => {
      const n = items.length + 1;
      fgMutate(list => { list.splice(at, 0, { key: '', label: 'New field', name: 'new_field_' + n, type: 'text', required: false, instructions: '', placeholder: '', wrapper: { width: '', class: '', id: '' } }); return list; });
      setFgSel(at);
    };
    const insertRow = at => h('div', { class: 've-fg-insrow', key: 'ins-' + at },
      h('button', { type: 'button', class: 've-fg-ins', onClick: () => insert(at) },
        h('span', { class: 've-fg-ln' }), h('span', { class: 've-fg-pl' }, '+ insert field'), h('span', { class: 've-fg-ln' })));
    const fieldWidth = field => { const w = parseInt(field && field.wrapper && field.wrapper.width, 10); return (w && w > 0) ? Math.min(100, w) : 100; };
    // Drag the right edge to set the field's Presentation width (#17), snapping to 5%.
    const startFieldResize = (e, i) => {
      e.stopPropagation(); e.preventDefault();
      const card = e.currentTarget.closest && e.currentTarget.closest('.ve-fg-f');
      const container = card && card.parentElement;
      if (!container) return;
      const rect = container.getBoundingClientRect();
      if (card.setPointerCapture && e.pointerId != null) { try { card.setPointerCapture(e.pointerId); } catch (err) {} }
      const move = ev => {
        const raw = ((ev.clientX - rect.left) / Math.max(1, rect.width)) * 100;
        const w = Math.max(15, Math.min(100, Math.round(raw / 5) * 5));
        fgMutate(list => { list[i] = { ...list[i], wrapper: { ...(list[i].wrapper || {}), width: String(w) } }; return list; });
      };
      const up = () => { window.removeEventListener('pointermove', move); window.removeEventListener('pointerup', up); };
      window.addEventListener('pointermove', move);
      window.addEventListener('pointerup', up);
    };
    const viewTabs = h('div', { class: 've-fg-views' }, [
      ['fields', 'Fields'], ['location', 'Location Rules'],
      ['presentation', 'Presentation'], ['group', 'Group Settings']
    ].map(t => h('button', {
      type: 'button', key: t[0], class: fgView === t[0] ? 'on' : '', onClick: () => setFgView(t[0])
    }, t[1])));
    if (fgView !== 'fields') {
      return h('div', { class: 've-fg-root' }, viewTabs,
        fgView === 'location' ? renderFgLocation() :
        fgView === 'presentation' ? renderFgPresentation() : renderFgGroupSettings());
    }
    return h('div', { class: 've-fg-root' }, viewTabs, h('div', { class: 've-fg-wrap' },
      h('div', { class: 've-fg-canvas' },
        h('div', { class: 've-fg-screen' },
          h('div', { class: 've-fg-titlebar' },
            h('div', { class: 've-fg-screenlabel' }, 'Post editor preview'),
            h('div', { class: 've-fg-faketitle' }, 'Add title'),
            h('div', { class: 've-fg-screenhint' }, 'The WordPress title field, shown so you can see where this group lands on the edit screen.')),
          h('p', { class: 've-fg-note' }, ph('eye'), items.length ? 'Exactly what your writers will see — click a field to edit it' : 'This group has no fields yet — add the first one below.'),
          !items.length && h('button', { type: 'button', class: 've-fg-first', onClick: () => insert(0) }, ph('plus'), 'Add the first field'),
          items.map((field, i) => h('div', { key: 'fg-' + i },
            insertRow(i),
            h('div', {
              class: 've-fg-f' + (i === fgSel ? ' sel' : ''),
              style: 'width:' + fieldWidth(field) + '%',
              onClick: () => setFgSel(i)
            },
              h('span', { class: 've-fg-wbadge' }, fieldWidth(field) + '%'),
              h('span', { class: 've-fg-resize', title: 'Drag to set width', onPointerDown: e => startFieldResize(e, i), onClick: e => e.stopPropagation() }),
              h('div', { class: 've-fg-tools' },
                h('button', { type: 'button', title: 'Move up', onClick: e => { e.stopPropagation(); if (i === 0) return; fgMutate(l => { const t = l[i - 1]; l[i - 1] = l[i]; l[i] = t; return l; }); setFgSel(i - 1); } }, ph('arrow-up')),
                h('button', { type: 'button', title: 'Move down', onClick: e => { e.stopPropagation(); if (i === items.length - 1) return; fgMutate(l => { const t = l[i + 1]; l[i + 1] = l[i]; l[i] = t; return l; }); setFgSel(i + 1); } }, ph('arrow-down')),
                h('button', { type: 'button', title: 'Duplicate', onClick: e => { e.stopPropagation(); fgMutate(l => { const c = { ...l[i], key: '', label: (l[i].label || '') + ' copy', name: (l[i].name || 'field') + '_copy' }; l.splice(i + 1, 0, c); return l; }); setFgSel(i + 1); } }, ph('copy')),
                h('button', { type: 'button', title: 'Delete', class: 've-fg-del', onClick: e => { e.stopPropagation(); fgMutate(l => { l.splice(i, 1); return l; }); setFgSel(Math.max(0, i - 1)); } }, ph('trash'))
              ),
              h('div', { class: 've-fg-lbl' }, (field.label || '(no label)'), field.required ? h('span', { class: 've-fg-rq' }, '*') : null),
              fgPreviewControl(field),
              field.instructions ? h('div', { class: 've-fg-hint' }, field.instructions) : null
            )
          )),
          insertRow(items.length)
        )
      ),
      renderFgDrawer()
    ));
  };

  const renderContentAddBlockMenu=()=>contentAddBlockOpen?h('div',{class:'ve-rich-popover ve-content-add-block-menu'},contentBlockGroups.map(group=>h('div',{class:'ve-rich-menu-group',key:group.label},h('span',{class:'ve-rich-menu-label'},group.label),group.items.map(item=>h('button',{type:'button',key:item[0],onMouseDown:event=>event.preventDefault(),onClick:event=>{event.stopPropagation();appendContentBlock(item[0]);}},ph(item[1]),item[2]))))):null;
  const openContentMediaPicker = useCallback((title, onSelect) => {
    setContentMediaPicker({ title: title || 'Choose image', onSelect });
  }, []);


  // Post form state
  const [title, setTitle] = useState('');
  const [status, setStatus] = useState('draft');
  const [newPost, setNewPost] = useState(null);
  const [showCreateForm, setShowCreateForm] = useState(false);

  // CPT form state
  const [showCptForm, setShowCptForm] = useState(false);
  const [cptName, setCptName] = useState('');
  const [editingCptName, setEditingCptName] = useState('');
  const [cptSingular, setCptSingular] = useState('');
  const [cptPlural, setCptPlural] = useState('');
  const [cptSource, setCptSource] = useState('acf');
  // Full ACF post-type registration settings (Post Types editor, #20).
  const [cptView, setCptView] = useState('general');
  const [cptSettings, setCptSettings] = useState(null);
  const cptDefaultSettings = () => ({
    description: '', public: true, hierarchical: false, has_archive: true,
    show_ui: true, show_in_menu: true, show_in_nav_menus: true, show_in_admin_bar: true,
    exclude_from_search: false, publicly_queryable: true, can_export: true, delete_with_user: false,
    menu_position: '', menu_icon: '', capability_type: 'post', query_var: '',
    rewrite_slug: '', rewrite_front: true, rewrite_feeds: false, rewrite_pages: true,
    show_in_rest: true, rest_base: '', rest_namespace: 'wp/v2', rest_controller_class: '',
    supports: ['title', 'editor', 'thumbnail'], taxonomies: [],
    labels: { menu_name: '', all_items: '', edit_item: '', view_item: '', add_new_item: '', new_item: '', search_items: '', not_found: '' }
  });

  // Taxonomy editor state (#8) — mirrors the post-type editor.
  const [showTaxForm, setShowTaxForm] = useState(false);
  const [taxName, setTaxName] = useState('');
  const [editingTaxName, setEditingTaxName] = useState('');
  const [taxSingular, setTaxSingular] = useState('');
  const [taxPlural, setTaxPlural] = useState('');
  const [taxView, setTaxView] = useState('general');
  const [taxSettings, setTaxSettings] = useState(null);
  const taxDefaultSettings = () => ({
    description: '', public: true, hierarchical: true,
    show_ui: true, show_in_menu: true, show_in_nav_menus: true, show_admin_column: true,
    publicly_queryable: true, query_var: '',
    rewrite_slug: '', rewrite_front: true,
    show_in_rest: true, rest_base: '', rest_namespace: 'wp/v2',
    object_type: [],
    labels: { menu_name: '', all_items: '', edit_item: '', view_item: '', add_new_item: '', new_item_name: '', search_items: '', not_found: '' }
  });

  // Options Page editor state (#13) — mirrors the taxonomy editor.
  const [showOptForm, setShowOptForm] = useState(false);
  const [optSlug, setOptSlug] = useState('');
  const [editingOptSlug, setEditingOptSlug] = useState('');
  const [optView, setOptView] = useState('placement');
  const [optSettings, setOptSettings] = useState(null);
  const [pendingDeleteOpt, setPendingDeleteOpt] = useState(null);
  const optDefaultSettings = () => ({
    page_title: '', menu_title: '', menu_slug: '', parent_slug: '', position: '', icon_url: '',
    capability: 'edit_posts', redirect: false, autoload: false, description: ''
  });

  // Field Group form state
  const [showFieldGroupForm, setShowFieldGroupForm] = useState(false);
  const [groupTitle, setGroupTitle] = useState('');
  const [groupSource, setGroupSource] = useState('acf');
  const [groupTargets, setGroupTargets] = useState([]);

  // Field form state
  const [showFieldForm, setShowFieldForm] = useState(false);
  const [editingFieldName, setEditingFieldName] = useState('');
  const [fieldName, setFieldName] = useState('');
  const [fieldLabel, setFieldLabel] = useState('');
  const [fieldType, setFieldType] = useState('text');

  const [optionDraft, setOptionDraft] = useState({});
  const [optionSaveState, setOptionSaveState] = useState('');
  const [pendingDeleteCS, setPendingDeleteCS] = useState(null);
  const [pendingDeleteCptCS, setPendingDeleteCptCS] = useState(null);
  const [pendingDeleteFgCS, setPendingDeleteFgCS] = useState(null);
  const [pendingDeleteFieldCS, setPendingDeleteFieldCS] = useState(null);
  const loadItemsSeq = useRef(0);

  const loadMeta = useCallback(async () => {
    try {
      const res = await api.g('content-studio/meta');
      if (res?.code) throw new Error(res.message || 'Content Studio could not read WordPress data.');
      if (res && (res.cpts || res.field_groups)) {
        setMeta(res);
      }
    } catch (e) {
      flash(e?.message || 'Content Studio could not read WordPress data.');
    }
  }, [flash]);

  useEffect(() => {
    loadMeta();
  }, [loadMeta]);

  useEffect(() => {
    if (meta.acf_active) {
      setCptSource('acf');
      setGroupSource('acf');
    } else if (meta.jet_active) {
      setCptSource('jet');
      setGroupSource('jet');
    }
  }, [meta.acf_active, meta.jet_active]);

  const loadItems = useCallback(async () => {
    const seq = ++loadItemsSeq.current;
    setLoading(true);
    try {
      const navKey = String(activeNav || '');
      const isFieldGroup = navKey.startsWith('acf-') || navKey.startsWith('jet-');
      const isOptionPage = navKey.startsWith('option-');
      if (isOptionPage) {
        const page = (meta.option_pages || []).find(x => x.id === navKey);
        if (seq !== loadItemsSeq.current) return;
        const fields = page ? (page.fields || []) : [];
        setItems(fields);
        const draft = {};
        fields.forEach(field => { if (field && field.name) draft[field.name] = field.value == null ? '' : field.value; });
        setOptionDraft(draft);
      } else if (isFieldGroup) {
        const group = meta.field_groups.find(g => g.id === navKey);
        if (seq !== loadItemsSeq.current) return;
        if (group) {
          setItems(group.fields || []);
        } else {
          setItems([]);
        }
      } else {
        const res = await api.g('content-studio/posts?post_type=' + encodeURIComponent(navKey));
        if (seq !== loadItemsSeq.current) return;
        if (res?.code) throw new Error(res.message || 'Content Studio could not read WordPress content.');
        if (Array.isArray(res)) {
          setItems(res);
        }
      }
    } catch (e) {
      if (seq !== loadItemsSeq.current) return;
      flash(e?.message || 'Content Studio could not read WordPress content.');
    }
    if (seq === loadItemsSeq.current) setLoading(false);
  }, [activeNav, meta.field_groups, meta.option_pages, flash]);

  useEffect(() => {
    loadItems();
    setShowCreateForm(false);
    setShowFieldForm(false);
    setEditingFieldName('');
    setEditingCptName('');
    setNewPost(null);
    setOptionSaveState('');
  }, [activeNav, loadItems]);

  const currentItems = useMemo(() => {
    return items;
  }, [items]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    const navKey = String(activeNav || '');
    const isFieldGroup = navKey.startsWith('acf-') || navKey.startsWith('jet-');
    const isOptionPage = navKey.startsWith('option-');
    if (isOptionPage) {
      return currentItems.filter(x => !q || (x.label || '').toLowerCase().includes(q) || (x.name || '').toLowerCase().includes(q));
    }
    if (isFieldGroup) {
      return currentItems.filter(x => !q || (x.label || '').toLowerCase().includes(q) || (x.name || '').toLowerCase().includes(q));
    }
    const statusFiltered = currentItems.filter(x => {
      if (contentStatusFilter === 'active') return x.status !== 'trash';
      if (contentStatusFilter === 'all') return true;
      return x.status === contentStatusFilter;
    });
    return statusFiltered.filter(x => !q || (x.title?.rendered || '').toLowerCase().includes(q) || (x.slug || '').toLowerCase().includes(q));
  }, [activeNav, currentItems, search, contentStatusFilter]);

  const contentStatusCounts = useMemo(() => {
    const counts = { all: currentItems.length, publish: 0, draft: 0, pending: 0, private: 0, trash: 0 };
    currentItems.forEach(item => { const st = item.status || 'draft'; counts[st] = (counts[st] || 0) + 1; });
    counts.active = currentItems.filter(item => item.status !== 'trash').length;
    return counts;
  }, [currentItems]);

  const contentDashboardCards = useMemo(() => ([
    { key: 'active', label: 'Active', value: contentStatusCounts.active || 0 },
    { key: 'publish', label: 'Published', value: contentStatusCounts.publish || 0 },
    { key: 'draft', label: 'Drafts', value: contentStatusCounts.draft || 0 },
    { key: 'trash', label: 'Trash', value: contentStatusCounts.trash || 0 }
  ]), [contentStatusCounts]);

  const getAdminBase = () => {
    const pathParts = window.location.pathname.split('/');
    const adminIndex = pathParts.findIndex(x => x.includes('admin') || x === 'wp-admin');
    if (adminIndex !== -1) {
      return pathParts.slice(0, adminIndex + 1).join('/') + '/';
    }
    return '/wp-admin/';
  };

  const getEditUrl = (id) => {
    if (id && typeof id === 'object') {
      return id.bricks_link || id.edit_link || id.link || getEditUrl(id.id);
    }
    return getAdminBase() + 'post.php?post=' + id + '&action=edit';
  };

  const setContentStatus = value => {
    const next = value || 'active';
    setContentStatusFilter(next);
    persistUserPreference('ve_content_status_filter', next);
  };

  const selectContentNav = key => {
    setCategoryView(null);
    const nextKey = String(key || 'page');
    const sameNav = nextKey === activeNav;
    loadItemsSeq.current++;
    setItems([]);
    setLoading(true);
    setActiveNav(nextKey);
    try { localStorage.setItem('ve_cs_nav', nextKey); } catch (e) {}
    // When the target nav equals the current one, setActiveNav is a no-op so the
    // [activeNav] effect never re-fires — load directly or the list stays stuck on
    // "Loading…" (e.g. re-selecting Pages after an import).
    if (sameNav) loadItems();
    setSearch('');
    setShowCptForm(false);
    setShowFieldGroupForm(false);
    setShowCreateForm(false);
    setShowFieldForm(false);
    setEditingPost(null);
    setContentEditorFocus(false);
    setContentEditorPreview(false);
    setContentEditorRailTab('publish');
    setContentEditorSelection('');
    setEditingFieldName('');
    setEditingCptName('');
    setNewPost(null);
    setContentImportOpen(false);
  };

  const resetContentEditorWorkspace = saveState => {
    setShowCreateForm(false);
    setShowCptForm(false);
    setShowFieldGroupForm(false);
    setShowFieldForm(false);
    setContentEditorFocus(false);
    setContentEditorPreview(false);
    setContentEditorDevice('desktop');
    setContentEditorSaveState(saveState || 'saved');
    setContentOutlineCollapsed(false);
    setContentCollapsedRows({});
    setContentOutlineSearchOpen(false);
    setContentOutlineQuery('');
    setContentEditorRailTab('publish');
    setContentEditorSelection('');
    setContentSelectedBlock(null);
  };

  const startStudioCreate = e => {
    if(e){e.preventDefault();e.stopPropagation();}
    applyCsTheme(readContentStudioDefaultTheme());
    resetContentEditorWorkspace('dirty');
    const postTypeMeta=getPostTypeMeta(activeNav)||{};
    setNewPost(null);
    setEditingPost({
      id:0,__isNew:true,post_type:activeNav,
      supports_editor:postTypeMeta.supports_editor!==false,
      titleText:'',slug:'',slugManuallyEdited:false,status:'draft',content:'',excerpt:'',author:meta.current_user_id||0,terms:{},parent:0,menu_order:0,
      featured_media:0,comment_status:(CFG.newPostDefaults&&CFG.newPostDefaults.comment_status)||'open',ping_status:(CFG.newPostDefaults&&CFG.newPostDefaults.ping_status)||'open',template:'',custom_fields:{},seo_details:{},bricks_editable:false
    });
  };

  const startStudioEdit = (item, e) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    applyCsTheme(readContentStudioDefaultTheme());
    resetContentEditorWorkspace('saved');
    const postType = item.type || activeNav;
    const postTypeMeta = getPostTypeMeta(postType) || {};
    setEditingPost({
      id: item.id,
      post_type: postType,
      supports_editor: item.supports_editor !== undefined ? !!item.supports_editor : postTypeMeta.supports_editor !== false,
      titleText: item.title?.rendered || '',
      slug: item.slug || '',
      slugManuallyEdited: false,
      status: item.status || 'draft',
      content: item.content?.raw || '',
      excerpt: item.excerpt?.raw || '',
      author: parseInt(item.author || 0, 10) || 0,
      terms: item.terms && typeof item.terms === 'object' ? item.terms : {},
      parent: item.parent || 0,
      menu_order: item.menu_order || 0,
      featured_media: item.featured_media || 0,
      featured_media_url: item.featured_media_url || '',
      comment_status: item.comment_status || 'closed',
      ping_status: item.ping_status || 'closed',
      template: item.template || '',
      custom_fields: item.custom_fields || {},
      edit_link: item.edit_link,
      bricks_link: item.bricks_link,
      bricks_editable: !!item.bricks_editable,
      seo_details: item.seo_details || {},
      link: item.link
    });
  };

  const saveContentEdit = async (e, statusOverride) => {
    if (e) e.preventDefault();
    if (!editingPost) return;
    if (!String(editingPost.titleText || '').trim()) {
      setContentEditorSaveState('error');
      setContentEditorRailTab('publish');
      setContentEditorSelection('title');
      setTimeout(()=>document.querySelector('.ve-content-title-fields input')?.focus(),0);
      flash('Post title is required.');
      return;
    }
    const creating=!!editingPost.__isNew;
    setLoading(true);
    setContentEditorSaveState('saving');
    try {
      const payload={
        title: editingPost.titleText,
        slug: editingPost.slug,
        status: statusOverride || editingPost.status,
        content: editingPost.content || '',
        excerpt: editingPost.excerpt || '',
        author: parseInt(editingPost.author || 0, 10) || 0,
        terms: editingPost.terms || {},
        parent: parseInt(editingPost.parent || 0, 10) || 0,
        menu_order: parseInt(editingPost.menu_order || 0, 10) || 0,
        featured_media: parseInt(editingPost.featured_media || 0, 10) || 0,
        comment_status: editingPost.comment_status === 'open',
        ping_status: editingPost.ping_status === 'open',
        template: editingPost.template || '',
        custom_fields: editingPost.custom_fields || {},
        seo_details: {
          ...(editingPost.seo_details || {}),
          ...(rankMathActive(editingPost) ? {} : { score: liveSeoScore(editingPost) })
        }
      };
      let res = await api.f('variable-engine/v1/content-studio/posts' + (creating?'':'/' + editingPost.id), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(creating?{...payload,post_type:editingPost.post_type||activeNav}:payload)
      });
      if(creating&&res?.id){
        const completed=await api.f('variable-engine/v1/content-studio/posts/'+res.id,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(payload)});
        if(completed?.id)res=completed;
      }
      if (res && res.id) {
        const savedResponse=res;
        setItems(prev => creating?[savedResponse,...prev.filter(x=>x.id!==savedResponse.id)]:prev.map(x => x.id === savedResponse.id ? savedResponse : x));
        setEditingPost(current => current ? ({
          ...current,
          id:savedResponse.id,
          __isNew:false,
          titleText: savedResponse.title?.rendered ?? current.titleText,
          slug: savedResponse.slug ?? current.slug,
          status: savedResponse.status ?? current.status,
          content: savedResponse.content?.raw ?? current.content,
          excerpt: savedResponse.excerpt?.raw ?? current.excerpt,
          author: savedResponse.author ?? current.author,
          terms: savedResponse.terms ?? current.terms,
          featured_media: savedResponse.featured_media ?? current.featured_media,
          featured_media_url: savedResponse.featured_media_url ?? current.featured_media_url,
          custom_fields: savedResponse.custom_fields ?? current.custom_fields,
          seo_details: savedResponse.seo_details,
          link: savedResponse.link || current.link,
          edit_link: savedResponse.edit_link || current.edit_link,
          bricks_link: savedResponse.bricks_link || current.bricks_link,
          bricks_editable: savedResponse.bricks_editable !== undefined ? !!savedResponse.bricks_editable : current.bricks_editable
        }) : current);
        setContentEditorSaveState('saved');
        flash(creating?'Content created.':'Content updated.');
        await loadMeta();
      } else {
        setContentEditorSaveState('error');
        flash(res?.message || (creating?'Creation failed.':'Update failed.'));
      }
    } catch (err) {
      setContentEditorSaveState('error');
      flash(creating?'Creation failed.':'Update failed.');
    }
    setLoading(false);
  };

  const handleToggleStatus = async (item) => {
    const nextStatus = item.status === 'publish' ? 'draft' : 'publish';
    setItems(prev => prev.map(x => x.id === item.id ? { ...x, status: nextStatus } : x));
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts/' + item.id, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus })
      });
      if (res && res.code) {
        flash('Status update failed');
        loadItems();
      } else {
        flash('Status updated to ' + nextStatus);
      }
    } catch (e) {
      flash('Status update failed');
      loadItems();
    }
  };

  const handleDelete = (item) => {
    setPendingDeleteCS(item);
  };

  const confirmDeleteCS = async () => {
    const item = pendingDeleteCS;
    if (!item) return;
    setPendingDeleteCS(null);
    setLoading(true);
    try {
      const force = item.__trashOnly ? 'false' : 'true';
      const res = await api.f('variable-engine/v1/content-studio/posts/' + item.id + '?force=' + force, { method: 'DELETE' });
      if (res && res.id) {
        setItems(prev => prev.filter(x => x.id !== item.id));
        flash(item.__trashOnly ? 'Moved to Trash.' : 'Deleted permanently.');
        loadMeta();
      } else {
        flash('Delete failed');
      }
    } catch (e) {
      flash('Delete failed');
    }
    setLoading(false);
  };

  const handleTrashContent = (item) => {
    setPendingDeleteCS({ ...item, __trashOnly: item.status !== 'trash' });
  };

  const restoreContentItem = async (item) => {
    if (!item) return;
    setItems(prev => prev.map(x => x.id === item.id ? { ...x, status: 'draft' } : x));
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts/' + item.id, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'draft' })
      });
      if (res && res.id) {
        flash('Content restored to Draft.');
        loadItems();
        loadMeta();
      } else {
        flash(res?.message || 'Restore failed.');
        loadItems();
      }
    } catch (e) {
      flash('Restore failed.');
      loadItems();
    }
  };

  const duplicateContentItem = async (item) => {
    if (!item) return;
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts/' + item.id + '/duplicate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'draft' })
      });
      if (res && res.id) {
        flash('Duplicated as draft.');
        setItems(prev => [res, ...prev]);
        loadMeta();
      } else {
        flash(res?.message || 'Duplicate failed.');
      }
    } catch (e) {
      flash('Duplicate failed.');
    }
    setLoading(false);
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    const draft = createDraft || {};
    if (!String(draft.title || '').trim()) return;
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          post_type: activeNav,
          title: draft.title,
          slug: draft.slug,
          status: draft.status || 'draft',
          content: draft.content || '',
          excerpt: draft.excerpt || ''
        })
      });
      if (res && res.id) {
        setNewPost(res);
        setCreateDraft({ title: '', slug: '', slugManuallyEdited: false, status: 'draft', content: '', excerpt: '' });
        flash('Content created.');
        loadItems();
        loadMeta();
      } else {
        flash(res?.message || 'Creation failed');
      }
    } catch (err) {
      flash('Creation failed');
    }
    setLoading(false);
  };

  const handleCopyLink = (url) => {
    if (url === '#') {
      flash('Cannot copy link');
      return;
    }
    navigator.clipboard.writeText(url);
    flash('Copied Link');
  };

  const startNewCpt = () => {
    setEditingCptName('');
    setCptName('');
    setCptSingular('');
    setCptPlural('');
    setCptSource(meta.acf_active ? 'acf' : 'jet');
    setCptSettings(cptDefaultSettings());
    setCptView('general');
    setShowCptForm(true);
    setShowTaxForm(false);
    setShowOptForm(false);
    setShowFieldGroupForm(false);
    setShowCreateForm(false);
    setShowFieldForm(false);
    setEditingPost(null);
  };

  const startEditCpt = (e, cpt) => {
    if (e) e.stopPropagation();
    if (!cpt || cpt.source === 'wp') return;
    setEditingCptName(cpt.name || '');
    setCptName(cpt.name || '');
    setCptSingular(cpt.singular || cpt.label || cpt.name || '');
    setCptPlural(cpt.label || cpt.singular || cpt.name || '');
    setCptSource(cpt.source || (meta.acf_active ? 'acf' : 'jet'));
    const base = cptDefaultSettings();
    setCptSettings(cpt.settings
      ? { ...base, ...cpt.settings, labels: { ...base.labels, ...(cpt.settings.labels || {}) } }
      : base);
    setCptView('general');
    setShowCptForm(true);
    setShowTaxForm(false);
    setShowOptForm(false);
    setShowFieldGroupForm(false);
    setShowCreateForm(false);
    setShowFieldForm(false);
    setEditingPost(null);
  };

  const handleCreateCpt = async (e) => {
    e.preventDefault();
    if (!cptName.trim() || !cptSingular.trim() || !cptPlural.trim()) {
      setCptView('general');
      flash('Add the plural, singular, and key on the General tab first.');
      return;
    }
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/cpts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: cptName, singular: cptSingular, plural: cptPlural, source: cptSource, settings: cptSource === 'acf' ? cptSettings : undefined })
      });
      if (res && res.success) {
        flash(editingCptName ? 'CPT updated successfully.' : 'CPT registered successfully.');
        setCptName('');
        setEditingCptName('');
        setCptSingular('');
        setCptPlural('');
        setCptSettings(null);
        setShowCptForm(false);
        await loadMeta();
      } else {
        flash('CPT registration failed');
      }
    } catch (e) {
      flash('CPT registration failed');
    }
    setLoading(false);
  };

  const handleDeleteCpt = (e, name) => {
    e.stopPropagation();
    setPendingDeleteCptCS(name);
  };

  const confirmDeleteCptCS = async () => {
    const name = pendingDeleteCptCS;
    if (!name) return;
    setPendingDeleteCptCS(null);
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/cpts/' + name, { method: 'DELETE' });
      if (res && res.success) {
        flash(`CPT "${name}" deleted.`);
        if (activeNav === name) setActiveNav('page');
        await loadMeta();
      } else {
        flash('Failed to delete CPT.');
      }
    } catch (e) {
      flash('Failed to delete CPT.');
    }
    setLoading(false);
  };

  /* ===== Post Types editor (#20) — full ACF post-type registration settings,
     mirroring ACF's own screens, reusing the field-group Settings chrome. ===== */
  const renderCptEditor = () => {
    const s = cptSettings || cptDefaultSettings();
    const set = patch => setCptSettings(prev => ({ ...(prev || cptDefaultSettings()), ...patch }));
    const setLabel = (k, v) => setCptSettings(prev => { const b = prev || cptDefaultSettings(); return { ...b, labels: { ...(b.labels || {}), [k]: v } }; });
    const field = (label, key, place, help, mono) => h('div', { class: 've-cpt-field' },
      h('label', { class: 've-fg-k' }, label),
      h('input', { class: 've-studio-input' + (mono ? ' ve-mono' : ''), value: s[key] == null ? '' : s[key], placeholder: place || '', onInput: e => set({ [key]: e.target.value }) }),
      help ? h('div', { class: 've-fg-help' }, help) : null);
    const lfield = (label, key, place) => h('div', { class: 've-cpt-field' },
      h('label', { class: 've-fg-k' }, label),
      h('input', { class: 've-studio-input', value: (s.labels && s.labels[key]) || '', placeholder: place || '', onInput: e => setLabel(key, e.target.value) }));
    const toggle = (label, key, help) => h('div', { class: 've-fg-tg' },
      h('div', null, h('div', { class: 've-fg-tl' }, label), help ? h('div', { class: 've-fg-ts' }, help) : null),
      h(ToggleControl, { checked: !!s[key], onChange: v => set({ [key]: v }) }));
    const choices = (label, key, options, help) => h('div', { class: 've-cpt-choices' },
      h('label', { class: 've-fg-k' }, label),
      help ? h('div', { class: 've-fg-help', style: 'margin:-2px 0 8px' }, help) : null,
      h('div', { class: 've-fg-checks' }, options.map(o => {
        const on = (s[key] || []).indexOf(o[0]) !== -1;
        return h('button', { type: 'button', key: o[0], role: 'switch', 'aria-checked': on ? 'true' : 'false', class: 've-fg-check' + (on ? ' on' : ''),
          onClick: () => { const list = (s[key] || []).slice(); const i = list.indexOf(o[0]); if (i === -1) list.push(o[0]); else list.splice(i, 1); set({ [key]: list }); } },
          h('span', { class: 've-fg-check-lbl' }, o[1]), h('span', { class: 've-fg-box', 'aria-hidden': 'true' }));
      })));
    const grid = (...kids) => h('div', { class: 've-cpt-grid' }, kids.filter(Boolean));
    const card = (title, sub, ...kids) => h('div', { class: 've-cpt-card' },
      h('h3', { class: 've-cpt-h' }, title), sub ? h('p', { class: 've-cpt-sub' }, sub) : null, ...kids.filter(Boolean));
    const supportOptions = [['title', 'Title'], ['editor', 'Content editor'], ['thumbnail', 'Featured image'], ['excerpt', 'Excerpt'], ['custom-fields', 'Custom fields'], ['revisions', 'Revisions'], ['page-attributes', 'Page attributes']];
    const taxOptions = (() => {
      const map = { category: 'Categories', post_tag: 'Tags' };
      const t = meta.taxonomies || {};
      Object.keys(t).forEach(pt => (Array.isArray(t[pt]) ? t[pt] : []).forEach(tx => {
        const n = typeof tx === 'string' ? tx : (tx && tx.name);
        const l = typeof tx === 'string' ? tx : (tx && (tx.label || tx.name));
        if (n) map[n] = l || n;
      }));
      (s.taxonomies || []).forEach(n => { if (!map[n]) map[n] = n; });
      return Object.keys(map).map(k => [k, map[k]]);
    })();
    const nameField = (label, value, onInput, opts) => h('div', { class: 've-cpt-field' },
      h('label', { class: 've-fg-k' }, label),
      h('input', { class: 've-studio-input' + ((opts && opts.mono) ? ' ve-mono' : ''), required: true, readOnly: !!(opts && opts.readOnly), value: value, placeholder: (opts && opts.place) || '', onInput }),
      (opts && opts.help) ? h('div', { class: 've-fg-help' }, opts.help) : null);
    const tabs = [['general', 'General'], ['labels', 'Labels'], ['visibility', 'Visibility'], ['urls', 'Permalinks'], ['permissions', 'Capabilities'], ['rest', 'REST API']];
    const view = cptView || 'general';
    const isJet = cptSource === 'jet';
    return h('form', { onSubmit: handleCreateCpt, class: 've-cpt-editor' },
      h('div', { class: 've-fg-views' }, tabs.map(t => h('button', { type: 'button', key: t[0], class: view === t[0] ? 'on' : '', onClick: () => setCptView(t[0]) }, t[1]))),
      h('div', { class: 've-cpt-body' },
        isJet && h('div', { class: 've-fg-help', style: 'margin-bottom:12px' }, 'JetEngine post types store labels only here; the settings tabs apply to ACF post types.'),
        view === 'general' && card('General registration', 'Core identity, visibility, editor features, and taxonomies.',
          grid(
            nameField('Plural label', cptPlural, e => setCptPlural(e.target.value), { place: 'e.g. Portfolios' }),
            nameField('Singular label', cptSingular, e => setCptSingular(e.target.value), { place: 'e.g. Portfolio Item' }),
            nameField('Post type key (slug)', cptName, e => setCptName(e.target.value.toLowerCase().replace(/[^a-z0-9_\-]/g, '')), { mono: true, readOnly: !!editingCptName, place: 'e.g. portfolio', help: 'Lowercase letters, underscores, and dashes. Max 20 characters.' }),
            field('Menu icon', 'menu_icon', 'dashicons-admin-post', null, true)
          ),
          h('div', { class: 've-cpt-field ve-cpt-field-full' },
            h('label', { class: 've-fg-k' }, 'Description'),
            h('textarea', { class: 've-studio-input', rows: 2, value: s.description || '', placeholder: 'A descriptive summary of the post type.', onInput: e => set({ description: e.target.value }) })),
          !editingCptName && (meta.acf_active && meta.jet_active) && h('div', { class: 've-cpt-field ve-cpt-field-full' },
            h('label', { class: 've-fg-k' }, 'Provider'),
            h(SelectMenu, { className: 've-studio-select', value: cptSource, onChange: setCptSource, options: [
              meta.acf_active && { value: 'acf', label: 'Advanced Custom Fields (ACF)' },
              meta.jet_active && { value: 'jet', label: 'JetEngine' }
            ].filter(Boolean) })),
          toggle('Public', 'public', 'Visible on the frontend and in the admin dashboard.'),
          toggle('Hierarchical', 'hierarchical', 'Allow parent and child records (page-style).'),
          choices('Editor supports', 'supports', supportOptions, 'Enable WordPress editing features for this post type.'),
          choices('Taxonomy assignments', 'taxonomies', taxOptions, 'Attach existing taxonomies without recreating them.')
        ),
        view === 'labels' && card('Generated labels', 'ACF generates the full WordPress label set from the plural and singular labels. Override only the wording that needs to differ.',
          grid(
            lfield('Menu name', 'menu_name', cptPlural),
            lfield('All items', 'all_items', 'All ' + (cptPlural || '')),
            lfield('Edit item', 'edit_item', 'Edit ' + (cptSingular || '')),
            lfield('View item', 'view_item', 'View ' + (cptSingular || '')),
            lfield('Add new item', 'add_new_item', 'Add New ' + (cptSingular || '')),
            lfield('New item', 'new_item', 'New ' + (cptSingular || '')),
            lfield('Search items', 'search_items', 'Search ' + (cptPlural || '')),
            lfield('No items found', 'not_found', 'No ' + (cptPlural || '').toLowerCase() + ' found')
          ),
          h('div', { class: 've-fg-help', style: 'margin-top:8px' }, 'Blank fields fall back to the WordPress defaults derived from the plural and singular labels.')
        ),
        view === 'visibility' && card('Admin & frontend visibility', 'Matches ACF’s complete visibility and menu-placement controls.',
          toggle('Publicly queryable', 'publicly_queryable', 'Allow frontend query-string and public URL access.'),
          toggle('Show in UI', 'show_ui', 'Allow items to be edited in the admin dashboard.'),
          toggle('Show in admin menu', 'show_in_menu', 'Add editor navigation to the WordPress sidebar.'),
          grid(
            field('Menu position', 'menu_position', 'e.g. 20', 'Where the menu item sits in the admin sidebar.', true),
            field('Menu icon', 'menu_icon', 'dashicons-admin-post', 'Dashicon, Media Library item, or URL.', true)
          ),
          toggle('Show in admin bar', 'show_in_admin_bar', 'Expose the type in the New admin-bar menu.'),
          toggle('Appearance Menus support', 'show_in_nav_menus', 'Allow records in Appearance → Menus.'),
          toggle('Exclude from search', 'exclude_from_search', 'Keep records out of search results and taxonomy archives.')
        ),
        view === 'urls' && card('Permalinks, archives & queries', 'Control WordPress rewrite, archive, and query behavior.',
          grid(
            field('Rewrite slug', 'rewrite_slug', cptName || 'post type key', 'Leave blank to use the post type key.', true),
            field('Query variable', 'query_var', cptName, null, true)
          ),
          toggle('Front URL prefix', 'rewrite_front', 'Include the site permalink front base.'),
          toggle('Feed URL', 'rewrite_feeds', 'Expose an RSS feed for this post type.'),
          toggle('Pagination', 'rewrite_pages', 'Support paginated archive URLs.'),
          toggle('Archive', 'has_archive', 'Create an item archive route.')
        ),
        view === 'permissions' && card('Capabilities & export', 'Keep WordPress capability inheritance explicit.',
          grid(
            field('Capability type', 'capability_type', 'post', 'Usually post or page.', true)
          ),
          toggle('Can export', 'can_export', 'Allow export through Tools → Export.'),
          toggle('Delete with user', 'delete_with_user', 'Delete authored records when a user is deleted.')
        ),
        view === 'rest' && card('REST API', 'Expose this post type to the block editor and API consumers.',
          toggle('Show in REST API', 'show_in_rest', 'Required to use the block editor.'),
          grid(
            field('Base URL', 'rest_base', cptName, null, true),
            field('Namespace route', 'rest_namespace', 'wp/v2', null, true)
          ),
          field('Controller class', 'rest_controller_class', 'WP_REST_Posts_Controller', 'Optional custom controller class.', true)
        )
      ),
      h('div', { class: 've-cpt-foot' },
        h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:600' }, loading ? 'Saving...' : (editingCptName ? 'Save post type' : 'Register post type')),
        h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => { setShowCptForm(false); setEditingCptName(''); setCptName(''); setCptSingular(''); setCptPlural(''); setCptSettings(null); } }, 'Cancel')
      )
    );
  };

  /* ===== Taxonomies editor (#8) — full ACF taxonomy registration, mirroring the
     post-type editor and reusing the field-group Settings chrome. ===== */
  const [pendingDeleteTax, setPendingDeleteTax] = useState(null);
  const startNewTax = () => {
    setEditingTaxName(''); setTaxName(''); setTaxSingular(''); setTaxPlural('');
    setTaxSettings(taxDefaultSettings()); setTaxView('general');
    setShowTaxForm(true); setShowCptForm(false); setShowOptForm(false); setShowFieldGroupForm(false); setShowCreateForm(false); setShowFieldForm(false); setEditingPost(null);
  };
  const startEditTax = (e, tax) => {
    if (e) e.stopPropagation();
    if (!tax) return;
    setEditingTaxName(tax.name || ''); setTaxName(tax.name || '');
    setTaxSingular(tax.singular || tax.label || tax.name || '');
    setTaxPlural(tax.label || tax.singular || tax.name || '');
    const base = taxDefaultSettings();
    setTaxSettings(tax.settings ? { ...base, ...tax.settings, labels: { ...base.labels, ...(tax.settings.labels || {}) } } : base);
    setTaxView('general');
    setShowTaxForm(true); setShowCptForm(false); setShowOptForm(false); setShowFieldGroupForm(false); setShowCreateForm(false); setShowFieldForm(false); setEditingPost(null);
  };
  const handleCreateTax = async (e) => {
    e.preventDefault();
    if (!taxName.trim() || !taxSingular.trim() || !taxPlural.trim()) { setTaxView('general'); flash('Add the plural, singular, and key on the General tab first.'); return; }
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/taxonomies', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ name: taxName, singular: taxSingular, plural: taxPlural, settings: taxSettings }) });
      if (res && res.success) {
        flash(editingTaxName ? 'Taxonomy updated.' : 'Taxonomy registered.');
        setTaxName(''); setEditingTaxName(''); setTaxSingular(''); setTaxPlural(''); setTaxSettings(null); setShowTaxForm(false);
        await loadMeta();
      } else { flash((res && res.message) || 'Taxonomy save failed.'); }
    } catch (err) { flash('Taxonomy save failed.'); }
    setLoading(false);
  };
  const handleDeleteTax = (e, name) => { if (e) e.stopPropagation(); setPendingDeleteTax(name); };
  const confirmDeleteTax = async () => {
    const name = pendingDeleteTax; if (!name) return; setPendingDeleteTax(null); setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/taxonomies/' + name, { method: 'DELETE' });
      if (res && res.success) { flash('Taxonomy "' + name + '" deleted.'); await loadMeta(); } else { flash((res && res.message) || 'Failed to delete taxonomy.'); }
    } catch (err) { flash('Failed to delete taxonomy.'); }
    setLoading(false);
  };

  const renderTaxEditor = () => {
    const s = taxSettings || taxDefaultSettings();
    const set = patch => setTaxSettings(prev => ({ ...(prev || taxDefaultSettings()), ...patch }));
    const setLabel = (k, v) => setTaxSettings(prev => { const b = prev || taxDefaultSettings(); return { ...b, labels: { ...(b.labels || {}), [k]: v } }; });
    const field = (label, key, place, help, mono) => h('div', { class: 've-cpt-field' },
      h('label', { class: 've-fg-k' }, label),
      h('input', { class: 've-studio-input' + (mono ? ' ve-mono' : ''), value: s[key] == null ? '' : s[key], placeholder: place || '', onInput: e => set({ [key]: e.target.value }) }),
      help ? h('div', { class: 've-fg-help' }, help) : null);
    const lfield = (label, key, place) => h('div', { class: 've-cpt-field' },
      h('label', { class: 've-fg-k' }, label),
      h('input', { class: 've-studio-input', value: (s.labels && s.labels[key]) || '', placeholder: place || '', onInput: e => setLabel(key, e.target.value) }));
    const toggle = (label, key, help) => h('div', { class: 've-fg-tg' },
      h('div', null, h('div', { class: 've-fg-tl' }, label), help ? h('div', { class: 've-fg-ts' }, help) : null),
      h(ToggleControl, { checked: !!s[key], onChange: v => set({ [key]: v }) }));
    const choices = (label, key, options, help) => h('div', { class: 've-cpt-choices' },
      h('label', { class: 've-fg-k' }, label),
      help ? h('div', { class: 've-fg-help', style: 'margin:-2px 0 8px' }, help) : null,
      h('div', { class: 've-fg-checks' }, options.map(o => {
        const on = (s[key] || []).indexOf(o[0]) !== -1;
        return h('button', { type: 'button', key: o[0], role: 'switch', 'aria-checked': on ? 'true' : 'false', class: 've-fg-check' + (on ? ' on' : ''),
          onClick: () => { const list = (s[key] || []).slice(); const i = list.indexOf(o[0]); if (i === -1) list.push(o[0]); else list.splice(i, 1); set({ [key]: list }); } },
          h('span', { class: 've-fg-check-lbl' }, o[1]), h('span', { class: 've-fg-box', 'aria-hidden': 'true' }));
      })));
    const grid = (...kids) => h('div', { class: 've-cpt-grid' }, kids.filter(Boolean));
    const card = (title, sub, ...kids) => h('div', { class: 've-cpt-card' },
      h('h3', { class: 've-cpt-h' }, title), sub ? h('p', { class: 've-cpt-sub' }, sub) : null, ...kids.filter(Boolean));
    const nameField = (label, value, onInput, opts) => h('div', { class: 've-cpt-field' },
      h('label', { class: 've-fg-k' }, label),
      h('input', { class: 've-studio-input' + ((opts && opts.mono) ? ' ve-mono' : ''), required: true, readOnly: !!(opts && opts.readOnly), value: value, placeholder: (opts && opts.place) || '', onInput }),
      (opts && opts.help) ? h('div', { class: 've-fg-help' }, opts.help) : null);
    const postTypeOptions = [...defaultCpts, ...contentCpts].map(pt => [pt.name, (pt.label || pt.name) + ' (' + pt.name + ')']);
    const tabs = [['general', 'General'], ['labels', 'Labels'], ['visibility', 'Visibility'], ['urls', 'Permalinks'], ['rest', 'REST API']];
    const view = taxView || 'general';
    return h('form', { onSubmit: handleCreateTax, class: 've-cpt-editor' },
      h('div', { class: 've-fg-views' }, tabs.map(t => h('button', { type: 'button', key: t[0], class: view === t[0] ? 'on' : '', onClick: () => setTaxView(t[0]) }, t[1]))),
      h('div', { class: 've-cpt-body' },
        view === 'general' && card('General registration', 'Core identity, visibility, and the post types this taxonomy applies to.',
          grid(
            nameField('Plural label', taxPlural, e => setTaxPlural(e.target.value), { place: 'e.g. Genres' }),
            nameField('Singular label', taxSingular, e => setTaxSingular(e.target.value), { place: 'e.g. Genre' }),
            nameField('Taxonomy key (slug)', taxName, e => setTaxName(e.target.value.toLowerCase().replace(/[^a-z0-9_\-]/g, '')), { mono: true, readOnly: !!editingTaxName, place: 'e.g. genre', help: 'Lowercase letters, underscores, and dashes. Max 32 characters.' })
          ),
          h('div', { class: 've-cpt-field ve-cpt-field-full' },
            h('label', { class: 've-fg-k' }, 'Description'),
            h('textarea', { class: 've-studio-input', rows: 2, value: s.description || '', placeholder: 'Shown to editors and API consumers.', onInput: e => set({ description: e.target.value }) })),
          toggle('Public', 'public', 'Visible on the frontend and in the admin dashboard.'),
          toggle('Hierarchical', 'hierarchical', 'Category-style parent/child terms (off = tag-style).'),
          choices('Assigned post types', 'object_type', postTypeOptions, 'Attach this taxonomy to existing post types without recreating them.')
        ),
        view === 'labels' && card('Generated labels', 'ACF generates the WordPress label set from the plural and singular labels. Override only what needs to differ.',
          grid(
            lfield('Menu name', 'menu_name', taxPlural),
            lfield('All items', 'all_items', 'All ' + (taxPlural || '')),
            lfield('Edit item', 'edit_item', 'Edit ' + (taxSingular || '')),
            lfield('View item', 'view_item', 'View ' + (taxSingular || '')),
            lfield('Add new item', 'add_new_item', 'Add New ' + (taxSingular || '')),
            lfield('New item name', 'new_item_name', 'New ' + (taxSingular || '') + ' Name'),
            lfield('Search items', 'search_items', 'Search ' + (taxPlural || '')),
            lfield('No items found', 'not_found', 'No ' + (taxPlural || '').toLowerCase() + ' found')
          )
        ),
        view === 'visibility' && card('Admin & frontend visibility', 'Control term editing, menus, and admin columns.',
          toggle('Publicly queryable', 'publicly_queryable', 'Allow public taxonomy queries and URLs.'),
          toggle('Show in UI', 'show_ui', 'Expose term management screens.'),
          toggle('Show in admin menu', 'show_in_menu', 'Add taxonomy navigation to the WordPress sidebar.'),
          toggle('Appearance Menus support', 'show_in_nav_menus', 'Allow terms in Appearance → Menus.'),
          toggle('Show admin column', 'show_admin_column', 'Add a column for this taxonomy on its post type list tables.')
        ),
        view === 'urls' && card('Permalinks & queries', 'Control term rewrite and query behavior.',
          grid(
            field('Rewrite slug', 'rewrite_slug', taxName || 'taxonomy key', 'Leave blank to use the taxonomy key.', true),
            field('Query variable', 'query_var', taxName, null, true)
          ),
          toggle('Front URL prefix', 'rewrite_front', 'Include the site permalink front base.')
        ),
        view === 'rest' && card('REST API', 'Expose terms to the block editor and API consumers.',
          toggle('Show in REST API', 'show_in_rest', 'Required for REST-backed editing.'),
          grid(
            field('Base URL', 'rest_base', taxName, null, true),
            field('Namespace route', 'rest_namespace', 'wp/v2', null, true)
          )
        )
      ),
      h('div', { class: 've-cpt-foot' },
        h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:600' }, loading ? 'Saving...' : (editingTaxName ? 'Save taxonomy' : 'Register taxonomy')),
        h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => { setShowTaxForm(false); setEditingTaxName(''); setTaxName(''); setTaxSingular(''); setTaxPlural(''); setTaxSettings(null); } }, 'Cancel')
      )
    );
  };

  /* ===== Category list (#8) — clicking a section header lists that category's items,
     mirroring the CRUD reference: real columns, inline toggles, search, and actions. ===== */
  const catSaveModel = async (kind, item, patch) => {
    const st = { ...(item.settings || {}), ...patch };
    const endpoint = kind === 'tax' ? 'content-studio/taxonomies' : 'content-studio/cpts';
    try {
      const res = await api.f('variable-engine/v1/' + endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: item.name, singular: item.singular || item.label || item.name, plural: item.label || item.singular || item.name, settings: st }) });
      if (res && res.success) await loadMeta(); else flash((res && res.message) || 'Could not update.');
    } catch (e) { flash('Could not update.'); }
  };
  const catDuplicateModel = async (kind, item) => {
    const cap = kind === 'tax' ? 32 : 20;
    const newName = (item.name + '_copy').toLowerCase().replace(/[^a-z0-9_\-]/g, '').slice(0, cap);
    const endpoint = kind === 'tax' ? 'content-studio/taxonomies' : 'content-studio/cpts';
    try {
      const res = await api.f('variable-engine/v1/' + endpoint, { method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: newName, singular: (item.singular || item.label || item.name) + ' copy', plural: (item.label || item.name) + ' copy', settings: { ...(item.settings || {}) } }) });
      if (res && res.success) { flash('Duplicated.'); await loadMeta(); } else flash((res && res.message) || 'Could not duplicate.');
    } catch (e) { flash('Could not duplicate.'); }
  };
  const renderCategoryList = () => {
    const spec = {
      default: { title: 'Default Content Types', noun: 'content types', add: null },
      custom: { title: 'Custom Post Types', noun: 'post types', add: (meta.acf_active || meta.jet_active) ? startNewCpt : null },
      taxonomies: { title: 'Taxonomies', noun: 'taxonomies', add: meta.acf_active ? startNewTax : null },
      options: { title: 'Options Pages', noun: 'options pages', add: meta.acf_active ? startNewOpt : null },
      fields: { title: 'Custom Field Groups', noun: 'field groups', add: (meta.acf_active || meta.jet_active) ? (() => { setCategoryView(null); setShowFieldGroupForm(true); setShowCptForm(false); setShowTaxForm(false); }) : null }
    }[categoryView] || { title: 'Items', noun: 'items', add: null };
    const q = catSearch.trim().toLowerCase();
    const matches = txt => !q || String(txt || '').toLowerCase().indexOf(q) !== -1;
    const pill = on => h('span', { class: 've-cat-pill' + (on ? ' on' : '') }, on ? 'Yes' : 'No');
    const swt = (on, onClick) => h('button', { type: 'button', class: 've-cat-switch' + (on ? ' on' : ''), 'aria-pressed': on ? 'true' : 'false', onClick: e => { e.stopPropagation(); onClick(); } });
    const iact = (title, icon, onClick, danger) => h('button', { type: 'button', class: 've-cat-act' + (danger ? ' danger' : ''), title, onClick: e => { e.stopPropagation(); onClick(); } }, ph(icon));
    const nameCell = (icon, label) => h('td', null, h('div', { class: 've-cat-name' }, ph(icon), h('span', null, label)));
    const code = t => h('td', null, h('code', { class: 've-cat-code' }, t));
    let header = [];
    let count = 0;
    let rows = [];
    if (categoryView === 'default') {
      header = ['Label', 'Singular', 'Slug', 'Hierarchical', 'Public', 'Archive', 'Front prefix', 'Actions'];
      const data = ['page', 'post'].map(k => (meta.cpts || []).find(pt => pt.name === k) || { name: k, label: formatNavLabel(k), singular: '', settings: {} }).filter(c => matches(c.label) || matches(c.name));
      count = data.length;
      rows = data.map(cpt => { const st = cpt.settings || {}; return h('tr', { key: cpt.name, class: 've-cat-row', onClick: () => selectContentNav(cpt.name) },
        nameCell(cpt.name === 'page' ? 'file' : 'article', cpt.label), h('td', null, cpt.singular || ''), code(cpt.name),
        h('td', null, pill(!!st.hierarchical)), h('td', null, pill(st.public !== false)), h('td', null, pill(!!st.has_archive)), h('td', null, pill(st.rewrite_front !== false)),
        h('td', { style: 'text-align:right' }, h('span', { class: 've-cat-wp' }, 'WordPress'))); });
    } else if (categoryView === 'custom') {
      header = ['Label', 'Singular', 'Slug', 'Hierarchical', 'Public', 'Archive', 'Front prefix', 'Actions'];
      const data = contentCpts.filter(c => matches(c.label) || matches(c.name));
      count = data.length;
      rows = data.map(cpt => { const st = cpt.settings || {}; const canEdit = cpt.source !== 'wp'; const acf = cpt.source === 'acf'; return h('tr', { key: cpt.name, class: 've-cat-row', onClick: () => canEdit ? startEditCpt(null, cpt) : selectContentNav(cpt.name) },
        nameCell('circles-three-plus', cpt.label), h('td', null, cpt.singular || ''), code(cpt.name),
        h('td', null, acf ? swt(!!st.hierarchical, () => catSaveModel('cpt', cpt, { hierarchical: !st.hierarchical })) : pill(!!st.hierarchical)),
        h('td', null, acf ? swt(st.public !== false, () => catSaveModel('cpt', cpt, { public: !(st.public !== false) })) : pill(st.public !== false)),
        h('td', null, acf ? swt(!!st.has_archive, () => catSaveModel('cpt', cpt, { has_archive: !st.has_archive })) : pill(!!st.has_archive)),
        h('td', null, acf ? swt(st.rewrite_front !== false, () => catSaveModel('cpt', cpt, { rewrite_front: !(st.rewrite_front !== false) })) : pill(st.rewrite_front !== false)),
        h('td', { style: 'text-align:right' }, h('div', { class: 've-cat-acts' }, canEdit && iact('Edit', 'pencil-simple', () => startEditCpt(null, cpt)), acf && iact('Duplicate', 'copy', () => catDuplicateModel('cpt', cpt)), canEdit && iact('Delete', 'trash', () => setPendingDeleteCptCS(cpt.name), true)))); });
    } else if (categoryView === 'taxonomies') {
      header = ['Label', 'Singular', 'Slug', 'Description', 'Hierarchical', 'Public', 'Post types', 'Actions'];
      const data = (meta.taxonomies_list || []).filter(t => matches(t.label) || matches(t.name));
      count = data.length;
      rows = data.map(tax => { const st = tax.settings || {}; const acf = tax.source === 'acf'; return h('tr', { key: tax.name, class: 've-cat-row', onClick: () => startEditTax(null, tax) },
        nameCell('tag', tax.label), h('td', null, tax.singular || ''), code(tax.name), h('td', null, h('span', { class: 've-cat-desc' }, st.description || '—')),
        h('td', null, acf ? swt(st.hierarchical !== false, () => catSaveModel('tax', tax, { hierarchical: !(st.hierarchical !== false) })) : pill(st.hierarchical !== false)),
        h('td', null, acf ? swt(st.public !== false, () => catSaveModel('tax', tax, { public: !(st.public !== false) })) : pill(st.public !== false)),
        h('td', null, h('div', { class: 've-cat-badges' }, ((st.object_type) || []).map(o => h('span', { class: 've-cat-badge', key: o }, o)))),
        h('td', { style: 'text-align:right' }, h('div', { class: 've-cat-acts' }, iact('Edit', 'pencil-simple', () => startEditTax(null, tax)), acf && iact('Duplicate', 'copy', () => catDuplicateModel('tax', tax)), acf && iact('Delete', 'trash', () => setPendingDeleteTax(tax.name), true)))); });
    } else if (categoryView === 'options') {
      header = ['Page title', 'Slug', 'Fields', 'Autoload', 'Actions'];
      const data = (meta.option_pages || []).filter(p => matches(p.label) || matches(p.slug));
      count = data.length;
      rows = data.map(page => { const st = page.settings || {}; const ed = page.editable !== false; return h('tr', { key: page.id, class: 've-cat-row', onClick: () => ed ? startEditOpt(null, page) : selectContentNav(page.id) },
        nameCell('sliders-horizontal', page.label || page.slug), code(page.slug), h('td', null, String((page.fields || []).length) + ' fields'),
        h('td', null, ed ? swt(!!st.autoload, () => setOptionsAutoload(page)) : pill(!!st.autoload)),
        h('td', { style: 'text-align:right' }, h('div', { class: 've-cat-acts' }, ed && iact('Edit', 'pencil-simple', () => startEditOpt(null, page)), iact('Open', 'arrow-right', () => selectContentNav(page.id)), ed && iact('Delete', 'trash', () => setPendingDeleteOpt(page.slug), true)))); });
    } else if (categoryView === 'fields') {
      header = ['Field Group', 'Fields', 'Source', 'Actions'];
      const data = (meta.field_groups || []).filter(g => matches(g.title));
      count = data.length;
      rows = data.map(group => h('tr', { key: group.id, class: 've-cat-row', onClick: () => selectContentNav(group.id) },
        nameCell('gear', group.title), h('td', null, String((group.fields || []).length) + ' fields'), h('td', null, h('span', { class: 've-cat-badge' }, String(group.source || '').toUpperCase())),
        h('td', { style: 'text-align:right' }, h('div', { class: 've-cat-acts' }, iact('Delete', 'trash', () => handleDeleteFieldGroup({ stopPropagation() {} }, group.id), true)))));
    }
    return h('div', { class: 've-cat-list' },
      h('div', { class: 've-cat-head' },
        h('button', { type: 'button', class: 've-btn ve-btn-g ve-btn-s', onClick: () => setCategoryView(null) }, ph('arrow-left'), 'Back'),
        h('h2', { class: 've-cat-title' }, spec.title, h('span', { class: 've-cat-count' }, count + ' ' + spec.noun)),
        h('input', { class: 've-studio-input ve-cat-search', placeholder: 'Search ' + spec.noun + '…', value: catSearch, onInput: e => setCatSearch(e.target.value) }),
        spec.add && h('button', { type: 'button', class: 've-btn ve-btn-s', onClick: spec.add }, ph('plus'), 'Add New')
      ),
      h('div', { class: 've-cat-table-wrap ve-scroll-custom' },
        count
          ? h('table', { class: 've-cat-table' }, h('thead', null, h('tr', null, header.map((c, i) => h('th', { key: i, style: c === 'Actions' ? 'text-align:right' : '' }, c)))), h('tbody', null, rows))
          : h('div', { class: 've-cat-empty' }, q ? 'No matches.' : 'Nothing here yet.')
      )
    );
  };

  /* ===== Options Pages editor (#13) — mirrors the taxonomy editor. ===== */
  const startNewOpt = () => {
    setEditingOptSlug(''); setOptSlug(''); setOptSettings(optDefaultSettings()); setOptView('placement');
    setShowOptForm(true); setShowCptForm(false); setShowTaxForm(false); setShowFieldGroupForm(false); setShowCreateForm(false); setShowFieldForm(false); setEditingPost(null); setCategoryView(null);
  };
  const startEditOpt = (e, page) => {
    if (e) e.stopPropagation();
    if (!page) return;
    setEditingOptSlug(page.slug || ''); setOptSlug(page.slug || '');
    const base = optDefaultSettings();
    setOptSettings(page.settings ? { ...base, ...page.settings } : base);
    setOptView('placement');
    setShowOptForm(true); setShowCptForm(false); setShowTaxForm(false); setShowFieldGroupForm(false); setShowCreateForm(false); setShowFieldForm(false); setEditingPost(null); setCategoryView(null);
  };
  const handleCreateOpt = async (e) => {
    e.preventDefault();
    const st = optSettings || optDefaultSettings();
    const slug = (editingOptSlug || optSlug || st.menu_slug || '').trim();
    if (!st.page_title || !st.page_title.trim() || !slug) { setOptView('placement'); flash('Add a page title and menu slug on the Placement tab first.'); return; }
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/options-pages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ slug: slug, settings: { ...st, menu_slug: slug } }) });
      if (res && res.success) {
        flash(editingOptSlug ? 'Options page updated.' : 'Options page registered.');
        setOptSlug(''); setEditingOptSlug(''); setOptSettings(null); setShowOptForm(false);
        await loadMeta();
      } else { flash((res && res.message) || 'Options page save failed.'); }
    } catch (err) { flash('Options page save failed.'); }
    setLoading(false);
  };
  const handleDeleteOpt = (e, slug) => { if (e) e.stopPropagation(); setPendingDeleteOpt(slug); };
  const confirmDeleteOpt = async () => {
    const slug = pendingDeleteOpt; if (!slug) return; setPendingDeleteOpt(null); setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/options-pages/' + slug, { method: 'DELETE' });
      if (res && res.success) { flash('Options page "' + slug + '" deleted.'); await loadMeta(); } else { flash((res && res.message) || 'Failed to delete options page.'); }
    } catch (err) { flash('Failed to delete options page.'); }
    setLoading(false);
  };
  // Inline autoload toggle used by the category list.
  const setOptionsAutoload = async (page) => {
    const st = { ...(page.settings || {}), autoload: !(page.settings && page.settings.autoload) };
    try {
      const res = await api.f('variable-engine/v1/content-studio/options-pages', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ slug: page.slug, settings: { ...st, menu_slug: page.slug } }) });
      if (res && res.success) await loadMeta(); else flash((res && res.message) || 'Could not update.');
    } catch (e) { flash('Could not update.'); }
  };

  const renderOptEditor = () => {
    const s = optSettings || optDefaultSettings();
    const set = patch => setOptSettings(prev => ({ ...(prev || optDefaultSettings()), ...patch }));
    const field = (label, key, place, help, mono) => h('div', { class: 've-cpt-field' },
      h('label', { class: 've-fg-k' }, label),
      h('input', { class: 've-studio-input' + (mono ? ' ve-mono' : ''), value: s[key] == null ? '' : s[key], placeholder: place || '', onInput: e => set({ [key]: e.target.value }) }),
      help ? h('div', { class: 've-fg-help' }, help) : null);
    const toggle = (label, key, help) => h('div', { class: 've-fg-tg' },
      h('div', null, h('div', { class: 've-fg-tl' }, label), help ? h('div', { class: 've-fg-ts' }, help) : null),
      h(ToggleControl, { checked: !!s[key], onChange: v => set({ [key]: v }) }));
    const grid = (...kids) => h('div', { class: 've-cpt-grid' }, kids.filter(Boolean));
    const card = (title, sub, ...kids) => h('div', { class: 've-cpt-card' },
      h('h3', { class: 've-cpt-h' }, title), sub ? h('p', { class: 've-cpt-sub' }, sub) : null, ...kids.filter(Boolean));
    const slugField = () => h('div', { class: 've-cpt-field' },
      h('label', { class: 've-fg-k' }, 'Menu slug'),
      h('input', { class: 've-studio-input ve-mono', required: true, readOnly: !!editingOptSlug, value: editingOptSlug || optSlug, placeholder: 'e.g. theme-settings', onInput: e => { const v = e.target.value.toLowerCase().replace(/[^a-z0-9_\-]/g, ''); setOptSlug(v); set({ menu_slug: v }); } }),
      h('div', { class: 've-fg-help' }, 'Stable menu slug. Locked after the first save.'));
    const assignedGroups = ((meta.option_pages || []).find(p => p.slug === (editingOptSlug || optSlug)) || {}).field_groups || [];
    const tabs = [['placement', 'Placement'], ['access', 'Access'], ['groups', 'Field Groups']];
    const view = optView || 'placement';
    return h('form', { onSubmit: handleCreateOpt, class: 've-cpt-editor' },
      h('div', { class: 've-fg-views' }, tabs.map(t => h('button', { type: 'button', key: t[0], class: view === t[0] ? 'on' : '', onClick: () => setOptView(t[0]) }, t[1]))),
      h('div', { class: 've-cpt-body' },
        view === 'placement' && card('Menu placement', 'Page title, stable menu slug, parent location, and admin-menu placement.',
          grid(
            field('Page title', 'page_title', 'e.g. Theme Settings'),
            field('Menu title', 'menu_title', 'Shown in the admin menu'),
            slugField(),
            field('Parent page', 'parent_slug', 'Optional parent menu slug', 'Leave blank for a top-level menu item.', true),
            field('Menu position', 'position', 'e.g. 80', null, true),
            field('Menu icon', 'icon_url', 'dashicons-admin-generic', 'Dashicon, Media Library item, or URL.', true)
          ),
          h('div', { class: 've-cpt-field ve-cpt-field-full' },
            h('label', { class: 've-fg-k' }, 'Description'),
            h('textarea', { class: 've-studio-input', rows: 2, value: s.description || '', placeholder: 'Optional description.', onInput: e => set({ description: e.target.value }) }))
        ),
        view === 'access' && card('Access & behavior', 'Control who can open the page and how ACF loads its values.',
          grid(field('Capability', 'capability', 'edit_posts', 'Users without this capability will not see the page.', true)),
          toggle('Redirect parent page', 'redirect', 'Redirect this menu item to its first child page.'),
          toggle('Autoload values', 'autoload', 'Load option values with WordPress options on every request.')
        ),
        view === 'groups' && card('Assigned field groups', 'Field groups target an options page through their own Location Rules, so assignment is edited there.',
          assignedGroups.length
            ? h('div', { class: 've-cat-badges' }, assignedGroups.map((g, i) => h('span', { class: 've-cat-badge', key: i }, g)))
            : h('div', { class: 've-fg-help' }, 'No field groups target this options page yet. Open a field group → Location Rules → add "Options Page is equal to ' + (editingOptSlug || optSlug || 'this page') + '".')
        )
      ),
      h('div', { class: 've-cpt-foot' },
        h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:600' }, loading ? 'Saving...' : (editingOptSlug ? 'Save options page' : 'Register options page')),
        h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => { setShowOptForm(false); setEditingOptSlug(''); setOptSlug(''); setOptSettings(null); } }, 'Cancel')
      )
    );
  };

  const handleCreateFieldGroup = async (e) => {
    e.preventDefault();
    if (!groupTitle.trim()) return;
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/fields', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: groupTitle, post_types: groupTargets, fields: [], source: groupSource })
      });
      if (res && res.success) {
        flash('Field Group created successfully!');
        const createdTitle = groupTitle;
        setGroupTitle('');
        setGroupTargets([]);
        setShowFieldGroupForm(false);
        await loadMeta();
        // Land straight in the builder for the group just created, rather than leaving
        // the user to find it in the sidebar.
        const createdId = res.id || res.group_id || (res.group && res.group.id) || null;
        if (createdId) {
          selectContentNav(createdId);
        } else {
          const match = (meta.field_groups || []).find(g => g.title === createdTitle);
          if (match) selectContentNav(match.id);
        }
      } else {
        flash('Field Group creation failed');
      }
    } catch (e) {
      flash('Field Group creation failed');
    }
    setLoading(false);
  };

  const handleDeleteFieldGroup = (e, id) => {
    e.stopPropagation();
    setPendingDeleteFgCS(id);
  };

  const confirmDeleteFgCS = async () => {
    const id = pendingDeleteFgCS;
    if (!id) return;
    setPendingDeleteFgCS(null);
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/fields/' + id, { method: 'DELETE' });
      if (res && res.success) {
        flash('Field Group deleted.');
        if (activeNav === id) setActiveNav('page');
        await loadMeta();
      } else {
        flash('Failed to delete Field Group.');
      }
    } catch (e) {
      flash('Failed to delete Field Group.');
    }
    setLoading(false);
  };

  const handleCreateField = async (e) => {
    e.preventDefault();
    if (!fieldName.trim() || !fieldLabel.trim()) return;
    setLoading(true);
    try {
      const group = meta.field_groups.find(g => g.id === activeNav);
      if (!group) return;
      
      const newField = { name: fieldName, label: fieldLabel, type: fieldType };
      const existingFields = group.fields || [];
      const updatedFields = editingFieldName
        ? existingFields.map(f => f.name === editingFieldName ? newField : f)
        : [...existingFields.filter(f => f.name !== fieldName), newField];
      
      const res = await api.f('variable-engine/v1/content-studio/fields', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: group.title,
          post_types: group.post_types || [],
          fields: updatedFields,
          source: group.source || 'acf'
        })
      });
      if (res && res.success) {
        flash(editingFieldName ? 'Custom field updated!' : 'Custom field added!');
        setFieldName('');
        setFieldLabel('');
        setEditingFieldName('');
        setShowFieldForm(false);
        await loadMeta();
      } else {
        flash('Failed to add field.');
      }
    } catch (e) {
      flash('Failed to add field.');
    }
    setLoading(false);
  };

  const handleDeleteField = (fName) => {
    setPendingDeleteFieldCS(fName);
  };

  const handleEditField = (field) => {
    setEditingFieldName(field.name || '');
    setFieldName(field.name || '');
    setFieldLabel(field.label || '');
    setFieldType(field.type || 'text');
    setShowFieldForm(true);
  };

  const confirmDeleteFieldCS = async () => {
    const fName = pendingDeleteFieldCS;
    if (!fName) return;
    setPendingDeleteFieldCS(null);
    setLoading(true);
    try {
      const group = meta.field_groups.find(g => g.id === activeNav);
      if (!group) return;
      
      const updatedFields = (group.fields || []).filter(f => f.name !== fName);
      
      const res = await api.f('variable-engine/v1/content-studio/fields', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: group.title,
          post_types: group.post_types || [],
          fields: updatedFields,
          source: group.source || 'acf'
        })
      });
      if (res && res.success) {
        flash('Field deleted.');
        await loadMeta();
      } else {
        flash('Failed to delete field.');
      }
    } catch (e) {
      flash('Failed to delete field.');
    }
    setLoading(false);
  };

  const formatNavLabel = (key) => {
    if (key === 'page') return 'Pages';
    if (key === 'post') return 'Posts';
    const cpt = meta.cpts.find(pt => pt.name === key);
    if (cpt) return cpt.label;
    const group = meta.field_groups.find(g => g.id === key);
    if (group) return group.title;
    return key;
  };

  const getPostTypeMeta = key => meta.cpts.find(pt => pt.name === key) || null;
  const canEditWithBricks = item => !!(item && item.bricks_editable && item.bricks_link);
  const contentTaxonomies = post => (meta.taxonomies && Array.isArray(meta.taxonomies[post?.post_type])) ? meta.taxonomies[post.post_type] : [];
  const updateContentTerms = (taxonomy, nextIds) => {
    setContentEditorSaveState('dirty');
    setEditingPost(current => current ? ({ ...current, terms: { ...(current.terms || {}), [taxonomy]: nextIds } }) : current);
  };
  const addContentTerm = (taxonomy, termId) => {
    const id = parseInt(termId || 0, 10) || 0;
    if (!id || !editingPost) return;
    const current = Array.isArray(editingPost.terms?.[taxonomy]) ? editingPost.terms[taxonomy].map(Number) : [];
    updateContentTerms(taxonomy, Array.from(new Set([...current, id])));
  };
  const removeContentTerm = (taxonomy, termId) => {
    const current = Array.isArray(editingPost?.terms?.[taxonomy]) ? editingPost.terms[taxonomy].map(Number) : [];
    updateContentTerms(taxonomy, current.filter(id => id !== Number(termId)));
  };
  const hasRankMathSeo = item => !!(item && item.seo_details && (item.seo_details.has_plugin || item.seo_details.score !== null || item.seo_details.focus_keyword || item.seo_details.title || item.seo_details.description));
  const renderSeoDetailsCell = item => {
    const seo = item?.seo_details || {};
    const hasScore = seo.score !== null && seo.score !== undefined && seo.score !== '';
    const score = hasScore ? Number(seo.score) : null;
    const scoreClass = score === null ? 'empty' : (score >= 80 ? 'good' : (score >= 50 ? 'warn' : 'bad'));
    const keyword = (seo.focus_keyword || '').trim();
    const desc = (seo.description || '').trim();
    const schema = (seo.schema || '').trim();
    // Score only — everything else reads better as chips under the title.
    return h('span', { class: 've-seo-score ' + scoreClass }, score === null ? 'N/A' : String(score));
  };
  // Meta / Schema / Robots / Comments / Pings as small chips under the post title.
  const renderTitleSeoChips = item => {
    const seo = item?.seo_details || {};
    return h('div', { class: 've-content-title-chips' },
      h('span', { class: 've-content-title-chip' }, 'Meta: ' + ((seo.description || '').trim() ? 'set' : 'missing')),
      h('span', { class: 've-content-title-chip' }, 'Schema: ' + ((seo.schema || '').trim() || 'Article')),
      h('span', { class: 've-content-title-chip' }, 'Robots: ' + (seo.robots || 'index')),
      h('span', { class: 've-content-title-chip' }, 'Comments: ' + (item.comment_status === 'open' ? 'on' : 'off')),
      h('span', { class: 've-content-title-chip' }, 'Pings: ' + (item.ping_status === 'open' ? 'on' : 'off'))
    );
  };
  // ── Content Studio view modes (List / Cards / Board / Calendar) ──────────
  const contentScoreOf = item => { const s = item && item.seo_details ? item.seo_details.score : null; return (s !== null && s !== undefined && s !== '' && Number.isFinite(Number(s))) ? Number(s) : null; };
  const contentScoreClass = s => s === null ? 'empty' : (s >= 80 ? 'good' : (s >= 50 ? 'warn' : 'bad'));
  const contentStatusMeta = st => st === 'publish' ? ['pub', 'Published'] : st === 'pending' ? ['pending', 'Pending'] : st === 'future' ? ['pending', 'Scheduled'] : st === 'private' ? ['pending', 'Private'] : ['draft', 'Draft'];
  const contentShortDate = raw => { if (!raw) return '—'; const d = new Date(raw); return isNaN(d) ? '—' : d.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }); };
  const contentPlainText = item => String((item && item.excerpt && item.excerpt.rendered) || (item && item.seo_details && item.seo_details.description) || '').replace(/<[^>]+>/g, ' ').replace(/&[a-z#0-9]+;/gi, ' ').replace(/\s+/g, ' ').trim();
  const contentThumbStyle = item => (item && item.featured_media_url) ? ('background-image:url(' + item.featured_media_url + ');background-size:cover;background-position:center') : '';
  const escHtml = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
  const showContentHover = (item, e) => {
    if (!hoverElRef.current) { const el = document.createElement('div'); el.className = 've-cv-pop'; el.style.display = 'none'; document.body.appendChild(el); hoverElRef.current = el; }
    const el = hoverElRef.current;
    const sc = contentScoreOf(item); const [scls, slabel] = contentStatusMeta(item.status);
    const desc = contentPlainText(item); const kw = (item.seo_details && item.seo_details.focus_keyword || '').trim();
    const row = (k, v) => v ? '<div class="ve-cv-pop-row"><span class="ve-cv-pop-k">' + k + '</span><span class="ve-cv-pop-v">' + escHtml(v) + '</span></div>' : '';
    el.innerHTML = '<div class="ve-cv-pop-type"><span class="ve-cv-pop-dot ' + scls + '"></span>' + slabel + ' · ' + escHtml(item.type || activeNav) + '</div>' +
      '<h4 class="ve-cv-pop-title">' + escHtml(item.title && item.title.rendered || 'Untitled') + '</h4>' +
      (desc ? '<div class="ve-cv-pop-desc">' + escHtml(desc.length > 180 ? desc.slice(0, 180) + '…' : desc) + '</div>' : '') +
      row('SEO score', sc === null ? 'Not scored' : sc + ' / 100') +
      row('Publish date', item.date ? new Date(item.date).toLocaleDateString() : 'Not scheduled') +
      row('Focus keyword', kw || 'None set') +
      (item.featured_media_url ? '<div class="ve-cv-pop-thumb" style="background-image:url(' + escHtml(item.featured_media_url) + ')"></div>' : '');
    el.style.display = 'block';
    // The card must stay INSIDE the Content Studio panel and must never sit on top of
    // the row/card being hovered. Try beside it first (right, then left); only if
    // neither side fits do we stack it below/above — always clamped to the panel box.
    const host = (csRootRef.current && (csRootRef.current.closest('.ve-standalone-panel') || csRootRef.current)) || document.body;
    const b = host.getBoundingClientRect();
    const r = e.currentTarget.getBoundingClientRect();
    const pad = 10, gap = 12;
    const maxW = Math.max(200, Math.min(300, b.width - pad * 2));
    el.style.width = maxW + 'px';
    const maxH = Math.max(160, b.height - pad * 2);
    el.style.maxHeight = maxH + 'px';
    el.style.overflow = 'hidden';
    // Measure what the card ACTUALLY occupies (border + padding included) — using the
    // requested width here is what let the card creep over the hovered item.
    const pw = el.offsetWidth || maxW, ph2 = Math.min(el.offsetHeight || 320, maxH);
    const clamp = (v, lo, hi) => Math.max(lo, Math.min(v, hi));
    let x, y;
    if (r.right + gap + pw <= b.right - pad) x = r.right + gap;            // to the right
    else if (r.left - gap - pw >= b.left + pad) x = r.left - gap - pw;     // to the left
    if (x != null) {
      y = clamp(r.top, b.top + pad, b.bottom - pad - ph2);
    } else {
      x = clamp(r.left, b.left + pad, b.right - pad - pw);
      if (r.bottom + gap + ph2 <= b.bottom - pad) y = r.bottom + gap;      // below
      else y = clamp(r.top - gap - ph2, b.top + pad, b.bottom - pad - ph2); // above
    }
    el.style.left = Math.round(x) + 'px'; el.style.top = Math.round(y) + 'px';
    if (contentFocus && csRootRef.current) {
      csRootRef.current.classList.remove('ve-cs-focus-blur', 've-cs-focus-dim');
      csRootRef.current.classList.add(contentFocusStyle === 'dim' ? 've-cs-focus-dim' : 've-cs-focus-blur');
    }
  };
  const hideContentHover = () => {
    if (hoverElRef.current) hoverElRef.current.style.display = 'none';
    if (csRootRef.current) csRootRef.current.classList.remove('ve-cs-focus-blur', 've-cs-focus-dim');
  };
  const hoverProps = item => ({ onMouseEnter: e => showContentHover(item, e), onMouseLeave: hideContentHover });
  const renderContentCards = items => h('div', { class: 've-cv-cards' }, items.map(item => {
    const sc = contentScoreOf(item); const [scls, slabel] = contentStatusMeta(item.status);
    return h('div', { key: item.id, class: 've-cv-card', ...hoverProps(item), onClick: e => startStudioEdit(item, e) },
      h('div', { class: 've-cv-thumb', style: contentThumbStyle(item) }),
      h('div', { class: 've-cv-card-body' },
        h('h4', null, item.title && item.title.rendered || 'Untitled'),
        h('div', { class: 've-cv-meta' },
          h('span', { class: 've-cv-pill ' + scls }, slabel),
          h('span', { class: 've-cv-when' }, contentShortDate(item.date)),
          sc !== null && h('span', { class: 've-cv-score ' + contentScoreClass(sc) }, sc)
        )
      )
    );
  }));
  const renderContentBoard = items => h('div', { class: 've-cv-board' },
    [['draft', 'Draft', ['draft', 'auto-draft', 'future', 'private']], ['pending', 'Pending', ['pending']], ['publish', 'Published', ['publish']]].map(col => {
      const list = items.filter(it => col[2].includes(it.status));
      return h('div', { key: col[0], class: 've-cv-col' },
        h('div', { class: 've-cv-col-head' }, h('span', { class: 've-cv-pill ' + contentStatusMeta(col[0])[0] }, col[1]), h('span', { class: 've-cv-col-n' }, list.length)),
        h('div', { class: 've-cv-col-body' }, list.length ? list.map(item => {
          const sc = contentScoreOf(item);
          return h('div', { key: item.id, class: 've-cv-bcard', ...hoverProps(item), onClick: e => startStudioEdit(item, e) },
            h('h5', null, item.title && item.title.rendered || 'Untitled'),
            h('div', { class: 've-cv-brow' }, sc !== null && h('span', { class: 've-cv-score ' + contentScoreClass(sc) }, sc), h('span', { class: 've-cv-when' }, contentShortDate(item.date)))
          );
        }) : h('div', { class: 've-cv-col-empty' }, 'Nothing here'))
      );
    })
  );
  // ── Calendar actions: reschedule by drag, and create a post on a day ──────
  const calDateKey = d => d.getFullYear() + '-' + ('0' + (d.getMonth() + 1)).slice(-2) + '-' + ('0' + d.getDate()).slice(-2);
  // Optimistic: the post jumps to the new day immediately and the request settles in
  // the background. Using the global `loading` flag here blanked the whole calendar
  // to "Loading…" on every drag, which read as a glitch.
  const rescheduleContentPost = async (id, dateStr) => {
    if (!id || !dateStr) return;
    hideContentHover();
    const previous = items;
    const optimisticDate = dateStr + 'T09:00:00';
    setItems(list => list.map(it => (it.id === id ? { ...it, date: optimisticDate, date_local: optimisticDate, calendar_scheduled: true } : it)));
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts/' + id, {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ date: dateStr })
      });
      if (res && res.id) {
        // Reconcile with the server's authoritative record (status may have flipped to
        // Scheduled/Published) without refetching the whole list.
        setItems(list => list.map(it => (it.id === res.id ? { ...it, ...res } : it)));
        flash('Moved to ' + new Date(optimisticDate).toLocaleDateString() + '.');
      } else {
        setItems(previous);
        flash((res && res.message) || 'Could not move this post.');
      }
    } catch (err) {
      setItems(previous);
      flash('Could not move this post.');
    }
  };
  const createContentPostOnDate = async dateStr => {
    if (!dateStr) return;
    hideContentHover();
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ post_type: activeNav, title: 'Untitled', status: 'draft', date: dateStr, content: '', excerpt: '' })
      });
      if (res && res.id) {
        setItems(list => [res, ...list]);
        flash('Draft created on ' + new Date(dateStr + 'T09:00:00').toLocaleDateString() + '.');
        startStudioEdit(res);
        loadMeta();
      } else flash((res && res.message) || 'Could not create the post.');
    } catch (err) { flash('Could not create the post.'); }
  };
  const calDragProps = item => ({
    draggable: true,
    onDragStart: e => { hideContentHover(); try { e.dataTransfer.setData('text/plain', String(item.id)); e.dataTransfer.effectAllowed = 'move'; } catch (err) {} },
  });
  const calDropProps = dateStr => ({
    onDragOver: e => { e.preventDefault(); try { e.dataTransfer.dropEffect = 'move'; } catch (err) {} e.currentTarget.classList.add('is-drop'); },
    onDragLeave: e => e.currentTarget.classList.remove('is-drop'),
    onDrop: e => {
      e.preventDefault(); e.currentTarget.classList.remove('is-drop');
      let id = 0; try { id = parseInt(e.dataTransfer.getData('text/plain'), 10) || 0; } catch (err) {}
      if (id) rescheduleContentPost(id, dateStr);
    }
  });
  const isContentUnscheduled = item => !!item && ['draft','auto-draft'].includes(item.status) && !item.calendar_scheduled;
  const renderContentCalendar = items => {
    const ref = contentCalRef; const y = ref.getFullYear(); const m = ref.getMonth();
    const today = new Date();
    const unscheduled = items.filter(isContentUnscheduled);
    const dated = items.filter(item => !isContentUnscheduled(item));
    const renderUnscheduled = () => h('aside', { class: 've-cv-unscheduled', 'aria-label': 'Unscheduled drafts' },
      h('div', { class: 've-cv-unscheduled-head' }, h('b', null, 'Unscheduled'), h('span', { class: 've-cv-unscheduled-n' }, unscheduled.length)),
      h('p', { class: 've-cv-unscheduled-hint' }, 'Drafts with no target date. Drag one onto a day to schedule it.'),
      unscheduled.length ? h('div', { class: 've-cv-unscheduled-list' }, unscheduled.map(item => {
        const sc = contentScoreOf(item);
        return h('div', { key: item.id, class: 've-cv-ucard', tabIndex: 0, title: 'Drag onto a calendar day to schedule', ...calDragProps(item), ...hoverProps(item),
          onClick: e => { e.stopPropagation(); startStudioEdit(item, e); },
          onKeyDown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); startStudioEdit(item, e); } } },
          h('h5', null, item.title && item.title.rendered || 'Untitled'),
          h('div', { class: 've-cv-ucard-meta' }, h('span', { class: 've-cv-pill draft' }, 'Draft'), sc !== null && h('span', { class: 've-cv-score ' + contentScoreClass(sc) }, sc), h('span', { class: 've-cv-no-date' }, 'No date'))
        );
      })) : h('div', { class: 've-cv-unscheduled-empty' }, 'Nothing waiting — every draft has a target date.')
    );
    const withRail = main => h('div', { class: 've-cv-cal-layout' }, h('div', { class: 've-cv-cal-main' }, main), renderUnscheduled());
    const evChip = item => { const sc = contentScoreOf(item); const [scls] = contentStatusMeta(item.status); return h('div', { key: item.id, class: 've-cv-ev ' + scls + (sc !== null ? ' ' + contentScoreClass(sc) : ''), title: 'Drag to another day to reschedule', ...calDragProps(item), ...hoverProps(item), onClick: e => { e.stopPropagation(); startStudioEdit(item, e); } }, h('span', { class: 've-cv-ev-t' }, item.title && item.title.rendered || 'Untitled'), sc !== null && h('span', { class: 've-cv-ev-s' }, sc)); };
    const head = h('div', { class: 've-cv-cal-head' },
      h('div', { class: 've-cv-cal-title' }, h('b', null, ref.toLocaleDateString(undefined, { month: 'long' })), h('span', { class: 've-cv-cal-yr' }, y)),
      h('button', { type: 'button', class: 've-btn ve-btn-g ve-btn-s', onClick: () => setContentCalRef(new Date()) }, 'Today'),
      h('div', { class: 've-cv-cal-nav' },
        h('button', { type: 'button', 'aria-label': 'Previous', onClick: () => setContentCalRef(contentCalMode === 'week' ? new Date(y, m, ref.getDate() - 7) : new Date(y, m - 1, 1)) }, '‹'),
        h('button', { type: 'button', 'aria-label': 'Next', onClick: () => setContentCalRef(contentCalMode === 'week' ? new Date(y, m, ref.getDate() + 7) : new Date(y, m + 1, 1)) }, '›')
      ),
      h('div', { class: 've-cv-seg' }, ['month', 'week'].map(md => h('button', { key: md, type: 'button', class: contentCalMode === md ? 'on' : '', onClick: () => setContentCalMode(md) }, md === 'month' ? 'Month' : 'Week')))
    );
    const dows = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    if (contentCalMode === 'week') {
      const start = new Date(y, m, ref.getDate() - ref.getDay());
      const cols = [];
      for (let i = 0; i < 7; i++) {
        const d = new Date(start.getFullYear(), start.getMonth(), start.getDate() + i);
        const dayItems = dated.filter(it => { if (!it.date) return false; const dd = new Date(it.date); return dd.toDateString() === d.toDateString(); });
        const isToday = d.toDateString() === today.toDateString();
        const ds = calDateKey(d);
        cols.push(h('div', { key: i, class: 've-cv-wk-col' + ((i === 0 || i === 6) ? ' wknd' : '') + (isToday ? ' today' : ''), ...calDropProps(ds) },
          h('div', { class: 've-cv-wk-head' }, h('span', { class: 've-cv-wk-wd' }, dows[i]), h('span', { class: 've-cv-wk-dd' }, d.getDate())),
          h('div', { class: 've-cv-wk-body' }, dayItems.length ? dayItems.map(item => { const sc = contentScoreOf(item); const [scls, slabel] = contentStatusMeta(item.status); return h('div', { key: item.id, class: 've-cv-wk-card', title: 'Drag to another day to reschedule', ...calDragProps(item), ...hoverProps(item), onClick: e => startStudioEdit(item, e) }, h('div', { class: 've-cv-thumb', style: contentThumbStyle(item) }), h('div', { class: 've-cv-wk-cb' }, h('h5', null, item.title && item.title.rendered || 'Untitled'), h('div', { class: 've-cv-brow' }, h('span', { class: 've-cv-pill ' + scls }, slabel), sc !== null && h('span', { class: 've-cv-score ' + contentScoreClass(sc) }, sc)))); }) : h('div', { class: 've-cv-wk-empty' }, '')),
          h('button', { type: 'button', class: 've-cv-add', title: 'New post on this day', 'aria-label': 'New post on ' + ds, onClick: e => { e.stopPropagation(); createContentPostOnDate(ds); } }, '+')
        ));
      }
      const range = start.toLocaleDateString(undefined, { month: 'short', day: 'numeric' }) + ' – ' + new Date(start.getFullYear(), start.getMonth(), start.getDate() + 6).toLocaleDateString(undefined, { month: 'short', day: 'numeric' });
      return withRail(h('div', { class: 've-cv-cal' }, head, h('div', { class: 've-cv-cal-sub' }, range), h('div', { class: 've-cv-week' }, cols)));
    }
    // Key every item by its full date so adjacent-month cells (e.g. late July / early
    // September shown around August) still surface their posts, not just the current month.
    const keyOf = d => d.getFullYear() + '-' + d.getMonth() + '-' + d.getDate();
    const byKey = {}; dated.forEach(it => { if (!it.date) return; const d = new Date(it.date); if (isNaN(d)) return; (byKey[keyOf(d)] = byKey[keyOf(d)] || []).push(it); });
    const first = new Date(y, m, 1).getDay();
    const gridStart = new Date(y, m, 1 - first); // first cell (may fall in the previous month)
    const cells = [];
    for (let i = 0; i < 42; i++) {
      const d = new Date(gridStart.getFullYear(), gridStart.getMonth(), gridStart.getDate() + i);
      const inMonth = d.getMonth() === m; const isToday = d.toDateString() === today.toDateString(); const dow = d.getDay();
      const list = byKey[keyOf(d)] || [];
      const ds = calDateKey(d);
      cells.push(h('div', { key: 'c' + i, class: 've-cv-day' + (inMonth ? '' : ' out') + (isToday ? ' today' : '') + ((dow === 0 || dow === 6) ? ' wknd' : ''), ...calDropProps(ds) },
        h('div', { class: 've-cv-num' }, d.getDate()),
        list.slice(0, 3).map(evChip),
        list.length > 3 && h('div', { class: 've-cv-more' }, '+' + (list.length - 3) + ' more'),
        h('button', { type: 'button', class: 've-cv-add', title: 'New post on this day', 'aria-label': 'New post on ' + ds, onClick: e => { e.stopPropagation(); createContentPostOnDate(ds); } }, '+')
      ));
    }
    return withRail(h('div', { class: 've-cv-cal' }, head,
      h('div', { class: 've-cv-dows' }, dows.map(d => h('div', { key: d, class: 've-cv-dow' }, d))),
      h('div', { class: 've-cv-grid' }, cells)
    ));
  };
  // Focus toggle + its settings popover, shown beside the view switcher.
  const renderContentFocusControl = () => h('div', { class: 've-cv-focus-wrap' },
    h('button', {
      type: 'button', class: 've-cv-focus' + (contentFocus ? ' on' : ''),
      title: contentFocus ? 'Focus mode on — the studio recedes while a preview is open' : 'Focus mode off',
      'aria-pressed': contentFocus ? 'true' : 'false',
      onClick: toggleContentFocus
    }, ph('crosshair'), h('span', null, 'Focus')),
    h('button', {
      type: 'button', class: 've-cv-focus-cog' + (contentFocusMenu ? ' on' : ''),
      title: 'Focus settings', 'aria-label': 'Focus settings',
      onClick: () => setContentFocusMenu(v => !v)
    }, ph('gear')),
    contentFocusMenu && h('div', { class: 've-cv-focus-pop' },
      h('div', { class: 've-cv-focus-pop-h' }, 'While a preview is open'),
      [['blur', 'Blur the studio', 'Everything behind the card softens out of focus.'],
       ['dim', 'Dim the studio', 'Everything behind the card darkens instead of blurring.']].map(o =>
        h('button', { key: o[0], type: 'button', class: contentFocusStyle === o[0] ? 'on' : '', onClick: () => { chooseContentFocusStyle(o[0]); setContentFocusMenu(false); } },
          h('span', null, h('b', null, o[1]), h('em', null, o[2])), contentFocusStyle === o[0] && ph('check'))
      ),
      h('div', { class: 've-cv-focus-pop-f' }, 'The preview card itself always stays sharp.')
    )
  );
  const renderContentViewSwitcher = () => h('div', { class: 've-cv-switch', role: 'group', 'aria-label': 'View mode' },
    [['list', 'list-bullets', 'List'], ['cards', 'squares-four', 'Cards'], ['board', 'kanban', 'Board'], ['calendar', 'calendar-blank', 'Calendar']].map(v =>
      h('button', { key: v[0], type: 'button', class: contentView === v[0] ? 'on' : '', title: v[2], 'aria-pressed': contentView === v[0] ? 'true' : 'false', onClick: () => chooseContentView(v[0]) }, ph(v[1]), h('span', null, v[2]))
    )
  );
  const getFieldGroupsForPostType = key => {
    const pt = String(key || '');
    if (!pt) return [];
    return (meta.field_groups || []).filter(group => {
      const targets = Array.isArray(group.post_types) ? group.post_types.map(String) : [];
      return targets.includes(pt);
    });
  };
  const getEditableCustomFields = post => {
    const groups = getFieldGroupsForPostType(post?.post_type);
    const fields = [];
    const seen = new Set();
    groups.forEach(group => (group.fields || []).forEach(field => {
      const key = field.name || field.label;
      if (!key || seen.has(key)) return;
      seen.add(key);
      fields.push({ ...field, groupTitle: group.title || 'Field group' });
    }));
    Object.keys(post?.custom_fields || {}).forEach(key => {
      if (!key || seen.has(key)) return;
      seen.add(key);
      fields.push({ name: key, label: key.replace(/[_-]+/g, ' ').replace(/\b\w/g, m => m.toUpperCase()), type: 'text', groupTitle: 'Custom meta' });
    });
    return fields;
  };
  const isRankMathField = key => /^rank[_-]?math/i.test(String(key || '')) || String(key || '').indexOf('rank_math') !== -1;
  const isContentNoiseMetaField = key => {
    const k = String(key || '').toLowerCase();
    return isRankMathField(k) || /(^|_)(views?|view_count|total_views|hits|hit_count|impressions|clicks|analytics|visits|visit_count|read_count|share_count|like_count)(_|$)/i.test(k) || /^(lawp|rankmath|rank_math|wpseo|yoast|aioseo|monsterinsights|analytify|jetpack)_/i.test(k);
  };
  const isReadOnlyRankMathField = key => {
    const k = String(key || '').toLowerCase();
    return k === 'rank_math_internal_links_processed' || k === 'rank_math_analytic_object_id' || k === 'rank_math_seo_score';
  };
  const isSerializedMetaValue = value => {
    const s = String(value == null ? '' : value).trim();
    return /^(a|O|s|i|b|d):\d+[:;]/.test(s) || (s.length > 120 && /[{}";:]/.test(s));
  };
  const getCustomFieldSections = post => {
    const sections = [];
    const custom = [];
    getEditableCustomFields(post).forEach(field => {
      const key = field.name || field.label;
      if (isContentNoiseMetaField(key)) return; // Keep SEO/plugin counters out of normal content fields.
      custom.push(field);
    });
    if (custom.length) sections.push({ title: 'Custom fields', help: 'Fields detected from ACF, JetEngine, or regular WordPress meta for this post type. Values save with the content item.', fields: custom });
    return sections;
  };
  const fieldInput = (field, value, onValue) => {
    const type = String(field.type || 'text').toLowerCase();
    const common = { class: 've-studio-input', value: value == null ? '' : value, onInput: e => onValue(e.target.value), placeholder: field.label || field.name };
    if (isReadOnlyRankMathField(field.name || field.label)) {
      return h('input', { class: 've-studio-input ve-studio-readonly', value: value == null ? '' : value, readOnly: true, disabled: true, title: 'Read-only Rank Math internal field' });
    }
    if (isSerializedMetaValue(value)) return h('textarea', { ...common, class: 've-studio-input ve-studio-textarea ve-field-serialized', style: 'line-height:1.55;resize:vertical' });
    if (type === 'textarea' || type === 'wysiwyg') return h('textarea', { ...common, class: 've-studio-input ve-studio-textarea', style: 'min-height:92px;line-height:1.6;resize:vertical' });
    if (type === 'number' || type === 'range') return h('input', { ...common, type: 'number' });
    if (type === 'true_false' || type === 'boolean' || type === 'checkbox') return h('div', { class: 've-opt ve-opt-toggle ve-field-toggle' },
      h('span', null, field.label || field.name),
      h(ToggleControl, { checked: !!value && value !== '0' && value !== 'false', label: field.label || field.name, onChange: checked => onValue(checked ? '1' : '0') })
    );
    return h('input', { ...common, type: 'text' });
  };

  const saveOptionPage = async e => {
    e.preventDefault();
    if (!activeOptionPage) return;
    setOptionSaveState('Saving...');
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/options/' + encodeURIComponent(activeOptionPage.id), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ post_id: activeOptionPage.post_id || 'options', fields: optionDraft || {} })
      });
      if (res && res.success) {
        setOptionSaveState('Saved');
        flash('Option page saved.');
        await loadMeta();
      } else {
        setOptionSaveState('Save failed');
        flash(res?.message || 'Option page save failed.');
      }
    } catch (err) {
      setOptionSaveState('Save failed');
      flash('Option page save failed.');
    }
    setLoading(false);
  };

  // No Slug column: the slug is already shown under each title, so the column was a
  // duplicate. The SEO column is the score alone — the detail lines moved to the
  // title chips.
  const contentColumnOptions = [
    { key: 'id', label: 'ID' },
    { key: 'status', label: 'Status' },
    { key: 'created', label: 'Created' },
    { key: 'modified', label: 'Last Edited' },
    { key: 'seo', label: 'SEO' },
    { key: 'actions', label: 'Actions' }
  ];
  const setContentColumnSelection = next => {
    const merged = { ...contentColumns, ...next };
    setContentColumns(merged);
    persistUserPreference('ve_content_table_columns', merged);
  };
  const toggleContentColumn = key => setContentColumnSelection({ [key]: !contentColumns[key] });
  const showAllContentColumns = () => setContentColumnSelection(contentColumnOptions.reduce((acc, opt) => ({ ...acc, [opt.key]: true }), {}));
  const hideMetaContentColumns = () => setContentColumnSelection({ id: false, slug: false, created: false, modified: false, seo: false, status: true, actions: true });
  const toPlainText = html => String(html || '').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
  const postWordCount = post => toPlainText(post?.content || '').split(/\s+/).filter(Boolean).length;
  const normalizeKeywords = value => String(value || '').split(',').map(x => x.trim()).filter(Boolean).slice(0, 5);
  const keywordText = keywords => (keywords || []).slice(0, 5).join(', ');
  const primaryKeyword = post => normalizeKeywords(post?.seo_details?.focus_keyword || '')[0] || '';
  const seoSet = (key, value) => {
    setContentEditorSaveState('dirty');
    setEditingPost(v => ({ ...v, seo_details: { ...(v.seo_details || {}), [key]: value } }));
  };
  const resolveSeoTitle = post => {
    const seo = post?.seo_details || {};
    const raw = String(seo.title || '').trim() || String(post?.titleText || '').trim() || 'Untitled';
    const site = seo.site_name || (document?.title ? document.title.split('‹').pop().trim() : '') || window.location.hostname;
    return raw.replace(/%title%/gi, post?.titleText || 'Untitled').replace(/%sitename%/gi, site).replace(/%sep%/gi, '•').replace(/%excerpt%/gi, toPlainText(post?.excerpt || '').slice(0, 160)).trim();
  };
  const resolveSeoDesc = post => {
    const seo = post?.seo_details || {};
    const raw = String(seo.description || '').trim() || String(post?.excerpt || '').trim() || toPlainText(post?.content || '').slice(0, 160);
    return raw.replace(/%excerpt%/gi, toPlainText(post?.excerpt || '').slice(0, 160)).replace(/%title%/gi, post?.titleText || '').trim();
  };
  const permalinkForPreview = post => {
    const link = String(post?.link || window.location.origin || '').split('?')[0];
    const slug = String(post?.slug || '').trim();
    if (!slug) return link || window.location.origin;
    try {
      const u = new URL(link || window.location.origin);
      const parts = u.pathname.split('/').filter(Boolean);
      if (parts.length) parts[parts.length - 1] = slug; else parts.push(slug);
      u.pathname = '/' + parts.join('/') + '/';
      return u.toString();
    } catch (e) {
      return (window.location.origin || '').replace(/\/$/, '') + '/' + slug + '/';
    }
  };
  const socialTitle = (post, network) => String(post?.seo_details?.[network + '_title'] || '').trim() || (network === 'twitter' ? String(post?.seo_details?.facebook_title || '').trim() : '') || resolveSeoTitle(post);
  const socialDescription = (post, network) => String(post?.seo_details?.[network + '_description'] || '').trim() || (network === 'twitter' ? String(post?.seo_details?.facebook_description || '').trim() : '') || resolveSeoDesc(post);
  const socialImage = (post, network) => String(post?.seo_details?.[network + '_image'] || (network === 'twitter' ? post?.seo_details?.facebook_image : '') || post?.seo_details?.opengraph_image || post?.featured_media_url || '').trim();
  const useWpMediaForSeoImage = key => {
    openContentMediaPicker('Choose Open Graph image', url => seoSet(key, url));
  };
  const addFocusKeyword = raw => {
    const next = String(raw || '').split(',').map(x => x.trim()).filter(Boolean);
    if (!next.length) return;
    const current = normalizeKeywords(editingPost?.seo_details?.focus_keyword || '');
    next.forEach(k => { if (current.length < 5 && !current.some(x => x.toLowerCase() === k.toLowerCase())) current.push(k); });
    setContentEditorSaveState('dirty');
    seoSet('focus_keyword', keywordText(current));
  };
  const removeFocusKeyword = index => { const current = normalizeKeywords(editingPost?.seo_details?.focus_keyword || ''); current.splice(index, 1); setContentEditorSaveState('dirty'); seoSet('focus_keyword', keywordText(current)); };
  const toggleRobot = value => {
    const seo = editingPost?.seo_details || {};
    const current = Array.isArray(seo.robots) ? seo.robots.slice() : String(seo.robots || '').split(',').map(x => x.trim()).filter(Boolean);
    const next = current.includes(value) ? current.filter(x => x !== value) : [...current, value];
    seoSet('robots', next);
  };
  const seoInput = (label, key, placeholder = '', opts = {}) => {
    const value = editingPost?.seo_details?.[key] || '';
    const max = opts.max || 0;
    const props = { class: 've-studio-input', value, placeholder, onInput: e => seoSet(key, e.target.value), disabled: !!opts.disabled };
    return h('div', { class: 've-seo-field-row ' + (opts.className || '') },
      h('label', null, h('span', null, label), max ? h('span', { class: 've-seo-count' }, String(value || '').length + ' / ' + max) : null),
      opts.textarea ? h('textarea', { ...props, class: 've-studio-input ve-studio-textarea', style: 'min-height:' + (opts.height || 74) + 'px!important;height:auto!important;max-height:none!important;line-height:1.55;resize:vertical' }) : h('input', props)
    );
  };
  const renderFocusKeywordEditor = () => {
    const kws = normalizeKeywords(editingPost?.seo_details?.focus_keyword || '');
    return h('div', { class: 've-seo-field-row' },
      h('label', null, h('span', null, 'Focus keywords'), h('span', { class: 've-seo-count' }, kws.length + ' / 5 free')),
      h('div', { class: 've-seo-keywords' },
        kws.map((kw, i) => h('span', { class: 've-seo-keyword-pill'+(i===0?' primary':''), key: 'kw-' + kw + i }, i===0&&h('i',{class:'ve-seo-keyword-primary',title:'Primary keyword'}),h('span',{class:'ve-seo-keyword-text'},kw),h('button', { type: 'button', onClick: () => removeFocusKeyword(i), title: 'Remove '+kw }, ph('x')))),
        h('input', { placeholder: kws.length >= 5 ? 'Free limit reached' : 'Type keyword, press Enter', disabled: kws.length >= 5, onKeyDown: e => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); addFocusKeyword(e.currentTarget.value); e.currentTarget.value = ''; } }, onBlur: e => { addFocusKeyword(e.currentTarget.value); e.currentTarget.value = ''; } })
      ),
      h('div', { class: 've-seo-muted-note' }, 'Rank Math free allows up to 5 focus keywords. Content Studio respects that limit for now.')
    );
  };
  const check = (pass, goodText, badText) => ({ pass: !!pass, text: pass ? goodText : (badText || goodText) });
  const buildSeoChecks = post => {
    const keywords = normalizeKeywords(post?.seo_details?.focus_keyword || '').map(x => x.toLowerCase().trim()).filter(Boolean);
    const primary = keywords[0] || '';
    const keywordSlugs = keywords.map(k => k.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')).filter(Boolean);
    const title = resolveSeoTitle(post);
    const titleLower = title.toLowerCase();
    const desc = resolveSeoDesc(post);
    const descLower = desc.toLowerCase();
    const slug = String(post?.slug || '').toLowerCase();
    const contentRaw = String(post?.content || '');
    const content = toPlainText(contentRaw).toLowerCase();
    const wc = postWordCount(post);
    const hasMedia = /<img|<video|<figure|wp:image|wp:video/i.test(contentRaw);
    const paragraphs = contentRaw.split(/<\/p>|\n\n/).map(x => toPlainText(x)).filter(Boolean);
    const hasLongPara = paragraphs.some(p => p.split(/\s+/).filter(Boolean).length > 120);
    const hasToc = /table of contents|rank-math-toc|toc/i.test(contentRaw);
    const positiveNegative = /(best|top|easy|simple|powerful|complete|proven|dangerous|beautiful|avoid|mistakes|worst|fail|secret|ultimate)/i.test(title);
    const powerWord = /(ultimate|proven|powerful|dangerous|secret|complete|beautiful|fast|clean|premium|advanced|essential)/i.test(title);
    const hasKw = !!keywords.length;
    const anyKeywordIn = text => hasKw && keywords.some(k => String(text || '').toLowerCase().includes(k));
    const anyKeywordStarts = text => hasKw && keywords.some(k => String(text || '').toLowerCase().trim().startsWith(k));
    const anyKeywordInUrl = () => hasKw && keywords.some((k, i) => slug.includes(k) || (keywordSlugs[i] && slug.includes(keywordSlugs[i])));
    return [
      ['Basic SEO', [
        check(anyKeywordIn(titleLower), 'Focus keyword found in the SEO title.', hasKw ? 'Focus keyword does not appear in the SEO title.' : 'Add a focus keyword first.'),
        check(anyKeywordIn(descLower), 'Focus keyword found in the SEO description.', hasKw ? 'Add Focus Keyword to your SEO Meta Description.' : 'Add Focus Keyword to your SEO Meta Description.'),
        check(anyKeywordInUrl(), 'Focus keyword found in the URL.', hasKw ? 'Focus keyword not found in the URL.' : 'Add a focus keyword to test the URL.'),
        check(anyKeywordStarts(content), 'Content starts with the focus keyword.', hasKw ? 'Use Focus Keyword at the beginning of your content.' : 'Add a focus keyword to test the content opening.'),
        check(anyKeywordIn(content), 'Focus keyword found in the content.', hasKw ? 'Use Focus Keyword in the content.' : 'Add a focus keyword to test the content.'),
        check(wc >= 600 && wc <= 2500, 'Content length is within the 600–2500 word range.', 'Content should be 600–2500 words long.')
      ]],
      ['Title Readability', [
        check(anyKeywordStarts(titleLower), 'Focus keyword is at the beginning of the SEO title.', hasKw ? 'Focus keyword doesn’t appear at the beginning of SEO title.' : 'Add a focus keyword first.'),
        check(positiveNegative, 'Your title contains a positive or negative sentiment word.', 'Your title doesn’t contain a positive or negative sentiment word.'),
        check(powerWord, 'Your title contains a power word.', 'Your title doesn’t contain a power word. Add at least one.'),
        check(/\d/.test(title), 'Your SEO title contains a number.', 'Your SEO title doesn’t contain a number.')
      ]],
      ['Content Readability', [
        check(hasToc, 'Table of Contents detected.', 'Use Table of Contents to break down your text.'),
        check(!hasLongPara && paragraphs.length > 1, 'Paragraph length looks readable.', 'Add short and concise paragraphs for better readability and UX.'),
        check(hasMedia, 'Media is included in the content.', 'Add a few images and/or videos to make your content appealing.')
      ]]
    ];
  };
  // Content Studio keeps a local analysis score only when Rank Math is absent.
  const liveSeoScore = post => {
    let total = 0, pass = 0;
    buildSeoChecks(post).forEach(cat => cat[1].forEach(r => { total++; if (r.pass) pass++; }));
    return total ? Math.round((pass / total) * 100) : 0;
  };
  const rankMathActive = post => !!(post && post.seo_details && post.seo_details.has_plugin);
  const rankMathAnalysisSignature = post => {
    if (!post) return '';
    const seo = post.seo_details || {};
    return JSON.stringify([
      post.id || 0,
      post.titleText || '',
      post.slug || '',
      post.content || '',
      post.excerpt || '',
      post.featured_media_url || '',
      seo.focus_keyword || '',
      seo.title || '',
      seo.description || '',
      seo.schema || ''
    ]);
  };
  useEffect(() => {
    if (!rankMathActive(editingPost)) {
      setRankMathLiveAnalysis({ key: '', id: 0, score: null, status: 'idle' });
      return;
    }

    const post = editingPost;
    const key = rankMathAnalysisSignature(post);
    let cancelled = false;
    window.__veRankMathDebug = { key, status: 'waiting', runtime: !!window.rankMathAnalyzer, config: !!window.veRankMathAnalysis, error: '' };
    window.mimamVarInspectRankMath = () => ({
      ...(window.__veRankMathDebug || {}),
      runtimeExports: Object.keys(window.rankMathAnalyzer || {}),
      configuredTests: (window.veRankMathAnalysis?.tests || window.rankMath?.assessor?.researchesTests || []).slice()
    });
    // Prints the full per-test comparison against Rank Math's saved score, so any
    // remaining difference can be attributed to a named research rather than guessed.
    window.mimamVarCompareRankMath = () => {
      const d = window.__veRankMathDebug || {};
      const rows = (d.breakdown || []);
      const earned = rows.reduce((sum, r) => sum + (Number(r.score) || 0), 0);
      const possible = rows.reduce((sum, r) => sum + (Number(r.max) || 0), 0);
      console.log('%c[MV] Rank Math score comparison', 'font-weight:bold');
      console.log('MV live score:', d.score, '· Rank Math saved score:', d.savedRankMathScore);
      console.log('Test list source:', d.testsSource, '· tests run:', d.tests, '· deliberately skipped:', d.testsExcluded);
      console.log('Points:', earned, '/', possible, '=', possible ? Math.round((earned / possible) * 100) : null);
      console.log('Keyword:', d.keyword, '· words analysed:', d.words);
      if (console.table) console.table(rows);
      return { score: d.score, saved: d.savedRankMathScore, earned, possible, rows };
    };
    setRankMathLiveAnalysis(current => ({ key, id: (post.id || 0), score: current.id === (post.id || 0) ? current.score : null, status: 'analyzing' }));
    const timer = setTimeout(async () => {
      let runtime = window.rankMathAnalyzer;
      for (let attempt = 0; attempt < 20 && (!runtime || typeof runtime.Analyzer !== 'function' || typeof runtime.Paper !== 'function'); attempt++) {
        await new Promise(resolve => setTimeout(resolve, 100));
        if (cancelled) return;
        runtime = window.rankMathAnalyzer;
      }
      const config = window.veRankMathAnalysis || {};
      if (!runtime || typeof runtime.Analyzer !== 'function' || typeof runtime.Paper !== 'function') {
        window.__veRankMathDebug = { key, status: 'unavailable', runtime: !!runtime, config: !!window.veRankMathAnalysis, error: 'Rank Math analyzer did not expose Analyzer and Paper within 2 seconds.' };
        if (!cancelled) setRankMathLiveAnalysis(current => ({ key, id: (post.id || 0), score: current.id === (post.id || 0) ? current.score : null, status: 'unavailable' }));
        return;
      }
      try {
        const keywords = normalizeKeywords(post?.seo_details?.focus_keyword || '');
        const primary = keywords[0] || '';
        const locale = config.localeFull || window.rankMath?.localeFull || 'en_US';
        // Rank Math's own runtime list wins. Ours is only a fallback for when Rank Math
        // hasn't published one on this screen — using ours over theirs is what made the
        // live score disagree with the score Rank Math's editor reports.
        const rmTests = window.rankMath?.assessor?.researchesTests;
        const tests = (Array.isArray(rmTests) && rmTests.length)
          ? rmTests
          : (Array.isArray(config.tests) && config.tests.length ? config.tests : []);
        // Rank Math analyses rendered content. Raw post_content still carries Gutenberg
        // block delimiters (HTML comments), which skew word count and link/image detection.
        let analyzedText = String(post.content || '').replace(/<!--\s*\/?wp:[\s\S]*?-->/g, '');
        if (window.wp?.autop?.autop) { try { analyzedText = window.wp.autop.autop(analyzedText); } catch (e) {} }
        const paper = new runtime.Paper('', { locale });
        paper.setTitle(resolveSeoTitle(post));
        paper.setPermalink(String(post.slug || ''));
        paper.setDescription(resolveSeoDesc(post));
        paper.setUrl(permalinkForPreview(post));
        paper.setText(analyzedText);
        paper.setKeyword(primary);
        paper.setKeywords(keywords);
        if (post.featured_media_url) paper.setThumbnail(post.featured_media_url);
        const analyzer = new runtime.Analyzer({ i18n: window.wp?.i18n, analyses: tests });
        const results = await analyzer.analyzeSome(tests, paper);
        let score = null;
        if (typeof runtime.ResultManager === 'function') {
          const manager = new runtime.ResultManager();
          manager.update(primary, results || {}, true);
          score = Number(manager.getScore(primary));
        } else {
          let earned = 0;
          let possible = 0;
          const shortLocale = String(locale).split('_')[0];
          Object.keys(results || {}).forEach(name => {
            const result = results[name];
            if (!result) return;
            if (typeof result.getScore === 'function') earned += Number(result.getScore()) || 0;
            if (typeof result.getMaxScore === 'function') possible += Number(result.getMaxScore(shortLocale)) || 0;
          });
          score = possible > 0 ? Math.round((earned / possible) * 100) : null;
        }
        score = Number.isFinite(score) ? Math.max(0, Math.min(100, score)) : null;
        const dbgWords = String(analyzedText).replace(/<[^>]+>/g, ' ').replace(/&[a-z#0-9]+;/gi, ' ').split(/\s+/).filter(Boolean).length;
        // Per-test breakdown: the only way to close a gap against Rank Math's own number
        // with certainty instead of guessing which research disagrees.
        const shortLoc = String(locale).split('_')[0];
        const breakdown = Object.keys(results || {}).map(name => {
          const r = results[name];
          let s = null, m = null, txt = '';
          try { if (r && typeof r.getScore === 'function') s = Number(r.getScore()); } catch (e) {}
          try { if (r && typeof r.getMaxScore === 'function') m = Number(r.getMaxScore(shortLoc)); } catch (e) {}
          try { if (r && typeof r.getText === 'function') txt = String(r.getText() || ''); } catch (e) {}
          return { test: name, score: s, max: m, text: txt.replace(/<[^>]+>/g, '') };
        }).sort((a, b) => a.test.localeCompare(b.test));
        window.__veRankMathDebug = {
          key, status: score === null ? 'unavailable' : 'ready', runtime: true, config: !!window.veRankMathAnalysis,
          testsSource: (Array.isArray(rmTests) && rmTests.length) ? 'rank-math-runtime' : (config.testsSource || 'mv-default-list'),
          testsExcluded: config.testsExcluded || [], tests: tests.length, results: Object.keys(results || {}).length,
          score, savedRankMathScore: rankMathStoredScore(post), words: dbgWords, keyword: primary || '(none)', breakdown,
          error: score === null ? 'Rank Math returned no scoreable results.' : ''
        };
        if (!cancelled) setRankMathLiveAnalysis(current => ({ key, id: (post.id || 0), score: score === null ? current.score : score, status: score === null ? 'unavailable' : 'ready', breakdown }));
      } catch (error) {
        window.__veRankMathDebug = { key, status: 'unavailable', runtime: true, config: !!window.veRankMathAnalysis, error: String(error?.stack || error?.message || error) };
        console.warn('[Mimam’s Var] Rank Math live analysis failed. Run mimamVarInspectRankMath() for details.', error);
        if (!cancelled) setRankMathLiveAnalysis(current => ({ key, id: (post.id || 0), score: current.id === (post.id || 0) ? current.score : null, status: 'unavailable' }));
      }
    }, 260);
    return () => {
      cancelled = true;
      clearTimeout(timer);
    };
  }, [rankMathAnalysisSignature(editingPost), rankMathActive(editingPost)]);
  const rankMathStoredScore = post => {
    const stored = post && post.seo_details ? post.seo_details.score : null;
    return stored !== null && stored !== '' && Number.isFinite(Number(stored)) ? Math.max(0, Math.min(100, Number(stored))) : null;
  };
  // Rank Math's own live analyzer score for THIS post, when the analyzer is loaded
  // and has produced a result — this is Rank Math's engine and it re-runs as you edit.
  const rankMathLiveScoreFor = post => {
    const a = rankMathLiveAnalysis;
    return (a && a.status === 'ready' && a.id === (post && post.id || 0) && Number.isFinite(a.score)) ? Math.max(0, Math.min(100, Number(a.score))) : null;
  };
  // Headline score. Rank Math's *browser analyzer* runs only a subset of the tests its
  // editor runs, so it produced a third number (66) that agreed with neither Rank
  // Math's own score (75) nor the checks listed below it (10/13) — and because it
  // resolves after mount, the card visibly jumped 75 → 66 on open while the note still
  // said 75. It no longer drives the headline. The headline is Rank Math's score when
  // Rank Math is active; the live feedback while editing comes from the passed/to-fix
  // counts and the category meters below, which are Content Studio's own checks.
  // Verified via mimamVarCompareRankMath() on 2026-08-06: MV now runs Rank Math's own
  // runtime test list (20 researches, 100 points) through Rank Math's own analyzer and
  // returns a self-consistent 69/100. Rank Math's stored 75 is the snapshot from the
  // last save, so the two legitimately differ once the content changes — the live
  // number is the accurate one for what's on screen, and saving reconciles them.
  const seoScoreForDisplay = post => {
    if (rankMathActive(post)) {
      const live = rankMathLiveScoreFor(post);
      if (live != null) return live;
      const stored = rankMathStoredScore(post);
      if (stored != null) return stored;
    }
    return liveSeoScore(post);
  };
  // True while Rank Math's analyzer is still running for this post. The gauge shows a
  // placeholder rather than the stored score, so the number never visibly jumps from
  // the saved value to the live one a moment after the card paints.
  const seoScorePending = post => rankMathActive(post)
    && rankMathLiveScoreFor(post) === null
    && rankMathLiveAnalysis.status !== 'unavailable';
  // Pass/fail mark as a controlled inline SVG (the phosphor font glyph rendered off-centre
  // and heavy inside the small circle). currentColor inherits the circle's ink colour.
  const seoMark = pass => h('svg', { viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor', 'stroke-width': '3', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', 'aria-hidden': 'true' }, pass ? h('path', { d: 'M5 12.5l4.5 4.5L19 7' }) : [h('path', { key: 'a', d: 'M6.5 6.5l11 11' }), h('path', { key: 'b', d: 'M17.5 6.5l-11 11' })]);
  // ── SEO analysis "Approach D" (approved from the mock): score gauge + summary
  // on top, segmented category meters below. Categories with issues open by
  // default; all-green categories stay folded to one line.
  // Rank Math's own grouping of its researches. Using this means the gauge, the
  // category meters and the individual lines are all one analysis — previously the
  // score came from Rank Math (20 researches / 100 points) while the meters came from
  // Content Studio's separate 13 checks, so the card contradicted itself (69 vs 10/13).
  const RM_CATEGORIES = [
    ['Basic SEO', ['keywordInTitle', 'keywordInMetaDescription', 'keywordInPermalink', 'keywordIn10Percent', 'keywordInContent', 'lengthContent', 'keywordNotUsed']],
    ['Additional', ['keywordInSubheadings', 'keywordInImageAlt', 'keywordDensity', 'lengthPermalink', 'linksHasInternal', 'linksHasExternals', 'linksNotAllExternals']],
    ['Title Readability', ['titleStartWithKeyword', 'titleSentiment', 'titleHasPowerWords', 'titleHasNumber']],
    ['Content Readability', ['contentHasTOC', 'contentHasShortParagraphs', 'contentHasAssets']]
  ];
  // Rank Math's researches are all-or-nothing in practice, so any awarded point is a pass.
  const rankMathChecks = post => {
    const a = rankMathLiveAnalysis;
    if (!rankMathActive(post) || a.status !== 'ready' || a.id !== (post && post.id || 0) || !Array.isArray(a.breakdown) || !a.breakdown.length) return null;
    const byName = {};
    a.breakdown.forEach(r => { byName[r.test] = r; });
    const used = new Set();
    const groups = RM_CATEGORIES.map(([title, names]) => {
      const rows = names.filter(n => byName[n]).map(n => {
        used.add(n);
        const r = byName[n];
        return { pass: Number(r.score) > 0, text: r.text || n };
      });
      return rows.length ? [title, rows] : null;
    }).filter(Boolean);
    // Anything Rank Math runs that isn't in the map above still has to be shown.
    const extra = a.breakdown.filter(r => !used.has(r.test)).map(r => ({ pass: Number(r.score) > 0, text: r.text || r.test }));
    if (extra.length) groups.push(['Other checks', extra]);
    return groups;
  };
  // One source of truth for the card: Rank Math's researches when live, otherwise
  // Content Studio's own checks (Rank Math inactive or analyzer unavailable).
  const seoChecksForDisplay = post => rankMathChecks(post) || buildSeoChecks(post);
  const seoCheckTotals = post => {
    let total = 0, passed = 0;
    seoChecksForDisplay(post).forEach(cat => cat[1].forEach(r => { total++; if (r.pass) passed++; }));
    return { total, passed, failed: total - passed };
  };
  const renderSeoGauge = post => {
    const pending = seoScorePending(post);
    const score = pending ? null : seoScoreForDisplay(post);
    const { total, passed, failed } = seoCheckTotals(post);
    const pct = score === null ? 0 : Math.max(0, Math.min(100, Number(score)));
    const R = 34, C = 2 * Math.PI * R;
    const verdict = pending ? 'Analysing…' : score === null ? 'Not scored yet' : pct >= 80 ? 'Great' : pct >= 50 ? 'Good — almost there' : 'Needs work';
    const sub = total ? (passed + ' of ' + total + ' checks passing' + (failed ? '. ' + failed + ' to look at.' : '.')) : 'No checks available.';
    return h('div', { class: 've-sd-gauge-row' },
      h('div', { class: 've-sd-gauge' },
        h('svg', { width: '84', height: '84', viewBox: '0 0 84 84' },
          h('circle', { class: 've-sd-g-track', cx: '42', cy: '42', r: String(R) }),
          h('circle', { class: 've-sd-g-fill' + (pct >= 80 ? ' good' : pct >= 50 ? ' warn' : ' bad'), cx: '42', cy: '42', r: String(R), style: 'stroke-dasharray:' + C + ';stroke-dashoffset:' + (C * (1 - pct / 100)) })
        ),
        h('div', { class: 've-sd-g-num' }, h('b', null, pending ? '—' : score === null ? 'N/A' : pct), h('span', null, 'Score'))
      ),
      h('div', { class: 've-sd-gauge-side' },
        h('b', null, verdict),
        h('p', null, sub),
        h('div', { class: 've-sd-chips' },
          h('span', { class: 've-sd-mini' }, h('i', { class: 'ok' }), passed + ' passed'),
          failed > 0 && h('span', { class: 've-sd-mini' }, h('i', { class: 'bad' }), failed + ' to fix')
        )
      )
    );
  };
  const renderSeoMeters = post => h('div', { class: 've-sd-cats' }, seoChecksForDisplay(post).map(([title, rows]) => {
    const total = rows.length; const fails = rows.filter(r => !r.pass).length; const passed = total - fails;
    return h('details', { class: 've-sd-cat' + (fails ? ' has-issues' : ''), open: fails > 0, key: 'sd-' + title },
      h('summary', { class: 've-sd-sum' },
        h('span', { class: 've-sd-name' }, title),
        h('span', { class: 've-sd-bar' }, rows.map((r, i) => h('i', { key: i, class: 've-sd-seg ' + (r.pass ? 'on' : 'off') }))),
        h('span', { class: 've-sd-count' + (fails ? ' warn' : '') }, passed + '/' + total),
        h('span', { class: 've-sd-caret' }, ph('caret-right'))
      ),
      h('div', { class: 've-sd-rows' }, rows.map((r, i) => h('div', { class: 've-sd-row ' + (r.pass ? 'pass' : 'fail'), key: 'sdr' + i },
        h('span', { class: 've-sd-mark' }, seoMark(r.pass)), h('span', null, r.text)
      )))
    );
  }));
  const renderAnalysisPanel = (title, rows) => {
    const errors = rows.filter(r => !r.pass).length;
    const total = rows.length;
    // Collapsible: sections with issues open by default; all-pass sections collapse to
    // a one-line summary so the panel reads as a checklist, not a wall of cards.
    return h('details', { class: 've-seo-analysis' + (errors ? ' has-errors' : ''), open: errors > 0 },
      h('summary', { class: 've-seo-analysis-title' },
        h('span', { class: 've-seo-analysis-caret' }, ph('caret-right')),
        h('span', { class: 've-seo-analysis-name' }, title),
        h('span', { class: 've-seo-analysis-count' }, (total - errors) + '/' + total),
        errors ? h('span', { class: 've-seo-error-pill' }, errors + ' issue' + (errors === 1 ? '' : 's')) : h('span', { class: 've-seo-good-pill' }, seoMark(true), 'All good')
      ),
      h('div', { class: 've-seo-analysis-list' }, rows.map((r, i) => h('div', { class: 've-seo-analysis-row ' + (r.pass ? 'pass' : 'fail'), key: title + i }, h('i', null, seoMark(r.pass)), h('span', null, r.text))))
    );
  };
  const renderSerpPreview = post => h('div', { class: 've-seo-snippet' }, h('div', { class: 've-seo-google-search' }, h('div', { class: 've-seo-google-bar' }, primaryKeyword(post) || post?.titleText || 'Search preview')), h('div', { class: 've-seo-result' }, h('div', { class: 've-seo-result-url' }, permalinkForPreview(post)), h('div', { class: 've-seo-result-title' }, resolveSeoTitle(post)), h('div', { class: 've-seo-result-desc' }, resolveSeoDesc(post) || 'Meta description preview will appear here.')));
  const renderSocialPreview = (post, network = 'facebook') => { const img = socialImage(post, network); return h('div', { class: 've-seo-social-card' }, h('div', { class: 've-seo-social-head' }, network === 'twitter' ? 'X / Twitter Preview' : 'Facebook Preview'), h('div', { class: 've-seo-social-img' }, img ? h('img', { src: img, loading: 'lazy', decoding: 'async' }) : h('span', null, 'Open Graph image preview')), h('div', { class: 've-seo-social-body' }, h('div', { class: 've-seo-social-domain' }, window.location.hostname), h('div', { class: 've-seo-social-title' }, socialTitle(post, network)), h('div', { class: 've-seo-social-desc' }, socialDescription(post, network) || 'Social description preview will appear here.'))); };
  // Which image source a network's preview is currently falling back to (for the note).
  const socialFallbackNote = (post, network) => {
    const seo = (post && post.seo_details) || {};
    const featured = post && post.featured_media_url;
    if (network === 'twitter') {
      if (seo.twitter_image) return '';
      if (seo.facebook_image) return 'Using the Open Graph image. Click the image to set a separate X/Twitter one.';
      if (featured) return 'Using the featured image. Click the image to set a custom X/Twitter one.';
      return 'No image set. Click the image to choose one, or set a featured image.';
    }
    if (seo.facebook_image) return '';
    if (featured) return 'Using the featured image. Click the image to set a custom Open Graph one.';
    return 'No image set. Click the image to choose one, or set a featured image.';
  };
  // The social preview whose image area IS the OG / Twitter image picker (rail SEO tab).
  const renderEditableSocialPreview = (post, network = 'facebook') => {
    const key = network === 'twitter' ? 'twitter_image' : 'facebook_image';
    const custom = (post && post.seo_details && post.seo_details[key]) || '';
    const img = socialImage(post, network);
    const note = socialFallbackNote(post, network);
    const pick = () => useWpMediaForSeoImage(key);
    const clear = () => { setContentEditorSaveState('dirty'); seoSet(key, ''); };
    return h('div', { class: 've-seo-social-card' },
      h('div', { class: 've-seo-social-head' }, network === 'twitter' ? 'X / Twitter Preview' : 'Facebook Preview'),
      h('div', { class: 've-seo-social-img ve-social-img-edit' + (custom ? ' has-thumb' : ''), role: 'button', tabIndex: 0, title: custom ? 'Replace or clear this image' : 'Click to set a custom image', onClick: custom ? null : pick, onKeyDown: e => { if ((e.key === 'Enter' || e.key === ' ') && !custom) { e.preventDefault(); pick(); } } },
        img ? h('img', { src: img, loading: 'lazy', decoding: 'async' }) : h('span', { class: 've-social-img-empty' }, ph('image'), 'Set image'),
        h('div', { class: 've-content-img-overlay' },
          h('button', { type: 'button', class: 've-btn ve-btn-s', onClick: e => { e.stopPropagation(); pick(); } }, ph('image'), img ? 'Replace' : 'Set image'),
          custom && h('button', { type: 'button', class: 've-btn ve-btn-g ve-btn-s', onClick: e => { e.stopPropagation(); clear(); } }, ph('x'), 'Clear')
        )
      ),
      h('div', { class: 've-seo-social-body' },
        h('div', { class: 've-seo-social-domain' }, window.location.hostname),
        h('div', { class: 've-seo-social-title' }, socialTitle(post, network)),
        h('div', { class: 've-seo-social-desc' }, socialDescription(post, network) || 'Social description preview will appear here.')
      ),
      note && h('div', { class: 've-content-og-hint ve-social-fallback-note' }, ph('info'), note)
    );
  };
  const renderSeoEditor = post => {
    if (!post) return null;
    const seo = post.seo_details || {};
    const robots = Array.isArray(seo.robots) ? seo.robots : String(seo.robots || 'index').split(',').map(x => x.trim()).filter(Boolean);
    const tab = seo._tab || 'general';
    const checks = buildSeoChecks(post);
    const robotsChoices = ['index','noindex','nofollow','noarchive','noimageindex','nosnippet'];
    const setTab = next => seoSet('_tab', next);
    return h('details', { class: 've-content-seo-editor', open: true },
      h('summary', null, 'Rank Math SEO + Open Graph'),
      h('div', { class: 've-seo-workspace' },
        h('div', { class: 've-seo-fields' },
          h('div', { class: 've-seo-tabs' }, ['general','social','advanced','schema'].map(t => h('button', { type: 'button', class: tab === t ? 'active' : '', onClick: () => setTab(t), key: 'seo-tab-' + t }, t[0].toUpperCase() + t.slice(1)))),
          tab === 'general' && h('div', { class: 've-seo-fieldset' }, h('div', { class: 've-seo-fieldset-title' }, 'Preview Snippet Editor'), renderFocusKeywordEditor(), seoInput('SEO title', 'title', '%title% %sep% %sitename%', { max: 60 }), seoInput('Meta description', 'description', 'Write the search result description...', { textarea: true, max: 160, height: 150 }), seoInput('Canonical URL', 'canonical_url', 'Optional canonical URL')),
          tab === 'social' && h('div', { class: 've-seo-fieldset' }, h('div', { class: 've-seo-fieldset-title' }, 'Facebook / Open Graph'), seoInput('Facebook title', 'facebook_title', 'Falls back to SEO title'), seoInput('Facebook description', 'facebook_description', 'Falls back to SEO description', { textarea: true, height: 72 }), h('div', { class: 've-seo-field-row' }, h('label', null, h('span', null, 'Facebook image'), h('span', { class: 've-seo-count' }, '1200×630 recommended')), h('div', { class: 've-seo-media-actions' }, h('input', { class: 've-studio-input', value: seo.facebook_image || '', placeholder: 'https://...', onInput: e => seoSet('facebook_image', e.target.value) }), h('button', { type: 'button', class: 've-btn ve-btn-g', onClick: () => useWpMediaForSeoImage('facebook_image') }, 'Choose'))), h('div', { class: 've-seo-fieldset-title', style: 'margin-top:8px' }, 'Twitter / X'), seoInput('Twitter title', 'twitter_title', 'Falls back to Facebook or SEO title'), seoInput('Twitter description', 'twitter_description', 'Falls back to Facebook or SEO description', { textarea: true, height: 72 }), h('div', { class: 've-seo-field-row' }, h('label', null, h('span', null, 'Twitter image'), h('span', { class: 've-seo-count' }, '1200×630 recommended')), h('div', { class: 've-seo-media-actions' }, h('input', { class: 've-studio-input', value: seo.twitter_image || '', placeholder: 'https://...', onInput: e => seoSet('twitter_image', e.target.value) }), h('button', { type: 'button', class: 've-btn ve-btn-g', onClick: () => useWpMediaForSeoImage('twitter_image') }, 'Choose'))), h('label', { class: 've-seo-checkbox-row' }, h('input', { type: 'checkbox', checked: !!seo.facebook_enable_image_overlay, onChange: e => seoSet('facebook_enable_image_overlay', e.target.checked ? 'on' : '') }), 'Add icon overlay to thumbnail')),
          tab === 'advanced' && h('div', { class: 've-seo-fieldset' }, h('div', { class: 've-seo-fieldset-title' }, 'Robots Meta'), h('div', { class: 've-seo-check-grid' }, robotsChoices.map(r => h('label', { key: 'robot-' + r }, h('input', { type: 'checkbox', checked: robots.includes(r), onChange: () => toggleRobot(r) }), r.replace(/^no/i, 'No ')))), h('div', { class: 've-seo-fieldset-title' }, 'Advanced Robots Meta'), h('div', { class: 've-seo-two' }, seoInput('Max snippet', 'max_snippet', '-1'), seoInput('Max video preview', 'max_video_preview', '-1'), h('div', { class: 've-seo-field-row' }, h('label', null, 'Max image preview'), h(SelectMenu, { className: 've-studio-select', value: seo.max_image_preview || 'large', onChange: value => seoSet('max_image_preview', value), options: [{value:'large',label:'Large'}, {value:'standard',label:'Standard'}, {value:'none',label:'None'}] })), seoInput('Redirect destination URL', 'redirect_url', 'https://...')), h('label', { class: 've-seo-checkbox-row' }, h('input', { type: 'checkbox', checked: !!seo.redirect_enabled, onChange: e => seoSet('redirect_enabled', e.target.checked ? '1' : '') }), 'Redirect'), seo.redirect_enabled && h('div', { class: 've-seo-field-row' }, h('label', null, 'Redirection type'), h(SelectMenu, { className: 've-studio-select', value: seo.redirect_type || '301', onChange: value => seoSet('redirect_type', value), options: [{value:'301',label:'301 Permanent Move'}, {value:'302',label:'302 Temporary Move'}, {value:'307',label:'307 Temporary Redirect'}, {value:'410',label:'410 Content Deleted'}, {value:'451',label:'451 Content Unavailable'}] })), h('div', { class: 've-seo-muted-note' }, 'Redirect UI is stored as Rank Math-style metadata for now. Full redirection module integration can come later.')),
          tab === 'schema' && h('div', { class: 've-seo-fieldset' }, h('div', { class: 've-seo-fieldset-title' }, 'Schema'), h('div', { class: 've-seo-field-row' }, h('label', null, 'Schema type'), h(SelectMenu, { className: 've-studio-select', value: seo.schema || 'Article', onChange: value => seoSet('schema', value), options: ['Article','Book','Course','Event','FAQ','HowTo','JobPosting','Movie','Music','Person','Product','Recipe','Restaurant','Service','Software','Video'].map(x => ({ value: x, label: x })) })), h('div', { class: 've-seo-fieldset ve-seo-premium-lock' }, h('div', { class: 've-seo-fieldset-title' }, 'Custom Schema Builder'), h('div', { class: 've-seo-muted-note' }, 'Multiple schemas and advanced custom schema builder are Rank Math Pro-level flows. Content Studio shows the lock for now instead of pretending the free version can edit them.')))
        ),
        h('div', { class: 've-seo-side' }, tab === 'social' ? renderSocialPreview(post, 'facebook') : renderSerpPreview(post), tab === 'social' && renderSocialPreview(post, 'twitter'), checks.map(([title, rows]) => renderAnalysisPanel(title, rows)))
      )
    );
  };

  const activeNavKey = String(activeNav || '');
  const isFieldGroup = activeNavKey.startsWith('acf-') || activeNavKey.startsWith('jet-');
  const isOptionPage = activeNavKey.startsWith('option-');
  const activeOptionPage = isOptionPage ? (meta.option_pages || []).find(page => page.id === activeNavKey) : null;
  const defaultNames = ['page', 'post'];
  const defaultLabelPattern = /^(pages?|posts?)$/i;
  const systemNamePattern = /^(acf-|acf_|wp_|nav_|custom_css|customize_changeset|oembed_cache|user_request|bricks_|ct_|frm_|wpcf7_|jet-|elementor_|revision$)/i;
  const systemLabelPattern = /(taxonom|option pages?|custom fonts?|rm content editor|field groups?|template parts?|navigation)/i;
  const isDefaultish = pt => defaultNames.includes(pt.name) || defaultLabelPattern.test(pt.label || '');
  const defaultCpts = meta.cpts.filter(pt => defaultNames.includes(pt.name));
  const systemCpts = meta.cpts.filter(pt => !isDefaultish(pt) && (pt.is_content === false || systemNamePattern.test(pt.name || '') || systemLabelPattern.test(pt.label || '')));
  const contentCpts = meta.cpts.filter(pt => !isDefaultish(pt) && !systemCpts.some(sys => sys.name === pt.name));
  const toggleContentGroup = key => {
    const next = { ...visibleContentGroups, [key]: !visibleContentGroups[key] };
    setVisibleContentGroups(next);
    persistUserPreference('ve_content_visible_groups_v2', next);
  };
  const navigateCategory = (key) => {
    setCategoryView(key);
    setCatSearch('');
    setShowCptForm(false); setShowTaxForm(false); setShowOptForm(false); setShowFieldGroupForm(false); setShowCreateForm(false); setShowFieldForm(false); setEditingPost(null);
  };
  // Caret toggles collapse; the label opens the category's item list in the main area.
  const sectionTitle = (key, label, canAdd, onAdd) => h('div', { class: 've-studio-nav-title ve-studio-section-title' },
    h('button', { type: 'button', class: 've-section-caret', onClick: (e) => { e.stopPropagation(); toggleContentGroup(key); }, title: visibleContentGroups[key] ? 'Collapse group' : 'Expand group' }, ph(visibleContentGroups[key] ? 'caret-down' : 'caret-right')),
    h('button', { type: 'button', class: 've-section-toggle ve-section-label' + (categoryView === key ? ' active' : ''), onClick: () => navigateCategory(key), title: 'Show all in ' + label }, h('span', null, label)),
    canAdd && h('button', { type: 'button', class: 've-a ve-a-inline', title: 'Create', onClick: onAdd }, ph('plus'))
  );

  const contentImportFieldOptions=[
    {value:'ignore',label:'Ignore column'},{value:'title',label:'Title'},{value:'content',label:'Content'},{value:'excerpt',label:'Excerpt'},
    {value:'slug',label:'Slug'},{value:'status',label:'Status'},{value:'date',label:'Publish date'},{value:'author',label:'Author'},
    {value:'categories',label:'Categories'},{value:'tags',label:'Tags'},{value:'featured_image_url',label:'Featured image URL'},{value:'custom',label:'Custom field'}
  ];
  const contentImportPostTypes=(meta.cpts||[]).filter(type=>type&&type.is_content!==false&&!['attachment','revision','nav_menu_item'].includes(type.name)).map(type=>({value:type.name,label:type.label||formatNavLabel(type.name)}));
  const contentImportAuthorOptions=(meta.authors||[]).map(author=>({value:String(author.id),label:author.name}));
  const resetContentImport=()=>{
    setContentImportStep(0);setContentImportFile(null);setContentImportMapping({});setContentImportPreview(null);setContentImportConfirmation('');setContentImportResult(null);setContentImportError('');setContentImportRunning(false);setContentImportDragging(false);
    if(contentImportFileRef.current)contentImportFileRef.current.value='';
  };
  const openContentImport=()=>{
    const available=contentImportPostTypes.some(type=>type.value===activeNav)?activeNav:(contentImportPostTypes[0]?.value||'post');
    const author=Number(meta.current_user_id||meta.authors?.[0]?.id||0);
    resetContentImport();setContentImportOptions({post_type:available,status:'draft',author,match_slug:true,import_media:true,update_existing:false});setContentImportOpen(true);
  };
  const closeContentImport=()=>{setContentImportOpen(false);resetContentImport();};
  const loadContentImportFile=async file=>{
    setContentImportError('');setContentImportResult(null);setContentImportPreview(null);setContentImportConfirmation('');
    if(!file)return;
    const extension=String(file.name||'').toLowerCase().split('.').pop();
    if(!['csv','tsv'].includes(extension)){setContentImportError('Choose a CSV or TSV file.');return;}
    if(Number(file.size||0)>10*1024*1024){setContentImportError('The file exceeds the 10 MB import limit.');return;}
    try{
      const parsed=parseContentImportText(await file.text(),file.name);
      setContentImportFile({...parsed,size:Number(file.size||0)});setContentImportMapping(defaultContentImportMapping(parsed.headers));setContentImportStep(0);
    }catch(error){setContentImportFile(null);setContentImportMapping({});setContentImportError(error?.message||'Content Studio could not read this file.');}
  };
  const contentImportPayload=()=>({
    file_name:contentImportFile?.name||'content-import.csv',rows:contentImportFile?.rows||[],mapping:contentImportMapping,
    options:{...contentImportOptions,author:Number(contentImportOptions.author||0)}
  });
  const previewContentImport=async()=>{
    if(!contentImportFile)return;
    setContentImportRunning(true);setContentImportError('');setContentImportPreview(null);
    try{
      const response=await api.p('content-studio/import/preview',contentImportPayload());
      if(response?.code)throw new Error(response.message||'The import preview failed.');
      setContentImportPreview(response);setContentImportConfirmation('');setContentImportStep(2);
    }catch(error){setContentImportError(error?.message||'The import preview failed.');}
    setContentImportRunning(false);
  };
  const applyContentImport=async()=>{
    if(!contentImportPreview||contentImportRunning)return;
    if(contentImportConfirmation.trim()!==String(contentImportPreview.confirmation||'')){setContentImportError('Type the exact confirmation phrase to run this import.');return;}
    setContentImportRunning(true);setContentImportError('');setContentImportResult(null);
    try{
      const response=await api.p('content-studio/import/apply',{...contentImportPayload(),confirmation:contentImportConfirmation.trim()});
      if(response?.code)throw new Error(response.message||'The content import failed.');
      setContentImportResult(response);await loadMeta();await loadItems();
    }catch(error){setContentImportError(error?.message||'The content import failed.');}
    setContentImportRunning(false);
  };
  const advanceContentImport=()=>{
    if(contentImportResult){closeContentImport();loadItems();return;}
    if(contentImportStep===0){if(contentImportFile)setContentImportStep(1);return;}
    if(contentImportStep===1){previewContentImport();return;}
    if(contentImportStep===2){setContentImportStep(3);setContentImportError('');return;}
    applyContentImport();
  };
  const contentImportMappingStats=useMemo(()=>{
    const values=Object.values(contentImportMapping||{});return{mapped:values.filter(value=>value!=='ignore'&&value!=='custom').length,custom:values.filter(value=>value==='custom').length,ignored:values.filter(value=>value==='ignore').length};
  },[contentImportMapping]);
  const renderContentImportWorkspace=()=>{
    const summary=contentImportPreview?.summary||{};
    const ready=Number(summary.create||0)+Number(summary.update||0);
    const actionLabel=contentImportResult?'View imported content':contentImportRunning?(contentImportStep===3?'Importing…':'Reviewing…'):contentImportStep===0?'Inspect file':contentImportStep===1?'Review import':contentImportStep===2?'Continue':'Run import';
    const actionIcon=contentImportStep===3?'play':'arrow-right';
    const hint=contentImportResult?'Import complete. The job report has been retained.':contentImportStep===0?(contentImportFile?'The file is ready for column inspection.':'Choose a source file to continue.'):contentImportStep===1?'Review mappings before previewing changes.':contentImportStep===2?(ready+' rows are ready; '+Number(summary.skip||0)+' rows will be skipped.'):'Keep this workspace open while WordPress creates the reviewed content.';
    const pane0=h('section',{class:'ve-ci-pane'},
      h('div',{class:'ve-ci-eyebrow'},'Source file'),h('h3',null,'Bring structured content into WordPress.'),h('p',{class:'ve-ci-lead'},'Start with CSV or TSV. The file is read locally for inspection, then sent only when you review the import.'),
      h('div',{class:'ve-ci-source-grid'},
        h('div',{class:'ve-ci-drop'+(contentImportDragging?' over':''),role:'button',tabIndex:0,onClick:()=>contentImportFileRef.current?.click(),onKeyDown:event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();contentImportFileRef.current?.click();}},onDragOver:event=>{event.preventDefault();setContentImportDragging(true);},onDragLeave:()=>setContentImportDragging(false),onDrop:event=>{event.preventDefault();setContentImportDragging(false);loadContentImportFile(event.dataTransfer?.files?.[0]);}},
          contentImportFile?h('div',null,ph('file-csv'),h('strong',null,contentImportFile.name),h('span',null,contentImportFile.rows.length+' rows · '+contentImportFile.headers.length+' columns · '+contentImportFile.delimiter),h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s'},'Choose another file')):h('div',null,ph('file-arrow-up'),h('strong',null,'Drop a CSV or TSV file here'),h('span',null,'UTF-8, up to 10 MB and 5,000 rows'),h('button',{type:'button',class:'ve-btn ve-btn-primary ve-btn-s'},'Choose file')),
          h('input',{ref:contentImportFileRef,class:'ve-ci-file-input',type:'file',accept:'.csv,.tsv,text/csv,text/tab-separated-values',onChange:event=>loadContentImportFile(event.target.files?.[0])})
        )
      )
    );
    const pane1=h('section',{class:'ve-ci-pane'},
      h('div',{class:'ve-ci-eyebrow'},'Column mapping'),h('h3',null,'Tell Content Studio what each column means.'),h('p',{class:'ve-ci-lead'},'Required fields are mapped automatically. Change any match, ignore unwanted columns, then choose how duplicates and media should be handled.'),
      h('div',{class:'ve-ci-file-ready'},ph('file-csv'),h('div',null,h('b',null,contentImportFile?.name||''),h('small',null,(contentImportFile?.rows?.length||0)+' rows · '+(contentImportFile?.headers?.length||0)+' columns · UTF-8')),h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>setContentImportStep(0)},'Change')),
      h('div',{class:'ve-ci-settings'},
        h('div',{class:'ve-ci-field'},h('label',null,'Import as'),h(SelectMenu,{className:'ve-studio-select',value:contentImportOptions.post_type,onChange:value=>{setContentImportOptions(options=>({...options,post_type:value}));setContentImportPreview(null);},options:contentImportPostTypes})),
        h('div',{class:'ve-ci-field'},h('label',null,'Default status'),h(SelectMenu,{className:'ve-studio-select',value:contentImportOptions.status,onChange:value=>{setContentImportOptions(options=>({...options,status:value}));setContentImportPreview(null);},options:[{value:'draft',label:'Draft'},{value:'pending',label:'Pending review'},{value:'publish',label:'Published'},{value:'private',label:'Private'}]})),
        h('div',{class:'ve-ci-field'},h('label',null,'Default author'),h(SelectMenu,{className:'ve-studio-select',value:String(contentImportOptions.author||''),onChange:value=>{setContentImportOptions(options=>({...options,author:Number(value||0)}));setContentImportPreview(null);},options:contentImportAuthorOptions}))
      ),
      h('div',{class:'ve-ci-section-head'},h('strong',null,'File columns'),h('span',null,contentImportMappingStats.mapped+' mapped, '+contentImportMappingStats.custom+' custom, '+contentImportMappingStats.ignored+' ignored'),h('span',{class:'ve-ci-spacer'}),h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>setContentImportMapping(defaultContentImportMapping(contentImportFile?.headers||[]))},'Reset matches')),
      h('div',{class:'ve-ci-mapping'},(contentImportFile?.headers||[]).map(header=>{
        const field=contentImportMapping[header]||'ignore';const sample=String(contentImportFile?.rows?.[0]?.[header]||'').replace(/\s+/g,' ').slice(0,90);
        const state=field==='title'?['check-circle','Required','']:field==='featured_image_url'?['warning-circle','Remote media','warn']:field==='ignore'?['minus-circle','Ignored','muted']:field==='custom'?['brackets-curly','Custom field','']:['check-circle','Mapped',''];
        return h('div',{class:'ve-ci-map-row',key:header},h('div',{class:'ve-ci-map-source'},h('b',null,header),h('small',null,sample||'Empty sample')),ph('arrow-right',{class:'ve-ci-map-arrow'}),h(SelectMenu,{className:'ve-studio-select',value:field,onChange:value=>{setContentImportMapping(mapping=>({...mapping,[header]:value}));setContentImportPreview(null);},options:contentImportFieldOptions}),h('div',{class:'ve-ci-map-state '+state[2]},ph(state[0]),state[1]));
      })),
      h('div',{class:'ve-ci-options'},
        [['match_slug','Match existing content by slug','Prevents duplicate posts when the same file is imported again.'],['import_media','Import remote media','Downloads mapped images into Media Library and sets the featured image.'],['update_existing','Update existing content','When off, matched rows are skipped and listed in the review.']].map(option=>h('div',{class:'ve-ci-toggle-row',key:option[0]},h('div',null,h('b',null,option[1]),h('small',null,option[2])),h('button',{type:'button',class:'ve-ci-toggle'+(contentImportOptions[option[0]]?'':' off'),'aria-pressed':contentImportOptions[option[0]]?'true':'false',onClick:()=>{setContentImportOptions(options=>({...options,[option[0]]:!options[option[0]]}));setContentImportPreview(null);}})))
      )
    );
    const pane2=h('section',{class:'ve-ci-pane'},
      h('div',{class:'ve-ci-eyebrow'},'Import preview'),h('h3',null,'Review exactly what Content Studio will do.'),h('p',{class:'ve-ci-lead'},'Rows with warnings remain visible. Fix the source or mapping before continuing; nothing is hidden behind a success count.'),
      h('div',{class:'ve-ci-review-grid'},
        h('div',{class:'ve-ci-review-list'},(contentImportPreview?.rows||[]).slice(0,250).map(row=>{const warning=['skip','invalid'].includes(row.action);return h('div',{class:'ve-ci-review-row'+(row.action==='invalid'?' bad':warning?' warn':''),key:row.source_index},ph(row.action==='invalid'?'x':warning?'warning':'check'),h('div',null,h('b',null,row.title),h('small',null,row.reason+' · '+Number(row.categories_count||0)+' categories · '+Number(row.remote_images||0)+' remote images')),h('span',{class:'ve-ci-row-action'},row.action[0].toUpperCase()+row.action.slice(1)));})),
        h('aside',{class:'ve-ci-summary'},h('h4',null,'Import summary'),[['Total rows',summary.total],['Create',summary.create],['Update',summary.update],['Skip',summary.skip],['Invalid',summary.invalid],['Remote images',summary.remote_images]].map(item=>h('div',{class:'ve-ci-summary-row',key:item[0]},h('span',null,item[0]),h('b',null,String(item[1]||0)))),(Number(summary.skip||0)+Number(summary.invalid||0)>0)&&h('div',{class:'ve-ci-attention'},Number(summary.skip||0)+' matching rows will be skipped and '+Number(summary.invalid||0)+' invalid rows will be held back.'))
      )
    );
    const completed=contentImportResult?.summary||{};
    const pane3=h('section',{class:'ve-ci-pane'},
      h('div',{class:'ve-ci-eyebrow'},'Confirm import'),h('h3',null,'Create the reviewed WordPress content.'),h('p',{class:'ve-ci-lead'},'This action can create '+Number(summary.create||0)+', update '+Number(summary.update||0)+', and import '+Number(summary.remote_images||0)+' remote images. The mapping and result report are retained.'),
      h('div',{class:'ve-ci-confirm'},h('h4',null,'Final confirmation'),h('p',null,'Type ',h('b',null,contentImportPreview?.confirmation||''),' to unlock the import. Keep this workspace open while WordPress processes the reviewed rows.'),h('div',{class:'ve-ci-field'},h('label',null,'Confirmation'),h('input',{class:'ve-studio-input',value:contentImportConfirmation,disabled:contentImportRunning||!!contentImportResult,placeholder:contentImportPreview?.confirmation||'',onInput:event=>setContentImportConfirmation(event.target.value)})),h('div',{class:'ve-ci-progress'+(contentImportRunning?' running':contentImportResult?' done':'')},h('i')),
        contentImportResult&&h('div',{class:'ve-ci-result'},ph('check-circle'),h('div',null,h('b',null,'Import complete.'),h('div',null,Number(completed.created||0)+' created, '+Number(completed.updated||0)+' updated, '+Number(completed.skipped||0)+' skipped, '+Number(completed.images_imported||0)+' images imported.'),h('small',null,'Report '+contentImportResult.report_id)))
      )
    );
    return h('section',{class:'ve-content-import-workspace'},
      h('header',{class:'ve-ci-top'},h('button',{type:'button',class:'ve-btn ve-btn-g ve-ci-close','aria-label':'Back to Content Studio',onClick:closeContentImport},ph('arrow-left')),h('div',{class:'ve-ci-top-copy'},h('h2',null,'Import content'),h('p',null,'Inspect and map the file before any WordPress content is created.')),h('span',{class:'ve-ci-spacer'}),h('nav',{class:'ve-ci-steps','aria-label':'Import steps'},['Upload','Map','Review','Import'].map((label,index)=>[index>0&&h('b',{class:'ve-ci-step-line',key:'line-'+index}),h('button',{type:'button',key:label,class:'ve-ci-step'+(contentImportStep===index?' active':contentImportStep>index?' done':''),onClick:()=>{if(index===0||contentImportFile){if(index<=contentImportStep||index===1)setContentImportStep(index);}}},h('i',null,index+1),h('span',null,label))]))),
      h('div',{class:'ve-ci-body'},[pane0,pane1,pane2,pane3][contentImportStep],contentImportError&&h('div',{class:'ve-ci-error'},contentImportError)),
      h('footer',{class:'ve-ci-actions'},h('span',{class:'hint'},hint),h('span',{class:'ve-ci-spacer'}),contentImportStep>0&&!contentImportRunning&&!contentImportResult&&h('button',{type:'button',class:'ve-btn ve-btn-g',onClick:()=>{setContentImportError('');setContentImportStep(step=>Math.max(0,step-1));}},ph('arrow-left'),'Back'),h('button',{type:'button',class:'ve-btn ve-btn-primary',disabled:contentImportRunning||(contentImportStep===0&&!contentImportFile),onClick:advanceContentImport},actionLabel,!contentImportRunning&&!contentImportResult&&ph(actionIcon)))
    );
  };

  return h('div', { ref: csRootRef, class: 've-studio-layout ve-content-studio' + (editingPost ? ' ve-content-editing ve-cs-' + (contentMediaPicker ? 'dark' : csTheme) : '') + (contentImportOpen ? ' ve-content-importing' : '') },
    contentMediaPicker && h(ContentMediaPicker, {
      title: contentMediaPicker.title,
      flash,
      onClose: () => setContentMediaPicker(null),
      onSelect: (url, item) => {
        const fn = contentMediaPicker && contentMediaPicker.onSelect;
        setContentMediaPicker(null);
        if (typeof fn === 'function') fn(url, item);
      }
    }),
    pendingDeleteCS && h(ConfirmModal, { title: pendingDeleteCS.__trashOnly ? 'Move to Trash' : 'Delete Content', body: pendingDeleteCS.__trashOnly ? 'Move this content item to Trash? You can restore it from the Trash filter.' : 'Are you sure you want to permanently delete this content?', confirmText: pendingDeleteCS.__trashOnly ? 'Move to Trash' : 'Delete', danger: true, onCancel: () => setPendingDeleteCS(null), onConfirm: confirmDeleteCS }),
    pendingDeleteCptCS && h(ConfirmModal, { title: 'Delete Post Type', body: 'Are you sure you want to permanently delete CPT "' + pendingDeleteCptCS + '"?', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteCptCS(null), onConfirm: confirmDeleteCptCS }),
    pendingDeleteTax && h(ConfirmModal, { title: 'Delete Taxonomy', body: 'Remove the ACF taxonomy "' + pendingDeleteTax + '"? Existing terms are not deleted, but WordPress will stop registering this taxonomy.', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteTax(null), onConfirm: confirmDeleteTax }),
    pendingDeleteOpt && h(ConfirmModal, { title: 'Delete Options Page', body: 'Remove the ACF options page "' + pendingDeleteOpt + '"? Stored option values are not deleted, but the admin page will stop being registered.', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteOpt(null), onConfirm: confirmDeleteOpt }),
    pendingDeleteFgCS && h(ConfirmModal, { title: 'Delete Field Group', body: 'Are you sure you want to delete this custom field group?', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteFgCS(null), onConfirm: confirmDeleteFgCS }),
    pendingDeleteFieldCS && h(ConfirmModal, { title: 'Delete Field', body: 'Are you sure you want to delete field "' + pendingDeleteFieldCS + '"?', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteFieldCS(null), onConfirm: confirmDeleteFieldCS }),
    pendingContentImageDelete && h(ConfirmModal,{title:'Remove image block',body:'Remove this image from the post content? The Media Library file will not be deleted.',confirmText:'Remove image',danger:true,onCancel:()=>setPendingContentImageDelete(false),onConfirm:deleteSelectedContentImage}),
    // 1. Sidebar
    !editingPost && h('div', { class: 've-studio-sidebar' },
      h('div', { style: 'flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:16px;padding-right:2px' },
        // Default Content Types
        h('div', { class: 've-studio-nav' },
          sectionTitle('default', 'Default Content Types'),
          visibleContentGroups.default && ['page', 'post'].map(k => {
            const cpt = meta.cpts.find(pt => pt.name === k);
            return h('div', {
              key: k,
              class: 've-studio-nav-item' + (activeNav === k && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm ? ' active' : ''),
              onClick: () => selectContentNav(k)
            },
              h('span', { style: 'display:flex;align-items:center;gap:8px' },
                ph(k === 'page' ? 'file' : 'article'),
                formatNavLabel(k)
              ),
              h('span', { class: 've-studio-badge' }, (activeNav === k && loading) ? '...' : (cpt ? cpt.count : '0'))
            );
          })
        ),
        // Custom Post Types
        h('div', { class: 've-studio-nav' },
          sectionTitle('custom', 'Custom Post Types', (meta.acf_active || meta.jet_active), startNewCpt),
          visibleContentGroups.custom && (contentCpts.length ? contentCpts.map(cpt => h('div', {
            key: cpt.name,
            class: 've-studio-nav-item ve-nav-item-cpt' + (activeNav === cpt.name && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm ? ' active' : ''),
            onClick: () => selectContentNav(cpt.name)
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' },
              ph('circles-three-plus'),
              h('span', { style: 'overflow:hidden;text-overflow:ellipsis' }, cpt.label),
              cpt.source !== 'wp' && h('span', {
                style: 'font-size:11px;padding:1px 4px;border-radius:4px;background:' + (cpt.source === 'acf' ? 'rgba(57,112,245,0.15)' : 'rgba(186,244,0,0.15)') + ';color:' + (cpt.source === 'acf' ? '#4f8bff' : '#baf400') + ';font-weight:700;margin-left:4px'
              }, cpt.source.toUpperCase())
            ),
            h('div', { style: 'display:flex;align-items:center;gap:6px' },
              h('span', { class: 've-studio-badge' }, cpt.count),
              cpt.source !== 'wp' && h('button', {
                class: 've-nav-delete-btn',
                title: 'Edit post type',
                style: 'border:none;background:none;padding:0;cursor:pointer;color:#baf400;opacity:0;transition:opacity 0.2s;display:flex;align-items:center',
                onClick: (e) => startEditCpt(e, cpt)
              }, ph('pencil-simple')),
              cpt.source !== 'wp' && h('button', {
                class: 've-nav-delete-btn',
                title: 'Delete post type',
                style: 'border:none;background:none;padding:0;cursor:pointer;color:#ff4d4d;opacity:0;transition:opacity 0.2s;display:flex;align-items:center',
                onClick: (e) => handleDeleteCpt(e, cpt.name)
              }, ph('trash'))
            )
          )) : h('div', { class: 've-empty ve-empty-inline' }, 'No custom content types detected.'))
        ),
        // Taxonomies (#8) — click a taxonomy to open its editor.
        h('div', { class: 've-studio-nav' },
          sectionTitle('taxonomies', 'Taxonomies', meta.acf_active, startNewTax),
          visibleContentGroups.taxonomies && ((meta.taxonomies_list || []).length ? (meta.taxonomies_list || []).map(tax => h('div', {
            key: tax.name,
            class: 've-studio-nav-item ve-nav-item-cpt' + (editingTaxName === tax.name && showTaxForm ? ' active' : ''),
            onClick: (e) => startEditTax(e, tax)
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' },
              ph('tag'),
              h('span', { style: 'overflow:hidden;text-overflow:ellipsis' }, tax.label),
              tax.source && tax.source !== 'wp' && h('span', {
                style: 'font-size:11px;padding:1px 4px;border-radius:4px;background:rgba(57,112,245,0.15);color:#4f8bff;font-weight:700;margin-left:4px'
              }, String(tax.source).toUpperCase())
            ),
            h('div', { style: 'display:flex;align-items:center;gap:6px' },
              h('span', { class: 've-studio-badge' }, tax.count),
              tax.source === 'acf' && h('button', {
                class: 've-nav-delete-btn',
                title: 'Delete taxonomy',
                style: 'border:none;background:none;padding:0;cursor:pointer;color:#ff4d4d;opacity:0;transition:opacity 0.2s;display:flex;align-items:center',
                onClick: (e) => handleDeleteTax(e, tax.name)
              }, ph('trash'))
            )
          )) : h('div', { class: 've-empty ve-empty-inline' }, 'No custom taxonomies detected.'))
        ),
        meta.acf_active && h('div', { class: 've-studio-nav' },
          sectionTitle('options', 'Options Pages', meta.acf_active, startNewOpt),
          visibleContentGroups.options && ((meta.option_pages || []).length ? (meta.option_pages || []).map(page => h('div', {
            key: page.id,
            class: 've-studio-nav-item ve-nav-item-cpt' + (activeNav === page.id ? ' active' : ''),
            onClick: () => selectContentNav(page.id)
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' },
              ph('sliders-horizontal'),
              h('span', { style: 'overflow:hidden;text-overflow:ellipsis' }, page.label || page.slug),
              h('span', { style: 'font-size:11px;padding:1px 4px;border-radius:4px;background:rgba(57,112,245,0.15);color:#4f8bff;font-weight:700;margin-left:4px' }, 'ACF')
            ),
            h('div', { style: 'display:flex;align-items:center;gap:6px' },
              h('span', { class: 've-studio-badge' }, (page.fields || []).length),
              page.editable !== false && h('button', {
                class: 've-nav-delete-btn', title: 'Edit options page',
                style: 'border:none;background:none;padding:0;cursor:pointer;color:#baf400;opacity:0;transition:opacity 0.2s;display:flex;align-items:center',
                onClick: (e) => startEditOpt(e, page)
              }, ph('pencil-simple')),
              page.editable !== false && h('button', {
                class: 've-nav-delete-btn', title: 'Delete options page',
                style: 'border:none;background:none;padding:0;cursor:pointer;color:#ff4d4d;opacity:0;transition:opacity 0.2s;display:flex;align-items:center',
                onClick: (e) => handleDeleteOpt(e, page.slug)
              }, ph('trash'))
            )
          )) : h('div', { class: 've-empty ve-empty-inline' }, 'No ACF option pages detected.'))
        ),
        /* Plugin/System Types intentionally hidden for now. Content Studio should stay focused on real content records and custom fields. */
        // Custom Field Groups
        h('div', { class: 've-studio-nav' },
          sectionTitle('fields', 'Custom Field Groups', (meta.acf_active || meta.jet_active), () => {
            setShowFieldGroupForm(true);
            setShowCptForm(false);
          }),
          visibleContentGroups.fields && meta.field_groups.map(group => h('div', {
            key: group.id,
            class: 've-studio-nav-item ve-nav-item-cpt' + (activeNav === group.id && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm ? ' active' : ''),
            onClick: () => selectContentNav(group.id)
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' },
              ph('gear'),
              h('span', { style: 'overflow:hidden;text-overflow:ellipsis' }, group.title),
              h('span', {
                style: 'font-size:11px;padding:1px 4px;border-radius:4px;background:' + (group.source === 'acf' ? 'rgba(57,112,245,0.15)' : 'rgba(186,244,0,0.15)') + ';color:' + (group.source === 'acf' ? '#4f8bff' : '#baf400') + ';font-weight:700;margin-left:4px'
              }, group.source.toUpperCase())
            ),
            h('div', { style: 'display:flex;align-items:center;gap:6px' },
              h('span', { class: 've-studio-badge' }, (group.fields || []).length),
              h('button', {
                class: 've-nav-delete-btn',
                title: 'Delete field group',
                style: 'border:none;background:none;padding:0;cursor:pointer;color:#ff4d4d;opacity:0;transition:opacity 0.2s;display:flex;align-items:center',
                onClick: (e) => handleDeleteFieldGroup(e, group.id)
              }, ph('trash'))
            )
          ))
        )
      )
    ),
    // 2. Main Area
    h('div', { class: 've-studio-main' },
      contentImportOpen && renderContentImportWorkspace(),
      !editingPost && !categoryView && h('div', { style: 'display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;gap:12px' },
        h('div', null,
          h('h2', { style: 'margin:0;font-size:16px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px' },
            showOptForm ? (editingOptSlug ? 'Edit Options Page' : 'Register Options Page') : showTaxForm ? (editingTaxName ? 'Edit Taxonomy' : 'Register Taxonomy') : showCptForm ? (editingCptName ? 'Edit Custom Post Type' : 'Register Custom Post Type') : (showFieldGroupForm ? 'Create Custom Field Group' : formatNavLabel(activeNav)),
            !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm && h('span', { style: 'font-size:11px;font-weight:400;color:#888;background:rgba(255,255,255,0.04);padding:2px 8px;border-radius:10px' }, `${filtered.length} items`)
          )
        ),
        h('div', { class: 've-content-tools' },
          !isFieldGroup && !isOptionPage && !categoryView && !showCreateForm && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm && !showFieldForm && !editingPost && renderContentViewSwitcher(),
          !isFieldGroup && !isOptionPage && !categoryView && !showCreateForm && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm && !showFieldForm && !editingPost && renderContentFocusControl(),
          !showCreateForm && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm && !showFieldForm && h('input', {
            class: 've-studio-input',
            style: 'width:220px',
            placeholder: 'Search...',
            value: search,
            onInput: e => setSearch(e.target.value)
          }),
          !isFieldGroup && !isOptionPage && contentView === 'list' && !showCreateForm && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm && !showFieldForm && !editingPost && h('div', { class: 've-content-column-pop-wrap' },
            h('button', { type: 'button', class: 've-btn ve-btn-g ve-btn-s ve-content-column-trigger', title: 'Choose table columns', 'aria-label': 'Choose table columns', onClick: () => setContentColumnPanelOpen(v => !v) }, ph('table', { 'aria-hidden': 'true' })),
            contentColumnPanelOpen && h('div', { class: 've-content-column-pop' },
              h('div', { class: 've-content-column-pop-head' }, h('span', null, 'Table columns'), h('button', { type: 'button', class: 've-a', onClick: () => setContentColumnPanelOpen(false) }, ph('x'))),
              contentColumnOptions.map(opt => h(CheckControl, { key: opt.key, className: 've-content-column-pop-row', checked: !!contentColumns[opt.key], onChange: () => toggleContentColumn(opt.key), title: opt.label, label: opt.label })),
              h('div', { class: 've-content-column-actions' },
                h('button', { type: 'button', onClick: showAllContentColumns }, 'Show all'),
                h('button', { type: 'button', onClick: hideMetaContentColumns }, 'Compact')
              )
            )
          ),
          // Actions for CPTs
          !isFieldGroup && !isOptionPage && !showCreateForm && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm && !showFieldForm && !editingPost && h('button', {
            type:'button',class:'ve-btn ve-btn-g ve-btn-s',onClick:openContentImport
          },ph('upload-simple'),'Import'),
          !isFieldGroup && !isOptionPage && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm && h('button', {
            class: 've-btn ve-btn-s',
            onClick: startStudioCreate
          }, '+ Add New'),
          // Actions for Field Groups
          isFieldGroup && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm && h('button', {
            class: 've-btn ve-btn-s ' + (showFieldForm ? 've-btn-g' : ''),
            onClick: () => setShowFieldForm(prev => {
              if (prev) {
                setEditingFieldName('');
                setFieldName('');
                setFieldLabel('');
                setFieldType('text');
              }
              return !prev;
            })
          }, showFieldForm ? 'Back to List' : '+ Add Field'),
          // Save the Live Preview builder's field list back through ACF.
          isFieldGroup && !showFieldForm && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm && h('button', {
            class: 've-btn ve-btn-s' + (fgDirty ? '' : ' ve-btn-g'),
            disabled: fgSaving || !fgDirty,
            onClick: saveFieldGroupFields,
            title: fgDirty ? 'Save field changes to ACF' : 'No unsaved field changes'
          }, fgSaving ? 'Saving…' : (fgDirty ? 'Save fields' : 'Saved'))
        )
      ),
      !isFieldGroup && !isOptionPage && !categoryView && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm && !showCreateForm && !showFieldForm && !editingPost && h('div', { class: 've-content-dashboard' },
        contentDashboardCards.map(card => h('button', { key: card.key, type: 'button', class: 've-content-stat-card' + (contentStatusFilter === card.key ? ' active' : ''), onClick: () => setContentStatus(card.key), title: 'Show ' + card.label.toLowerCase() },
          h('strong', null, card.value), h('span', null, card.label)
        ))
      ),
      !isFieldGroup && !isOptionPage && !categoryView && !showCptForm && !showTaxForm && !showOptForm && !showFieldGroupForm && !showCreateForm && !showFieldForm && !editingPost && h('div', { class: 've-content-status-tabs' },
        [
          { value: 'active', label: 'Active' },
          { value: 'all', label: 'All' },
          { value: 'publish', label: 'Published' },
          { value: 'draft', label: 'Drafts' },
          { value: 'pending', label: 'Pending' },
          { value: 'private', label: 'Private' },
          { value: 'trash', label: 'Trash' }
        ].map(opt => h('button', { key: opt.value, type: 'button', class: contentStatusFilter === opt.value ? 'active' : '', onClick: () => setContentStatus(opt.value) }, h('span', null, opt.label), h('em', null, String(contentStatusCounts[opt.value] || 0))))
      ),

      // ── Form: Register CPT ──
      showOptForm ? renderOptEditor() :
      showTaxForm ? renderTaxEditor() :
      showCptForm ? renderCptEditor() :

      // ── Form: Create Field Group ──
      showFieldGroupForm ? h('form', { onSubmit: handleCreateFieldGroup, style: 'max-width:500px;display:flex;flex-direction:column;gap:14px;background:rgba(255,255,255,0.01);border:1px solid rgba(255,255,255,0.05);border-radius:10px;padding:20px' },
        // This screen only starts the group. Fields and the full ACF settings —
        // Location Rules, Presentation, Group Settings — are edited straight after.
        h('div', { class: 've-fg-createnote' },
          ph('info'),
          h('div', null,
            h('b', null, 'This creates the group and opens the builder.'),
            h('span', null, 'Fields, Location Rules, Presentation and Group Settings are all edited there — the post types below just seed the first location rule.')
          )
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Group Title'),
          h('input', {
            class: 've-studio-input',
            required: true,
            value: groupTitle,
            onInput: e => setGroupTitle(e.target.value),
            placeholder: 'e.g. Project Specs'
          })
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Show on post types (starting location rule)'),
          h('div', { class: 've-check-list ve-scroll-custom' },
            [...defaultCpts, ...contentCpts].map(pt => h(CheckControl, {
              key: pt.name,
              checked: groupTargets.includes(pt.name),
              label: pt.label + ' (' + pt.name + ')',
              onChange: checked => {
                if (checked) setGroupTargets([...groupTargets, pt.name]);
                else setGroupTargets(groupTargets.filter(x => x !== pt.name));
              }
            }))
          )
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Provider'),
          h(SelectMenu, { className: 've-studio-select', value: groupSource, onChange: setGroupSource, options: [
            meta.acf_active && { value: 'acf', label: 'Advanced Custom Fields (ACF)' },
            meta.jet_active && { value: 'jet', label: 'JetEngine' }
          ].filter(Boolean) })
        ),
        h('div', { style: 'display:flex;gap:8px;margin-top:8px' },
          h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:600;flex:1' }, loading ? 'Creating...' : 'Create Field Group'),
          h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => setShowFieldGroupForm(false) }, 'Cancel')
        )
      ) :

      // ── Category list (#8): clicking a section header lists its items ──
      categoryView ? renderCategoryList() :

      // ── Form: Create Post inside CPT ──
      !isFieldGroup && !isOptionPage && showCreateForm ? h('form', { onSubmit: handleCreate, class: 've-content-create-form' },
        newPost ? h('div', { style: 'background:rgba(186,244,0,0.1);border:1px solid #baf400;border-radius:10px;padding:16px;text-align:center' },
          h('div', { style: 'color:#baf400;font-weight:800;margin-bottom:8px;font-size:13px' }, 'Content created'),
          h('div', { style: 'color:#fff;font-size:12px;margin-bottom:12px;font-weight:700' }, newPost.title?.rendered),
          h('div', { style: 'display:flex;gap:8px;justify-content:center;flex-wrap:wrap' },
            h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:34px', onClick: () => { setNewPost(null); setShowCreateForm(false); } }, 'Back to list'),
            h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:34px', onClick: () => startStudioEdit(newPost) }, 'Edit in Studio'),
            canEditWithBricks(newPost) && h('a', { class: 've-btn ve-btn-primary', style: 'height:34px;text-decoration:none;display:inline-flex;align-items:center;color:#1f1f1f;font-weight:700', href: newPost.bricks_link, target: '_blank' }, 'Open in Bricks'),
            newPost.edit_link && h('a', { class: 've-btn ve-btn-g', style: 'height:34px;text-decoration:none;display:inline-flex;align-items:center', href: newPost.edit_link, target: '_blank' }, 'Open WP editor')
          )
        ) : [
          h('div', { class: 've-content-create-grid' },
            h('div', null,
              h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Title'),
              h('input', { class: 've-studio-input', required: true, value: createDraft.title, onInput: e => setCreateDraft(v => ({ ...v, title: e.target.value, slug: v.slugManuallyEdited ? v.slug : contentTitleSlug(e.target.value) })), placeholder: 'e.g. New ' + formatNavLabel(activeNav) })
            ),
            h('div', null,
              h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Status'),
              h(SelectMenu, { className: 've-studio-select', value: createDraft.status || 'draft', onChange: value => setCreateDraft(v => ({ ...v, status: value })), options: [{ value: 'draft', label: 'Draft' }, { value: 'publish', label: 'Publish' }, { value: 'pending', label: 'Pending' }, { value: 'private', label: 'Private' }] })
            )
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Slug (optional)'),
            h('input', { class: 've-studio-input', value: createDraft.slug || '', onInput: e => setCreateDraft(v => ({ ...v, slug: contentTitleSlug(e.target.value), slugManuallyEdited: true })), placeholder: 'auto-generated from title' })
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Excerpt'),
            h('textarea', { class: 've-studio-input ve-studio-textarea', value: createDraft.excerpt || '', onInput: e => setCreateDraft(v => ({ ...v, excerpt: e.target.value })), placeholder: 'Optional short summary...', style: 'min-height:76px;line-height:1.55;resize:vertical' })
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Content'),
            h(RichContentEditor, { value: createDraft.content || '', onChange: html => setCreateDraft(v => ({ ...v, content: html })), onChooseImage: cb => openContentMediaPicker('Choose content image', cb), theme: csTheme, onTheme: applyCsTheme })
          ),
          h('div', { class: 've-content-create-actions' },
            h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => { setShowCreateForm(false); setNewPost(null); } }, 'Cancel'),
            h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:800;min-width:150px' }, loading ? 'Creating...' : 'Create Content')
          )
        ]
      ) :

      // ── Form: Create Custom Field inside Field Group ──
      isFieldGroup && showFieldForm ? h('form', { onSubmit: handleCreateField, class: 've-content-field-edit-form' },
        h('div', { class: 've-content-field-edit-main ve-scroll-custom' },
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Field Name (Key/Slug)'),
            h('input', {
              class: 've-studio-input',
              required: true,
              value: fieldName,
              onInput: e => setFieldName(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '')),
              placeholder: 'e.g. project_cost'
            })
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Field Label'),
            h('input', {
              class: 've-studio-input',
              required: true,
              value: fieldLabel,
              onInput: e => setFieldLabel(e.target.value),
              placeholder: 'e.g. Project Cost'
            })
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Field Type'),
            h(SelectMenu, { className: 've-studio-select', value: fieldType, onChange: setFieldType, options: [
              { value: 'text', label: 'Text' },
              { value: 'textarea', label: 'Text Area' },
              { value: 'number', label: 'Number' },
              { value: 'image', label: 'Image' },
              { value: 'select', label: 'Select / Dropdown' },
              { value: 'boolean', label: 'True / False' }
            ] })
          )
        ),
        h('div', { class: 've-content-field-edit-actions' },
          h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:38px;color:#1f1f1f;font-weight:600;flex:1' }, loading ? 'Saving...' : (editingFieldName ? 'Save Field' : 'Add Field')),
          h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:38px', onClick: () => { setEditingFieldName(''); setShowFieldForm(false); } }, 'Cancel')
        )
      ) :

      isOptionPage && activeOptionPage ? h('form', { onSubmit: saveOptionPage, class: 've-content-edit-form' },
        h('div', { class: 've-content-edit-scroll ve-scroll-custom' },
          h('div', { class: 've-content-editor-note' }, 'ACF Options Pages store global site settings, not normal posts. Edit them here when they are content-related; use ACF when changing field structure.'),
          h('div', { class: 've-content-custom-grid' },
            (filtered || []).map(field => h('div', { key: 'option-field-' + field.name },
              h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, field.label || field.name),
              fieldInput(field, optionDraft[field.name], next => setOptionDraft(v => ({ ...(v || {}), [field.name]: next }))),
              h('div', { class: 've-content-field-help' }, 'ACF option · ' + (field.type || 'text'))
            ))
          ),
          optionSaveState && h('div', { class: 've-content-field-help-muted' }, optionSaveState)
        ),
        h('div', { class: 've-content-edit-actions' },
          h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:700;min-width:150px' }, loading ? 'Saving...' : 'Save Options')
        )
      ) :

      editingPost ? h('form', { onSubmit: saveContentEdit, class: 've-content-edit-form ve-content-editor-redesign' + (contentEditorFocus?' is-focus':'') + (contentEditorPreview?' is-preview dev-'+contentEditorDevice:'') },
        h('div',{class:'ve-content-editor-topbar'},
          !contentEditorPreview&&h('button',{type:'button',class:'ve-btn ve-btn-g ve-content-editor-back','aria-label':'Back to content list',onClick:()=>{setEditingPost(null);setContentEditorFocus(false);setContentEditorPreview(false);}},ph('caret-left'),'Content'),
          h('div',{class:'ve-content-editor-topbar-title'},h('strong',null,editingPost.titleText||(editingPost.__isNew?'New '+formatNavLabel(editingPost.post_type||activeNav):'Untitled'))),
          renderContentThemeToggle(),
          contentEditorPreview&&h('button',{type:'button',class:'ve-btn ve-btn-g ve-content-preview-back',onClick:()=>setContentPreviewMode(false)},ph('caret-left'),'Back to editor'),
          contentEditorPreview&&h('div',{class:'ve-content-device-switch',role:'group','aria-label':'Preview size'},['desktop','tablet','mobile'].map(device=>h('button',{type:'button',key:device,class:contentEditorDevice===device?'on':'','aria-pressed':contentEditorDevice===device?'true':'false',onClick:()=>setContentEditorDevice(device)},ph(device),device[0].toUpperCase()+device.slice(1)))),
          !contentEditorPreview&&h('button',{type:'button',class:'ve-btn ve-btn-g',onClick:()=>setContentPreviewMode(true)},ph('play'),h('span',{class:'ve-content-editor-topbar-label'},'Preview')),
          !contentEditorPreview&&h('button',{type:'button',class:'ve-btn ve-btn-g'+(contentEditorFocus?' active':''),onClick:()=>setContentEditorFocus(value=>!value)},ph(contentEditorFocus?'corners-in':'corners-out'),h('span',{class:'ve-content-editor-topbar-label'},'Focus')),
          !contentEditorPreview&&h('span',{class:'ve-content-save-state '+contentEditorSaveState},contentEditorSaveState==='saving'?'Saving…':contentEditorSaveState==='error'?'Not saved':editingPost.__isNew?'New':'Saved'),
          !contentEditorPreview&&h('button',{type:'button',class:'ve-btn ve-btn-primary',disabled:loading,onClick:event=>saveContentEdit(event,editingPost.__isNew?undefined:'publish')},loading?'Saving…':editingPost.__isNew?'Create':editingPost.status==='publish'?'Update':'Publish')
        ),
        !contentEditorPreview&&h('div',{class:'ve-content-editor-notice'},ph('sidebar-simple'),contentEditorSelection
          ?(contentEditorSelection==='content'?'Editing body content. Use the toolbar above, or choose Publish / SEO for post settings.':'Editing '+(contentEditorSelection==='title'?'title':contentEditorSelection==='excerpt'?'excerpt':'selected block')+'.')
          :'Editing whole page — nothing selected. Click a block to edit it, or use Publish / SEO.'),
        h('div',{class:'ve-content-editor-layout'},
          h('aside',{class:'ve-content-editor-outline'},
            h('div',{class:'ve-content-editor-side-head'},h('strong',null,'Structure'),h('span',{class:'ve-content-outline-tools'},
              h('button',{type:'button',class:(contentOutlineCollapsed?'on ':'')+'ve-tip-bottom','data-ve-tip':contentOutlineCollapsed?'Expand nested rows':'Collapse nested rows','aria-label':contentOutlineCollapsed?'Expand nested rows':'Collapse nested rows',onClick:()=>setContentOutlineCollapsed(value=>!value)},ph(contentOutlineCollapsed?'arrows-out-line-vertical':'arrows-in-line-vertical')),
              h('button',{type:'button',class:contentOutlineSearchOpen?'on':'',title:'Search structure',onClick:()=>{setContentOutlineSearchOpen(value=>!value);if(contentOutlineSearchOpen)setContentOutlineQuery('');}},ph('magnifying-glass')),
              h('div',{class:'ve-content-add-block-wrap',ref:contentAddBlockRef},
                h('button',{type:'button',class:contentAddBlockOpen?'on':'',title:'Add block','aria-expanded':contentAddBlockOpen?'true':'false',onClick:()=>setContentAddBlockOpen(open=>!open)},ph('plus')),
                renderContentAddBlockMenu()
              )
            )),
            contentOutlineSearchOpen&&h('div',{class:'ve-content-outline-search'},h('input',{autoFocus:true,value:contentOutlineQuery,placeholder:'Search structure…',onInput:event=>setContentOutlineQuery(event.target.value)})),
            h('div',{class:'ve-content-outline-list ve-scroll-custom'},
              visibleContentEditorOutline.map(row=>h('div',{
                key:row.id,draggable:!!row.draggable,role:'button',tabIndex:0,
                'data-ve-tip':row.draggable?'Drag to reorder · right-click for actions':'Right-click for actions',
                class:'ve-content-outline-row depth-'+(row.depth||0)+(contentEditorSelection===row.id?' on':'')+(contentDraggedBlock===row.nodeIndex?' is-dragging':'')+(contentDropTarget===row.nodeIndex?' is-drop-target':''),
                onClick:()=>selectContentOutlineRow(row),
                onKeyDown:event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();selectContentOutlineRow(row);}},
                onContextMenu:event=>openContentOutlineContext(event,row),
                onDragStart:row.draggable?event=>{setContentDraggedBlock(row.nodeIndex);event.dataTransfer.effectAllowed='move';event.dataTransfer.setData('text/x-ve-content-block',String(row.nodeIndex));}:undefined,
                onDragOver:row.draggable?event=>{event.preventDefault();event.dataTransfer.dropEffect='move';setContentDropTarget(row.nodeIndex);}:undefined,
                onDragLeave:row.draggable?event=>{if(!event.currentTarget.contains(event.relatedTarget))setContentDropTarget(null);}:undefined,
                onDrop:row.draggable?event=>{event.preventDefault();const from=parseInt(event.dataTransfer.getData('text/x-ve-content-block'),10);reorderContentBlocks(from,row.nodeIndex);setContentDraggedBlock(null);setContentDropTarget(null);}:undefined,
                onDragEnd:row.draggable?()=>{setContentDraggedBlock(null);setContentDropTarget(null);}:undefined
              },h('span',{class:'ve-content-outline-disclosure'+(row.hasChildren?' has-children':''),role:row.hasChildren?'button':undefined,'aria-label':row.hasChildren?(contentCollapsedRows[row.id]?'Show children':'Hide children'):undefined,onClick:row.hasChildren?event=>{event.stopPropagation();toggleContentOutlineRow(row);}:undefined},row.hasChildren?ph(contentCollapsedRows[row.id]?'caret-right':'caret-down'):null),ph(row.icon==='text-h-one'?'text-h-one':row.icon),h('span',null,row.label),row.itemCount?h('em',{class:'ve-content-outline-count'},String(row.itemCount)):null,h('small',null,row.type))),
              visibleContentEditorOutline.length===0&&h('div',{class:'ve-content-outline-empty'},'No matching blocks.'),
              getCustomFieldSections(editingPost).length>0&&h('button',{type:'button',class:'ve-content-outline-row',onClick:()=>setContentEditorRailTab('block')},ph('square-half'),'Custom fields',h('small',null,getCustomFieldSections(editingPost).reduce((count,section)=>count+section.fields.length,0)))
            )
          ),
          h('main',{class:'ve-content-editor-canvas ve-scroll-custom',tabIndex:contentEditorPreview?0:undefined,onWheel:contentEditorPreview?scrollContentPreview:undefined},
            h('div',{class:'ve-content-editor-paper'},
              h('div',{class:'ve-content-editor-shell'},
                h(RichContentEditor,{
                  workspace:true,readOnly:contentEditorPreview,value:editingPost.content||'',theme:csTheme,onTheme:applyCsTheme,
                  onChange:html=>{setContentEditorSaveState('dirty');setEditingPost(value=>({...value,content:html}));},
                  onChooseImage:callback=>openContentMediaPicker('Choose content image',callback),onNotice:flash,
                  onBlockSelect:block=>{const outlineMatch=block&&contentEditorOutline.find(row=>row.depth>0&&((block.tag==='img'&&row.type==='Image')||(row.tag===block.tag&&(!block.text||row.label===block.text))));setContentSelectedBlock(block);setContentEditorSelection(outlineMatch?.id||block?.id||'content');setContentEditorRailTab(block?'block':contentEditorRailTab);},
                  beforeSurface:contentEditorPreview?h('div',{class:'ve-content-editor-title-wrap'},
                    h('h1',{class:'ve-content-preview-title'},editingPost.titleText||'Untitled'),
                    editingPost.excerpt&&h('p',{class:'ve-content-preview-excerpt'},editingPost.excerpt)
                  ):null
                })
              )
            )
          ),
          h('aside',{class:'ve-content-editor-rail'},
            h('div',{class:'ve-content-editor-tabs'},
              [['publish','Publish'],['seo','SEO'],['block','Block']].map(tab=>h('button',{type:'button',key:tab[0],class:'ve-content-editor-tab'+(contentEditorRailTab===tab[0]?' on':''),onClick:()=>setContentEditorRailTab(tab[0])},tab[1]))
            ),
            h('div',{class:'ve-content-editor-pane ve-scroll-custom',hidden:contentEditorRailTab!=='publish'},
              h('section',{class:'ve-content-editor-card ve-content-title-fields'},h('h4',null,'Title & excerpt'),h('label',{class:'ve-content-editor-label'},'Title'),h('input',{class:'ve-studio-input',required:true,value:editingPost.titleText,onFocus:()=>setContentEditorSelection('title'),onInput:event=>{const titleText=event.target.value;setContentEditorSaveState('dirty');setEditingPost(value=>({...value,titleText,slug:value.slugManuallyEdited?value.slug:contentTitleSlug(titleText)}));}}),h('label',{class:'ve-content-editor-label'},'Excerpt'),h('textarea',{class:'ve-studio-input ve-content-rail-textarea',placeholder:'Write an excerpt…',value:editingPost.excerpt||'',onFocus:()=>setContentEditorSelection('excerpt'),onInput:event=>{setContentEditorSaveState('dirty');setEditingPost(value=>({...value,excerpt:event.target.value}));}})),
              h('section',{class:'ve-content-editor-card'},h('h4',null,'Status & visibility'),h('label',{class:'ve-content-editor-label'},'Status'),h('div',{class:'ve-content-editor-segment'},[['draft','Draft'],['pending','Pending'],['publish','Published']].map(option=>h('button',{type:'button',key:option[0],class:editingPost.status===option[0]?'on':'',onClick:()=>{setContentEditorSaveState('dirty');setEditingPost(current=>({...current,status:option[0]}));}},option[1]))),h('label',{class:'ve-content-editor-label'},'Visibility'),h('div',{class:'ve-content-editor-segment'},h('button',{type:'button',class:editingPost.status!=='private'?'on':'',onClick:()=>{setContentEditorSaveState('dirty');setEditingPost(current=>({...current,status:current.status==='private'?'draft':current.status}));}},'Public'),h('button',{type:'button',class:editingPost.status==='private'?'on':'',onClick:()=>{setContentEditorSaveState('dirty');setEditingPost(current=>({...current,status:'private'}));}},'Private'),h('button',{type:'button',disabled:true,title:'Set a password in the WordPress editor'},'Password'))),
              h('section',{class:'ve-content-editor-card'},h('h4',null,'Permalink'),h('div',{class:'ve-content-permalink'},window.location.hostname+'/',h('input',{value:editingPost.slug||'',onInput:event=>{setContentEditorSaveState('dirty');setEditingPost(current=>({...current,slug:contentTitleSlug(event.target.value),slugManuallyEdited:true}));}}))),
              h('section',{class:'ve-content-editor-card ve-content-author-taxonomy'},
                h('h4',null,'Author & taxonomy'),
                h('div',{class:'ve-content-author-control'},ph('user-circle'),h(SelectMenu,{className:'ve-studio-select ve-content-author-select',value:String(editingPost.author||''),onChange:value=>{setContentEditorSaveState('dirty');setEditingPost(current=>({...current,author:parseInt(value||0,10)||0}));},options:(meta.authors||[]).map(author=>({value:String(author.id),label:author.name}))})),
                contentTaxonomies(editingPost).map(taxonomy=>{
                  const selectedIds=Array.isArray(editingPost.terms?.[taxonomy.name])?editingPost.terms[taxonomy.name].map(Number):[];
                  const selectedTerms=(taxonomy.terms||[]).filter(term=>selectedIds.includes(Number(term.id)));
                  const available=(taxonomy.terms||[]).filter(term=>!selectedIds.includes(Number(term.id)));
                  return h('div',{class:'ve-content-taxonomy-row',key:taxonomy.name},
                    h('label',{class:'ve-content-editor-label'},taxonomy.label),
                    h('div',{class:'ve-content-term-list'},
                      selectedTerms.map(term=>h('button',{type:'button',class:'ve-content-term-chip',key:term.id,'aria-label':'Remove '+term.name,onClick:()=>removeContentTerm(taxonomy.name,term.id)},term.name,h('span',null,'×')))
                    ),
                    available.length>0&&h('div',{class:'ve-content-term-add-row'},h(SelectMenu,{className:'ve-content-term-add',value:'',onChange:value=>addContentTerm(taxonomy.name,value),options:[{value:'',label:'+ add'},...available.map(term=>({value:String(term.id),label:term.name}))]}))
                  );
                })
              ),
              h('section',{class:'ve-content-editor-card'},h('h4',null,'Discussion'),
                h('label',{class:'ve-content-toggle-label',style:'display:flex;align-items:center;gap:9px;font-size:12px;margin-bottom:9px'},h(ToggleControl,{checked:editingPost.comment_status==='open',onChange:v=>{setContentEditorSaveState('dirty');setEditingPost(c=>({...c,comment_status:v?'open':'closed'}));}}),'Allow comments'),
                h('label',{class:'ve-content-toggle-label',style:'display:flex;align-items:center;gap:9px;font-size:12px'},h(ToggleControl,{checked:editingPost.ping_status==='open',onChange:v=>{setContentEditorSaveState('dirty');setEditingPost(c=>({...c,ping_status:v?'open':'closed'}));}}),'Allow pingbacks & trackbacks')),
              h('section',{class:'ve-content-editor-card'},h('h4',null,'Featured image'),h('button',{type:'button',class:'ve-content-featured-pick'+(editingPost.featured_media_url?' has-thumb':''),onClick:()=>openContentMediaPicker('Choose featured image',(url,item)=>{setContentEditorSaveState('dirty');setEditingPost(current=>({...current,featured_media:parseInt(item?.id||0,10)||0,featured_media_url:url||item?.source_url||''}));})},editingPost.featured_media_url?h('img',{class:'ve-content-featured-thumb',src:editingPost.featured_media_url,alt:''}):(editingPost.featured_media?ph('image'):''),h('span',{class:'ve-content-featured-label'},editingPost.featured_media?'Attachment #'+editingPost.featured_media+' · Replace':'Set cover'))),
              h('div',{class:'ve-content-editor-links'},canEditWithBricks(editingPost)&&h('a',{class:'ve-btn ve-btn-g ve-btn-s',href:editingPost.bricks_link,target:'_blank',rel:'noopener'},ph('squares-four'),'Edit in Bricks'),editingPost.edit_link&&h('a',{class:'ve-btn ve-btn-g ve-btn-s',href:editingPost.edit_link,target:'_blank',rel:'noopener'},ph('note-pencil'),'Open WP editor')),
              h('div',{class:'ve-content-editor-rail-actions'},h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',disabled:loading,onClick:event=>saveContentEdit(event,'draft')},editingPost.__isNew?'Create draft':'Save draft'),h('button',{type:'button',class:'ve-btn ve-btn-s',disabled:loading,onClick:event=>saveContentEdit(event,'publish')},editingPost.__isNew?'Create & publish':editingPost.status==='publish'?'Update':'Publish'))
            ),
            h('div',{class:'ve-content-editor-pane ve-scroll-custom',hidden:contentEditorRailTab!=='seo'},
              h('section',{class:'ve-content-editor-card ve-sd-score-card'},h('h4',null,'SEO score'),renderSeoGauge(editingPost),h('div',{class:'ve-sd-divider'}),renderSeoMeters(editingPost),h('div',{class:'ve-seo-rm-note'},ph('info'),rankMathActive(editingPost)?(rankMathLiveScoreFor(editingPost)!=null?('Rank Math’s analysis of the content as it stands — updates as you edit.'+(rankMathStoredScore(editingPost)!=null?' Rank Math last saved '+rankMathStoredScore(editingPost)+'/100; saving reconciles the two.':'')):(rankMathStoredScore(editingPost)!=null?'Rank Math’s last saved score ('+rankMathStoredScore(editingPost)+'/100). The live analysis is still starting up.':'Rank Math hasn’t scored this post yet, so this is Content Studio’s own analysis. Save to have Rank Math score it.')):'Rank Math is not active — showing Content Studio’s own analysis.'),h('div',{class:'ve-content-seo-save-row'},h('span',{class:contentEditorSaveState==='dirty'?'is-dirty':contentEditorSaveState==='saved'?'is-saved':''},contentEditorSaveState==='dirty'?'SEO changes not saved':contentEditorSaveState==='saving'?'Saving SEO…':contentEditorSaveState==='saved'?'SEO fields saved':rankMathActive(editingPost)?'Rank Math analysis is live':'Content checks update live'),h('button',{type:'button',class:'ve-btn ve-btn-s',disabled:loading,onClick:event=>saveContentEdit(event,editingPost.status)},loading?'Saving…':'Save SEO fields'))),
              h('section',{class:'ve-content-editor-card ve-content-focus-keywords'},renderFocusKeywordEditor()),
              h('section',{class:'ve-content-editor-card'},h('h4',null,'Search appearance'),h('label',{class:'ve-content-editor-label'},'SEO title'),h('input',{class:'ve-studio-input',value:editingPost.seo_details?.title||'',onInput:event=>{setContentEditorSaveState('dirty');seoSet('title',event.target.value);}}),h('label',{class:'ve-content-editor-label'},'Meta description'),h('textarea',{class:'ve-studio-input ve-content-rail-textarea',value:editingPost.seo_details?.description||'',onInput:event=>{setContentEditorSaveState('dirty');seoSet('description',event.target.value);}})),
              h('section',{class:'ve-content-editor-card'},h('h4',null,'Schema'),h('label',{class:'ve-content-editor-label'},'Schema type for this post'),h(SelectMenu,{className:'ve-studio-select',value:editingPost.seo_details?.schema||'Article',onChange:v=>{setContentEditorSaveState('dirty');seoSet('schema',v);},options:['Article','Book','Course','Event','FAQ','HowTo','JobPosting','Movie','Music','Person','Product','Recipe','Restaurant','Service','Software','Video'].map(x=>({value:x,label:x}))})),
              h('section',{class:'ve-content-editor-card ve-content-google-preview'},h('h4',null,'Google preview'),renderSerpPreview(editingPost)),
              h('section',{class:'ve-content-editor-card ve-content-social-previews'},h('h4',null,'Social / Open Graph'),
                h('div',{class:'ve-content-og-hint'},'Each preview image is that network’s share image — click it to set a custom one. Leave it and the featured image is used.'),
                h('div',{class:'ve-content-seo-preview-stack'},renderEditableSocialPreview(editingPost,'facebook'),renderEditableSocialPreview(editingPost,'twitter')))
            ),
            h('div',{class:'ve-content-editor-pane ve-scroll-custom',hidden:contentEditorRailTab!=='block'},
              h('section',{class:'ve-content-editor-card selected'},h('h4',null,'Selected block'),h('strong',{class:'ve-content-selected-name'},contentSelectedBlock?.label||contentEditorOutline.find(row=>row.id===contentEditorSelection)?.label||'Content'),h('span',{class:'ve-content-selected-type'},contentSelectedBlock?.type||(contentEditorSelection==='title'?'Title and excerpt':contentEditorSelection==='excerpt'?'Post excerpt':'Rich content field'))),
              selectedContentNode()?h('section',{class:'ve-content-editor-card ve-content-block-tools'},
                h('h4',null,'Block actions'),
                h('div',{class:'ve-content-block-actions'},
                  h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>mutateSelectedContentBlock('duplicate')},ph('copy'),'Duplicate'),
                  h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',disabled:!selectedContentNode()?.previousElementSibling,onClick:()=>mutateSelectedContentBlock('up')},ph('arrow-up'),'Move up'),
                  h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',disabled:!selectedContentNode()?.nextElementSibling,onClick:()=>mutateSelectedContentBlock('down')},ph('arrow-down'),'Move down'),
                  h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s danger',onClick:()=>mutateSelectedContentBlock('delete')},ph('trash'),'Delete')
                ),
                h('h4',{class:'ve-content-block-insert-title'},'Add below'),
                h('div',{class:'ve-content-block-insert'},
                  [['paragraph','paragraph','Paragraph'],['heading','text-h-two','Heading'],['quote','quotes','Quote'],['code','code','Code'],['bullets','list-bullets','List'],['image','image','Image']].map(item=>h('button',{type:'button',key:item[0],onClick:()=>insertContentBlockAfterSelection(item[0])},ph(item[1]),item[2]))
                )
              ):h('section',{class:'ve-content-editor-card ve-content-block-help'},h('h4',null,'Block tools'),h('p',null,'Select a block in the canvas or Structure panel to duplicate, move, delete, or insert directly below it. Double-tap Alt while editing to open the Add block menu at the text cursor.')),
              contentSelectedBlock?.image&&h('section',{class:'ve-content-editor-card ve-content-image-controls'},
                h('h4',null,'Image'),
                h('label',{class:'ve-content-editor-label'},'Alt text'),
                h('input',{class:'ve-studio-input',value:contentSelectedBlock.image.alt||'',placeholder:'Describe this image',onInput:event=>updateSelectedContentImageAlt(event.target.value)}),
                h('div',{class:'ve-content-image-actions'},
                  h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',onClick:replaceSelectedContentImage},ph('image-square'),'Replace'),
                  h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s danger',onClick:()=>setPendingContentImageDelete(true)},ph('trash'),'Remove')
                )
              ),
              editingPost.supports_editor===false&&h('div',{class:'ve-transfer-error'},'This post type reports the WordPress editor as disabled. Use Bricks or the WordPress editor for plugin-specific builder data.'),
              getCustomFieldSections(editingPost).map(section=>h('details',{class:'ve-content-custom-fields',open:true,key:'custom-section-'+section.title},h('summary',null,section.title),h('div',{class:'ve-content-field-help'},section.help),h('div',{class:'ve-content-custom-grid'},section.fields.map(field=>{const key=field.name||field.label;if(!key)return null;const value=(editingPost.custom_fields||{})[key];return h('div',{key:'field-'+key},h('label',{style:'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600'},field.label||key),fieldInput(field,value,next=>{setContentEditorSaveState('dirty');setEditingPost(current=>({...current,custom_fields:{...(current.custom_fields||{}),[key]:next}}));}),h('div',{class:'ve-content-field-help'},(field.groupTitle||'Custom field')+' · '+(field.type||'text')+(isSerializedMetaValue(value)?' · serialized/plugin data':'')));}))))
            )
          )
        )
      ) :

      // ── Main Content Lists (CPT Posts or Field Group Fields) ──
      h('div', { class: 've-studio-table-container ve-content-table-wrap' + ((!isFieldGroup && contentView !== 'list') ? ' ve-cv-wrap' : '') },
        loading ? h('div', { style: 'text-align:center;padding:60px;color:#888' }, 'Loading...') :
        // A field group with no fields yet must still render the builder — otherwise a
        // newly created group hits "No items found." and there is no way to add the first field.
        (filtered.length === 0 && !isFieldGroup) ? h('div', { style: 'text-align:center;padding:60px;color:#888' }, 'No items found.') :

        (!isFieldGroup ? (
          contentView === 'cards' ? renderContentCards(filtered) :
          contentView === 'board' ? renderContentBoard(filtered) :
          contentView === 'calendar' ? renderContentCalendar(filtered) :
          h('table', { class: 've-studio-table' },
            h('thead', null,
              h('tr', null,
                contentColumns.id && h('th', { style: 'width:60px' }, 'ID'),
                h('th', null, 'Title'),
                contentColumns.status && h('th', { style: 'width:100px' }, 'Status'),
                contentColumns.created && h('th', { style: 'width:120px' }, 'Created'),
                contentColumns.modified && h('th', { style: 'width:120px' }, 'Last Edited'),
                contentColumns.seo && h('th', { style: 'width:210px' }, 'SEO Details'),
                contentColumns.actions && h('th', { style: 'width:260px;text-align:right' }, 'Actions')
              )
            ),
            h('tbody', null, filtered.map(item =>
              h('tr', { key: item.id, class: 've-content-row', ...hoverProps(item) },
                contentColumns.id && h('td', { style: 'color:#666' }, `#${item.id}`),
                h('td', null, h('div', { class: 've-content-title-cell' }, h('strong', null, item.title?.rendered || 'Untitled'), h('em', { class: 've-content-title-slug' }, '/' + (item.slug || '')), renderTitleSeoChips(item))),
                contentColumns.status && h('td', null,
                  h('button', {
                    onClick: () => handleToggleStatus(item),
                    class: 've-status-toggle',
                    title: item.status === 'publish' ? 'Click to move this item to Draft' : 'Click to publish this item'
                  },
                    h('span', {
                      class: 've-studio-badge',
                      style: item.status === 'publish'
                        ? 'background:rgba(186,244,0,0.1);color:#baf400;border:1px solid rgba(186,244,0,0.2)'
                        : 'background:rgba(255,184,0,0.1);color:#ffb800;border:1px solid rgba(255,184,0,0.2)'
                    }, item.status === 'publish' ? 'Published' : 'Draft')
                  )
                ),
                contentColumns.created && h('td', { style: 'color:#888;font-size:11px' }, item.date ? new Date(item.date).toLocaleDateString() : '-'),
                contentColumns.modified && h('td', { style: 'color:#888;font-size:11px' }, item.modified ? new Date(item.modified).toLocaleDateString() : '-'),
                contentColumns.seo && h('td', null, renderSeoDetailsCell(item)),
                contentColumns.actions && h('td', { style: 'text-align:right' },
                  h('div', { class: 've-content-actions ve-content-action-stack' },
                    h('div', { class: 've-content-action-primary' },
                      h('button', {
                        type: 'button',
                        class: 've-btn ve-btn-g ve-btn-s ve-content-action-main',
                        onPointerDown: e => startStudioEdit(item, e),
                        onMouseDown: e => e.stopPropagation(),
                        onClick: e => startStudioEdit(item, e),
                        title: 'Edit clean content fields in Content Studio'
                      }, 'Studio'),
                      canEditWithBricks(item) && h('a', {
                        class: 've-btn ve-btn-primary ve-btn-s ve-content-action-main',
                        style: 'text-decoration:none;display:inline-flex;align-items:center;color:#1f1f1f;font-weight:800',
                        href: item.bricks_link,
                        title: 'Edit design/layout in Bricks'
                      }, 'Bricks')
                    ),
                    h('div', { class: 've-content-action-secondary' },
                      item.edit_link && h('a', {
                        class: 've-content-icon-action',
                        href: item.edit_link,
                        target: '_blank',
                        title: 'Open WordPress editor'
                      }, ph('file-text')),
                      item.link !== '#' && item.status !== 'trash' && h('a', {
                        class: 've-content-icon-action',
                        href: item.link,
                        target: '_blank',
                        title: 'View page'
                      }, ph('eye')),
                      h('button', {
                        class: 've-content-icon-action',
                        onClick: () => duplicateContentItem(item),
                        title: 'Duplicate as draft'
                      }, ph('copy')),
                      item.status === 'trash' && h('button', {
                        class: 've-content-icon-action',
                        onClick: () => restoreContentItem(item),
                        title: 'Restore to Draft'
                      }, ph('arrow-counter-clockwise')),
                      h('button', {
                        class: 've-content-icon-action',
                        onClick: () => handleCopyLink(item.link),
                        title: 'Copy link'
                      }, ph('link')),
                      h('button', {
                        class: 've-content-icon-action ' + (item.status === 'trash' ? 'danger' : 'warning'),
                        onClick: () => item.status === 'trash' ? handleDelete(item) : handleTrashContent(item),
                        title: item.status === 'trash' ? 'Delete permanently' : 'Move to Trash'
                      }, ph('trash'))
                    )
                  )
                )
              )
            ))
          )
        ) : (
          // Live Preview field builder — you edit the real editor screen.
          renderFieldGroupBuilder()
        ))
      )
    )
  );
}
function MediaStudioSub({ onClose, flash, onInsertMedia, picking, initialFilter, pageMode }) {
  const mediaIconPaths = {
    'arrows-clockwise': ['M128 40a88 88 0 0 1 83.3 59.5a8 8 0 0 1-15.2 5A72 72 0 0 0 64.9 82.9L80 98a8 8 0 0 1-5.7 13.7H32a8 8 0 0 1-8-8V61.4A8 8 0 0 1 37.7 55.8l15.8 15.8A88 88 0 0 1 128 40Zm-83.3 116.5a8 8 0 1 1 15.2-5A72 72 0 0 0 191.1 173.1L176 158a8 8 0 0 1 5.7-13.7H224a8 8 0 0 1 8 8v42.3a8 8 0 0 1-13.7 5.6l-15.8-15.8A88 88 0 0 1 44.7 156.5Z'],
    'arrows-merge': ['M48 40h56a8 8 0 0 1 8 8v38.1a40 40 0 0 0 11.7 28.3L128 118.7l4.3-4.3A40 40 0 0 0 144 86.1V48a8 8 0 0 1 8-8h56a8 8 0 0 1 5.7 13.7l-24 24a8 8 0 0 1-11.4-11.2L188.7 56H160v30.1a56 56 0 0 1-16.4 39.6L139.3 130l39 39-10.6 10.6-39-39-4.4 4.4A56 56 0 0 1 108.1 184H80v28.7l10.3-10.4a8 8 0 0 1 11.4 11.4l-24 24A8 8 0 0 1 64 232v-56a8 8 0 0 1 8-8h36.1a40 40 0 0 0 28.3-11.7l4.4-4.3-4.4-4.4A56 56 0 0 1 96 86.1V56H67.3l10.4 10.3a8 8 0 0 1-11.4 11.4l-24-24A8 8 0 0 1 48 40Z'],
    'arrows-out-line-vertical': ['M56 40h144a8 8 0 0 1 0 16H56a8 8 0 0 1 0-16Zm72 32a8 8 0 0 1 8 8v68.7l18.3-18.4a8 8 0 1 1 11.4 11.4l-32 32a8 8 0 0 1-11.4 0l-32-32a8 8 0 1 1 11.4-11.4l18.3 18.4V80a8 8 0 0 1 8-8ZM56 200h144a8 8 0 0 1 0 16H56a8 8 0 0 1 0-16Z'],
    'calendar': ['M80 24a8 8 0 0 1 8 8v8h80v-8a8 8 0 0 1 16 0v8h16a24 24 0 0 1 24 24v136a24 24 0 0 1-24 24H56a24 24 0 0 1-24-24V64a24 24 0 0 1 24-24h16v-8a8 8 0 0 1 8-8Zm128 88H48v88a8 8 0 0 0 8 8h144a8 8 0 0 0 8-8V112Z'],
    'caret-down': ['M50.3 88.6a8 8 0 0 1 11.4 0L128 154.9l66.3-66.3a8 8 0 1 1 11.4 11.4l-72 72a8 8 0 0 1-11.4 0l-72-72a8 8 0 0 1 0-11.4Z'],
    'caret-right': ['M96.6 42.3a8 8 0 0 1 11.4 0l72 72a8 8 0 0 1 0 11.4l-72 72a8 8 0 1 1-11.4-11.4L162.9 120 96.6 53.7a8 8 0 0 1 0-11.4Z'],
    'columns': ['M40 48a16 16 0 0 1 16-16h144a16 16 0 0 1 16 16v160a16 16 0 0 1-16 16H56a16 16 0 0 1-16-16V48Zm72 0H56v160h56V48Zm16 0v160h72V48h-72Z'],
    'command': ['M88 40a32 32 0 0 1 32 32v8h16v-8a32 32 0 1 1 32 32h-16v48h16a32 32 0 1 1-32 32v-16h-16v16a32 32 0 1 1-32-32h16v-48H88a32 32 0 1 1 0-64Zm0 16a16 16 0 1 0 0 32h16V72a16 16 0 0 0-16-16Zm80 0a16 16 0 0 0-16 16v16h16a16 16 0 1 0 0-32ZM88 168a16 16 0 1 0 16 16v-16H88Zm64 0v16a16 16 0 1 0 16-16h-16Zm-32-64v48h16v-48h-16Z'],
    'copy': ['M88 64h96a24 24 0 0 1 24 24v96a24 24 0 0 1-24 24H88a24 24 0 0 1-24-24V88a24 24 0 0 1 24-24Zm-32 24v96a32 32 0 0 0 32 32h96a8 8 0 0 1-8 8H72a40 40 0 0 1-40-40V80a8 8 0 0 1 8-8h8a8 8 0 0 1 8 8v8Z'],
    'copy-simple': ['M72 48h104a16 16 0 0 1 16 16v128a16 16 0 0 1-16 16H72a16 16 0 0 1-16-16V64a16 16 0 0 1 16-16Zm24-24h96a40 40 0 0 1 40 40v104a8 8 0 0 1-16 0V64a24 24 0 0 0-24-24H96a8 8 0 0 1 0-16Z'],
    'dots-six-vertical': ['M92 60a12 12 0 1 1-12-12 12 12 0 0 1 12 12Zm84 12a12 12 0 1 0-12-12 12 12 0 0 0 12 12ZM80 116a12 12 0 1 0 12 12 12 12 0 0 0-12-12Zm96 0a12 12 0 1 0 12 12 12 12 0 0 0-12-12ZM80 184a12 12 0 1 0 12 12 12 12 0 0 0-12-12Zm96 0a12 12 0 1 0 12 12 12 12 0 0 0-12-12Z'],
    'download-simple': ['M128 24a8 8 0 0 1 8 8v102.7l34.3-34.4a8 8 0 0 1 11.4 11.4l-48 48a8 8 0 0 1-11.4 0l-48-48a8 8 0 1 1 11.4-11.4L120 134.7V32a8 8 0 0 1 8-8Zm-88 144a8 8 0 0 1 8 8v24h160v-24a8 8 0 0 1 16 0v24a16 16 0 0 1-16 16H48a16 16 0 0 1-16-16v-24a8 8 0 0 1 8-8Z'],
    'file': ['M56 24h96l48 48v136a24 24 0 0 1-24 24H56a24 24 0 0 1-24-24V48a24 24 0 0 1 24-24Zm88 16v40h40l-40-40Z'],
    'file-arrow-down': ['M56 24h96l48 48v136a24 24 0 0 1-24 24H56a24 24 0 0 1-24-24V48a24 24 0 0 1 24-24Zm72 72a8 8 0 0 0-8 8v48.7l-18.3-18.4a8 8 0 0 0-11.4 11.4l32 32a8 8 0 0 0 11.4 0l32-32a8 8 0 0 0-11.4-11.4L136 152.7V104a8 8 0 0 0-8-8Z'],
    'filter': ['M32 56a16 16 0 0 1 16-16h160a16 16 0 0 1 12.5 26l-60.5 75.6V200a8 8 0 0 1-3.6 6.7l-40 26.7A8 8 0 0 1 104 226.7v-85.1L43.5 66A16 16 0 0 1 32 56Z'],
    'folder': ['M24 72a24 24 0 0 1 24-24h48l24 24h88a24 24 0 0 1 24 24v88a24 24 0 0 1-24 24H48a24 24 0 0 1-24-24V72Z'],
    'folder-dashed': ['M48 56h48l24 24h40a8 8 0 0 1 0 16h-43.3a8 8 0 0 1-5.7-2.3L89.4 72H48a8 8 0 0 0-8 8v16a8 8 0 0 1-16 0V80a24 24 0 0 1 24-24Zm152 40a24 24 0 0 1 24 24v64a24 24 0 0 1-24 24h-24a8 8 0 0 1 0-16h24a8 8 0 0 0 8-8v-64a8 8 0 0 0-8-8h-8a8 8 0 0 1 0-16h8ZM32 120a8 8 0 0 1 8 8v16a8 8 0 0 1-16 0v-16a8 8 0 0 1 8-8Zm0 48a8 8 0 0 1 8 8v8a8 8 0 0 0 8 8h16a8 8 0 0 1 0 16H48a24 24 0 0 1-24-24v-8a8 8 0 0 1 8-8Zm56 32a8 8 0 0 1 8-8h48a8 8 0 0 1 0 16H96a8 8 0 0 1-8-8Z'],
    'folder-open': ['M24 88a24 24 0 0 1 24-24h52.7l21.6 21.7a8 8 0 0 0 5.7 2.3h88a16 16 0 0 1 15.3 20.6l-28.8 96A24 24 0 0 1 179.5 224H52.5A24 24 0 0 1 29.6 207L8.7 137.3A24 24 0 0 1 31.7 106H208l.6-2H128a24 24 0 0 1-17-7L93.4 80H48a8 8 0 0 0-8 8v18H31.7a24.6 24.6 0 0 0-7.7 1.3V88Z'],
    'grid-four': ['M40 40h72v72H40V40Zm104 0h72v72h-72V40ZM40 144h72v72H40v-72Zm104 0h72v72h-72v-72Z'],
    'hard-drives': ['M56 32h144a24 24 0 0 1 24 24v48a24 24 0 0 1-24 24H56a24 24 0 0 1-24-24V56a24 24 0 0 1 24-24Zm0 112h144a24 24 0 0 1 24 24v32a24 24 0 0 1-24 24H56a24 24 0 0 1-24-24v-32a24 24 0 0 1 24-24Zm112 40a12 12 0 1 0 12-12 12 12 0 0 0-12 12Z'],
    'image-square': ['M48 32h160a16 16 0 0 1 16 16v160a16 16 0 0 1-16 16H48a16 16 0 0 1-16-16V48a16 16 0 0 1 16-16Zm32 56a24 24 0 1 0 24-24 24 24 0 0 0-24 24Zm128 104v-34.7l-34.3-34.3a8 8 0 0 0-11.4 0L120 165.3l-18.3-18.3a8 8 0 0 0-11.4 0L48 189.3V208h160v-16Z'],
    'images': ['M48 40h128a24 24 0 0 1 24 24v112a24 24 0 0 1-24 24H48a24 24 0 0 1-24-24V64a24 24 0 0 1 24-24Zm176 32a8 8 0 0 1 8 8v128a24 24 0 0 1-24 24H72a8 8 0 0 1 0-16h136a8 8 0 0 0 8-8V80a8 8 0 0 1 8-8Z'],
    'list': ['M88 64h128a8 8 0 0 1 0 16H88a8 8 0 0 1 0-16Zm0 56h128a8 8 0 0 1 0 16H88a8 8 0 0 1 0-16Zm0 56h128a8 8 0 0 1 0 16H88a8 8 0 0 1 0-16ZM40 72a12 12 0 1 1 12 12A12 12 0 0 1 40 72Zm0 56a12 12 0 1 1 12 12 12 12 0 0 1-12-12Zm0 56a12 12 0 1 1 12 12 12 12 0 0 1-12-12Z'],
    'lock-open': ['M80 104V80a48 48 0 0 1 91.5-20.2 8 8 0 1 1-14.5 6.7A32 32 0 0 0 96 80v24h88a16 16 0 0 1 16 16v80a16 16 0 0 1-16 16H72a16 16 0 0 1-16-16v-80a16 16 0 0 1 16-16h8Z'],
    'lock-simple': ['M80 104V80a48 48 0 0 1 96 0v24h8a16 16 0 0 1 16 16v80a16 16 0 0 1-16 16H72a16 16 0 0 1-16-16v-80a16 16 0 0 1 16-16h8Zm16 0h64V80a32 32 0 0 0-64 0v24Z'],
    'magic-wand': ['M200 24l12 28 28 12-28 12-12 28-12-28-28-12 28-12 12-28ZM80 40l9.5 22.5L112 72l-22.5 9.5L80 104l-9.5-22.5L48 72l22.5-9.5L80 40Zm79.4 60.6 24 24a8 8 0 0 1 0 11.4l-93.4 93.4a24 24 0 0 1-34 0l-29.4-29.4a24 24 0 0 1 0-34l93.4-93.4a8 8 0 0 1 11.4 0l28 28ZM128 89.4 89.4 128 128 166.6l38.6-38.6L128 89.4Z'],
    'pencil-simple': ['M204.3 73.7 182.3 51.7a24 24 0 0 0-34 0L45.7 154.3a8 8 0 0 0-2.1 3.8l-16 64a8 8 0 0 0 9.7 9.7l64-16a8 8 0 0 0 3.8-2.1L207.7 107.7a24 24 0 0 0-3.4-34Z'],
    'palette': ['M128 24a104 104 0 0 0 0 208h16a24 24 0 0 0 0-48h-12a12 12 0 0 1 0-24h44a56 56 0 0 0 0-112A103.6 103.6 0 0 0 128 24ZM80 104a16 16 0 1 1 16-16 16 16 0 0 1-16 16Zm40-32a16 16 0 1 1 16 16 16 16 0 0 1-16-16Zm56 32a16 16 0 1 1 16-16 16 16 0 0 1-16 16ZM88 152a16 16 0 1 1 16-16 16 16 0 0 1-16 16Z'],
    'star': ['M128 24l30.9 62.6 69.1 10-50 48.8 11.8 68.8L128 181.7 66.2 214.2 78 145.4 28 96.6l69.1-10L128 24Z'],
    'plus': ['M128 40a8 8 0 0 1 8 8v72h72a8 8 0 0 1 0 16h-72v72a8 8 0 0 1-16 0v-72H48a8 8 0 0 1 0-16h72V48a8 8 0 0 1 8-8Z'],
    'squares-four': ['M48 40h64v64H48V40Zm96 0h64v64h-64V40ZM48 152h64v64H48v-64Zm96 0h64v64h-64v-64Z'],
    'tray': ['M40 40h176a16 16 0 0 1 16 16v144a16 16 0 0 1-16 16H40a16 16 0 0 1-16-16V56a16 16 0 0 1 16-16Zm0 112h43.1a8 8 0 0 1 6.7 3.6L101.3 176h53.4l11.5-20.4a8 8 0 0 1 6.7-3.6H216V56H40v96Z'],
    'trash': ['M216 56h-40V40a16 16 0 0 0-16-16H96a16 16 0 0 0-16 16v16H40a8 8 0 0 0 0 16h8v136a16 16 0 0 0 16 16h128a16 16 0 0 0 16-16V72h8a8 8 0 0 0 0-16ZM96 40h64v16H96V40Z'],
    'tree-structure': ['M120 32h16v48h56a16 16 0 0 1 16 16v32h-16V96h-56v32h-16V96H64v32H48V96a16 16 0 0 1 16-16h56V32Zm-88 112h48v48H32v-48Zm72 0h48v48h-48v-48Zm72 0h48v48h-48v-48Z'],
    'text-aa': ['M73 48h22l45 136h-22l-10-32H59l-10 32H27L73 48Zm-8 84h37L83.5 73 65 132Zm106-15h18l31 67h-20l-6-14h-29l-6 14h-19l31-67Zm0 38h18l-9-21-9 21Z'],
    'eye-slash': ['M39 35a8 8 0 0 1 11.3 0l171 171a8 8 0 0 1-11.3 11.3l-28.8-28.8A126.7 126.7 0 0 1 128 200C64 200 26 132 24.4 129.1a8 8 0 0 1 0-7.8 149.8 149.8 0 0 1 43.3-48.4L27.7 46.3A8 8 0 0 1 39 35Zm89 21c64 0 102 68 103.6 70.9a8 8 0 0 1 0 7.8 143.5 143.5 0 0 1-28 36.5l-28.5-28.5A48 48 0 0 0 113.3 80.9L92.7 60.3A126.3 126.3 0 0 1 128 56Z'],
    'bounding-box': ['M48 32h48v16H56a8 8 0 0 0-8 8v40H32V48a16 16 0 0 1 16-16Zm112 0h48a16 16 0 0 1 16 16v48h-16V56a8 8 0 0 0-8-8h-40V32ZM32 160h16v40a8 8 0 0 0 8 8h40v16H48a16 16 0 0 1-16-16v-48Zm176 0h16v48a16 16 0 0 1-16 16h-48v-16h40a8 8 0 0 0 8-8v-40Z'],
    'device-mobile': ['M88 24h80a24 24 0 0 1 24 24v160a24 24 0 0 1-24 24H88a24 24 0 0 1-24-24V48a24 24 0 0 1 24-24Zm0 16a8 8 0 0 0-8 8v160a8 8 0 0 0 8 8h80a8 8 0 0 0 8-8V48a8 8 0 0 0-8-8h-80Zm24 144h32v16h-32v-16Z'],
    'square': ['M56 48h144a8 8 0 0 1 8 8v144a8 8 0 0 1-8 8H56a8 8 0 0 1-8-8V56a8 8 0 0 1 8-8Zm8 16v128h128V64H64Z'],
    'upload-simple': ['M128 24a8 8 0 0 1 5.7 2.3l48 48a8 8 0 1 1-11.4 11.4L136 51.3V152a8 8 0 0 1-16 0V51.3L85.7 85.7a8 8 0 0 1-11.4-11.4l48-48A8 8 0 0 1 128 24Zm-88 144a8 8 0 0 1 8 8v24h160v-24a8 8 0 0 1 16 0v24a16 16 0 0 1-16 16H48a16 16 0 0 1-16-16v-24a8 8 0 0 1 8-8Z'],
    'user': ['M128 128a48 48 0 1 0-48-48 48 48 0 0 0 48 48Zm0 16c-44.2 0-80 22.4-80 50v6a16 16 0 0 0 16 16h128a16 16 0 0 0 16-16v-6c0-27.6-35.8-50-80-50Z'],
    'x': ['M205.7 61.7a8 8 0 0 0-11.4-11.4L128 116.7 61.7 50.3a8 8 0 0 0-11.4 11.4L116.7 128l-66.4 66.3a8 8 0 0 0 11.4 11.4L128 139.3l66.3 66.4a8 8 0 0 0 11.4-11.4L139.3 128l66.4-66.3Z']
  };
  // font-aa and tags are not Phosphor names; they were offered as collection icons, so
  // keep resolving any collection already saved with one.
  const mediaIconAliases = { 'brackets-curly':'file', 'folder-simple-plus':'folder', 'hard-drive':'hard-drives', 'font-aa':'text-aa', 'tags':'tag' };
  const ph = (n, props={})=>{
    const name = mediaIconAliases[n] || n || 'file';
    const paths = mediaIconPaths[name];
    const cls = 've-ms-icon ' + (props.class || '');
    const style = props.style || '';
    // This inline table only covers part of the set. Falling back to mediaIconPaths.file
    // drew a document glyph on unrelated buttons (Save metadata, Import, Restore) and on
    // most of the collection icon picker, so names it does not carry defer to the
    // Phosphor webfont. ve-ms-icon is deliberately omitted: it sizes an SVG box.
    if (!paths) return h('i', { ...(props||{}), class: 'ph-duotone ph-' + name + ' ve-ms-icon-font ' + (props.class || ''), style, 'aria-hidden':'true' });
    return h('svg', { ...(props||{}), class: cls, style, viewBox:'0 0 256 256', width:'1em', height:'1em', fill:'currentColor', stroke:'none', 'aria-hidden':'true', focusable:'false' }, paths.map((d,i)=>h('path',{key:'tone-'+i,d,class:'ve-ms-icon-tone'})).concat(paths.map((d,i)=>h('path',{key:'main-'+i,d,class:'ve-ms-icon-main'}))));
  };
  const [items, setItems] = useState(() => Array.isArray(VE_MEDIA_CACHE.items) ? VE_MEDIA_CACHE.items : []);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [collectionSearch, setCollectionSearch] = useState('');
  const [collectionSort, setCollectionSort] = useState(() => localStorage.getItem('ve_media_collection_sort') || 'az');
  const [selected, setSelected] = useState(null);
  const insertLockRef = useRef(false);
  const [mediaUsage, setMediaUsage] = useState(null);
  const [mediaUsageLoading, setMediaUsageLoading] = useState(false);
  const [mediaUsageError, setMediaUsageError] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(null);
  const [mediaBusyMessage, setMediaBusyMessage] = useState('');
  useEffect(() => {
    if (!uploadProgress) return;
    const state = String(uploadProgress.state || '');
    const shouldAutoDismiss = !!uploadProgress.dismissMs || /(complete|failed|finished|saved|filled|converted|compressed|deleted|uploaded|imported)/i.test(state);
    if (!shouldAutoDismiss) return;
    const delay = Math.max(5000, Number(uploadProgress.dismissMs || 5000) || 5000);
    const current = uploadProgress;
    const timer = setTimeout(() => {
      setUploadProgress(prev => prev === current ? null : prev);
    }, delay);
    return () => clearTimeout(timer);
  }, [uploadProgress]);
  useEffect(() => {
    document.body.classList.toggle('ve-media-progress-active', !!uploadProgress);
    return () => document.body.classList.remove('ve-media-progress-active');
  }, [uploadProgress]);
  const [urlImportBusy, setUrlImportBusy] = useState(false);
  const [pendingUrlImport, setPendingUrlImport] = useState(null);
  const urlImportRef = useRef(null);
  const normalizeMediaLayout = mode => (mode === 'list' || mode === 'masonry' ? mode : 'grid');
  const [layoutMode, setLayoutMode] = useState(() => normalizeMediaLayout(localStorage.getItem('ve_media_layout') || 'grid'));
  const defaultListMetaFields = ['mime','size','dimensions','uploaded'];
  const [listMetaFields, setListMetaFields] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('ve_media_list_meta_fields') || 'null');
      if (Array.isArray(saved)) return saved.filter(Boolean);
    } catch(e) {}
    return localStorage.getItem('ve_media_list_meta') === '0' ? [] : defaultListMetaFields;
  });
  const showListMeta = listMetaFields.length > 0;
  const [listMetaPanelOpen, setListMetaPanelOpen] = useState(false);
  const [selectedColl, setSelectedColl] = useState(() => {
    try { return localStorage.getItem('ve_media_last_collection') || 'all'; } catch (e) { return 'all'; }
  });
  useEffect(() => {
    // Remember the last collection the Media Studio was in, so reopening (via Bricks or
    // anywhere) lands back where you left off instead of resetting to All media.
    try { localStorage.setItem('ve_media_last_collection', selectedColl); } catch (e) {}
  }, [selectedColl]);
  const [checkedItems, setCheckedItems] = useState([]);
  const fileInputRef = useRef(null);
  const zipImportRef = useRef(null);
  const zipImportTargetRef = useRef('');
  const [zipImportBusy, setZipImportBusy] = useState(false);
  const [filterType, setFilterType] = useState(() => {
    if (picking) return ['all','image','svg','video','audio','application','font'].includes(initialFilter) ? initialFilter : 'image';
    return localStorage.getItem('ve_media_filter') || 'all';
  });
  const parseStoredQualityFilters = raw => {
    if (!raw) return [];
    try {
      const parsed = String(raw).trim().charAt(0) === '[' ? JSON.parse(raw) : null;
      if (Array.isArray(parsed)) return [...new Set(parsed.map(String).filter(x => x && x !== 'all'))];
    } catch(e) {}
    return [...new Set(String(raw).split(',').map(x => x.trim()).filter(x => x && x !== 'all'))];
  };
  const [qualityFilter, setQualityFilter] = useState(() => localStorage.getItem('ve_media_quality_filter') || 'all');
  const [qualityFilters, setQualityFilters] = useState(() => parseStoredQualityFilters(localStorage.getItem('ve_media_quality_filters') || localStorage.getItem('ve_media_quality_filter') || ''));
  const [qualityPanelOpen, setQualityPanelOpen] = useState(false);
  const [qualityQuery, setQualityQuery] = useState('');
  const readSavedQualityPresets = () => {
    try {
      const parsed = JSON.parse(localStorage.getItem('ve_media_saved_filters') || '[]');
      return Array.isArray(parsed) ? parsed.filter(x => x && x.name && Array.isArray(x.qualityFilters)).slice(0, 12) : [];
    } catch(e) {
      return [];
    }
  };
  const [savedQualityPresets, setSavedQualityPresets] = useState(readSavedQualityPresets);
  const [qualityPresetName, setQualityPresetName] = useState('');
  const [unusedScan, setUnusedScan] = useState({ key: '', ids: null, loading: false, scanned: 0, limited: false, message: '' });
  const unusedScanRunRef = useRef(0);
  const unusedScanTimeoutRef = useRef(null);
  const [viewPanelOpen, setViewPanelOpen] = useState(false);
  const viewPanelCloseTimerRef = useRef(null);
  const viewPanelRef = useRef(null);
  const [masonryColumnCount, setMasonryColumnCount] = useState(5);
  const [videoAspectRatios, setVideoAspectRatios] = useState({});
  const [sortBy, setSortBy] = useState(() => localStorage.getItem('ve_media_sort') || 'date');
  const [showNewCollForm, setShowNewCollForm] = useState(false);
  const [newCollName, setNewCollName] = useState('');
  const newCollInputRef = useRef(null);
  const [newCollIcon, setNewCollIcon] = useState('folder');
  const [iconSearch, setIconSearch] = useState('');
  const [iconCatalog, setIconCatalog] = useState(COLL_ICONS);
  const [folderData, setFolderData] = useState({ folders: [], map: {} });
  const [dragActive, setDragActive] = useState(false);
  const [lastMediaIndex, setLastMediaIndex] = useState(null);
  const [pendingBatchCollection, setPendingBatchCollection] = useState(false);
  const [convertFormat, setConvertFormat] = useState('webp');
  const [convertingId, setConvertingId] = useState(null);
  const [pendingDeleteMedia, setPendingDeleteMedia] = useState(null);
  const [pendingBatchDelete, setPendingBatchDelete] = useState(false);
  const [pendingReplaceRequest, setPendingReplaceRequest] = useState(null);
  const [urlImportHistory, setUrlImportHistory] = useState([]);
  const [diagnostics, setDiagnostics] = useState(null);
  const [diagnosticsLoading, setDiagnosticsLoading] = useState(false);
  const [pendingDeleteCollection, setPendingDeleteCollection] = useState(null);
  const [batchNewCollName, setBatchNewCollName] = useState('');
  const [batchNewCollIcon, setBatchNewCollIcon] = useState('folder');
  const [filenameDraft, setFilenameDraft] = useState('');
  const [altDraft, setAltDraft] = useState('');
  const [captionDraft, setCaptionDraft] = useState('');
  const [descriptionDraft, setDescriptionDraft] = useState('');
  const [mediaSaveState, setMediaSaveState] = useState('');
  const [pendingRename, setPendingRename] = useState(null);
  const replaceInputRef = useRef(null);
  const [collectionMenu, setCollectionMenu] = useState(null);
  const [collectionColorPicker, setCollectionColorPicker] = useState(null);
  const [collectionColorFmt, setCollectionColorFmt] = useState('hex');
  const [renameCollectionKey, setRenameCollectionKey] = useState(null);
  const [renameCollectionName, setRenameCollectionName] = useState('');
  const [dragCollection, setDragCollection] = useState(null);
  const [dropCollection, setDropCollection] = useState(null);
  const [dropMode, setDropMode] = useState('');
  const [collectionCreateModal, setCollectionCreateModal] = useState(null);
  const [externalFolderTip, setExternalFolderTip] = useState(null);
  const [detailPreviewMode, setDetailPreviewMode] = useState(() => localStorage.getItem('ve_media_detail_preview_mode') || 'fit');
  const [detailPreviewZoom, setDetailPreviewZoom] = useState(() => Math.max(1, Math.min(4, parseFloat(localStorage.getItem('ve_media_detail_preview_zoom') || '1') || 1)));
  const [mediaDragIds, setMediaDragIds] = useState([]);
  const [showCommandPanel, setShowCommandPanel] = useState(false);
  const [showDynamicFolders, setShowDynamicFolders] = useState(false);
  const [dynamicCollapsed, setDynamicCollapsed] = useState(() => {
    try {
      const parsed = JSON.parse(localStorage.getItem('ve_media_dynamic_collapsed') || '{}');
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    } catch(e) {
      return {};
    }
  });
  const [dynamicFilter, setDynamicFilter] = useState(null);
  const [sidebarWidth, setSidebarWidth] = useState(() => Math.max(320, Math.min(480, parseInt(localStorage.getItem('ve_media_sidebar_width') || '320', 10) || 320)));
  const [viewPanelSuppressed, setViewPanelSuppressed] = useState(false);
  const selectedMediaRef = useRef(null);
  const pickerClickRef = useRef({ id: null, at: 0 });
  const mediaLayoutRef = useRef(null);
  const collectionPopoverCleanup = useRef(null);
  const mediaMainRef = useRef(null);
  const detailPreviewRef = useRef(null);
  const qualityPanelRef = useRef(null);
  useEffect(() => {
    if (!showNewCollForm && !collectionCreateModal) return;
    const timer = setTimeout(() => {
      try { newCollInputRef.current?.focus?.(); newCollInputRef.current?.select?.(); } catch(e) {}
    }, 30);
    return () => clearTimeout(timer);
  }, [showNewCollForm, collectionCreateModal]);
  const listMetaPanelRef = useRef(null);
  useEffect(() => () => {
    if (viewPanelCloseTimerRef.current) clearTimeout(viewPanelCloseTimerRef.current);
  }, []);
  useEffect(() => {
    const updateColumns = () => {
      const width = mediaMainRef.current?.clientWidth || mediaLayoutRef.current?.clientWidth || window.innerWidth || 900;
      const next = Math.max(2, Math.min(6, Math.floor(width / 205)));
      setMasonryColumnCount(next || 5);
    };
    updateColumns();
    let observer = null;
    if (typeof ResizeObserver !== 'undefined' && mediaMainRef.current) {
      observer = new ResizeObserver(updateColumns);
      observer.observe(mediaMainRef.current);
    }
    window.addEventListener('resize', updateColumns);
    return () => {
      window.removeEventListener('resize', updateColumns);
      if (observer) observer.disconnect();
    };
  }, []);
  const mediaDropDepthRef = useRef(0);
  const mediaDragActiveRef = useRef(false);
  const mediaDragCandidateRef = useRef(false);
  const collectionDragActiveRef = useRef(false);
  const internalDragBlockUntilRef = useRef(0);
  const fileDragClearTimerRef = useRef(null);
  const [showMigrationModal, setShowMigrationModal] = useState(false);
  const [selectedMigrateFolders, setSelectedMigrateFolders] = useState([]);
  const [migrateHideFolders, setMigrateHideFolders] = useState(false);
  const [hideFolders, setHideFolders] = useState(() => localStorage.getItem('ve_media_hide_folders') === 'true');
  const [collapsedPaths, setCollapsedPaths] = useState(loadMediaCollapsedPaths);

  // Collections are WordPress-backed via MV Media Collections taxonomy.
  // localStorage remains a fast cache and migration bridge for older local-only maps.
  const readLocalCollections = () => {
    try {
      const saved = localStorage.getItem('ve_media_collections');
      if (!saved) return {};
      const parsed = JSON.parse(saved);
      const migrated = {};
      for (const k of Object.keys(parsed || {})) {
        if (String(k).indexOf('folder:') === 0) continue;
        if (Array.isArray(parsed[k])) {
          migrated[k] = { ids: parsed[k], icon: 'folder' };
        } else if (parsed[k] && typeof parsed[k] === 'object') {
          migrated[k] = parsed[k];
        }
      }
      return migrated;
    } catch (e) {
      return {};
    }
  };

  const [collectionMap, setCollectionMap] = useState(readLocalCollections);
  const [collectionsHydrated, setCollectionsHydrated] = useState(false);
  const collectionMutationRevisionRef = useRef(0);
  const pendingCollectionSelectionRef = useRef(null);

  const cacheCollections = (next) => {
    const safe = next && typeof next === 'object' && !Array.isArray(next) ? next : {};
    setCollectionMap(safe);
    localStorage.setItem('ve_media_collections', JSON.stringify(safe));
    persistUserPreference('ve_media_collections', JSON.stringify(safe));
    try { window.dispatchEvent(new CustomEvent('ve-media-collections-changed', { detail: safe })); } catch(e) {}
  };

  const applyServerCollections = (res) => {
    if (!res || res.code || !res.collections || typeof res.collections !== 'object') return false;
    cacheCollections(res.collections);
    if (res.map) {
      setFolderData(prev => ({ ...(prev || {}), mvMap: res.map }));
    }
    return true;
  };

  const persistCollections = (next, options = {}) => {
    collectionMutationRevisionRef.current += 1;
    cacheCollections(next);
    return api.p('media-studio/collections/sync', {
      collections: next,
      delete_missing: options.deleteMissing !== false
    }).then(res => {
      if (res && res.success) applyServerCollections(res);
      return res;
    }).catch(() => null);
  };

  const loadMvCollections = useCallback(async () => {
    const startedAtRevision = collectionMutationRevisionRef.current;
    try {
      const res = await api.g('media-studio/collections');
      if (startedAtRevision !== collectionMutationRevisionRef.current) return;
      const serverCollections = res && res.collections && typeof res.collections === 'object' ? res.collections : {};
      if (Object.keys(serverCollections).length) {
        applyServerCollections(res);
      } else {
        const local = readLocalCollections();
        if (Object.keys(local).length) {
          const migrated = await api.p('media-studio/collections/sync', { collections: local, delete_missing: false });
          if (!applyServerCollections(migrated)) cacheCollections(local);
        }
      }
    } catch (e) {}
    if (startedAtRevision === collectionMutationRevisionRef.current) setCollectionsHydrated(true);
  }, []);

  const makeCollectionKey = label => (label || '').trim().toLowerCase().replace(/\s*\/\s*/g, '/').replace(/[^a-z0-9/]+/g, '_').replace(/^_+|_+$/g, '');
  const isFolderCollection = key => String(key || '').indexOf('folder:') === 0;
  useEffect(() => {
    // If the remembered collection was deleted in a previous session, fall back to All
    // rather than opening to an empty view.
    if (selectedColl === 'all' || selectedColl === 'uncollected' || isFolderCollection(selectedColl)) return;
    if (!collectionMap || !Object.keys(collectionMap).length) return;
    const pending = pendingCollectionSelectionRef.current;
    if (pending && (pending.key === selectedColl || Object.values(collectionMap).some(entry => String(entry?.label || '') === pending.label))) return;
    if (!collectionMap[selectedColl]) setSelectedColl('all');
  }, [collectionMap]);
  const folderIdFromKey = key => String(key || '').replace(/^folder:/, '');
  const folderKey = id => 'folder:' + id;
  const folderByKey = key => (folderData.folders || []).find(f => String(f.id) === folderIdFromKey(key));
  const isLockedCollection = key => !!(!isFolderCollection(key) && collectionMap[key] && collectionMap[key].locked);
  const isStarredCollection = key => !!(!isFolderCollection(key) && collectionMap[key] && collectionMap[key].starred);
  const normalizeCollectionColor = value => {
    const raw = String(value || '').trim();
    return /^#[0-9a-f]{6}([0-9a-f]{2})?$/i.test(raw) ? raw.toLowerCase() : '';
  };
  const collectionColor = key => normalizeCollectionColor(!isFolderCollection(key) && collectionMap[key] && collectionMap[key].color ? collectionMap[key].color : '');

  const buildFolderPath = (folder) => {
    if (!folder) return '';
    const parts = [folder.name];
    let current = folder;
    while (current && current.parent && current.parent !== '0') {
      const parentFolder = (folderData.folders || []).find(f => String(f.id) === String(current.parent));
      if (parentFolder) {
        parts.unshift(parentFolder.name);
        current = parentFolder;
      } else {
        break;
      }
    }
    return parts.join(' / ');
  };

  const collLabel = (key) => {
    if (isFolderCollection(key)) {
      const folder = folderByKey(key);
      return folder ? buildFolderPath(folder) : folderIdFromKey(key);
    }
    const entry = collectionMap[key];
    return (entry && entry.label) || key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  };

  const treeAwareCollectionOrder = keys => {
    const sourceOrder = new Map(keys.map((key, index) => [key, index]));
    const byParent = new Map();
    const labelByKey = new Map(keys.map(key => [key, collLabel(key)]));
    keys.forEach(key => {
      const label = labelByKey.get(key) || '';
      const parts = label.split('/').map(x => x.trim()).filter(Boolean);
      const parent = parts.slice(0, -1).join(' / ');
      if (!byParent.has(parent)) byParent.set(parent, []);
      byParent.get(parent).push(key);
    });
    byParent.forEach(list => list.sort((a, b) => (sourceOrder.get(a) || 0) - (sourceOrder.get(b) || 0)));
    const out = [];
    const seen = new Set();
    const walk = parent => {
      (byParent.get(parent) || []).forEach(key => {
        if (seen.has(key)) return;
        seen.add(key);
        out.push(key);
        walk(labelByKey.get(key) || '');
      });
    };
    walk('');
    keys.forEach(key => { if (!seen.has(key)) out.push(key); });
    return out;
  };

  const compareCollectionKeys = (a, b) => {
    const aStar = isStarredCollection(a) ? 1 : 0;
    const bStar = isStarredCollection(b) ? 1 : 0;
    if (aStar !== bStar) return bStar - aStar;
    if (collectionSort === 'za') return collLabel(b).localeCompare(collLabel(a));
    if (collectionSort === 'old' || collectionSort === 'manual') return 0;
    return collLabel(a).localeCompare(collLabel(b));
  };

  let localCollKeys = Object.keys(collectionMap);
  localCollKeys.sort(compareCollectionKeys);
  localCollKeys = treeAwareCollectionOrder(localCollKeys);

  let folderCollKeys = (hideFolders || !folderData.folders) ? [] : (folderData.folders || []).map(f => folderKey(f.id));
  folderCollKeys.sort(compareCollectionKeys);
  folderCollKeys = treeAwareCollectionOrder(folderCollKeys);

  const collKeys = [...folderCollKeys, ...localCollKeys];
  const collectionSearchTerm = collectionSearch.trim().toLowerCase();
  const visibleCollKeys = collKeys.filter(key => !collectionSearchTerm || collLabel(key).toLowerCase().includes(collectionSearchTerm));
  const collectionLabelToKey = useMemo(() => {
    const map = {};
    collKeys.forEach(key => { const label = collLabel(key); if (label) map[label] = key; });
    return map;
  }, [collKeys.join('|'), folderData.folders, collectionMap]);
  const collectionCollapseId = (key, label) => key ? ('key:' + String(key)) : ('path:' + String(label || ''));
  const isCollectionBranchCollapsed = (key, label) => {
    const id = collectionCollapseId(key, label);
    if (Object.prototype.hasOwnProperty.call(collapsedPaths, id)) return !!collapsedPaths[id];
    if (!key && label && Object.prototype.hasOwnProperty.call(collapsedPaths, String(label))) return !!collapsedPaths[String(label)];
    return false;
  };
  const setCollectionBranchCollapsed = (key, label, collapsed) => {
    const id = collectionCollapseId(key, label);
    const next = { ...collapsedPaths, [id]: !!collapsed };
    if (!key && label) next[String(label)] = !!collapsed; // legacy label fallback only when no stable key exists.
    setCollapsedPaths(next);
    persistMediaCollapsedPaths(next);
    window.dispatchEvent(new CustomEvent('ve-media-collapsed-paths-changed', { detail: next }));
  };
  const collectionBranchLabels = useMemo(() => {
    const labels = collKeys.map(key => collLabel(key)).filter(Boolean);
    return labels.filter(label => labels.some(other => other !== label && other.indexOf(label + ' / ') === 0));
  }, [collKeys.join('|'), folderData.folders, collectionMap]);
  const hasCollapsedCollectionBranches = collectionBranchLabels.some(label => isCollectionBranchCollapsed(collectionLabelToKey[label], label));
  const collectionBranchesAllExpanded = collectionBranchLabels.length > 0 && !hasCollapsedCollectionBranches;
  const toggleAllCollectionBranches = () => {
    const next = {};
    if (collectionBranchesAllExpanded) {
      collectionBranchLabels.forEach(label => {
        const key = collectionLabelToKey[label];
        next[collectionCollapseId(key, label)] = true;
        next[label] = true;
      });
    }
    setCollapsedPaths(next);
    persistMediaCollapsedPaths(next);
    window.dispatchEvent(new CustomEvent('ve-media-collapsed-paths-changed', { detail: next }));
  };
  const persistCollectionSort = value => {
    setCollectionSort(value);
    persistUserPreference('ve_media_collection_sort', value);
  };

  const openMediaCollection = key => {
    if (selectedColl === key) return;
    // Keep the selection tray alive across collections so users can collect media
    // from multiple collections before running a batch action.
    if (checkedItems.length) {
      flash('Kept ' + checkedItems.length + ' selected across collections. Use Deselect when you are done.');
    }
    setPendingBatchCollection(false);
    setSelected(null);
    setLastMediaIndex(null);
    setSelectedColl(key);
  };

  const toggleCollectionItem = (coll, id, checked) => {
    if (isFolderCollection(coll)) {
      const folderId = folderIdFromKey(coll);
      api.p('media-studio/folders/assign', { attachment_id: id, folder_id: folderId, checked: checked }).then(r => {
        if (r && r.success) {
          setFolderData(prev => {
            const nextMap = { ...(prev.map || {}) };
            const list = (nextMap[id] || []).map(String);
            const nextList = checked ? [...new Set([...list, String(folderId)])] : list.filter(x => x !== String(folderId));
            nextMap[id] = nextList;
            return { ...prev, map: nextMap };
          });
          flash(checked ? `Added to "${collLabel(coll)}"` : `Removed from "${collLabel(coll)}"`);
        } else {
          flash('Folder update failed.');
        }
      }).catch(() => flash('Folder update failed.'));
      return;
    }
    const entry = collectionMap[coll] || { ids: [], icon: 'folder' };
    if (entry.locked) {
      flash('Unlock this collection before changing its media.');
      return;
    }
    const ids = entry.ids || [];
    const nextIds = checked ? [...ids, id] : ids.filter(x => x !== id);
    persistCollections({ ...collectionMap, [coll]: { ...entry, ids: nextIds } });
    flash(checked ? `Added to "${coll}"` : `Removed from "${coll}"`);
  };

  const createCollection = () => {
    const label = newCollName.trim();
    if (!label) { flash('Enter a collection name.'); return; }
    const key = makeCollectionKey(label);
    if (!key || collectionMap[key]) { flash('Collection already exists or name is invalid.'); return; }
    // Expand every ancestor branch first so a child collection under a collapsed
    // parent is visible once selected.
    const parts = label.split(' / ');
    if (parts.length > 1) {
      const nextCollapsed = { ...collapsedPaths };
      for (let i = 1; i < parts.length; i++) {
        const ancestor = parts.slice(0, i).join(' / ');
        const aKey = collectionLabelToKey[ancestor];
        nextCollapsed[collectionCollapseId(aKey, ancestor)] = false;
        nextCollapsed[String(ancestor)] = false;
      }
      setCollapsedPaths(nextCollapsed);
      persistMediaCollapsedPaths(nextCollapsed);
      window.dispatchEvent(new CustomEvent('ve-media-collapsed-paths-changed', { detail: nextCollapsed }));
    }
    // The server can re-key a nested collection, so select it by label once the sync
    // returns rather than trusting the locally guessed key (which the validation
    // effect would otherwise reset to "all").
    pendingCollectionSelectionRef.current = { key, label };
    persistCollections({ ...collectionMap, [key]: { ids: [], icon: newCollIcon, label: label } }).then(res => {
      const serverMap = res && res.collections && typeof res.collections === 'object' ? res.collections : null;
      let targetKey = key;
      if (serverMap && !serverMap[targetKey]) {
        const match = Object.keys(serverMap).find(k => String((serverMap[k] && serverMap[k].label) || '') === label);
        if (match) targetKey = match;
      }
      pendingCollectionSelectionRef.current = null;
      setSelectedColl(targetKey);
    });
    setSelectedColl(key);
    setNewCollName('');
    setNewCollIcon('folder');
    setShowNewCollForm(false);
    setCollectionCreateModal(null);
    flash(`Collection "${label}" created!`);
  };

  const requestDeleteCollection = (key) => {
    if (!key || isFolderCollection(key) || !collectionMap[key]) return;
    if (isLockedCollection(key)) { flash('Unlock this collection before deleting it.'); return; }
    setPendingDeleteCollection({ key, label: collLabel(key), count: collCounts[key] || 0 });
  };

  const confirmDeleteCollection = () => {
    const key = pendingDeleteCollection?.key;
    if (!key || isFolderCollection(key) || !collectionMap[key]) {
      setPendingDeleteCollection(null);
      return;
    }
    const next = { ...collectionMap };
    delete next[key];
    persistCollections(next);
    if (selectedColl === key) setSelectedColl('all');
    setPendingDeleteCollection(null);
    flash('Collection removed.');
  };

  const renameLocalCollection = (oldKey, nextLabel) => {
    if (!oldKey || isFolderCollection(oldKey)) return;
    if (isLockedCollection(oldKey)) { flash('Unlock this collection before renaming it.'); return; }
    const label = (nextLabel || '').trim();
    const nextKey = makeCollectionKey(label);
    if (!label || !nextKey) { flash('Enter a valid collection name.'); return; }
    if (nextKey !== oldKey && collectionMap[nextKey]) { flash('Collection already exists.'); return; }
    const next = {};
    Object.keys(collectionMap).forEach(key => {
      if (key === oldKey) {
        next[nextKey] = { ...(collectionMap[oldKey] || {}), label };
      } else {
        next[key] = collectionMap[key];
      }
    });
    persistCollections(next);
    if (selectedColl === oldKey) setSelectedColl(nextKey);
    setRenameCollectionKey(null);
    setRenameCollectionName('');
    flash('Collection renamed.');
  };

  const collectionLabelPartsForMove = key => collLabel(key).split('/').map(x => x.trim()).filter(Boolean);
  const collectionParentLabel = key => collectionLabelPartsForMove(key).slice(0, -1).join(' / ');

  const moveCollectionTree = (sourceKey, nextRootLabel, targetKey, message, insertMode = 'before') => {
    if (!sourceKey || !nextRootLabel || isFolderCollection(sourceKey)) return false;
    if (isLockedCollection(sourceKey)) { flash('Unlock this collection before moving it.'); return false; }
    const sourceEntry = collectionMap[sourceKey];
    if (!sourceEntry) return false;
    const oldRootLabel = collLabel(sourceKey);
    const allKeys = Object.keys(collectionMap);
    const subtreeKeys = allKeys.filter(key => key === sourceKey || collLabel(key).startsWith(oldRootLabel + ' / '));
    const subtreeSet = new Set(subtreeKeys);
    if (targetKey && subtreeSet.has(targetKey)) {
      flash('Move this collection outside itself first.');
      return false;
    }

    const mapped = {};
    const movedEntries = [];
    for (const oldKey of subtreeKeys) {
      const oldLabel = collLabel(oldKey);
      const suffix = oldLabel === oldRootLabel ? '' : oldLabel.slice(oldRootLabel.length + 3);
      const newLabel = suffix ? nextRootLabel + ' / ' + suffix : nextRootLabel;
      const newKey = makeCollectionKey(newLabel);
      if (!newKey) { flash('Collection move failed. Invalid collection name.'); return false; }
      if (!subtreeSet.has(newKey) && collectionMap[newKey]) {
        flash('A collection with that name already exists.');
        return false;
      }
      mapped[oldKey] = newKey;
      movedEntries.push([newKey, { ...(collectionMap[oldKey] || {}), label: newLabel }]);
    }

    const next = {};
    const remaining = allKeys.filter(key => !subtreeSet.has(key));
    const targetLabel = targetKey ? collLabel(targetKey) : '';
    const targetSubtree = targetLabel ? new Set(remaining.filter(key => key === targetKey || collLabel(key).startsWith(targetLabel + ' / '))) : new Set();
    let inserted = false;
    const insertMoved = () => {
      if (inserted) return;
      movedEntries.forEach(([nextKey, value]) => { next[nextKey] = value; });
      inserted = true;
    };
    remaining.forEach((key, index) => {
      if (targetKey && key === targetKey && insertMode === 'before') insertMoved();
      next[key] = collectionMap[key];
      if (targetKey && key === targetKey && insertMode === 'after') insertMoved();
      if (targetKey && insertMode === 'afterSubtree' && targetSubtree.has(key)) {
        const nextKey = remaining[index + 1];
        if (!nextKey || !targetSubtree.has(nextKey)) insertMoved();
      }
    });
    if (!inserted) insertMoved();

    persistCollections(next);
    persistCollectionSort('manual');
    if (mapped[selectedColl]) setSelectedColl(mapped[selectedColl]);
    flash(message || 'Collection moved.');
    return true;
  };

  const nestCollectionUnder = (childKey, parentKey) => {
    if (!childKey || !parentKey || childKey === parentKey || isFolderCollection(childKey) || isFolderCollection(parentKey)) return;
    const childLeaf = collectionLeafLabel(childKey);
    const parentLabel = collLabel(parentKey);
    moveCollectionTree(childKey, parentLabel + ' / ' + childLeaf, parentKey, 'Collection nested.', 'afterSubtree');
  };

  const reorderCollectionBefore = (fromKey, toKey) => {
    if (!fromKey || !toKey || fromKey === toKey || isFolderCollection(fromKey) || isFolderCollection(toKey)) return;
    const targetParent = collectionParentLabel(toKey);
    const nextLabel = targetParent ? targetParent + ' / ' + collectionLeafLabel(fromKey) : collectionLeafLabel(fromKey);
    moveCollectionTree(fromKey, nextLabel, toKey, 'Collection reordered.', 'before');
  };

  const reorderCollectionAfter = (fromKey, toKey) => {
    if (!fromKey || !toKey || fromKey === toKey || isFolderCollection(fromKey) || isFolderCollection(toKey)) return;
    const targetParent = collectionParentLabel(toKey);
    const nextLabel = targetParent ? targetParent + ' / ' + collectionLeafLabel(fromKey) : collectionLeafLabel(fromKey);
    moveCollectionTree(fromKey, nextLabel, toKey, 'Collection reordered.', 'afterSubtree');
  };


  const runFoldersMigration = () => {
    if (!selectedMigrateFolders.length) {
      flash('Select at least one folder to migrate.');
      return;
    }
    const nextMap = { ...collectionMap };
    let migratedCount = 0;
    
    selectedMigrateFolders.forEach(folderId => {
      const folder = (folderData.folders || []).find(f => String(f.id) === String(folderId));
      if (!folder) return;
      
      const pathLabel = buildFolderPath(folder);
      const key = makeCollectionKey(pathLabel);
      if (!key) return;
      
      const newIds = collIds('folder:' + folderId) || [];
      const existing = nextMap[key] || { ids: [], icon: 'folder', label: pathLabel };
      const nextIds = [...new Set([...(existing.ids || []), ...newIds])];
      
      nextMap[key] = {
        ids: nextIds,
        icon: existing.icon || 'folder',
        label: pathLabel
      };
      migratedCount++;
    });
    
    persistCollections(nextMap);
    
    localStorage.setItem('ve_media_hide_folders', migrateHideFolders ? 'true' : 'false');
    setHideFolders(migrateHideFolders);
    
    // Dispatch custom events for real-time synchronization
    window.dispatchEvent(new CustomEvent('ve-media-collections-migrated'));
    window.dispatchEvent(new CustomEvent('ve-media-hide-folders-changed', { detail: migrateHideFolders }));
    
    setShowMigrationModal(false);
    flash(`Successfully migrated ${migratedCount} folder(s) to MV collections!`);
  };

  const beginRenameCollection = key => {
    if (isFolderCollection(key)) {
      flash('Detected folder-plugin folders are read-only here.');
      return;
    }
    if (isLockedCollection(key)) {
      flash('Unlock this collection before renaming it.');
      setCollectionMenu(null);
      return;
    }
    setRenameCollectionKey(key);
    setRenameCollectionName(collLabel(key));
    setCollectionMenu(null);
  };

  const beginChildCollection = key => {
    if (isFolderCollection(key)) {
      flash('Folder-plugin folders are detected here, but hierarchy editing stays inside that plugin for now.');
      setCollectionMenu(null);
      return;
    }
    if (isLockedCollection(key)) {
      flash('Unlock this collection before creating a sub-collection.');
      setCollectionMenu(null);
      return;
    }
    setNewCollName(collLabel(key) + ' / ');
    setNewCollIcon('folder');
    setCollectionCreateModal({ parentKey: key });
    setCollectionMenu(null);
  };


  const createCollectionForSelection = () => {
    const label = batchNewCollName.trim();
    if (!label) { flash('Enter a collection name.'); return; }
    const key = makeCollectionKey(label);
    if (!key || collectionMap[key]) { flash('Collection already exists or name is invalid.'); return; }
    const next = { ...collectionMap, [key]: { ids: [...new Set(checkedItems)], icon: batchNewCollIcon, label } };
    persistCollections(next);
    setBatchNewCollName('');
    setBatchNewCollIcon('folder');
    setPendingBatchCollection(false);
    setCheckedItems([]);
    flash(`Created "${label}" and added selected media.`);
  };

  const collIcon = (key) => {
    if (isFolderCollection(key)) return 'folder';
    const entry = collectionMap[key] || {};
    return entry.icon || 'folder';
  };

  const collIds = (key) => {
    if (key === 'uncollected') {
      const assigned = new Set();
      collKeys.forEach(coll => collIds(coll).forEach(id => assigned.add(id)));
      return items.filter(item => !assigned.has(item.id)).map(item => item.id);
    }
    if (isFolderCollection(key)) {
      const fid = folderIdFromKey(key);
      return collectFolderMediaIds(folderData, fid);
    }
    const entry = collectionMap[key] || {};
    return entry.ids || [];
  };

  const isLocalCollectionOpen = () => selectedColl && selectedColl !== 'all' && selectedColl !== 'uncollected' && !isFolderCollection(selectedColl) && !!collectionMap[selectedColl];

  const checkedItemsInCurrentCollection = () => {
    if (!isLocalCollectionOpen()) return [];
    const currentIds = new Set((collIds(selectedColl) || []).map(id => Number(id)));
    return checkedItems.map(id => Number(id)).filter(id => currentIds.has(id));
  };

  const removeCheckedFromCurrentCollection = () => {
    if (!isLocalCollectionOpen()) {
      flash('Open an MV collection before removing media from a collection.');
      return;
    }
    if (isLockedCollection(selectedColl)) {
      flash('Unlock this collection before removing media.');
      return;
    }
    const removeIds = checkedItemsInCurrentCollection();
    if (!removeIds.length) {
      flash('None of the selected media are in "' + collLabel(selectedColl) + '".');
      return;
    }
    const removeSet = new Set(removeIds.map(Number));
    const entry = collectionMap[selectedColl] || { ids: [], icon: 'folder', label: collLabel(selectedColl) };
    const nextIds = (entry.ids || []).map(id => Number(id)).filter(id => !removeSet.has(id));
    persistCollections({ ...collectionMap, [selectedColl]: { ...entry, ids: nextIds } });
    setCheckedItems(prev => prev.map(id => Number(id)).filter(id => !removeSet.has(id)));
    const kept = checkedItems.length - removeIds.length;
    flash('Removed ' + removeIds.length + ' from "' + collLabel(selectedColl) + '"' + (kept > 0 ? '. Kept ' + kept + ' selected from other collections.' : '.'));
  };

  const addUploadedToOpenCollection = (uploadedIds) => {
    const ids = (uploadedIds || []).map(id => Number(id)).filter(Boolean);
    if (!ids.length || !isLocalCollectionOpen()) return;
    const entry = collectionMap[selectedColl] || { ids: [], icon: 'folder', label: collLabel(selectedColl) };
    const nextIds = [...new Set([...(entry.ids || []).map(id => Number(id)).filter(Boolean), ...ids])];
    persistCollections({ ...collectionMap, [selectedColl]: { ...entry, ids: nextIds } });
  };

  const uploadWithProgress = (endpoint, body, headers, onProgress) => new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', restEndpoint(endpoint), true);
    xhr.withCredentials = true;
    xhr.setRequestHeader('X-WP-Nonce', CFG.nonce || '');
    Object.entries(headers || {}).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') xhr.setRequestHeader(key, value);
    });
    xhr.upload.onprogress = event => {
      if (!event.lengthComputable) return;
      const percent = Math.max(1, Math.min(99, Math.round((event.loaded / event.total) * 100)));
      onProgress && onProgress(percent, event.loaded, event.total);
    };
    xhr.onload = () => {
      let data = null;
      try { data = xhr.responseText ? JSON.parse(xhr.responseText) : {}; } catch(e) { data = { code: 've_bad_json', message: 'WordPress returned invalid upload data.' }; }
      if (xhr.status >= 200 && xhr.status < 300 && !data?.code) {
        resolve(data);
      } else {
        reject(new Error(data?.message || data?.code || 'Upload failed.'));
      }
    };
    xhr.onerror = () => reject(new Error('Upload failed. Check your connection, then try again.'));
    xhr.send(body);
  });

  const loadMedia = useCallback(async (q = '') => {
    const hasSearch = !!q.trim();
    const hasCachedItems = !hasSearch && Array.isArray(VE_MEDIA_CACHE.items);
    if (hasCachedItems) {
      setItems(VE_MEDIA_CACHE.items);
      setLoading(false);
    } else {
      setLoading(true);
    }
    try {
      const cacheAge = Date.now() - Number(VE_MEDIA_CACHE.at || 0);
      const shouldRefresh = !hasCachedItems || cacheAge > 30 * 1000;
      const all = hasSearch
        ? await fetchMediaLibraryPages(q.trim(), false)
        : shouldRefresh
          ? await prefetchMediaLibrary(true)
          : VE_MEDIA_CACHE.items;
      setItems(all);
      if (!hasSearch) publishMediaCache(all, true);
      setLoading(false);
      return all;
    } catch (e) {
      flash(e?.message || 'Media Studio could not read the media library.');
    }
    setLoading(false);
    return hasSearch ? [] : (VE_MEDIA_CACHE.items || []);
  }, [flash]);

  useEffect(() => subscribeMediaCache(nextItems => {
    if (search.trim()) return;
    setItems(nextItems);
    setLoading(false);
  }), [search]);

  const loadFolders = useCallback(async () => {
    if (VE_MEDIA_CACHE.folders) {
      setFolderData(VE_MEDIA_CACHE.folders);
    }
    try {
      const res = await api.g('media-studio/folders');
      if (res && !res.code) {
        VE_MEDIA_CACHE.folders = { folders: res.folders || [], map: res.map || {} };
        setFolderData(VE_MEDIA_CACHE.folders);
      }
    } catch (e) {}
  }, []);

  const syncExternalFolders = useCallback(async () => {
    VE_MEDIA_CACHE.folders = null;
    VE_MEDIA_CACHE.items = null;
    try { sessionStorage.removeItem(VE_MEDIA_CACHE_KEY); } catch (e) {}
    try {
      const res = await api.g('media-studio/folders');
      if (res && !res.code) {
        const next = { folders: res.folders || [], map: res.map || {} };
        VE_MEDIA_CACHE.folders = next;
        setFolderData(next);
        loadMedia(search || '');
        flash('External folder plugin synced.');
      } else {
        flash(res?.message || 'External folder sync found no readable folders.');
      }
    } catch (e) {
      flash('External folder sync failed.');
    }
  }, [flash, loadMedia, search]);

  const refreshUrlImportHistory = useCallback(async () => {
    try {
      const res = await api.g('media-studio/url-history');
      if (res && Array.isArray(res.history)) setUrlImportHistory(res.history);
    } catch (e) {}
  }, []);

  const refreshDiagnostics = useCallback(async () => {
    setDiagnosticsLoading(true);
    try {
      const res = await api.g('media-studio/diagnostics');
      if (res && res.success) setDiagnostics(res);
    } catch (e) {}
    setDiagnosticsLoading(false);
  }, []);

  useEffect(() => {
    loadMedia();
    loadFolders();
    loadMvCollections();
    refreshUrlImportHistory();
    refreshDiagnostics();
  }, [loadMedia, loadFolders, loadMvCollections, refreshUrlImportHistory, refreshDiagnostics]);

  useEffect(() => {
    const sync = () => syncExternalFolders();
    window.addEventListener('ve-media-sync-external-folders', sync);
    return () => window.removeEventListener('ve-media-sync-external-folders', sync);
  }, [syncExternalFolders]);

  useEffect(() => {
    const resetDrop = (event) => {
      // Firefox/Chromium can fire pointercancel as soon as native HTML5 dragging starts.
      // Do not clear MV's internal drag markers on pointercancel, otherwise collection/media drags
      // can be mistaken for OS file uploads. A normal pointerup must still clear click-only candidates.
      if (event?.type === 'pointercancel' && (mediaDragActiveRef.current || mediaDragCandidateRef.current || collectionDragActiveRef.current || (Date.now() < internalDragBlockUntilRef.current))) {
        mediaDropDepthRef.current = 0;
        setDragActive(false);
        return;
      }
      mediaDropDepthRef.current = 0;
      mediaDragCandidateRef.current = false;
      mediaDragActiveRef.current = false;
      collectionDragActiveRef.current = false;
      setDragActive(false);
      setMediaDragIds([]);
      setDragCollection(null);
      setDropCollection(null);
      setDropMode('');
      clearInternalDragMarker()
    };
    window.addEventListener('drop', resetDrop);
    window.addEventListener('dragend', resetDrop);
    window.addEventListener('pointerup', resetDrop);
    window.addEventListener('pointercancel', resetDrop);
    window.addEventListener('blur', resetDrop);
    return () => {
      window.removeEventListener('drop', resetDrop);
      window.removeEventListener('dragend', resetDrop);
      window.removeEventListener('pointerup', resetDrop);
      window.removeEventListener('pointercancel', resetDrop);
      window.removeEventListener('blur', resetDrop);
      if (fileDragClearTimerRef.current) clearTimeout(fileDragClearTimerRef.current);
    };
  }, []);

  useEffect(() => {
    try { document.body.classList.add('ve-media-studio-open'); } catch(e) {}
    return () => {
      try { document.body.classList.remove('ve-media-studio-open'); } catch(e) {}
    };
  }, []);

  useEffect(() => {
    if (!picking) return;
    const allowed = ['all','image','svg','video','audio','application','font'];
    const nextFilter = allowed.includes(initialFilter) ? initialFilter : 'image';
    setFilterType(nextFilter);
  }, [picking, initialFilter]);

  useEffect(() => {
    const handleCollectionsMigrated = () => {
      try {
        const saved = localStorage.getItem('ve_media_collections');
        if (saved) setCollectionMap(JSON.parse(saved));
      } catch (e) {}
    };
    const handleHideFoldersChanged = (e) => {
      setHideFolders(e.detail);
    };
    window.addEventListener('ve-media-collections-migrated', handleCollectionsMigrated);
    window.addEventListener('ve-media-hide-folders-changed', handleHideFoldersChanged);
    return () => {
      window.removeEventListener('ve-media-collections-migrated', handleCollectionsMigrated);
      window.removeEventListener('ve-media-hide-folders-changed', handleHideFoldersChanged);
    };
  }, []);

  const mediaTextValue = (item, key) => {
    const value = item && item[key];
    if (!value) return '';
    if (typeof value === 'string') return value;
    if (typeof value === 'object') {
      if (typeof value.raw === 'string') return value.raw;
      if (typeof value.rendered === 'string') return value.rendered.replace(/<[^>]*>/g, '').trim();
    }
    return '';
  };

  const mergeMediaItem = nextItem => {
    if (!nextItem || !nextItem.id) return;
    // Shallow-MERGE onto the existing item rather than replacing it. A metadata
    // save (e.g. alt text) can return an item whose preview fields aren't fully
    // populated yet — especially for a just-uploaded image whose thumbnails
    // haven't been generated — so a wholesale replace made the preview vanish
    // until a reload. Merging keeps the working preview while applying updates.
    const merge = (x) => Number(x.id) === Number(nextItem.id) ? { ...x, ...nextItem } : x;
    setItems(prev => prev.map(merge));
    if (Array.isArray(VE_MEDIA_CACHE.items)) {
      publishMediaCache(VE_MEDIA_CACHE.items.map(merge), true);
    }
    if (selectedMediaRef.current && Number(selectedMediaRef.current.id) === Number(nextItem.id)) {
      setSelected(prev => ({ ...(prev || {}), ...nextItem }));
    }
  };

  const broadcastMediaItemUpdate = nextItem => {
    if (!nextItem || !nextItem.id) return;
    const payload = { at: Date.now(), item: nextItem };
    try { localStorage.setItem('ve_media_item_update', JSON.stringify(payload)); } catch(e) {}
    try { window.dispatchEvent(new CustomEvent('ve-media-item-updated', { detail: nextItem })); } catch(e) {}
  };

  useEffect(() => {
    const apply = item => {
      if (item && item.id) mergeMediaItem(item);
    };
    const onLocal = e => apply(e.detail);
    const onStorage = e => {
      if (e.key !== 've_media_item_update' || !e.newValue) return;
      try { apply(JSON.parse(e.newValue).item); } catch(err) {}
    };
    window.addEventListener('ve-media-item-updated', onLocal);
    window.addEventListener('storage', onStorage);
    return () => {
      window.removeEventListener('ve-media-item-updated', onLocal);
      window.removeEventListener('storage', onStorage);
    };
  }, []);

  useEffect(() => {
    setFilenameDraft(selected?.title?.raw || selected?.title?.rendered || '');
    setAltDraft(selected?.alt_text || '');
    setCaptionDraft(mediaTextValue(selected, 'caption'));
    setDescriptionDraft(mediaTextValue(selected, 'description'));
    setMediaSaveState('');
  }, [selected?.id, selected?.title?.rendered, selected?.title?.raw]);

  useEffect(() => {
    selectedMediaRef.current = selected;
  }, [selected]);

  useEffect(() => {
    let alive = true;
    const id = selected?.id;
    setMediaUsage(null);
    setMediaUsageError('');
    if (!id) {
      setMediaUsageLoading(false);
      return () => { alive = false; };
    }
    setMediaUsageLoading(true);
    api.g('media-studio/usage/' + encodeURIComponent(id))
      .then(res => {
        if (!alive) return;
        if (!res || res.code || res.success === false) {
          setMediaUsageError(res?.message || 'Usage scan failed.');
          setMediaUsage(null);
        } else {
          setMediaUsage(res);
        }
      })
      .catch(() => {
        if (!alive) return;
        setMediaUsageError('Usage scan failed.');
        setMediaUsage(null);
      })
      .finally(() => {
        if (alive) setMediaUsageLoading(false);
      });
    return () => { alive = false; };
  }, [selected?.id]);

  useEffect(() => {
    if (!qualityPanelOpen && !listMetaPanelOpen && !viewPanelOpen) return;
    const closeOpenPopovers = e => {
      if (qualityPanelOpen && qualityPanelRef.current && !qualityPanelRef.current.contains(e.target)) {
        setQualityPanelOpen(false);
      }
      if (listMetaPanelOpen && listMetaPanelRef.current && !listMetaPanelRef.current.contains(e.target)) {
        setListMetaPanelOpen(false);
      }
      if (viewPanelOpen && viewPanelRef.current && !viewPanelRef.current.contains(e.target)) {
        setViewPanelOpen(false);
        setViewPanelSuppressed(false);
      }
    };
    document.addEventListener('pointerdown', closeOpenPopovers, true);
    return () => document.removeEventListener('pointerdown', closeOpenPopovers, true);
  }, [qualityPanelOpen, listMetaPanelOpen, viewPanelOpen]);

  useEffect(() => {
    const base = CFG.assetUrl || '';
    if (!base) return;
    fetch(base + 'phosphor-icons.json', { credentials: 'same-origin' })
      .then(r => r.ok ? r.json() : null)
      .then(list => {
        if (Array.isArray(list) && list.length) setIconCatalog(list.filter(Boolean));
      })
      .catch(() => {});
  }, []);

  const handleSearch = (e) => {
    const val = e.target.value;
    setSearch(val);
  };

  const dataTransferTypes = e => Array.from(e?.dataTransfer?.types || []);
  const hasFileDrag = e => dataTransferTypes(e).includes('Files');
  const hasInternalDragType = e => dataTransferTypes(e).includes('application/x-ve-internal-drag');
  const markInternalDrag = type => {
    internalDragBlockUntilRef.current = Date.now() + 1400;
    try {
      document.body.classList.add('ve-internal-drag-active');
      if (type === 'collection') document.body.classList.add('ve-internal-collection-drag');
      if (type === 'media') document.body.classList.add('ve-internal-media-drag');
    } catch(e) {}
    setDragActive(false);
    mediaDropDepthRef.current = 0;
  };
  const isInternalDragBlocked = () => {
    if (Date.now() < internalDragBlockUntilRef.current) return true;
    try {
      return !!(document.body?.classList?.contains('ve-internal-drag-active') || document.body?.classList?.contains('ve-internal-media-drag') || document.body?.classList?.contains('ve-internal-collection-drag'));
    } catch(e) {
      return false;
    }
  };
  const clearInternalDragMarker = () => {
    internalDragBlockUntilRef.current = Date.now() + 250;
    try {
      document.body.classList.remove('ve-internal-drag-active');
      document.body.classList.remove('ve-internal-media-drag');
      document.body.classList.remove('ve-internal-collection-drag');
    } catch(e) {}
  };
  const hasMediaDrag = e => {
    const types = dataTransferTypes(e);
    const isCollection = collectionDragActiveRef.current || !!dragCollection || types.includes('application/x-ve-collection-key') || (typeof document !== 'undefined' && document.body?.classList?.contains('ve-internal-collection-drag'));
    if (isCollection) return false;
    return mediaDragActiveRef.current || mediaDragCandidateRef.current || types.includes('application/x-ve-media-ids') || mediaDragIds.length > 0 || (typeof document !== 'undefined' && document.body?.classList?.contains('ve-internal-media-drag'));
  };
  const hasCollectionDrag = e => {
    const types = dataTransferTypes(e);
    return collectionDragActiveRef.current || !!dragCollection || types.includes('application/x-ve-collection-key') || (typeof document !== 'undefined' && document.body?.classList?.contains('ve-internal-collection-drag'));
  };
  const isInternalDragSource = e => !!e?.target?.closest?.('.ve-studio-nav-item,.ve-collection-drag,.ve-tree-toggle,.ve-media-thumb,.ve-media-selected-strip,.ve-media-batch-overlay');
  const isUploadFileDrag = e => !isInternalDragBlocked() && hasFileDrag(e) && !hasInternalDragType(e) && !hasMediaDrag(e) && !hasCollectionDrag(e) && !isInternalDragSource(e);
  const dragIsStillInside = (e, el) => {
    if (!el) return false;
    if (e?.relatedTarget && el.contains(e.relatedTarget)) return true;
    const rect = el.getBoundingClientRect();
    const x = e?.clientX || -1;
    const y = e?.clientY || -1;
    return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
  };
  const showFileDrop = e => {
    if (isInternalDragBlocked() || isInternalDragSource(e) || hasCollectionDrag(e)) {
      mediaDropDepthRef.current = 0;
      setDragActive(false);
      return false;
    }
    if (hasMediaDrag(e)) {
      mediaDropDepthRef.current = 0;
      mediaDragCandidateRef.current = true;
      setDragActive(false);
      return false;
    }
    if (!isUploadFileDrag(e)) {
      if (dragActive) setDragActive(false);
      mediaDropDepthRef.current = 0;
      return false;
    }
    if (fileDragClearTimerRef.current) clearTimeout(fileDragClearTimerRef.current);
    e.preventDefault();
    e.stopPropagation();
    mediaDragCandidateRef.current = false;
    if (!dragActive) setDragActive(true);
    return true;
  };
  const clearFileDrop = (delay = 90) => {
    if (fileDragClearTimerRef.current) clearTimeout(fileDragClearTimerRef.current);
    fileDragClearTimerRef.current = setTimeout(() => {
      mediaDropDepthRef.current = 0;
      mediaDragCandidateRef.current = false;
      setDragActive(false);
    }, delay);
  };
  useEffect(() => {
    const hideWordPressUploaderOverlay = () => {
      try {
        if (!document.body?.classList?.contains('ve-media-studio-open')) return;
        document.querySelectorAll('.uploader-window,[class*="uploader-window"]').forEach(node => {
          if (!node || node.closest?.('.ve-media-studio')) return;
          node.style.setProperty('display', 'none', 'important');
          node.style.setProperty('visibility', 'hidden', 'important');
          node.style.setProperty('opacity', '0', 'important');
          node.style.setProperty('pointer-events', 'none', 'important');
          node.style.setProperty('z-index', '-1', 'important');
        });
      } catch(err) {}
    };
    hideWordPressUploaderOverlay();
    const observer = new MutationObserver(hideWordPressUploaderOverlay);
    try { observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class','style'] }); } catch(err) {}
    const onDragActivity = () => hideWordPressUploaderOverlay();
    ['dragenter','dragover','dragleave','drop'].forEach(type => window.addEventListener(type, onDragActivity, true));
    return () => {
      try { observer.disconnect(); } catch(err) {}
      ['dragenter','dragover','dragleave','drop'].forEach(type => window.removeEventListener(type, onDragActivity, true));
    };
  }, []);

  const showExternalFolderTip = (label, e) => {
    const rect = e?.currentTarget?.getBoundingClientRect ? e.currentTarget.getBoundingClientRect() : null;
    if (!rect) return;
    const w = 200;
    const hgt = 104;
    const offset = 8;
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    let left = rect.left - w - offset;
    let placement = 'left';
    if (left < 8) {left = rect.right + offset;placement='right';}
    left = clamp(left, 8, window.innerWidth - w - 8);
    const top = clamp(rect.top + rect.height / 2 - hgt / 2, 8, window.innerHeight - hgt - 8);
    setExternalFolderTip({ label, left, top, placement });
  };

  const toggleDynamicGroup = key => {
    setDynamicCollapsed(prev => {
      const currentlyCollapsed = prev[key] !== false;
      const next = { ...prev, [key]: !currentlyCollapsed };
      try { localStorage.setItem('ve_media_dynamic_collapsed', JSON.stringify(next)); } catch(e) {}
      return next;
    });
  };

  const beginSidebarResize = e => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startWidth = sidebarWidth;
    const move = ev => {
      const next = Math.max(320, Math.min(480, startWidth + (ev.clientX - startX)));
      setSidebarWidth(next);
      try { localStorage.setItem('ve_media_sidebar_width', String(next)); } catch(err) {}
    };
    const up = () => {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', up);
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
  };

  /* ── Right-click, arrangement C ─────────────────────────────────────────
     Approved mock: docs/mocks/tools/2026-08-14-media-context-menu.html.
     Checklist ref C11.

     Every row here is an existing handler. The mock briefly carried "Star" and
     "Regenerate thumbnails"; neither exists for a media item (star is a
     collection property, and nothing in MV regenerates thumbnails) so neither
     is built. A menu row that leads nowhere is worse than no menu.

     The fold rule: the primary verb stays flat and its variants fold. Copy URL
     is visible; File path and HTML tag sit behind Copy as. */
  const [ctxMenu, setCtxMenu] = useState(null);

  const closeCtxMenu = useCallback(() => setCtxMenu(null), []);

  useEffect(() => {
    if (!ctxMenu) return undefined;
    // Same guard as the contextmenu handler: a target without closest() throws
    // here too, and a throw inside a capture listener takes the menu's only way
    // of closing with it.
    const away = e => { if (!(e.target && e.target.closest && e.target.closest('.ve-ctx'))) closeCtxMenu(); };
    const key = e => { if (e.key === 'Escape') { e.preventDefault(); closeCtxMenu(); } };
    document.addEventListener('pointerdown', away, true);
    document.addEventListener('keydown', key, true);
    window.addEventListener('resize', closeCtxMenu);
    return () => {
      document.removeEventListener('pointerdown', away, true);
      document.removeEventListener('keydown', key, true);
      window.removeEventListener('resize', closeCtxMenu);
    };
  }, [ctxMenu, closeCtxMenu]);

  /* Attached to the document while the studio is mounted, rather than to the
     grid container. Media Studio has three views — grid, masonry and a list
     table — and the list rows are rendered by a different function, so a
     container-scoped handler covered two of the three. Anything carrying
     data-media-id now answers, wherever it is drawn. */
  /* Capture phase, deliberately. Media Studio's own collection menus call
     stopPropagation on contextmenu, and so do several WP-admin and Bricks
     handlers, so a listener on document in the bubble phase can be silenced
     before it is ever reached. Capture runs on the way down, before anything
     can stop it. This is why right-click did nothing after three builds that
     each looked correct in the source. */
  const ctxHandlerRef = useRef(null);
  useEffect(() => {
    const fn = e => { if (ctxHandlerRef.current) ctxHandlerRef.current(e); };
    document.addEventListener('contextmenu', fn, true);
    return () => document.removeEventListener('contextmenu', fn, true);
  }, []);

  const onStudioContextMenu = e => {
    // e.target is not always an Element: a right-click can land on a text node
    // or the document, where closest() does not exist and throws, which kills
    // the listener silently for the rest of the session.
    const el = e.target && e.target.closest ? e.target : null;
    if (!el) return;
    // The listener is on document, so it hears every right-click on the page,
    // and MediaStudioSub is mounted more than once — the Content Studio picker
    // and the standalone panel can both be open. Without this, one right-click
    // opens a menu in each of them.
    const host = mediaLayoutRef.current;
    if (host && !host.contains(el)) return;
    // MV takes the right-click inside the studio only. Text fields keep the
    // native menu, because Paste and spellcheck live there.
    if (el.closest('input, textarea, [contenteditable="true"]')) return;
    const thumb = el.closest('[data-media-id]');
    if (!thumb) return;
    const id = Number(thumb.getAttribute('data-media-id'));
    const item = (items || []).find(x => Number(x.id) === id);
    if (!item) return;
    e.preventDefault();
    // Right-click aims the menu; it does not select. Ticking the checkbox and
    // opening the details panel were both side effects nobody asked for: the
    // batch bar appeared, the checkbox filled, and "Open in the side panel"
    // became a row that had already happened before you could read it.
    // The tile the menu belongs to is marked by a dashed ring instead —
    // .ve-ctx-target, the approved mock's own answer.
    //
    // A right-click inside the checked set still acts on all of it, so the
    // plural labels stay truthful; outside it, the menu acts on that one file
    // and leaves the selection exactly as the owner left it.
    const ids = checkedItems.includes(id) ? checkedItems.slice() : [id];
    // Stored in the studio's frame, because that is the frame the menu is
    // positioned in. Same conversion the collection menus do.
    const b = host && host.getBoundingClientRect ? host.getBoundingClientRect() : null;
    setCtxMenu({
      x: b ? e.clientX - b.left : e.clientX,
      y: b ? e.clientY - b.top : e.clientY,
      item, ids
    });
  };

  ctxHandlerRef.current = onStudioContextMenu;

  const ctxRows = () => {
    if (!ctxMenu) return [];
    const { item, ids } = ctxMenu;
    const many = ids.length > 1;
    const img = isImageFile(item);
    const path = (() => { try { return new URL(item.source_url).pathname; } catch (e) { return item.source_url; } })();
    const inColl = isLocalCollectionOpen() && collIds(selectedColl).includes(item.id);
    const targets = collKeys.filter(k => !collIds(k).includes(item.id));
    return [
      { label: 'Open in the side panel', hint: 'Enter',
        run: () => setSelected(item) },
      { label: 'Open in the WP editor',
        run: () => window.open(getAdminBase() + 'post.php?post=' + item.id + '&action=edit', '_blank') },
      { label: 'Copy URL', hint: 'Ctrl C', run: () => handleCopyLink(item.source_url) },
      { label: 'Copy as', sub: [
        { label: 'File path', run: () => { navigator.clipboard.writeText(path); flash('Copied file path'); } },
        { label: 'HTML tag', run: () => handleCopyTag(item) }
      ] },
      { label: 'Insert into the control', off: typeof onInsertMedia !== 'function',
        hint: typeof onInsertMedia === 'function' ? '' : 'picker only',
        run: () => insertSelectedMedia(item) },
      { sep: true },
      { label: 'Replace file', off: many,
        run: () => { setSelected(item); replaceInputRef.current?.click(); } },
      { label: 'Convert to', off: !img || many, sub: ['WEBP', 'JPEG', 'AVIF'].map(f => ({
        label: f, run: () => { setSelected(item); setConvertFormat(f.toLowerCase()); setTimeout(convertSelected, 0); } })) },
      { sep: true },
      // collLabel, not collectionLabel — the latter has never existed. It threw a
      // ReferenceError here while the rows were being built, which killed the whole
      // render, which is why right-click did nothing at all: the menu never reached
      // the DOM to be looked for. Four builds went past this because the throw was
      // an unhandled promise rejection inside Preact rather than a visible error.
      { label: 'Add to collection', off: targets.length === 0, sub: targets.slice(0, 8).map(k => ({
        label: collLabel(k), run: () => ids.forEach(x => toggleCollectionItem(k, x, true)) })) },
      { label: 'Remove from collection', off: !inColl,
        run: () => ids.forEach(x => toggleCollectionItem(selectedColl, x, false)) },
      { label: many ? ('Download ' + ids.length + ' files') : 'Download file',
        run: () => ids.forEach(x => { const it = items.find(y => Number(y.id) === Number(x)); if (it) downloadMediaUrl(it); }) },
      { sep: true },
      { label: many ? ('Delete ' + ids.length + ' files permanently') : 'Delete permanently',
        bad: true, run: () => handleDelete(item) }
    ];
  };

  const handleUploadFiles = async (files) => {
    const fileList = Array.from(files || []);
    if (!fileList.length) return;
    setUploading(true);
    setMediaBusyMessage('');
    const uploadedIds = [];
    const failedNames = [];
    const failReasons = [];
    setUploadProgress({ done: 0, total: fileList.length, name: fileList[0]?.name || '', state: 'Uploading', percent: 1 });
    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      setUploadProgress({ done: i, total: fileList.length, name: file.name || '', state: 'Uploading', percent: Math.max(1, Math.round((i / fileList.length) * 100)) });
      try {
        const item = await uploadWithProgress('wp/v2/media', file, {
          'Content-Disposition': 'attachment; filename="' + headerSafeFilename(file.name) + '"',
          'Content-Type': file.type || 'application/octet-stream',
          // Tells the plugin this upload came from Media Studio, which is the
          // only context where the font MIME types are permitted.
          'X-MV-Media-Upload': '1'
        }, percent => {
          const overall = Math.max(1, Math.min(99, Math.round(((i + percent / 100) / fileList.length) * 100)));
          setUploadProgress({ done: i, total: fileList.length, name: file.name || '', state: 'Uploading', percent: overall });
        });
        if (item && item.id) {
          uploadedIds.push(Number(item.id));
          setItems(prev => [item, ...prev]);
        } else {
          failedNames.push(file.name || 'media');
          failReasons.push('WordPress accepted the request but returned no media item.');
        }
      } catch (err) {
        failedNames.push(file.name || 'media');
        failReasons.push(String(err?.message || 'Upload failed.'));
      }
      setUploadProgress({ done: i + 1, total: fileList.length, name: file.name || '', state: i + 1 === fileList.length ? 'Upload complete' : 'Uploading', percent: Math.round(((i + 1) / fileList.length) * 100) });
    }
    addUploadedToOpenCollection(uploadedIds);
    setUploading(false);
    // A failure has to say why. "2 failed" with no reason sent people looking
    // for a broken upload when the real answer was a rejected file type.
    const distinctReasons = failReasons.filter((reason, index) => failReasons.indexOf(reason) === index);
    setUploadProgress({
      done: fileList.length,
      total: fileList.length,
      name: failedNames.length
        ? uploadedIds.length + ' uploaded · ' + failedNames.length + ' failed'
        : uploadedIds.length + ' file' + (uploadedIds.length === 1 ? '' : 's') + ' uploaded',
      reason: failedNames.length
        ? distinctReasons.slice(0, 2).join(' ') + (failedNames.length <= 3 ? ' (' + failedNames.join(', ') + ')' : '')
        : '',
      sticky: failedNames.length > 0,
      state: failedNames.length ? 'Upload finished' : 'Upload complete',
      percent: 100
    });
    if (!failedNames.length) setTimeout(() => setUploadProgress(null), 5000);
  };

  const doUrlImport = async (url) => {
    setPendingUrlImport(null);
    setUrlImportBusy(true);
    setUploading(true);
    setUploadProgress({ done: 0, total: 1, name: url.split('/').pop() || 'URL', state: 'Importing', percent: 30 });
    try {
      const res = await api.p('media-studio/import-url', { url, collection: isLocalCollectionOpen() ? selectedColl : '' });
      if (res && res.success && res.item) {
        setItems(prev => [res.item, ...prev]);
        addUploadedToOpenCollection([Number(res.item.id)]);
        refreshUrlImportHistory();
        refreshDiagnostics();
        flash('Imported ' + (res.item.title?.rendered || url.split('/').pop() || 'media'));
      } else {
        refreshUrlImportHistory();
        flash(res?.message || 'Import failed.');
      }
    } catch (err) {
      refreshUrlImportHistory();
      flash((err && err.message) || 'URL import failed.');
    }
    setUrlImportBusy(false);
    setUploading(false);
    setUploadProgress(null);
    if (urlImportRef.current) urlImportRef.current.value = '';
  };

  const handleUrlImport = async (rawUrl) => {
    const url = (rawUrl || '').trim();
    if (!url) return;
    if (!/^https?:\/\//i.test(url)) { flash('Enter a valid HTTP or HTTPS URL.'); return; }
    setUrlImportBusy(true);
    try {
      const res = await api.p('media-studio/import-url/preview', { url });
      if (res && res.success) {
        setPendingUrlImport(res);
      } else {
        flash(res?.message || 'Could not preview that URL.');
      }
    } catch (err) {
      flash((err && err.message) || 'URL preview failed.');
    }
    setUrlImportBusy(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (fileDragClearTimerRef.current) clearTimeout(fileDragClearTimerRef.current);
    mediaDropDepthRef.current = 0;
    setDragActive(false);
    if (hasMediaDrag(e) || hasCollectionDrag(e)) return;
    if (e.dataTransfer?.files && e.dataTransfer.files.length) {
      handleUploadFiles(e.dataTransfer.files);
    }
  };

  const handleSelect = (item) => {
    setSelected(prev => prev && prev.id === item.id ? { ...item } : item);
  };

  const handleMediaClick = (item, e, idx) => {
    const hasModifier = !!(e && (e.shiftKey || e.ctrlKey || e.metaKey));
    if (picking && e && !hasModifier) {
      const now = Date.now();
      const prev = pickerClickRef.current || { id: null, at: 0 };
      if ((Number(e.detail || 0) >= 2) || (String(prev.id) === String(item.id) && now - Number(prev.at || 0) < 520)) {
        pickerClickRef.current = { id: null, at: 0 };
        handleMediaDoubleClick(item, e, idx);
        return;
      }
      pickerClickRef.current = { id: item.id, at: now };
    }
    if (e && hasModifier) {
      e.preventDefault();
      if (e.shiftKey && lastMediaIndex !== null) {
        const start = Math.min(lastMediaIndex, idx);
        const end = Math.max(lastMediaIndex, idx);
        const range = filtered.slice(start, end + 1).map(x => x.id);
        setCheckedItems(prev => prev.includes(item.id) ? prev.filter(id => !range.includes(id)) : [...new Set([...prev, ...range])]);
      } else {
        toggleCheckItem(item.id, e, idx);
        setLastMediaIndex(idx);
      }
      setSelected(item);
      return;
    }
    handleSelect(item);
    setLastMediaIndex(idx);
  };

  const handleCopyLink = (url) => {
    navigator.clipboard.writeText(url);
    flash('Copied URL');
  };

  const handleCopyTag = (item) => {
    const tag = `<img src="${item.source_url}" alt="${item.alt_text || ''}" />`;
    navigator.clipboard.writeText(tag);
    flash('Copied HTML Tag');
  };

  const fetchMediaUsageSafe = async (id) => {
    try {
      const res = await api.g('media-studio/usage/' + id);
      return res && res.success ? res : { success: false, total: 0, groups: {} };
    } catch (e) {
      return { success: false, total: 0, groups: {}, message: (e && e.message) || 'Usage check failed.' };
    }
  };

  const usageRowsFromReport = usage => Object.entries(usage?.groups || {}).flatMap(([group, rows]) => (Array.isArray(rows) ? rows : []).map(row => ({ ...row, group })));

  const renderUsageSafetySummary = (usage, fallback) => {
    if (!usage) return h('div', { class: 've-safety-note' }, h('span', { class: 've-media-progress-spinner' }), 'Checking usage…');
    const rows = usageRowsFromReport(usage);
    if (!rows.length) return h('div', { class: 've-safety-ok' }, ph('shield-check'), fallback || 'No safe usage detected. Custom code or CDN references may still exist.');
    return h('div', { class: 've-safety-warning' },
      h('strong', null, rows.length + ' detected use' + (rows.length === 1 ? '' : 's')),
      h('em', null, 'Review these before replacing or deleting this file.'),
      h('div', { class: 've-safety-usage-list' }, rows.slice(0, 5).map((row, idx) => h('div', { class: 've-safety-usage-row', key: idx },
        h('span', null, row.label || row.id || row.group),
        h('small', null, (row.source || row.group) + (row.detail ? ' · ' + row.detail : ''))
      ))),
      rows.length > 5 && h('small', null, '+' + (rows.length - 5) + ' more detected references')
    );
  };

  const handleDelete = async (item) => {
    if (!item) return;
    setPendingDeleteMedia({ item, usage: null, loading: true });
    const usage = await fetchMediaUsageSafe(item.id);
    setPendingDeleteMedia(prev => prev && Number(prev.item?.id) === Number(item.id) ? { ...prev, usage, loading: false } : prev);
  };

  const confirmDeleteMedia = async () => {
    const item = pendingDeleteMedia?.item || pendingDeleteMedia;
    if (!item) return;
    setPendingDeleteMedia(null);
    setMediaBusyMessage('Deleting media…');
    setLoading(true);
    try {
      const res = await api.f('wp/v2/media/' + item.id + '?force=true', { method: 'DELETE' });
      if (res && res.deleted) {
        setItems(prev => prev.filter(x => x.id !== item.id));
        if (selected && selected.id === item.id) setSelected(null);
        setCheckedItems(prev => prev.filter(id => id !== item.id));
        refreshDiagnostics();
        flash('Deleted media');
      } else {
        flash('Delete failed');
      }
    } catch (e) {
      flash('Delete failed');
    }
    setLoading(false);
    setMediaBusyMessage('');
  };

  const handleAltTextSave = async (id, value) => {
    setItems(prev => prev.map(x => x.id === id ? { ...x, alt_text: value } : x));
    if (selected && selected.id === id) {
      setSelected(prev => ({ ...prev, alt_text: value }));
    }
    if (selected && selected.id === id) { setAltDraft(value); setMediaSaveState('Saving alt text…'); }
    try {
      const res = await api.p('media-studio/metadata', { attachment_id: id, alt_text: value });
      if (res && res.item) {
        mergeMediaItem(res.item);
        broadcastMediaItemUpdate(res.item);
        if (selected && selected.id === id) setMediaSaveState('Saved');
        flash('Alt text saved.');
      } else {
        if (selected && selected.id === id) setMediaSaveState('Save failed');
        flash(res?.message || 'Failed to save alt text on WordPress.');
      }
    } catch (e) {
      if (selected && selected.id === id) setMediaSaveState('Save failed');
      flash('Failed to save alt text on WordPress.');
    }
  };

  const titleToAltText = item => {
    const title = (item?.title?.raw || item?.title?.rendered || item?.filename || '').replace(/\.[a-z0-9]+$/i, '');
    return title.replace(/[-_]+/g, ' ').replace(/\s+/g, ' ').trim();
  };

  const saveSelectedMetadata = async () => {
    if (!selected) return;
    setMediaSaveState('Saving metadata…');
    try {
      const res = await api.p('media-studio/metadata', {
        attachment_id: selected.id,
        title: filenameDraft,
        alt_text: altDraft,
        caption: captionDraft,
        description: descriptionDraft
      });
      if (res && res.item) {
        mergeMediaItem(res.item);
        broadcastMediaItemUpdate(res.item);
        setMediaSaveState('Saved');
        flash('Media metadata saved.');
      } else {
        setMediaSaveState('Save failed');
        flash(res?.message || 'Metadata save failed.');
      }
    } catch (e) {
      setMediaSaveState('Save failed');
      flash('Metadata save failed.');
    }
  };

  const bulkFillMissingAltFromFilename = async () => {
    const source = checkedItems.length ? checkedItems.map(id => items.find(x => Number(x.id) === Number(id))).filter(Boolean) : filtered;
    const targets = source.filter(item => isImageFile(item) && !(item.alt_text || '').trim());
    if (!targets.length) { flash('No selected or visible images are missing alt text.'); return; }
    setMediaBusyMessage('');
    setUploadProgress({ done: 0, total: targets.length, name: 'Missing alt text', state: 'Filling alt text', percent: 1 });
    let saved = 0;
    for (let i = 0; i < targets.length; i++) {
      const item = targets[i];
      const alt = titleToAltText(item);
      setUploadProgress({ done: i, total: targets.length, name: item.title?.rendered || item.filename || 'image', state: 'Filling alt text', percent: Math.max(1, Math.round((i / targets.length) * 100)) });
      if (!alt) continue;
      try {
        const res = await api.p('media-studio/metadata', { attachment_id: item.id, alt_text: alt });
        if (res && res.item) {
          saved++;
          mergeMediaItem(res.item);
          broadcastMediaItemUpdate(res.item);
        }
      } catch(e) {}
    }
    setUploadProgress({ done: targets.length, total: targets.length, name: 'Missing alt text', state: 'Alt text filled', percent: 100 });
    setMediaBusyMessage('');
    setTimeout(() => setUploadProgress(null), 5000);
    flash('Filled alt text for ' + saved + ' image' + (saved === 1 ? '' : 's') + '.');
  };

  const toggleCheckItem = (id, event, idx) => {
    const shouldCheck = !checkedItems.includes(id);
    const shiftHeld = !!(
      event?.shiftKey ||
      event?.__veShiftKey ||
      event?.nativeEvent?.shiftKey ||
      event?.currentTarget?.__veShiftKey ||
      event?.currentTarget?.parentNode?.__veShiftKey ||
      (typeof window !== 'undefined' && window.__veLastShiftCheckUntil && window.__veLastShiftCheckUntil > Date.now())
    );
    if (shiftHeld && lastMediaIndex !== null && typeof idx === 'number') {
      const start = Math.min(lastMediaIndex, idx);
      const end = Math.max(lastMediaIndex, idx);
      const range = filtered.slice(start, end + 1).map(x => x.id);
      setCheckedItems(prev => shouldCheck ? [...new Set([...prev, ...range])] : prev.filter(x => !range.includes(x)));
      setLastMediaIndex(idx);
      return;
    }
    setCheckedItems(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
    if (typeof idx === 'number') setLastMediaIndex(idx);
  };

  const toggleCheckRange = (id, idx) => {
    if (lastMediaIndex === null || typeof idx !== 'number') {
      toggleCheckItem(id, { __veShiftKey: false }, idx);
      return;
    }
    const shouldCheck = !checkedItems.includes(id);
    const start = Math.min(lastMediaIndex, idx);
    const end = Math.max(lastMediaIndex, idx);
    const range = filtered.slice(start, end + 1).map(x => x.id);
    setCheckedItems(prev => shouldCheck ? [...new Set([...prev, ...range])] : prev.filter(x => !range.includes(x)));
    setLastMediaIndex(idx);
  };

  const toggleCheckAll = () => {
    const currentList = filtered.map(x => x.id);
    if (checkedItems.length === currentList.length) {
      setCheckedItems([]);
    } else {
      setCheckedItems(currentList);
    }
  };

  const handleBatchAddToCollection = () => {
    setPendingBatchCollection(true);
  };

  const applyBatchCollection = (targetColl) => {
    if (!targetColl) return;
    if (isFolderCollection(targetColl)) {
      checkedItems.forEach(id => toggleCollectionItem(targetColl, id, true));
    } else {
      const entry = collectionMap[targetColl] || { ids: [], icon: 'folder' };
      if (entry.locked) {
        flash('Unlock "' + collLabel(targetColl) + '" before adding media.');
        return;
      }
      const currentIds = entry.ids || [];
      const newIds = [...new Set([...currentIds, ...checkedItems])];
      persistCollections({ ...collectionMap, [targetColl]: { ...entry, ids: newIds } });
    }
    flash(`Added ${checkedItems.length} items to "${collLabel(targetColl)}"!`);
    setCheckedItems([]);
    setPendingBatchCollection(false);
  };

  const addMediaIdsToCollection = (targetColl, ids) => {
    const cleanIds = [...new Set((ids || []).map(id => parseInt(id, 10)).filter(Boolean))];
    if (!targetColl || !cleanIds.length) return;
    if (targetColl === 'all' || targetColl === 'uncollected') {
      flash('Choose a real collection to add media.');
      return;
    }
    if (isFolderCollection(targetColl)) {
      cleanIds.forEach(id => toggleCollectionItem(targetColl, id, true));
    } else {
      const entry = collectionMap[targetColl] || { ids: [], icon: 'folder' };
      if (entry.locked) {
        flash('Unlock "' + collLabel(targetColl) + '" before adding media.');
        return;
      }
      const newIds = [...new Set([...(entry.ids || []), ...cleanIds])];
      persistCollections({ ...collectionMap, [targetColl]: { ...entry, ids: newIds } });
    }
    flash(`Added ${cleanIds.length} item${cleanIds.length === 1 ? '' : 's'} to "${collLabel(targetColl)}".`);
  };

  const downloadMediaUrl = item => {
    if (!item?.source_url) return;
    const a = document.createElement('a');
    a.href = item.source_url;
    a.download = (item.title?.rendered || item.slug || 'media') + '.' + fileExt(item).toLowerCase();
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const downloadCollectionZip = async key => {
    const ids = collIds(key);
    if (!ids.length) { flash('This collection has no files to download.'); return; }
    try {
      const res = await api.p('media-studio/collection-zip', { collection: collLabel(key), attachment_ids: ids });
      if (res?.url) {
        window.open(res.url, '_blank');
        flash('Collection ZIP is ready.');
      } else {
        flash(res?.message || 'Could not create collection ZIP.');
      }
    } catch (e) {
      flash('Could not create collection ZIP.');
    }
  };

  const downloadAllLibraryZip = async () => {
    setCollectionMenu(null);
    setUploadProgress({ done: 0, total: 1, name: 'Entire media library', state: 'Building library ZIP', busy: true, percent: 30 });
    try {
      const res = await api.p('media-studio/collection-zip', { collection: 'all-media', all: true });
      if (res?.url) {
        window.open(res.url, '_blank');
        setUploadProgress({ done: 1, total: 1, name: (res.count || '') + ' files', state: 'Library ZIP ready', percent: 100 });
        flash('Entire media library ZIP is ready.');
      } else {
        setUploadProgress({ done: 0, total: 1, name: 'Entire media library', state: 'Library ZIP failed', percent: 0 });
        flash(res?.message || 'Could not create the library ZIP.');
      }
    } catch (e) {
      setUploadProgress({ done: 0, total: 1, name: 'Entire media library', state: 'Library ZIP failed', percent: 0 });
      flash('Could not create the library ZIP.');
    }
    setTimeout(() => setUploadProgress(null), 5000);
  };

  const downloadSelectedZip = async () => {
    const ids = [...new Set(checkedItems.map(id => Number(id)).filter(Boolean))];
    if (!ids.length) { flash('Select media to export first.'); return; }
    setUploadProgress({ done: 0, total: 1, name: ids.length + ' selected media', state: 'Building export ZIP', busy: true, percent: 40 });
    try {
      const res = await api.p('media-studio/collection-zip', { collection: 'selected-media', attachment_ids: ids });
      if (res?.url) {
        window.open(res.url, '_blank');
        setUploadProgress({ done: 1, total: 1, name: (res.count || ids.length) + ' files', state: 'Export ZIP ready', percent: 100 });
        flash('Selected media ZIP is ready.');
      } else {
        setUploadProgress({ done: 0, total: 1, name: ids.length + ' selected media', state: 'Export ZIP failed', percent: 0 });
        flash(res?.message || 'Could not create selected media ZIP.');
      }
    } catch (e) {
      setUploadProgress({ done: 0, total: 1, name: ids.length + ' selected media', state: 'Export ZIP failed', percent: 0 });
      flash('Could not create selected media ZIP.');
    }
    setTimeout(() => setUploadProgress(null), 5000);
  };

  const chooseZipForCollection = key => {
    if (!key || isFolderCollection(key)) return;
    if (isLockedCollection(key)) { flash('Unlock this collection before importing ZIP media.'); return; }
    zipImportTargetRef.current = key;
    setCollectionMenu(null);
    setTimeout(() => zipImportRef.current?.click(), 0);
  };

  const importZipToCollection = async file => {
    const key = zipImportTargetRef.current;
    if (!file || !key) return;
    const fd = new FormData();
    fd.append('collection', key);
    fd.append('zip_file', file);
    setZipImportBusy(true);
    setUploadProgress({ done: 0, total: 1, name: file.name || 'collection.zip', state: 'Uploading ZIP', percent: 1 });
    let zipSuccess = false;
    try {
      const res = await uploadWithProgress('variable-engine/v1/media-studio/import-zip', fd, {}, percent => {
        const rawPct = Math.max(1, Math.min(100, Math.round(Number(percent) || 1)));
        const uploadPct = rawPct >= 99 ? 90 : Math.max(2, Math.min(90, Math.round(rawPct * 0.9)));
        setUploadProgress({ done: 0, total: 1, name: file.name || 'collection.zip', state: rawPct >= 99 ? 'Extracting ZIP' : 'Uploading ZIP', percent: uploadPct, busy: rawPct >= 99 });
      });
      if (res && res.success) {
        zipSuccess = true;
        if (Array.isArray(res.items) && res.items.length) {
          setItems(prev => {
            const existing = new Set(prev.map(x => Number(x.id)));
            return [...res.items.filter(x => !existing.has(Number(x.id))), ...prev];
          });
          if (Array.isArray(VE_MEDIA_CACHE.items)) {
            const existing = new Set(VE_MEDIA_CACHE.items.map(x => Number(x.id)));
            publishMediaCache([...res.items.filter(x => !existing.has(Number(x.id))), ...VE_MEDIA_CACHE.items], true);
          }
        }
        if (res.collections) applyServerCollections(res);
        refreshDiagnostics();
        setSelectedColl(key);
        flash('Imported ' + (res.count || 0) + ' media file' + ((res.count || 0) === 1 ? '' : 's') + ' into "' + collLabel(key) + '".');
      } else {
        flash(res?.message || 'ZIP import failed.');
      }
    } catch (e) {
      flash((e && e.message) || 'ZIP import failed.');
    }
    setUploadProgress({ done: zipSuccess ? 1 : 0, total: 1, name: file.name || 'collection.zip', state: zipSuccess ? 'ZIP import complete' : 'ZIP import failed', percent: zipSuccess ? 100 : 0 });
    setTimeout(() => setUploadProgress(null), 5000);
    setZipImportBusy(false);
    zipImportTargetRef.current = '';
    if (zipImportRef.current) zipImportRef.current.value = '';
  };

  const requestFilenameSave = () => {
    if (!selected) return;
    const next = filenameDraft.trim();
    const current = selected.title?.rendered || '';
    if (!next || next === current) return;
    setPendingRename({ item: selected, title: next });
  };

  const applyFilenameSave = async (renameFile) => {
    const pending = pendingRename;
    if (!pending) return;
    setPendingRename(null);
    setLoading(true);
    const res = await api.p('media-studio/rename', { attachment_id: pending.item.id, title: pending.title, rename_file: !!renameFile });
    setLoading(false);
    if (res && res.item) {
      setItems(prev => prev.map(x => x.id === pending.item.id ? res.item : x));
      setSelected(res.item);
      flash(renameFile ? 'Filename and media title updated.' : 'Media title updated.');
    } else {
      flash(res?.message || 'Rename failed.');
      setFilenameDraft(pending.item.title?.rendered || '');
    }
  };

  const handleBatchDelete = async () => {
    const ids = [...checkedItems];
    if (!ids.length) return;
    setPendingBatchDelete({ ids, loading: true, usages: [], usedCount: 0, sampled: Math.min(ids.length, 12) });
    const sample = ids.slice(0, 12);
    const usages = [];
    let usedCount = 0;
    for (const id of sample) {
      const usage = await fetchMediaUsageSafe(id);
      if ((usage?.total || 0) > 0) usedCount++;
      usages.push({ id, item: items.find(x => Number(x.id) === Number(id)), usage });
    }
    setPendingBatchDelete(prev => prev ? { ...prev, usages, usedCount, loading: false } : prev);
  };

  const confirmBatchDelete = async () => {
    const ids = pendingBatchDelete?.ids ? [...pendingBatchDelete.ids] : [...checkedItems];
    const total = ids.length;
    setPendingBatchDelete(false);
    if (!total) return;
    setUploadProgress({ done: 0, total, name: total + ' selected media', state: 'Deleting selected media', percent: 1 });
    const deleted = [];
    for (let i = 0; i < ids.length; i++) {
      const id = ids[i];
      const item = items.find(x => Number(x.id) === Number(id));
      setUploadProgress({ done: i, total, name: item?.title?.rendered || ('Media #' + id), state: 'Deleting selected media', percent: Math.max(1, Math.round((i / total) * 100)) });
      try {
        const res = await api.f('wp/v2/media/' + id + '?force=true', { method: 'DELETE' });
        if (!res || res.deleted !== false) deleted.push(id);
      } catch (e) {}
    }
    setItems(prev => prev.filter(x => !deleted.includes(x.id)));
    if (selected && deleted.includes(selected.id)) setSelected(null);
    setCheckedItems(prev => prev.filter(id => !deleted.includes(id)));
    refreshDiagnostics();
    setUploadProgress({ done: total, total, name: deleted.length + ' deleted', state: 'Delete complete', percent: 100 });
    setTimeout(() => setUploadProgress(null), 5000);
    flash(deleted.length === 1 ? 'Media deleted.' : `Deleted ${deleted.length} media file${deleted.length === 1 ? '' : 's'}.`);
  };

  const getFileSize = (item) => {
    if (item?.file_size) return Number(item.file_size) || 0;
    if (item?.media_details?.filesize) return item.media_details.filesize;
    if (item?.media_details?.sizes?.full?.file_size) return item.media_details.sizes.full.file_size;
    return (item?.id % 200 + 45) * 1024;
  };

  const fileExt = item => {
    const src = item?.source_url || '';
    const clean = src.split('?')[0].split('#')[0];
    const ext = clean.indexOf('.') !== -1 ? clean.split('.').pop() : '';
    return (ext || (item?.mime_type || '').split('/').pop() || 'file').toUpperCase();
  };
  const authorLabel = item => item?.author_name || item?._embedded?.author?.[0]?.name || item?._embedded?.['wp:author']?.[0]?.name || (item?.author ? 'Author #' + item.author : 'Unknown');
  const collectionLeafLabel = key => (collLabel(key) || '').split('/').map(x => x.trim()).filter(Boolean).pop() || collLabel(key);
  const collectionDepth = key => (collLabel(key) || '').split('/').filter(Boolean).length;
  const setMediaDynamicFilter = (type, value, label) => {
    setDynamicFilter({ type, value, label });
    setSelectedColl('all');
  };

  const mediaSizeBuckets = [
    { label: '0-1 MB', value: '0-1' },
    { label: '1-10 MB', value: '1-10' },
    { label: '10-100 MB', value: '10-100' },
    { label: 'Over 100 MB', value: '100+' }
  ];

  const isFontFile = item => /font|woff|ttf|otf|eot/i.test((item?.mime_type || '') + ' ' + (item?.source_url || ''));
  const isImageFile = item => (item?.mime_type || '').indexOf('image/') === 0;
  const isVideoFile = item => /video\/|\.((mp4|webm|mov|m4v|ogv))(\?|#|$)/i.test(String((item?.mime_type || '') + ' ' + (item?.source_url || '') + ' ' + (item?.filename || '')));
  const isSvgMedia = item => /image\/svg\+xml|\.svg(\?|#|$)/i.test(String((item?.mime_type || '') + ' ' + (item?.source_url || '') + ' ' + (item?.filename || '')));
  const cleanMediaUrl = value => {
    if (typeof value !== 'string') return '';
    const next = value.trim();
    return next && next !== 'false' && next !== 'undefined' && next !== 'null' ? next : '';
  };
  const mediaUrlWithBust = (url, bust) => {
    const clean = cleanMediaUrl(url);
    if (!clean || !bust) return clean;
    const split = clean.split('#');
    return split[0] + (split[0].includes('?') ? '&' : '?') + 've_preview=' + encodeURIComponent(String(bust)) + (split[1] ? '#' + split[1] : '');
  };
  const mediaPreviewUrl = (item, preferFull) => {
    const sizes = item?.media_details?.sizes || {};
    // SVGs must render from their original attachment URL. Some WordPress/SVG
    // helper plugins expose generated "sizes" thumbnails that are only
    // placeholder stripes, which made masonry cards show lines instead of
    // the actual vector preview inside Bricks.
    if (isSvgMedia(item)) {
      const candidates = [
        item?.source_url,
        item?.url,
        item?.guid?.rendered,
        sizes.full?.source_url,
        sizes.full?.url,
        sizes.large?.source_url,
        sizes.large?.url,
        sizes.medium_large?.source_url,
        sizes.medium_large?.url,
        sizes.medium?.source_url,
        sizes.medium?.url,
        sizes.thumbnail?.source_url,
        sizes.thumbnail?.url
      ];
      return mediaUrlWithBust(candidates.map(cleanMediaUrl).find(Boolean) || '', item?._vePreviewBust);
    }
    const isMasonryPreview = preferFull === 'masonry';
    const candidates = isMasonryPreview
      ? [
          sizes.medium_large?.source_url,
          sizes.medium_large?.url,
          sizes.large?.source_url,
          sizes.large?.url,
          sizes.medium?.source_url,
          sizes.medium?.url,
          sizes.full?.source_url,
          sizes.full?.url,
          item?.source_url,
          item?.url,
          item?.guid?.rendered,
          sizes.thumbnail?.source_url,
          sizes.thumbnail?.url
        ]
      : preferFull
      ? [
          item?.source_url,
          item?.url,
          item?.guid?.rendered,
          sizes.full?.source_url,
          sizes.full?.url,
          sizes.large?.source_url,
          sizes.large?.url,
          sizes.medium_large?.source_url,
          sizes.medium_large?.url,
          sizes.medium?.source_url,
          sizes.medium?.url,
          sizes.thumbnail?.source_url,
          sizes.thumbnail?.url
        ]
      : [
          sizes.thumbnail?.source_url,
          sizes.thumbnail?.url,
          sizes.medium?.source_url,
          sizes.medium?.url,
          item?.source_url,
          item?.url,
          item?.guid?.rendered
        ];
    return mediaUrlWithBust(candidates.map(cleanMediaUrl).find(Boolean) || '', item?._vePreviewBust);
  };

  const renderFilePreview = (item, mode) => {
    const modeName = String(mode || '');
    const modeParts = modeName.split(':');
    const detailMode = modeName.startsWith('detail:') ? modeParts[1] : '';
    const detailZoom = Math.max(1, Math.min(4, parseFloat(modeParts[2] || '1') || 1));
    const isFullPreview = modeName === 'detail' || modeName === 'hover' || modeName === 'bento' || modeName.startsWith('detail:');
    const thumb = mediaPreviewUrl(item, modeName === 'masonry' ? 'masonry' : isFullPreview);
    if (isImageFile(item)) {
      const zoomWidth = Math.round(detailZoom * 100);
      const masonryLike = modeName === 'masonry' || modeName === 'bento';
      const resetDetailScroll = () => {
        if (!modeName.startsWith('detail:')) return;
        requestAnimationFrame(() => {
          const el = detailPreviewRef.current;
          if (!el) return;
          el.scrollLeft = 0;
          el.scrollTop = 0;
        });
      };
      const svgPreview = isSvgMedia(item);
      let imgStyle = masonryLike
        ? 'width:100%;height:auto;max-width:100%;max-height:none;object-fit:contain;display:block'
        : detailMode === 'fit-width'
        ? 'width:100%;height:auto;max-width:100%;max-height:none;object-fit:contain;display:block'
        : detailMode === 'actual'
          ? 'width:auto;height:auto;max-width:none;max-height:none;object-fit:contain;display:block'
          : detailMode === 'zoom'
            ? `width:${zoomWidth}%;height:auto;max-width:none;max-height:none;object-fit:contain;display:block;transform-origin:top left`
          : 'width:100%;height:100%;object-fit:' + (isFullPreview || modeName === 'masonry' || modeName === 'bento' ? 'contain' : 'cover');
      let wrapStyle = masonryLike
        ? 'width:100%;height:auto;display:block;min-height:0'
        : detailMode === 'fit-width'
        ? 'width:100%;height:auto;display:block;min-height:0;overflow:visible'
        : detailMode === 'actual'
          ? 'width:100%;min-width:100%;height:auto;display:block;min-height:0;overflow:visible'
        : detailMode === 'zoom'
        ? 'width:100%;min-width:100%;min-height:0;display:block;overflow:visible'
        : 'width:100%;height:100%;display:flex;align-items:center;justify-content:center';
      if (svgPreview && masonryLike) {
        imgStyle = 'display:block;width:auto;max-width:100%;height:auto;max-height:none;object-fit:contain;background:transparent;min-width:48px;min-height:48px';
        wrapStyle = 'width:auto;max-width:100%;height:auto;display:inline-flex;align-items:flex-start;justify-content:flex-start;min-height:48px;background:transparent;line-height:0';
      }
      const fallback = h('div', { class: 've-preview-fallback' }, ph('image-square'), h('span', null, 'Preview unavailable'), h('em', null, fileExt(item)));
      if (!thumb) return h('div', { class: 've-checker-bg ve-preview-missing', style: wrapStyle }, fallback);
      const markPreviewFailed = event => {
        const wrap = event?.currentTarget?.closest?.('.ve-checker-bg');
        if (wrap) wrap.classList.add('ve-preview-failed');
      };
      return h('div', { class: 've-checker-bg' + (svgPreview ? ' ve-svg-preview-bg' : ''), style: wrapStyle },
        h('img', { class: svgPreview ? 've-svg-preview-img' : '', src: thumb, style: imgStyle, loading: (modeName === 'masonry' || modeName.startsWith('detail')) ? 'eager' : 'lazy', decoding: 'async', onLoad: resetDetailScroll, onError: markPreviewFailed }),
        fallback
      );
    }
    if (isVideoFile(item)) {
      const label = item?.title?.rendered || item?.filename || 'Video';
      return modeName === 'detail' || modeName.startsWith('detail:')
        ? h(MediaVideoPlayer, { src: thumb, label })
        : h(MediaVideoThumbnail, { src: thumb, label, onDimensions: (width, height) => {
          const ratio = width > 0 && height > 0 ? width / height : 0;
          if (!ratio) return;
          setVideoAspectRatios(previous => previous[item.id] === ratio ? previous : { ...previous, [item.id]: ratio });
        } });
    }
    if (isFontFile(item)) return h('div', { class: 've-font-file-card' }, h('span', null, 'Aa'), h('em', null, fileExt(item)));
    return h('div', { class: 've-file-card' }, ph((item.mime_type || '').startsWith('video/') ? 'image-square' : (item.mime_type || '').startsWith('audio/') ? 'file-arrow-down' : 'file-arrow-down'), h('span', null, fileExt(item)));
  };

  const performReplaceFile = async (item, file) => {
    if (!item || !file) return;
    const selectedId = item.id;
    const fd = new FormData();
    fd.append('attachment_id', selectedId);
    fd.append('file', file);
    setMediaBusyMessage('');
    setUploadProgress({ done: 0, total: 1, name: file.name || item.title?.rendered || 'media', state: 'Uploading replacement', percent: 1 });
    try {
      const data = await uploadWithProgress('variable-engine/v1/media-studio/replace', fd, {}, percent => {
        if (percent >= 99) {
          setUploadProgress({ done: 0, total: 1, name: file.name || item.title?.rendered || 'media', state: 'Processing replacement', busy: true });
        } else {
          setUploadProgress({ done: 0, total: 1, name: file.name || item.title?.rendered || 'media', state: 'Uploading replacement', percent });
        }
      });
      if (data && data.item) {
        const bust = Date.now();
        const nextItem = { ...data.item, _vePreviewBust: bust };
        setItems(prev => prev.map(x => Number(x.id) === Number(selectedId) ? nextItem : x));
        if (Array.isArray(VE_MEDIA_CACHE.items)) {
          publishMediaCache(VE_MEDIA_CACHE.items.map(x => Number(x.id) === Number(selectedId) ? nextItem : x), true);
        }
        setSelected(nextItem);
        broadcastMediaItemUpdate(nextItem);
        setUploadProgress({ done: 1, total: 1, name: file.name || data.item.title?.rendered || 'media', state: 'Replace complete', percent: 100 });
        flash('Asset file replaced. Rollback point saved.');
      } else {
        flash(data?.message || 'Replace failed.');
      }
    } catch (e) {
      flash((e && e.message) || 'Replace failed.');
    }
    setMediaBusyMessage('');
    setTimeout(() => setUploadProgress(null), 5000);
  };

  const handleReplaceFile = async (files) => {
    if (!selected || !files || !files[0]) return;
    const item = selected;
    const file = files[0];
    setPendingReplaceRequest({ item, file, usage: null, loading: true });
    const usage = await fetchMediaUsageSafe(item.id);
    setPendingReplaceRequest(prev => prev && Number(prev.item?.id) === Number(item.id) ? { ...prev, usage, loading: false } : prev);
  };

  const confirmReplaceFile = async () => {
    const pending = pendingReplaceRequest;
    setPendingReplaceRequest(null);
    if (replaceInputRef.current) replaceInputRef.current.value = '';
    if (!pending) return;
    await performReplaceFile(pending.item, pending.file);
  };

  const rollbackMediaAction = async (row) => {
    if (!selected || !row?.rollback_id) return;
    setUploadProgress({ done: 0, total: 1, name: selected.title?.rendered || selected.filename || 'media', state: 'Restoring rollback point', busy: true });
    try {
      const res = await api.p('media-studio/rollback', { attachment_id: selected.id, rollback_id: row.rollback_id });
      if (res && res.item) {
        const nextItem = { ...res.item, _vePreviewBust: Date.now() };
        mergeMediaItem(nextItem);
        setSelected(nextItem);
        broadcastMediaItemUpdate(nextItem);
        setUploadProgress({ done: 1, total: 1, name: nextItem.title?.rendered || nextItem.filename || 'media', state: 'Rollback restored', percent: 100 });
        flash('Rollback restored.');
      } else {
        setUploadProgress({ done: 0, total: 1, name: 'Rollback failed', state: 'Rollback failed', percent: 0 });
        flash(res?.message || 'Rollback failed.');
      }
    } catch (e) {
      setUploadProgress({ done: 0, total: 1, name: 'Rollback failed', state: 'Rollback failed', percent: 0 });
      flash((e && e.message) || 'Rollback failed.');
    }
    setTimeout(() => setUploadProgress(null), 5000);
  };

  const convertSelected = async () => {
    if (!selected || !isImageFile(selected)) return;
    const item = selected;
    const format = convertFormat;
    setConvertingId(item.id);
    flash('Converting ' + (item.title?.rendered || 'asset') + ' to ' + format.toUpperCase() + '...');
    let res = null;
    try {
      res = await api.p('media-studio/convert', { attachment_id: item.id, format });
    } catch (e) {
      res = { message: 'Conversion failed.' };
    }
    setConvertingId(prev => prev === item.id ? null : prev);
    if (res && res.item) {
      setItems(prev => prev.map(x => x.id === item.id ? res.item : x));
      if (selectedMediaRef.current && selectedMediaRef.current.id === item.id) setSelected(res.item);
      flash('Converted ' + (item.title?.rendered || 'asset') + ' to ' + format.toUpperCase() + '.');
    } else {
      flash(res?.message || 'Conversion failed.');
    }
  };

  const convertCheckedImages = async () => {
    const targets = selectedImageItems;
    if (!targets.length) { flash('No selected images can be converted.'); return; }
    let converted = 0;
    setUploadProgress({ done: 0, total: targets.length, name: convertFormat.toUpperCase(), state: 'Converting selected images', percent: 1 });
    for (let i = 0; i < targets.length; i++) {
      const item = targets[i];
      setUploadProgress({ done: i, total: targets.length, name: item.title?.rendered || item.filename || 'image', state: 'Converting to ' + convertFormat.toUpperCase(), percent: Math.max(1, Math.round((i / targets.length) * 100)) });
      try {
        const res = await api.p('media-studio/convert', { attachment_id: item.id, format: convertFormat });
        if (res && res.item) {
          converted++;
          mergeMediaItem(res.item);
          broadcastMediaItemUpdate(res.item);
        }
      } catch(e) {}
    }
    setUploadProgress({ done: targets.length, total: targets.length, name: converted + ' converted', state: 'Convert complete', percent: 100 });
    setTimeout(() => setUploadProgress(null), 5000);
    flash(`Converted ${converted} image${converted === 1 ? '' : 's'} to ${convertFormat.toUpperCase()}.`);
  };

  const compressCheckedImages = async () => {
    const targets = selectedImageItems;
    if (!targets.length) { flash('No selected images can be compressed.'); return; }
    let compressed = 0;
    setUploadProgress({ done: 0, total: targets.length, name: targets.length + ' images', state: 'Compressing selected images', percent: 1 });
    for (let i = 0; i < targets.length; i++) {
      const item = targets[i];
      setUploadProgress({ done: i, total: targets.length, name: item.title?.rendered || item.filename || 'image', state: 'Compressing images', percent: Math.max(1, Math.round((i / targets.length) * 100)) });
      try {
        const res = await api.p('media-studio/compress', { attachment_id: item.id });
        if (res && res.item) {
          compressed++;
          mergeMediaItem(res.item);
          broadcastMediaItemUpdate(res.item);
        }
      } catch(e) {}
    }
    setUploadProgress({ done: targets.length, total: targets.length, name: compressed + ' compressed', state: 'Compression complete', percent: 100 });
    setTimeout(() => setUploadProgress(null), 5000);
    flash(`Compressed ${compressed} image${compressed === 1 ? '' : 's'}.`);
  };

  const startPreviewPan = (event) => {
    if (detailPreviewMode !== 'zoom' || !event || event.button !== 0) return;
    const el = event.currentTarget;
    if (!el) return;
    event.preventDefault();
    const startX = event.clientX;
    const startY = event.clientY;
    const startLeft = el.scrollLeft;
    const startTop = el.scrollTop;
    el.classList.add('panning');
    const move = ev => {
      el.scrollLeft = startLeft - (ev.clientX - startX);
      el.scrollTop = startTop - (ev.clientY - startY);
    };
    const stop = () => {
      el.classList.remove('panning');
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', stop);
      window.removeEventListener('mouseleave', stop);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', stop);
    window.addEventListener('mouseleave', stop);
  };

  useEffect(() => {
    const el = detailPreviewRef.current;
    if (!el) return;
    el.scrollTop = 0;
    el.scrollLeft = 0;
  }, [selected?.id, detailPreviewMode, detailPreviewZoom]);

  const insertSelectedMedia = (itemOverride) => {
    if (insertLockRef.current) return false;
    insertLockRef.current = true;
    setTimeout(() => { insertLockRef.current = false; }, 650);
    const target = itemOverride && itemOverride.source_url ? itemOverride : selected;
    if (!target) { insertLockRef.current = false; return false; }
    if (typeof onInsertMedia === 'function') {
      const inserted = onInsertMedia(target);
      if (inserted) {
        setSelected(null);
        if (picking && typeof onClose === 'function') onClose();
        return true;
      }
      if (picking) {
        // A component instance's image control can mount its writable field a frame
        // late, so the first insert finds nothing. Reset the lock and retry once
        // before reporting a refusal — this removes the "select the image twice" step.
        insertLockRef.current = false;
        if (!(itemOverride && itemOverride.__retry)) {
          setTimeout(() => insertSelectedMedia({ ...target, __retry: true }), 140);
          return false;
        }
        flash && flash('Media selected, but Bricks did not accept the insert from this control yet.');
        return false;
      }
    }
    handleCopyLink(target.source_url);
    setSelected(null);
    if (picking && typeof onClose === 'function') onClose();
    return true;
  };

  const handleMediaDoubleClick = (item, e, idx) => {
    if (!picking) return;
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setSelected(item);
    setLastMediaIndex(idx);
    insertSelectedMedia(item);
  };

  const masonryAspect = item => {
    if (isFontFile(item) || (!isImageFile(item) && !isVideoFile(item))) return '4 / 3';
    const measuredRatio = Number(videoAspectRatios[item?.id] || 0);
    if (isVideoFile(item) && measuredRatio > 0) return Math.round(measuredRatio * 10000) + ' / 10000';
    const w = Number(item?.media_details?.width || 0);
    const ht = Number(item?.media_details?.height || 0);
    if (w > 0 && ht > 0) {
      if (isVideoFile(item)) return w + ' / ' + ht;
      const ratio = Math.max(0.62, Math.min(2.05, w / ht));
      const safeW = Math.round(ratio * 100);
      return safeW + ' / 100';
    }
    return '4 / 3';
  };

  const formatSize = (bytes) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const persistFilter = (val) => { setFilterType(val); persistUserPreference('ve_media_filter', val); };
  const persistSort = (val) => { setSortBy(val); persistUserPreference('ve_media_sort', val); };
  const qualityOptions = [
    { value: 'all', label: 'All media', icon: 'filter' },
    { value: 'missing-alt', label: 'Missing Alt Text', icon: 'text-aa' },
    { value: 'unused', label: 'Unused Images', icon: 'eye-slash' },
    { value: 'recent', label: 'Recent Uploads', icon: 'calendar' },
    { value: 'large', label: 'Large Files', icon: 'hard-drive' },
    { value: 'tiny', label: 'Small Images', icon: 'bounding-box' },
    { value: 'landscape', label: 'Landscape', icon: 'image-square' },
    { value: 'portrait', label: 'Portrait', icon: 'device-mobile' },
    { value: 'square', label: 'Square', icon: 'square' }
  ];
  const validQualityValues = qualityOptions.map(x => x.value);
  const activeQualityFilters = qualityFilters.filter(x => validQualityValues.includes(x) && x !== 'all');
  const activeQualityKey = activeQualityFilters.join('|');
  const persistQualityFilters = (vals, closePanel = false) => {
    const clean = [...new Set((Array.isArray(vals) ? vals : [vals]).map(String).filter(x => validQualityValues.includes(x) && x !== 'all'))];
    setQualityFilters(clean);
    setQualityFilter(clean[0] || 'all');
    persistUserPreference('ve_media_quality_filters', JSON.stringify(clean));
    persistUserPreference('ve_media_quality_filter', clean[0] || 'all');
    if (closePanel) setQualityPanelOpen(false);
  };
  const persistQualityFilter = (val) => persistQualityFilters(val === 'all' ? [] : [val], true);
  const toggleQualityFilter = (val) => {
    if (val === 'all') { persistQualityFilters([]); return; }
    const next = activeQualityFilters.includes(val) ? activeQualityFilters.filter(x => x !== val) : [...activeQualityFilters, val];
    persistQualityFilters(next);
  };
  const removeQualityRule = val => persistQualityFilters(activeQualityFilters.filter(x => x !== val));
  const persistSavedQualityPresets = presets => {
    const clean = (Array.isArray(presets) ? presets : []).filter(x => x && x.name && Array.isArray(x.qualityFilters)).slice(0, 12);
    setSavedQualityPresets(clean);
    try { localStorage.setItem('ve_media_saved_filters', JSON.stringify(clean)); } catch(e) {}
  };
  const saveCurrentQualityPreset = () => {
    if (!activeQualityFilters.length && filterType === 'all' && sortBy === 'date' && !dynamicFilter) { flash('Choose at least one filter before saving.'); return; }
    const name = (qualityPresetName || (activeQualityFilters.length ? activeQualityFilters.map(v => (qualityOptions.find(x => x.value === v) || { label: v }).label).join(' + ') : 'Custom filter')).trim();
    if (!name) { flash('Name this filter first.'); return; }
    const preset = { id: 'preset-' + Date.now(), name: name.slice(0, 36), qualityFilters: activeQualityFilters, filterType, sortBy, dynamicFilter: dynamicFilter || null };
    persistSavedQualityPresets([preset, ...savedQualityPresets.filter(x => x.name.toLowerCase() !== name.toLowerCase())]);
    setQualityPresetName('');
    flash('Saved filter: ' + preset.name);
  };
  const applySavedQualityPreset = preset => {
    if (!preset) return;
    if (preset.filterType) persistFilter(preset.filterType);
    if (preset.sortBy) persistSort(preset.sortBy);
    setDynamicFilter(preset.dynamicFilter || null);
    persistQualityFilters(preset.qualityFilters || []);
    flash('Applied filter: ' + preset.name);
  };
  const removeSavedQualityPreset = id => persistSavedQualityPresets(savedQualityPresets.filter(x => x.id !== id));
  const currentQuality = activeQualityFilters.length > 1
    ? { value: 'multi', label: activeQualityFilters.length + ' filters', icon: 'filter' }
    : (qualityOptions.find(x => x.value === (activeQualityFilters[0] || 'all')) || qualityOptions[0]);
  const shownQualityOptions = qualityOptions.filter(opt => {
    const q = qualityQuery.trim().toLowerCase();
    if (!q) return true;
    return opt.label.toLowerCase().includes(q) || opt.value.toLowerCase().includes(q);
  });

  // Filter items based on selected collection
  const filteredByCollection = useMemo(() => {
    if (selectedColl === 'all') return items;
      const ids = collIds(selectedColl);
      return items.filter(x => ids.includes(x.id));
  }, [items, selectedColl, collectionMap, folderData]);

  // Filter by type
  const filteredByType = useMemo(() => {
    if (filterType === 'all') return filteredByCollection;
    if (filterType === 'font') return filteredByCollection.filter(x => isFontFile(x));
    if (filterType === 'svg') return filteredByCollection.filter(x => /svg/i.test((x.mime_type || '') + ' ' + (x.source_url || '')));
    return filteredByCollection.filter(x => (x.mime_type || '').startsWith(filterType + '/'));
  }, [filteredByCollection, filterType]);

  const filteredByDynamic = useMemo(() => {
    if (!dynamicFilter) return filteredByType;
    if (dynamicFilter.type === 'year') return filteredByType.filter(x => String((x.date || '').slice(0, 4)) === String(dynamicFilter.value));
    if (dynamicFilter.type === 'ext') return filteredByType.filter(x => fileExt(x).toLowerCase() === String(dynamicFilter.value).toLowerCase());
    if (dynamicFilter.type === 'author') return filteredByType.filter(x => String(authorLabel(x)) === String(dynamicFilter.value));
    if (dynamicFilter.type === 'size') {
      return filteredByType.filter(item => {
        const bytes = getFileSize(item);
        if (dynamicFilter.value === '0-1') return bytes < 1024 * 1024;
        if (dynamicFilter.value === '1-10') return bytes >= 1024 * 1024 && bytes < 10 * 1024 * 1024;
        if (dynamicFilter.value === '10-100') return bytes >= 10 * 1024 * 1024 && bytes < 100 * 1024 * 1024;
        return bytes >= 100 * 1024 * 1024;
      });
    }
    return filteredByType;
  }, [filteredByType, dynamicFilter]);

  const unusedImageIdsForScan = useMemo(() => filteredByDynamic.filter(isImageFile).map(item => item.id), [filteredByDynamic]);
  const unusedImageScanKey = unusedImageIdsForScan.join(',');

  useEffect(() => {
    if (activeQualityFilters.includes('unused')) return;
    unusedScanRunRef.current += 1;
    if (unusedScanTimeoutRef.current) { clearTimeout(unusedScanTimeoutRef.current); unusedScanTimeoutRef.current = null; }
    setUnusedScan(prev => prev.loading ? { ...prev, loading: false, message: '' } : prev);
    setUploadProgress(prev => prev && String(prev.state || '').indexOf('Scanning unused') === 0 ? null : prev);
  }, [activeQualityKey]);

  useEffect(() => {
    if (!activeQualityFilters.includes('unused')) return;
    if (!unusedImageIdsForScan.length) {
      setUnusedScan({ key: unusedImageScanKey, ids: [], loading: false, scanned: 0, limited: false, message: '' });
      return;
    }
    if (unusedScan.key === unusedImageScanKey && (Array.isArray(unusedScan.ids) || unusedScan.loading)) return;
    let alive = true;
    const runId = ++unusedScanRunRef.current;
    setUnusedScan(prev => ({ ...prev, key: unusedImageScanKey, ids: null, loading: true, scanned: 0, message: 'Scanning media references…' }));
    setUploadProgress({ done: 0, total: unusedImageIdsForScan.length, name: unusedImageIdsForScan.length + ' images', state: 'Scanning unused images', busy: true });
    if (unusedScanTimeoutRef.current) clearTimeout(unusedScanTimeoutRef.current);
    unusedScanTimeoutRef.current = setTimeout(() => {
      if (!alive || runId !== unusedScanRunRef.current) return;
      unusedScanRunRef.current += 1;
      const message = 'Unused scan stopped after 35 seconds. Narrow the collection, search, or type filter and rescan.';
      setUnusedScan({ key: unusedImageScanKey, ids: [], loading: false, scanned: 0, limited: true, message });
      setUploadProgress(null);
      flash(message);
      unusedScanTimeoutRef.current = null;
    }, 35000);
    api.p('media-studio/unused-scan', { attachment_ids: unusedImageIdsForScan }).then(res => {
      if (!alive || runId !== unusedScanRunRef.current) return;
      if (unusedScanTimeoutRef.current) { clearTimeout(unusedScanTimeoutRef.current); unusedScanTimeoutRef.current = null; }
      if (res && res.success) {
        setUnusedScan({ key: unusedImageScanKey, ids: Array.isArray(res.unused_ids) ? res.unused_ids.map(Number) : [], loading: false, scanned: Number(res.scanned || 0), limited: !!res.limited, message: res.message || '' });
        setUploadProgress({ done: Number(res.scanned || 0), total: unusedImageIdsForScan.length, name: (Array.isArray(res.unused_ids) ? res.unused_ids.length : 0) + ' unused found', state: 'Unused scan complete', percent: 100 });
        setTimeout(() => { if (runId === unusedScanRunRef.current) setUploadProgress(null); }, 5000);
      } else {
        setUnusedScan({ key: unusedImageScanKey, ids: [], loading: false, scanned: 0, limited: false, message: res?.message || 'Unused image scan failed.' });
        setUploadProgress(null);
        flash(res?.message || 'Unused image scan failed.');
      }
    }).catch(err => {
      if (!alive || runId !== unusedScanRunRef.current) return;
      if (unusedScanTimeoutRef.current) { clearTimeout(unusedScanTimeoutRef.current); unusedScanTimeoutRef.current = null; }
      const message = err?.message || 'Unused image scan failed.';
      setUnusedScan({ key: unusedImageScanKey, ids: [], loading: false, scanned: 0, limited: false, message });
      setUploadProgress(null);
      flash(message);
    });
    return () => { alive = false; if (unusedScanTimeoutRef.current) { clearTimeout(unusedScanTimeoutRef.current); unusedScanTimeoutRef.current = null; } };
  }, [activeQualityKey, unusedImageScanKey]);

  const filteredByQuality = useMemo(() => {
    if (!activeQualityFilters.length) return filteredByDynamic;
    const ratioOf = item => {
      const w = Number(item?.media_details?.width || 0);
      const hgt = Number(item?.media_details?.height || 0);
      if (!w || !hgt || isFontFile(item)) return 1;
      return Math.max(.38, Math.min(3.2, w / hgt));
    };
    const unusedSet = Array.isArray(unusedScan.ids) ? new Set(unusedScan.ids.map(Number)) : null;
    const match = (item, filter) => {
      if (filter === 'missing-alt') return isImageFile(item) && !(item.alt_text || '').trim();
      if (filter === 'unused') return unusedSet ? (isImageFile(item) && unusedSet.has(Number(item.id))) : (unusedScan.loading ? isImageFile(item) : false);
      if (filter === 'recent') {
        const cutoff = Date.now() - (1000 * 60 * 60 * 24 * 14);
        const t = Date.parse(item.date || item.modified || '');
        return !!(t && t >= cutoff);
      }
      if (filter === 'large') return getFileSize(item) >= 1024 * 1024;
      if (filter === 'tiny') return isImageFile(item) && ((Number(item?.media_details?.width || 0) < 800) || (Number(item?.media_details?.height || 0) < 800));
      if (filter === 'landscape') return isImageFile(item) && ratioOf(item) > 1.15;
      if (filter === 'portrait') return isImageFile(item) && ratioOf(item) < .87;
      if (filter === 'square') return isImageFile(item) && Math.abs(ratioOf(item) - 1) <= .13;
      return true;
    };
    return filteredByDynamic.filter(item => activeQualityFilters.every(filter => match(item, filter)));
  }, [filteredByDynamic, activeQualityKey, unusedScan.ids, unusedScan.loading]);


  const qualityCounts = useMemo(() => {
    const ratioOf = item => {
      const w = Number(item?.media_details?.width || 0);
      const hgt = Number(item?.media_details?.height || 0);
      if (!w || !hgt || isFontFile(item)) return 1;
      return Math.max(.38, Math.min(3.2, w / hgt));
    };
    return {
      all: filteredByDynamic.length,
      'missing-alt': filteredByDynamic.filter(item => isImageFile(item) && !(item.alt_text || '').trim()).length,
      unused: Array.isArray(unusedScan.ids) ? unusedScan.ids.length : 0,
      recent: filteredByDynamic.filter(item => { const t = Date.parse(item.date || item.modified || ''); return t && t >= Date.now() - (1000 * 60 * 60 * 24 * 14); }).length,
      large: filteredByDynamic.filter(item => getFileSize(item) >= 1024 * 1024).length,
      tiny: filteredByDynamic.filter(item => isImageFile(item) && ((Number(item?.media_details?.width || 0) < 800) || (Number(item?.media_details?.height || 0) < 800))).length,
      landscape: filteredByDynamic.filter(item => isImageFile(item) && ratioOf(item) > 1.15).length,
      portrait: filteredByDynamic.filter(item => isImageFile(item) && ratioOf(item) < .87).length,
      square: filteredByDynamic.filter(item => isImageFile(item) && Math.abs(ratioOf(item) - 1) <= .13).length
    };
  }, [filteredByDynamic, unusedScan.ids]);

  // Filter by search
  const filteredBySearch = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return filteredByQuality;
    return filteredByQuality.filter(x =>
      (x.title?.rendered || '').toLowerCase().includes(q) ||
      (x.slug || '').toLowerCase().includes(q) ||
      (x.mime_type || '').toLowerCase().includes(q) ||
      (x.source_url || '').toLowerCase().includes(q)
    );
  }, [filteredByQuality, search]);

  // Sort
  const filtered = useMemo(() => {
    const list = [...filteredBySearch];
    if (sortBy === 'name') list.sort((a, b) => (a.title?.rendered || '').localeCompare(b.title?.rendered || ''));
    else if (sortBy === 'size') list.sort((a, b) => getFileSize(b) - getFileSize(a));
    else list.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
    return list;
  }, [filteredBySearch, sortBy]);

  useEffect(() => {
    if (!picking || !filtered.length) return;
    setSelected(current => {
      if (current && filtered.some(item => Number(item.id) === Number(current.id))) return current;
      let rememberedId = 0;
      try { rememberedId = Number(localStorage.getItem('ve_media_picker_last_item') || 0); } catch (e) {}
      return filtered.find(item => Number(item.id) === rememberedId) || filtered[0];
    });
  }, [picking, filtered]);

  useEffect(() => {
    if (!picking || !selected?.id) return;
    try { localStorage.setItem('ve_media_picker_last_item', String(selected.id)); } catch (e) {}
  }, [picking, selected?.id]);

  const masonryColumns = useMemo(() => {
    const count = Math.max(2, Math.min(7, Number(masonryColumnCount) || 5));
    const cols = Array.from({ length: count }, () => ({ height: 0, items: [] }));
    const estimateHeight = item => {
      if (isFontFile(item) || (!isImageFile(item) && !isVideoFile(item))) return 118;
      const measuredRatio = Number(videoAspectRatios[item?.id] || 0);
      const w = Number(item?.media_details?.width || 0);
      const ht = Number(item?.media_details?.height || 0);
      const storedRatio = w && ht ? w / ht : 0;
      const ratio = isVideoFile(item)
        ? (measuredRatio || storedRatio || 16 / 9)
        : (storedRatio ? Math.max(.62, Math.min(2.05, storedRatio)) : 1.33);
      return isVideoFile(item) ? Math.max(80, 180 / ratio) : Math.max(96, Math.min(270, 180 / ratio));
    };
    filtered.forEach((item, idx) => {
      let target = 0;
      for (let i = 1; i < cols.length; i++) {
        if (cols[i].height < cols[target].height) target = i;
      }
      cols[target].items.push({ item, idx });
      cols[target].height += estimateHeight(item) + 12;
    });
    return cols.map(col => col.items);
  }, [filtered, masonryColumnCount, videoAspectRatios]);

  const totalStorageSize = useMemo(() => {
    return items.reduce((acc, x) => acc + getFileSize(x), 0);
  }, [items]);

  const selectedMediaItems = useMemo(() => checkedItems.map(id => items.find(x => Number(x.id) === Number(id))).filter(Boolean), [checkedItems, items]);
  const selectedImageItems = useMemo(() => selectedMediaItems.filter(isImageFile), [selectedMediaItems]);

  // Dynamic collection counts
  const collCounts = useMemo(() => {
    const counts = {};
    for (const key of collKeys) {
      const ids = collIds(key);
      counts[key] = items.filter(x => ids.includes(x.id)).length;
    }
    return counts;
  }, [items, collectionMap, folderData]);

  const overviewStats = useMemo(() => {
    const diag = diagnostics || {};
    const valueOr = (key, fallback) => Number.isFinite(Number(diag[key])) ? Number(diag[key]) : fallback;
    return [
      { key: 'all', label: 'Total media', value: valueOr('total', qualityCounts.all || items.length || 0), helper: diagnosticsLoading ? 'Checking library' : (diag.total_size_human || formatSize(totalStorageSize)), icon: 'hard-drives' },
      { key: 'missing-alt', label: 'Missing alt', value: valueOr('missing_alt', qualityCounts['missing-alt'] || 0), helper: 'Needs text', icon: 'text-aa' },
      { key: 'unused', label: 'Unused', value: unusedScan.loading ? 'Scanning' : (qualityCounts.unused || 0), helper: unusedScan.loading ? 'Running scan' : 'Safe scan result', icon: 'eye-slash' },
      { key: 'large', label: 'Large files', value: valueOr('large_files', qualityCounts.large || 0), helper: '1 MB+', icon: 'hard-drives' },
      { key: 'recent', label: 'Recent uploads', value: valueOr('recent_uploads', qualityCounts.recent || 0), helper: 'Last 14 days', icon: 'calendar' }
    ];
  }, [diagnostics, diagnosticsLoading, qualityCounts, unusedScan.loading, items.length, totalStorageSize]);

  const activateOverviewFilter = key => {
    if (key === 'all') { persistQualityFilters([]); return; }
    persistQualityFilters([key]);
  };

  const persistLayoutMode = (mode) => {
    const normalized = normalizeMediaLayout(mode);
    setLayoutMode(normalized);
    persistUserPreference('ve_media_layout', normalized);
  };
  const openViewPanel = () => {
    if (viewPanelCloseTimerRef.current) clearTimeout(viewPanelCloseTimerRef.current);
    setViewPanelSuppressed(false);
    setViewPanelOpen(true);
  };
  const scheduleViewPanelClose = () => {
    if (viewPanelCloseTimerRef.current) clearTimeout(viewPanelCloseTimerRef.current);
    viewPanelCloseTimerRef.current = setTimeout(() => {
      setViewPanelOpen(false);
      setViewPanelSuppressed(false);
    }, 280);
  };
  const toggleViewPanel = () => {
    if (viewPanelCloseTimerRef.current) clearTimeout(viewPanelCloseTimerRef.current);
    setViewPanelSuppressed(false);
    setViewPanelOpen(prev => !prev);
  };
  const listMetaOptions = [
    { key: 'mime', label: 'MIME Type' },
    { key: 'size', label: 'File Size' },
    { key: 'dimensions', label: 'Dimensions' },
    { key: 'uploaded', label: 'Uploaded On' },
    { key: 'uploaded_by', label: 'Uploaded By' }
  ];
  const setListMetaSelection = (next) => {
    const clean = listMetaOptions.map(x => x.key).filter(key => next.includes(key));
    setListMetaFields(clean);
    persistUserPreference('ve_media_list_meta_fields', JSON.stringify(clean));
    persistUserPreference('ve_media_list_meta', clean.length ? '1' : '0');
  };
  const toggleListMetaField = (key) => {
    setListMetaSelection(listMetaFields.includes(key)
      ? listMetaFields.filter(x => x !== key)
      : [...listMetaFields, key]);
  };

  const openCollectionColorPicker = (key, event) => {
    if (!key || isFolderCollection(key)) return;
    event?.preventDefault?.();
    event?.stopPropagation?.();
    const current = collectionColor(key) || '#baf400';
    const rect = event?.currentTarget?.getBoundingClientRect ? event.currentTarget.getBoundingClientRect() : null;
    const panelRect = mediaLayoutRef.current?.getBoundingClientRect ? mediaLayoutRef.current.getBoundingClientRect() : null;
    const pad = 16;
    const bounds = panelRect || { left: 0, top: 0, right: window.innerWidth || 900, bottom: window.innerHeight || 700, width: window.innerWidth || 900, height: window.innerHeight || 700 };
    const popW = Math.min(320, Math.max(292, Math.min(window.innerWidth || 900, bounds.width) - (pad * 2)));
    // The picker is intentionally compact now, so position the whole popover instead of making it scroll internally.
    const popH = Math.min(462, Math.max(416, bounds.height - (pad * 2)));
    const anchorX = rect ? (rect.left + rect.width / 2) : (Number.isFinite(event?.clientX) ? event.clientX : bounds.left + bounds.width / 2);
    const anchorY = rect ? (rect.top + rect.height / 2) : (Number.isFinite(event?.clientY) ? event.clientY : bounds.top + bounds.height / 2);
    let left = rect ? rect.right + 12 : anchorX + 12;
    if (left + popW > bounds.right - pad) left = (rect ? rect.left : anchorX) - popW - 12;
    if (left < bounds.left + pad) left = Math.min(Math.max(bounds.left + pad, anchorX - popW / 2), bounds.right - popW - pad);
    let top = anchorY - (popH / 2);
    top = Math.max(bounds.top + pad, Math.min(top, bounds.bottom - popH - pad));
    if (bounds.bottom - bounds.top < popH + (pad * 2)) top = bounds.top + pad;
    setCollectionColorPicker({ key, color: current, left: Math.round(left), top: Math.round(top) });
    setCollectionMenu(null);
  };

  const setDraftCollectionColor = color => {
    setCollectionColorPicker(prev => prev ? { ...prev, color: normalizeCollectionColor(color) || '' } : prev);
  };

  const applyCollectionColor = (key, color) => {
    if (!key || isFolderCollection(key) || !collectionMap[key]) return;
    const clean = normalizeCollectionColor(color);
    persistCollections({ ...collectionMap, [key]: { ...(collectionMap[key] || {}), color: clean } });
    setCollectionColorPicker(null);
    flash(clean ? 'Collection color updated.' : 'Collection color cleared.');
  };

  const createMediaDragGhost = ids => {
    const ghost = document.createElement('div');
    ghost.className = 've-media-drag-ghost';
    const stack = document.createElement('div');
    stack.className = 've-media-drag-stack';
    (ids || []).slice(0, 3).forEach(id => {
      const item = items.find(x => String(x.id) === String(id));
      const mini = document.createElement('div');
      mini.className = 've-media-drag-mini';
      if (item?.source_url && !isFontFile(item)) {
        const img = document.createElement('img');
        img.src = item.media_details?.sizes?.thumbnail?.source_url || item.source_url;
        img.alt = '';
        img.style.width = '100%';
        img.style.height = '100%';
        img.style.objectFit = 'cover';
        mini.appendChild(img);
      } else {
        mini.textContent = (fileExt(item || {}) || 'FILE').slice(0, 4).toUpperCase();
        mini.style.display = 'flex';
        mini.style.alignItems = 'center';
        mini.style.justifyContent = 'center';
        mini.style.fontSize = '8px';
        mini.style.color = '#dfffa3';
      }
      stack.appendChild(mini);
    });
    const count = document.createElement('span');
    count.className = 've-media-drag-count';
    count.textContent = String((ids || []).length || 1);
    const label = document.createElement('span');
    label.textContent = ((ids || []).length === 1 ? 'media' : 'media files');
    ghost.appendChild(stack);
    ghost.appendChild(count);
    ghost.appendChild(label);
    document.body.appendChild(ghost);
    return ghost;
  };

  const visibleIcons = iconCatalog.filter(icon => !iconSearch.trim() || icon.indexOf(iconSearch.toLowerCase().trim()) !== -1);
  const renderMediaCard = (item, idx, mode = 'grid', extraStyle = {}) => {
    const isChecked = checkedItems.includes(item.id);
    const isSel = selected && selected.id === item.id;
    const masonryStyle = mode === 'masonry' ? { '--ve-media-aspect': masonryAspect(item) } : {};
    return h('div', {
      key: item.id,
      onClick: e => handleMediaClick(item, e, idx),
      onDoubleClick: e => handleMediaDoubleClick(item, e, idx),
      onDblClick: e => handleMediaDoubleClick(item, e, idx),
      ondblclick: e => handleMediaDoubleClick(item, e, idx),
      onPointerDown: e => {
        if (e.button !== 0) return;
        mediaDragCandidateRef.current = true;
        markInternalDrag('media');
      },
      // Draggable even in picker mode so a selection can be dragged onto a
      // collection to file it; native drag only starts on movement, so plain
      // click-to-choose is unaffected.
      draggable: true,
      onDragStart: e => {
        const ids = checkedItems.includes(item.id) ? checkedItems : [item.id];
        mediaDragActiveRef.current = true;
        mediaDragCandidateRef.current = true;
        mediaDropDepthRef.current = 0;
        setDragActive(false);
        setDropCollection(null);
        setDropMode('');
        setDragCollection(null);
        setMediaDragIds(ids);
        markInternalDrag('media');
        e.dataTransfer.effectAllowed = 'copy';
        e.dataTransfer.setData('application/x-ve-media-ids', JSON.stringify(ids));
        e.dataTransfer.setData('application/x-ve-internal-drag', 'media');
        e.dataTransfer.setData('text/plain', ids.join(','));
        const ghost = createMediaDragGhost(ids);
        e.dataTransfer.setDragImage(ghost, 10, 10);
        setTimeout(() => ghost.remove(), 0);
      },
      onDragEnd: () => { mediaDragActiveRef.current = false; mediaDragCandidateRef.current = false; clearInternalDragMarker(); setMediaDragIds([]); setDropCollection(null); setDropMode(''); setDragActive(false); },
      class: 've-media-thumb' + (isSvgMedia(item) ? ' ve-media-is-svg' : '') + (isVideoFile(item) ? ' ve-media-is-video' : '') + (isSel ? ' selected' : '') + (isChecked ? ' checked' : '') + (ctxMenu && ctxMenu.item && ctxMenu.item.id === item.id ? ' ve-ctx-target' : ''),
      'data-mime': item.mime_type || '',
      'data-media-id': item.id,
      style: {
        border: '1px solid ' + (isSel ? '#baf400' : 'rgba(255,255,255,0.05)'),
        ...masonryStyle,
        ...extraStyle
      }
    }, [
      renderFilePreview(item, mode),
      h('div', { class: 've-media-meta-hover' },
        h('div', { style: 'font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis' }, item.title?.rendered || 'Untitled'),
        h('div', null, fileExt(item), ' · ', formatSize(getFileSize(item)))
      ),
      h('div', { class: 've-media-select', onClick: e => e.stopPropagation() },
        h(CheckControl, { checked: isChecked, onShiftClick: () => toggleCheckRange(item.id, idx), onChange: (_, e, held) => toggleCheckItem(item.id, Object.assign(e || {}, { __veShiftKey: !!held }), idx), title: isChecked ? 'Deselect asset' : 'Select asset' })
      )
    ]);
  };

  const contextMenuStyle = collectionMenu ? (() => {
    const menuWidth = 188;
    const actionRows = 10;
    const requestedHeight = 18 + (actionRows * 31) + ((actionRows - 1) * 4);
    const bounds = collectionMenu.bounds || { width: 900, height: 620 };
    const pad = 14;
    const menuHeight = Math.max(180, Math.min(requestedHeight, bounds.height - (pad * 2)));
    const rowHeight = collectionMenu.rowHeight || 32;
    const rowTop = typeof collectionMenu.rowTop === 'number' ? collectionMenu.rowTop : Math.max(pad, (collectionMenu.y || 0) - (rowHeight / 2));
    const rowCenter = rowTop + (rowHeight / 2);
    let top = rowTop;
    top = Math.max(pad, Math.min(top, bounds.height - menuHeight - pad));
    let left = collectionMenu.x || 0;
    let placement = 'right';
    if (left + menuWidth > bounds.width - pad) {
      left = (collectionMenu.fallbackX || 0);
      placement = 'left';
    }
    left = Math.max(pad, Math.min(left, bounds.width - menuWidth - pad));
    const arrowY = Math.max(14, Math.min(rowCenter - top - 5, menuHeight - 22));
    const style = {
      position: 'absolute',
      left:left + 'px',
      top:top + 'px',
      transform: 'none',
      '--ve-context-arrow-y': arrowY + 'px',
      '--ve-context-arrow-left': placement === 'right' ? '-5px' : 'calc(100% - 4px)',
      '--ve-context-arrow-rotate': placement === 'right' ? '45deg' : '225deg'
    };
    if (menuHeight < requestedHeight) {
      style.maxHeight = menuHeight + 'px';
      style.overflowY = 'auto';
    }
    return style;
  })() : {};

  const renderDynamicGroup = (key, icon, label, children) => {
    const collapsed = dynamicCollapsed[key] !== false;
    return [
      h('button', {
        type: 'button',
        class: 've-dynamic-folder-group',
        key: key + '-head',
        onClick: () => toggleDynamicGroup(key),
        title: collapsed ? 'Expand ' + label : 'Collapse ' + label
      }, ph(collapsed ? 'caret-right' : 'caret-down'), ph(icon), label),
      !collapsed && children
    ];
  };

  const renderDynamicFoldersPanel = () => h('div', { class: 've-dynamic-folders' },
    h('div', { class: 've-studio-nav-title', style: 'margin:0 0 3px' }, 'Dynamic folders'),
    dynamicFilter && h('button', { type: 'button', class: 've-dynamic-folder-child active', onClick: () => setDynamicFilter(null) }, ph('x'), 'Clear dynamic filter'),
    renderDynamicGroup('authors', 'user', 'All Authors',
      [...new Set(items.map(authorLabel).filter(Boolean))].slice(0, 8).map(author => h('button', { type: 'button', class: 've-dynamic-folder-child' + (dynamicFilter?.type === 'author' && dynamicFilter.value === author ? ' active' : ''), key: 'author-' + author, onClick: () => setMediaDynamicFilter('author', author, author) }, author))
    ),
    renderDynamicGroup('dates', 'calendar', 'All Dates',
      [...new Set(items.map(x => String((x.date || '').slice(0,4))).filter(Boolean))].slice(0,6).map(year => h('button', { type: 'button', class: 've-dynamic-folder-child' + (dynamicFilter?.type === 'year' && String(dynamicFilter.value) === String(year) ? ' active' : ''), key: year, onClick: () => setMediaDynamicFilter('year', year, year) }, year))
    ),
    renderDynamicGroup('extensions', 'file', 'All Extensions',
      [...new Set(items.map(fileExt))].sort().slice(0,8).map(ext => h('button', { type: 'button', class: 've-dynamic-folder-child' + (dynamicFilter?.type === 'ext' && String(dynamicFilter.value).toLowerCase() === ext.toLowerCase() ? ' active' : ''), key: ext, onClick: () => setMediaDynamicFilter('ext', ext.toLowerCase(), '.' + ext.toLowerCase()) }, '.' + ext.toLowerCase()))
    ),
    renderDynamicGroup('sizes', 'hard-drives', 'All Sizes',
      mediaSizeBuckets.map(bucket => h('button', { type: 'button', class: 've-dynamic-folder-child' + (dynamicFilter?.type === 'size' && dynamicFilter.value === bucket.value ? ' active' : ''), key: bucket.value, onClick: () => setMediaDynamicFilter('size', bucket.value, bucket.label) }, bucket.label))
    )
  );

  return h('div', {
    class: 've-studio-layout ve-media-studio' + (pageMode ? ' ve-media-studio-page-mode' : ''),
    ref: mediaLayoutRef,
    onClick: () => collectionMenu && setCollectionMenu(null),
    onDragStartCapture: e => {
      if (e.target?.closest?.('.ve-studio-nav-item,.ve-collection-drag')) {
        collectionDragActiveRef.current = true;
        markInternalDrag('collection');
        setDragActive(false);
      }
      if (e.target?.closest?.('.ve-media-thumb,.ve-media-selected-strip,.ve-media-batch-overlay')) {
        mediaDragActiveRef.current = true;
        mediaDragCandidateRef.current = true;
        markInternalDrag('media');
        setDragActive(false);
      }
    },
    onDragEnter: e => { showFileDrop(e); },
    onDragOver: e => { showFileDrop(e); },
    onDragLeave: e => { if (MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED && isUploadFileDrag(e) && !dragIsStillInside(e, e.currentTarget)) clearFileDrop(); },
    onDrop: e => { if (MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED && isUploadFileDrag(e)) handleDrop(e); }
  },
    // ConfirmModals
    !uploadProgress && loading && h('div', { class: 've-media-progress-toast busy', role: 'status', 'aria-live': 'polite' },
      h('span', { class: 've-media-progress-spinner' }),
      h('div', { class: 've-media-progress-copy' },
        h('strong', null, mediaBusyMessage || 'Loading media'),
        h('em', null, 'Media Studio stays usable while this loads'),
        h('div', { class: 've-upload-bar' }, h('span', null))
      )
    ),
    uploadProgress && h('div', { class: 've-media-progress-toast' + (uploadProgress.busy ? ' busy' : '') + (uploadProgress.sticky ? ' failed' : ''), role: 'status', 'aria-live': 'polite' },
      uploadProgress.busy ? h('span', { class: 've-media-progress-spinner' }) : ph(uploadProgress.state && uploadProgress.state.indexOf('Replac') === 0 ? 'arrows-clockwise' : uploadProgress.state && uploadProgress.state.indexOf('Scann') === 0 ? 'magnifying-glass' : 'upload-simple'),
      h('div', { class: 've-media-progress-copy' },
        h('strong', null,
          uploadProgress.state || 'Working',
          uploadProgress.total > 1 && !uploadProgress.busy ? ` ${Math.min(uploadProgress.done || 0, uploadProgress.total)} of ${uploadProgress.total}` : '',
          uploadProgress.total <= 1 && !uploadProgress.busy && Number.isFinite(Number(uploadProgress.percent)) ? ` · ${Math.round(uploadProgress.percent)}%` : ''
        ),
        h('em', null, uploadProgress.name || 'media'),
        uploadProgress.reason && h('em', { class: 've-media-progress-why' }, uploadProgress.reason),
        h('div', { class: 've-upload-bar' }, h('span', { style: uploadProgress.busy ? '' : `width:${Math.max(8, Math.min(100, Math.round(uploadProgress.percent ?? (((uploadProgress.done || 0) / (uploadProgress.total || 1)) * 100))))}%` }))
      ),
      uploadProgress.sticky && h('button', { type: 'button', class: 've-media-progress-x', 'aria-label': 'Dismiss', onClick: () => setUploadProgress(null) }, ph('x'))
    ),
    ctxMenu && h(MediaCtxMenu, { at: ctxMenu, rows: ctxRows(), onClose: closeCtxMenu, host: mediaLayoutRef }),
    pendingDeleteMedia && h(ConfirmModal, {
      title: 'Delete Media',
      body: h('div', { class: 've-safety-modal-body' },
        h('p', null, 'Permanently delete "' + ((pendingDeleteMedia.item || pendingDeleteMedia)?.title?.rendered || (pendingDeleteMedia.item || pendingDeleteMedia)?.filename || 'this media file') + '"?'),
        pendingDeleteMedia.loading ? h('div', { class: 've-safety-note' }, h('span', { class: 've-media-progress-spinner' }), 'Checking usage…') : renderUsageSafetySummary(pendingDeleteMedia.usage)
      ),
      confirmText: 'Delete',
      danger: true,
      onCancel: () => setPendingDeleteMedia(null),
      onConfirm: confirmDeleteMedia
    }),
    pendingBatchDelete && h(ConfirmModal, {
      title: (pendingBatchDelete.ids || checkedItems).length === 1 ? 'Delete Media' : 'Batch Delete',
      body: h('div', { class: 've-safety-modal-body' },
        h('p', null, 'Permanently delete ' + (pendingBatchDelete.ids || checkedItems).length + ' media file' + ((pendingBatchDelete.ids || checkedItems).length === 1 ? '' : 's') + '?'),
        pendingBatchDelete.loading
          ? h('div', { class: 've-safety-note' }, h('span', { class: 've-media-progress-spinner' }), 'Checking selected media usage…')
          : h('div', { class: pendingBatchDelete.usedCount ? 've-safety-warning' : 've-safety-ok' },
              pendingBatchDelete.usedCount ? ph('warning') : ph('shield-check'),
              h('strong', null, pendingBatchDelete.usedCount ? (pendingBatchDelete.usedCount + ' selected file' + (pendingBatchDelete.usedCount === 1 ? '' : 's') + ' have detected usage') : 'No usage detected in sampled files'),
              h('em', null, 'Checked ' + (pendingBatchDelete.sampled || 0) + ' of ' + (pendingBatchDelete.ids || checkedItems).length + ' selected files before deleting.'),
              Array.isArray(pendingBatchDelete.usages) && pendingBatchDelete.usages.filter(x => (x.usage?.total || 0) > 0).slice(0, 4).map(x => h('small', { key: x.id }, (x.item?.title?.rendered || 'Media #' + x.id) + ' · ' + x.usage.total + ' use' + (x.usage.total === 1 ? '' : 's')))
            )
      ),
      confirmText: (pendingBatchDelete.ids || checkedItems).length === 1 ? 'Delete Media' : 'Delete Selected',
      danger: true,
      onCancel: () => setPendingBatchDelete(false),
      onConfirm: confirmBatchDelete
    }),
    pendingReplaceRequest && h(ConfirmModal, {
      title: 'Replace Media File',
      body: h('div', { class: 've-safety-modal-body' },
        h('p', null, 'Replace "' + (pendingReplaceRequest.item?.title?.rendered || pendingReplaceRequest.item?.filename || 'this media file') + '" with "' + (pendingReplaceRequest.file?.name || 'new file') + '"?'),
        pendingReplaceRequest.loading ? h('div', { class: 've-safety-note' }, h('span', { class: 've-media-progress-spinner' }), 'Checking usage…') : renderUsageSafetySummary(pendingReplaceRequest.usage, 'No detected usage. MV will still save a rollback point before replacing the file.')
      ),
      confirmText: 'Replace File',
      danger: !!(pendingReplaceRequest.usage?.total),
      onCancel: () => { setPendingReplaceRequest(null); if (replaceInputRef.current) replaceInputRef.current.value = ''; },
      onConfirm: confirmReplaceFile
    }),
    pendingDeleteCollection && h(ConfirmModal, {
      title: 'Remove Collection',
      body: `Remove "${pendingDeleteCollection.label}" from Media Studio? Media files will not be deleted, but ${pendingDeleteCollection.count || 0} collection assignment(s) will be removed.`,
      confirmText: 'Remove Collection',
      danger: true,
      onCancel: () => setPendingDeleteCollection(null),
      onConfirm: confirmDeleteCollection
    }),
    pendingUrlImport && h('div', { class: 've-modal', onMouseDown: () => setPendingUrlImport(null) },
      h('div', { class: 've-modal-box', onMouseDown: e => e.stopPropagation() },
        h('div', { class: 've-modal-title' }, 'Preview URL import'),
        h('div', { class: 've-modal-body' }, 'Review the remote file before Media Studio downloads it into WordPress.'),
        h('div', { class: 've-url-preview-grid' },
          h('div', { class: 've-url-preview-row' }, h('strong', null, 'File'), h('span', { title: pendingUrlImport.filename || pendingUrlImport.url }, pendingUrlImport.filename || pendingUrlImport.url)),
          h('div', { class: 've-url-preview-row' }, h('strong', null, 'Type'), h('span', null, pendingUrlImport.content_type || 'Unknown')),
          h('div', { class: 've-url-preview-row' }, h('strong', null, 'Size'), h('span', null, pendingUrlImport.size_human || 'Unknown')),
          h('div', { class: 've-url-preview-row' }, h('strong', null, 'Source'), h('span', { title: pendingUrlImport.url }, pendingUrlImport.host || pendingUrlImport.url))
        ),
        pendingUrlImport.over_limit && h('div', { class: 've-url-preview-error' }, 'This file is larger than the current 50 MB server import limit. Download it manually or raise the limit later.'),
        !pendingUrlImport.over_limit && !pendingUrlImport.size && h('div', { class: 've-url-preview-warning' }, 'The server could not confirm the file size before download. Import may still fail if the source blocks downloads or the file is above the limit.'),
        pendingUrlImport.looks_like_page && h('div', { class: 've-url-preview-warning' }, 'This looks like a webpage, not a direct media file. A direct .jpg, .png, .mp4, .pdf, or similar file URL works best.'),
        urlImportHistory.length > 0 && h('div', { class: 've-url-history-mini' },
          h('div', { class: 've-url-history-head' },
            h('strong', null, 'Recent URL imports'),
            h('button', { class: 've-url-history-clear', type: 'button', onClick: async () => { try { await api.f('variable-engine/v1/media-studio/url-history', { method: 'DELETE' }); setUrlImportHistory([]); } catch(e) {} } }, 'Clear')
          ),
          urlImportHistory.slice(0, 4).map(row => h('div', { class: 've-url-history-row', key: row.id || row.at || row.url },
            h('span', null, row.title || row.url || 'URL import'),
            h('em', null, (row.status || 'complete') + (row.mime_type ? ' · ' + row.mime_type : '') + (row.size ? ' · ' + formatSize(row.size) : ''))
          ))
        ),
        h('div', { class: 've-modal-actions', style: 'margin-top:12px' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => setPendingUrlImport(null) }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-s', type: 'button', disabled: !!pendingUrlImport.over_limit, onClick: () => doUrlImport(pendingUrlImport.url) }, 'Import media')
        )
      )
    ),
    collectionMenu && h('div', {
      class: 've-context-menu ve-context-menu-attached',
      style: contextMenuStyle,
      onClick: e => e.stopPropagation()
    },
      (() => {
        const menuKey = collectionMenu.key;
        // "All media" is not a user collection — only the actions that make sense
        // for the whole library apply (rename/star/color/lock/delete/subfolder do not).
        if (menuKey === 'all') {
          return [
            h('button', { type: 'button', onClick: () => { openMediaCollection('all'); setCollectionMenu(null); } }, ph('images'), 'View all media'),
            h('button', { type: 'button', onClick: () => { setNewCollName(''); setShowNewCollForm(true); setCollectionMenu(null); } }, ph('plus'), 'New collection'),
            h('button', { type: 'button', onClick: downloadAllLibraryZip }, ph('download-simple'), 'Download all media')
          ];
        }
        const menuEntry = collectionMap[menuKey] || {};
        const lockedMenu = !!menuEntry.locked;
        const shortcode = '[mv_media_collection collection="' + menuKey + '"]';
        const updateCollectionMeta = patch => {
          persistCollections({ ...collectionMap, [menuKey]: { ...menuEntry, ...patch } });
          setCollectionMenu(null);
        };
        return [
          h('button', { type: 'button', onClick: () => beginRenameCollection(menuKey), disabled: lockedMenu }, ph('pencil-simple'), 'Rename'),
          h('button', { type: 'button', onClick: () => beginChildCollection(menuKey), disabled: lockedMenu }, ph('tree-structure'), 'New subfolder'),
          !isFolderCollection(menuKey) && h('button', { type: 'button', onClick: () => { updateCollectionMeta({ starred: !menuEntry.starred }); flash(menuEntry.starred ? 'Removed from Starred.' : 'Pinned to Starred.'); } }, ph('star'), menuEntry.starred ? 'Unstar collection' : 'Star collection'),
          !isFolderCollection(menuKey) && h('button', { type: 'button', onClick: event => openCollectionColorPicker(menuKey, event) }, ph('palette'), collectionColor(menuKey) ? 'Change color' : 'Set color'),
          h('button', { type: 'button', onClick: () => { setSelectedColl(menuKey); setCollectionMenu(null); } }, ph('folder-open'), 'View collection'),
          h('button', { type: 'button', onClick: () => { downloadCollectionZip(menuKey); setCollectionMenu(null); } }, ph('download-simple'), 'Download all'),
          !isFolderCollection(menuKey) && h('button', { type: 'button', onClick: () => chooseZipForCollection(menuKey), disabled: lockedMenu }, ph('file-arrow-down'), 'Import ZIP to collection'),
          !isFolderCollection(menuKey) && h('button', { type: 'button', onClick: () => { navigator.clipboard?.writeText(shortcode); flash('Copied collection shortcode.'); setCollectionMenu(null); } }, ph('brackets-curly'), 'Copy gallery shortcode'),
          !isFolderCollection(menuKey) && h('button', { type: 'button', onClick: () => {
            updateCollectionMeta({ locked: !lockedMenu });
            flash(lockedMenu ? 'Collection unlocked.' : 'Collection locked.');
          } }, ph(lockedMenu ? 'lock-open' : 'lock-simple'), lockedMenu ? 'Unlock folder' : 'Lock folder'),
          !isFolderCollection(menuKey) && h('button', { type: 'button', class: 'danger', disabled: lockedMenu, onClick: () => { requestDeleteCollection(menuKey); setCollectionMenu(null); } }, ph('trash'), 'Delete')
        ];
      })()
    ),
    collectionColorPicker && h('div', { class: 've-floating-scrim ve-collection-color-scrim', onMouseDown: () => setCollectionColorPicker(null) },
      h('div', {
        class: 've-collection-color-popover',
        ref: el => {
          // Clamped inside the studio, not the window: a backdrop-filter
          // ancestor makes the panel its containing block. Re-clamped on resize
          // because switching to VAR makes the popover taller after it opens.
          if (collectionPopoverCleanup.current) { collectionPopoverCleanup.current(); collectionPopoverCleanup.current = null; }
          if (!el) return;
          collectionPopoverCleanup.current = keepInsideBounds(el, () =>
            mediaLayoutRef.current?.getBoundingClientRect ? mediaLayoutRef.current.getBoundingClientRect() : null);
        },
        style: { left: (collectionColorPicker.left || 16) + 'px', top: (collectionColorPicker.top || 16) + 'px' },
        onMouseDown: e => e.stopPropagation()
      },
        h('div', { class: 've-collection-color-head' },
          h('div', { class: 've-collection-color-copy' },
            h('div', { class: 've-modal-title' }, 'Collection color'),
            h('div', { class: 've-modal-body' }, 'Used in the collection tree and filters')
          ),
          h('span', {
            class: 've-collection-color-preview',
            style: {
              '--ve-picker-alpha-color': collectionColorPicker.color || '#baf400'
            },
            'aria-hidden': 'true'
          })
        ),
        h('div', { class: 've-collection-color-name' }, ph(collIcon(collectionColorPicker.key)), h('span', null, collLabel(collectionColorPicker.key))),
        h(MVInlineColorPicker, {
          hex: clrToHex(collectionColorPicker.color || '#baf400'),
          onChange: hex => setDraftCollectionColor(hexWithAlpha(hex,clrAlpha(collectionColorPicker.color || '#baf400'))),
          alpha: clrAlpha(collectionColorPicker.color || '#baf400'),
          onAlphaChange: alpha => setDraftCollectionColor(hexWithAlpha(clrToHex(collectionColorPicker.color || '#baf400'),alpha)),
          fmt: collectionColorFmt,
          setFmt: setCollectionColorFmt,
          variant: 'inline',
          label: 'Collection color',
          boundVar: /^var\(/.test(String(collectionColorPicker.color || '')) ? String(collectionColorPicker.color) : '',
          onBindVariable: token => setDraftCollectionColor(token),
          actions: [
            { label: 'Cancel', onClick: () => setCollectionColorPicker(null) },
            { label: 'Clear', icon: 'x', title: 'Remove the colour from this collection', onClick: () => setDraftCollectionColor('') },
            { label: 'Apply', primary: true, onClick: () => applyCollectionColor(collectionColorPicker.key, collectionColorPicker.color || '') }
          ]
        })
      )
    ),
    externalFolderTip && h('span', {
      class: 've-tooltip-card ve-rich-tip-' + (externalFolderTip.placement || 'left'),
      style: { left: externalFolderTip.left + 'px', top: externalFolderTip.top + 'px' }
    },
      h('strong', null, 'External folder'),
      h('em', null, externalFolderTip.label),
      'Detected from a folder plugin. MV can read counts and assign files, but hierarchy ownership stays external until migrated.'
    ),
    renameCollectionKey && h('div', { class: 've-modal', onMouseDown: () => { setRenameCollectionKey(null); setRenameCollectionName(''); } },
      h('div', { class: 've-modal-box', onMouseDown: e => e.stopPropagation() },
        h('div', { class: 've-modal-title' }, 'Rename collection'),
        h('div', { class: 've-modal-body' }, 'Use slashes to make sub-collections, e.g. Brand / Portraits.'),
        h('input', { class: 've-studio-input', value: renameCollectionName, onInput: e => setRenameCollectionName(e.target.value), onKeyDown: e => { if (e.key === 'Enter') renameLocalCollection(renameCollectionKey, renameCollectionName); if (e.key === 'Escape') setRenameCollectionKey(null); }, autoFocus: true }),
        h('div', { class: 've-modal-actions', style: 'margin-top:12px' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { setRenameCollectionKey(null); setRenameCollectionName(''); } }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: () => renameLocalCollection(renameCollectionKey, renameCollectionName) }, 'Save')
        )
      )
    ),
    showMigrationModal && h('div', { class: 've-modal', onMouseDown: () => setShowMigrationModal(false) },
      h('div', { class: 've-modal-box ve-migration-modal', onMouseDown: e => e.stopPropagation(), style: 'width: 460px; max-width: 90vw; background: #161616; border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); display: flex; flex-direction: column; overflow: hidden;' },
        h('div', { class: 've-modal-title', style: 'padding: 16px; border-bottom: 1px solid rgba(255,255,255,0.06); margin: 0; font-size: 14px; font-weight: 700; color: #fff; display: flex; align-items: center; gap: 8px' },
          ph('arrows-merge', { style: 'color: #baf400; font-size: 18px' }),
          'Migrate Folder-Plugin Folders'
        ),
        h('div', { class: 've-modal-body ve-scroll-custom', style: 'padding: 16px; flex: 1; overflow-y: auto; display: flex; flex-direction: column; gap: 14px; max-height: 380px;' },
          h('div', { style: 'font-size: 12px; color: #aaa; line-height: 1.5' },
            'Migrate detected folder structures and media assignments into Mimam\'s Var local collections. This will copy assignments without deleting the original folders.'
          ),
          h('div', { style: 'display: flex; flex-direction: column; gap: 6px' },
            h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:10px' },
              h('div', { style: 'font-size: 11px; font-weight: 600; color: #888; text-transform: uppercase; letter-spacing: 0.5px' }, 'Select folders to migrate:'),
              (folderData.folders || []).length > 0 && h('div', { style: 'display:flex;align-items:center;gap:6px;flex-shrink:0' },
                h('button', {
                  type: 'button',
                  class: 've-btn ve-btn-g ve-btn-s',
                  style: 'min-height:24px;height:24px;padding:0 8px;font-size:10px',
                  onClick: () => setSelectedMigrateFolders((folderData.folders || []).map(f => String(f.id)))
                }, 'Select all'),
                h('button', {
                  type: 'button',
                  class: 've-btn ve-btn-g ve-btn-s',
                  style: 'min-height:24px;height:24px;padding:0 8px;font-size:10px;color:#aaa',
                  onClick: () => setSelectedMigrateFolders([])
                }, 'Clear')
              )
            ),
            h('div', { class: 've-scroll-custom', style: 'max-height: 180px; overflow-y: auto; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.04); border-radius: 6px; padding: 6px; display: flex; flex-direction: column; gap: 4px;' },
              (folderData.folders || []).length === 0 ? h('div', { style: 'padding: 12px; font-size: 11px; color: #666; text-align: center' }, 'No folders found.') :
              (folderData.folders || []).map(f => {
                const folderId = String(f.id);
                const pathLabel = buildFolderPath(f);
                const isSelected = selectedMigrateFolders.includes(folderId);
                const count = collCounts['folder:' + folderId] || 0;
                return h('label', {
                  key: folderId,
                  style: 'display: flex; align-items: center; gap: 8px; padding: 6px; border-radius: 4px; cursor: pointer; user-select: none; transition: background 0.2s;',
                  class: 've-migration-row'
                },
                  h('input', {
                    type: 'checkbox',
                    class: 've-var-check',
                    checked: isSelected,
                    onChange: (e) => {
                      setSelectedMigrateFolders(prev => {
                        if (e.target.checked) return [...prev, folderId];
                        return prev.filter(x => x !== folderId);
                      });
                    }
                  }),
                  h('span', { style: 'font-size: 11px; color: #ddd; flex: 1; display: flex; align-items: center; gap: 6px' },
                    ph('folder', { style: 'color: #baf400; opacity: 0.7' }),
                    pathLabel
                  ),
                  h('span', { class: 've-studio-badge', style: 'opacity: 0.68' }, `${count} item${count === 1 ? '' : 's'}`)
                );
              })
            )
          ),
          h('div', { style: 'margin-top: 4px; border-top: 1px solid rgba(255,255,255,0.04); padding-top: 12px; display: flex; flex-direction: column; gap: 8px' },
            h('label', { style: 'display: flex; align-items: center; gap: 8px; cursor: pointer' },
              h('input', {
                type: 'checkbox',
                class: 've-var-check',
                checked: migrateHideFolders,
                onChange: (e) => setMigrateHideFolders(e.target.checked)
              }),
              h('span', { style: 'font-size: 11px; color: #ccc' }, 'Hide external folders sidebar after migration')
            )
          )
        ),
        h('div', { class: 've-modal-actions', style: 'padding: 12px 16px; border-top: 1px solid rgba(255,255,255,0.06); display: flex; justify-content: flex-end; gap: 8px; margin: 0; background: rgba(0,0,0,0.1)' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => setShowMigrationModal(false) }, 'Cancel'),
          h('button', {
            class: 've-btn ve-btn-s',
            type: 'button',
            style: 'background: #baf400; color: #111; font-weight: 600',
            disabled: !selectedMigrateFolders.length,
            onClick: runFoldersMigration
          }, 'Confirm Migration')
        )
      )
    ),
    collectionCreateModal && h('div', { class: 've-modal', onMouseDown: () => setCollectionCreateModal(null) },
      h('div', { class: 've-modal-box ve-collection-modal', onMouseDown: e => e.stopPropagation() },
        h('div', { class: 've-modal-title' }, 'New sub-collection'),
        h('div', { class: 've-modal-body' }, 'Create this under "' + collLabel(collectionCreateModal.parentKey) + '". Use a clear name so sub-folders stay readable.'),
        h('input', { ref: newCollInputRef, class: 've-studio-input', value: newCollName, onInput: e => setNewCollName(e.target.value), onKeyDown: e => { if (e.key === 'Enter') createCollection(); if (e.key === 'Escape') setCollectionCreateModal(null); }, autoFocus: true }),
        h('div', { class: 've-modal-actions', style: 'margin-top:12px' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { setCollectionCreateModal(null); setNewCollName(''); } }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: createCollection, disabled: !newCollName.trim() }, 'Create')
        )
      )
    ),
    pendingRename && h('div', { class: 've-modal', onMouseDown: () => { setPendingRename(null); setFilenameDraft(pendingRename.item.title?.rendered || ''); } },
      h('div', { class: 've-modal-box', onMouseDown: e => e.stopPropagation() },
        h('div', { class: 've-modal-title' }, 'Update media filename?'),
        h('div', { class: 've-modal-body' }, 'Save the new name as the attachment title only, or also rename the physical file URL where WordPress allows it.'),
        h('div', { class: 've-modal-actions' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { setPendingRename(null); setFilenameDraft(pendingRename.item.title?.rendered || ''); } }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => applyFilenameSave(false) }, 'Title only'),
          h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: () => applyFilenameSave(true) }, 'Rename file URL')
        )
      )
    ),
    pendingBatchCollection && h('div', { class: 've-modal', onMouseDown: () => setPendingBatchCollection(false) },
      h('div', { class: 've-modal-box ve-collection-modal', onMouseDown: e => e.stopPropagation() },
        h('div', { class: 've-modal-title' }, 'Add to Collection'),
        h('div', { class: 've-modal-body' }, 'Choose where to place the selected media, or create a new collection first.'),
        h('div', { class: 've-collection-choice-list ve-scroll-custom' },
          collKeys.length ? collKeys.map(key => { const lockedChoice = isLockedCollection(key); return h('button', { type: 'button', key, class: 've-collection-choice' + (lockedChoice ? ' disabled' : ''), disabled: lockedChoice, onClick: () => applyBatchCollection(key), title: lockedChoice ? 'Unlock this collection before adding media.' : '' }, ph(lockedChoice ? 'lock-simple' : collIcon(key)), h('span', null, collLabel(key)), h('em', null, lockedChoice ? 'Locked' : (collCounts[key] || 0) + ' items')); }) : h('div', { class: 've-empty', style: 'padding:12px' }, 'No collections yet.')
        ),
        h('div', { class: 've-batch-new-collection' },
          h('div', { class: 've-studio-nav-title', style: 'margin:0 0 6px' }, 'Create new collection'),
          h('div', { class: 've-batch-new-collection-grid' },
            h('input', { class: 've-studio-input', placeholder: 'Collection name...', value: batchNewCollName, onInput: e => setBatchNewCollName(e.target.value), autoFocus: true }),
            h(SelectMenu, { className: 've-filter-menu ve-icon-select', value: batchNewCollIcon, onChange: setBatchNewCollIcon, options: visibleIcons.slice(0, 80).map(icon => ({ value: icon, label: icon })) }),
            h('div', { class: 've-batch-new-collection-actions' },
              h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { setBatchNewCollName(''); setBatchNewCollIcon('folder'); setPendingBatchCollection(false); } }, 'Cancel'),
              h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: createCollectionForSelection, disabled: !batchNewCollName.trim() }, 'Create')
            )
          )
        )
      )
    ),
    MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED && dragActive && !isInternalDragBlocked() && !hasMediaDrag(null) && !hasCollectionDrag(null) && h('div', { class: 've-drop-overlay', onDragOver: e => { if (isUploadFileDrag(e)) { e.preventDefault(); e.stopPropagation(); } }, onDragLeave: e => { e.preventDefault(); e.stopPropagation(); if (!dragIsStillInside(e, mediaLayoutRef.current)) clearFileDrop(); }, onDrop: handleDrop }, h('div', null, ph('upload-simple'), h('strong', null, 'Drop files to upload'))),
    // 1. Sidebar Left
    h('div', { class: 've-studio-sidebar', style: { position: 'relative', width: sidebarWidth + 'px', flexBasis: sidebarWidth + 'px' } },
      h('div', { class: 've-sidebar-resizer', onMouseDown: beginSidebarResize, title: 'Drag to resize sidebar' }),
      showNewCollForm && h('div', { class: 've-collection-inline-pop' },
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:8px' },
          h('div', { class: 've-studio-nav-title', style: 'margin:0' }, 'Create collection'),
          h('button', { class: 've-a', type: 'button', style: 'width:24px;height:24px;display:flex;align-items:center;justify-content:center', onClick: () => { setShowNewCollForm(false); setNewCollName(''); } }, ph('x'))
        ),
        h('input', { ref: newCollInputRef, class: 've-studio-input', placeholder: 'Collection name...', value: newCollName, onInput: e => setNewCollName(e.target.value), onKeyDown: e => { if (e.key === 'Enter') createCollection(); if (e.key === 'Escape') setShowNewCollForm(false); } }),
        h('div', { style: 'font-size:10px;color:#777;line-height:1.45' }, 'Use slashes for sub collections, e.g. Brand / Portraits. One media item can belong to many collections.'),
        h('input', { class: 've-studio-input', placeholder: 'Search Phosphor icons...', value: iconSearch, onInput: e => setIconSearch(e.target.value), style: 'font-size:11px' }),
        h('div', { class: 've-icon-grid ve-scroll-custom' },
          visibleIcons.map(icon => h('button', { type: 'button', key: icon, class: 've-icon-pick' + (newCollIcon === icon ? ' active' : ''), onClick: () => setNewCollIcon(icon), title: icon }, ph(icon), h('span', null, icon)))
        ),
        h('div', { style: 'display:flex;gap:7px' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', style: 'flex:1', onClick: () => { setShowNewCollForm(false); setNewCollName(''); } }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-s', style: 'flex:1;background:#baf400;color:#111;font-weight:600', onClick: createCollection, disabled: !newCollName.trim() }, 'Create')
        )
      ),
      h('div', { class: 've-studio-sidebar-scroll ve-scroll-custom' + (showNewCollForm ? ' ve-sidebar-blurred' : '') },
        h('div', { class: 've-studio-nav' },
          h('div', { class: 've-media-collections-head' },
            h('div', { class: 've-studio-nav-title', style: 'display:flex;align-items:center;justify-content:space-between;width:100%' }, 
              h('span', null, 'Collections'),
              folderData.folders && folderData.folders.length > 0 && h('button', {
                type: 'button',
                class: 've-a',
                style: 'color:#baf400;font-size:12px;display:flex;align-items:center;gap:4px',
                title: 'Migrate Folder-Plugin Folders',
                onClick: (e) => {
                  e.stopPropagation();
                  setSelectedMigrateFolders((folderData.folders || []).map(f => String(f.id)));
                  setShowMigrationModal(true);
                }
              }, ph('arrows-merge'))
            ),
            h('div', { class: 've-collection-tools' },
              h('input', { class: 've-studio-input', placeholder: 'Search collections...', value: collectionSearch, onInput: e => setCollectionSearch(e.target.value) }),
              h('button', { class: 've-btn ve-btn-g ve-btn-s ve-collection-tool-btn ve-collection-shortcuts', type: 'button', title: 'Shortcuts', onClick: () => setShowCommandPanel(true) }, ph('command')),
              h('button', {
                key: collectionBranchesAllExpanded ? 'collapse-folders' : 'expand-folders',
                class: 've-btn ve-btn-g ve-btn-s ve-collection-tool-btn',
                title: collectionBranchesAllExpanded ? 'Collapse all folders' : 'Expand all folders',
                'aria-label': collectionBranchesAllExpanded ? 'Collapse all folders' : 'Expand all folders',
                onClick: toggleAllCollectionBranches
              }, ph(collectionBranchesAllExpanded ? 'arrows-in-line-vertical' : 'arrows-out-line-vertical')),
              h(SelectMenu, { className: 've-filter-menu', value: collectionSort, onChange: persistCollectionSort, options: [
                { value: 'az', label: 'A-Z' },
                { value: 'za', label: 'Z-A' },
                { value: 'manual', label: 'Manual' },
                { value: 'old', label: 'Old-New' }
              ] }),
              h('button', { class: 've-btn ve-btn-g ve-btn-s ve-collection-tool-btn ve-collection-dynamic', type: 'button', title: showDynamicFolders ? 'Hide dynamic folders' : 'Show dynamic folders', onClick: () => setShowDynamicFolders(v => !v) }, ph('magic-wand'))
            ),
            showDynamicFolders && renderDynamicFoldersPanel(),
            h('div', { class: 've-studio-nav-item' + (selectedColl === 'all' ? ' active' : ''), onClick: () => openMediaCollection('all'),
              onContextMenu: e => {
                e.preventDefault();
                e.stopPropagation();
                const hostRect = mediaLayoutRef.current ? mediaLayoutRef.current.getBoundingClientRect() : null;
                const rowRect = e.currentTarget.getBoundingClientRect();
                if (hostRect) {
                  const menuWidth = 188;
                  const gap = 10;
                  setCollectionMenu({
                    key: 'all',
                    x: rowRect.right - hostRect.left + gap,
                    fallbackX: rowRect.left - hostRect.left - menuWidth - gap,
                    y: rowRect.top + (rowRect.height / 2) - hostRect.top,
                    rowTop: rowRect.top - hostRect.top,
                    rowHeight: rowRect.height || 32,
                    bounds: { width: hostRect.width, height: hostRect.height }
                  });
                } else {
                  setCollectionMenu({ key: 'all', x: e.clientX + 10, fallbackX: e.clientX - 198, y: e.clientY, rowTop: e.clientY - 16, rowHeight: rowRect.height || 32, bounds: { width: window.innerWidth || 900, height: window.innerHeight || 620 } });
                }
              }
            },
              h('span', { style: 'display:flex;align-items:center;gap:8px' }, ph('images'), 'All media'),
              h('span', { class: 've-studio-badge' }, items.length)
            ),
            h('div', { class: 've-studio-nav-item' + (selectedColl === 'uncollected' ? ' active' : ''), onClick: () => openMediaCollection('uncollected') },
              h('span', { style: 'display:flex;align-items:center;gap:8px' }, ph('tray'), 'Uncollected'),
              h('span', { class: 've-studio-badge' }, collIds('uncollected').length)
            )
          ),
          // Dynamic collection items
          h('div', { class: 've-media-collection-list ve-scroll-custom' },
          visibleCollKeys.map(key => {
            const entry = collectionMap[key] || {};
            const canDrag = !isFolderCollection(key);
            const locked = !!entry.locked;
            const label = collLabel(key);
            
            const isPathHidden = (lbl) => {
              const parts = lbl.split(' / ');
              for (let i = 1; i < parts.length; i++) {
                const ancestor = parts.slice(0, i).join(' / ');
                if (isCollectionBranchCollapsed(collectionLabelToKey[ancestor], ancestor)) return true;
              }
              return false;
            };
            if (isPathHidden(label)) return null;

            const depth = label.split('/').length - 1;
            const leafLabel = label.split('/').pop().trim();

            const hasChildren = collKeys.some(otherKey => {
              if (otherKey === key) return false;
              const otherLabel = collLabel(otherKey);
              return otherLabel.startsWith(label + ' / ');
            });

            const guides = [];
            for (let i = 0; i < depth; i++) {
              guides.push(h('div', { class: 've-tree-guide', key: i }));
            }

            const dropClass = dropCollection === key ? (dropMode === 'nest' ? ' drop-nest' : (dropMode === 'media' ? ' drop-media' : (dropMode === 'after' ? ' drop-after' : ' drop-before'))) : '';
            const dropLabel = dropCollection === key
              ? (dropMode === 'nest' ? ('Make child of ' + leafLabel) : (dropMode === 'media' ? 'Add media' : (dropMode === 'after' ? ('After ' + leafLabel) : ('Before ' + leafLabel))))
              : '';
            return h('div', {
              key,
              class: 've-studio-nav-item' + (selectedColl === key ? ' active' : '') + dropClass + (locked ? ' ve-media-locked' : '') + (isStarredCollection(key) ? ' starred' : '') + (collectionColor(key) ? ' has-custom-color' : ''),
              'data-drop-label': dropLabel,
              style: collectionColor(key) ? { '--ve-collection-accent': collectionColor(key) } : undefined,
              'aria-label': canDrag ? 'MV collection. Drag the handle to reorder. Shift-drop onto another MV collection to nest.' : 'Detected folder-plugin collection. Selectable here; hierarchy stays owned by the folder plugin.',
              title: '',
              draggable: canDrag && !locked,
              onPointerDown: e => {
                if (e.button !== 0 || !canDrag || locked) return;
                collectionDragActiveRef.current = true;
                mediaDragActiveRef.current = false;
                mediaDragCandidateRef.current = false;
                setMediaDragIds([]);
                markInternalDrag('collection');
              },
              onClick: () => openMediaCollection(key),
              onContextMenu: e => {
                e.preventDefault();
                e.stopPropagation();
                const hostRect = mediaLayoutRef.current ? mediaLayoutRef.current.getBoundingClientRect() : null;
                const rowRect = e.currentTarget.getBoundingClientRect();
                if (hostRect) {
                  const menuWidth = 188;
                  const gap = 10;
                  setCollectionMenu({
                    key,
                    x: rowRect.right - hostRect.left + gap,
                    fallbackX: rowRect.left - hostRect.left - menuWidth - gap,
                    y: rowRect.top + (rowRect.height / 2) - hostRect.top,
                    rowTop: rowRect.top - hostRect.top,
                    rowHeight: rowRect.height || 32,
                    bounds: { width: hostRect.width, height: hostRect.height }
                  });
                } else {
                  setCollectionMenu({
                    key,
                    x: e.clientX + 10,
                    fallbackX: e.clientX - 198,
                    y: e.clientY,
                    rowTop: e.clientY - 16,
                    rowHeight: rowRect.height || 32,
                    bounds: { width: window.innerWidth || 900, height: window.innerHeight || 620 }
                  });
                }
              },
              onDragStart: e => {
                if (!canDrag || locked) return;
                collectionDragActiveRef.current = true;
                mediaDragActiveRef.current = false;
                mediaDragCandidateRef.current = false;
                setMediaDragIds([]);
                markInternalDrag('collection');
                setDragCollection(key);
                setDragActive(false);
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('application/x-ve-collection-key', key);
                e.dataTransfer.setData('application/x-ve-internal-drag', 'collection');
                e.dataTransfer.setData('text/plain', key);
              },
              onDragOver: e => {
                const collectionPayload = e?.dataTransfer?.getData ? e.dataTransfer.getData('application/x-ve-collection-key') : '';
                const isCollectionMove = !!dragCollection || !!collectionPayload || collectionDragActiveRef.current;
                if (isCollectionMove) {
                  if (!dragCollection && collectionPayload) setDragCollection(collectionPayload);
                  if ((dragCollection || collectionPayload) === key || locked) return;
                  e.preventDefault();
                  e.stopPropagation();
                  mediaDropDepthRef.current = 0;
                  setDragActive(false);
                  setDropCollection(key);
                  const rowRect = e.currentTarget.getBoundingClientRect();
                  const yRatio = rowRect.height ? (e.clientY - rowRect.top) / rowRect.height : 0.5;
                  const xNestPoint = rowRect.left + Math.min(rowRect.width * 0.30, 82);
                  const sourceKey = dragCollection || collectionPayload;
                  const sourceLabel = sourceKey ? collLabel(sourceKey) : '';
                  const targetLabel = collLabel(key);
                  const targetIsInsideSource = sourceLabel && (targetLabel === sourceLabel || targetLabel.startsWith(sourceLabel + ' / '));
                  const wantsNest = !targetIsInsideSource && (e.shiftKey || e.altKey || (yRatio > 0.26 && yRatio < 0.74 && e.clientX > xNestPoint));
                  const mode = wantsNest ? 'nest' : (yRatio > 0.68 ? 'after' : 'before');
                  setDropMode(mode);
                  return;
                }
                if (hasMediaDrag(e)) {
                  if (locked) {
                    e.preventDefault();
                    e.stopPropagation();
                    setDropCollection(null);
                    setDropMode('');
                    return;
                  }
                  e.preventDefault();
                  e.stopPropagation();
                  mediaDropDepthRef.current = 0;
                  setDragActive(false);
                  setDropCollection(key);
                  setDropMode('media');
                  return;
                }
              },
              onDragLeave: () => {
                if (dropCollection === key) {
                  setDropCollection(null);
                  setDropMode('');
                }
              },
              onDrop: e => {
                e.preventDefault();
                e.stopPropagation();
                const mediaPayload = e.dataTransfer.getData('application/x-ve-media-ids');
                let droppedMediaIds = [];
                if (mediaPayload) {
                  try { droppedMediaIds = JSON.parse(mediaPayload); } catch(err) { droppedMediaIds = []; }
                }
                if (!droppedMediaIds.length && mediaDragIds.length) droppedMediaIds = mediaDragIds;
                if (droppedMediaIds.length) {
                  if (locked) {
                    flash('Unlock "' + collLabel(key) + '" before adding media.');
                    mediaDragActiveRef.current = false;
                    mediaDragCandidateRef.current = false;
                    mediaDropDepthRef.current = 0;
                    setDragActive(false);
                    setMediaDragIds([]);
                    clearInternalDragMarker();
                    setDropCollection(null);
                    setDropMode('');
                    return;
                  }
                  addMediaIdsToCollection(key, droppedMediaIds);
                  mediaDragActiveRef.current = false;
                  mediaDragCandidateRef.current = false;
                  mediaDropDepthRef.current = 0;
                  setDragActive(false);
                  setMediaDragIds([]);
                  clearInternalDragMarker()
                  setDropCollection(null);
                  setDropMode('');
                  return;
                }
                const from = dragCollection || e.dataTransfer.getData('application/x-ve-collection-key') || e.dataTransfer.getData('text/plain');
                if (dropMode === 'nest' || e.shiftKey || e.altKey) nestCollectionUnder(from, key);
                else if (dropMode === 'after') reorderCollectionAfter(from, key);
                else reorderCollectionBefore(from, key);
                collectionDragActiveRef.current = false;
                clearInternalDragMarker()
                setDragCollection(null);
                setDropCollection(null);
                setDropMode('');
                setDragActive(false);
              },
              onDragEnd: () => {
                collectionDragActiveRef.current = false;
                clearInternalDragMarker()
                setDragCollection(null);
                setDropCollection(null);
                setDropMode('');
                setDragActive(false);
              }
            },
              canDrag
                ? (locked
                  ? h('span', {
                    class: 've-collection-drag ve-collection-drag-disabled ve-collection-lock-static',
                    'aria-label': 'Locked collection. Use the right-click menu to unlock before moving.',
                    title: '',
                    onClick: e => { e.preventDefault(); e.stopPropagation(); },
                    onPointerDown: e => { e.preventDefault(); e.stopPropagation(); }
                  }, ph('lock-simple'))
                  : h('button', {
                    type: 'button',
                    class: 've-collection-drag',
                    draggable: true,
                    'aria-label': 'Drag to reorder. Move slightly right or hold Shift while dropping to nest.',
                    title: '',
                    onPointerDown: e => {
                      if (e.button !== 0) return;
                      e.stopPropagation();
                      collectionDragActiveRef.current = true;
                      mediaDragActiveRef.current = false;
                      mediaDragCandidateRef.current = false;
                      setMediaDragIds([]);
                      markInternalDrag('collection');
                    },
                    onClick: e => e.stopPropagation(),
                    onDragStart: e => {
                      e.stopPropagation();
                      collectionDragActiveRef.current = true;
                      mediaDragActiveRef.current = false;
                      mediaDragCandidateRef.current = false;
                      setMediaDragIds([]);
                      markInternalDrag('collection');
                      setDragCollection(key);
                      setDragActive(false);
                      e.dataTransfer.effectAllowed = 'move';
                      e.dataTransfer.setData('application/x-ve-collection-key', key);
                      e.dataTransfer.setData('application/x-ve-internal-drag', 'collection');
                      e.dataTransfer.setData('text/plain', key);
                    },
                    onDragEnd: () => {
                      collectionDragActiveRef.current = false;
                      clearInternalDragMarker()
                      setDragCollection(null);
                      setDropCollection(null);
                      setDropMode('');
                      setDragActive(false);
                    }
                  }, ph('dots-six-vertical')))
                : h('span', {
                  class: 've-collection-drag ve-collection-drag-disabled',
                  'aria-label': 'Detected folder-plugin folder. MV can view and assign it, but cannot safely reorder or nest it yet.'
                }, ph('lock-simple')),
              h('div', { class: 've-media-tree-guides' }, guides),
              h('div', { style: 'display: flex; align-items: center; gap: 4px; flex: 1; min-width: 0;' },
                hasChildren ? h('button', {
                  key: 'tree-toggle-' + key + '-' + (isCollectionBranchCollapsed(key, label) ? 'collapsed' : 'open'),
                  type: 'button',
                  class: 've-tree-toggle',
                  onClick: (e) => {
                    e.stopPropagation();
                    setCollectionBranchCollapsed(key, label, !isCollectionBranchCollapsed(key, label));
                  },
                  'aria-label': isCollectionBranchCollapsed(key, label) ? 'Expand children' : 'Collapse children',
                  title: isCollectionBranchCollapsed(key, label) ? 'Expand children' : 'Collapse children'
                }, ph(isCollectionBranchCollapsed(key, label) ? 'caret-right' : 'caret-down')) : h('div', { class: 've-tree-spacer' }),
                ph(collIcon(key), { style: 'flex-shrink: 0;' }),
                isStarredCollection(key) && h('span', { class: 've-collection-star-pill', title: 'Starred collection: pinned above normal collections' }, ph('star')),
                h('span', { style: 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px' }, leafLabel)
              ),
              h('span', { style: 'display:flex;align-items:center;gap:4px;flex-shrink:0' },
                canDrag && h('span', {
                  class: 've-collection-badge local',
                  'aria-label': 'Mimam’s Var collection'
                }, 'MV'),
                h('span', { class: 've-studio-badge' }, collCounts[key] || 0),
                !canDrag && h('span', {
                  class: 've-collection-source-pill',
                  onMouseEnter: e => showExternalFolderTip(collLabel(key), e),
                  onMouseMove: e => showExternalFolderTip(collLabel(key), e),
                  onMouseLeave: () => setExternalFolderTip(null),
                  title: ''
                },
                  ph('folder-dashed')
                ),
                !isFolderCollection(key) && h('button', { class: 've-a', style: 'width:16px;height:16px;display:flex;align-items:center;justify-content:center;opacity:0.4;font-size:11px', title: 'Remove collection', onClick: (e) => { e.stopPropagation(); requestDeleteCollection(key); } }, ph('x'))
              )
            );
          }),
          collectionSearchTerm && !visibleCollKeys.length && h('div', { class: 've-empty', style: 'padding:10px;text-align:left' }, 'No matching collections.')
          )
        )
      ),
      h('div', { class: 've-studio-sidebar-actions' + (showNewCollForm ? ' ve-sidebar-blurred' : '') },
        h('button', {
          class: 've-btn ve-btn-g ve-btn-s',
          style: 'display:flex;align-items:center;justify-content:center;gap:6px',
          onClick: () => { setNewCollName(''); setShowNewCollForm(true); }
        }, ph('plus'), 'New Collection'),
        folderData.folders && folderData.folders.length > 0 && h('div', {
          class: 've-folder-migration-promo',
          style: 'margin-top:12px;background:rgba(186,244,0,0.04);border:1px dashed rgba(186,244,0,0.25);padding:10px;border-radius:6px;display:flex;flex-direction:column;gap:6px'
        },
          h('div', { style: 'font-size:11px;color:#fff;font-weight:600;display:flex;align-items:center;gap:4px' }, ph('arrows-merge'), 'Folder Plugin Migration'),
          h('div', { style: 'font-size:10px;color:#bbb;line-height:1.45' }, 'Copy your external folders into MV local collections in bulk, or sync while the old folder plugin stays installed.'),
          h('button', {
            type: 'button',
            class: 've-btn ve-btn-g ve-btn-s',
            style: 'font-size:10px;padding:4px 8px;width:100%',
            onClick: syncExternalFolders
          }, ph('arrows-clockwise'), 'Sync external folders'),
          h('button', {
            type: 'button',
            class: 've-btn ve-btn-s',
            style: 'background:#baf400;color:#111;font-weight:600;font-size:10px;padding:4px 8px;margin-top:2px;width:100%',
            onClick: () => {
              setSelectedMigrateFolders((folderData.folders || []).map(f => String(f.id)));
              setShowMigrationModal(true);
            }
          }, 'Migrate to MV')
        )
      )
    ),
    // 2. Main Middle Gallery
    h('div', {
      class: 've-studio-main' + (MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED && dragActive && !isInternalDragBlocked() && !hasCollectionDrag(null) && !hasMediaDrag(null) ? ' drag-over' : ''),
      ref: mediaMainRef,
      onDragEnter: e => {
        if (showFileDrop(e)) return;
      },
      onDragOver: e => {
        if (hasMediaDrag(e) || hasCollectionDrag(e) || isInternalDragBlocked()) { e.preventDefault(); e.stopPropagation(); return; }
        showFileDrop(e);
      },
      onDragLeave: e => {
        if (MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED && isUploadFileDrag(e) && !dragIsStillInside(e, e.currentTarget)) clearFileDrop();
      },
      onDrop: handleDrop
    },
      h('div', { class: 've-media-main-head', style: 'display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;gap:12px' },
        h('div', null,
          h('h2', { style: 'margin:0;font-size:16px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px' },
            selectedColl === 'all' ? 'All Media' : selectedColl === 'uncollected' ? 'Uncollected Media' : collLabel(selectedColl) + ' Collection',
            h('span', { style: 'font-size:11px;font-weight:400;color:#888;background:rgba(255,255,255,0.04);padding:2px 8px;border-radius:10px' }, `${filtered.length} items`),
            dynamicFilter && h('button', { class: 've-btn ve-btn-g ve-btn-s', style: 'min-height:24px;height:24px;padding:0 7px', type: 'button', onClick: () => setDynamicFilter(null), title: 'Clear dynamic filter' }, ph('x'), dynamicFilter.label || 'Dynamic')
          )
        ),
        h('div', { class: 've-media-toolbar', style: 'display:flex;gap:8px;align-items:center' },
          h('input', {
            class: 've-studio-input',
            style: 'width:160px',
            placeholder: 'Search media...',
            value: search,
            onInput: handleSearch
          }),
          h('div', { class: 've-url-import-row ve-url-import-row--toolbar', onClick: e => e.stopPropagation() },
            h('input', {
              ref: urlImportRef,
              class: 've-studio-input ve-url-import-input',
              type: 'text',
              placeholder: 'Paste media URL…',
              disabled: urlImportBusy,
              onKeyDown: e => { if (e.key === 'Enter') { e.preventDefault(); handleUrlImport(e.target.value); } },
              onPaste: e => { setTimeout(() => { const v = e.target.value.trim(); if (/^https?:\/\//i.test(v)) handleUrlImport(v); }, 0); }
            }),
            h('button', {
              type: 'button',
              class: 've-btn ve-btn-g ve-btn-s ve-url-import-btn',
              disabled: urlImportBusy,
              title: 'Import media from URL',
              onClick: () => handleUrlImport(urlImportRef.current?.value)
            }, ph('cloud-arrow-up'), urlImportBusy ? 'Importing…' : 'Import')
          ),
          h('div', { class: 've-filter-bar' },
            h(SelectMenu, { className: 've-filter-menu', value: filterType, onChange: persistFilter, options: [
              { value: 'all', label: 'All Types' },
              { value: 'image', label: 'Images' },
              { value: 'svg', label: 'SVG' },
              { value: 'video', label: 'Videos' },
              { value: 'audio', label: 'Audio' },
              { value: 'application', label: 'Documents' },
              { value: 'font', label: 'Fonts' }
            ] }),
            h('div', { class: 've-filter-pop-wrap', ref: qualityPanelRef },
              h('button', {
                type: 'button',
                class: 've-menu-btn ve-filter-pop-btn' + (activeQualityFilters.length || qualityPanelOpen ? ' active' : ''),
                onClick: () => setQualityPanelOpen(v => !v),
                'aria-label': activeQualityFilters.length ? 'Open media filters: ' + currentQuality.label : 'Open media filters',
                title: activeQualityFilters.length ? 'Filter: ' + currentQuality.label : 'Filter'
              },
                ph('filter')
              ),
              qualityPanelOpen && h('div', { class: 've-filter-pop ve-scroll-custom' },
                h('div', { class: 've-filter-pop-head' },
                  h('strong', null, ph('filter'), 'Filters'),
                  h('div', { class: 've-filter-pop-head-actions' },
                    activeQualityFilters.length > 0 && h('button', { type: 'button', class: 've-filter-add ve-filter-clear-top', onClick: () => { persistQualityFilters([], false); } }, ph('trash'), 'Delete filter'),
                    h('button', { type: 'button', class: 've-a', onClick: () => setQualityPanelOpen(false) }, ph('x'))
                  )
                ),
                h('input', { class: 've-filter-search', value: qualityQuery, placeholder: 'Filter by…', autoFocus: true, onInput: e => setQualityQuery(e.target.value), onKeyDown: e => { if (e.key === 'Escape') setQualityPanelOpen(false); } }),
                h('div', { class: 've-filter-rulebar' },
                  activeQualityFilters.length ? h('span', { class: 've-filter-rule-pill' }, activeQualityFilters.length + ' rule' + (activeQualityFilters.length === 1 ? '' : 's'), ph('caret-down')) : h('button', { type: 'button', class: 've-filter-add', onClick: () => persistQualityFilters(['missing-alt']) }, ph('plus'), 'Add filter'),
                  h('button', { type: 'button', class: 've-filter-save-link', onClick: saveCurrentQualityPreset }, ph('star'), 'Save current')
                ),
                h('div', { class: 've-filter-save-row' },
                  h('input', { class: 've-filter-search', value: qualityPresetName, placeholder: 'Saved filter name…', onInput: e => setQualityPresetName(e.target.value), onKeyDown: e => { if (e.key === 'Enter') saveCurrentQualityPreset(); } }),
                  h('button', { type: 'button', class: 've-btn ve-btn-s', onClick: saveCurrentQualityPreset }, 'Save')
                ),
                savedQualityPresets.length > 0 && h('div', { class: 've-saved-filter-list' },
                  h('div', { class: 've-saved-filter-title' }, ph('star'), 'Saved filters'),
                  savedQualityPresets.map(preset => h('div', { class: 've-saved-filter-row', key: preset.id },
                    h('button', { type: 'button', onClick: () => applySavedQualityPreset(preset) }, h('strong', null, preset.name), h('em', null, (preset.qualityFilters || []).length + ' rule' + ((preset.qualityFilters || []).length === 1 ? '' : 's'))),
                    h('button', { type: 'button', class: 've-saved-filter-remove', title: 'Delete saved filter', onClick: () => removeSavedQualityPreset(preset.id) }, ph('x'))
                  ))
                ),
                activeQualityFilters.length > 0 && h('div', { class: 've-filter-builder-list' },
                  activeQualityFilters.map(val => {
                    const rule = qualityOptions.find(x => x.value === val) || { label: val };
                    return h('div', { class: 've-filter-builder', key: val },
                      h('span', null, 'Where'),
                      h('code', null, rule.label),
                      h('button', { type: 'button', class: 've-filter-rule-remove', onClick: () => removeQualityRule(val), title: 'Remove this rule' }, ph('x'))
                    );
                  })
                ),
                h('div', { class: 've-filter-pop-help' }, 'Combines with collection, dynamic folders, type, search, and sort.'),
                h('div', { class: 've-filter-choice-list ve-scroll-custom' },
                  shownQualityOptions.length ? shownQualityOptions.map(opt => h('button', {
                    type: 'button',
                    key: opt.value,
                    class: 've-filter-choice' + ((opt.value === 'all' ? activeQualityFilters.length === 0 : activeQualityFilters.includes(opt.value)) ? ' active' : ''),
                    onClick: () => toggleQualityFilter(opt.value)
                  }, ph(opt.icon), h('span', null, opt.label), h('em', null, opt.value === 'all' ? qualityCounts.all : (qualityCounts[opt.value] || 0)))) : h('div', { class: 've-menu-empty' }, 'No matching filters')
                ),
                diagnostics && !String(qualityQuery || '').trim() && h('div', { class: 've-diagnostics-mini' },
                  h('div', { class: 've-diagnostics-mini-head' }, h('strong', null, 'Diagnostics'), h('button', { type: 'button', class: 've-filter-rescan', disabled: diagnosticsLoading, onClick: refreshDiagnostics, title: diagnosticsLoading ? 'Checking diagnostics…' : 'Rescan diagnostics' }, diagnosticsLoading ? ph('arrows-clockwise') : ph('arrows-clockwise'), h('span', null, diagnosticsLoading ? 'Checking' : 'Rescan'))),
                  h('div', { class: 've-diagnostics-mini-grid' },
                    h('span', null, 'Missing files', h('b', null, diagnostics.missing_files || 0)),
                    h('span', null, 'Empty titles', h('b', null, diagnostics.empty_title || 0)),
                    h('span', null, 'Duplicate names', h('b', null, diagnostics.duplicate_filenames || 0))
                  )
                )
              )
            ),
            h(SelectMenu, { className: 've-filter-menu', value: sortBy, onChange: persistSort, options: [
              { value: 'date', label: 'Newest' },
              { value: 'name', label: 'Name A-Z' },
              { value: 'size', label: 'Largest' }
            ] })
          ),
          h('input', { type: 'file', ref: fileInputRef, multiple: true, style: 'display:none', onChange: e => { handleUploadFiles(e.target.files); e.target.value = ''; } }),
          h('input', { type: 'file', ref: zipImportRef, accept: '.zip,application/zip,application/x-zip-compressed', style: 'display:none', onChange: e => { importZipToCollection(e.target.files && e.target.files[0]); } }),
          h('div', { ref: viewPanelRef, class: 've-view-pop-wrap' + (viewPanelOpen && !viewPanelSuppressed ? ' open' : ''), onMouseEnter: openViewPanel, onMouseLeave: scheduleViewPanelClose },
            h('button', {
              class: 've-btn ve-btn-g ve-btn-s',
              style: 'padding:4px 8px;display:flex;align-items:center',
              type: 'button',
              onClick: e => { e.preventDefault(); e.stopPropagation(); toggleViewPanel(); },
              onFocus: openViewPanel,
              'aria-label': 'Choose media view',
              'aria-expanded': viewPanelOpen && !viewPanelSuppressed ? 'true' : 'false'
            }, ph(layoutMode === 'grid' ? 'squares-four' : layoutMode === 'masonry' ? 'columns' : 'list')),
            h('div', { class: 've-view-pop', onMouseEnter: openViewPanel, onMouseLeave: scheduleViewPanelClose },
              [
                { value: 'grid', label: 'Grid View', icon: 'squares-four' },
                { value: 'masonry', label: 'Masonry View', icon: 'columns' },
                { value: 'list', label: 'List View', icon: 'list' }
              ].map(opt => h('button', {
                key: opt.value,
                type: 'button',
                class: 've-view-choice' + (layoutMode === opt.value ? ' active' : ''),
                title: 'Switch to ' + opt.label,
                onClick: e => {
                  persistLayoutMode(opt.value);
                  setViewPanelOpen(false);
                  setViewPanelSuppressed(true);
                  if (e && e.currentTarget && e.currentTarget.blur) e.currentTarget.blur();
                  setTimeout(() => setViewPanelSuppressed(false), 160);
                }
              }, ph(opt.icon), h('span', null, opt.label)))
            )
          ),
          layoutMode === 'list' && h('div', { class: 've-list-meta-pop-wrap', ref: listMetaPanelRef },
            h('button', {
              class: 've-btn ve-btn-g ve-btn-s',
              style: 'padding:4px 8px;display:flex;align-items:center',
              onClick: () => setListMetaPanelOpen(v => !v),
              title: 'Choose list metadata columns',
              'aria-label': 'Choose list metadata columns'
            }, ph('columns')),
            listMetaPanelOpen && h('div', { class: 've-list-meta-pop ve-scroll-custom' },
              h('div', { class: 've-list-meta-pop-head' }, h('span', null, 'Metadata columns'), h('button', { type: 'button', class: 've-a', onClick: () => setListMetaPanelOpen(false) }, ph('x'))),
              listMetaOptions.map(opt => h('label', { class: 've-list-meta-row', key: opt.key },
                h(CheckControl, { checked: listMetaFields.includes(opt.key), onChange: () => toggleListMetaField(opt.key), title: opt.label }),
                h('span', null, opt.label)
              )),
              h('div', { class: 've-filter-rulebar' },
                h('button', { type: 'button', class: 've-filter-add', onClick: () => setListMetaSelection(listMetaOptions.map(x => x.key)) }, ph('plus'), 'Show all'),
                h('button', { type: 'button', class: 've-filter-add', onClick: () => setListMetaSelection([]) }, ph('trash'), 'Hide all')
              )
            )
          )
        )
      ),
      h('div', {
        class: 've-dropzone' + (dragActive && !isInternalDragBlocked() && !hasCollectionDrag(null) && !hasMediaDrag(null) ? ' drag-over' : ''),
        onDragEnter: showFileDrop,
        onDragOver: showFileDrop,
        onDragLeave: e => { if (isUploadFileDrag(e) && !dragIsStillInside(e, e.currentTarget)) clearFileDrop(); },
        onDrop: handleDrop,
        style: 'border:1px dashed rgba(255,255,255,0.1);border-radius:8px;padding:12px;text-align:center;color:#666;font-size:11px;margin-bottom:12px;background:rgba(255,255,255,0.005)'
      }, uploading ? h('div', { class: 've-upload-progress' },
        ph('upload-simple'),
        h('span', null, `${uploadProgress?.state || 'Uploading'} ${Math.min(uploadProgress?.done || 0, uploadProgress?.total || 1)} of ${uploadProgress?.total || 1}`),
        h('em', null, uploadProgress?.name || 'media'),
        h('div', { class: 've-upload-bar' }, h('span', { style: `width:${Math.max(6, Math.min(100, Math.round(uploadProgress?.percent ?? (((uploadProgress?.done || 0) / (uploadProgress?.total || 1)) * 100))))}%` }))
      ) : [
        h('span', { onClick: () => fileInputRef.current?.click(), style: 'cursor:pointer' }, ph('upload-simple'), ' Drag & drop files here, or click to browse')
      ]),
      h('div', { class: 've-media-overview' },
        overviewStats.map(card => h('button', {
          key: card.key,
          type: 'button',
          class: 've-media-overview-card' + (activeQualityFilters.includes(card.key) ? ' active' : ''),
          onClick: () => activateOverviewFilter(card.key),
          title: 'Filter by ' + card.label
        },
          h('span', { class: 've-media-overview-icon' }, ph(card.icon)),
          h('span', { class: 've-media-overview-copy' }, h('strong', null, card.value), h('em', null, card.label), h('small', null, card.helper))
        ))
      ),
      activeQualityFilters.length > 0 && h('div', { class: 've-active-filter-strip' },
        h('span', null, ph('filter'), 'Active filters'),
        activeQualityFilters.map(val => { const rule = qualityOptions.find(x => x.value === val) || { label: val }; return h('button', { key: val, type: 'button', onClick: () => removeQualityRule(val) }, rule.label, ph('x')); }),
        h('button', { type: 'button', class: 'clear', onClick: () => persistQualityFilters([]) }, 'Clear all')
      ),
      activeQualityFilters.includes('missing-alt') && h('div', { class: 've-media-workflow-card' },
        h('div', null, h('strong', null, 'Missing Alt Text workflow'), h('span', null, 'Edit inline, save on blur, or bulk-fill from clean filenames/titles.')),
        h('div', null,
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: bulkFillMissingAltFromFilename }, ph('text-aa'), 'Bulk fill visible'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', disabled: true, title: 'Reserved for later AI alt suggestions.' }, ph('sparkle'), 'AI suggestions later')
        )
      ),
      activeQualityFilters.includes('unused') && h('div', { class: 've-media-workflow-card' },
        h('div', null, h('strong', null, 'True Unused Images scan'), h('span', null, unusedScan.loading ? 'Scanning in the background. You can keep using the library.' : (unusedScan.message ? unusedScan.message : (unusedScan.scanned ? 'Scanned ' + unusedScan.scanned + ' images. ' + (unusedScan.limited ? 'Result was limited for safety.' : '') : 'Select this filter to scan image references.')))),
        h('div', null,
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', disabled: unusedScan.loading, onClick: () => { unusedScanRunRef.current += 1; setUnusedScan({ key: '', ids: null, loading: false, scanned: 0, limited: false, message: '' }); } }, ph('arrows-clockwise'), unusedScan.loading ? 'Scanning…' : 'Rescan')
        )
      ),
      (!loading && filtered.length === 0) ? h('div', { class: 've-media-empty-state' }, activeQualityFilters.includes('unused') ? (unusedScan.loading ? 'Scanning unused images in the background…' : 'No unused images found in the places MV can scan.') : 'No media files found.') :
      showCommandPanel && h('div', { class: 've-media-command' },
        h('div', { class: 've-media-command-head' },
          ph('command'),
          h('input', { class: 've-studio-input', placeholder: 'Search commands and settings', autoFocus: true, onKeyDown: e => { if (e.key === 'Escape') setShowCommandPanel(false); } }),
          h('button', { class: 've-a', style: 'width:28px;height:28px;display:flex;align-items:center;justify-content:center', onClick: () => setShowCommandPanel(false) }, ph('x'))
        ),
        h('div', { class: 've-media-command-body ve-scroll-custom' },
          [
            ['Create New Collection', 'Alt', 'N'],
            ['Rename Collection', 'F2'],
            ['Download Collection ZIP', 'Ctrl', 'D'],
            ['Expand All Folders', '→'],
            ['Collapse Folder', '←'],
            ['Next Collection', '↓'],
            ['Previous Collection', '↑'],
            ['Select range', 'Shift', 'Click'],
            ['Open Media Studio', 'Alt', 'Z']
          ].map((row, index) => h('div', { class: 've-shortcut-row', key: index },
            h('span', null, row[0]),
            h('span', null, row.slice(1).map(key => h('span', { class: 've-keycap', key }, key)))
          ))
        )
      ),
      filtered.length > 0 && (layoutMode === 'grid' ? (
        h('div', { class: 've-media-grid ve-scroll-custom', onContextMenu: onStudioContextMenu }, filtered.map((item, idx) => renderMediaCard(item, idx, 'grid')))
      ) : layoutMode === 'masonry' ? (
        h('div', { class: 've-media-masonry ve-scroll-custom', onContextMenu: onStudioContextMenu, style: { '--ve-masonry-columns': masonryColumnCount } },
          masonryColumns.map((col, colIndex) => h('div', { class: 've-media-masonry-col', key: 'masonry-col-' + colIndex },
            col.map(({ item, idx }) => renderMediaCard(item, idx, 'masonry'))
          ))
        )
      ) : (
        h('div', { class: 've-studio-table-container ve-media-list-scroller ve-scroll-custom', style: 'margin:0;flex:1' },
          h('table', { class: 've-studio-table ve-media-list-table ' + (showListMeta ? 'meta-open' : 'meta-closed'), style: { minWidth: 'max(100%, ' + (720 + (listMetaFields.length * 132)) + 'px)' } },
            h('thead', null,
              h('tr', null,
                h('th', { style: 'width:40px' },
                  h(CheckControl, { checked: checkedItems.length === filtered.length && filtered.length > 0, onChange: toggleCheckAll, title: checkedItems.length === filtered.length ? 'Deselect all' : 'Select all' })
                ),
                h('th', { style: 'width:80px' }, 'Preview'),
                h('th', { class: 've-list-name' }, 'Filename'),
                h('th', { class: 've-list-alt' }, 'Alt Text (Auto-saves on blur)'),
                listMetaFields.includes('mime') && h('th', { class: 've-list-meta' }, 'MIME Type'),
                listMetaFields.includes('size') && h('th', { class: 've-list-meta' }, 'File Size'),
                listMetaFields.includes('dimensions') && h('th', { class: 've-list-meta' }, 'Dimensions'),
                listMetaFields.includes('uploaded') && h('th', { class: 've-list-meta' }, 'Uploaded'),
                listMetaFields.includes('uploaded_by') && h('th', { class: 've-list-meta' }, 'Uploaded By'),
                h('th', { class: 've-list-actions', style: 'text-align:right' }, 'Actions')
              )
            ),
            h('tbody', null, filtered.map((item, idx) => {
              const isChecked = checkedItems.includes(item.id);
              const isSel = selected && Number(selected.id) === Number(item.id);
              return h('tr', {
                key: item.id,
                'data-media-id': item.id,
                class: (isSel ? 'selected ' : '') + (isChecked ? 'checked ' : '') + (ctxMenu && ctxMenu.item && ctxMenu.item.id === item.id ? 've-ctx-target' : ''),
                onClick: e => handleMediaClick(item, e, idx),
                onDoubleClick: e => handleMediaDoubleClick(item, e, idx),
                onDblClick: e => handleMediaDoubleClick(item, e, idx),
                ondblclick: e => handleMediaDoubleClick(item, e, idx),
                draggable: !picking,
                onDragStart: e => {
                  if (picking) { e.preventDefault(); return false; }
                  const ids = checkedItems.includes(item.id) ? checkedItems : [item.id];
                  mediaDragActiveRef.current = true;
                  mediaDragCandidateRef.current = true;
                  setMediaDragIds(ids);
                  markInternalDrag('media');
                  e.dataTransfer.effectAllowed = 'copy';
                  e.dataTransfer.setData('application/x-ve-media-ids', JSON.stringify(ids));
                  e.dataTransfer.setData('application/x-ve-internal-drag', 'media');
                  e.dataTransfer.setData('text/plain', ids.join(','));
                  const ghost = createMediaDragGhost(ids);
                  e.dataTransfer.setDragImage(ghost, 10, 10);
                  setTimeout(() => ghost.remove(), 0);
                },
                onDragEnd: () => { mediaDragActiveRef.current = false; mediaDragCandidateRef.current = false; clearInternalDragMarker(); setMediaDragIds([]); setDropCollection(null); setDropMode(''); setDragActive(false); }
              },
                h('td', { onClick: e => e.stopPropagation() },
                  h(CheckControl, { checked: isChecked, onShiftClick: () => toggleCheckRange(item.id, idx), onChange: (_, e, held) => toggleCheckItem(item.id, Object.assign(e || {}, { __veShiftKey: !!held }), idx), title: isChecked ? 'Deselect asset' : 'Select asset' })
                ),
                h('td', null,
                  h('div', { class: 've-media-list-preview' }, renderFilePreview(item, 'list'))
                ),
                h('td', { class: 've-list-name' },
                  h('div', { class: 've-list-title-cell' },
                    h('strong', null, item.title?.rendered || 'Untitled'),
                    h('em', null, fileExt(item) + ' · ' + formatSize(getFileSize(item)))
                  )
                ),
                h('td', { class: 've-list-alt', onClick: e => e.stopPropagation() },
                  h('input', {
                    class: 've-studio-input',
                    value: item.alt_text || '',
                    placeholder: 'Add alt text...',
                    onInput: e => setItems(prev => prev.map(x => Number(x.id) === Number(item.id) ? { ...x, alt_text: e.target.value } : x)),
                    onBlur: e => handleAltTextSave(item.id, e.target.value)
                  })
                ),
                listMetaFields.includes('mime') && h('td', { class: 've-list-meta', style: 'color:#888;white-space:nowrap' }, item.mime_type),
                listMetaFields.includes('size') && h('td', { class: 've-list-meta', style: 'color:#888;white-space:nowrap' }, formatSize(getFileSize(item))),
                listMetaFields.includes('dimensions') && h('td', { class: 've-list-meta', style: 'color:#888;white-space:nowrap' }, item.media_details ? `${item.media_details.width}x${item.media_details.height}` : 'N/A'),
                listMetaFields.includes('uploaded') && h('td', { class: 've-list-meta', style: 'color:#888;white-space:nowrap' }, item.date ? new Date(item.date).toLocaleDateString() : 'Unknown'),
                listMetaFields.includes('uploaded_by') && h('td', { class: 've-list-meta', style: 'color:#888;white-space:nowrap;overflow:hidden;text-overflow:ellipsis' }, authorLabel(item)),
                h('td', { class: 've-list-actions', style: 'text-align:right', onClick: e => e.stopPropagation() },
                  h('div', { style: 'display:flex;gap:6px;justify-content:flex-end' },
                    h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => handleCopyLink(item.source_url), title: 'Copy URL' }, ph('copy')),
                    h('button', { class: 've-btn ve-btn-g ve-btn-s', style: 'color:#ff4d4d', onClick: () => handleDelete(item), title: 'Delete Permanently' }, ph('trash'))
                  )
                )
              );
            }))
          )
        )
      )),
      // Batch action overlay
      checkedItems.length > 0 && h('div', { class: 've-media-batch-overlay ve-bulk-polished' },
        h('div', { class: 've-bulk-summary' },
          h('button', { type: 'button', class: 've-bulk-close', onClick: () => setCheckedItems([]), title: 'Deselect all' }, ph('x')),
          h('span', { class: 've-bulk-count' }, checkedItems.length),
          h('strong', null, 'Selected'),
          selectedImageItems.length > 0 && h('em', null, selectedImageItems.length + ' image' + (selectedImageItems.length === 1 ? '' : 's'))
        ),
        h('div', { class: 've-media-selected-strip' },
          checkedItems.slice(0, 8).map(id => {
            const item = items.find(x => x.id === id);
            return item ? h('div', { class: 've-media-selected-mini', key: id, title: item.title?.rendered || '' }, renderFilePreview(item, 'grid')) : null;
          }),
          checkedItems.length > 8 && h('span', { class: 've-media-selected-more' }, '+' + (checkedItems.length - 8))
        ),
        h('div', { class: 've-media-batch-actions' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => handleBatchAddToCollection() }, ph('folder'), 'Add to collection'),
          isLocalCollectionOpen() && h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: removeCheckedFromCurrentCollection, title: 'Remove selected media that belong to this open collection' }, ph('x'), 'Remove'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: downloadSelectedZip, title: 'Download selected media as a ZIP export' }, ph('download-simple'), 'Export ZIP'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', disabled: !selectedImageItems.length, onClick: compressCheckedImages, title: selectedImageItems.length ? 'Compress selected images in place. MV rewrites supported image files through the WordPress image editor to reduce file size, then refreshes metadata.' : 'Only images can be compressed' }, ph('hard-drives'), 'Compress'),
          h('span', { class: 've-bulk-convert-group' },
            h(SelectMenu, { className: 've-filter-menu', value: convertFormat, onChange: setConvertFormat, options: [
              { value: 'webp', label: 'WEBP' },
              { value: 'avif', label: 'AVIF' },
              { value: 'jpeg', label: 'JPEG' },
              { value: 'png', label: 'PNG' }
            ] }),
            h('button', { class: 've-btn ve-btn-g ve-btn-s', disabled: !selectedImageItems.length, onClick: convertCheckedImages }, ph('file-arrow-down'), 'Convert')
          ),
          h('button', { class: 've-btn ve-btn-s ve-danger-outline', onClick: handleBatchDelete }, ph('trash'), 'Delete')
        )
      )
    ),
    // 3. Right Sidebar Details Panel — keyed on selected.id for instant switching
    selected && h('div', { key: 'sidecar-' + selected.id, class: 've-studio-details-sidebar ve-scroll-custom' },
      h('div', { class: 've-details-head' },
        h('span', { style: 'font-weight:700;color:#fff' }, 'Attachment Details'),
        h('button', { class: 've-a', style: 'width:24px;height:24px;display:flex;align-items:center;justify-content:center', onClick: () => setSelected(null), title: 'Close Sidebar' }, ph('x'))
      ),
      // When Media Studio is opened by a media picker, keep the confirm action above the
      // metadata (sticky) so it never sits below a long detail list.
      picking && h('div', { class: 've-media-pick-top' },
        h('button', { class: 've-btn ve-btn-primary', style: 'width:100%;color:#1f1f1f;font-weight:600;display:flex;align-items:center;justify-content:center;gap:6px', onClick: () => insertSelectedMedia() }, ph('check'), 'Use Selected Media')),
      isVideoFile(selected)
        ? h('div', { class: 've-media-video-detail-card' }, renderFilePreview(selected, 'detail:video'))
        : h('div', { ref: detailPreviewRef, class: 've-media-detail-preview ve-scroll-custom ve-preview-mode-' + detailPreviewMode, onMouseDown: startPreviewPan }, renderFilePreview(selected, 'detail:' + detailPreviewMode + ':' + detailPreviewZoom)),
      isImageFile(selected) && h('div', { class: 've-preview-mode-row' },
        [
          { value: 'fit', label: 'Fit' },
          { value: 'fit-width', label: 'Fit width' },
          { value: 'actual', label: 'Actual size' },
          { value: 'zoom', label: 'Pan/zoom' }
        ].map(opt => h('button', {
          key: opt.value,
          type: 'button',
          class: detailPreviewMode === opt.value ? 'active' : '',
          onClick: () => { setDetailPreviewMode(opt.value); persistUserPreference('ve_media_detail_preview_mode', opt.value); }
        }, opt.label))
      ),
      isImageFile(selected) && detailPreviewMode === 'zoom' && h('label', { class: 've-preview-zoom-row' },
        h('span', null, Math.round(detailPreviewZoom * 100) + '%'),
        h('input', {
          type: 'range',
          min: '1',
          max: '4',
          step: '.1',
          value: detailPreviewZoom,
          onInput: e => {
            const next = Math.max(1, Math.min(4, parseFloat(e.target.value || '1') || 1));
            setDetailPreviewZoom(next);
            persistUserPreference('ve_media_detail_preview_zoom', String(next));
          }
        })
      ),
      isImageFile(selected) && detailPreviewMode === 'zoom' && h('div', { style: 'font-size:10px;color:#777;line-height:1.35;margin-top:-2px' }, 'Drag inside the preview or use the scrollbars to pan the enlarged image.'),
      h('div', { style: 'display:flex;flex-direction:column;gap:12px' },
        h('div', { class: 've-media-meta-card' },
          h('div', { class: 've-media-meta-head' },
            h('span', null, 'Metadata'),
            h('em', null, mediaSaveState || 'Ready')
          ),
          h('label', { class: 've-media-meta-field' },
            h('span', null, 'File name / Title'),
            h('div', { class: 've-media-meta-row' },
              h('input', { class: 've-studio-input ve-studio-input-filename', value: filenameDraft, onInput: e => setFilenameDraft(e.target.value), onBlur: requestFilenameSave }),
              h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => handleCopyLink(selected.filename || filenameDraft), title: 'Copy filename' }, ph('copy'))
            )
          ),
          h('label', { class: 've-media-meta-field' },
            h('span', null, 'Alt Text'),
            h('textarea', {
              class: 've-studio-input ve-studio-textarea',
              value: altDraft,
              placeholder: 'Describe this image...',
              onInput: e => setAltDraft(e.target.value),
              onBlur: e => handleAltTextSave(selected.id, e.target.value)
            })
          ),
          h('label', { class: 've-media-meta-field' },
            h('span', null, 'Caption'),
            h('textarea', { class: 've-studio-input ve-studio-textarea ve-studio-textarea-small ve-media-caption-textarea', value: captionDraft, placeholder: 'Optional visible caption...', onInput: e => setCaptionDraft(e.target.value) })
          ),
          h('label', { class: 've-media-meta-field' },
            h('span', null, 'Description'),
            h('textarea', { class: 've-studio-input ve-studio-textarea ve-studio-textarea-small ve-media-description-textarea', value: descriptionDraft, placeholder: 'Optional attachment description...', onInput: e => setDescriptionDraft(e.target.value) })
          ),
          h('div', { class: 've-media-copy-grid' },
            h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => handleCopyLink(selected.source_url) }, ph('copy'), 'Copy URL'),
            h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => handleCopyTag(selected) }, ph('brackets-curly'), 'Copy tag'),
            h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: saveSelectedMetadata }, ph('check'), mediaSaveState === 'Saving metadata…' ? 'Saving…' : 'Save metadata')
          )
        ),
        h('div', { style: 'display:flex;gap:12px;font-size:11px;color:#888' },
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:11px;text-transform:uppercase;margin-bottom:2px' }, 'Dimensions'),
            h('div', { style: 'color:#ccc' }, selected.media_details ? `${selected.media_details.width}x${selected.media_details.height}` : 'N/A')
          ),
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:11px;text-transform:uppercase;margin-bottom:2px' }, 'Size'),
            h('div', { style: 'color:#ccc' }, formatSize(getFileSize(selected)))
          ),
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:11px;text-transform:uppercase;margin-bottom:2px' }, 'File type'),
            h('div', { style: 'color:#ccc' }, fileExt(selected))
          )
        ),
        h('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:11px;color:#888' },
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:11px;text-transform:uppercase;margin-bottom:2px' }, 'Uploaded by'),
            h('div', { style: 'color:#ccc;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, authorLabel(selected))
          ),
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:11px;text-transform:uppercase;margin-bottom:2px' }, 'Uploaded on'),
            h('div', { style: 'color:#ccc' }, selected.date ? new Date(selected.date).toLocaleDateString() : 'Unknown')
          )
        ),
        h('div', { class: 've-media-usage-card' },
          h('div', { class: 've-media-usage-head' },
            h('div', { class: 've-media-usage-title' }, ph('tree-structure'), 'Usage & replace impact'),
            h('span', { class: 've-media-usage-count' }, mediaUsageLoading ? 'Scanning' : `${mediaUsage?.total || 0} use${(mediaUsage?.total || 0) === 1 ? '' : 's'}`)
          ),
          mediaUsageError
            ? h('div', { class: 've-media-usage-empty' }, mediaUsageError)
            : mediaUsageLoading
              ? h('div', { class: 've-media-usage-empty' }, 'Checking featured images, post content, saved builder data, post meta, and options…')
              : mediaUsage?.unused
                ? h('div', { class: 've-media-usage-empty' }, 'Unused in the places MV can scan. Replace is low impact, but custom code or remote CSS may still reference the file URL.')
                : h('div', { class: 've-media-usage-list ve-scroll-custom' },
                  Object.keys(mediaUsage?.groups || {}).reduce((rows, group) => rows.concat((mediaUsage.groups[group] || []).map((row, idx) => {
                    const content = [
                      h('span', { key: 'label' }, row.label || row.id || group),
                      h('em', { key: 'meta' }, (row.source || group) + (row.detail ? ' · ' + row.detail : ''))
                    ];
                    return row.edit
                      ? h('a', { key: group + '-' + idx, class: 've-media-usage-row', href: row.edit, target: '_blank', rel: 'noreferrer' }, content)
                      : h('div', { key: group + '-' + idx, class: 've-media-usage-row' }, content);
                  })), [])
                ),
          mediaUsage?.limited && h('div', { class: 've-media-usage-empty' }, 'Usage list is capped for performance. Counts show the visible scan result.'),
          !mediaUsageLoading && !mediaUsageError && h('div', { class: 've-media-usage-help' }, (mediaUsage?.total || 0) ? 'Use this before replacing or deleting. MV shows the places it can safely detect, so used assets are easier to review first.' : 'No safe usage detected. Custom PHP/CSS/CDN references may still exist.')
        ),
        collKeys.length > 0 && h('div', null,
          h('div', { style: 'font-size:11px;color:#555;text-transform:uppercase;font-weight:700;margin-bottom:6px' }, 'Collections'),
          h('div', { class: 've-chip-list', style: 'font-size:11px' },
            collKeys.filter(key => collIds(key).includes(selected.id)).sort((a, b) => collectionDepth(b) - collectionDepth(a)).map(key => {
              const ids = collIds(key);
              return h('div', { key, class: 've-chip-row' },
                h('span', { style: 'display:flex;align-items:center;gap:6px;min-width:0' }, h('span', { style: 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, collectionLeafLabel(key))),
                h('button', { class: 've-chip-remove', title: 'Remove from collection', onClick: () => toggleCollectionItem(key, selected.id, false) }, ph('x'))
              );
            }),
            !collKeys.some(key => collIds(key).includes(selected.id)) && h('div', { class: 've-empty', style: 'padding:8px 0;text-align:left' }, 'Not in any collection yet.')
          ),
          h('div', { class: 've-chip-action-row' },
            h('button', { class: 've-btn ve-btn-g ve-btn-s ve-replace-wide', type: 'button', onClick: () => { setCheckedItems([selected.id]); setPendingBatchCollection(true); } }, ph('plus'), 'Add to collection')
          )
        ),
        (() => {
          const historyRows = Array.isArray(selected.action_history) && selected.action_history.length ? selected.action_history : (Array.isArray(selected.replace_history) ? selected.replace_history : []);
          return historyRows.length > 0 && h('div', { class: 've-replace-history-card' },
            h('div', { class: 've-media-usage-head' },
              h('div', { class: 've-media-usage-title' }, ph('arrows-clockwise'), 'Change history'),
              h('span', { class: 've-media-usage-count' }, historyRows.length + ' event' + (historyRows.length === 1 ? '' : 's'))
            ),
            h('div', { class: 've-replace-history-list ve-scroll-custom' }, historyRows.map((row, idx) => {
              const action = row.action ? String(row.action) : 'replace';
              const before = row.old_file || row.old_title || 'Previous';
              const after = row.new_file || row.new_title || 'Current';
              return h('div', { class: 've-replace-history-row', key: row.rollback_id || idx },
                h('span', null, action.charAt(0).toUpperCase() + action.slice(1) + ' · ' + (row.at || 'Unknown time')),
                h('em', null, before + ' → ' + after),
                row.rollback_id && action !== 'rollback' && h('button', { type: 'button', class: 've-history-restore-btn', onClick: () => rollbackMediaAction(row), title: 'Restore this version' }, ph('arrows-counter-clockwise'), 'Restore')
              );
            }))
          );
        })(),
        h('div', null,
          h('div', { style: 'font-size:11px;color:#555;text-transform:uppercase;font-weight:700;margin-bottom:6px' }, 'Asset Actions'),
          h('input', { type: 'file', ref: replaceInputRef, style: 'display:none', onChange: e => handleReplaceFile(e.target.files) }),
          h('div', { class: 've-media-actions-card' },
            h('button', { class: 've-btn ve-btn-g ve-btn-s ve-replace-wide', onClick: () => replaceInputRef.current?.click(), title: 'Upload a new file while keeping this attachment ID, alt text, title, and references.' }, ph('arrows-clockwise'), 'Replace File'),
            isImageFile(selected) && h('div', { class: 've-convert-card' },
              h('div', { class: 've-convert-card-title' }, 'Convert file type'),
              h(SelectMenu, { className: 've-filter-menu ve-convert-menu', value: convertFormat, onChange: setConvertFormat, options: [
                { value: 'webp', label: 'WEBP' },
                { value: 'avif', label: 'AVIF' },
                { value: 'jpeg', label: 'JPEG' },
                { value: 'png', label: 'PNG' }
              ] }),
              h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: convertSelected, disabled: convertingId === selected.id, title: 'Create a converted copy in the selected format and keep this asset selected.' }, ph('file-arrow-down'), convertingId === selected.id ? 'Converting...' : 'Convert to ' + convertFormat.toUpperCase())
            ),
            h('button', { class: 've-btn ve-btn-g ve-btn-s ve-replace-wide', type: 'button', onClick: () => downloadMediaUrl(selected) }, ph('download-simple'), 'Download file')
          )
        )
      ),
      h('div', { style: 'display:flex;flex-direction:column;gap:8px;margin-top:auto;border-top:1px solid rgba(255,255,255,0.06);padding-top:12px' },
        !picking && h('button', {
          class: 've-btn ve-btn-primary',
          style: 'color:#1f1f1f;font-weight:600;display:flex;align-items:center;justify-content:center;gap:6px',
          onClick: () => insertSelectedMedia()
        }, ph('check'), 'Insert Media URL'),
        h('button', {
          class: 've-btn ve-btn-g',
          style: 'display:flex;align-items:center;justify-content:center;gap:6px',
          onClick: () => handleCopyTag(selected)
        }, ph('copy'), 'Copy HTML Tag'),
        h('button', {
          class: 've-btn',
          style: 'background:rgba(255,77,77,0.1);color:#ff4d4d;border:1px solid rgba(239,68,68,0.55);display:flex;align-items:center;justify-content:center;gap:6px',
          onClick: () => handleDelete(selected)
        }, ph('trash'), 'Delete Permanently')
      )
    ),
    !selected && isLocalCollectionOpen() && (() => {
      const key = selectedColl;
      const entry = collectionMap[key] || {};
      const ids = collIds(key).map(Number);
      const collectionItems = items.filter(item => ids.includes(Number(item.id)));
      const size = collectionItems.reduce((sum, item) => sum + getFileSize(item), 0);
      const shortcode = '[mv_media_collection collection="' + key + '"]';
      const locked = !!entry.locked;
      const starred = !!entry.starred;
      const color = collectionColor(key);
      return h('div', { key: 'collection-sidecar-' + key, class: 've-studio-details-sidebar ve-collection-details-sidebar ve-scroll-custom' },
        h('div', { class: 've-details-head' },
          h('span', { style: 'font-weight:700;color:#fff' }, 'Collection Details'),
          h('button', { class: 've-a', style: 'width:24px;height:24px;display:flex;align-items:center;justify-content:center', onClick: () => setSelectedColl('all'), title: 'Close collection details' }, ph('x'))
        ),
        h('div', { class: 've-collection-detail-hero', style: color ? { '--ve-collection-accent': color } : undefined },
          h('div', { class: 've-collection-detail-icon' }, ph(collIcon(key))),
          h('div', { class: 've-collection-detail-title' },
            h('strong', null, collLabel(key)),
            h('span', null, collectionItems.length + ' media file' + (collectionItems.length === 1 ? '' : 's') + ' · ' + formatSize(size))
          )
        ),
        h('div', { class: 've-collection-status-grid' },
          h('span', null, ph(starred ? 'star' : 'star'), 'Starred', h('b', null, starred ? 'Yes' : 'No')),
          h('span', null, ph(locked ? 'lock-simple' : 'lock-open'), 'Lock', h('b', null, locked ? 'Locked' : 'Open')),
          h('span', null, ph('palette'), 'Color', h('b', null, color || 'Default'))
        ),
        h('div', { class: 've-collection-shortcode-block' },
          h('div', { class: 've-collection-shortcode-label' }, ph('brackets-curly'), 'Shortcode'),
          h('div', { class: 've-collection-shortcode-row' },
            h('input', { class: 've-studio-input', value: shortcode, readOnly: true, onFocus: e => e.target.select() }),
            h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { navigator.clipboard?.writeText(shortcode); flash('Copied collection shortcode.'); } }, ph('copy'))
          )
        ),
        h('div', { class: 've-collection-action-grid' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', disabled: locked, onClick: () => beginRenameCollection(key) }, ph('pencil-simple'), 'Rename'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', disabled: locked, onClick: () => beginChildCollection(key) }, ph('tree-structure'), 'Subfolder'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { persistCollections({ ...collectionMap, [key]: { ...entry, starred: !starred } }); flash(starred ? 'Removed from Starred.' : 'Pinned to Starred.'); } }, ph('star'), starred ? 'Unstar' : 'Star'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: event => openCollectionColorPicker(key, event) }, ph('palette'), color ? 'Color' : 'Set color'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => downloadCollectionZip(key) }, ph('download-simple'), 'Download ZIP'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', disabled: locked, onClick: () => chooseZipForCollection(key) }, ph('file-arrow-down'), 'Import ZIP')
        ),
        h('div', { class: 've-collection-preview-list' },
          collectionItems.slice(0, 6).map(item => h('button', { type: 'button', key: item.id, onClick: () => setSelected(item) }, renderFilePreview(item, 'list'), h('span', null, item.title?.rendered || item.filename || 'Untitled'))),
          !collectionItems.length && h('div', { class: 've-empty', style: 'padding:12px;text-align:left' }, 'No media in this collection yet.')
        )
      );
    })()
  );
}
function FontManagerStudio({flash}){
  const[tab,setTab]=useState('library');
  const[data,setData]=useState({families:[],available:true,can_manage:true,bricks_url:''});
  const[loading,setLoading]=useState(true);
  const[status,setStatus]=useState('');
  const[query,setQuery]=useState('');
  const[queue,setQueue]=useState([]);
  const[busy,setBusy]=useState(false);
  const[dragging,setDragging]=useState(false);
  const[editing,setEditing]=useState(null);
  const[confirmDelete,setConfirmDelete]=useState(null);
  const[importTarget,setImportTarget]=useState(null);
  // Broken-variant recovery: which variant is being relinked, and the ranked
  // media-library candidates MV found for it.
  const[relink,setRelink]=useState(null);
  const[relinkList,setRelinkList]=useState(null);
  const[relinkAllState,setRelinkAllState]=useState(null);
  const inputRef=useRef(null);
  const fontPreviewFamily=family=>'"VEBricksFont'+Number(family.id||0)+'"';

  const load=useCallback(async()=>{
    setLoading(true);
    const result=await api.g('font-manager/families');
    if(result?.code){
      setData({families:[],available:result.available!==false,can_manage:false,bricks_url:result.bricks_url||''});
      setStatus(result.message||'Bricks fonts could not be loaded.');
    }else{
      setData(result||{families:[]});
      setStatus('');
    }
    setLoading(false);
  },[]);
  useEffect(()=>{load();},[load]);
  useEffect(()=>()=>queue.forEach(item=>{if(item.previewUrl)URL.revokeObjectURL(item.previewUrl);}),[]);

  const inspectFiles=async fileList=>{
    const files=Array.from(fileList||[]).filter(file=>/\.(ttf|otf|woff2?|)$/i.test(file.name||'')&&/\.(ttf|otf|woff2?)$/i.test(file.name||''));
    if(!files.length){setStatus('Choose TTF, OTF, WOFF, or WOFF2 font files.');return;}
    setBusy(true);setStatus('Reading font metadata…');
    try{
      const tools=await ensureFontToolsRuntime();
      await tools.woff2.init(CFG.fontToolsWasm);
      const inspected=[];
      for(const file of files){
        const ext=(file.name.split('.').pop()||'').toLowerCase();
        const buffer=await file.arrayBuffer();
        const font=tools.createFont(buffer,{type:ext,hinting:true,kerning:true});
        const fontData=font.get()||{};
        const family=fontNameText(fontData.name?.fontFamily)||fontNameText(fontData.name?.fullName)||file.name.replace(/\.[^.]+$/,'');
        const weight=Math.max(1,Math.min(1000,Number(fontData['OS/2']?.usWeightClass)||400));
        const italic=Number(fontData.post?.italicAngle||0)!==0||!!(Number(fontData['OS/2']?.fsSelection||0)&1);
        const output=ext==='woff2'?buffer:font.write({type:'woff2',toBuffer:false});
        const blob=new Blob([output],{type:'font/woff2'});
        inspected.push({
          id:Date.now()+'-'+Math.random().toString(36).slice(2),
          sourceName:file.name,
          family:importTarget?.family||family,
          familyId:importTarget?.id||0,
          weight,
          style:italic?'italic':'normal',
          blob,
          previewUrl:URL.createObjectURL(blob),
          sourceFormat:ext.toUpperCase(),
          size:blob.size,
          replace:false
        });
      }
      setQueue(current=>[...current,...inspected]);
      setStatus(inspected.length+' font '+(inspected.length===1?'file':'files')+' ready to import.');
      setTab('import');
    }catch(error){setStatus(error?.message||'The font files could not be read.');}
    finally{setBusy(false);if(inputRef.current)inputRef.current.value='';}
  };
  const updateQueue=(id,key,value)=>setQueue(current=>current.map(item=>item.id===id?{...item,[key]:value}:item));
  const removeQueue=id=>setQueue(current=>{
    const removed=current.find(item=>item.id===id);
    if(removed?.previewUrl)URL.revokeObjectURL(removed.previewUrl);
    return current.filter(item=>item.id!==id);
  });
  const importFonts=async()=>{
    if(!queue.length)return;
    setBusy(true);setStatus('');
    let imported=0;
    for(const item of queue){
      const form=new FormData();
      form.append('font_file',item.blob,item.sourceName.replace(/\.[^.]+$/,'.woff2'));
      form.append('family',item.family);
      form.append('family_id',String(item.familyId||0));
      form.append('weight',String(item.weight));
      form.append('style',item.style);
      form.append('replace',item.replace?'1':'0');
      const result=await api.f('variable-engine/v1/font-manager/families',{method:'POST',body:form});
      if(result?.code){
        setStatus(result.message||'A font could not be imported.');
        setBusy(false);
        return;
      }
      imported++;
    }
    queue.forEach(item=>item.previewUrl&&URL.revokeObjectURL(item.previewUrl));
    setQueue([]);setImportTarget(null);setStatus(imported+' font '+(imported===1?'variant':'variants')+' imported into Bricks.');
    await load();setTab('library');setBusy(false);
  };
  const saveFamily=async()=>{
    if(!editing)return;
    setBusy(true);
    const result=await api.u('font-manager/families/'+editing.id,{
      family:editing.family,
      rename_from:editing.renameFrom||'',
      weight:editing.weight,
      style:editing.style
    });
    if(result?.code)setStatus(result.message||'The Bricks font could not be updated.');
    else{setStatus('Bricks font updated.');setEditing(null);await load();}
    setBusy(false);
  };
  const removeVariant=async target=>{
    if(!target)return;
    setBusy(true);
    const result=await api.d('font-manager/families/'+target.id+'/variants/'+encodeURIComponent(target.variantKey));
    setStatus(result?.code?(result.message||'Variant could not be removed.'):'Variant removed from Bricks. The Media Library file was retained.');
    if(!result?.code){setConfirmDelete(null);await load();}
    setBusy(false);
  };
  const deleteFamily=async()=>{
    if(!confirmDelete)return;
    setBusy(true);
    const result=await api.d('font-manager/families/'+confirmDelete.id);
    setStatus(result?.message||'Font family moved to Trash.');
    if(!result?.code){setConfirmDelete(null);await load();}
    setBusy(false);
  };
  // Open the relink drawer for a broken variant and fetch ranked candidates.
  const openRelink=async(family,variant)=>{
    const expected=(variant.files||[]).map(file=>file.name).filter(Boolean)[0]||'';
    setRelink({id:family.id,family:family.family,variantKey:variant.key,weight:variant.weight,style:variant.style,expected});
    setRelinkList(null);
    const result=await api.g('font-manager/relink-candidates?family='+encodeURIComponent(family.family)
      +'&expected='+encodeURIComponent(expected)
      +'&weight='+encodeURIComponent(variant.weight||0)
      +'&style='+encodeURIComponent(variant.style||'normal'));
    setRelinkList(Array.isArray(result?.candidates)?result.candidates:[]);
  };
  // Manual escape hatch: open the WP media picker and relink to whatever is chosen.
  const browseForFont=()=>{
    // Prefer Media Studio; only fall back to the WordPress library if the bridge is absent.
    // Filter to font files — this picker can only ever relink a font.
    const open=window.veOpenMediaPicker
      ? opts=>window.veOpenMediaPicker(opts,'font')
      : (window.wp&&window.wp.media);
    if(!open){setStatus('No media picker is available on this screen.');return;}
    const frame=open({title:'Choose a font file',button:{text:'Use this file'},multiple:false});
    if(!frame){setStatus('The media picker could not be opened.');return;}
    frame.on('select',()=>{
      const item=frame.state().get('selection').first();
      if(!item)return;
      const attributes=item.toJSON()||{};
      const name=String(attributes.filename||attributes.title||'font file');
      const extension=(name.split('.').pop()||'').toLowerCase();
      applyRelink({
        attachment_id:Number(attributes.id),
        name:name,
        format:extension==='ttf'?'truetype':(extension==='otf'?'opentype':extension)
      });
    });
    frame.open();
  };
  const applyRelink=async candidate=>{
    if(!relink||!candidate)return;
    setBusy(true);
    const result=await api.p('font-manager/relink',{id:relink.id,variant:relink.variantKey,attachment_id:candidate.attachment_id,format:candidate.format});
    if(result?.code){setStatus(result.message||'That variant could not be relinked.');}
    else{setStatus('Relinked to '+candidate.name+'.');setRelink(null);setRelinkList(null);await load();}
    setBusy(false);
  };
  // Relink every broken variant in a family that has a confident (>=70) match.
  const relinkAll=async family=>{
    const broken=(family.variants||[]).filter(variant=>!(variant.files||[]).some(file=>file.url));
    if(!broken.length)return;
    setBusy(true);
    // Progress must be visible where the user clicked — the footer status alone is
    // offscreen in a long family list.
    setRelinkAllState({id:family.id,done:0,total:broken.length});
    setStatus('Scanning the media library for '+broken.length+' variants…');
    let fixed=0,skipped=0,step=0;
    for(const variant of broken){
      step++;
      setRelinkAllState({id:family.id,done:step,total:broken.length});
      const expected=(variant.files||[]).map(file=>file.name).filter(Boolean)[0]||'';
      const result=await api.g('font-manager/relink-candidates?family='+encodeURIComponent(family.family)
        +'&expected='+encodeURIComponent(expected)
        +'&weight='+encodeURIComponent(variant.weight||0)
        +'&style='+encodeURIComponent(variant.style||'normal'));
      const best=(result?.candidates||[]).filter(candidate=>Number(candidate.score||0)>=70)[0];
      if(!best){skipped++;continue;}
      const applied=await api.p('font-manager/relink',{id:family.id,variant:variant.key,attachment_id:best.attachment_id,format:best.format});
      if(applied?.code)skipped++;else fixed++;
    }
    const summary=fixed
      ?('Relinked '+fixed+' variant'+(fixed===1?'':'s')+(skipped?' · '+skipped+' still need a file':'')+'.')
      :('No matching font files found in the media library for '+broken.length+' variant'+(broken.length===1?'':'s')+' — re-upload them with “Add variant”, or remove them.');
    setStatus(summary);
    if(typeof flash==='function')flash(summary);
    setRelinkAllState(null);
    setRelink(null);setRelinkList(null);
    await load();
    setBusy(false);
  };
  const openAddVariants=family=>{setImportTarget({id:family.id,family:family.family});setTab('import');setStatus('New variants will be added to '+family.family+'.');};
  const returnToLibrary=()=>{setTab('library');setImportTarget(null);setStatus('');};
  const filtered=(data.families||[]).filter(family=>family.family.toLowerCase().includes(query.trim().toLowerCase()));
  const styleRules=(data.families||[]).flatMap(family=>family.variants.map(variant=>{
    const sources=variant.files.filter(file=>file.url).map(file=>'url("'+String(file.url).replace(/"/g,'%22')+'") format("'+file.format+'")');
    return sources.length?'@font-face{font-family:'+fontPreviewFamily(family)+';font-weight:'+variant.weight+';font-style:'+variant.style+';font-display:swap;src:'+sources.join(',')+'}':'';
  })).filter(Boolean).join('');

  return h('div',{class:'ve-font-manager'},
    styleRules&&h('style',null,styleRules),
    h('div',{class:'ve-font-tabs'},
      h('button',{type:'button',class:'ve-font-tab'+(tab==='library'?' on':''),onClick:returnToLibrary},'Library'),
      h('button',{type:'button',class:'ve-font-tab'+(tab==='import'?' on':''),onClick:()=>{setImportTarget(null);setTab('import');setStatus('');}},'Import')
    ),
    tab==='library'?h(Fragment,null,
      h('div',{class:'ve-font-toolbar'},
        h('input',{class:'ve-studio-input',value:query,placeholder:'Search font families',onInput:e=>setQuery(e.target.value)})
      ),
      loading?h('div',{class:'ve-font-empty'},'Loading Bricks fonts…')
      :!data.available?h('div',{class:'ve-font-empty'},h('strong',null,'Bricks Custom Fonts is unavailable.'),h('span',null,'Activate Bricks to use this adapter.'))
      :!filtered.length?h('div',{class:'ve-font-empty'},h('strong',null,query?'No matching font families.':'No Bricks fonts yet.'),h('span',null,query?'Try another search.':'Import a font here or add one in Bricks Font Manager.'))
      :h('div',{class:'ve-font-family-list'},filtered.map(family=>{
        const availableVariant=family.variants.find(variant=>variant.files.some(file=>file.url));
        const previewVariant=availableVariant||family.variants[0]||{weight:400,style:'normal'};
        const hasPreview=!!availableVariant;
        const previewFamily=fontPreviewFamily(family);
        return h('article',{class:'ve-font-family-card',key:family.id},
        h('div',{class:'ve-font-family-head'},
          h('div',null,h('strong',{style:hasPreview?{fontFamily:previewFamily}:undefined},family.family),h('span',null,family.variants.length+' '+(family.variants.length===1?'variant':'variants')+' · Bricks')),
          h('div',{class:'ve-font-card-actions'},
            h('button',{type:'button','aria-label':'Edit '+family.family,onClick:()=>setEditing({id:family.id,family:family.family})},ph('pencil-simple')),
            h('button',{type:'button','aria-label':'Delete '+family.family,onClick:()=>setConfirmDelete({...family,kind:'family'})},ph('trash'))
          )
        ),
        hasPreview
          ?h('div',{class:'ve-font-family-preview',style:{fontFamily:previewFamily,fontWeight:String(previewVariant.weight),fontStyle:previewVariant.style}},'Design systems stay in sync.')
          :h('div',{class:'ve-font-family-preview is-unavailable'},ph('warning'),'Bricks family found · source attachments need relinking'),
        // Relink all must stay reachable while ANY variant is still broken — it used to
        // live inside the "no preview" branch, so it vanished as soon as one was fixed.
        (()=>{const brokenCount=(family.variants||[]).filter(variant=>!(variant.files||[]).some(file=>file.url)).length;
          return brokenCount?h('div',{class:'ve-font-relink-strip'},
            ph('warning'),
            h('span',null,brokenCount+' variant'+(brokenCount===1?'':'s')+' still need'+(brokenCount===1?'s':'')+' a font file'),
            h('button',{type:'button',class:'ve-font-relink-all'+(relinkAllState&&relinkAllState.id===family.id?' is-working':''),disabled:busy,onClick:()=>relinkAll(family)},
              ph('link'),
              relinkAllState&&relinkAllState.id===family.id
                ?('Scanning '+relinkAllState.done+'/'+relinkAllState.total+'…')
                :'Relink all')
          ):null;})(),
        family.variants.map(variant=>{
          const availableFiles=variant.files.filter(file=>file.url);
          const missingFiles=variant.files.filter(file=>!file.url);
          const relinkOpen=relink&&relink.id===family.id&&relink.variantKey===variant.key;
          return h(Fragment,{key:variant.key},
          relinkOpen&&h('div',{class:'ve-font-relink-panel'},
            h('div',{class:'ve-font-relink-head'},
              h('strong',null,'Relink '+fontWeightLabel(variant.weight)+(variant.style!=='normal'?' · '+variant.style:'')),
              h('button',{type:'button','aria-label':'Cancel relink',onClick:()=>{setRelink(null);setRelinkList(null);}},ph('x'))
            ),
            relink.expected?h('p',{class:'ve-font-relink-looking'},'Looking for ',h('b',null,relink.expected)):null,
            relinkList===null
              ?h('div',{class:'ve-font-relink-empty'},'Scanning the media library…')
              :(relinkList.length
                  ?relinkList.map(candidate=>h('button',{type:'button',class:'ve-font-relink-cand'+(candidate.score>=100?' is-best':''),key:candidate.attachment_id,disabled:busy,onClick:()=>applyRelink(candidate)},
                      h('span',{class:'ve-font-relink-ic'},ph('file')),
                      h('span',{class:'ve-font-relink-meta'},
                        h('strong',null,candidate.name),
                        h('span',null,'#'+candidate.attachment_id+(candidate.uploaded?' · '+candidate.uploaded:'')+(candidate.size?' · '+Math.round(candidate.size/1024)+' KB':''))
                      ),
                      h('em',{class:'ve-font-relink-score'},candidate.reason)
                    ))
                  :h('div',{class:'ve-font-relink-empty'},'No automatic match found — pick the file yourself, or re-upload it with “Add variant”.')
              ),
            h('div',{class:'ve-font-relink-foot'},
              h('button',{type:'button',class:'ve-font-relink-browse',disabled:busy,onClick:()=>browseForFont()},ph('folder-open'),'Browse media library')
            )
          ),
          h('div',{class:'ve-font-variant-row'+(availableFiles.length?'':' is-missing'),style:{fontFamily:previewFamily,fontWeight:String(variant.weight),fontStyle:variant.style}},
          h('div',null,h('strong',null,fontWeightLabel(variant.weight)+(variant.style!=='normal'?' · '+variant.style:'')),h('span',null,availableFiles.map(file=>file.name).join(', ')||(missingFiles.length?'Bricks attachment missing · relink this variant':'No font file assigned'))),
          h('div',{class:'ve-font-variant-actions'},
            h('span',null,variant.files.reduce((sum,file)=>sum+Number(file.size||0),0)?Math.round(variant.files.reduce((sum,file)=>sum+Number(file.size||0),0)/1024)+' KB':''),
            !availableFiles.length&&h('button',{type:'button',class:'ve-font-relink','aria-label':'Relink variant',onClick:()=>openRelink(family,variant)},ph('link'),'Relink'),
            h('button',{type:'button','aria-label':'Edit variant',onClick:()=>setEditing({id:family.id,family:family.family,renameFrom:variant.key,weight:variant.weight,style:variant.style})},ph('pencil-simple')),
            h('button',{type:'button','aria-label':'Remove variant',onClick:()=>setConfirmDelete({kind:'variant',id:family.id,family:family.family,variantKey:variant.key,variantLabel:fontWeightLabel(variant.weight)+(variant.style!=='normal'?' · '+variant.style:'')})},ph('trash'))
          )
        ))}),
        h('button',{type:'button',class:'ve-font-add-variant',onClick:()=>openAddVariants(family)},ph('plus'),'Add variant')
      )})),
      h('div',{class:'ve-font-source-note'},ph('check-circle'),'Editing Bricks Custom Fonts directly')
    ):h(Fragment,null,
      h('div',{class:'ve-font-import-head'},
        h('button',{type:'button',class:'ve-font-back',onClick:returnToLibrary},ph('arrow-left'),'Back to library'),
        h('span',null,importTarget?'Adding variants to '+importTarget.family:'Import a Bricks font family')
      ),
      h('div',{class:'ve-font-drop'+(dragging?' is-dragging':''),
        onDragOver:e=>{e.preventDefault();setDragging(true);},
        onDragLeave:()=>setDragging(false),
        onDrop:e=>{e.preventDefault();setDragging(false);inspectFiles(e.dataTransfer.files);}
      },
        h('strong',null,importTarget?'Add variants to '+importTarget.family:'Drop TTF, OTF, WOFF, or WOFF2 files'),
        h('span',null,'Desktop font files are converted to WOFF2 in your browser before upload.'),
        h('button',{type:'button',class:'ve-btn ve-btn-s',disabled:busy,onClick:()=>inputRef.current?.click()},busy?'Reading…':'Choose files'),
        h('input',{ref:inputRef,type:'file',multiple:true,accept:'.ttf,.otf,.woff,.woff2',hidden:true,onChange:e=>inspectFiles(e.target.files)})
      ),
      queue.length?h('div',{class:'ve-font-queue'},queue.map(item=>h('article',{class:'ve-font-queue-row',key:item.id},
        h('div',{class:'ve-font-file-badge'},item.sourceFormat),
        h('div',{class:'ve-font-queue-main'},
          h('input',{class:'ve-studio-input',value:item.family,'aria-label':'Font family',onInput:e=>updateQueue(item.id,'family',e.target.value)}),
          h('div',{class:'ve-font-queue-fields'},
            h(SelectMenu,{value:String(item.weight),onChange:value=>updateQueue(item.id,'weight',Number(value)),options:[100,200,300,400,500,600,700,800,900].map(value=>({value:String(value),label:fontWeightLabel(value)}))}),
            h(SelectMenu,{value:item.style,onChange:value=>updateQueue(item.id,'style',value),options:[{value:'normal',label:'Normal'},{value:'italic',label:'Italic'},{value:'oblique',label:'Oblique'}]})
          ),
          h('div',{class:'ve-font-queue-preview',style:{fontFamily:'"VEQueue'+item.id+'"'}},
            h('style',null,'@font-face{font-family:"VEQueue'+item.id+'";src:url("'+item.previewUrl+'") format("woff2");font-weight:'+item.weight+';font-style:'+item.style+'}'),
            'The quick brown fox jumps.'
          ),
          h('span',{class:'ve-font-file-meta'},item.sourceName+' → WOFF2 · '+Math.round(item.size/1024)+' KB')
        ),
        h('button',{class:'ve-font-remove-file',type:'button','aria-label':'Remove '+item.sourceName,onClick:()=>removeQueue(item.id)},ph('x'))
      ))):h('div',{class:'ve-font-empty ve-font-empty-compact'},'No font files queued.'),
      queue.length>0&&h('div',{class:'ve-font-import-actions'},
        h('button',{class:'ve-btn ve-btn-g',disabled:busy,onClick:()=>{queue.forEach(item=>item.previewUrl&&URL.revokeObjectURL(item.previewUrl));setQueue([]);}},'Clear'),
        h('button',{class:'ve-btn',disabled:busy||queue.some(item=>!item.family.trim()),onClick:importFonts},busy?'Importing…':'Import '+queue.length)
      )
    ),
    status&&h('div',{class:'ve-font-status'},status),
    editing&&h('div',{class:'ve-font-editor'},
      h('div',{class:'ve-font-editor-head'},h('strong',null,editing.renameFrom?'Edit variant':'Edit family'),h('button',{type:'button',onClick:()=>setEditing(null)},ph('x'))),
      h('label',null,'Family name',h('input',{class:'ve-studio-input',value:editing.family,onInput:e=>setEditing({...editing,family:e.target.value})})),
      editing.renameFrom&&h('div',{class:'ve-font-queue-fields'},
        h(SelectMenu,{value:String(editing.weight),onChange:value=>setEditing({...editing,weight:Number(value)}),options:[100,200,300,400,500,600,700,800,900].map(value=>({value:String(value),label:fontWeightLabel(value)}))}),
        h(SelectMenu,{value:editing.style,onChange:value=>setEditing({...editing,style:value}),options:[{value:'normal',label:'Normal'},{value:'italic',label:'Italic'},{value:'oblique',label:'Oblique'}]})
      ),
      h('div',{class:'ve-font-editor-actions'},h('button',{class:'ve-btn ve-btn-g',onClick:()=>setEditing(null)},'Cancel'),h('button',{class:'ve-btn',disabled:busy||!editing.family.trim(),onClick:saveFamily},busy?'Saving…':'Save'))
    ),
    confirmDelete&&h('div',{class:'ve-font-confirm'},
      h('strong',null,confirmDelete.kind==='variant'?'Remove '+confirmDelete.variantLabel+' from '+confirmDelete.family+'?':'Move '+confirmDelete.family+' to Trash?'),
      h('span',null,confirmDelete.kind==='variant'?'The variant will be removed from Bricks. Its Media Library font file will be kept for recovery.':'Bricks can restore the family. Its Media Library font files will be kept.'),
      h('div',null,
        h('button',{class:'ve-btn ve-btn-g',onClick:()=>setConfirmDelete(null)},'Cancel'),
        h('button',{class:'ve-btn ve-btn-danger',disabled:busy,onClick:()=>confirmDelete.kind==='variant'?removeVariant(confirmDelete):deleteFamily()},busy?(confirmDelete.kind==='variant'?'Removing…':'Moving…'):(confirmDelete.kind==='variant'?'Remove variant':'Move to Trash'))
      )
    )
  );
}
function PluginStudioSub({ flash }) {
  const [plugins, setPlugins] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [pending, setPending] = useState(null);
  const [directoryQuery, setDirectoryQuery] = useState('');
  const [directoryResults, setDirectoryResults] = useState([]);
  const [directoryLoading, setDirectoryLoading] = useState(false);
  const [directoryMode, setDirectoryMode] = useState(false);
  const [directoryView, setDirectoryView] = useState(() => localStorage.getItem('ve_plugin_directory_view') || 'list');
  const uploadRef = useRef(null);

  const loadPlugins = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.g('plugin-studio/plugins');
      setPlugins(Array.isArray(res?.plugins) ? res.plugins : []);
    } catch (e) {
      setPlugins([]);
    }
    setLoading(false);
  }, []);

  useEffect(() => { loadPlugins(); }, [loadPlugins]);

  const runPluginAction = async (plugin, action) => {
    setPending(plugin.slug + ':' + action);
    try {
      const res = await api.p('plugin-studio/action', { plugin: plugin.file, action });
      if (res && res.success) {
        flash(res.message || 'Plugin updated.');
        await loadPlugins();
      } else {
        flash(res?.message || 'Plugin action failed.');
      }
    } catch (e) {
      flash('Plugin action failed.');
    }
    setPending(null);
  };

  const searchDirectory = async (query) => {
    const q = (typeof query === 'string' ? query : directoryQuery).trim();
    setDirectoryMode(true);
    setDirectoryLoading(true);
    try {
      const res = await api.g('plugin-studio/directory?search=' + encodeURIComponent(q));
      setDirectoryResults(Array.isArray(res?.plugins) ? res.plugins : []);
    } catch (e) {
      setDirectoryResults([]);
      flash('Directory search failed.');
    }
    setDirectoryLoading(false);
  };

  useEffect(() => {
    if (!directoryMode) return;
    const t = setTimeout(() => searchDirectory(directoryQuery), 320);
    return () => clearTimeout(t);
  }, [directoryMode, directoryQuery]);

  const installDirectoryPlugin = async slug => {
    setPending(slug + ':install');
    try {
      const res = await api.p('plugin-studio/install', { slug });
      flash(res?.message || (res?.success ? 'Plugin installed.' : 'Install failed.'));
      if (res?.success) await loadPlugins();
    } catch (e) {
      flash('Install failed.');
    }
    setPending(null);
  };

  const uploadPluginZip = async file => {
    if (!file) return;
    const fd = new FormData();
    fd.append('plugin_zip', file);
    setPending('upload:plugin');
    try {
      const res = await api.f('variable-engine/v1/plugin-studio/upload', { method: 'POST', body: fd });
      flash(res?.message || (res?.success ? 'Plugin uploaded.' : 'Upload failed.'));
      if (res?.success) await loadPlugins();
    } catch (e) {
      flash('Plugin upload failed.');
    }
    if (uploadRef.current) uploadRef.current.value = '';
    setPending(null);
  };

  const filteredPlugins = useMemo(() => {
    const q = search.toLowerCase().trim();
    return plugins.filter(p => {
      if (status === 'active' && !p.active) return false;
      if (status === 'inactive' && p.active) return false;
      if (status === 'updates' && !p.update_available) return false;
      if (!q) return true;
      return (p.name || '').toLowerCase().includes(q) || (p.description || '').toLowerCase().includes(q) || (p.author || '').toLowerCase().includes(q);
    });
  }, [plugins, search, status]);

  const counts = useMemo(() => ({
    all: plugins.length,
    active: plugins.filter(p => p.active).length,
    inactive: plugins.filter(p => !p.active).length,
    updates: plugins.filter(p => p.update_available).length
  }), [plugins]);

  const directoryIcon = item => {
    const icons = item.icons || {};
    return icons['2x'] || icons['1x'] || icons.svg || icons.default || '';
  };

  const setPluginDirectoryView = view => {
    setDirectoryView(view);
    persistUserPreference('ve_plugin_directory_view', view);
  };

  return h('div', { class: 've-studio-layout ve-plugin-studio' },
    h('div', { class: 've-studio-sidebar' },
      h('div', { class: 've-studio-nav' },
        h('div', { class: 've-studio-nav-title' }, 'Installed Plugins'),
        [
          ['all', 'All plugins', 'plugs'],
          ['active', 'Active', 'toggle-right'],
          ['inactive', 'Inactive', 'toggle-left'],
          ['updates', 'Updates', 'arrow-circle-up']
        ].map(row => h('div', { class: 've-studio-nav-item' + (!directoryMode && status === row[0] ? ' active' : ''), onClick: () => { setDirectoryMode(false); setStatus(row[0]); } },
          h('span', { style: 'display:flex;align-items:center;gap:8px' }, ph(row[2]), row[1]),
          h('span', { class: 've-studio-badge' }, counts[row[0]])
        ))
      ),
      h('div', { class: 've-studio-nav' },
        h('div', { class: 've-studio-nav-title' }, 'Plugin Directory'),
        h('div', { class: 've-studio-nav-item' + (directoryMode ? ' active' : ''), onClick: () => { setDirectoryMode(true); if (!directoryResults.length) searchDirectory(''); } },
          h('span', { style: 'display:flex;align-items:center;gap:8px' }, ph('download-simple'), 'Browse plugins'),
          h('span', { class: 've-studio-badge' }, directoryResults.length || 'WP')
        )
      ),
      h('div', { class: 've-studio-stats' },
        h('div', { class: 've-studio-stats-item' }, h('span', null, 'Active'), h('b', null, counts.active)),
        h('div', { class: 've-studio-stats-item' }, h('span', null, 'Updates'), h('b', null, counts.updates))
      )
    ),
    h('div', { class: 've-studio-main' },
      h('div', { class: 've-studio-topbar' },
        h('div', null,
          h('h2', { style: 'margin:0;font-size:16px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px' }, directoryMode ? 'Plugin Directory' : 'Plugin Studio', h('span', { class: 've-studio-badge' }, directoryMode ? ((directoryLoading ? '...' : directoryResults.length) + ' found') : (filteredPlugins.length + ' shown'))),
          h('div', { class: 've-studio-help' }, directoryMode ? 'Search and install plugins from the WordPress.org directory.' : 'Manage activation, updates, auto-updates, and cleanup without leaving Mimam\'s Var.')
        ),
        h('div', { style: 'display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:flex-end' },
          !directoryMode && h('input', { class: 've-studio-input', style: 'width:220px', placeholder: 'Search installed plugins...', value: search, onInput: e => setSearch(e.target.value) }),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: loadPlugins, disabled: loading }, ph('arrows-clockwise'), loading ? 'Refreshing' : 'Refresh'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => uploadRef.current && uploadRef.current.click(), disabled: pending === 'upload:plugin' }, ph('upload-simple'), pending === 'upload:plugin' ? 'Uploading' : 'Upload ZIP'),
          h('input', { ref: uploadRef, type: 'file', accept: '.zip,application/zip,application/x-zip-compressed', style: 'display:none', onChange: e => uploadPluginZip(e.target.files && e.target.files[0]) })
        )
      ),
      directoryMode && h('div', { class: 've-plugin-directory-bar' },
        h('input', { class: 've-studio-input', placeholder: 'Ajax search WordPress plugin directory...', value: directoryQuery, onInput: e => setDirectoryQuery(e.target.value), onKeyDown: e => { if (e.key === 'Enter') searchDirectory(); } }),
        h('button', { class: 've-btn ve-btn-s', onClick: () => searchDirectory(), disabled: directoryLoading }, ph('magnifying-glass'), directoryLoading ? 'Searching' : 'Search'),
        h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => setPluginDirectoryView(directoryView === 'grid' ? 'list' : 'grid'), title: directoryView === 'grid' ? 'List view' : 'Grid view' }, ph(directoryView === 'grid' ? 'list' : 'squares-four')),
        directoryMode && h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => setDirectoryMode(false) }, 'Installed')
      ),
      directoryMode && h('div', { class: 've-plugin-directory-results ' + directoryView },
        directoryLoading ? h('div', { class: 've-empty' }, 'Searching WordPress.org...') :
        directoryResults.length === 0 ? h('div', { class: 've-empty' }, 'No directory results yet.') :
        directoryResults.map(item => h('div', { class: 've-plugin-card', key: item.slug },
          directoryIcon(item)
            ? h('img', { class: 've-plugin-card-icon', src: directoryIcon(item), alt: '' })
            : h('div', { class: 've-plugin-card-icon' }, ph('plug')),
          h('div', { class: 've-plugin-card-main' },
            h('strong', null, item.name || item.slug),
            h('span', null, item.short_description || 'No description provided.'),
            h('small', null, (item.version ? 'v' + item.version : ''), item.author ? ' · ' + item.author.replace(/<[^>]*>/g, '') : '', item.active_installs ? ' · ' + item.active_installs.toLocaleString() + '+ installs' : '')
          ),
          h('button', { class: 've-btn ve-btn-s', disabled: pending === item.slug + ':install', onClick: () => installDirectoryPlugin(item.slug) }, pending === item.slug + ':install' ? 'Installing' : 'Install')
        ))
      ),
      !directoryMode &&
      h('div', { class: 've-studio-table-container' },
        loading ? h('div', { class: 've-empty' }, 'Loading plugins...') :
        filteredPlugins.length === 0 ? h('div', { class: 've-empty' }, 'No plugins match this filter.') :
        h('table', { class: 've-studio-table ve-plugin-table' },
          h('thead', null, h('tr', null,
            h('th', null, 'Plugin'),
            h('th', { style: 'width:100px' }, 'Version'),
            h('th', { style: 'width:110px' }, 'Status'),
            h('th', { style: 'width:120px' }, 'Auto-update'),
            h('th', { style: 'width:260px;text-align:right' }, 'Actions')
          )),
          h('tbody', null, filteredPlugins.map(plugin => {
            const busy = pending && pending.indexOf(plugin.slug + ':') === 0;
            return h('tr', { key: plugin.file },
              h('td', null,
                h('div', { style: 'display:flex;flex-direction:column;gap:3px' },
                  h('strong', { style: 'color:#fff' }, plugin.name),
                  h('span', { class: 've-plugin-description' }, plugin.description || plugin.file),
                  h('span', { class: 've-plugin-author' }, plugin.author || '')
                )
              ),
              h('td', null, h('span', { style: 'font-family:"SF Mono","Fira Code",monospace;color:#ccc' }, plugin.version || '-')),
              h('td', null, h('span', { class: 've-studio-badge ' + (plugin.active ? 'ok' : '') }, plugin.active ? 'Active' : 'Inactive')),
              h('td', null, h(ToggleControl, { checked: !!plugin.auto_update, disabled: busy, onChange: () => runPluginAction(plugin, plugin.auto_update ? 'auto_update_off' : 'auto_update_on'), title: plugin.auto_update ? 'Auto-update on' : 'Auto-update off' })),
              h('td', { style: 'text-align:right' },
                h('div', { style: 'display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap' },
                  plugin.update_available && h('a', { class: 've-btn ve-btn-s', href: plugin.update_url || 'update-core.php', style: 'text-decoration:none;display:inline-flex;align-items:center' }, ph('arrow-circle-up'), 'Update'),
                  h('button', { class: 've-btn ve-btn-g ve-btn-s', disabled: busy, onClick: () => runPluginAction(plugin, plugin.active ? 'deactivate' : 'activate') }, plugin.active ? 'Deactivate' : 'Activate'),
                  !plugin.active && h('button', { class: 've-btn ve-btn-g ve-btn-s ve-danger-soft', disabled: busy, onClick: () => runPluginAction(plugin, 'delete') }, ph('trash'), 'Delete')
                )
              )
            );
          }))
        )
      )
    )
  );
}
window.__VE.studios={ContentStudioSub:ContentStudioSub,MediaStudioSub:MediaStudioSub,FontManagerStudio:FontManagerStudio,PluginStudioSub:PluginStudioSub};
try{window.dispatchEvent(new CustomEvent('ve-studios-ready'));}catch(e){}
})();
