<?php
namespace VE\Adapters;
defined('ABSPATH') || exit;

class AdminAdapter {
    public function __construct() {
        if (defined('VE_IS_BRICKS') && VE_IS_BRICKS) return;
        if (!is_admin()) return;
        global $pagenow;
        if (in_array($pagenow, ['update.php', 'update-core.php'])) return;
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
    }
    public function enqueue(): void {
        if (!current_user_can('manage_options')) return;
        // All runtime vendor assets are bundled with the plugin, not loaded from a CDN, so
        // the builder works offline, under strict CSP, and on privacy-strict hosts. GSAP was
        // enqueued but never referenced by the panel; it has been removed.
        $ver = VE_VERSION;
        wp_enqueue_style('ve-ph', VE_URL.'assets/phosphor/style.css', [], $ver.'.'.filemtime(VE_DIR.'assets/phosphor/style.css'));
        wp_enqueue_style('ve-components', VE_URL.'assets/components.css', [], $ver.'.'.filemtime(VE_DIR.'assets/components.css'));
        wp_enqueue_style('ve-panel', VE_URL.'assets/css/panel.css', ['ve-ph','ve-components'], $ver.'.'.filemtime(VE_DIR.'assets/css/panel.css'));
        // CodeMirror's editor CSS is pre-scoped to `.ve-cm-host` (codemirror.scoped.css), so it
        // styles only MV's own editors and never bleeds into — or gets neutralized against —
        // other plugins' code editors (Advanced Themer Style Manager, Code2Bricks Quick Import).
        wp_enqueue_style('ve-codemirror', VE_URL.'assets/vendor/codemirror/codemirror.scoped.css', [], '5.65.16');
        wp_enqueue_style('ve-codemirror-hint', VE_URL.'assets/vendor/codemirror/show-hint.css', ['ve-codemirror'], '5.65.16');
        wp_enqueue_script('ve-shortcuts', VE_URL.'assets/js/shortcut-registry.js', [], $ver.'.'.filemtime(VE_DIR.'assets/js/shortcut-registry.js'), true);
        wp_enqueue_script('ve-p', VE_URL.'assets/vendor/preact.umd.js', [], '10', true);
        wp_enqueue_script('ve-ph', VE_URL.'assets/vendor/preact-hooks.umd.js', ['ve-p'], '10', true);
        wp_enqueue_script('ve-codemirror', VE_URL.'assets/vendor/codemirror/codemirror.js', [], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-css', VE_URL.'assets/vendor/codemirror/mode-css.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-xml', VE_URL.'assets/vendor/codemirror/mode-xml.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-javascript', VE_URL.'assets/vendor/codemirror/mode-javascript.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-htmlmixed', VE_URL.'assets/vendor/codemirror/mode-htmlmixed.js', ['ve-codemirror-xml','ve-codemirror-javascript','ve-codemirror-css'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-closebrackets', VE_URL.'assets/vendor/codemirror/closebrackets.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-hint', VE_URL.'assets/vendor/codemirror/show-hint.js', ['ve-codemirror'], '5.65.16', true);
        $app_dependencies = array_merge(
            ['ve-p','ve-ph','ve-codemirror-htmlmixed','ve-codemirror-closebrackets','ve-codemirror-hint'],
            \VE\Core\RankMathAnalysisBridge::enqueue()
        );
        $app_dependencies[] = 've-shortcuts';
        wp_enqueue_script('ve-app', VE_URL.'assets/js/builder-panel.js', $app_dependencies, $ver.'.'.filemtime(VE_DIR.'assets/js/builder-panel.js'), true);
        $preferences = get_user_meta( get_current_user_id(), 've_user_preferences', true );
        wp_localize_script('ve-app', 'vePanel', ['apiRoot'=>esc_url_raw(rest_url()),'ajaxUrl'=>esc_url_raw(admin_url('admin-ajax.php')),'nonce'=>wp_create_nonce('wp_rest'),'version'=>VE_VERSION,'mode'=>'admin','siteTitle'=>sanitize_text_field(get_bloginfo('name')),'logoUrl'=>esc_url_raw(VE_URL.'assets/hebronmimam-logo-icon.png'),'assetUrl'=>esc_url_raw(VE_URL.'assets/'),'fontToolsScript'=>esc_url_raw(VE_URL.'assets/vendor/fonteditor-core/fonteditor-core.iife.js'),'fontToolsWasm'=>esc_url_raw(VE_URL.'assets/vendor/fonteditor-core/woff2.wasm'),'newPostDefaults'=>['comment_status'=>get_option('default_comment_status')?:'open','ping_status'=>get_option('default_ping_status')?:'open'],'userPreferences'=>is_array($preferences)?$preferences:[]]);
        if (class_exists('\VE\Modules\BuilderTools\MimamsBarModule')) {
            (new \VE\Modules\BuilderTools\MimamsBarModule())->enqueue('admin');
        }
    }
}
