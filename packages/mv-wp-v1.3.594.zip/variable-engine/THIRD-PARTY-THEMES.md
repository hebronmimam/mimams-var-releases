# Third-party syntax themes

Mimam's Var ships colour data for the syntax themes below. Only theme data is
included - no icons, fonts, screenshots, README files or extension code from the
upstream projects.

The data was obtained from [tm-themes]
(https://github.com/shikijs/textmate-grammars-themes/tree/main/packages/tm-themes),
which normalises upstream VS Code themes and preserves each one's licence and
copyright notice. It was then translated for CodeMirror 5 by
`scripts/import-syntax-themes.py`: TextMate scopes do not map one-to-one onto
CodeMirror token classes, so each of MV's token classes is resolved from an
ordered list of scopes. **The colours are upstream; the mapping is ours.**

Shiki and tm-themes are development-time tools only. Neither is a runtime
dependency of this plugin, and no network request is made when a theme changes.

## One Dark Pro (`one-dark-pro`)

- Appearance: dark
- Source: `tm-themes/one-dark-pro.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/Binaryify/OneDark-Pro/master/LICENSE.txt
- Copyright (c) 2013-2022 Binaryify
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Dracula (`dracula`)

- Appearance: dark
- Source: `tm-themes/dracula.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/dracula/visual-studio-code/main/LICENSE
- Copyright (c) 2016 Dracula Theme
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Tokyo Night (`tokyo-night`)

- Appearance: dark
- Source: `tm-themes/tokyo-night.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/tokyo-night/tokyo-night-vscode-theme/master/LICENSE.txt
- Copyright (c) 2018-present Enkia
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Catppuccin Mocha (`catppuccin-mocha`)

- Appearance: dark
- Source: `tm-themes/catppuccin-mocha.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/catppuccin/vscode/main/LICENSE
- Copyright (c) 2021 Catppuccin
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Gruvbox Dark Medium (`gruvbox-dark-medium`)

- Appearance: dark
- Source: `tm-themes/gruvbox-dark-medium.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/jdinhify/vscode-theme-gruvbox/main/LICENSE
- Copyright © 2017 JD
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Nord (`nord`)

- Appearance: dark
- Source: `tm-themes/nord.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/nordtheme/visual-studio-code/develop/license
- Copyright (c) 2016-present Sven Greb <development@svengreb.de> (https://www.svengreb.de)
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Monokai (`monokai`)

- Appearance: dark
- Source: `tm-themes/monokai.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/microsoft/vscode/main/LICENSE.txt
- Copyright (c) 2015 - present Microsoft Corporation
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## GitHub Dark (`github-dark`)

- Appearance: dark
- Source: `tm-themes/github-dark.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/primer/github-vscode-theme/main/LICENSE
- Copyright (c) 2020 Primer
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## GitHub Light (`github-light`)

- Appearance: light
- Source: `tm-themes/github-light.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/primer/github-vscode-theme/main/LICENSE
- Copyright (c) 2020 Primer
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Ayu Mirage (`ayu-mirage`)

- Appearance: dark
- Source: `tm-themes/ayu-mirage.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/ayu-theme/vscode-ayu/master/LICENSE
- Copyright (c) 2016 Ike Kurghinyan
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Kanagawa Wave (`kanagawa-wave`)

- Appearance: dark
- Source: `tm-themes/kanagawa-wave.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/paccodes/kanagawa-vscode-theme/main/LICENSE
- Copyright (c) 2025 Pierre-Alain Castella
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Rose Pine (`rose-pine`)

- Appearance: dark
- Source: `tm-themes/rose-pine.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/rose-pine/vscode/main/LICENSE
- Copyright (c) 2021 Rosé Pine
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Night Owl (`night-owl`)

- Appearance: dark
- Source: `tm-themes/night-owl.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/sdras/night-owl-vscode-theme/main/LICENSE.md
- Copyright (c) 2018 Sarah Drasner
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Material Palenight (`material-palenight`)

- Appearance: dark
- Source: `tm-themes/material-theme-palenight.json`
- Licence: Apache-2.0
- Licence text: https://raw.githubusercontent.com/antfu/vsc-material-theme/main/LICENSE
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Solarized Dark (`solarized-dark`)

- Appearance: dark
- Source: `tm-themes/solarized-dark.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/microsoft/vscode/main/LICENSE.txt
- Copyright (c) 2015 - present Microsoft Corporation
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Solarized Light (`solarized-light`)

- Appearance: light
- Source: `tm-themes/solarized-light.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/microsoft/vscode/main/LICENSE.txt
- Copyright (c) 2015 - present Microsoft Corporation
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## Everforest Dark (`everforest-dark`)

- Appearance: dark
- Source: `tm-themes/everforest-dark.json`
- Licence: MIT
- Licence text: https://raw.githubusercontent.com/sainnhe/everforest-vscode/master/LICENSE
- Copyright (c) 2020 sainnhe
- Adapted: yes - normalised and translated to CodeMirror 5 token classes.

## CodeMirror language modes

The editor and its language modes are CodeMirror 5.65.16, MIT licensed, vendored under
`assets/vendor/codemirror/`. Each file keeps its upstream copyright header. The `php` and
`clike` modes were added in v1.3.593; `codemirror.scoped.css` and `show-hint.scoped.css` are
MV-scoped copies of the upstream stylesheets, carrying a header that says so.
