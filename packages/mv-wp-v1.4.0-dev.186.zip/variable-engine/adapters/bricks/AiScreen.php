<?php

namespace VE\Adapters\Bricks;

defined( 'ABSPATH' ) || exit;

/**
 * R45, the owner: "where is the bricks settings Abilities API" then "MV should
 * mirrow that." Direction 2, "build it." (2026-09-24): Bricks' whole AI screen
 * (Bricks -> AI, Experimental) in MV, with its three tabs - Configuration,
 * Abilities, Skills.
 *
 * The rule it follows: MV writes what Bricks writes, in the shape Bricks reads.
 * Every write here is the same write Bricks 2.4.1's own handlers make
 * (Admin::save_ai_settings, generate_ai_application_password,
 * install_mcp_adapter, activate_mcp_adapter), so Bricks' own screen shows the
 * same answers.
 *
 * The one credential is a WordPress application password. WordPress makes it;
 * MV hands it back once and keeps nothing - not in an option, not in a log,
 * not in a transient.
 */
class AiScreen {

    public static function available(): bool {
        return class_exists( '\\Bricks\\Abilities\\Manager' ) && class_exists( '\\Bricks\\Database' );
    }

    private static function abilities_api_ready(): bool {
        return function_exists( 'wp_register_ability' ) && function_exists( 'wp_register_ability_category' );
    }

    private static function manager() {
        $theme = class_exists( '\\Bricks\\Theme' ) ? \Bricks\Theme::instance() : null;
        if ( $theme && isset( $theme->abilities ) && $theme->abilities instanceof \Bricks\Abilities\Manager ) {
            return $theme->abilities;
        }
        $manager = new \Bricks\Abilities\Manager();
        if ( $theme ) {
            $theme->abilities = $manager;
        }
        return $manager;
    }

    /** Everything the three tabs show, read the way Bricks' screen reads it. */
    public static function state(): array {
        if ( ! self::available() ) {
            return [ 'available' => false ];
        }
        $settings   = is_array( \Bricks\Database::$global_settings ) ? \Bricks\Database::$global_settings : [];
        $mcp        = \Bricks\Abilities\Manager::get_mcp_settings();
        $disabled   = (array) ( $mcp['disabledAbilities'] ?? [] );
        $enabled_on = (array) ( $mcp['enabledAbilities'] ?? [] );
        $ready      = self::abilities_api_ready();
        $by_const   = \Bricks\Abilities\Manager::is_disabled_by_constant();
        $requested  = isset( $settings['abilitiesApi'] );
        $always_on  = (array) \Bricks\Abilities\Manager::ALWAYS_ON_ABILITIES;
        $php_name   = class_exists( '\\Bricks\\Abilities\\Execute_Php' ) ? \Bricks\Abilities\Execute_Php::ABILITY_NAME : 'bricks/execute-php';

        $abilities = [];
        foreach ( self::manager()->get_ability_registry() as $row ) {
            $name        = (string) ( $row['name'] ?? '' );
            $default_on  = isset( $row['defaultEnabled'] ) ? (bool) $row['defaultEnabled'] : true;
            $is_always   = in_array( $name, $always_on, true );
            $is_managed  = ! empty( $row['managedExternally'] );
            $is_enabled  = $is_managed ? ! empty( $row['enabled'] )
                : ( $is_always || ( $default_on ? ! in_array( $name, $disabled, true ) : in_array( $name, $enabled_on, true ) ) );
            if ( $name === $php_name && ! $ready ) {
                $is_enabled = false;
            }
            $category    = (string) ( $row['category'] ?? 'bricks-other' ) ?: 'bricks-other';
            $abilities[] = [
                'name'           => $name,
                'label'          => (string) ( $row['label'] ?? $name ),
                'description'    => (string) ( $row['description'] ?? '' ),
                'category'       => $category,
                'category_label' => self::category_label( $category ),
                'destructive'    => ! empty( $row['destructive'] ),
                'readonly'       => ! empty( $row['readonly'] ),
                'default_on'     => $default_on,
                'always_on'      => $is_always,
                'managed'        => $is_managed,
                'enabled'        => $is_enabled,
            ];
        }

        $status   = class_exists( '\\Bricks\\Helpers' ) && method_exists( '\\Bricks\\Helpers', 'get_mcp_server_status' ) ? \Bricks\Helpers::get_mcp_server_status() : [ 'state' => 'not_installed' ];
        $endpoint = ! empty( $status['endpoint_url'] ) ? (string) $status['endpoint_url'] : rest_url( 'mcp/mcp-adapter-default-server' );
        $host     = (string) wp_parse_url( $endpoint, PHP_URL_HOST );

        $php = [ 'status' => 'Not configured', 'configured' => false ];
        if ( class_exists( '\\Bricks\\Abilities\\Execute_Php' ) && method_exists( '\\Bricks\\Abilities\\Execute_Php', 'admin_state' ) ) {
            $ps  = (array) \Bricks\Abilities\Execute_Php::admin_state();
            $php = [
                'configured' => ! empty( $ps['configured'] ),
                'status'     => 'invalid' === ( $ps['constantStatus'] ?? '' ) ? 'Invalid configuration'
                    : ( ! empty( $ps['configured'] ) && ! empty( $ps['signaturesLocked'] ) ? 'Blocked by signature lock'
                    : ( ! empty( $ps['configured'] ) ? 'Enabled' : ( 'false' === ( $ps['constantStatus'] ?? '' ) ? 'Disabled' : 'Not configured' ) ) ),
            ];
        }

        return [
            'available'        => true,
            'abilities_ready'  => $ready,
            'disabled_by_const' => $by_const,
            'requested'        => $requested,
            'enabled'          => $requested && $ready && ! $by_const,
            'abilities'        => $abilities,
            'execute_php'      => $php + [ 'name' => $php_name ],
            'mcp'              => [
                'state'        => (string) ( $status['state'] ?? 'not_installed' ),
                'source_label' => (string) ( $status['source_label'] ?? '' ),
                'version'      => (string) ( $status['version'] ?? '' ),
                'can_install'  => current_user_can( 'install_plugins' ),
                'can_activate' => current_user_can( 'activate_plugins' ),
            ],
            'connect'          => [
                'endpoint'    => $endpoint,
                'server_name' => sanitize_title( $host ?: get_bloginfo( 'name' ) ),
                // As Bricks: only once the adapter reports its own endpoint, not from the fallback address.
                'local_https' => ! empty( $status['endpoint_url'] ) && 0 === strpos( $endpoint, 'https://' ) && 1 === preg_match( '/(\.local|\.test|\.localhost|\.ddev\.site|localhost|127\.0\.0\.1)$/', $host ),
            ],
            'credential'       => self::credential(),
            'setup_guide'      => apply_filters( 'bricks_mcp_adapter_setup_guide_url', 'https://academy.bricksbuilder.io/builder/features/ai-abilities-and-skills/' ),
            'skills_repo'      => 'https://github.com/codeerhq/bricks-skills',
            'bricks_screen'    => admin_url( 'admin.php?page=bricks-ai' ),
        ];
    }

    /** The current user's application passwords - names and dates only. */
    private static function credential(): array {
        $user = wp_get_current_user();
        $ok   = class_exists( '\\WP_Application_Passwords' ) && function_exists( 'wp_is_application_passwords_available_for_user' );
        $site = $ok && function_exists( 'wp_is_application_passwords_available' ) && wp_is_application_passwords_available();
        $out  = [
            'available'      => false,
            'needs_https'    => $ok && function_exists( 'wp_is_application_passwords_supported' ) && ! wp_is_application_passwords_supported() && ! $site,
            'username'       => $user ? (string) $user->user_login : '',
            'passwords'      => [],
            'manage_url'     => admin_url( 'profile.php#application-passwords-section' ),
        ];
        if ( ! $ok || ! $site || ! $user || ! $user->ID || ! current_user_can( 'create_app_password', $user->ID )
            || ! current_user_can( 'list_app_passwords', $user->ID ) || ! wp_is_application_passwords_available_for_user( $user ) ) {
            return $out;
        }
        $out['available'] = true;
        foreach ( \WP_Application_Passwords::get_user_application_passwords( $user->ID ) as $p ) {
            $out['passwords'][] = [
                'name'      => (string) $p['name'],
                'created'   => date_i18n( get_option( 'date_format' ), (int) $p['created'] ),
                'last_used' => empty( $p['last_used'] ) ? 'Never' : date_i18n( get_option( 'date_format' ), (int) $p['last_used'] ),
            ];
        }
        return $out;
    }

    /**
     * Bricks' Admin::save_ai_settings(), the same writes: `abilitiesApi` in
     * Bricks' global settings, and the abilities that differ from their
     * default in Bricks' abilities option.
     *
     * @param string[] $enabled_names Every ability that should be on.
     */
    public static function save( bool $requested, array $enabled_names ) {
        if ( ! self::available() ) {
            return new \WP_Error( 'bricks_ai_unavailable', 'This version of Bricks has no AI screen.' );
        }
        $global   = is_array( \Bricks\Database::$global_settings ) ? \Bricks\Database::$global_settings : [];
        $by_const = \Bricks\Abilities\Manager::is_disabled_by_constant();
        $ready    = self::abilities_api_ready();
        // Locked by the constant: keep what was asked for before, as Bricks does.
        $requested = $by_const ? isset( $global['abilitiesApi'] ) : $requested;
        $on        = $requested && $ready && ! $by_const;

        if ( $requested && $ready ) {
            $global['abilitiesApi'] = true;
        } else {
            unset( $global['abilitiesApi'] );
        }
        update_option( BRICKS_DB_GLOBAL_SETTINGS, $global );
        \Bricks\Database::$global_settings = $global;

        $enabled_names = array_values( array_map( 'sanitize_text_field', array_map( 'strval', $enabled_names ) ) );
        $existing      = get_option( \Bricks\Abilities\Manager::SETTINGS_OPTION, [] );
        $new           = [
            'enabled'           => $requested && $ready,
            'disabledAbilities' => isset( $existing['disabledAbilities'] ) && is_array( $existing['disabledAbilities'] ) ? $existing['disabledAbilities'] : [],
            'enabledAbilities'  => isset( $existing['enabledAbilities'] ) && is_array( $existing['enabledAbilities'] ) ? $existing['enabledAbilities'] : [],
        ];
        if ( $on ) {
            $disabled = [];
            $enabled  = [];
            foreach ( self::manager()->get_ability_registry() as $row ) {
                if ( in_array( $row['name'], \Bricks\Abilities\Manager::ALWAYS_ON_ABILITIES, true ) || ! empty( $row['managedExternally'] ) ) {
                    continue;
                }
                $is_on      = in_array( $row['name'], $enabled_names, true );
                $default_on = isset( $row['defaultEnabled'] ) ? (bool) $row['defaultEnabled'] : true;
                if ( $default_on && ! $is_on ) {
                    $disabled[] = $row['name'];
                }
                if ( ! $default_on && $is_on ) {
                    $enabled[] = $row['name'];
                }
            }
            $new['disabledAbilities'] = array_values( array_unique( $disabled ) );
            $new['enabledAbilities']  = array_values( array_unique( $enabled ) );
        }
        update_option( \Bricks\Abilities\Manager::SETTINGS_OPTION, $new );
        \Bricks\Abilities\Manager::reset_settings_cache();
        return self::state();
    }

    /**
     * A new application password for the current user, through WordPress's own
     * API. The password is in the return value and nowhere else.
     */
    public static function create_password( string $name ) {
        $user = wp_get_current_user();
        $name = sanitize_text_field( $name );
        if ( '' === $name ) {
            return new \WP_Error( 'bricks_ai_name', 'Give the credential a name, such as the client or device that will use it.' );
        }
        if ( ! $user || ! $user->ID || ! current_user_can( 'create_app_password', $user->ID ) || ! current_user_can( 'list_app_passwords', $user->ID ) ) {
            return new \WP_Error( 'bricks_ai_forbidden', 'You cannot create application passwords for your account.' );
        }
        if ( ! class_exists( '\\WP_Application_Passwords' ) || ! function_exists( 'wp_is_application_passwords_available_for_user' ) || ! wp_is_application_passwords_available_for_user( $user ) ) {
            return new \WP_Error( 'bricks_ai_unavailable', 'Application passwords are not available for your account on this site.' );
        }
        $made = \WP_Application_Passwords::create_new_application_password( $user->ID, [ 'name' => $name ] );
        if ( is_wp_error( $made ) ) {
            return $made;
        }
        return [ 'password' => (string) $made[0], 'name' => $name, 'username' => (string) $user->user_login, 'credential' => self::credential() ];
    }

    /** Bricks' install_mcp_adapter / activate_mcp_adapter, through WordPress's plugin API. */
    public static function adapter( string $step ) {
        if ( ! self::available() || ! method_exists( '\\Bricks\\Helpers', 'get_mcp_server_status' ) ) {
            return new \WP_Error( 'bricks_ai_unavailable', 'This version of Bricks has no MCP setup.' );
        }
        $status = \Bricks\Helpers::get_mcp_server_status();
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        if ( 'activate' === $step ) {
            if ( ! current_user_can( 'activate_plugins' ) ) {
                return new \WP_Error( 'bricks_ai_forbidden', 'You cannot activate plugins.' );
            }
            if ( 'connected' === $status['state'] ) {
                return self::state();
            }
            if ( empty( $status['plugin_file'] ) ) {
                return new \WP_Error( 'bricks_ai_missing', 'The WordPress MCP Adapter is not installed.' );
            }
            $res = activate_plugin( (string) $status['plugin_file'] );
            if ( is_wp_error( $res ) ) {
                return $res;
            }
            wp_clean_plugins_cache( true );
            return self::state();
        }

        if ( ! current_user_can( 'install_plugins' ) ) {
            return new \WP_Error( 'bricks_ai_forbidden', 'You cannot install plugins.' );
        }
        if ( 'not_installed' !== $status['state'] ) {
            return self::state();
        }
        $url = self::adapter_download_url();
        if ( is_wp_error( $url ) ) {
            return $url;
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/misc.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        $skin     = new \Automatic_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader( $skin );
        $result   = $upgrader->install( $url );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        if ( is_wp_error( $skin->result ) ) {
            return $skin->result;
        }
        if ( ! $result ) {
            return new \WP_Error( 'bricks_ai_install', 'The WordPress MCP Adapter could not be installed.' );
        }
        wp_clean_plugins_cache( true );
        return self::state();
    }

    /** The latest stable MCP Adapter release's ZIP, from GitHub - where Bricks gets it. */
    private static function adapter_download_url() {
        $res = wp_remote_get( 'https://api.github.com/repos/WordPress/mcp-adapter/releases/latest', [
            'timeout'             => 8,
            'redirection'         => 3,
            'limit_response_size' => 1048576,
            'headers'             => [ 'Accept' => 'application/vnd.github+json', 'User-Agent' => 'MimamsVar/' . ( defined( 'VE_VERSION' ) ? VE_VERSION : '1' ) ],
        ] );
        if ( is_wp_error( $res ) ) {
            return $res;
        }
        $code = (int) wp_remote_retrieve_response_code( $res );
        $rel  = json_decode( (string) wp_remote_retrieve_body( $res ), true );
        if ( $code < 200 || $code >= 300 || ! is_array( $rel ) ) {
            return new \WP_Error( 'bricks_ai_release', 'Could not read the latest WordPress MCP Adapter release from GitHub.' );
        }
        if ( ! empty( $rel['draft'] ) || ! empty( $rel['prerelease'] ) ) {
            return new \WP_Error( 'bricks_ai_release', 'The latest WordPress MCP Adapter release is not marked as stable.' );
        }
        foreach ( (array) ( $rel['assets'] ?? [] ) as $asset ) {
            $url = (string) ( $asset['browser_download_url'] ?? '' );
            if ( preg_match( '/\.zip$/i', (string) ( $asset['name'] ?? '' ) ) && 0 === strpos( $url, 'https://github.com/' ) ) {
                return $url;
            }
        }
        return new \WP_Error( 'bricks_ai_release', 'The latest WordPress MCP Adapter release has no installable ZIP file.' );
    }

    private static function category_label( string $category ): string {
        if ( function_exists( 'wp_has_ability_category' ) && function_exists( 'wp_get_ability_category' ) && wp_has_ability_category( $category ) ) {
            $registered = wp_get_ability_category( $category );
            if ( $registered ) {
                return (string) $registered->get_label();
            }
        }
        $label = ucwords( str_replace( '-', ' ', str_replace( 'bricks-', '', $category ) ) );
        return str_replace( [ 'Cms', 'Css', 'Mcp' ], [ 'CMS', 'CSS', 'MCP' ], $label );
    }
}
