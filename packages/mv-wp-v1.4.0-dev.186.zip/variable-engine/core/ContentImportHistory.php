<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * R46, the owner, 2026-09-22: "I should be able to role back imports made,
 * like revert imports." Direction 2, picked and "build it." 2026-09-24: an
 * import history. Every import is listed; open one, untick any post to keep,
 * preview exactly what will happen, roll back. It stays listed, marked.
 *
 * Rolling back puts the site back to how it was before the import:
 * - posts it created go to the Trash (restorable from there);
 * - posts it updated get their earlier content, terms and fields back;
 * - images it downloaded that nothing else uses are removed.
 *
 * The report of each run always said which posts it created and updated. What
 * it did not keep is what an updated post was BEFORE, or which images were
 * downloaded - those are recorded here from this build on. An older import can
 * still have its created posts rolled back, and the preview says its updates
 * cannot be.
 */
class ContentImportHistory {

    public const REPORTS_OPTION = 've_content_studio_import_reports';
    /** How many imports stay on record. The list says where it stops. */
    public const KEEP = 50;
    private const UNDO_PREFIX = 've_ci_undo_';

    /** @var array<int,int>|null Attachments WordPress created while an import runs. */
    private static $capture = null;

    /* ── recording, at import time ─────────────────────────────────────── */

    /** What an existing post is, before an import writes over it. */
    public static function snapshot( int $post_id, array $meta_keys ): array {
        $post = get_post( $post_id );
        if ( ! $post ) {
            return [];
        }
        $fields = [ 'post_title', 'post_content', 'post_excerpt', 'post_status', 'post_date', 'post_date_gmt', 'post_name', 'post_author', 'post_parent', 'menu_order' ];
        $data   = [];
        foreach ( $fields as $f ) {
            $data[ $f ] = $post->$f;
        }
        $terms = [];
        foreach ( [ 'category', 'post_tag' ] as $tax ) {
            if ( taxonomy_exists( $tax ) && is_object_in_taxonomy( $post->post_type, $tax ) ) {
                $ids = wp_get_object_terms( $post_id, $tax, [ 'fields' => 'ids' ] );
                $terms[ $tax ] = is_wp_error( $ids ) ? [] : array_map( 'intval', $ids );
            }
        }
        $meta = [];
        foreach ( array_unique( array_merge( array_map( 'strval', $meta_keys ), [ '_thumbnail_id' ] ) ) as $key ) {
            if ( '' === $key ) {
                continue;
            }
            // null: the post had no such field, so rolling back removes it again.
            $meta[ $key ] = metadata_exists( 'post', $post_id, $key ) ? get_post_meta( $post_id, $key, false ) : null;
        }
        return [ 'post' => $data, 'terms' => $terms, 'meta' => $meta ];
    }

    public static function capture_start(): void {
        self::$capture = [];
        add_action( 'add_attachment', [ self::class, 'captured' ] );
    }

    /** @param int $id */
    public static function captured( $id ): void {
        if ( is_array( self::$capture ) ) {
            self::$capture[] = (int) $id;
        }
    }

    /** The attachments made since the last take - one row's images. */
    public static function capture_take(): array {
        $taken = is_array( self::$capture ) ? self::$capture : [];
        if ( is_array( self::$capture ) ) {
            self::$capture = [];
        }
        return array_values( array_unique( $taken ) );
    }

    public static function capture_stop(): void {
        remove_action( 'add_attachment', [ self::class, 'captured' ] );
        self::$capture = null;
    }

    /**
     * Keep what a rollback needs, and let go of it for imports that fall off
     * the list.
     *
     * @param array $rows   [ post_id, status created|updated, title, media[] ] for every row that saved.
     * @param array $before post_id => snapshot(), for every updated post.
     */
    public static function save( string $report_id, array $rows, array $before, array $fields ): void {
        update_option( self::UNDO_PREFIX . $report_id, [ 'rows' => array_values( $rows ), 'before' => $before, 'fields' => $fields, 'rolled' => [] ], false );
    }

    /** Called after a new report is added: trims the list and what it kept. */
    public static function prune(): void {
        $reports = self::reports();
        foreach ( array_slice( $reports, self::KEEP ) as $gone ) {
            delete_option( self::UNDO_PREFIX . (string) ( $gone['id'] ?? '' ) );
        }
        update_option( self::REPORTS_OPTION, array_slice( $reports, 0, self::KEEP ), false );
    }

    /* ── the history ───────────────────────────────────────────────────── */

    public static function reports(): array {
        $r = get_option( self::REPORTS_OPTION, [] );
        return is_array( $r ) ? array_values( array_filter( $r, 'is_array' ) ) : [];
    }

    public static function list(): array {
        $out = [];
        foreach ( self::reports() as $r ) {
            $id   = (string) ( $r['id'] ?? '' );
            $undo = get_option( self::UNDO_PREFIX . $id, null );
            $user = get_userdata( (int) ( $r['user_id'] ?? 0 ) );
            $type = get_post_type_object( (string) ( $r['options']['post_type'] ?? '' ) );
            $rows = self::rows( $r, $undo );
            $rolled = is_array( $undo ) ? count( (array) ( $undo['rolled'] ?? [] ) ) : count( (array) ( $r['rolled_back']['rows'] ?? [] ) );
            $out[] = [
                'id'         => $id,
                'file'       => (string) ( $r['file_name'] ?? '' ),
                'created_at' => (string) ( $r['created_at'] ?? '' ),
                'who'        => $user ? $user->display_name : '',
                'type'       => $type ? $type->labels->name : (string) ( $r['options']['post_type'] ?? '' ),
                'completed'  => (array) ( $r['completed'] ?? [] ),
                'rows'       => count( $rows ),
                'rolled'     => $rolled,
                'state'      => ! $rolled ? 'imported' : ( $rolled >= count( $rows ) ? 'rolled-back' : 'partly-rolled-back' ),
                'recorded'   => is_array( $undo ),
            ];
        }
        return [ 'imports' => $out, 'keep' => self::KEEP ];
    }

    /** One import, post by post, as it stands now. */
    public static function detail( string $id ): ?array {
        $report = self::report( $id );
        if ( ! $report ) {
            return null;
        }
        $undo   = get_option( self::UNDO_PREFIX . $id, null );
        $rolled = is_array( $undo ) ? (array) ( $undo['rolled'] ?? [] ) : (array) ( $report['rolled_back']['rows'] ?? [] );
        $ran_at = strtotime( (string) ( $report['created_at'] ?? '' ) ) ?: 0;
        $rows   = [];
        foreach ( self::rows( $report, $undo ) as $row ) {
            $pid  = (int) $row['post_id'];
            $post = get_post( $pid );
            $rows[] = [
                'post_id'     => $pid,
                'title'       => $post ? (string) $post->post_title : (string) ( $row['title'] ?? '' ),
                'did'         => (string) $row['status'],
                'exists'      => (bool) $post,
                'post_status' => $post ? (string) $post->post_status : '',
                'edited_since' => $post && $ran_at && strtotime( $post->post_modified_gmt . ' UTC' ) > $ran_at + 1,
                'restorable'  => 'created' === $row['status'] || ( is_array( $undo ) && isset( $undo['before'][ $pid ] ) ),
                'media'       => count( (array) ( $row['media'] ?? [] ) ),
                'rolled'      => ! empty( $rolled[ $pid ] ),
            ];
        }
        return [
            'id'       => $id,
            'file'     => (string) ( $report['file_name'] ?? '' ),
            'recorded' => is_array( $undo ),
            'fields'   => is_array( $undo ) ? array_values( (array) ( $undo['fields'] ?? [] ) ) : [],
            'rows'     => $rows,
        ];
    }

    /**
     * What rolling back will do, for every row not kept. Nothing changes here;
     * rollback() does exactly this.
     *
     * @param int[] $keep Post IDs the owner unticked.
     */
    public static function plan( string $id, array $keep ): ?array {
        $report = self::report( $id );
        if ( ! $report ) {
            return null;
        }
        $undo   = get_option( self::UNDO_PREFIX . $id, null );
        $keep   = array_flip( array_map( 'intval', $keep ) );
        $rolled = is_array( $undo ) ? (array) ( $undo['rolled'] ?? [] ) : (array) ( $report['rolled_back']['rows'] ?? [] );
        $ran_at = strtotime( (string) ( $report['created_at'] ?? '' ) ) ?: 0;
        $plan   = [ 'trash' => [], 'restore' => [], 'cannot' => [], 'skip' => [], 'edited' => [], 'media_remove' => [], 'media_keep' => [], 'recorded' => is_array( $undo ) ];
        $set    = [];
        $media  = [];
        foreach ( self::rows( $report, $undo ) as $row ) {
            $pid = (int) $row['post_id'];
            if ( isset( $keep[ $pid ] ) || ! empty( $rolled[ $pid ] ) ) {
                continue;
            }
            $post  = get_post( $pid );
            $title = $post ? (string) $post->post_title : (string) ( $row['title'] ?? '' );
            $item  = [ 'post_id' => $pid, 'title' => $title ];
            if ( ! $post ) {
                $plan['skip'][] = $item + [ 'why' => 'It no longer exists.' ];
                continue;
            }
            if ( 'created' === $row['status'] ) {
                if ( 'trash' === $post->post_status ) {
                    $plan['skip'][] = $item + [ 'why' => 'It is already in the Trash.' ];
                    continue;
                }
                if ( ! current_user_can( 'delete_post', $pid ) ) {
                    $plan['skip'][] = $item + [ 'why' => 'You cannot delete it.' ];
                    continue;
                }
                $plan['trash'][] = $item;
            } else {
                if ( ! is_array( $undo ) || ! isset( $undo['before'][ $pid ] ) ) {
                    $plan['cannot'][] = $item;
                    continue;
                }
                if ( ! current_user_can( 'edit_post', $pid ) ) {
                    $plan['skip'][] = $item + [ 'why' => 'You cannot edit it.' ];
                    continue;
                }
                $plan['restore'][] = $item;
            }
            $set[ $pid ] = true;
            if ( $ran_at && strtotime( $post->post_modified_gmt . ' UTC' ) > $ran_at + 1 ) {
                $plan['edited'][] = $item;
            }
            foreach ( (array) ( $row['media'] ?? [] ) as $aid ) {
                $media[ (int) $aid ] = $pid;
            }
        }
        foreach ( $media as $aid => $pid ) {
            $att = get_post( $aid );
            if ( ! $att || 'attachment' !== $att->post_type ) {
                continue;
            }
            $used = self::used_elsewhere( $aid, array_keys( $set ) );
            $name = (string) basename( (string) get_attached_file( $aid ) );
            if ( $used ) {
                $plan['media_keep'][] = [ 'id' => $aid, 'name' => $name, 'used_by' => $used ];
            } elseif ( current_user_can( 'delete_post', $aid ) ) {
                $plan['media_remove'][] = [ 'id' => $aid, 'name' => $name ];
            }
        }
        return $plan;
    }

    /** Do what plan() said, and mark the import. */
    public static function rollback( string $id, array $keep ): ?array {
        $plan = self::plan( $id, $keep );
        if ( null === $plan ) {
            return null;
        }
        $undo   = get_option( self::UNDO_PREFIX . $id, null );
        $done   = [ 'trashed' => 0, 'restored' => 0, 'media_removed' => 0, 'failed' => [] ];
        $rolled = [];

        foreach ( $plan['trash'] as $item ) {
            if ( wp_trash_post( (int) $item['post_id'] ) ) {
                $done['trashed']++;
                $rolled[ (int) $item['post_id'] ] = true;
            } else {
                $done['failed'][] = $item['title'];
            }
        }
        foreach ( $plan['restore'] as $item ) {
            $pid = (int) $item['post_id'];
            if ( self::restore( $pid, (array) $undo['before'][ $pid ] ) ) {
                $done['restored']++;
                $rolled[ $pid ] = true;
            } else {
                $done['failed'][] = $item['title'];
            }
        }
        foreach ( $plan['media_remove'] as $m ) {
            if ( wp_delete_attachment( (int) $m['id'], true ) ) {
                $done['media_removed']++;
            }
        }

        $at = gmdate( 'c' );
        if ( is_array( $undo ) ) {
            $undo['rolled'] = (array) ( $undo['rolled'] ?? [] ) + $rolled;
            update_option( self::UNDO_PREFIX . $id, $undo, false );
        }
        $reports = self::reports();
        foreach ( $reports as $i => $r ) {
            if ( (string) ( $r['id'] ?? '' ) === $id ) {
                $prev = (array) ( $r['rolled_back'] ?? [] );
                $reports[ $i ]['rolled_back'] = [
                    'at'   => $at,
                    'by'   => get_current_user_id(),
                    'rows' => (array) ( $prev['rows'] ?? [] ) + $rolled,
                    'runs' => array_merge( (array) ( $prev['runs'] ?? [] ), [ [ 'at' => $at, 'by' => get_current_user_id() ] + array_diff_key( $done, [ 'failed' => 1 ] ) ] ),
                ];
            }
        }
        update_option( self::REPORTS_OPTION, $reports, false );
        return $done;
    }

    /* ── helpers ───────────────────────────────────────────────────────── */

    private static function report( string $id ): ?array {
        foreach ( self::reports() as $r ) {
            if ( (string) ( $r['id'] ?? '' ) === $id ) {
                return $r;
            }
        }
        return null;
    }

    /** Every row that saved: the full record when there is one, else the report's own list. */
    private static function rows( array $report, $undo ): array {
        if ( is_array( $undo ) ) {
            return array_values( array_filter( (array) ( $undo['rows'] ?? [] ), 'is_array' ) );
        }
        $rows = [];
        foreach ( (array) ( $report['results'] ?? [] ) as $r ) {
            if ( is_array( $r ) && ! empty( $r['post_id'] ) && in_array( $r['status'] ?? '', [ 'created', 'updated' ], true ) ) {
                $rows[] = [ 'post_id' => (int) $r['post_id'], 'status' => $r['status'], 'title' => (string) ( $r['title'] ?? '' ), 'media' => [] ];
            }
        }
        return $rows;
    }

    /** Put an updated post back as it was before the import. */
    private static function restore( int $post_id, array $before ): bool {
        $post = (array) ( $before['post'] ?? [] );
        if ( ! $post ) {
            return false;
        }
        // edit_date: without it WordPress keeps a draft's date blank rather than restoring it.
        $res = wp_update_post( wp_slash( [ 'ID' => $post_id, 'edit_date' => true ] + $post ), true );
        if ( is_wp_error( $res ) || ! $res ) {
            return false;
        }
        foreach ( (array) ( $before['terms'] ?? [] ) as $tax => $ids ) {
            wp_set_object_terms( $post_id, array_map( 'intval', (array) $ids ), (string) $tax, false );
        }
        foreach ( (array) ( $before['meta'] ?? [] ) as $key => $values ) {
            delete_post_meta( $post_id, (string) $key );
            foreach ( null === $values ? [] : (array) $values as $v ) {
                add_post_meta( $post_id, (string) $key, wp_slash( $v ) );
            }
        }
        return true;
    }

    /**
     * Where else an image the import downloaded is used: another post's
     * featured image or field, or another post's content. Posts being rolled
     * back do not count.
     *
     * @return string[] Titles of up to three posts that use it.
     */
    private static function used_elsewhere( int $aid, array $rolling ): array {
        global $wpdb;
        $not = $rolling ? ' AND p.ID NOT IN (' . implode( ',', array_map( 'intval', $rolling ) ) . ')' : '';
        $by  = $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT p.post_title FROM {$wpdb->postmeta} m JOIN {$wpdb->posts} p ON p.ID = m.post_id
             WHERE m.meta_value = %s AND m.meta_key NOT LIKE %s AND p.post_type NOT IN ('revision','attachment') AND p.post_status <> 'trash'{$not} LIMIT 3",
            (string) $aid, $wpdb->esc_like( '_wp_' ) . '%'
        ) );
        if ( $by ) {
            return array_map( 'strval', $by );
        }
        $file = (string) get_post_meta( $aid, '_wp_attached_file', true );
        $stem = '' !== $file ? preg_replace( '/\.[a-z0-9]+$/i', '', $file ) : '';
        $like = [ '%' . $wpdb->esc_like( 'wp-image-' . $aid . '"' ) . '%', '%' . $wpdb->esc_like( 'wp-image-' . $aid . ' ' ) . '%' ];
        $sql  = "SELECT DISTINCT p.post_title FROM {$wpdb->posts} p WHERE p.post_type NOT IN ('revision','attachment') AND p.post_status <> 'trash'{$not}
                 AND ( p.post_content LIKE %s OR p.post_content LIKE %s" . ( '' !== $stem ? ' OR p.post_content LIKE %s' : '' ) . ' ) LIMIT 3';
        $args = '' !== $stem ? array_merge( $like, [ '%' . $wpdb->esc_like( $stem ) . '%' ] ) : $like;
        return array_map( 'strval', (array) $wpdb->get_col( $wpdb->prepare( $sql, $args ) ) );
    }
}
