(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarCommandSuggestions) return;

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[char];
    });
  }

  function highlightMatch(text, query) {
    text = String(text == null ? '' : text);
    query = String(query || '');
    if (!query) return escapeHtml(text);
    var i = text.toLowerCase().indexOf(query.toLowerCase());
    if (i === -1) return escapeHtml(text); // fuzzy match: no single contiguous span to mark
    return escapeHtml(text.slice(0, i)) + '<mark class="baqa-suggestion-mark">' + escapeHtml(text.slice(i, i + query.length)) + '</mark>' + escapeHtml(text.slice(i + query.length));
  }

  function unique(values) {
    var out = [];
    (values || []).forEach(function (value) {
      value = String(value || '').trim();
      if (value && out.indexOf(value) === -1) out.push(value);
    });
    return out;
  }

  function scoreByPrefix(value, query) {
    value = String(value || '').toLowerCase();
    query = String(query || '').toLowerCase();
    if (!query) return 1;
    if (value === query) return 100;
    if (value.indexOf(query) === 0) return 80 - value.length;
    if (value.indexOf(query) !== -1) return 40 - value.length;
    // Fuzzy: every query character appears in order (a subsequence), so ".splmed" still
    // finds ".split-content__media". Ranked below prefix/substring matches.
    var vi = 0;
    for (var qi = 0; qi < query.length; qi++) {
      vi = value.indexOf(query.charAt(qi), vi);
      if (vi === -1) return -1;
      vi++;
    }
    return 8;
  }

  function sortMatches(items, query) {
    return items.map(function (item) {
      item._score = scoreByPrefix(item.key || item.label || item.command, query);
      return item;
    }).filter(function (item) {
      return item._score >= 0;
    }).sort(function (a, b) {
      return (b.priority || 0) - (a.priority || 0) || b._score - a._score || String(a.label).localeCompare(String(b.label));
    });
  }

  function getElement(app) {
    return app && app.adapter && typeof app.adapter.getSelectedElement === 'function'
      ? app.adapter.getSelectedElement()
      : null;
  }

  function getClasses(app, element) {
    if (!app || !app.adapter || !element) return [];
    return unique(app.adapter.getElementClasses(element));
  }

  function getAttributes(app, element) {
    if (!app || !app.adapter || !element) return [];
    return (app.adapter.getElementAttributes(element) || []).filter(function (attr) {
      return attr && attr.name;
    });
  }

  function buildRemoveClassSuggestions(app, value) {
    var match = String(value || '').match(/^\s*-\.?([^\s]*)$/);
    if (!match) return [];

    var element = getElement(app);
    if (!element) return [];

    var query = match[1] || '';
    return sortMatches(getClasses(app, element).map(function (name) {
      return {
        type: 'remove-class',
        key: name,
        label: '-' + name,
        detail: 'remove .' + name + ' from selected element',
        command: '-' + name
      };
    }), query).slice(0, 6);
  }

  function buildDeleteSuggestions(app, value) {
    var raw = String(value || '');
    var match = raw.match(/^\s*delete(?:\s+(.+))?$/i);
    if (!match) return [];

    var element = getElement(app);
    if (!element) return [];

    var remainder = String(match[1] || '');
    var tokens = remainder.split(/\s+/).filter(Boolean);
    var last = tokens.length ? tokens[tokens.length - 1] : '';
    var prefix = last;
    var isClassDelete = prefix.charAt(0) === '.';
    var query = isClassDelete ? prefix.slice(1) : prefix;

    var suggestions = [];

    if (isClassDelete) {
      suggestions = sortMatches(getClasses(app, element).map(function (name) {
        return {
          type: 'delete-global-class',
          key: name,
          label: 'delete .' + name,
          detail: 'open guarded global class cleanup dialog',
          command: 'delete .' + name
        };
      }), query);
    } else {
      suggestions = sortMatches(getAttributes(app, element).map(function (attr) {
        return {
          type: 'delete-attribute',
          key: attr.name,
          label: 'delete ' + attr.name,
          detail: attr.value === '' ? 'remove boolean/empty attribute' : 'remove attribute currently set to “' + attr.value + '”',
          command: 'delete ' + attr.name
        };
      }), query);
    }

    return suggestions.slice(0, 6);
  }

  // Common data-* / ARIA / HTML attribute names to autosuggest, in the spirit of a simple
  // but powerful attribute bar. The selected element's own attributes are merged in ahead
  // of these so editing an existing attribute is one keystroke away.
  var COMMON_ATTRIBUTES = [
    'data-anim', 'data-animation', 'data-aos', 'data-delay', 'data-duration', 'data-speed',
    'data-scroll', 'data-parallax', 'data-sticky', 'data-target', 'data-toggle', 'data-tooltip',
    'data-title', 'data-id', 'data-index', 'data-tab', 'data-accordion', 'data-modal', 'data-src',
    'data-count', 'data-group', 'data-state',
    'aria-label', 'aria-hidden', 'aria-expanded', 'aria-controls', 'aria-live', 'aria-current',
    'role', 'tabindex', 'id', 'title', 'loading', 'target', 'rel', 'type', 'name', 'placeholder',
    'value', 'href', 'alt'
  ];

  function buildAttributeSuggestions(app, value) {
    var raw = String(value || '');
    // Operate on the last whitespace-separated token so this also works after a bulk
    // target (e.g. "all h2 => data-a") or after earlier attributes on the same line.
    var lastStart = raw.search(/\S+$/);
    if (lastStart < 0) return [];
    var prefixText = raw.slice(0, lastStart);
    var token = raw.slice(lastStart);
    // Only when typing a bare attribute name (no value started yet, not a class/id/remove/delete).
    if (!/^[A-Za-z][A-Za-z0-9-]*$/.test(token)) return [];

    var element = getElement(app);
    var existing = element ? getAttributes(app, element).map(function (attr) { return attr.name; }) : [];
    var names = unique(existing.concat(COMMON_ATTRIBUTES));

    return sortMatches(names.map(function (name) {
      var command = prefixText + name + '=""';
      return {
        type: 'set-attribute',
        key: name,
        label: name,
        detail: existing.indexOf(name) !== -1 ? 'edit existing attribute' : 'set ' + name + '="..."',
        command: command,
        nextValue: command,
        caret: command.length - 1,
        priority: existing.indexOf(name) !== -1 ? 20 : 0
      };
    }), token).slice(0, 7);
  }

  function buildClassSuggestions(app, value) {
    var raw = String(value || '');
    var lastStart = raw.search(/\S+$/);
    if (lastStart < 0) return [];
    var prefixText = raw.slice(0, lastStart);
    var token = raw.slice(lastStart);
    if (!/^\.[A-Za-z0-9_-]*$/.test(token)) return [];

    var element = getElement(app);
    if (!element) return [];
    var query = token.slice(1);
    var ql = query.toLowerCase();

    var make = function (name, group, priority) {
      var command = prefixText + '.' + name;
      var fuzzy = ql && String(name).toLowerCase().indexOf(ql) === -1;
      return {
        type: 'add-class',
        key: name,
        label: '.' + name,
        group: group,
        q: query,
        icon: group === 'element' ? 'selection' : 'globe-simple',
        badge: fuzzy ? 'fuzzy' : (group === 'element' ? 'on element' : 'global'),
        detail: group === 'element' ? 'class used on selected element' : 'global class on the site',
        command: command,
        nextValue: command,
        caret: command.length,
        priority: priority
      };
    };

    var onEl = getClasses(app, element);
    var seen = {};
    var items = onEl.map(function (name) { seen[name] = true; return make(name, 'element', 20); });

    // Also suggest global classes defined anywhere on the site (not only those already on
    // the selected element), so you can apply an existing class you're not currently using.
    var globals = [];
    try {
      if (app.adapter && typeof app.adapter.getGlobalClasses === 'function') {
        globals = app.adapter.getGlobalClasses() || [];
      }
    } catch (e) { globals = []; }
    globals.forEach(function (g) {
      var name = g && g.name ? String(g.name) : '';
      if (name && !seen[name]) { seen[name] = true; items.push(make(name, 'global', 5)); }
    });

    return sortMatches(items, query).slice(0, 8);
  }

  function getSuggestions(app) {
    if (!app || app.mode !== 'default' || !app.input) return [];
    var value = String(app.input.value || '');
    if (!value.trim()) return [];

    if (app.mvIntegration && typeof app.mvIntegration.getSuggestions === 'function') {
      var mvSuggestions = app.mvIntegration.getSuggestions(app, value);
      if (mvSuggestions && mvSuggestions.length) return mvSuggestions;
    }

    var removeSuggestions = buildRemoveClassSuggestions(app, value);
    if (removeSuggestions.length) return removeSuggestions;

    var deleteSuggestions = buildDeleteSuggestions(app, value);
    if (deleteSuggestions.length) return deleteSuggestions;

    var classSuggestions = buildClassSuggestions(app, value);
    if (classSuggestions.length) return classSuggestions;

    var attributeSuggestions = buildAttributeSuggestions(app, value);
    if (attributeSuggestions.length) return attributeSuggestions;

    return [];
  }

  function render(app) {
    var container = app && app.commandSuggestions;
    if (!container) return [];

    var suggestions = getSuggestions(app);
    container.innerHTML = '';

    if (!suggestions.length) {
      container.hidden = true;
      app.activeCommandSuggestions = [];
      return suggestions;
    }

    if (typeof app.activeCommandSuggestionIndex !== 'number') app.activeCommandSuggestionIndex = 0;
    if (app.activeCommandSuggestionIndex < 0) app.activeCommandSuggestionIndex = 0;
    if (app.activeCommandSuggestionIndex >= suggestions.length) app.activeCommandSuggestionIndex = suggestions.length - 1;

    var lastGroup = null;
    suggestions.forEach(function (item, index) {
      if (item.group && item.group !== lastGroup) {
        lastGroup = item.group;
        var head = document.createElement('div');
        head.className = 'baqa-command-suggestion-group';
        head.textContent = item.group === 'element' ? 'On this element' : 'All classes on the site';
        container.appendChild(head);
      }
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'baqa-command-suggestion' + (index === app.activeCommandSuggestionIndex ? ' is-active' : '');
      button.setAttribute('data-type', item.type || '');
      var right;
      if (item.badge) {
        var badgeCls = item.badge === 'fuzzy' ? 'fuzzy' : (item.badge === 'global' ? 'global' : 'onel');
        right = '<em class="baqa-cmd-right"><i class="baqa-suggestion-badge baqa-badge-' + badgeCls + '">' + escapeHtml(item.badge) + '</i></em>';
      } else {
        right = '<em>' + escapeHtml(item.detail) + '</em>';
      }
      var labelHtml;
      if (item.type === 'add-class' && item.key) {
        var iconHtml = item.icon ? '<i class="ph-duotone ph-' + item.icon + ' baqa-suggestion-ic"></i>' : '';
        labelHtml = iconHtml + '<span class="baqa-suggestion-name">.' + highlightMatch(item.key, item.q) + '</span>';
      } else {
        labelHtml = escapeHtml(item.label);
      }
      button.innerHTML = '<span class="baqa-suggestion-lead">' + labelHtml + '</span>' + right;
      button.addEventListener('mouseenter', function () {
        app.activeCommandSuggestionIndex = index;
        render(app);
      });
      button.addEventListener('click', function (event) {
        event.preventDefault();
        app.activeCommandSuggestionIndex = index;
        accept(app, item);
      });
      container.appendChild(button);
    });

    container.hidden = false;
    app.activeCommandSuggestions = suggestions;
    return suggestions;
  }

  function clear(app) {
    if (!app) return;
    app.activeCommandSuggestions = [];
    app.activeCommandSuggestionIndex = 0;
    if (app.commandSuggestions) {
      app.commandSuggestions.hidden = true;
      app.commandSuggestions.innerHTML = '';
    }
  }

  function accept(app, item) {
    item = item || (app && app.activeCommandSuggestions && app.activeCommandSuggestions[typeof app.activeCommandSuggestionIndex === 'number' ? app.activeCommandSuggestionIndex : 0]) || (app && app.activeCommandSuggestions && app.activeCommandSuggestions[0]);
    if (!app || !app.input || !item || !item.command) return false;
    var value = item.nextValue || item.command;
    var caret = typeof item.caret === 'number' ? item.caret : value.length;
    app.input.value = value;
    app.input.focus();
    try { app.input.setSelectionRange(caret, caret); } catch (e) { app.input.setSelectionRange(value.length, value.length); }
    clear(app);
    if (typeof app.updateTabHint === 'function') app.updateTabHint();
    return true;
  }

  function move(app, delta) {
    if (!app) return false;
    var list = app.activeCommandSuggestions || render(app) || [];
    if (!list.length) return false;
    var index = typeof app.activeCommandSuggestionIndex === 'number' ? app.activeCommandSuggestionIndex : 0;
    index += delta;
    if (index < 0) index = list.length - 1;
    if (index >= list.length) index = 0;
    app.activeCommandSuggestionIndex = index;
    render(app);
    return true;
  }

  function hasSuggestions(app) {
    return !!(app && app.activeCommandSuggestions && app.activeCommandSuggestions.length);
  }

  var CommandSuggestions = {
    getSuggestions: getSuggestions,
    render: render,
    clear: clear,
    accept: accept,
    move: move,
    hasSuggestions: hasSuggestions
  };

  window.MimamsBarCommandSuggestions = CommandSuggestions;
  window.MimamsBar = window.MimamsBar || {};
  window.MimamsBar.CommandSuggestions = CommandSuggestions;
})();
