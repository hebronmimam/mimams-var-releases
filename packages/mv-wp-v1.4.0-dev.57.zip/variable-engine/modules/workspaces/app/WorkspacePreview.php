<?php
/**
 * Private preview for a workspace's structural objects.
 *
 * SLICE 3 of the Workspaces plan. §18 asks for a preview where "public visitors
 * receive Live state, the workspace user receives workspace effective state",
 * where the preview "cannot poison public caches", is noindex, and where tokens
 * expire and can be revoked.
 *
 * §18 also says a shareable link "is not required for the first technical
 * proof", and this slice takes that permission deliberately: a preview needs
 * **both** a valid token **and** a user who could have edited the object anyway.
 * That makes "public visitors receive Live state" true by construction rather
 * than by a rule that has to be got right, and it means a leaked link is worth
 * nothing on its own. Sharing to logged-out reviewers is slice 3's successor,
 * not slice 3.
 *
 * Fail-closed, per §100 and §98. Every way this can go wrong - no module, no
 * capability, unknown token, expired token, revoked token, missing shadow -
 * ends in the same 404 with the same empty body. A preview that explains why it
 * refused tells an anonymous caller which tokens exist.
 *
 * Tokens are stored as **hashes**. A database read cannot mint a working link,
 * only invalidate one, which is the failure worth having.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspacePreview {

    /** Where the issued tokens live. Small, pruned on every write. */
    public const OPTION = 've_workspace_preview_tokens';

    /** §18: "preview tokens must expire". Fifteen minutes, and re-issuing is free. */
    public const TTL = 900;

    /** A ceiling so a runaway caller cannot grow the option without bound. */
    public const MAX_TOKENS = 200;

    /**
     * The workspace-effective object for a live object.
     *
     * This is the whole of "workspace-effective" at slice 3: a structural object
     * IS its shadow, because Bricks writes to the post id it was opened with.
     * Runtime families (global classes, variables, theme styles) have no
     * workspace-effective state yet and this must not pretend otherwise - it
     * answers only for objects the map actually holds.
     *
     * @return int Shadow post id, or 0 when the workspace does not hold it.
     */
    public static function effective_object_id( int $workspace_id, int $live_id ): int {
        if ( $workspace_id <= 0 || $live_id <= 0 ) {
            return 0;
        }
        $row = WorkspaceObjectMap::find( $workspace_id, $live_id );
        return $row ? (int) $row['shadow_id'] : 0;
    }

    /**
     * Issue a preview token for one mapped object.
     *
     * @return array|\WP_Error { token, url, expires }
     */
    public static function issue( int $object_id, int $ttl = self::TTL ) {
        $row = WorkspaceObjectMap::get( $object_id );
        if ( ! $row ) {
            return new \WP_Error( 've_object_missing', 'That object is not in a workspace.', [ 'status' => 404 ] );
        }
        $shadow = (int) $row['shadow_id'];
        if ( $shadow <= 0 || ! get_post( $shadow ) ) {
            return new \WP_Error( 've_shadow_missing', 'That workspace copy no longer exists.', [ 'status' => 404 ] );
        }

        $ttl   = max( 60, min( 86400, $ttl ) );
        $token = bin2hex( random_bytes( 16 ) );
        $now   = time();

        $tokens = self::read();
        $tokens[ self::fingerprint( $token ) ] = [
            'object'  => $object_id,
            'shadow'  => $shadow,
            'expires' => $now + $ttl,
            'issued'  => $now,
            'by'      => get_current_user_id(),
        ];
        self::write( $tokens );

        return [
            'token'   => $token,
            'url'     => self::url( $token ),
            'expires' => $now + $ttl,
        ];
    }

    /**
     * Resolve a token to the object it previews, or false.
     *
     * Every refusal returns the same false. The caller has no way to tell an
     * unknown token from an expired one from a missing capability, which is the
     * point: "reveal less on failure, not more".
     *
     * @return array|false
     */
    public static function verify( $token ) {
        if ( ! is_string( $token ) || ! preg_match( '/^[a-f0-9]{32}$/', $token ) ) {
            return false;
        }
        if ( class_exists( __NAMESPACE__ . '\WorkspacesModule' )
            && WorkspacesModule::is_disabled() ) {
            return false;
        }

        $tokens = self::read();
        $key    = self::fingerprint( $token );
        if ( ! isset( $tokens[ $key ] ) ) {
            return false;
        }
        $record = $tokens[ $key ];
        if ( (int) $record['expires'] <= time() ) {
            return false;
        }

        $shadow = (int) $record['shadow'];
        if ( $shadow <= 0 || ! get_post( $shadow ) ) {
            return false;
        }
        /* The token is necessary and not sufficient. Slice 3 previews are for
           someone who could have opened the object in the builder anyway. */
        if ( ! current_user_can( 'edit_post', $shadow ) ) {
            return false;
        }
        return $record;
    }

    /** @return int How many tokens were withdrawn. */
    public static function revoke( $token ): int {
        if ( ! is_string( $token ) || '' === $token ) {
            return 0;
        }
        $tokens = self::read();
        $key    = self::fingerprint( $token );
        if ( ! isset( $tokens[ $key ] ) ) {
            return 0;
        }
        unset( $tokens[ $key ] );
        self::write( $tokens );
        return 1;
    }

    /** Withdraw every link ever issued for one object. */
    public static function revoke_object( int $object_id ): int {
        $tokens  = self::read();
        $removed = 0;
        foreach ( $tokens as $key => $record ) {
            if ( (int) $record['object'] === $object_id ) {
                unset( $tokens[ $key ] );
                $removed++;
            }
        }
        if ( $removed ) {
            self::write( $tokens );
        }
        return $removed;
    }

    /** How many live links this object has, for the panel to show. */
    public static function count_for_object( int $object_id ): int {
        $now   = time();
        $count = 0;
        foreach ( self::read() as $record ) {
            if ( (int) $record['object'] === $object_id && (int) $record['expires'] > $now ) {
                $count++;
            }
        }
        return $count;
    }

    /** The address a token is redeemed at. */
    public static function url( string $token ): string {
        return rest_url( VE_API_NAMESPACE . '/workspaces/preview/' . $token );
    }

    /**
     * Headers every preview response carries, valid or not.
     *
     * §18: a preview "cannot poison public caches" and "must be noindex". These
     * go on the refusal as well as the success - a 404 that a shared cache keeps
     * is its own small bug, and a refusal is exactly the response most likely to
     * be cached by something in front of WordPress.
     */
    public static function send_headers(): void {
        if ( headers_sent() ) {
            return;
        }
        header( 'Cache-Control: private, no-store, no-cache, max-age=0' );
        header( 'Pragma: no-cache' );
        header( 'X-Robots-Tag: noindex, nofollow, noarchive' );
        header( 'Vary: Cookie' );
    }

    // ── internals ──────────────────────────────────────────────────────────

    /**
     * What is stored instead of the token.
     *
     * Keyed on the site's own salt so a copy of the table taken to another
     * install matches nothing there either.
     */
    private static function fingerprint( string $token ): string {
        return hash_hmac( 'sha256', $token, wp_salt( 'auth' ) );
    }

    private static function read(): array {
        $tokens = get_option( self::OPTION, [] );
        return is_array( $tokens ) ? $tokens : [];
    }

    /**
     * Expired tokens are dropped on every write rather than by a schedule: the
     * option is only touched when someone issues or revokes, so there is no
     * moment where pruning is owed and nothing is running to do it.
     */
    private static function write( array $tokens ): void {
        $now  = time();
        $kept = [];
        foreach ( $tokens as $key => $record ) {
            if ( isset( $record['expires'] ) && (int) $record['expires'] > $now ) {
                $kept[ $key ] = $record;
            }
        }
        if ( count( $kept ) > self::MAX_TOKENS ) {
            uasort( $kept, static function ( $a, $b ) {
                return (int) $b['issued'] <=> (int) $a['issued'];
            } );
            $kept = array_slice( $kept, 0, self::MAX_TOKENS, true );
        }
        update_option( self::OPTION, $kept, false );
    }
}
