<?php

namespace VE\Modules\Recovery\Backup;

defined( 'ABSPATH' ) || exit;

/**
 * Mandatory at-rest encryption for persisted backup packages (AES-256-GCM).
 *
 * A backup contains the full database — user password hashes, secret keys, and
 * customer data. When a passphrase is set, the package file is wrapped so it is
 * useless without the passphrase, protecting it in cloud storage / transit.
 *
 * Format (streamed, chunked so large packages never load into memory):
 *   magic:  "RBENC1\n"                         (7 bytes)
 *   header: salt(16) | base_iv(12) | flags(1)  (29 bytes)
 *   frames: [uint32 LE cipher_len][cipher][tag(16)] ...   (per 1 MiB plaintext)
 *   end:    uint32 LE 0
 *
 * Key derivation: PBKDF2-HMAC-SHA256(passphrase, salt, 120000) -> 32 bytes.
 * Each frame uses base_iv with its 4-byte counter XORed into the low bytes, so
 * no (key, iv) pair repeats within a package.
 *
 * An agency passphrase remains supported for portable packages. Otherwise a
 * site-bound secret derived from WordPress salts protects local packages.
 */
final class PackageCipher {
    private const MAGIC     = "RBENC1\n";
    private const CHUNK     = 1048576; // 1 MiB plaintext frames
    private const ITER      = 120000;
    private const SALT_LEN  = 16;
    private const IV_LEN    = 12;
    private const TAG_LEN   = 16;

    public static function available(): bool {
        return function_exists( 'openssl_encrypt' )
            && in_array( 'aes-256-gcm', array_map( 'strtolower', openssl_get_cipher_methods() ), true );
    }

    public static function is_encrypted( string $path ): bool {
        if ( '' === $path || ! is_readable( $path ) ) {
            return false;
        }
        $fh = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        if ( ! is_resource( $fh ) ) {
            return false;
        }
        $magic = fread( $fh, strlen( self::MAGIC ) );
        fclose( $fh );
        return self::MAGIC === $magic;
    }

    /** Encrypt $source into $dest. Returns [ok,message]. */
    public static function encrypt_file( string $source, string $dest, string $passphrase ): array {
        if ( ! self::available() ) {
            return [ 'ok' => false, 'message' => 'AES-256-GCM is not available on this PHP build.' ];
        }
        if ( '' === $passphrase ) {
            return [ 'ok' => false, 'message' => 'A passphrase is required to encrypt the package.' ];
        }
        $in = fopen( $source, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        $out = fopen( $dest, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        if ( ! is_resource( $in ) || ! is_resource( $out ) ) {
            if ( is_resource( $in ) ) { fclose( $in ); }
            if ( is_resource( $out ) ) { fclose( $out ); }
            return [ 'ok' => false, 'message' => 'Could not open package files for encryption.' ];
        }

        $salt    = random_bytes( self::SALT_LEN );
        $base_iv = random_bytes( self::IV_LEN );
        $key     = hash_pbkdf2( 'sha256', $passphrase, $salt, self::ITER, 32, true );

        fwrite( $out, self::MAGIC );
        fwrite( $out, $salt . $base_iv . chr( 0 ) );

        $counter = 0;
        while ( ! feof( $in ) ) {
            $plain = fread( $in, self::CHUNK );
            if ( '' === $plain || false === $plain ) {
                break;
            }
            $iv  = self::frame_iv( $base_iv, $counter );
            $tag = '';
            $cipher = openssl_encrypt( $plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag, '', self::TAG_LEN );
            if ( false === $cipher ) {
                fclose( $in ); fclose( $out );
                return [ 'ok' => false, 'message' => 'Encryption failed on a package frame.' ];
            }
            fwrite( $out, pack( 'V', strlen( $cipher ) ) . $cipher . $tag );
            $counter++;
        }
        fwrite( $out, pack( 'V', 0 ) );
        fclose( $in );
        fclose( $out );
        return [ 'ok' => true, 'message' => 'Package encrypted.', 'frames' => $counter ];
    }

    /** Decrypt $source into $dest. Wrong passphrase or tampering fails the GCM tag. */
    public static function decrypt_file( string $source, string $dest, string $passphrase ): array {
        if ( ! self::available() ) {
            return [ 'ok' => false, 'message' => 'AES-256-GCM is not available on this PHP build.' ];
        }
        $in = fopen( $source, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        if ( ! is_resource( $in ) ) {
            return [ 'ok' => false, 'message' => 'Could not open encrypted package.' ];
        }
        if ( self::MAGIC !== fread( $in, strlen( self::MAGIC ) ) ) {
            fclose( $in );
            return [ 'ok' => false, 'message' => 'Package is not RestoreBase-encrypted.' ];
        }
        $header = fread( $in, self::SALT_LEN + self::IV_LEN + 1 );
        if ( strlen( $header ) < self::SALT_LEN + self::IV_LEN + 1 ) {
            fclose( $in );
            return [ 'ok' => false, 'message' => 'Encrypted package header is truncated.' ];
        }
        $salt    = substr( $header, 0, self::SALT_LEN );
        $base_iv = substr( $header, self::SALT_LEN, self::IV_LEN );
        $key     = hash_pbkdf2( 'sha256', $passphrase, $salt, self::ITER, 32, true );

        $out = fopen( $dest, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        if ( ! is_resource( $out ) ) {
            fclose( $in );
            return [ 'ok' => false, 'message' => 'Could not open destination for decryption.' ];
        }

        $counter = 0;
        while ( true ) {
            $len_raw = fread( $in, 4 );
            if ( false === $len_raw || strlen( $len_raw ) < 4 ) {
                fclose( $in ); fclose( $out );
                return [ 'ok' => false, 'message' => 'Encrypted package ended unexpectedly.' ];
            }
            $len = (int) unpack( 'V', $len_raw )[1];
            if ( 0 === $len ) {
                break; // clean end marker
            }
            $cipher = fread( $in, $len );
            $tag    = fread( $in, self::TAG_LEN );
            if ( false === $cipher || strlen( $cipher ) < $len || false === $tag || strlen( $tag ) < self::TAG_LEN ) {
                fclose( $in ); fclose( $out );
                return [ 'ok' => false, 'message' => 'Encrypted package frame is corrupt.' ];
            }
            $iv    = self::frame_iv( $base_iv, $counter );
            $plain = openssl_decrypt( $cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
            if ( false === $plain ) {
                fclose( $in ); fclose( $out );
                @unlink( $dest ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
                return [ 'ok' => false, 'message' => 'Wrong passphrase or the package has been tampered with.' ];
            }
            fwrite( $out, $plain );
            $counter++;
        }
        fclose( $in );
        fclose( $out );
        return [ 'ok' => true, 'message' => 'Package decrypted.', 'frames' => $counter ];
    }

    /**
     * Resolved package passphrase, in order of how much it can be trusted.
     *
     * R37. The site key comes before the stored option, and the reason is the
     * whole point of R37: a package CONTAINS the database, so a key kept in
     * `wp_options` travels inside the thing it is supposed to protect. Anyone
     * holding the package holds the key. The site key lives in `wp-config.php`,
     * which no package carries.
     *
     * The option is still read, because sites that set one before this build
     * must keep working, and an agency passphrase for a package that has to
     * travel is still a legitimate thing to want.
     */
    public static function passphrase(): string {
        $stored = (string) get_option( 'restorebase_package_passphrase', '' );
        if ( '' === $stored && class_exists( '\\VE\\Modules\\Recovery\\Backup\\SiteKey' ) ) {
            $stored = SiteKey::current();
        }
        return (string) apply_filters( 'restorebase_package_passphrase', $stored );
    }

    public static function is_configured(): bool {
        return '' !== self::passphrase();
    }

    /** Passphrase used for local packages when no portable secret is configured. */
    public static function default_passphrase(): string {
        $configured = self::passphrase();
        if ( '' !== $configured ) {
            return $configured;
        }
        return hash_hmac( 'sha256', 'restorebase-package-encryption-v1', wp_salt( 'auth' ) );
    }

    /**
     * Return a readable path for a package, transparently decrypting to a temp file
     * when the package is encrypted. Callers must unlink the temp path (temp=true)
     * once done reading.
     *
     * @return array{ok:bool,path:string,temp:bool,encrypted:bool,message:string}
     */
    public static function resolve_readable( string $package_path, string $temp_dir = '', string $passphrase = '' ): array {
        if ( ! self::is_encrypted( $package_path ) ) {
            return [ 'ok' => true, 'path' => $package_path, 'temp' => false, 'encrypted' => false, 'message' => '' ];
        }
        // Explicit passphrase (entered inline in the restore flow) wins; otherwise
        // use the configured portable secret or this site's salt-bound secret.
        if ( '' === $passphrase ) {
            $passphrase = self::default_passphrase();
        }
        $dir = '' !== $temp_dir ? trailingslashit( $temp_dir ) : trailingslashit( sys_get_temp_dir() );
        if ( ! is_dir( $dir ) ) {
            wp_mkdir_p( $dir );
        }
        $dest = $dir . 'rb-decrypted-' . wp_generate_password( 10, false, false ) . '.zip';
        $res = self::decrypt_file( $package_path, $dest, $passphrase );
        if ( empty( $res['ok'] ) ) {
            return [ 'ok' => false, 'path' => '', 'temp' => false, 'encrypted' => true, 'needs_passphrase' => true, 'message' => (string) ( $res['message'] ?? 'Package decryption failed.' ) ];
        }
        return [ 'ok' => true, 'path' => $dest, 'temp' => true, 'encrypted' => true, 'message' => 'Package decrypted for reading.' ];
    }

    private static function frame_iv( string $base_iv, int $counter ): string {
        // XOR the 32-bit counter into the last 4 bytes of the base IV.
        $ctr = pack( 'N', $counter );
        $iv  = $base_iv;
        for ( $i = 0; $i < 4; $i++ ) {
            $pos = self::IV_LEN - 4 + $i;
            $iv[ $pos ] = chr( ord( $iv[ $pos ] ) ^ ord( $ctr[ $i ] ) );
        }
        return $iv;
    }
}
