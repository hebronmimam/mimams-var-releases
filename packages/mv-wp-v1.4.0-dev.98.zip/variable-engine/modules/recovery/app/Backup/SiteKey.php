<?php

namespace VE\Modules\Recovery\Backup;

defined( 'ABSPATH' ) || exit;

/**
 * The key a site encrypts its own packages with, kept out of the database.
 *
 * R37. The owner asked the right question - "why not just make it compulsory to
 * encrypt backup, and then remove the option to turn encrypt off" - and it is
 * the better default. An unencrypted package is a plaintext copy of the
 * database: users, e-mail addresses, password hashes, API keys sitting in
 * options. It lives in `wp-content/uploads` behind an unguessable filename, and
 * "unguessable" is not "protected".
 *
 * Two things stood in the way, and this is the answer to both:
 *
 * 1. **A lost passphrase used to mean a lost backup.** So MV makes the key
 *    itself, rather than asking anybody to invent one, and it is the same key
 *    every time on this site - so restoring your own backup never asks for it.
 * 2. **The key must not live in the database.** A database dump is exactly what
 *    the package contains, so a key stored in `wp_options` travels inside the
 *    thing it is supposed to protect. It goes in `wp-config.php`, which is the
 *    one file WordPress already treats as the place for secrets and the one
 *    file a package never carries.
 *
 * If `wp-config.php` cannot be written, nothing is invented in its place: the
 * line is handed back for the owner to paste. A key written somewhere weaker
 * than wp-config would be a worse answer pretending to be the same one.
 */
final class SiteKey {

    public const CONSTANT = 'RESTOREBASE_KEY';

    /** Where wp-config.php is, allowing for the "one level up" layout. */
    public static function config_path(): string {
        $direct = trailingslashit( ABSPATH ) . 'wp-config.php';
        if ( file_exists( $direct ) ) {
            return $direct;
        }
        // WordPress itself accepts wp-config.php one directory above ABSPATH, as
        // long as that directory holds no other WordPress install.
        $above = trailingslashit( dirname( trailingslashit( ABSPATH ) ) ) . 'wp-config.php';
        if ( file_exists( $above ) && ! file_exists( trailingslashit( dirname( trailingslashit( ABSPATH ) ) ) . 'wp-settings.php' ) ) {
            return $above;
        }
        return $direct;
    }

    /** The key this site already has, from wherever it legitimately lives. */
    public static function current(): string {
        if ( defined( self::CONSTANT ) ) {
            $value = (string) constant( self::CONSTANT );
            if ( '' !== trim( $value ) ) {
                return trim( $value );
            }
        }
        return '';
    }

    public static function exists(): bool {
        return '' !== self::current();
    }

    /** A new key. Not a password anybody has to remember, so it is not one. */
    public static function generate(): string {
        try {
            return 'rb_' . bin2hex( random_bytes( 24 ) );
        } catch ( \Throwable $e ) {
            // wp_generate_password is seeded well enough to be a fallback, and a
            // site without a CSPRNG has bigger problems than this line.
            return 'rb_' . strtolower( wp_generate_password( 48, false, false ) );
        }
    }

    /** The line that has to be in wp-config.php, ready to paste. */
    public static function line( string $key ): string {
        return "define( '" . self::CONSTANT . "', '" . $key . "' );";
    }

    /**
     * Put a key in wp-config.php, or explain exactly why it could not be.
     *
     * Never partially written: the whole file is composed in memory, written,
     * and read back before this reports success. A wp-config.php left half
     * rewritten takes the site down, and no backup feature is worth that.
     *
     * @return array{ok:bool,key:string,written:bool,path:string,line:string,message:string}
     */
    public static function install( string $key = '' ): array {
        $existing = self::current();
        if ( '' !== $existing ) {
            return [
                'ok'      => true,
                'key'     => $existing,
                'written' => false,
                'path'    => self::config_path(),
                'line'    => self::line( $existing ),
                'message' => 'This site already has a recovery key.',
            ];
        }

        $key  = '' !== trim( $key ) ? trim( $key ) : self::generate();
        $path = self::config_path();
        $line = self::line( $key );

        if ( ! file_exists( $path ) || ! is_readable( $path ) ) {
            return [
                'ok' => false, 'key' => $key, 'written' => false, 'path' => $path, 'line' => $line,
                'message' => 'wp-config.php could not be found. Add the line below to it yourself.',
            ];
        }
        if ( ! is_writable( $path ) ) {
            return [
                'ok' => false, 'key' => $key, 'written' => false, 'path' => $path, 'line' => $line,
                'message' => 'wp-config.php is not writable. Add the line below to it yourself.',
            ];
        }

        $source = file_get_contents( $path );
        if ( ! is_string( $source ) || '' === $source ) {
            return [
                'ok' => false, 'key' => $key, 'written' => false, 'path' => $path, 'line' => $line,
                'message' => 'wp-config.php could not be read. Add the line below to it yourself.',
            ];
        }
        if ( false !== strpos( $source, self::CONSTANT ) ) {
            return [
                'ok' => false, 'key' => $key, 'written' => false, 'path' => $path, 'line' => $line,
                'message' => 'wp-config.php already mentions ' . self::CONSTANT . '. It was left alone.',
            ];
        }

        $updated = self::compose( $source, $line );
        if ( null === $updated ) {
            return [
                'ok' => false, 'key' => $key, 'written' => false, 'path' => $path, 'line' => $line,
                'message' => 'This wp-config.php is not shaped the way MV can edit safely. Add the line below yourself.',
            ];
        }

        $wrote = file_put_contents( $path, $updated, LOCK_EX );
        if ( false === $wrote ) {
            return [
                'ok' => false, 'key' => $key, 'written' => false, 'path' => $path, 'line' => $line,
                'message' => 'wp-config.php could not be written. Add the line below yourself.',
            ];
        }

        // Read it back. A write that reported success and did not land is the
        // one failure that would be discovered at restore time.
        $check = file_get_contents( $path );
        if ( ! is_string( $check ) || false === strpos( $check, $line ) ) {
            return [
                'ok' => false, 'key' => $key, 'written' => false, 'path' => $path, 'line' => $line,
                'message' => 'The key did not survive the write. Add the line below yourself.',
            ];
        }

        return [
            'ok' => true, 'key' => $key, 'written' => true, 'path' => $path, 'line' => $line,
            'message' => 'A recovery key was written to wp-config.php. Keep a copy of it.',
        ];
    }

    /**
     * Where the line goes: above WordPress's own "stop editing" marker, which is
     * where every constant belongs, and never after `require_once ABSPATH`.
     *
     * @return string|null null when the file has no place this can go safely.
     */
    public static function compose( string $source, string $line ): ?string {
        $eol = false !== strpos( $source, "\r\n" ) ? "\r\n" : "\n";
        $block = $eol . '/* Added by Mimam\'s Var Recovery: the key this site encrypts its backups with.' . $eol
            . '   Keep a copy somewhere other than this server. Without it an encrypted' . $eol
            . '   package cannot be opened, by anyone. */' . $eol . $line . $eol;

        // WordPress's own marker, in the several spellings it has shipped with.
        foreach ( [ "/* That's all, stop editing!", '/* That\'s all, stop editing!', '/** Sets up WordPress vars' ] as $marker ) {
            $at = strpos( $source, $marker );
            if ( false !== $at ) {
                return substr( $source, 0, $at ) . ltrim( $block, "\r\n" ) . $eol . substr( $source, $at );
            }
        }

        // No marker: before the line that loads WordPress, which is the last
        // moment a constant can still be defined in time.
        if ( preg_match( '/^\s*require(_once)?[\s(]+ABSPATH/mi', $source, $m, PREG_OFFSET_CAPTURE ) ) {
            $at = (int) $m[0][1];
            return substr( $source, 0, $at ) . ltrim( $block, "\r\n" ) . $eol . substr( $source, $at );
        }

        return null;
    }
}
