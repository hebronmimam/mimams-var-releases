const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const pluginRoot = path.resolve(__dirname, '..');
const moduleRoot = path.join(pluginRoot, 'modules', 'builder-tools', 'mimams-bar', 'assets', 'js', 'modules');
const listeners = {};
const context = {
  console,
  Date,
  Math,
  JSON,
  Array,
  Object,
  String,
  Number,
  Boolean,
  RegExp,
  Promise,
  setTimeout,
  clearTimeout,
  CustomEvent: function CustomEvent(type, options) {
    this.type = type;
    this.detail = options && options.detail;
  },
  window: {
    baqaConfig: {
      savedAttributes: [{ name: 'data-aos', value: 'fade-up' }],
      apiRoot: 'https://example.test/wp-json/',
      nonce: 'test'
    },
    addEventListener: function (name, callback) { listeners[name] = callback; },
    dispatchEvent: function () {},
    fetch: async function () {
      return {
        ok: true,
        json: async function () {
          return { saved_attributes: [{ name: 'data-aos', value: 'fade-up' }] };
        }
      };
    },
    setTimeout,
    clearTimeout
  }
};
context.window.window = context.window;
context.window.CustomEvent = context.CustomEvent;
vm.createContext(context);

function loadModule(file) {
  const source = fs.readFileSync(path.join(moduleRoot, file), 'utf8');
  vm.runInContext(source, context, { filename: file });
}

loadModule('saved-attribute-manager.js');
loadModule('command-suggestion-manager.js');

const savedAttributes = context.window.MimamsBarSavedAttributes;
const suggestions = context.window.MimamsBarCommandSuggestions;
assert(savedAttributes, 'Saved attribute manager should load.');
assert(suggestions, 'Command suggestions should load.');

const selected = { id: 'one', settings: { _attributes: [{ name: 'aria-label', value: 'Hero' }] } };
const other = { id: 'two', settings: { _attributes: [{ name: 'data-theme', value: 'dark' }] } };
const adapter = {
  getSelectedElement: function () { return selected; },
  getElementAttributes: function (element) { return element.settings._attributes; },
  getAllElements: function () { return [selected, other]; },
  getElementClasses: function () { return []; }
};
const input = {
  value: 'd',
  focus: function () {},
  setSelectionRange: function (start, end) {
    this.selectionStart = start;
    this.selectionEnd = end;
  }
};
const app = {
  mode: 'default',
  input,
  adapter,
  savedAttributes,
  activeCommandSuggestionIndex: 0
};

const matches = suggestions.getSuggestions(app);
const saved = matches.find(function (item) {
  return item.group === 'saved' && item.key === 'data-aos';
});
assert(saved, 'Saved group should include the site-level saved attribute.');
assert.strictEqual(saved.value, 'fade-up');
assert(matches.some(function (item) {
  return item.group === 'site' && item.key === 'data-theme' && item.value === 'dark';
}), 'Used-elsewhere group should include another element attribute and its value.');

suggestions.accept(app, saved);
assert.strictEqual(input.value, 'data-aos="fade-up"', 'Saved suggestion should prefill name and value.');
assert.strictEqual(input.selectionStart, 10, 'Saved value selection should start inside the quotes.');
assert.strictEqual(input.selectionEnd, 17, 'Saved value selection should cover the stored value.');

/* R11, the cause. A record handed to the store at load time came back BLANK:
   the cap the normaliser compares against was declared below the line that
   loads the store, so `out.length < VALUES_PER_NAME` compared against undefined
   and every value was dropped. Saving later worked, which is why the owner
   found it "only until I restarred it". The assertion above this one covers it
   through the suggestion list; this one names it, so a future reorder of the
   file fails here with the reason rather than three layers away. */
{
  const raw = fs.readFileSync(path.join(moduleRoot, 'saved-attribute-manager.js'), 'utf8');
  assert(
    raw.indexOf('var VALUES_PER_NAME') < raw.indexOf('var items = normalizeList('),
    'VALUES_PER_NAME must be assigned before the store is first normalised - hoisting declares it, it does not assign it, and an undefined cap silently drops every value.'
  );
}

/* R11 - 2026-09-05. "it was only until I restarred it started working. I want
   it all to work whether I restar or not, as far as it's already been starred."
   A pair starred with no value beside it is BLANK ON DISK; no amount of
   normalising can recover a value that was never written. The site index knows
   it, and the saved entry was shadowing that entry because it is added first
   and add() dedupes by name. Re-injecting the blank record is what makes this
   test fail without the fix. */
{
  const blankStar = { name: 'data-theme', value: '', values: [''] };
  const withBlank = Object.create(savedAttributes);
  withBlank.getAll = function () { return [{ name: 'data-aos', value: 'fade-up', values: ['fade-up'] }, blankStar]; };
  const byValue = suggestions.getSuggestions({
    mode: 'default',
    adapter: adapter,
    savedAttributes: withBlank,
    activeCommandSuggestionIndex: 0,
    input: { value: 'dark', focus: function () {}, setSelectionRange: function () {} }
  });
  const found = byValue.find(function (item) { return item.key === 'data-theme'; });
  assert(found, 'A name starred with no value must still be findable by the value the site uses it with - without re-starring it.');
  assert.strictEqual(found.value, 'dark', 'The borrowed value is the one the site actually holds.');
  assert(found.searchKeys.indexOf('dark') !== -1, 'and it must be a search key, or the filter drops it again.');
}

/* R17 - the typed characters were being marked adrift in a second word:
   `data-anim-mobile individual` with `ind` lit in the middle of it, while every
   other row marks inside the name. The value is quoted onto the name now, which
   is also exactly what the suggestion inserts. Asserted against the source: the
   label is built as a string and there is no DOM here to render it into. */
{
  const csm = fs.readFileSync(path.join(moduleRoot, 'command-suggestion-manager.js'), 'utf8');
  const label = csm.slice(csm.indexOf("item.type === 'set-attribute' && item.key"));
  assert(
    /baqa-suggestion-value">="' \+ highlightMatch\(item\.value, item\.q\) \+ '"<\/small>/.test(label),
    'A value shown beside its name must be quoted onto it, so the mark reads as a value and not as a second word.'
  );
}

loadModule('app-controller.js');

let restoredToken = null;
let inputFocused = 0;
let refreshed = 0;
const noop = function () {};
const controller = context.window.MimamsBarAppController.create({
  Parser: {},
  BricksAdapter: {
    applyAttributes: function () { return { ok: true }; },
    getSelectedElement: function () { return selected; }
  },
  Settings: { isAutoClose: function () { return false; } },
  Toast: { show: noop },
  FieldAssist: {},
  ElementSearch: {},
  EverythingManager: {},
  Emmet: {},
  MVIntegration: {},
  SavedAttributes: savedAttributes,
  CommandSuggestions: { clear: noop },
  Bulk: {},
  Dialogs: {},
  UIRenderer: {
    restoreTokenFocus: function (panel, token) {
      restoredToken = token;
      return true;
    }
  },
  OperationManager: {
    getApplyFailure: function () { return null; },
    getApplySuccessMessage: function () { return ''; }
  },
  PanelManager: {},
  ModeManager: {},
  AppShell: {},
  InputManager: {},
  TargetManager: { refresh: function () { refreshed += 1; } },
  GlobalEvents: {},
  labels: {}
});
controller.panel = {};
controller.input = { value: 'old', focus: function () { inputFocused += 1; } };
controller.hideError = noop;
controller.updateTabHint = noop;
controller._pendingTokenFocus = { kind: 'attribute', key: 'data-aos' };
controller.applyOperations([]);

setTimeout(function () {
  assert.deepStrictEqual(
    JSON.parse(JSON.stringify(restoredToken)),
    { kind: 'attribute', key: 'data-aos' },
    'Inline save should restore focus to the edited token.'
  );
  assert.strictEqual(inputFocused, 0, 'The trailing command field should not steal focus after inline save.');
  assert.strictEqual(refreshed, 1, 'The token rail should refresh once after apply.');
  console.log("Mimam's Bar saved attribute and post-save focus contracts passed.");
}, 15);
