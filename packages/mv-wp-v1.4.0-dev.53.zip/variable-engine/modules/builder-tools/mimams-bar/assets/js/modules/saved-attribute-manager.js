(function () {
  'use strict';

  if (window.MimamsBarFrameBridge || window.MimamsBarSavedAttributes) return;

  var config = window.baqaConfig || (window.MimamsBarCore && window.MimamsBarCore.config) || {};
  var VALUES_PER_NAME = 20;

  /* This line runs the normaliser, so VALUES_PER_NAME has to be ASSIGNED above
     it and not merely hoisted. It used to be declared further down, so at this
     point it was `undefined` and `out.length < VALUES_PER_NAME` was false on the
     very first comparison - every value was dropped and every record loaded at
     startup came back blank. Saving later worked, because by then the assignment
     had run. That is exactly what the owner saw: "it was only until I restarred
     it started working" (R11). */
  var items = normalizeList(config.savedAttributes || []);
  var writeChain = Promise.resolve();

  function normalizeName(value) {
    value = String(value == null ? '' : value).trim();
    return /^[A-Za-z_:][A-Za-z0-9:._-]*$/.test(value) ? value : '';
  }

  /* A name holds SEVERAL values, newest first. It used to hold one, keyed by
     name alone, so starring data-anim="fade-up" after data-anim="stagger-group"
     silently replaced it and you ended up with as many rows as you had distinct
     names - which is what R9 reported. `value` stays as the primary so every
     existing reader keeps working, and it is always values[0]. The suggestion
     layer has read `values` all along; nothing ever filled it. */

  function normalizeValues(item) {
    var out = [];
    var push = function (v) {
      v = String(v == null ? '' : v).trim().slice(0, 500);
      if (out.indexOf(v) === -1 && out.length < VALUES_PER_NAME) out.push(v);
    };
    // `value` first: it is the primary, and an old record has only that.
    if (item.value !== undefined) push(item.value);
    if (Array.isArray(item.values)) item.values.forEach(push);
    /* A blank carries no information once a real value is known - the same
       rule mergeValues has always applied, which was never applied here. A
       record arriving as {name, values:['970']} with no `value` beside it
       normalised to value:'' with '970' behind it, and the primary is what
       every reader keys on. */
    if (out.length > 1) out = out.filter(function (v) { return v !== ''; });
    if (!out.length) out.push('');
    return out;
  }

  function normalizeItem(item) {
    if (!item || typeof item !== 'object') return null;
    var name = normalizeName(item.name);
    if (!name) return null;
    var values = normalizeValues(item);
    return { name: name, value: values[0], values: values };
  }

  function mergeValues(into, from) {
    var values = into.values.slice();
    from.values.forEach(function (v) {
      if (values.indexOf(v) === -1 && values.length < VALUES_PER_NAME) values.push(v);
    });
    // A blank carries no information once a real value is known for the name.
    if (values.length > 1) values = values.filter(function (v) { return v !== ''; });
    return { name: into.name, value: values[0], values: values };
  }

  function normalizeList(list) {
    var next = [];
    (Array.isArray(list) ? list : []).forEach(function (item) {
      var clean = normalizeItem(item);
      if (!clean) return;
      var existing = next.findIndex(function (saved) { return saved.name === clean.name; });
      // Two records for one name are merged, not overwritten - overwriting is
      // how the values were being lost in the first place.
      if (existing >= 0) next[existing] = mergeValues(next[existing], clean);
      else if (next.length < 100) next.push(clean);
    });
    return next;
  }

  function copyItems() {
    return items.map(function (item) {
      return { name: item.name, value: item.value, values: item.values.slice() };
    });
  }

  function emit() {
    var detail = copyItems();
    try {
      window.dispatchEvent(new CustomEvent('ve-saved-attributes-changed', { detail: detail }));
    } catch (e) {}
  }

  function endpoint() {
    var root = String(config.apiRoot || (window.vePanel && window.vePanel.apiRoot) || '').replace(/\/?$/, '/');
    return root ? root + 'variable-engine/v1/settings' : '';
  }

  function persist(next) {
    var url = endpoint();
    if (!url || !window.fetch) return Promise.resolve(copyItems());
    var nonce = config.nonce || (window.vePanel && window.vePanel.nonce) || '';
    writeChain = writeChain.catch(function () {}).then(function () {
      return window.fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': nonce
        },
        body: JSON.stringify({ saved_attributes: next })
      }).then(function (response) {
        if (!response || !response.ok) throw new Error('Saved attributes could not be updated.');
        return response.json();
      }).then(function (response) {
        if (response && Array.isArray(response.saved_attributes)) {
          items = normalizeList(response.saved_attributes);
          config.savedAttributes = copyItems();
          emit();
        }
        return copyItems();
      });
    });
    return writeChain;
  }

  function setAll(list, shouldPersist) {
    var previous = copyItems();
    items = normalizeList(list);
    config.savedAttributes = copyItems();
    emit();
    if (shouldPersist === false) return Promise.resolve(copyItems());
    return persist(copyItems()).catch(function (error) {
      items = previous;
      config.savedAttributes = copyItems();
      emit();
      throw error;
    });
  }

  function find(name) {
    name = normalizeName(name);
    if (!name) return null;
    return items.find(function (item) { return item.name === name; }) || null;
  }

  // isSaved(name) still answers "is this name saved at all", which is what the
  // suggestion rows that know no value ask. With a value it answers for the pair.
  function isSavedPair(name, value) {
    var item = find(name);
    if (!item) return false;
    if (value === undefined) return true;
    return item.values.indexOf(String(value == null ? '' : value).trim().slice(0, 500)) !== -1;
  }

  /* Saving puts this value at the FRONT of the name's list rather than over
     the top of whatever was there. Starring it again just moves it up. */
  function save(name, value) {
    var clean = normalizeItem({ name: name, value: value });
    if (!clean) return Promise.reject(new Error('Use a valid attribute name.'));
    var next = copyItems();
    var index = next.findIndex(function (item) { return item.name === clean.name; });
    if (index < 0) next.push(clean);
    else {
      var values = [clean.value].concat(next[index].values.filter(function (v) {
        return v !== clean.value && v !== '';
      })).slice(0, VALUES_PER_NAME);
      next[index] = { name: clean.name, value: values[0], values: values };
    }
    return setAll(next);
  }

  /* With a value, only that value is unstarred, and the name goes only when it
     was the last one. Without a value the whole name goes, which is what the
     Settings row and every older caller mean. */
  function remove(name, value) {
    name = normalizeName(name);
    if (!name) return Promise.resolve(copyItems());
    if (value === undefined) {
      return setAll(items.filter(function (item) { return item.name !== name; }));
    }
    var want = String(value == null ? '' : value).trim().slice(0, 500);
    var next = [];
    items.forEach(function (item) {
      if (item.name !== name) { next.push(item); return; }
      var values = item.values.filter(function (v) { return v !== want; });
      if (values.length) next.push({ name: item.name, value: values[0], values: values });
    });
    return setAll(next);
  }

  function toggle(name, value) {
    // The star sits on one name AND value, so that pair is what it answers for.
    return isSavedPair(name, value) ? remove(name, value) : save(name, value);
  }

  window.addEventListener('ve-saved-attributes-changed', function (event) {
    if (!event || !Array.isArray(event.detail)) return;
    var next = normalizeList(event.detail);
    if (JSON.stringify(next) === JSON.stringify(items)) return;
    items = next;
    config.savedAttributes = copyItems();
  });

  window.MimamsBarSavedAttributes = {
    getAll: copyItems,
    find: find,
    isSaved: function (name, value) { return isSavedPair(name, value); },
    save: save,
    remove: remove,
    toggle: toggle,
    setAll: setAll,
    normalizeList: normalizeList
  };
})();
