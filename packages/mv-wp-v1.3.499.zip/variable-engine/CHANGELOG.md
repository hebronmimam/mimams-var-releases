## v1.3.499 — Update decision dock and contained Quiet cross

- Routine plugin installs stay in a corner progress pill; failures and successful installs open the named step ledger when a decision is needed.
- Successful installs show current release notes and require an explicit Reload the builder or Later choice.
- Theme Styles T/R/B/L fields now share one responsive width and stay inside narrow panels.

## v1.3.498 — Complete Quiet cross interaction

- Restored equal edge inputs, separate resting number/unit presentation, focus editing, unit-aware scrubbing, fill, explicit units and linked propagation.

## v1.3.497 — Quiet cross and Calendar Unscheduled rail

- Added the approved Theme Styles Quiet cross and Content Studio Calendar's draggable Unscheduled rail.

## v1.3.496 — Delayed module-state responses stay stale

- Prevented older Settings responses from restoring a module after a newer toggle.

## v1.3.495 — Immediate module state and Site Visibility handoff

- Applied module switches immediately and repaired the Bricks Settings Site Visibility handoff.

## v1.3.494 — CSS Studio can close and the shared picker stays canonical

- CSS Studio's unsaved-change confirmation now sits above the Studio backdrop and panel, keeping its discard/keep-editing actions clickable from both backdrop and header-close requests.
- Content Studio no longer overrides the shared colour picker's format buttons; the selected format, dimensions and light/dark styling match the canonical component.

## v1.3.493 — Shared autocomplete and reliable module switches

- Every MV CSS editor shares one preloaded autocomplete index that refreshes after variable changes without duplicate concurrent requests.
- Admin and Builder module switches apply an explicit atomic surface update, so enabling CSS Recipes or another module does not overwrite the other rail.

## v1.3.492 — Public framework variables return to autocomplete

- Variables explicitly registered in Bricks/Advanced Themer, Core Framework and Automatic.css are suggested alongside MV and CSS Studio variables.
- Provider variables preserve their literal CSS names and do not collapse together through migration family normalization.
- Arbitrary provider settings and internal plugin/theme styles remain excluded.

## v1.3.491 — Autocomplete and migration use separate indexes

- Normal CSS suggestions now contain MV variables and CSS Studio declarations, not framework variables registered by Bricks, Advanced Themer or migration providers.
- Advanced Themer framework classes are excluded by their structured provenance flag while user-authored Bricks global classes remain available.
- CSS Studio custom-property names retain their first character during normalization.

## v1.3.490 — Bricks suggestions use explicit authored stores

- Server autocomplete reads only Bricks global classes, global variables and theme styles rather than every `bricks_%` option.
- Unrelated Bricks settings can no longer contribute implementation variable, class or ID names.

## v1.3.489 — Autocomplete indexes authored site names only

- Live page CSS still resolves the effective value of a known authored variable, but it can no longer contribute new variable names.
- WordPress admin, theme, Bricks and MV interface classes/IDs are no longer collected from the current DOM or loaded stylesheets.
- Server suggestions no longer scan generated framework CSS, theme/plugin source files, templates, taxonomy slugs, generic plugin options or third-party snippet tables.

## v1.3.488 — Autocomplete stays inside the editor and suggests usable variables

- Suggestion menus now clamp to the owning CodeMirror rectangle rather than the full browser viewport.
- MV interface styling variables are excluded from the site/design-variable pool.
- Reference-only and unresolved names are removed, so variable rows have an actual authored or live value.

## v1.3.487 — Autocomplete is stable, contextual, and viewport-safe

- Active completion updates are no longer reopened on each keystroke, removing the visible jump and double refresh.
- Property/value/variable lists share one width, remain inside the viewport, flip above when needed, and never scroll horizontally.
- Variables appear only after `--`, `var`, or `var(`; ordinary value typing stays focused on CSS values.
- MV and detected external variable values/sources now come from the suggestion endpoint, with live computed values filling remaining gaps and defined variables ranked first.

## v1.3.486 — Hidden autocomplete lists are restored

- Live Firefox console evidence showed the correct hint node had `display:none` and a 0×0 rectangle; the backdrop warning was only the result of probing that empty rectangle at `(0,0)`.
- The active list now forces `display:block!important`, clears stale popover state, and is measured only after it is displayable.
- Hidden and zero-size states are reported directly instead of being misclassified as stacking overlap.

## v1.3.485 — Autocomplete uses a root-level viewport portal

- Removed the Popover API path that still failed in the live Theme Styles panel.
- Suggestion lists now render in one direct-body fixed portal, outside transformed panel coordinate systems and above MV's studio backdrop.
- Placement targets the active CodeMirror widget's own list, keeps that list hit-testable, and exposes `mimamVarInspectAutocomplete()` for live console evidence.

## v1.3.484 — Autocomplete suggestions appear beside the caret

- The top-layer suggestion list now applies caret coordinates at the same cascade priority as its `inset:auto!important` reset, so it no longer collapses into a thin strip at the top of the viewport.
- The list remains above MV's studio backdrop and is hit-testable beside the editor caret.
- MV no longer blames another plugin when its own suggestion display audit reports a failure.

## v1.3.483 — The suggestion list renders in the browser top layer

- The list is promoted to the top layer, which paints above every stacking context regardless of z-index, ancestry or filters.
- It is placed at the caret in viewport terms, since the top layer is positioned against the viewport.
- Browsers without the top layer fall back to the previous behaviour.

## v1.3.482 — The suggestion list moves inside the panel

- The list is hosted by the panel that owns the editor instead of the page body, so MV's blurred studio backdrop can no longer paint over it.
- The container stays hit-testable, so the visibility check reports the truth.

## v1.3.481 — Lift the suggestion list clear of whatever covers it

- The list is raised to the top of the stacking range and moved to the end of the body, so a tie or an ancestor stacking context cannot bury it.
- If something still covers it, the panel names that element instead of describing it vaguely.

## v1.3.480 — The suggestion list can no longer hide behind the panel

- Visibility is confirmed by asking what is painted on top, not by position alone.
- A covered list is lifted clear, and reported if it stays covered.
- The list outranks every MV surface by default.

## v1.3.479 — A suggestion request can no longer end in silence

- Every empty suggestion list now names its cause in the panel instead of looking like nothing happened.
- A list that opens outside the viewport is pulled back to the caret.
- Producing suggestions that never reach the page is reported rather than swallowed.

## v1.3.478 — MV pins its own CodeMirror

- MV keeps a reference to the CodeMirror build it verified, so another plugin taking over window.CodeMirror can no longer leave the editor without autocomplete.
- A suggestion list that cannot open now says so in the panel instead of failing silently inside a timer.

## v1.3.477 — Every code editor is MV’s own CodeMirror

- MV loads its bundled CodeMirror when the page has none, instead of sniffing for a link tag and degrading to a textarea.
- Another plugin's unscoped CodeMirror stylesheet no longer counts as MV's own.
- If the plain textarea is ever reached, the panel says so instead of impersonating the real editor.

## v1.3.476 — Module toggles apply immediately

- A module switch no longer reverses when an in-flight settings request finishes with older data.
- Each MV runtime derives its own surface list from a complete snapshot instead of the sender guessing.

## v1.3.475 — Suggestions in wp-admin, box control at any width

- The CodeMirror hint container is pinned to the viewport, so suggestions appear in wp-admin, not only in the Bricks builder.
- The theme style box control is a grid, so a pinned group rail can no longer squash it or push a field outside the band.
- The box centre names the element instead of showing the internal "all" token.

## v1.3.474 — Box control, picker card, shared suggestions

- Theme style box controls draw the spacing as a band around the element, with each field on the band it controls.
- The highlight colour picker has its card back; every picker host now shows exactly one.
- Every CodeMirror in MV shares the same suggestion pool.

## v1.3.473 — Light mode reaches the whole colour picker

- Every colour picker element now has a light-mode counterpart, including both alpha checkerboards and the alpha percentage box.
- The Content Studio swatch border override now matches the !important it competes with.
- A regression check enumerates the whole picker instead of spot-checking one rule.

## v1.3.472 — Suggestion values and per-control history

- CSS Studio suggestions show each variable's preview, resolved value and source instead of the bare name.
- Alias chains resolve to their final value; cycles and undefined tokens are reported rather than guessed.
- Bricks Theme Styles: undo, redo and clear on every control, and on each group as a whole.
- Typing collapses into one undo step instead of one per keystroke.

## v1.3.471 — Variable menu stacking

- An open ⚡ variable menu now sits above the colour rows beneath it. The row wrapper's own z-index made it a stacking context, capping the menu inside that row.

## v1.3.470
- The selected recent-colour ring is no longer clipped. It was a `box-shadow` painted 2px outside the swatch, and the picker core clips (`overflow:hidden`, with its padding removed inside a popover), so the outer edge was cut off. It is now an `outline` with a negative offset, drawn inside the swatch's own box — impossible to clip and costing no layout — with an inset hairline so it stays visible on a swatch close to the brand colour.

## v1.3.469
- Defined when a colour becomes "recent", and fixed what shipped. It was recorded only when a hex was typed and committed — so dragging the map, the hue or the alpha, or editing a channel field, recorded nothing at all, which is most of how the picker is used. It is now recorded **on close, once per picker session, and only if the colour changed**: not on every edit, because a drag emits hundreds of intermediate colours nobody chose, and not only on a typed hex, because that is the rarest way anyone picks. The stored value keeps its alpha, so a translucent colour comes back translucent.
- The rule is written into the Component Library entry so the next picker host does not have to guess it.

## v1.3.468
- The hue slider keeps its rainbow while you drag it. Exempting ranges from the control-height rules missed two more: a plain `.ve-row input` background and, more to the point, `.ve-row input:focus` — a slider takes focus on pointer-down, which is exactly why it only greyed mid-drag. Ranges are now exempt from those too, and the hue and alpha gradients carry `!important` so no host rule can repaint them. The codebase had already solved this once for an older picker with `.ve-hue`; the shared track now does the same.
- The colour popover stays inside the panel as it grows. The clamp was writing `el.style.top`, but the host renders `left`/`top` from state, so every re-render — changing the colour, typing in the VAR search — wiped the correction and it slid back off the bottom. It now nudges with `transform`, which the host does not manage.

## v1.3.467
- The colour popover now re-clamps as it grows. It was measured once when it opened, so switching to VAR — which adds a variable list — made it taller after the decision had been taken, and it hung off the bottom of the Media Studio panel again. A shared `keepInsideBounds` helper clamps on open and re-clamps on every resize, and scrolls internally when it is taller than its container. The Theme Styles popover had the same staleness deciding which way to open, and uses it too.
- The Variables colour picker closes on an outside click or Escape. It only ever toggled from its own swatch, so once open the only way out was to click the swatch again.

## v1.3.466
- Found the real cause of the oversized colour sliders. `.ve-sr input`, `.ve-row input` and `.ve-ren input` force every descendant input to the 38px control height with `!important` — correct for text and number fields, wrong for a range. The Variables panel is the only host that wraps the picker in `.ve-row`, which is why its two sliders rendered at 38px while every other picker looked right, and why the track's own `height:14px` never applied: it carried no `!important` and lost on specificity.
- Ranges are now exempt from those three blanket rules, and the picker track asserts its own height so a future host cannot override it the same way.
- Three checks pin it, including one that fails if the exemption is removed.

## v1.3.465
- Reworked the alpha slider after measuring it instead of eyeballing it. Two separate causes: the % readout was 20px while the hue row is 18px (its thumb, not its 14px track, sets the height), and the track carried the same 10px / 20%-contrast checkerboard as the 34px swatches — which in a 14px bar is 1.4 rows of loud squares, reading as a block rather than a slider. The readout is now 18px, so both rows match exactly, and the track checker is 6px at 4% contrast: texture instead of pattern. Light mode gets the same treatment.
- Two checks pin both: the readout may not be the tallest item in its row, and the thin track may not reuse the swatch checker.

## v1.3.464
- Connected the transparency slider in Theme Styles. It was passed `alpha:1` with a no-op `onAlphaChange`, so it rendered and moved but reported nothing and always snapped back to 100%. Alpha is now read from and written to the stored value as an eight-digit hex, which Bricks resolves straight into CSS.
- The Theme Styles swatch now shows translucency, layering the colour over a checkerboard instead of replacing it — so a half-transparent colour is distinguishable from an opaque one.
- Added two checks rejecting a no-op `onAlphaChange` or a hard-coded `alpha:1` in any picker host, since every host that shows the picker shows the slider.

## v1.3.463
- Fixed the colour popover overflowing the Theme Styles panel. It was a fixed 316px, which fitted the old full-width body but not the 270px left once the new group rail is pinned (468 − 150 − padding), so the panel scrolled sideways. The popover now anchors to its field row and is exactly as wide as the space available, at any rail width.

## v1.3.462
- Fixed the rail icons properly. A Phosphor icon is a font glyph drawn on a `::before` pseudo-element; I had put `display:grid` on the `<i>`, which turns that pseudo into a grid item and lets the default line-height inflate the box — so every glyph rendered low and read as two marks stacked above its label. The existing studio tool rail already had this right: flex-centre the button and give the `<i>` nothing but a size and `line-height:1`. The rail now matches it.
- Contract check extended to reject `display:grid` on the glyph and require `line-height:1`, so this cannot come back.

## v1.3.461
- Fixed the rail's stray squares. The set-dot is rendered as an `<i>`, and the rail's icon rule targeted every `<i>` in a button — so each dot was being sized as a 19px icon box. The rule is now scoped to the Phosphor glyph.
- Removed the native tooltip on rail buttons, which duplicated the label the rail already reveals on hover.
- Hovering the rail now fits the longest group name instead of truncating at 150px. Overlaying costs nothing underneath, so hover can be as wide as the text needs; only the pinned width stays fixed, because that one is taken out of the fields — pinned truncates rather than widening the panel.

## v1.3.460
- Theme Styles groups are a left rail instead of a tab strip across the top (id14, mock option D). Ten groups never fitted across 410px, so six were always scrolled out of sight — including the set-dots you were looking for. The rail shows all ten at once in 52px.
- Hovering the rail slides the labels out as an overlay, so the fields underneath never reflow; the pin reserves 150px permanently for anyone who would rather always read the names. The pin state is remembered per user, like the last group already was. It defaults to collapsed.
- Added the rail to the Component Library as `Panel group rail` before porting it, including the note that the collapsed label must be `flex:0 0 0` — `flex-grow` makes it consume the free space even at zero width, which is what pushed the icons off centre in the mock.
- Three contract checks cover it: every group has an icon, the collapsed label cannot grow, and the rail overlays on hover while only the pin reserves width. All three verified to fail when the bug is reintroduced.

## v1.3.459
- Fixed the transparency slider, broken by v1.3.458. Pinning the slider height with `flex:0 0 14px` set its *width* instead, because it sits in a flex row — it collapsed to a dot. The same change had also overridden the alpha row from its intended grid to flex. Both reverted; the base rule already pinned the height.
- Fixed the height that was reported twice: the alpha row was 30px because of the percentage readout, against a 14px hue bar above it, so the block read as twice the height. The readout is now 20px and the two rows share one rhythm.
- Fixed the Media Studio colour popover clipping, made worse by v1.3.458. The popover is `position:fixed` but a `backdrop-filter` ancestor makes the studio its containing block, so it cannot escape the panel — clamping it to the window pushed it under the panel edge. It clamps inside the panel again, using its measured height, and scrolls internally when taller than the panel.
- Added three regression checks covering exactly these mistakes: no flex-basis on the alpha range, the alpha row keeps its grid, and the popover clamps to the panel rather than the window. All three verified to fail when the bug is reintroduced.

## v1.3.458
- Replaced the fixed preset row in the colour picker with recently used colours, shared across every picker and stored locally. When there is no history the row is not rendered at all, so it can never be the line of empty boxes it was in the Content Studio.
- Removed the double frame: the popover drew a border and the picker drew another inside it. The core is now borderless wherever a host already supplies the frame.
- Colour pickers no longer run off the bottom of the screen. The Media Studio popover was positioned from a hard-coded height estimate that VAR and the recent row invalidated; it now measures itself after render and moves back into view. The Theme Styles picker opens upward when there is no room below.
- Pinned the hue and alpha slider heights so they cannot stretch in the wider Variables panel, and stopped the VAR list and its value column overflowing the picker.
- Deleted 31 dead CSS rules targeting a colour picker that no longer exists (`.ve-color-panel`, `.ve-color-map`, `.ve-color-fields`, `.ve-format-tabs`, `.ve-color-dot`, `.ve-rich-popover-title` — all CSS-only, never rendered).

## v1.3.457
- Restored the VAR format in the colour picker. It was dropped on the reasoning that the ⚡ picker replaced it, which was wrong: ⚡ is a shortcut on a field, VAR is a mode of the picker itself. Selecting it swaps the channel fields for a searchable list of MV variables and stores `var(--token)` instead of a literal, with the bound token shown above the search and an unbind control beside it.
- VAR is offered only where the host can store a reference, which is now all four pickers — media collection colours previously accepted six- or eight-digit HEX only and now take a variable reference too.
- Added a shared variable cache so a picker host only has to declare that it can store a reference, rather than fetching its own copy of the variable list.

## v1.3.456
- Fixed the canvas flicker properly. The debounce in v1.3.455 only slowed it down; the cause was double delivery — MV wrote Bricks' store AND posted the same payload to the iframe, and Bricks mirrors every store write to the iframe by itself, so the canvas CSS regenerated twice per keystroke. MV now writes the store only, skips identical payloads, and defers the panel re-render until the value settles.
- Added OKLAB alongside OKLCH in every colour picker. It is derived from the existing OKLCH conversion rather than implemented separately — the same colour in Cartesian instead of polar coordinates — so the two can never disagree.
- Built the Component Library's preset swatch row, which the library had specified for a long time and no picker had.
- Moved "Backdrop behind panels" out of the CSS Studio settings tab into Settings → General beside Studio defaults. It governs nine modules and had no business living under CSS Studio.
- Gave the product one segmented control (`.ve-seg`) matching the Component Library's, and moved the backdrop intensity control onto it. It was inline-styled with its own geometry.
- Reconciled the Component Library colour picker entry with what ships, and recorded why the one remaining difference is deliberate: `VAR` is not a format tab because variables are bound with the ⚡ picker, which searches — a tab cannot.

## v1.3.455
- Theme Styles remembers the group you were last in, and switching between styles no longer throws you back to General.
- Closing MV with unsaved theme style edits no longer leaves them applied in Bricks. The live preview writes to Bricks' store, so an abandoned edit stayed on the canvas and in Bricks' own panel while MV had already discarded it; the saved state is now restored on close, on Reset, and on unmount.
- Stopped the canvas flickering while typing. Every keystroke replaced the whole theme-styles map and stamped `rerenderControls`, re-rendering Bricks' entire panel; pushes now coalesce to the pause between keystrokes.
- Withdrew the Elements / Structure dock-float-hide menu from the Bricks toolbar pending a redesign, and it is removed from installs that already rendered it. The same settings remain in MV Settings → Builder Panels.
- Checklist audit: removed two rows confirmed working, one that outlived the feature it tested (minimum canvas), and one superseded by a later row testing the same thing.

## v1.3.454
- Bricks' own Theme Styles panel now updates with MV instead of showing stale values until it was closed and reopened. The canvas was repainting, but the panel keeps per-control state; Bricks refreshes it by stamping `rerenderControls` on the store, which MV now does after every push.
- Every colour picker is one component again. The map, sliders, OKLCH fields and format tabs were already shared, but each host built its own footer and sized its own popover, which is why the Variables, Theme Styles, Content Studio and Media Studio pickers looked like four designs. Footers are now declared as actions on the shared core, and all hosts size from one `--ve-picker-width` token.
- Added light-mode theming to the colour picker. It had none, so inside the Content Studio's light canvas it rendered dark chrome — including the alpha checkerboard, which now uses light squares.
- Swatches keep a 1:1 ratio and take the height of the field beside them. `.ve-cp` pinned its first grid column to 42px, so the swatch could never track the field; that column is now sized by the square.
- The ⚡ variable control opens a searchable dropdown listing MV variables with their resolved values, plus Unbind when one is already set. It previously just seeded `var(--` into the field, and rendered a second redundant lightning icon beside the first.
- Removed the minimum canvas viewport setting and its REST route, runtime and stored option. Parked, not abandoned — the finding worth keeping is that Bricks' `previewWidthLocked` watcher only persists the number, and `previewWidth` is recomputed solely when `previewWrapperWidth` changes, so any future version must mirror the width itself.
- Rewrote the Component Library's colour picker entry, which had drifted from what ships: it documented HEX/HSL/OKLAB/VAR tabs and a preset swatch row that no longer exist.

## v1.3.453
- Theme style edits now show in the builder immediately, without a reload. Saving only wrote the `bricks_theme_styles` option; the builder generated its canvas CSS at boot and never re-read it, so nothing MV changed here was visible. MV now writes the builder store the way Bricks' own panel does — the styles map first, then the active style's settings, which is the watcher the iframe uses to regenerate (`$_generateCss("themeStyles")`). Every value is a fresh clone because those watchers compare by reference, and the message is posted to the canvas with `ignoreOrigin` so Bricks cannot drop it.
- The canvas repaints on every field change, not only on Save, matching how Bricks previews its own theme style edits. Conditions are live too: the server recomputes which styles apply to the previewed post on each read and write.
- Minimum canvas now actually moves the canvas. Bricks' watcher on `previewWidthLocked` only persists the number over AJAX — `previewWidth` is recomputed solely when `previewWrapperWidth` changes, so setting a width saved it and moved nothing until the next panel resize or reload. Bricks never hit this because its own lock button locks to the *current* width. MV now mirrors the locked width onto `previewWidth` on desktop, and restores the wrapper width when the lock is turned off.
- Colour picker: added a footer with breathing room above the Done button, a Clear command that removes the colour so the Bricks default applies again, and dismissal by clicking outside or pressing Escape.
- Any colour or text field in Theme Styles now has a ⚡ that opens the MV variable list. The suggestions only appeared once the text already looked like a variable reference, which was not discoverable.
- Branded the scrollbar on the CSS editor's variable-suggestion list; it was still the browser default.

## v1.3.452
- Theme Styles now write into the group Bricks reads them from. Bricks resolves a style as `settings[group][key]` (`Theme_Styles::get_setting_by_key`); MV wrote every key flat at the top of `settings`, so outside conditions nothing MV saved was ever applied. Values written by earlier builds are lifted into their real group the first time a style is opened.
- Saving from MV no longer deletes per-element theme styles. The save replaced the whole settings array, wiping Bricks' ~40 element groups (Section, Button, Heading…); it now merges, and the Elements tab names the groups a style is carrying.
- Completed all nine whole-style groups — 107 controls. Group ids, keys, labels, placeholders, option tokens, `exclude` lists and `required` show/hide rules are generated from Bricks' own `includes/theme-styles/controls/*.php` rather than transcribed.
- Replaced every JSON textarea with a typed control: a 15-field typography panel, border as width/style/colour, box-shadow as X/Y/blur/spread/colour/inset, spacing as the four-side box, multi-selects that accept custom tags, and a repeater for contextual-spacing targets.
- Stored stylesheets, link CSS selectors and the contextual-spacing selector list verbatim; `sanitize_textarea_field` strips `%xx` octets and tag-shaped text, which corrupts CSS.
- Regenerated Bricks' `theme-style-*.min.css` explicitly on save, since Bricks' own hook only fires when the stored value changed, and suffixed duplicate style labels because Bricks names that file after the label.
- Added `scripts/check-theme-styles-contracts.js` (10 checks) and `scripts/gen-theme-styles-spec/`, which diff MV's spec against Bricks' control files so a rename cannot silently turn saves into no-ops.

## v1.3.405
- Replaced the v1.3.404 per-editor listener with one broker registered before the Preact panel mounts, so the handler exists before editor effects and later Bricks window listeners.
- Routed standard `wheel`, Firefox `DOMMouseScroll`, and legacy `mousewheel` through the same bounded editor path, suppressing compatibility duplicates only while an MV editor consumes the input.
- Made the native CodeMirror scroller's `scrollTop`, `scrollHeight`, and `clientHeight` authoritative instead of relying only on CodeMirror's calculated range.
- Exposed `mimamVarInspectCodeEditors()` immediately in the current and same-origin top-frame console, before any editor mounts.
- Verified physical wheel input in Firefox 153.0.1 and Chromium: inline and pop-out editors reached their native final line, inline boundary scrolling moved the Settings panel, and the pop-out footer remained visible.

## v1.3.404
- Captured CodeMirror wheel input at the window boundary so Bricks document/panel handlers cannot cancel it before inline or pop-out editors scroll.
- Added `mimamVarInspectCodeEditors()` for on-demand console reporting of every live editor's measured and native scroll range plus its last wheel decision.
- Kept Execution, Styles, and Scripts fully expanded in Custom Code instead of turning the editing workspace into accordion toggles; calmer accordions remain unchanged in the other Bricks Settings groups.
- Continued inline wheel movement into the Bricks Settings panel after the editor reaches either boundary, while keeping the pop-out isolated above its accepted visible footer.
- Added a faithful browser harness that installs a cancelling document-capture listener before CodeMirror, then verifies both editors reach their measured final line.

## v1.3.403
- Routed physical mouse-wheel input through bounded inline and pop-out CodeMirror editors, while releasing the wheel to the surrounding panel at the first and final line.
- Added Bricks-native Theme Styles Phase 1: create, rename, duplicate, guarded delete, conditions, whole-style General/Colors/Typography/Links/Spacing/Content controls, and Custom CSS all read and write the existing `bricks_theme_styles` option.
- Reorganized Bricks Settings into calm collapsible subsections with optional descriptions while preserving global search and native Bricks saves.
- Vendored CodeMirror 5.65.16 XML, JavaScript, and HTML Mixed modes so Bricks header/body script fields receive real HTML/JS/CSS syntax highlighting inline and in the pop-out.
- Added a focused 21-check contract suite and a bundled-CodeMirror browser harness that verifies physical wheel movement, the final line, visible pop-out footer, and HTML Mixed mode.

## v1.3.402

- **CodeMirror remeasures instead of losing its bottom edge.** Inline and popped-out Bricks editors now observe their real host geometry, refresh after layout/font changes, and keep the final line plus scrollbar inside the visible editor.
- **Bricks Settings matches the Settings panel.** Its docked and floating panel width now uses the same 468px product width; the purpose-built 410px code pop-out remains unchanged.
- **Content Studio uses Rank Math's live analyzer.** When Rank Math is active, edits to SEO-relevant content are passed through Rank Math's own analyzer, configured tests, locale data, and score weighting before save. The stored `rank_math_seo_score` remains Rank Math-owned.
- Added a focused v1.3.402 contract and a real bundled-CodeMirror browser harness for editor bounds, panel width, analyzer wiring, and score ownership.

## v1.3.401

- **Bricks code editing reaches the real bottom.** Inline CodeMirror stays inside its fixed-height box; the pop-out body is bounded above its visible save-state footer; the studio rail sits immediately beside the pop-out and follows it after resize or drag; and the stale native dock-back tooltip is removed.
- **Attachment video layout is independent from image previews.** Video media, hover/focus seekbar, and Play/Sound/Volume controls render in a dedicated intrinsic-ratio card before Metadata, including portrait video.
- **Focus keywords are calmer and readable.** Each keyword now uses one compact full-width row with wrapped text instead of uneven bubble widths.
- **Rank Math owns its SEO score.** Content Studio reads the score Rank Math stored in WordPress, reports N/A when Rank Math has not produced one, and no longer writes over `rank_math_seo_score`; MV analysis remains the fallback only when Rank Math is inactive.
- Added a focused v1.3.401 contract plus a browser layout harness for the editor/rail/footer geometry.

## v1.3.400

- **All Bricks code fields use the shared editor.** Custom CSS, header scripts, and body scripts mount the CSS Studio CodeMirror shell; inline instances are fixed-height and the rail clears a popped-out field.

## v1.3.399

- **One editor and minimal pop-out.** Custom CSS gained the shared CSS Studio highlighting/suggestion engine and any Bricks code field can open in a 410px full-height side panel with keyboard saving.

## v1.3.398

- **Everything feedback stays visible.** Selection/opening toasts choose space above or below Mimam's Bar and clamp to the viewport instead of rendering off-screen.
- **Video Attachment Details no longer breaks its layout.** Playable and failed previews reserve their own bounded space, controls remain below the media, and a seekbar appears on hover or keyboard focus.
- **Masonry uses true video geometry.** Video tiles report intrinsic dimensions to the column balancer, so portrait, square, and landscape assets render at their real aspect and rebalance the columns.
- **Long focus keywords show in full.** Keyword text wraps inside the pill without ellipsis or horizontal overflow.
- **SEO score persistence is explicit.** All SEO edits mark the editor dirty, and the SEO tab now has a dedicated Save SEO & score action with saved/unsaved feedback.
- Added a focused v1.3.398 contract for viewport-safe feedback, video layout/geometry/seeking, keyword wrapping, and SEO score persistence.

## v1.3.397

- **Visible Everything selection feedback.** Opening a result now announces what was selected and whether it is opening here or in a new tab; same-tab navigation pauses briefly so the confirmation can paint.
- **Video previews now follow the media.** Portrait videos use their intrinsic aspect ratio, all controls sit below the media, and Play/Pause plus Sound use compact accessible icons.
- **Metadata fields are easier to edit.** Caption and Description have dedicated taller multi-line areas.
- **Content SEO acceptance fixes.** Meta-description textareas escape the global one-line clamp, focus-keyword pills wrap instead of shrinking into one line, and Content Studio persists its own computed SEO score while still writing the Rank Math score for compatibility.
- **Upload feedback no longer collides.** While Media Studio progress is visible, the global toast reserves space above it.
- **Approved Output unit clarity design shipped.** The default for new tokens is a clear four-card choice; converting existing tokens is a separate optional flow with an inline review step.
- Added focused contracts for Everything feedback, responsive video layout, icon controls, metadata sizing, toast spacing, SEO persistence/wrapping, and the approved output-unit flow.

## v1.3.396

- **Media Studio opens with media already waiting.** The library now warms in the background, survives reloads in a short-lived session cache, paints the first REST page immediately, and refreshes stale data without replacing the usable gallery with an empty loading state. Media requests also drop the unused embedded-author expansion.
- **Videos now look and behave like videos.** MP4, WEBM, MOV, M4V, and OGV tiles lazily capture a real frame only when near the viewport. Selecting one opens an in-panel player with Play/Pause, explicit Sound on/off, and a Volume control.
- Added focused contracts for the cache/prefetch path, progressive paint, removal of the expensive request shape, real video previews, and accessible playback controls.

## v1.3.395

- **Media Studio scrolls again in every launch mode.** The normal Studio bridge now fills the remaining panel height instead of expanding with all media content, so Collections, the gallery/list, attachment details, and batch actions receive bounded scroll areas while Bricks picker mode keeps its existing context-preserving layout.
- Added a focused Media Studio regression contract for the complete flex-height chain and corrected the archived ACF mock path used by the v1.3.340 contract gate.

## v1.3.394

- Added explicit flex and overflow ownership to the Media Studio collection list. Live acceptance showed the outer normal-mode bridge was still unconstrained, so the complete height-chain correction follows in v1.3.395.

## v1.3.386

- **Backdrop behind studio panels, per module (#18).** While a studio is open you can blur/dim the page behind it. Settings → Studio preferences adds an intensity picker (Blur + dim / Soft / Dim only / None) and per-module switches (Content, Media, Plugin, CSS Studio, CSS Recipes, Font Manager, Documentation). Defaults: Blur + dim, on for those studios, off for the docked Variables panel and Settings. The wide studios already dimmed; this makes it consistent and controllable.

## v1.3.385

- **Drag a field's right edge to set its Presentation width (#17).** In the field-group builder each field now renders at its wrapper width; a handle on the right edge resizes it (snapping to 5%, 15–100%) and shows a live percentage. The drawer's width field stays in sync.

## v1.3.384

- **Documentation module (#14).** The Help speed-dial (now "Docs") opens a full documentation hub: a rail of modules (Variables, Media Studio, Content Studio, Builder Tools, Recovery), a home with search, module cards, Quick answers and "What's new", per-module article lists, and a rich article reader (callouts, numbered steps, command lists, keyboard chips). Built from the approved v4 mock; the Bar command reference is now an article.

## v1.3.383

- **ACF Options Pages editor (#13).** The Options Pages section now has a **+** to register a page and pencil/delete controls per row; the tabbed editor covers **Placement** (page/menu title, stable slug, parent, position, icon, description), **Access** (capability, redirect parent, autoload), and **Field Groups** (which groups target the page). Everything saves through ACF's own `acf_update_ui_options_page`, merging into the existing record.
- **The category list's Autoload toggle is now live** for options pages, saving through ACF, and options rows gained Edit/Delete actions.

## v1.3.382

- **Image pickers across wp-admin now open Media Studio** (Site Icon, featured image, ACF image fields, etc.), not just inside the builder. The wp.media bridge is active on every admin page whenever the Media Studio tool is enabled, and falls back to the native WordPress library when Media Studio can't handle a request. Disable the Media Studio tool to restore native pickers everywhere.

## v1.3.381

- **Pressing Enter in the Bar's Direct mode now applies the command** even when a class/attribute token chip is focused — previously Enter only triggered the chip's own click, so the change was lost until you clicked Apply. Editing a token's value inline still commits on Enter as before.

## v1.3.380

- **Focus keywords now wrap instead of overflowing.** Long focus-keyword pills flow onto multiple rows and truncate cleanly rather than spilling out of the box.
- **The SEO score updates live as you type**, computed from the on-page analysis checks, instead of only showing the last saved Rank Math score.
- **A notice shows when Rank Math isn't active**, making clear the SEO analysis is Content Studio's own.

## v1.3.379

- **The featured image now shows its actual thumbnail** in the content editor rail instead of a generic icon (the server now sends the thumbnail URL, and picking a new one updates it live).
- **Taller meta-description field** in the SEO preview editor.

## v1.3.378

- **Custom post types are reliably tagged as ACF-editable**, so the category-list status cells render as working toggle switches (not read-only pills) and the row/edit actions open the editor. Source detection now uses ACF's UI-created post-type definitions and tolerates both array and string shapes.

## v1.3.377

- **The category list now matches the reference prototype.** Each category shows the full column set (Singular, Slug, Description, Front prefix, Post-type badges, etc.), the status cells for post types and taxonomies are **inline toggle switches that save through ACF**, and there's a search box, an "Add [type]", and Edit / Duplicate / Delete row actions. Default content types stay read-only (labelled WordPress).

## v1.3.376

- **Clicking a Content Studio section header lists that category's items (#8).** Default Content Types, Custom Post Types, Taxonomies, Options Pages and Custom Field Groups each open a table of their items (with public/hierarchical/archive status and Edit/Delete actions); the caret icon alone now toggles collapse. Clicking a row opens that item.
- **Options Pages hides externally-registered pages.** Only options pages created through ACF's own UI are listed; ones registered in code by plugins/themes (e.g. Advanced Themer's Theme Settings) are hidden.

## v1.3.375

- **The Taxonomies list no longer shows internal plumbing.** MV's own media-collection taxonomy and Bricks' template Tag/Bundle taxonomies are hidden from the Content Studio Taxonomies list — it shows only real content-model taxonomies.
- **Creating a child collection reliably opens it.** The server re-keys nested collections, so MV now re-selects the new collection by its label once the sync returns instead of trusting the locally guessed key (which the fallback then reset to All).

## v1.3.374

- **Custom Taxonomies editor (#8).** Content Studio has a Taxonomies section listing custom taxonomies; the **+** registers a new one and clicking a taxonomy opens a tabbed ACF editor — General (plural/singular/key, description, public, hierarchical, assigned post types), Labels, Visibility, Permalinks, and REST API. Everything saves through ACF's own `acf_update_taxonomy`, merging into the existing record; delete removes the definition (terms are kept).
- **The upload success toast no longer overlaps the upload progress card.** The sticky toast now sits above the progress indicator instead of on top of it.

## v1.3.373

- **Uploaded media keep spaces in their names.** The upload path percent-encoded the filename into the Content-Disposition header, so WordPress stripped the `%` and left "20" (`campaign monitoring` → `campaign20monitoring`). The filename is now sent header-safe with spaces intact.
- **Bar suggestions are faster again.** Reduced the command/element-search debounce from ~220–240 ms to ~120–150 ms.
- **Creating a child collection opens it.** Sub-collections now select and expand their parent branch on creation, matching top-level collections.

## v1.3.372

- **Selecting an image for a component instance now applies on the first try.** The component's image control sometimes mounts its writable field a frame after the picker confirms, so the first insert found nothing and you had to select twice. The insert lock is released on that miss and the insert retries once automatically.

## v1.3.371

- **Safe Add no longer pauses custom/third-party elements.** Adding an element like Slot from the Bar inserts it directly, the same as a core Bricks element.
- **Imported media keep spaces in their names.** A source name with `%20` (e.g. `high%20visibility%20image`) is now decoded before sanitising, so it reads "high visibility image" instead of "high20visibility20image". Applies to URL, content-disposition, and ZIP imports.
- **Typing `//` closes the Bar.** Pressing `/` while the field already holds a single `/` clears and closes it.
- **The Bar's suggestions are snappier.** Command and element-search results were debounced at 620–760 ms; they now respond in ~200–240 ms.
- **The "Use Selected Media" button sits above the metadata when picking.** When Media Studio is opened by a media picker, the confirm action is pinned to the top of the detail panel instead of below a long detail list.
- **Creating a collection in Media Studio opens it.** The new collection is selected immediately so you can start adding to it.

## v1.3.370

- **The multi-select option grids are now toggle switches.** The field-group Presentation → "Hide on screen" list and the post-type editor's "Editor supports" and "Taxonomy assignments" grids used square checkboxes; each option is now a labelled toggle switch, matching the rest of MV's controls.

## v1.3.369

- **Removed the stray horizontal scrollbar along the bottom of the ACF field-group and post-type editors.** The settings panes are meant to fit their width, so a sideways scrollbar there was always wrong; they now scroll vertically only, and the post-type editor's two-column rows can shrink instead of overflowing.

## v1.3.368

- **The floating settings speed dial only opens from the gear now.** Hovering anywhere in the button's column — including the empty space above the gear where the tool icons sit — used to reveal the whole speed dial. The tools now appear only when you hover the gear itself, and still stay open while you move up onto them.

## v1.3.367

- **The Custom Post Types editor is now a full ACF registration screen (#20).** Editing or registering a post type opens a tabbed editor — **General** (plural/singular/key, menu icon, description, public, hierarchical, editor supports, taxonomy assignments), **Labels** (the eight override labels ACF generates), **Visibility** (publicly queryable, show in UI/menu/admin bar/nav menus, menu position/icon, exclude from search), **Permalinks** (rewrite slug, query var, front prefix, feeds, pagination, archive), **Capabilities** (capability type, can export, delete with user) and **REST API** (show in REST, base, namespace, controller). Previously only the post type's labels could be changed.
- Every value saves through ACF's own `acf_update_post_type`, merging into the existing record so its key and any settings the editor does not expose stay attached.
- Editing an older-ACF or JetEngine post type keeps the labels-only behaviour; the settings tabs apply to ACF post types.

## v1.3.366

- **Dropdown menus scroll properly again.** Hovering an option re-anchored the list to that option, so every wheel notch snapped the menu back where it started. The list now only follows the highlight when you move it with the keyboard, and long menus (rule types, field types) get more height before they scroll.
- **Controls in the field-group editor match the chrome around them.** Selects and inputs sat at a 4px radius while the cards, pills and buttons beside them are 8-12px, so they read as squared-off.
- **The field-group editor fills the panel height.** It was capped at a fixed height and left dead space below the drawer.
- **The preview title bar says what it is.** The fake WordPress "Add title" field is now labelled as the post editor preview, so it is not mistaken for a group setting.

## v1.3.365

- **Field-group panes now have real padding and spacing.** The tab row, Location Rules, Presentation and Group Settings all sat flush against the panel edge with no breathing room between controls.
- **The field drawer fills the panel height** instead of stopping partway down and leaving dead space beneath it.
- **Dropdowns in the ACF editor are MV-styled.** Rule type, operator, rule value and field type used native selects, so their menus rendered in the operating system's styling; they use MV's own dropdown now, with search on the long lists.

## v1.3.364

- **Fixed the Presentation tab collapsing onto one line.** Content Studio styles labels inline, so Style, Position, Label placement, Instruction placement and Order all ran together; each setting is its own stacked row again.
- **Download ZIP no longer renders as a blue link.** wp-admin colours anchors, and the Release manager action is an anchor styled as a button.
- **Location rule values are now dropdowns** where MV knows the options — post types (from the site's registered types), post status, page type and user roles — instead of a free-text box you had to guess at.

## v1.3.363

- **Made clear that creating a field group is only the first step.** The create screen now says the group opens in the builder straight after, where fields and the full ACF settings live; its post-type list is relabelled as the starting location rule rather than the only way to target content.

## v1.3.362

- **Field groups now expose everything ACF's own screen does.** The editor gained the Settings ACF ships with, as tabs beside the field builder: **Location Rules** (a real rule builder with all 21 rule types, AND rules and OR rule groups — not just a post-type checklist), **Presentation** (style, position, label placement, instruction placement, order number, and the full Hide-on-screen list) and **Group Settings** (active, show in REST API, description, display title). All of it saves through ACF, so groups edited in MV match groups edited natively.

## v1.3.361

- **An empty field group can now be built.** A group with no fields hit the generic "No items found." state, so a newly created group had no way to add its first field. Field groups always render the builder now, with an "Add the first field" prompt when empty.
- **Creating a field group opens it.** You land straight in the builder instead of having to find the new group in the sidebar.
- **The Latest release card is gone from Release manager.** Removing only its Update button still left a duplicate of the Check-update block above it; the pending build is listed in one place. Installed and rollback rows are unchanged.

## v1.3.360

- **ACF field groups now use the approved Live Preview builder.** Opening a field group in Content Studio shows the edit screen your writers actually see instead of a plain table: click a field to edit it in the side drawer (General / Validation / Presentation), hover between fields to insert, and reorder, duplicate or delete inline. Changing a field type re-renders its real control — image drop zone, repeater rows, true/false switch, and so on. **Save fields** writes back through ACF, updating fields in place so keys and stored content survive.

## v1.3.359

- **Release manager entries show their own version again.** Every row was labelled with the same old version because the release script copied the previous entry's label instead of deriving it; all existing entries have been repaired.
- **Removed the duplicate Update button** from the Release manager's Latest row — updating to the newest build is already offered by the Check-update block directly above it.
- **The font relink picker now lists font files only**, instead of the whole media library.

## v1.3.358

- **ACF content-model API (Content Studio groundwork).** New endpoints read every ACF model in one call — field groups with their fields, post types, taxonomies and options pages — and save a field group back through ACF's own API, updating fields in place, appending new ones and deleting removed ones so keys and stored values survive. Reports cleanly when ACF is not active. This backs the approved Live Preview builder; the UI lands next.

## v1.3.357

- **The Media Studio picker now works in wp-admin, not just the Bricks builder.** The media bridge effect returned early outside the builder, so the direct picker MV panels rely on was never defined there — Font Manager fell back to the WordPress library. Only the wp.media hooking is builder-specific now.

## v1.3.356

- **The font relink picker now opens Media Studio instead of the WordPress library.** MV already swaps `wp.media` for a Media-Studio-backed frame, but only when a recent Bricks control intent exists — a call from Font Manager had none and fell straight through to the native library. MV panels can now open the picker directly.

## v1.3.355

- **Updates fixed — the feed was rate-limited, not blocked.** The primary feed pointed at `api.github.com`, whose unauthenticated limit is 60 requests per hour per IP; a normal day of checks exhausted it and GitHub returned `403 API rate limit exceeded`, which surfaced as "Update feed blocked". `raw.githubusercontent.com` serves the same manifest with no auth and no limit, so it is now the primary feed and the API endpoints are the fallback. (Verified live: API → 403, raw → 200.)
- **Pages and Bricks templates can now be opened in the WordPress editor** from Everything mode with `⇧↵`, instead of always going straight to Bricks.

## v1.3.354

- **Updates work again — the real cause this time.** Removing the "Update feed URL" field left its old value in the database, and the updater still read that stored value as a fallback. It was a bare repository URL with no manifest path, so every check failed. The stored value is now ignored entirely: only a `wp-config` constant can override the built-in per-channel feed.
- **Dismissing a toast (or using the media frame) no longer closes the open studio.** The outside-click watcher runs in the capture phase, so it fired before the toast's own handler could stop it; toasts and the WordPress media frame are now excluded at the watcher itself.
- **Adding an element with nothing selected no longer errors.** Only Section could be added without a target; anything else was refused. Elements are appended to the canvas root instead.
- **Everything mode now finds Bricks templates** — headers, footers, single templates — and opens them straight in the builder.

## v1.3.353

- **Fixed the General settings tab doing nothing when clicked (regression in 1.3.352).** The per-module tooltip switches were rendered in the Settings component but their state was declared in the app shell, so the tab threw on render. The stored list is now read through a shared helper: Settings owns the switches, the tooltip engine mirrors them via an event.

## v1.3.352

- **Tooltips can now be turned off per module** — Settings ▸ Modules lists every studio plus the speed dial/rail, each with its own switch. The tooltip engine checks the hovered element's `data-panel` before showing anything.
- **The speed dial no longer closes before you reach an icon.** It used to close the instant the pointer left the wrapper, so any diagonal travel dismissed it; it now waits ~320ms and cancels that timer when the pointer returns.
- **Fixed core Bricks elements being rejected by Safe Add.** The core allowlist used reversed keys (`basic-text`) while Bricks names them `text-basic`, so "Basic Text", "Rich Text" and "Text link" were treated as third-party and blocked.

## v1.3.351

- **Fixed updates being unreachable ("Update feed blocked") in 1.3.349–1.3.350.** Moving the feed URL into a constant hard-coded a bare repository URL, which both lacked the manifest path (`/contents/updates/…json?ref=main`) and overrode the Stable/Beta/Dev channel selection, so no channel could resolve. `VE_UPDATE_FEED_URL` and `VE_LICENSE_SERVER_URL` now default to empty — meaning "use the built-in per-channel feed" exactly as before — and only take effect when deliberately defined in `wp-config.php`.

## v1.3.350

- **Dismissing a toast no longer closes the studio behind it.** The toast is rendered outside every panel, so its clicks reached the document and read as "clicked outside" — closing Font Manager along with the message. Toast pointer events are now contained.
- **The media picker no longer closes Font Manager.** The WordPress media frame renders at `<body>`, so clicks inside it counted as outside the panel; those events are now swallowed while the frame is open.

## v1.3.349

- **"Relink all" no longer disappears after the first fix.** It lived inside the family's "no preview" warning, so the moment one variant healed the family regained its preview and the button vanished with 8 still broken. It now sits in its own strip that stays while any variant lacks a file, and reports the count.
- **Added "Browse media library" to the relink drawer** so a variant with no automatic match can still be pointed at a file by hand.
- **Unsaved-changes text no longer clips the Close button** — the footer shows a compact dot + "Unsaved" instead of a full sentence; results are toasts.
- **Removed the Update feed URL and License server URL fields.** They are infrastructure, not user settings: a customer editing them silently breaks updates or licensing. They now live in code as `VE_UPDATE_FEED_URL` / `VE_LICENSE_SERVER_URL`, each overridable from `wp-config.php`.

## v1.3.348

- **Fixed Relink all failing when the right files were sitting in the media library.** Matching only knew one name per weight, so a family like Lato — which calls weight 100 "Hairline", not "Thin" — scored every file below the auto-relink threshold. Weights now match on numerals *and* foundry synonyms (thin/hairline, extralight/ultralight, semibold/demibold, black/heavy…), italics must agree in both directions so an upright variant can never take an italic file, a different family is rejected outright, and unsuffixed regulars (`Lato.woff2`, `Lato-Italic.woff2`) are understood. All nine Lato variants now resolve to the correct file.
- **Long toasts wait for you.** Messages over ~70 characters drop the countdown ring and stay put with a × to dismiss, so there's time to read them.
- **Visibility save result is now a toast** instead of a cramped footer strip that squeezed the Close button.

## v1.3.347

- **Relink all now reports what it did.** Progress runs on the button itself ("Scanning 3/9…") instead of only in the far-away footer status, and the result is announced as a toast — including the previously silent case where no media-library match was found for any variant.
- **Settings footer really stops clipping Close.** The actions group had no `min-width:0`, so it overflowed the footer instead of letting the status text truncate.

## v1.3.346

- **Fixed the broken Relink button.** The variant action row forces 27×27 icon buttons, which crushed the labelled pill so its icon and text overlapped; the pill now sizes to its content.
- **Added "Relink all"** to a family's warning row — it scans once per broken variant and relinks every confident match in a single pass, then reports how many still need a file.
- **Settings footer no longer clips Close** when a long status message shows: the buttons stop shrinking and the status truncates instead.
- **Toggle On/Off label is properly centred** — it now stretches between the track edges and centres with flex instead of relying on a fixed height and line-height.

## v1.3.345

- **Broken font variants can now be recovered in place.** A variant whose Bricks attachment no longer resolves gets a **Relink** action: MV scans the media library and ranks replacements (exact filename → same stem → family/weight/style match), and one click repoints the variant and rebuilds the Bricks font-face rules. If nothing matches, the panel says so and points at re-upload or removal. New endpoints: `font-manager/relink-candidates` and `font-manager/relink`.

## v1.3.344

- **Restored the Direct row's inline padding.** Zeroing `padding-inline-start` to let tokens wrap under the mode control left every *wrapped* row running flush to the panel edge; the row keeps its 16px inset again (the mode pill no longer needs its compensating margin).

## v1.3.342

- Fixed both Font Manager launchers so the Studio rail and builder speed dial open the same Bricks-backed panel.
- Added an explicit return path from Import/Add variant, matched the shared panel width, removed the redundant Import action and external Bricks-admin handoff, and guarded variant removal with MV confirmation.
- Normalized Bricks font-face sources stored as attachment IDs, source arrays, or URLs so existing family/variant files resolve instead of silently appearing missing.
- Registered per-family preview faces from the actual Bricks font URLs, weights, and styles; unavailable sources now show an explicit recovery state.
- Refined Mimam's Bar so Direct and the opening tokens share the first row while later rows use the full rail, and made class/attribute suggestion focus, spacing, match emphasis, and scrollbar gutter calmer.
- Added prototype-only three-direction ACF UX comparison, product Documentation v2, and type-aware Variables List/Visual/Groups views for review.

## v1.3.341

- Added a Bricks-backed Font Manager that reads and writes Bricks Custom Fonts, imports browser-converted WOFF2 files as WordPress attachments, refreshes Bricks font rules, and keeps every family editable through Bricks without MV.
- Added family search, real family/weight previews, family rename, variant weight/style editing, add-variant import, variant removal, and recoverable family trash.
- Kept Direct at the Bar's top-left while wrapped tokens align beneath the token rail, reserved the top-right Saved Attributes action, and made its Settings deep link durable.
- Replaced saved-list removal with Unstar, clarified which Bar settings are surface-specific versus shared, and quieted attribute suggestion rows and match highlighting.
- Reframed the Help prototype as full product Documentation and replaced duplicate Variables view controls with type-aware Color palette, Typography specimen, Spacing scale, and Layout diagram views.

## v1.3.340

- Added spatial Arrow Up/Down navigation across wrapped Direct tokens and Backspace/Delete removal for a focused ID, class, or attribute while preserving native keys inside inline editors.
- Moved the saved-attributes library action to the Bar's top-right corner, let tokens fill beside the Direct selector, and deep-linked Settings to the Saved Attributes section with visible focus when opening or editing.
- Made visitor preview-key access opt-in, added Bricks-compatible role-based maintenance bypass controls, and kept administrators on Bricks' always-bypass behavior.
- Preserved Bricks' transient direct component-property editor while Media Studio selects an image default.

## v1.3.339

- Added the approved Attribute Suggestions v2 runtime with grouped suggestions, site-level saved names/values, star-to-save actions, suggestion value prefill, and add/edit/remove/bulk-paste management in Unified Settings.
- Restored focus to the token just saved through inline editing so keyboard traversal can continue immediately.
- Polished Site Visibility's numbered sections, mode selector, rendering switches, and shared Save/Close footer.

## v1.3.338

- Added Site Visibility to Unified Settings with live Bricks maintenance/coming-soon mode, template rendering, searchable exclusions, a WordPress-owned read-only site URL, and an MV-managed visitor preview key/link.
- Completed global class rename propagation into Bricks custom-CSS selector fields and refreshed Code2Bricks’ selector index, selector UI, and active editor buffer.
- Fixed Direct token editing so Left/Right moves the caret while editing and added a clearer keyboard focus state when traversing class and attribute tokens.
- Cleared Add Element search and highlight state after a Bricks element or Component is inserted.
- Matched the Bar update-banner actions to MV’s normal button height and rounded border rhythm.

## v1.3.337

- Refreshed Bricks selection consumers after an in-place global class rename so Code2Bricks and other selected-element integrations receive the new selector immediately without creating a replacement class.
- Replaced Direct mode's boxed ID, class, and attribute pills with a flat editable token rail, including Arrow Left/Right traversal between tokens and the trailing command field.
- Extended Add Element search to index native Bricks Components and insert a linked component instance through Bricks' add-element pipeline while retaining existing Safe Add restrictions for third-party elements.

## v1.3.336

- Fixed Bricks-triggered Media Studio picking so the current collection preselects its first item on first use, remembers the last picked attachment on later opens, and suppresses the redundant open/insert success toasts.
- Fixed Mimam's Bar class editing so global classes rename in place without losing their ID, styles, or references; manual classes still rename locally, and duplicate global names are rejected.

## v1.3.305

- Hardened Content Studio and Media Studio reopen synchronization with a pre-paint layout effect on both close and open, so a default changed while the Studio is hidden is applied without a stale-view flash.

## v1.3.304

- Fixed the Content Studio and Media Studio close/reopen flash by preloading each configured Normal or Full screen default while the Studio is hidden.
- Standardized Variable, Content highlight, and Media collection color editing on the approved shared visual core, including the compact map, tracks, channel fields, and format tabs.
- Simplified Media collection color editing by removing its unrelated preset grid and retaining the collection context, shared picker, and Cancel/Clear/Apply actions.

## v1.3.303

- Fixed the remaining Content Studio and Media Studio fullscreen cascade failure. The late shared open-panel centering transform can no longer shift half of a viewport-sized Studio offscreen.

## v1.3.302

- Corrected the shared color picker's Escape path so a cancelled valid draft is restored without the subsequent blur event committing it.

## v1.3.301

- Fixed Content Studio and Media Studio Full screen so shared panel geometry cannot preserve normal-view offsets, transforms, or size caps.
- Fixed Content Studio list requests on plain-permalink WordPress sites, including the return path after structured Import, by separating `rest_route` from endpoint query parameters.
- Removed the obsolete first-release explainer from Import and repaired shared color-picker typing, keyboard commit/cancel, and pointer dragging.

## v1.3.335

- **Everything mode Phase B — Plugins · Settings · Bricks scopes are live.** A new `everything-index` endpoint serves every wp-admin destination (captured from the admin menu on each admin load, so plugin pages like ACF, Settings ▸ *, Tools ▸ *, Bricks ▸ * are all included), cap-filtered per user, plus the installed plugins. Typing now returns real destinations — "acf", "permalinks", "site health", a plugin name, "bricks performance" — and `↵`/`⌘·Ctrl ↵` opens them in your chosen tab. The `⇥` scope control now cycles All · Pages · Plugins · Settings · Bricks.

## v1.3.334

- **Fixed the class/attribute suggestion icon chips** looking broken — the glyph is now sized and centred cleanly inside its chip.
- **Update-available banner in the Bar now matches Settings** — rounded corners and a more compact height (the Bar context was dropping the base radius).

## v1.3.333

- **Everything mode reimagined (Phase A).** The approved calm palette is now live: one ranked list (best match first, fuzzy), quiet category tags on the right, muted icons, faded scroll edges. It searches **commands + your pages/posts live** (Pages via WP REST). A keyboard-first segmented scope control — **`⇥` / `⇧⇥`** cycles All · Pages (wraps), clearing the box snaps back to All. `↵` opens a page in the Bricks builder in your chosen tab; **`⌘/Ctrl ↵`** opens in the other; the footer toggle sets the default. Elements/add-element left Everything (they have their own modes). *Plugins / WP settings / Bricks settings scopes land in Phase B with the everything-index endpoint.*

## v1.3.332

- **RR rename inside the component editor no longer kicks you out to the instance.** The deselect→reselect (needed for live structure refresh on normal elements) exited component-editing mode; inside a component it now refreshes the row in place without changing selection.

## v1.3.331

- **RR rename now reflects in the structure panel instantly, and works on component roots.** The rename replays Bricks' own deselect→reselect after writing the label (what clicking out and back in did), so the structure row updates live. Components need no special handling — a component root is just an element with a `label`.

## v1.3.330

- **RR rename now updates the structure panel immediately** (no more click-out/click-in). The shallow elements ref is nudged so Vue re-renders the row live.

## v1.3.329

- **Fixed RR rename not taking effect.** The label now writes to the element's top-level `label` (the key Bricks renders the structure-panel name from), in addition to `settings._label`. (Note: a component root may still display its component name rather than a per-instance label.)

## v1.3.328

- **Rename an element's label with a double-tap of `R`.** With an element selected in Bricks (and not typing in a field), tap `R` `R` to open a rename bar — the Bar in a Rename mode: the label comes pre-selected, the element's id / classes / attributes show as read-only pills, and the builder behind blurs. `↵` renames, `Esc`/click-out cancels. First of the planned double-letter shortcut family.

## v1.3.327

- **Everything mode results now actually run.** Clicking or pressing Enter on a result did nothing because the execute path was still guarded on the lost manager reference; it now resolves at call time, so Direct/Search/Add/Settings commands, page-element select, and add-element all fire.
- **Arrow-key navigation scrolls the highlighted result into view** in Everything mode and in the class/attribute suggestion list, so the active row is never hidden below the fold.
- **Suggestion list height increased to 2×** (was 1.5×) so more matches show at once.
- **Suggestion rows no longer bleed to the panel edge in Direct mode** — the results now inset to align with the input field.
- **Suggestion icons get a rounded background chip** (lime-tinted when the row is active), matching the mock.

## v1.3.326

- **Fixed Everything mode doing nothing.** It was throwing on every keystroke because its manager reference was lost during startup; the reference now resolves at call time, so on-page element search, add-element search, and the mode/settings shortcuts work again.
- **Bar suggestion polish.** Removed the lime left-accent bar on the active suggestion, widened the horizontal padding, and increased the suggestion list height by ~1.5× so more matches are visible at once.

## v1.3.325

- **Bar class suggestions now match the mock's design.** Each row has an icon (a selection glyph for on-element classes, a globe for site classes) and the matched part of the class name is highlighted in lime, alongside the existing group headers and badges.

## v1.3.324

- **Bulk "review selected" bar matches the mock.** The count is now an inline `40 selected` chip on the left (the old floating "REVIEW 40 SELECTED" pill sat on its own row above the actions), and the whole bar hugs into one row — Move-to · Move · Family (icon) · │ · ✕ · 🗑. Clicking the count still expands the selected-variables review list.
- **New Variable form uses the same type selector as the edit form** — the clean labels-only Color/Fixed/Fluid/Static segmented control.

## v1.3.323

- **Mimam's Bar class suggestions: fuzzy match + all site classes** (approved mock). Typing a class now matches fuzzily (`.splmed` finds `.split-content__media`), and suggestions include **every global class defined on the site**, not just the ones already on the selected element — so you can apply an existing class you aren't using yet. Results are grouped ("On this element" / "All classes on the site") with badges (on element · global · fuzzy).

## v1.3.322

- **Edit form type selector cleaned up.** The Color/Fixed/Fluid/Static row is now a clean labels-only segmented control (the small icons rendered washed-out) — clearer and on-brand.
- **Color swatch matches the value field height.** In the color editor the swatch was a fixed 42px while the value field is 38px; it's now sized to the control height so the box and input line up.

## v1.3.321

- **Variable edit form redesigned** (approved mock). The flat stack is now four clear sections — **Type** (a connected Color/Fixed/Fluid/Static segmented control), **Identity** (name with a live `--css-name` preview, plus category), **Value** (the per-type editor), and **Impact** (a card that only appears on rename — green "safe" when unused, amber otherwise, with the update-usages toggle and Preview impact). Same fields and behavior, just grouped and legible, with a proper Cancel / Save changes footer.

## v1.3.320

- **Bar shortcut now keeps focus when opened from a code editor.** Confirmed the editor (Code2Bricks) was refocusing its own textarea the instant it lost focus, so plain re-focus just ping-ponged back. MV now briefly disables the editor field so it can't reclaim focus, moves the caret into the Bar, then restores the field — no more bouncing back to C2B.
- **Class-chip badges have hover feedback.** Hovering the duplicate or remove badge now pops it (slight scale + brighten + glow) so they read as interactive, not decorative.

## v1.3.319

- **Duplicate-class icon is now a corner badge, matching the remove ×.** It floats on the pill's top-right corner just to the left of the × (same 20×20 size, shape, and hover scale-reveal) instead of sitting inline inside the pill.
- **Bar shortcut focus, harder try.** When opened from a code editor, MV now blurs the editor field and pulls focus back to the Bar input across a short window (30/90/180/320 ms), to beat editors that reclaim focus after open.

## v1.3.318

- **New/duplicated classes now show their real name immediately** in the Bar, not a raw id like `.hkszmp`. The Bar caches the class id→name map for 650 ms, so a just-created class rendered as its id until the cache expired and you reopened. Creating or duplicating a class now invalidates that cache, so the next render resolves the name. (Item 6.)
- **Copy icon now reveals on hover, exactly like the remove ×** — opacity-only (it keeps its slot, so the pill never resizes under the cursor), sitting right next to the ×.
- **Bar shortcut reliably moves focus off the code editor** — it now blurs the editor field and re-focuses the Bar input after open, so opening from Code2Bricks lands the caret in the Bar.

## v1.3.317

- **Bar shortcut now moves focus into the command field** when opened from a code editor. Opening the Bar from the Code2Bricks textarea worked, but the caret stayed in C2B; focus now follows into the Bar's input.
- **Fixed the duplicate-class icon flickering on hover.** The icon revealed itself by animating its width, which resized the pill under the cursor and caused a hover-flicker loop. It's now always visible next to the remove ×, styled the same way (dim, brightens on hover) — no reveal animation, no flicker.

## v1.3.316

- **Mimam's Bar: duplicate a class with its styles.** Hovering an existing-class chip now reveals a duplicate icon next to the remove ×. Clicking it clones the global class — a new `{name}-copy` class whose styles are a deep copy of the original — and applies it to the current element, so its chip appears ready to rename/edit. (Approved mock; the clone copies styles, per the chosen behavior.)

## v1.3.315

- **Bulk "review selected" bar cleaned up** (approved mock). Cancel and Delete are now compact icon buttons (× and trash) separated from the primary Move-to / Move / Family group by a divider, so the destructive Delete reads as clearly distinct instead of a flat cluster of text buttons.

## v1.3.314

- **Figma connection screen redesigned** (approved mock). It now opens with a clear connection-status header (● Not connected / Connected), then two numbered steps: 1) generate credentials with the pairing code and API key each in their own copyable field (one-click copy buttons), or 2) enter a code shown in the Figma plugin. Same actions, clearer flow.

## v1.3.313

- **Export formats are now a clear list, not ambiguous tabs.** The old export row looked like selectable tabs, so it wasn't obvious a click downloads. Each format is now a row with an icon, a one-line description, and an explicit **Download** button — System Bundle featured as the complete/primary format, with DTCG, Flat, Figma, and CSS as interoperability exports. (First of the approved review-pass redesigns.)

## v1.3.312

- **Mimam's Bar shortcut now opens from inside code editors.** When focus was in a text field — notably the Code2Bricks editor textarea — the Bar's open shortcut was ignored, so you had to click a canvas element first. A shortcut that uses a modifier (Ctrl/Cmd/Alt) now fires even from within an input/textarea (a plain-key shortcut still won't hijack typing).
- **Selected media tiles now show their checkmark.** The checked checkbox on media thumbnails resolved to `background-image: none`, so selected items were just a solid lime square. The checkmark SVG is now forced on the media selection state.

## v1.3.311

- **Variable changes now reflect on the site without a manual refresh.** The server already regenerated `variables.css` on every create/edit/delete, but the stylesheet `<link>` already loaded in the admin page and the Bricks canvas iframe still pointed at the stale file — so deleting a used variable (and other edits) only showed after reloading. MV now cache-busts those generated CSS links across the admin document and the canvas iframe whenever the variable set actually changes, so the change is live. Signature-gated so the background 30-second/focus refresh doesn't re-fetch needlessly.

## v1.3.310

- **Content Studio list no longer gets stuck on "Loading…".** Re-selecting the already-active content type (e.g. clicking Pages again after an import) bumped the load sequence and showed the spinner, but because the active nav hadn't changed the load effect never re-fired — so it spun forever with "0 items" until you closed and reopened the studio. Same-nav reselection now loads directly.

## v1.3.309

- **New setting: "Media Studio as Bricks media picker" (Settings → Studio defaults).** MV replaces the Bricks builder's media control with Media Studio; this toggle (default on) lets you turn that off so media controls open the native WordPress media library instead. The interception now checks the preference before taking over the `wp.media` frame.

## v1.3.308

- **The "Delete variable?" impact dialog no longer traps you.** With many affected consumers the box grew past the screen, pushing the Keep/Delete buttons off-screen with no way to scroll or dismiss — a full page refresh was the only escape. The dialog is now a fixed-height flex column (capped at 86vh): the header and action buttons always stay visible, the consumer list scrolls inside, and clicking the backdrop closes it.

## v1.3.307

- **Media Studio remembers the last collection you were in.** Reopening it (from Bricks or anywhere) returns to that collection instead of resetting to All media; if the remembered collection was deleted since, it falls back to All rather than opening empty.
- **Imported media titles no longer turn spaces into `20`.** A URL space is `%20`, and `sanitize_file_name()` stripped the `%` and kept the `20`, so `lagos image` imported as `lagos20image`. Percent-encoding is now decoded before sanitizing.

## v1.3.306

- **Unitless variables (font-weight, line-height, z-index, opacity, …) are no longer converted to `rem` on import.** The dimension normalizer applied the project's 10px-rem conversion to the whole `font` namespace, so a Figma `font-weight: 100` came through as `1rem`/`10rem` instead of `100`. Normalization now gates on the token *family*, not the namespace: weight/line-height/z-index/opacity/order/flex families pass through untouched, while real length tokens (font-size, space, radius, …) still convert as before.
- **New content defaults its author to the logged-in user.** Creating a page/post or opening the content importer now pre-selects the current user as author instead of the first author in the site list (you can still change it). Uses a new `current_user_id` field on the Content Studio meta endpoint.

## v1.3.294

- Content Studio now has a proper light/dark mode for the **whole studio**, not just the editor text. Previously the canvas toggle only recolored the writing surface, leaving the structure panel, toolbar, Publish/SEO/Block rail, and window header dark — so "light" looked half-broken. The theme is now lifted to the studio root and mirrored onto the panel frame, so one toggle themes the title bar, the STRUCTURE outline, the editor toolbar and paper, and the entire right rail together. The lime brand (`#baf400`) is kept for buttons, active pills, and fills; where lime would be text or an icon on a light surface it steps down to a readable dark‑olive (`#557a00`) so nothing is illegible. Dark mode is unchanged. The canvas control is now a segmented **Light / Dark** toggle (with sun/moon icons) instead of a single icon button, and your choice persists.

## v1.3.293

- Recovery no longer shows a "session expired" 403 or a frozen/"skipped" step after a guarded restore's database swap — the admin now refreshes itself cleanly through the swap. Root cause: the restore's job status lives in a database table, so the moment the destructive "Swap DB Tables" step replaces the live database with the backup's, the in-flight job row briefly vanishes (status 403 / "job not found") until RestoreBase re-seeds it. The status poller gave up after just 4 failed polls during that blackout, so it never observed the final "completed" status — which is what triggers the automatic admin refresh — and the last-seen step stayed painted as unfinished. The poller is now swap-aware: once it sees the restore enter the destructive swap zone it keeps polling patiently through the expected blackout, so it reaches "completed" and fires the clean auto-refresh (with a forced reload as a fallback if the row is slow to re-seed). Any nonce request that still races the swap now shows a calm "reconnecting after database swap" notice instead of the alarming 403. No restore/swap logic changed — this is entirely in the panel's polling and messaging.

## v1.3.292

- Recovery can now run a guarded restore on a live/production site, not just staging. The production restore path was blocking itself: after you typed the "RESTORE PRODUCTION" confirmation, the readiness assessment still counted "this site is production" as two danger checks (the environment check and the dry-run's "not staging" blocker), dropping the score to ~30 and failing at the ≥ 65 gate. The readiness/dry-run are now production-aware — when a production restore is explicitly confirmed, targeting a live site is treated as the intended condition, not a fault, while every real safeguard stays: the typed "RESTORE PRODUCTION" confirmation, package validation, disk-space check, danger-preview and WooCommerce-merge checks, and the pre-restore rollback snapshot. The staging ladder and the readiness UI keep their strict production-is-danger behavior. (Note: releases v1.3.289–v1.3.291 were shipped from another session and are not itemized in this source changelog.)

## v1.3.288

- Fixed MV darkening other plugins' code editors in the Bricks builder. MV loaded CodeMirror's stylesheet globally and then neutralized `.CodeMirror` to a transparent background across the whole page — which made Advanced Themer's Style Manager "Framework" CSS editor (and any other CodeMirror instance) go transparent/dark instead of keeping its own background. MV's CodeMirror CSS is now pre-scoped to its own `.ve-cm-host` editors (`codemirror.scoped.css`), and the global neutralization is removed, so foreign editors are left completely untouched — AT's editor keeps its light background whether MV is active or not. Resolves the recurring CodeMirror-bleed class of bug at the root (scoping, not counter-overrides).

## v1.3.287

- Snapshot Restore/Delete are now compact icon buttons (a counter-clockwise arrow and a trash icon, side by side) instead of stacked text buttons, so the Snapshots list reads cleaner. Hover/disabled states and tooltips retained.

## v1.3.286

- Snapshots are now manageable. Each snapshot has a **Delete** button (with a confirm), the list **auto-prunes** to the 20 most recent so recovery points can't grow unbounded, and creating a snapshot whose captured state is identical to the newest one **reuses it instead of stacking a duplicate** — which collapses the back-to-back "Before import" points. Added a `DELETE /sync/snapshot/{id}` route, `SnapshotManager::delete()` and `::prune()`.
- The migration **Preview** button now reads **"Re-preview"** once a preview exists, making clear it refreshes the scan rather than starting over.

## v1.3.285

- Fixed an imported scale family being wholesale skipped when its base collides on CSS name with an existing variable stored under a wrapper namespace. Concretely: an imported `space` family (base `space` → `--space`) unified with an existing `size.space` (which also resolves to `--space`, since `size` is a storage wrapper). `resolve_public_import_names` renamed the imported base `space → size.space` to merge them, but left the children's `source_name` pointing at the old `space`, so all 15 `space-*` steps plus their aliases were skipped as "source 'space' was not found" (22 items). The rename is now propagated to every child/alias `source_name`, so the family attaches to the unified base and imports cleanly. Reproduced the exact 22-item skip against the real registry+state and confirmed 0 after.

## v1.3.284

- Variable migration now imports base scale steps whose value is a long fluid `clamp()` formula. The scanner's "looks like a value" check rejected anything over 220 characters, but Advanced Themer's fluid `clamp()` values (with the full min-viewport/base-font math) run ~400–450 chars — so the base steps `font-size-s`, `radius-s`, and the entire `space-*` scale were silently dropped, which in turn orphaned every alias pointing at them (`font-size-caption`, `radius-default`, `section-content-title`, `space-grid-gap`, etc. → "source not found"). The cap is raised to 2000 chars (still guarding against whole-CSS blobs), so those steps import and their aliases resolve. Verified against the real registry: reproduced the exact skip list at 220 and confirmed 0 skips at 2000.

## v1.3.283

- Variable migration no longer lists **Core Framework** as a source when its plugin is uninstalled. Removing Core Framework leaves its options and the `core_framework_presets` table behind, which made MV keep showing it as an available source (a "ghost") and scan its orphaned tokens. The scanner now gates on the plugin being **active** (checks the active-plugins list for single-site and network, with a class/constant fallback); a removed framework stops appearing, and its leftovers are ignored — those tokens are read from Bricks/Advanced Themer instead. No data is deleted; the orphan rows are simply no longer surfaced.

## v1.3.282

- Imported color shades now sort in a sensible order inside each color family: all light steps first (`-l-1…8`), then dark (`-d-1…8`), then transparent (`-t-1…8`), instead of interleaving by step number (`-d-1, -l-1, -t-1, -d-2, …`). Matches the Advanced Themer Color Manager grouping. Display-only — no re-migration needed. Spacing/size (t-shirt) families are unaffected.

## v1.3.281

- Color migration now also brings across each color's **shade children** (the `-l-1…8`, `-d-1…8`, `-t-1…8` light/dark/transparent steps), not just the base colors. They import with their own stored values and nest as generated children under each base color, mirroring the Advanced Themer Color Manager. (v1.3.280 deliberately excluded them; this makes the import complete.)

## v1.3.280

- Variable migration now imports the **full** Advanced Themer color palette (all 14 base colors), not just the 6 theme-level ones. The complete palette lives in the `bricks_color_palette` option (v1.3.279 only read `bricks_theme_styles`), where the base colors sit alongside 252 auto-generated light/dark/transparent shades. The scanner now reads both options and skips any entry flagged `isShade`, so the semantic colors (`color-bg-body`, `color-bg-surface`, `color-text-body`, `color-text-body-reverse`, `color-text-title`, `color-text-title-reverse`, `color-border-primary`, `color-shadow-primary`) migrate in with their real values while the regenerable shades are left out. Verified against the real 266-entry palette export.

## v1.3.279

- Variable migration now imports the Advanced Themer / Bricks color palette. AT's Color Manager stores its palette in the `bricks_theme_styles` option — not in `bricks_global_variables` — so the migration scanner never saw it and imported zero colors even though the palette was populated. A new reader walks `bricks_theme_styles`, and for every color takes its portable CSS name from `raw` (`var(--color-primary)`) and its value from `rawValue.light` (`hsla(…)`), so the base palette (primary, neutral-light/dark, success, warning, error) now migrates into MV as color variables. Verified against a real exported palette.

## v1.3.278

- Fixed the styled tooltip still rendering ~350px wide in the Bricks builder. Once the native title was eliminated in v1.3.277, the remaining wide bubble was the styled card itself: a live console read showed computed `width:350px` while its own `max-width` was `220px` — which is only possible when an external `min-width` (set by Bricks/Advanced Themer) overrides the max-width. MV now forces `min-width:0` on the tooltip card (and `!important` on the compact variant), so nothing external can inflate it and compact tooltips hug their text in the builder exactly as they do in wp-admin.

## v1.3.277

- Actually fixed the raw, over-wide browser tooltip in the Bricks builder. v1.3.276 broadened the styled handler to match any MV surface, but that still relied on the mouseover handler intercepting before the browser painted its native `title` box — which it does not do reliably in the builder. This release removes the race entirely: an observer strips `title` off every MV surface the moment it is painted and mirrors it into `data-ve-tip` (which the browser cannot show natively and the styled tooltip reads). The browser therefore has nothing to render on its own — worst case is no tip, never the wide native one — and it runs in whatever frame the panel mounts in, so it is frame-independent.

## v1.3.276

- Fixed tooltips showing as the raw, over-wide browser title inside the Bricks builder. The styled-tooltip handler only intercepted elements inside #ve-panel-root; in the builder that lookup does not resolve to the hovered node's root, so the browser's own title tooltip showed instead. The handler now matches any MV surface, so styled tooltips render in the builder as they do in wp-admin.

## v1.3.275

- Fixed variable families not collapsing when a source filter (e.g. AT, CF) is active. The rows were force-expanded under a selected source, so the collapse toggle did nothing; the toggle now works in every view, defaulting to expanded in a source view and collapsed in All.
- Long tooltips now wrap to multiple lines within a moderate width instead of forming one over-wide, truncated bar; short tooltips still size to their text.

## v1.3.274

- Variable migration no longer aborts when a generated variable's source is missing ("Migration failed Add 'space-2xl': Generated variables require a valid source variable"). Preview's transitive skip now covers generated variables (not just aliases), so a generated variable whose source was itself skipped is removed with a warning and the remaining changes apply cleanly.
- The plugin's front-end runtime (Preact, CodeMirror) is now bundled with the plugin instead of loaded from a CDN, so the builder works offline, under strict CSP, and on privacy-strict hosts — the same reliability fix already applied to the Phosphor icons. GSAP, which was loaded but never used, has been removed.
- Fixed compact tooltips rendering too wide inside the Bricks builder; the bubble now sizes to its text regardless of the builder's global styles.

## v1.3.273

- Security (completes v1.3.272): the credentialed-CORS fix now also covers the REST response handler, not just the preflight handler. v1.3.272 hardened the OPTIONS preflight but the `rest_pre_serve_request` filter still reflected an arbitrary Origin with Allow-Credentials on actual responses (and it applies to all REST routes). Both paths now gate credentials to first-party origins only.

## v1.3.272

- Security: the VE REST API no longer reflects an arbitrary request Origin together with Access-Control-Allow-Credentials. That combination let any website make cookie-authenticated requests to a logged-in admin's API. Credentials are now sent only to the site's own first-party origin(s) (filterable via `ve_cors_allowed_origins`); all other callers — including the Figma plugin, which authenticates with an API key, not cookies — receive a credential-less wildcard.
- Security: the public pairing endpoint is now brute-force resistant. A wrong pairing code costs the pending code one of eight attempts before it is burned (turning a ~16.7M-guess search into an 8-guess one), attempts are throttled per IP, and the code comparison is timing-safe.

## v1.3.271

- Variable migration no longer aborts wholesale when a single alias cannot resolve its source at apply time ("Migration failed Add 'X': alias source 'Y' was not found"). One orphaned alias used to throw inside the apply transaction and roll back every other reviewed change. It is now skipped with a named warning — matching how the preview already treats unresolvable aliases — and the remaining changes apply, verify, and persist normally.
- Compact tooltips now size to their text. The JS width estimate is used only for positioning; forcing it as the bubble's width made short labels render as too-wide bubbles.

## v1.3.270

- Fixed the Migrate Variables preview collapsing into a thin bar. The preview list is a scrollable flex child, which lets flex shrink it to zero height when the panel content overflows; it now keeps its own height (min 96px, max 210px) and the panel scrolls instead.
- Fixed compact tooltips rendering as long caret-less pills. The bubble's own overflow:hidden — needed for text ellipsis — was clipping the caret, which sits just outside the bubble's edge. The ellipsis now clips an inner text element, so every tooltip keeps its caret.

## v1.3.267

- The "Pretty URLs are not active" warning no longer shows when everything actually works. The server-side probe requests its own domain, which false-negatives on local sites; the check is now advisory and the browser re-verifies it directly — the row shows "confirmed from this browser" on success and only warns (with instructions) when the browser cannot reach /wp-json either. An unreachable self-probe also no longer downgrades a clean restore to "passed with notes".

## v1.3.266

- The rewrite-rule repair now actually lands. Two silent no-ops defeated the v1.3.265 version: when several restore steps run in one request the rewrite engine still holds the pre-swap plain-permalink state (writing empty rules), and WordPress' own writer quietly refuses under PHP-FPM where it cannot detect mod_rewrite. The repair now re-initializes the rewrite engine from the restored permalink option and writes the rules block directly, so a manual Settings → Permalinks save should no longer be needed.
- If pretty URLs still do not answer, the post-restore verification report now says so in its own row with the exact action: "open Settings → Permalinks and click Save Changes once."
- "View restore steps" now renders as status dots with plain text in all report containers (the previous styling missed one), matching the job-card design.

## v1.3.265

- Found via console debugging: after a restore, the destination site could be fully restored yet look broken — the restored database brings pretty permalinks, but the destination's protected .htaccess had no WordPress rewrite rules, so every /wp-json request 404'd at the web server before WordPress ran. All Studios showed "WordPress returned an error while loading data" against a perfectly restored site.
- MV's panel now falls back automatically to the query-string REST route (?rest_route=), which needs no rewrite rules, whenever /wp-json 404s — and remembers the working form.
- The restore now repairs the rewrite rules itself: post-restore hardening loads the admin file helpers (flush_rewrite_rules cannot write .htaccess during AJAX without them), writes the standard rules, and probes /wp-json until it answers JSON, reporting a warning if the server still refuses.

## v1.3.264

- Fixed the last silent truncation point: the restore reads workspace copies of the package, and a partial extraction could leave a short files.restorebase that the bundle reader treated as a clean end — so a restore completed green while the site was missing its tail files. Prepare Workspace now verifies every extracted copy against the package's recorded checksums (re-streaming a bad copy once) and refuses the workspace with exact byte counts if it still mismatches — before anything destructive runs. The file-restore step is additionally held to the file count recorded at backup time and fails with "read X of Y" if the bundle ends early.
- "View restore steps" now matches the job-card design: a status dot and plain text per step instead of filled pills.

## v1.3.263

- Import now verifies bundle completeness: the file entries actually present in files.restorebase are counted and compared against the count recorded when the backup was built. A truncated package — the class that restored half a site while passing every checksum — is rejected at import with the exact counts ("holds 20,000 of 47,000 recorded files") instead of restoring silently.
- Fixed the footer status dot floating detached from its message when the text wraps to two lines.

## v1.3.262

- Fixed backups silently shipping only the first ~20,000 files. The bundler re-reads the file inventory on every batched request; if that read ever failed it came back empty, and the bundler finalized the truncated bundle as a success — which then passed every checksum, imported as "Verified", and restored half a site whose broken plugins turned Studio requests into HTML errors. The bundler now fails loudly when the inventory is empty or changes size mid-bundle, so an incomplete package can never be produced.
- The restore now runs WordPress' silent database upgrade when the restored database carries a different db_version, so wp-admin is no longer intercepted by the "Database Update Required" screen after a restore.
- Backup ages now show hours and minutes ("1h 22m ago") instead of rounding to the hour, and the Recovery footer gives its status message proper spacing instead of cramming it against the version text.

## v1.3.261

- A MV settings verification miss can no longer abort the restore. The settings step runs after the database swap but before files are copied and the site is finalized, so failing it left a half-restored site — files never copied, rewrite rules never flushed, Studios reading no content — which is the exact outcome it was guarding against. The step now always completes; a read-back mismatch stays visible in the step report and names the affected groups.

## v1.3.260

- Recovery backup creation now waits for current MV browser preferences to persist before its manifest is built. The portable Bar and Studio preference allowlists include the live panel, editor, media, and position settings, and restored server preferences replace stale local browser copies.
- Portable MV writes invalidate both direct and aggregate WordPress option caches plus user caches. Every carried group is read back, and a mismatch fails the restore task instead of being marked successful.
- The shared Studio API refreshes an expired WordPress REST nonce and retries once after a restore. Content Studio and Media Studio retain their current data and show the actual error if access still fails rather than displaying a false zero-item site.
- Post-restore hardening reloads the destination administrator's role/capability runtime.

## v1.3.257

- Fixed a restore being marked failed at the final "Restore MV Settings" step even though the database and files restored correctly. The MV settings verification read stale option values after the raw database swap (the autoloaded 'alloptions' cache was not cleared), so it wrongly reported the just-written settings as unverifiable. The cache is now cleared correctly, and — as a safeguard — MV settings portability can no longer fail a restore whose core work already completed; a verification miss is reported as a note and names the affected groups.

## v1.3.256

- Fixed backup import rejection ("incomplete or corrupted (files.restorebase)") for good, including on hosts where the v1.3.255 file lock was silently ignored. Two things now guarantee a package matches its own checksums: the backup job is serialized with a database advisory lock so two overlapping requests can no longer finalize the bundle at once, and the component checksums are recomputed from the files on disk in the same step that packages them, so the recorded size can never disagree with the shipped bytes. New backups made on this version import and restore correctly; backups built by earlier versions must be re-created.

## v1.3.255

- Fixed the backup-import "incomplete or corrupted (files.restorebase)" rejection at its real root. When a slow finalize outlasts the client's request timeout, the client re-issues the job and two executions finalize the bundle at once; the v1.3.254 guard still had a check-then-write race that let the end marker be written more than once. Finalization is now made atomic with an exclusive file lock, so exactly one end marker is written no matter how the requests overlap. New backups made on this version import and restore correctly.
- Fixed backup timestamps showing a wrong relative age (e.g. every backup reading "1h ago" the moment it was made) when the site timezone differs from the viewer's. The site's UTC offset is now used to compute the age.

## v1.3.254

- Fixed backups being rejected on import as "incomplete or corrupted (files.restorebase)". Under concurrent job polling the file bundle's end marker could be written twice, leaving the packaged bundle a few bytes larger than its recorded checksum. Finalization is now idempotent, so the recorded size always matches the packaged bundle. New backups made on this version import and restore correctly; backups built by earlier versions must be re-created.

## v1.3.253

- Backup filenames now use the Mimam's Var plugin version (e.g. v1.3.253) instead of the Recovery module's internal version (v1.0.0-rcNN).
- Import errors now state exactly why a package was rejected — whether a component is the wrong size (truncated) or fails its checksum (altered) — instead of a generic "download did not finish."

## v1.3.252

- Gave CSS Recipes its own Studio rail entry, so it shows the rail and stays reachable while other Studios are open, and stopped it being force-closed when CSS Studio is disabled.
- Bundled the Phosphor duotone icon set (MIT) with the plugin instead of loading it from jsDelivr, so icons no longer depend on a third-party CDN being reachable.
- Fixed Media Studio icons that silently fell back to a generic file glyph (Save metadata, Import, Restore, Insert Media URL, safety notes, and most of the collection icon picker).
- Replaced two icon names that are not in the Phosphor set (`bricks`, `wordpress-logo`), which rendered nothing on the Content Studio editor links.
- Replacing a content image now carries the new attachment's alt text across; it previously read a field the REST attachment does not have and kept the old alt.
- Fixed dynamic tooltips showing the previous label until the element was hovered twice, and made a tooltip repaint in place when its label changes under a stationary pointer (canvas theme toggle).
- Recovery now says a reload is needed when it is re-enabled after the page loaded, instead of appearing to do nothing.
- Fixed post-restore MV settings verification reporting a false failure. It compared the package against the destination outright, but the write is a merge: key order and destination-only keys both read as mismatches, which failed the step for Mimam's Bar and Studio preferences even though every value transferred.

## v1.3.176

- Optimized Media Studio collection query performance by implementing `ve_media_collections_list` Transient caching inside `MediaCollectionManager`, preventing N+1 taxonomy queries during REST lookups.
- Added dynamic WP taxonomy hooks (`created_mv_media_collection`, `edited_mv_media_collection`, `delete_mv_media_collection`, `set_object_terms`) to automatically invalidate the cached collections transient.
- Hardened SVG masonry previews by injecting min-width/height fallbacks to prevent raw SVG files lacking intrinsic dimensions or viewBox definitions from collapsing.

## v1.3.175

- Fixed SVG previews in Media Studio Masonry view by forcing SVG assets to use the original attachment URL before generated thumbnail sizes, preventing SVG helper/plugin placeholder stripes from appearing as line previews.
- Added final masonry SVG containment rules so vector previews sit inside stable card boxes without affecting the working image masonry layout, builder picker insert flow, or AT/Code2Bricks suggestions.

## v1.3.174

- Tightened Media Studio builder picker behavior after v1.3.173 QA.
- Improved builder Masonry view with safer image-first picker filtering, larger/steadier masonry cards, fewer cramped columns, and cover-based thumbnail filling for non-SVG images.
- Made media double-click insertion independent of browser `dblclick` reliability by tracking two close clicks on the same media item, while disabling media dragging in picker mode so drag behavior cannot swallow the insert action.
- Preserved the restored Advanced Themer and Code2Bricks suggestion behavior from v1.3.173.

## v1.3.173
- Fixed Media Studio Masonry view inside Bricks Builder by forcing stable masonry card boxes in nested builder overlays, including SVG/line-art assets that were collapsing into thin strips.
- Changed the Masonry toolbar/dropdown icon to the clearer Columns icon instead of the previous custom masonry icon.
- Fixed double-click media insertion by detecting browser click detail and adding double-click event aliases, so draggable media cards still insert in builder picker mode.
- Restored Mimam's Var's CodeMirror runtime/addons so Advanced Themer, Code2Bricks, and Bricks code editors keep their autocomplete/suggestion behavior. MV's hint styling remains scoped to CSS Studio only, so suggestion styles should no longer leak into other editors.

## v1.3.172
- Reworked the Masonry view icon to a clearer uneven-column masonry symbol.
- Hardened Media Studio masonry cards inside Bricks so very wide/tall assets cannot collapse into thin line cards.
- Fixed the picker insert button so it no longer receives the click event as the media item.
- Fixed the WordPress media-frame bridge callback context so Bricks receives selected media from both Use Selected Media and double-click selection.
- Stopped the picker flow from falling back to copying the media URL when Bricks insertion fails.
- Removed Mimam's Var's global CodeMirror CDN enqueue so CSS Studio no longer overrides Code2Bricks, Advanced Themer, or other builder code editor styling/suggestions. CSS Studio still uses its own fallback editor and will use an existing complete CodeMirror instance when another tool already provides one.

## v1.3.171
- Fixed Media Studio URL import history Clear button styling so it no longer inherits the compact icon-button sizing.
- Stabilized Media Studio Masonry view with explicit media aspect placeholders so thumbnails do not collapse into a thin line before images load.
- Added a dedicated Masonry view icon instead of reusing the grid icon.
- Added builder picker double-click support: double-clicking a media item now inserts/uses the selected media immediately when Media Studio is opened for picking.
- Scoped CSS Studio CodeMirror hint styling and hint containers to the CSS Studio editor so Bricks/native builder code editors and suggestion popups are not affected.

## v1.3.170

### Fixed

- Contained Content Studio rich-editor images so inserted media cannot break the editor/SEO layout.
- Reverted the editor theme control to a compact text toggle.
- Improved Content Studio media picker collection rendering with parent/child indentation and faster prepaint from cached media when switching collections.
- Hid the extra editor note strip and added safer scroll padding above the fixed action area.
- Added final Content Studio layout overrides for toolbar centering, action bar consistency, code blocks, and editor image sizing.


## v1.3.169 - Content Studio Picker + SEO Polish Regression Fix
- Normalized Media Studio masonry SVG sizing and gap handling.
- Restored Content Studio media picker collection list from WP-backed collection maps.
- Tightened Content Studio editor/metadata/SEO layout so sections do not create stray empty bands.
- Improved keyword pill styling, light/dark editor toggle styling, centered editor utility buttons, and SEO check labels.

# v1.3.168 — Content Studio Picker + SEO Editor Refinement

- Fixed Media Studio masonry SVG sizing so small SVG assets fill their masonry column width while preserving natural aspect ratio.
- Upgraded the Content Studio media chooser toward the Media Studio experience with collections, default masonry view, grid/list switching, refresh, search, drag/drop upload, and upload button support.
- Tightened Content Studio editor layout so the content editor remains on the left, meta fields stay on the right, and SEO sections no longer overlap during scroll.
- Centered Clear/Undo/Redo in the content editor toolbar and changed the Light/Dark control to a compact icon toggle.
- Improved focus keyword pills: better contrast, equal padding, and full-height alignment inside the keyword input row.
- Added visible code-block styling for the rich editor.
- Improved SEO check rows with live pass/fail wording and stronger pass/fail styling.
- Calmed the SEO field surface background while keeping the SERP/social previews distinct.

# v1.3.167 — Content Studio Layout + Picker Cleanup

### Fixed

- Tightened SVG masonry cards so SVG previews no longer carry extra visual wrappers or artificial card height/width.
- Reworked Content Studio edit layout so the content editor sits on the left and the post meta panel sits on the right.
- Removed the sticky meta-panel overlap while scrolling the edit form.
- Converted the writing theme control into a real compact toggle.
- Centered Clear/Undo/Redo in the editor toolbar.
- Improved focus keyword pill/input height alignment.
- Polished the MV media picker grid so image cards use consistent usable preview sizes.
- Normalized Content Studio border radius and replaced the dark action-footer block with a quieter panel footer.

## v1.3.166 - Content Studio Media Picker + Editor Layout Polish

### Fixed
- Equalized Media Studio masonry spacing again and removed the dark card background from SVG previews.
- Replaced browser prompt dialogs in the Content Studio rich editor with MV inline dialogs.
- Replaced the default WordPress media chooser in Content Studio SEO/social image fields with a native MV Media Studio picker so Content Studio stays open.
- Added a split Content Studio edit layout with title/status/slug/excerpt on the left and the writing editor on the right.

### Added
- Added a light/dark mode toggle to the Content Studio writing editor.

### Changed
- Tightened oversized SEO/social image URL inputs and focus keyword input height.
- Moved rich-editor utility actions to the far right of the toolbar.

# 1.3.165 - Content Studio Scroll + Masonry Gap Fix

- Fixed Media Studio Masonry spacing so row and column gaps use the same masonry gap token.
- Removed conflicting masonry item margins so vertical spacing is controlled by the masonry column gap only.
- Fixed Content Studio edit mode so the form has a real internal scroll area instead of compressing all sections to fit the modal height.
- Kept the action bar fixed outside the scroll area while the content/SEO/custom-field sections scroll naturally.

# 1.3.162 - Content Studio Writing + SEO Polish

## v1.3.164 — Masonry row gap + Content Studio spacing polish

- Restored visible row spacing in Media Studio Masonry by applying the gap directly to the JS masonry columns and individual cards.
- Reworked the Content Studio edit screen into a roomier structure: metadata panel, larger writing editor, larger SEO workspace, and more breathing space between sections.
- Increased rich editor height and padding so writing no longer feels squeezed.
- Enlarged the Rank Math-style SEO workspace with wider field/preview columns while keeping the live preview/checks on the side.


## v1.3.163 — Content Studio Rank Math workspace + masonry restore

- Restored real Media Studio masonry by using medium/large natural-ratio previews instead of square thumbnails.
- Fixed Media Studio collection expand/collapse persistence so stable collection keys are not overridden by old label-based state.
- Restored the Content Studio rich writing surface even when a post type reports editor support inconsistently.
- Rebuilt the Rank Math area into a two-column SEO workspace with live SERP/social previews, focus keyword pills, checks, social image controls, robots options, schema type, and advanced placeholders that respect free/pro limits.
- General SEO values now update live previews immediately, including slug/permalink changes; Facebook and Twitter previews fall back to general values unless edited directly.


- Optimized Media Studio previews so Masonry no longer asks for full/original image files and images use lazy/async loading outside detail preview.
- Restored visible row spacing in the JS Masonry columns.
- Hardened Media Studio collection tree collapse persistence with stable collection-key storage plus legacy path fallback.
- Replaced the large Content Studio dashboard cards with compact status pills that include counts.
- Added Content Studio table column visibility controls, similar to Media Studio list metadata controls.
- Strengthened Content Studio action icons so the right-side action buttons do not render as empty boxes.
- Hid noisy analytics/plugin meta such as view counters from editable custom fields.
- Expanded the Content Studio rich content editor with H4, underline, strikethrough, code, link, image URL, divider, clear formatting, undo, and redo controls.
- Added editable Rank Math SEO, canonical, robots, Facebook/Open Graph, and Twitter fields inside the Content Studio edit form.
- Added first-pass ACF Options Page discovery and editing under a dedicated Options Pages section in Content Studio.

# 1.3.161 - Content Studio Cleanup + Masonry Stability Polish

- Rebuilt Media Studio Masonry view into JS-distributed columns so the full result set renders vertically instead of showing only the visible slice.
- Made the Media Studio view switcher easier to use with delayed hover close, click toggle, and outside-click dismissal.
- Cleaned Content Studio edit forms by hiding noisy Rank Math internal fields and removing the Advanced WordPress Fields panel from the main Studio flow.
- Hid Plugin/System Types from the Content Studio sidebar for now so the panel stays focused on real content records and custom field groups.
- Increased Content Studio sidebar width to better match the Media Studio adjustment/sidebar feel.
- Forced Content Studio rich-editor text and heading colors to stay readable inside the dark MV UI.
- Restyled Content Studio table actions into primary actions and compact icon actions for a calmer right-side area.

# 1.3.160 - Default Content Types Polish + Masonry Ratio Fix

- Fixed Media Studio Masonry view to preserve image aspect ratios and avoid horizontal scrolling.
- Polished Content Studio default Pages/Posts area with MV-style sidebar groups, dashboard cards, table rows, hover actions, and form inputs.
- Added Rank Math SEO summary data for Pages/Posts in Content Studio.
- Added Bricks post type support detection so Edit in Bricks only appears for post types enabled in Bricks settings.
- Kept WP editor access visible for block/plugin-specific editing.

# v1.3.159 — Media Studio View Fixes + Content CRUD Layer

- Fixed the Media Studio view dropdown so Grid, Masonry, and List render as clear MV-styled menu rows.
- Reworked Masonry View away from CSS multi-column layout so it scrolls top-to-bottom instead of creating horizontal scroll.
- Added richer Content Studio content CRUD: create with title/status/slug/excerpt/content, edit core fields, duplicate as draft, move to Trash, restore from Trash, and permanently delete from Trash.
- Added Content Studio status dashboard cards and status tabs for Active, All, Published, Drafts, Pending, Private, and Trash.
- Added CPT label editing for MV-created ACF/Jet post types, while keeping existing CPT create/delete behavior.
- Added a REST duplicate endpoint for Content Studio posts/CPT entries and strengthened content create/update handling.

# v1.3.158 — Media Studio Filter/Masonry Cleanup

- Cleaned the Media Studio filter popover so search results are visible first and diagnostics no longer cover filtered results.
- Restyled the diagnostics Rescan action as a proper MV button and hid diagnostics while typing in filter search.
- Removed the extra sidebar overview note now that dashboard cards own those stats.
- Added Masonry View as the third media view alongside Grid and List.
- Kept collection tree collapsed/expanded state persisted through the existing Media Studio local preference store.

# v1.3.157 — Media Studio Dashboard Summary Cleanup

- Removed the duplicate bottom-left Total Assets / Storage Used stats card from the Media Studio sidebar.
- Left the top dashboard overview as the single source for total media, storage, missing alt text, unused media, large files, and recent uploads.
- Added a small sidebar note so the sidebar no longer looks like a second dashboard.

# v1.3.156 — Media Studio Safety, Export, Diagnostics

- Fixed the attached collection context menu placement so the Delete row stays inside the rounded menu box.
- Added Media Studio diagnostics endpoint for total size, missing alt, large files, recent uploads, missing files, empty titles, and duplicate filenames.
- Added selected-media ZIP export from the bulk action bar.
- Added usage-aware delete and replace confirmation checks, with detected references shown before destructive action.
- Added rollback history for replace, convert, compress, and rename operations, with restore support from Media Studio.
- Added URL import history storage with success/failure entries and a small recent-imports panel in the URL import preview.

## 1.3.155 - Media Studio tooltip placement fix
- Reworked MV global tooltip positioning so long tooltips are measured/estimated before placement.
- Tooltips now sit fully outside the hovered control, avoid the cursor, and fall back to side placement when there is not enough room above or below.
- Native browser title bubbles continue to be converted into MV-styled tooltips inside the panel.

## 1.3.154 - Media Studio feedback polish

- Removed the duplicate Total Media overview card because total assets and storage already live in the sidebar summary.
- Replaced blocking media-loading whitespace with a non-blocking toast so grid/list content does not jump.
- Added a robust 5-second auto-dismiss for completed Media Studio progress toasts, including unused-image scan completion.
- Improved collection context-menu bottom padding and kept attached-menu arrow support.
- Clarified the bulk Compress tooltip: it rewrites supported selected image files through the WordPress image editor to reduce size, then refreshes metadata.

## 1.3.153 - Media Studio list, filters, bulk actions, and overview polish
- Media Studio: added a compact dashboard/overview strip for total media, missing alt text, unused images, large files, and recent uploads; overview cards activate the matching quality filter.
- Media Studio: polished the filter panel with active filter chips, a save-current-filter flow, and saved custom filter presets stored per browser.
- Media Studio: refined list/table view with sticky headers, selected/checked row states, stronger title/meta cells, thumbnail previews, and drag support from list rows.
- Media Studio: polished bulk actions into a clearer action bar with grouped Add to collection, Compress, Convert, Remove from collection, and Delete actions plus progress toasts.
- Media Studio: added a server-side image compression endpoint for selected image bulk compression.

## 1.3.152 - Media Studio color picker compact polish
- Media Studio: removed the internal scroll from the collection color picker and clamped the full compact popover into view instead.
- Media Studio: cleaned the selected color state so it uses a simple MV-style active ring instead of the dirty double/boxy mark.
- Media Studio: tightened the picker spacing and map height so the color popover fits without feeling unnecessarily tall.
- Native WordPress Media Library replacement remains paused.

## 1.3.151 - Media Studio positioning, scan timeout, and toast polish
- Media Studio: fixed the collection color picker so it opens inside the visible Media Studio panel instead of dropping to the floor/edge.
- Media Studio: fixed the Unused Images scan timeout guard so it actually stops the visible scan state after 35 seconds instead of staying stuck.
- Media Studio: restored the collection context-menu caret and added bottom breathing room so lower menus no longer sit tight against the edge.
- Media Studio: extended MV toast/progress completion visibility to 5 seconds so feedback is readable.

## 1.3.150 - Media Studio scan, color, menu, and ZIP polish
- Media Studio: restyled the collection color picker fields to stay on MV's dark input style instead of using light native-looking inputs.
- Media Studio: removed the dirty check badge from active collection color swatches and replaced it with a cleaner active ring.
- Media Studio: hardened the Unused Images scanner with a frontend stop guard, clearer timeout messaging, and a faster server-side scan path.
- Media Studio: clamped collection context menus with a taller measured height and scroll guard so lower menus no longer get cropped.
- Media Studio: changed ZIP import progress so upload progress caps before extraction, preventing the toast from claiming 99% too early.

## 1.3.149 - Media Studio filter and color picker polish

- Media Studio: polished the collection color picker toward the MV Variable Panel style and removed the duplicate/odd clear swatch, leaving one clear action in the footer.
- Media Studio: added multi-rule quality filters so Missing Alt Text, Unused Images, Recent Uploads, Large Files, shape filters, and size filters can be combined instead of being limited to one active rule.
- Media Studio: stopping/removing the Unused Images filter now clears the visible scan state and ignores stale scan responses, so the UI no longer keeps scanning after the filter is removed.
- Media Studio: added a safety timeout for long unused scans with a useful message to narrow collection/search/type filters and rescan.
- Media Studio: improved ZIP import progress feedback with Uploading ZIP percentage, Extracting ZIP busy state, and final completion feedback.
- Media Studio: refined Usage & replace impact hover styling and added a clearer open affordance on detected usage rows.
- Native WordPress Media Library replacement remains paused.

## 1.3.148 - Media Studio feedback polish

- Media Studio: restored clean metadata panel styling in both admin and builder surfaces, with stronger scoped input/textarea/button rules.
- Media Studio: fixed the collection color popover so it opens beside the clicked action and no native browser/OS color picker is used in this flow.
- Media Studio: moved Delete filter to the top of the filter panel and removed the duplicate shortcode card from Collection Details.
- Media Studio: changed Missing Alt Text and Unused Images long-running operations to use toast/progress feedback instead of replacing the media grid with a large empty busy block.
- Media Studio: optimized the Unused Images scan by batching reference detection across featured images, content, post meta, and options instead of doing one heavy scan per attachment.
- Media Studio: made the Unused Images rescan button disabled while a scan is already running.
- Media Studio: improved replace-file progress with upload/proccessing states and broadcast replaced media updates to other open Media Studio tabs.
- Media Studio: added clearer usage-impact helper copy and padded replace-history layout.
- Native WordPress Media Library replacement remains paused.

## 1.3.147 - Media Studio unused scanner, ZIP import, metadata polish

- Media Studio: replaced the collection custom color browser input with an MV-native color panel, opened beside the clicked menu/action instead of the OS picker.
- Media Studio: added an Unused Images filter backed by a server-side usage scan across featured images, content, post meta, and options.
- Media Studio: added ZIP import into a selected MV collection, with imported files assigned immediately to that collection.
- Media Studio: improved the Missing Alt Text workflow with inline saving and a bulk fill from clean filenames/titles.
- Media Studio: added a collection detail side panel with count, storage size, shortcode, lock/star/color status, quick actions, ZIP import, and collection preview.
- Media Studio: polished attachment details with caption/description editing, explicit save state, URL/tag copy actions, file-size data, and replace history.
- Native WordPress Media Library replacement remains paused.

## v1.3.146

- Media Studio: made starred collections meaningful by pinning them above normal collections and showing a visible star indicator on the collection row.
- Media Studio: replaced the random color-cycling action with a proper color picker modal, preset swatches, custom color input, Apply, Clear, and Cancel actions.
- Media Studio: added explanatory copy to the color picker so collection color is understood as a Media Studio accent only.
- Native WordPress Media Library replacement remains paused and was not touched.
- Plugin version bumped to 1.3.146.

## v1.3.145

- Made the MV media collection taxonomy more explicitly internal/private so SEO plugins should stop treating collection terms as public URLs.
- Persisted locked/starred/color collection metadata to WordPress-backed MV collections.
- Hardened locked collections: lock state now survives refresh/server sync and blocks rename, delete, move, add media, and remove media until unlocked from the context menu.
- Added collection context menu items for Star, Change color, Download all, and Copy gallery shortcode.
- Added Recent Uploads to the Media Studio filter list and renamed Missing Alt to Missing Alt Text.
- Plugin version bumped to 1.3.145.

## v1.3.144
- Media Studio: improved collection drag labels so reorder states now show “Before [collection]” and “After [collection]”.
- Media Studio: made the make-child/nest drop zone easier to reach, so users no longer need to drag far to the right.
- Media Studio: locked collection icons are now static and cannot unlock/open/move the collection by accidental click. Unlock remains available from the right-click menu.
- Plugin version bumped to 1.3.144.

## v1.3.143
- Fixed stale Add Media hover state after cancelled or incomplete media drags.
- Improved collection drag/drop state separation with clear Move Before, Move After, Make Child, and Add Media states.
- Added collection drop-after handling so children can be promoted back to parent level more reliably.
- Fixed nesting insertion so parent/child tree order stays intact after moving collections.
- Made collection list ordering tree-aware so expanded parent children render under their parent instead of breaking when object order changes.
- Kept Media Library replacement paused and full-area MV upload behavior intact.
- Plugin version bumped to 1.3.143.

## v1.3.142
- Locked page/background scrolling while the MV Settings panel is open in admin surfaces.
- Refined Media Studio add-media drop styling: rounded MV-style row, no thick left border, cleaner action pill.
- Fixed collection drag detection so collection reorder/nest states no longer fall back to the add-media drop state.
- Cleared stale media-drag state when starting a collection drag so selected media does not confuse collection reordering.
- Removed native cursor-covering tooltips from collection drag handles.
- Plugin version bumped to 1.3.142.

## v1.3.141
- Media Studio: removed the native browser tooltip from the collection drag handle so the drag hint no longer sits on top of the cursor.
- Media Studio: updated add-media, reorder, and nest drop indicators so each state has a distinct MV-styled visual treatment using the MV green accent instead of the blue temporary styling.
- Media Studio: fixed collection tree movement so dragging a parent into another collection moves the whole subtree, and dragging a child before a top-level collection promotes it back to that level.
- Media Studio: kept full-area MV file upload behavior from v1.3.140 and kept native WordPress Media Library replacement paused.
- Plugin version bumped to 1.3.141.

## v1.3.140
- Restored Media Studio full-area custom upload drop design while keeping native WordPress Media Library replacement paused.
- Removed the capture-phase drag guard that blocked React collection/media drag handlers, restoring collection dragging and drop styling.
- Replaced the aggressive event-blocking WordPress uploader suppression with a passive overlay hider so MV drag interactions can continue working.
- Kept WordPress core blue uploader overlay hidden while Media Studio is open, but allowed MV's own dark upload overlay for real OS file uploads.
- Fixed click-only drag candidates so simple collection clicks do not leave internal drag flags stuck.
- Plugin version bumped to 1.3.140.

## v1.3.139
- Paused native Media Library replacement remains enforced.
- Fixed Media Studio internal drag issue by suppressing WordPress core uploader overlay while Media Studio is open and during MV internal drags.
- Kept upload support restricted to the explicit Media Studio dropzone.
- Hid the auto-sync external folders setting unless an external folder plugin/folder source is detected.
- Removed the extra footer divider line in Settings → Modules.
- Plugin version bumped to 1.3.139.

## v1.3.138
- Paused the native WordPress Media Library replacement again so Media → Library stays on the default WordPress media screen while this flow is rebuilt safely later.
- Removed the runtime setting toggle for native Media Library replacement and replaced it with a paused status badge.
- Disabled the full-page blue file-drop overlay in Media Studio; uploads now rely on the explicit dropzone/upload control while collection/media drag behavior is stabilized.
- Kept drag/drop upload support available through the dropzone, without allowing internal media/collection drags to trigger the full-screen overlay.
- Plugin version bumped to 1.3.138.

## v1.3.137
- Fixed Media Studio runtime setting saves so toggling the native Media Library replacement no longer resets module enable/disable states.
- Hardened Media Studio internal drag detection so collection/media drags do not trigger the full-screen file upload overlay.
- Restored accurate expand/collapse tooltip copy for collection tree toggles.
- Plugin version bumped to 1.3.137.

## v1.3.136
- Fixed Media Studio regression where internal collection/media dragging could still trigger the full-screen “Drop files to upload” overlay.
- Preserved media selections across collection navigation so users can select media from multiple collections before taking batch actions.
- Restored the collection batch bar inside MV collection views by adding the missing `Remove from Collection` handler.
- Added safer removal logic that removes only selected media belonging to the currently open collection and keeps selections from other collections.
- Changed collection branch hover copy to neutral “Toggle children” to avoid wrong expand/collapse tooltips.
- Made the native Media Library replacement legacy switch safer by removing the active class and reloading the Media Library page after switching back.
- Added stronger internal drag detection with custom dataTransfer markers and capture-phase marking.
- Plugin version bumped to 1.3.136.

## v1.3.135
- Fixed Media Studio file-drop overlay so internal collection/media dragging no longer triggers the full-screen upload overlay.
- Restored SEO notices; MV no longer hides Rank Math/SEO notices for internal media collection taxonomy actions.
- Improved collection switching while media is selected: switching collections now clears selection and opens the requested collection with a notice.
- Fixed batch action bar reliability inside individual MV collections and kept Remove from Collection available there.
- Added safer native Media Library replacement close/legacy handling and a close button in the native replacement header.
- Reworked Mimam’s Bar Quick Help into a cleaner flat layout with no gradients, better alignment, and command rows that do not collide.
- Added stronger separation for collection reorder, nesting, and media-add drag states.
- Plugin version bumped to 1.3.135.

## v1.3.134
- Added URL import preview before server download so users can review filename, host, content type, and known file size before importing.
- Kept the 50 MB URL import limit, but now oversized files are blocked at preview when the remote server exposes Content-Length.
- Fixed Media Studio collection manual reordering by switching the collection sort to Manual after drag reorder.
- Improved collection drag/drop indicators with separate states for reorder, make-child/nest, and add-media drops.
- Added right-side drag hover behavior: dragging a collection toward the right side of another collection now previews dropping it as a child.
- Added “Remove from Collection” to the selected-media batch action bar when viewing an MV collection.
- Cleaned the Media Studio collection sidebar separator so the New Collection area no longer appears with double divider lines.
- Added autofocus/select behavior for collection name fields when creating collections.
- Hid external SEO redirect notices generated for the internal mv_media_collection taxonomy after collection rename/delete.
- Improved native Media Library replacement positioning so Media Studio scrolls into view immediately on Media → Library.
- Removed gradients from the MV Quick Help panel and tightened its visual language.
- Plugin version bumped to 1.3.134.

## v1.3.133
- Moved Media Studio URL import into the main toolbar beside Search media so it stays on the same row as search and filters.
- Restyled the URL import input with stronger admin-safe styles so WordPress admin input defaults do not make it appear unstyled.
- Changed the URL import action icon to a Phosphor `cloud-arrow-up` icon and kept the button aligned with MV toolbar controls.
- Added clearer URL import feedback for protected page links such as Pexels video/photo pages and forbidden remote downloads.
- Plugin version bumped to 1.3.133.

## v1.3.132
- Added WordPress-backed MV Media Collections using a dedicated attachment taxonomy so Media Studio collections are no longer only browser/localStorage data.
- Added REST endpoints for listing, creating, updating, deleting, syncing, assigning, and querying Media Studio collections.
- Added automatic migration/sync from existing local Media Studio collections into the WordPress-backed collection system.
- Added loopable media collection output through the `[mv_media_collection]` shortcode and a Bricks-friendly query hook for `mv_media_collection` object-type experiments.
- Re-enabled the native WordPress Media Library replacement toggle and added an instant “Use legacy library” switch inside the Media Studio replacement page.
- Added optional URL-import-to-open-collection support so imported media can land inside the current MV collection.
- Plugin version bumped to 1.3.132.

## v1.3.131
- Antigravity package handoff build. Media Studio work continued from the v1.3.130 state.

## v1.3.130
- **Improved Bulk Targeting Accuracy:** Hardened bulk selection logic by combining results from both Bricks data and canvas DOM. This ensures that mixed elements (e.g. Basic Text set to custom tag `li` vs native list items) are correctly unioned and targeted at the same time without omitting any matches.
- Plugin version bumped to 1.3.130 and Mimam’s Bar module version bumped to 0.3.28.

## v1.3.129
- Added a Mimam’s Bar setting to skip the bulk preview confirmation from Settings → Mimam’s Bar. Bulk commands still use the guarded matching/apply path and still stop above the safety limit.
- Fixed combined selector matching for commands like `all li.bulk-lab__item => data-anim="fade-up"` when Bricks exposes the element type as Basic Text instead of the rendered custom tag.
- Added a safe DOM fallback for class/comma/combined bulk selectors when Bricks element data does not expose enough selector information.
- Updated MV Quick Help again with the new skip-preview setting and clearer combined selector examples.
- Plugin version bumped to 1.3.129 and Mimam’s Bar module version bumped to 0.3.27.

## v1.3.128
- Added combined bulk target support in Mimam’s Bar: `all li.card-item`, `.card.is-featured`, comma groups like `all h2, all p`, and mixed class groups like `.card,.panel-card`.
- Kept bulk matching safe by using Bricks element data first and bounded canvas fallback only where needed.
- Updated the bulk preview wording for combined targets so it describes tag/class/ID combinations clearly.
- Updated the Quick Help panel with clearer Direct Mode, Bulk target, Combined selector, and mode-switch examples.
- Updated the inline example chips in Mimam’s Bar to include combined selector bulk commands.
- Mimam’s Bar module version bumped to 0.3.26.

## v1.3.127
- Improved Mimam’s Bar bulk confirmation wording with clear Target, Action, Scope, and Safety rows.
- Redesigned the bulk confirmation modal with a cleaner premium card layout, stronger visual hierarchy, and clearer primary action label.
- Mimam’s Bar module version bumped to 0.3.25.

## v1.3.126

- Fixed Mimam’s Bar bulk parser getting stuck on commands like `all li => data-anim="fade-up"`, which caused Firefox/Bricks to throw repeated out-of-memory errors before apply could finish.
- Bulk commands now consume the full input after parsing once instead of re-parsing the same `=>` command forever.
- Bulk tag matching now checks Bricks element data before touching the canvas DOM, and the DOM fallback uses a streaming TreeWalker instead of `querySelectorAll` to reduce memory pressure.
- Mimam’s Bar module version bumped to 0.3.24.

## v1.3.125

- Bulk syntax now forces Mimam’s Bar back into Direct mode without clearing the input.
- Page Search/Add Element live search is suspended immediately when the input looks like a bulk command.
- Pending element-search timers are cleared before opening/applying bulk confirmation.
- Bulk commands can now be applied with Enter even if the bar was previously in Search Page mode.
- Reduced the chance of Search Page scans fighting the console-proven bulk writer and causing Firefox/Bricks memory pressure.
- Mimam’s Bar module version bumped to 0.3.23.

## v1.3.124

- Rebuilt bulk apply from the console method that worked on Ahlfigh Bricks page.
- Bulk tag matching now uses canvas rendered `li` IDs and resolves them through the safe Bricks dynamic elements root.
- Removed Vue `toRaw` usage from the bulk ID lookup and light write path.
- Removed automatic full page element pre-scan when Mimam’s Bar opens.
- Disabled command suggestions while typing bulk syntax so Direct mode does not do unrelated selected-element suggestion work.
- Skips target refresh after successful bulk apply to avoid unnecessary selected-element attribute re-rendering.
- Mimam’s Bar module version bumped to 0.3.22.

## v1.3.124
- Hotfixed bulk apply memory path again for `all li => data-anim="fade-up"`.
- Bulk confirmation no longer scans/counts Bricks elements before the user confirms.
- Tag-based bulk matching now tries a canvas DOM ID lookup first, then resolves only those Bricks element IDs.
- Added bounded iterative fallback scanning with a hard guard instead of full cached tree scans.
- Light bulk writer now works on raw element/settings data where possible to reduce Vue reactive setter pressure.

## v1.3.122
- Hotfixed bulk tag matching and bulk attribute writes for commands such as `all li => data-anim="fade-up"`.
- Added lightweight bulk tag matching so `li` targets use Bricks settings/default tags instead of iframe DOM/Vue helper calls.
- Added a lightweight bulk attribute/id writer for simple bulk commands to avoid cloning/stringifying full element settings.
- Bulk apply now marks changed elements once after the batch instead of doing heavy per-element commit work.
- Reduced memory pressure in Firefox/Bricks during bulk preview/apply.

## v1.3.121
- Hotfixed Mimam's Bar bulk apply performance for commands like `all li => data-anim="fade-up"`.
- Removed verbose per-element bulk console logging that could retain large Bricks/Vue objects and exhaust browser memory.
- Stopped forcing a fresh full Bricks tree scan for every bulk preview/apply step.
- Reworked bulk commits to avoid iframe Vue-state crawling and deep equality checks per target.
- Batch invalidates caches and requests Bricks refresh once after bulk apply.

# CHANGELOG.md

## v1.3.82 — Dev

### Fixed
- Fixed the main MV panel boot crash caused by the toast helper being referenced before it was initialized during early module guard setup.
- Restored the normal floating MV launcher and admin-bar launcher target after confirming the panel boots in a real browser engine without falling back to the emergency MV button.

## v1.3.81 — Dev

### Fixed
- Hardened the WordPress admin-bar MV launcher so it binds immediately and through delegated click handling, even when admin footer scripts run after `DOMContentLoaded`.
- Added direct app-side `veToggleVariables` / `veOpenSettings` entry points so the toolbar and emergency controls can open MV without relying only on custom event timing.
- Added a small emergency MV boot button if the panel runtime fails before rendering, including a pre-boot guard for missing Preact/runtime dependencies.

## v1.3.80 — Dev

### Fixed
- Restored the MV floating launcher/speed dial after the native Media Library replacement could leave Media Studio marked open while the popup was not rendered.
- Scoped native Media Library replacement CSS so it no longer treats the whole MV root/backdrop as embedded page content, keeping the settings gear available as the global escape hatch.
- Preserved the embedded Media → Library page replacement while keeping Settings and the speed dial accessible.

## v1.3.79 — Dev

### Fixed
- Reworked Media Studio Masonry to use a direct natural-proportion column flow instead of the manual lane renderer, preventing square-grid fallback, empty guide columns, and non-scrollable masonry panels.
- Strengthened Admin/Builder module deactivation propagation so disabled CSS Studio, Media Studio, Plugin Studio, and Mimam’s Bar states are saved, rebroadcast, and refused/closed across shortcuts, speed dial, global toggles, Mimam’s Bar, and builder media interception.
- Tightened the opt-in native WordPress Media Library replacement so Media → Library embeds MV Media Studio inside the normal admin content area rather than behaving like a popup overlay.
- Corrected tall image preview wrappers so Fit width, Actual size, and Pan/zoom use the full image surface from the real top-left.
- Preserved the working media drag-to-collection path while keeping internal media drags separate from upload drop overlays.

## v1.3.65 — Dev

### Fixed
- Folder-plugin parent folders now count and filter media from all descendant folders, so a parent like `Project Files / Brands` reflects child assets instead of showing `0`.
- Detected folder-plugin rows no longer display the `MV` pill; only MV-owned local collections show `MV`.
- The folder migration modal now uses proper compact MV buttons for Select all and Clear actions instead of tiny link-style controls.

### Changed
- Settings and Media Studio use the same descendant-aware folder counting logic so sidebar counts, settings counts, filtering, and migration previews stay consistent.

## v1.3.64 — Dev

### Changed
- Redesigned the Media Studio folder-plugin integration settings card as a real nested MV tree with leaf-only labels, line guides, folder icons, counts, and quiet `MV` badges.
- Shared Media Studio folder expand/collapse state between the sidebar and Modules settings so the same hierarchy state persists locally after reload.
- Replaced the old external-folder badge language with `MV` across local and external folder rows so migrated and MV-shown folders use one product vocabulary.

### Fixed
- Fixed Modules settings only showing a detected-folder count by making the actual folder hierarchy visible and manageable before migration.
- Removed leftover browser-default/small-text risk in the touched folder migration surfaces.

## v1.3.63 — Dev

### Changed
- Polished Media Studio folder migration layouts so setting rows, action controls, and helper text follow the current MV height and spacing rhythm.
- Added visual line guides to the nested Media Studio sidebar hierarchy tree so sub-collections read as a clear structure rather than a flat list.
- Persisted Media Studio sidebar and Modules settings folder expand/collapse state locally so the tree stays where the user left it after reloads.
- Changed external folder badges to `MV` to match the current product language for MV-managed or migrated folder data.

### Fixed
- Fixed sidebar list node parsing and layout regressions that could break nested folder display.

## v1.3.62 — Dev

### Added
- Folder Hierarchy Display: Render nested collections in a visual hierarchy tree in the sidebar, showing only the leaf names for nested collections, with tree caret toggles to expand/collapse sub-collections and a compact "EXT" badge for external folders to avoid text overlap.
- Folder-Plugin-to-MV Migration UI: Added a folder-plugin migration section under Media Studio settings in Modules settings. Added a clean warning confirmation modal to migrate all detected folders to local collections, toggle hiding of external folders in the sidebar, and confirm action.
- State Synchronization: Real-time event communication between the settings panel and Media Studio for seamless layout updates without page reload.

## v1.3.61 — Dev

### Removed
- Completely removed the codebase languages distribution bar from the settings General tab.


## v1.3.60 — Dev

### Fixed
- Reverted builder panel user interface styling from rem back to px, resolving the 1.6x layout enlargement caused by the WordPress Admin root font-size.
- Fixed settings panel tab container class name and layout to prevent squishing, restoring visibility to all tabs (General, Mimam's Bar, CSS Studio, Modules).
- Relocated codebase languages bar from the Sync sub-panel to the General Settings tab.
- Corrected Notion integration active checks and release notes.


## v1.3.59 — Dev

### Added
- Integrated a GitHub-style languages distribution bar (PHP 78.5%, JS 18.2%, CSS 3.3%) into the builder settings panel to visualize codebase distribution.

### Changed
- Redesigned snapshot cards in the builder panel to look like proper UI cards: Restore and Delete/Archive buttons look like proper clickable actions, spacing is structured, and metadata (Snapshot number, exact timestamp, affected counts) is clear and readable.
- Refactored builder UI styling to use the centralized variable system instead of hardcoded static values.
- Implemented a 10px = 1rem grid rhythm with rem-based margins, padding, and font-sizing, enforcing an 11px (1.1rem) minimum text size boundary.
- Converted the database cleanup action to be unconditionally visible in the Database settings section.

### Fixed
- Fixed category and palette name isolation during Figma/file imports to prevent leakage into fallback options when origin data is empty or generic.

## v1.3.58 — Dev

### Fixed
- Snapshot titles and descriptions are now correctly decoded and rendered in the UI even when the snapshot is flagged as "Unavailable" due to warnings or validation failures.
- Converted the inline "Create recovery point" form into a clean dialog modal shown only when clicking "+ New Snapshot".
- Stale or orphaned generator rows referencing deleted or non-base variables are now automatically identified and deleted during database cleanup to prevent snapshot validation failures.
- General `/sync/apply` and `/sync/drift/apply` imports (from Figma or files) now correctly isolate variables under their own source-named categories and color palettes instead of fallback AT/CF options.
- Fixed empty Description tab in WordPress 'View details' modal by providing explicit HTML sections in the dev manifest.
- Updated plugin row metadata links to display: `Version | By Hebronmimam | View details | User Guide | Support | FAQs | Cheat Sheet`, pointing Hebronmimam to `hebronmimam.com` and User Guide to Notion documentation.

### Reliability
- Updated the verification checklists and ensured all PHP 7.4 compatibility rules are fully validated.

## v1.3.57 — Dev

### Added
- Provenance pills now act as source filters for MV, FILE, Figma, AT, CF, and ACSS.
- Source counts and a source-wide selection action now compose with Category, Color Palette, and text search.
- Sync Drift compares Mimam's Var with the paired Figma collection or Bricks global-variable registry.
- Sync Drift supports previewed Pull and Push plans, explicit conflict rows, snapshot-protected pulls, adapter-owned Bricks pushes, and queued paired-Figma pushes.
- Manual snapshots now support a meaningful title and optional description.

### Changed
- Snapshot cards now explain what each recovery point protects and show the snapshot number, time, source file, and reviewed change count where available.
- JSON, DTCG, Flat, CSS, System Bundle, and Sync Drift imports attach readable context to their automatic pre-import snapshots.
- The Figma companion now publishes a current collection report and processes partial queued Drift pushes without replacing its full WordPress-to-Figma identity map.

### Reliability
- Expanded the core reliability suite to 158 assertions covering snapshot context, composable provenance filtering, source-wide selection, Drift preview/apply contracts, Bricks adapter ownership, and paired Figma reporting.

## v1.3.56 — Dev

### Added
- Native variables now display a compact `MV` provenance pill.
- Generic JSON, DTCG, Flat, and CSS file imports now display a `FILE` provenance pill.

### Changed
- Provenance pills use a quieter neutral surface, softer border, restrained text color, and lower font weight so they support scanning without competing with variable names and values.
- File provenance now follows imported value updates, generated-family repairs, and alias relinks instead of being limited to newly created rows.
- Existing AT, CF, ACSS, and Figma provenance remains distinct and explicit.

### Reliability
- Expanded the core reliability suite to 152 assertions with coverage for DTCG, Flat, Figma collection, Figma handoff, explicit-origin preservation, update propagation, alias relinks, and MV/FILE UI labels.

## v1.3.55 — Dev

### Fixed
- Figma, flat JSON, and framework imports now decide generated-child editability from the active MV generator registry instead of unreliable historical `generator_type` labels.
- Imported/manual family children such as `text-2xl` update in place while preserving their parent, exact token name, value, relationship metadata, and source tag.
- True calculated generator children no longer roll back an otherwise valid import when an external file contains a different child value.

### Changed
- Import Preview now shows calculated child differences as `LOCK` rows with a direct explanation that the base variable or generator settings own the value.
- Protected calculated rows are excluded from the Apply count and safely skipped during normal imports and external migrations.

### Reliability
- Expanded the core reliability suite to 144 assertions with an import scenario matrix covering unchanged rows, base updates, alias relinks, editable imported families, calculated-family protection, repeat-import idempotency, and external verification.

## v1.3.54 — Dev

### Fixed
- Applying an UPDATE to an existing imported generated child no longer routes through the normal editor that blocks generated-variable edits.
- Figma and flat imports now preserve the existing parent relationship and `imported` generator type when updating generated children such as `radius-l`.
- Calculated Color and Fluid generator children remain protected from direct imported-value edits.

### Reliability
- Added regression coverage for parent preservation, imported generator-type preservation, and calculated-family protection.

## v1.3.53 — Dev

### Fixed
- Import Preview no longer proposes `ADD` for an exact generated variable that already exists, including T-shirt family children such as `radius-l` and `text-xl`.
- Applying a Figma handoff or flat import containing existing generated children no longer rolls the complete import back with a duplicate-variable error.
- Explicitly imported generated children still remain excluded from deletion when omitted from a partial import, while changed children preview as updates.

### Reliability
- Added regression coverage for unchanged and changed hyphenated T-shirt generated children.

## v1.3.52 — Dev

### Fixed
- Sync/import validation errors where different dot-notation names (such as `size.text.2xl` and `text.2xl`) would map to the same public CSS custom property (`--text-2xl`) and crash validation.
- Figma plugin exports now calculate and include `public_css_name` and `external_css_name` to enable rename matching during WordPress import.
- WordPress importer now computes robust default fallbacks for `public_css_name` and `external_css_name` if they are missing or empty in flat sync or handoff files.

## v1.3.51 — Dev

### Added
- Direct Figma local-file handoff using a dedicated companion format (`mimams-var-figma-handoff` JSON) exported from the Figma plugin for offline imports.
- Re-styled Figma pairing panel to include an option to export the local handoff file.

### Fixed
- Sync/import now preserves variable alias relationships, mapping incoming Figma variable aliases (which point to parent variables) correctly as `type: 'alias'` and resolving their source links.
- Set imported Figma variables' origin metadata explicitly to `'figma'` to display a clean origin badge.

## v1.3.50 — Dev

### Fixed
- Usage & Impact no longer counts the `bricks_global_variables` definition registry as a real consumer.
- Persisted Bricks references are separated from the currently open Bricks document and display the saved post title plus post ID.
- Generic saved references now appear under Other WordPress storage instead of being mixed with Bricks content.

### Changed
- Single and batch deletion now use a wider MV-styled impact dialog with a clear destructive header, readable token name, contained consumer list, and balanced Keep/Delete actions.
- Navigating from an affected consumer closes the delete confirmation before opening the destination.

### Reliability
- Added regression coverage for registry exclusion, saved Bricks labeling, usage-source separation, and the redesigned delete confirmation.

## v1.3.49 — Dev

### Added
- Variable detail now shows a unified Usage & Impact view covering aliases, Themes, CSS Studio stylesheets, custom CSS Recipes, current Bricks elements, and matching WordPress storage.
- Usage rows navigate directly to the referenced variable, Theme manager, exact CSS Studio stylesheet, CSS Recipe, or Bricks element where supported.
- Variables with no detected consumers are clearly marked Unused.
- Rename, type-change, family relationship, single-delete, and batch-delete surfaces now show affected consumers before changes are applied.

### Changed
- Searchable Family selectors rank exact and prefix token matches above broad substring matches.
- Arrow Up/Down, Home/End, and Enter now navigate and select the highlighted Family option.

### Reliability
- Bricks and CSS Recipe usage scans are lazy and run only when a Usage or Impact surface is opened.
- Added regression coverage for keyboard selection, relevance ranking, usage navigation, unused status, and mutation impact previews.

## v1.3.48 — Dev

### Changed
- Family Destination root, Current family root, and New root selectors now span the full available panel width.
- Family root and child dropdowns now include token-name search with an explicit no-results state.

### Reliability
- Searchable behavior is opt-in to the Family selectors, preserving the dimensions and behavior of compact dropdowns elsewhere.

## v1.3.47 — Dev

### Fixed
- Shift-range checkbox selection no longer highlights variable names and values between the selected rows.
- Family root detection now derives the current family from the selected generated children when they share one parent, instead of falling back to the first family in the dataset.
- Selecting children such as `text-xl` through `text-7xl` now opens Change Root against their actual `text` family.

### Reliability
- Added regression coverage for non-selectable variable rows and selected-child common-parent inference.

## v1.3.46 — Dev

### Fixed
- Select All now visibly checks every matching root and expanded generated-child checkbox instead of updating only the batch count.
- Individual and Shift selection now use the same normalized numeric identity as Select All, preventing string-versus-number ID mismatches.

### Reliability
- All checkbox rendering, selected-row styling, range checks, and Select All state now read from one normalized selected-ID set.
- Regression coverage rejects direct mixed-type row-ID comparisons.

## v1.3.45 — Dev

### Fixed
- The selected-variable review tray now opens automatically when one or more selected variables move outside the current visible list.
- Closing the automatically opened tray remains respected until the hidden selection set changes.

### Changed
- The batch control now says `Review … selected` and shows a hidden-selection count, making its purpose and the missing rows explicit.

## v1.3.44 — Dev

### Fixed
- Variable, generated-child, and Select All checkboxes now render their checked mark through MV-owned styling, preventing Bricks builder CSS from hiding the selected state.
- The selected-count review control now sits above the batch actions instead of consuming horizontal action space.
- The review tray opens above the relocated selected-count control without overlapping it.

### Changed
- Move, Family, Cancel, and Delete now receive the full batch-action row width in narrow panels.

## v1.3.43 — Dev

### Fixed
- Selected root variables and generated children now use a clear MV-accent row state instead of relying on the checkbox alone.
- Batch selection no longer becomes mysterious when selected variables are filtered, collapsed, unloaded, or outside the viewport.
- Stale selections are removed automatically when their variables no longer exist.

### Added
- The selected-count control now opens a review tray listing every selected token.
- The review tray identifies selections outside the current view and supports individual removal or Clear all.

## v1.3.42 — Dev

### Fixed
- Hides the floating batch action bar while the Family subpanel is open.
- Adds checkboxes to expanded generated children so Ungroup and Reparent operate on the intended child rather than its root.
- Opens row-level Manage Family directly in the current family context and limits new-root choices to that family’s children.
- Preselects a clicked child as the candidate new root.

### Added
- Shift-click range selection across the exact visible order of roots and expanded children.
- Focused helper text and checkbox tooltips explaining Shift-range selection.

### Changed
- A selection containing only imported/manual children defaults to Ungroup; Reparent remains available through the Action selector.
- Family-context actions use the current family’s children instead of passing unrelated variables into the operation.

## v1.3.41 — Dev

### Added
- Added previewed manual family management for grouping, ungrouping, reparenting, and changing a family root without re-importing.

### Changed
- Variable names, exact values, CSS names, aliases, source pills, and Theme values remain untouched during relationship changes.
- Color Palette ownership follows the selected family root, while generated children continue inheriting membership.
- The Category tabs strip now reads as one balanced control with an aligned fixed manager lane and contained MV-styled scrollbar.
- Routine update-reactivation and Bricks save/reload checks are now risk-based instead of repeated for unrelated releases.

### Safety
- Added safety snapshots, stale-preview protection, transactional dependency updates, CSS export rollback, and calculated-generator protection.

## v1.3.40 — Dev

### Changed
- Imported T-shirt scales such as `text-xs`, `text-m`, `text-2xl`, `space-*`, `shadow-*`, and `radius-*` now group beneath a clean imported root like generated families while preserving every original token and value.
- Rootless T-shirt families use the `m` child as the initial clean-root value when available and remain manually selectable in Migration Preview.
- Imported T-shirt children display in logical size order from the smallest `xs` step through the largest `xl` step.
- The Category manager action now occupies a fixed area beside the scrollable Category tabs instead of floating over the final tab.

### Fixed
- Dropdown scrollbars now use the shared MV dark track and accent thumb instead of the platform-native scrollbar.
- Category tabs now clip and begin horizontal scrolling before the fixed Category manager action.
- Lone variables ending in `-s`, `-m`, or another recognized scale suffix are not grouped unless sibling evidence confirms a family.

### Documentation
- Added the MV scrollbar rule to the permanent agent and UI quality guidance.

## v1.3.39 — Dev

### Added
- Update checks now report and obey the site's selected Stable, Beta, or Dev channel across both the branded updater and WordPress's native Plugins screen.
- Repeat migration previews with no applicable changes keep a disabled “No changes to apply” control visible.

### Changed
- Development releases now publish to the Dev manifest only; Beta and Stable remain untouched until explicitly promoted.
- Migration Preview uses the panel's main scrollbar instead of a second scrollbar inside Imported family base values.
- Migration actions and the detected-variable summary remain together in a sticky bottom surface.
- Select menus render in a viewport-level layer and automatically open upward when there is not enough room below.
- Imported generated-family children sort naturally by numeric token step rather than by their converted value.

### Fixed
- Update manifests are cached independently by channel and feed URL, preventing one release lane from leaking into another.
- Changing the update channel immediately clears Mimam's Var and WordPress native update caches.
- Imported family roots inherit the AT, CF, or ACSS source pill from their imported children.
- Long imported-family selector labels remain on one line without breaking the card layout.

### Documentation
- Persisted the Dev-first release policy in the agent operating rules, architecture decisions, and release runbook.
- Added/updated tester-facing Mimam's Var onboarding documentation in Notion.

## v1.3.38

### Added
- Migration Preview now shows an Imported family base values section for rootless imported scales. Users can choose which original child supplies the clean root value before Apply.
- Manual imported-family base choices are remembered per source and reused on later migrations.

### Changed
- Rootless imported scales now create a clean root such as `color.mellow-apricot` instead of a synthetic `color.mellow-apricot.base`.
- The `500` child is selected automatically as the initial root value when available; otherwise the closest numbered step is used.
- Imported children remain generated-style organizational children while retaining their exact external names and values.
- Trailing external `base` labels are removed from semantic token names and normalized alias sources, so `color-error-base` imports publicly as `color-error`.

### Fixed
- Diff and Apply no longer recreate `.base` fallback variables when repairing or importing numbered families.
- Repeated migrations preserve the user's selected family root value instead of resetting it to the automatic default.

### Packaging
- The latest verified Figma plugin ZIP is now kept in the Vengine root alongside the latest WordPress install ZIP, with prior root Figma packages archived in `old/`.

## v1.3.37

### Changed
- External migration now derives Color Palette ownership from the selected scanner and AT/CF/ACSS origin metadata instead of trusting only the normalized preview category.
- Imported generated-family rows resolve to their persisted root color before Palette assignment, so the base owns the family while every supplied child value remains unchanged.
- Reusable source Palettes are found by stable name as well as slug, preventing an existing `Bricks / Advanced Themer` Palette from being missed because of earlier slug history.

### Fixed
- Bricks / Advanced Themer migrations no longer allow reviewed root colors to remain in or fall back to Palette One when preview metadata has been normalized.
- Migration Apply now verifies source Palette membership after the final repair pass and rolls back with an explicit error instead of reporting a false success.

## v1.3.36

### Changed
- Color and protected Uncategorized tabs now expose the same right-click Category menu as user Categories, with Rename and Remove shown in a disabled state to communicate that system organization cannot be changed.
- Advanced Themer colors use the stable reusable Color Palette name `Bricks / Advanced Themer`; an earlier `Advanced Themer` source Palette is reused and relabeled instead of duplicated.

### Fixed
- Category context menus now render in a viewport-level layer, clamp within the visible window, and no longer clip against the horizontally scrolling tab strip.
- The global pointer handler no longer removes the Category menu before Rename or Remove receives its click event.
- Category Rename and Remove use dedicated POST actions, restoring reliable operation on WordPress environments that interfere with PUT or DELETE requests.
- External migration now reconciles Palette ownership for every reviewed incoming root color, including unchanged, updated, and newly imported rows, instead of considering only rows represented in the variable diff.

## v1.3.35

### Added
- Right-click (context) menu on user Category tabs in the builder panel with quick Rename and Remove actions (system-protected tabs like Uncategorized are excluded).
- Modals for renaming and deleting Categories directly from the tabs bar.

### Fixed
- Color migration palette placement attempted to include imported/updated colors in their source-named Color Palette; v1.3.36 completes this by reconciling every reviewed incoming root color.

## v1.3.34

### Added
- Non-color variables now use independent user-managed Categories instead of token-derived namespace tabs. Existing variables start in protected `Uncategorized`, while users can create, rename, delete, and batch-assign categories without changing token names or CSS.
- External migrations create source categories for Advanced Themer, Core Framework, and Automatic.css, and imported rows display compact `AT`, `CF`, or `ACSS` origin pills.
- Snapshots now have a dedicated header action and preserve variable Categories and source-origin metadata.

### Changed
- Snapshots have been removed from Sync so backup and rollback are available directly from the main Variable Engine toolbar.
- The migration source cards, callout, badges, result cards, and actions no longer use decorative icons.
- MV System Bundles now carry Categories and origin labels alongside variables, generators, Themes, and Color Palettes.

### Fixed
- Imported colors are assigned to a reusable source-named Color Palette before general Palette repair can claim them for Palette One.
- Multi-source migration creates separate source Palettes and Categories instead of collapsing imported variables into a generic destination.
- Full variable editing no longer references a removed namespace-prefix field.

## v1.3.33

### Changed
- Bricks / Advanced Themer migration now reads only the registered global-variable collection and no longer harvests Bricks theme-style settings as fake variables such as `general-settings-*`.
- Registered Mimam's Var mirrors are always excluded from Bricks migration. Core Framework and Automatic.css registry mirrors are excluded when their owning engines are detected, while an orphaned registry copy remains available as a fallback when its engine is absent.
- Imported numeric and dark/light/tint families such as `bg-body-5`, `bg-body-10`, and `bg-body-d-1` are grouped beneath their detected base variable like generated children.

### Fixed
- Imported family children retain the exact values supplied by Advanced Themer instead of being recalculated from the base.
- Previously imported flat family rows can be repaired into nested imported-child relationships without a blocking TYPE change.

## v1.3.32

### Fixed
- Imported CSS color values now appear in Color even when their semantic names are dotless families such as `bg-body-*`, `bg-surface-*`, or `border-primary`.
- Color Palette eligibility now recognizes strict hex, RGB/RGBA, HSL/HSLA, HWB, LAB/LCH, OKLAB/OKLCH, `color()`, and `color-mix()` values without relying only on the `color` namespace.
- Updating to this version repairs Palette membership for previously imported unowned color-valued variables.

## v1.3.31

### Fixed
- External migration now creates missing imported alias and generated sources recursively with their reviewed relationship type instead of temporarily storing them as base variables.
- Alias chains such as `section-title-to-content` → `space-grid-gap` → its source now survive post-Apply verification without a false type mismatch rollback.
- New imported aliases can no longer inherit stale generated-base state from a previous change in the same migration loop.
- Circular imported source relationships are stopped with a specific error instead of recursing indefinitely.

## v1.3.30

### Changed
- External migration verifies the reviewed rows directly against stored variables after Apply, checking canonical values, alias/generated types, and source relationships.
- Verification errors now identify the exact affected token and expected versus stored state inside the migration panel.

### Fixed
- Post-migration verification no longer reuses the broad general import diff, which could treat destination-only variables or acceptable inferred generated topology as an unresolved reviewed change and roll back a valid import.
- The generic repeated migration rollback now has actionable diagnostics if any genuine persistence mismatch remains.

## v1.3.29

### Changed
- MV interface text now has a 10px minimum across the Variable Panel, migration UI, studios, helper text, badges, metadata, and Mimam's Bar styling. This follows the product's 10px = 1rem design convention.
- External migration Preview canonicalizes incoming dimension values through the same 10px-root rem conversion used by variable storage.

### Fixed
- A reviewed value such as external `10` now previews and verifies as `1rem` instead of being stored as `1rem` and then falsely compared against `10`.
- Large Advanced Themer migrations no longer roll back with “imported variables did not match the reviewed preview” solely because of expected px/rem normalization.

## v1.3.28

### Changed
- Color is now the only category automatically retained during external migration. Non-color framework paths are flattened into portable tokens in the general Base line, such as `bricks.border.primary` becoming `border-primary`; users can add their own categories later.
- Dotless variables display under Base instead of creating a tab named after each token.
- Long migration requests continue server-side if the builder panel closes and receive the WordPress admin memory allowance plus a bounded execution window.

### Fixed
- External migration defers per-variable generated CSS writes and performs one final verified export, removing hundreds of redundant full-file rewrites from large imports.
- Migration success now requires every reviewed affected name to exist after the transaction.
- Network/server failures are caught and shown in the migration panel; the header progress state says Failed instead of falsely saying Complete.
- The migration panel closes as soon as a verified successful response arrives, before the variable list refresh begins.

## v1.3.27

### Changed
- External Bricks, Advanced Themer, Core Framework, and Automatic.css imports now remove storage/source wrappers and derive semantic names from the variable itself. Examples include `base.font` becoming `font`, `bricks.border.primary` becoming `border.primary`, and a color-valued `brickstheme.brand.primary` becoming `color.brand.primary`.
- Imported aliases retain a mapping to their original external CSS custom-property names so source normalization does not break `var()` relationships.
- Variable rows, generated children, detail panels, edit panels, and generator panels now show the complete public CSS token name without dot notation or a leading `--`.
- Large variable namespaces render in batches of 100 with an explicit Load More action.

### Fixed
- Builder variable mirroring now coalesces overlapping refreshes, skips unchanged frame/provider updates, and avoids repeated multi-stage retries.
- Variable refresh events are debounced and background polling is less aggressive, reducing panel lag and freezes on large installations.

## v1.3.26

### Changed
- After external migration, the panel waits for the authoritative variable reload, opens the namespace containing the first affected variable, and only then reports completion.
- Namespace tabs now explain on hover that they come from the first segment of variable names.

### Fixed
- Concurrent cross-frame variable refresh requests can no longer let an older response overwrite newer imported data in the panel.
- External migrations now appear in Mimam's Var immediately without requiring a page reload.

### Clarified
- Variable tabs are derived namespaces, not separately stored folders. A namespace is added through a variable's category, and it disappears automatically when no variables remain in it.

## v1.3.25

### Changed
- External migration Apply now uses the exact prepared variable payload that the user reviewed instead of discarding it and rescanning the source independently.
- Successful migration feedback includes the number of changes actually written.

### Fixed
- External migration can no longer report success when it wrote zero variables.
- After Apply, the server re-diffs the reviewed payload against Mimam's Var. If intended changes remain, the safety snapshot is restored and the operation reports a verification failure instead of a false success.
- External migration preview, apply, verification, metrics, and tests now share one definition of applicable non-deletion changes.

## v1.3.24

### Changed
- Rebuilt Migrate Variables around a stronger MV-dark visual hierarchy inspired by the supplied reference: framed information callout, icon medallions, source-specific Phosphor duotone icons, compact status badges, icon-led actions, reconciled result cards, warning callout, and a clearer change list.
- Migration preview now uses one server-owned count model for detected, ready, new, changed, skipped, and unchanged rows. The Apply button uses the exact same ready count.
- Phosphor duotone icons are the default icon language for new and touched MV controls, badges, callouts, statuses, and actions wherever a meaningful icon exists.

### Fixed
- In-panel updates now preserve and explicitly restore the plugin's previous activation scope after installation, including normal site activation and multisite network activation.
- External migration assigns only newly added colors to the source-named imported palette. Existing colors and aliases keep their current palette ownership.
- Preview and Apply maintain independent loading labels and never show the other action's loading state.

## v1.3.23

### Changed
- Improved the visual aesthetics of the Migrate Variables sub-panel: added a dark, glassmorphic layout for source cards and callouts, replaced loud background colors with premium callouts/alerts, and added distinct, styled badges for migration actions and statuses.
- The preview summary math now includes type changes, relationship changes, and repairs in the "changed" count, perfectly aligning the summary count with the Apply button count.

### Fixed
- External migrations now tolerate and skip CSS custom property conflicts (e.g., when two different names map to the same CSS custom property like `text.base` and `size.text.base`) and report them as warnings, preventing a single clash from failing the entire migration.
- Fixed the button loading states sharing the same boolean variable, ensuring the Scan button shows "Scanning..." and the Apply button shows "Applying..." independently and cleanly.

## v1.3.22

### Added
- Plugin updates can now be installed directly inside Mimam's Var through WordPress's native plugin upgrader.
- After an in-panel update succeeds, a branded confirmation dialog offers **Refresh Now** or **Later** so the newly installed runtime is loaded intentionally.
- External migration previews now report unresolved source aliases as explicit skipped warnings.

### Changed
- Long-operation progress now appears inside the header of the active MV panel, with a stable operation label, staged percentage, waiting ceiling, and clear 100% completion state inspired by the RestoreBase panel pattern.

### Fixed
- A stale Bricks or Advanced Themer alias whose source no longer exists no longer blocks hundreds of otherwise valid migration rows.
- Alias chains that depend on an unresolved external alias are skipped together, while resolvable aliases continue through preview and apply normally.
- The Settings update action and shared update notices no longer redirect away to the WordPress updater screen.

## v1.3.21

### Changed
- Long-operation progress now tracks only known time-consuming work instead of every Mimam's Var API request.
- The progress bar advances once toward a waiting point, holds calmly while server work continues, then fills to completion without restarting or repeatedly sweeping.

### Fixed
- Post-operation refresh requests no longer replace the active progress label or restart the progress animation.
- External migration treats a safe base or static variable becoming an alias with an explicit source as a LINK change instead of blocking it as a manual type change.
- Generated variables remain protected from direct type conversion and still require manual review when an import attempts to turn one into an alias.

## v1.3.20

### Added
- Added a shared branded progress bar for Mimam's Var API work that lasts longer than a brief interaction.
- Progress feedback identifies common operations such as scanning or importing external variables, preparing or restoring a System Bundle, creating or restoring snapshots, generating variables, and updating Themes or Color Palettes.
- Quick requests complete without flashing the progress surface; longer requests show an honest indeterminate bar and a short completion state.

### Changed
- Successful external migration, token import, System Bundle apply, and snapshot restore now refresh builder variable stylesheets and runtime consumers immediately.
- System Bundle LINK guidance now covers both alias and generated source relationships.

### Fixed
- External migration carries public CSS names through reconciliation, preventing alternate stored forms such as `color.color.2` and `color.color-2` from being imported as conflicting custom properties.
- External migration preserves detected alias rows with empty stored values and deduplicates scanned variables by their public CSS identity.
- System Bundle LINK application now preserves generated relationships instead of attempting to convert or edit generated variables through the locked normal update path.
- Generated value updates carry their explicit source and generator type, avoiding name-derived parent guesses during apply.

## v1.3.19

### Added
- External migration from Bricks / Advanced Themer, Core Framework, and Automatic.css now creates a new source-named Color Palette and places imported color variables and resolved color aliases inside it.
- External `var(--token-name)` values are imported as real alias relationships instead of static text values.
- External migration now creates a complete safety snapshot even when token values already match and only Palette ownership changes.

### Changed
- System Bundle and token import preview rows now use a readable two-line layout with wrapping names, values, and relationship details.
- LINK rows show the complete old and new source names, while UPDATE rows show the complete old and new values without hard character truncation.

### Fixed
- System Bundle generated-child repairs now use the bundle's explicit source variable instead of guessing a parent from the child's name.
- Snapshot recovery now accepts semantic aliases such as `design.*` as Color Palette members when their source chain resolves to a Color variable.
- The failed-recovery combination reported in v1.3.18—generated variable conflict followed by invalid color-palette membership—no longer follows those incorrect repair paths.

## v1.3.18

### Added
- Added the MV System Bundle as the complete portable WordPress-to-WordPress handoff format.
- System Bundles preserve variables, generated children, aliases, generator configurations, Themes, active Theme, Color Palettes, memberships, ordering, and generated CSS behavior without carrying source-site database IDs.
- Added dedicated System Bundle export, preview, and apply REST routes plus automatic bundle detection in Sync import.
- Added preview rows for generator, Theme, and Palette changes alongside existing ADD, UPDATE, LINK, and DELETE variable changes.

### Changed
- Sync export now distinguishes the complete System Bundle from interoperability exports such as DTCG, Flat, Figma JSON, and CSS.
- Portable imports reconnect relationships by stable variable names, create a complete safety snapshot first, and automatically restore it if a later import phase fails.
- Skip deletions now also preserves destination-only generators, Themes, Color Palettes, and memberships during System Bundle updates.
- Release packaging now excludes local `.bak` and `.tmp` development artifacts.

### Fixed
- Generated children are applied before aliases, allowing aliases that point to generated tokens to transfer safely between installations.
- Portable bundle validation rejects duplicate Palette memberships, invalid relationship sources, unsupported generator ownership, empty Palette state, and generated-child Palette membership.

## v1.3.17

### Fixed
- Fixed batch actions overlay background color by changing it to `#1b1b1b` (replacing the blueish slate shade) to match the native dark glassmorphic MV product identity.
- Oriented the batch actions target palette dropdown menu to open upwards instead of downwards, ensuring it remains fully visible within the panel viewport and doesn't collide with the status bar.
- Added custom button border-radius overrides for the upward-opening dropdown when active to maintain geometric layout integrity.

## v1.3.16

### Fixed
- Fixed HTML5 drag-and-drop reordering for both variables and palettes in sandboxed environments (like Bricks Builder) by reading the active drag state variables (`draggingVarId` and `draggingPaletteId`) rather than relying on browser `dataTransfer` APIs.
- Resolved batch actions overlay (`.ve-studio-batch-overlay`) design and alignment bugs by overriding standard centering translations (`transform: none!important`), enforcing non-wrapping text (`white-space: nowrap!important`), and assigning an explicit layout width and responsive padding to the target palette dropdown SelectMenu.

## v1.3.15

### Fixed
- Fixed variable drag-and-drop reordering persistence by sorting the `bases` array by position first in the client-side `useMemo` block.
- Implemented the missing floating batch actions overlay (`.ve-studio-batch-overlay`) inside the main panel, appearing at the bottom when checkboxes are checked.
- Added a batch delete confirmation modal (`ConfirmModal`) to prevent accidental mass deletion of variables.
- Fixed Theme/Palette switcher pill styling by setting `width: 100%` and `display: flex` centering on switcher buttons so they span the container width symmetrically.

## v1.3.14

### Added
- Implemented HTML5 drag-and-drop reordering for variables in the tree list, preserving positions via the new `position` database column and POST `/variables/reorder` REST API endpoint.
- Implements HTML5 drag-and-drop reordering for color palettes in the palette manager, calling POST `/color-palettes/reorder` to serialize palette positions.
- Added bulk selection checkboxes next to variable rows in the tree view and a select-all header bar.
- Added a floating batch actions overlay (`.ve-studio-batch-overlay`) at the bottom of the panel showing selected count with batch delete (with confirmation) and batch move (with target palette selector).

### Changed
- Redesigned the Theme/Palette switcher into a capsule pill control (`.ve-color-kind-switch`).
- Removed dropdown labels (`Theme` and `Palette` text span) from select rows to allow selectors to span the full width.
- Styled the active palette/theme current banner to be transparent (`.ve-palette-current` with `padding: 4px 0` and no background/border).

### Fixed
- Removed the header palette shortcut icon button from the header action buttons row (`.ve-hdr-a`).

## v1.3.13

### Changed
- Replaced the stacked Theme and Palette selectors with a compact two-mode switch so only the active Theme or Palette control is shown at a time.
- Theme and Palette selectors now share a fixed label column and begin at the same horizontal position.
- Standardized normal product inputs and branded select controls on the shared 38px control height across the Variable panel and standalone product surfaces.
- Theme and Palette create/rename fields, License Key, search, transfer dialogs, and their adjacent primary action buttons now use the standard control rhythm.

### Fixed
- Removed remaining 24px and 30px inline input-height overrides that bypassed the product control token.
- Preserved specialized heights for checkboxes, radios, color sliders, file inputs, icon controls, and multiline textareas.

## v1.3.12

### Changed
- Color Palette management now expands inline beneath the Palette selector, matching the established Theme manager interaction instead of sliding into a separate panel.
- The header Color Palettes shortcut now opens the Color tab and expands the inline manager.

### Fixed
- Semantic aliases such as `design.*` that resolve through a Color source are now recognized as palette-eligible colors.
- Color aliases appear in the Color tab for palette organization and gain Move to Palette, Copy to Palette, and palette-aware Duplicate actions without changing their stored name, CSS custom property, or source relationship.
- Upgrade membership repair now assigns existing semantic color aliases to Palette One and removes only genuinely invalid memberships.

## v1.3.11

### Added
- Added true user-created Color Palettes as organizational containers for actual Color variables.
- Existing installations migrate their current root colors and aliases into a renameable `Palette One`; generated children inherit their base variable's palette.
- Added an `All Colors` view plus palette filtering under the Color tab.
- Added palette-aware Color creation, Move to Palette, Copy to Palette, palette duplication with independent color copies, inline rename, and safe deletion previews.
- Populated palette deletion can move colors to another palette or explicitly delete the palette and its color/dependency tree through custom confirmation UI.
- Snapshot state version 3 now preserves themes, palettes, memberships, variables, generators, and dependencies together.

### Changed
- Corrected the previous value-layer feature to **Themes** while preserving its existing WordPress options and legacy `/palettes` REST routes for compatibility.
- Added correctly named `/themes` routes and separate `/color-palettes` routes.
- Theme switching continues to affect CSS, Bricks, Code2Bricks, and exports; palette selection affects organization only.

### Fixed
- Imported, migrated, and cleanup-repaired Color variables are assigned to a valid palette without giving generated children independent memberships.
- Color duplication preserves custom-theme values and optional generated children.

### Pending
- Palette drag-and-drop, bulk selection, and manual color ordering remain later interaction phases.

## v1.3.10

### Added
- Added a variable duplication confirmation modal popup (confirmDuplicate) before duplicating a variable to prevent accidental copy creations.

### Changed
- Redesigned active palette and theme card styles with premium duotone palette icon and clean dark card styling, removing the old gradient dot and olive background.

### Fixed
- Fixed input field height alignment for General Settings License Key input (30px), palette sub-panel creation input (30px), and palette sub-panel inline rename input (24px) to align with their action buttons.

## v1.3.09

### Added
- Integrated the full Color Palettes manager inline inside the Color namespace tab. Clicking the sliders/caret toggle next to the palette dropdown expands the palette creation, list, duplication, inline renaming, and deletion interface directly under the tabs.

### Fixed
- Fixed variable row actions (Edit, Duplicate, Delete) in the variable tree list by declaring all the missing handler functions (`hDup`, `hDel`, `cfmDel`, `hCreated`, `tgExp`, `allCats`) in the main `Panel()` component, resolving the console reference errors.

## v1.3.08

### Fixed
- Fixed variable row click handler (`hSel` ReferenceError) so clicking any variable or child variable shows its details card at the bottom.
- Fixed Color namespace tab switching by implementing the `activatePalette` handler and resolving the `ReferenceError: activatePalette is not defined` during Preact render.
- Modifies the `Detail` component to display basic variable metadata immediately rather than blocking render while dependencies are loaded.
- Styled the General Settings "License key" input field (Image 1) to match the dark premium input styling instead of defaulting to a native white box.
- Implemented real-time cross-frame synchronization: any variable change (CRUD) or settings update is automatically broadcast to all frames/windows via `builderRuntimeWindows()` so all open panels refresh instantly without page reload.

## v1.3.07

### Added
- Added a General setting option to show/hide the "All" tab in the variables list.

### Fixed
- Fixed the Preact rendering crash when switching to the **Color** namespace tab by properly declaring the palettesData state and activatePalette handler in the parent panel component.
- Aligned the header action icons row to the left (matching the search input and tabs) by changing the left padding offset from `48px` to `16px`.

## v1.3.06

### Added
- Added a quick palette switcher dropdown inside the Color namespace tab. This allows the user to switch the active color palette instantly from the main view.

### Fixed
- Styled the palette creation and rename inputs in the Palette panel to match the premium dark theme instead of defaulting to white native inputs.

## v1.3.05

### Added
- Added Color Palettes phase 1 under the new palette toolbar action.
- Added palette creation from the active color set, instant activation, duplication, inline renaming, and confirmed deletion.
- Custom palettes keep public token names stable while overriding effective color values in the variable API, generated CSS, Bricks mirroring, Code2Bricks, and DTCG/Flat/Figma/CSS exports.
- Editing a Color variable while a custom palette is active updates that palette instead of overwriting Default; existing generated color children are recalculated from the edited palette base.
- Palette overrides follow base/generated variable renames and are removed with deleted variables.

### Fixed
- Rebuilt variable row actions around explicit open state and the toolbar panel control's 220ms hover-intent close behavior, with the menu anchored at the far-right edge.

### Pending
- Palette snapshot/import payload support and selector-scoped frontend palette switching remain later phases.

## v1.3.04

### Changed
- Variable actions now appear when hovering or keyboard-focusing anywhere on the variable row and remain anchored to the row's right edge.
- Snapshot entries now use descriptive labels such as “Manual backup,” “Before import,” “Before database cleanup,” and “Before snapshot restore,” with the snapshot number and timestamp shown separately.

## v1.3.03

### Added
- Added a clear JSON/CSS import drop zone that displays “Drop file here” while a compatible file is held over it and previews the dropped file before applying anything.
- Added concise import guidance for DTCG, Flat, Figma JSON, and CSS files.

### Fixed
- Restored generated children to a single indented tree beneath their base variable instead of allowing the list to split into a second column.
- Confined variable row actions to the visible swatch/icon hover boundary, keeping them hidden over empty row space while preserving a clickable action bridge.
- Changed JSON and CSS export filenames to include the current WordPress site name, export format, and date.
- Displays alias source changes as explicit old-source to new-source LINK rows and applies supported relationship changes transactionally.

### Planned
- Defined palettes as alternate value layers over stable color-token identities; implementation is intentionally reserved for a dedicated module phase.

## v1.3.02

### Added
- Added unsaved color previewing in the Bricks canvas while editing a color variable; closing the editor without saving removes the temporary preview.

### Fixed
- Recursively discovers nested builder iframe runtimes, reapplies the runtime variable layer after iframe loads, and keeps retrying even when Code2Bricks is already available so custom-property values resolve on the canvas.
- Marks the builder-only runtime variable layer as authoritative so stale Bricks styles cannot mask the current Mimam's Var value.
- Automatically recognizes exact `var(--token)` and `--token` static values as aliases in WordPress, while resolving string and numeric database IDs consistently in the builder.
- Hides the category selector while editing a static variable because the existing namespace is retained.
- Reveals variable row actions only after the pointer enters the variable swatch/icon, instead of activating from the hidden action area.

## v1.3.01

### Added
- Added Tab key autocomplete support to `VarRefInput` in the static value field.
- Added recursive `resolvedVariableValue` helper to fully resolve colors, sizes, swatches, and values for alias variables in lists and autocomplete.

### Fixed
- Added `_nc` cache-buster query parameters to variable list REST requests to ensure value updates propagate to the builder canvas instantly on save.
- Automatically closes the Media Studio panel upon successful asset selection and insertion into Bricks controls.
- Propagates click intent to `createFrame` inside the `wp.media` wrapper to ensure picking state resolves correctly.
- Pre-filled inline editor and full editor in `EditSub` with `css_value` instead of empty string for alias variables, and auto-detects type updates on inline edit save.

## v1.3.00

### Added
- Merged the separate "Alias" mode into "Static" mode. Typing `--` or `var(` in the static value field triggers autocomplete suggestions of existing variables, which automatically transitions the variable's type to `alias` on save.
- Dynamically injects a `:root` style tag on mutation into both the main document and iframe canvas window so newly created variable values resolve instantly in Code2Bricks and Bricks without editor reloads.

### Fixed
- Replaced the timeout polling wrapper with a property getter/setter wrapper on `runtime.wp.media` to immediately intercept Bricks image selectors without race conditions.
- Simplified pointerdown click tracking to register media selection intent for any element outside the Vengine panel and native media modal, bypassing fragile class guessing.
- Corrected the fluid scale generator trigger bug by removing the automatic popup showing when fixed/static variables are created.
- Extended the PHP `VariableManager::update()` method to accept and write `type` and `source_id` edits and correctly register/deregister relations in the dependency graph.

## v1.2.129

### Added
- Added an Alias mode to the variable creation panel with an explicit source-variable selector and a preview of the resulting `var(--token)` reference.
- Added builder UI tokens for the shared accent, surfaces, borders, text, danger state, and 38px control-height rhythm.

### Fixed
- Reconciled MV variables into every accessible Bricks/Code2Bricks runtime at builder startup and after mutations, including direct provider population so autocomplete does not depend on a stylesheet scan or a later focus refresh.
- Rebuilt the Media Studio replacement around Bricks' actual `wp.media` request and selection callback, allowing Bricks to receive the selected attachment through its native control path while leaving navigation clicks untouched.
- Forced search, variable-name, fixed-value, and related single-line controls to the shared 38px product input height.
- Prevented small fluid scales from producing duplicate rounded child names such as two `import-delete.2` rows.

## v1.2.128

### Fixed
- Mirrored MV-owned public tokens into Bricks global variables through the Bricks adapter so Code2Bricks can discover them, while preserving external variable ownership and removing only stale MV mirror rows.
- Refreshed the in-memory Bricks variable list and Code2Bricks provider immediately after variable mutations.
- Restored Media Studio replacement behavior for media-specific Bricks controls without reintroducing sidebar-navigation interception.
- Matched the HEX and channel value fields to the standard 38px input height.

## v1.2.127

### Fixed
- Normalized user-entered variable-name spaces to hyphens, allowed CSS-safe hyphens in stored variable segments, and kept internal dot separators out of the variable-name UI.
- Added horizontal padding to the HEX/RGB/HSL/OKLCH format controls.
- Refreshed the selected variable immediately after inline value saves instead of requiring the user to leave and reselect it.
- Reloaded generated `variables.css` after variable mutations so already-open Bricks tools such as Code2Bricks can discover newly created variables.
- Narrowed the Bricks Media Studio trigger bridge to explicit media controls so sidebar navigation icons no longer open Media Studio.
- Changed snapshots to capture variables, stable IDs, dependencies, and generator configuration as one versioned state.
- Made snapshot rollback transactional, recovery-snapshot-backed, and explicit about legacy snapshots that cannot restore generated relationships safely.
- Marked incomplete legacy snapshots as unavailable in the Snapshots UI instead of offering a misleading Restore action.
- Prevented imports from applying when their required pre-import safety snapshot cannot be created.
- Rejected duplicate names before variable rename writes and stopped recording rename history when the database update fails.
- Made generated variable CSS writes atomic and deduplicated declarations by public CSS name.
- Rejected create/rename operations that would make two stored variables resolve to the same public CSS custom property.
- Added CSS-name collision diagnostics and deduplicated legacy JSON/Figma exports by the newest stored variable row.
- Preserved valid single-segment tokens in DTCG export instead of silently omitting them.
- Made import application transactional: any failed change, CSS write, or sync-log write rolls the complete import back.
- Blocked unsupported type-change imports before mutation and added a custom confirmation before applying import deletions.
- Prevented generators from converting unrelated existing variables into generated children when names or public CSS names collide.
- Added checked generator database writes, duplicate-generator prevention, transactional attach/detach, and explicit regeneration failures.
- Made variable create, update, and delete operations transactional, including dependency, generator-regeneration, and generated-CSS writes.
- Replaced the delete-then-create generator UI flow with one transactional generator replacement, preserving the old scale if the new configuration fails.
- Surfaced generator, duplicate, and delete API failures instead of showing false success messages.
- Preserved generated-variable IDs during generator replacement and blocked removal of generated tokens that still have downstream alias/dependency usage.
- Made forced variable deletion traverse the complete dependency tree instead of leaving grandchildren with missing sources.
- Added a complete pre-cleanup snapshot and one transaction around duplicate/orphan/stale-variable cleanup, generator recovery, regeneration, and CSS export.
- Preserved alias source names in flat and DTCG exports and restored alias relationships when importing into a new variable set.
- Normalized flat import metadata instead of passing unvalidated relationship fields straight through.
- Added import preflight validation for duplicate names, public CSS collisions, missing/self-referencing alias sources, and conflicts with existing variables.
- Made source-relationship changes visible in import diffs and blocked them for explicit manual review instead of silently relinking variables.
- Changed rename propagation from substring replacement to exact CSS custom-property token matching, preventing a rename such as `--brand` from altering `--brand-alt`.
- Surfaced rename-propagation warnings after a successful variable rename.
- Prevented database read or JSON encoding failures from being stored as successful snapshots.
- Added pre-rollback snapshot structure checks for duplicate identities, invalid dependency rows, and malformed generator rows while still allowing an exact safety capture of a database that needs cleanup.
- Prevented alias relationship round trips from producing false value updates and exported an alias source's resolved value to Figma.
- Separated manually resolved CSS-name conflicts from automatic cleanup issues and stopped cleanup failures from showing a false success toast.
- Converted unexpected rename-propagation failures into visible warnings while keeping the successful core rename intact.
- Remapped source IDs, generators, and dependency edges to the kept row before database cleanup removes older duplicate variable records.
- Added diagnostics for broken alias sources, missing dependency links, and orphan dependency rows.
- Extended cleanup to repair valid alias/generated dependency links, remove generated rows whose source is gone, and delete orphan dependency records while leaving ambiguous aliases for manual relinking.
- Prevented cleanup from deleting orphan generated variables that still serve downstream dependents; those cases are now flagged for manual review.
- Added a recoverable backup-swap fallback for atomic generated-CSS replacement on hosts where `rename()` cannot overwrite an existing file directly.
- Corrected existing dependency edges when their stored relation type is stale and required imported generated-variable edge registration to succeed.
- Extended snapshot structure validation to reject duplicate dependency and generator IDs before rollback.
- Preserved generated child IDs across base-variable renames by matching owned color/scale children through stable generator suffixes and renaming those rows in place.
- Rejected snapshots whose alias/generated sources, dependency edges, or generator owners do not exist in the captured variable state, and stopped rollback before mutation when its database transaction cannot start.
- Refreshed alias CSS references inside variable rename transactions so source and generated-token renames cannot leave `var(--old-name)` declarations behind.
- Made viewport-driven fluid-variable recompilation transactional and surfaced database, CSS-write, and commit failures without retaining the new viewport settings.
- Made CSS import previews reconcile public CSS names back to unambiguous stored variable identities and infer simple `var(--token)` alias relationships.
- Expanded import previews to show and block unsupported type/source relationship changes before application.
- Surfaced direct sync-log database write failures instead of returning false success.
- Applied identity validation to legacy base-only snapshots and surfaced failures when stale generated dependency edges cannot be removed.

## v1.2.126

### Fixed
- Synchronized every fresh MV update check into WordPress's native `update_plugins` site transient so the first refresh no longer merely primes a later update display.
- Added a pre-render fresh manifest check on the WordPress Plugins and Updates screens, preventing stale six-hour manifest data from requiring a second refresh.
- Removed the 120ms restore gate and the additional panel entrance animation from hidden floating Elements/Structure restoration; the panel now rebuilds immediately at its validated saved geometry.

## v1.2.125

### Fixed
- Applied pending floating-panel restore geometry synchronously during shell creation, before the browser can paint the temporary reconstructed position.
- Removed the early delayed position correction that allowed the panel to flash near the bottom before moving to its saved location; retained a later fallback only for unusually delayed Bricks mounts.

## v1.2.124

### Fixed
- Kept an immutable hide-time geometry snapshot for floating Elements and Structure panels so shell reconstruction and width-preset initialization cannot overwrite the position and size that restore must use.
- Preserved pending restore metadata during normal floating-panel persistence, then cleared the one-time snapshot only after the rebuilt shell successfully receives it.

## v1.2.123

### Fixed
- Positioned the compact Bricks panel-preference control immediately before Undo instead of leaving it detached after Save.
- Added hover intent and a cursor bridge to the compact panel-control popover so it remains open while the pointer moves from the toolbar icon into the dialog.
- Saved floating Elements and Structure geometry at hide time and reapplied it on restore, clamping oversized or off-screen positions into the current viewport.

## v1.2.122

### Added
- Added account-backed UI preference storage through WordPress user meta so panel modes, positions, Builder Tools settings, CSS Studio preferences, Media Studio view preferences, and update skips can follow the logged-in account across browser sessions.
- Added the update-available notice to the main panel, its nested views, all standalone Studio panels, Settings, Help, and Mimam's Bar.

### Changed
- Consolidated the Bricks toolbar Elements and Structure controls into one compact MV panel-control icon with a branded hover/focus popover for dock, float, and hide actions.
- Corrected the WordPress plugin author name to `Hebronmimam`.

### Fixed
- Preserved whether Elements or Structure was floating or docked before hiding, so its restore icon returns it to the same mode.
- Kept toolbar control popovers stable instead of rebuilding their DOM while the panel state is unchanged.

## v1.2.121

### Changed
- Made the release workflow stricter by documenting the Notion Release Notes page as a required release step and backfill target.
- Recorded the fixed `left`/`top` floating-panel drag model as the default pattern for future MV floating surfaces.

### Fixed
- Made floating shell Wide and Max presets expand the inner Bricks panel subtree instead of leaving empty shell space beside a fixed-width panel.
- Moved floating shell header tooltips below the size/dock/hide controls so they no longer sit directly on top of the hovered icon.
- Changed Elements and Structure hide behavior to create separate restore icons near the MV control area, so hidden panels can animate down to a small icon and restore from their own icon.

## v1.2.120

### Changed
- Replaced the floating shell S/M/L/XL size language with MV-owned Narrow, Balanced, Wide, and Max presets.
- Updated floating shell dock, float, and hide icons so the controls read as Mimam's Var UI instead of mirroring the reference floating-panel plugin.

### Fixed
- Made Wide and Max floating shell presets apply larger real widths and persist those widths.
- Added Structure-specific floating shell spacing and toggle visibility rules so Bricks row expand/caret controls can remain visible and clickable while floating.

## v1.2.119

### Fixed
- Fixed Builder Tools floating Elements and Structure shells so the active shell wrapper is not removed by the stale-panel cleanup pass immediately after toggling float.
- Tightened vertical centering for the Bricks toolbar MV Elements and Structure mode controls.
- Reverted Media Studio collection context menus to Studio-relative row anchoring and refined lower-row clamping so menus stay attached to the clicked collection without drifting across the viewport.

## v1.2.118

### Changed
- Reworked Builder Tools floating Elements and Structure into MV-owned floating shells with custom headers, S/M/L/XL width presets, dock/hide controls, and Bricks toolbar panel mode controls.
- Set floating panel opacity default to 100% and migrated the old 78% default once for existing installs that had not changed it manually.

### Fixed
- Kept native Bricks Structure markup inside the floating shell so row expand/caret controls remain visible and clickable without opening Media Studio.
- Restored floating panels through the shell cleanup path so dock/hide state changes do not leave orphan wrappers or stale inline styles.
- Improved Media Studio collection context menus by anchoring them with viewport-fixed row geometry and a pointer that follows the clicked row, including lower sidebar rows.

## v1.2.117

### Fixed
- Stabilized Builder Tools floating Structure/Elements cleanup by removing inactive float root classes before restoring docked panel styles.
- Stopped floating Structure from wrapping Bricks internals in an MV layout wrapper, reducing dock-restore glitches.
- Scoped floating-panel button layout overrides to panel headers so Structure row expand/caret controls are not affected.
- Broadened floating Structure expand/caret visibility rules while keeping them scoped to Structure rows.
- Re-centered Media Studio collection context-menu pointers around the clicked row, including lower sidebar rows.

## v1.2.116

### Changed
- CSS Studio keeps the Variable Panel surface, but the stylesheet settings area is more compact and the CSS editor fills the remaining panel height.
- Media Studio collection menus now anchor inside the Studio layout context instead of relying on an unpositioned ancestor.

### Fixed
- Kept Bricks Structure expand/caret controls visible and clickable while the Structure panel is floating.
- Added targeted cleanup for disabled floating Structure/Elements panels so disabling one panel can restore its Bricks docked state even if another Builder Tools panel remains active.
- Further softened floating Structure/Elements shadows to avoid a glowing/pulsing feel.
- Made Rank Math internal links processed, Rank Math analytic object ID, and Rank Math SEO score read-only in Content Studio.

## v1.2.115

### Changed
- Added named UI surface styles to the AI UI rules so future work can refer to Variable Panel, Wide Studio, Medium Studio, and Sidecar Editor consistently.
- Changed CSS Studio back to the narrow Variable Panel style instead of the wide Studio modal style.

### Fixed
- Prevented Bricks Structure panel clicks from being captured by the Media Studio picker interceptor.
- Fixed CSS variable autocomplete so bare `--token` completions wrap as `var(--token)` unless the cursor is already inside `var(...)`.
- Improved Media Studio collection context menu anchoring by positioning from the clicked collection row instead of centering the menu over nearby rows.
- Added floating-panel style snapshot/restore cleanup so disabling floating Structure or Elements can return Bricks panels closer to their native docked state.
- Restored MV-created floating header wrappers during cleanup so Structure/Elements headers do not keep altered markup after disabling float.
- Repositioned the Elements floating drag handle inside the panel header and kept the Structure minimize control in the header row.
- Kept Structure expand/caret controls visible while floating and removed animated shadow transitions that made floating panels feel like they were pulsing.

## v1.2.114

### Added
- Added safe Content Studio REST endpoints to preview and apply a JetEngine-to-ACF mirror migration without deleting JetEngine data.
- Added local Figma dev sync documentation for using a reachable HTTPS tunnel URL instead of `localhost`.

### Changed
- Content Studio now separates Rank Math custom fields into their own section so SEO metadata is not mixed into general custom fields.
- Content Studio preserves richer custom-field/meta values for editing, including JSON-friendly complex values.
- CSS Studio now combines the stylesheet settings and editor into one studio panel instead of using the old detached sidecar layout.
- CSS autocomplete now wraps bare `--token` completions in `var(...)` unless the cursor is already inside a `var()` context.
- Studio input heights were tightened toward the shared 38px rhythm.

### Fixed
- Tightened CSS Recipes editor/form spacing and kept recipe actions below the editor.
- Reworked CSS Studio sizing overrides so it no longer inherits stale compact sidecar CSS.
- Improved Media Studio context-menu anchoring so menus align from the clicked collection row instead of the row above.
- Further stabilized floating Structure/Elements panel manual positions after drag/drop and kept the Structure shortcut rail hidden.
- Centered the Elements panel floating drag handle vertically in its header and moved the Structure minimize control to the far header edge.

## v1.2.113

### Changed
- Lowered floating Bricks Structure and Elements panels beneath Advanced Themer popovers while keeping MV Studio panels above normal admin/builder surfaces.
- Added common logical CSS properties to CSS Studio validation and autocomplete support.
- Content Studio now hides the WordPress content editor when a post type does not support default content and surfaces detected custom fields/meta in the in-studio editor.

### Fixed
- Reworked floating Structure/Elements dragging to update fixed `left`/`top` during drag instead of applying a temporary transform and snapping on drop.
- Prevented active CSS and rich-content editors from re-syncing external values while typing, reducing cursor jumps to the start of the editor.
- Tightened CSS Recipes layout so shortcode prefix/input spacing is clean and recipe action buttons sit directly under the editor.
- Centered the Media Studio collection context-menu pointer on the clicked row and kept the menu clamped inside the Studio panel.
- Added a settings-panel fallback so Settings no longer stays on a permanent loading state if the settings request fails.
- Refined floating Structure/Elements handle sizing, spacing, and z-index so the handles feel less intrusive.

## v1.2.112

### Changed
- Upgraded Content Studio's in-studio content field to a lightweight WordPress-like rich editor with paragraph, heading, list, bold/italic, and quote controls.
- Made Media Studio reopen faster by reusing an in-memory media/folder cache while refreshing data in the background.

### Fixed
- Tightened CSS Recipes form/editor sizing so recipe preview and new-recipe states use the full available editor width consistently.
- Re-anchored Media Studio collection context menus to the clicked collection row edge while keeping the menu clamped inside the Studio viewport.
- Replaced the floating Builder Tools drag handle icon with an inline SVG handle and removed the unwanted handle tooltip pseudo-element.
- Persisted floating panel width and clamped Structure restore/drag positions to reduce jumping and prevent panels from leaving the viewport.
- Scoped Bricks panel styling overrides to MV floating-panel states so Builder Tools CSS does not leak into unrelated Bricks/site UI.
- Applied the requested floating Structure spacing of `2rem` padding and `2rem` gap.

## v1.2.111

### Changed
- Removed the temporary MV Structure shortcut rail from the active Builder Tools UI and settings until the shortcut system is redesigned later.
- Moved CSS Studio's Save & Compile action to the code editor sidecar so compiling stays attached to the stylesheet being edited.
- Upgraded CSS Recipes editing to use the same CSS editor surface as CSS Studio, including recipe edit/cancel state and autocomplete sources.
- Reworked Content Studio's in-studio editor to use the full available workspace with sticky actions and an Advanced WordPress fields section.

### Fixed
- Added cleanup for MV Structure wrappers so docking the Structure panel can restore Bricks' default layout more reliably.
- Improved floating Structure and Elements drag handle styling and placement.
- Anchored Media Studio collection context menus inside the Studio panel so transformed panel positioning no longer pushes menus away from the clicked collection row.
- Reduced 1Password/autofill interference on CSS recipe name and shortcode fields.

## v1.2.110

### Changed
- Moved CSS recipe discovery out of CSS Studio so the stylesheet editor no longer shows recipe shortcode rows or recipe scope controls.
- Changed CSS Recipes Studio to list shortcodes only; clicking a shortcode loads its generated CSS into the recipe editor.
- Auto-prefixes new recipe shortcodes with `@` so users type only the shortcode name.
- Reworked Builder Tools Structure shortcut handling to use MV's owned fixed rail instead of moving external Bricks or Advanced Themer rails.

### Fixed
- Expanded Content Studio "Edit in Studio" so it can save core WordPress edit fields including title, slug, status, content, excerpt, parent/order, featured image ID, comments, pings, and template metadata.
- Re-anchored Media Studio collection context menus beside the clicked collection row and clamped them to the viewport.
- Added a local settings backup write for Builder Tools panel preferences to reduce future update-related settings loss.

## v1.2.109

### Fixed
- Removed CSS Studio from the large Studio modal sizing rules so the compact settings panel and code editor sidecar stay beside each other.
- Added explicit CSS Recipes centering and width rules so the Recipes Studio no longer opens stretched or clipped offscreen.
- Fixed Content Studio "Edit in Studio" by moving its save handler back into the Content Studio scope.
- Anchored Media Studio collection context menus to the actual pointer position and clamped them inside the viewport.
- Made MV-owned Media Studio collections draggable from the row as well as the handle, while detected folder-plugin collections now show a read-only lock affordance.
- Stabilized the Builder Tools Structure shortcut rail by mounting it to the Structure panel instead of positioning it as a separate fixed element during drag.

## v1.2.108

### Fixed
- Restored CSS Studio to the compact MV panel sizing with the code editor sidecar placed beside the main settings panel.
- Fixed Media Studio folder-plugin collection counts so detected folders show the same item count as the filtered gallery.
- Changed Media Studio sub-collection creation from an inline bottom-of-list form to a focused modal.
- Made Media Studio Bricks picker mode close after a successful insert or copy fallback.
- Scoped Media Studio conversion progress to the selected asset so another asset no longer inherits the converting state.
- Made Content Studio input heights match action buttons and made Edit in Studio start from pointer-down for more reliable in-panel editing.
- Stabilized Builder Tools floating handles and Structure shortcut rail visibility while dragging.
- Smoothed the toast countdown ring animation and prevented older toast timers from hiding newer messages.

### Changed
- Media Studio collection rows now label MV-owned collections versus detected folder-plugin collections, show sub-collection indentation, and expose drag only through an explicit handle.
- CSS Recipes now uses a centered studio width instead of stretching to the full available viewport.
- Added an agent UI-memory rule for clearly labelling MV-owned data versus adapter-detected data.

## v1.2.107

### Added
- Added an MV-styled right-click context menu for Media Studio collections.
- Added local Media Studio collection rename, remove, sub-collection creation, drag-to-reorder, and Shift-drop nesting.

### Fixed
- Fixed CSS Studio panel placement by excluding CSS Studio and CSS Recipes from the generic standalone-panel transform override.

### Changed
- Kept the update ZIP filename short as `mv-wp-v1.2.107.zip` while preserving the internal `variable-engine` plugin folder required by WordPress updates.

## v1.2.106

### Added
- Added a dedicated CSS Recipes Studio panel for managing reusable CSS shortcodes that autocomplete inside CSS Studio.

### Fixed
- Restored the floating Elements panel drag handle even when no Bricks element is selected.
- Lowered Builder Tools floating Elements, Structure, rail, tooltip, and minimized-restore layers below MV Studio overlays.
- Stabilized Structure shortcut rail dragging by clearing rail transforms and transitions after drag.
- Added a Bricks media-selection handoff so Media Studio can insert the chosen media URL into the originating Bricks control, with a copy fallback when no writable control is exposed.
- Changed Media Studio file conversion to show converting/converted toasts without switching the full Studio into a loading state.
- Made Content Studio clear stale rows immediately when switching sections and made Edit in Studio open the inline edit form more reliably.

### Changed
- Clarified the General setting label for single-panel versus multiple-panel behavior.

## v1.2.105

### Fixed
- Added file type metadata to Media Studio attachment details beside dimensions and size.
- Reworked Plugin Directory result cards so grid and list views align consistently.
- Fixed Plugin Studio navigation so installed-plugin filters switch back from Plugin Directory content instead of only changing the header.
- Fixed Content Studio navigation races so slower previous requests cannot repaint Pages after clicking another type.
- Reset Content Studio transient row/edit state when switching content groups.
- Changed Content Studio edit links to use server-provided Bricks links when available.
- Clamped floating Builder Tools panels to the viewport after drag, resize, and settings changes.
- Prevented dragging the floating Elements panel from moving the Structure shortcut rail.

## v1.2.104

### Added
- Plugin Directory browsing now has its own Plugin Studio sidebar section with preloaded popular plugins.
- Plugin Directory results now support grid/list views and display plugin icons when WordPress.org provides them.

### Fixed
- Restored CSS Studio to the slimmer MV panel sizing so the code editor area is visible again.
- Filtered duplicate default Pages/Posts out of the Content Studio custom post type list.
- Hid Advanced Themer/options-page field groups from Content Studio field-group lists.
- Made Content Studio field rows editable in Studio instead of only deletable.
- Improved branded focus styling so Studio inputs do not show the browser's blue focus ring.
- Broadened Bricks image/SVG/media/background click detection so Media Studio opens from more Bricks selector controls.
- Reduced Structure/Elements hide-versus-float conflicts by applying builder panel state classes to both document roots.

### Changed
- Plugin Studio directory search now fills the available result height and uses more readable plugin card text.
- The multiple-panel option is now labelled as Panel behavior with helper text in General settings.

## v1.2.103

### Added
- Plugin Studio can now search the WordPress.org plugin directory and install plugins directly from Studio.
- Plugin Studio can now upload plugin ZIP files from Studio.
- Added a General setting to allow either one MV panel at a time or multiple Studio panels at once.
- Added toast countdown ring animation so temporary messages show their remaining display time.

### Fixed
- Improved Plugin Studio text contrast so plugin descriptions and authors remain readable in the dark UI.
- Lowered MV panel and Builder Tools z-index layers so native WordPress/Bricks modals can appear above MV panels.
- Broadened the Bricks media-control bridge so common image, SVG, media, and background selectors open Media Studio instead of the default media library.
- Prevented Structure/Elements panel hide settings from hiding panels that are also configured to float.
- Improved Content Studio labels so in-Studio editing and Bricks editing are clearly separated.
- Expanded Content Studio metadata detection for ACF and JetEngine CPT definitions that are not exposed through normal registered post types.

### Changed
- Shortened the update package filename to the `mv-wp-vX.Y.Z.zip` format while keeping the internal WordPress plugin folder as `variable-engine`.

## v1.2.102

### Fixed
- Fixed Plugin Studio and CSS Studio standalone centering by excluding both Studio panels from the older utility-panel transform rule and including them in the center-screen Studio CSS block.
- Added outside-click closing behavior for Plugin Studio so it behaves like the other Studio panels.
- Replaced remaining native Settings and Modules checkboxes with the shared MV checkbox component for consistent styling across admin and builder.
- Added a lightweight Bricks media-control bridge that opens Media Studio from common Bricks image/media controls without mutating Bricks save state directly.

### Changed
- The v1.2.102 package includes the v1.2.101 Studio polish pass plus the final centering, checkbox, and media-control bridge fixes.

## v1.2.101

### Added
- Added Plugin Studio as a Builder Tools module for plugin listing, filtering, activation/deactivation, auto-update toggles, native update links, and inactive plugin deletion.
- Media Studio now supports batch deselect, in-modal new collection creation from a selection, and selected-asset collection membership display with an explicit add-to-collection action.
- Media Studio now has a branded media rename confirmation flow with title-only and file-URL rename options.
- Content Studio now supports in-studio title, slug, and status editing for content rows.

### Fixed
- Hardened Media Studio grid rendering with fixed grid tracks and stable media card dimensions to prevent asset overlap.
- Fixed folder collection membership refresh by including detected folder data in the collection filter dependencies.
- Preserved FileBird parent-folder relationships when detected, allowing sub-collections to appear instead of flattening all folders.
- Improved Content Studio grouping so default content, true custom post types, plugin/system types, and field groups are separated and can be hidden or shown.
- Replaced remaining native selects and checkbox lists in Studio forms with MV-styled controls.
- Restored CSS Studio workspace sizing inside the large studio shell.
- Rebuilt the MV-owned structure shortcut rail to use Phosphor icon classes and readable tooltip labels instead of copied shortcut letters.

### Changed
- Applied lean MV-styled scrollbars and consistent control heights across Studio surfaces.
- Clarified Media Studio replace/convert action labels and tooltips.

## v1.2.100

### Added
- Media Studio now loads media through paginated WordPress media requests instead of stopping at the first 60 items.
- Media Studio now reads supported media-folder plugin data through the existing folder endpoint and exposes detected folders as system collections.
- Media Studio now supports Ctrl/Cmd-click toggling and Shift-click range selection in grid and list views.
- Media Studio batch "Add to Collection" now opens a branded chooser and can route items into existing local collections or detected folder-plugin collections.
- Media Studio collection names can use slash paths for sub-collections, and the icon picker now loads the full local Phosphor duotone catalog for searchable icon selection.
- Media Studio now has replace-file and image-conversion actions for selected assets.
- Builder Tools adds a setting to use an MV-owned shortcut rail beside the floated Structure panel.

### Fixed
- Content Studio route calls now use the registered `variable-engine/v1` namespace, fixing empty/slow content loading caused by the old `ve/v1` path.
- Removed the redundant Content Hub title in Content Studio.
- Media Studio grid cards now use fixed grid tracks, internal selection rings, and no hover scaling to prevent overlap.
- Media Studio type/sort controls now use the branded custom select menu instead of native dropdowns.
- Media Studio file-name fields, font-file previews, dropzone behavior, and full-screen drag/drop feedback were restyled to match the product UI.
- Builder Tools delays Structure floating until Bricks loading/preloader screens are gone.
- Structure panel handle/resize tooltips now render above the panel chrome instead of being clipped below it.
- Figma pairing state is now stamped to the current Figma file identity so older/shared storage cannot make unrelated files appear paired to the same site.
- Dark UI surfaces were pulled back toward the product's black/charcoal palette instead of drifting blue.

## v1.2.99

### Added
- Media Studio: Added dynamic collection creation with a Phosphor duotone icon picker grid, allowing custom-defined collections instead of hardcoded defaults.
- Media Studio: Added MIME type filter dropdown (`all`, `image`, `video`, `audio`, `application`) next to search, along with persistent sort dropdown (Newest, A-Z, Largest).
- Media Studio: Implemented a transparency grid background (`.ve-checker-bg`) for images with transparent backgrounds in the gallery, list view, and attachment details preview.
- Media Studio: Replaced browser `confirm()` calls for deleting media and batch deletes with custom `ConfirmModal` overlays.
- Content Studio: Replaced browser `confirm()` calls for deleting posts, CPTs, field groups, and fields with custom `ConfirmModal` overlays.

### Fixed
- Media Studio: Removed the redundant "Asset Manager" sidebar title.
- Media Studio: Removed hardcoded "Testimonials" and "Team" collections, migrating any existing client lists to dynamic keys.
- Media Studio: Fixed preview pane switching latency (keyed details sidebar on selected item ID to force re-mount).
- Media Studio: Fixed selection highlight styling to prevent grid item overlap in gallery mode.
- Media Studio: Aligned file name field height, padding, and font family in the details sidebar.

## v1.2.98

### Added
- Content Studio: Guarded CPT and Field creation triggers and dropdown selections by provider activity (ACF/JetEngine) and set active provider defaults dynamically on load.

### Fixed
- Drag Freeze: Stabilized structure panel dragging by removing pointerup/mouseup propagation swallowing in `settings-manager.js`, allowing standard browser and builder drag cleanup to complete correctly.
- Centering: Fixed widescreen centering offsets for Content Studio and Media Studio by excluding them from the runtime injected `transform: none` rule in `builder-panel.js` and raising selector specificity in `builder.css`.
- Performance: Optimized the `globalPanelDOMObserver` MutationObserver by implementing a fast pre-filter to bypass queries on routine/minor builder DOM changes.

### Documentation
- Hardened the Antigravity/Codex operating layer with explicit agent quality, UI quality, validation, and release-runbook rules.
- Added canonical docs for agent quality gates, UI standards, and release packaging.
- Updated the setup script to prefer the current checked-in docs instead of regenerating stale weaker templates.

## v1.2.97

### Added
- Reintroduced post-v1.2.93 feature work in a syntax-valid state.
- Modules settings panel deactivation tab to turn off CSS Studio, Mimam's Bar, Content Studio, and Media Studio.
- Speed-dial FAB menu visibility logic: hides the FAB completely when any panel is open.
- Centered widescreen layouts (max-width: 1920px, height: 80dvh) for Content Studio CPT categories and Media Studio 3-column designs.
- Alt-text auto-save on blur, image dimensions, insert URL, and Copy HTML tag features in Media Studio.
- Multi-select batch actions (Add to collection, Compress, Delete) in Media Studio.

### Fixed
- Fixed settings reset on plugin update using robust direct `localStorage` fallbacks in `settings-manager.js`.
- Configured Mimam's Bar module to completely bypass asset enqueuing when deactivated.

## v1.2.96

### Fixed
- Recovery release based on the last confirmed working `v1.2.93` codebase.
- Removed the broken `v1.2.94`/`v1.2.95` JavaScript package line from the stable update path.
- Restored a syntax-valid WordPress panel package while keeping Content Studio and Media Studio at their last verified `v1.2.93` behavior.

### Notes
- The `v1.2.94` Content/Media Studio redesign and `v1.2.95` Modules settings work are intentionally held back for re-implementation in smaller verified slices.

## v1.2.95

### Added
- Added a "Modules" settings tab inside the Unified Settings Panel to let users deactivate individual tools (CSS Studio, Mimam's Bar, Content Studio, and Media Studio).
- Deactivating a tool immediately hides its icon/item from the speed-dial FAB menu and auto-closes any of its open panels.
- Configured Mimam's Bar to completely bypass asset enqueuing when deactivated.
- Organized the workspace root by moving utility script files (`update_notion_*.js`, `read_roadmap.py`, etc.) into a dedicated `scripts/` directory.

### Fixed
- Fixed FAB speed-dial visibility: the floating FAB menu icon now hides completely when any panel (Settings, Help, CSS Studio, Content Studio, Media Studio, or the main bar) is open.

## v1.2.94

### Added
- Upgraded Content Studio and Media Studio layouts to centered widescreen layouts (max-width: 1920px, height: 80dvh) that disable drag/float/dock controls.
- Added Content Studio sidebar navigation categories (Default CPTs, Custom Post Types, and Custom Field Groups) with a detailed tabular list displaying ID, Title, Slug, Status Badge (clickable to toggle), and dates.
- Added Media Studio three-column design layout (left sidebar collections, middle gallery/list layout modes, and right attachment details sidecar).
- Integrated Alt Text auto-save on blur, image dimensions, insert URL copy, and HTML tag copy in Media Studio sidecar.
- Added multi-select batch actions bar (Add to collection, Compress, and Delete) at the bottom of Media Studio.
- Styled all studio inputs, textareas, and dropdown selects with dark glassmorphic styling.

### Fixed
- Fixed settings reset on update by writing direct localStorage fallbacks in `settings-manager.js` storage functions.

## v1.2.93

### Fixed
- Fixed a bug in the Content Studio where selecting the "Content Type" (Page or Post) in the dropdown immediately redirected the user away and defaulted the created type to Post. It now uses a dedicated local state `contentType` and functions correctly.

## v1.2.92

### Added
- Implemented **Content Studio** floating panel to manage pages and posts, support search, quick-toggle status (Publish/Draft), and quick-create new pages/posts with a direct "Edit in Bricks" setup.
- Implemented **Media Studio** floating panel functioning as a premium, glassmorphic WordPress Media Gallery replacement with search, drag-and-drop file uploading, attachment details, and link/HTML copies.
- Added dedicated speed-dial FAB tray icons for the new Content Studio (`ph-file-text`) and Media Studio (`ph-image`).

### Fixed
- Fixed floated structure panel disappearing bug by bypassing bounding client rect height checks on exact matches, maintaining floating state when minimized or natively toggled.
- Fixed shortcut rail positioning by locking width to `44px` with compact padding, and attaching a style MutationObserver to shield positioning from Advanced Themer script overrides.

## v1.2.91

### Added
- Styled Advanced Themer shortcut tooltip balloons (`.brxc-shortcut-balloon`) to match the dark glassmorphic theme and elevated their `z-index` to `2147483015` to prevent rendering behind floated panels.
- Upgraded floated panels' resize indicators (`.mimams-bar-float-resize`) to render as a fully rounded centered pill handle that dynamically expands and glows with `#baf400` color on hover.

### Fixed
- Implemented a DOM `MutationObserver` on `document.body` to listen for additions of structure panel or shortcut rail nodes and synchronize them in real-time, preventing misalignment when Bricks or Advanced Themer detaches and re-appends them.

## v1.2.90

### Fixed
- Hotfixed a critical browser freezing and lag issue affecting standard WordPress Admin screens and the Bricks builder, caused by an infinite MutationObserver loop in the speed-dial FAB repositioning effect (`useEffect` inside `builder-panel.js`).
- Optimized the FAB position MutationObserver to run only when at least one side panel is open, completely bypassing body element observation on standard closed-state dashboard pages.
- Configured the observer to ignore mutations triggered on the speed-dial FAB itself (`fab.contains(m.target)`), ensuring layout mutations do not trigger recursive observer callbacks.

## v1.2.89

### Added
- Moved CSS Studio settings (SCSS Mode toggle, priority drag-and-drop sources list, index rebuild operations, and instructions) to a dedicated **"CSS Studio"** tab inside the main unified settings panel.
- Implemented real-time synchronization between the main settings panel and the CSS Studio editor using a custom event-driven observer pattern (`ve-css-settings-changed`).
- Implemented dynamic positioning for the speed-dial FAB wrap: it now remains visible when panels are open and automatically slides to the left edge of the active panel (or to the right edge if the panel is docked left), adjusting sub-menu and tooltip alignments accordingly.
- Speed-dial FAB icon now toggles the main panel on click (`sO(prev => !prev)` instead of `sO(true)`).

### Fixed
- Repaired floated structure panel detection in `isReasonableSidePanel`: exact class/ID selectors bypass size and position checks, ensuring the panel is correctly recognized, cached, and floated even when temporarily collapsed to `width: 0 !important` by CSS rules.

## v1.2.88

### Added
- Minimize button tooltip text updated to `"Minimize structure panel"`.

### Fixed
- Fixed macOS Genie minimization transition by capturing active panel coordinates right before minimization and adding transition delays to `visibility: hidden` (prevents instant opacity cutoffs and glitches).
- Fixed floating structure panel self-disappearing bug by enhancing `MutationObserver` checks to detect inline `display: none` resets and missing coordinate properties while ignoring active drag/resize operations.
- Fixed shortcut rail sync by dynamically querying the rail element in drag listeners if the node is detached/re-created by Bricks/Advanced Themer.
- Aligned shortcut rail position margin to a consistent `16px` everywhere.
- Fixed custom tooltip clipping and stacking by elevating the rail `z-index` to `2147483005` (with tooltips at `2147483010`) and applying `overflow: visible !important` to the rail and all of its descendants.

## v1.2.87

### Added
- Caches the shortcut rail DOM reference when dragging starts rather than querying the DOM repeatedly.
- Sets custom tooltip attribute `data-tooltip` to say "Minimize structure panel" on the minimize button.

### Fixed
- Fixed macOS Genie minimization transition by removing inline `transform: none !important` locking styles when minimized and drag-end cleans up.
- Fixed floating panel glitching/disappearing-on-own behavior by simplifying MutationObserver style loops (observes only `position`).
- Fixed custom tooltips display order by elevating shortcut rail z-index to `2147483004` (higher than structure panel `2147483002`).
- Fixed clipping of custom tooltips inside container components by setting `overflow: visible !important` on `[data-tooltip]` elements.

## v1.2.86

### Added
- Implemented smooth macOS-style Genie minimization scale and translate transitions for the floating structure panel and the rail.
- Added custom HTML tooltips (`data-tooltip`) styled like the bottom speed-dial tooltips to replace browser-default ones.
- Added drag transition bypass on the shortcut rail to prevent layout lag or misalignment during drag.

### Fixed
- Fixed stuck standalone panels (Settings, Help, CSS Studio) by styling their closed state (opacity 0, visibility hidden, pointer-events none, scale 0.9).
- Synchronized dragging offsets and aligned spacing margin to a consistent 16px between the structure panel and the shortcut rail.
- Increased default visibility and contrast of shortcut rail icons for better readability.

## v1.2.85

### Fixed
- Hotfixed a syntax error in settings-manager.js (removed extra closing brace at line 442) which broke JavaScript execution and caused settings to reset to default on reload.

## v1.2.84

### Fixed
- Fixed floating structure panel minimize/restore button functionality so it collapses and restores reliably on click.
- Stopped pointerdown event propagation on the minimize button to prevent builder drag handlers from intercepting the action.
- Enforced high-specificity CSS overrides targeting ID selectors (e.g. `#bricks-structure.mimams-bar-structure-minimized`) and the floating structure rail to prevent style resets during element inspection.

## v1.2.83

### Added
- Added lazy-mounted keep-alive state tracking for panels.
- Added mutual exclusion behavior between all open panels so that opening one closes another.
- Added scale-in/out visual transitions for standalone panels.
- Disabled standalone panel draggability while retaining handles.
- Styled standalone panel float handles to match the Variable panel, and applied a modern dot-pattern radial resize gripper.
- Applied brand color `#baf400` to Advanced Themer shortcut icons and hid empty shortcut wrappers in floating mode.
- Added dynamic semantic `ul` wrapper correction for Advanced Themer shortcut items.

### Fixed
- Clamped docked layout heights and positions on WP Admin load to prevent offscreen/misplaced panels.
- Resolved settings close button container height overflow via `flex: 1; min-height: 0`.
- Optimized query/variable name lowercasing for improved fuzzy search performance.
- Implemented a `MutationObserver` on floated panels to restore layout styles dynamically under inspector mutations.
- Intercepted pointerdown, mousedown, and click events on `.mimams-bar-toggle-button` in the capture phase to toggle Mimam's Bar and prevent duplicate open triggers.

## v1.2.82

### Fixed
- Fixed standalone panel heights (Settings, Help, CSS Studio) to dynamically match the Variable panel state (docked vs. floating) down to the pixel, removing hardcoded important heights.
- Repaired the structure panel minimize button SVG coordinates and attributes, resolving the malformed diagonal slash.
- Resolved Bricks and Advanced Themer shortcut rail positioning overlap and synchronization issues by applying explicit physical positioning and sizing overrides (`left`, `right: auto`, `top`, `bottom: auto`, `height` with `!important`).

## v1.2.81

### Fixed
- Matched Settings, Help, and CSS Studio standalone panel heights with the Variable panel exactly down to the pixel.
- Fixed CSS Studio editor sidecar visibility and layout clipping by removing nested scrollable containment.
- Fixed mutual exclusion of open panels so that multiple standalone panels can remain open at the same time.
- Synchronized BricksExtras and Advanced Themer shortcut rails in real-time on structure panel drag and resize.
- Fixed broken structure panel drag handle grab icon and positioned the minimize button as a header sibling.

## v1.2.80

### Added
- Implemented structure panel minimize/restore button interactions. Clicking the minimize button collapses the panel to a tree icon next to the bottom-right speed-dial, and clicking the restore button restores it.
- Enabled responsive sidecar placement for the CSS Studio sidecar (renders direct sibling outside scrollable `.ve-body`).

### Fixed
- Matched standalone panel heights (Settings, Help, CSS Studio) with the Variable panel.
- Fixed CSS Studio settings layout overlap and duplicate headers.
- Fixed BricksExtras shortcut container overlap by dynamically positioning it with a 16px space gap on the side of the structure panel, extracting it to the document body to prevent container containment clipping.
- Raised structure panel z-index to `2147483002` to render above canvas components.
- Fixed update transient caching by unsetting the stale response key in the updater cache.

## v1.2.79

### Fixed
- Restored pointer interaction (`pointer-events: auto !important`) on all standalone panels (Settings, Help, CSS Studio), allowing click, drag, and scroll operations instead of clicking through.
- Fixed the sticky "update available" notification issue by hooking into `upgrader_process_complete` and purging WordPress's plugin updates cache transient immediately after updates complete.

## v1.2.78

### Fixed
- Fixed bug where standalone panels (Settings, Help, CSS Studio) opened outside the viewport boundaries to the right.
- Excluded WordPress update pages (`update.php`, `update-core.php`) from loading the speed-dial menu assets to prevent centered floating icon visual issues.

## v1.2.77

### Added
- Consolidated settings: General/Vengine and Mimam's Bar settings are now unified inside a single standalone Settings panel using tabbed navigation.
- Extracted CSS Studio from the main command console into a standalone premium floating panel, toggled directly by the code icon in the bottom-right speed-dial menu.
- Enabled the speed-dial FAB menu and all floating panels (Settings, Help, CSS Studio) to render and function on standard WordPress Admin screens in addition to the Bricks builder.
- Implemented global click-outside-to-close behavior: clicking outside any standalone panel or command console automatically closes it.

### Fixed
- Fixed scrolling inside the floated Bricks structure panel by establishing correct flexbox height inheritance rules on nested panels.
- Standardized settings label text to "Undock Mimam's Bar and remember position".

## v1.2.76

### Added
- Extracted Settings and Help panels from the main Mimam's Bar command console into standalone floating windows.
- Added a Help icon (`ph('question')`) to the bottom-right speed-dial menu.
- Connected speed-dial menu clicks to directly toggle Settings and Help standalone panels.
- Enabled drag position management on standalone panels independently of the main bar's docking settings.
## v1.2.75

### Added
- Implemented a 'Deselect Element' shortcut for Bricks Builder, defaulting to Esc or Shift+D via settings.
- Refined the bottom-right hub into an intentional speed-dial menu that expands on hover.
- Added new settings to hide or show Vengine and Mimam's Bar icons from the Bricks top toolbar, dynamically clearing clutter.

## v1.2.74

### Fixed
- Replaced the hardcoded pixel-based initialization height for floating panels with a dynamic `70dvh` CSS value to keep the interface deeply responsive without constant recalibrations.
- Injected a dedicated `.mimams-bar-structure-wrapper` directly into the DOM to seamlessly group `#bricks-panel-header`, `.panel-content`, and `#brxcStructureTopContainer` within the Structure panel to maintain clean flex and grid behavior.
- Disabled transitions completely (`transition: none !important`) on floating host wrappers to outright kill any remaining native FOUC animations from Bricks.
- Scoped `#bricks-panel-header` `nowrap` explicitly to `#bricks-panel-elements` to ensure the structure panel continues to correctly wrap its header elements down.

### Fixed
- Enforced 70% window height explicitly for the floating structure panel to match the elements panel identically.
- Overhauled the early FOUC prevention script to instantly inject classes directly onto `<html>` before the body even paints, completely eliminating the brief docked flash on page load.
- Grouped the panel drag handle and `.title` element together in the DOM, forcing `.actions` underneath via flex wrapping for a cleaner header layout.
- Standardized the `#bricks-panel-search` input height so it strictly matches the height of its placeholder, resolving awkward vertical sizing.

### Fixed
- Eliminated the FOUC (Flash of Unstyled Content) where panels glitched in docked mode before switching to float on page load. A MutationObserver early script now seamlessly applies the floating classes as the body renders.
- Corrected `#bricks-panel-header` padding to ensure consistent spacing and aligned the drag handle perfectly horizontally on the same line as the header content.
- Ensured the Structure panel respects its native content height when floating instead of erroneously expanding to full screen height.
- Added a 2rem spacing gap before the BricksExtras shortcut container in the structure panel and aligned its items to the center.

### Fixed
- Fixed elements panel initializing with a short height by using window.innerHeight minus 100px.
- Unhid the structure panel header when floated, making the drag handle visible again.
- Removed the "Elements" and "Structure" text from the drag handles to prevent redundant "mimams bar floating panel" labels.
- Removed the 38px padding block start from floating panels and reset BricksExtras shortcut container padding to zero.

## v1.2.70

### Fixed

- Resolved the elements panel glitching on hide/unhide while floating by fixing the wrapper detection logic (`findPanelFromNode`) in `findElementsPanel`.
- Prevented the structure panel from losing its floating height when the browser resizes (e.g., opening Inspector) by explicitly setting `height` and `max-height` inline properties.
- Relocated the float drag handle inside the native Bricks panel headers.
- Replaced the online Phosphor icon with the local duotone SVG `dots-six-vertical-duotone.svg` for better styling.

## v1.2.69

### Fixed

- Resolved UI "freezes and lags" by removing forced heavy DOM scans during panel state retries in `settings-manager.js`.
- Fixed panel toggle glitches where Bricks panel widths would fall to 0, causing the detector to lose track and flicker.
- Re-introduced a safe wrapper bounding box logic (`markSafeHosts`) to collapse intermediate Bricks host wrappers, fixing "ghost background" when floating panels.

## v1.2.68

### Changed

- Re-wrote `builder.css` panel logic to use native Bricks ID selectors instead of tracking dynamic classes with JS.
- Replaced JS bounds-checking logic (`markFloatingHostChain`) with CSS-only visibility states based on `body` classes.

### Fixed

- Fixed floating panel bounds issues causing visual ghosting/flicker.
- Fixed the update manifest to resolve WordPress infinite update loop (bumped from v1.2.64 to v1.2.65, now correctly pointing to v1.2.68).

## Unreleased

### Added

- Added Vengine Agent OS folder structure and documentation files.

### Changed

- Updated `build.py` and manifest to `v1.2.66`.
- Redesigned floating panel UI drag handle to properly match the visual design of the main `.baqa-panel` header, adding left alignment, padding, and neon green panel titles (c01 fix).

### Fixed

- Hiding the Elements panel now correctly collapses its native wrapper completely (c02 fix). Fixed the `markFloatingHostChain` loop logic that was un-marking hidden elements due to `width: 0`, and added `opacity: 0`/`overflow: hidden` to ensure no grey background remains.
- **HOTFIX (v1.2.65)**: `VE_VERSION` constant on line 17 was still `1.2.64` while the header said `1.2.65`, causing an infinite WordPress update loop. Both now read `1.2.65`.

### Notes

- Future Antigravity agents should update this file after implementation work.
