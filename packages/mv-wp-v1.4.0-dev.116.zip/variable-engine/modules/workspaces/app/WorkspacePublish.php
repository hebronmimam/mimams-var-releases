<?php
/**
 * Publishing a workspace: preflight, apply, verify, commit.
 *
 * Slice 5 of the Workspaces module — the structural half of handoff §20.
 *
 * THE ONE RULE THAT SHAPES ALL OF THIS (§13)
 *
 *   > Do not simply publish the shadow post as a replacement when doing so
 *   > would break canonical identity, menus, external references, template
 *   > assignments, or other relationships.
 *
 * So publishing does NOT promote the shadow and does NOT delete the live post.
 * It copies the shadow's Bricks payload onto the LIVE post id. The published
 * page keeps its ID, its slug, its menu entries, its template assignments and
 * every link anyone has ever made to it. The shadow stays exactly where it was,
 * still a draft, so the workspace is still a workspace after a publish.
 *
 * AND THE ONE THAT DECIDES THE ORDER OF OPERATIONS (§68.12)
 *
 *   > Do not mark publish/deploy successful before verification.
 *
 * Written out, that is: open a release, apply, re-read what landed, compare it
 * with what was meant to land, and only then say the word "published". A
 * publish that verifies nothing is a publish that reports its own intentions.
 *
 * If verification fails for any object, every object this release wrote is put
 * back from its own `prior_payload` and the release is recorded as failed with
 * the object that broke it named. Partly-published is not a state a person
 * should ever have to reason about.
 *
 * WHAT IT REFUSES, AND WHY EACH REFUSAL IS NOT PESSIMISM
 *
 *   - a conflict (§68.11, do not silently merge): the page changed here AND on
 *     the site. Publishing would throw away the live change without saying so.
 *   - a live page that has gone: there is no identity left to publish onto.
 *   - an archived workspace, and a workspace with nothing to publish.
 *
 * A workspace that is merely BEHIND is publishable: its pages have not changed
 * on the site, only others have. That is said in the preflight rather than
 * blocked, because it is information, not a fault.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspacePublish {

    /**
     * What would happen, computed from the current state of the site.
     *
     * Always runs the slice 4 comparison first: a preflight made from stale
     * hashes is a preflight of a site that may no longer exist.
     */
    public static function preflight( int $workspace_id ): array {
        $workspace = WorkspaceStore::get( $workspace_id );
        if ( ! $workspace ) {
            return self::refusal( 've_workspace_missing', 'That workspace no longer exists.' );
        }
        if ( WorkspaceStore::STATUS_ARCHIVED === $workspace['status'] ) {
            return self::refusal(
                've_workspace_archived',
                'Bring the workspace back before publishing from it.'
            );
        }

        $objects   = WorkspaceSnapshot::refresh_all( $workspace_id );
        $publish   = [];
        $conflicts = [];
        $behind    = [];
        $missing   = [];
        $unchanged = 0;

        foreach ( $objects as $object ) {
            $state = isset( $object['state'] ) ? (string) $object['state'] : WorkspaceSnapshot::UNCHANGED;

            if ( ! self::live_exists( $object ) ) {
                $missing[] = $object;
                continue;
            }
            if ( WorkspaceSnapshot::CONFLICT === $state ) {
                $conflicts[] = $object;
                continue;
            }
            if ( WorkspaceSnapshot::BEHIND === $state ) {
                $behind[] = $object;
                $unchanged += 1;
                continue;
            }
            if ( WorkspaceSnapshot::MODIFIED === $state ) {
                $publish[] = $object;
                continue;
            }
            if ( WorkspaceSnapshot::CONVERGED === $state ) {
                // Both changed to the same thing. Writing it would be a no-op
                // that still spends a release record, so it is reported and
                // left alone rather than published.
                $unchanged += 1;
                continue;
            }
            $unchanged += 1;
        }

        $blockers = [];
        if ( $conflicts ) {
            $blockers[] = [
                'code'    => 've_publish_conflicts',
                'message' => self::count_phrase( count( $conflicts ), 'page' )
                    . ' changed here and on the site. Publishing would overwrite the live change.',
                'objects' => array_map( [ __CLASS__, 'brief' ], $conflicts ),
            ];
        }
        if ( $missing ) {
            $blockers[] = [
                'code'    => 've_publish_live_missing',
                'message' => self::count_phrase( count( $missing ), 'page' )
                    . ' no longer on the site, so there is nothing to publish onto.',
                'objects' => array_map( [ __CLASS__, 'brief' ], $missing ),
            ];
        }
        if ( ! $publish && ! $blockers ) {
            $blockers[] = [
                'code'    => 've_publish_nothing',
                'message' => 'Nothing in this workspace has changed, so there is nothing to publish.',
                'objects' => [],
            ];
        }

        return [
            'ok'        => empty( $blockers ),
            'workspace' => $workspace_id,
            'publish'   => array_map( [ __CLASS__, 'brief' ], $publish ),
            'behind'    => array_map( [ __CLASS__, 'brief' ], $behind ),
            'conflicts' => array_map( [ __CLASS__, 'brief' ], $conflicts ),
            'missing'   => array_map( [ __CLASS__, 'brief' ], $missing ),
            'unchanged' => $unchanged,
            'blockers'  => $blockers,
        ];
    }

    /**
     * Do it.
     *
     * @return array|\WP_Error The release record, or the preflight that refused.
     */
    public static function publish( int $workspace_id ) {
        $pre = self::preflight( $workspace_id );
        if ( empty( $pre['ok'] ) ) {
            return [ 'published' => false, 'preflight' => $pre ];
        }

        /* The objects are re-read by uuid rather than carried over from the
           preflight: between the two, nothing should have changed, and "should"
           is not a word to apply a page on. */
        $targets = [];
        foreach ( WorkspaceSnapshot::refresh_all( $workspace_id ) as $object ) {
            if ( WorkspaceSnapshot::MODIFIED === (string) $object['state'] && self::live_exists( $object ) ) {
                $targets[] = $object;
            }
        }
        if ( ! $targets ) {
            return [ 'published' => false, 'preflight' => self::preflight( $workspace_id ) ];
        }

        /* A deterministic order. Slice 11 turns this into §32's dependency
           graph; until there is one, "the order they were added" is honest and
           repeatable, which is what a release record needs. */
        usort( $targets, static function ( $a, $b ) {
            return (int) $a['id'] <=> (int) $b['id'];
        } );

        $planned = [];
        foreach ( $targets as $object ) {
            $planned[] = WorkspaceRelease::entry(
                $object,
                null,
                (string) $object['hashes']['base'],
                (string) $object['hashes']['workspace']
            );
        }

        $release = WorkspaceRelease::open( $workspace_id, $planned );
        if ( ! is_array( $release ) || isset( $release['error'] ) || is_wp_error( $release ) ) {
            return $release;
        }

        $written = [];
        $applied = [];
        foreach ( $targets as $object ) {
            $live   = (int) $object['live_id'];
            $shadow = (int) $object['shadow_id'];

            // §113: the whole previous value, captured BEFORE anything is
            // written, and kept per object so slice 6 can restore this one
            // alone.
            $prior = WorkspaceSnapshot::payload( $live );

            $applied[] = WorkspaceRelease::entry(
                $object,
                $prior,
                (string) $object['hashes']['base'],
                (string) $object['hashes']['workspace']
            );

            BricksPageAdapter::apply_payload( $live, WorkspaceSnapshot::payload( $shadow ) );
            $written[] = [ 'object' => $object, 'prior' => $prior ];
        }

        /* §68.12. Re-read the live pages and compare what is there with what
           was meant to be there. Not "the writes returned true" - what landed. */
        $broken = null;
        foreach ( $targets as $i => $object ) {
            $wanted = (string) $object['hashes']['workspace'];
            $landed = WorkspaceSnapshot::hash( (int) $object['live_id'] );
            if ( $landed !== $wanted ) {
                $broken = [ 'object' => $object, 'wanted' => $wanted, 'landed' => $landed ];
                break;
            }
        }

        if ( $broken ) {
            foreach ( array_reverse( $written ) as $undo ) {
                BricksPageAdapter::apply_payload( (int) $undo['object']['live_id'], $undo['prior'] );
            }
            $reason = 'Verification failed on "' . $broken['object']['label'] . '". Nothing was published: '
                . 'every page this release had already written was put back.';
            WorkspaceRelease::settle( (int) $release['id'], WorkspaceRelease::FAILED, $reason, $applied );
            return [
                'published' => false,
                'release'   => WorkspaceRelease::get( (int) $release['id'] ),
                'failed_on' => self::brief( $broken['object'] ),
            ];
        }

        /* Verified, and only now. The base moves to what was just published, so
           §19 reads "unchanged" on every page this release carried - which is
           true: the workspace and the site now say the same thing. */
        foreach ( $targets as $object ) {
            $published = (string) $object['hashes']['workspace'];
            WorkspaceObjectMap::set_hashes(
                (int) $object['id'],
                [ 'base' => $published, 'workspace' => $published, 'live' => $published ],
                WorkspaceSnapshot::UNCHANGED
            );
        }

        WorkspaceRelease::settle(
            (int) $release['id'],
            WorkspaceRelease::PUBLISHED,
            self::count_phrase( count( $targets ), 'page' ) . ' published and verified.',
            $applied
        );

        return [
            'published' => true,
            'release'   => WorkspaceRelease::get( (int) $release['id'] ),
            'count'     => count( $targets ),
        ];
    }

    // ── internals ──────────────────────────────────────────────────────────

    private static function live_exists( array $object ): bool {
        $live = isset( $object['live_id'] ) ? (int) $object['live_id'] : 0;
        return $live > 0 && (bool) get_post( $live );
    }

    /** What the panel needs to name an object, and nothing else. */
    private static function brief( array $object ): array {
        return [
            'id'      => (int) $object['id'],
            'uuid'    => (string) $object['uuid'],
            'label'   => (string) $object['label'],
            'type'    => (string) $object['object_type'],
            'live_id' => isset( $object['live_id'] ) ? (int) $object['live_id'] : 0,
            'state'   => (string) $object['state'],
        ];
    }

    private static function count_phrase( int $n, string $noun ): string {
        return 1 === $n ? ( 'One ' . $noun . ' is' ) : ( $n . ' ' . $noun . 's are' );
    }

    private static function refusal( string $code, string $message ): array {
        return [
            'ok'        => false,
            'publish'   => [],
            'behind'    => [],
            'conflicts' => [],
            'missing'   => [],
            'unchanged' => 0,
            'blockers'  => [ [ 'code' => $code, 'message' => $message, 'objects' => [] ] ],
        ];
    }
}
