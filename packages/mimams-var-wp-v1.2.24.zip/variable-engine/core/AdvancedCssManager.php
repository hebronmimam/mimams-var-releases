<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

class AdvancedCssManager {

    private const OPTION = 've_advanced_css';

    public function get(): array {
        $data = get_option( self::OPTION, [] );
        if ( ! is_array( $data ) ) {
            $data = [];
        }

        $sheets = $data['stylesheets'] ?? [];
        if ( ! is_array( $sheets ) || empty( $sheets ) ) {
            $sheets = $this->default_sheets();
        }

        return [
            'stylesheets' => array_values( array_map( [ $this, 'normalize_sheet' ], $sheets ) ),
            'file_url'    => $this->file_url(),
            'file_path'   => $this->file_path(),
        ];
    }

    public function save( array $sheets ): array {
        $clean = [];
        foreach ( $sheets as $sheet ) {
            if ( ! is_array( $sheet ) ) {
                continue;
            }
            $clean[] = $this->normalize_sheet( $sheet );
        }

        if ( empty( $clean ) ) {
            $clean = $this->default_sheets();
        }

        update_option( self::OPTION, [ 'stylesheets' => $clean ], false );
        $this->compile();

        return $this->get();
    }

    public function suggestions(): array {
        global $wpdb;

        $classes = [];
        $ids     = [];
        $vars    = [];

        $var_table = Schema::table( 'variables' );
        $rows = $wpdb->get_results( "SELECT name FROM {$var_table} ORDER BY name ASC", ARRAY_A ) ?: [];
        $manager = new VariableManager();
        foreach ( $rows as $row ) {
            $name = (string) ( $row['name'] ?? '' );
            if ( '' !== $name ) {
                $vars[] = $manager->to_css_name( $name );
            }
        }

        $scan_text = [];
        $posts = $wpdb->get_col(
            "SELECT post_content FROM {$wpdb->posts}
             WHERE post_status NOT IN ('trash','auto-draft')
             ORDER BY post_modified_gmt DESC
             LIMIT 600"
        ) ?: [];
        $scan_text = array_merge( $scan_text, $posts );

        $meta_rows = $wpdb->get_col(
            "SELECT meta_value FROM {$wpdb->postmeta}
             WHERE meta_key LIKE '_bricks_%'
                OR meta_key LIKE 'bricks_%'
                OR meta_key LIKE '%class%'
                OR meta_key LIKE '%css%'
             ORDER BY meta_id DESC
             LIMIT 1200"
        ) ?: [];
        $scan_text = array_merge( $scan_text, $meta_rows );

        $option_rows = $wpdb->get_col(
            "SELECT option_value FROM {$wpdb->options}
             WHERE option_name LIKE 'bricks_%'
                OR option_name LIKE '_bricks_%'
                OR option_name LIKE 'core_framework%'
                OR option_name LIKE 'automatic_css%'
                OR option_name LIKE '%advanced%themer%'
                OR option_name LIKE '%custom_css%'
             LIMIT 500"
        ) ?: [];
        $scan_text = array_merge( $scan_text, $option_rows );

        foreach ( $scan_text as $text ) {
            $text = maybe_unserialize( $text );
            if ( is_array( $text ) || is_object( $text ) ) {
                $this->extract_identifiers_from_data( $text, $classes, $ids );
                $text = wp_json_encode( $text );
            }
            $text = (string) $text;
            if ( '' === $text ) {
                continue;
            }

            $decoded = json_decode( $text, true );
            if ( is_array( $decoded ) ) {
                $this->extract_identifiers_from_data( $decoded, $classes, $ids );
            }

            if ( preg_match_all( '/class(?:Name)?=["\']([^"\']+)["\']/i', $text, $matches ) ) {
                foreach ( $matches[1] as $match ) {
                    foreach ( preg_split( '/\s+/', $match ) as $class ) {
                        $this->add_identifier( $classes, $class, '.' );
                    }
                }
            }

            if ( preg_match_all( '/"class(?:Name)?"\s*:\s*"([^"]+)"/i', $text, $matches ) ) {
                foreach ( $matches[1] as $match ) {
                    foreach ( preg_split( '/\s+/', $match ) as $class ) {
                        $this->add_identifier( $classes, $class, '.' );
                    }
                }
            }

            if ( preg_match_all( '/id=["\']([A-Za-z][A-Za-z0-9_-]*)["\']/i', $text, $matches ) ) {
                foreach ( $matches[1] as $id ) {
                    $this->add_identifier( $ids, $id, '#' );
                }
            }

            if ( preg_match_all( '/"id"\s*:\s*"([A-Za-z][A-Za-z0-9_-]*)"/i', $text, $matches ) ) {
                foreach ( $matches[1] as $id ) {
                    $this->add_identifier( $ids, $id, '#' );
                }
            }

            if ( preg_match_all( '/\.([A-Za-z_][A-Za-z0-9_-]*)/', $text, $matches ) ) {
                foreach ( $matches[1] as $class ) {
                    $this->add_identifier( $classes, $class, '.' );
                }
            }

            if ( preg_match_all( '/#([A-Za-z_][A-Za-z0-9_-]*)/', $text, $matches ) ) {
                foreach ( $matches[1] as $id ) {
                    $this->add_identifier( $ids, $id, '#' );
                }
            }
        }

        $sources = ( new MigrationScanner() )->sources();
        $source_labels = [ "Mimam's Var" ];
        foreach ( $sources as $source ) {
            if ( ! empty( $source['available'] ) ) {
                if ( 'Bricks / Advanced Themer' === $source['name'] ) {
                    $source_labels[] = 'Bricks';
                    $source_labels[] = 'Advanced Themer';
                } else {
                    $source_labels[] = (string) $source['name'];
                }
            }
        }
        if ( ! empty( $classes ) ) {
            $source_labels[] = 'CSS Classes';
        }
        if ( ! empty( $ids ) ) {
            $source_labels[] = 'Element IDs';
        }

        return [
            'variables' => $this->sorted_keys( $vars ),
            'classes'   => $this->sorted_keys( array_keys( $classes ) ),
            'ids'       => $this->sorted_keys( array_keys( $ids ) ),
            'sources'   => array_values( array_unique( $source_labels ) ),
        ];
    }

    public function compile(): array {
        $data   = $this->get();
        $sheets = $data['stylesheets'];
        $lines  = [
            '/*',
            " * Mimam's Var - CSS Studio",
            ' * Version: ' . VE_VERSION,
            ' * Compiled: ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC',
            ' */',
            '',
        ];

        foreach ( $sheets as $sheet ) {
            if ( empty( $sheet['enabled'] ) || '' === trim( (string) $sheet['css'] ) ) {
                continue;
            }
            $lines[] = '/* === ' . $sheet['name'] . ' (' . $sheet['scope'] . ') === */';
            $lines[] = rtrim( (string) $sheet['css'] );
            $lines[] = '';
        }

        if ( ! is_dir( VE_CSS_OUTPUT_DIR ) ) {
            wp_mkdir_p( VE_CSS_OUTPUT_DIR );
        }

        $written = file_put_contents( $this->file_path(), implode( "\n", $lines ) );

        return [
            'compiled'  => false !== $written,
            'file_url'  => $this->file_url(),
            'file_path' => $this->file_path(),
        ];
    }

    private function normalize_sheet( array $sheet ): array {
        $id = sanitize_key( (string) ( $sheet['id'] ?? '' ) );
        if ( '' === $id ) {
            $id = 'sheet_' . substr( md5( wp_json_encode( $sheet ) . microtime( true ) ), 0, 8 );
        }

        $scope = sanitize_key( (string) ( $sheet['scope'] ?? 'global' ) );
        if ( ! in_array( $scope, [ 'page', 'global', 'child', 'custom', 'recipe' ], true ) ) {
            $scope = 'custom';
        }

        return [
            'id'      => $id,
            'name'    => sanitize_text_field( (string) ( $sheet['name'] ?? 'custom.css' ) ),
            'scope'   => $scope,
            'enabled' => ! isset( $sheet['enabled'] ) || ! empty( $sheet['enabled'] ),
            'css'     => wp_kses_post( (string) ( $sheet['css'] ?? '' ) ),
        ];
    }

    private function default_sheets(): array {
        return [
            [ 'id' => 'global', 'name' => 'global.css', 'scope' => 'global', 'enabled' => true, 'css' => '' ],
        ];
    }

    private function add_identifier( array &$bucket, string $value, string $prefix ): void {
        $value = trim( html_entity_decode( $value, ENT_QUOTES, 'UTF-8' ) );
        $value = preg_replace( '/[^A-Za-z0-9_-]/', '', $value );
        if ( ! is_string( $value ) || '' === $value || is_numeric( $value[0] ) ) {
            return;
        }
        if ( 80 < strlen( $value ) ) {
            return;
        }
        if ( '#' === $prefix && preg_match( '/^[A-Fa-f0-9]{3,8}$/', $value ) ) {
            return;
        }
        $bucket[ $prefix . $value ] = true;
    }

    private function extract_identifiers_from_data( $data, array &$classes, array &$ids, string $parent_key = '', int $depth = 0 ): void {
        if ( 8 < $depth ) {
            return;
        }

        if ( is_object( $data ) ) {
            $data = (array) $data;
        }

        if ( ! is_array( $data ) ) {
            if ( '' !== $parent_key ) {
                $this->extract_identifier_value( $parent_key, $data, $classes, $ids );
            }
            return;
        }

        foreach ( $data as $key => $value ) {
            $key_string = is_string( $key ) ? $key : $parent_key;
            if ( '' !== $key_string ) {
                $this->extract_identifier_value( $key_string, $value, $classes, $ids );
            }

            if ( is_array( $value ) || is_object( $value ) ) {
                $this->extract_identifiers_from_data( $value, $classes, $ids, $key_string, $depth + 1 );
            }
        }
    }

    private function extract_identifier_value( string $key, $value, array &$classes, array &$ids ): void {
        $key = strtolower( $key );
        $is_class_key = false !== strpos( $key, 'class' );
        $is_id_key    = 'id' === $key || false !== strpos( $key, '_id' ) || false !== strpos( $key, '-id' ) || false !== strpos( $key, 'id_' );

        if ( ! $is_class_key && ! $is_id_key ) {
            return;
        }

        if ( is_array( $value ) || is_object( $value ) ) {
            $value = wp_json_encode( $value );
        }

        $value = trim( (string) $value );
        if ( '' === $value || 2000 < strlen( $value ) ) {
            return;
        }

        $tokens = preg_split( '/[\s,"\':;\[\]\{\}]+/', $value ) ?: [];
        foreach ( $tokens as $token ) {
            $token = trim( $token );
            if ( '' === $token ) {
                continue;
            }
            if ( $is_class_key ) {
                $this->add_identifier( $classes, ltrim( $token, '.' ), '.' );
            }
            if ( $is_id_key ) {
                $this->add_identifier( $ids, ltrim( $token, '#' ), '#' );
            }
        }
    }

    private function sorted_keys( array $items ): array {
        $items = array_values( array_unique( array_filter( $items ) ) );
        natcasesort( $items );
        return array_values( array_slice( $items, 0, 2500 ) );
    }

    private function file_path(): string {
        return VE_CSS_OUTPUT_DIR . 'advanced.css';
    }

    private function file_url(): string {
        return VE_CSS_OUTPUT_URL . 'advanced.css';
    }
}
