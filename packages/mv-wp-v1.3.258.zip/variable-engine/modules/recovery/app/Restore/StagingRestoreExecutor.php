<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Backup\PackageBuilder;
use VE\Modules\Recovery\Backup\PackageValidator;
use VE\Modules\Recovery\Jobs\JobRunner;
use VE\Modules\Recovery\Jobs\JobStore;
use VE\Modules\Recovery\Jobs\TaskResponse;
use VE\Modules\Recovery\Utils\Logger;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared

defined( 'ABSPATH' ) || exit;

final class StagingRestoreExecutor {
    private JobStore $jobs;

    public function __construct( ?JobStore $jobs = null ) {
        $this->jobs = $jobs ?: new JobStore();
    }

    public function execute( string $snapshot_key = '', string $confirmation = '', string $passphrase = '' ): array {
        $snapshot_key = sanitize_text_field( $snapshot_key );
        $confirmation = trim( sanitize_text_field( $confirmation ) );
        $label = 'Staging restore execution ' . current_time( 'mysql' );
        $tasks = $this->tasks( $snapshot_key, $confirmation, $passphrase );
        $job = $this->jobs->create( 'staging_restore', $label, $tasks );
        $run = ( new JobRunner( $this->jobs ) )->run( (string) $job['job_key'], $tasks, [
            'snapshot_key'  => $snapshot_key,
            'confirmation'  => $confirmation,
        ] );

        $result = isset( $run['context']['finish_execution'] ) && is_array( $run['context']['finish_execution'] ) ? $run['context']['finish_execution'] : [];
        $result['job'] = $this->jobs->get( (string) $job['job_key'] );
        $result['ok'] = ! empty( $run['ok'] );
        $result['message'] = $run['message'] ?? ( ! empty( $run['ok'] ) ? 'Staging restore finished.' : 'Staging restore was blocked.' );
        return $result;
    }

    private function tasks( string $snapshot_key, string $confirmation, string $passphrase = '' ): array {
        return [
            [
                'id'       => 'confirmation_gate',
                'label'    => 'Confirmation Gate',
                'callback' => function () use ( $confirmation ) {
                    if ( 'RESTORE STAGING' !== $confirmation ) {
                        return TaskResponse::fail( 'Type RESTORE STAGING to unlock staging-only execution.', [ 'required' => 'RESTORE STAGING' ] );
                    }
                    return TaskResponse::ok( 'Typed confirmation accepted.', [ 'confirmed' => true ] );
                },
            ],
            [
                'id'       => 'environment_gate',
                'label'    => 'Environment Gate',
                'callback' => function () {
                    $site = ( new \VE\Modules\Recovery\Backup\SiteScanner() )->scan();
                    $env = function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'production';
                    $allowed = RestoreReadiness::is_staging_like( $site, $env );
                    return $allowed ? TaskResponse::ok( 'Staging/local environment confirmed.', [ 'environment' => $env ] ) : TaskResponse::fail( 'This site looks like production. Staging restore execution is blocked.', [ 'environment' => $env ] );
                },
            ],
            [
                'id'       => 'locate_package',
                'label'    => 'Locate Package',
                'callback' => function () use ( $snapshot_key ) {
                    $located = ( new PackageLocator() )->locate( $snapshot_key );
                    return ! empty( $located['ok'] ) ? TaskResponse::ok( 'Package located.', $located ) : TaskResponse::fail( (string) $located['message'], $located );
                },
            ],
            [
                'id'       => 'validate_package',
                'label'    => 'Validate Package',
                'callback' => function () use ( $snapshot_key, $passphrase ) {
                    $validation = ( new PackageValidator() )->validate_snapshot( $snapshot_key, $passphrase );
                    return ! empty( $validation['ok'] ) ? TaskResponse::ok( 'Package validation passed.', $validation ) : TaskResponse::fail( 'Package validation has blockers.', $validation );
                },
            ],
            [
                'id'       => 'capture_restorebase_state',
                'label'    => 'Protect RestoreBase State',
                'callback' => function () {
                    $state = ( new SelfProtection() )->capture();
                    return ! empty( $state['ok'] ) ? TaskResponse::ok( 'RestoreBase memory captured before restore.', $state ) : TaskResponse::fail( 'RestoreBase memory could not be captured.', $state );
                },
            ],
            [
                'id'       => 'pre_restore_package',
                'label'    => 'Pre-Restore Safety Package',
                'callback' => function () {
                    $package = ( new PackageBuilder() )->create( 'Pre-restore safety package ' . current_time( 'mysql' ) );
                    return ! empty( $package['id'] ) && 'completed' === ( $package['status'] ?? '' ) ? TaskResponse::ok( 'Pre-restore safety package created.', $package ) : TaskResponse::fail( 'Pre-restore safety package failed. Restore execution stopped.', $package );
                },
            ],
            [
                'id'       => 'prepare_workspace',
                'label'    => 'Prepare Workspace',
                'callback' => function ( array $context ) use ( $snapshot_key, $passphrase ) {
                    $prep = ( new RestorePreparation() )->prepare( $snapshot_key, $passphrase );
                    return ! empty( $prep['workspace']['ok'] ) || ! empty( $prep['plan_file']['ok'] ) ? TaskResponse::ok( 'Restore workspace and plan prepared.', $prep ) : TaskResponse::fail( 'Restore workspace preparation failed.', $prep );
                },
            ],
            [
                'id'       => 'readiness_check',
                'label'    => 'Readiness Check',
                'callback' => function ( array $context ) use ( $snapshot_key, $passphrase ) {
                    $prep = isset( $context['prepare_workspace'] ) && is_array( $context['prepare_workspace'] ) ? $context['prepare_workspace'] : [];
                    $readiness = ( new RestoreReadiness() )->assess( $snapshot_key, $prep['workspace'] ?? [], $passphrase );
                    return ! empty( $readiness['ok'] ) ? TaskResponse::ok( 'Restore readiness passed.', $readiness ) : TaskResponse::fail( 'Restore readiness has blockers.', $readiness );
                },
            ],
            [
                'id'       => 'stage_files',
                'label'    => 'Stage Files',
                'callback' => function ( array $context ) {
                    $prep = $context['prepare_workspace'] ?? [];
                    $workspace = $prep['workspace'] ?? [];
                    $entries = $prep['package_extract']['entries'] ?? $prep['extract_metadata']['entries'] ?? [];
                    if ( empty( $entries ) && isset( $prep['workspace']['path'] ) ) {
                        $files_zip = $this->restore_files_archive_path( $prep['workspace'] );
                    } else {
                        $files_zip = isset( $entries['files.restorebase']['path'] ) ? (string) $entries['files.restorebase']['path'] : ( isset( $entries['files.zip']['path'] ) ? (string) $entries['files.zip']['path'] : '' );
                    }
                    $stage = ( new FileRestoreStager() )->stage( $files_zip, $workspace );
                    return ! empty( $stage['ok'] ) ? TaskResponse::ok( 'Files staged.', $stage ) : TaskResponse::fail( 'Files staging failed.', $stage );
                },
            ],
            [
                'id'       => 'temp_database_import',
                'label'    => 'Temporary DB Import',
                'callback' => function ( array $context ) {
                    $prep = $context['prepare_workspace'] ?? [];
                    $workspace = $prep['workspace'] ?? [];
                    $sql_path = trailingslashit( (string) ( $workspace['extracted'] ?? '' ) ) . 'database.sql';
                    $plan = $prep['sql_import_plan'] ?? [];
                    $token = strtolower( wp_generate_password( 5, false, false ) );
                    $import = ( new SQLTemporaryImporter() )->import( $sql_path, $plan, $token );
                    return ! empty( $import['ok'] ) ? TaskResponse::ok( 'Database imported to temporary tables.', $import ) : TaskResponse::fail( 'Temporary database import failed.', $import );
                },
            ],
            [
                'id'       => 'swap_database_tables',
                'label'    => 'Swap DB Tables',
                'callback' => function ( array $context ) {
                    $import = $context['temp_database_import'] ?? [];
                    $map = isset( $import['map'] ) && is_array( $import['map'] ) ? $import['map'] : [];
                    $swap = ( new SQLTemporaryImporter() )->swap_to_live( $map );
                    return ! empty( $swap['ok'] ) ? TaskResponse::ok( 'Temporary tables swapped into live names.', $swap ) : TaskResponse::fail( (string) ( $swap['message'] ?? 'Database table swap failed.' ), $swap );
                },
            ],
            [
                'id'       => 'apply_url_options',
                'label'    => 'Apply URL Options',
                'callback' => function ( array $context ) {
                    global $wpdb;
                    $prep = isset( $context['prepare_workspace'] ) && is_array( $context['prepare_workspace'] ) ? $context['prepare_workspace'] : [];
                    $plan = isset( $prep['serialized_rewrite_plan'] ) && is_array( $prep['serialized_rewrite_plan'] ) ? $prep['serialized_rewrite_plan'] : [];
                    $rewrite = ( new SerializedRewritePlanner() )->apply_destination_url_lock( (string) $wpdb->prefix, $plan );
                    return ! empty( $rewrite['ok'] ) ? TaskResponse::ok( 'Destination URL kept and backup URLs rewritten.', $rewrite ) : TaskResponse::fail( 'Destination URL lock failed.', $rewrite );
                },
            ],
            [
                'id'       => 'reapply_restorebase_state',
                'label'    => 'Reapply RestoreBase State',
                'callback' => function ( array $context ) {
                    $state = isset( $context['capture_restorebase_state'] ) && is_array( $context['capture_restorebase_state'] ) ? $context['capture_restorebase_state'] : [];
                    $result = ( new SelfProtection() )->reapply( $state );
                    return ! empty( $result['ok'] ) ? TaskResponse::ok( 'RestoreBase memory preserved after restore.', $result ) : TaskResponse::fail( 'RestoreBase memory could not be preserved.', $result );
                },
            ],
            [
                'id'       => 'restore_mv_settings',
                'label'    => 'Restore MV Settings',
                'callback' => function ( array $context ) {
                    $prep = isset( $context['prepare_workspace'] ) && is_array( $context['prepare_workspace'] ) ? $context['prepare_workspace'] : [];
                    $manifest = isset( $prep['package_manifest'] ) && is_array( $prep['package_manifest'] ) ? $prep['package_manifest'] : [];
                    $portability = new MVSettingsPortability();
                    $result = $portability->apply_from_manifest( $manifest, $portability->destination_user_id_from_context( $context ) );
                    // MV settings portability is best-effort and runs after the database and
                    // files are already restored, so it must never fail the restore. Surface
                    // the outcome and continue regardless.
                    return TaskResponse::ok( (string) ( $result['message'] ?? 'MV settings step completed.' ), $result );
                },
            ],
            [
                'id'       => 'copy_staged_files',
                'label'    => 'Copy Staged Files',
                'callback' => function ( array $context ) {
                    $stage = $context['stage_files'] ?? [];
                    $copy = ( new FileRestoreStager() )->apply_to_site( $stage );
                    return ! empty( $copy['ok'] ) ? TaskResponse::ok( 'Staged files restored.', $copy ) : TaskResponse::fail( (string) ( $copy['message'] ?? 'Some staged files failed to restore.' ), $copy );
                },
            ],
            [
                'id'       => 'restore_plugin_state',
                'label'    => 'Restore Plugin State',
                'callback' => function ( array $context ) {
                    $state = ( new PluginStateRestorer() )->apply_from_context( $context );
                    return ! empty( $state['ok'] ) ? TaskResponse::ok( 'Plugin activation state restored from backup.', $state ) : TaskResponse::fail( 'Plugin activation state could not be restored.', $state );
                },
            ],
            [
                'id'       => 'finish_execution',
                'label'    => 'Finish Execution',
                'callback' => function ( array $context ) {
                    // The raw table swap changes the database underneath WordPress without
                    // going through its APIs, so any persistent object cache (LiteSpeed,
                    // Redis, Memcached) still holds the pre-restore data. Only the production
                    // path flushed it via PostRestoreHardener; without the same flush here a
                    // staging restore leaves options, posts, terms and media reading stale —
                    // which is why the Studios showed no content and settings looked unrestored
                    // even though the swap succeeded. Flush the object and plugin/theme caches.
                    if ( function_exists( 'wp_cache_flush' ) ) {
                        wp_cache_flush();
                    }
                    if ( function_exists( 'wp_clean_plugins_cache' ) ) {
                        wp_clean_plugins_cache( true );
                    }
                    if ( function_exists( 'wp_clean_themes_cache' ) ) {
                        wp_clean_themes_cache( true );
                    }
                    if ( function_exists( 'flush_rewrite_rules' ) ) {
                        flush_rewrite_rules();
                    }
                    Logger::warning( 'staging_restore_executed', 'RestoreBase staging-only restore execution completed.', [ 'context_keys' => array_keys( $context ) ] );
                    return TaskResponse::ok( 'Staging-only restore execution completed. Verify the site immediately.', [
                        'executed'       => true,
                        'verify_now'     => [ 'frontend', 'wp-admin', 'media', 'plugins', 'theme', 'permalinks' ],
                        'rollback_source'=> $context['pre_restore_package'] ?? [],
                        'database_swap'  => $context['swap_database_tables'] ?? [],
                        'file_copy'      => $context['copy_staged_files'] ?? [],
                        'plugin_state'   => $context['restore_plugin_state'] ?? [],
                        'self_state'     => $context['reapply_restorebase_state'] ?? [],
                        'mv_settings'    => $context['restore_mv_settings'] ?? [],
                    ] );
                },
            ],
        ];
    }

    private function restore_files_archive_path( array $workspace ): string {
        $base = trailingslashit( (string) ( $workspace['extracted'] ?? '' ) );
        $bundle = $base . 'files.restorebase';
        if ( is_readable( $bundle ) ) {
            return $bundle;
        }
        return $base . 'files.zip';
    }
}
