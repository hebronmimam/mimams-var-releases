<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Backup\PackageValidator;
use VE\Modules\Recovery\Jobs\JobRunner;
use VE\Modules\Recovery\Jobs\JobStore;
use VE\Modules\Recovery\Jobs\TaskResponse;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Guarded production restore runner.
 *
 * This uses the same safety chain as staging restore, but does not block on
 * wp_get_environment_type(). It requires an explicit typed confirmation and
 * creates a pre-restore safety package first.
 */
final class ProductionRestoreExecutor {
    private JobStore $jobs;

    public function __construct( ?JobStore $jobs = null ) {
        $this->jobs = $jobs ?: new JobStore();
    }

    public function begin( string $snapshot_key = '', string $confirmation = '', string $passphrase = '' ): array {
        $snapshot_key = sanitize_text_field( $snapshot_key );
        $confirmation = trim( sanitize_text_field( $confirmation ) );

        if ( 'RESTORE PRODUCTION' !== $confirmation ) {
            return [ 'ok' => false, 'message' => 'Type RESTORE to start the guarded restore.', 'required' => 'RESTORE' ];
        }

        $label = 'Production restore execution ' . current_time( 'mysql' );
        $tasks = $this->tasks( $snapshot_key, $confirmation, $passphrase );
        $job = $this->jobs->create( 'production_restore', $label, $tasks );
        $job_key = isset( $job['job_key'] ) ? (string) $job['job_key'] : '';
        $token = wp_generate_password( 32, false, false );

        if ( '' === $job_key ) {
            return [ 'ok' => false, 'message' => 'Restore job could not be created.' ];
        }

        // The passphrase lives only in the protected RestoreBase jobs table (excluded
        // from package exports) so the nopriv job runner can decrypt after auth drops.
        $token_meta = $this->token_meta( $job_key, $snapshot_key, $confirmation, $token );
        $token_meta['passphrase'] = $passphrase;

        // Store the restore job token in two places:
        // - a transient for normal pre-restore operation;
        // - the protected RestoreBase jobs table so status polling survives the options table swap.
        set_transient( $this->transient_key( $job_key ), $token_meta, 6 * HOUR_IN_SECONDS );
        $this->jobs->merge_result( $job_key, [ 'restorebase_job_meta' => $token_meta ] );

        return [
            'ok'           => true,
            'message'      => 'Restore job created.',
            'job_key'      => $job_key,
            'status_token' => $token,
            'job'          => $job,
        ];
    }

    public function execute_job( string $job_key = '', string $token = '' ): array {
        $job_key = sanitize_text_field( $job_key );
        $token = sanitize_text_field( $token );
        $meta = $this->job_meta( $job_key, $token );
        if ( empty( $meta['ok'] ) ) {
            return $meta;
        }

        $snapshot_key = (string) ( $meta['snapshot_key'] ?? '' );
        $confirmation = (string) ( $meta['confirmation'] ?? '' );
        $passphrase = (string) ( $meta['passphrase'] ?? '' );
        $run = ( new JobRunner( $this->jobs ) )->run( $job_key, $this->tasks( $snapshot_key, $confirmation, $passphrase ), [
            'snapshot_key'          => $snapshot_key,
            'confirmation'          => $confirmation,
            'restorebase_job_meta'  => $this->storable_job_meta( $meta ),
        ] );

        $result = isset( $run['context']['finish_execution'] ) && is_array( $run['context']['finish_execution'] ) ? $run['context']['finish_execution'] : [];
        $result['job'] = $this->jobs->get( $job_key );
        $result['ok'] = ! empty( $run['ok'] );
        $result['message'] = $run['message'] ?? ( ! empty( $run['ok'] ) ? 'Production restore finished.' : 'Production restore was blocked.' );
        return $result;
    }

    public function status( string $job_key = '', string $token = '' ): array {
        $job_key = sanitize_text_field( $job_key );
        $token = sanitize_text_field( $token );
        $meta = $this->job_meta( $job_key, $token );
        if ( empty( $meta['ok'] ) ) {
            return $meta;
        }

        $job = $this->jobs->get( $job_key );
        if ( ! $job ) {
            return [ 'ok' => false, 'message' => 'Restore job not found.' ];
        }

        return [
            'ok'      => true,
            'message' => (string) ( $job['message'] ?? 'Restore job status loaded.' ),
            'job'     => $job,
        ];
    }

    public function execute( string $snapshot_key = '', string $confirmation = '', string $passphrase = '' ): array {
        $snapshot_key = sanitize_text_field( $snapshot_key );
        $confirmation = trim( sanitize_text_field( $confirmation ) );
        $label = 'Production restore execution ' . current_time( 'mysql' );
        $tasks = $this->tasks( $snapshot_key, $confirmation, $passphrase );
        $job = $this->jobs->create( 'production_restore', $label, $tasks );
        $run = ( new JobRunner( $this->jobs ) )->run( (string) $job['job_key'], $tasks, [
            'snapshot_key' => $snapshot_key,
            'confirmation' => $confirmation,
        ] );

        $result = isset( $run['context']['finish_execution'] ) && is_array( $run['context']['finish_execution'] ) ? $run['context']['finish_execution'] : [];
        $result['job'] = $this->jobs->get( (string) $job['job_key'] );
        $result['ok'] = ! empty( $run['ok'] );
        $result['message'] = $run['message'] ?? ( ! empty( $run['ok'] ) ? 'Production restore finished.' : 'Production restore was blocked.' );
        return $result;
    }

    private function job_meta( string $job_key, string $token ): array {
        if ( '' === $job_key || '' === $token ) {
            return [ 'ok' => false, 'message' => 'Restore job token is missing.' ];
        }

        $meta = get_transient( $this->transient_key( $job_key ) );
        if ( ! is_array( $meta ) ) {
            $job = $this->jobs->get( $job_key );
            $result = $job && isset( $job['result'] ) && is_array( $job['result'] ) ? $job['result'] : [];
            $meta = isset( $result['restorebase_job_meta'] ) && is_array( $result['restorebase_job_meta'] ) ? $result['restorebase_job_meta'] : [];
        }

        $hash = (string) ( $meta['status_token_hash'] ?? '' );
        $candidate = $this->hash_token( $job_key, $token );
        if ( '' === $hash || ! hash_equals( $hash, $candidate ) ) {
            return [ 'ok' => false, 'message' => 'Restore job token is invalid or expired.' ];
        }

        $meta['ok'] = true;
        // Re-prime the transient when possible. It may have disappeared during the restored options table swap.
        set_transient( $this->transient_key( $job_key ), $meta, 6 * HOUR_IN_SECONDS );
        return $meta;
    }

    private function token_meta( string $job_key, string $snapshot_key, string $confirmation, string $token ): array {
        return [
            'snapshot_key'       => $snapshot_key,
            'confirmation'       => $confirmation,
            'status_token_hash'  => $this->hash_token( $job_key, $token ),
            'created_at'         => time(),
            'storage'            => 'restorebase_protected_job_table',
        ];
    }

    private function hash_token( string $job_key, string $token ): string {
        return hash_hmac( 'sha256', $token, $this->token_secret() . '|' . $job_key );
    }

    private function token_secret(): string {
        $parts = [];
        foreach ( [ 'AUTH_KEY', 'SECURE_AUTH_KEY', 'LOGGED_IN_KEY', 'NONCE_KEY', 'DB_NAME', 'DB_USER' ] as $constant ) {
            if ( defined( $constant ) ) {
                $value = (string) constant( $constant );
                if ( '' !== $value && false === strpos( $value, 'put your unique phrase here' ) ) {
                    $parts[] = $constant . ':' . $value;
                }
            }
        }
        $parts[] = 'ABSPATH:' . ( defined( 'ABSPATH' ) ? (string) ABSPATH : '' );
        $parts[] = 'VE_RECOVERY_FILE:' . ( defined( 'VE_RECOVERY_FILE' ) ? (string) VE_RECOVERY_FILE : '' );

        return hash( 'sha256', implode( '|', $parts ) );
    }

    private function storable_job_meta( array $meta ): array {
        unset( $meta['ok'] );
        return $meta;
    }

    private function transient_key( string $job_key ): string {
        return 'restorebase_restore_job_' . preg_replace( '/[^A-Za-z0-9_\-]/', '', $job_key );
    }

    private function tasks( string $snapshot_key, string $confirmation, string $passphrase = '' ): array {
        return [
            [
                'id'       => 'confirmation_gate',
                'label'    => 'Production Confirmation',
                'callback' => function () use ( $confirmation ) {
                    if ( 'RESTORE PRODUCTION' !== $confirmation ) {
                        return TaskResponse::fail( 'Type RESTORE PRODUCTION to run guarded production restore.', [ 'required' => 'RESTORE PRODUCTION' ] );
                    }
                    return TaskResponse::ok( 'Production confirmation accepted.', [ 'confirmed' => true ] );
                },
            ],
            [
                'id'       => 'locate_package',
                'label'    => 'Locate Package',
                'callback' => function () use ( $snapshot_key ) {
                    $located = ( new PackageLocator() )->locate( $snapshot_key );
                    return ! empty( $located['ok'] ) ? TaskResponse::ok( 'Package located.', $located ) : TaskResponse::fail( (string) ( $located['message'] ?? 'Package not found.' ), $located );
                },
            ],
            [
                'id'       => 'validate_package',
                'label'    => 'Validate Package',
                'callback' => function () use ( $snapshot_key, $passphrase ) {
                    $validation = ( new PackageValidator() )->validate_snapshot( $snapshot_key, $passphrase );
                    return ! empty( $validation['ok'] ) ? TaskResponse::ok( 'Package validation passed.', $validation ) : TaskResponse::fail( 'Package validation has blockers.', $validation );
                },
            ],
            [
                'id'       => 'capture_restorebase_state',
                'label'    => 'Protect RestoreBase State',
                'callback' => function () {
                    $state = ( new SelfProtection() )->capture();
                    return ! empty( $state['ok'] ) ? TaskResponse::ok( 'RestoreBase memory captured before restore.', $state ) : TaskResponse::fail( 'RestoreBase memory could not be captured.', $state );
                },
            ],
            [
                'id'       => 'capture_destination_access',
                'label'    => 'Protect Destination Login',
                'callback' => function () {
                    $state = ( new DestinationAccessGuard() )->capture();
                    return ! empty( $state['ok'] ) ? TaskResponse::ok( 'Destination admin login captured before restore.', $state ) : TaskResponse::fail( 'Destination admin login could not be captured.', $state );
                },
            ],
            [
                'id'       => 'pre_restore_package',
                'label'    => 'Create Restore Point',
                'callback' => function () {
                    $marker = [
                        'ok'          => true,
                        'created_at'  => current_time( 'mysql' ),
                        'site_url'    => site_url(),
                        'home_url'    => home_url(),
                        'table_prefix'=> isset( $GLOBALS['wpdb'] ) ? (string) $GLOBALS['wpdb']->prefix : '',
                        'note'        => 'Fast restore point created. Full destination backup should be created separately before risky restores.',
                    ];
                    return TaskResponse::ok( 'Fast restore point created.', $marker );
                },
            ],
            [
                'id'       => 'prepare_workspace',
                'label'    => 'Prepare Workspace',
                'callback' => function () use ( $snapshot_key, $passphrase ) {
                    $prep = ( new RestorePreparation() )->prepare( $snapshot_key, $passphrase );
                    return ! empty( $prep['workspace']['ok'] ) || ! empty( $prep['plan_file']['ok'] ) ? TaskResponse::ok( 'Restore workspace and plan prepared.', $prep ) : TaskResponse::fail( 'Restore workspace preparation failed.', $prep );
                },
            ],
            [
                'id'       => 'readiness_check',
                'label'    => 'Readiness Check',
                'callback' => function ( array $context ) use ( $snapshot_key, $passphrase ) {
                    $prep = isset( $context['prepare_workspace'] ) && is_array( $context['prepare_workspace'] ) ? $context['prepare_workspace'] : [];
                    $readiness = ( new RestoreReadiness() )->assess( $snapshot_key, $prep['workspace'] ?? [], $passphrase );
                    return ! empty( $readiness['score'] ) && (int) $readiness['score'] >= 65 ? TaskResponse::ok( 'Restore readiness accepted for guarded production restore.', $readiness ) : TaskResponse::fail( 'Restore readiness score is too low for production restore.', $readiness );
                },
            ],
            [
                'id'       => 'apply_portable_config',
                'label'    => 'Apply Portable Config',
                'callback' => function ( array $context ) {
                    $prep = isset( $context['prepare_workspace'] ) && is_array( $context['prepare_workspace'] ) ? $context['prepare_workspace'] : [];
                    $manifest = isset( $prep['package_manifest'] ) && is_array( $prep['package_manifest'] ) ? $prep['package_manifest'] : [];
                    $result = ( new RankMathConfigGuard() )->apply_from_manifest( $manifest );
                    return ! empty( $result['ok'] ) ? TaskResponse::ok( 'Portable plugin config checked.', $result ) : TaskResponse::ok( 'Portable plugin config needs attention.', $result );
                },
            ],
            [
                'id'       => 'stage_files',
                'label'    => 'Inspect Files',
                'callback' => function ( array $context ) {
                    $prep = $context['prepare_workspace'] ?? [];
                    $workspace = $prep['workspace'] ?? [];
                    $files_zip = $this->restore_files_archive_path( $workspace );
                    $content_guard = ( new PackageContentGuard() )->check( $files_zip, $prep );
                    if ( empty( $content_guard['ok'] ) ) {
                        return TaskResponse::fail( (string) ( $content_guard['message'] ?? 'Backup file completeness check failed.' ), $content_guard );
                    }
                    $stage = ( new FileRestoreStager() )->stage( $files_zip, $workspace );
                    $stage['content_guard'] = $content_guard;
                    return ! empty( $stage['ok'] ) ? TaskResponse::ok( 'Files inspected and ready to copy.', $stage ) : TaskResponse::fail( 'Files inspection failed.', $stage );
                },
            ],
            [
                'id'       => 'copy_staged_files',
                'label'    => 'Copy Staged Files',
                'callback' => function ( array $context ) {
                    $stage = $context['stage_files'] ?? [];
                    $job_key = isset( $context['job_key'] ) ? (string) $context['job_key'] : '';
                    $task_index = isset( $context['_current_task_index'] ) ? (int) $context['_current_task_index'] : 0;
                    $store = $this->jobs;
                    $progress = function ( string $message, float $within, array $data = [] ) use ( $store, $job_key, $task_index ) {
                        if ( '' === $job_key ) { return; }
                        $data['_task_progress'] = $within;
                        $store->update_task( $job_key, $task_index, 'copy_staged_files', 'running', $message, $data );
                    };
                    // PERF: this runs once per restored file. A full job read here
                    // (SELECT * + json_decode of the result blob) throttled restore to a
                    // crawl. Use a scalar status query, at most once every 2s.
                    $cancel_checked_at = 0.0;
                    $cancelled = false;
                    $should_cancel = function () use ( $store, $job_key, &$cancel_checked_at, &$cancelled ): bool {
                        if ( '' === $job_key || $cancelled ) { return $cancelled; }
                        $now = microtime( true );
                        if ( $now - $cancel_checked_at < 2.0 ) { return false; }
                        $cancel_checked_at = $now;
                        $cancelled = 'cancelled' === $store->status( $job_key );
                        return $cancelled;
                    };
                    $copy = ( new FileRestoreStager() )->apply_to_site( $stage, $progress, $should_cancel );
                    if ( ! empty( $copy['cancelled'] ) ) {
                        return TaskResponse::fail( 'Restore cancelled while copying files.', $copy );
                    }
                    return ! empty( $copy['ok'] ) ? TaskResponse::ok( 'Files restored.', $copy ) : TaskResponse::fail( (string) ( $copy['message'] ?? 'Some files failed to restore.' ), $copy );
                },
            ],
            [
                'id'       => 'temp_database_import',
                'label'    => 'Temporary DB Import',
                'callback' => function ( array $context ) {
                    $prep = $context['prepare_workspace'] ?? [];
                    $workspace = $prep['workspace'] ?? [];
                    $sql_path = trailingslashit( (string) ( $workspace['extracted'] ?? '' ) ) . 'database.sql';
                    $plan = $prep['sql_import_plan'] ?? [];
                    $token = strtolower( wp_generate_password( 5, false, false ) );
                    $import = ( new SQLTemporaryImporter() )->import( $sql_path, $plan, $token );
                    return ! empty( $import['ok'] ) ? TaskResponse::ok( 'Database imported to temporary tables.', $import ) : TaskResponse::fail( 'Temporary database import failed.', $import );
                },
            ],
            [
                'id'       => 'swap_database_tables',
                'label'    => 'Swap DB Tables',
                'callback' => function ( array $context ) {
                    $import = $context['temp_database_import'] ?? [];
                    $map = isset( $import['map'] ) && is_array( $import['map'] ) ? $import['map'] : [];
                    $swap = ( new SQLTemporaryImporter() )->swap_to_live( $map );

                    if ( ! empty( $swap['ok'] ) ) {
                        // The live users/usermeta/options tables may now be from the backup. Reapply the
                        // destination login and RestoreBase state immediately inside the same request so the
                        // browser session and controller plugin recover before the next task/poll.
                        $access_state = isset( $context['capture_destination_access'] ) && is_array( $context['capture_destination_access'] ) ? $context['capture_destination_access'] : [];
                        $self_state = isset( $context['capture_restorebase_state'] ) && is_array( $context['capture_restorebase_state'] ) ? $context['capture_restorebase_state'] : [];
                        $swap['immediate_destination_access'] = ( new DestinationAccessGuard() )->reapply( $access_state );
                        $swap['immediate_self_state'] = ( new SelfProtection() )->reapply( $self_state );
                    }

                    return ! empty( $swap['ok'] ) ? TaskResponse::ok( 'Temporary tables swapped into live names and destination access was refreshed.', $swap ) : TaskResponse::fail( (string) ( $swap['message'] ?? 'Database table swap failed.' ), $swap );
                },
            ],
            [
                'id'       => 'apply_url_options',
                'label'    => 'Apply URL Options',
                'callback' => function ( array $context ) {
                    global $wpdb;
                    $prep = isset( $context['prepare_workspace'] ) && is_array( $context['prepare_workspace'] ) ? $context['prepare_workspace'] : [];
                    $plan = isset( $prep['serialized_rewrite_plan'] ) && is_array( $prep['serialized_rewrite_plan'] ) ? $prep['serialized_rewrite_plan'] : [];
                    $rewrite = ( new SerializedRewritePlanner() )->apply_destination_url_lock( (string) $wpdb->prefix, $plan );
                    return ! empty( $rewrite['ok'] ) ? TaskResponse::ok( 'Destination URL kept and backup URLs rewritten.', $rewrite ) : TaskResponse::fail( 'Destination URL lock failed.', $rewrite );
                },
            ],
            [
                'id'       => 'reapply_destination_access',
                'label'    => 'Keep Destination Login',
                'callback' => function ( array $context ) {
                    $state = isset( $context['capture_destination_access'] ) && is_array( $context['capture_destination_access'] ) ? $context['capture_destination_access'] : [];
                    $result = ( new DestinationAccessGuard() )->reapply( $state );
                    return ! empty( $result['ok'] ) ? TaskResponse::ok( 'Destination admin login preserved after restore.', $result ) : TaskResponse::fail( 'Destination admin login could not be preserved.', $result );
                },
            ],
            [
                'id'       => 'reapply_restorebase_state',
                'label'    => 'Reapply RestoreBase State',
                'callback' => function ( array $context ) {
                    $state = isset( $context['capture_restorebase_state'] ) && is_array( $context['capture_restorebase_state'] ) ? $context['capture_restorebase_state'] : [];
                    $result = ( new SelfProtection() )->reapply( $state );
                    return ! empty( $result['ok'] ) ? TaskResponse::ok( 'RestoreBase memory preserved after restore.', $result ) : TaskResponse::fail( 'RestoreBase memory could not be preserved.', $result );
                },
            ],
            [
                'id'       => 'restore_mv_settings',
                'label'    => 'Restore MV Settings',
                'callback' => function ( array $context ) {
                    $prep = isset( $context['prepare_workspace'] ) && is_array( $context['prepare_workspace'] ) ? $context['prepare_workspace'] : [];
                    $manifest = isset( $prep['package_manifest'] ) && is_array( $prep['package_manifest'] ) ? $prep['package_manifest'] : [];
                    $portability = new MVSettingsPortability();
                    $result = $portability->apply_from_manifest( $manifest, $portability->destination_user_id_from_context( $context ) );
                    // MV settings portability is best-effort and runs after the database and
                    // files are already restored, so it must never fail the restore. Surface
                    // the outcome and continue regardless.
                    return TaskResponse::ok( (string) ( $result['message'] ?? 'MV settings step completed.' ), $result );
                },
            ],
            [
                'id'       => 'restore_plugin_state',
                'label'    => 'Restore Plugin State',
                'callback' => function ( array $context ) {
                    $state = ( new PluginStateRestorer() )->apply_from_context( $context );
                    return ! empty( $state['ok'] ) ? TaskResponse::ok( 'Plugin activation state restored from backup.', $state ) : TaskResponse::fail( 'Plugin activation state could not be restored.', $state );
                },
            ],
            [
                'id'       => 'finalize_restored_site',
                'label'    => 'Finalize Restored Site',
                'callback' => function ( array $context ) {
                    $hardening = ( new PostRestoreHardener() )->apply( $context );
                    return ! empty( $hardening['ok'] ) ? TaskResponse::ok( 'Post-restore cleanup completed.', $hardening ) : TaskResponse::fail( 'Post-restore cleanup needs attention.', $hardening );
                },
            ],
            [
                'id'       => 'post_restore_verification',
                'label'    => 'Verify Restored Site',
                'callback' => function () {
                    $verification = ( new PostRestoreVerifier() )->verify();
                    if ( empty( $verification['ok'] ) ) {
                        return TaskResponse::fail( 'Restore verification found blockers.', $verification );
                    }
                    // Warnings (e.g. permalink structure) are reported, not failed —
                    // the restore itself succeeded.
                    return TaskResponse::ok(
                        ! empty( $verification['has_warnings'] ) ? 'Restore verification passed with notes.' : 'Restore verification passed.',
                        $verification
                    );
                },
            ],
            [
                'id'       => 'finish_execution',
                'label'    => 'Finish Execution',
                'callback' => function ( array $context ) {
                    if ( function_exists( 'flush_rewrite_rules' ) ) {
                        flush_rewrite_rules();
                    }
                    Logger::warning( 'production_restore_executed', 'RestoreBase guarded production restore execution completed.', [ 'context_keys' => array_keys( $context ) ] );
                    return TaskResponse::ok( 'Guarded production restore completed. Verify the site immediately.', [
                        'executed'        => true,
                        'mode'            => 'production',
                        'verify_now'      => [ 'frontend', 'wp-admin', 'media', 'plugins', 'theme', 'permalinks' ],
                        'rollback_source' => $context['pre_restore_package'] ?? [],
                        'database_swap'   => $context['swap_database_tables'] ?? [],
                        'file_copy'       => $context['copy_staged_files'] ?? [],
                        'portable_config' => $context['apply_portable_config'] ?? [],
                        'destination_login' => $context['reapply_destination_access'] ?? [],
                        'plugin_state'    => $context['restore_plugin_state'] ?? [],
                        'self_state'      => $context['reapply_restorebase_state'] ?? [],
                        'mv_settings'     => $context['restore_mv_settings'] ?? [],
                        'post_restore_hardening' => $context['finalize_restored_site'] ?? [],
                        'post_restore_verification' => $context['post_restore_verification'] ?? [],
                        'refresh_required' => true,
                    ] );
                },
            ],
        ];
    }

    private function restore_files_archive_path( array $workspace ): string {
        $base = trailingslashit( (string) ( $workspace['extracted'] ?? '' ) );
        $bundle = $base . 'files.restorebase';
        if ( is_readable( $bundle ) ) {
            return $bundle;
        }
        return $base . 'files.zip';
    }
}
