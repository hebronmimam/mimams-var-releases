<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Storage\LocalStorage;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared

defined( 'ABSPATH' ) || exit;

final class SerializedRewritePlanner {
    public function plan( string $sql_path, array $manifest = [] ): array {
        $base = ( new URLRewritePlanner() )->plan( $sql_path, $manifest );
        $backup_url = isset( $base['backup_url'] ) ? (string) $base['backup_url'] : '';
        $backup_home = isset( $base['backup_home'] ) ? (string) $base['backup_home'] : $backup_url;
        $current_url = site_url();
        $current_home = home_url();
        $backup_uploads = isset( $manifest['site_scan']['uploads']['baseurl'] ) ? (string) $manifest['site_scan']['uploads']['baseurl'] : '';
        $uploads = wp_upload_dir( null, false );
        $current_uploads = isset( $uploads['baseurl'] ) ? (string) $uploads['baseurl'] : '';

        return [
            'ok'                => true,
            'message'           => 'Destination URL lock prepared. RestoreBase keeps the current site URL and rewrites supported backup URLs to the destination URL during restore.',
            'site_url'          => [ 'from' => $backup_url, 'to' => $current_url, 'needs_rewrite' => $backup_url && $backup_url !== $current_url ],
            'home_url'          => [ 'from' => $backup_home, 'to' => $current_home, 'needs_rewrite' => $backup_home && $backup_home !== $current_home ],
            'uploads_url'       => [ 'from' => $backup_uploads, 'to' => $current_uploads, 'needs_rewrite' => $backup_uploads && $backup_uploads !== $current_uploads ],
            'sql_mentions'      => $base['sql_mentions'] ?? [],
            'strategy'          => 'destination_url_lock_with_serialized_safe_rewrite',
            'automatic_apply'   => true,
            'preserve_current_site_url' => true,
            'allowed_tables'    => [ 'options', 'posts', 'postmeta', 'termmeta', 'usermeta' ],
            'blocked_tables'    => [ 'woocommerce_order', 'wc_orders', 'actionscheduler' ],
            'woocommerce_note'  => 'WooCommerce transactional tables require a dedicated merge strategy before production restore.',
        ];
    }

    public function apply_site_options( string $table_prefix ): array {
        global $wpdb;
        $options_table = $table_prefix . 'options';
        $updated = [];
        foreach ( [ 'siteurl' => site_url(), 'home' => home_url() ] as $option => $value ) {
            $result = $wpdb->update( $options_table, [ 'option_value' => $value ], [ 'option_name' => $option ], [ '%s' ], [ '%s' ] );
            $updated[ $option ] = false !== $result;
        }
        return [ 'ok' => ! in_array( false, $updated, true ), 'table' => $options_table, 'updated' => $updated, 'kept' => [ 'siteurl' => site_url(), 'home' => home_url() ] ];
    }

    public function apply_destination_url_lock( string $table_prefix, array $rewrite_plan = [] ): array {
        $options = $this->apply_site_options( $table_prefix );
        $replacements = $this->replacements_from_plan( $rewrite_plan );
        $content = empty( $replacements ) ? [ 'ok' => true, 'message' => 'No URL content rewrite was needed.', 'tables' => [], 'rows_checked' => 0, 'rows_updated' => 0 ] : $this->apply_content_replacements( $table_prefix, $replacements );

        return [
            'ok'              => ! empty( $options['ok'] ) && ! empty( $content['ok'] ),
            'message'         => 'Destination URL lock applied. Current siteurl/home were kept and supported content URLs were rewritten.',
            'site_options'    => $options,
            'content_rewrite' => $content,
            'replacements'    => array_map(
                static function ( array $pair ): array {
                    return [ 'from' => $pair['from'], 'to' => $pair['to'] ];
                },
                $replacements
            ),
        ];
    }

    private function replacements_from_plan( array $plan ): array {
        $pairs = [];
        foreach ( [ 'site_url', 'home_url', 'uploads_url' ] as $key ) {
            $from = isset( $plan[ $key ]['from'] ) ? (string) $plan[ $key ]['from'] : '';
            $to = isset( $plan[ $key ]['to'] ) ? (string) $plan[ $key ]['to'] : '';
            if ( '' !== $from && '' !== $to && $from !== $to ) {
                $pairs[ $from . '=>' . $to ] = [ 'from' => $from, 'to' => $to ];
                $pairs[ untrailingslashit( $from ) . '=>' . untrailingslashit( $to ) ] = [ 'from' => untrailingslashit( $from ), 'to' => untrailingslashit( $to ) ];
                $pairs[ trailingslashit( $from ) . '=>' . trailingslashit( $to ) ] = [ 'from' => trailingslashit( $from ), 'to' => trailingslashit( $to ) ];
            }
        }
        return array_values( array_filter( $pairs, static fn( $pair ) => $pair['from'] !== $pair['to'] && '' !== $pair['from'] ) );
    }

    private function apply_content_replacements( string $prefix, array $pairs ): array {
        $tables = [
            'options'  => [ 'table' => $prefix . 'options', 'id' => 'option_id', 'columns' => [ 'option_value' ] ],
            'posts'    => [ 'table' => $prefix . 'posts', 'id' => 'ID', 'columns' => [ 'post_content', 'post_excerpt', 'guid' ] ],
            'postmeta' => [ 'table' => $prefix . 'postmeta', 'id' => 'meta_id', 'columns' => [ 'meta_value' ] ],
            'termmeta' => [ 'table' => $prefix . 'termmeta', 'id' => 'meta_id', 'columns' => [ 'meta_value' ] ],
            'usermeta' => [ 'table' => $prefix . 'usermeta', 'id' => 'umeta_id', 'columns' => [ 'meta_value' ] ],
        ];

        $summary = [];
        $rows_checked = 0;
        $rows_updated = 0;
        $errors = [];
        $warnings = [];

        foreach ( $tables as $key => $def ) {
            $result = $this->rewrite_table( $def['table'], $def['id'], $def['columns'], $pairs );
            $summary[ $key ] = $result;
            $rows_checked += (int) ( $result['checked'] ?? 0 );
            $rows_updated += (int) ( $result['updated'] ?? 0 );
            if ( ! empty( $result['errors'] ) ) {
                $errors = array_merge( $errors, (array) $result['errors'] );
            }
            if ( ! empty( $result['warnings'] ) ) {
                $warnings = array_merge( $warnings, (array) $result['warnings'] );
            }
        }

        /* R37. A row left alone is not a failure, but it is not silence either -
           somebody has to know which setting still points at the old site. */
        $message = 'Supported content URLs rewritten to destination URL.';
        if ( ! empty( $errors ) ) {
            $message = 'Some content URL rewrites had errors.';
        } elseif ( ! empty( $warnings ) ) {
            $message = sprintf(
                'URLs rewritten. %d row(s) were left unchanged because they hold serialized objects from plugins this site does not have. First: %s',
                count( $warnings ),
                (string) $warnings[0]
            );
        }

        return [
            'ok'           => empty( $errors ),
            'message'      => $message,
            'tables'       => $summary,
            'rows_checked' => $rows_checked,
            'rows_updated' => $rows_updated,
            'errors'       => array_slice( $errors, 0, 20 ),
            'warnings'     => array_slice( array_values( array_unique( $warnings ) ), 0, 20 ),
        ];
    }

    private function rewrite_table( string $table, string $id_column, array $columns, array $pairs ): array {
        global $wpdb;

        if ( ! $this->table_exists( $table ) ) {
            return [ 'checked' => 0, 'updated' => 0, 'skipped' => true, 'errors' => [] ];
        }

        $select_columns = array_merge( [ $id_column ], $columns );
        $rows = $wpdb->get_results( 'SELECT `' . implode( '`, `', array_map( [ $this, 'escape_identifier' ], $select_columns ) ) . '` FROM `' . $this->escape_identifier( $table ) . '` LIMIT 50000', ARRAY_A );
        if ( ! is_array( $rows ) ) {
            return [ 'checked' => 0, 'updated' => 0, 'errors' => [ (string) $wpdb->last_error ] ];
        }

        $checked = 0;
        $updated = 0;
        $errors = [];
        $warnings = [];

        foreach ( $rows as $row ) {
            $checked++;
            $id = isset( $row[ $id_column ] ) ? (int) $row[ $id_column ] : 0;
            if ( $id <= 0 ) {
                continue;
            }

            $data = [];
            $formats = [];
            foreach ( $columns as $column ) {
                $old = isset( $row[ $column ] ) ? (string) $row[ $column ] : '';
                if ( '' === $old || ! $this->contains_any( $old, $pairs ) ) {
                    continue;
                }
                $blocked = [];
                try {
                    $new = $this->replace_value( $old, $pairs, $blocked );
                } catch ( \Throwable $e ) {
                    /* Belt and braces. A value this planner cannot read is a row
                       left alone, never a restore that stops. */
                    $warnings[] = sprintf( '%s.%s #%d left unchanged: %s', $table, $column, $id, $e->getMessage() );
                    continue;
                }
                foreach ( array_unique( $blocked ) as $reason ) {
                    $warnings[] = 'unreadable serialized value' === $reason
                        ? sprintf( '%s.%s #%d left unchanged: it is serialized data this site cannot read, so rewriting it would damage it further.', $table, $column, $id )
                        : sprintf( '%s.%s #%d left unchanged: it holds a serialized %s object, which cannot be rewritten without that class.', $table, $column, $id, $reason );
                }
                if ( $new !== $old ) {
                    $data[ $column ] = $new;
                    $formats[] = '%s';
                }
            }

            if ( empty( $data ) ) {
                continue;
            }

            $result = $wpdb->update( $table, $data, [ $id_column => $id ], $formats, [ '%d' ] );
            if ( false === $result ) {
                $errors[] = (string) $wpdb->last_error;
            } else {
                $updated++;
            }
        }

        return [
            'checked'  => $checked,
            'updated'  => $updated,
            'errors'   => $errors,
            'warnings' => array_slice( array_values( array_unique( $warnings ) ), 0, 20 ),
        ];
    }

    /*
     * R37. The restore reached step 13 of 21 and died here:
     *
     *   "The script tried to modify a property on an incomplete object. Please
     *    ensure that the class definition WonderPush\Obj\Application of the
     *    object you are trying to operate on was loaded _before_ unserialize()
     *    gets called or provide an autoloader to load the class definition"
     *
     * unserialize() on a serialized object whose class is not loaded hands back a
     * __PHP_Incomplete_Class, and writing a property on one of those is a fatal,
     * not a warning. The package came from a site running WonderPush; the
     * destination has not got it, so the class does not exist there and never
     * will. Any package from any site can carry a serialized object from a plugin
     * the destination does not have - this was never about one plugin.
     *
     * So the walk does not modify objects at all. It cannot rewrite one safely:
     * putting a string back into an object means instantiating the class, and the
     * class is the thing that is missing. A row it cannot rewrite is LEFT EXACTLY
     * AS IT WAS and reported. That is the safe direction - a URL that did not get
     * rewritten is one setting to fix by hand, while a corrupted serialized
     * option is a site that does not boot.
     */
    private function replace_value( string $value, array $pairs, array &$blocked = [] ): string {
        if ( is_serialized( $value ) ) {
            $unserialized = @unserialize( $value ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
            if ( false !== $unserialized || 'b:0;' === $value ) {
                $holding = [];
                $rewritten = $this->replace_deep( $unserialized, $pairs, $holding );
                if ( ! empty( $holding ) ) {
                    $blocked = array_merge( $blocked, $holding );
                    return $value;
                }
                return serialize( $rewritten );
            }

            /*
             * R37, found while writing the guard for the one above. This used to
             * fall through to the plain string replace below - on a SERIALIZED
             * value. A raw str_replace changes the text of a string without
             * changing the s:<length>: in front of it, so
             *
             *     s:19:"https://hoiheidi.ch"   ->   s:19:"http://test9.test"
             *
             * and the row stops being readable at all. It is only reachable when
             * unserialize() refuses the value, which means the row was already
             * damaged - and turning slightly-damaged into unreadable during a
             * restore is the worst thing this planner could do.
             */
            $blocked[] = 'unreadable serialized value';
            return $value;
        }

        return $this->replace_string( $value, $pairs );
    }

    private function replace_deep( $value, array $pairs, array &$blocked ) {
        if ( is_string( $value ) ) {
            return $this->replace_string( $value, $pairs );
        }
        if ( is_array( $value ) ) {
            foreach ( $value as $key => $item ) {
                $value[ $key ] = $this->replace_deep( $item, $pairs, $blocked );
            }
            return $value;
        }
        if ( is_object( $value ) ) {
            $blocked[] = $this->class_of( $value );
            return $value;
        }
        return $value;
    }

    /* Named for the report. An incomplete object still knows what it was. */
    private function class_of( $value ): string {
        $vars = get_object_vars( $value );
        if ( isset( $vars['__PHP_Incomplete_Class_Name'] ) ) {
            return (string) $vars['__PHP_Incomplete_Class_Name'];
        }
        return get_class( $value );
    }

    private function replace_string( string $value, array $pairs ): string {
        foreach ( $pairs as $pair ) {
            $value = str_replace( (string) $pair['from'], (string) $pair['to'], $value );
        }
        return $value;
    }

    private function contains_any( string $value, array $pairs ): bool {
        foreach ( $pairs as $pair ) {
            if ( '' !== (string) $pair['from'] && false !== strpos( $value, (string) $pair['from'] ) ) {
                return true;
            }
        }
        return false;
    }

    private function table_exists( string $table ): bool {
        global $wpdb;
        return (string) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
    }

    private function escape_identifier( string $identifier ): string {
        return str_replace( '`', '``', $identifier );
    }
}
