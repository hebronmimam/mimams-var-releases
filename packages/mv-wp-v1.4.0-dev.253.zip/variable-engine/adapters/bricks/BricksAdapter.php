<?php
namespace VE\Adapters;
defined('ABSPATH') || exit;

class BricksAdapter {
    public function __construct() {
        add_action('wp', [$this, 'init']);
        // Merge owner-defined custom tags into Bricks' HTML sanitiser allow-list.
        // Registered unconditionally (not gated by ?bricks=run) because Bricks
        // applies this filter on both the front end and inside the builder.
        add_filter('bricks/allowed_html_tags', [$this, 'allowed_html_tags']);
    }

    /**
     * @param mixed $allowed_tags Bricks passes an array of tag-name strings.
     * @return array
     */
    public function allowed_html_tags($allowed_tags): array {
        $allowed_tags = is_array($allowed_tags) ? $allowed_tags : (array) $allowed_tags;
        $custom = get_option('ve_bricks_custom_tags', []);
        if (!is_array($custom)) {
            $custom = [];
        }
        foreach ($custom as $tag) {
            $tag = strtolower(trim((string) $tag));
            $tag = preg_replace('/[^a-z0-9-]/', '', $tag);
            if ('' !== $tag && !in_array($tag, $allowed_tags, true)) {
                $allowed_tags[] = $tag;
            }
        }
        return $allowed_tags;
    }

    public function init(): void {
        if (!isset($_GET['bricks']) || $_GET['bricks'] !== 'run') return;
        ( new \VE\Adapters\Bricks\VariablesMirror() )->sync();
        add_action('wp_enqueue_scripts', [$this, 'enqueue'], 9999);
        add_filter('body_class', [$this, 'body_class']);
        add_action('wp_head', [$this, 'early_panels'], 1);
    }

    /* dev.248, the owner: "On load, I still see that of bricks." MV's Elements
       and Structure replace Bricks' panels, but MV's script runs after Bricks has
       drawn its own. So the head carries, for each panel switched on in Bricks
       Enhancements, a style that hides Bricks' panel and gives its column MV's
       saved width from the first paint. MV removes each one as its panel takes
       over (veBxEarlyOff); a timer removes them if MV never starts. */
    public function early_panels(): void {
        if (function_exists('bricks_is_builder_main') && !bricks_is_builder_main()) return;
        if (!is_user_logged_in()) return;
        $prefs = get_user_meta(get_current_user_id(), 've_user_preferences', true);
        $prefs = is_array($prefs) ? $prefs : [];
        $on = isset($prefs['ve_bx_enhance']) && is_array($prefs['ve_bx_enhance']) ? $prefs['ve_bx_enhance'] : [];
        $layout = isset($prefs['ve_bx_layout']) && is_array($prefs['ve_bx_layout']) ? $prefs['ve_bx_layout'] : [];
        $off = isset($prefs['ve_deactivated_tools']) ? $prefs['ve_deactivated_tools'] : [];
        if (is_string($off)) $off = array_filter(array_map('trim', explode(',', $off)));
        $off = is_array($off) ? array_map('strval', $off) : [];
        /* dev.249: the column is painted in the owner's panel colour. */
        $pal = isset($prefs['ve_bx_palette']) && is_array($prefs['ve_bx_palette']) ? $prefs['ve_bx_palette'] : [];
        $bg = isset($pal['base']) && is_string($pal['base']) && preg_match('/^#[0-9a-fA-F]{6}$/', $pal['base']) ? strtolower($pal['base']) : '#1f1f1f';
        $panels = ['elements' => ['el', 'panel', 'bricks-panel'], 'structure' => ['st', 'structure', 'bricks-structure']];
        $out = '';
        foreach ($panels as $id => $p) {
            if (array_key_exists($id, $on) && !$on[$id]) continue;
            if (in_array($id, $off, true)) continue;
            $l = isset($layout[$id]) && is_array($layout[$id]) ? $layout[$id] : [];
            $mode = isset($l['mode']) && in_array($l['mode'], ['dock', 'float', 'collapsed'], true) ? $l['mode'] : 'dock';
            $w = isset($l['w']) ? (int) $l['w'] : 300;
            $w = $w > 0 ? max(240, min(640, $w)) : 300;
            if ($mode !== 'dock') $w = 0;
            $out .= '<style id="ve-bx-early-' . $p[0] . '">#' . $p[2] . ',#' . $p[2] . '-toggle{display:none!important}'
                . '.bricks-side-dock-panel.is-' . $p[1] . '{width:' . $w . 'px!important;min-width:0!important;max-width:none!important;flex:0 0 ' . $w . 'px!important;padding:0!important;border:0!important;background:' . $bg . '!important}</style>' . "\n";
        }
        if ($out === '') return;
        echo $out;
        echo '<script>setTimeout(function(){if(window.veBxBooted)return;["ve-bx-early-el","ve-bx-early-st"].forEach(function(i){var s=document.getElementById(i);if(s)s.remove();});},15000);</script>' . "\n";
    }

    /* R64, the owner: "when code2bricks is installed and active, I actually do
       not work with any of those in the marked area, how do we go about removing
       those by default when c2b is installed with an option to turn it back on?"
       The marked area is the toolbar's breakpoint switcher: with Code2Bricks,
       responsive work is written as media queries there, not clicked through
       Bricks' breakpoints. On by default while Code2Bricks is active; Settings >
       "Bricks breakpoint buttons" turns it back off, live. */
    public static function hides_breakpoints(): bool {
        if (!defined('CODE2BRICKS_VERSION')) return false;
        $settings = get_option('ve_settings', []);
        return !is_array($settings) || !array_key_exists('c2b_hide_breakpoints', $settings) || !empty($settings['c2b_hide_breakpoints']);
    }

    public function body_class($classes): array {
        $classes = is_array($classes) ? $classes : [];
        if (self::hides_breakpoints()) $classes[] = 'mv-c2b-bp-hidden';
        return $classes;
    }

    /* Everything in Bricks' breakpoint group except reloading the canvas and the
       width, height, scale and zoom controls - the owner's box also held the two
       menus beside the icons. If the builder is ever on a smaller breakpoint (a
       shortcut, an old session), the current one and Desktop come back, so there
       is always a way home. */
    public static function breakpoint_css(): string {
        $bp = 'body.mv-c2b-bp-hidden #bricks-toolbar-top ul.breakpoints';
        return $bp . '>li:not(.reload-canvas):not(.preview-dimension):not(.zoom-out):not(.zoom-in){display:none!important}'
            // Both through :has(): the hide rule's four :not()s outweigh a plain .active.
            . $bp . ':has(>li.breakpoint.active:not(.base))>li.breakpoint.base,'
            . $bp . ':has(>li.breakpoint.active:not(.base))>li.breakpoint.active{display:flex!important}';
    }

    public function enqueue(): void {
        // All runtime vendor assets are bundled with the plugin, not loaded from a CDN, so
        // the builder works offline, under strict CSP, and on privacy-strict hosts. GSAP was
        // enqueued but never referenced by the panel; it has been removed.
        $ver = VE_VERSION;
        // Plus Jakarta Sans and JetBrains Mono, bundled beside every other asset
        // rather than fetched from Google: MV has to render the same offline, under a
        // strict CSP, and on hosts where an external font request is a privacy issue.
        wp_enqueue_style('ve-fonts', VE_URL.'assets/fonts.css', [], $ver.'.'.filemtime(VE_DIR.'assets/fonts.css'));
        wp_enqueue_style('ve-ph', VE_URL.'assets/phosphor/style.css', [], $ver.'.'.filemtime(VE_DIR.'assets/phosphor/style.css'));
        wp_enqueue_style('ve-components', VE_URL.'assets/components.css', [], $ver.'.'.filemtime(VE_DIR.'assets/components.css'));
        if (defined('CODE2BRICKS_VERSION')) wp_add_inline_style('ve-components', self::breakpoint_css());
        // CodeMirror's editor CSS is pre-scoped to `.ve-cm-host` (codemirror.scoped.css), so it
        // styles only MV's own editors and never bleeds into — or gets neutralized against —
        // other plugins' code editors (Advanced Themer Style Manager, Code2Bricks Quick Import).
        wp_enqueue_style('ve-codemirror', VE_URL.'assets/vendor/codemirror/codemirror.scoped.css', [], '5.65.16');
        // show-hint.css ships unscoped upstream: `.CodeMirror-hints` is a global
        // class, so loading it restyles every CodeMirror suggestion popup on the
        // page - Bricks', Advanced Themer's, Code2Bricks', WPCodeBox's - to white
        // on silver with a blue selection, and whichever copy loads last wins.
        // MV ships a copy scoped to `.ve-cm-hints-root`, the container it passes
        // to show-hint for its own editors, and nothing else.
        wp_enqueue_style('ve-codemirror-hint', VE_URL.'assets/vendor/codemirror/show-hint.scoped.css', ['ve-codemirror'], '5.65.16');
        // The syntax themes: one generated stylesheet, every selector inside
        // `.mv-code-editor` or `.mv-code-hints`. Generated by
        // scripts/import-syntax-themes.py from upstream theme data; see
        // THIRD-PARTY-THEMES.md. No network request is made at runtime.
        wp_enqueue_style('ve-syntax-themes', VE_URL.'assets/css/syntax-themes.css', ['ve-codemirror'], $ver.'.'.filemtime(VE_DIR.'assets/css/syntax-themes.css'));
        wp_enqueue_script('ve-shortcuts', VE_URL.'assets/js/shortcut-registry.js', [], $ver.'.'.filemtime(VE_DIR.'assets/js/shortcut-registry.js'), true);
        wp_enqueue_script('ve-p', VE_URL.'assets/vendor/preact.umd.js', [], '10', true);
        wp_enqueue_script('ve-ph', VE_URL.'assets/vendor/preact-hooks.umd.js', ['ve-p'], '10', true);
        wp_enqueue_script('ve-codemirror', VE_URL.'assets/vendor/codemirror/codemirror.js', [], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-css', VE_URL.'assets/vendor/codemirror/mode-css.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-xml', VE_URL.'assets/vendor/codemirror/mode-xml.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-javascript', VE_URL.'assets/vendor/codemirror/mode-javascript.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-htmlmixed', VE_URL.'assets/vendor/codemirror/mode-htmlmixed.js', ['ve-codemirror-xml','ve-codemirror-javascript','ve-codemirror-css'], '5.65.16', true);
        // PHP. Code Studio has always offered PHP items and asked CodeMirror for
        // application/x-httpd-php, but no PHP mode was ever loaded - so those
        // items fell back to plain text and had no highlighting at all. The PHP
        // mode needs clike, and htmlmixed, which is already above it.
        wp_enqueue_script('ve-codemirror-clike', VE_URL.'assets/vendor/codemirror/mode-clike.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-php', VE_URL.'assets/vendor/codemirror/mode-php.js', ['ve-codemirror-htmlmixed','ve-codemirror-clike'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-closebrackets', VE_URL.'assets/vendor/codemirror/closebrackets.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-hint', VE_URL.'assets/vendor/codemirror/show-hint.js', ['ve-codemirror'], '5.65.16', true);
        // The theme registry: the one place that knows which themes exist and
        // what each one's colours are. Loaded before the panel so a theme can be
        // resolved before the first editor is constructed, which is what keeps
        // an editor from opening on one theme and jumping to another.
        wp_enqueue_script('ve-syntax-themes', VE_URL.'assets/js/syntax-themes.js', [], $ver.'.'.filemtime(VE_DIR.'assets/js/syntax-themes.js'), true);
        $app_dependencies = array_merge(
            ['ve-p','ve-ph','ve-codemirror-htmlmixed','ve-codemirror-php','ve-codemirror-closebrackets','ve-codemirror-hint','ve-syntax-themes'],
            \VE\Core\RankMathAnalysisBridge::enqueue()
        );
        $app_dependencies[] = 've-shortcuts';
        wp_enqueue_script('ve-app', VE_URL.'assets/js/builder-panel.js', $app_dependencies, $ver.'.'.filemtime(VE_DIR.'assets/js/builder-panel.js'), true);
        $preferences = get_user_meta( get_current_user_id(), 've_user_preferences', true );
        /* R55 - "ctrl + / isn't commenting" in Code2Bricks. window.CodeMirror is
           shared, and MV's build replaced another plugin's (without its comment
           add-on) whenever MV loaded after it. MV now keeps its own build to
           itself and puts the one it found back, unless a later plugin has
           taken the global since. */
        wp_add_inline_script('ve-codemirror', 'window.__veCmBefore=window.CodeMirror;', 'before');
        wp_add_inline_script('ve-codemirror', 'window.__veCmOwn=window.CodeMirror;', 'after');
        wp_add_inline_script('ve-app', '(function(){var o=window.__veCmOwn,b=window.__veCmBefore;if(b&&o&&b!==o&&window.CodeMirror===o){window.CodeMirror=b;}})();', 'before');
        wp_localize_script('ve-app', 'vePanel', ['apiRoot'=>esc_url_raw(rest_url()),'ajaxUrl'=>esc_url_raw(admin_url('admin-ajax.php')),'nonce'=>wp_create_nonce('wp_rest'),'version'=>VE_VERSION,'mode'=>'builder','code2bricks'=>defined('CODE2BRICKS_VERSION'),'cssOutputUrl'=>esc_url_raw(VE_CSS_OUTPUT_URL),'siteTitle'=>sanitize_text_field(get_bloginfo('name')),'logoUrl'=>esc_url_raw(VE_URL.'assets/hebronmimam-logo-icon.png'),'assetUrl'=>esc_url_raw(VE_URL.'assets/'),'fontToolsScript'=>esc_url_raw(VE_URL.'assets/vendor/fonteditor-core/fonteditor-core.iife.js'),'fontToolsWasm'=>esc_url_raw(VE_URL.'assets/vendor/fonteditor-core/woff2.wasm'),'newPostDefaults'=>['comment_status'=>get_option('default_comment_status')?:'open','ping_status'=>get_option('default_ping_status')?:'open'],'userPreferences'=>is_array($preferences)?$preferences:[],'userId'=>get_current_user_id(),'settings'=>(function(){$v=get_option('ve_settings',[]);return is_array($v)?$v:[];})(),'namespace'=>(defined('VE_API_NAMESPACE')?VE_API_NAMESPACE:'variable-engine/v1'),'workspace'=>(function(){
            /* Slice 8. The builder is told which workspace this session is in,
               and nothing else about it. That one number is all workspace-guard.js
               needs to decide whether to watch, and it is already the user's own
               session - so it tells the page nothing the page could not ask for. */
            if (!class_exists('\VE\Modules\Workspaces\WorkspaceRuntime')) { return 0; }
            return (int) \VE\Modules\Workspaces\WorkspaceRuntime::session_id();
        })()]);

        /* Slice 8, §100.1 "shortening the window". Depends on ve-app because
           that is what vePanel is localised onto, and this reads it. It stands
           itself down when there is no workspace session, which is why it can be
           enqueued for every builder load without asking first. */
        wp_enqueue_script('ve-workspace-guard', VE_URL.'assets/js/workspace-guard.js', ['ve-app'], $ver.'.'.filemtime(VE_DIR.'assets/js/workspace-guard.js'), true);

        if (class_exists('\VE\Modules\BuilderTools\MimamsBarModule')) {
            (new \VE\Modules\BuilderTools\MimamsBarModule())->enqueue('builder');
        }
    }
}
