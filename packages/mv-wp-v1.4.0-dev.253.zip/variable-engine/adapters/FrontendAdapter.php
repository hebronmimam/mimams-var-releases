<?php
namespace VE\Adapters;
defined('ABSPATH') || exit;

/**
 * The owner, 2026-09-27: "I now want the mv float to also show in frontend for
 * logged in users, with an option to disable that and a shortcut to hide and
 * show."
 *
 * MV's panel on the site's own pages - for the people who can use MV
 * (manage_options), never for visitors. Settings -> General -> "Show MV on the
 * site's pages" turns it off; Alt+Shift+M (Settings -> Shortcuts) hides and
 * shows the button while it is loaded. Everything it loads is the wp-admin
 * panel, scoped to MV's own classes, so the page itself is not restyled.
 */
class FrontendAdapter {
    public function __construct() {
        add_action('wp_enqueue_scripts', [$this, 'enqueue'], 20);
    }

    public static function wanted(): bool {
        if (is_admin() || wp_doing_ajax() || (defined('REST_REQUEST') && REST_REQUEST)) return false;
        if (!is_user_logged_in() || !current_user_can('manage_options')) return false;
        // Bricks' own windows: the builder, and the canvas it previews the page in.
        if (isset($_GET['bricks']) || isset($_GET['brickspreview'])) return false; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
        if (function_exists('bricks_is_builder') && bricks_is_builder()) return false;
        if (function_exists('bricks_is_builder_iframe') && bricks_is_builder_iframe()) return false;
        if (is_customize_preview() || is_feed() || is_embed() || is_robots() || is_trackback()) return false;
        $settings = get_option('ve_settings', []);
        return !(is_array($settings) && array_key_exists('frontend_float', $settings) && empty($settings['frontend_float']));
    }

    public function enqueue(): void {
        if (!self::wanted()) return;
        AdminAdapter::enqueue_panel('frontend');
    }
}
