<?php

$root  = dirname( __DIR__ );
$panel = file_get_contents( $root . '/assets/js/builder-panel.js' );
$bar   = file_get_contents( $root . '/modules/builder-tools/mimams-bar/assets/css/builder.css' );

$failures = [];
$expect = static function ( $condition, $message ) use ( &$failures ) {
    if ( ! $condition ) {
        $failures[] = $message;
    }
};

$expect(
    false !== strpos( $panel, '.ve-font-tabs{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);flex:0 0 40px;min-height:40px' ),
    'Font Manager tabs must retain their full two-column height while the Library grows.'
);
$expect(
    false !== strpos( $panel, 'Bricks family found · source attachments need relinking' )
    && false !== strpos( $panel, 'Bricks attachment missing · relink this variant' ),
    'A Bricks family record must be distinguished from its missing source attachments.'
);
$expect(
    // Renamed since: the gate is now "any variant with a file" (usableVariants).
    false !== strpos( $panel, 'const hasPreview=!!usableVariants.length;' )
    && false !== strpos( $panel, "h('strong',{style:hasPreview?{fontFamily:previewFamily}:undefined},family.family)" ),
    'Unavailable font files must not produce a fake actual-font preview.'
);
$expect(
    false !== strpos( $bar, 'padding-inline-start:16px!important' )
    && false !== strpos( $bar, '.baqa-mode-dropdown' )
    && false !== strpos( $bar, 'margin-inline-start:0!important' ),
    'Wrapped Direct rows and the Direct control must retain the v1.3.344 normal panel inset.'
);
$expect(
    false !== strpos( $bar, '.baqa-suggestion-name {' )
    && false !== strpos( $bar, 'display:inline!important' )
    && false !== strpos( $bar, 'gap:0!important' ),
    // The value's 8px gap became 1px on purpose: the token reads as one name="value" string.
    'Match styling must not insert visual spaces inside class or attribute names.'
);

if ( $failures ) {
    fwrite( STDERR, "v1.3.343 contract failures:\n- " . implode( "\n- ", $failures ) . "\n" );
    exit( 1 );
}

echo "v1.3.343 Font Manager and Bar regression contracts passed.\n";
