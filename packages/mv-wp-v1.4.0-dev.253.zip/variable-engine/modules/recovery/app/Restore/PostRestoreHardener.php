<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Utils\Logger;

// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_unlink
// phpcs:disable WordPress.PHP.NoSilencedErrors.Discouraged

defined( 'ABSPATH' ) || exit;

/**
 * Final post-restore cleanup that makes the restored admin feel ready immediately.
 */
final class PostRestoreHardener {
    public function apply( array $restore_context = [] ): array {
        $changes = [];
        $warnings = [];

        $prep = $restore_context['prepare_workspace'] ?? [];
        $plan = $prep['sql_import_plan'] ?? [];
        $old_prefix = $plan['backup_prefix'] ?? '';
        global $wpdb;
        $new_prefix = $plan['current_prefix'] ?? $wpdb->prefix;

        if ( $old_prefix && $new_prefix && $old_prefix !== $new_prefix ) {
            $prefix_map = $this->map_database_prefixes( $old_prefix, $new_prefix );
            $changes['prefix_mapping'] = $prefix_map;
        }

        $changes['db_upgrade'] = $this->upgrade_wordpress_database();

        $permalink = $this->force_postname_permalinks();
        $changes['permalinks'] = $permalink;

        $rest = $this->ensure_pretty_urls_reachable();
        $changes['rest_reachability'] = $rest;
        if ( empty( $rest['ok'] ) ) {
            $warnings[] = (string) ( $rest['message'] ?? 'Pretty REST URLs are not reachable on this server.' );
        }

        $maintenance = $this->remove_maintenance_marker();
        $changes['maintenance_marker'] = $maintenance;

        $cache = $this->clear_runtime_caches();
        $changes['runtime_cache'] = $cache;

        $identity = $this->refresh_current_user_runtime();
        $changes['current_user_runtime'] = $identity;
        if ( empty( $identity['ok'] ) ) {
            $warnings[] = (string) ( $identity['message'] ?? 'The destination administrator runtime needs a refresh.' );
        }

        $bricks = $this->refresh_bricks_runtime();
        $changes['bricks'] = $bricks;

        $studio = $this->refresh_studio_runtime();
        $changes['studio_runtime'] = $studio;

        $rank_math = ( new RankMathConfigGuard() )->repair_after_restore( $restore_context );
        $changes['rank_math'] = $rank_math;
        if ( empty( $rank_math['ok'] ) ) {
            $warnings[] = (string) ( $rank_math['message'] ?? 'Rank Math post-restore repair needs attention.' );
        }

        Logger::info( 'post_restore_hardening_complete', 'RestoreBase applied post-restore hardening.', [
            'permalink_changed' => ! empty( $permalink['changed'] ),
            'bricks_refresh'    => $bricks,
            'rank_math'         => [
                'ok'      => ! empty( $rank_math['ok'] ),
                'changed' => ! empty( $rank_math['changed'] ),
                'reset'   => ! empty( $rank_math['registration_reset'] ),
            ],
        ] );

        return [
            'ok'              => true,
            'message'         => empty( $warnings ) ? 'Post-restore cleanup completed. Refresh the admin once to load the restored plugins and data.' : 'Post-restore cleanup completed with notes.',
            'changes'         => $changes,
            'warnings'        => $warnings,
            'refresh_required'=> true,
        ];
    }

    /**
     * The restored database brings the source site's pretty permalinks, but the restore
     * deliberately protects the destination's .htaccess — on a site installed without
     * pretty permalinks that file has no WordPress rewrite rules, so every pretty URL
     * (including /wp-json) 404s at the web server before WordPress runs. During AJAX,
     * flush_rewrite_rules() cannot write .htaccess either (save_mod_rewrite_rules is not
     * loaded), which is why the rules were never repaired. Load the admin file helpers,
     * write the standard rules, and prove /wp-json actually answers JSON.
     */
    private function ensure_pretty_urls_reachable(): array {
        $probe = static function (): bool {
            $response = wp_remote_get( rest_url(), [ 'timeout' => 8, 'sslverify' => false, 'redirection' => 2 ] );
            if ( is_wp_error( $response ) ) {
                return false;
            }
            if ( 404 === (int) wp_remote_retrieve_response_code( $response ) ) {
                return false;
            }
            return null !== json_decode( (string) wp_remote_retrieve_body( $response ), true );
        };

        if ( $probe() ) {
            return [ 'ok' => true, 'changed' => false ];
        }

        try {
            if ( ! function_exists( 'save_mod_rewrite_rules' ) || ! function_exists( 'insert_with_markers' ) ) {
                require_once ABSPATH . 'wp-admin/includes/misc.php';
            }
            if ( ! function_exists( 'get_home_path' ) ) {
                require_once ABSPATH . 'wp-admin/includes/file.php';
            }
            // Two silent no-ops defeated the first version of this repair. When several
            // restore steps run in one request, $wp_rewrite was initialized BEFORE the
            // database swap — with the destination's plain permalinks — so flushing wrote
            // empty rules. And save_mod_rewrite_rules() quietly refuses when it cannot
            // detect mod_rewrite (PHP-FPM behind Apache). Re-init the rewrite engine from
            // the restored option and write the rules block directly.
            global $wp_rewrite;
            $structure = (string) get_option( 'permalink_structure' );
            if ( is_object( $wp_rewrite ) && '' !== $structure ) {
                $wp_rewrite->init();
                $wp_rewrite->set_permalink_structure( $structure );
                $rules = (string) $wp_rewrite->mod_rewrite_rules();
                if ( '' !== trim( $rules ) && function_exists( 'insert_with_markers' ) && function_exists( 'get_home_path' ) ) {
                    insert_with_markers( get_home_path() . '.htaccess', 'WordPress', explode( "\n", trim( $rules ) ) );
                }
            }
            flush_rewrite_rules( true );
        } catch ( \Throwable $e ) {
            return [ 'ok' => false, 'changed' => false, 'message' => 'Rewrite rules could not be written: ' . $e->getMessage() . ' MV panels fall back to query-string REST routes automatically.' ];
        }

        if ( $probe() ) {
            return [ 'ok' => true, 'changed' => true ];
        }
        return [
            'ok'      => false,
            'changed' => true,
            'message' => 'Pretty URLs are still not reachable after writing rewrite rules (the server may ignore .htaccess). MV panels fall back to query-string REST routes automatically; check the front end and re-save Settings → Permalinks if pages 404.',
        ];
    }

    /**
     * The restored database carries the SOURCE site's db_version. When it differs from
     * this WordPress install's own, core intercepts every wp-admin request with the
     * "Database Update Required" screen until someone runs the upgrade by hand. Run the
     * same silent upgrade upgrade.php would, so the restored site is immediately usable.
     */
    private function upgrade_wordpress_database(): array {
        global $wp_db_version;
        $stored = (int) get_option( 'db_version' );
        if ( empty( $wp_db_version ) || $stored === (int) $wp_db_version ) {
            return [ 'ok' => true, 'changed' => false, 'db_version' => $stored ];
        }
        try {
            if ( ! function_exists( 'wp_upgrade' ) ) {
                require_once ABSPATH . 'wp-admin/includes/upgrade.php';
            }
            if ( function_exists( 'wp_upgrade' ) ) {
                wp_upgrade();
            }
        } catch ( \Throwable $e ) {
            return [ 'ok' => false, 'changed' => false, 'message' => $e->getMessage() ];
        }
        return [
            'ok'         => (int) get_option( 'db_version' ) === (int) $wp_db_version,
            'changed'    => true,
            'from'       => $stored,
            'db_version' => (int) get_option( 'db_version' ),
        ];
    }

    private function force_postname_permalinks(): array {
        global $wp_rewrite;

        $target  = '/%postname%/';
        $before  = (string) get_option( 'permalink_structure', '' );
        $changed = $before !== $target;

        if ( $changed ) {
            // $wp_rewrite was built at page load, before the database swap, so it still
            // holds the previous structure. set_permalink_structure() updates the option
            // AND re-inits the object; flushing without it regenerates rules for the old
            // permalink form.
            if ( isset( $wp_rewrite ) && is_object( $wp_rewrite ) && method_exists( $wp_rewrite, 'set_permalink_structure' ) ) {
                $wp_rewrite->set_permalink_structure( $target );
            } else {
                update_option( 'permalink_structure', $target );
            }
            // The options cache can still hold the pre-swap value.
            wp_cache_delete( 'permalink_structure', 'options' );
            wp_cache_delete( 'alloptions', 'options' );
        }

        delete_option( 'rewrite_rules' );
        if ( function_exists( 'flush_rewrite_rules' ) ) {
            flush_rewrite_rules( true );
        }

        $after = (string) get_option( 'permalink_structure', '' );

        // Last resort: write straight to the options table if the write did not stick
        // (a stale cache or a filter can silently swallow update_option here).
        if ( $target !== $after ) {
            global $wpdb;
            $wpdb->update( $wpdb->options, [ 'option_value' => $target ], [ 'option_name' => 'permalink_structure' ] );
            wp_cache_delete( 'permalink_structure', 'options' );
            wp_cache_delete( 'alloptions', 'options' );
            $after = (string) get_option( 'permalink_structure', '' );
        }

        return [
            'ok'      => $target === $after,
            'before'  => $before,
            'after'   => $after,
            'changed' => $changed,
            'flushed' => true,
        ];
    }

    private function remove_maintenance_marker(): array {
        $path = trailingslashit( ABSPATH ) . '.maintenance';
        $existed = is_file( $path );
        $removed = false;
        if ( $existed && is_writable( $path ) ) {
            $removed = @unlink( $path );
        }

        return [
            'ok'      => ! $existed || $removed || ! file_exists( $path ),
            'path'    => $path,
            'existed' => $existed,
            'removed' => $removed,
        ];
    }

    private function clear_runtime_caches(): array {
        if ( function_exists( 'wp_cache_flush' ) ) {
            wp_cache_flush();
        }
        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
            wp_clean_plugins_cache( true );
        }
        if ( function_exists( 'wp_clean_themes_cache' ) ) {
            wp_clean_themes_cache( true );
        }
        if ( function_exists( 'opcache_reset' ) ) {
            @opcache_reset();
        }

        // Common update and plugin metadata transients can be stale after a table swap.
        foreach ( [ 'update_plugins', 'update_themes', 'update_core' ] as $transient ) {
            delete_site_transient( $transient );
        }

        return [
            'ok'                    => true,
            'object_cache_flushed'  => function_exists( 'wp_cache_flush' ),
            'plugins_cache_cleaned' => function_exists( 'wp_clean_plugins_cache' ),
            'themes_cache_cleaned'  => function_exists( 'wp_clean_themes_cache' ),
            'opcache_reset'         => function_exists( 'opcache_reset' ),
        ];
    }

    private function refresh_bricks_runtime(): array {
        $scheduled = false;
        $deleted_options = [];
        $deleted_transients = $this->delete_option_name_like( [
            '_transient_bricks_%',
            '_transient_timeout_bricks_%',
            '_site_transient_bricks_%',
            '_site_transient_timeout_bricks_%',
        ] );
        $deleted_css_files = $this->delete_bricks_generated_css();
        update_option( 'restorebase_deferred_builder_recovery', time(), false );

        foreach ( [
            'bricks_css_files_last_generated',
            'bricks_css_files_last_generated_timestamp',
            'bricks_css_files_admin_notice',
            'bricks_breakpoints_last_generated',
            'bricks_code_signatures_last_generated',
            'bricks_code_signatures_last_generated_timestamp',
            'bricks_code_signatures_admin_notice',
        ] as $option ) {
            if ( false !== get_option( $option, false ) ) {
                delete_option( $option );
                $deleted_options[] = $option;
            }
        }

        if ( class_exists( '\Bricks\Assets_Files' ) && method_exists( '\Bricks\Assets_Files', 'schedule_css_file_regeneration' ) ) {
            \Bricks\Assets_Files::schedule_css_file_regeneration();
            $scheduled = true;
        } elseif ( function_exists( 'wp_schedule_single_event' ) && ! wp_next_scheduled( 'bricks_regenerate_css_files' ) ) {
            wp_schedule_single_event( time() + 5, 'bricks_regenerate_css_files' );
            $scheduled = true;
        }

        return [
            'ok'                 => true,
            'scheduled_regen'    => $scheduled,
            'deleted_options'    => $deleted_options,
            'deleted_transients' => $deleted_transients,
            'deleted_css_files'  => $deleted_css_files,
            'message'            => $scheduled ? 'Bricks builder runtime/cache refresh was scheduled.' : 'Bricks runtime cache options were checked.',
        ];
    }

    private function delete_option_name_like( array $patterns ): int {
        global $wpdb;
        $deleted = 0;
        foreach ( $patterns as $pattern ) {
            $deleted += (int) $wpdb->query(
                $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $pattern )
            );
        }
        return $deleted;
    }

    private function delete_bricks_generated_css(): int {
        $uploads = wp_upload_dir( null, false );
        $base = isset( $uploads['basedir'] ) ? trailingslashit( wp_normalize_path( (string) $uploads['basedir'] ) ) : '';
        if ( '' === $base ) {
            return 0;
        }
        $css_dir = $base . 'bricks/css/';
        if ( ! is_dir( $css_dir ) || ! is_readable( $css_dir ) ) {
            return 0;
        }
        $deleted = 0;
        foreach ( glob( $css_dir . '*.css' ) ?: [] as $file ) {
            if ( is_file( $file ) && is_writable( $file ) && @unlink( $file ) ) {
                $deleted++;
            }
        }
        return $deleted;
    }

    private function refresh_studio_runtime(): array {
        // Studio-style plugins often keep their list screens alive with pre-restore REST nonces.
        // A full admin refresh after restore is the reliable fix; this flag lets the panel say so.
        delete_transient( 'restorebase_last_studio_refresh_hint' );
        set_transient( 'restorebase_last_studio_refresh_hint', current_time( 'mysql' ), HOUR_IN_SECONDS );

        return [
            'ok'               => true,
            'refresh_required' => true,
            'message'          => 'Admin refresh requested so restored media/plugin studios can reload fresh REST nonces and data.',
        ];
    }

    private function refresh_current_user_runtime(): array {
        $user_id = get_current_user_id();
        if ( $user_id <= 0 ) {
            return [
                'ok'      => false,
                'message' => 'The current destination administrator could not be resolved after restore.',
            ];
        }

        if ( function_exists( 'clean_user_cache' ) ) {
            clean_user_cache( $user_id );
        }
        if ( function_exists( 'wp_roles' ) ) {
            $roles = wp_roles();
            if ( is_object( $roles ) && method_exists( $roles, 'for_site' ) ) {
                $roles->for_site( get_current_blog_id() );
            }
        }
        if ( function_exists( 'wp_set_current_user' ) ) {
            wp_set_current_user( 0 );
            wp_set_current_user( $user_id );
        }

        return [
            'ok'             => current_user_can( 'edit_posts' ),
            'user_id'        => $user_id,
            'can_edit_posts' => current_user_can( 'edit_posts' ),
            'can_manage'     => current_user_can( 'manage_options' ),
            'message'        => current_user_can( 'edit_posts' ) ? 'Destination administrator capabilities refreshed.' : 'Destination administrator capabilities are not readable after restore.',
        ];
    }
    public static function maybe_run_deferred_builder_recovery(): void {
        $marked = (int) get_option( 'restorebase_deferred_builder_recovery', 0 );
        if ( $marked <= 0 ) {
            return;
        }
        if ( time() - $marked > HOUR_IN_SECONDS ) {
            delete_option( 'restorebase_deferred_builder_recovery' );
            return;
        }

        try {
            if ( class_exists( '\Bricks\Assets_Files' ) && method_exists( '\Bricks\Assets_Files', 'regenerate_css_files' ) ) {
                \Bricks\Assets_Files::regenerate_css_files();
            }
            if ( class_exists( '\Bricks\Admin' ) && method_exists( '\Bricks\Admin', 'crawl_and_update_code_signatures' ) ) {
                \Bricks\Admin::crawl_and_update_code_signatures( true );
                if ( defined( 'BRICKS_VERSION' ) ) {
                    update_option( 'bricks_code_signatures_last_generated', BRICKS_VERSION );
                    update_option( 'bricks_code_signatures_last_generated_timestamp', time() );
                }
            }
        } catch ( \Throwable $throwable ) {
            Logger::warning( 'deferred_builder_recovery_failed', 'Deferred Bricks recovery could not finish.', [
                'message' => $throwable->getMessage(),
                'file'    => $throwable->getFile(),
                'line'    => $throwable->getLine(),
            ] );
        }

        delete_option( 'restorebase_deferred_builder_recovery' );
    }

    private function map_database_prefixes( string $old_prefix, string $new_prefix ): array {
        global $wpdb;

        $results = [];

        // 1. Rename options table keys (specifically {prefix}user_roles)
        $old_roles_key = $old_prefix . 'user_roles';
        $new_roles_key = $new_prefix . 'user_roles';

        $wpdb->query( 'SET FOREIGN_KEY_CHECKS=0' );

        // Delete any existing target option if it got created to avoid duplicates/errors
        $wpdb->delete( $wpdb->options, [ 'option_name' => $new_roles_key ] );

        $updated_options = $wpdb->update(
            $wpdb->options,
            [ 'option_name' => $new_roles_key ],
            [ 'option_name' => $old_roles_key ]
        );
        $results['options_renamed'] = ( false !== $updated_options );

        // 2. Rename usermeta keys starting with the old prefix
        $old_prefix_like = $wpdb->esc_like( $old_prefix ) . '%';
        $meta_query = $wpdb->prepare(
            "UPDATE {$wpdb->usermeta} 
             SET meta_key = CONCAT(%s, SUBSTRING(meta_key, %d)) 
             WHERE meta_key LIKE %s",
            $new_prefix,
            strlen( $old_prefix ) + 1,
            $old_prefix_like
        );
        $updated_meta = $wpdb->query( $meta_query );
        $results['usermeta_updated'] = ( false !== $updated_meta ) ? $updated_meta : 0;

        $wpdb->query( 'SET FOREIGN_KEY_CHECKS=1' );

        // Flush options cache
        wp_cache_delete( $new_roles_key, 'options' );
        wp_cache_delete( 'alloptions', 'options' );

        Logger::info( 'post_restore_prefix_mapping', 'Mapped database prefixes in options and usermeta.', [
            'old_prefix' => $old_prefix,
            'new_prefix' => $new_prefix,
            'options'    => $results['options_renamed'],
            'usermeta'   => $results['usermeta_updated'],
        ] );

        return $results;
    }

}
