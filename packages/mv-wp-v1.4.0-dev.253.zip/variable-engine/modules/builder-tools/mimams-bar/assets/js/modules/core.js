(function () {
  'use strict';

  var config = window.baqaConfig || {};
  var labels = config.labels || {};
  var DEBUG = !!config.debug;
  var SETTINGS_KEY = 'mimamsBarSettings';
  var MAX_BULK_TARGETS = 40;

  function readStoredSettings() {
    try {
      var raw = window.localStorage ? window.localStorage.getItem(SETTINGS_KEY) : '';
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  }

  function writeStoredSettings(value) {
    try {
      if (window.localStorage) {
        window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(value || {}));
      }
    } catch (e) {}
  }

  function getEffectiveShortcut() {
    var stored = readStoredSettings();
    var shortcutName = stored.shortcut || 'ctrl-k';
    var shortcuts = {
      'alt-q': { ctrl: false, alt: true, shift: false, meta: false, key: 'q' },
      'ctrl-k': { ctrl: true, alt: false, shift: false, meta: false, key: 'k' },
      'ctrl-alt-a': { ctrl: true, alt: true, shift: false, meta: false, key: 'a' }
    };
    return shortcuts[shortcutName] || config.shortcut || shortcuts['ctrl-k'];
  }

  function matchesConfiguredShortcut(event) {
    // One source of truth: assets/js/shortcut-registry.js. The inline test that
    // used to live here is the fallback for the case where the registry script
    // did not load, so the Bar never becomes unreachable.
    if (window.MVShortcuts && typeof window.MVShortcuts.matches === 'function') {
      return window.MVShortcuts.matches('bar.open', event);
    }
    var shortcut = getEffectiveShortcut();
    var key = String(shortcut.key || 'q').toLowerCase();
    return (!!shortcut.ctrl === event.ctrlKey) &&
      (!!shortcut.alt === event.altKey) &&
      (!!shortcut.shift === event.shiftKey) &&
      (!!shortcut.meta === event.metaKey) &&
      String(event.key || '').toLowerCase() === key;
  }

  function isMimamsBarDisabled() {
    try {
      var storage = window.top && window.top.localStorage ? window.top.localStorage : window.localStorage;
      var raw = storage ? storage.getItem('ve_deactivated_tools') : '';
      var surfaceRaw = storage ? storage.getItem('ve_deactivated_tool_surfaces') : '';
      var list = raw ? JSON.parse(raw) : [];
      var surfaces = surfaceRaw ? JSON.parse(surfaceRaw) : {};
      var builderList = surfaces && Array.isArray(surfaces.builder) ? surfaces.builder : [];
      var adminList = surfaces && Array.isArray(surfaces.admin) ? surfaces.admin : [];
      var surface = config.surface === 'builder' ? 'builder' : 'admin';
      var activeList = surface === 'builder' ? builderList : adminList;
      var legacy = Array.isArray(list) ? list : [];
      var legacyWithoutSurfaceChoice = legacy.filter(function (id) {
        return adminList.indexOf(id) === -1 && builderList.indexOf(id) === -1;
      });
      return activeList.indexOf('mimams_bar') !== -1 || legacyWithoutSurfaceChoice.indexOf('mimams_bar') !== -1;
    } catch (e) {
      return false;
    }
  }

  function log() {
    if (DEBUG && window.console) {
      console.log.apply(console, ["[Mimam's Bar]"].concat(Array.prototype.slice.call(arguments)));
    }
  }

  function makeId() {
    return 'baqa_' + Math.random().toString(36).slice(2, 9);
  }

  var Core = {
    version: config.version || '0.2.4',
    config: config,
    labels: labels,
    debug: DEBUG,
    SETTINGS_KEY: SETTINGS_KEY,
    MAX_BULK_TARGETS: MAX_BULK_TARGETS,
    readStoredSettings: readStoredSettings,
    writeStoredSettings: writeStoredSettings,
    getEffectiveShortcut: getEffectiveShortcut,
    matchesConfiguredShortcut: matchesConfiguredShortcut,
    log: log,
    makeId: makeId
  };

  window.MimamsBarCore = Core;

  // Bricks can load builder assets in the preview/canvas iframe too.
  // The actual floating panel must only live in the top builder document;
  // otherwise the preview document can gain extra scrollbars/white gutters.
  // When the shortcut is pressed from inside the iframe, forward it upward.
  if (window.self !== window.top) {
    window.MimamsBarFrameBridge = true;

    document.addEventListener('keydown', function (event) {
      if (!matchesConfiguredShortcut(event)) return;
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
      if (isMimamsBarDisabled()) return;
      try {
        window.top.postMessage({ type: 'baqa:toggle' }, window.location.origin);
      } catch (e) {
        try { window.top.postMessage({ type: 'baqa:toggle' }, '*'); } catch (ignore) {}
      }
    }, true);

    window.BAQA = { frameBridge: true, version: Core.version };
  }
})();
