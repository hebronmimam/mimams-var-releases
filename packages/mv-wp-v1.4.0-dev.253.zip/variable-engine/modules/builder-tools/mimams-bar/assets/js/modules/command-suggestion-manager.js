(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarCommandSuggestions) return;

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[char];
    });
  }

  function highlightMatch(text, query) {
    text = String(text == null ? '' : text);
    query = String(query || '');
    if (!query) return escapeHtml(text);
    var i = text.toLowerCase().indexOf(query.toLowerCase());
    if (i === -1) return escapeHtml(text); // fuzzy match: no single contiguous span to mark
    return escapeHtml(text.slice(0, i)) + '<mark class="baqa-suggestion-mark">' + escapeHtml(text.slice(i, i + query.length)) + '</mark>' + escapeHtml(text.slice(i + query.length));
  }

  function unique(values) {
    var out = [];
    (values || []).forEach(function (value) {
      value = String(value || '').trim();
      if (value && out.indexOf(value) === -1) out.push(value);
    });
    return out;
  }

  function scoreByPrefix(value, query) {
    value = String(value || '').toLowerCase();
    query = String(query || '').toLowerCase();
    if (!query) return 1;
    if (value === query) return 100;
    if (value.indexOf(query) === 0) return 80 - value.length;
    if (value.indexOf(query) !== -1) return 40 - value.length;
    // Fuzzy: every query character appears in order (a subsequence), so ".splmed" still
    // finds ".split-content__media". Ranked below prefix/substring matches.
    var vi = 0;
    for (var qi = 0; qi < query.length; qi++) {
      vi = value.indexOf(query.charAt(qi), vi);
      if (vi === -1) return -1;
      vi++;
    }
    return 8;
  }

  // A suggestion is findable by every string that identifies it, not only by its
  // name. Typing "slant" has to reach data-section-edge="slant": the value is what
  // you remember, and searching the name alone meant the attribute was on the page,
  // was indexed, and still could not be found.
  function bestScore(item, query) {
    var keys = item.searchKeys && item.searchKeys.length
      ? item.searchKeys
      : [item.key || item.label || item.command];
    var best = -1;
    for (var i = 0; i < keys.length; i++) {
      var score = scoreByPrefix(keys[i], query);
      if (score < 0) continue;
      // A hit on a later key (the value) ranks under the same hit on the name, but
      // stays above no hit at all — hence the floor rather than a plain subtraction,
      // which would push a fuzzy value match back below zero and filter it straight
      // out again.
      if (i) score = Math.max(1, score - 20);
      if (score > best) best = score;
    }
    return best;
  }

  function sortMatches(items, query) {
    return items.map(function (item) {
      item._score = bestScore(item, query);
      return item;
    }).filter(function (item) {
      return item._score >= 0;
    }).sort(function (a, b) {
      return (b.priority || 0) - (a.priority || 0) || b._score - a._score || String(a.label).localeCompare(String(b.label));
    });
  }

  function getElement(app) {
    return app && app.adapter && typeof app.adapter.getSelectedElement === 'function'
      ? app.adapter.getSelectedElement()
      : null;
  }

  function getClasses(app, element) {
    if (!app || !app.adapter || !element) return [];
    return unique(app.adapter.getElementClasses(element));
  }

  function getAttributes(app, element) {
    if (!app || !app.adapter || !element) return [];
    return (app.adapter.getElementAttributes(element) || []).filter(function (attr) {
      return attr && attr.name;
    });
  }

  function buildRemoveClassSuggestions(app, value) {
    var match = String(value || '').match(/^\s*-\.?([^\s]*)$/);
    if (!match) return [];

    var element = getElement(app);
    if (!element) return [];

    var query = match[1] || '';
    return sortMatches(getClasses(app, element).map(function (name) {
      return {
        type: 'remove-class',
        key: name,
        label: '-' + name,
        detail: 'remove .' + name + ' from selected element',
        command: '-' + name
      };
    }), query).slice(0, 6);
  }

  function buildDeleteSuggestions(app, value) {
    var raw = String(value || '');
    var match = raw.match(/^\s*delete(?:\s+(.+))?$/i);
    if (!match) return [];

    var element = getElement(app);
    if (!element) return [];

    var remainder = String(match[1] || '');
    var tokens = remainder.split(/\s+/).filter(Boolean);
    var last = tokens.length ? tokens[tokens.length - 1] : '';
    var prefix = last;
    var isClassDelete = prefix.charAt(0) === '.';
    var query = isClassDelete ? prefix.slice(1) : prefix;

    var suggestions = [];

    if (isClassDelete) {
      suggestions = sortMatches(getClasses(app, element).map(function (name) {
        return {
          type: 'delete-global-class',
          key: name,
          label: 'delete .' + name,
          detail: 'open guarded global class cleanup dialog',
          command: 'delete .' + name
        };
      }), query);
    } else {
      suggestions = sortMatches(getAttributes(app, element).map(function (attr) {
        return {
          type: 'delete-attribute',
          key: attr.name,
          label: 'delete ' + attr.name,
          detail: attr.value === '' ? 'remove boolean/empty attribute' : 'remove attribute currently set to “' + attr.value + '”',
          command: 'delete ' + attr.name
        };
      }), query);
    }

    return suggestions.slice(0, 6);
  }

  // Common data-* / ARIA / HTML attribute names to autosuggest, in the spirit of a simple
  // but powerful attribute bar. The selected element's own attributes are merged in ahead
  // of these so editing an existing attribute is one keystroke away.
  var COMMON_ATTRIBUTES = [
    'data-anim', 'data-animation', 'data-aos', 'data-delay', 'data-duration', 'data-speed',
    'data-scroll', 'data-parallax', 'data-sticky', 'data-target', 'data-toggle', 'data-tooltip',
    'data-title', 'data-id', 'data-index', 'data-tab', 'data-accordion', 'data-modal', 'data-src',
    'data-count', 'data-group', 'data-state',
    'aria-label', 'aria-hidden', 'aria-expanded', 'aria-controls', 'aria-live', 'aria-current',
    'role', 'tabindex', 'id', 'title', 'loading', 'target', 'rel', 'type', 'name', 'placeholder',
    'value', 'href', 'alt'
  ];

  var ATTRIBUTE_GROUP_LABELS = {
    element: 'On this element',
    saved: 'Saved · frequent',
    data: 'Data attributes',
    accessibility: 'Accessibility',
    site: 'Used elsewhere on the site',
    standard: 'Standard'
  };

  // Enough to cover the settings a name is really used with, few enough that one
  // attribute cannot fill the list.
  var VALUES_PER_ATTRIBUTE = 6;

  function getSiteAttributes(app, selected) {
    if (!app || !app.adapter || typeof app.adapter.getAllElements !== 'function') return [];
    var now = Date.now ? Date.now() : new Date().getTime();
    if (app._attributeSiteIndex && now - (app._attributeSiteIndexAt || 0) < 1500) return app._attributeSiteIndex;
    var selectedId = selected && selected.id ? String(selected.id) : '';
    var seen = {};
    var out = [];
    // Keep every distinct value a name is used with, most used first. Collapsing to
    // the first value found is what made a value unfindable and, where two sections
    // used the same attribute differently, hid the other setting entirely.
    (app.adapter.getAllElements() || []).forEach(function (element) {
      if (!element || (selectedId && String(element.id || '') === selectedId)) return;
      getAttributes(app, element).forEach(function (attr) {
        var entry = seen[attr.name];
        if (!entry) {
          entry = { name: attr.name, value: attr.value, values: [], counts: {} };
          seen[attr.name] = entry;
          out.push(entry);
        }
        var value = String(attr.value == null ? '' : attr.value);
        if (!value) return;
        if (entry.counts[value] === undefined && entry.values.length < VALUES_PER_ATTRIBUTE) entry.values.push(value);
        entry.counts[value] = (entry.counts[value] || 0) + 1;
      });
    });
    out.forEach(function (entry) {
      entry.values.sort(function (a, b) { return entry.counts[b] - entry.counts[a]; });
      if (!entry.value && entry.values.length) entry.value = entry.values[0];
    });
    app._attributeSiteIndex = out;
    app._attributeSiteIndexAt = now;
    return out;
  }

  function attributeSuggestion(prefixText, name, value, group, query, saved, alsoKnownAs) {
    value = String(value == null ? '' : value);
    var escaped = value.replace(/\\/g, '\\\\').replace(/"/g, '\\"');
    var command = prefixText + name + '="' + escaped + '"';
    var valueStart = prefixText.length + name.length + 2;
    return {
      type: 'set-attribute',
      key: name,
      label: name,
      value: value,
      group: group,
      q: query,
      saved: !!saved,
      icon: group === 'saved' ? 'star' : group === 'accessibility' ? 'person-simple' : group === 'standard' ? 'tag' : group === 'element' ? 'pencil-simple' : 'database',
      /* Every value the name is known by, not just the primary. A record whose
         primary is blank - which is what a saved pair with no value stored
         beside it normalises to - had searchKeys of [name] alone, so a starred
         data-anim-mobile-breakpoint="970" could not be found by typing 970: the
         suggestion was built and then filtered straight back out again, which is
         exactly what the owner's trace showed (builtFromSaved 5, attr 0). */
      searchKeys: [name].concat(
        (alsoKnownAs || []).concat(value ? [value] : [])
          .filter(function (v, i, all) { return v && all.indexOf(v) === i; })
      ),
      matchedValue: !!(value && query && scoreByPrefix(name, query) < 0 && scoreByPrefix(value, query) >= 0),
      badge: group === 'element' ? 'on element' : group === 'saved' ? 'saved' : group === 'accessibility' ? 'a11y' : group === 'site' ? 'on site' : group === 'data' ? 'data' : 'attribute',
      detail: value ? value : 'set ' + name + '="..."',
      command: command,
      nextValue: command,
      caret: valueStart + value.length,
      selectionStart: valueStart,
      selectionEnd: valueStart + value.length
    };
  }

  function buildAttributeSuggestions(app, value) {
    var raw = String(value || '');
    // Operate on the last whitespace-separated token so this also works after a bulk
    // target (e.g. "all h2 => data-a") or after earlier attributes on the same line.
    var lastStart = raw.search(/\S+$/);
    if (lastStart < 0) return [];
    var prefixText = raw.slice(0, lastStart);
    var token = raw.slice(lastStart);
    // Not a class, not an id, and not an attribute whose value has already been
    // started. The leading-letter rule this replaces was written when only names
    // were matched here; values are matched now too, and a value is not a name -
    // it can open with a digit and carry a dot or a percent. That is why a starred
    // data-stagger="0.12" could not be found by typing 0.12, while one starred
    // with a word could (R11).
    if (!token || /^[.#]/.test(token) || token.indexOf('=') !== -1) return [];
    if (!/^[A-Za-z0-9][A-Za-z0-9._%:/-]*$/.test(token)) return [];

    var element = getElement(app);
    var existing = element ? getAttributes(app, element) : [];
    var manager = app.savedAttributes || window.MimamsBarSavedAttributes;
    var saved = manager && typeof manager.getAll === 'function' ? manager.getAll() : [];
    var site = getSiteAttributes(app, element);
    var seen = {};
    var grouped = { element: [], saved: [], data: [], accessibility: [], site: [], standard: [] };

    function add(item, group, isSaved) {
      if (!item || !item.name || seen[item.name]) return;
      seen[item.name] = true;
      /* The primary is what gets offered, and a blank primary offers you
         name="" - a suggestion for setting an attribute to nothing, sitting
         in front of the real value. Records already stored that way stay
         that way until they are next saved, so the first real value stands
         in rather than waiting for the store to be rewritten. */
      var primary = item.value;
      if (!primary && Array.isArray(item.values)) {
        for (var v = 0; v < item.values.length; v++) {
          if (item.values[v]) { primary = item.values[v]; break; }
        }
      }
      grouped[group].push(attributeSuggestion(prefixText, item.name, primary, group, token, isSaved, item.values));
      // Where a name is used with several values, offer the others too — but only
      // the ones the query actually names, so typing a name still lists names
      // rather than one attribute's whole value history.
      if (!token || !item.values || item.values.length < 2) return;
      item.values.forEach(function (value) {
        if (!value || value === primary) return;
        if (scoreByPrefix(value, token) < 0) return;
        // The star belongs to this name AND value, so it is asked about the
        // pair. Asking about the name alone lit every value of a saved name.
        grouped[group].push(attributeSuggestion(prefixText, item.name, value, group, token,
          !!(manager && manager.isSaved && manager.isSaved(item.name, value))));
      });
    }

    /* A pair starred with no value beside it is blank on disk, and nothing in
       the store can recover a value that was never written - which is why the
       owner found it worked "only until I restarred it" (R11). It does not have
       to be re-starred: the site index already knows every value that name is
       used with, so a saved record holding nothing of its own borrows them.
       This has to happen HERE and not in the store, because the saved entry is
       added before the site one and add() dedupes by name - so the blank record
       was shadowing the very entry that had the answer. */
    var knownValues = {};
    existing.concat(site).forEach(function (item) {
      if (!item || !item.name) return;
      var known = knownValues[item.name] || (knownValues[item.name] = []);
      [item.value].concat(item.values || []).forEach(function (v) {
        v = String(v == null ? '' : v);
        if (v && known.indexOf(v) === -1) known.push(v);
      });
    });
    function withKnownValues(item) {
      if (!item || !item.name) return item;
      var hasOwn = item.value || (item.values || []).some(function (v) { return !!v; });
      if (hasOwn) return item;
      var known = knownValues[item.name];
      if (!known || !known.length) return item;
      return { name: item.name, value: known[0], values: known.slice() };
    }

    existing.forEach(function (item) { add(item, 'element', !!(manager && manager.isSaved && manager.isSaved(item.name, item.value))); });
    saved.forEach(function (item) { add(withKnownValues(item), 'saved', true); });
    /* counts:{attr:0} said the builder returned nothing and not why, and this
       same function returns all five of the owner's starred attributes when it
       is lifted out of this file and run. So the difference is in what it is
       handed, and this records exactly that: the token it split out, and the
       saved records as THIS function sees them, spelling and all. */
    try {
      if (window.veLastSuggest) {
        window.veLastSuggest.attrDetail = {
          token: token,
          prefix: prefixText,
          savedCount: saved.length,
          /* As one string: an object collapses in the console and the answer
             was inside the part that was collapsed, twice. */
          savedSeen: saved.slice(0, 6).map(function (i) {
            return (i && i.name) + '="' + (i && i.value) + '" values=' +
              JSON.stringify((i && i.values) || []);
          }).join('  |  '),
          builtFromSaved: grouped.saved.length,
          keys: grouped.saved.slice(0, 3).map(function (x) { return x.searchKeys; })
        };
      }
    } catch (e) {}
    COMMON_ATTRIBUTES.filter(function (name) { return name.indexOf('data-') === 0; }).forEach(function (name) { add({ name: name, value: '' }, 'data', !!(manager && manager.isSaved && manager.isSaved(name))); });
    COMMON_ATTRIBUTES.filter(function (name) { return name.indexOf('aria-') === 0 || name === 'role' || name === 'tabindex'; }).forEach(function (name) { add({ name: name, value: '' }, 'accessibility', !!(manager && manager.isSaved && manager.isSaved(name))); });
    site.forEach(function (item) { add(item, 'site', !!(manager && manager.isSaved && manager.isSaved(item.name))); });
    COMMON_ATTRIBUTES.filter(function (name) { return name.indexOf('data-') !== 0 && name.indexOf('aria-') !== 0 && name !== 'role' && name !== 'tabindex'; }).forEach(function (name) { add({ name: name, value: '' }, 'standard', !!(manager && manager.isSaved && manager.isSaved(name))); });

    return ['element', 'saved', 'data', 'accessibility', 'site', 'standard'].reduce(function (all, group) {
      return all.concat(sortMatches(grouped[group], token).slice(0, group === 'data' ? 4 : 3));
    }, []).slice(0, 14);
  }

  function buildClassSuggestions(app, value) {
    var raw = String(value || '');
    var lastStart = raw.search(/\S+$/);
    if (lastStart < 0) return [];
    var prefixText = raw.slice(0, lastStart);
    var token = raw.slice(lastStart);
    if (!/^\.[A-Za-z0-9_-]*$/.test(token)) return [];

    var element = getElement(app);
    if (!element) return [];
    var query = token.slice(1);
    var ql = query.toLowerCase();

    var make = function (name, group, priority) {
      var command = prefixText + '.' + name;
      var fuzzy = ql && String(name).toLowerCase().indexOf(ql) === -1;
      return {
        type: 'add-class',
        key: name,
        label: '.' + name,
        group: group,
        q: query,
        icon: group === 'element' ? 'selection' : 'globe-simple',
        badge: fuzzy ? 'fuzzy' : (group === 'element' ? 'on element' : 'global'),
        detail: group === 'element' ? 'class used on selected element' : 'global class on the site',
        command: command,
        nextValue: command,
        caret: command.length,
        priority: priority
      };
    };

    var onEl = getClasses(app, element);
    var seen = {};
    var items = onEl.map(function (name) { seen[name] = true; return make(name, 'element', 20); });

    // Also suggest global classes defined anywhere on the site (not only those already on
    // the selected element), so you can apply an existing class you're not currently using.
    var globals = [];
    try {
      if (app.adapter && typeof app.adapter.getGlobalClasses === 'function') {
        globals = app.adapter.getGlobalClasses() || [];
      }
    } catch (e) { globals = []; }
    globals.forEach(function (g) {
      var name = g && g.name ? String(g.name) : '';
      if (name && !seen[name]) { seen[name] = true; items.push(make(name, 'global', 5)); }
    });

    return sortMatches(items, query).slice(0, 8);
  }

  /* Every stage, recorded. Three rounds of R11 have been spent on theories
     about which of these returns nothing and why: the owner's console says the
     saved list is there (inConfig 5, fromManager 5), and this same chain lifted
     out of the shipped file and run returns all five - so the answer is in the
     running builder and nowhere else. Each stage writes what it produced, and
     which one answered, onto window.veLastSuggest. */
  function getSuggestions(app) {
    var trace = { at: new Date().toISOString(), stage: 'no app, not Direct mode, or no input' };
    try { window.veLastSuggest = trace; } catch (e) {}
    if (!app || app.mode !== 'default' || !app.input) {
      trace.mode = app ? app.mode : '(no app)';
      return [];
    }
    var value = String(app.input.value || '');
    trace.mode = app.mode;
    trace.value = value;
    var manager = app.savedAttributes || window.MimamsBarSavedAttributes;
    trace.saved = manager && typeof manager.getAll === 'function' ? manager.getAll().length : '(no manager)';
    trace.onApp = !!app.savedAttributes;
    trace.element = !!(app.adapter && typeof app.adapter.getSelectedElement === 'function' && app.adapter.getSelectedElement());
    if (!value.trim()) { trace.stage = 'the input is empty'; return []; }
    trace.counts = {};

    if (app.mvIntegration && typeof app.mvIntegration.getSuggestions === 'function') {
      var mvSuggestions = app.mvIntegration.getSuggestions(app, value);
      trace.counts.mv = (mvSuggestions || []).length;
      if (mvSuggestions && mvSuggestions.length) { trace.stage = 'MV integration answered'; return mvSuggestions; }
    } else trace.counts.mv = '(no integration)';

    var removeSuggestions = buildRemoveClassSuggestions(app, value);
    trace.counts.remove = removeSuggestions.length;
    if (removeSuggestions.length) { trace.stage = 'remove-class answered'; return removeSuggestions; }

    var deleteSuggestions = buildDeleteSuggestions(app, value);
    trace.counts.del = deleteSuggestions.length;
    if (deleteSuggestions.length) { trace.stage = 'delete answered'; return deleteSuggestions; }

    /* An early return here is why a fuzzy class match can hide an exact
       attribute one - noted rather than changed, because until the trace says
       this is the stage that answers, changing it would be another guess. */
    var classSuggestions = buildClassSuggestions(app, value);
    trace.counts.cls = classSuggestions.length;
    if (classSuggestions.length) {
      trace.stage = 'classes answered';
      trace.clsFirst = classSuggestions.slice(0, 3).map(function (x) { return x.label; });
      return classSuggestions;
    }

    var attributeSuggestions = buildAttributeSuggestions(app, value);
    trace.counts.attr = attributeSuggestions.length;
    if (attributeSuggestions.length) {
      trace.stage = 'attributes answered';
      trace.attrFirst = attributeSuggestions.slice(0, 3).map(function (x) { return x.label + '=' + x.value; });
      return attributeSuggestions;
    }

    trace.stage = 'every stage returned nothing';
    return [];
  }

  function render(app) {
    var container = app && app.commandSuggestions;
    if (!container) return [];

    var suggestions = getSuggestions(app);
    container.innerHTML = '';

    if (!suggestions.length) {
      container.hidden = true;
      app.activeCommandSuggestions = [];
      return suggestions;
    }

    if (typeof app.activeCommandSuggestionIndex !== 'number') app.activeCommandSuggestionIndex = 0;
    if (app.activeCommandSuggestionIndex < 0) app.activeCommandSuggestionIndex = 0;
    if (app.activeCommandSuggestionIndex >= suggestions.length) app.activeCommandSuggestionIndex = suggestions.length - 1;

    var lastGroup = null;
    suggestions.forEach(function (item, index) {
      if (item.group && item.group !== lastGroup) {
        lastGroup = item.group;
        var head = document.createElement('div');
        head.className = 'baqa-command-suggestion-group';
        head.textContent = item.type === 'set-attribute'
          ? (ATTRIBUTE_GROUP_LABELS[item.group] || item.group)
          : (item.group === 'element' ? 'On this element' : 'All classes on the site');
        container.appendChild(head);
      }
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'baqa-command-suggestion' + (index === app.activeCommandSuggestionIndex ? ' is-active' : '');
      button.setAttribute('data-type', item.type || '');
      var right;
      if (item.badge) {
        var badgeCls = item.badge === 'fuzzy' ? 'fuzzy'
          : item.badge === 'global' ? 'global'
          : item.badge === 'saved' ? 'saved'
          : item.badge === 'data' ? 'data'
          : item.badge === 'a11y' ? 'a11y'
          : item.badge === 'on site' ? 'site'
          : item.badge === 'attribute' ? 'attribute'
          : 'onel';
        right = '<em class="baqa-cmd-right"><i class="baqa-suggestion-badge baqa-badge-' + badgeCls + '">' + escapeHtml(item.badge) + '</i></em>';
      } else {
        right = '<em>' + escapeHtml(item.detail) + '</em>';
      }
      var labelHtml;
      if (item.type === 'add-class' && item.key) {
        var iconHtml = item.icon ? '<i class="ph-duotone ph-' + item.icon + ' baqa-suggestion-ic"></i>' : '';
        labelHtml = iconHtml + '<span class="baqa-suggestion-name">.' + highlightMatch(item.key, item.q) + '</span>';
      } else if (item.type === 'set-attribute' && item.key) {
        var attrIcon = item.icon ? '<i class="ph-duotone ph-' + item.icon + ' baqa-suggestion-ic"></i>' : '';
        /* `name="value"`, not `name value`. Every other row marks the typed
           characters inside the name, so a row that matched on its VALUE showed
           its highlight adrift in a second word with nothing to say what that
           word was - `data-anim-mobile individual` with `ind` lit in the middle
           of it (R17). Quoting it says value, and it is also exactly what the
           suggestion inserts, so the row now reads as the thing it will do. */
        labelHtml = attrIcon + '<span class="baqa-suggestion-name">' + highlightMatch(item.key, item.q) + (item.value ? '<small class="baqa-suggestion-value">="' + highlightMatch(item.value, item.q) + '"</small>' : '') + '</span>';
      } else {
        labelHtml = escapeHtml(item.label);
      }
      button.innerHTML = '<span class="baqa-suggestion-lead">' + labelHtml + '</span>' + right;
      button.addEventListener('mouseenter', function () {
        app.activeCommandSuggestionIndex = index;
        render(app);
      });
      button.addEventListener('click', function (event) {
        event.preventDefault();
        app.activeCommandSuggestionIndex = index;
        accept(app, item);
      });
      if (item.type === 'set-attribute') {
        var row = document.createElement('div');
        row.className = 'baqa-command-suggestion-row';
        row.appendChild(button);
        var star = document.createElement('button');
        star.type = 'button';
        star.className = 'baqa-suggestion-star' + (item.saved ? ' is-saved' : '');
        star.textContent = '★';
        star.setAttribute('aria-label', (item.saved ? 'Remove ' : 'Save ') + item.key + (item.saved ? ' from' : ' to') + ' saved attributes');
        star.setAttribute('title', item.saved ? 'Remove from saved attributes' : 'Save this attribute and value');
        star.addEventListener('click', function (event) {
          event.preventDefault();
          event.stopPropagation();
          var manager = app.savedAttributes || window.MimamsBarSavedAttributes;
          if (!manager || typeof manager.toggle !== 'function') return;
          manager.toggle(item.key, item.value || '').then(function () {
            if (app.toast && typeof app.toast.show === 'function') {
              app.toast.show(item.key + (item.saved ? ' removed from saved attributes.' : ' saved for this site.'));
            }
            render(app);
          }).catch(function (error) {
            if (app.toast && typeof app.toast.show === 'function') app.toast.show(error && error.message ? error.message : 'Saved attributes could not be updated.', 'error');
          });
        });
        row.appendChild(star);
        container.appendChild(row);
      } else {
        container.appendChild(button);
      }
    });

    container.hidden = false;
    app.activeCommandSuggestions = suggestions;
    return suggestions;
  }

  function clear(app) {
    if (!app) return;
    app.activeCommandSuggestions = [];
    app.activeCommandSuggestionIndex = 0;
    if (app.commandSuggestions) {
      app.commandSuggestions.hidden = true;
      app.commandSuggestions.innerHTML = '';
    }
  }

  function accept(app, item) {
    item = item || (app && app.activeCommandSuggestions && app.activeCommandSuggestions[typeof app.activeCommandSuggestionIndex === 'number' ? app.activeCommandSuggestionIndex : 0]) || (app && app.activeCommandSuggestions && app.activeCommandSuggestions[0]);
    if (!app || !app.input || !item || !item.command) return false;
    var value = item.nextValue || item.command;
    var caret = typeof item.caret === 'number' ? item.caret : value.length;
    app.input.value = value;
    app.input.focus();
    try {
      if (typeof item.selectionStart === 'number' && typeof item.selectionEnd === 'number') {
        app.input.setSelectionRange(item.selectionStart, item.selectionEnd);
      } else {
        app.input.setSelectionRange(caret, caret);
      }
    } catch (e) { app.input.setSelectionRange(value.length, value.length); }
    clear(app);
    if (typeof app.updateTabHint === 'function') app.updateTabHint();
    return true;
  }

  function move(app, delta) {
    if (!app) return false;
    var list = app.activeCommandSuggestions || render(app) || [];
    if (!list.length) return false;
    var index = typeof app.activeCommandSuggestionIndex === 'number' ? app.activeCommandSuggestionIndex : 0;
    index += delta;
    if (index < 0) index = list.length - 1;
    if (index >= list.length) index = 0;
    app.activeCommandSuggestionIndex = index;
    render(app);
    if (app.commandSuggestions) {
      var active = app.commandSuggestions.querySelector('.is-active');
      if (active && active.scrollIntoView) active.scrollIntoView({ block: 'nearest' });
    }
    return true;
  }

  function hasSuggestions(app) {
    return !!(app && app.activeCommandSuggestions && app.activeCommandSuggestions.length);
  }

  var CommandSuggestions = {
    getSuggestions: getSuggestions,
    render: render,
    clear: clear,
    accept: accept,
    move: move,
    hasSuggestions: hasSuggestions
  };

  window.MimamsBarCommandSuggestions = CommandSuggestions;
  window.MimamsBar = window.MimamsBar || {};
  window.MimamsBar.CommandSuggestions = CommandSuggestions;
})();
