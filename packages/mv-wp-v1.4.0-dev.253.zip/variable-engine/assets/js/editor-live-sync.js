/*
 * C3, the owner: "build it." Two-way live sync between the WordPress editor and
 * Content Studio, no refresh. This is the block editor's half.
 *
 * - When this editor saves, other tabs are told at once (BroadcastChannel), so
 *   an open Content Studio shows the change.
 * - When Content Studio (or anyone) saves the post, this editor hears it - at
 *   once from a tab in the same browser, otherwise from a small check of the
 *   post's modified time on focus and every 20 seconds.
 * - With no unsaved edits here, the editor takes the new version in place.
 *   With unsaved edits, nothing is overwritten: a notice says so, and offers a
 *   reload (WordPress asks before dropping the edits).
 */
(function (wp) {
  if (!wp || !wp.data || !wp.apiFetch) return;
  var data = wp.data;
  var ns = (window.veEditorLiveSync && window.veEditorLiveSync.ns) || 'variable-engine/v1';
  var channel = null;
  try { channel = new BroadcastChannel('ve-content-live'); } catch (e) {}

  function editor() { return data.select('core/editor'); }
  function postId() { var e = editor(); return e && e.getCurrentPostId ? e.getCurrentPostId() : 0; }
  function postType() { return editor().getCurrentPostType(); }
  // WordPress's REST says 2026-09-25T10:00:00, MV's post_modified_gmt 2026-09-25 10:00:00.
  function norm(s) { return String(s || '').replace('T', ' ').slice(0, 19); }
  function current() { var p = editor().getCurrentPost(); return norm(p && p.modified_gmt); }

  var known = '';
  var wasSaving = false;
  var warnedFor = '';

  data.subscribe(function () {
    var e = editor();
    if (!e || !postId()) return;
    if (!known) known = current();
    var saving = e.isSavingPost() && !e.isAutosavingPost();
    if (wasSaving && !saving && e.didPostSaveRequestSucceed()) {
      known = current();
      if (channel) channel.postMessage({ type: 'saved', from: 'editor', id: postId(), modified: known });
    }
    wasSaving = saving;
  });

  function refresh(stamp) {
    var type = postType(), id = postId();
    var core = data.dispatch('core');
    return wp.apiFetch({ path: '/' + ns + '/content-studio/posts/' + id }).then(function (post) {
      var raw = post && post.content ? String(post.content.raw || '') : '';
      // The record first, so the saved state matches; then the blocks on screen.
      return Promise.resolve(core.invalidateResolution('getEntityRecord', ['postType', type, id]))
        .then(function () { return data.resolveSelect('core').getEntityRecord('postType', type, id); })
        .then(function () {
          var blocks = wp.blocks.parse(raw);
          data.dispatch('core/block-editor').resetBlocks(blocks);
          // Blocks live on the entity as a transient edit; drop it so the editor reads the new content.
          core.editEntityRecord('postType', type, id, { blocks: blocks, content: raw, title: post.title ? post.title.raw : undefined, excerpt: post.excerpt ? post.excerpt.raw : undefined }, { undoIgnore: true });
          known = norm(stamp);
          data.dispatch('core/notices').createInfoNotice('Updated with the changes saved in Content Studio.', { id: 've-live-sync', type: 'snackbar' });
        });
    });
  }

  function check(hint) {
    var id = postId();
    if (!id) return;
    var got = hint ? Promise.resolve(hint) : wp.apiFetch({ path: '/' + ns + '/content-studio/posts/' + id + '/stamp' }).then(function (r) { return r && r.modified; });
    got.then(function (stamp) {
      if (!stamp || norm(stamp) <= known) return;
      var e = editor();
      if (e.isSavingPost()) return;
      if (e.isEditedPostDirty()) {
        if (warnedFor === norm(stamp)) return;
        warnedFor = norm(stamp);
        data.dispatch('core/notices').createWarningNotice(
          'This post was saved in Content Studio after you opened it here. Your unsaved edits are kept. Reload to see the other version; WordPress asks before dropping your edits.',
          { id: 've-live-sync', isDismissible: true, actions: [{ label: 'Reload', onClick: function () { window.location.reload(); } }] }
        );
        return;
      }
      return refresh(stamp);
    }).catch(function () {});
  }

  if (channel) channel.onmessage = function (ev) {
    var m = ev && ev.data;
    if (m && m.type === 'saved' && m.from === 'studio' && +m.id === +postId()) check(m.modified);
  };
  window.addEventListener('focus', function () { check(); });
  setInterval(function () { if (document.visibilityState === 'visible') check(); }, 20000);
})(window.wp);
