/*
 * R50, the owner: "for @i12 it remained stale until I refreshed the page ... I
 * want once a change is made and saved in content studio, I don't need to
 * refresh to see the change on admin." This is the posts list's half of the
 * live sync (C3 built the block editor's, in editor-live-sync.js).
 *
 * When a post is saved - by Content Studio over this page, or in another tab -
 * the list asks WordPress for this same page again and swaps in that post's
 * row, so every column shows the saved state: title, status, date, and what
 * other plugins draw there (Rank Math's score among them). Nothing is rebuilt
 * but that one row, and a row being quick-edited is left alone.
 */
(function () {
  var list = document.getElementById('the-list');
  if (!list || typeof BroadcastChannel === 'undefined' || typeof DOMParser === 'undefined') return;
  var channel;
  try { channel = new BroadcastChannel('ve-content-live'); } catch (e) { return; }

  var waiting = {};
  var timer = 0;

  function rowFor(id) { return document.getElementById('post-' + id); }
  // WordPress hides the row and shows #edit-<id> while Quick Edit is open.
  function quickEditing(id) { return !!document.getElementById('edit-' + id); }

  function refresh() {
    var ids = Object.keys(waiting);
    waiting = {};
    if (!ids.length) return;
    fetch(window.location.href, { credentials: 'same-origin', cache: 'no-store' })
      .then(function (r) { return r.ok ? r.text() : ''; })
      .then(function (html) {
        if (!html) return;
        var fresh = new DOMParser().parseFromString(html, 'text/html');
        ids.forEach(function (id) {
          var now = rowFor(id);
          var next = fresh.getElementById('post-' + id);
          if (!now || !next || quickEditing(id)) return;
          var box = now.querySelector('input[name="post[]"]');
          var ticked = !!(box && box.checked);
          var row = document.importNode(next, true);
          var newBox = row.querySelector('input[name="post[]"]');
          if (newBox) newBox.checked = ticked;
          now.parentNode.replaceChild(row, now);
          row.classList.add('ve-row-updated');
          setTimeout(function () { row.classList.remove('ve-row-updated'); }, 1600);
        });
      })
      .catch(function () {});
  }

  channel.onmessage = function (e) {
    var m = e && e.data;
    if (!m || m.type !== 'saved' || !m.id || !rowFor(m.id)) return;
    waiting[String(m.id)] = true;
    clearTimeout(timer);
    // Several saves in a burst cost one request.
    timer = setTimeout(refresh, 250);
  };

  var style = document.createElement('style');
  // A brief tint that eases back to the row's own background, striped or not.
  style.textContent = '@keyframes ve-row-updated{from{background-color:rgba(214,255,0,.2)}}'
    + '#the-list tr.ve-row-updated>*{animation:ve-row-updated 1.4s ease-out}'
    + '@media (prefers-reduced-motion:reduce){#the-list tr.ve-row-updated>*{animation:none}}';
  document.head.appendChild(style);
})();
