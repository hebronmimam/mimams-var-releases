/* Enhancement Studio · Floating admin notices (C1).
   The owner's "HM - WordPress Admin Notices -> Floating Toasts", as an MV
   enhancement. Loaded in wp-admin only, and only while it is switched on for
   this account (core/Enhancements.php). */
(function () {
  'use strict';
  var CFG = Object.assign({}, window.veAdminToastsConfig || {});
  var STACK_ID = 've-admin-toast-stack';
  var DURATION = Math.max(3, Math.min(20, Number(CFG.duration) || 10));
  var PERSIST = CFG.persist !== false;
  var NOTICE = 'div.notice, div.updated, div.update-nag, #wpbody-content > div.error, .wrap > div.error';
  var PROTECTED = ['BODY', '#wpwrap', '#wpcontent', '#wpbody', '#wpbody-content', '.wrap'];

  function stack() {
    var s = document.getElementById(STACK_ID);
    if (s) return s;
    s = document.createElement('div');
    s.id = STACK_ID;
    s.className = 'pos-' + (/^(tr|tl|br|bl)$/.test(CFG.position) ? CFG.position : 'tr');
    s.setAttribute('role', 'region');
    s.setAttribute('aria-label', 'Notifications');
    s.setAttribute('aria-live', 'polite');
    s.setAttribute('aria-relevant', 'additions');
    document.body.appendChild(s);
    return s;
  }

  function isProtected(el) {
    if (!(el instanceof HTMLElement)) return true;
    return PROTECTED.some(function (sel) { return el.matches(sel); });
  }

  /* A plugin wrapper left empty by the move is folded away, never a WordPress one. */
  function tidy(parent) {
    if (!parent || isProtected(parent)) return;
    requestAnimationFrame(function () {
      if (!parent.isConnected) return;
      var kids = Array.prototype.filter.call(parent.children, function (c) { return c.id !== STACK_ID && c.tagName !== 'SCRIPT' && c.tagName !== 'STYLE'; });
      if (!kids.length && !parent.textContent.replace(/\s+/g, '')) {
        parent.style.setProperty('display', 'none', 'important');
      }
    });
  }

  function isNotice(el) {
    if (!(el instanceof HTMLElement) || !el.matches(NOTICE)) return false;
    if (el.classList.contains('inline') || el.classList.contains('hidden')) return false;
    // MV's own panels, the block editor and anything already floating are left alone.
    if (el.closest('#' + STACK_ID + ', #ve-panel-root, .ve-standalone-panel, .block-editor, .media-modal, .components-modal__frame')) return false;
    return true;
  }

  function kind(el) {
    if (el.classList.contains('notice-error') || el.classList.contains('error')) return 'error';
    if (el.classList.contains('notice-warning') || el.classList.contains('update-nag')) return 'warning';
    return 'info';
  }

  function leave(el) {
    if (!el.isConnected || el.classList.contains('ve-toast-leaving')) return;
    el.classList.add('ve-toast-leaving');
    var done = function () { if (el.isConnected) el.remove(); };
    el.addEventListener('animationend', done, { once: true });
    setTimeout(done, 400);
  }

  function float(el) {
    if (!isNotice(el)) return;
    var parent = el.parentElement;
    // WordPress's common.js moves every notice under the page heading once the
    // page is ready - after this has already floated them. One it already
    // prepared just goes back to the stack.
    if (el.classList.contains('ve-admin-toast')) {
      stack().appendChild(el);
      tidy(parent);
      return;
    }
    var k = kind(el);
    el.classList.add('ve-admin-toast');
    if (k === 'error') el.setAttribute('role', 'alert');
    var first = el.firstElementChild;
    if (first && (first.tagName === 'IMG' || first.tagName === 'svg' || first.tagName === 'SVG')) el.classList.add('ve-toast-has-icon');
    // A notice WordPress cannot dismiss still needs a way out of the stack.
    if (!el.classList.contains('is-dismissible') && !el.querySelector('.notice-dismiss')) {
      var close = document.createElement('button');
      close.type = 'button';
      close.className = 've-admin-toast-close';
      close.setAttribute('aria-label', 'Dismiss this notice');
      close.textContent = '×';
      close.addEventListener('click', function () { leave(el); });
      el.appendChild(close);
    }
    // Dismissing through WordPress's own button still tells WordPress (and the plugin).
    el.addEventListener('click', function (e) {
      if (e.target.closest && e.target.closest('.notice-dismiss')) setTimeout(function () { leave(el); }, 0);
    });
    var timed = k === 'info' || !PERSIST;
    if (timed) {
      var bar = document.createElement('span');
      bar.className = 've-toast-progress';
      bar.innerHTML = '<span class="ve-toast-progress-bar"></span>';
      el.style.setProperty('--ve-toast-duration', DURATION + 's');
      el.appendChild(bar);
      bar.firstChild.addEventListener('animationend', function () { leave(el); });
    }
    stack().appendChild(el);
    tidy(parent);
  }

  function sweep(root) {
    if (!root || !root.querySelectorAll) return;
    if (root.matches && root.matches(NOTICE)) float(root);
    Array.prototype.forEach.call(root.querySelectorAll(NOTICE), float);
  }

  function start() {
    sweep(document);
    // Notices added later (after a save over AJAX, a plugin's own message):
    // only what was ADDED is looked at, never the whole page again.
    new MutationObserver(function (records) {
      records.forEach(function (r) {
        Array.prototype.forEach.call(r.addedNodes, function (n) { if (n.nodeType === 1) sweep(n); });
      });
    }).observe(document.body, { childList: true, subtree: true });
    window.__veToastsReady = true;
  }

  /* For the Enhancement Studio's Test buttons. A change made in the Studio
     applies to the next notice at once, without a reload. */
  window.veAdminToasts = {
    configure: function (next) {
      next = next || {};
      if (/^(tr|tl|br|bl)$/.test(next.position)) {
        CFG.position = next.position;
        var s = document.getElementById(STACK_ID);
        if (s) s.className = 'pos-' + next.position;
      }
      if (next.duration != null) DURATION = Math.max(3, Math.min(20, Number(next.duration) || 10));
      if (next.persist != null) PERSIST = next.persist !== false;
    },
    demo: function (k) {
      var el = document.createElement('div');
      el.className = 'notice ' + (k === 'error' ? 'notice-error' : k === 'warning' ? 'notice-warning' : 'notice-success') + ' is-dismissible';
      el.innerHTML = '<p><strong>' + (k === 'error' ? 'Could not save.' : k === 'warning' ? 'An update needs your attention.' : 'Settings saved.') + '</strong> ' +
        (k === 'error' ? 'Check your connection and try again.' : k === 'warning' ? 'Warnings stay until you dismiss them.' : 'This one leaves by itself; hover it to pause.') + '</p>';
      var b = document.createElement('button');
      b.type = 'button'; b.className = 'notice-dismiss';
      b.innerHTML = '<span class="screen-reader-text">Dismiss this notice.</span>';
      el.appendChild(b);
      (document.getElementById('wpbody-content') || document.body).appendChild(el);
      float(el);
    }
  };

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', start);
  else start();
})();
