<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * C64, the owner: "set it up." - update ZIPs are verified with a publisher
 * signature before WordPress installs them.
 *
 * Each release in MV's feed carries `sha256` (of its ZIP), `signature`
 * (Ed25519, detached, base64) and `key_id`. The signature is over
 *
 *     mimams-var-wp\n<version>\n<sha256 hex>
 *
 * so it binds that version to that exact file. The private key never leaves
 * the publisher's machine (scripts/sign-release.js); the public key is pinned
 * here. On every update of this plugin - MV's own Install, WordPress's Updates
 * screen, automatic updates, a rollback - the ZIP is downloaded, hashed and
 * checked BEFORE WordPress unpacks it. A modified ZIP, a wrong digest, an
 * unknown key or a release without a signature is refused.
 *
 * A ZIP uploaded by hand under Plugins -> Add New is not this path and is not
 * refused: that is the owner installing a file they chose.
 */
class ReleaseSignature {

    /** key_id => raw Ed25519 public key, base64. key_id is the first 16 hex of sha256(public key). */
    public const KEYS = [
        '697b62adadb6892a' => 'xCTqJJSEwicPaP/vfnbsCkZMiGE3n9vgaDXv4WRLfxc=',
    ];

    /** Where MV's packages are published. */
    public const PACKAGE_HOST = 'https://raw.githubusercontent.com/hebronmimam/mimams-var-releases/';

    public static function register(): void {
        add_filter( 'upgrader_pre_download', [ self::class, 'pre_download' ], 10, 4 );
    }

    public static function message( string $version, string $sha256 ): string {
        return "mimams-var-wp\n" . $version . "\n" . $sha256;
    }

    /**
     * Whether $file is the package $entry describes, signed by a pinned key.
     *
     * @return true|\WP_Error
     */
    public static function verify( string $file, array $entry ) {
        $version = (string) ( $entry['version'] ?? '' );
        if ( '' === (string) ( $entry['signature'] ?? '' ) || '' === (string) ( $entry['sha256'] ?? '' ) ) {
            return new \WP_Error( 'mv_package_unsigned', 'Mimam\'s Var ' . $version . ' is not signed by its publisher, so it was not installed.' );
        }
        $key_id = (string) ( $entry['key_id'] ?? '' );
        if ( ! isset( self::KEYS[ $key_id ] ) ) {
            return new \WP_Error( 'mv_package_signature_key', 'Mimam\'s Var ' . $version . ' is signed with a key this site does not trust, so it was not installed.' );
        }
        $actual = is_readable( $file ) ? (string) hash_file( 'sha256', $file ) : '';
        if ( '' === $actual || ! hash_equals( strtolower( (string) $entry['sha256'] ), $actual ) ) {
            return new \WP_Error( 'mv_package_digest', 'The downloaded Mimam\'s Var ' . $version . ' is not the file its publisher released (its fingerprint does not match), so it was not installed.' );
        }
        $signature  = base64_decode( (string) $entry['signature'], true );
        $public_key = base64_decode( self::KEYS[ $key_id ], true );
        if ( ! function_exists( 'sodium_crypto_sign_verify_detached' ) ) {
            return new \WP_Error( 'mv_package_signature_unavailable', 'This server cannot check release signatures (no sodium), so the update was not installed.' );
        }
        $ok = false;
        try {
            $ok = false !== $signature && 64 === strlen( $signature ) && 32 === strlen( (string) $public_key )
                && sodium_crypto_sign_verify_detached( $signature, self::message( $version, $actual ), $public_key );
        } catch ( \Throwable $e ) {
            $ok = false;
        }
        return $ok ? true : new \WP_Error( 'mv_package_signature', 'Mimam\'s Var ' . $version . ' failed its signature check, so it was not installed.' );
    }

    /**
     * WordPress asks here before downloading any package. For this plugin's own
     * updates - and anything from MV's release host - MV downloads it, checks
     * it, and hands WordPress the checked file; otherwise WordPress carries on.
     *
     * @param mixed $reply
     * @param mixed $package
     * @param mixed $upgrader
     * @param mixed $hook_extra
     * @return mixed
     */
    public static function pre_download( $reply, $package, $upgrader = null, $hook_extra = [] ) {
        if ( false !== $reply || ! is_string( $package ) || '' === $package ) {
            return $reply;
        }
        $mine   = plugin_basename( VE_DIR . 'variable-engine.php' );
        $ours   = ( is_array( $hook_extra ) && isset( $hook_extra['plugin'] ) && $mine === $hook_extra['plugin'] )
            || 0 === strpos( $package, self::PACKAGE_HOST );
        $remote = 1 === preg_match( '!^https?://!i', $package );
        if ( ! $ours || ! $remote ) {
            return $reply;
        }
        $entry = self::entry_for( $package );
        if ( ! $entry ) {
            return new \WP_Error( 'mv_package_unknown', 'That package is not in Mimam\'s Var release feed, so it was not installed.' );
        }
        if ( ! function_exists( 'download_url' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        $file = download_url( $package, 300 );
        if ( is_wp_error( $file ) ) {
            return $file;
        }
        $checked = self::verify( (string) $file, $entry );
        if ( is_wp_error( $checked ) ) {
            wp_delete_file( (string) $file );
            return $checked;
        }
        return $file;
    }

    /** The feed's entry for a package address: the release list first, then the top-level release. */
    private static function entry_for( string $package ): array {
        $updater = new Updater();
        $found   = [];
        /* The cached feed first; the live one when the cache does not know the
           package - or knows it without a signature, which is what a feed cached
           by a build older than this one looks like. */
        foreach ( [ false, true ] as $force ) {
            $manifest = $updater->fetch_manifest( $force );
            if ( is_wp_error( $manifest ) || ! is_array( $manifest ) ) {
                continue;
            }
            $candidates = array_merge( (array) ( $manifest['releases'] ?? [] ), [ $manifest ] );
            foreach ( $candidates as $entry ) {
                if ( is_array( $entry ) && isset( $entry['download_url'] ) && self::same_url( (string) $entry['download_url'], $package ) ) {
                    if ( ! empty( $entry['signature'] ) ) {
                        return $entry;
                    }
                    $found = $entry;
                }
            }
        }
        return $found;
    }

    private static function same_url( string $a, string $b ): bool {
        $strip = static function ( string $u ): string { return strtok( $u, '?' ) ?: $u; };
        return '' !== $a && $strip( $a ) === $strip( $b );
    }
}
