<?php
/**
 * Broken media, found and repaired (B54, direction 1 · Broken as a view).
 *
 * Three kinds of breakage, each found from the evidence that proves it:
 *
 * - file    a media item whose file is gone from the server;
 * - record  a media number pages still use after the item was deleted
 *           (a featured image, a wp-image-N in content, a Bricks image);
 * - url     a link or image in content that points into uploads at a file
 *           that does not exist and that no media item holds.
 *
 * The fixes change only the references a problem lists: relink them to a
 * media item that exists, or take them out. Nothing is deleted from the media
 * library, and every change keeps a copy of what it touched for Undo.
 *
 * @package VariableEngine
 */

namespace VE\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class MediaRepairManager {

    private const POST_LIMIT       = 2000;
    private const ATTACHMENT_LIMIT = 5000;
    private const TREE_KEYS        = [ '_bricks_page_content_2', '_bricks_page_header_2', '_bricks_page_footer_2' ];
    private const UNDO_INDEX       = 've_media_repair_undo';
    private const UNDO_PREFIX      = 've_media_repair_undo_';
    private const UNDO_KEEP        = 5;

    /** @var array<int,array{name:string,stem:string,url:string}>|null */
    private $library = null;

    /* ── finding ─────────────────────────────────────────────────────── */

    /** Every problem, most-used first. */
    public function scan(): array {
        global $wpdb;
        $problems = [];
        $posts    = $this->posts();
        $uploads  = wp_get_upload_dir();
        $base_url = untrailingslashit( (string) $uploads['baseurl'] );
        $base_dir = untrailingslashit( (string) $uploads['basedir'] );

        // 1 · file: the item exists, its file does not.
        foreach ( $this->attachment_ids() as $aid ) {
            $file = (string) get_attached_file( $aid );
            if ( $file && file_exists( $file ) ) {
                continue;
            }
            $name = $file ? wp_basename( $file ) : ( get_the_title( $aid ) ?: 'Media #' . $aid );
            $problems[ 'file-' . $aid ] = [
                'id' => 'file-' . $aid, 'kind' => 'file', 'attachment' => $aid, 'name' => $name,
                'path' => $file ? str_replace( $base_dir, '/uploads', $file ) : 'no file recorded',
                'url' => (string) wp_get_attachment_url( $aid ), 'where' => [],
            ];
        }

        // Every reference the site holds, by post.
        $exists = function ( int $id ): bool {
            return $id > 0 && 'attachment' === get_post_type( $id );
        };
        foreach ( $posts as $post ) {
            $pid   = (int) $post->ID;
            $label = [ 'post' => $pid, 'title' => '' !== $post->post_title ? $post->post_title : '(no title)', 'type' => $this->type_label( $post->post_type ) ];

            $thumb = (int) get_post_meta( $pid, '_thumbnail_id', true );
            if ( $thumb ) {
                $this->note( $problems, $thumb, $exists, $label + [ 'field' => 'featured', 'detail' => 'featured image' ] );
            }

            $content = (string) $post->post_content;
            if ( '' !== $content ) {
                if ( preg_match_all( '/wp-image-(\d+)/', $content, $m ) ) {
                    foreach ( array_unique( array_map( 'intval', $m[1] ) ) as $id ) {
                        $this->note( $problems, $id, $exists, $label + [ 'field' => 'content', 'detail' => 'content' ] );
                    }
                }
                if ( preg_match_all( '#(?:src|href)=["\'](' . preg_quote( $base_url, '#' ) . '/[^"\'?\#]+)#i', $content, $m ) ) {
                    foreach ( array_unique( $m[1] ) as $url ) {
                        $rel  = substr( $url, strlen( $base_url ) );
                        $path = $base_dir . $rel;
                        if ( file_exists( $path ) || file_exists( rawurldecode( $path ) ) ) {
                            continue;
                        }
                        // A link to a media item's own missing file is that item's problem.
                        $owner = (int) attachment_url_to_postid( preg_replace( '/-\d+x\d+(\.[a-z0-9]+)$/i', '$1', $url ) );
                        if ( $owner && isset( $problems[ 'file-' . $owner ] ) ) {
                            $problems[ 'file-' . $owner ]['where'][] = $label + [ 'field' => 'content', 'detail' => 'content' ];
                            continue;
                        }
                        $key = 'url-' . substr( md5( $url ), 0, 12 );
                        if ( ! isset( $problems[ $key ] ) ) {
                            $problems[ $key ] = [ 'id' => $key, 'kind' => 'url', 'attachment' => 0, 'name' => rawurldecode( wp_basename( $url ) ), 'path' => $url, 'url' => $url, 'where' => [] ];
                        }
                        $problems[ $key ]['where'][] = $label + [ 'field' => 'content', 'detail' => 'content' ];
                    }
                }
            }

            foreach ( self::TREE_KEYS as $key ) {
                $tree = get_post_meta( $pid, $key, true );
                if ( ! is_array( $tree ) ) {
                    continue;
                }
                foreach ( $this->tree_images( $tree ) as $id => $file ) {
                    $this->note( $problems, $id, $exists, $label + [ 'field' => 'bricks', 'meta' => $key, 'detail' => 'Bricks image' ], $file );
                }
            }
        }

        foreach ( $problems as $k => $p ) {
            // A file problem nobody uses is still a problem; a record problem always has a place.
            $problems[ $k ]['where']      = array_values( array_map( 'unserialize', array_unique( array_map( 'serialize', $p['where'] ) ) ) );
            $problems[ $k ]['candidates'] = $this->candidates( (string) $p['name'], (int) $p['attachment'] );
            foreach ( $problems[ $k ]['where'] as $i => $w ) {
                $problems[ $k ]['where'][ $i ]['edit'] = (string) get_edit_post_link( (int) $w['post'], 'raw' );
            }
        }
        $list = array_values( $problems );
        usort( $list, static function ( $a, $b ) { return count( $b['where'] ) <=> count( $a['where'] ) ?: strcmp( $a['name'], $b['name'] ); } );
        return [ 'problems' => $list, 'scanned_posts' => count( $posts ), 'limited' => count( $posts ) >= self::POST_LIMIT ];
    }

    /** One problem, fresh, by its id. */
    public function find( string $id ): ?array {
        foreach ( $this->scan()['problems'] as $p ) {
            if ( $p['id'] === $id ) {
                return $p;
            }
        }
        return null;
    }

    /* ── fixing ──────────────────────────────────────────────────────── */

    /** Point every place a problem lists at a media item that exists. */
    public function relink( string $problem_id, int $target ): array {
        $p = $this->find( $problem_id );
        if ( ! $p ) {
            return self::fail( 'gone', 'This problem is no longer there. Rescan to see the current list.' );
        }
        if ( 'attachment' !== get_post_type( $target ) || ! file_exists( (string) get_attached_file( $target ) ) ) {
            return self::fail( 'target', 'Pick a media item whose file is on the server.' );
        }
        return $this->rewrite( $p, $target );
    }

    /** Take the broken references out of every place a problem lists. */
    public function remove( string $problem_id ): array {
        $p = $this->find( $problem_id );
        if ( ! $p ) {
            return self::fail( 'gone', 'This problem is no longer there. Rescan to see the current list.' );
        }
        return $this->rewrite( $p, 0 );
    }

    public function undo( string $token ): array {
        $token = preg_replace( '/[^a-z0-9]/', '', strtolower( $token ) );
        $saved = '' === $token ? null : get_option( self::UNDO_PREFIX . $token, null );
        if ( ! is_array( $saved ) ) {
            return self::fail( 'undo-gone', 'That change can no longer be undone.' );
        }
        foreach ( (array) $saved['posts'] as $pid => $content ) {
            wp_update_post( [ 'ID' => (int) $pid, 'post_content' => wp_slash( (string) $content ) ] );
        }
        foreach ( (array) $saved['meta'] as $m ) {
            if ( null === $m[2] ) {
                delete_post_meta( (int) $m[0], (string) $m[1] );
            } else {
                update_post_meta( (int) $m[0], (string) $m[1], wp_slash( $m[2] ) );
            }
        }
        delete_option( self::UNDO_PREFIX . $token );
        return [ 'ok' => true ];
    }

    /**
     * Change the references a problem lists. $target 0 removes them.
     */
    private function rewrite( array $p, int $target ): array {
        $old_id  = (int) $p['attachment'];
        $old_url = (string) $p['url'];
        $new_url = $target ? (string) wp_get_attachment_url( $target ) : '';
        $saved   = [ 'posts' => [], 'meta' => [] ];
        $changed = 0;

        foreach ( $p['where'] as $w ) {
            $pid = (int) $w['post'];
            if ( 'featured' === $w['field'] ) {
                $saved['meta'][] = [ $pid, '_thumbnail_id', get_post_meta( $pid, '_thumbnail_id', true ) ];
                if ( $target ) {
                    update_post_meta( $pid, '_thumbnail_id', $target );
                } else {
                    delete_post_meta( $pid, '_thumbnail_id' );
                }
                $changed++;
            } elseif ( 'content' === $w['field'] ) {
                $post = get_post( $pid );
                if ( ! $post || isset( $saved['posts'][ $pid ] ) ) {
                    continue;
                }
                $before  = (string) $post->post_content;
                $after   = $target ? $this->relink_content( $before, $old_id, $old_url, $target, $new_url ) : $this->strip_content( $before, $old_id, $old_url );
                if ( $after !== $before ) {
                    $saved['posts'][ $pid ] = $before;
                    wp_update_post( [ 'ID' => $pid, 'post_content' => wp_slash( $after ) ] );
                    $changed++;
                }
            } elseif ( 'bricks' === $w['field'] && ! empty( $w['meta'] ) ) {
                $tree = get_post_meta( $pid, $w['meta'], true );
                if ( ! is_array( $tree ) ) {
                    continue;
                }
                $count = 0;
                $next  = $this->relink_tree( $tree, $old_id, $target, $new_url, $count );
                if ( $count ) {
                    $saved['meta'][] = [ $pid, $w['meta'], $tree ];
                    update_post_meta( $pid, $w['meta'], wp_slash( $next ) );
                    $changed++;
                }
            }
        }
        if ( ! $changed ) {
            return self::fail( 'nothing', 'None of the places listed still use it. Rescan to see the current list.' );
        }
        $token = strtolower( wp_generate_password( 12, false, false ) );
        update_option( self::UNDO_PREFIX . $token, $saved, false );
        $index   = get_option( self::UNDO_INDEX, [] );
        $index   = is_array( $index ) ? $index : [];
        $index[] = $token;
        while ( count( $index ) > self::UNDO_KEEP ) {
            delete_option( self::UNDO_PREFIX . array_shift( $index ) );
        }
        update_option( self::UNDO_INDEX, array_values( $index ), false );
        return [ 'ok' => true, 'changed' => $changed, 'undo' => $token ];
    }

    private function relink_content( string $html, int $old_id, string $old_url, int $new_id, string $new_url ): string {
        if ( $old_id ) {
            $html = str_replace( 'wp-image-' . $old_id . '"', 'wp-image-' . $new_id . '"', $html );
            $html = str_replace( 'wp-image-' . $old_id . ' ', 'wp-image-' . $new_id . ' ', $html );
            $html = preg_replace( '/(<!--\s*wp:image\s*\{[^}]*"id":)' . $old_id . '\b/', '${1}' . $new_id, $html );
        }
        if ( '' !== $old_url && '' !== $new_url ) {
            // The file and its sized copies (name-300x200.jpg) all point at the new file.
            $stem = preg_replace( '/\.[a-z0-9]+$/i', '', $old_url );
            $html = preg_replace( '#' . preg_quote( $stem, '#' ) . '(?:-\d+x\d+)?\.[a-z0-9]+#i', $new_url, $html );
        }
        return $html;
    }

    private function strip_content( string $html, int $old_id, string $old_url ): string {
        $hits = [];
        if ( $old_id ) {
            $hits[] = 'wp-image-' . $old_id;
        }
        if ( '' !== $old_url ) {
            $hits[] = preg_replace( '/\.[a-z0-9]+$/i', '', $old_url );
        }
        foreach ( $hits as $hit ) {
            $q = preg_quote( $hit, '#' );
            // A whole image block that holds it, then a bare <img>, then a link: its words stay.
            $html = preg_replace( '#<!--\s*wp:image\b[^>]*-->(?:(?!<!--\s*/wp:image).)*' . $q . '(?:(?!<!--\s*/wp:image).)*<!--\s*/wp:image\s*-->\s*#s', '', $html );
            $html = preg_replace( '#<img\b[^>]*' . $q . '[^>]*>#i', '', $html );
            $html = preg_replace( '#<a\b[^>]*href=["\'][^"\']*' . $q . '[^"\']*["\'][^>]*>(.*?)</a>#is', '$1', $html );
        }
        return $html;
    }

    /** Bricks image values: `{id, url, ...}`. $new_id 0 empties them. */
    private function relink_tree( array $node, int $old_id, int $new_id, string $new_url, int &$count ): array {
        if ( isset( $node['id'], $node['url'] ) && is_scalar( $node['id'] ) && (int) $node['id'] === $old_id && $old_id > 0 ) {
            $count++;
            if ( ! $new_id ) {
                return [];
            }
            $node['id']  = $new_id;
            $node['url'] = $new_url;
            if ( isset( $node['full'] ) ) {
                $node['full'] = $new_url;
            }
            if ( isset( $node['filename'] ) ) {
                $node['filename'] = wp_basename( $new_url );
            }
            return $node;
        }
        foreach ( $node as $k => $v ) {
            if ( is_array( $v ) ) {
                $node[ $k ] = $this->relink_tree( $v, $old_id, $new_id, $new_url, $count );
            }
        }
        return $node;
    }

    /* ── pieces ──────────────────────────────────────────────────────── */

    private static function fail( string $code, string $message ): array {
        return [ 'ok' => false, 'code' => $code, 'message' => $message ];
    }

    /** A reference to $id: fine, or the item's file is gone (file), or the item is gone (record). */
    private function note( array &$problems, int $id, callable $exists, array $where, string $file = '' ): void {
        if ( ! $exists( $id ) ) {
            $key = 'record-' . $id;
            if ( ! isset( $problems[ $key ] ) ) {
                $problems[ $key ] = [ 'id' => $key, 'kind' => 'record', 'attachment' => $id, 'name' => 'Media #' . $id, 'path' => 'media ' . $id . ' was deleted', 'url' => '', 'where' => [] ];
            }
            // A Bricks image still knows the file it showed: name it, and match by it.
            if ( '' !== $file && 0 === strpos( $problems[ $key ]['name'], 'Media #' ) ) {
                $problems[ $key ]['name'] = $file;
                $problems[ $key ]['path'] = 'media ' . $id . ' (' . $file . ') was deleted';
            }
            $problems[ $key ]['where'][] = $where;
            return;
        }
        if ( isset( $problems[ 'file-' . $id ] ) ) {
            $problems[ 'file-' . $id ]['where'][] = $where;
        }
    }

    /** Bricks image values in a tree: media id => the file it names. */
    private function tree_images( array $node ): array {
        $ids = [];
        if ( isset( $node['id'], $node['url'] ) && is_scalar( $node['id'] ) && (int) $node['id'] > 0 && is_string( $node['url'] ) ) {
            $ids[ (int) $node['id'] ] = (string) ( $node['filename'] ?? wp_basename( (string) $node['url'] ) );
        }
        foreach ( $node as $v ) {
            if ( is_array( $v ) ) {
                $ids = $this->tree_images( $v ) + $ids;
            }
        }
        return $ids;
    }

    private function posts(): array {
        global $wpdb;
        return (array) $wpdb->get_results(
            "SELECT ID, post_title, post_type, post_content FROM {$wpdb->posts}
             WHERE post_type NOT IN ('attachment','revision','nav_menu_item','customize_changeset','oembed_cache','wp_global_styles')
               AND post_status NOT IN ('trash','auto-draft','inherit')
             ORDER BY post_modified_gmt DESC LIMIT " . self::POST_LIMIT
        );
    }

    private function attachment_ids(): array {
        global $wpdb;
        return array_map( 'intval', (array) $wpdb->get_col( "SELECT ID FROM {$wpdb->posts} WHERE post_type = 'attachment' ORDER BY ID DESC LIMIT " . self::ATTACHMENT_LIMIT ) );
    }

    private function type_label( string $type ): string {
        $obj = get_post_type_object( $type );
        return $obj ? (string) $obj->labels->singular_name : $type;
    }

    /** name → stem: no extension, no -300x200, no -scaled, no -1 duplicate suffix. */
    public static function stem( string $name ): string {
        $s = strtolower( preg_replace( '/\.[a-z0-9]+$/i', '', $name ) );
        $s = preg_replace( '/-(\d+x\d+|scaled|rotated|e\d{10,})$/', '', $s );
        return preg_replace( '/-\d$/', '', $s );
    }

    /** Up to three media items worth relinking to, best first, each with why. */
    public function candidates( string $name, int $except = 0 ): array {
        if ( null === $this->library ) {
            $this->library = [];
            foreach ( $this->attachment_ids() as $id ) {
                $file = (string) get_attached_file( $id );
                if ( ! $file || ! file_exists( $file ) ) {
                    continue;
                }
                $n                    = wp_basename( $file );
                $this->library[ $id ] = [ 'name' => $n, 'stem' => self::stem( $n ), 'url' => (string) wp_get_attachment_url( $id ) ];
            }
        }
        $want  = self::stem( $name );
        $lower = strtolower( $name );
        $out   = [];
        if ( '' === $want || 0 === strpos( $want, 'media #' ) ) {
            return [];
        }
        foreach ( $this->library as $id => $item ) {
            if ( $id === $except ) {
                continue;
            }
            if ( strtolower( $item['name'] ) === $lower ) {
                $score = 98; $why = 'same name';
            } elseif ( $item['stem'] === $want ) {
                $score = 92; $why = 'same name, other format or size';
            } else {
                similar_text( $want, $item['stem'], $pct );
                if ( $pct < 70 ) {
                    continue;
                }
                $score = (int) round( $pct * 0.9 ); $why = 'similar name';
            }
            $out[] = [ 'id' => (int) $id, 'name' => $item['name'], 'score' => $score, 'why' => $why, 'url' => $item['url'] ];
        }
        usort( $out, static function ( $a, $b ) { return $b['score'] <=> $a['score']; } );
        return array_slice( $out, 0, 3 );
    }
}
