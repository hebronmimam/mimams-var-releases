<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

class Updater {

    const SLUG = 'variable-engine';
    const LEGACY_FEED_URL = 'https://raw.githubusercontent.com/hebronmimam/mimams-var-releases/main/updates/mimams-var-wp.json';
    const DEFAULT_FEED_URL = 'https://api.github.com/repos/hebronmimam/mimams-var-releases/contents/updates/mimams-var-wp.json?ref=main';
    /**
     * PRIMARY feeds: raw.githubusercontent. It serves the manifest as plain JSON with no
     * authentication and no rate limit.
     *
     * These used to point at api.github.com, whose unauthenticated limit is 60 requests
     * per hour per IP — a normal day of update checks exhausts it and every check then
     * fails with "403 API rate limit exceeded", surfaced as "Update feed blocked". The
     * API endpoints are kept below as a fallback only.
     */
    const CHANNEL_FEEDS = [
        'stable' => self::LEGACY_FEED_URL,
        'beta'   => 'https://raw.githubusercontent.com/hebronmimam/mimams-var-releases/main/updates/mimams-var-wp-beta.json',
        'dev'    => 'https://raw.githubusercontent.com/hebronmimam/mimams-var-releases/main/updates/mimams-var-wp-dev.json',
    ];
    /** FALLBACK feeds: the GitHub contents API, used only if the raw host is unreachable. */
    const RAW_CHANNEL_FEEDS = [
        'stable' => self::DEFAULT_FEED_URL,
        'beta'   => 'https://api.github.com/repos/hebronmimam/mimams-var-releases/contents/updates/mimams-var-wp-beta.json?ref=main',
        'dev'    => 'https://api.github.com/repos/hebronmimam/mimams-var-releases/contents/updates/mimams-var-wp-dev.json?ref=main',
    ];

    public static function feed_url_for_channel( string $channel ): string {
        $channel = sanitize_key( $channel );
        return self::CHANNEL_FEEDS[ $channel ] ?? self::LEGACY_FEED_URL;
    }

    /** The alternate feed tried when the primary fails. */
    public static function raw_feed_url_for_channel( string $channel ): string {
        $channel = sanitize_key( $channel );
        return self::RAW_CHANNEL_FEEDS[ $channel ] ?? self::DEFAULT_FEED_URL;
    }

    /**
     * Stable and Dev are the product's active channels. Beta remains in the
     * feed map only so an existing site can leave it safely; a fresh setting
     * must never opt into that retired channel.
     */
    public static function sanitize_update_channel( string $requested, string $previous = 'stable' ): string {
        $requested = sanitize_key( $requested );
        $previous = sanitize_key( $previous );
        if ( in_array( $requested, [ 'stable', 'dev' ], true ) ) {
            return $requested;
        }
        return 'beta' === $requested && 'beta' === $previous ? 'beta' : 'stable';
    }

    public function register(): void {
        if ( ! is_admin() ) {
            return;
        }

        if ( function_exists( 'add_filter' ) ) {
            add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'inject_update' ] );
            add_filter( 'site_transient_update_plugins', [ $this, 'inject_update' ] );
            add_filter( 'plugins_api', [ $this, 'plugin_info' ], 10, 3 );
            add_filter( 'auto_update_plugin', [ $this, 'auto_update' ], 10, 2 );
            add_action( 'delete_site_transient_update_plugins', [ $this, 'clear_cache' ] );
            add_action( 'upgrader_process_complete', [ $this, 'upgrader_complete' ], 10, 2 );
            add_action( 'admin_init', [ $this, 'prime_native_update_screen' ], 2 );
        }
    }

    /**
     * How long a fetched manifest may be trusted.
     *
     * Dev is the channel releases are verified on, so a six-hour cache there
     * means a build can be published and invisible for most of a working day.
     * Beta and Stable move rarely and keep the long cache. The webhook in
     * ReleaseWebhook closes the gap entirely when it is configured; this is the
     * floor for sites that have not set one up, or that missed a delivery.
     */
    private function manifest_ttl( string $channel ): int {
        return 'dev' === $channel ? 5 * MINUTE_IN_SECONDS : 6 * HOUR_IN_SECONDS;
    }

    public function clear_cache(): void {
        delete_transient( 've_update_manifest' );
        foreach ( array_keys( self::CHANNEL_FEEDS ) as $channel ) {
            delete_transient( $this->manifest_cache_key( $channel, self::feed_url_for_channel( $channel ) ) );
            delete_transient( $this->manifest_cache_key( $channel, self::raw_feed_url_for_channel( $channel ) ) );
        }
    }

    /**
     * B36, 2026-09-29 (the audit): every builder load asked this, and it always
     * fetched the manifest from GitHub fresh - about a second of MV's own time
     * before the panel had its update line, measured on test7. A check nobody
     * asked for now reads the cached manifest (5 minutes on Dev, 6 hours on
     * Stable); "Check for updates", and the release webhook, still force it.
     */
    public function check_now( bool $force = true ): array {
        if ( $force ) {
            $this->clear_cache();
            if ( function_exists( 'wp_clean_plugins_cache' ) ) {
                wp_clean_plugins_cache();
            }
        }

        $settings = $this->settings();
        $channel = sanitize_key( (string) ( $settings['update_channel'] ?? 'stable' ) );
        $manifest = $this->fetch_manifest( $force );
        if ( is_wp_error( $manifest ) ) {
            $error_data = $manifest->get_error_data();
            return [
                'configured'        => false,
                'current_version'   => VE_VERSION,
                'latest_version'    => VE_VERSION,
                'update_available'  => false,
                'update_channel'    => $channel,
                'code'              => $manifest->get_error_code(),
                'message'           => $manifest->get_error_message(),
                'error_details'     => is_array( $error_data ) ? $error_data : [],
            ];
        }

        $channel = sanitize_key( (string) ( $manifest['channel'] ?? $channel ) );
        $latest = isset( $manifest['version'] ) ? (string) $manifest['version'] : VE_VERSION;
        $this->sync_native_update_transient( $manifest );

        $legacy_beta_migrated = ! empty( $manifest['legacy_beta_migrated'] );
        return [
            'configured'        => true,
            'current_version'   => VE_VERSION,
            'latest_version'    => $latest,
            'update_available'  => version_compare( $latest, VE_VERSION, '>' ),
            'update_channel'    => $channel,
            'download_url'      => isset( $manifest['download_url'] ) ? (string) $manifest['download_url'] : '',
            'details_url'       => isset( $manifest['details_url'] ) ? (string) $manifest['details_url'] : '',
            'feed_url'          => isset( $manifest['feed_url'] ) ? (string) $manifest['feed_url'] : '',
            'feed_fallback'     => isset( $manifest['feed_fallback'] ) ? (string) $manifest['feed_fallback'] : '',
            // The same list also went out as `release_history`: 500 releases,
            // twice, on every builder load (446 kB). It goes once now, with only
            // what the release list shows; signatures and hashes stay here,
            // where an install is verified.
            'releases'          => self::releases_for_panel( $manifest['releases'] ?? [] ),
            'update_admin_url'  => $this->update_admin_url(),
            'message'           => $legacy_beta_migrated
                ? 'Stable has caught up. This site has left the retired Beta channel.'
                : ( version_compare( $latest, VE_VERSION, '>' ) ? 'Update available.' : 'Already up to date.' ),
        ];
    }

    /** B36: the release list as the panel shows it - version, label, date and the ZIP link. */
    public static function releases_for_panel( $releases ): array {
        $out = [];
        foreach ( is_array( $releases ) ? $releases : [] as $release ) {
            if ( ! is_array( $release ) || empty( $release['version'] ) ) {
                continue;
            }
            $out[] = [
                'version'      => (string) $release['version'],
                'label'        => (string) ( $release['label'] ?? '' ),
                'created_at'   => (string) ( ( $release['created_at'] ?? '' ) ?: ( $release['date'] ?? '' ) ),
                'download_url' => (string) ( $release['download_url'] ?? '' ),
            ];
        }
        return $out;
    }

    public function install_available_update( string $target_version = '' ) {
        if ( function_exists( 'current_user_can' ) && ! current_user_can( 'update_plugins' ) ) {
            return new \WP_Error( 've_update_forbidden', 'You do not have permission to update plugins.', [ 'status' => 403 ] );
        }

        $manifest = $this->fetch_manifest( true );
        if ( is_wp_error( $manifest ) ) {
            return $manifest;
        }

        $latest = (string) ( $manifest['version'] ?? VE_VERSION );
        $manifest_latest_version = $latest;
        $package = $manifest;
        $is_targeted_release = false;

        if ( '' !== trim( $target_version ) ) {
            $is_targeted_release = true;
            $target_version = sanitize_text_field( trim( $target_version ) );
            $package = $this->find_release_package( $manifest, $target_version );
            if ( empty( $package ) ) {
                return new \WP_Error( 've_update_release_missing', 'That release is not available on the selected channel.', [ 'status' => 404 ] );
            }
            $latest = (string) ( $package['version'] ?? $target_version );
        }

        if ( $is_targeted_release && 0 === version_compare( $latest, VE_VERSION ) ) {
            return [
                'updated'          => false,
                'refresh_required' => false,
                'version'          => VE_VERSION,
                'message'          => "Mimam's Var v{$latest} is already installed.",
            ];
        }

        if ( ! $is_targeted_release && ! version_compare( $latest, VE_VERSION, '>' ) ) {
            return [
                'updated'          => false,
                'refresh_required' => false,
                'version'          => VE_VERSION,
                'message'          => 'Mimam\'s Var is already up to date.',
            ];
        }
        if ( empty( $manifest['download_url'] ) ) {
            return new \WP_Error( 've_update_missing_package', 'The update manifest does not include a package URL.', [ 'status' => 500 ] );
        }
        if ( ! empty( $package['download_url'] ) && $package !== $manifest ) {
            $manifest['version'] = $latest;
            $manifest['download_url'] = (string) $package['download_url'];
            if ( ! empty( $package['details_url'] ) ) {
                $manifest['details_url'] = (string) $package['details_url'];
            }
        }
        $is_rollback = version_compare( $latest, VE_VERSION, '<' );
        // Still the version this request started on: the new files are not loaded until the next one.
        $updated_from = (string) VE_VERSION;

        if ( ! function_exists( 'request_filesystem_credentials' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        if ( ! class_exists( '\Plugin_Upgrader' ) ) {
            require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        }
        if ( ! function_exists( 'get_plugin_data' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugin_file = $this->plugin_file();
        $was_network_active = function_exists( 'is_plugin_active_for_network' ) && is_plugin_active_for_network( $plugin_file );
        $was_site_active = function_exists( 'is_plugin_active' ) && is_plugin_active( $plugin_file );
        $activation_scope = self::activation_scope( $was_site_active, $was_network_active );

        $this->sync_native_update_transient( $manifest, $is_targeted_release );
        $skin = new \Automatic_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader( $skin );
        $result = $upgrader->upgrade( $plugin_file );

        if ( is_wp_error( $result ) ) {
            return $result;
        }
        if ( false === $result ) {
            $errors = $skin->get_errors();
            if ( is_wp_error( $errors ) && $errors->has_errors() ) {
                return $errors;
            }
            return new \WP_Error( 've_update_failed', 'WordPress could not install the plugin update.', [ 'status' => 500 ] );
        }

        $this->clear_cache();
        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
            wp_clean_plugins_cache( true );
        }

        $activation_result = $this->restore_activation_state( $plugin_file, $activation_scope );
        if ( is_wp_error( $activation_result ) ) {
            return $activation_result;
        }

        $installed_version = $latest;
        if ( file_exists( VE_FILE ) ) {
            $plugin_data = get_plugin_data( VE_FILE, false, false );
            if ( ! empty( $plugin_data['Version'] ) ) {
                $installed_version = (string) $plugin_data['Version'];
            }
        }

        return [
            'updated'          => true,
            'refresh_required' => true,
            'version'          => $installed_version,
            'rollback'         => $is_rollback,
            'release_notes'    => 0 === version_compare( $latest, $manifest_latest_version ) ? $this->release_notes_from_manifest( $manifest ) : [],
            /* R65: every release between the one this site ran and the one it now has. */
            'release_notes_since' => $is_rollback ? [] : self::release_notes_between( (string) ( $manifest['sections']['changelog'] ?? '' ), $updated_from, $installed_version ),
            'updated_from'     => $updated_from,
            'message'          => $is_rollback ? "Mimam's Var was rolled back to v{$installed_version}. Refresh required." : "Mimam's Var v{$installed_version} was installed successfully.",
        ];
    }

    /**
     * Return only the newest release's bullets for the post-install decision card.
     * The manifest changelog is owned by MV and always starts with the current
     * release heading followed by its list; older releases must not flood the UI.
     */
    private function release_notes_from_manifest( array $manifest ): array {
        $html = isset( $manifest['sections']['changelog'] ) ? (string) $manifest['sections']['changelog'] : '';
        if ( '' === trim( $html ) || ! preg_match( '/<h4[^>]*>.*?<\/h4>\s*<ul[^>]*>(.*?)<\/ul>/is', $html, $list_match ) ) {
            return [];
        }
        if ( ! preg_match_all( '/<li[^>]*>(.*?)<\/li>/is', (string) $list_match[1], $item_matches ) ) {
            return [];
        }
        $notes = [];
        foreach ( array_slice( (array) $item_matches[1], 0, 5 ) as $item ) {
            $note = trim( html_entity_decode( wp_strip_all_tags( (string) $item ), ENT_QUOTES, 'UTF-8' ) );
            if ( '' !== $note ) {
                $notes[] = $note;
            }
        }
        return $notes;
    }

    /**
     * R65, the owner: "I'm currently on dev.201 updating to dev.206, but then it
     * only showed the last what changed, instead it should show the changes for
     * all missed updates till the current update."
     *
     * The manifest changelog holds every release, newest first, as
     * `<h4>v1.4.0-dev.206 &mdash; Dev</h4><ul><li>..</li></ul>`. This returns the
     * ones after $from up to and including $to, newest first, each with its
     * bullets as plain text. Capped so a site many months behind still gets a
     * card, not a book.
     *
     * @return array<int, array{version: string, notes: string[]}>
     */
    public static function release_notes_between( string $html, string $from, string $to ): array {
        if ( '' === trim( $html ) || '' === $from || '' === $to ) {
            return [];
        }
        if ( ! preg_match_all( '/<h4[^>]*>\s*v?([0-9][0-9A-Za-z.\-]*)[^<]*<\/h4>\s*<ul[^>]*>(.*?)<\/ul>/is', $html, $blocks, PREG_SET_ORDER ) ) {
            return [];
        }
        $out  = [];
        $seen = [];
        foreach ( $blocks as $block ) {
            $version = (string) $block[1];
            if ( isset( $seen[ $version ] ) || version_compare( $version, $from, '<=' ) || version_compare( $version, $to, '>' ) ) {
                continue;
            }
            $seen[ $version ] = true;
            $notes = [];
            if ( preg_match_all( '/<li[^>]*>(.*?)<\/li>/is', (string) $block[2], $items ) ) {
                foreach ( array_slice( (array) $items[1], 0, 6 ) as $item ) {
                    $note = trim( html_entity_decode( wp_strip_all_tags( (string) $item ), ENT_QUOTES, 'UTF-8' ) );
                    if ( '' !== $note ) {
                        $notes[] = $note;
                    }
                }
            }
            if ( $notes ) {
                $out[] = [ 'version' => $version, 'notes' => $notes ];
            }
            if ( count( $out ) >= 40 ) {
                break;
            }
        }
        return $out;
    }

    public static function activation_scope( bool $site_active, bool $network_active ): string {
        if ( $network_active ) {
            return 'network';
        }
        return $site_active ? 'site' : 'inactive';
    }

    /** Map updater errors to the approved eight-step B79 ledger. */
    public static function failure_step_for_code( string $code ): int {
        $code = strtolower( $code );
        if ( preg_match( '/feed|license|forbidden/', $code ) ) {
            return 0;
        }
        if ( preg_match( '/release|missing_package|manifest/', $code ) ) {
            return 1;
        }
        if ( preg_match( '/download|http|ssl|signature/', $code ) ) {
            return 3;
        }
        if ( preg_match( '/zip|unpack|incompatible|archive/', $code ) ) {
            return 4;
        }
        if ( preg_match( '/activat/', $code ) ) {
            return 6;
        }
        return 5;
    }

    private function restore_activation_state( string $plugin_file, string $activation_scope ) {
        if ( 'inactive' === $activation_scope ) {
            return true;
        }
        if ( ! function_exists( 'activate_plugin' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        if ( 'network' === $activation_scope ) {
            $is_active = function_exists( 'is_plugin_active_for_network' ) && is_plugin_active_for_network( $plugin_file );
            if ( ! $is_active ) {
                $activated = activate_plugin( $plugin_file, '', true, true );
                if ( is_wp_error( $activated ) ) {
                    return new \WP_Error(
                        've_update_reactivation_failed',
                        'The update installed, but WordPress could not restore network activation: ' . $activated->get_error_message(),
                        [ 'status' => 500 ]
                    );
                }
            }
            return true;
        }

        $is_active = function_exists( 'is_plugin_active' ) && is_plugin_active( $plugin_file );
        if ( 'site' === $activation_scope && ! $is_active ) {
            $activated = activate_plugin( $plugin_file, '', false, true );
            if ( is_wp_error( $activated ) ) {
                return new \WP_Error(
                    've_update_reactivation_failed',
                    'The update installed, but WordPress could not reactivate Mimam\'s Var: ' . $activated->get_error_message(),
                    [ 'status' => 500 ]
                );
            }
        }

        return true;
    }

    public function prime_native_update_screen(): void {
        global $pagenow;

        if ( ! in_array( (string) $pagenow, [ 'plugins.php', 'update-core.php' ], true ) ) {
            return;
        }
        if ( function_exists( 'current_user_can' ) && ! current_user_can( 'update_plugins' ) ) {
            return;
        }

        $manifest = $this->fetch_manifest( true );
        if ( ! is_wp_error( $manifest ) ) {
            $this->sync_native_update_transient( $manifest );
        }
    }

    public function inject_update( $transient ) {
        if ( ! is_object( $transient ) ) {
            $transient = new \stdClass();
        }
        if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
            $transient->response = [];
        }
        if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
            $transient->no_update = [];
        }

        $manifest = $this->fetch_manifest();
        if ( is_wp_error( $manifest ) ) {
            return $transient;
        }

        $item = $this->update_item( $manifest );
        $file = $this->plugin_file();
        if ( ! isset( $transient->checked ) || ! is_array( $transient->checked ) ) {
            $transient->checked = [];
        }
        $transient->checked[ $file ] = VE_VERSION;

        if ( version_compare( (string) $manifest['version'], VE_VERSION, '>' ) ) {
            $transient->response[ $file ] = $item;
            if ( isset( $transient->no_update[ $file ] ) ) {
                unset( $transient->no_update[ $file ] );
            }
        } else {
            $transient->no_update[ $file ] = $item;
            if ( isset( $transient->response[ $file ] ) ) {
                unset( $transient->response[ $file ] );
            }
        }

        return $transient;
    }

    public function plugin_info( $result, $action, $args ) {
        if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
            return $result;
        }

        $manifest = $this->fetch_manifest();
        if ( is_wp_error( $manifest ) ) {
            return $result;
        }

        return (object) [
            'name'          => "Mimam's Var - WP",
            'slug'          => self::SLUG,
            'version'       => (string) $manifest['version'],
            'author'        => '<a href="https://hebronmimam.com">Hebronmimam</a>',
            'homepage'      => isset( $manifest['details_url'] ) ? (string) $manifest['details_url'] : '',
            'requires'      => isset( $manifest['requires'] ) ? (string) $manifest['requires'] : '6.0',
            'tested'        => isset( $manifest['tested'] ) ? (string) $manifest['tested'] : '',
            'requires_php'  => isset( $manifest['requires_php'] ) ? (string) $manifest['requires_php'] : '7.4',
            'download_link' => isset( $manifest['download_url'] ) ? (string) $manifest['download_url'] : '',
            'sections'      => isset( $manifest['sections'] ) && is_array( $manifest['sections'] ) ? $manifest['sections'] : [ 'changelog' => '' ],
        ];
    }

    public function auto_update( $update, $item ) {
        if ( empty( $item->plugin ) || $this->plugin_file() !== $item->plugin ) {
            return $update;
        }

        $settings = $this->settings();
        return ! empty( $settings['auto_update'] );
    }

    public function fetch_manifest( bool $force = false ) {
        $settings = $this->settings();
        // Infrastructure endpoint: the constant (optionally set in wp-config.php) wins
        // over any legacy stored setting.
        // The feed is infrastructure, not a setting. Only an explicit wp-config constant
        // may override it; otherwise always use the built-in per-channel feed.
        // NOTE: the old editable "Update feed URL" field is gone, but sites that used it
        // still have a stale value stored (often a bare repo URL with no manifest path).
        // Reading that back is what blocked updates, so the stored value is ignored.
        $url     = defined( 'VE_UPDATE_FEED_URL' ) && VE_UPDATE_FEED_URL ? (string) VE_UPDATE_FEED_URL : '';
        $channel = sanitize_key( (string) ( $settings['update_channel'] ?? 'stable' ) );

        if ( '' === $url || self::LEGACY_FEED_URL === $url ) {
            $url = self::feed_url_for_channel( $channel );
        }
        $cache_key = $this->manifest_cache_key( $channel, $url );

        if ( ! $force ) {
            $cached = get_transient( $cache_key );
            if ( is_array( $cached ) && ! empty( $cached['version'] ) ) {
                return $this->maybe_migrate_legacy_beta_manifest( $cached, $force );
            }
        }

        $manifest = $this->request_manifest( $url, $channel, $force, $cache_key );
        if ( ! is_wp_error( $manifest ) ) {
            return $this->maybe_migrate_legacy_beta_manifest( $manifest, $force );
        }

        if ( $this->is_official_channel_feed( $url ) ) {
            $fallback_url = self::raw_feed_url_for_channel( $channel );
            $fallback_key = $this->manifest_cache_key( $channel, $fallback_url );
            $fallback = $this->request_manifest( $fallback_url, $channel, $force, $fallback_key );
            if ( ! is_wp_error( $fallback ) ) {
                $fallback['feed_fallback'] = 'raw';
                $fallback['primary_feed_error'] = $manifest->get_error_message();
                set_transient( $fallback_key, $fallback, $this->manifest_ttl( $channel ) );
                return $this->maybe_migrate_legacy_beta_manifest( $fallback, $force );
            }

            return new \WP_Error(
                've_update_feed_blocked',
                "Mimam's Var could not reach the selected update feed. Allow api.github.com and raw.githubusercontent.com in WordPress, hosting, firewall, or security-plugin HTTP rules, then try again.",
                [
                    'status'           => 502,
                    'primary_url'      => $url,
                    'fallback_url'     => $fallback_url,
                    'primary_message'  => $manifest->get_error_message(),
                    'fallback_message' => $fallback->get_error_message(),
                    'hosts'            => [ 'api.github.com', 'raw.githubusercontent.com' ],
                ]
            );
        }

        return new \WP_Error(
            've_update_feed_unreachable',
            "Mimam's Var could not reach the custom update feed. Check the feed URL or hosting HTTP rules, then try again.",
            [
                'status'  => 502,
                'url'     => $url,
                'message' => $manifest->get_error_message(),
            ]
        );
    }

    /**
     * Retire a saved Beta selection only after Stable is at least as new as
     * both the Beta feed and the installed plugin. Until then Beta remains a
     * compatibility endpoint and is never redirected to Dev or downgraded.
     */
    private function maybe_migrate_legacy_beta_manifest( array $beta_manifest, bool $force ): array {
        $settings = $this->settings();
        if ( 'beta' !== sanitize_key( (string) ( $settings['update_channel'] ?? 'stable' ) ) ) {
            return $beta_manifest;
        }
        if ( defined( 'VE_UPDATE_FEED_URL' ) && VE_UPDATE_FEED_URL && self::LEGACY_FEED_URL !== VE_UPDATE_FEED_URL ) {
            return $beta_manifest;
        }

        $stable_url = self::feed_url_for_channel( 'stable' );
        $stable_key = $this->manifest_cache_key( 'stable', $stable_url );
        $stable_manifest = $force ? false : get_transient( $stable_key );
        if ( ! is_array( $stable_manifest ) || empty( $stable_manifest['version'] ) ) {
            $stable_manifest = $this->request_manifest( $stable_url, 'stable', $force, $stable_key );
        }
        if ( is_wp_error( $stable_manifest ) ) {
            return $beta_manifest;
        }

        $stable_version = (string) ( $stable_manifest['version'] ?? '0' );
        $beta_version = (string) ( $beta_manifest['version'] ?? VE_VERSION );
        if ( version_compare( $stable_version, $beta_version, '<' ) || version_compare( $stable_version, VE_VERSION, '<' ) ) {
            return $beta_manifest;
        }

        $settings['update_channel'] = 'stable';
        $settings['update_url'] = $stable_url;
        update_option( 've_settings', $settings );
        $stable_manifest['legacy_beta_migrated'] = true;
        return $stable_manifest;
    }

    private function request_manifest( string $url, string $channel, bool $force, string $cache_key ) {
        $request_url = $force ? $this->cache_bust_url( $url ) : $url;
        $accept = false !== strpos( $request_url, 'api.github.com/repos/hebronmimam/mimams-var-releases/contents/' ) ? 'application/vnd.github.raw' : 'application/json';

        $response = wp_remote_get( $request_url, [
            'timeout' => 12,
            'headers' => [
                'Accept'     => $accept,
                'User-Agent' => "Mimam's Var - WP/" . VE_VERSION . '; ' . home_url(),
            ],
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) {
            return new \WP_Error( 've_update_http_error', 'Update feed returned HTTP ' . $code . '.', [ 'status' => $code, 'url' => $url ] );
        }

        $body_raw = wp_remote_retrieve_body( $response );
        $body = json_decode( $body_raw, true );
        if ( is_array( $body ) && isset( $body['content'], $body['encoding'] ) && 'base64' === $body['encoding'] ) {
            $decoded = base64_decode( (string) $body['content'], true );
            if ( false !== $decoded ) {
                $body = json_decode( $decoded, true );
            }
        }
        if ( ! is_array( $body ) || empty( $body['version'] ) ) {
            return new \WP_Error( 've_update_bad_manifest', 'Update feed JSON must include a version.', [ 'status' => 500, 'url' => $url ] );
        }

        $manifest = $this->sanitize_manifest( $body, $channel, $url );

        set_transient( $cache_key, $manifest, $this->manifest_ttl( $channel ) );

        return $manifest;
    }

    private function sanitize_manifest( array $body, string $channel, string $feed_url ): array {
        $manifest = [
            'version'       => sanitize_text_field( (string) $body['version'] ),
            'download_url'  => esc_url_raw( isset( $body['download_url'] ) ? (string) $body['download_url'] : ( isset( $body['package'] ) ? (string) $body['package'] : '' ) ),
            'details_url'   => esc_url_raw( isset( $body['details_url'] ) ? (string) $body['details_url'] : ( isset( $body['url'] ) ? (string) $body['url'] : '' ) ),
            'requires'      => sanitize_text_field( isset( $body['requires'] ) ? (string) $body['requires'] : '6.0' ),
            'tested'        => sanitize_text_field( isset( $body['tested'] ) ? (string) $body['tested'] : '' ),
            'requires_php'  => sanitize_text_field( isset( $body['requires_php'] ) ? (string) $body['requires_php'] : '7.4' ),
            'sections'      => isset( $body['sections'] ) && is_array( $body['sections'] ) ? $body['sections'] : [ 'changelog' => wp_kses_post( isset( $body['changelog'] ) ? (string) $body['changelog'] : '' ) ],
            'channel'       => sanitize_key( $channel ),
            'feed_url'      => esc_url_raw( $feed_url ),
        ] + self::sanitize_signature( $body );

        $manifest['releases'] = $this->sanitize_releases( $body, $manifest, $channel );
        return $manifest;
    }

    private function sanitize_releases( array $body, array $manifest, string $channel ): array {
        $raw_releases = isset( $body['releases'] ) && is_array( $body['releases'] ) ? $body['releases'] : [];
        if ( empty( $raw_releases ) ) {
            $raw_releases = [ $manifest ];
        }

        $releases = [];
        foreach ( $raw_releases as $release ) {
            if ( ! is_array( $release ) || empty( $release['version'] ) ) {
                continue;
            }
            $version = sanitize_text_field( (string) $release['version'] );
            $download_url = esc_url_raw( isset( $release['download_url'] ) ? (string) $release['download_url'] : ( isset( $release['package'] ) ? (string) $release['package'] : '' ) );
            if ( '' === $download_url ) {
                continue;
            }
            $releases[] = [
                'version'      => $version,
                'download_url' => $download_url,
                'details_url'  => esc_url_raw( isset( $release['details_url'] ) ? (string) $release['details_url'] : (string) ( $manifest['details_url'] ?? '' ) ),
                'label'        => sanitize_text_field( isset( $release['label'] ) ? (string) $release['label'] : 'v' . $version ),
                'channel'      => sanitize_key( isset( $release['channel'] ) ? (string) $release['channel'] : $channel ),
                'created_at'   => sanitize_text_field( isset( $release['created_at'] ) ? (string) $release['created_at'] : '' ),
            ] + self::sanitize_signature( $release );
        }

        usort( $releases, static function ( $a, $b ) {
            return version_compare( (string) $b['version'], (string) $a['version'] );
        } );

        return $releases;
    }

    /** C64 - what ReleaseSignature checks a package against, kept exactly and nothing else. */
    private static function sanitize_signature( array $entry ): array {
        $out = [];
        if ( isset( $entry['sha256'] ) && preg_match( '/^[a-f0-9]{64}$/i', (string) $entry['sha256'] ) ) {
            $out['sha256'] = strtolower( (string) $entry['sha256'] );
        }
        if ( isset( $entry['signature'] ) && preg_match( '#^[A-Za-z0-9+/]+={0,2}$#', (string) $entry['signature'] ) ) {
            $out['signature'] = (string) $entry['signature'];
        }
        if ( isset( $entry['key_id'] ) && preg_match( '/^[a-f0-9]{16}$/', (string) $entry['key_id'] ) ) {
            $out['key_id'] = (string) $entry['key_id'];
        }
        return $out;
    }

    private function find_release_package( array $manifest, string $target_version ): array {
        $releases = isset( $manifest['releases'] ) && is_array( $manifest['releases'] ) ? $manifest['releases'] : [];
        foreach ( $releases as $release ) {
            if ( is_array( $release ) && isset( $release['version'] ) && 0 === version_compare( (string) $release['version'], $target_version ) ) {
                return $release;
            }
        }
        if ( isset( $manifest['version'] ) && 0 === version_compare( (string) $manifest['version'], $target_version ) ) {
            return $manifest;
        }
        return [];
    }

    private function is_official_channel_feed( string $url ): bool {
        foreach ( array_merge( self::CHANNEL_FEEDS, self::RAW_CHANNEL_FEEDS ) as $feed_url ) {
            if ( 0 === strpos( $url, $feed_url ) ) {
                return true;
            }
        }
        return false;
    }

    private function settings(): array {
        $defaults = [
            'vw_min'              => 320,
            'vw_max'              => 1440,
            'delete_on_uninstall' => false,
            'update_url'          => self::DEFAULT_FEED_URL,
            'update_channel'      => 'stable',
            'auto_update'         => false,
            'license_server_url'  => '',
        ];

        $settings = get_option( 've_settings', $defaults );
        return wp_parse_args( is_array( $settings ) ? $settings : [], $defaults );
    }

    private function cache_bust_url( string $url ): string {
        $separator = false === strpos( $url, '?' ) ? '?' : '&';
        return $url . $separator . 've_t=' . rawurlencode( (string) time() );
    }

    private function manifest_cache_key( string $channel, string $url ): string {
        $channel = sanitize_key( $channel );
        if ( ! in_array( $channel, array_keys( self::CHANNEL_FEEDS ), true ) ) {
            $channel = 'stable';
        }
        return 've_update_manifest_' . $channel . '_' . substr( md5( $url ), 0, 12 );
    }

    private function plugin_file(): string {
        return plugin_basename( VE_FILE );
    }

    private function update_admin_url(): string {
        if ( ! function_exists( 'wp_nonce_url' ) || ! function_exists( 'self_admin_url' ) ) {
            return '';
        }

        $file = $this->plugin_file();
        $url = wp_nonce_url(
            self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . urlencode( $file ) ),
            'upgrade-plugin_' . $file
        );

        return html_entity_decode( $url, ENT_QUOTES, 'UTF-8' );
    }

    private function update_item( array $manifest ): \stdClass {
        return (object) [
            'id'            => isset( $manifest['details_url'] ) ? (string) $manifest['details_url'] : '',
            'slug'          => self::SLUG,
            'plugin'        => $this->plugin_file(),
            'new_version'   => (string) $manifest['version'],
            'url'           => isset( $manifest['details_url'] ) ? (string) $manifest['details_url'] : '',
            'package'       => isset( $manifest['download_url'] ) ? (string) $manifest['download_url'] : '',
            'requires'      => isset( $manifest['requires'] ) ? (string) $manifest['requires'] : '6.0',
            'tested'        => isset( $manifest['tested'] ) ? (string) $manifest['tested'] : '',
            'requires_php'  => isset( $manifest['requires_php'] ) ? (string) $manifest['requires_php'] : '7.4',
        ];
    }

    private function sync_native_update_transient( array $manifest, bool $force_response = false ): void {
        $transient = get_site_transient( 'update_plugins' );
        if ( ! is_object( $transient ) ) {
            $transient = new \stdClass();
        }
        if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
            $transient->response = [];
        }
        if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
            $transient->no_update = [];
        }
        if ( ! isset( $transient->checked ) || ! is_array( $transient->checked ) ) {
            $transient->checked = [];
        }

        $file = $this->plugin_file();
        $item = $this->update_item( $manifest );
        $transient->checked[ $file ] = VE_VERSION;
        $transient->last_checked = time();

        if ( $force_response || version_compare( (string) $manifest['version'], VE_VERSION, '>' ) ) {
            $transient->response[ $file ] = $item;
            unset( $transient->no_update[ $file ] );
        } else {
            $transient->no_update[ $file ] = $item;
            unset( $transient->response[ $file ] );
        }

        set_site_transient( 'update_plugins', $transient );
    }

    public function upgrader_complete( $upgrader, $options ): void {
        if ( is_array( $options ) && isset( $options['action'], $options['type'], $options['plugins'] ) && 'plugin' === $options['action'] && 'update' === $options['type'] ) {
            foreach ( (array) $options['plugins'] as $plugin ) {
                if ( $plugin === $this->plugin_file() ) {
                    $this->clear_cache();
                    if ( function_exists( 'wp_clean_plugins_cache' ) ) {
                        wp_clean_plugins_cache();
                    }
                    break;
                }
            }
        }
    }
}
