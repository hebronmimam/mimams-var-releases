<?php
namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Loads Rank Math's own browser analyzer for Content Studio.
 *
 * Rank Math calculates its editor score in JavaScript. This bridge exposes the
 * same analyzer, configured tests, locale data, and language helpers without
 * mounting or imitating Rank Math's editor UI.
 */
class RankMathAnalysisBridge {
    private const DEFAULT_TESTS = [
        'contentHasTOC',
        'contentHasShortParagraphs',
        'contentHasAssets',
        'keywordInTitle',
        'keywordInMetaDescription',
        'keywordInPermalink',
        'keywordIn10Percent',
        'keywordInContent',
        'keywordInSubheadings',
        'keywordInImageAlt',
        'keywordDensity',
        'keywordNotUsed',
        'lengthContent',
        'lengthPermalink',
        'linksHasInternal',
        'linksHasExternals',
        'linksNotAllExternals',
        'titleStartWithKeyword',
        'titleSentiment',
        'titleHasPowerWords',
        'titleHasNumber',
        'hasContentAI',
    ];

    /**
     * Enqueue Rank Math's analyzer and return the optional VE app dependency.
     *
     * @return array<int,string>
     */
    public static function enqueue(): array {
        // Detect Rank Math loosely. Earlier this required a top-level \RankMath class
        // AND a plugin_url() method on its instance; some Rank Math builds satisfy
        // neither, so the analyzer never enqueued and the live score fell back to N/A.
        if ( ! function_exists( 'rank_math' ) && ! defined( 'RANK_MATH_VERSION' ) && ! class_exists( 'RankMath' ) ) {
            return [];
        }

        $rank_math = function_exists( 'rank_math' ) ? rank_math() : null;
        $version   = defined( 'RANK_MATH_VERSION' ) ? RANK_MATH_VERSION : ( is_object( $rank_math ) && isset( $rank_math->version ) ? $rank_math->version : null );

        // Resolve Rank Math's plugin dir + URL without depending on plugin_url():
        // constants first, then instance methods, then the standard install path.
        $dir = '';
        if ( defined( 'RANK_MATH_PATH' ) ) {
            $dir = RANK_MATH_PATH;
        } elseif ( defined( 'RANK_MATH_FILE' ) ) {
            $dir = plugin_dir_path( RANK_MATH_FILE );
        } elseif ( is_object( $rank_math ) && method_exists( $rank_math, 'plugin_dir' ) ) {
            $dir = $rank_math->plugin_dir();
        }
        if ( ! $dir && defined( 'WP_PLUGIN_DIR' ) && file_exists( WP_PLUGIN_DIR . '/seo-by-rank-math/rank-math.php' ) ) {
            $dir = WP_PLUGIN_DIR . '/seo-by-rank-math/';
        }
        $url = '';
        if ( defined( 'RANK_MATH_FILE' ) ) {
            $url = plugin_dir_url( RANK_MATH_FILE );
        } elseif ( is_object( $rank_math ) && method_exists( $rank_math, 'plugin_url' ) ) {
            $url = $rank_math->plugin_url();
        } elseif ( $dir ) {
            $url = plugins_url( '/', trailingslashit( $dir ) . 'rank-math.php' );
        }

        $analyzer_file = $dir ? trailingslashit( $dir ) . 'assets/admin/js/analyzer.js' : '';
        $analyzer_url  = $url ? trailingslashit( $url ) . 'assets/admin/js/analyzer.js' : '';

        // If the analyzer can't be located on disk, expose a config flag so the panel
        // reports "unavailable" immediately instead of hanging for 2s then showing N/A.
        if ( ! $analyzer_file || ! file_exists( $analyzer_file ) || ! $analyzer_url ) {
            $reason = ! $dir ? 'rank-math-path-unresolved' : 'analyzer-js-missing';
            wp_register_script( 've-rank-math-config', '', [], $version ?: null, true );
            wp_enqueue_script( 've-rank-math-config' );
            wp_add_inline_script( 've-rank-math-config', 'window.veRankMathAnalysis={available:false,reason:' . wp_json_encode( $reason ) . '};', 'before' );
            return [];
        }

        if ( ! wp_script_is( 'rank-math-analyzer', 'registered' ) ) {
            wp_register_script(
                'rank-math-analyzer',
                $analyzer_url,
                [ 'lodash', 'wp-autop', 'wp-wordcount', 'wp-url', 'wp-hooks', 'wp-i18n' ],
                $version,
                true
            );
        } else {
            global $wp_scripts;
            if ( isset( $wp_scripts->registered['rank-math-analyzer'] ) ) {
                $required = [ 'lodash', 'wp-autop', 'wp-wordcount', 'wp-url', 'wp-hooks', 'wp-i18n' ];
                $wp_scripts->registered['rank-math-analyzer']->deps = array_values(
                    array_unique( array_merge( $wp_scripts->registered['rank-math-analyzer']->deps, $required ) )
                );
            }
        }

        $config = self::configuration( $dir );
        $json   = wp_json_encode( $config );
        if ( $json ) {
            // Fill gaps only — never clobber Rank Math's own data. Previously this merged
            // MV's values OVER window.rankMath.assessor, so when Rank Math had already
            // published its real researchesTests we replaced them with our guess and the
            // live score diverged from the score Rank Math's own editor shows.
            wp_add_inline_script(
                'rank-math-analyzer',
                'window.veRankMathAnalysis=' . $json . ';'
                . 'window.rankMath=window.rankMath||{};'
                . 'window.rankMath.localeFull=window.rankMath.localeFull||window.veRankMathAnalysis.localeFull;'
                . 'Object.keys(window.veRankMathAnalysis.links||{}).forEach(function(k){if(window.rankMath[k]===undefined)window.rankMath[k]=window.veRankMathAnalysis.links[k];});'
                . 'window.rankMath.assessor=Object.assign({},window.veRankMathAnalysis.assessor,window.rankMath.assessor||{});',
                'before'
            );
        }

        wp_enqueue_script( 'rank-math-analyzer' );
        if ( function_exists( 'wp_set_script_translations' ) && $dir ) {
            wp_set_script_translations( 'rank-math-analyzer', 'seo-by-rank-math', trailingslashit( $dir ) . 'languages/' );
        }

        return [ 'rank-math-analyzer' ];
    }

    /**
     * @param string $plugin_dir Absolute path to the Rank Math plugin directory.
     * @return array<string,mixed>
     */
    private static function configuration( string $plugin_dir ): array {
        $locale       = get_locale();
        $short_locale = strtolower( substr( str_replace( '-', '_', $locale ), 0, 2 ) );
        $plugin_dir   = $plugin_dir ? trailingslashit( $plugin_dir ) : '';

        $power_words = self::include_array( $plugin_dir . 'assets/vendor/powerwords/' . $short_locale . '.php' );
        $diacritics_locale = in_array( $short_locale, [ 'en', 'de', 'ru' ], true ) ? $short_locale : 'en';
        $diacritics = self::include_array( $plugin_dir . 'assets/vendor/diacritics/' . $diacritics_locale . '.php' );

        $tests    = self::DEFAULT_TESTS;
        $resolved = false;
        if ( class_exists( '\RankMath\Admin\Metabox\Post_Screen' ) ) {
            try {
                $screen     = new \RankMath\Admin\Metabox\Post_Screen();
                $configured = apply_filters( 'rank_math/researches/tests', $screen->get_analysis(), 'post' );
                if ( is_array( $configured ) && $configured ) {
                    $tests    = array_values( array_keys( array_filter( $configured ) ) );
                    $resolved = true;
                }
            } catch ( \Throwable $error ) {
                // Keep the Rank Math default post test list when its screen helper is unavailable.
            }
        }

        // `keywordNotUsed` needs Rank Math's server lookup of keywords already in use; its
        // maximum is 0, so leaving it out moves nothing. `hasContentAI` used to be left out
        // too, on the belief that Rank Math's editor skipped it. It does not (R50, measured
        // on test7): its 5 points count towards the total there, so MV now runs it, with the
        // post's Content AI state supplied by content-studio/posts/<id>/rank-math-paper.
        $unrunnable = [ 'keywordNotUsed' ];
        $runnable   = array_values( array_diff( $tests, $unrunnable ) );
        $excluded   = array_values( array_intersect( $tests, $unrunnable ) );

        return [
            'available'    => true,
            'localeFull'   => $locale ?: 'en_US',
            'tests'        => $runnable,
            // Diagnostics: lets the panel report where the list came from and what we
            // deliberately skipped, so a score gap can be explained instead of guessed at.
            'testsSource'  => $resolved ? 'rank-math-post-screen' : 'mv-default-list',
            'testsExcluded' => $excluded,
            /* R50, 2026-09-24: Rank Math's editor scored kryptfo's post 77 and MV 63.
               Rank Math's ACF module appends the post's ACF text to what its editor
               analyses (722 words there, 681 in the body), and MV was scoring the
               body alone. The panel appends the same fields when this is on. */
            'acfModule'    => class_exists( '\RankMath\Helper' ) && method_exists( '\RankMath\Helper', 'is_module_active' )
                && \RankMath\Helper::is_module_active( 'acf' ) && function_exists( 'acf_get_field_groups' ),
            /* R50, 2026-09-28: kryptfo's post, side by side. Rank Math passed
               internal links and failed both outbound checks; MV had it the other
               way round. Its analyzer sorts links with W(link, rankMath.parentDomain),
               and outside Rank Math's post screen parentDomain was never set, so
               every https://kryptfo.com/... link read as external. The table of
               contents check reads rankMath.assessor.hasTOCPlugin the same way.
               Both come from here now, worked out as the post screen does. */
            'links'        => self::link_settings(),
            'assessor'     => [
                'researchesTests' => $runnable,
                'powerWords'      => array_values( array_map( 'strtolower', $power_words ) ),
                'diacritics'      => $diacritics,
                'hasTOCPlugin'    => self::has_toc_plugin(),
            ],
        ];
    }

    /**
     * What Rank Math's post screen puts on window.rankMath for sorting links.
     *
     * @return array<string,mixed>
     */
    private static function link_settings(): array {
        $setting = static function ( string $key ) {
            return class_exists( '\RankMath\Helper' ) && method_exists( '\RankMath\Helper', 'get_settings' )
                ? \RankMath\Helper::get_settings( $key ) : null;
        };
        $list = static function ( $value ): array {
            if ( class_exists( '\RankMath\Helpers\Str' ) && method_exists( '\RankMath\Helpers\Str', 'to_arr_no_empty' ) ) {
                return array_values( (array) \RankMath\Helpers\Str::to_arr_no_empty( $value ) );
            }
            return array_values( array_filter( array_map( 'trim', preg_split( '/[\r\n,]+/', (string) $value ) ?: [] ) ) );
        };
        return [
            'parentDomain'           => self::domain_of( home_url() ),
            'noFollowDomains'        => $list( $setting( 'general.nofollow_domains' ) ),
            'noFollowExcludeDomains' => $list( $setting( 'general.nofollow_exclude_domains' ) ),
            'noFollowExternalLinks'  => $setting( 'general.nofollow_external_links' ),
        ];
    }

    /** Rank Math's Url::get_domain(): the registrable part of the host. */
    public static function domain_of( string $url ) {
        if ( class_exists( '\RankMath\Helpers\Url' ) && method_exists( '\RankMath\Helpers\Url', 'get_domain' ) ) {
            return \RankMath\Helpers\Url::get_domain( $url );
        }
        $pieces = wp_parse_url( $url );
        $domain = isset( $pieces['host'] ) ? (string) $pieces['host'] : '';
        if ( false !== strpos( $domain, 'localhost' ) ) {
            return 'localhost';
        }
        return preg_match( '/(?P<domain>[a-zÀ-ž0-9][a-zÀ-ž0-9\-]{1,63}\.[a-zÀ-ž\.]{2,15})$/ui', $domain, $regs ) ? $regs['domain'] : false;
    }

    /** Rank Math's has_toc_plugin(), which is private to its post screen. */
    private static function has_toc_plugin() {
        if ( defined( 'ELEMENTOR_PRO_VERSION' ) ) {
            return true;
        }
        $active = (array) get_option( 'active_plugins', [] );
        if ( is_multisite() ) {
            $active = array_merge( $active, array_keys( (array) get_site_option( 'active_sitewide_plugins', [] ) ) );
        }
        $toc = apply_filters( 'rank_math/researches/toc_plugins', [
            'wp-shortcode/wp-shortcode.php'         => 'WP Shortcode by RankMath',
            'wp-shortcode-pro/wp-shortcode-pro.php' => 'WP Shortcode Pro by RankMath',
        ] );
        $found = [];
        foreach ( (array) $toc as $slug => $name ) {
            if ( in_array( $slug, $active, true ) ) {
                $found[ $slug ] = $name;
            }
        }
        return $found ?: false;
    }

    /**
     * @return array<mixed>
     */
    private static function include_array( string $path ): array {
        if ( ! $path || ! is_readable( $path ) ) {
            return [];
        }

        $value = include $path;
        return is_array( $value ) ? $value : [];
    }
}
