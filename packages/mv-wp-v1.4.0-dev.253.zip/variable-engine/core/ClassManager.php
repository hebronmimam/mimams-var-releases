<?php
/**
 * Class Manager: every Bricks global class on the site, audited, and the
 * changes the owner makes to them in bulk (B78, direction 2 · Audit Table).
 *
 * Bricks is the owner of these records, so MV writes exactly what Bricks'
 * builder writes and nothing else:
 *
 * - classes      `bricks_global_classes`, each change stamped `modified` and
 *                `user_id`, and the list's timestamp/user moved, so a builder
 *                with class sync on sees the change as another user's;
 * - trash        `bricks_global_classes_trash`, the record plus `deletedAt` in
 *                milliseconds - Bricks' own shape, so its Trash restores it;
 * - protection   `bricks_global_classes_locked`, a list of ids.
 *
 * Elements refer to a class by its id, not its name, so renaming is a change
 * to one record. Merging is the one operation that rewrites pages: every
 * element wearing a merged class is pointed at the class that survives. It
 * keeps a copy of everything it touches so the owner can undo it, and it is
 * refused inside a Workspaces session, where option writes stay private but a
 * page rewrite would reach the live site.
 *
 * @package VariableEngine
 */

namespace VE\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ClassManager {

    public const CLASSES    = 'bricks_global_classes';
    public const CATEGORIES = 'bricks_global_classes_categories';
    public const LOCKED     = 'bricks_global_classes_locked';
    public const TRASH      = 'bricks_global_classes_trash';
    public const TIMESTAMP  = 'bricks_global_classes_timestamp';
    public const USER       = 'bricks_global_classes_user';

    /** Undo records: an index, and one option per record (merges carry page trees). */
    public const UNDO_INDEX  = 've_class_manager_undo';
    private const UNDO_PREFIX = 've_class_manager_undo_';
    private const UNDO_KEEP   = 5;

    /** How many element trees to read, as the Classes lane does. */
    public const SCAN_LIMIT = 800;

    /** Where Bricks keeps a post's elements. */
    private const TREE_KEYS = [ '_bricks_page_content_2', '_bricks_page_header_2', '_bricks_page_footer_2' ];

    /** How many places to list per class; the count stays exact. */
    private const PLACES_SHOWN = 40;

    /* ── reading ─────────────────────────────────────────────────────── */

    /**
     * The whole audit: classes with their evidence, the trash, and what the
     * scan could and could not see.
     */
    public function inventory(): array {
        $records    = $this->records();
        $locked     = $this->locked_ids();
        $categories = $this->categories();
        $cat_names  = [];
        foreach ( $categories as $cat ) {
            if ( is_array( $cat ) && isset( $cat['id'] ) ) {
                $cat_names[ (string) $cat['id'] ] = (string) ( $cat['name'] ?? '' );
            }
        }

        $by_name = [];
        foreach ( $records as $r ) {
            $by_name[ (string) $r['name'] ] = (string) $r['id'];
        }
        $scan = $this->scan_usage( $by_name );

        // Two records are duplicates when their names differ only by case,
        // hyphens and underscores, or when they carry the same non-empty styles.
        $groups = [];
        foreach ( $records as $r ) {
            $groups[ 'n:' . self::name_key( (string) $r['name'] ) ][] = (string) $r['id'];
            $sig = $this->style_signature( $r );
            if ( '' !== $sig ) {
                $groups[ 's:' . $sig ][] = (string) $r['id'];
            }
        }
        $twins = [];
        foreach ( $groups as $ids ) {
            if ( count( $ids ) < 2 ) {
                continue;
            }
            foreach ( $ids as $id ) {
                $twins[ $id ] = array_values( array_unique( array_merge( $twins[ $id ] ?? [], array_diff( $ids, [ $id ] ) ) ) );
            }
        }

        $classes = [];
        foreach ( $records as $r ) {
            $id     = (string) $r['id'];
            $places = $scan['places'][ $id ] ?? [];
            usort( $places, static function ( $a, $b ) { return $b['count'] <=> $a['count'] ?: strcmp( $a['title'], $b['title'] ); } );
            $category  = (string) ( $r['category'] ?? '' );
            $classes[] = [
                'id'            => $id,
                'name'          => (string) $r['name'],
                'category'      => $category,
                'category_name' => $cat_names[ $category ] ?? '',
                'locked'        => in_array( $id, $locked, true ),
                'framework'     => self::is_framework( $r ),
                'styles'        => $this->count_styles( $r['settings'] ?? [] ),
                'rule'          => $this->rule_text( $r ),
                'used'          => (int) ( $scan['used'][ $id ] ?? 0 ),
                'places'        => array_slice( $places, 0, self::PLACES_SHOWN ),
                'places_total'  => count( $places ),
                'duplicates'    => $twins[ $id ] ?? [],
                'modified'      => (int) ( $r['modified'] ?? 0 ),
            ];
        }
        usort( $classes, static function ( $a, $b ) { return strnatcasecmp( $a['name'], $b['name'] ); } );

        $trash = [];
        foreach ( $this->trash_records() as $t ) {
            $trash[] = [
                'id'         => (string) $t['id'],
                'name'       => (string) ( $t['name'] ?? '' ),
                'deleted_at' => (int) ( $t['deletedAt'] ?? 0 ),
                'styles'     => $this->count_styles( $t['settings'] ?? [] ),
            ];
        }
        usort( $trash, static function ( $a, $b ) { return $b['deleted_at'] <=> $a['deleted_at']; } );

        return [
            'bricks'       => defined( 'BRICKS_VERSION' ),
            'classes'      => $classes,
            'trash'        => $trash,
            'categories'   => array_values( $categories ),
            'scanned'      => $scan['scanned'],
            'scan_limited' => $scan['limited'],
            'workspace'    => self::in_workspace_session(),
            'timestamp'    => (int) get_option( self::TIMESTAMP, 0 ),
        ];
    }

    /* ── writing ─────────────────────────────────────────────────────── */

    public function create( string $name, string $category = '' ): array {
        $name = self::clean_name( $name );
        if ( '' === $name ) {
            return self::fail( 'invalid-name', 'Use letters, numbers, hyphens and underscores, starting with a letter or underscore.' );
        }
        if ( $taken = $this->name_taken( $name ) ) {
            return $taken;
        }
        $before = $this->snapshot();
        $record = [ 'id' => $this->new_id(), 'name' => $name, 'settings' => [] ];
        if ( '' !== $category ) {
            $record['category'] = sanitize_key( $category );
        }
        $record    = $this->stamp( $record );
        $records   = $this->records();
        $records[] = $record;
        $this->save_classes( $records );
        return $this->done( 'create', $before, [ 'record' => $record ] );
    }

    public function rename( string $id, string $name ): array {
        $name  = self::clean_name( $name );
        $index = $this->index_of( $id );
        if ( null === $index ) {
            return self::fail( 'not-found', 'That class is no longer on the site. Refresh the list.' );
        }
        if ( '' === $name ) {
            return self::fail( 'invalid-name', 'Use letters, numbers, hyphens and underscores, starting with a letter or underscore.' );
        }
        $records = $this->records();
        if ( $guard = $this->guard( [ $records[ $index ] ], 'rename' ) ) {
            return $guard;
        }
        if ( $records[ $index ]['name'] === $name ) {
            return self::fail( 'same-name', 'That is already its name.' );
        }
        if ( $taken = $this->name_taken( $name, $id ) ) {
            return $taken;
        }
        $before                    = $this->snapshot();
        $old                       = $records[ $index ]['name'];
        $records[ $index ]['name'] = $name;
        $records[ $index ]         = $this->stamp( $records[ $index ] );
        $this->save_classes( $records );
        return $this->done( 'rename', $before, [ 'record' => $records[ $index ], 'old_name' => $old ] );
    }

    public function duplicate( string $id ): array {
        $index = $this->index_of( $id );
        if ( null === $index ) {
            return self::fail( 'not-found', 'That class is no longer on the site. Refresh the list.' );
        }
        $records = $this->records();
        $source  = $records[ $index ];
        $name    = $source['name'] . '-copy';
        for ( $n = 2; $this->name_taken( $name ); $n++ ) {
            $name = $source['name'] . '-copy-' . $n;
        }
        $before = $this->snapshot();
        $copy   = $source;
        unset( $copy['modified'], $copy['user_id'], $copy['user'] );
        $copy['id']   = $this->new_id();
        $copy['name'] = $name;
        $copy         = $this->stamp( $copy );
        array_splice( $records, $index + 1, 0, [ $copy ] );
        $this->save_classes( $records );
        return $this->done( 'duplicate', $before, [ 'record' => $copy, 'from' => $source['id'] ] );
    }

    public function set_locked( array $ids, bool $locked ): array {
        $ids = $this->existing_ids( $ids );
        if ( ! $ids ) {
            return self::fail( 'not-found', 'None of those classes are on the site any more. Refresh the list.' );
        }
        $before  = $this->snapshot();
        $current = $this->locked_ids();
        $next    = $locked ? array_values( array_unique( array_merge( $current, $ids ) ) ) : array_values( array_diff( $current, $ids ) );
        if ( $next ) {
            update_option( self::LOCKED, $next, false );
        } else {
            delete_option( self::LOCKED );
        }
        return $this->done( $locked ? 'lock' : 'unlock', $before, [ 'ids' => $ids, 'locked' => $next ] );
    }

    public function trash( array $ids ): array {
        $ids = $this->existing_ids( $ids );
        if ( ! $ids ) {
            return self::fail( 'not-found', 'None of those classes are on the site any more. Refresh the list.' );
        }
        $records = $this->records();
        $chosen  = array_values( array_filter( $records, static function ( $r ) use ( $ids ) { return in_array( (string) $r['id'], $ids, true ); } ) );
        if ( $guard = $this->guard( $chosen, 'trash' ) ) {
            return $guard;
        }
        $before = $this->snapshot();
        $this->move_to_trash( $ids );
        return $this->done( 'trash', $before, [ 'ids' => $ids ] );
    }

    public function restore( array $ids ): array {
        $ids   = array_map( 'strval', $ids );
        $trash = $this->trash_records();
        $back  = [];
        $keep  = [];
        foreach ( $trash as $t ) {
            if ( in_array( (string) $t['id'], $ids, true ) ) {
                $back[] = $t;
            } else {
                $keep[] = $t;
            }
        }
        if ( ! $back ) {
            return self::fail( 'not-found', 'Those classes are not in the trash any more. Refresh the list.' );
        }
        foreach ( $back as $t ) {
            if ( $this->name_taken( (string) $t['name'], '', false ) ) {
                return self::fail( 'exists', '.' . $t['name'] . ' exists again on the site. Rename that one first, then restore.' );
            }
        }
        $before  = $this->snapshot();
        $records = $this->records();
        $out     = [];
        foreach ( $back as $t ) {
            unset( $t['deletedAt'] );
            $t         = $this->stamp( $t );
            $records[] = $t;
            $out[]     = $t;
        }
        $this->save_classes( $records );
        $this->save_trash( $keep );
        return $this->done( 'restore', $before, [ 'records' => $out ] );
    }

    /**
     * Point every element wearing one of $ids at $target, give $target the
     * styles it does not set itself, and move the others to the trash.
     */
    public function merge( array $ids, string $target ): array {
        if ( self::in_workspace_session() ) {
            return self::fail( 'workspace', 'Merging rewrites pages on the live site, so it is not available inside a workspace. Leave the workspace first.' );
        }
        $ids = $this->existing_ids( $ids );
        if ( count( $ids ) < 2 || ! in_array( $target, $ids, true ) ) {
            return self::fail( 'merge-needs-two', 'Pick at least two classes, and the one to keep among them.' );
        }
        $records = $this->records();
        $chosen  = array_values( array_filter( $records, static function ( $r ) use ( $ids ) { return in_array( (string) $r['id'], $ids, true ); } ) );
        if ( $guard = $this->guard( $chosen, 'merge' ) ) {
            return $guard;
        }
        $sources = array_values( array_diff( $ids, [ $target ] ) );

        // Read every tree first; the copy for undo is taken before anything moves.
        $touched = [];
        $moved   = 0;
        foreach ( $this->trees() as $tree ) {
            $count    = 0;
            $elements = $this->repoint( $tree['elements'], $sources, $target, $count );
            if ( $count > 0 ) {
                $touched[] = [ 'post' => $tree['post'], 'key' => $tree['key'], 'before' => $tree['raw'], 'after' => $elements ];
                $moved    += $count;
            }
        }

        $before         = $this->snapshot();
        $before['meta'] = array_map( static function ( $t ) { return [ $t['post'], $t['key'], $t['before'] ]; }, $touched );

        $t_index  = $this->index_of( $target );
        $survivor = $records[ $t_index ];
        $settings = is_array( $survivor['settings'] ?? null ) ? $survivor['settings'] : [];
        foreach ( $chosen as $r ) {
            if ( (string) $r['id'] === $target || ! is_array( $r['settings'] ?? null ) ) {
                continue;
            }
            // The survivor keeps its own value wherever both set the same thing.
            $settings += $r['settings'];
        }
        $records[ $t_index ]['settings'] = $settings;
        $records[ $t_index ]             = $this->stamp( $records[ $t_index ] );
        $this->save_classes( $records );

        foreach ( $touched as $t ) {
            update_post_meta( $t['post'], $t['key'], wp_slash( $t['after'] ) );
        }
        $this->move_to_trash( $sources );

        return $this->done( 'merge', $before, [
            'record'  => $records[ $t_index ],
            'sources' => $sources,
            'moved'   => $moved,
            'pages'   => count( array_unique( array_column( $touched, 'post' ) ) ),
        ] );
    }

    /**
     * Put back what one write changed - only while nothing else has changed
     * the classes since, so an undo can never throw away someone's later work.
     */
    public function undo( string $token ): array {
        $token = preg_replace( '/[^a-z0-9]/', '', strtolower( $token ) );
        $saved = '' === $token ? null : get_option( self::UNDO_PREFIX . $token, null );
        if ( ! is_array( $saved ) ) {
            return self::fail( 'undo-gone', 'That change can no longer be undone.' );
        }
        if ( $this->state_hash() !== ( $saved['after'] ?? '' ) ) {
            return self::fail( 'undo-stale', 'The classes have changed since, so undoing this could throw away later work. Undo it by hand instead.' );
        }
        $this->restore_snapshot( $saved['before'] );
        foreach ( (array) ( $saved['before']['meta'] ?? [] ) as $m ) {
            update_post_meta( (int) $m[0], (string) $m[1], wp_slash( $m[2] ) );
        }
        $this->forget_undo( $token );
        ClassLensManager::forget();
        return [ 'ok' => true, 'action' => 'undo', 'undone' => (string) ( $saved['action'] ?? '' ), 'timestamp' => (int) get_option( self::TIMESTAMP, 0 ) ];
    }

    /* ── pieces ──────────────────────────────────────────────────────── */

    /** `feature_Card` and `feature-card` are the same name to a reader. */
    public static function name_key( string $name ): string {
        return trim( preg_replace( '/[-_]+/', '-', strtolower( $name ) ), '-' );
    }

    public static function clean_name( string $raw ): string {
        $name = ltrim( trim( $raw ), '.' );
        return preg_match( '/^[A-Za-z_][A-Za-z0-9_-]{0,120}$/', $name ) ? $name : '';
    }

    public static function is_framework( array $record ): bool {
        if ( ! empty( $record['at_framework'] ) || ! empty( $record['framework'] ) ) {
            return true;
        }
        $settings = $record['settings'] ?? null;
        return is_array( $settings ) && ! empty( $settings['at_framework'] );
    }

    private static function in_workspace_session(): bool {
        return class_exists( '\\VE\\Modules\\Workspaces\\WorkspaceRuntime' )
            && \VE\Modules\Workspaces\WorkspaceRuntime::session_id() > 0;
    }

    private static function fail( string $code, string $message ): array {
        return [ 'ok' => false, 'code' => $code, 'message' => $message ];
    }

    /** Framework classes are theirs; a protected class waits to be unlocked. */
    private function guard( array $records, string $action ): ?array {
        $locked = $this->locked_ids();
        foreach ( $records as $r ) {
            if ( self::is_framework( $r ) ) {
                return self::fail( 'framework', '.' . $r['name'] . ' belongs to a CSS framework. Change it in the framework instead.' );
            }
            if ( in_array( (string) $r['id'], $locked, true ) ) {
                $verb = [ 'rename' => 'renaming', 'trash' => 'moving it to the trash', 'merge' => 'merging' ][ $action ] ?? 'changing it';
                return self::fail( 'locked', '.' . $r['name'] . ' is protected. Unlock it before ' . $verb . '.' );
            }
        }
        return null;
    }

    /** A name in use by another class, or waiting in the trash (Bricks refuses both). */
    private function name_taken( string $name, string $except = '', bool $check_trash = true ): ?array {
        foreach ( $this->records() as $r ) {
            if ( $r['name'] === $name && (string) $r['id'] !== $except ) {
                return self::fail( 'exists', '.' . $name . ' already exists. Pick another name, or merge the two.' );
            }
        }
        if ( $check_trash ) {
            foreach ( $this->trash_records() as $t ) {
                if ( (string) ( $t['name'] ?? '' ) === $name ) {
                    return self::fail( 'in-trash', '.' . $name . ' is in the trash. Restore it, or pick another name.' );
                }
            }
        }
        return null;
    }

    private function records(): array {
        $records = get_option( self::CLASSES, [] );
        if ( is_string( $records ) ) {
            $decoded = json_decode( $records, true );
            $records = is_array( $decoded ) ? $decoded : [];
        }
        $out = [];
        foreach ( is_array( $records ) ? $records : [] as $r ) {
            if ( is_array( $r ) && isset( $r['id'], $r['name'] ) && '' !== (string) $r['name'] ) {
                $out[] = $r;
            }
        }
        return $out;
    }

    private function trash_records(): array {
        $trash = get_option( self::TRASH, [] );
        return array_values( array_filter( is_array( $trash ) ? $trash : [], static function ( $t ) { return is_array( $t ) && isset( $t['id'] ); } ) );
    }

    private function locked_ids(): array {
        $locked = get_option( self::LOCKED, [] );
        return array_values( array_map( 'strval', is_array( $locked ) ? $locked : [] ) );
    }

    private function categories(): array {
        $cats = get_option( self::CATEGORIES, [] );
        return is_array( $cats ) ? array_values( array_filter( $cats, 'is_array' ) ) : [];
    }

    private function index_of( string $id ): ?int {
        foreach ( $this->records() as $i => $r ) {
            if ( (string) $r['id'] === $id ) {
                return $i;
            }
        }
        return null;
    }

    private function existing_ids( array $ids ): array {
        $have = array_map( static function ( $r ) { return (string) $r['id']; }, $this->records() );
        return array_values( array_intersect( array_unique( array_map( 'strval', $ids ) ), $have ) );
    }

    /** Six lower-case letters, like the ids Bricks' builder makes. */
    private function new_id(): string {
        $taken = array_merge(
            array_map( static function ( $r ) { return (string) $r['id']; }, $this->records() ),
            array_map( static function ( $t ) { return (string) $t['id']; }, $this->trash_records() )
        );
        do {
            $id = '';
            for ( $i = 0; $i < 6; $i++ ) {
                $id .= chr( 97 + random_int( 0, 25 ) );
            }
        } while ( in_array( $id, $taken, true ) );
        return $id;
    }

    /** What Bricks stamps on a class it saves. */
    private function stamp( array $record ): array {
        $record['modified'] = time();
        $record['user_id']  = get_current_user_id();
        return $record;
    }

    private function save_classes( array $records ): void {
        $records = array_values( $records );
        if ( class_exists( '\\Bricks\\Helpers' ) && method_exists( '\\Bricks\\Helpers', 'save_global_classes_in_db' ) && $records ) {
            \Bricks\Helpers::save_global_classes_in_db( $records );
        } else {
            if ( $records ) {
                update_option( self::CLASSES, $records );
            } else {
                delete_option( self::CLASSES );
            }
            update_option( self::TIMESTAMP, time() );
            update_option( self::USER, get_current_user_id() );
        }
        ClassLensManager::forget();
    }

    private function save_trash( array $trash ): void {
        if ( $trash ) {
            update_option( self::TRASH, array_values( $trash ), false );
        } else {
            delete_option( self::TRASH );
        }
    }

    private function move_to_trash( array $ids ): void {
        $records = $this->records();
        $trash   = $this->trash_records();
        $keep    = [];
        $now     = (int) round( microtime( true ) * 1000 );
        foreach ( $records as $r ) {
            if ( in_array( (string) $r['id'], $ids, true ) ) {
                $r['deletedAt'] = $now;
                $trash[]        = $r;
            } else {
                $keep[] = $r;
            }
        }
        $this->save_classes( $keep );
        $this->save_trash( $trash );
        $locked = array_values( array_diff( $this->locked_ids(), $ids ) );
        if ( $locked ) {
            update_option( self::LOCKED, $locked, false );
        } else {
            delete_option( self::LOCKED );
        }
    }

    /* The four options a write can touch, for undo and for "has anything moved since". */
    private function snapshot(): array {
        return [
            'classes' => get_option( self::CLASSES, null ),
            'trash'   => get_option( self::TRASH, null ),
            'locked'  => get_option( self::LOCKED, null ),
        ];
    }

    private function restore_snapshot( array $snap ): void {
        foreach ( [ 'classes' => self::CLASSES, 'trash' => self::TRASH, 'locked' => self::LOCKED ] as $key => $option ) {
            if ( null === ( $snap[ $key ] ?? null ) ) {
                delete_option( $option );
            } else {
                update_option( $option, $snap[ $key ], self::CLASSES === $option );
            }
        }
        update_option( self::TIMESTAMP, time() );
        update_option( self::USER, get_current_user_id() );
    }

    private function state_hash(): string {
        $s = $this->snapshot();
        return md5( wp_json_encode( [ $s['classes'], $s['trash'], $s['locked'] ] ) );
    }

    private function done( string $action, array $before, array $extra ): array {
        $token = strtolower( wp_generate_password( 12, false, false ) );
        update_option( self::UNDO_PREFIX . $token, [ 'action' => $action, 'at' => time(), 'before' => $before, 'after' => $this->state_hash() ], false );
        $index   = get_option( self::UNDO_INDEX, [] );
        $index   = is_array( $index ) ? $index : [];
        $index[] = $token;
        while ( count( $index ) > self::UNDO_KEEP ) {
            delete_option( self::UNDO_PREFIX . array_shift( $index ) );
        }
        update_option( self::UNDO_INDEX, array_values( $index ), false );
        return [ 'ok' => true, 'action' => $action, 'undo' => $token, 'timestamp' => (int) get_option( self::TIMESTAMP, 0 ) ] + $extra;
    }

    private function forget_undo( string $token ): void {
        delete_option( self::UNDO_PREFIX . $token );
        $index = get_option( self::UNDO_INDEX, [] );
        update_option( self::UNDO_INDEX, array_values( array_diff( is_array( $index ) ? $index : [], [ $token ] ) ), false );
    }

    /* ── usage ───────────────────────────────────────────────────────── */

    /** Every live Bricks element tree, with the post it belongs to. */
    private function trees(): array {
        global $wpdb;
        $keys = "'" . implode( "','", array_map( 'esc_sql', self::TREE_KEYS ) ) . "'";
        $rows = $wpdb->get_results(
            "SELECT m.post_id, m.meta_key, m.meta_value FROM {$wpdb->postmeta} m
             INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id
             WHERE m.meta_key IN ({$keys})
               AND p.post_type NOT IN ('revision')
               AND p.post_status NOT IN ('trash','auto-draft','inherit')
             ORDER BY m.meta_id DESC
             LIMIT " . (int) ( self::SCAN_LIMIT + 1 )
        );
        $out = [];
        foreach ( (array) $rows as $row ) {
            $elements = maybe_unserialize( $row->meta_value );
            if ( is_array( $elements ) ) {
                $out[] = [ 'post' => (int) $row->post_id, 'key' => (string) $row->meta_key, 'elements' => $elements, 'raw' => $elements ];
            }
        }
        return $out;
    }

    private function scan_usage( array $by_name ): array {
        $trees   = $this->trees();
        $limited = count( $trees ) > self::SCAN_LIMIT;
        $trees   = array_slice( $trees, 0, self::SCAN_LIMIT );
        $used    = [];
        $per     = [];
        foreach ( $trees as $tree ) {
            $counts = [];
            $this->count_in( $tree['elements'], $counts, $by_name );
            foreach ( $counts as $id => $n ) {
                $used[ $id ]                  = ( $used[ $id ] ?? 0 ) + $n;
                $per[ $id ][ $tree['post'] ] = ( $per[ $id ][ $tree['post'] ] ?? 0 ) + $n;
            }
        }
        $places = [];
        foreach ( $per as $id => $posts ) {
            foreach ( $posts as $post_id => $n ) {
                $post = get_post( $post_id );
                if ( ! $post ) {
                    continue;
                }
                $type             = get_post_type_object( $post->post_type );
                $places[ $id ][] = [
                    'id'    => (int) $post_id,
                    'title' => '' !== $post->post_title ? $post->post_title : '(no title)',
                    'type'  => $type ? (string) $type->labels->singular_name : $post->post_type,
                    'count' => (int) $n,
                    'edit'  => $this->builder_url( (int) $post_id ),
                ];
            }
        }
        return [ 'used' => $used, 'places' => $places, 'scanned' => count( $trees ), 'limited' => $limited ];
    }

    private function count_in( array $node, array &$counts, array $by_name ): void {
        $settings = $node['settings'] ?? null;
        if ( is_array( $settings ) ) {
            foreach ( (array) ( $settings['_cssGlobalClasses'] ?? [] ) as $id ) {
                if ( is_scalar( $id ) && '' !== (string) $id ) {
                    $counts[ (string) $id ] = ( $counts[ (string) $id ] ?? 0 ) + 1;
                }
            }
            $plain = $settings['_cssClasses'] ?? '';
            if ( is_string( $plain ) && '' !== trim( $plain ) ) {
                foreach ( preg_split( '/\s+/', trim( $plain ) ) as $one ) {
                    $id = $by_name[ ltrim( $one, '.' ) ] ?? '';
                    if ( '' !== $id ) {
                        $counts[ $id ] = ( $counts[ $id ] ?? 0 ) + 1;
                    }
                }
            }
        }
        foreach ( $node as $value ) {
            if ( is_array( $value ) ) {
                $this->count_in( $value, $counts, $by_name );
            }
        }
    }

    /** The same tree with every source id replaced by $target, once per element. */
    private function repoint( array $node, array $sources, string $target, int &$count ): array {
        if ( isset( $node['settings']['_cssGlobalClasses'] ) && is_array( $node['settings']['_cssGlobalClasses'] ) ) {
            $list = $node['settings']['_cssGlobalClasses'];
            $next = [];
            $hit  = false;
            foreach ( $list as $id ) {
                if ( in_array( (string) $id, $sources, true ) ) {
                    $hit = true;
                    $id  = $target;
                }
                if ( ! in_array( (string) $id, array_map( 'strval', $next ), true ) ) {
                    $next[] = $id;
                }
            }
            if ( $hit ) {
                $count++;
                $node['settings']['_cssGlobalClasses'] = $next;
            }
        }
        // Bricks keeps elements as a flat list; settings hold values, not elements.
        foreach ( $node as $key => $value ) {
            if ( is_array( $value ) && 'settings' !== $key ) {
                $node[ $key ] = $this->repoint( $value, $sources, $target, $count );
            }
        }
        return $node;
    }

    private function builder_url( int $post_id ): string {
        if ( class_exists( '\\Bricks\\Helpers' ) && method_exists( '\\Bricks\\Helpers', 'get_builder_edit_link' ) ) {
            return (string) \Bricks\Helpers::get_builder_edit_link( $post_id );
        }
        $link = get_permalink( $post_id );
        return $link ? add_query_arg( 'bricks', 'run', $link ) : '';
    }

    /* ── styles ──────────────────────────────────────────────────────── */

    /** How many things a class sets: one per control value, one per CSS declaration. */
    private function count_styles( $settings ): int {
        if ( ! is_array( $settings ) ) {
            return 0;
        }
        $n = 0;
        foreach ( $settings as $key => $value ) {
            if ( 'at_framework' === $key ) {
                continue;
            }
            if ( 0 === strpos( (string) $key, '_cssCustom' ) ) {
                $n += is_string( $value ) ? (int) preg_match_all( '/[-a-z]+\s*:\s*[^;{}]+/i', preg_replace( '/[^{}]*\{/', '{', $value ) ) : 0;
                continue;
            }
            $n += $this->leaves( $value );
        }
        return $n;
    }

    private function leaves( $value ): int {
        if ( is_array( $value ) ) {
            $n = 0;
            foreach ( $value as $v ) {
                $n += $this->leaves( $v );
            }
            return $n;
        }
        return ( null === $value || '' === $value || false === $value ) ? 0 : 1;
    }

    private function style_signature( array $record ): string {
        $settings = is_array( $record['settings'] ?? null ) ? $record['settings'] : [];
        unset( $settings['at_framework'] );
        if ( ! $settings || 0 === $this->count_styles( $settings ) ) {
            return '';
        }
        ksort( $settings );
        return md5( wp_json_encode( $settings ) );
    }

    /** The class's custom CSS as a reader expects it: %root% is the class. */
    private function rule_text( array $record ): string {
        $settings = is_array( $record['settings'] ?? null ) ? $record['settings'] : [];
        $parts    = [];
        foreach ( $settings as $key => $value ) {
            if ( is_string( $value ) && '' !== trim( $value ) && 0 === strpos( (string) $key, '_cssCustom' ) ) {
                $parts[] = trim( str_replace( '%root%', '.' . $record['name'], $value ) );
            }
        }
        return implode( "\n\n", $parts );
    }
}
