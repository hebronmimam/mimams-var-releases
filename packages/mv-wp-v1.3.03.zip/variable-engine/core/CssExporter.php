<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

class CssExporter {

    /**
     * Export all variables to /wp-content/uploads/variable-engine/variables.css
     */
    public function export(): bool {
        $manager = new VariableManager();
        $vars = $manager->get_all();

        if ( empty( $vars ) ) {
            // Write an empty file so the enqueue doesn't error.
            if ( ! $this->write( "/* Variable Engine — no variables defined yet. */\n:root {}\n" ) ) {
                return false;
            }
            return ( new \VE\Adapters\Bricks\VariablesMirror() )->sync( [] );
        }

        usort( $vars, static function ( $a, $b ) {
            return (int) ( $b['id'] ?? 0 ) <=> (int) ( $a['id'] ?? 0 );
        } );

        $declarations = [];
        foreach ( $vars as $v ) {
            $css_name = $manager->to_css_name( $v['name'] );
            if ( isset( $declarations[ $css_name ] ) ) {
                continue;
            }
            $value    = $v['css_value'] ?: $v['value'];
            $declarations[ $css_name ] = "  {$css_name}: {$value};";
        }
        ksort( $declarations, SORT_NATURAL );
        $lines = array_values( $declarations );

        $header = "/* Variable Engine v" . VE_VERSION . " - Auto-generated. Do not edit. */\n";
        $css    = $header . ":root {\n" . implode( "\n", $lines ) . "\n}\n";

        if ( ! $this->write( $css ) ) {
            return false;
        }

        return ( new \VE\Adapters\Bricks\VariablesMirror() )->sync( $vars );
    }

    /**
     * Write CSS string to disk.
     */
    private function write( string $css ): bool {
        $dir = VE_CSS_OUTPUT_DIR;

        if ( ! is_dir( $dir ) && ! wp_mkdir_p( $dir ) ) {
            return false;
        }

        $file = $dir . 'variables.css';
        $temp = tempnam( $dir, 'variables-' );
        if ( false === $temp ) {
            return false;
        }

        $written = file_put_contents( $temp, $css, LOCK_EX );
        if ( false === $written || $written !== strlen( $css ) ) {
            @unlink( $temp );
            return false;
        }

        if ( ! @rename( $temp, $file ) ) {
            $backup = $file . '.backup-' . str_replace( '.', '-', uniqid( '', true ) );
            if ( ! file_exists( $file ) || ! @rename( $file, $backup ) ) {
                @unlink( $temp );
                return false;
            }
            if ( ! @rename( $temp, $file ) ) {
                @rename( $backup, $file );
                @unlink( $temp );
                return false;
            }
            @unlink( $backup );
        }

        return true;
    }

    /**
     * Get the URL of the generated CSS file.
     */
    public function get_url(): string {
        return VE_CSS_OUTPUT_URL . 'variables.css';
    }

    /**
     * Get the path of the generated CSS file.
     */
    public function get_path(): string {
        return VE_CSS_OUTPUT_DIR . 'variables.css';
    }
}
