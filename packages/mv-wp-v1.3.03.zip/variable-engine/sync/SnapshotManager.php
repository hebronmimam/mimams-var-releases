<?php
namespace VE\Sync;

use VE\Database\Schema;
use VE\Core\VariableManager;
use VE\Core\CssExporter;

defined('ABSPATH') || exit;

/**
 * SnapshotManager — captures full variable state before sync operations.
 * Enables rollback if a sync goes wrong.
 */
class SnapshotManager {

    private const STATE_VERSION = 2;

    /**
     * Create a snapshot of all current variables.
     *
     * @param string $trigger 'manual' | 'pre_import' | 'pre_export'
     * @return int|\WP_Error Snapshot ID or an error when the state could not be captured
     */
    public function create( string $trigger = 'manual' ) {
        global $wpdb;

        $variables = $wpdb->get_results(
            'SELECT * FROM ' . Schema::table('variables') . ' ORDER BY id ASC',
            ARRAY_A
        );
        $dependencies = $wpdb->get_results(
            'SELECT * FROM ' . Schema::table('dependencies') . ' ORDER BY id ASC',
            ARRAY_A
        );
        $generators = $wpdb->get_results(
            'SELECT * FROM ' . Schema::table('generators') . ' ORDER BY id ASC',
            ARRAY_A
        );

        if ( null === $variables || null === $dependencies || null === $generators ) {
            return new \WP_Error(
                've_snapshot_read_failed',
                'Could not read the complete variable state for the snapshot.',
                [ 'status' => 500, 'database_error' => $wpdb->last_error ]
            );
        }

        $state = [
            'version'      => self::STATE_VERSION,
            'variables'    => $variables,
            'dependencies' => $dependencies,
            'generators'   => $generators,
        ];
        $encoded = wp_json_encode( $state );
        if ( false === $encoded || '' === $encoded ) {
            return new \WP_Error(
                've_snapshot_encode_failed',
                'Could not encode the complete variable state for the snapshot.',
                [ 'status' => 500 ]
            );
        }

        $inserted = $wpdb->insert(
            Schema::table('snapshots'),
            [
                'variables_state' => $encoded,
                'trigger_type'    => $trigger,
            ],
            ['%s', '%s']
        );

        if ( false === $inserted ) {
            return new \WP_Error(
                've_snapshot_create_failed',
                'Could not create the safety snapshot.',
                [ 'status' => 500, 'database_error' => $wpdb->last_error ]
            );
        }

        return (int) $wpdb->insert_id;
    }

    /**
     * Restore variables from a snapshot.
     * Deletes all current variables and recreates from snapshot state.
     *
     * @param int $snapshot_id
     * @return array|\WP_Error Restored state or an error on failure
     */
    public function rollback( int $snapshot_id ) {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . Schema::table('snapshots') . ' WHERE id = %d',
                $snapshot_id
            ),
            ARRAY_A
        );

        if ( ! $row ) {
            return new \WP_Error( 've_snapshot_not_found', 'Snapshot not found.', [ 'status' => 404 ] );
        }

        $state = $this->decode_state( (string) $row['variables_state'] );
        if ( is_wp_error( $state ) ) {
            return $state;
        }

        // Create a pre-rollback snapshot for safety.
        $safety_snapshot = $this->create('pre_rollback');
        if ( is_wp_error( $safety_snapshot ) ) {
            return $safety_snapshot;
        }

        $vars_table = Schema::table('variables');
        $deps_table = Schema::table('dependencies');
        $gens_table = Schema::table('generators');

        if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
            return new \WP_Error(
                've_snapshot_transaction_failed',
                'Snapshot restore could not start a database transaction, so no variables were changed.',
                [
                    'status'             => 500,
                    'database_error'     => $wpdb->last_error,
                    'safety_snapshot_id' => (int) $safety_snapshot,
                ]
            );
        }

        try {
            $this->must_query( "DELETE FROM {$deps_table}" );
            $this->must_query( "DELETE FROM {$gens_table}" );
            $this->must_query( "DELETE FROM {$vars_table}" );

            foreach ( $state['variables'] as $variable ) {
                $this->restore_variable( $vars_table, $variable );
            }
            foreach ( $state['generators'] as $generator ) {
                $this->restore_generator( $gens_table, $generator );
            }
            foreach ( $state['dependencies'] as $dependency ) {
                $this->restore_dependency( $deps_table, $dependency );
            }

            if ( ! ( new CssExporter() )->export() ) {
                throw new \RuntimeException( 'The restored CSS file could not be written.' );
            }

            $this->must_query( 'COMMIT' );
        } catch ( \Throwable $e ) {
            $wpdb->query( 'ROLLBACK' );
            ( new CssExporter() )->export();
            return new \WP_Error(
                've_snapshot_restore_failed',
                'Snapshot restore failed and the database changes were rolled back.',
                [
                    'status'         => 500,
                    'detail'         => $e->getMessage(),
                    'database_error' => $wpdb->last_error,
                    'safety_snapshot_id' => (int) $safety_snapshot,
                ]
            );
        }

        return [
            'variables'          => $state['variables'],
            'dependencies'       => $state['dependencies'],
            'generators'         => $state['generators'],
            'safety_snapshot_id' => (int) $safety_snapshot,
            'state_version'      => (int) $state['version'],
        ];
    }

    private function decode_state( string $json ) {
        $decoded = json_decode( $json, true );
        if ( ! is_array( $decoded ) ) {
            return new \WP_Error( 've_snapshot_invalid', 'Snapshot data is invalid.', [ 'status' => 422 ] );
        }

        // Version 1 snapshots stored only the variable array. They are safe to
        // restore only when no generated/alias relationships need reconstructing.
        if ( ! isset( $decoded['version'] ) ) {
            foreach ( $decoded as $variable ) {
                if ( ! is_array( $variable ) || 'base' !== ( $variable['type'] ?? 'base' ) ) {
                    return new \WP_Error(
                        've_snapshot_legacy_incomplete',
                        'This legacy snapshot does not contain dependency and generator state, so it cannot be restored safely.',
                        [ 'status' => 409 ]
                    );
                }
            }

            $legacy_state = [
                'version'      => 1,
                'variables'    => $decoded,
                'dependencies' => [],
                'generators'   => [],
            ];
            $integrity_error = $this->validate_state( $legacy_state );
            return $integrity_error ?: $legacy_state;
        }

        if (
            (int) $decoded['version'] !== self::STATE_VERSION
            || ! isset( $decoded['variables'], $decoded['dependencies'], $decoded['generators'] )
            || ! is_array( $decoded['variables'] )
            || ! is_array( $decoded['dependencies'] )
            || ! is_array( $decoded['generators'] )
        ) {
            return new \WP_Error( 've_snapshot_unsupported', 'Snapshot format is incomplete or unsupported.', [ 'status' => 422 ] );
        }

        $integrity_error = $this->validate_state( $decoded );
        return $integrity_error ?: $decoded;
    }

    private function validate_state( array $state ): ?\WP_Error {
        $ids = [];
        $names = [];
        $variables_by_id = [];

        foreach ( $state['variables'] as $variable ) {
            $id = (int) ( $variable['id'] ?? 0 );
            $name = (string) ( $variable['name'] ?? '' );
            $type = (string) ( $variable['type'] ?? 'base' );
            if (
                $id <= 0
                || '' === $name
                || ! in_array( $type, [ 'base', 'generated', 'alias' ], true )
                || isset( $ids[ $id ] )
                || isset( $names[ $name ] )
            ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains duplicate or invalid variable identity.', [ 'status' => 422 ] );
            }
            $ids[ $id ] = true;
            $names[ $name ] = true;
            $variables_by_id[ $id ] = $variable;
        }

        foreach ( $variables_by_id as $id => $variable ) {
            $type = (string) ( $variable['type'] ?? 'base' );
            $source_id = (int) ( $variable['source_id'] ?? 0 );
            if ( in_array( $type, [ 'generated', 'alias' ], true ) ) {
                if ( $source_id <= 0 || $source_id === $id || ! isset( $variables_by_id[ $source_id ] ) ) {
                    return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains a variable with an invalid source reference.', [ 'status' => 422 ] );
                }
            } elseif ( $source_id > 0 ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains a base variable with an unexpected source reference.', [ 'status' => 422 ] );
            }
        }

        $dependency_pairs = [];
        $dependency_ids = [];
        $dependency_children = [];
        foreach ( $state['dependencies'] as $dependency ) {
            $dependency_id = (int) ( $dependency['id'] ?? 0 );
            $parent_id = (int) ( $dependency['parent_id'] ?? 0 );
            $child_id = (int) ( $dependency['child_id'] ?? 0 );
            $relation = (string) ( $dependency['relation'] ?? '' );
            $pair = $parent_id . ':' . $child_id;
            if (
                $dependency_id <= 0
                || isset( $dependency_ids[ $dependency_id ] )
                || $parent_id <= 0
                || $child_id <= 0
                || $parent_id === $child_id
                || ! isset( $variables_by_id[ $parent_id ], $variables_by_id[ $child_id ] )
                || ! in_array( $relation, [ 'generated', 'alias' ], true )
                || isset( $dependency_pairs[ $pair ] )
                || isset( $dependency_children[ $child_id ] )
                || (int) ( $variables_by_id[ $child_id ]['source_id'] ?? 0 ) !== $parent_id
                || (string) ( $variables_by_id[ $child_id ]['type'] ?? '' ) !== $relation
            ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains an invalid variable dependency.', [ 'status' => 422 ] );
            }
            $dependency_ids[ $dependency_id ] = true;
            $dependency_pairs[ $pair ] = true;
            $dependency_children[ $child_id ] = true;
        }

        foreach ( $variables_by_id as $id => $variable ) {
            if ( in_array( (string) ( $variable['type'] ?? '' ), [ 'generated', 'alias' ], true ) && ! isset( $dependency_children[ $id ] ) ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot is missing a required variable dependency.', [ 'status' => 422 ] );
            }
        }

        $generator_ids = [];
        $generator_keys = [];
        foreach ( $state['generators'] as $generator ) {
            $generator_id = (int) ( $generator['id'] ?? 0 );
            $variable_id = (int) ( $generator['variable_id'] ?? 0 );
            $type = (string) ( $generator['type'] ?? '' );
            $key = $variable_id . ':' . $type;
            $config = json_decode( (string) ( $generator['config'] ?? '' ), true );
            if (
                $generator_id <= 0
                || isset( $generator_ids[ $generator_id ] )
                || $variable_id <= 0
                || ! isset( $variables_by_id[ $variable_id ] )
                || 'base' !== (string) ( $variables_by_id[ $variable_id ]['type'] ?? '' )
                || ! in_array( $type, [ 'color', 'spacing', 'typography', 'radius', 'size' ], true )
                || isset( $generator_keys[ $key ] )
                || ! is_array( $config )
            ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains an invalid generator row.', [ 'status' => 422 ] );
            }
            $generator_ids[ $generator_id ] = true;
            $generator_keys[ $key ] = true;
        }

        return null;
    }

    private function restore_variable( string $table, array $row ): void {
        global $wpdb;

        if ( empty( $row['id'] ) || empty( $row['name'] ) ) {
            throw new \RuntimeException( 'Snapshot contains an invalid variable row.' );
        }

        $inserted = $wpdb->insert(
            $table,
            [
                'id'             => (int) $row['id'],
                'name'           => (string) $row['name'],
                'type'           => (string) ( $row['type'] ?? 'base' ),
                'namespace'      => (string) ( $row['namespace'] ?? '' ),
                'value'          => (string) ( $row['value'] ?? '' ),
                'css_value'      => (string) ( $row['css_value'] ?? '' ),
                'source_id'      => empty( $row['source_id'] ) ? null : (int) $row['source_id'],
                'generator_type' => empty( $row['generator_type'] ) ? null : (string) $row['generator_type'],
                'created_at'     => (string) ( $row['created_at'] ?? current_time( 'mysql', true ) ),
                'updated_at'     => (string) ( $row['updated_at'] ?? current_time( 'mysql', true ) ),
            ],
            [ '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' ]
        );

        if ( false === $inserted ) {
            throw new \RuntimeException( 'Could not restore variable #' . (int) $row['id'] . ': ' . $wpdb->last_error );
        }
    }

    private function restore_generator( string $table, array $row ): void {
        global $wpdb;

        if ( empty( $row['id'] ) || empty( $row['variable_id'] ) || empty( $row['type'] ) ) {
            throw new \RuntimeException( 'Snapshot contains an invalid generator row.' );
        }

        $inserted = $wpdb->insert(
            $table,
            [
                'id'          => (int) $row['id'],
                'variable_id' => (int) $row['variable_id'],
                'type'        => (string) $row['type'],
                'config'      => (string) ( $row['config'] ?? '{}' ),
                'active'      => empty( $row['active'] ) ? 0 : 1,
                'created_at'  => (string) ( $row['created_at'] ?? current_time( 'mysql', true ) ),
            ],
            [ '%d', '%d', '%s', '%s', '%d', '%s' ]
        );

        if ( false === $inserted ) {
            throw new \RuntimeException( 'Could not restore generator #' . (int) $row['id'] . ': ' . $wpdb->last_error );
        }
    }

    private function restore_dependency( string $table, array $row ): void {
        global $wpdb;

        if ( empty( $row['id'] ) || empty( $row['parent_id'] ) || empty( $row['child_id'] ) ) {
            throw new \RuntimeException( 'Snapshot contains an invalid dependency row.' );
        }

        $inserted = $wpdb->insert(
            $table,
            [
                'id'         => (int) $row['id'],
                'parent_id'  => (int) $row['parent_id'],
                'child_id'   => (int) $row['child_id'],
                'relation'   => (string) ( $row['relation'] ?? 'generated' ),
                'created_at' => (string) ( $row['created_at'] ?? current_time( 'mysql', true ) ),
            ],
            [ '%d', '%d', '%d', '%s', '%s' ]
        );

        if ( false === $inserted ) {
            throw new \RuntimeException( 'Could not restore dependency #' . (int) $row['id'] . ': ' . $wpdb->last_error );
        }
    }

    private function must_query( string $sql ): void {
        global $wpdb;
        if ( false === $wpdb->query( $sql ) ) {
            throw new \RuntimeException( $wpdb->last_error ?: 'Database operation failed.' );
        }
    }

    /**
     * List all snapshots (newest first).
     *
     * @param int $limit
     * @return array
     */
    public function list( int $limit = 20 ): array {
        global $wpdb;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, trigger_type, created_at, variables_state FROM ' . Schema::table('snapshots') .
                ' ORDER BY id DESC LIMIT %d',
                $limit
            ),
            ARRAY_A
        ) ?: [];

        foreach ( $rows as &$row ) {
            $state = $this->decode_state( (string) ( $row['variables_state'] ?? '' ) );
            $row['restorable'] = ! is_wp_error( $state );
            $row['state_version'] = is_wp_error( $state ) ? 1 : (int) $state['version'];
            $row['restore_warning'] = is_wp_error( $state ) ? $state->get_error_message() : '';
            unset( $row['variables_state'] );
        }
        unset( $row );

        return $rows;
    }

    /**
     * Get a single snapshot by ID.
     */
    public function get( int $id ): ?array {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . Schema::table('snapshots') . ' WHERE id = %d',
                $id
            ),
            ARRAY_A
        );

        return $row ?: null;
    }
}
