/**
 * Slice 8 — §100.1's "shortening the window".
 *
 * The leak this slice repairs is created by a Bricks tab that is already open
 * when MV stops running. The server-side repair in WorkspaceFingerprint is the
 * contract; this file is the courtesy that makes the repair rarer, and the
 * handoff is explicit that it is best-effort and can be bypassed. That is
 * exactly why it is not allowed to be the only thing standing there.
 *
 * So: while a workspace session is open, ask MV every few seconds whether it is
 * still answering. If it stops, block Bricks' save and say why. A save that is
 * blocked here never becomes a leak that has to be found and undone later.
 *
 * Deliberately NOT doing:
 *   - guessing from a 500 or a 403. Those mean MV answered. Only a request that
 *     does not arrive means MV is gone, and the fetch rejecting is that.
 *   - blocking on the first miss. One dropped request on a flaky connection is
 *     not a deactivated plugin, and an editor locked out of saving by a hiccup
 *     will work around this file, which helps nobody.
 *   - unblocking Bricks' button if something else disabled it. This puts back
 *     only what it took away.
 */
( function () {
	'use strict';

	var cfg = window.vePanel || {};
	var ws  = cfg.workspace ? parseInt( cfg.workspace, 10 ) : 0;

	if ( ! ws || 'builder' !== cfg.mode || ! cfg.apiRoot ) {
		return;
	}

	var EVERY   = 8000;   // ms between polls
	var FORGIVE = 2;      // consecutive misses before the door closes

	var missed  = 0;
	var blocked = false;
	var banner  = null;
	var timer   = null;

	function url() {
		var root = String( cfg.apiRoot ).replace( /\/+$/, '' );
		var ns   = cfg.namespace || 'variable-engine/v1';
		return root + '/' + ns + '/workspaces/' + ws + '/lifecycle';
	}

	/** Bricks' own save controls, whatever the build calls them. */
	function saveControls() {
		var found = [];
		[ '#bricks-panel-header .bricks-save-post', '.bricks-save-post',
		  '#bricks-toolbar .save', '[data-balloon="Save"]' ].forEach( function ( sel ) {
			Array.prototype.forEach.call( document.querySelectorAll( sel ), function ( el ) {
				if ( -1 === found.indexOf( el ) ) {
					found.push( el );
				}
			} );
		} );
		return found;
	}

	function block() {
		if ( blocked ) {
			return;
		}
		blocked = true;

		saveControls().forEach( function ( el ) {
			// Marked so unblock() puts back only what this file took away.
			el.setAttribute( 'data-ve-ws-blocked', '1' );
			el.style.pointerEvents = 'none';
			el.style.opacity = '0.45';
		} );

		// The capture-phase listener is the part that actually holds the door:
		// Bricks saves from its own handlers and from ⌘S, and a greyed button is
		// only the sign on the door.
		document.addEventListener( 'click', swallow, true );
		document.addEventListener( 'keydown', swallowKey, true );

		banner = document.createElement( 'div' );
		banner.className = 've-ws-offline';
		banner.setAttribute( 'role', 'alert' );
		banner.textContent = 'Workspace runtime unavailable — saving is paused. '
			+ 'Mimam’s Var has stopped responding, so a save now would be '
			+ 'written to the live site instead of your workspace. Reload once it '
			+ 'is back.';
		banner.style.cssText = 'position:fixed;z-index:100000;left:12px;right:12px;'
			+ 'bottom:12px;padding:10px 14px;border-radius:6px;background:#7a1d1d;'
			+ 'color:#fff;font:13px/1.45 system-ui,sans-serif;'
			+ 'box-shadow:0 2px 12px rgba(0,0,0,.35)';
		document.body.appendChild( banner );
	}

	function unblock() {
		if ( ! blocked ) {
			return;
		}
		blocked = false;

		Array.prototype.forEach.call(
			document.querySelectorAll( '[data-ve-ws-blocked]' ),
			function ( el ) {
				el.removeAttribute( 'data-ve-ws-blocked' );
				el.style.pointerEvents = '';
				el.style.opacity = '';
			}
		);

		document.removeEventListener( 'click', swallow, true );
		document.removeEventListener( 'keydown', swallowKey, true );

		if ( banner && banner.parentNode ) {
			banner.parentNode.removeChild( banner );
		}
		banner = null;
	}

	function swallow( e ) {
		var el = e.target && e.target.closest
			? e.target.closest( '[data-ve-ws-blocked]' )
			: null;
		if ( el ) {
			e.preventDefault();
			e.stopPropagation();
		}
	}

	function swallowKey( e ) {
		if ( 's' === String( e.key ).toLowerCase() && ( e.metaKey || e.ctrlKey ) ) {
			e.preventDefault();
			e.stopPropagation();
		}
	}

	function poll() {
		fetch( url(), {
			credentials: 'same-origin',
			headers: { 'X-WP-Nonce': cfg.nonce || '' }
		} ).then( function ( res ) {
			/* MV answered. A 403 or a 500 is still an answer - the plugin is
			   there, and blocking a save because a permission check said no
			   would be this file inventing a problem. */
			missed = 0;
			if ( res ) {
				unblock();
			}
		} ).catch( function () {
			missed += 1;
			if ( missed >= FORGIVE ) {
				block();
			}
		} );
	}

	function start() {
		if ( timer ) {
			return;
		}
		poll();
		timer = window.setInterval( poll, EVERY );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', start );
	} else {
		start();
	}

	// For the guard, and for anyone debugging this from the console.
	window.veWorkspaceGuard = {
		poll: poll,
		block: block,
		unblock: unblock,
		state: function () {
			return { workspace: ws, missed: missed, blocked: blocked, forgive: FORGIVE };
		}
	};
}() );
