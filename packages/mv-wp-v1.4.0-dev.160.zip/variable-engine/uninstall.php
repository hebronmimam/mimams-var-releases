<?php
/**
 * Variable Engine uninstall.
 *
 * Handoff §96, and slice 12. WordPress runs this when the plugin is DELETED,
 * not when it is deactivated - §96.1 is satisfied by this file not running
 * then, and by nothing else of MV's deleting anything at deactivation.
 *
 * §96.2 is the default and the point of the file: **preserve**. WordPress
 * takes the code away and MV's data stays where it is, recoverable by
 * reinstalling. Nothing below runs unless somebody has chosen otherwise and
 * confirmed it, which `WorkspaceLifecycle::set_policy()` requires.
 *
 * §96.3 is the destructive opt-in, and its limits are the reason this file is
 * a list of names rather than a loop over `$wpdb->tables()`. Removal must
 * NOT:
 *
 *   * publish unfinished workspace changes - so nothing here writes to a post,
 *     an option Bricks owns, or anything on the live site;
 *   * restore an older live state - so nothing here rolls anything back;
 *   * remove native published Bricks or WordPress state - so `bricks_*`
 *     options and every post are left exactly as they are, including the
 *     shadow posts' live counterparts;
 *   * delete RestoreBase recovery points merely because MV was removed - so
 *     nothing here touches them, whoever owns them.
 *
 * The workspace tables go only inside this branch. Uninstalling is not
 * publishing and is not rolling back: an unfinished workspace survives an
 * ordinary uninstall and is lost only when destructive cleanup is chosen.
 *
 * §102 is the other half, and it is not here: someone can delete this folder
 * without WordPress ever running this file. Live safety cannot depend on it,
 * and does not - the overlay is a request-time filter that never writes a live
 * row. See `WorkspaceLifecycle` and `scripts/check-workspace-manual-removal.php`.
 */
defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

/* §96, and preserve is the default in both spellings. `ve_uninstall_policy` is
   what the panel writes; `ve_delete_on_uninstall` is the boolean this file has
   always read and is kept in step with it. Either one asking to remove is
   enough, because the only way to set either is to have confirmed it. */
$policy   = get_option( 've_uninstall_policy', 'preserve' );
$destroy  = ( 'remove' === $policy ) || (bool) get_option( 've_delete_on_uninstall', false );

if ( ! $destroy ) {
    return;
}

global $wpdb;
$p = $wpdb->prefix;

/* MV-owned tables. Named one at a time: a prefix loop would take anything a
   later plugin happened to call `ve_`, and this is not an operation to be
   approximate about. */
foreach ( [
    've_dependencies',
    've_generators',
    've_sync_logs',
    've_snapshots',
    've_color_palette_members',
    /* `ve_color_palettes` stores THEMES (value layers), not colour palettes.
       The name is historical (v1.3.05) and was never migrated. Colour palettes
       live in the `color_palettes` tables, owned by ColorPaletteManager. */
    've_color_palettes',
    've_variables',
    // Workspaces, their objects, and what was published from them.
    've_workspaces',
    've_workspace_objects',
    've_workspace_releases',
] as $table ) {
    $wpdb->query( 'DROP TABLE IF EXISTS ' . $p . $table );
}

// MV-owned options, by name for the same reason.
foreach ( [
    've_db_version',
    've_delete_on_uninstall',
    've_uninstall_policy',
    've_settings',
    've_license',
    've_advanced_css',
    've_color_palettes',
    've_active_color_palette',
] as $option ) {
    delete_option( $option );
}

/* Workspace runtime state: the held payloads, the fingerprints and the
   sessions. These are per-workspace and there is no list of them left once the
   tables are gone, so they are matched on MV's own prefixes - and only on
   those. */
$wpdb->query(
    "DELETE FROM {$wpdb->options}
      WHERE option_name LIKE 've\\_ws\\_%'
         OR option_name LIKE 've\\_workspace\\_%'"
);
// `_ve_workspace_session`, which begins with an underscore, as user meta does.
$wpdb->query( "DELETE FROM {$wpdb->usermeta} WHERE meta_key LIKE '\\_ve\\_workspace\\_%'" );

/* Generated CSS. MV's own directory, and the per-workspace Bricks CSS
   directories MV created beside Bricks' own - never Bricks' own, which holds
   the CSS the live site is being served right now. */
$uploads = wp_upload_dir( null, false );
$basedir = isset( $uploads['basedir'] ) ? $uploads['basedir'] : '';

if ( $basedir ) {
    $ve_dir = $basedir . '/variable-engine/';
    if ( is_dir( $ve_dir ) ) {
        foreach ( (array) glob( $ve_dir . '*' ) as $file ) {
            if ( is_file( $file ) ) {
                unlink( $file );
            }
        }
        rmdir( $ve_dir );
    }

    /* `ve-ws-<id>` directories beside Bricks' own CSS. MV's, never Bricks'.
       Bricks' CSS directory is read from `\Bricks\Assets::$css_dir` at run
       time and this file runs with MV gone, so only the documented default is
       searched. A site that has moved that directory keeps its `ve-ws-*`
       folders, which is §103.2 exactly: files may remain physically present
       and unreachable. Nothing references them once MV is gone. */
    foreach ( [ $basedir . '/bricks/css/ve-ws-*', $basedir . '/ve-ws-*' ] as $pattern ) {
        foreach ( (array) glob( $pattern, GLOB_ONLYDIR ) as $dir ) {
            foreach ( (array) glob( $dir . '/*' ) as $file ) {
                if ( is_file( $file ) ) {
                    unlink( $file );
                }
            }
            rmdir( $dir );
        }
    }
}
