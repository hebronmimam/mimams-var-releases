<?php
/**
 * Publishing a workspace: preflight, apply, verify, commit.
 *
 * Slice 5 of the Workspaces module — the structural half of handoff §20.
 *
 * THE ONE RULE THAT SHAPES ALL OF THIS (§13)
 *
 *   > Do not simply publish the shadow post as a replacement when doing so
 *   > would break canonical identity, menus, external references, template
 *   > assignments, or other relationships.
 *
 * So publishing does NOT promote the shadow and does NOT delete the live post.
 * It copies the shadow's Bricks payload onto the LIVE post id. The published
 * page keeps its ID, its slug, its menu entries, its template assignments and
 * every link anyone has ever made to it. The shadow stays exactly where it was,
 * still a draft, so the workspace is still a workspace after a publish.
 *
 * AND THE ONE THAT DECIDES THE ORDER OF OPERATIONS (§68.12)
 *
 *   > Do not mark publish/deploy successful before verification.
 *
 * Written out, that is: open a release, apply, re-read what landed, compare it
 * with what was meant to land, and only then say the word "published". A
 * publish that verifies nothing is a publish that reports its own intentions.
 *
 * If verification fails for any object, every object this release wrote is put
 * back from its own `prior_payload` and the release is recorded as failed with
 * the object that broke it named. Partly-published is not a state a person
 * should ever have to reason about.
 *
 * WHAT IT REFUSES, AND WHY EACH REFUSAL IS NOT PESSIMISM
 *
 *   - a conflict (§68.11, do not silently merge): the page changed here AND on
 *     the site. Publishing would throw away the live change without saying so.
 *   - a live page that has gone: there is no identity left to publish onto.
 *   - an archived workspace, and a workspace with nothing to publish.
 *
 * A workspace that is merely BEHIND is publishable: its pages have not changed
 * on the site, only others have. That is said in the preflight rather than
 * blocked, because it is information, not a fault.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspacePublish {

    /**
     * What would happen, computed from the current state of the site.
     *
     * Always runs the slice 4 comparison first: a preflight made from stale
     * hashes is a preflight of a site that may no longer exist.
     */
    public static function preflight( int $workspace_id ): array {
        $workspace = WorkspaceStore::get( $workspace_id );
        if ( ! $workspace ) {
            return self::refusal( 've_workspace_missing', 'That workspace no longer exists.' );
        }
        if ( WorkspaceStore::STATUS_ARCHIVED === $workspace['status'] ) {
            return self::refusal(
                've_workspace_archived',
                'Bring the workspace back before publishing from it.'
            );
        }

        $objects   = WorkspaceSnapshot::refresh_all( $workspace_id );
        $publish   = [];
        $conflicts = [];
        $behind    = [];
        $missing   = [];
        $unchanged = 0;

        foreach ( $objects as $object ) {
            $state = isset( $object['state'] ) ? (string) $object['state'] : WorkspaceSnapshot::UNCHANGED;

            if ( ! self::live_exists( $object ) ) {
                $missing[] = $object;
                continue;
            }
            if ( WorkspaceSnapshot::CONFLICT === $state ) {
                $conflicts[] = $object;
                continue;
            }
            if ( WorkspaceSnapshot::BEHIND === $state ) {
                $behind[] = $object;
                $unchanged += 1;
                continue;
            }
            if ( WorkspaceSnapshot::MODIFIED === $state ) {
                $publish[] = $object;
                continue;
            }
            if ( WorkspaceSnapshot::CONVERGED === $state ) {
                // Both changed to the same thing. Writing it would be a no-op
                // that still spends a release record, so it is reported and
                // left alone rather than published.
                $unchanged += 1;
                continue;
            }
            $unchanged += 1;
        }

        $blockers = [];
        if ( $conflicts ) {
            $blockers[] = [
                'code'    => 've_publish_conflicts',
                'message' => self::count_phrase( count( $conflicts ), 'page' )
                    . ' changed here and on the site. Publishing would overwrite the live change.',
                'objects' => array_map( [ __CLASS__, 'brief' ], $conflicts ),
            ];
        }
        if ( $missing ) {
            $blockers[] = [
                'code'    => 've_publish_live_missing',
                'message' => self::count_phrase( count( $missing ), 'page' )
                    . ' no longer on the site, so there is nothing to publish onto.',
                'objects' => array_map( [ __CLASS__, 'brief' ], $missing ),
            ];
        }
        /* SLICE 11, §32. What the objects going out actually need, and whether
           publishing would leave each of those needs met. An unsupported one is
           a REFUSAL, not a warning: a page published pointing at a template
           that exists nowhere renders a hole, and it renders it live. */
        $deps = class_exists( __NAMESPACE__ . '\WorkspaceDependencies' )
            ? WorkspaceDependencies::report( $workspace_id )
            : [ 'items' => [], 'unsupported' => [], 'unknown' => [] ];

        if ( $deps['unsupported'] ) {
            $names = [];
            foreach ( $deps['unsupported'] as $dep ) {
                $names[ $dep['label'] ] = true;
            }
            $blockers[] = [
                'code'    => 've_publish_unsupported_dependency',
                'message' => 'Cannot publish. '
                    . self::count_phrase( count( $names ), 'thing' )
                    . ' needed here that publishing cannot provide: '
                    . implode( ', ', array_slice( array_keys( $names ), 0, 4 ) )
                    . ( count( $names ) > 4 ? ' and others' : '' ) . '.',
                'objects' => array_values( $deps['unsupported'] ),
            ];
        }

        /* §87.6. A global that changed here AND on the site is a conflict, and
           publish is blocked until somebody says which value wins. Slice 8 found
           these and retained them; until now nothing stopped a publish walking
           over one. */
        $globals = [];
        if ( class_exists( __NAMESPACE__ . '\WorkspaceFingerprint' ) ) {
            $globals = WorkspaceFingerprint::unresolved( $workspace_id );
        }
        if ( $globals ) {
            $blockers[] = [
                'code'    => 've_publish_global_conflicts',
                'message' => self::count_phrase( count( $globals ), 'global' )
                    . ' changed here and on the site. Choose which value wins before publishing.',
                'objects' => array_map( static function ( $family ) use ( $globals ) {
                    $c = $globals[ $family ];
                    return [
                        'family'         => $family,
                        'base_hash'      => (string) ( $c['base_hash'] ?? '' ),
                        'workspace_hash' => (string) ( $c['workspace_hash'] ?? '' ),
                        'live_hash'      => (string) ( $c['live_hash'] ?? '' ),
                        'choices'        => [ 'keep_workspace', 'keep_live', 'skip' ],
                    ];
                }, array_keys( $globals ) ),
            ];
        }

        /* SLICE 11. A workspace whose only change is a GLOBAL - a variable
           edited in the builder, which slices 7-10 hold in the workspace and
           never in an object snapshot - has nothing in $publish and everything
           to publish. Counting only objects here is what made "change a
           variable, then publish" answer "nothing has changed". */
        $plan = self::global_plan( $workspace_id );

        if ( ! $publish && ! $plan['write'] && ! $blockers ) {
            $blockers[] = [
                'code'    => 've_publish_nothing',
                'message' => 'Nothing in this workspace has changed, so there is nothing to publish.',
                'objects' => [],
            ];
        }

        return [
            'ok'        => empty( $blockers ),
            'workspace' => $workspace_id,
            'publish'   => array_map( [ __CLASS__, 'brief' ], $publish ),
            'behind'    => array_map( [ __CLASS__, 'brief' ], $behind ),
            'conflicts' => array_map( [ __CLASS__, 'brief' ], $conflicts ),
            'missing'   => array_map( [ __CLASS__, 'brief' ], $missing ),
            'unchanged' => $unchanged,
            /* §87.4 - "include dependencies visibly". Reported whether or not
               anything is wrong with them, because a change set that only
               mentions its dependencies when they break is one nobody learns to
               read. */
            'dependencies' => $deps['items'],
            'unknown'      => $deps['unknown'],
            /* Named, not counted. "2 globals" leaves somebody who answered
               `skip` on one of them wondering which two went out. */
            'globals'         => $plan['write'],
            'globals_skipped' => $plan['skipped'],
            /* §87.6. What has been answered, so the panel can show the choice
               back and let it be changed - an answer nobody can see again is a
               decision they cannot revisit. */
            'global_answers'  => $plan['answers'],
            'blockers'        => $blockers,
        ];
    }

    /**
     * Do it.
     *
     * @return array|\WP_Error The release record, or the preflight that refused.
     */
    public static function publish( int $workspace_id ) {
        $pre = self::preflight( $workspace_id );
        if ( empty( $pre['ok'] ) ) {
            return [ 'published' => false, 'preflight' => $pre ];
        }

        /* The objects are re-read by uuid rather than carried over from the
           preflight: between the two, nothing should have changed, and "should"
           is not a word to apply a page on. */
        $targets = [];
        foreach ( WorkspaceSnapshot::refresh_all( $workspace_id ) as $object ) {
            if ( WorkspaceSnapshot::MODIFIED === (string) $object['state'] && self::live_exists( $object ) ) {
                $targets[] = $object;
            }
        }
        /* SLICE 11. A globals-only publish has no object targets and plenty
           to do, so "nothing to publish" is both lists being empty. */
        if ( ! $targets && ! self::global_plan( $workspace_id )['write'] ) {
            return [ 'published' => false, 'preflight' => self::preflight( $workspace_id ) ];
        }

        /* SLICE 11, §32. Depended-on objects first.

           A page that pulls in a template has to go out after it, or for the
           moment between the two writes the live page points at a template that
           is still the old one. Ordering by id was repeatable and arbitrary;
           this is repeatable and means something.

           Ties keep the old rule, so the order stays deterministic for a
           release record when nothing depends on anything. */
        $needed_by = self::dependency_depth( $workspace_id, $targets );
        usort( $targets, static function ( $a, $b ) use ( $needed_by ) {
            $da = $needed_by[ (int) $a['id'] ] ?? 0;
            $db = $needed_by[ (int) $b['id'] ] ?? 0;
            if ( $da !== $db ) {
                return $db <=> $da;   // most depended-on first
            }
            return (int) $a['id'] <=> (int) $b['id'];
        } );

        $planned = [];
        foreach ( $targets as $object ) {
            $planned[] = WorkspaceRelease::entry(
                $object,
                null,
                (string) $object['hashes']['base'],
                (string) $object['hashes']['workspace']
            );
        }

        /* SLICE 11, and the thing slices 7-10 left undone.

           Those slices isolate sixteen globals and hold every write. Nothing
           ever put them BACK. `restore_live()` had exactly two callers - the
           leak repair and the delete-undo - and neither was publish, so a
           variable changed in a workspace was held correctly and then held for
           ever. Three checklist rows have been asking the owner to publish and
           confirm the change reached the site.

           Done before the release opens so a failure here refuses the whole
           publish rather than leaving half of one on the site. */
        /* SLICE 12, §101. The release is opened FIRST.

           It used to be opened after the globals had already gone out, so a
           process killed during those wrote sixteen live options with no
           record anywhere that a publish was in progress. A journal that
           starts after the first write is not a journal. */
        $release = WorkspaceRelease::open( $workspace_id, $planned );
        if ( ! is_array( $release ) || isset( $release['error'] ) || is_wp_error( $release ) ) {
            return $release;
        }
        $release_id = (int) $release['id'];

        /* Each family's previous value reaches the release row before that
           family is written, so an interruption inside this call still leaves
           something to put the site back from. */
        $globals = self::publish_globals(
            $workspace_id,
            static function ( array $undo ) use ( $release_id ) {
                WorkspaceJournal::note_globals( $release_id, $undo, WorkspaceJournal::WRITING );
            }
        );
        if ( is_wp_error( $globals ) ) {
            WorkspaceRelease::settle( $release_id, WorkspaceRelease::FAILED, $globals->get_error_message(), $planned );
            return $globals;
        }
        WorkspaceJournal::note_globals( $release_id, $globals['undo'], WorkspaceJournal::WRITTEN );

        $written = [];
        $applied = [];
        $global_result = $globals;
        foreach ( $targets as $object ) {
            $live   = (int) $object['live_id'];
            $shadow = (int) $object['shadow_id'];

            // §113: the whole previous value, captured BEFORE anything is
            // written, and kept per object so slice 6 can restore this one
            // alone.
            $prior = WorkspaceSnapshot::payload( $live );

            $entry = WorkspaceRelease::entry(
                $object,
                $prior,
                (string) $object['hashes']['base'],
                (string) $object['hashes']['workspace']
            );
            $applied[] = $entry;

            /* SLICE 12, §101. On disk before the page is touched.

               This array used to be the only copy: `$written` and `$applied`
               lived in PHP until `settle()` at the end, so a fatal or a
               timeout inside this loop left pages changed on the site, a
               release reading `applying`, and nothing that said which pages or
               what they had been. */
            WorkspaceJournal::note(
                $release_id,
                (string) $entry['object_uuid'],
                array_merge( $entry, [ 'state' => WorkspaceJournal::WRITING ] )
            );

            BricksPageAdapter::apply_payload( $live, WorkspaceSnapshot::payload( $shadow ) );
            WorkspaceJournal::note(
                $release_id,
                (string) $entry['object_uuid'],
                [ 'state' => WorkspaceJournal::WRITTEN ]
            );
            $written[] = [ 'object' => $object, 'prior' => $prior ];
        }

        /* §68.12. Re-read the live pages and compare what is there with what
           was meant to be there. Not "the writes returned true" - what landed. */
        $broken = null;
        foreach ( $targets as $i => $object ) {
            $wanted = (string) $object['hashes']['workspace'];
            $landed = WorkspaceSnapshot::hash( (int) $object['live_id'] );
            if ( $landed !== $wanted ) {
                $broken = [ 'object' => $object, 'wanted' => $wanted, 'landed' => $landed ];
                break;
            }
        }

        if ( $broken ) {
            foreach ( array_reverse( $written ) as $undo ) {
                BricksPageAdapter::apply_payload( (int) $undo['object']['live_id'], $undo['prior'] );
            }
            /* The globals went out before the pages, so putting the pages back
               and leaving the globals on the site would be exactly the
               partly-published state this file refuses to create. */
            self::unpublish_globals( $workspace_id, $global_result['undo'] );

            $reason = 'Verification failed on "' . $broken['object']['label'] . '". Nothing was published: '
                . 'every page this release had already written was put back'
                . ( $global_result['written'] ? ', and every global setting with them' : '' ) . '.';
            WorkspaceRelease::settle( $release_id, WorkspaceRelease::FAILED, $reason, $applied );
            return [
                'published' => false,
                'release'   => WorkspaceRelease::get( (int) $release['id'] ),
                'failed_on' => self::brief( $broken['object'] ),
            ];
        }

        /* Verified, and only now. The base moves to what was just published, so
           §19 reads "unchanged" on every page this release carried - which is
           true: the workspace and the site now say the same thing. */
        foreach ( $targets as $object ) {
            $published = (string) $object['hashes']['workspace'];
            WorkspaceObjectMap::set_hashes(
                (int) $object['id'],
                [ 'base' => $published, 'workspace' => $published, 'live' => $published ],
                WorkspaceSnapshot::UNCHANGED
            );
        }

        WorkspaceRelease::settle(
            $release_id,
            WorkspaceRelease::PUBLISHED,
            self::settled_phrase( count( $targets ), count( $global_result['written'] ) ),
            $applied
        );

        return [
            'published' => true,
            'release'   => WorkspaceRelease::get( (int) $release['id'] ),
            'count'     => count( $targets ),
            /* Slice 11. Named rather than counted: "2 globals published" leaves
               somebody who chose `skip` on one of them wondering which two. */
            'globals'   => $global_result['written'],
            'skipped'   => $global_result['skipped'],
        ];
    }

    /**
     * Slice 12, §101 - an interrupted publish, finished or put back.
     *
     * Never from a step counter, and never from the journal's own marks
     * either: both can be one step behind what happened. `assess()` reads the
     * live objects and compares them with the two hashes the journal kept, and
     * this refuses outright unless every object is either where it started or
     * where the release meant to put it. "Resume only if provably safe" is a
     * real condition, not a flourish: an object somebody else has changed since
     * is never written to and never restored.
     *
     * @param string $choice 'finish' or 'undo'.
     * @return array|\WP_Error
     */
    public static function recover( int $release_id, string $choice ) {
        $release = WorkspaceRelease::get( $release_id );
        if ( ! $release ) {
            return new \WP_Error( 've_release_missing', 'That release no longer exists.', [ 'status' => 404 ] );
        }
        if ( WorkspaceRelease::APPLYING !== $release['status'] ) {
            return new \WP_Error(
                've_release_settled',
                'That release was already recorded as ' . $release['status'] . '.',
                [ 'status' => 409 ]
            );
        }

        $report = WorkspaceJournal::assess( $release );
        if ( empty( $report['safe'] ) ) {
            return new \WP_Error(
                've_recover_unsafe',
                $report['headline'],
                [ 'status' => 409, 'report' => $report ]
            );
        }

        return 'finish' === $choice
            ? self::finish_interrupted( $release, $report )
            : self::undo_interrupted( $release, $report );
    }

    /**
     * Put back everything this release had written, and record it as failed.
     *
     * Only objects the site agrees this release wrote are touched - `applied`,
     * and holding a prior payload. Anything else is left exactly as found.
     */
    private static function undo_interrupted( array $release, array $report ) {
        $by_uuid = [];
        foreach ( $release['objects'] as $entry ) {
            $by_uuid[ (string) ( $entry['object_uuid'] ?? '' ) ] = $entry;
        }

        $restored = [];
        foreach ( $report['objects'] as $object ) {
            if ( empty( $object['undoable'] ) ) {
                continue;
            }
            $entry = isset( $by_uuid[ $object['uuid'] ] ) ? $by_uuid[ $object['uuid'] ] : null;
            if ( ! $entry ) {
                continue;
            }
            BricksPageAdapter::apply_payload( (int) $object['live_id'], $entry['prior_payload'] );
            // §68.12 again: what landed, not what the write answered.
            if ( WorkspaceSnapshot::hash( (int) $object['live_id'] ) === (string) $entry['base_hash'] ) {
                $restored[] = (string) $object['label'];
            }
        }

        $globals = $report['globals'];
        if ( $globals && ! empty( $globals['undo'] ) ) {
            self::unpublish_globals( (int) $release['workspace'], $globals['undo'] );
        }

        $wrote  = $globals ? (int) $globals['written'] : 0;
        $reason = ( $restored || $wrote )
            ? 'Interrupted, and put back: ' . self::listed( $restored )
                . ( $wrote ? ( $restored ? ', and ' : '' ) . $wrote . ' global setting'
                    . ( 1 === $wrote ? '' : 's' ) : '' ) . '.'
            : 'Interrupted before anything reached the site. Nothing needed putting back.';

        WorkspaceRelease::settle( (int) $release['id'], WorkspaceRelease::FAILED, $reason, $release['objects'] );

        return [
            'recovered' => true,
            'choice'    => 'undo',
            'restored'  => $restored,
            'globals'   => $wrote,
            'release'   => WorkspaceRelease::get( (int) $release['id'] ),
            'message'   => $reason,
        ];
    }

    /**
     * Write the objects this release never reached, and settle it published.
     *
     * The ones already on the site are left alone rather than written again:
     * they are byte for byte what this release meant them to be, which is what
     * `applied` means.
     */
    private static function finish_interrupted( array $release, array $report ) {
        $workspace = (int) $release['workspace'];

        $shadows = [];
        foreach ( WorkspaceSnapshot::refresh_all( $workspace ) as $object ) {
            $shadows[ (string) $object['uuid'] ] = $object;
        }
        $by_uuid = [];
        foreach ( $release['objects'] as $entry ) {
            $by_uuid[ (string) ( $entry['object_uuid'] ?? '' ) ] = $entry;
        }

        $done = [];
        foreach ( $report['objects'] as $object ) {
            if ( WorkspaceJournal::APPLIED === $object['verdict'] ) {
                $done[] = $object;
                continue;
            }
            $source = isset( $shadows[ $object['uuid'] ] ) ? $shadows[ $object['uuid'] ] : null;
            $entry  = isset( $by_uuid[ $object['uuid'] ] ) ? $by_uuid[ $object['uuid'] ] : null;
            if ( ! $source || ! $entry ) {
                return new \WP_Error(
                    've_recover_gone',
                    'The workspace no longer holds "' . $object['label'] . '", so this publish cannot be '
                        . 'finished. Put it back instead.',
                    [ 'status' => 409 ]
                );
            }
            WorkspaceJournal::note( (int) $release['id'], $object['uuid'], [ 'state' => WorkspaceJournal::WRITING ] );
            BricksPageAdapter::apply_payload(
                (int) $object['live_id'],
                WorkspaceSnapshot::payload( (int) $source['shadow_id'] )
            );
            WorkspaceJournal::note( (int) $release['id'], $object['uuid'], [ 'state' => WorkspaceJournal::WRITTEN ] );
            $done[] = $object;
        }

        // §68.12. Everything re-read, including what was already there.
        foreach ( $done as $object ) {
            $entry  = isset( $by_uuid[ $object['uuid'] ] ) ? $by_uuid[ $object['uuid'] ] : [];
            $wanted = isset( $entry['payload_hash'] ) ? (string) $entry['payload_hash'] : '';
            if ( WorkspaceSnapshot::hash( (int) $object['live_id'] ) !== $wanted ) {
                return new \WP_Error(
                    've_recover_unverified',
                    'The site did not take "' . $object['label'] . '", so this publish was not finished. '
                        . 'Nothing further was written.',
                    [ 'status' => 409 ]
                );
            }
        }

        foreach ( $done as $object ) {
            $source = isset( $shadows[ $object['uuid'] ] ) ? $shadows[ $object['uuid'] ] : null;
            if ( ! $source ) {
                continue;
            }
            $published = (string) $by_uuid[ $object['uuid'] ]['payload_hash'];
            WorkspaceObjectMap::set_hashes(
                (int) $source['id'],
                [ 'base' => $published, 'workspace' => $published, 'live' => $published ],
                WorkspaceSnapshot::UNCHANGED
            );
        }

        $globals = $report['globals'];
        $reason  = 'Interrupted and finished: '
            . self::settled_phrase( count( $done ), $globals ? (int) $globals['written'] : 0 );
        WorkspaceRelease::settle( (int) $release['id'], WorkspaceRelease::PUBLISHED, $reason, $release['objects'] );

        return [
            'recovered' => true,
            'choice'    => 'finish',
            'count'     => count( $done ),
            'release'   => WorkspaceRelease::get( (int) $release['id'] ),
            'message'   => $reason,
        ];
    }

    /** "A, B and C", because "3 objects" is not an answer to "which ones". */
    private static function listed( array $names ): string {
        $names = array_values( array_filter( $names ) );
        if ( ! $names ) {
            return 'nothing';
        }
        if ( 1 === count( $names ) ) {
            return $names[0];
        }
        $last = array_pop( $names );
        return implode( ', ', $names ) . ' and ' . $last;
    }

    // ── internals ──────────────────────────────────────────────────────────

    private static function live_exists( array $object ): bool {
        $live = isset( $object['live_id'] ) ? (int) $object['live_id'] : 0;
        return $live > 0 && (bool) get_post( $live );
    }

    /** What the panel needs to name an object, and nothing else. */
    private static function brief( array $object ): array {
        return [
            'id'      => (int) $object['id'],
            'uuid'    => (string) $object['uuid'],
            'label'   => (string) $object['label'],
            'type'    => (string) $object['object_type'],
            'live_id' => isset( $object['live_id'] ) ? (int) $object['live_id'] : 0,
            'state'   => (string) $object['state'],
        ];
    }

    /**
     * Slice 11 - put the workspace's globals onto the site.
     *
     * A family the workspace never touched has a null payload and is left
     * alone; inventing a value for it would blank every variable on the site.
     * A family answered `skip` under §87.6 is excluded and says so.
     *
     * After each one lands the workspace lets it go and the fingerprint moves
     * with it. That is not tidying: the published value IS the workspace value,
     * and a workspace still claiming to differ is exactly what slice 8 reads as
     * a leak - it would "repair" the publish away on the next admin request.
     *
     * @return array|\WP_Error
     */
    private static function publish_globals( int $workspace_id, callable $journal = null ) {
        $plan = self::global_plan( $workspace_id );
        if ( ! $plan['write'] ) {
            return [ 'written' => [], 'skipped' => $plan['skipped'], 'undo' => [] ];
        }

        $written = [];
        $undo    = [];
        foreach ( $plan['write'] as $family ) {
            $value = WorkspaceRuntime::payload( $workspace_id, $family );

            /* §113, for globals: the whole previous value, captured before
               anything is written. The pages are verified AFTER this runs, and
               a page that fails puts every page back - so there has to be
               something to put these back from too. */
            $undo[] = [
                'family' => $family,
                'value'  => $value,
                'prior'  => WorkspaceRuntime::live_value( $family ),
            ];

            /* SLICE 12, §101. Prior on disk, then the write. A kill between
               the two leaves a journal that says this family was being written
               and what it was before; a kill the other way round would leave
               the site changed and no way back. */
            if ( $journal ) {
                $journal( $undo );
            }

            WorkspaceRuntime::restore_live( $family, $value );

            /* §68.12, applied to globals: what LANDED, not what the write
               returned. `update_option()` answers false when the value is
               already the one being written - which happens whenever the same
               change was also made on the site - so trusting its return would
               refuse a publish that had simply finished early. And a write
               swallowed by an overlay would return true. Only reading Live back
               tells the difference. */
            if ( WorkspaceRuntime::hash( WorkspaceRuntime::live_value( $family ) )
                !== WorkspaceRuntime::hash( $value ) ) {
                return new \WP_Error(
                    've_publish_global_failed',
                    'The site did not take the new value for ' . $family
                        . ', so nothing was published.'
                );
            }

            WorkspaceRuntime::forget_family( $workspace_id, $family );
            if ( class_exists( __NAMESPACE__ . '\WorkspaceFingerprint' ) ) {
                WorkspaceFingerprint::rebase( $workspace_id, $family );
            }
            $written[] = $family;
        }

        return [ 'written' => $written, 'skipped' => $plan['skipped'], 'undo' => $undo ];
    }

    /**
     * Put the globals back, and put the workspace back in front of them.
     *
     * Restoring Live alone would be the worst of both: the site back where it
     * was and the workspace no longer holding the change it just lost. So the
     * payload goes back too, and the base with it - which is the state the
     * workspace was in one line before publish started.
     *
     * @param array<int,array{family:string,value:mixed,prior:mixed}> $done
     */
    private static function unpublish_globals( int $workspace_id, array $done ): void {
        foreach ( array_reverse( $done ) as $g ) {
            WorkspaceRuntime::restore_live( $g['family'], $g['prior'] );
            WorkspaceRuntime::set_payload( $workspace_id, $g['family'], $g['value'] );
            if ( class_exists( __NAMESPACE__ . '\\WorkspaceFingerprint' ) ) {
                WorkspaceFingerprint::rebase( $workspace_id, $g['family'] );
            }
        }
    }

    /**
     * Slice 11 - the globals this publish would write, and the ones it will not.
     *
     * `preflight()` has to know whether there is anything to publish,
     * `publish()` has to know whether to open a release, and
     * `publish_globals()` has to know what to write. Three enumerations that
     * agree by coincidence is how a workspace ends up refusing to publish a
     * change it is holding, so there is one.
     *
     * @return array{write:array<int,string>,skipped:array<int,string>,answers:array<string,string>}
     */
    private static function global_plan( int $workspace_id ): array {
        if ( ! class_exists( __NAMESPACE__ . '\WorkspaceRuntime' ) ) {
            return [ 'write' => [], 'skipped' => [], 'answers' => [] ];
        }

        $answers = class_exists( __NAMESPACE__ . '\WorkspaceFingerprint' )
            ? WorkspaceFingerprint::resolutions( $workspace_id )
            : [];

        $write   = [];
        $skipped = [];
        foreach ( WorkspaceRuntime::watched_families() as $family ) {
            if ( null === WorkspaceRuntime::payload( $workspace_id, $family ) ) {
                continue;   // the workspace never touched it
            }
            if ( 'skip' === ( $answers[ $family ] ?? '' ) ) {
                $skipped[] = $family;   // §87.6, answered "not this time"
                continue;
            }
            $write[] = $family;
        }

        return [ 'write' => $write, 'skipped' => $skipped, 'answers' => $answers ];
    }

    /** What the release record says happened. Pages and globals both count. */
    private static function settled_phrase( int $pages, int $globals ): string {
        $parts = [];
        if ( $pages ) {
            $parts[] = 1 === $pages ? 'One page' : ( $pages . ' pages' );
        }
        if ( $globals ) {
            $parts[] = 1 === $globals ? 'one global' : ( $globals . ' globals' );
        }
        if ( ! $parts ) {
            return 'Nothing was published.';
        }
        return implode( ' and ', $parts ) . ' published and verified.';
    }

    /**
     * How many things in this publish depend on each object.
     *
     * Only one level deep, deliberately. A full topological sort needs a graph
     * with no cycles, and a Bricks template can include a template that
     * includes it - which is a mistake, not an impossibility. One level puts
     * templates before the pages that pull them in, which is the case §32 shows
     * and the only one that has come up.
     *
     * @return array<int,int> object id => how many others need it
     */
    private static function dependency_depth( int $workspace_id, array $targets ): array {
        if ( ! class_exists( __NAMESPACE__ . '\WorkspaceDependencies' ) ) {
            return [];
        }
        $by_live = [];
        foreach ( $targets as $object ) {
            $by_live[ (int) $object['live_id'] ] = (int) $object['id'];
        }

        $count = [];
        foreach ( $targets as $object ) {
            foreach ( WorkspaceDependencies::scan( (int) $object['id'] ) as $dep ) {
                if ( 'template' !== $dep['kind'] ) {
                    continue;
                }
                $needed = $by_live[ (int) $dep['ref'] ] ?? 0;
                if ( $needed > 0 && $needed !== (int) $object['id'] ) {
                    $count[ $needed ] = ( $count[ $needed ] ?? 0 ) + 1;
                }
            }
        }
        return $count;
    }

    private static function count_phrase( int $n, string $noun ): string {
        return 1 === $n ? ( 'One ' . $noun . ' is' ) : ( $n . ' ' . $noun . 's are' );
    }

    private static function refusal( string $code, string $message ): array {
        return [
            'ok'        => false,
            'publish'   => [],
            'behind'    => [],
            'conflicts' => [],
            'missing'   => [],
            'unchanged' => 0,
            'blockers'  => [ [ 'code' => $code, 'message' => $message, 'objects' => [] ] ],
        ];
    }
}
