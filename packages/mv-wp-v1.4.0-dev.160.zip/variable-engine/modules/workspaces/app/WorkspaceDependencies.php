<?php
/**
 * Slice 11 — §32: what an object needs, and refusing to pretend otherwise.
 *
 * "A workspace publish must not silently omit required dependencies." And when
 * one cannot be included: **Cannot publish**, naming the object. "Do not fake
 * completeness."
 *
 * ── What counts as a dependency, read off Bricks rather than guessed ─────────
 *
 * An element tree carries its references in known places, taken from Bricks 2.4:
 *
 *   `settings._cssGlobalClasses`  ids into `bricks_global_classes`
 *   `cid`                         a component instance (`bricks_components`)
 *   `global`                      a global element (`bricks_global_elements`)
 *   name `template` + `settings.template`   another post
 *   any string containing `var(--x)`        a global variable
 *   any `{ id: <int>, … }` under an image-ish key   an attachment
 *
 * ── Supported, and the one word this slice turns on ──────────────────────────
 *
 * A dependency is SUPPORTED when publishing this workspace can leave it
 * satisfied. Three ways that is true, and they are different:
 *
 *   - It is a global MV holds (classes, variables, components, global
 *     elements). Publishing the workspace publishes those with it.
 *   - It is another object in THIS workspace, going out in the same publish.
 *   - It already exists on the live site and this publish does not remove it.
 *
 * Anything else is UNSUPPORTED, and unsupported is a refusal rather than a
 * warning. A page published pointing at a template that exists nowhere is a
 * page that renders a hole, and it renders it on the live site.
 *
 * ── What this deliberately does not claim ────────────────────────────────────
 *
 * ACF field groups, JetEngine meta boxes and the plugins behind them are NOT
 * scanned. A Bricks element that reads a custom field names it as a dynamic-data
 * string, and MV can see the string, but whether the FIELD is published with
 * the workspace is a question about ACF's own storage that slices 1-10 never
 * answered. Reporting a dependency MV cannot check the state of would be the
 * fake completeness §32 is about. §32's own example lists an ACF field group,
 * so this is a gap in the slice rather than a gap in the spec, and it is named
 * in the report as `unknown` rather than quietly counted as satisfied.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceDependencies {

    /** Publishing the workspace satisfies it. */
    public const SUPPORTED = 'supported';

    /** It cannot be satisfied, and that is a refusal. */
    public const UNSUPPORTED = 'unsupported';

    /** MV cannot see enough to say. Never counted as satisfied. */
    public const UNKNOWN = 'unknown';

    /**
     * Everything one workspace object refers to.
     *
     * @return array<int,array{kind:string,ref:string,label:string}>
     */
    public static function scan( int $object_id ): array {
        $object = WorkspaceObjectMap::get( $object_id );
        if ( ! is_array( $object ) ) {
            return [];
        }
        $shadow = (int) ( $object['shadow_id'] ?? 0 );
        if ( $shadow <= 0 ) {
            return [];
        }

        $found = [];
        foreach ( BricksPageAdapter::META as $key ) {
            if ( false === strpos( (string) $key, '_bricks_page_' )
                && false === strpos( (string) $key, '_bricks_template' ) ) {
                continue;
            }
            $tree = get_post_meta( $shadow, $key, true );
            if ( is_array( $tree ) ) {
                self::walk( $tree, $found );
            }
        }

        return array_values( $found );
    }

    /**
     * Walk an element tree, collecting references.
     *
     * Recursive over anything array-shaped rather than over Bricks' own element
     * order, because a reference can sit inside `slotChildren`, a repeater, or a
     * nested settings group, and a walker that only knows the top level finds
     * the easy half of the problem.
     *
     * @param mixed $node
     */
    private static function walk( $node, array &$found ): void {
        if ( ! is_array( $node ) ) {
            if ( is_string( $node ) ) {
                self::variables_in( $node, $found );
            }
            return;
        }

        if ( ! empty( $node['cid'] ) && is_scalar( $node['cid'] ) ) {
            self::add( $found, 'component', (string) $node['cid'] );
        }
        if ( ! empty( $node['global'] ) && is_scalar( $node['global'] ) ) {
            self::add( $found, 'global_element', (string) $node['global'] );
        }

        $settings = isset( $node['settings'] ) && is_array( $node['settings'] ) ? $node['settings'] : [];

        if ( 'template' === ( $node['name'] ?? '' ) && ! empty( $settings['template'] ) ) {
            self::add( $found, 'template', (string) (int) $settings['template'] );
        }
        foreach ( (array) ( $settings['_cssGlobalClasses'] ?? [] ) as $id ) {
            if ( is_scalar( $id ) ) {
                self::add( $found, 'global_class', (string) $id );
            }
        }

        /* An attachment is `{ id: 12, url: … }` wherever Bricks' image control
           put it. Matched on the shape rather than on a list of setting names,
           because that list is Bricks' to change and the shape is not. */
        if ( isset( $node['id'] ) && is_numeric( $node['id'] ) && (int) $node['id'] > 0
            && ( isset( $node['url'] ) || isset( $node['filename'] ) || isset( $node['size'] ) ) ) {
            self::add( $found, 'media', (string) (int) $node['id'] );
        }

        foreach ( $node as $value ) {
            self::walk( $value, $found );
        }
    }

    private static function variables_in( string $text, array &$found ): void {
        if ( false === strpos( $text, 'var(--' ) ) {
            return;
        }
        if ( preg_match_all( '/var\(\s*--([A-Za-z0-9_-]+)/', $text, $m ) ) {
            foreach ( $m[1] as $name ) {
                self::add( $found, 'variable', $name );
            }
        }
    }

    private static function add( array &$found, string $kind, string $ref ): void {
        if ( '' === $ref ) {
            return;
        }
        $found[ $kind . ':' . $ref ] = [ 'kind' => $kind, 'ref' => $ref ];
    }

    // ── judging them ────────────────────────────────────────────────────────

    /**
     * What one workspace needs, and whether publishing it would leave each
     * dependency satisfied.
     *
     * @return array{items:array,unsupported:array,unknown:array}
     */
    public static function report( int $workspace_id ): array {
        $objects = class_exists( __NAMESPACE__ . '\WorkspaceObjectMap' )
            ? WorkspaceObjectMap::all( $workspace_id ) : [];

        /* Everything going out in this publish. A dependency on one of these is
           satisfied BY this publish, which is the whole reason the set has to be
           known before anything is judged. */
        $going_out = [];
        foreach ( $objects as $object ) {
            $going_out[ (string) (int) ( $object['live_id'] ?? 0 ) ] = true;
        }

        $items = [];
        foreach ( $objects as $object ) {
            $object_id = (int) ( $object['id'] ?? 0 );
            foreach ( self::scan( $object_id ) as $dep ) {
                $verdict = self::judge( $dep, $going_out );
                $items[] = [
                    'object'  => $object_id,
                    'live_id' => (int) ( $object['live_id'] ?? 0 ),
                    'kind'    => $dep['kind'],
                    'ref'     => $dep['ref'],
                    'label'   => self::label( $dep ),
                    'state'   => $verdict,
                ];
            }
        }

        return [
            'items'       => $items,
            'unsupported' => array_values( array_filter( $items, static function ( $i ) {
                return self::UNSUPPORTED === $i['state'];
            } ) ),
            'unknown'     => array_values( array_filter( $items, static function ( $i ) {
                return self::UNKNOWN === $i['state'];
            } ) ),
        ];
    }

    /**
     * The one judgement, kept in one place so a guard can drive it.
     *
     * @param array<string,string> $dep
     * @param array<string,bool>   $going_out live ids in this publish
     */
    public static function judge( array $dep, array $going_out ): string {
        $kind = (string) ( $dep['kind'] ?? '' );
        $ref  = (string) ( $dep['ref'] ?? '' );

        /* The globals MV holds. Publishing the workspace publishes these with
           it - that is what slices 7 to 10 are - so a page that uses one is not
           waiting on anything. */
        if ( in_array( $kind, [ 'global_class', 'variable', 'component', 'global_element' ], true ) ) {
            return self::SUPPORTED;
        }

        if ( 'template' === $kind ) {
            $id = (int) $ref;
            if ( isset( $going_out[ (string) $id ] ) ) {
                return self::SUPPORTED;   // going out in the same publish
            }
            $post = $id > 0 ? get_post( $id ) : null;
            if ( ! $post ) {
                return self::UNSUPPORTED; // points at nothing, anywhere
            }
            /* On the site but not published yet. Publishing the page would put a
               live page in front of a draft template, which renders nothing. */
            return 'publish' === get_post_status( $id ) ? self::SUPPORTED : self::UNSUPPORTED;
        }

        if ( 'media' === $kind ) {
            $id = (int) $ref;
            return ( $id > 0 && 'attachment' === get_post_type( $id ) )
                ? self::SUPPORTED
                : self::UNSUPPORTED;
        }

        // Anything this slice cannot see the state of. Never "satisfied".
        return self::UNKNOWN;
    }

    private static function label( array $dep ): string {
        $names = [
            'global_class'   => 'Global class',
            'variable'       => 'Variable',
            'component'      => 'Component',
            'global_element' => 'Global element',
            'template'       => 'Template',
            'media'          => 'Media',
        ];
        $kind = (string) ( $dep['kind'] ?? '' );
        $name = $names[ $kind ] ?? ucfirst( str_replace( '_', ' ', $kind ) );
        $ref  = (string) ( $dep['ref'] ?? '' );

        if ( 'template' === $kind || 'media' === $kind ) {
            $title = get_the_title( (int) $ref );
            if ( '' !== (string) $title ) {
                return $name . ': ' . $title;
            }
        }
        return $name . ': ' . $ref;
    }
}
