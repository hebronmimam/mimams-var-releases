<?php
/**
 * C157 — the session follows what you are editing.
 *
 * "Nope, logged out browser shows the new value, even when the change was made
 *  on the workspace and not on the main site."
 *
 * Slices 7 to 12 built the whole of runtime isolation around one condition: a
 * workspace SESSION. While a user is in one, `WorkspaceRuntime` answers reads of
 * Bricks' global options from the workspace and holds their writes there;
 * `VariablesMirror` treats a held write as success; the theme-style route stops
 * rewriting the shared file. All of it waits on `session_id() > 0`.
 *
 * Nothing in the product ever started one. `begin_session()` was called by five
 * guards and by no code a person could reach, so every one of those guards
 * tested isolation under a condition that never occurred in use — and "Open in
 * Bricks" on a workspace page gave you the private copy of the PAGE while every
 * global you touched went straight to the live site. Reproduced on a real
 * WordPress before this was written: opened a workspace page in the builder,
 * changed a variable, and a logged-out request was served the new value, with
 * the user's session marker empty.
 *
 * So the builder decides. When it opens a page, the page says which workspace it
 * belongs to — a shadow post belongs to exactly one, anything else to none — and
 * the session is made to match. That covers every way in: the panel's button, a
 * bookmark, the back button, a typed address.
 *
 * ── Why a reload, and why exactly one ─────────────────────────────────────────
 *
 * Bricks reads the globals early in the builder request, and `WorkspaceCss` has
 * already chosen its stylesheet directory on `init`. Changing the session
 * half-way through that request would load the builder in the OLD state — and
 * because the builder saves the whole globals array back, one save could replace
 * everything the workspace held with Live plus the latest edit. So when the state
 * has to change, it is changed and the same address is loaded again, and the
 * whole of that second load happens in the right state.
 *
 * It cannot loop. The reload only happens when the session now reads back as
 * exactly what was wanted; if it could not be changed (a closed workspace, a
 * refused write) nothing is reloaded and the page loads as it is.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceSessionFollower {

    /** Statuses a workspace can be edited in, the same list session_id() reads. */
    private const OPEN = [ 'open', 'active', 'draft' ];

    public static function register(): void {
        // Early on template_redirect: the query is parsed, so the page is known,
        // and nothing has been rendered yet.
        add_action( 'template_redirect', [ self::class, 'on_template_redirect' ], 0 );
    }

    /**
     * What should happen, from the facts and nothing else.
     *
     * Kept free of WordPress so a guard can walk every case of it rather than
     * one - that is how the missing session went unnoticed for six slices.
     *
     * @param int  $shadow_workspace The workspace this page is a copy in, or 0 for a live page.
     * @param bool $workspace_open   Whether that workspace can still be edited.
     * @param int  $current_session  The workspace the user is in now, or 0.
     * @return array{action:string,want:int}
     */
    public static function decide( int $shadow_workspace, bool $workspace_open, int $current_session ): array {
        // A copy in a workspace that is no longer open is not somewhere edits can
        // be held, so it counts as live. Holding them in a published or archived
        // workspace would put them where nothing will ever publish them.
        $want = ( $shadow_workspace > 0 && $workspace_open ) ? $shadow_workspace : 0;

        if ( $want === $current_session ) {
            return [ 'action' => 'none', 'want' => $want ];
        }
        return [ 'action' => $want > 0 ? 'begin' : 'end', 'want' => $want ];
    }

    public static function on_template_redirect(): void {
        // The main builder window only. Its canvas iframe loads the same page and
        // would find the state already right; a reload there would be a flicker
        // inside the editor for nothing.
        if ( ! function_exists( 'bricks_is_builder_main' ) || ! bricks_is_builder_main() ) {
            return;
        }
        $user_id = (int) get_current_user_id();
        if ( $user_id <= 0 ) {
            return;
        }
        $post_id = (int) get_queried_object_id();
        if ( $post_id <= 0 || ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }

        $row       = WorkspaceObjectMap::by_shadow( $post_id );
        // `workspace`, not `workspace_id`: that is the column name, and
        // WorkspaceObjectMap::shape() renames it. Reading the column name got
        // 0 for every page and treated each workspace copy as live - found by
        // opening one in the real builder, not by the decision tests.
        $workspace = is_array( $row ) ? (int) ( $row['workspace'] ?? 0 ) : 0;
        $open      = false;
        if ( $workspace > 0 ) {
            $record = WorkspaceStore::get( $workspace );
            $open   = is_array( $record ) && in_array( (string) ( $record['status'] ?? '' ), self::OPEN, true );
        }

        $plan = self::decide( $workspace, $open, WorkspaceRuntime::session_id() );
        if ( 'none' === $plan['action'] ) {
            return;
        }

        if ( 'begin' === $plan['action'] ) {
            WorkspaceRuntime::begin_session( $user_id, $plan['want'] );
        } else {
            WorkspaceRuntime::end_session( $user_id );
        }
        WorkspaceRuntime::forget_session_cache();

        // Only reload when the change actually took. Anything else would be a
        // loop the moment a write was refused.
        if ( WorkspaceRuntime::session_id() !== $plan['want'] ) {
            return;
        }
        nocache_headers();
        wp_safe_redirect( add_query_arg( [] ) );
        exit;
    }
}
