<?php
/**
 * What removing MV would mean, and what it would take with it.
 *
 * Slice 12 of the Workspaces module: handoff §96 (uninstall data policy), §97
 * (removal readiness check) and §102 (manual removal).
 *
 * ## The three things that are not the same
 *
 * §96 separates them and MV had not:
 *
 *   * **Deactivate** deletes nothing. Workspaces, objects, releases, history,
 *     base states, identity maps, environments and settings all stay.
 *   * **Uninstall, preserving data** is the DEFAULT. WordPress takes the code
 *     away; MV's own data stays recoverable for a reinstall.
 *   * **Uninstall, removing everything** is destructive and opt-in, and has to
 *     be confirmed explicitly.
 *
 * The plugin shipped one boolean, `ve_delete_on_uninstall`, with no report of
 * what it would take and nothing to confirm against. This file is the report,
 * and `ve_uninstall_policy` is the choice.
 *
 * ## What destructive removal must never do (§96.3)
 *
 * It must not publish unfinished workspace changes, must not restore an older
 * live state, must not remove native Bricks or WordPress state, and must not
 * delete RestoreBase recovery points merely because MV was removed. Removing
 * MV is not a way of publishing and not a way of rolling back - which is why
 * the report says so in those words, as §97 requires.
 *
 * ## §102, and why this file does not implement it
 *
 * Someone can delete `wp-content/plugins/mimams-var/` and no hook of MV's will
 * ever fire. The requirement is that the public site still equals the last
 * committed live state, and that is a property of how the overlay is built,
 * not something a cleanup routine can provide: `WorkspaceRuntime` overlays
 * through `pre_option_*` filters and writes nothing to the live rows, and
 * `WorkspaceCss` retargets Bricks' CSS directory per request rather than
 * writing workspace CSS into the live one. With the plugin gone, none of those
 * filters is added, and every read is the live read. `scripts/
 * check-workspace-manual-removal.php` proves it by running core's own
 * `get_option()` with MV absent.
 *
 * So lifecycle hooks are for cleanup, and never the foundation of live safety.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceLifecycle {

    /** §96: the default, and the other one. */
    public const PRESERVE = 'preserve';
    public const REMOVE   = 'remove';

    public const OPTION = 've_uninstall_policy';

    /** The sentence §97 requires the report to carry, in its own words. */
    public const PROMISE = 'No workspace will be automatically published or rolled back.';

    /**
     * The policy as it stands. Anything unrecognised reads as preserve,
     * because a data-destroying default is not a default.
     */
    public static function policy(): string {
        $stored = get_option( self::OPTION, '' );
        return self::REMOVE === $stored ? self::REMOVE : self::PRESERVE;
    }

    /**
     * Choose a policy. The destructive one has to be asked for by name AND
     * confirmed; the safe one never needs confirming.
     *
     * @return array|\WP_Error
     */
    public static function set_policy( string $policy, bool $confirmed = false ) {
        if ( self::REMOVE !== $policy && self::PRESERVE !== $policy ) {
            return new \WP_Error(
                've_uninstall_policy_unknown',
                'An uninstall policy is either "preserve" or "remove".',
                [ 'status' => 400 ]
            );
        }
        if ( self::REMOVE === $policy && ! $confirmed ) {
            return new \WP_Error(
                've_uninstall_policy_unconfirmed',
                'Removing all MV data on uninstall is permanent. Confirm it explicitly.',
                [ 'status' => 409, 'readiness' => self::readiness() ]
            );
        }

        update_option( self::OPTION, $policy, false );

        /* The old boolean is what `uninstall.php` has always read, and an
           uninstall runs with none of this code loaded. Kept in step so the
           two can never disagree about something this expensive. */
        update_option( 've_delete_on_uninstall', self::REMOVE === $policy, false );

        return [ 'policy' => self::policy(), 'readiness' => self::readiness() ];
    }

    /**
     * §97's removal readiness check, in the shape the panel draws it.
     *
     * Every number here is counted rather than estimated, and the unpublished
     * count is the one that matters: it is what would still be unpublished
     * afterwards, in either policy, because removing MV publishes nothing.
     */
    public static function readiness(): array {
        $workspaces = self::workspace_summary();

        return [
            'policy'  => self::policy(),
            'promise' => self::PROMISE,
            'live'    => self::live_independence(),
            'workspaces' => $workspaces,
            'releases'   => self::release_summary(),
            'environments' => self::environment_count(),
            'restore_points' => [
                'owned_by'  => 'RestoreBase',
                'note'      => 'Recovery points are owned separately and are never removed '
                    . 'because MV was.',
            ],
            'removes' => self::what_removal_takes(),
            'keeps'   => [
                'Published pages, templates and Bricks settings - the site as it stands.',
                'Anything WordPress owns: posts, media, users, options MV does not own.',
                'RestoreBase recovery points.',
            ],
        ];
    }

    /**
     * Is the live site independent of the workspace runtime right now?
     *
     * Read rather than asserted. The overlay answers `pre_option_*` and never
     * writes the live row, so the question is whether anything HAS been
     * written - which slice 8's fingerprint already watches, family by family.
     * An unresolved conflict means a live value moved under a workspace and
     * nobody has said which should win, and that is the one state where
     * removing MV would leave a question behind rather than an answer.
     */
    private static function live_independence(): array {
        $unresolved = 0;
        if ( class_exists( __NAMESPACE__ . '\WorkspaceFingerprint' ) ) {
            foreach ( WorkspaceStore::all( true ) as $workspace ) {
                $open = WorkspaceFingerprint::unresolved( (int) $workspace['id'] );
                $unresolved += is_array( $open ) ? count( $open ) : 0;
            }
        }

        return [
            'independent' => 0 === $unresolved,
            'unresolved'  => $unresolved,
            'note'        => 0 === $unresolved
                ? 'The live site reads live values. MV overlays them for a workspace '
                    . 'session only, and never writes them, so removing MV leaves the site '
                    . 'exactly as it is now.'
                : $unresolved . ' global setting' . ( 1 === $unresolved ? '' : 's' )
                    . ' changed on the site while a workspace held ' . ( 1 === $unresolved ? 'it' : 'them' )
                    . ', and nobody has said which should win. Settle those first: removing MV '
                    . 'would leave the site on whichever value is there now.',
        ];
    }

    /** Active workspaces, and how much has never been published. */
    private static function workspace_summary(): array {
        $names   = [];
        $changes = 0;
        $active  = 0;

        foreach ( WorkspaceStore::all( false ) as $workspace ) {
            $id = (int) $workspace['id'];
            $active++;
            $modified = 0;
            foreach ( WorkspaceObjectMap::all( $id ) as $object ) {
                if ( WorkspaceSnapshot::UNCHANGED !== (string) $object['state'] ) {
                    $modified++;
                }
            }
            $changes += $modified;
            $names[]  = [
                'id'      => $id,
                'name'    => (string) $workspace['name'],
                'changes' => $modified,
            ];
        }

        return [ 'active' => $active, 'changes' => $changes, 'list' => $names ];
    }

    /** Releases, and any publish that never settled. */
    private static function release_summary(): array {
        global $wpdb;
        $table = WorkspaceRelease::table();
        $total = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $table );
        $open  = class_exists( __NAMESPACE__ . '\WorkspaceJournal' )
            ? count( WorkspaceJournal::interrupted() )
            : 0;

        return [ 'records' => $total, 'interrupted' => $open ];
    }

    /** Paired environments, where the module that owns them is present. */
    private static function environment_count(): int {
        $environments = apply_filters( 've_workspace_environments', null );
        if ( is_array( $environments ) ) {
            return count( $environments );
        }
        return 0;
    }

    /**
     * §96.3's list, as things rather than table names.
     *
     * Named so the person reading can recognise what they would lose. The
     * shape of this list is the contract `uninstall.php` is written against.
     */
    private static function what_removal_takes(): array {
        return [
            'Workspaces and everything inside them, published or not.',
            'Workspace payloads and generated workspace CSS.',
            'Release records and deployment history.',
            'Base states, identity maps and rollback metadata.',
            'Preview tokens and workspace-only temporary assets.',
            'Environment connection metadata and local MV credentials.',
            'MV variables, themes, palettes and module settings.',
        ];
    }
}
