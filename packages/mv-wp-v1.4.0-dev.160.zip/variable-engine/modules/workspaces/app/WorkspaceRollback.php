<?php
/**
 * Undoing a release, one object at a time.
 *
 * Slice 6 of the Workspaces module, and the other half of handoff §113.
 *
 * THE DECISION THIS FILE IMPLEMENTS
 *
 *   > Rollback targets objects. A release is only a convenient way to select
 *   > them.
 *
 * So nothing here restores "a release". It restores each object from that
 * object's own `prior_payload`, which slice 5 wrote beside it for exactly this.
 * A release-level snapshot would not do, and a hash would not do.
 *
 * SUPERSESSION, COMPUTED PER OBJECT
 *
 * For each object in the release being rolled back:
 *
 *     current Live hash == this release's payload_hash
 *       -> nothing landed on it since. Clean.
 *
 *     current Live hash != this release's payload_hash
 *       -> a later release, or somebody editing the page directly, changed it.
 *          Superseded.
 *
 * That is §19's comparison, not a new engine.
 *
 * AND SCOPED PER TARGET
 *
 * Only later events against the SAME target can supersede an object. There is
 * one target today, and the filter is written anyway, because the handoff says
 * what happens without it: *"a team deploying to Staging regularly would find
 * every Live rollback refused for no reason"* - found while building the UI for
 * this, where an unscoped rule blocked a clean rollback because an unrelated
 * Staging deploy had touched an object with the same name.
 *
 * ALPHA BEHAVIOUR, AND IT IS NOT A RESTING PLACE
 *
 * If ANY object is superseded, the whole rollback is refused and every
 * superseded object is named along with what superseded it. Nothing is
 * partially applied.
 *
 * §113.3 is honest about the cost: on a site that publishes often, almost every
 * object will have been touched by something later, and a rollback that is
 * always refused is a rollback that does not exist. Beta offers the clean
 * subset; later offers three-way resolution on the rest. Both are possible on
 * top of this because `prior_payload` is per object from the first release.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceRollback {

    /**
     * What rolling this release back would do, computed from the site as it is
     * now rather than from what the release believed when it was written.
     */
    public static function preflight( int $release_id ): array {
        $release = WorkspaceRelease::get( $release_id );
        if ( ! $release ) {
            return self::refusal( 've_release_missing', 'That release no longer exists.' );
        }
        if ( WorkspaceRelease::PUBLISHED !== $release['status'] ) {
            return self::refusal(
                've_release_not_published',
                'That release was recorded as ' . $release['status'] . ', so it never changed anything to undo.'
            );
        }
        if ( ! $release['objects'] ) {
            return self::refusal( 've_release_empty', 'That release carried no pages.' );
        }

        /* Every release that landed on the same target AFTER this one. The
           target filter is §113's scoping rule; the id ordering is what "after"
           means for events on one site. */
        $later = array_values( array_filter(
            WorkspaceRelease::landed_on( $release['target'] ),
            static function ( $r ) use ( $release ) {
                return (int) $r['id'] > (int) $release['id'];
            }
        ) );

        $clean      = [];
        $superseded = [];
        $missing    = [];

        foreach ( $release['objects'] as $entry ) {
            $live = isset( $entry['live_id'] ) ? (int) $entry['live_id'] : 0;
            if ( $live <= 0 || ! get_post( $live ) ) {
                $missing[] = self::brief( $entry, null );
                continue;
            }
            $now = WorkspaceSnapshot::hash( $live );
            if ( null !== $now && $now === (string) $entry['payload_hash'] ) {
                $clean[] = self::brief( $entry, null );
                continue;
            }
            $superseded[] = self::brief( $entry, self::what_changed_it( $entry, $later ) );
        }

        $blockers = [];
        if ( $superseded ) {
            /* §113's Alpha: name every superseded object AND what superseded
               it. "Something changed" is not an answer a person can act on. */
            $blockers[] = [
                'code'    => 've_rollback_superseded',
                'message' => self::count_phrase( count( $superseded ) )
                    . ' changed after this release, so rolling it back would undo that too.',
                'objects' => $superseded,
            ];
        }
        if ( $missing ) {
            $blockers[] = [
                'code'    => 've_rollback_live_missing',
                'message' => self::count_phrase( count( $missing ) )
                    . ' no longer on the site, so there is nothing to restore onto.',
                'objects' => $missing,
            ];
        }
        if ( ! $clean && ! $blockers ) {
            $blockers[] = [
                'code'    => 've_rollback_nothing',
                'message' => 'There is nothing in that release to undo.',
                'objects' => [],
            ];
        }

        return [
            'ok'         => empty( $blockers ),
            'release'    => (int) $release['id'],
            'restore'    => $clean,
            'superseded' => $superseded,
            'missing'    => $missing,
            'blockers'   => $blockers,
        ];
    }

    /**
     * Do it. Same order of operations as a publish, for the same reason
     * (§68.12): apply, re-read, compare, and only then record it as done.
     *
     * @return array
     */
    public static function rollback( int $release_id ): array {
        $pre = self::preflight( $release_id );
        if ( empty( $pre['ok'] ) ) {
            return [ 'rolled_back' => false, 'preflight' => $pre ];
        }

        $release = WorkspaceRelease::get( $release_id );
        $targets = [];
        foreach ( $release['objects'] as $entry ) {
            $live = (int) $entry['live_id'];
            if ( $live > 0 && get_post( $live ) ) {
                $targets[] = $entry;
            }
        }
        if ( ! $targets ) {
            return [ 'rolled_back' => false, 'preflight' => self::preflight( $release_id ) ];
        }

        /* The rollback is itself a release: it changed the site, it can be
           superseded by whatever comes next, and §42 has to be able to show it.
           Its `prior_payload` is what is on the page NOW - so a rollback can be
           rolled back. */
        $planned = [];
        foreach ( $targets as $entry ) {
            $planned[] = self::event_entry( $entry, null );
        }
        $event = WorkspaceRelease::open(
            (int) $release['workspace'],
            $planned,
            WorkspaceRelease::ROLLBACK,
            (int) $release['id']
        );
        if ( ! is_array( $event ) || isset( $event['error'] ) ) {
            return [ 'rolled_back' => false, 'error' => $event ];
        }

        $written = [];
        $applied = [];
        foreach ( $targets as $entry ) {
            $live  = (int) $entry['live_id'];
            $prior = WorkspaceSnapshot::payload( $live );   // what this undo replaces
            $applied[] = self::event_entry( $entry, $prior );

            BricksPageAdapter::apply_payload( $live, $entry['prior_payload'] );
            $written[] = [ 'entry' => $entry, 'prior' => $prior ];
        }

        /* §68.12 again. What landed, not what was asked for. */
        $broken = null;
        foreach ( $targets as $entry ) {
            $wanted = \VE\Core\CanonicalJson::hash(
                is_array( $entry['prior_payload'] ) ? $entry['prior_payload'] : []
            );
            $landed = WorkspaceSnapshot::hash( (int) $entry['live_id'] );
            if ( $landed !== $wanted ) {
                $broken = $entry;
                break;
            }
        }

        if ( $broken ) {
            foreach ( array_reverse( $written ) as $undo ) {
                BricksPageAdapter::apply_payload( (int) $undo['entry']['live_id'], $undo['prior'] );
            }
            $reason = 'Verification failed on "' . $broken['label'] . '". Nothing was rolled back: '
                . 'every page this undo had already written was put back.';
            WorkspaceRelease::settle( (int) $event['id'], WorkspaceRelease::FAILED, $reason, $applied );
            return [
                'rolled_back' => false,
                'event'       => WorkspaceRelease::get( (int) $event['id'] ),
                'failed_on'   => self::brief( $broken, null ),
            ];
        }

        /* The workspace's own base follows the site. The page in the workspace
           still holds the newer version, so §19 reads it as changed here again -
           which is true, and means it can simply be published a second time. */
        foreach ( $targets as $entry ) {
            $object = self::object_of( $entry );
            if ( $object ) {
                WorkspaceSnapshot::refresh( (int) $object['id'] );
                $restored = WorkspaceSnapshot::hash( (int) $entry['live_id'] );
                WorkspaceObjectMap::set_hashes(
                    (int) $object['id'],
                    [
                        'base'      => $restored,
                        'workspace' => WorkspaceSnapshot::hash( (int) $object['shadow_id'] ),
                        'live'      => $restored,
                    ],
                    WorkspaceSnapshot::compare(
                        $restored,
                        WorkspaceSnapshot::hash( (int) $object['shadow_id'] ),
                        $restored
                    )
                );
            }
        }

        WorkspaceRelease::settle(
            (int) $event['id'],
            WorkspaceRelease::PUBLISHED,
            self::count_phrase( count( $targets ) ) . ' put back and verified.',
            $applied
        );

        return [
            'rolled_back' => true,
            'event'       => WorkspaceRelease::get( (int) $event['id'] ),
            'count'       => count( $targets ),
        ];
    }

    // ── internals ──────────────────────────────────────────────────────────

    /**
     * Which later release changed this object - or null, meaning somebody
     * edited the page outside MV. Both are supersession; only one has a name,
     * and saying which is the difference between "roll back R-103 first" and a
     * refusal with no next step.
     */
    private static function what_changed_it( array $entry, array $later ) {
        foreach ( $later as $r ) {
            foreach ( $r['objects'] as $other ) {
                if ( (string) $other['object_uuid'] === (string) $entry['object_uuid'] ) {
                    return $r;
                }
            }
        }
        return null;
    }

    /**
     * The workspace row this release entry came from.
     *
     * By live id, which is indexed, rather than by uuid, which would mean
     * scanning every workspace. The object may be gone - removed from the
     * workspace since it was published - and that is not an error: the page was
     * still put back, there is simply no workspace row left to re-base.
     *
     * @return array|null
     */
    private static function object_of( array $entry ) {
        $live = isset( $entry['live_id'] ) ? (int) $entry['live_id'] : 0;
        return $live > 0 ? WorkspaceObjectMap::by_live( $live ) : null;
    }

    private static function event_entry( array $entry, $prior ): array {
        return [
            'object_uuid'   => (string) $entry['object_uuid'],
            'adapter'       => (string) $entry['adapter'],
            'object_type'   => isset( $entry['object_type'] ) ? (string) $entry['object_type'] : '',
            'label'         => (string) $entry['label'],
            'live_id'       => (int) $entry['live_id'],
            // This undo replaces what the release wrote, and restores what the
            // release replaced. Stated in the same shape, so the undo of an undo
            // needs no special case.
            'base_hash'     => (string) $entry['payload_hash'],
            'payload_hash'  => \VE\Core\CanonicalJson::hash(
                is_array( $entry['prior_payload'] ) ? $entry['prior_payload'] : []
            ),
            'prior_payload' => $prior,
        ];
    }

    private static function brief( array $entry, $by ): array {
        return [
            'object_uuid' => (string) $entry['object_uuid'],
            'label'       => (string) $entry['label'],
            'live_id'     => isset( $entry['live_id'] ) ? (int) $entry['live_id'] : 0,
            'changed_by'  => $by ? [
                'id'     => (int) $by['id'],
                'uuid'   => (string) $by['uuid'],
                'kind'   => (string) $by['kind'],
                'at'     => (string) ( $by['settled_at'] ? $by['settled_at'] : $by['created_at'] ),
                'reason' => (string) $by['reason'],
            ] : null,
        ];
    }

    private static function count_phrase( int $n ): string {
        return 1 === $n ? 'One page is' : ( $n . ' pages are' );
    }

    private static function refusal( string $code, string $message ): array {
        return [
            'ok'         => false,
            'restore'    => [],
            'superseded' => [],
            'missing'    => [],
            'blockers'   => [ [ 'code' => $code, 'message' => $message, 'objects' => [] ] ],
        ];
    }
}
