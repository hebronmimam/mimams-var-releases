<?php
/**
 * Slice 8 — §100.1.b: detect the leak, put Live back, and never guess.
 *
 * Slice 7 isolates a runtime global by answering `pre_option_*` differently for
 * a workspace session. That isolation lasts **while MV runs**. The hole it
 * leaves is the one §100.1 names: a Bricks builder tab is already open, MV is
 * deactivated (or killed, or its directory deleted), the editor saves, and the
 * write lands on the live option with nothing to hold it.
 *
 * MV cannot prevent that — §100.1.c explains why inverting the storage to
 * prevent it would be worse, because it would make the public site depend on
 * the MV runtime. So the contract is detect, restore, quarantine, and say so.
 *
 * ── The three verdicts, and why there is no fourth ────────────────────────────
 *
 * On session open this class records Live's value and hash. Later it compares:
 *
 *   live === recorded              → CLEAN.     Nothing happened.
 *   live === the workspace's value → LEAKED.    Restore Live, quarantine, log.
 *   anything else                  → CONFLICT.  Touch nothing. Ask.
 *
 * The third line is §108.10 exactly — `BASE A / Workspace B / Live C` stays a
 * conflict — and it is also §100.1.5: a value that is neither the base nor the
 * workspace could be a legitimate external edit or a half-finished leaked save,
 * MV cannot tell those apart, and a wrong repair destroys somebody's work. So
 * the ambiguous case does nothing at all except report.
 *
 * ── Witnessed writes: the discriminator that is evidence, not a heuristic ─────
 *
 * The second line has a failure mode worth taking seriously. Another admin, with
 * no workspace open, could legitimately edit Live into exactly the value this
 * workspace holds — they made the same change I did. Read naively, that is
 * "live === the workspace's value" and MV would undo their work.
 *
 * A clock cannot settle it. A heartbeat cannot tell a quiet site from an absent
 * plugin, and anything built on "how long since MV was last seen" would repair
 * on a site nobody visited overnight.
 *
 * But MV holds real evidence: `pre_update_option_*` fires for EVERY write to the
 * family, so a Live write made while MV is running is a write MV **witnessed**.
 * A leak, by definition, is a write it did not — that is the whole reason the
 * leak exists. So `WorkspaceRuntime::witness()` records the hash of every Live
 * write it sees pass through, and a value MV witnessed is never repaired. It is
 * reported as drift, which is what §93.5 calls it.
 *
 * That is not a guess about intent. It is the difference between a write MV was
 * present for and one it was not, which is precisely the distinction §100.1.3
 * asks for when it says "changed while MV was inactive".
 *
 * ── Why the base is never rebased ────────────────────────────────────────────
 *
 * §93.6: restore conflict state rather than silently creating a new base. So a
 * conflict updates `reported` — what has already been said out loud, so the same
 * drift is not logged on every request — and never `hash`, which is the base the
 * workspace was cut from. Those two being separate fields IS §93.6.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceFingerprint {

    /** Nothing was recorded for this family, so there is nothing to say. */
    public const UNWATCHED = 'unwatched';

    /** Live is exactly what it was when the session opened. */
    public const CLEAN = 'clean';

    /** Live holds this workspace's unpublished value, and MV never saw it written. */
    public const LEAKED = 'leaked';

    /** Live is something else. §108.10 — retained, never repaired. */
    public const CONFLICT = 'conflict';

    /** How many events and conflicts a workspace keeps. */
    private const MAX_EVENTS = 50;

    /** @var array<int,bool> Inspected once per request, per workspace. */
    private static $inspected = [];

    public static function register(): void {
        /* `init` and not `plugins_loaded`: WorkspaceRuntime cannot answer who is
           asking before `init`, and an inspection is pointless without that.
           Priority 20 so anything registering ON init has already run. */
        add_action( 'init', [ self::class, 'inspect_due' ], 20 );
    }

    /** Where a workspace keeps its fingerprints. One option per workspace. */
    public static function store_key( int $workspace_id ): string {
        return 've_ws_fingerprint_' . $workspace_id;
    }

    /** The short list of workspaces that have one, so a quiet site reads one option. */
    public const INDEX_KEY = 've_ws_fingerprint_index';

    /**
     * The families slice 8 watches.
     *
     * Asked of the runtime rather than kept here: one list decides what is
     * overlaid and what is fingerprinted, and a second copy is how the two come
     * to disagree about which globals are protected. Slice 9 lengthened it from
     * one to fourteen without touching this file.
     */
    public static function families(): array {
        return WorkspaceRuntime::watched_families();
    }

    // ── recording ───────────────────────────────────────────────────────────

    /**
     * §100.1.1 — a session is opening, so write down what Live says right now.
     *
     * Recorded per family and only once: a second session on the same workspace
     * must not move the base, or a leak that happened between the two would be
     * fingerprinted as the base and never detected.
     */
    public static function record( int $workspace_id ): bool {
        if ( $workspace_id <= 0 ) {
            return false;
        }

        /* Slice 10 removed a gate that used to be here. It refused to record
           anything in file CSS-loading mode, because slices 7-9 stood the
           overlay down there and a fingerprint of a family nothing was holding
           would have called every ordinary edit drift.

           `WorkspaceCss` gives file mode a workspace of its own, so the overlay
           runs in both modes now and there is nothing left for that gate to
           refuse. It is gone rather than left returning true forever: a
           condition that cannot fire is a condition no test can cover. */

        $record = self::read( $workspace_id );
        $now    = time();

        foreach ( self::families() as $family ) {
            if ( isset( $record['families'][ $family ] ) ) {
                continue;
            }
            $live = WorkspaceRuntime::live_value( $family );

            $record['families'][ $family ] = [
                'live'     => $live,
                'hash'     => self::hash( $live ),
                'reported' => '',
                'opened'   => $now,
            ];
        }

        $ok = self::write( $workspace_id, $record );
        self::index_add( $workspace_id );

        return $ok;
    }

    // ── inspection ──────────────────────────────────────────────────────────

    /**
     * Every fingerprinted workspace, on an admin or REST request.
     *
     * Not on a front-end visitor request. A visitor is §85's whole concern and
     * has no business doing option writes for somebody else's workspace; the
     * repair can wait for the next admin page, because until it happens the
     * public is seeing the leaked value either way and the repair is what stops
     * that, not the request that triggers it.
     */
    public static function inspect_due(): void {
        if ( ! is_admin() && ! ( defined( 'REST_REQUEST' ) && REST_REQUEST ) ) {
            return;
        }
        foreach ( self::index() as $workspace_id ) {
            self::inspect_workspace( (int) $workspace_id );
        }
    }

    /** @return array<string,array> Verdict per family. */
    public static function inspect_workspace( int $workspace_id ): array {
        if ( $workspace_id <= 0 || isset( self::$inspected[ $workspace_id ] ) ) {
            return [];
        }
        self::$inspected[ $workspace_id ] = true;

        $out = [];
        foreach ( self::families() as $family ) {
            $verdict = self::inspect( $workspace_id, $family );

            if ( self::LEAKED === $verdict['verdict'] ) {
                self::repair( $workspace_id, $family, $verdict );
            } elseif ( self::CONFLICT === $verdict['verdict'] ) {
                self::retain_conflict( $workspace_id, $family, $verdict );
            }
            $out[ $family ] = $verdict;
        }
        return $out;
    }

    /**
     * The verdict, and nothing else — this function changes no state, so it can
     * be asked the question without answering it.
     *
     * @return array{verdict:string,family:string,live:mixed,live_hash:string,base_hash:string,workspace_hash:string,witnessed:bool}
     */
    public static function inspect( int $workspace_id, string $family ): array {
        $record = self::read( $workspace_id );
        $known  = isset( $record['families'][ $family ] ) ? $record['families'][ $family ] : null;

        $answer = [
            'verdict'        => self::UNWATCHED,
            'family'         => $family,
            'live'           => null,
            'live_hash'      => '',
            'base_hash'      => is_array( $known ) ? (string) $known['hash'] : '',
            'workspace_hash' => '',
            'witnessed'      => false,
        ];

        if ( ! is_array( $known ) ) {
            return $answer;
        }

        $live              = WorkspaceRuntime::live_value( $family );
        $answer['live']    = $live;
        $live_hash         = self::hash( $live );
        $answer['live_hash'] = $live_hash;

        if ( $live_hash === (string) $known['hash'] ) {
            $answer['verdict'] = self::CLEAN;
            return $answer;
        }

        $held = WorkspaceRuntime::payload( $workspace_id, $family );
        if ( null !== $held ) {
            $answer['workspace_hash'] = self::hash( $held );
        }

        /* Live was written while MV was running, so MV was there to hold it if it
           had needed holding. That makes it somebody's legitimate edit to Live,
           not a leak out of this workspace - even when the two values happen to
           be identical because they made the same change. §93.5 calls this drift
           and §108.10 says it is retained as a conflict, not repaired. */
        $answer['witnessed'] = WorkspaceRuntime::was_witnessed( $family, $live_hash );

        if ( ! $answer['witnessed'] && '' !== $answer['workspace_hash'] && $live_hash === $answer['workspace_hash'] ) {
            $answer['verdict'] = self::LEAKED;
            return $answer;
        }

        $answer['verdict'] = self::CONFLICT;
        return $answer;
    }

    // ── repair ──────────────────────────────────────────────────────────────

    /**
     * §100.1.3 — restore the recorded Live value, keep the observed value in the
     * workspace as an unpublished change, and record it in History.
     *
     * The quarantine half needs no write, and that is worth stating rather than
     * writing something redundant to look thorough. The value is only called a
     * leak BECAUSE it is byte-for-byte this workspace's value - that comparison
     * is the whole verdict - so it is already an unpublished change in the
     * workspace and putting it there again would store what is already stored.
     *
     * A mutation test is what settled that: removing the write changed no
     * outcome, which meant either the write or the assertion covering it was
     * decoration. If a later slice ever admits a leak that is NOT identical to
     * the workspace value, the write comes back and it will be testable then.
     */
    public static function repair( int $workspace_id, string $family, array $verdict ): bool {
        $record = self::read( $workspace_id );
        $known  = isset( $record['families'][ $family ] ) ? $record['families'][ $family ] : null;
        if ( ! is_array( $known ) ) {
            return false;
        }

        $observed = $verdict['live'];
        $restored = $known['live'];

        /* `restore_live` stands the overlay down, and that is not tidiness: this
           runs inside the session's own request, so an ordinary update_option()
           here would be caught by `hold_write` and filed into the workspace, and
           the leak would sit on the live site being repaired forever. */
        if ( ! WorkspaceRuntime::restore_live( $family, $restored ) ) {
            /* Say the repair failed rather than log one that did not happen. The
               next admin request tries again, because nothing below was written
               and the verdict will come out LEAKED a second time. */
            return false;
        }

        $opened = (int) $known['opened'];

        self::add_event( $workspace_id, [
            'type'        => 'recovered_leak',
            'family'      => $family,
            'at'          => time(),
            /* §100.1.4 - "for how long it was live" is bounded, not invented. MV
               was not running for the window, so it cannot know when within it
               the write landed; the honest number is the outside edge. */
            'live_since'  => $opened,
            'live_for'    => max( 0, time() - $opened ),
            'live_for_is' => 'at most',
            'restored'    => $restored,
            'quarantined' => $observed,
            'restored_hash'    => (string) $known['hash'],
            'quarantined_hash' => (string) $verdict['live_hash'],
        ] );

        /* The base does not move. Live is back to what it was, so the next
           inspection reads CLEAN on its own. */
        return true;
    }

    /**
     * §108.10 — a conflict is retained, and retained means stored, not raised
     * again on every page load.
     */
    private static function retain_conflict( int $workspace_id, string $family, array $verdict ): void {
        $record = self::read( $workspace_id );
        if ( ! isset( $record['families'][ $family ] ) ) {
            return;
        }
        if ( (string) $record['families'][ $family ]['reported'] === (string) $verdict['live_hash'] ) {
            return;
        }

        /* `reported` moves. `hash` does not. §93.6 in two lines: MV must not
           reset the workspace base to C merely because it noticed C. */
        $record['families'][ $family ]['reported'] = (string) $verdict['live_hash'];

        $record['conflicts'][ $family ] = [
            'at'             => time(),
            'family'         => $family,
            'base_hash'      => (string) $verdict['base_hash'],
            'workspace_hash' => (string) $verdict['workspace_hash'],
            'live_hash'      => (string) $verdict['live_hash'],
            'live'           => $verdict['live'],
            'witnessed'      => (bool) $verdict['witnessed'],
        ];

        self::write( $workspace_id, $record );

        self::add_event( $workspace_id, [
            'type'      => 'live_drift',
            'family'    => $family,
            'at'        => time(),
            'witnessed' => (bool) $verdict['witnessed'],
            'base_hash'      => (string) $verdict['base_hash'],
            'workspace_hash' => (string) $verdict['workspace_hash'],
            'live_hash'      => (string) $verdict['live_hash'],
        ] );
    }

    // ── reading it back ─────────────────────────────────────────────────────

    /** @return array<int,array> Newest first. */
    public static function events( int $workspace_id ): array {
        $record = self::read( $workspace_id );
        return isset( $record['events'] ) && is_array( $record['events'] ) ? $record['events'] : [];
    }

    /** @return array<string,array> Outstanding conflicts, by family. */
    public static function conflicts( int $workspace_id ): array {
        $record = self::read( $workspace_id );
        return isset( $record['conflicts'] ) && is_array( $record['conflicts'] ) ? $record['conflicts'] : [];
    }

    /**
     * Slice 11 — move the base, because the workspace just published it.
     *
     * §93.6 forbids creating a new base SILENTLY, and every other path in this
     * file honours that. Publishing is the one moment where moving it is the
     * correct thing and not a silent one: the value on Live is now the value the
     * workspace asked for, so the old base describes a state that no longer
     * exists anywhere. Leaving it would make the next inspection read the
     * published value as drift from a base nobody is holding.
     */
    public static function rebase( int $workspace_id, string $family ): bool {
        $record = self::read( $workspace_id );
        if ( ! isset( $record['families'][ $family ] ) ) {
            return false;
        }
        $live = WorkspaceRuntime::live_value( $family );

        $record['families'][ $family ]['live']     = $live;
        $record['families'][ $family ]['hash']     = self::hash( $live );
        $record['families'][ $family ]['reported'] = '';
        unset( $record['conflicts'][ $family ] );

        return self::write( $workspace_id, $record );
    }

    /**
     * §87.6 — the answer to a conflict, given on purpose.
     *
     * Slice 8 detected these and stopped, because §93.6 says MV must not resolve
     * one silently. It does not say the workspace has to stay stuck: a decision
     * a person cannot make is not a decision they were left, and publish is
     * blocked until every conflict has one.
     *
     * The three answers §87.6 names, and what each actually does:
     *
     *   keep_workspace — the workspace value wins at publish. Live keeps the
     *                    other value until then, so nothing changes on the site
     *                    by answering.
     *   keep_live      — take the live value INTO the workspace and rebase on
     *                    it. The workspace's own value is kept on the record, so
     *                    choosing this is not the same as losing it.
     *   skip           — leave both alone. The family is excluded from the
     *                    publish, and says so.
     *
     * None of the three writes to Live. A conflict is answered here and acted
     * on at publish, because answering a question should not change the site.
     *
     * @return array|\WP_Error The resolution, or why it was refused.
     */
    public static function resolve( int $workspace_id, string $family, string $choice ) {
        $allowed = [ 'keep_workspace', 'keep_live', 'skip' ];
        if ( ! in_array( $choice, $allowed, true ) ) {
            return new \WP_Error(
                've_conflict_choice',
                'Answer a conflict with keep_workspace, keep_live or skip.'
            );
        }

        $record = self::read( $workspace_id );
        if ( ! isset( $record['conflicts'][ $family ] ) ) {
            return new \WP_Error( 've_conflict_missing', 'There is no conflict on ' . $family . '.' );
        }
        $conflict = $record['conflicts'][ $family ];
        $now      = time();

        if ( 'keep_live' === $choice ) {
            /* The workspace takes the live value and is rebased onto it - which
               is the ONE case where §93.6's "never silently create a new base"
               is satisfied by doing exactly that, because it is no longer
               silent: the person just asked for it. */
            $live = $conflict['live'];
            WorkspaceRuntime::set_payload( $workspace_id, $family, $live );
            if ( isset( $record['families'][ $family ] ) ) {
                $record['families'][ $family ]['live'] = $live;
                $record['families'][ $family ]['hash'] = self::hash( $live );
            }
        }

        $record['conflicts'][ $family ]['resolved'] = [
            'choice' => $choice,
            'at'     => $now,
        ];
        self::write( $workspace_id, $record );

        self::add_event( $workspace_id, [
            'type'      => 'conflict_resolved',
            'family'    => $family,
            'at'        => $now,
            'choice'    => $choice,
            'base_hash'      => (string) ( $conflict['base_hash'] ?? '' ),
            'workspace_hash' => (string) ( $conflict['workspace_hash'] ?? '' ),
            'live_hash'      => (string) ( $conflict['live_hash'] ?? '' ),
        ] );

        return [ 'family' => $family, 'choice' => $choice, 'at' => $now ];
    }

    /**
     * Conflicts still waiting on an answer.
     *
     * What publish is blocked on, and the only thing that should block it - a
     * conflict somebody has already answered is a decision, not an obstacle.
     *
     * @return array<string,array>
     */
    public static function unresolved( int $workspace_id ): array {
        $out = [];
        foreach ( self::conflicts( $workspace_id ) as $family => $conflict ) {
            if ( empty( $conflict['resolved'] ) ) {
                $out[ $family ] = $conflict;
            }
        }
        return $out;
    }

    /**
     * How an answered family should be treated at publish.
     *
     * @return array<string,string> family => keep_workspace|keep_live|skip
     */
    public static function resolutions( int $workspace_id ): array {
        $out = [];
        foreach ( self::conflicts( $workspace_id ) as $family => $conflict ) {
            if ( ! empty( $conflict['resolved']['choice'] ) ) {
                $out[ $family ] = (string) $conflict['resolved']['choice'];
            }
        }
        return $out;
    }

    /** Everything the workspace fingerprinted, dropped. Used when one is discarded. */
    public static function forget( int $workspace_id ): bool {
        if ( $workspace_id <= 0 ) {
            return false;
        }
        self::index_remove( $workspace_id );
        WorkspaceRuntime::without_overlay( static function () use ( $workspace_id ) {
            delete_option( self::store_key( $workspace_id ) );
        } );
        unset( self::$inspected[ $workspace_id ] );
        return true;
    }

    /** For tests, and for a request that has genuinely changed identity. */
    public static function forget_request_cache(): void {
        self::$inspected = [];
    }

    // ── storage ─────────────────────────────────────────────────────────────

    private static function add_event( int $workspace_id, array $event ): void {
        $record = self::read( $workspace_id );
        array_unshift( $record['events'], $event );
        if ( count( $record['events'] ) > self::MAX_EVENTS ) {
            $record['events'] = array_slice( $record['events'], 0, self::MAX_EVENTS );
        }
        self::write( $workspace_id, $record );
    }

    private static function read( int $workspace_id ): array {
        $stored = WorkspaceRuntime::without_overlay( static function () use ( $workspace_id ) {
            return get_option( self::store_key( $workspace_id ), [] );
        } );

        $stored = is_array( $stored ) ? $stored : [];

        return [
            'families'  => isset( $stored['families'] ) && is_array( $stored['families'] ) ? $stored['families'] : [],
            'events'    => isset( $stored['events'] ) && is_array( $stored['events'] ) ? $stored['events'] : [],
            'conflicts' => isset( $stored['conflicts'] ) && is_array( $stored['conflicts'] ) ? $stored['conflicts'] : [],
        ];
    }

    private static function write( int $workspace_id, array $record ): bool {
        return (bool) WorkspaceRuntime::without_overlay( static function () use ( $workspace_id, $record ) {
            // Never autoloaded: a fingerprint holds a whole copy of a global.
            return update_option( self::store_key( $workspace_id ), $record, false );
        } );
    }

    /** @return array<int,int> */
    public static function index(): array {
        $ids = WorkspaceRuntime::without_overlay( static function () {
            return get_option( self::INDEX_KEY, [] );
        } );
        return is_array( $ids ) ? array_values( array_unique( array_map( 'intval', $ids ) ) ) : [];
    }

    private static function index_add( int $workspace_id ): void {
        $ids = self::index();
        if ( in_array( $workspace_id, $ids, true ) ) {
            return;
        }
        $ids[] = $workspace_id;
        WorkspaceRuntime::without_overlay( static function () use ( $ids ) {
            update_option( self::INDEX_KEY, $ids, false );
        } );
    }

    private static function index_remove( int $workspace_id ): void {
        $ids  = self::index();
        $left = array_values( array_filter( $ids, static function ( $id ) use ( $workspace_id ) {
            return (int) $id !== $workspace_id;
        } ) );
        if ( $left === $ids ) {
            return;
        }
        WorkspaceRuntime::without_overlay( static function () use ( $left ) {
            update_option( self::INDEX_KEY, $left, false );
        } );
    }

    /** @param mixed $value */
    private static function hash( $value ): string {
        if ( class_exists( '\VE\Core\CanonicalJson' ) ) {
            return \VE\Core\CanonicalJson::hash( $value );
        }
        return hash( 'sha256', (string) maybe_serialize( $value ) );
    }
}
