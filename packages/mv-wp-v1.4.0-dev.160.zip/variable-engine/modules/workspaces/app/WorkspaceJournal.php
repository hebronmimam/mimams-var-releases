<?php
/**
 * What a publish has done SO FAR, written down as it does it.
 *
 * Slice 12 of the Workspaces module, and handoff §101.
 *
 * A publish can stop in the middle. Not only by deactivation: a PHP fatal, a
 * process kill, a server restart, a database or network interruption, a
 * WordPress timeout. §101 lists nine of them and asks for a persistent
 * deployment transaction journal, because the alternative is what MV had:
 *
 *     $written = [];
 *     foreach ( $targets as $object ) { ... $written[] = [...]; }
 *
 * Every prior value held in a PHP array. `WorkspaceRelease::open()` wrote the
 * PLAN - object uuids and hashes, `prior_payload` null - and the values needed
 * to undo the work were only written at `settle()`, at the end. So a publish
 * killed halfway left pages changed on the live site, a release row reading
 * `applying`, and nothing anywhere that said which pages or what they used to
 * be. The site was half-published and MV could not have put it back.
 *
 * So each object's previous value is written to the release BEFORE that object
 * is touched, and the entry is marked again after. The marks are for reading;
 * the safety is the prior payload being on disk before the write.
 *
 * ## Recovery reads the site, not the journal
 *
 * §101: "Never blindly resume from an in-memory step counter." It is worth
 * being exact about why the journal is not one either. A publish can die
 * BETWEEN writing the page and marking the entry `written`, so the marks can
 * be one step behind the truth and there is no ordering that removes that -
 * the gap just moves. What the journal is for is the two hashes and the prior
 * payload; what actually happened is read off the live object:
 *
 *     live hash === base_hash       nothing was written here
 *     live hash === payload_hash    this one went out
 *     neither                       somebody else changed it since
 *
 * That last case is why "resume only if provably safe" is a real clause and
 * not a flourish. An object nobody can account for is never written to and
 * never restored; it is named, and the person decides.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceJournal {

    /** Where an entry has got to. Read-only signals: see the note above. */
    public const PLANNED = 'planned';
    public const WRITING = 'writing';
    public const WRITTEN = 'written';

    /** What the site says about one object, once the dust has settled. */
    public const UNTOUCHED = 'untouched';
    public const APPLIED   = 'applied';
    public const FOREIGN   = 'foreign';
    public const MISSING   = 'missing';

    /**
     * Write one object's entry into the release, merging by uuid.
     *
     * Read-modify-write on a single row, once per object. A publish of forty
     * objects is forty small updates, which is the price of the site being
     * recoverable at any point inside the loop.
     */
    public static function note( int $release_id, string $uuid, array $fields ): bool {
        global $wpdb;

        if ( $release_id <= 0 || '' === $uuid ) {
            return false;
        }
        $release = WorkspaceRelease::get( $release_id );
        if ( ! $release ) {
            return false;
        }

        $objects = $release['objects'];
        $found   = false;
        foreach ( $objects as $index => $entry ) {
            if ( (string) ( $entry['object_uuid'] ?? '' ) === $uuid ) {
                $objects[ $index ] = array_merge( $entry, $fields );
                $found             = true;
                break;
            }
        }
        if ( ! $found ) {
            $objects[] = array_merge( [ 'object_uuid' => $uuid ], $fields );
        }

        return (bool) $wpdb->update(
            WorkspaceRelease::table(),
            [ 'objects' => wp_json_encode( array_values( $objects ) ) ],
            [ 'id' => $release_id ],
            [ '%s' ],
            [ '%d' ]
        );
    }

    /**
     * The globals go out as one step, so they are journalled as one.
     *
     * Slice 11 publishes them before any page and holds their undo in a PHP
     * array, which is the same fault as the pages had and loses more: a
     * half-written set of globals affects every page on the site.
     */
    public static function note_globals( int $release_id, array $undo, string $state ): bool {
        global $wpdb;

        $release = WorkspaceRelease::get( $release_id );
        if ( ! $release ) {
            return false;
        }
        $objects   = $release['objects'];
        $objects[] = [
            'object_uuid' => 'globals',
            'adapter'     => 'globals',
            'object_type' => 'globals',
            'label'       => 'Global settings',
            'live_id'     => 0,
            'state'       => $state,
            'undo'        => $undo,
        ];
        // Only ever one globals entry per release.
        $seen  = false;
        $clean = [];
        foreach ( array_reverse( $objects ) as $entry ) {
            if ( 'globals' === (string) ( $entry['object_uuid'] ?? '' ) ) {
                if ( $seen ) {
                    continue;
                }
                $seen = true;
            }
            $clean[] = $entry;
        }

        return (bool) $wpdb->update(
            WorkspaceRelease::table(),
            [ 'objects' => wp_json_encode( array_values( array_reverse( $clean ) ) ) ],
            [ 'id' => $release_id ],
            [ '%s' ],
            [ '%d' ]
        );
    }

    /**
     * Every release that never settled.
     *
     * A release is opened `applying` and settled exactly once. One still
     * reading `applying` after the request that opened it has ended is a
     * publish that was interrupted - there is no other way to get one.
     */
    public static function interrupted(): array {
        global $wpdb;
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM ' . WorkspaceRelease::table() . ' WHERE status = %s ORDER BY id ASC',
                WorkspaceRelease::APPLYING
            ),
            ARRAY_A
        );
        $out = [];
        foreach ( is_array( $rows ) ? $rows : [] as $row ) {
            $release = WorkspaceRelease::get( (int) $row['id'] );
            if ( $release ) {
                $out[] = $release;
            }
        }
        return $out;
    }

    /**
     * What the live site says about each object in an interrupted release.
     *
     * The verdicts are read off the site and compared with the two hashes the
     * journal kept. Nothing here writes anything.
     */
    public static function assess( array $release ): array {
        $objects = [];
        $counts  = [ self::UNTOUCHED => 0, self::APPLIED => 0, self::FOREIGN => 0, self::MISSING => 0 ];
        $globals = null;

        foreach ( $release['objects'] as $entry ) {
            if ( 'globals' === (string) ( $entry['object_uuid'] ?? '' ) ) {
                $globals = [
                    'state'   => (string) ( $entry['state'] ?? self::PLANNED ),
                    'undo'    => is_array( $entry['undo'] ?? null ) ? $entry['undo'] : [],
                    'written' => count( is_array( $entry['undo'] ?? null ) ? $entry['undo'] : [] ),
                ];
                continue;
            }

            $live    = (int) ( $entry['live_id'] ?? 0 );
            $base    = (string) ( $entry['base_hash'] ?? '' );
            $wanted  = (string) ( $entry['payload_hash'] ?? '' );
            $verdict = self::FOREIGN;

            if ( $live <= 0 || ! get_post( $live ) ) {
                $verdict = self::MISSING;
            } else {
                $now = WorkspaceSnapshot::hash( $live );
                if ( '' !== $wanted && $now === $wanted ) {
                    $verdict = self::APPLIED;
                } elseif ( '' !== $base && $now === $base ) {
                    $verdict = self::UNTOUCHED;
                }
            }

            $counts[ $verdict ]++;
            $objects[] = [
                'uuid'      => (string) ( $entry['object_uuid'] ?? '' ),
                'label'     => (string) ( $entry['label'] ?? '' ),
                'type'      => (string) ( $entry['object_type'] ?? '' ),
                'live_id'   => $live,
                'state'     => (string) ( $entry['state'] ?? self::PLANNED ),
                'verdict'   => $verdict,
                // Whether this one could be put back if asked. An object
                // somebody else has changed could not, and is never guessed at.
                'undoable'  => self::APPLIED === $verdict && null !== ( $entry['prior_payload'] ?? null ),
            ];
        }

        /* Provably safe, and nothing weaker. Every object has to be either
           where it started or where this release meant to put it; one that is
           neither has been changed by somebody or something else since, and
           there is no way to finish or undo this release without writing over
           whatever they did. */
        $safe = 0 === $counts[ self::FOREIGN ] && 0 === $counts[ self::MISSING ];

        return [
            'release'  => [
                'id'         => (int) $release['id'],
                'uuid'       => (string) $release['uuid'],
                'workspace'  => (int) $release['workspace'],
                'kind'       => (string) $release['kind'],
                'created_at' => (string) $release['created_at'],
            ],
            'objects'  => $objects,
            'counts'   => $counts,
            'globals'  => $globals,
            'safe'     => $safe,
            'headline' => self::headline( $counts, $globals, $safe ),
        ];
    }

    /** One sentence saying what is on the site right now. */
    public static function headline( array $counts, $globals, bool $safe ): string {
        $applied = (int) $counts[ self::APPLIED ];
        $left    = (int) $counts[ self::UNTOUCHED ];
        $wrote   = $globals ? (int) $globals['written'] : 0;

        if ( ! $safe ) {
            $stray = (int) $counts[ self::FOREIGN ] + (int) $counts[ self::MISSING ];
            $total = $applied + $left + $stray;
            return 'This publish was interrupted, and ' . $stray . ' of its ' . $total
                . ' item' . ( 1 === $total ? '' : 's' ) . ( 1 === $stray ? ' is' : ' are' )
                . ' no longer in a state MV can account for. Nothing will be written or '
                . 'put back until you say so.';
        }
        if ( 0 === $applied && 0 === $wrote ) {
            return 'This publish was interrupted before anything reached the site.';
        }
        $parts = [];
        if ( $applied ) {
            $parts[] = $applied . ' page' . ( 1 === $applied ? '' : 's' );
        }
        if ( $wrote ) {
            $parts[] = $wrote . ' global setting' . ( 1 === $wrote ? '' : 's' );
        }
        return 'This publish was interrupted after ' . implode( ' and ', $parts )
            . ' had gone out' . ( $left ? ', with ' . $left . ' still to go' : '' ) . '.';
    }
}
