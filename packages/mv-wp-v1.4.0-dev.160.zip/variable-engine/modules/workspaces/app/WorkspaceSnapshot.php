<?php
/**
 * What a workspace object looked like, and what changed since.
 *
 * Slice 4 of the Workspaces module: handoff §19's three-way comparison.
 *
 *     BASE        the live payload at the moment the object joined the workspace
 *     WORKSPACE   the shadow's payload now
 *     LIVE NOW    the live post's payload now
 *
 * and the four outcomes §19 names:
 *
 *     workspace changed, live unchanged      -> safe publish candidate
 *     workspace unchanged, live changed      -> the workspace is behind
 *     both changed                           -> conflict
 *     both changed to the same normalised result -> no conflict
 *
 * That last one is why this hashes a CANONICAL form rather than the raw meta.
 * Two people can make the same edit in two sessions and PHP will hand back the
 * same array with its keys in a different order; a raw comparison calls that a
 * conflict and makes the owner resolve a difference that does not exist.
 *
 * WHAT IS IN THE PAYLOAD, AND WHAT IS DELIBERATELY NOT
 *
 * The Bricks meta `BricksPageAdapter::META` names, minus two exclusions:
 *
 *   - `_bricks_editor_mode` is which pane the builder was left showing. It is a
 *     preference belonging to whoever opened it last, not to the page. Hashing
 *     it would mark a page changed because somebody looked at it.
 *   - the post's TITLE is not in the payload at all, and that is a limitation
 *     rather than a nicety: `BricksPageAdapter::shadow_title()` deliberately
 *     renames the shadow, so every object in every workspace would read as
 *     modified the moment it was added. Slice 4 compares the Bricks payload.
 *     Renaming a page in a workspace is not yet a change this can see, and
 *     nothing here should pretend otherwise.
 *
 * WHAT THIS FILE MUST NEVER DO
 *
 * Read. That is all it does. It writes hashes onto MV's own map row and touches
 * no post, no meta and no option — the live post especially. A comparison that
 * can change what it is comparing is not a comparison.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceSnapshot {

    /**
     * Meta that belongs to whoever opened the builder, not to the page.
     * §19's fourth rule is about normalised results; this is the same idea one
     * level down — a difference that is not a difference.
     */
    public const VOLATILE = [
        '_bricks_editor_mode',
    ];

    /** §19's outcomes, named as the panel says them. */
    public const UNCHANGED = 'unchanged';
    public const MODIFIED  = 'modified';   // workspace changed, live did not
    public const BEHIND    = 'behind';     // live changed, workspace did not
    public const CONFLICT  = 'conflict';   // both changed, differently
    public const CONVERGED = 'converged';  // both changed, to the same thing

    /**
     * The payload of one post, canonically. `null` for a post that is not there
     * — which is itself a fact worth comparing: a live page deleted while a
     * workspace held a copy of it is not the same as one that never changed.
     *
     * @return array|null
     */
    public static function payload( int $post_id ) {
        if ( $post_id <= 0 || ! get_post( $post_id ) ) {
            return null;
        }
        $payload = [];
        foreach ( BricksPageAdapter::META as $key ) {
            if ( in_array( $key, self::VOLATILE, true ) ) {
                continue;
            }
            $value = get_post_meta( $post_id, $key, true );
            if ( '' === $value || null === $value || [] === $value ) {
                continue;
            }
            $payload[ $key ] = $value;
        }
        return $payload;
    }

    /**
     * The digest of a post's payload, or null if the post is gone.
     *
     * @return string|null
     */
    public static function hash( int $post_id ) {
        $payload = self::payload( $post_id );
        return null === $payload ? null : \VE\Core\CanonicalJson::hash( $payload );
    }

    /**
     * §19, and nothing but §19.
     *
     * A null hash means "could not be read" — a deleted post, or a row from
     * before slice 4 whose base was never captured. Without a base there is
     * nothing to compare against, and reporting `unchanged` would be a claim
     * rather than an answer, so it says so.
     *
     * @param string|null $base
     * @param string|null $workspace
     * @param string|null $live
     */
    public static function compare( $base, $workspace, $live ): string {
        if ( null === $base || null === $workspace ) {
            return self::UNCHANGED;
        }
        $workspace_moved = ( $workspace !== $base );
        $live_moved      = ( null !== $live && $live !== $base );

        if ( ! $workspace_moved && ! $live_moved ) {
            return self::UNCHANGED;
        }
        if ( $workspace_moved && ! $live_moved ) {
            return self::MODIFIED;
        }
        if ( ! $workspace_moved && $live_moved ) {
            return self::BEHIND;
        }
        // Both moved. §19: the same normalised result is not a conflict.
        return ( null !== $live && $workspace === $live ) ? self::CONVERGED : self::CONFLICT;
    }

    /**
     * Fix the base for an object that has just joined a workspace.
     *
     * Called once, at add time, from the live post — before the shadow has been
     * touched, so base, workspace and live are the same digest by construction.
     * Recording all three rather than only the base means a later comparison
     * never has to assume what the other two were.
     *
     * @return array The hash triple, as stored.
     */
    public static function capture_base( int $object_id ): array {
        $object = WorkspaceObjectMap::get( $object_id );
        if ( ! $object ) {
            return [ 'base' => null, 'workspace' => null, 'live' => null ];
        }
        $base = self::hash( (int) $object['live_id'] );
        $hashes = [
            'base'      => $base,
            'workspace' => null === $base ? self::hash( (int) $object['shadow_id'] ) : $base,
            'live'      => $base,
        ];
        WorkspaceObjectMap::set_hashes( $object_id, $hashes, self::UNCHANGED );
        return $hashes;
    }

    /**
     * Re-read one object and record where it stands. Returns the object row as
     * the map reports it, so a caller never has to re-fetch.
     *
     * @return array|null
     */
    public static function refresh( int $object_id ) {
        $object = WorkspaceObjectMap::get( $object_id );
        if ( ! $object ) {
            return null;
        }

        $base = isset( $object['hashes']['base'] ) ? $object['hashes']['base'] : null;
        if ( null === $base ) {
            // A row added before slice 4. Its base is the only thing that was
            // never recorded, and the live post is the closest honest answer:
            // it is what the shadow was copied from.
            return self::adopt_base( $object );
        }

        $workspace = self::hash( (int) $object['shadow_id'] );
        $live      = self::hash( (int) $object['live_id'] );
        $state     = self::compare( $base, $workspace, $live );

        WorkspaceObjectMap::set_hashes(
            $object_id,
            [ 'base' => $base, 'workspace' => $workspace, 'live' => $live ],
            $state
        );
        return WorkspaceObjectMap::get( $object_id );
    }

    /** Every object in a workspace, re-read. */
    public static function refresh_all( int $workspace_id ): array {
        $out = [];
        foreach ( WorkspaceObjectMap::all( $workspace_id ) as $object ) {
            $fresh = self::refresh( (int) $object['id'] );
            $out[] = $fresh ? $fresh : $object;
        }
        return $out;
    }

    /**
     * What a workspace has to say about itself: how many objects have moved,
     * and whether anything needs a person.
     */
    public static function summary( int $workspace_id, bool $refresh = true ): array {
        $counts = [
            self::UNCHANGED => 0,
            self::MODIFIED  => 0,
            self::BEHIND    => 0,
            self::CONFLICT  => 0,
            self::CONVERGED => 0,
        ];
        $objects = $refresh
            ? self::refresh_all( $workspace_id )
            // The list of workspaces reads a dozen cards. Re-hashing every post
            // behind every card on every GET would make opening the panel do
            // work nobody asked for, so the card reports what was last
            // recorded and opening the workspace refreshes it.
            : WorkspaceObjectMap::all( $workspace_id );
        foreach ( $objects as $object ) {
            $state = isset( $object['state'] ) ? (string) $object['state'] : self::UNCHANGED;
            if ( ! isset( $counts[ $state ] ) ) {
                $counts[ $state ] = 0;
            }
            $counts[ $state ] += 1;
        }
        return [
            'objects'   => array_sum( $counts ),
            // "Changes" is what the owner reads on the card, so it has to mean
            // what they would mean: things that have actually moved. It counted
            // objects held until slice 4, which read as a change list on a
            // workspace nobody had edited.
            'changes'   => $counts[ self::MODIFIED ] + $counts[ self::CONFLICT ] + $counts[ self::CONVERGED ],
            'behind'    => $counts[ self::BEHIND ],
            'conflicts' => $counts[ self::CONFLICT ],
            'states'    => $counts,
        ];
    }

    // ── internals ──────────────────────────────────────────────────────────

    /** A pre-slice-4 row: take the live payload as the base, once. */
    private static function adopt_base( array $object ) {
        $base = self::hash( (int) $object['live_id'] );
        if ( null === $base ) {
            return $object;
        }
        WorkspaceObjectMap::set_hashes(
            (int) $object['id'],
            [
                'base'      => $base,
                'workspace' => self::hash( (int) $object['shadow_id'] ),
                'live'      => $base,
            ],
            self::UNCHANGED
        );
        return self::refresh( (int) $object['id'] );
    }
}
