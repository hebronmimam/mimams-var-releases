<?php
/**
 * Which live object a workspace object shadows, and where its shadow lives.
 *
 * Slice 2 of the Workspaces module.
 *
 * Handoff §30: WordPress numeric IDs are not portable. They differ between
 * environments, and they differ between a live object and its shadow on the
 * SAME site. So every workspace object carries a v4 uuid that is its identity,
 * and the two native ids hang off it:
 *
 *     object_uuid  550e8400-...      the identity, stable everywhere
 *     live_id      42                the published post, never written to here
 *     shadow_id    918               the private post Bricks actually edits
 *
 * The hash columns are declared now and filled in slice 4. They are the base /
 * workspace / live triple that §19's conflict model compares, and the row has to
 * exist before there is anything to compare, so the shape is settled once rather
 * than migrated later.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceObjectMap {

    /** Isolation classes, per handoff §100.1. Stated per object, never implied. */
    public const ISO_STRUCTURAL = 'structural';
    public const ISO_RUNTIME    = 'runtime';

    public const STATE_UNCHANGED = 'unchanged';
    public const STATE_MODIFIED  = 'modified';
    public const STATE_ADDED     = 'added';

    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 've_workspace_objects';
    }

    /**
     * Record that a workspace now owns a shadow of a live object.
     *
     * @return array|\WP_Error
     */
    public static function add( int $workspace_id, array $fields ) {
        global $wpdb;

        if ( $workspace_id <= 0 ) {
            return self::error( 've_workspace_missing', 'That workspace no longer exists.' );
        }

        $live_id = isset( $fields['live_id'] ) ? (int) $fields['live_id'] : 0;
        if ( $live_id > 0 && self::find( $workspace_id, $live_id ) ) {
            return self::error( 've_object_already_added', 'That page is already in this workspace.' );
        }

        $now = current_time( 'mysql', true );
        $row = [
            'workspace_id' => $workspace_id,
            'object_uuid'  => WorkspaceStore::new_uuid(),
            'object_type'  => isset( $fields['object_type'] ) ? (string) $fields['object_type'] : 'bricks_page',
            'adapter'      => isset( $fields['adapter'] ) ? (string) $fields['adapter'] : 'bricks_page',
            'isolation'    => isset( $fields['isolation'] ) ? (string) $fields['isolation'] : self::ISO_STRUCTURAL,
            'label'        => isset( $fields['label'] ) ? (string) $fields['label'] : '',
            'live_id'      => $live_id > 0 ? $live_id : null,
            'shadow_id'    => isset( $fields['shadow_id'] ) ? (int) $fields['shadow_id'] : null,
            'state'        => isset( $fields['state'] ) ? (string) $fields['state'] : self::STATE_UNCHANGED,
            'created_at'   => $now,
            'updated_at'   => $now,
        ];

        $ok = $wpdb->insert(
            self::table(),
            $row,
            [ '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s' ]
        );
        if ( ! $ok ) {
            return self::error( 've_object_not_added', 'That page could not be added to the workspace.' );
        }

        return self::get( (int) $wpdb->insert_id );
    }

    /** @return array|null */
    public static function get( int $id ) {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ),
            ARRAY_A
        );
        return $row ? self::shape( $row ) : null;
    }

    /**
     * Is this live object already in this workspace?
     *
     * @return array|null
     */
    public static function find( int $workspace_id, int $live_id ) {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . self::table() . ' WHERE workspace_id = %d AND live_id = %d',
                $workspace_id,
                $live_id
            ),
            ARRAY_A
        );
        return $row ? self::shape( $row ) : null;
    }

    /**
     * Which workspace object is this post the shadow of?
     *
     * The lookup the resolver and the save guard both need: given the post ID
     * Bricks is editing, is it a workspace shadow, and whose.
     *
     * @return array|null
     */
    public static function by_shadow( int $shadow_id ) {
        global $wpdb;
        if ( $shadow_id <= 0 ) {
            return null;
        }
        $row = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE shadow_id = %d', $shadow_id ),
            ARRAY_A
        );
        return $row ? self::shape( $row ) : null;
    }

    /**
     * The row for a live object, whichever workspace holds it.
     *
     * Slice 6 needs this: a release names objects by uuid and live id, and when
     * it is rolled back the workspace's own base has to follow the site. Looking
     * it up by uuid would mean scanning every workspace; the live id is indexed.
     *
     * @return array|null
     */
    public static function by_live( int $live_id ) {
        global $wpdb;
        if ( $live_id <= 0 ) {
            return null;
        }
        $row = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE live_id = %d', $live_id ),
            ARRAY_A
        );
        return $row ? self::shape( $row ) : null;
    }

    public static function all( int $workspace_id ): array {
        global $wpdb;
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM ' . self::table() . ' WHERE workspace_id = %d ORDER BY object_type ASC, label ASC, id ASC',
                $workspace_id
            ),
            ARRAY_A
        );
        return array_map( [ __CLASS__, 'shape' ], is_array( $rows ) ? $rows : [] );
    }

    public static function count( int $workspace_id ): int {
        global $wpdb;
        return (int) $wpdb->get_var(
            $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::table() . ' WHERE workspace_id = %d', $workspace_id )
        );
    }

    /**
     * Record where an object stands. Slice 4: the only writer of the three hash
     * columns, and of `state` after the row is created.
     *
     * `$hashes` keys are base / workspace / live; a null is stored as an empty
     * string so the column can hold "read, and there was nothing there".
     */
    public static function set_hashes( int $id, array $hashes, string $state ): bool {
        global $wpdb;
        if ( $id <= 0 ) {
            return false;
        }
        $value = static function ( $v ) {
            return null === $v ? '' : (string) $v;
        };
        $ok = $wpdb->update(
            self::table(),
            [
                'base_hash'      => $value( isset( $hashes['base'] ) ? $hashes['base'] : null ),
                'workspace_hash' => $value( isset( $hashes['workspace'] ) ? $hashes['workspace'] : null ),
                'live_hash'      => $value( isset( $hashes['live'] ) ? $hashes['live'] : null ),
                'state'          => $state,
                'updated_at'     => current_time( 'mysql', true ),
            ],
            [ 'id' => $id ],
            [ '%s', '%s', '%s', '%s', '%s' ],
            [ '%d' ]
        );
        return false !== $ok;
    }

    /** @return true|\WP_Error */
    public static function remove( int $id ) {
        global $wpdb;
        if ( ! self::get( $id ) ) {
            return self::error( 've_object_missing', 'That object is no longer in the workspace.' );
        }
        if ( false === $wpdb->delete( self::table(), [ 'id' => $id ], [ '%d' ] ) ) {
            return self::error( 've_object_not_removed', 'It could not be removed from the workspace.' );
        }
        return true;
    }

    /** Every row belonging to a workspace, for discard and for cleanup. */
    public static function remove_all( int $workspace_id ): int {
        global $wpdb;
        $n = $wpdb->delete( self::table(), [ 'workspace_id' => $workspace_id ], [ '%d' ] );
        return false === $n ? 0 : (int) $n;
    }

    /**
     * Grouped the way the panel and §10's change summary want it: by object
     * family, not as a flat list.
     */
    public static function grouped( int $workspace_id ): array {
        $labels = [
            'bricks_page'     => 'Pages',
            'bricks_template' => 'Templates',
        ];
        $groups = [];
        foreach ( self::all( $workspace_id ) as $object ) {
            $name = isset( $labels[ $object['object_type'] ] ) ? $labels[ $object['object_type'] ] : 'Other';
            if ( ! isset( $groups[ $name ] ) ) {
                $groups[ $name ] = [ 'name' => $name, 'items' => [] ];
            }
            $groups[ $name ]['items'][] = $object;
        }
        return array_values( $groups );
    }

    // ── internals ──────────────────────────────────────────────────────────

    private static function shape( array $row ): array {
        return [
            'id'          => (int) $row['id'],
            'workspace'   => (int) $row['workspace_id'],
            'uuid'        => (string) $row['object_uuid'],
            'object_type' => (string) $row['object_type'],
            'adapter'     => (string) $row['adapter'],
            'isolation'   => (string) $row['isolation'],
            'label'       => (string) $row['label'],
            'live_id'     => empty( $row['live_id'] ) ? null : (int) $row['live_id'],
            'shadow_id'   => empty( $row['shadow_id'] ) ? null : (int) $row['shadow_id'],
            'state'       => (string) $row['state'],
            // Slice 4 fills these. Reported as null rather than '' so a client
            // cannot mistake "not computed yet" for "computed, and empty".
            //
            // Read defensively: a row written before a column existed comes back
            // without the key, and dbDelta adds columns to live sites on the
            // update after the one that declared them. A missing hash means "not
            // computed", which is the same answer as an empty one.
            'hashes'      => [
                'base'      => self::hash( $row, 'base_hash' ),
                'workspace' => self::hash( $row, 'workspace_hash' ),
                'live'      => self::hash( $row, 'live_hash' ),
            ],
            'created_at'  => (string) $row['created_at'],
            'updated_at'  => (string) $row['updated_at'],
        ];
    }

    /** @return string|null */
    private static function hash( array $row, string $key ) {
        if ( ! isset( $row[ $key ] ) ) {
            return null;
        }
        $value = (string) $row[ $key ];
        return '' === $value ? null : $value;
    }

    /** @return \WP_Error|array */
    private static function error( string $code, string $message ) {
        if ( class_exists( '\WP_Error' ) ) {
            return new \WP_Error( $code, $message, [ 'status' => 400 ] );
        }
        return [ 'error' => $code, 'message' => $message ];
    }
}
