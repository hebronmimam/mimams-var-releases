<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * CanonicalJson — one spelling of a value, so two of them can be compared.
 *
 * Extracted from `VE\Sync\PortableBundleManager::canonical_json()`, which has
 * been deciding whether two bundle configurations are the same since the sync
 * engine shipped. Workspaces slice 4 needs exactly that and the slice plan says
 * so in as many words: *"reuse PortableBundleManager's canonical serialiser per
 * the audit, do not write a second"*. A second one would drift, and the first
 * time it drifted a workspace would report a change that is not there — or,
 * worse, miss one that is.
 *
 * The rule is narrow on purpose:
 *
 *   - a MAP is sorted by key, because PHP preserves insertion order and two
 *     writers of the same data insert in whatever order they happened to read
 *     it. `['a' => 1, 'b' => 2]` and `['b' => 2, 'a' => 1]` are the same value.
 *   - a LIST is NOT sorted, because the order of a list is part of its meaning.
 *     Bricks stores a page as an ordered array of elements; sorting it would
 *     make moving a section invisible.
 *
 * "Map" here means what PHP calls an array whose keys are not `0..n-1` — the
 * same test the original used.
 *
 * @package VE\Core
 */
final class CanonicalJson {

    /**
     * The canonical JSON text for a value.
     *
     * @param mixed $value
     */
    public static function encode( $value ): string {
        return (string) wp_json_encode( self::normalise( $value ) );
    }

    /**
     * The canonical SHA-256 of a value. Two values that mean the same thing
     * give the same digest whatever order their keys arrived in.
     *
     * @param mixed $value
     */
    public static function hash( $value ): string {
        return hash( 'sha256', self::encode( $value ) );
    }

    /**
     * @param mixed $value
     * @return mixed
     */
    private static function normalise( $value ) {
        if ( ! is_array( $value ) ) {
            return $value;
        }
        if ( array_keys( $value ) !== range( 0, count( $value ) - 1 ) ) {
            ksort( $value );
        }
        foreach ( $value as $key => $item ) {
            $value[ $key ] = self::normalise( $item );
        }
        return $value;
    }
}
