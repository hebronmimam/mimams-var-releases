<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * ContentReadiness — the owner's own rules about whether a post is ready.
 *
 * B57, built on their instruction of 2026-09-15, and shaped by one sentence of
 * theirs that settles the hardest question in it:
 *
 *   > "an unmet rule should only warn."
 *
 * So there is no blocking mode, no `severity`, no per-rule escalation and no
 * setting that could grow one. A rule that can stop a publish is a rule that
 * gets switched off the first time it is wrong, and then it protects nothing.
 * This says what is unmet and stays out of the way. Publishing is never refused
 * on its account, and the absence of that code path is the feature.
 *
 * WHAT A RULE IS
 *
 *     id          a slug, stable, so a rule can be renamed without losing it
 *     label       what the owner calls it
 *     check       one of CHECKS below
 *     value       the number or text the check compares against, where it needs one
 *     post_types  which content it applies to; empty means all
 *
 * Every check is evaluated from the post itself. Nothing is stored per post: a
 * post is not "marked ready", it is read and answered about, so changing a rule
 * re-answers every post immediately rather than leaving stale marks behind.
 *
 * @package VE\Core
 */
final class ContentReadiness {

    public const OPTION = 've_content_readiness';

    /**
     * What a rule can ask. Each is a closure over the post, returning true when
     * the rule is MET.
     *
     * Deliberately a fixed list rather than arbitrary expressions: a rule
     * language is a second product, and everything here is answerable from a
     * post without one.
     */
    public static function checks(): array {
        return [
            'featured_image' => [
                'label' => 'Has a featured image',
                'needs' => null,
                'test'  => static function ( $post ) {
                    return (bool) get_post_thumbnail_id( $post->ID );
                },
            ],
            'excerpt' => [
                'label' => 'Has an excerpt',
                'needs' => null,
                'test'  => static function ( $post ) {
                    return '' !== trim( (string) $post->post_excerpt );
                },
            ],
            'word_count' => [
                'label' => 'At least N words',
                'needs' => 'number',
                'test'  => static function ( $post, $value ) {
                    $words = preg_split( '/\s+/', trim( wp_strip_all_tags( (string) $post->post_content ) ) );
                    $words = array_filter( (array) $words, static function ( $w ) { return '' !== $w; } );
                    return count( $words ) >= max( 0, (int) $value );
                },
            ],
            'has_category' => [
                'label' => 'In a real category',
                'needs' => null,
                'test'  => static function ( $post ) {
                    $terms = wp_get_post_terms( $post->ID, 'category', [ 'fields' => 'slugs' ] );
                    if ( is_wp_error( $terms ) ) {
                        return true;   // cannot read it, so cannot fail it
                    }
                    $real = array_diff( (array) $terms, [ 'uncategorized', 'uncategorised' ] );
                    return ! empty( $real );
                },
            ],
            'has_tag' => [
                'label' => 'Has at least one tag',
                'needs' => null,
                'test'  => static function ( $post ) {
                    $terms = wp_get_post_terms( $post->ID, 'post_tag', [ 'fields' => 'ids' ] );
                    return ! is_wp_error( $terms ) && ! empty( $terms );
                },
            ],
            'seo_description' => [
                'label' => 'SEO description filled',
                'needs' => null,
                'test'  => static function ( $post ) {
                    return '' !== trim( (string) get_post_meta( $post->ID, 'rank_math_description', true ) );
                },
            ],
            'focus_keyword' => [
                'label' => 'Focus keyword set',
                'needs' => null,
                'test'  => static function ( $post ) {
                    return '' !== trim( (string) get_post_meta( $post->ID, 'rank_math_focus_keyword', true ) );
                },
            ],
            'internal_link' => [
                'label' => 'Links to another page on this site',
                'needs' => null,
                'test'  => static function ( $post ) {
                    $home = wp_parse_url( home_url(), PHP_URL_HOST );
                    if ( ! preg_match_all( '/<a\s[^>]*href=(["\'])(.*?)\1/i', (string) $post->post_content, $m ) ) {
                        return false;
                    }
                    foreach ( $m[2] as $href ) {
                        $href = trim( $href );
                        if ( '' === $href || 0 === strpos( $href, '#' ) ) {
                            continue;
                        }
                        // A root-relative link is always this site.
                        if ( 0 === strpos( $href, '/' ) && 0 !== strpos( $href, '//' ) ) {
                            return true;
                        }
                        $host = wp_parse_url( $href, PHP_URL_HOST );
                        if ( $host && $home && strtolower( $host ) === strtolower( $home ) ) {
                            return true;
                        }
                    }
                    return false;
                },
            ],
            'meta_filled' => [
                'label' => 'A custom field is filled',
                'needs' => 'text',
                'test'  => static function ( $post, $value ) {
                    $key = trim( (string) $value );
                    if ( '' === $key ) {
                        return true;   // an unfinished rule cannot fail a post
                    }
                    $stored = get_post_meta( $post->ID, $key, true );
                    return ! ( '' === $stored || null === $stored || [] === $stored );
                },
            ],
        ];
    }

    /** The owner's rules, as stored. */
    public static function rules(): array {
        $stored = get_option( self::OPTION, [] );
        if ( ! is_array( $stored ) ) {
            return [];
        }
        $checks = self::checks();
        $out    = [];
        foreach ( $stored as $rule ) {
            if ( ! is_array( $rule ) || empty( $rule['check'] ) || ! isset( $checks[ $rule['check'] ] ) ) {
                continue;   // a check that no longer exists is dropped, not guessed at
            }
            $out[] = [
                'id'         => isset( $rule['id'] ) ? (string) $rule['id'] : self::new_id(),
                'label'      => isset( $rule['label'] ) && '' !== trim( (string) $rule['label'] )
                    ? (string) $rule['label']
                    : (string) $checks[ $rule['check'] ]['label'],
                'check'      => (string) $rule['check'],
                'value'      => isset( $rule['value'] ) ? $rule['value'] : '',
                'post_types' => isset( $rule['post_types'] ) && is_array( $rule['post_types'] )
                    ? array_values( array_filter( array_map( 'sanitize_key', $rule['post_types'] ) ) )
                    : [],
            ];
        }
        return $out;
    }

    /** @return array|\WP_Error */
    public static function save( array $rules ) {
        $checks = self::checks();
        $clean  = [];
        foreach ( $rules as $rule ) {
            if ( ! is_array( $rule ) ) {
                continue;
            }
            $check = isset( $rule['check'] ) ? (string) $rule['check'] : '';
            if ( ! isset( $checks[ $check ] ) ) {
                continue;
            }
            $clean[] = [
                'id'         => isset( $rule['id'] ) && $rule['id'] ? (string) $rule['id'] : self::new_id(),
                'label'      => sanitize_text_field( (string) ( $rule['label'] ?? $checks[ $check ]['label'] ) ),
                'check'      => $check,
                'value'      => isset( $rule['value'] ) && is_scalar( $rule['value'] )
                    ? sanitize_text_field( (string) $rule['value'] )
                    : '',
                'post_types' => isset( $rule['post_types'] ) && is_array( $rule['post_types'] )
                    ? array_values( array_filter( array_map( 'sanitize_key', $rule['post_types'] ) ) )
                    : [],
            ];
        }
        update_option( self::OPTION, $clean );
        return self::rules();
    }

    /**
     * How one post stands against the rules that apply to it.
     *
     * Always returns `blocking: false`. It is stated rather than implied,
     * because the panel reads this payload and somebody later will look for the
     * flag that decides whether to disable the publish button - and the answer
     * needs to be visibly, permanently no.
     */
    public static function review( int $post_id ): array {
        $post = get_post( $post_id );
        if ( ! $post ) {
            return [ 'rules' => [], 'unmet' => 0, 'blocking' => false ];
        }

        $checks = self::checks();
        $rows   = [];
        $unmet  = 0;
        foreach ( self::rules() as $rule ) {
            if ( $rule['post_types'] && ! in_array( $post->post_type, $rule['post_types'], true ) ) {
                continue;
            }
            $spec = $checks[ $rule['check'] ];
            $met  = (bool) call_user_func( $spec['test'], $post, $rule['value'] );
            if ( ! $met ) {
                $unmet++;
            }
            $rows[] = [
                'id'    => $rule['id'],
                'label' => $rule['label'],
                'check' => $rule['check'],
                'value' => $rule['value'],
                'met'   => $met,
            ];
        }

        return [
            'rules'    => $rows,
            'unmet'    => $unmet,
            // "an unmet rule should only warn." - the owner, 2026-09-15.
            'blocking' => false,
        ];
    }

    private static function new_id(): string {
        return 'rr_' . substr( md5( uniqid( '', true ) ), 0, 8 );
    }
}
