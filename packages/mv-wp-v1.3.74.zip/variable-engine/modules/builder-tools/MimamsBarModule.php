<?php
namespace VE\Modules\BuilderTools;

defined('ABSPATH') || exit;

final class MimamsBarModule {
    public const VERSION = '0.3.18';

    public function enqueue(): void {
        if (!current_user_can('edit_posts') && !current_user_can('manage_options')) {
            return;
        }

        $settings = get_option('ve_settings', []);
        $deactivated = isset($settings['deactivated_tools']) && is_array($settings['deactivated_tools'])
            ? $settings['deactivated_tools']
            : [];
        $surface_deactivated = isset($settings['deactivated_tool_surfaces']) && is_array($settings['deactivated_tool_surfaces'])
            ? $settings['deactivated_tool_surfaces']
            : [];
        $builder_deactivated = isset($surface_deactivated['builder']) && is_array($surface_deactivated['builder'])
            ? $surface_deactivated['builder']
            : [];
        if (in_array('mimams_bar', $deactivated, true) || in_array('mimams_bar', $builder_deactivated, true)) {
            return;
        }

        // If the standalone Mimam's Bar plugin is active, do not load the bundled module too.
        if (defined('BAQA_VERSION')) {
            return;
        }

        if (apply_filters('ve_mimams_bar_enabled', true) === false) {
            return;
        }

        $base_dir = VE_DIR . 'modules/builder-tools/mimams-bar/';
        $base_url = VE_URL . 'modules/builder-tools/mimams-bar/';
        $css_path = $base_dir . 'assets/css/builder.css';

        wp_enqueue_style(
            've-mimams-bar',
            $base_url . 'assets/css/builder.css',
            [],
            VE_VERSION . '.' . self::VERSION . '.' . (file_exists($css_path) ? filemtime($css_path) : time())
        );

        $scripts = [
            've-mb-core' => [
                'path' => 'assets/js/modules/core.js',
                'deps' => [],
            ],
            've-mb-command-parser' => [
                'path' => 'assets/js/modules/command-parser.js',
                'deps' => ['ve-mb-core'],
            ],
            've-mb-bricks-adapter' => [
                'path' => 'assets/js/modules/bricks-adapter.js',
                'deps' => ['ve-mb-core'],
            ],
            've-mb-settings-manager' => [
                'path' => 'assets/js/modules/settings-manager.js',
                'deps' => ['ve-mb-core'],
            ],
            've-mb-toast-manager' => [
                'path' => 'assets/js/modules/toast-manager.js',
                'deps' => ['ve-mb-core'],
            ],
            've-mb-field-assist-manager' => [
                'path' => 'assets/js/modules/field-assist-manager.js',
                'deps' => ['ve-mb-core'],
            ],
            've-mb-element-search-manager' => [
                'path' => 'assets/js/modules/element-search-manager.js',
                'deps' => ['ve-mb-core', 've-mb-bricks-adapter'],
            ],
            've-mb-emmet-manager' => [
                'path' => 'assets/js/modules/emmet-manager.js',
                'deps' => ['ve-mb-core', 've-mb-element-search-manager'],
            ],
            've-mb-mv-integration' => [
                'path' => 'assets/js/modules/mv-integration-manager.js',
                'deps' => ['ve-mb-core'],
            ],
            've-mb-command-suggestions' => [
                'path' => 'assets/js/modules/command-suggestion-manager.js',
                'deps' => ['ve-mb-core', 've-mb-bricks-adapter', 've-mb-mv-integration'],
            ],
            've-mb-bulk-manager' => [
                'path' => 'assets/js/modules/bulk-manager.js',
                'deps' => ['ve-mb-core'],
            ],
            've-mb-dialog-manager' => [
                'path' => 'assets/js/modules/dialog-manager.js',
                'deps' => ['ve-mb-core', 've-mb-bulk-manager'],
            ],
            've-mb-ui-renderer' => [
                'path' => 'assets/js/modules/ui-renderer.js',
                'deps' => ['ve-mb-core'],
            ],
            've-mb-operation-manager' => [
                'path' => 'assets/js/modules/operation-manager.js',
                'deps' => ['ve-mb-core'],
            ],
            've-mb-panel-manager' => [
                'path' => 'assets/js/modules/panel-manager.js',
                'deps' => ['ve-mb-core', 've-mb-settings-manager'],
            ],
            've-mb-mode-manager' => [
                'path' => 'assets/js/modules/mode-manager.js',
                'deps' => ['ve-mb-core'],
            ],
            've-mb-app-shell' => [
                'path' => 'assets/js/modules/app-shell.js',
                'deps' => ['ve-mb-core'],
            ],
            've-mb-input-manager' => [
                'path' => 'assets/js/modules/input-manager.js',
                'deps' => ['ve-mb-core', 've-mb-field-assist-manager'],
            ],
            've-mb-target-manager' => [
                'path' => 'assets/js/modules/target-manager.js',
                'deps' => ['ve-mb-core', 've-mb-ui-renderer', 've-mb-bricks-adapter'],
            ],
            've-mb-global-events' => [
                'path' => 'assets/js/modules/global-event-manager.js',
                'deps' => ['ve-mb-core', 've-mb-bricks-adapter', 've-mb-dialog-manager'],
            ],
            've-mb-app-controller' => [
                'path' => 'assets/js/modules/app-controller.js',
                'deps' => ['ve-mb-core', 've-mb-command-parser', 've-mb-bricks-adapter', 've-mb-settings-manager', 've-mb-toast-manager', 've-mb-field-assist-manager', 've-mb-element-search-manager', 've-mb-emmet-manager', 've-mb-mv-integration', 've-mb-command-suggestions', 've-mb-bulk-manager', 've-mb-dialog-manager', 've-mb-ui-renderer', 've-mb-operation-manager', 've-mb-panel-manager', 've-mb-mode-manager', 've-mb-app-shell', 've-mb-input-manager', 've-mb-target-manager', 've-mb-global-events'],
            ],
            've-mimams-bar-app' => [
                'path' => 'assets/js/builder.js',
                'deps' => ['ve-mb-app-controller'],
            ],
        ];

        foreach ($scripts as $handle => $script) {
            $script_path = $base_dir . $script['path'];
            wp_enqueue_script(
                $handle,
                $base_url . $script['path'],
                $script['deps'],
                VE_VERSION . '.' . self::VERSION . '.' . (file_exists($script_path) ? filemtime($script_path) : time()),
                true
            );
        }

        wp_localize_script('ve-mb-core', 'baqaConfig', [
            'version'  => self::VERSION,
            'debug'    => (bool) apply_filters('ve_mimams_bar_debug', defined('WP_DEBUG') && WP_DEBUG),
            'shortcut' => apply_filters('ve_mimams_bar_shortcut', [
                'ctrl'  => false,
                'alt'   => true,
                'shift' => false,
                'meta'  => false,
                'key'   => 'q',
            ]),
            'labels' => [
                'title'       => "Mimam's Bar",
                'placeholder' => 'data-anim="fade-up" .hero #section-id delete data-anim',
                'selectFirst' => 'Select a Bricks element first.',
                'selectForDirect' => 'Pick a target from Search Page, or add a new element.',
                'applied'     => 'Attributes applied. Save in Bricks to persist.',
                'invalid'     => 'Invalid attribute syntax. Nothing was applied.',
            ],
            'source' => 'mimams-var-builder-tools',
            'apiRoot' => esc_url_raw(rest_url()),
            'nonce' => wp_create_nonce('wp_rest'),
        ]);

        // Prevent FOUC when panels are floating
        add_action('wp_head', function() {
            echo "<script>
                (function() {
                    try {
                        var settings = JSON.parse(localStorage.getItem('mimamsBarSettings') || '{}');
                        var cl = document.documentElement.classList;
                        if (settings.floatElements) cl.add('mimams-bar-float-bricks-elements');
                        if (settings.floatStructure) cl.add('mimams-bar-float-bricks-structure');
                        if (settings.hideElements) cl.add('mimams-bar-hide-bricks-elements');
                        if (settings.hideStructure) cl.add('mimams-bar-hide-bricks-structure');
                        if (settings.showVengineTopBarIcon === false) cl.add('ve-hide-top-bar-icon');
                        if (settings.showTopBarIcon === false) cl.add('mimams-bar-hide-top-bar-icon');
                    } catch(e) {}
                })();
            </script>";
        }, 0);
    }
}
