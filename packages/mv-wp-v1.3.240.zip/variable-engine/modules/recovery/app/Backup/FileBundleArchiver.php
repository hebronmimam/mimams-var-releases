<?php

namespace VE\Modules\Recovery\Backup;

use VE\Modules\Recovery\Storage\LocalStorage;

// phpcs:disable WordPress.WP.AlternativeFunctions

defined( 'ABSPATH' ) || exit;

/**
 * RestoreBase raw file bundle writer.
 *
 * ZIP is portable, but creating a ZIP entry for every small WordPress file is
 * expensive. This writer appends files into one RestoreBase-owned bundle with a
 * tiny per-file header. It avoids CRC calculation, central directory writes,
 * native shell process waits, and repeated ZipArchive open/close cycles.
 */
final class FileBundleArchiver {
    private const MAGIC = "RESTOREBASE-BUNDLE-1\n";
    private const ENTRY = "RBEN";
    private const END = "RBEND";

    private int $max_files;
    private int $max_bytes;
    private int $max_single_file;

    public function __construct( int $max_files = 100000, int $max_bytes = 5368709120, int $max_single_file = 536870912 ) {
        $this->max_files = max( 100, min( 250000, absint( $max_files ) ) );
        $this->max_bytes = max( 1048576, absint( $max_bytes ) );
        $this->max_single_file = max( 1048576, absint( $max_single_file ) );
    }

    public function archive( string $path, array $inventory, ?callable $progress = null, ?callable $should_cancel = null, array $state = [] ): array {
        if ( isset( $state['method'] ) && 'restorebase_bundle' !== (string) $state['method'] ) {
            $state = [];
        }
        $files = isset( $inventory['files'] ) && is_array( $inventory['files'] ) ? array_values( $inventory['files'] ) : [];
        $total_candidates = count( $files );
        $offset = max( 0, (int) ( $state['offset'] ?? 0 ) );
        $included = max( 0, (int) ( $state['included'] ?? 0 ) );
        $skipped = max( 0, (int) ( $state['skipped'] ?? 0 ) );
        $bytes = max( 0, (int) ( $state['bytes'] ?? 0 ) );
        $too_large = max( 0, (int) ( $state['too_large'] ?? 0 ) );
        $unreadable = max( 0, (int) ( $state['unreadable'] ?? 0 ) );
        $truncated = ! empty( $state['truncated'] );
        $groups = isset( $state['groups'] ) && is_array( $state['groups'] ) ? $state['groups'] : [];
        $group_bytes = isset( $state['group_bytes'] ) && is_array( $state['group_bytes'] ) ? $state['group_bytes'] : [];
        $request = (int) ( $state['request'] ?? 0 ) + 1;

        $dir = dirname( $path );
        if ( ! is_dir( $dir ) ) {
            wp_mkdir_p( $dir );
        }

        $first = 0 === $offset && 0 === $included && empty( $state );
        if ( $first && file_exists( $path ) ) {
            @unlink( $path );
        }

        $handle = @fopen( $path, $first ? 'wb' : 'ab' );
        if ( ! is_resource( $handle ) ) {
            return [
                'ok'      => false,
                'message' => 'RestoreBase bundle could not be opened for writing.',
                'path'    => '',
                'hash'    => '',
                'size'    => 0,
                'summary' => [],
            ];
        }

        if ( $first ) {
            fwrite( $handle, self::MAGIC );
        }

        $started = microtime( true );
        $last_progress_at = $started;
        $time_budget = $this->time_budget();
        $max_per_request = $this->files_per_request();
        $processed_this_request = 0;
        $bytes_this_request = 0;

        if ( is_callable( $progress ) ) {
            $progress(
                'Bundling files: ' . number_format_i18n( $included ) . ' of ' . number_format_i18n( $total_candidates ) . '.',
                $this->within_progress( $offset, $total_candidates ),
                [
                    'seen'    => $offset,
                    'copied'  => $included,
                    'total'   => $total_candidates,
                    'bytes'   => $bytes,
                    'method'  => 'raw bundle',
                    'chunked' => true,
                    'request' => $request,
                    'mode'    => 'no zip-per-file overhead',
                ]
            );
        }

        for ( $i = $offset; $i < $total_candidates; $i++ ) {
            if ( is_callable( $should_cancel ) && $should_cancel() ) {
                fclose( $handle );
                return [ 'ok' => false, 'cancelled' => true, 'message' => 'Backup cancelled while bundling files.', 'path' => '', 'hash' => '', 'size' => 0, 'summary' => [ 'included_files' => $included, 'skipped_files' => $skipped ] ];
            }

            if ( $included >= $this->max_files || $bytes >= $this->max_bytes ) {
                $truncated = true;
                $skipped += ( $total_candidates - $i );
                $offset = $total_candidates;
                break;
            }

            $file = $files[ $i ];
            $relative = isset( $file['path'] ) ? trim( wp_normalize_path( (string) $file['path'] ), '/' ) : '';
            $offset = $i + 1;
            $processed_this_request++;

            if ( '' === $relative || false !== strpos( $relative, "\0" ) || 0 === strpos( $relative, '../' ) || false !== strpos( $relative, '/../' ) ) {
                $skipped++;
                continue;
            }

            $absolute = LocalStorage::absolute_from_relative( $relative );
            if ( ! is_readable( $absolute ) || ! is_file( $absolute ) || is_link( $absolute ) ) {
                $unreadable++;
                $skipped++;
                continue;
            }

            $size = (int) filesize( $absolute );
            if ( $size > $this->max_single_file ) {
                $too_large++;
                $skipped++;
                continue;
            }

            if ( ( $bytes + $size ) > $this->max_bytes ) {
                $truncated = true;
                $skipped += ( $total_candidates - $i );
                $offset = $total_candidates;
                break;
            }

            $write = $this->write_entry( $handle, $absolute, $relative, $size );
            if ( empty( $write['ok'] ) ) {
                fclose( $handle );
                return [
                    'ok'      => false,
                    'message' => (string) ( $write['message'] ?? 'RestoreBase bundle write failed.' ),
                    'path'    => '',
                    'hash'    => '',
                    'size'    => file_exists( $path ) ? (int) filesize( $path ) : 0,
                    'summary' => $this->summary( $included, $bytes, $skipped, $unreadable, $too_large, $truncated, $groups, $group_bytes ),
                ];
            }

            $included++;
            $bytes += $size;
            $bytes_this_request += $size;
            $group = $this->group( $relative );
            $groups[ $group ] = ( $groups[ $group ] ?? 0 ) + 1;
            $group_bytes[ $group ] = ( $group_bytes[ $group ] ?? 0 ) + $size;

            if ( is_callable( $progress ) && ( 0 === ( ( $included + $skipped ) % 500 ) || microtime( true ) - $last_progress_at >= 0.75 || $included < 5 ) ) {
                $progress(
                    'Bundling files: ' . number_format_i18n( $included ) . ' of ' . number_format_i18n( $total_candidates ) . '.',
                    $this->within_progress( $offset, $total_candidates ),
                    [
                        'seen'                 => $offset,
                        'copied'               => $included,
                        'total'                => $total_candidates,
                        'bytes'                => $bytes,
                        'method'               => 'raw bundle',
                        'chunked'              => true,
                        'request'              => $request,
                        'written_this_request' => $bytes_this_request,
                    ]
                );
                $last_progress_at = microtime( true );
            }

            if ( $processed_this_request >= $max_per_request || microtime( true ) - $started >= $time_budget ) {
                break;
            }
        }

        fflush( $handle );
        fclose( $handle );

        $next_state = [
            'method'      => 'restorebase_bundle',
            'offset'      => $offset,
            'included'    => $included,
            'skipped'     => $skipped,
            'bytes'       => $bytes,
            'too_large'   => $too_large,
            'unreadable'  => $unreadable,
            'truncated'   => $truncated,
            'groups'      => $groups,
            'group_bytes' => $group_bytes,
            'request'     => $request,
            'last_size'   => file_exists( $path ) ? (int) filesize( $path ) : 0,
            'updated_at'  => current_time( 'mysql' ),
        ];

        if ( $offset < $total_candidates ) {
            return [
                'ok'            => true,
                'deferred'      => true,
                'message'       => 'Bundling files: ' . number_format_i18n( $included ) . ' of ' . number_format_i18n( $total_candidates ) . '.',
                'path'          => $path,
                'relative_path' => basename( $path ),
                'hash'          => '',
                'size'          => file_exists( $path ) ? (int) filesize( $path ) : 0,
                'state'         => $next_state,
                'summary'       => $this->summary( $included, $bytes, $skipped, $unreadable, $too_large, $truncated, $groups, $group_bytes ),
                'seen'          => $offset,
                'copied'        => $included,
                'total'         => $total_candidates,
                'bytes'         => $bytes,
                'method'        => 'raw bundle',
                'format'        => 'restorebase_bundle',
                'chunked'       => true,
            ];
        }

        $final = @fopen( $path, 'ab' );
        if ( is_resource( $final ) ) {
            fwrite( $final, self::END );
            fclose( $final );
        }

        if ( is_callable( $progress ) ) {
            $progress( 'File bundle finalized: ' . number_format_i18n( $included ) . ' files.', 1, [ 'seen' => $offset, 'copied' => $included, 'total' => $total_candidates, 'bytes' => $bytes, 'method' => 'raw bundle', 'chunked' => true ] );
        }

        $exists = file_exists( $path );
        return [
            'ok'            => $exists,
            'message'       => $exists ? 'RestoreBase file bundle created.' : 'RestoreBase file bundle was not found after creation.',
            'path'          => $exists ? $path : '',
            'relative_path' => basename( $path ),
            'hash'          => is_readable( $path ) ? (string) hash_file( 'sha256', $path ) : '',
            'size'          => $exists ? (int) filesize( $path ) : 0,
            'summary'       => $this->summary( $included, $bytes, $skipped, $unreadable, $too_large, $truncated, $groups, $group_bytes ),
            'seen'          => $offset,
            'copied'        => $included,
            'total'         => $total_candidates,
            'bytes'         => $bytes,
            'method'        => 'raw bundle',
            'format'        => 'restorebase_bundle',
            'chunked'       => true,
        ];
    }

    private function write_entry( $handle, string $absolute, string $relative, int $size ): array {
        $path_bytes = $relative;
        $path_len = strlen( $path_bytes );
        if ( $path_len <= 0 || $path_len > 1048576 ) {
            return [ 'ok' => false, 'message' => 'Bundle entry path is invalid: ' . basename( $relative ) ];
        }

        $mtime = (int) filemtime( $absolute );
        $header = self::ENTRY . pack( 'V', $path_len ) . $this->pack_uint64_le( $size ) . $this->pack_uint64_le( $mtime ) . $path_bytes;
        if ( false === fwrite( $handle, $header ) ) {
            return [ 'ok' => false, 'message' => 'Could not write bundle entry header.' ];
        }

        $input = @fopen( $absolute, 'rb' );
        if ( ! is_resource( $input ) ) {
            return [ 'ok' => false, 'message' => 'Could not read file while bundling: ' . $relative ];
        }

        $written = 0;
        while ( ! feof( $input ) ) {
            $chunk = fread( $input, 4194304 );
            if ( false === $chunk ) {
                fclose( $input );
                return [ 'ok' => false, 'message' => 'Could not read file chunk while bundling: ' . $relative ];
            }
            if ( '' === $chunk ) {
                continue;
            }
            $length = strlen( $chunk );
            $out = fwrite( $handle, $chunk );
            if ( false === $out || $out < $length ) {
                fclose( $input );
                return [ 'ok' => false, 'message' => 'Could not write file data to bundle: ' . $relative ];
            }
            $written += $length;
        }
        fclose( $input );

        if ( $written !== $size ) {
            return [ 'ok' => false, 'message' => 'File changed while bundling: ' . $relative ];
        }

        return [ 'ok' => true ];
    }

    private function pack_uint64_le( int $value ): string {
        $low = $value & 0xFFFFFFFF;
        $high = (int) floor( $value / 4294967296 );
        return pack( 'VV', $low, $high );
    }

    private function within_progress( int $seen, int $total ): float {
        if ( $total <= 0 ) { return 0.02; }
        return min( 0.98, 0.02 + ( 0.96 * min( 1, $seen / max( 1, $total ) ) ) );
    }

    private function time_budget(): float {
        $limit = (int) ini_get( 'max_execution_time' );
        if ( $limit <= 0 ) { return 18.0; }
        return max( 6.0, min( 16.0, (float) $limit - 4.0 ) );
    }

    private function files_per_request(): int {
        return (int) apply_filters( 'restorebase_backup_bundle_files_per_request', 20000 );
    }

    private function summary( int $included, int $bytes, int $skipped, int $unreadable, int $too_large, bool $truncated, array $groups, array $group_bytes ): array {
        return [
            'included_files'  => $included,
            'included_bytes'  => $bytes,
            'skipped_files'   => $skipped,
            'unreadable'      => $unreadable,
            'too_large'       => $too_large,
            'truncated'       => $truncated,
            'max_files'       => $this->max_files,
            'max_bytes'       => $this->max_bytes,
            'max_single_file' => $this->max_single_file,
            'groups'          => $groups,
            'group_bytes'     => $group_bytes,
            'format'          => 'restorebase_bundle',
        ];
    }

    private function group( string $path ): string {
        $path = trim( wp_normalize_path( $path ), '/' );
        if ( 0 === strpos( $path, 'wp-content/uploads/' ) ) { return 'uploads'; }
        if ( 0 === strpos( $path, 'wp-content/plugins/' ) ) { return 'plugins'; }
        if ( 0 === strpos( $path, 'wp-content/themes/' ) ) { return 'themes'; }
        if ( 0 === strpos( $path, 'wp-content/mu-plugins/' ) ) { return 'mu-plugins'; }
        if ( 0 === strpos( $path, 'wp-content/' ) ) { return 'wp-content'; }
        return 'other';
    }
}
