<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Utils\Logger;

// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_unlink
// phpcs:disable WordPress.PHP.NoSilencedErrors.Discouraged

defined( 'ABSPATH' ) || exit;

/**
 * Final post-restore cleanup that makes the restored admin feel ready immediately.
 */
final class PostRestoreHardener {
    public function apply( array $restore_context = [] ): array {
        $changes = [];
        $warnings = [];

        $permalink = $this->force_postname_permalinks();
        $changes['permalinks'] = $permalink;

        $maintenance = $this->remove_maintenance_marker();
        $changes['maintenance_marker'] = $maintenance;

        $cache = $this->clear_runtime_caches();
        $changes['runtime_cache'] = $cache;

        $bricks = $this->refresh_bricks_runtime();
        $changes['bricks'] = $bricks;

        $studio = $this->refresh_studio_runtime();
        $changes['studio_runtime'] = $studio;

        $rank_math = ( new RankMathConfigGuard() )->repair_after_restore( $restore_context );
        $changes['rank_math'] = $rank_math;
        if ( empty( $rank_math['ok'] ) ) {
            $warnings[] = (string) ( $rank_math['message'] ?? 'Rank Math post-restore repair needs attention.' );
        }

        Logger::info( 'post_restore_hardening_complete', 'RestoreBase applied post-restore hardening.', [
            'permalink_changed' => ! empty( $permalink['changed'] ),
            'bricks_refresh'    => $bricks,
            'rank_math'         => [
                'ok'      => ! empty( $rank_math['ok'] ),
                'changed' => ! empty( $rank_math['changed'] ),
                'reset'   => ! empty( $rank_math['registration_reset'] ),
            ],
        ] );

        return [
            'ok'              => true,
            'message'         => empty( $warnings ) ? 'Post-restore cleanup completed. Refresh the admin once to load the restored plugins and data.' : 'Post-restore cleanup completed with notes.',
            'changes'         => $changes,
            'warnings'        => $warnings,
            'refresh_required'=> true,
        ];
    }

    private function force_postname_permalinks(): array {
        global $wp_rewrite;

        $target  = '/%postname%/';
        $before  = (string) get_option( 'permalink_structure', '' );
        $changed = $before !== $target;

        if ( $changed ) {
            // $wp_rewrite was built at page load, before the database swap, so it still
            // holds the previous structure. set_permalink_structure() updates the option
            // AND re-inits the object; flushing without it regenerates rules for the old
            // permalink form.
            if ( isset( $wp_rewrite ) && is_object( $wp_rewrite ) && method_exists( $wp_rewrite, 'set_permalink_structure' ) ) {
                $wp_rewrite->set_permalink_structure( $target );
            } else {
                update_option( 'permalink_structure', $target );
            }
            // The options cache can still hold the pre-swap value.
            wp_cache_delete( 'permalink_structure', 'options' );
            wp_cache_delete( 'alloptions', 'options' );
        }

        delete_option( 'rewrite_rules' );
        if ( function_exists( 'flush_rewrite_rules' ) ) {
            flush_rewrite_rules( true );
        }

        $after = (string) get_option( 'permalink_structure', '' );

        // Last resort: write straight to the options table if the write did not stick
        // (a stale cache or a filter can silently swallow update_option here).
        if ( $target !== $after ) {
            global $wpdb;
            $wpdb->update( $wpdb->options, [ 'option_value' => $target ], [ 'option_name' => 'permalink_structure' ] );
            wp_cache_delete( 'permalink_structure', 'options' );
            wp_cache_delete( 'alloptions', 'options' );
            $after = (string) get_option( 'permalink_structure', '' );
        }

        return [
            'ok'      => $target === $after,
            'before'  => $before,
            'after'   => $after,
            'changed' => $changed,
            'flushed' => true,
        ];
    }

    private function remove_maintenance_marker(): array {
        $path = trailingslashit( ABSPATH ) . '.maintenance';
        $existed = is_file( $path );
        $removed = false;
        if ( $existed && is_writable( $path ) ) {
            $removed = @unlink( $path );
        }

        return [
            'ok'      => ! $existed || $removed || ! file_exists( $path ),
            'path'    => $path,
            'existed' => $existed,
            'removed' => $removed,
        ];
    }

    private function clear_runtime_caches(): array {
        if ( function_exists( 'wp_cache_flush' ) ) {
            wp_cache_flush();
        }
        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
            wp_clean_plugins_cache( true );
        }
        if ( function_exists( 'wp_clean_themes_cache' ) ) {
            wp_clean_themes_cache( true );
        }
        if ( function_exists( 'opcache_reset' ) ) {
            @opcache_reset();
        }

        // Common update and plugin metadata transients can be stale after a table swap.
        foreach ( [ 'update_plugins', 'update_themes', 'update_core' ] as $transient ) {
            delete_site_transient( $transient );
        }

        return [
            'ok'                    => true,
            'object_cache_flushed'  => function_exists( 'wp_cache_flush' ),
            'plugins_cache_cleaned' => function_exists( 'wp_clean_plugins_cache' ),
            'themes_cache_cleaned'  => function_exists( 'wp_clean_themes_cache' ),
            'opcache_reset'         => function_exists( 'opcache_reset' ),
        ];
    }

    private function refresh_bricks_runtime(): array {
        $scheduled = false;
        $deleted_options = [];
        $deleted_transients = $this->delete_option_name_like( [
            '_transient_bricks_%',
            '_transient_timeout_bricks_%',
            '_site_transient_bricks_%',
            '_site_transient_timeout_bricks_%',
        ] );
        $deleted_css_files = $this->delete_bricks_generated_css();
        update_option( 'restorebase_deferred_builder_recovery', time(), false );

        foreach ( [
            'bricks_css_files_last_generated',
            'bricks_css_files_last_generated_timestamp',
            'bricks_css_files_admin_notice',
            'bricks_breakpoints_last_generated',
            'bricks_code_signatures_last_generated',
            'bricks_code_signatures_last_generated_timestamp',
            'bricks_code_signatures_admin_notice',
        ] as $option ) {
            if ( false !== get_option( $option, false ) ) {
                delete_option( $option );
                $deleted_options[] = $option;
            }
        }

        if ( class_exists( '\Bricks\Assets_Files' ) && method_exists( '\Bricks\Assets_Files', 'schedule_css_file_regeneration' ) ) {
            \Bricks\Assets_Files::schedule_css_file_regeneration();
            $scheduled = true;
        } elseif ( function_exists( 'wp_schedule_single_event' ) && ! wp_next_scheduled( 'bricks_regenerate_css_files' ) ) {
            wp_schedule_single_event( time() + 5, 'bricks_regenerate_css_files' );
            $scheduled = true;
        }

        return [
            'ok'                 => true,
            'scheduled_regen'    => $scheduled,
            'deleted_options'    => $deleted_options,
            'deleted_transients' => $deleted_transients,
            'deleted_css_files'  => $deleted_css_files,
            'message'            => $scheduled ? 'Bricks builder runtime/cache refresh was scheduled.' : 'Bricks runtime cache options were checked.',
        ];
    }

    private function delete_option_name_like( array $patterns ): int {
        global $wpdb;
        $deleted = 0;
        foreach ( $patterns as $pattern ) {
            $deleted += (int) $wpdb->query(
                $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $pattern )
            );
        }
        return $deleted;
    }

    private function delete_bricks_generated_css(): int {
        $uploads = wp_upload_dir( null, false );
        $base = isset( $uploads['basedir'] ) ? trailingslashit( wp_normalize_path( (string) $uploads['basedir'] ) ) : '';
        if ( '' === $base ) {
            return 0;
        }
        $css_dir = $base . 'bricks/css/';
        if ( ! is_dir( $css_dir ) || ! is_readable( $css_dir ) ) {
            return 0;
        }
        $deleted = 0;
        foreach ( glob( $css_dir . '*.css' ) ?: [] as $file ) {
            if ( is_file( $file ) && is_writable( $file ) && @unlink( $file ) ) {
                $deleted++;
            }
        }
        return $deleted;
    }

    private function refresh_studio_runtime(): array {
        // Studio-style plugins often keep their list screens alive with pre-restore REST nonces.
        // A full admin refresh after restore is the reliable fix; this flag lets the panel say so.
        delete_transient( 'restorebase_last_studio_refresh_hint' );
        set_transient( 'restorebase_last_studio_refresh_hint', current_time( 'mysql' ), HOUR_IN_SECONDS );

        return [
            'ok'               => true,
            'refresh_required' => true,
            'message'          => 'Admin refresh requested so restored media/plugin studios can reload fresh REST nonces and data.',
        ];
    }
    public static function maybe_run_deferred_builder_recovery(): void {
        $marked = (int) get_option( 'restorebase_deferred_builder_recovery', 0 );
        if ( $marked <= 0 ) {
            return;
        }
        if ( time() - $marked > HOUR_IN_SECONDS ) {
            delete_option( 'restorebase_deferred_builder_recovery' );
            return;
        }

        try {
            if ( class_exists( '\Bricks\Assets_Files' ) && method_exists( '\Bricks\Assets_Files', 'regenerate_css_files' ) ) {
                \Bricks\Assets_Files::regenerate_css_files();
            }
            if ( class_exists( '\Bricks\Admin' ) && method_exists( '\Bricks\Admin', 'crawl_and_update_code_signatures' ) ) {
                \Bricks\Admin::crawl_and_update_code_signatures( true );
                if ( defined( 'BRICKS_VERSION' ) ) {
                    update_option( 'bricks_code_signatures_last_generated', BRICKS_VERSION );
                    update_option( 'bricks_code_signatures_last_generated_timestamp', time() );
                }
            }
        } catch ( \Throwable $throwable ) {
            Logger::warning( 'deferred_builder_recovery_failed', 'Deferred Bricks recovery could not finish.', [
                'message' => $throwable->getMessage(),
                'file'    => $throwable->getFile(),
                'line'    => $throwable->getLine(),
            ] );
        }

        delete_option( 'restorebase_deferred_builder_recovery' );
    }

}
