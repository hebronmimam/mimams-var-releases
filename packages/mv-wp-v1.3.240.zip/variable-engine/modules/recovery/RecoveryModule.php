<?php
/**
 * Recovery module registrar (RestoreBase engine, re-shelled for Mimam's Var).
 *
 * Merge target: variable-engine/modules/recovery/RecoveryModule.php
 * Namespace:    VE\Modules\Recovery
 *
 * Wire-in (in variable-engine.php, near the other module require):
 *   require_once VE_DIR . 'modules/recovery/RecoveryModule.php';
 *   add_action( 'plugins_loaded', function () { \VE\Modules\Recovery\RecoveryModule::init( VE_FILE ); }, 20 );
 *
 * Pass VE_FILE — it becomes VE_RECOVERY_FILE, which SelfProtection uses to keep the
 * host plugin active across a restore's database swap.
 *
 * Until that line is added the module is inert. It self-gates on capability and
 * the ve_settings deactivated-tools list, mirroring MimamsBarModule.
 */

namespace VE\Modules\Recovery;

defined( 'ABSPATH' ) || exit;

final class RecoveryModule {
    public const VERSION = '1.0.0-rc70';

    /** Ordered load list — dependencies first (mirrors the original bootstrap). */
    private const FILES = [
        'app/Utils/Logger.php',
        'app/Utils/FileStreamer.php',
        'app/Security/Capability.php',
        'app/Security/SecurityAudit.php',
        'app/Security/ProductionReadiness.php',
        'app/Database/Schema.php',
        'app/Database/Migrations.php',
        'app/Storage/LocalStorage.php',
        'app/Jobs/TaskResponse.php',
        'app/Jobs/JobStore.php',
        'app/Jobs/JobRunner.php',
        'app/Backup/SiteScanner.php',
        'app/Backup/FileInventory.php',
        'app/Backup/FileArchiver.php',
        'app/Backup/FileBundleArchiver.php',
        'app/Backup/DatabaseExporter.php',
        'app/Backup/ManifestBuilder.php',
        'app/Backup/PackageSigner.php',
        'app/Backup/PackageCipher.php',
        'app/Backup/PackageChecksums.php',
        'app/Backup/PackageValidator.php',
        'app/Backup/SnapshotManager.php',
        'app/Backup/SnapshotJob.php',
        'app/Backup/PackageBuilder.php',
        'app/Restore/PackageLocator.php',
        'app/Restore/RestoreWorkspace.php',
        'app/Restore/SQLImportPlanner.php',
        'app/Restore/SerializedRewritePlanner.php',
        'app/Restore/SelfProtection.php',
        'app/Restore/DestinationAccessGuard.php',
        'app/Restore/PluginStateRestorer.php',
        'app/Restore/FileRestoreStager.php',
        'app/Restore/PackageContentGuard.php',
        'app/Restore/PostRestoreVerifier.php',
        'app/Restore/PostRestoreHardener.php',
        'app/Restore/SQLTemporaryImporter.php',
        'app/Restore/RestoreReadiness.php',
        'app/Restore/ConfigGuard.php',
        'app/Restore/RankMathConfigGuard.php',
        'app/Restore/URLRewritePlanner.php',
        'app/Restore/RestorePreview.php',
        'app/Restore/RestoreDryRun.php',
        'app/Restore/RestorePreparation.php',
        'app/Restore/StagingRestoreExecutor.php',
        'app/Restore/ProductionRestoreExecutor.php',
        'app/Restore/RestoreVerifier.php',
        'app/Restore/RollbackManager.php',
        'app/Restore/RollbackExecutor.php',
        'app/Workflow/StagingWorkflow.php',
        'app/Workflow/MigrationPlanner.php',
        'app/Workflow/StagingCloneBuilder.php',
        'app/Workflow/MigrationWorkflow.php',
        'app/Workflow/MigrationImporter.php',
        'app/Storage/RemoteStorageManager.php',
        'app/Schedule/ScheduleManager.php',
        'app/WooCommerce/WooSafety.php',
        'app/Emergency/EmergencyRecovery.php',
        'app/Agency/AgencyDashboard.php',
        'app/API/Routes.php',
        'app/Admin/AdminPage.php',
        'app/Plugin.php',
    ];

    private static bool $booted = false;

    /**
     * @param string $plugin_file The HOST plugin's entry file (the one with the plugin
     *                            header). Standalone: recovery-studio-test.php.
     *                            Merged into MV: VE_FILE (variable-engine.php).
     */
    public static function init( string $plugin_file = '' ): void {
        if ( self::$booted ) {
            return;
        }

        if ( self::is_deactivated() ) {
            return;
        }

        self::define_constants( $plugin_file );
        self::load();

        \VE\Modules\Recovery\Utils\Logger::register_fatal_handler();
        \VE\Modules\Recovery\Plugin::instance()->boot();

        self::$booted = true;
    }

    /** Honour the MV per-tool deactivation switch (same shape as MimamsBar). */
    private static function is_deactivated(): bool {
        $settings = get_option( 've_settings', [] );
        $legacy = isset( $settings['deactivated_tools'] ) && is_array( $settings['deactivated_tools'] )
            ? $settings['deactivated_tools']
            : [];
        $surfaces = isset( $settings['deactivated_tool_surfaces'] ) && is_array( $settings['deactivated_tool_surfaces'] )
            ? $settings['deactivated_tool_surfaces']
            : [];
        $admin = isset( $surfaces['admin'] ) && is_array( $surfaces['admin'] ) ? $surfaces['admin'] : [];
        $builder = isset( $surfaces['builder'] ) && is_array( $surfaces['builder'] ) ? $surfaces['builder'] : [];

        // Settings now writes the per-surface map; only fall back to the legacy list
        // when no per-surface choice has been made (same rule as MimamsBarModule).
        $has_surface_choice = in_array( 'recovery', $admin, true ) || in_array( 'recovery', $builder, true );
        if ( $has_surface_choice ) {
            // Recovery is an admin-side tool.
            if ( in_array( 'recovery', $admin, true ) ) {
                return true;
            }
        } elseif ( in_array( 'recovery', $legacy, true ) ) {
            return true;
        }

        return apply_filters( 've_recovery_enabled', true ) === false;
    }

    private static function define_constants( string $plugin_file = '' ): void {
        if ( defined( 'VE_RECOVERY_VERSION' ) ) {
            return;
        }
        define( 'VE_RECOVERY_VERSION', self::VERSION );

        // VE_RECOVERY_FILE must be the HOST PLUGIN's entry file, not this registrar.
        // SelfProtection derives plugin_basename() from it to keep the plugin active
        // across the database swap. Pointing it at RecoveryModule.php makes WordPress
        // try to activate a file with no plugin header, which it then deactivates:
        // "The plugin does not have a valid header." Merged into MV it would also mean
        // variable-engine.php itself was never protected during a restore.
        $host = '' !== $plugin_file ? $plugin_file : ( defined( 'VE_FILE' ) ? VE_FILE : __FILE__ );
        define( 'VE_RECOVERY_FILE', $host );

        // Module paths stay relative to THIS file so app/ and assets/ resolve correctly.
        define( 'VE_RECOVERY_DIR', plugin_dir_path( __FILE__ ) );
        define( 'VE_RECOVERY_URL', plugin_dir_url( __FILE__ ) );
        define( 'VE_RECOVERY_API_NAMESPACE', 'restorebase/v1' );
        define( 'VE_RECOVERY_MIN_PHP', '7.4' );
        define( 'VE_RECOVERY_MIN_WP', '6.0' );
    }

    private static function load(): void {
        foreach ( self::FILES as $file ) {
            $path = VE_RECOVERY_DIR . $file;
            if ( is_readable( $path ) ) {
                require_once $path;
            }
        }
    }
}
