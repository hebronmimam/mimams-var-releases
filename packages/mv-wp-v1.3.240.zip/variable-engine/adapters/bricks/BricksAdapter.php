<?php
namespace VE\Adapters;
defined('ABSPATH') || exit;

class BricksAdapter {
    public function __construct() { add_action('wp', [$this, 'init']); }
    public function init(): void {
        if (!isset($_GET['bricks']) || $_GET['bricks'] !== 'run') return;
        ( new \VE\Adapters\Bricks\VariablesMirror() )->sync();
        add_action('wp_enqueue_scripts', [$this, 'enqueue'], 9999);
    }
    public function enqueue(): void {
        wp_enqueue_style('ve-ph', 'https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2/src/duotone/style.css', [], '2');
        wp_enqueue_style('ve-components', VE_URL.'assets/components.css', [], VE_VERSION.'.'.filemtime(VE_DIR.'assets/components.css'));
        wp_enqueue_style('ve-codemirror', 'https://cdn.jsdelivr.net/npm/codemirror@5.65.16/lib/codemirror.css', [], '5.65.16');
        wp_enqueue_style('ve-codemirror-hint', 'https://cdn.jsdelivr.net/npm/codemirror@5.65.16/addon/hint/show-hint.css', ['ve-codemirror'], '5.65.16');
        // Neutralize CodeMirror 5's unscoped light defaults so MV's globally loaded editor CSS
        // does not bleed a white background into other plugins' editors (e.g. Code2Bricks Quick
        // Import). MV's own editors override this via the more specific `.ve-cm-host` rules.
        wp_add_inline_style('ve-codemirror', '.CodeMirror{background:transparent;color:inherit}.CodeMirror-gutters{background:transparent}');
        wp_enqueue_script('ve-p', 'https://cdn.jsdelivr.net/npm/preact@10/dist/preact.umd.js', [], '10', true);
        wp_enqueue_script('ve-ph', 'https://cdn.jsdelivr.net/npm/preact@10/hooks/dist/hooks.umd.js', ['ve-p'], '10', true);
        wp_enqueue_script('ve-gsap', 'https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js', [], '3.12.5', true);
        wp_enqueue_script('ve-codemirror', 'https://cdn.jsdelivr.net/npm/codemirror@5.65.16/lib/codemirror.js', [], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-css', 'https://cdn.jsdelivr.net/npm/codemirror@5.65.16/mode/css/css.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-closebrackets', 'https://cdn.jsdelivr.net/npm/codemirror@5.65.16/addon/edit/closebrackets.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-hint', 'https://cdn.jsdelivr.net/npm/codemirror@5.65.16/addon/hint/show-hint.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-app', VE_URL.'assets/js/builder-panel.js', ['ve-p','ve-ph','ve-gsap','ve-codemirror-css','ve-codemirror-closebrackets','ve-codemirror-hint'], VE_VERSION.'.'.filemtime(VE_DIR.'assets/js/builder-panel.js'), true);
        $preferences = get_user_meta( get_current_user_id(), 've_user_preferences', true );
        wp_localize_script('ve-app', 'vePanel', ['apiRoot'=>esc_url_raw(rest_url()),'nonce'=>wp_create_nonce('wp_rest'),'version'=>VE_VERSION,'mode'=>'builder','siteTitle'=>sanitize_text_field(get_bloginfo('name')),'logoUrl'=>esc_url_raw(VE_URL.'assets/hebronmimam-logo-icon.png'),'assetUrl'=>esc_url_raw(VE_URL.'assets/'),'userPreferences'=>is_array($preferences)?$preferences:[]]);
        if (class_exists('\VE\Modules\BuilderTools\MimamsBarModule')) {
            (new \VE\Modules\BuilderTools\MimamsBarModule())->enqueue('builder');
        }
    }
}
