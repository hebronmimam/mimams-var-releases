<?php
/**
 * What a publish did, recorded so it can be undone.
 *
 * Slice 5 of the Workspaces module, and handoff §113 in full.
 *
 * §113's one instruction about this table is that its SHAPE has to be right on
 * the first release, because it cannot be reconstructed later:
 *
 *     object_uuid
 *     adapter
 *     base_hash        the Live hash this release replaced
 *     payload_hash     the hash this release wrote
 *     prior_payload    the full previous value, sufficient to restore alone
 *
 * `prior_payload` is the expensive one and it is the one that matters. A
 * release-level snapshot is not enough and a hash is not enough: rollback
 * targets OBJECTS, and an object is only independently restorable if its own
 * previous value was kept beside it. Slice 6 computes supersession per object
 * from `payload_hash`; it can only do that if slice 5 wrote it.
 *
 * The record is IMMUTABLE apart from settling: a release is created `applying`
 * and then settled once, to `published` or `failed`, with a reason. Nothing
 * rewrites an object row afterwards. A release that could be edited is not a
 * record of what happened, it is a record of what somebody last said happened.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceRelease {

    public const APPLYING  = 'applying';
    public const PUBLISHED = 'published';
    public const FAILED    = 'failed';

    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 've_workspace_releases';
    }

    /**
     * Open a release. Called before the first object is written, so a publish
     * interrupted halfway leaves a record saying it was interrupted rather than
     * leaving nothing at all.
     *
     * @return array|\WP_Error
     */
    public static function open( int $workspace_id, array $objects ) {
        global $wpdb;

        if ( $workspace_id <= 0 ) {
            return self::error( 've_workspace_missing', 'That workspace no longer exists.' );
        }

        $now = current_time( 'mysql', true );
        $ok  = $wpdb->insert(
            self::table(),
            [
                'uuid'         => WorkspaceStore::new_uuid(),
                'workspace_id' => $workspace_id,
                'status'       => self::APPLYING,
                'reason'       => '',
                'objects'      => wp_json_encode( array_values( $objects ) ),
                'created_by'   => get_current_user_id() ? get_current_user_id() : null,
                'created_at'   => $now,
                'settled_at'   => null,
            ],
            [ '%s', '%d', '%s', '%s', '%s', '%d', '%s', '%s' ]
        );
        if ( ! $ok ) {
            return self::error( 've_release_not_opened', 'The release could not be started.' );
        }
        return self::get( (int) $wpdb->insert_id );
    }

    /**
     * Settle it, once. §68.12: a publish is not successful until it has been
     * verified, so `published` is written here and nowhere else, and only by a
     * caller that has already verified every object.
     *
     * @return array|\WP_Error
     */
    public static function settle( int $id, string $status, string $reason = '', array $objects = null ) {
        global $wpdb;

        $release = self::get( $id );
        if ( ! $release ) {
            return self::error( 've_release_missing', 'That release no longer exists.' );
        }
        if ( self::APPLYING !== $release['status'] ) {
            // Immutable once settled. Saying so is better than quietly winning.
            return self::error(
                've_release_settled',
                'That release was already recorded as ' . $release['status'] . '.'
            );
        }
        if ( ! in_array( $status, [ self::PUBLISHED, self::FAILED ], true ) ) {
            return self::error( 've_release_status', 'A release settles as published or failed.' );
        }

        $fields  = [
            'status'     => $status,
            'reason'     => $reason,
            'settled_at' => current_time( 'mysql', true ),
        ];
        $formats = [ '%s', '%s', '%s' ];
        if ( null !== $objects ) {
            $fields['objects'] = wp_json_encode( array_values( $objects ) );
            $formats[]         = '%s';
        }

        $wpdb->update( self::table(), $fields, [ 'id' => $id ], $formats, [ '%d' ] );
        return self::get( $id );
    }

    /** @return array|null */
    public static function get( int $id ) {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ),
            ARRAY_A
        );
        return $row ? self::shape( $row ) : null;
    }

    /** Newest first: a history is read backwards. */
    public static function all( int $workspace_id ): array {
        global $wpdb;
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT * FROM ' . self::table() . ' WHERE workspace_id = %d ORDER BY id DESC',
                $workspace_id
            ),
            ARRAY_A
        );
        return array_map( [ __CLASS__, 'shape' ], is_array( $rows ) ? $rows : [] );
    }

    /**
     * One object's record inside a release, in §113's shape exactly.
     *
     * `prior_payload` is the whole previous value. It is deliberately not a
     * diff and deliberately not a hash: slice 6 has to be able to restore this
     * object on its own, without replaying anything else.
     */
    public static function entry( array $object, $prior_payload, string $base_hash, string $payload_hash ): array {
        return [
            'object_uuid'   => isset( $object['uuid'] ) ? (string) $object['uuid'] : '',
            'adapter'       => isset( $object['adapter'] ) ? (string) $object['adapter'] : 'bricks_page',
            'object_type'   => isset( $object['object_type'] ) ? (string) $object['object_type'] : '',
            'label'         => isset( $object['label'] ) ? (string) $object['label'] : '',
            'live_id'       => isset( $object['live_id'] ) ? (int) $object['live_id'] : 0,
            'base_hash'     => $base_hash,
            'payload_hash'  => $payload_hash,
            'prior_payload' => $prior_payload,
        ];
    }

    // ── internals ──────────────────────────────────────────────────────────

    private static function shape( array $row ): array {
        $objects = json_decode( (string) $row['objects'], true );
        return [
            'id'         => (int) $row['id'],
            'uuid'       => (string) $row['uuid'],
            'workspace'  => (int) $row['workspace_id'],
            'status'     => (string) $row['status'],
            'reason'     => (string) $row['reason'],
            'objects'    => is_array( $objects ) ? $objects : [],
            'created_by' => empty( $row['created_by'] ) ? null : (int) $row['created_by'],
            'created_at' => (string) $row['created_at'],
            'settled_at' => empty( $row['settled_at'] ) ? null : (string) $row['settled_at'],
        ];
    }

    /** @return \WP_Error|array */
    private static function error( string $code, string $message ) {
        if ( class_exists( '\WP_Error' ) ) {
            return new \WP_Error( $code, $message, [ 'status' => 400 ] );
        }
        return [ 'error' => $code, 'message' => $message ];
    }
}
