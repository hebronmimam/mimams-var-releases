(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;

  var CORE_ELEMENT_NAMES = {
    section: true,
    container: true,
    block: true,
    div: true,
    heading: true,
    text: true,
    'basic-text': true,
    'rich-text': true,
    button: true,
    icon: true,
    image: true,
    video: true,
    svg: true,
    shortcode: true,
    code: true,
    template: true,
    form: true,
    map: true,
    list: true,
    accordion: true,
    slider: true,
    carousel: true,
    tabs: true,
    alert: true,
    divider: true,
    dropdown: true,
    offcanvas: true,
    toggle: true,
    nav: true,
    'nav-nestable': true
  };



  function getEmmet() {
    return window.MimamsBarEmmet || null;
  }

  var libraryConfigCache = null;
  var libraryConfigCacheAt = 0;
  function getLibraryConfigCache(BricksAdapter) {
    var now = Date.now ? Date.now() : new Date().getTime();
    if (libraryConfigCache && now - libraryConfigCacheAt < 2000) return libraryConfigCache;
    var elements = BricksAdapter.getBricksElementConfigs();
    var components = typeof BricksAdapter.getBricksComponents === 'function'
      ? BricksAdapter.getBricksComponents()
      : [];
    libraryConfigCache = elements.concat(components);
    libraryConfigCacheAt = now;
    return libraryConfigCache;
  }

  function clearLibraryConfigCache() {
    libraryConfigCache = null;
    libraryConfigCacheAt = 0;
  }

  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function iconSvg(kind) {
    kind = String(kind || '').toLowerCase();
    var name = 'cube';
    if (kind.indexOf('image') !== -1 || kind === 'img' || kind === 'svg') name = 'image';
    else if (kind.indexOf('button') !== -1) name = 'cursor-click';
    else if (kind.indexOf('heading') !== -1 || kind === 'h1' || kind === 'h2' || kind === 'h3') name = 'text-h';
    else if (kind.indexOf('container') !== -1 || kind.indexOf('section') !== -1 || kind.indexOf('block') !== -1) name = 'square';
    else if (kind.indexOf('text') !== -1 || kind.indexOf('rich') !== -1) name = 'paragraph';
    else if (kind.indexOf('nav') !== -1 || kind.indexOf('list') !== -1) name = 'list';
    return '<i class="ph-duotone ph-' + name + '"></i>';
  }

  function compactMeta(parts) {
    return parts.filter(function (part) { return !!String(part || '').trim(); }).join(' · ');
  }

  function rowContent(iconKind, title, meta) {
    return '' +
      '<span class="baqa-element-main">' +
        '<span class="baqa-element-icon" aria-hidden="true">' + iconSvg(iconKind) + '</span>' +
        '<span class="baqa-element-title">' + escapeHtml(title || 'Element') + '</span>' +
      '</span>' +
      '<em class="baqa-element-meta">' + escapeHtml(meta || '') + '</em>';
  }

  function wordStartsWith(value, query) {
    value = String(value || '').toLowerCase();
    query = String(query || '').toLowerCase();
    return value.split(/[^a-z0-9_-]+/).some(function (part) {
      return part.indexOf(query) === 0;
    });
  }

  function isCoreElementName(name) {
    name = String(name || '').trim().toLowerCase();
    return !!CORE_ELEMENT_NAMES[name];
  }

  function queryScore(haystack, query, primaryName, primaryLabel) {
    haystack = String(haystack || '').toLowerCase();
    query = String(query || '').trim().toLowerCase();
    primaryName = String(primaryName || '').toLowerCase();
    primaryLabel = String(primaryLabel || '').toLowerCase();

    if (!query) return 1;

    var score = 0;
    if (primaryName === query) score += 120;
    if (primaryLabel === query) score += 110;
    if (primaryName.indexOf(query) === 0) score += 80;
    if (primaryLabel.indexOf(query) === 0) score += 70;
    if (wordStartsWith(primaryName, query)) score += 45;
    if (wordStartsWith(primaryLabel, query)) score += 40;
    if (haystack.indexOf(query) !== -1) score += 10;

    var parts = query.split(/\s+/).filter(Boolean);
    if (parts.length && parts.every(function (part) { return haystack.indexOf(part) !== -1; })) score += 6;

    return score;
  }

  var ElementSearch = {
    escapeHtml: escapeHtml,
    isCoreElementName: isCoreElementName,
    clearLibraryConfigCache: clearLibraryConfigCache,

    getPageMatches: function (BricksAdapter, query, limit, cachedElements) {
      limit = limit || 8;
      query = String(query || '').trim();
      if (!query) return [];
      var elements = Array.isArray(cachedElements) ? cachedElements : BricksAdapter.getAllElements();
      var scored = [];

      elements.forEach(function (element) {
        var label = BricksAdapter.getElementFullLabel(element);
        var basicLabel = BricksAdapter.getElementLabel(element);
        var customLabel = BricksAdapter.getElementCustomLabel ? BricksAdapter.getElementCustomLabel(element) : '';
        var tag = BricksAdapter.getElementTagName(element);
        var haystack = [
          label,
          basicLabel,
          customLabel,
          tag,
          element.name,
          element.label,
          element.title,
          BricksAdapter.getElementCssId(element),
          BricksAdapter.getElementClasses(element).join(' '),
          element.id
        ].join(' ');

        var score = queryScore(haystack, query, customLabel || tag || basicLabel, customLabel || basicLabel);
        if (score) scored.push({ element: element, label: label, score: score });
      });

      scored.sort(function (a, b) { return b.score - a.score; });
      return scored.slice(0, limit);
    },

    getLibraryMatches: function (BricksAdapter, query, limit) {
      limit = limit || 10;
      query = String(query || '').trim();
      if (!query) return [];
      var emmet = getEmmet();
      var emmetPlan = emmet && emmet.parse ? emmet.parse(query) : null;
      var searchQuery = emmet && emmet.alias && !emmetPlan ? emmet.alias(query) : query;
      var configs = getLibraryConfigCache(BricksAdapter);
      var scored = [];

      if (emmetPlan) {
        scored.push({
          config: {
            name: '__emmet__',
            label: emmetPlan.ok ? 'Emmet: ' + emmet.label(emmetPlan) : 'Emmet pattern too deep',
            category: 'emmet',
            emmet: emmetPlan
          },
          score: 999
        });
      }

      configs.forEach(function (item) {
        var searchableName = item.kind === 'component' ? item.label : item.name;
        var haystack = [searchableName, item.name, item.label, item.category, item.kind].join(' ');
        var score = queryScore(haystack, searchQuery, searchableName, item.label);

        // Prefer official/common Bricks elements for short searches like "im" so
        // Image appears before third-party Dynamic Image results.
        if (item.kind === 'component') score += 14;
        else if (isCoreElementName(item.name)) score += 20;
        else if (String(item.name || '').indexOf('-') !== -1) score -= 8;

        if (score > 0) scored.push({ config: item, score: score });
      });

      scored.sort(function (a, b) {
        if (b.score !== a.score) return b.score - a.score;
        return String(a.config.label).localeCompare(String(b.config.label));
      });
      return scored.slice(0, limit);
    },

    renderResults: function (container, mode, matches, callbacks) {
      if (!container) return;
      callbacks = callbacks || {};
      container.innerHTML = '';

      if (!matches || !matches.length) {
        var empty = document.createElement('div');
        empty.className = 'baqa-element-empty';
        empty.textContent = mode === 'add-elements' ? 'No matching Bricks elements found.' : 'No matching page elements found.';
        container.appendChild(empty);
        return;
      }

      var activeIndex = typeof callbacks.activeIndex === 'number' ? callbacks.activeIndex : 0;
      if (activeIndex < 0) activeIndex = 0;
      if (activeIndex >= matches.length) activeIndex = matches.length - 1;

      matches.forEach(function (item, index) {
        var row = document.createElement('button');
        row.type = 'button';
        row.className = 'baqa-element-row' + (index === activeIndex ? ' is-active' : '');
        row.setAttribute('data-baqa-result-index', String(index));

        if (mode === 'add-elements') {
          var config = item.config || {};
          var isComponent = config.kind === 'component';
          var source = isComponent ? 'component' : (isCoreElementName(config.name) ? 'core' : 'custom');
          row.innerHTML = rowContent(isComponent ? 'component' : (config.name || config.category), config.label || config.name || '', compactMeta([isComponent ? config.category : config.name, source]));
          row.addEventListener('mouseenter', function () {
            if (typeof callbacks.activate === 'function') callbacks.activate(index);
          });
          row.addEventListener('click', function () {
            if (typeof callbacks.activate === 'function') callbacks.activate(index);
            if (typeof callbacks.add === 'function') callbacks.add(config);
          });
        } else {
          var element = item.element || {};
          var label = callbacks.label ? callbacks.label(element) : (element.name || element.id || 'Element');
          var meta = compactMeta([element.name || element.tag || element.type || '', element.id ? '#' + element.id : '']);
          row.innerHTML = rowContent(element.name || element.tag || element.type, label, meta);
          row.addEventListener('mouseenter', function () {
            if (typeof callbacks.activate === 'function') callbacks.activate(index);
          });
          row.addEventListener('click', function () {
            if (typeof callbacks.activate === 'function') callbacks.activate(index);
            if (typeof callbacks.select === 'function') callbacks.select(element);
          });
        }

        container.appendChild(row);
      });

      var active = container.querySelector('.baqa-element-row.is-active');
      if (active && typeof active.scrollIntoView === 'function') {
        try { active.scrollIntoView({ block: 'nearest' }); } catch (e) {}
      }
    }
  };

  window.MimamsBarElementSearch = ElementSearch;
})();
