<?php
/**
 * Where a class's CSS actually lives.
 *
 * A class rule on a Bricks site can be in three different places at once, and
 * the site owner usually cannot tell which one they are looking at: on the
 * Bricks global class, inside one element's custom CSS, or in a stylesheet Code
 * Studio owns. The Classes lane's first job is to say which - before it offers
 * to move anything - so this class reads all three and reports one answer per
 * class, with the rule it found and how many elements wear it.
 *
 * Reading is broad; writing is deliberately narrow. Only the Bricks global
 * class is written back to, because that record is a self-contained option row
 * with a shape MV already edits in the builder (`settings._cssCustom`, plus one
 * key per breakpoint). An element's custom CSS lives inside the page's
 * serialised element tree, where a blind REST write could damage a page, so it
 * is shown and never written.
 *
 * @package VariableEngine
 */

namespace VE\Core;

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class ClassLensManager {

    /** Where Bricks keeps its global classes. */
    private const CLASS_OPTIONS = [ 'bricks_global_classes' ];

    /** How many element trees to read when counting where a class is used. */
    private const SCAN_LIMIT = 800;

    /** Read once per instance - never shared between them, so a write is seen. */
    private $trees = null;

    /**
     * Every class this site knows about, with where its rule lives.
     *
     * @return array<int,array<string,mixed>>
     */
    public function classes(): array {
        $found = [];

        // 1 - Bricks global classes. A record with no custom CSS still counts:
        // the class exists, it is simply not styled here yet.
        foreach ( $this->global_classes() as $record ) {
            $name = $this->class_name( $record['name'] ?? '' );
            if ( '' === $name ) {
                continue;
            }
            $css = $this->custom_css_of( $record );
            // Automatic.css, Core Framework and Advanced Themer register their
            // utility classes as Bricks global classes, and style them from their
            // own stylesheet rather than from custom CSS. Reporting those as
            // "nothing styles it" is wrong twice over: something does, and MV
            // must never offer to adopt a rule it does not own.
            $origin = $this->is_framework_class( $record ) ? 'framework' : ( '' === trim( $css ) ? 'none' : 'bricks' );
            $found[ $name ] = [
                'selector' => '.' . $name,
                'origin'   => $origin,
                'css'      => $this->as_rule( $name, $css ),
                'sheet'    => '',
                'sheet_id' => '',
                'class_id' => (string) ( $record['id'] ?? '' ),
                'used'     => 0,
            ];
        }

        // 2 - one element's custom CSS. Narrower than a global class and easy to
        // lose track of, so it is worth naming even though it cannot be edited
        // from here.
        foreach ( $this->element_custom_css() as $name => $css ) {
            if ( isset( $found[ $name ] ) && 'none' !== $found[ $name ]['origin'] ) {
                continue;
            }
            $found[ $name ] = [
                'selector' => '.' . $name,
                'origin'   => 'element',
                'css'      => $css,
                'sheet'    => '',
                'sheet_id' => '',
                'class_id' => isset( $found[ $name ] ) ? $found[ $name ]['class_id'] : '',
                'used'     => isset( $found[ $name ] ) ? $found[ $name ]['used'] : 0,
            ];
        }

        // 3 - a stylesheet Code Studio owns. This wins over the other two: if
        // Code Studio already styles the class there is nothing to move, and the
        // lane has to say so rather than offering to adopt it again.
        foreach ( $this->studio_rules() as $name => $rule ) {
            $found[ $name ] = [
                'selector' => '.' . $name,
                'origin'   => 'studio',
                'css'      => $rule['css'],
                'sheet'    => $rule['name'],
                'sheet_id' => $rule['id'],
                'class_id' => isset( $found[ $name ] ) ? $found[ $name ]['class_id'] : '',
                'used'     => isset( $found[ $name ] ) ? $found[ $name ]['used'] : 0,
            ];
        }

        $counts = $this->usage_counts( array_keys( $found ) );
        foreach ( $found as $name => $entry ) {
            $found[ $name ]['used'] = (int) ( $counts[ $name ] ?? 0 );
        }

        ksort( $found );
        return array_values( $found );
    }

    /** One class, or null. */
    public function find( string $selector ): ?array {
        $name = $this->class_name( $selector );
        if ( '' === $name ) {
            return null;
        }
        foreach ( $this->classes() as $entry ) {
            if ( $entry['selector'] === '.' . $name ) {
                return $entry;
            }
        }
        return null;
    }

    /**
     * Write a rule back to the Bricks global class it came from.
     *
     * Only `_cssCustom` is touched, and only on the one record whose name
     * matches. Every other key on that record, and every other record, is left
     * exactly as it was - this is somebody's site, and a class rule is not a
     * reason to rewrite the option.
     */
    public function save_to_bricks( string $selector, string $css ): bool {
        $name = $this->class_name( $selector );
        if ( '' === $name ) {
            return false;
        }

        foreach ( self::CLASS_OPTIONS as $option ) {
            $records = get_option( $option, [] );
            if ( ! is_array( $records ) ) {
                continue;
            }
            $changed = false;
            foreach ( $records as $index => $record ) {
                if ( ! is_array( $record ) || $this->class_name( $record['name'] ?? '' ) !== $name ) {
                    continue;
                }
                if ( ! isset( $record['settings'] ) || ! is_array( $record['settings'] ) ) {
                    $records[ $index ]['settings'] = [];
                }
                $records[ $index ]['settings']['_cssCustom'] = $this->as_bricks( $name, $css );
                $changed = true;
            }
            if ( $changed ) {
                update_option( $option, $records );
                return true;
            }
        }
        return false;
    }

    /**
     * Move a class's rule out of Bricks and into a Code Studio stylesheet.
     *
     * One way, and it clears the Bricks copy, so the rule has exactly one owner
     * afterwards rather than two that can disagree. The CSS is written into the
     * item first and only then removed from Bricks: if the write fails, nothing
     * has been lost.
     */
    public function adopt( string $selector, string $item_id ): ?array {
        $name  = $this->class_name( $selector );
        $entry = '' === $name ? null : $this->find( '.' . $name );
        if ( ! $entry || 'bricks' !== $entry['origin'] ) {
            return null;
        }

        $items = new CodeItemManager();
        $item  = $items->find( $item_id );
        if ( ! $item || 'css' !== $item['language'] ) {
            return null;
        }

        $rule    = trim( (string) $entry['css'] ) ?: ( '.' . $name . " {\n  \n}" );
        $code    = rtrim( (string) $item['code'] );
        $updated = $items->update( $item_id, [ 'code' => ( '' === $code ? '' : $code . "\n\n" ) . $rule ] );
        if ( ! $updated ) {
            return null;
        }

        // Read it back before letting go of the original. The order is the whole
        // safety property here: clear Bricks first and a write that fails is
        // somebody's CSS gone, with nothing left to put back.
        $stored = $items->find( $item_id );
        if ( ! $stored || false === strpos( (string) $stored['code'], $rule ) ) {
            return null;
        }

        $this->save_to_bricks( '.' . $name, '' );
        return $updated;
    }

    /**
     * Begin a rule for a class that nothing styles yet.
     *
     * The empty rule is the point: it puts the class in a stylesheet Code Studio
     * owns, so the next line the author writes belongs to one place.
     */
    public function start( string $selector, string $item_id ): ?array {
        $name = $this->class_name( $selector );
        if ( '' === $name ) {
            return null;
        }
        $items = new CodeItemManager();
        $item  = $items->find( $item_id );
        if ( ! $item || 'css' !== $item['language'] ) {
            return null;
        }
        if ( false !== strpos( (string) $item['code'], '.' . $name . ' {' ) ) {
            return $item;
        }
        $code = rtrim( (string) $item['code'] );
        return $items->update( $item_id, [ 'code' => ( '' === $code ? '' : $code . "\n\n" ) . '.' . $name . " {\n  \n}" ] );
    }

    /* -- reading ---------------------------------------------------------- */

    private function global_classes(): array {
        foreach ( self::CLASS_OPTIONS as $option ) {
            $records = get_option( $option, [] );
            if ( is_string( $records ) ) {
                $decoded = json_decode( $records, true );
                $records = is_array( $decoded ) ? $decoded : [];
            }
            if ( is_array( $records ) && $records ) {
                return array_values( array_filter( $records, 'is_array' ) );
            }
        }
        return [];
    }

    /**
     * Does this record belong to a framework rather than to the site author?
     *
     * The flag is the framework's own: Automatic.css and the others mark the
     * classes they register, and MV already reads that mark elsewhere. A name
     * that looks like a utility is not enough on its own - plenty of hand-written
     * classes look like that - so only the mark counts.
     */
    private function is_framework_class( array $record ): bool {
        if ( ! empty( $record['at_framework'] ) || ! empty( $record['framework'] ) ) {
            return true;
        }
        $settings = $record['settings'] ?? null;
        return is_array( $settings ) && ! empty( $settings['at_framework'] );
    }

    /**
     * Bricks writes custom CSS to `_cssCustom`, and one key per breakpoint
     * beside it. All of them belong to the class, so all of them are read.
     */
    private function custom_css_of( array $record ): string {
        $settings = $record['settings'] ?? [];
        if ( ! is_array( $settings ) ) {
            return '';
        }
        $parts = [];
        foreach ( $settings as $key => $value ) {
            if ( ! is_string( $value ) || '' === trim( $value ) ) {
                continue;
            }
            if ( '_cssCustom' === $key || 0 === strpos( (string) $key, '_cssCustom:' ) ) {
                $parts[] = trim( $value );
            }
        }
        return implode( "\n\n", $parts );
    }

    /**
     * The rule exactly as Bricks now holds it, for the open builder to adopt.
     *
     * The database write is only half the job while the builder is running: it
     * loaded the classes at boot and saves the whole option back from memory.
     * The panel hands this string to the store so the builder's own save
     * carries the edit instead of overwriting it.
     */
    public function bricks_rule( string $selector ): string {
        $name = $this->class_name( $selector );
        if ( '' === $name ) {
            return '';
        }
        foreach ( self::CLASS_OPTIONS as $option ) {
            $records = get_option( $option, [] );
            if ( ! is_array( $records ) ) {
                continue;
            }
            foreach ( $records as $record ) {
                if ( ! is_array( $record ) || $this->class_name( $record['name'] ?? '' ) !== $name ) {
                    continue;
                }
                return (string) ( $record['settings']['_cssCustom'] ?? '' );
            }
        }
        return '';
    }

    /**
     * The rule as Bricks stores it, rather than as it was shown for reading.
     *
     * The inverse of `as_rule`. Reading translated `%root%` into the class
     * selector so the owner saw a whole rule; writing has to translate it back,
     * because `%root%` is the dialect Bricks' own Custom CSS box speaks and the
     * builder writes. Saving the expanded selector left MV and Bricks holding
     * the same rule in two spellings - which is what "the change did not show
     * in Bricks' Custom CSS" looked like from the outside.
     *
     * Only selector text is touched. A class name inside a string or a comment
     * (`content: ".card"`) is somebody's content, not a selector, so the scan
     * skips quoted runs and comments rather than replacing blind.
     */
    private function as_bricks( string $name, string $css ): string {
        $css = trim( $css );
        if ( '' === $name || '' === $css ) {
            return $css;
        }
        $needle = '.' . $name;
        $len    = strlen( $needle );
        $out    = '';
        $i      = 0;
        $end    = strlen( $css );
        while ( $i < $end ) {
            $ch = $css[ $i ];
            // A comment runs to its terminator and is copied across untouched.
            if ( '/' === $ch && $i + 1 < $end && '*' === $css[ $i + 1 ] ) {
                $stop = strpos( $css, '*/', $i + 2 );
                $stop = false === $stop ? $end : $stop + 2;
                $out .= substr( $css, $i, $stop - $i );
                $i    = $stop;
                continue;
            }
            // So does a quoted string, including one with an escaped quote in it.
            if ( '"' === $ch || "'" === $ch ) {
                $out .= $ch;
                $i++;
                while ( $i < $end ) {
                    $out .= $css[ $i ];
                    if ( '\\' === $css[ $i ] && $i + 1 < $end ) {
                        $out .= $css[ $i + 1 ];
                        $i   += 2;
                        continue;
                    }
                    if ( $css[ $i ] === $ch ) {
                        $i++;
                        break;
                    }
                    $i++;
                }
                continue;
            }
            if ( 0 === substr_compare( $css, $needle, $i, $len ) ) {
                // `.card` is this class; `.card-wide` is a different one, so the
                // character after the name has to end it.
                $next = $i + $len < $end ? $css[ $i + $len ] : '';
                if ( '' === $next || ! preg_match( '/[A-Za-z0-9_-]/', $next ) ) {
                    $out .= '%root%';
                    $i   += $len;
                    continue;
                }
            }
            $out .= $ch;
            $i++;
        }
        return $out;
    }

    /**
     * The rule as CSS anyone can read, rather than as Bricks stores it.
     *
     * Bricks accepts bare declarations - `color: red;` with no selector at all -
     * and writes `%root%` where the class goes. Showing that raw handed the
     * owner half a rule in the preview and, worse, in the edit box, where the
     * closing brace of a rule that had no opening one was all that fitted.
     */
    private function as_rule( string $name, string $css ): string {
        $css = trim( str_replace( [ '%%root%%', '%root%' ], '.' . $name, $css ) );
        if ( '' === $css ) {
            return '';
        }
        // No braces at all means Bricks stored declarations on their own.
        if ( false === strpos( $css, '{' ) ) {
            return '.' . $name . " {\n" . $this->indent( $css ) . "\n}";
        }
        // A stray closing brace with nothing opening it is the same thing with a
        // brace typed by hand; treat what precedes it as the declarations.
        if ( 0 !== strpos( $css, '.' ) && 0 !== strpos( $css, '#' ) && 0 !== strpos( $css, '@' )
            && strpos( $css, '{' ) > strpos( $css . '}', '}' ) ) {
            return '.' . $name . " {\n" . $this->indent( trim( $css, "{} \n\r\t" ) ) . "\n}";
        }
        return $css;
    }

    private function indent( string $css ): string {
        $lines = preg_split( '/\r?\n/', trim( $css ) );
        foreach ( $lines as $index => $line ) {
            $lines[ $index ] = '' === trim( $line ) ? '' : '  ' . trim( $line );
        }
        return implode( "\n", $lines );
    }

    /** Classes whose only rule is inside one element's own custom CSS. */
    private function element_custom_css(): array {
        $found = [];
        foreach ( $this->element_trees() as $elements ) {
            $this->collect_element_css( $elements, $found );
        }
        return $found;
    }

    private function collect_element_css( array $node, array &$found ): void {
        $settings = $node['settings'] ?? null;
        if ( is_array( $settings ) ) {
            foreach ( $settings as $key => $value ) {
                if ( ! is_string( $value ) || ( '_cssCustom' !== $key && 0 !== strpos( (string) $key, '_cssCustom:' ) ) ) {
                    continue;
                }
                foreach ( $this->selectors_in( $value ) as $name ) {
                    $rule = $this->as_rule( $name, $value );
                    $found[ $name ] = isset( $found[ $name ] ) ? $found[ $name ] . "\n\n" . $rule : $rule;
                }
            }
        }
        foreach ( $node as $value ) {
            if ( is_array( $value ) ) {
                $this->collect_element_css( $value, $found );
            }
        }
    }

    /** Class rules Code Studio's own CSS items already carry. */
    private function studio_rules(): array {
        $found = [];
        foreach ( ( new CodeItemManager() )->all() as $item ) {
            if ( 'css' !== ( $item['language'] ?? '' ) ) {
                continue;
            }
            foreach ( $this->rules_in( (string) $item['code'] ) as $name => $css ) {
                $found[ $name ] = [ 'css' => $css, 'name' => (string) $item['name'], 'id' => (string) $item['id'] ];
            }
        }
        return $found;
    }

    /**
     * How many elements wear each class.
     *
     * Counted from the Bricks element trees rather than guessed, because "used
     * on 14 elements" is the number that decides whether a rule is worth
     * chasing - and a wrong number here is worse than none.
     */
    private function usage_counts( array $names ): array {
        if ( ! $names ) {
            return [];
        }
        $counts = array_fill_keys( $names, 0 );

        $by_id = [];
        foreach ( $this->global_classes() as $record ) {
            $id   = (string) ( $record['id'] ?? '' );
            $name = $this->class_name( $record['name'] ?? '' );
            if ( '' !== $id && '' !== $name ) {
                $by_id[ $id ] = $name;
            }
        }

        foreach ( $this->element_trees() as $elements ) {
            $this->count_in_elements( $elements, $counts, $by_id );
        }
        return $counts;
    }

    private function count_in_elements( array $node, array &$counts, array $by_id ): void {
        $settings = $node['settings'] ?? null;
        if ( is_array( $settings ) ) {
            $applied = $settings['_cssGlobalClasses'] ?? [];
            if ( is_array( $applied ) ) {
                foreach ( $applied as $id ) {
                    $name = $by_id[ (string) $id ] ?? '';
                    if ( '' !== $name && isset( $counts[ $name ] ) ) {
                        $counts[ $name ]++;
                    }
                }
            }
            $classes = $settings['_cssClasses'] ?? '';
            if ( is_string( $classes ) && '' !== trim( $classes ) ) {
                foreach ( preg_split( '/\s+/', trim( $classes ) ) as $one ) {
                    $name = $this->class_name( $one );
                    if ( '' !== $name && isset( $counts[ $name ] ) ) {
                        $counts[ $name ]++;
                    }
                }
            }
        }
        foreach ( $node as $value ) {
            if ( is_array( $value ) ) {
                $this->count_in_elements( $value, $counts, $by_id );
            }
        }
    }

    /** Every Bricks element tree on the site, read once. */
    private function element_trees(): array {
        global $wpdb;

        if ( null !== $this->trees ) {
            return $this->trees;
        }

        // Revisions carry a copy of the element tree, so a page saved sixteen
        // times counted every class in it sixteen times - which is exactly what
        // the owner saw: every class on one template reading 16x. Only live
        // posts count, and each one only once.
        $trees = [];
        $rows  = $wpdb->get_col(
            "SELECT m.meta_value FROM {$wpdb->postmeta} m
             INNER JOIN {$wpdb->posts} p ON p.ID = m.post_id
             WHERE m.meta_key LIKE '_bricks_page_content%'
               AND p.post_type NOT IN ('revision')
               AND p.post_status NOT IN ('trash','auto-draft','inherit')
             GROUP BY m.post_id, m.meta_key
             ORDER BY MAX(m.meta_id) DESC
             LIMIT " . (int) self::SCAN_LIMIT
        );
        foreach ( (array) $rows as $row ) {
            $elements = maybe_unserialize( $row );
            if ( is_array( $elements ) ) {
                $trees[] = $elements;
            }
        }
        $this->trees = $trees;
        return $trees;
    }

    /* -- small shared pieces ---------------------------------------------- */

    /** `.thing`, `thing`, ` .thing ` all mean the same class. */
    private function class_name( $raw ): string {
        $name = ltrim( trim( (string) $raw ), '.' );
        return preg_match( '/^[A-Za-z_][A-Za-z0-9_-]{0,120}$/', $name ) ? $name : '';
    }

    /** Every class a block of CSS mentions. */
    private function selectors_in( string $css ): array {
        $names = [];
        if ( preg_match_all( '/\.([A-Za-z_][A-Za-z0-9_-]*)/', $css, $matches ) ) {
            foreach ( $matches[1] as $name ) {
                $clean = $this->class_name( $name );
                if ( '' !== $clean ) {
                    $names[ $clean ] = true;
                }
            }
        }
        return array_keys( $names );
    }

    /**
     * The rules a stylesheet declares, keyed by class.
     *
     * Only a rule whose selector *starts* with the class counts: `.card{}` is a
     * rule for `.card`, and `.wrap .card{}` is a rule for `.wrap`. Anything
     * looser would report a class as owned by a stylesheet that merely mentions
     * it in passing, and the lane's whole job is to be right about ownership.
     */
    private function rules_in( string $css ): array {
        $found = [];
        if ( ! preg_match_all( '/([^{}]*)\{([^{}]*)\}/', $css, $matches, PREG_SET_ORDER ) ) {
            return $found;
        }
        foreach ( $matches as $match ) {
            $selector = self::selector_of( $match[1] );
            $name     = $this->class_name( self::head_class( $selector ) );
            if ( '' === $name ) {
                continue;
            }
            $block = $selector . " {\n" . rtrim( $match[2] ) . "\n}";
            $found[ $name ] = isset( $found[ $name ] ) ? $found[ $name ] . "\n\n" . $block : $block;
        }
        return $found;
    }

    /**
     * Everything in front of a `{` is not the selector.
     *
     * A rule is usually preceded by whitespace and often by a comment. A CSS
     * comment glued to the front of a rule made the whole thing parse as a
     * selector that does not start with a dot - so a commented rule was
     * invisible to the lane, and to the rewriter that has to find it again.
     *
     * @return array{0:string,1:string} what comes before, and the selector.
     */
    public static function split_selector( string $raw ): array {
        if ( preg_match( '/^((?:\s|\/\*[\s\S]*?\*\/)*)([\s\S]*)$/', $raw, $parts ) ) {
            return [ $parts[1], trim( $parts[2] ) ];
        }
        return [ '', trim( $raw ) ];
    }

    public static function selector_of( string $raw ): string {
        return self::split_selector( $raw )[1];
    }

    /** The class a selector is a rule *for*: `.card:hover span` is `.card`. */
    public static function head_class( string $selector ): string {
        if ( '' === $selector || 0 !== strpos( $selector, '.' ) ) {
            return '';
        }
        $parts = preg_split( '/[\s,>+~:]/', ltrim( $selector, '.' ) );
        return (string) ( $parts[0] ?? '' );
    }

    /** A rule block for a class, keeping whatever CSS was already written. */
    private function rule_block( string $name, string $css ): string {
        $css = trim( $css );
        if ( '' === $css ) {
            return '.' . $name . " {\n  \n}";
        }
        // Bricks writes `%root%` for "this class"; in a stylesheet that is the
        // selector itself, so it is replaced rather than carried across.
        $css = str_replace( [ '%%root%%', '%root%' ], '.' . $name, $css );
        return false === strpos( $css, '{' ) ? '.' . $name . " {\n" . $css . "\n}" : $css;
    }
}
