<?php
namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * The store behind Code Studio.
 *
 * CSS Studio kept a list of stylesheets and compiled all of them into one file.
 * Code Studio keeps **code items**, and the thing in the editor is no longer
 * always CSS: an item has a language, and what it means to "run" depends on
 * that language.
 *
 *   * **CSS** has a real destination. Four of them, each a file this class
 *     writes and something else enqueues: `global` (site and builder),
 *     `frontend` (site only), `builder` (builder only), and `page` (one post,
 *     which the panel will address later). The old single `advanced.css` is
 *     still written, so anything already enqueueing it keeps working while the
 *     transition finishes.
 *
 *   * **PHP, JavaScript and HTML** have a hook and a priority instead. Those
 *     are **stored and never executed** - deliberately, and the panel says so.
 *     Running stored PHP is the half that can white-screen a site, and it does
 *     not ship until it ships with a fatal-error guard that switches the item
 *     off and says which one it was. Storing the fields now means the model
 *     does not change underneath that work.
 *
 * Migration from `ve_advanced_css` runs once, is idempotent, and keeps every id
 * so the version history written against those ids still points at the right
 * item.
 */
class CodeItemManager {

    private const OPTION    = 've_code_items';
    private const MIGRATED  = 've_code_items_migrated_from_css_studio';
    private const LEGACY    = 've_advanced_css';

    /** The languages an item can be. */
    public const LANGUAGES = [ 'css', 'php', 'js', 'html' ];

    /** Where compiled CSS can land. Each one is a real file. */
    public const DESTINATIONS = [ 'global', 'frontend', 'builder', 'page' ];

    /** What an item can be doing. `error` is set by the runtime, never by hand. */
    public const STATUSES = [ 'active', 'paused', 'error' ];

    /** Everything, oldest first, migrated if this is the first look. */
    public function all(): array {
        $this->migrate_once();
        $stored = get_option( self::OPTION, null );
        if ( ! is_array( $stored ) || ! isset( $stored['items'] ) || ! is_array( $stored['items'] ) ) {
            return $this->defaults();
        }
        return array_values( array_map( [ $this, 'normalize' ], $stored['items'] ) );
    }

    /** One item by id, or null. */
    public function find( string $id ): ?array {
        foreach ( $this->all() as $item ) {
            if ( $item['id'] === $id ) {
                return $item;
            }
        }
        return null;
    }

    /**
     * Write the whole set, then compile.
     *
     * Whole-set rather than per-item because order matters to CSS: the sequence
     * items are written in is the sequence they are compiled in, and that is what
     * decides which rule wins.
     */
    public function save( array $items ): array {
        $clean = [];
        foreach ( $items as $item ) {
            if ( is_array( $item ) ) {
                $clean[] = $this->normalize( $item );
            }
        }
        if ( ! $clean ) {
            $clean = $this->defaults();
        }
        update_option( self::OPTION, [ 'items' => $clean ], false );
        $this->compile();
        return $clean;
    }

    /** Add one item and return it, already saved. */
    public function create( array $item ): array {
        $items   = $this->all();
        $created = $this->normalize( $item );
        // A new id every time, so creating never overwrites by accident.
        $created['id'] = $this->fresh_id( $created['language'], $items );
        $items[]       = $created;
        $this->save( $items );
        return $created;
    }

    /** Change one item. Unknown keys are ignored; unknown ids return null. */
    /**
     * Change one item.
     *
     * `$track` exists because restore_version() calls this after it has already
     * recorded the version it is about to overwrite; recording again would put
     * the same change in history twice.
     */
    public function update( string $id, array $changes, bool $track = true ): ?array {
        $items = $this->all();
        $found = null;
        $before = null;
        foreach ( $items as $index => $item ) {
            if ( $item['id'] !== $id ) {
                continue;
            }
            $before = (string) ( $item['code'] ?? '' );
            $merged = array_merge( $item, $changes );
            // The id is the one thing a change cannot move.
            $merged['id']  = $id;
            $items[ $index ] = $this->normalize( $merged );
            $found = $items[ $index ];
        }
        if ( ! $found ) {
            return null;
        }
        $this->save( $items );
        if ( $track && null !== $before ) {
            $this->record_version( $found, $before, (string) $found['code'] );
        }
        return $found;
    }


    /* ── History ─────────────────────────────────────────────────────────────
       Code Studio items keep a version per save, in the same `css_versions`
       table CSS Studio has always used, keyed by the same id. That is not a
       coincidence: the migration deliberately preserved every stylesheet's id
       so its history would still point at it. A sheet that came across from CSS
       Studio therefore arrives here with its whole past intact, and this is the
       last capability CSS Studio had that Code Studio did not. */

    /** How many versions to keep per item, matching CSS Studio's own limit. */
    public const VERSION_LIMIT = 25;

    private function versions_table(): string {
        return Schema::table( 'css_versions' );
    }

    private function has_versions( string $item_id ): bool {
        global $wpdb;
        $table = $this->versions_table();
        return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$table} WHERE sheet_id = %s LIMIT 1", $item_id ) );
    }

    private function insert_version( array $item, string $code, string $note ): void {
        global $wpdb;
        $wpdb->insert(
            $this->versions_table(),
            [
                'sheet_id'   => (string) ( $item['id'] ?? '' ),
                'sheet_name' => (string) ( $item['name'] ?? '' ),
                // The column is named `scope` because CSS Studio called it that.
                // For a code item the equivalent is where it lands.
                'scope'      => (string) ( $item['destination'] ?? 'global' ),
                'css'        => $code,
                'bytes'      => strlen( $code ),
                'note'       => $note,
                'created_by' => get_current_user_id(),
                'created_at' => current_time( 'mysql' ),
            ]
        );
    }

    private function prune_versions( string $item_id ): void {
        global $wpdb;
        $table = $this->versions_table();
        $keep  = $wpdb->get_col(
            $wpdb->prepare( "SELECT id FROM {$table} WHERE sheet_id = %s ORDER BY id DESC LIMIT %d", $item_id, self::VERSION_LIMIT )
        );
        if ( empty( $keep ) ) {
            return;
        }
        $ids = implode( ',', array_map( 'absint', $keep ) );
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE sheet_id = %s AND id NOT IN ({$ids})", $item_id ) );
    }

    /**
     * Record a change, if it is one.
     *
     * Saving without changing anything must add nothing, or the list fills with
     * identical entries and stops being readable. The first tracked edit also
     * writes what the item held beforehand, so the very first save is still
     * undoable - without that, history only starts helping from the second time.
     */
    public function record_version( array $item, string $before, string $after, string $note = 'save' ): int {
        $id = (string) ( $item['id'] ?? '' );
        if ( '' === $id || $before === $after ) {
            return 0;
        }
        $written = 0;
        if ( ! $this->has_versions( $id ) && '' !== trim( $before ) ) {
            $this->insert_version( $item, $before, 'before first tracked edit' );
            $written++;
        }
        $this->insert_version( $item, $after, $note );
        $written++;
        $this->prune_versions( $id );
        return $written;
    }

    /**
     * The list for the History panel: everything except the code itself, because
     * twenty-five copies of a stylesheet is a lot of bytes to send to draw dates.
     *
     * @return array<int,array<string,mixed>>
     */
    public function versions( string $item_id = '' ): array {
        global $wpdb;
        $table = $this->versions_table();
        $sql   = "SELECT id, sheet_id, sheet_name, scope, bytes, note, created_by, created_at FROM {$table}";
        $rows  = '' !== $item_id
            ? $wpdb->get_results( $wpdb->prepare( $sql . ' WHERE sheet_id = %s ORDER BY id DESC LIMIT %d', $item_id, self::VERSION_LIMIT ), ARRAY_A )
            : $wpdb->get_results( $sql . ' ORDER BY id DESC LIMIT 100', ARRAY_A );

        return array_map(
            static function ( $row ) {
                $user          = ! empty( $row['created_by'] ) ? get_userdata( (int) $row['created_by'] ) : null;
                $row['id']     = (int) $row['id'];
                $row['bytes']  = (int) $row['bytes'];
                $row['author'] = $user ? $user->display_name : '';
                return $row;
            },
            is_array( $rows ) ? $rows : []
        );
    }

    /** One version, code included. */
    public function version( int $id ): ?array {
        global $wpdb;
        $table = $this->versions_table();
        $row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );
        return is_array( $row ) ? $row : null;
    }

    /**
     * Put a version back.
     *
     * The current code is recorded first, so restoring is itself undoable - the
     * one thing that makes a restore button safe to press. The compile runs
     * afterwards, because a restore that changes the stored item and leaves the
     * old CSS on the site would be worse than no restore at all.
     *
     * @return array<string,mixed>
     */
    public function restore_version( int $id ): array {
        $version = $this->version( $id );
        if ( ! $version ) {
            return [ 'restored' => false, 'message' => 'That version no longer exists.' ];
        }
        $item_id = (string) $version['sheet_id'];
        $item    = $this->find( $item_id );
        if ( ! $item ) {
            return [ 'restored' => false, 'message' => 'That item no longer exists.' ];
        }

        $code = (string) $version['css'];
        if ( $code === (string) $item['code'] ) {
            return [
                'restored' => true,
                'item'     => $item,
                'items'    => $this->all(),
                'message'  => 'That version is already what the item holds.',
            ];
        }

        $this->record_version( $item, (string) $item['code'], $code, 'restored version ' . (int) $id );
        $updated = $this->update( $item_id, [ 'code' => $code ], false );
        // save() compiles already, so this is belt and braces rather than the
        // thing that makes it work - removing it does not break the guard. It
        // stays because a restore that changed the item and left the old CSS on
        // the site is the one failure here nobody would notice until later.
        $this->compile();

        return [
            'restored' => true,
            'item'     => $updated,
            'items'    => $this->all(),
            'message'  => 'Restored the version from ' . (string) $version['created_at'] . '.',
        ];
    }

    /** Remove one item. Returns whether it was there. */
    public function delete( string $id ): bool {
        $items = $this->all();
        $kept  = array_values( array_filter( $items, static fn( $item ) => $item['id'] !== $id ) );
        if ( count( $kept ) === count( $items ) ) {
            return false;
        }
        $this->save( $kept );
        return true;
    }

    /**
     * Write the CSS files.
     *
     * One file per destination, holding the active CSS items for it in the order
     * they are stored. A destination with nothing in it is written empty rather
     * than left behind, so a stale file cannot outlive the item that made it.
     */
    public function compile(): array {
        $items   = $this->all();
        $written = [];

        /* A page destination writes one file per page that has CSS attached, so a
           page loads its own rules and nobody else's. Grouped first, because
           several items can point at the same page. */
        $by_page = [];
        foreach ( $items as $item ) {
            if ( 'css' !== $item['language'] || 'active' !== $item['status'] ) {
                continue;
            }
            if ( 'page' !== $item['destination'] || empty( $item['page_id'] ) ) {
                continue;
            }
            if ( '' === trim( $item['code'] ) ) {
                continue;
            }
            $by_page[ (int) $item['page_id'] ][] = $item;
        }
        foreach ( $by_page as $page_id => $page_items ) {
            $parts = [ $this->file_header( 'page ' . $page_id ) ];
            foreach ( $page_items as $item ) {
                $parts[] = '/* === ' . $item['name'] . ' === */';
                $parts[] = rtrim( $item['code'] );
                $parts[] = '';
            }
            $written[ 'page-' . $page_id ] = $this->write( 'code-studio-page-' . $page_id . '.css', implode( "
", $parts ) );
        }

        foreach ( self::DESTINATIONS as $destination ) {
            if ( 'page' === $destination ) {
                continue;   // written above, one file per page
            }
            $parts = [ $this->file_header( $destination ) ];
            foreach ( $items as $item ) {
                if ( 'css' !== $item['language'] || 'active' !== $item['status'] ) {
                    continue;
                }
                if ( $item['destination'] !== $destination ) {
                    continue;
                }
                if ( '' === trim( $item['code'] ) ) {
                    continue;
                }
                $parts[] = '/* === ' . $item['name'] . ' === */';
                $parts[] = rtrim( $item['code'] );
                $parts[] = '';
            }
            $written[ $destination ] = $this->write( $this->file_name( $destination ), implode( "\n", $parts ) );
        }

        // The old single file, still written so anything enqueueing it keeps
        // working until the transition is finished and it can be retired.
        $legacy = [ $this->file_header( 'legacy' ) ];
        foreach ( $items as $item ) {
            if ( 'css' !== $item['language'] || 'active' !== $item['status'] || 'page' === $item['destination'] ) {
                continue;
            }
            if ( '' === trim( $item['code'] ) ) {
                continue;
            }
            $legacy[] = '/* === ' . $item['name'] . ' (' . $item['destination'] . ') === */';
            $legacy[] = rtrim( $item['code'] );
            $legacy[] = '';
        }
        $written['legacy'] = $this->write( 'advanced.css', implode( "\n", $legacy ) );

        return [ 'compiled' => ! in_array( false, $written, true ), 'files' => $written ];
    }

    /** Where a destination's file lives, for whoever enqueues it. */
    public function file_url( string $destination ): string {
        return VE_CSS_OUTPUT_URL . $this->file_name( $destination );
    }

    /* -- the shape of an item --------------------------------------------- */

    /**
     * Fill in what is missing and refuse what is not allowed.
     *
     * Every unknown value falls back rather than being stored: an item with a
     * language nobody recognises is an item that will never run and never say
     * why.
     */
    public function normalize( array $item ): array {
        $language = sanitize_key( (string) ( $item['language'] ?? 'css' ) );
        if ( ! in_array( $language, self::LANGUAGES, true ) ) {
            $language = 'css';
        }

        $destination = sanitize_key( (string) ( $item['destination'] ?? 'global' ) );
        if ( ! in_array( $destination, self::DESTINATIONS, true ) ) {
            $destination = 'global';
        }

        $status = sanitize_key( (string) ( $item['status'] ?? 'active' ) );
        if ( ! in_array( $status, self::STATUSES, true ) ) {
            $status = 'active';
        }

        $id = sanitize_key( (string) ( $item['id'] ?? '' ) );
        if ( '' === $id ) {
            $id = $this->fresh_id( $language, [] );
        }

        $name = sanitize_text_field( (string) ( $item['name'] ?? '' ) );
        if ( '' === $name ) {
            $name = 'untitled.' . ( 'js' === $language ? 'js' : $language );
        }

        return [
            'id'          => $id,
            'name'        => $name,
            'language'    => $language,
            // CSS lands somewhere; everything else hangs off a hook it does not
            // yet run on, so the destination is not its business.
            'destination' => 'css' === $language ? $destination : 'global',
            /* Which page, when the destination is one page. Kept even if the
               destination changes, so switching away and back does not lose the
               choice the person already made. */
            'page_id'     => absint( $item['page_id'] ?? 0 ),
            'status'      => $status,
            'code'        => (string) ( $item['code'] ?? '' ),
            'folder'      => sanitize_text_field( (string) ( $item['folder'] ?? '' ) ),
            // Stored, never evaluated. See the note at the top of this class.
            'hook'        => sanitize_text_field( (string) ( $item['hook'] ?? '' ) ),
            'priority'    => (int) ( $item['priority'] ?? 10 ),
            'run_context' => sanitize_key( (string) ( $item['run_context'] ?? 'everywhere' ) ),
            // Written by whatever discovers the failure, so the panel can show
            // which item was switched off and what it said.
            'last_error'  => sanitize_text_field( (string) ( $item['last_error'] ?? '' ) ),
        ];
    }

    private function fresh_id( string $language, array $existing ): string {
        $taken = [];
        foreach ( $existing as $item ) {
            $taken[ $item['id'] ?? '' ] = true;
        }
        do {
            $id = $language . '_' . substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 8 );
        } while ( isset( $taken[ $id ] ) );
        return $id;
    }

    private function defaults(): array {
        return [
            $this->normalize( [ 'id' => 'global', 'name' => 'global.css', 'language' => 'css', 'destination' => 'global' ] ),
        ];
    }

    /* -- coming from CSS Studio -------------------------------------------- */

    /**
     * Bring the old stylesheets across, once.
     *
     * Ids are kept, because the version history is written against them: change
     * the id and every saved version of that sheet becomes unreachable. The old
     * option is left exactly as it was, so this can be re-run and so nothing is
     * destroyed if the transition is reversed.
     */
    public function migrate_once(): array {
        if ( get_option( self::MIGRATED, '' ) ) {
            return [ 'migrated' => 0, 'already' => true ];
        }
        if ( is_array( get_option( self::OPTION, null ) ) ) {
            update_option( self::MIGRATED, gmdate( 'c' ), false );
            return [ 'migrated' => 0, 'already' => true ];
        }

        $legacy = get_option( self::LEGACY, [] );
        $sheets = is_array( $legacy ) && isset( $legacy['stylesheets'] ) && is_array( $legacy['stylesheets'] )
            ? $legacy['stylesheets']
            : [];

        $items = [];
        foreach ( $sheets as $sheet ) {
            if ( ! is_array( $sheet ) ) {
                continue;
            }
            $items[] = $this->normalize( [
                'id'          => (string) ( $sheet['id'] ?? '' ),
                'name'        => (string) ( $sheet['name'] ?? '' ),
                'language'    => 'css',
                'destination' => $this->destination_for_scope( (string) ( $sheet['scope'] ?? 'global' ) ),
                'status'      => ( ! isset( $sheet['enabled'] ) || ! empty( $sheet['enabled'] ) ) ? 'active' : 'paused',
                'code'        => (string) ( $sheet['css'] ?? '' ),
            ] );
        }

        if ( ! $items ) {
            $items = $this->defaults();
        }

        update_option( self::OPTION, [ 'items' => $items ], false );
        update_option( self::MIGRATED, gmdate( 'c' ), false );
        $this->compile();

        return [ 'migrated' => count( $items ), 'already' => false ];
    }

    /**
     * The old scopes were about where a sheet was written, not where it lands.
     * `page` is the one that means the same thing in both.
     */
    private function destination_for_scope( string $scope ): string {
        $scope = sanitize_key( $scope );
        if ( 'page' === $scope ) {
            return 'page';
        }
        return 'global';
    }

    /* -- files -------------------------------------------------------------- */

    private function file_name( string $destination ): string {
        return 'code-studio-' . sanitize_key( $destination ) . '.css';
    }

    private function file_header( string $what ): string {
        return "/*\n * Mimam's Var - Code Studio (" . $what . ")\n"
            . ' * Version: ' . ( defined( 'VE_VERSION' ) ? VE_VERSION : '' ) . "\n"
            . ' * Compiled: ' . gmdate( 'Y-m-d H:i:s' ) . " UTC\n */\n";
    }

    private function write( string $file, string $contents ): bool {
        if ( ! is_dir( VE_CSS_OUTPUT_DIR ) ) {
            wp_mkdir_p( VE_CSS_OUTPUT_DIR );
        }
        return false !== file_put_contents( VE_CSS_OUTPUT_DIR . $file, $contents );
    }
}
