<?php
/**
 * Security boundary regression guard.
 *
 * Run: php tests/check-security-boundaries.php
 */

declare( strict_types = 1 );

$root = dirname( __DIR__ );
$paths = [
	'bootstrap' => $root . '/variable-engine.php',
	'routes'    => $root . '/api/Routes.php',
	'sync'      => $root . '/api/SyncController.php',
	'pairing'   => $root . '/sync/PairingManager.php',
	'capability'=> $root . '/modules/recovery/app/Security/Capability.php',
	'recovery'  => $root . '/modules/recovery/app/API/Routes.php',
	'builder'   => $root . '/modules/recovery/app/Backup/PackageBuilder.php',
	'validator' => $root . '/modules/recovery/app/Backup/PackageValidator.php',
	'importer'  => $root . '/modules/recovery/app/Restore/SQLTemporaryImporter.php',
	'visibility'=> $root . '/core/SiteVisibility.php',
];

$source = [];
foreach ( $paths as $name => $path ) {
	$source[ $name ] = (string) file_get_contents( $path );
}

if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', $root . '/' );
}
require_once $paths['importer'];
$importer_ref = new ReflectionClass( \VE\Modules\Recovery\Restore\SQLTemporaryImporter::class );
$importer = $importer_ref->newInstanceWithoutConstructor();
$policy = $importer_ref->getMethod( 'import_statement_policy' );
$policy->setAccessible( true );
$sql_map = [ 'wp_posts' => 'wp_rb_tmp_posts' ];

$checks = [
	'Integration keys never assume WordPress user 1' =>
		false === strpos( $source['bootstrap'], 'wp_set_current_user( 1 )' )
		&& false !== strpos( $source['bootstrap'], '/wp-json/variable-engine/v1' ),
	'Figma pairing registration requires WordPress write authorization' =>
		false !== strpos( $source['routes'], "'/sync/pair/register'" )
		&& false !== strpos( $source['pairing'], '$expected_origin' )
		&& false !== strpos( $source['pairing'], '/^ve_[a-f0-9]{48}$/' ),
	'Paired metadata updates require the integration credential' =>
		false !== strpos( $source['sync'], 've_sync_unauthorized' )
		&& false !== strpos( $source['sync'], 'self::can_sync( $request )' ),
	'Integration-key access is constrained to token-model routes' =>
		false !== strpos( $source['routes'], 'sync_key_allowed_for_request' )
		&& false !== strpos( $source['routes'], 'variables|generators|categories|palettes|themes|color-palettes|families' ),
	'Plugin actions use action-specific capabilities' =>
		false !== strpos( $source['routes'], 'can_run_plugin_action' )
		&& false !== strpos( $source['routes'], "'delete'          => 'delete_plugins'" )
		&& false !== strpos( $source['routes'], 'can_upload_plugins' ),
	'Destructive recovery uses the core-update boundary' =>
		false !== strpos( $source['capability'], "'update_core'" )
		&& false !== strpos( $source['capability'], 'is_super_admin()' )
		&& substr_count( $source['recovery'], "[ \$this, 'restore_permissions' ]" ) >= 4,
	'Persisted recovery packages fail closed without encryption' =>
		false !== strpos( $source['builder'], 'PackageCipher::default_passphrase()' )
		&& false !== strpos( $source['builder'], 'no plaintext backup was retained' )
		&& false !== strpos( $source['validator'], 'Package origin could not be authenticated' ),
	'Recovery SQL uses a temporary-table command allowlist' =>
		false !== strpos( $source['importer'], 'import_statement_policy' )
		&& false !== strpos( $source['importer'], 'has_extra_statement_terminator' )
		&& false !== strpos( $source['importer'], "return 'deny';" )
		&& 'allow' === $policy->invoke( $importer, "INSERT INTO `wp_rb_tmp_posts` (`post_title`) VALUES ('semi;colon');", $sql_map )
		&& 'deny' === $policy->invoke( $importer, 'UPDATE `wp_rb_tmp_posts` SET post_title = \'owned\';', $sql_map )
		&& 'deny' === $policy->invoke( $importer, 'INSERT INTO `wp_rb_tmp_posts` VALUES (1); DROP TABLE `wp_users`;', $sql_map ),
	'Remote media uses safe bounded HTTP requests' =>
		false !== strpos( $source['routes'], 'wp_safe_remote_head' )
		&& false !== strpos( $source['routes'], 'limit_response_size' )
		&& false === strpos( $source['routes'], 'download_url(' ),
	'Media ZIPs are inspected before extraction' =>
		false !== strpos( $source['routes'], 'validate_media_zip_archive' )
		&& false !== strpos( $source['routes'], 'unsafe compression ratio' ),
	'Content and media exports enforce object reads' =>
		substr_count( $source['routes'], "current_user_can( 'read_post'" ) >= 3
		&& false !== strpos( $source['routes'], "'perm'           => 'readable'" ),
	'Maintenance preview has no fixed fallback credential' =>
		false !== strpos( $source['visibility'], 'wp_generate_password( 32, false, false )' )
		&& false === strpos( $source['visibility'], "?? 'bypass'" ),
];

$failed = array_keys( array_filter( $checks, static function ( bool $passed ): bool {
	return ! $passed;
} ) );

if ( $failed ) {
	echo "FAILED - security boundaries:\n";
	foreach ( $failed as $label ) {
		echo '  - ' . $label . "\n";
	}
	exit( 1 );
}

echo sprintf( "OK: %d security boundary contracts are guarded.\n", count( $checks ) );
exit( 0 );
