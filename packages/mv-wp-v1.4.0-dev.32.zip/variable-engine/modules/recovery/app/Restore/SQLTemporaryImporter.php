<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class SQLTemporaryImporter {
    public function import( string $sql_path, array $plan, string $token = '' ): array {
        global $wpdb;

        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        }

        if ( '' === $sql_path || ! is_readable( $sql_path ) ) {
            return [ 'ok' => false, 'message' => 'database.sql is missing or unreadable.', 'tables' => [], 'map' => [] ];
        }

        $tables = isset( $plan['tables'] ) && is_array( $plan['tables'] ) ? array_values( $plan['tables'] ) : [];
        if ( empty( $tables ) ) {
            return [ 'ok' => false, 'message' => 'No tables were available for temporary import.', 'tables' => [], 'map' => [] ];
        }

        $token = $this->safe_token( $token ?: strtolower( wp_generate_password( 6, false, false ) ) );
        $backup_prefix = isset( $plan['backup_prefix'] ) ? (string) $plan['backup_prefix'] : '';
        $current_prefix = isset( $wpdb->prefix ) ? (string) $wpdb->prefix : '';
        $map = $this->build_map( $tables, $backup_prefix, $current_prefix, $token );

        if ( empty( $map ) ) {
            return [ 'ok' => false, 'message' => 'No restorable database tables were available after RestoreBase safety filtering.', 'tables' => [], 'map' => [] ];
        }

        $this->drop_temp_tables( $map );

        $handle = fopen( $sql_path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        if ( ! $handle ) {
            return [ 'ok' => false, 'message' => 'database.sql could not be opened for temporary import.', 'tables' => [], 'map' => $map ];
        }

        $statement = '';
        $queries = 0;
        $errors = [];

        $wpdb->query( 'SET FOREIGN_KEY_CHECKS=0' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $wpdb->query( 'SET UNIQUE_CHECKS=0' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        while ( ! feof( $handle ) ) {
            $line = fgets( $handle );
            if ( ! is_string( $line ) ) {
                continue;
            }

            $trimmed = trim( $line );
            if ( '' === $statement ) {
                if ( '' === $trimmed || 0 === strpos( $trimmed, '--' ) || 0 === strpos( $trimmed, '/*' ) ) {
                    continue;
                }

                if ( preg_match( '/^(LOCK TABLES|UNLOCK TABLES)/i', $trimmed ) ) {
                    continue;
                }
            }

            $statement .= $this->rewrite_tables( $line, $map );

            if ( ';' === substr( rtrim( $line ), -1 ) ) {
                $sql = trim( $statement );
                $statement = '';
                if ( '' === $sql ) {
                    continue;
                }

                $policy = $this->import_statement_policy( $sql, $map );
                if ( 'skip' === $policy ) {
                    continue;
                }
                if ( 'allow' !== $policy ) {
                    $errors[] = 'RestoreBase blocked a SQL statement outside the safe export grammar.';
                    break;
                }

                $result = $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                $queries++;
                if ( false === $result ) {
                    $errors[] = $this->compact_sql_error( (string) $wpdb->last_error, $sql );
                    if ( count( $errors ) >= 5 ) {
                        break;
                    }
                }
            }
        }

        fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

        $wpdb->query( 'SET UNIQUE_CHECKS=1' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $wpdb->query( 'SET FOREIGN_KEY_CHECKS=1' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        $imported = $this->existing_temp_tables( $map );
        $ok = empty( $errors ) && count( $imported ) > 0;

        Logger::info( 'temporary_sql_import_finished', 'RestoreBase temporary SQL import finished.', [
            'ok'       => $ok,
            'queries'  => $queries,
            'imported' => count( $imported ),
            'errors'   => count( $errors ),
        ] );

        return [
            'ok'              => $ok,
            'message'         => $ok ? 'SQL imported into temporary RestoreBase tables.' : $this->message_with_first_error( 'Temporary SQL import encountered blockers.', $errors ),
            'queries'         => $queries,
            'tables'          => $imported,
            'map'             => $map,
            'errors'          => $errors,
            'rollback_note'   => 'Live tables have not been replaced yet. Temporary tables can be removed safely if execution stops here.',
        ];
    }

    /**
     * Only execute statements emitted by the bundled exporter and only when the
     * first table target is one of this restore's isolated temporary tables.
     */
    private function import_statement_policy( string $sql, array $map ): string {
        $sql = trim( $sql );
        if ( preg_match( '/^SET\s+/i', $sql ) ) {
            return 'skip';
        }
        if ( $this->has_extra_statement_terminator( $sql ) ) {
            return 'deny';
        }

        $statement = preg_replace( '/;\s*$/', '', $sql );
        $table = '';
        if ( preg_match( '/^DROP\s+TABLE\s+IF\s+EXISTS\s+`?([A-Za-z0-9_]+)`?\s*$/i', $statement, $match ) ) {
            $table = $match[1];
        } elseif ( preg_match( '/^CREATE\s+TABLE\s+(?:IF\s+NOT\s+EXISTS\s+)?`?([A-Za-z0-9_]+)`?\s*\(/is', $statement, $match ) ) {
            $table = $match[1];
        } elseif ( preg_match( '/^INSERT\s+INTO\s+`?([A-Za-z0-9_]+)`?\s+(?:VALUES|\()/is', $statement, $match ) ) {
            $table = $match[1];
        } else {
            return 'deny';
        }

        return in_array( $table, array_values( $map ), true ) ? 'allow' : 'deny';
    }

    /** Detect a second top-level statement while allowing semicolons in strings. */
    private function has_extra_statement_terminator( string $sql ): bool {
        $length = strlen( $sql );
        $quote = '';
        $escaped = false;
        for ( $i = 0; $i < $length; $i++ ) {
            $char = $sql[ $i ];
            if ( $escaped ) {
                $escaped = false;
                continue;
            }
            if ( '\\' === $char && '' !== $quote ) {
                $escaped = true;
                continue;
            }
            if ( '' !== $quote ) {
                if ( $char === $quote ) {
                    $quote = '';
                }
                continue;
            }
            if ( "'" === $char || '"' === $char || '`' === $char ) {
                $quote = $char;
                continue;
            }
            if ( ';' === $char && '' !== trim( substr( $sql, $i + 1 ) ) ) {
                return true;
            }
        }
        return false;
    }

    public function swap_to_live( array $map ): array {
        global $wpdb;

        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        }

        $prepared = $this->prepare_swap_entries( $map );
        if ( empty( $prepared['entries'] ) ) {
            return [
                'ok'       => false,
                'message'  => 'No imported temporary database tables were available to swap.',
                'renamed'  => [],
                'errors'   => [],
                'warnings' => [],
                'skipped'  => $prepared['skipped'],
            ];
        }

        $entries = $prepared['entries'];
        $errors = [];
        $warnings = [];
        $renamed = [];
        $used_fallback = false;
        $recovery = [
            'preserved'   => 0,
            'overwritten' => 0,
        ];

        $rename_parts = [];
        foreach ( $entries as $entry ) {
            if ( ! empty( $entry['live_exists'] ) ) {
                $rename_parts[] = $this->quote( (string) $entry['live'] ) . ' TO ' . $this->quote( (string) $entry['backup'] );
            }
            $rename_parts[] = $this->quote( (string) $entry['temp'] ) . ' TO ' . $this->quote( (string) $entry['live'] );
        }

        $wpdb->query( 'SET FOREIGN_KEY_CHECKS=0' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $wpdb->query( 'SET UNIQUE_CHECKS=0' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        $result = false;
        $bulk_error = '';
        if ( ! empty( $rename_parts ) ) {
            $sql = 'RENAME TABLE ' . implode( ', ', $rename_parts );
            $result = $this->run_query( $sql );
            if ( false === $result['ok'] ) {
                $bulk_error = $this->compact_sql_error( (string) $result['error'], $sql );
                $warnings[] = $bulk_error;
            }
        }

        if ( false !== $result && ! empty( $result['ok'] ) ) {
            foreach ( $entries as $entry ) {
                $renamed[] = [
                    'live'   => (string) $entry['live'],
                    'temp'   => (string) $entry['temp'],
                    'backup' => $this->table_exists( (string) $entry['backup'] ) ? (string) $entry['backup'] : '',
                    'mode'   => ! empty( $entry['live_exists'] ) ? 'preserved' : 'new',
                ];
            }
            $recovery['preserved'] = count( $renamed );
        } else {
            $used_fallback = true;
            $fallback = $this->swap_entries_one_by_one( $entries );
            $renamed = $fallback['renamed'];
            $errors = $fallback['errors'];
            $warnings = array_merge( $warnings, $fallback['warnings'] );
            $recovery = isset( $fallback['recovery'] ) && is_array( $fallback['recovery'] ) ? array_merge( $recovery, $fallback['recovery'] ) : $recovery;

            if ( ! empty( $bulk_error ) && ( ! empty( $errors ) || count( $renamed ) !== count( $entries ) ) ) {
                array_unshift( $errors, $bulk_error );
            }
        }

        $wpdb->query( 'SET UNIQUE_CHECKS=1' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $wpdb->query( 'SET FOREIGN_KEY_CHECKS=1' ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        $ok = empty( $errors ) && count( $renamed ) === count( $entries );
        if ( $ok ) {
            if ( $used_fallback && ! empty( $recovery['overwritten'] ) ) {
                $message = 'Temporary tables swapped into live table names with the overwrite recovery fallback.';
            } elseif ( $used_fallback ) {
                $message = 'Temporary tables swapped into live table names with the safe fallback path.';
            } else {
                $message = 'Temporary tables swapped into live table names.';
            }
        } else {
            $message = $this->message_with_first_error( 'Database table swap failed.', $errors );
        }

        Logger::info( 'database_table_swap_finished', 'RestoreBase database table swap finished.', [
            'ok'          => $ok,
            'attempted'   => count( $entries ),
            'renamed'     => count( $renamed ),
            'errors'      => count( $errors ),
            'warnings'    => count( $warnings ),
            'fallback'    => $used_fallback,
            'overwritten' => (int) ( $recovery['overwritten'] ?? 0 ),
        ] );

        return [
            'ok'        => $ok,
            'message'   => $message,
            'renamed'   => $renamed,
            'errors'    => array_slice( array_values( array_unique( $errors ) ), 0, 10 ),
            'warnings'  => array_slice( array_values( array_unique( $warnings ) ), 0, 10 ),
            'skipped'   => $prepared['skipped'],
            'attempted' => count( $entries ),
            'fallback'  => $used_fallback,
            'recovery'  => $recovery,
        ];
    }

    private function build_map( array $tables, string $backup_prefix, string $current_prefix, string $token ): array {
        $map = [];
        $reserved = [];
        foreach ( $tables as $table ) {
            $table = sanitize_text_field( (string) $table );
            if ( '' === $table || SelfProtection::is_restorebase_table( $table ) || ! $this->valid_identifier( $table ) ) {
                continue;
            }
            $short = $backup_prefix && 0 === strpos( $table, $backup_prefix ) ? substr( $table, strlen( $backup_prefix ) ) : $table;
            $short = ltrim( (string) $short, '_' );
            if ( '' === $short ) {
                continue;
            }

            $live = $current_prefix . $short;
            if ( ! $this->valid_identifier( $live ) || SelfProtection::is_restorebase_table( $live ) ) {
                continue;
            }

            $temp = $this->unique_limited_name( $current_prefix . 'rbtmp_' . $token . '_' . $short, $short, $reserved );
            $map[] = [ 'backup' => $table, 'live' => $live, 'temp' => $temp ];
        }
        return $map;
    }

    private function rewrite_tables( string $sql, array $map ): string {
        foreach ( $map as $entry ) {
            $backup = (string) $entry['backup'];
            $temp = (string) $entry['temp'];
            $sql = str_replace( '`' . $backup . '`', '`' . $temp . '`', $sql );
            $sql = preg_replace( '/(?<=\s)' . preg_quote( $backup, '/' ) . '(?=[\s(;])/', $temp, $sql );
        }
        return $sql;
    }

    private function prepare_swap_entries( array $map ): array {
        $entries = [];
        $skipped = [];
        $reserved_backups = [];
        $backup_token = 'rbbak_' . strtolower( wp_generate_password( 6, false, false ) ) . '_';

        foreach ( $map as $entry ) {
            $live = isset( $entry['live'] ) ? (string) $entry['live'] : '';
            $temp = isset( $entry['temp'] ) ? (string) $entry['temp'] : '';
            if ( '' === $live || '' === $temp || ! $this->valid_identifier( $live ) || ! $this->valid_identifier( $temp ) ) {
                $skipped[] = [ 'live' => $live, 'temp' => $temp, 'reason' => 'invalid_table_name' ];
                continue;
            }
            if ( SelfProtection::is_restorebase_table( $live ) ) {
                $skipped[] = [ 'live' => $live, 'temp' => $temp, 'reason' => 'restorebase_table_protected' ];
                continue;
            }
            if ( ! $this->table_exists( $temp ) ) {
                $skipped[] = [ 'live' => $live, 'temp' => $temp, 'reason' => 'temporary_table_missing' ];
                continue;
            }

            $backup = $this->unique_backup_name( $live, $backup_token, $reserved_backups );
            $entries[] = [
                'live'        => $live,
                'temp'        => $temp,
                'backup'      => $backup,
                'live_exists' => $this->table_exists( $live ),
            ];
        }

        return [ 'entries' => $entries, 'skipped' => $skipped ];
    }

    private function swap_entries_one_by_one( array $entries ): array {
        $renamed = [];
        $errors = [];
        $warnings = [];
        $recovery = [
            'preserved'   => 0,
            'overwritten' => 0,
        ];

        foreach ( $entries as $entry ) {
            $live = (string) $entry['live'];
            $temp = (string) $entry['temp'];
            $backup = (string) $entry['backup'];

            if ( ! $this->table_exists( $temp ) ) {
                if ( $this->table_exists( $live ) ) {
                    $renamed[] = [
                        'live'   => $live,
                        'temp'   => $temp,
                        'backup' => $this->table_exists( $backup ) ? $backup : '',
                        'mode'   => 'already_live',
                    ];
                    $warnings[] = 'Temporary table was no longer present, but the live table exists after fallback check: ' . $live;
                    continue;
                }

                $errors[] = 'Temporary table missing before fallback swap: ' . $temp;
                continue;
            }

            if ( ! empty( $entry['live_exists'] ) && $this->table_exists( $live ) ) {
                $sql = 'RENAME TABLE ' . $this->quote( $live ) . ' TO ' . $this->quote( $backup ) . ', ' . $this->quote( $temp ) . ' TO ' . $this->quote( $live );
                $result = $this->run_query( $sql );
                if ( ! empty( $result['ok'] ) ) {
                    $renamed[] = [
                        'live'   => $live,
                        'temp'   => $temp,
                        'backup' => $this->table_exists( $backup ) ? $backup : '',
                        'mode'   => 'preserved',
                    ];
                    $recovery['preserved']++;
                    continue;
                }

                $warnings[] = $this->compact_sql_error( (string) $result['error'], $sql );
            }

            $replace = $this->replace_live_with_temp( $live, $temp );
            $warnings = array_merge( $warnings, $replace['warnings'] );
            if ( ! empty( $replace['ok'] ) ) {
                $renamed[] = [
                    'live'   => $live,
                    'temp'   => $temp,
                    'backup' => '',
                    'mode'   => 'overwritten',
                ];
                $recovery['overwritten']++;
                continue;
            }

            $errors = array_merge( $errors, $replace['errors'] );
        }

        return [
            'renamed'  => $renamed,
            'errors'   => $errors,
            'warnings' => $warnings,
            'recovery' => $recovery,
        ];
    }

    private function replace_live_with_temp( string $live, string $temp ): array {
        $errors = [];
        $warnings = [];

        if ( ! $this->table_exists( $temp ) ) {
            return [
                'ok'       => false,
                'errors'   => [ 'Temporary table missing before overwrite recovery: ' . $temp ],
                'warnings' => $warnings,
            ];
        }

        if ( $this->table_exists( $live ) ) {
            $drop = $this->force_drop_table( $live );
            $warnings = array_merge( $warnings, $drop['warnings'] );
            if ( empty( $drop['ok'] ) ) {
                return [
                    'ok'       => false,
                    'errors'   => $drop['errors'],
                    'warnings' => $warnings,
                ];
            }
        }

        $sql = 'RENAME TABLE ' . $this->quote( $temp ) . ' TO ' . $this->quote( $live );
        $result = $this->run_query( $sql );
        if ( ! empty( $result['ok'] ) ) {
            return [
                'ok'       => true,
                'errors'   => [],
                'warnings' => $warnings,
            ];
        }

        $errors[] = $this->compact_sql_error( (string) $result['error'], $sql );

        if ( $this->table_exists( $live ) && $this->table_exists( $temp ) ) {
            $drop = $this->force_drop_table( $live );
            $warnings = array_merge( $warnings, $drop['warnings'] );
            if ( ! empty( $drop['ok'] ) ) {
                $retry = $this->run_query( $sql );
                if ( ! empty( $retry['ok'] ) ) {
                    return [
                        'ok'       => true,
                        'errors'   => [],
                        'warnings' => $warnings,
                    ];
                }
                $errors[] = $this->compact_sql_error( (string) $retry['error'], $sql );
            } else {
                $errors = array_merge( $errors, $drop['errors'] );
            }
        }

        return [
            'ok'       => false,
            'errors'   => array_slice( array_values( array_unique( $errors ) ), 0, 5 ),
            'warnings' => $warnings,
        ];
    }

    private function force_drop_table( string $table ): array {
        $warnings = [];
        $errors = [];

        if ( ! $this->table_exists( $table ) ) {
            return [ 'ok' => true, 'errors' => [], 'warnings' => $warnings ];
        }

        $attempts = [
            'DROP TABLE IF EXISTS ' . $this->quote( $table ),
            'DROP VIEW IF EXISTS ' . $this->quote( $table ),
            'ALTER TABLE ' . $this->quote( $table ) . ' DISCARD TABLESPACE',
            'DROP TABLE IF EXISTS ' . $this->quote( $table ),
        ];

        foreach ( $attempts as $sql ) {
            $result = $this->run_query( $sql );
            if ( ! empty( $result['ok'] ) ) {
                $warnings[] = 'Overwrite recovery ran: ' . $sql;
            } else {
                $warnings[] = $this->compact_sql_error( (string) $result['error'], $sql );
            }

            if ( ! $this->table_exists( $table ) ) {
                return [
                    'ok'       => true,
                    'errors'   => [],
                    'warnings' => $warnings,
                ];
            }
        }

        $errors[] = 'Destination table could not be removed before overwrite recovery: ' . $table;
        return [
            'ok'       => false,
            'errors'   => $errors,
            'warnings' => $warnings,
        ];
    }

    private function run_query( string $sql ): array {
        global $wpdb;

        $wpdb->last_error = '';
        $result = $wpdb->query( $sql ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        if ( false === $result ) {
            return [
                'ok'    => false,
                'error' => (string) $wpdb->last_error,
            ];
        }

        return [
            'ok'    => true,
            'error' => '',
        ];
    }

    private function drop_temp_tables( array $map ): void {
        foreach ( $map as $entry ) {
            $temp = isset( $entry['temp'] ) ? (string) $entry['temp'] : '';
            if ( '' !== $temp && $this->valid_identifier( $temp ) ) {
                $this->force_drop_table( $temp );
            }
        }
    }

    private function existing_temp_tables( array $map ): array {
        $tables = [];
        foreach ( $map as $entry ) {
            $temp = isset( $entry['temp'] ) ? (string) $entry['temp'] : '';
            if ( $temp && $this->table_exists( $temp ) ) {
                $tables[] = $temp;
            }
        }
        return $tables;
    }

    private function table_exists( string $table ): bool {
        global $wpdb;

        if ( '' === $table || ! $this->valid_identifier( $table ) ) {
            return false;
        }

        $count = $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM INFORMATION_SCHEMA.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = %s', $table ) );
        if ( is_numeric( $count ) ) {
            return (int) $count > 0;
        }

        $matches = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $wpdb->esc_like( $table ) ) );
        if ( ! is_array( $matches ) ) {
            return false;
        }

        foreach ( $matches as $match ) {
            if ( (string) $match === $table ) {
                return true;
            }
        }

        return false;
    }

    private function unique_backup_name( string $live, string $backup_token, array &$reserved ): string {
        global $wpdb;

        $prefix = isset( $wpdb->prefix ) ? (string) $wpdb->prefix : '';
        $short = $prefix && 0 === strpos( $live, $prefix ) ? substr( $live, strlen( $prefix ) ) : $live;
        return $this->unique_limited_name( $prefix . $backup_token . $short, $live, $reserved, true );
    }

    private function unique_limited_name( string $candidate, string $seed, array &$reserved, bool $must_not_exist = false ): string {
        $candidate = preg_replace( '/[^A-Za-z0-9$_]/', '_', $candidate );
        $candidate = (string) $candidate;
        $hash = '_' . substr( md5( $seed ), 0, 8 );
        if ( strlen( $candidate ) > 64 ) {
            $candidate = substr( $candidate, 0, 64 - strlen( $hash ) ) . $hash;
        }

        $base = $candidate;
        $i = 1;
        while ( isset( $reserved[ $candidate ] ) || ( $must_not_exist && $this->table_exists( $candidate ) ) ) {
            $suffix = '_' . $i;
            $candidate = substr( $base, 0, 64 - strlen( $suffix ) ) . $suffix;
            $i++;
        }

        $reserved[ $candidate ] = true;
        return $candidate;
    }

    private function safe_token( string $token ): string {
        $token = strtolower( preg_replace( '/[^a-zA-Z0-9]/', '', $token ) );
        return '' !== $token ? substr( $token, 0, 12 ) : strtolower( wp_generate_password( 6, false, false ) );
    }

    private function valid_identifier( string $identifier ): bool {
        return '' !== $identifier && strlen( $identifier ) <= 64 && (bool) preg_match( '/^[A-Za-z0-9$_]+$/', $identifier );
    }

    private function compact_sql_error( string $error, string $sql ): string {
        $error = trim( $error );
        $sql = preg_replace( '/\s+/', ' ', trim( $sql ) );
        $sql = substr( (string) $sql, 0, 220 );
        return ( '' !== $error ? $error : 'Unknown MySQL error.' ) . ( '' !== $sql ? ' SQL: ' . $sql : '' );
    }

    private function message_with_first_error( string $message, array $errors ): string {
        $errors = array_values( array_filter( array_map( 'strval', $errors ) ) );
        if ( empty( $errors ) ) {
            return $message;
        }
        return $message . ' First error: ' . substr( $errors[0], 0, 260 );
    }

    private function quote( string $identifier ): string {
        return '`' . str_replace( '`', '``', $identifier ) . '`';
    }
}
