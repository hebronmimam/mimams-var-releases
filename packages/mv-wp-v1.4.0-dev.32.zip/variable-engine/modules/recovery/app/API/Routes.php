<?php

namespace VE\Modules\Recovery\API;

use VE\Modules\Recovery\Agency\AgencyDashboard;
use VE\Modules\Recovery\Emergency\EmergencyRecovery;
use VE\Modules\Recovery\Restore\RollbackManager;
use VE\Modules\Recovery\Restore\RollbackExecutor;
use VE\Modules\Recovery\Restore\RestoreVerifier;
use VE\Modules\Recovery\Schedule\ScheduleManager;
use VE\Modules\Recovery\Storage\RemoteStorageManager;
use VE\Modules\Recovery\WooCommerce\WooSafety;
use VE\Modules\Recovery\Workflow\MigrationPlanner;
use VE\Modules\Recovery\Workflow\StagingWorkflow;
use VE\Modules\Recovery\Backup\PackageBuilder;
use VE\Modules\Recovery\Backup\PackageValidator;
use VE\Modules\Recovery\Backup\SnapshotJob;
use VE\Modules\Recovery\Backup\SnapshotManager;
use VE\Modules\Recovery\Jobs\JobStore;
use VE\Modules\Recovery\Restore\RestoreDryRun;
use VE\Modules\Recovery\Restore\RestorePreparation;
use VE\Modules\Recovery\Restore\RestorePreview;
use VE\Modules\Recovery\Restore\RestoreReadiness;
use VE\Modules\Recovery\Restore\StagingRestoreExecutor;
use VE\Modules\Recovery\Security\Capability;
use VE\Modules\Recovery\Security\SecurityAudit;
use VE\Modules\Recovery\Security\ProductionReadiness;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class Routes {
    public function register(): void {
        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/status', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [ $this, 'status' ],
            'permission_callback' => [ $this, 'permissions' ],
        ] );

        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/snapshots', [
            [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => [ $this, 'snapshots' ],
                'permission_callback' => [ $this, 'permissions' ],
                'args'                => [ 'limit' => [ 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 20 ] ],
            ],
            [
                'methods'             => \WP_REST_Server::CREATABLE,
                'callback'            => [ $this, 'create_snapshot' ],
                'permission_callback' => [ $this, 'permissions' ],
                'args'                => [ 'label' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ] ],
            ],
        ] );

        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/snapshots/(?P<snapshot_key>[a-zA-Z0-9\-_]+)', [
            'methods'             => \WP_REST_Server::DELETABLE,
            'callback'            => [ $this, 'delete_snapshot' ],
            'permission_callback' => [ $this, 'permissions' ],
            'args'                => [
                'snapshot_key' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'required' => true ],
                'delete_files' => [ 'type' => 'boolean', 'default' => true ],
            ],
        ] );

        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/packages', [
            'methods'             => \WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'create_package' ],
            'permission_callback' => [ $this, 'permissions' ],
            'args'                => [ 'label' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ] ],
        ] );

        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/packages/validate', [
            'methods'             => \WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'validate_package' ],
            'permission_callback' => [ $this, 'permissions' ],
            'args'                => [ 'snapshot_key' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
                'passphrase'   => [ 'type' => 'string', 'default' => '' ] ],
        ] );

        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/jobs', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [ $this, 'jobs' ],
            'permission_callback' => [ $this, 'permissions' ],
            'args'                => [ 'limit' => [ 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 20 ] ],
        ] );

        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/logs', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [ $this, 'logs' ],
            'permission_callback' => [ $this, 'permissions' ],
            'args'                => [ 'limit' => [ 'type' => 'integer', 'sanitize_callback' => 'absint', 'default' => 20 ] ],
        ] );

        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/restore-preview', [
            'methods'             => \WP_REST_Server::READABLE,
            'callback'            => [ $this, 'restore_preview' ],
            'permission_callback' => [ $this, 'permissions' ],
            'args'                => [ 'snapshot_key' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
                'passphrase'   => [ 'type' => 'string', 'default' => '' ] ],
        ] );

        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/restore-dry-run', [
            'methods'             => \WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'restore_dry_run' ],
            'permission_callback' => [ $this, 'restore_permissions' ],
            'args'                => [ 'snapshot_key' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
                'passphrase'   => [ 'type' => 'string', 'default' => '' ] ],
        ] );

        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/restore-prepare', [
            'methods'             => \WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'restore_prepare' ],
            'permission_callback' => [ $this, 'permissions' ],
            'args'                => [ 'snapshot_key' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
                'passphrase'   => [ 'type' => 'string', 'default' => '' ] ],
        ] );

        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/restore-readiness', [
            'methods'             => \WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'restore_readiness' ],
            'permission_callback' => [ $this, 'permissions' ],
            'args'                => [ 'snapshot_key' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
                'passphrase'   => [ 'type' => 'string', 'default' => '' ] ],
        ] );

        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/staging-restore/execute', [
            'methods'             => \WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'staging_restore_execute' ],
            'permission_callback' => [ $this, 'restore_permissions' ],
            'args'                => [
                'snapshot_key'  => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
                'confirmation'  => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ],
            ],
        ] );


        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/rollback/dry-run', [
            'methods'             => \WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'rollback_dry_run' ],
            'permission_callback' => [ $this, 'restore_permissions' ],
            'args'                => [ 'confirmation' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ] ],
        ] );

        register_rest_route( VE_RECOVERY_API_NAMESPACE, '/rollback/execute', [
            'methods'             => \WP_REST_Server::CREATABLE,
            'callback'            => [ $this, 'rollback_execute' ],
            'permission_callback' => [ $this, 'restore_permissions' ],
            'args'                => [ 'confirmation' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field', 'default' => '' ] ],
        ] );

        foreach ( [
            '/verify'         => [ $this, 'verify' ],
            '/rollback-plan'  => [ $this, 'rollback_plan' ],
            '/staging-plan'   => [ $this, 'staging_plan' ],
            '/migration-plan' => [ $this, 'migration_plan' ],
            '/remote-storage' => [ $this, 'remote_storage' ],
            '/schedule-plan'  => [ $this, 'schedule_plan' ],
            '/woo-safety'     => [ $this, 'woo_safety' ],
            '/emergency-plan' => [ $this, 'emergency_plan' ],
            '/agency-report'  => [ $this, 'agency_report' ],
            '/security-audit' => [ $this, 'security_audit' ],
            '/production-readiness' => [ $this, 'production_readiness' ],
        ] as $route => $callback ) {
            register_rest_route( VE_RECOVERY_API_NAMESPACE, $route, [
                'methods'             => \WP_REST_Server::READABLE,
                'callback'            => $callback,
                'permission_callback' => [ $this, 'permissions' ],
            ] );
        }

    }


    /** Optional inline passphrase for encrypted packages (not sanitize_text_field'd: symbols must survive). */
    private function request_passphrase( \WP_REST_Request $request ): string {
        return trim( (string) $request->get_param( 'passphrase' ) );
    }

    public function permissions(): bool {
        return Capability::can_manage();
    }

    public function restore_permissions(): bool {
        return Capability::can_restore();
    }

    public function status(): \WP_REST_Response {
        return new \WP_REST_Response( ( new SnapshotManager() )->status(), 200 );
    }

    public function snapshots( \WP_REST_Request $request ): \WP_REST_Response {
        $limit = absint( $request->get_param( 'limit' ) ?: 20 );
        return new \WP_REST_Response( ( new SnapshotManager() )->all( $limit ), 200 );
    }

    public function create_snapshot( \WP_REST_Request $request ): \WP_REST_Response {
        $label = sanitize_text_field( (string) $request->get_param( 'label' ) );
        return new \WP_REST_Response( ( new SnapshotJob() )->create( $label ), 201 );
    }

    public function delete_snapshot( \WP_REST_Request $request ): \WP_REST_Response {
        $snapshot_key = sanitize_text_field( (string) $request->get_param( 'snapshot_key' ) );
        $delete_files = null === $request->get_param( 'delete_files' ) ? true : rest_sanitize_boolean( $request->get_param( 'delete_files' ) );
        return new \WP_REST_Response( ( new SnapshotManager() )->delete( $snapshot_key, (bool) $delete_files ), 200 );
    }

    public function create_package( \WP_REST_Request $request ): \WP_REST_Response {
        $label = sanitize_text_field( (string) $request->get_param( 'label' ) );
        return new \WP_REST_Response( ( new PackageBuilder() )->create( $label ), 201 );
    }

    public function validate_package( \WP_REST_Request $request ): \WP_REST_Response {
        $snapshot_key = sanitize_text_field( (string) $request->get_param( 'snapshot_key' ) );
        return new \WP_REST_Response( ( new PackageValidator() )->validate_snapshot( $snapshot_key, $this->request_passphrase( $request ) ), 200 );
    }

    public function jobs( \WP_REST_Request $request ): \WP_REST_Response {
        $limit = absint( $request->get_param( 'limit' ) ?: 20 );
        return new \WP_REST_Response( ( new JobStore() )->all( $limit ), 200 );
    }

    public function logs( \WP_REST_Request $request ): \WP_REST_Response {
        $limit = absint( $request->get_param( 'limit' ) ?: 20 );
        return new \WP_REST_Response( Logger::latest( $limit ), 200 );
    }

    public function restore_preview( \WP_REST_Request $request ): \WP_REST_Response {
        $snapshot_key = sanitize_text_field( (string) $request->get_param( 'snapshot_key' ) );
        return new \WP_REST_Response( ( new RestorePreview() )->preview_snapshot( $snapshot_key ), 200 );
    }

    public function restore_dry_run( \WP_REST_Request $request ): \WP_REST_Response {
        $snapshot_key = sanitize_text_field( (string) $request->get_param( 'snapshot_key' ) );
        return new \WP_REST_Response( ( new RestoreDryRun() )->run( $snapshot_key, $this->request_passphrase( $request ) ), 200 );
    }

    public function restore_prepare( \WP_REST_Request $request ): \WP_REST_Response {
        $snapshot_key = sanitize_text_field( (string) $request->get_param( 'snapshot_key' ) );
        return new \WP_REST_Response( ( new RestorePreparation() )->prepare( $snapshot_key ), 200 );
    }

    public function restore_readiness( \WP_REST_Request $request ): \WP_REST_Response {
        $snapshot_key = sanitize_text_field( (string) $request->get_param( 'snapshot_key' ) );
        return new \WP_REST_Response( ( new RestoreReadiness() )->assess( $snapshot_key, [], $this->request_passphrase( $request ) ), 200 );
    }

    public function staging_restore_execute( \WP_REST_Request $request ): \WP_REST_Response {
        $snapshot_key = sanitize_text_field( (string) $request->get_param( 'snapshot_key' ) );
        $confirmation = sanitize_text_field( (string) $request->get_param( 'confirmation' ) );
        return new \WP_REST_Response( ( new StagingRestoreExecutor() )->execute( $snapshot_key, $confirmation ), 200 );
    }

    public function verify(): \WP_REST_Response {
        return new \WP_REST_Response( ( new RestoreVerifier() )->verify(), 200 );
    }

    public function rollback_plan(): \WP_REST_Response {
        return new \WP_REST_Response( ( new RollbackManager() )->plan(), 200 );
    }

    public function rollback_dry_run( \WP_REST_Request $request ): \WP_REST_Response {
        $confirmation = sanitize_text_field( (string) $request->get_param( 'confirmation' ) );
        return new \WP_REST_Response( ( new RollbackExecutor() )->dry_run( $confirmation ), 200 );
    }

    public function rollback_execute( \WP_REST_Request $request ): \WP_REST_Response {
        $confirmation = sanitize_text_field( (string) $request->get_param( 'confirmation' ) );
        return new \WP_REST_Response( ( new RollbackExecutor() )->execute( $confirmation ), 200 );
    }

    public function staging_plan(): \WP_REST_Response {
        return new \WP_REST_Response( ( new StagingWorkflow() )->plan(), 200 );
    }

    public function migration_plan(): \WP_REST_Response {
        return new \WP_REST_Response( ( new MigrationPlanner() )->plan(), 200 );
    }

    public function remote_storage(): \WP_REST_Response {
        return new \WP_REST_Response( ( new RemoteStorageManager() )->plan(), 200 );
    }

    public function schedule_plan(): \WP_REST_Response {
        return new \WP_REST_Response( ( new ScheduleManager() )->plan(), 200 );
    }

    public function woo_safety(): \WP_REST_Response {
        return new \WP_REST_Response( ( new WooSafety() )->report(), 200 );
    }

    public function emergency_plan(): \WP_REST_Response {
        return new \WP_REST_Response( ( new EmergencyRecovery() )->plan(), 200 );
    }

    public function agency_report(): \WP_REST_Response {
        return new \WP_REST_Response( ( new AgencyDashboard() )->report(), 200 );
    }

    public function security_audit(): \WP_REST_Response {
        return new \WP_REST_Response( ( new SecurityAudit() )->report(), 200 );
    }

    public function production_readiness(): \WP_REST_Response {
        return new \WP_REST_Response( ( new ProductionReadiness() )->report(), 200 );
    }

}
