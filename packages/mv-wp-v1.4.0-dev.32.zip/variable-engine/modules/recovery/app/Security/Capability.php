<?php

namespace VE\Modules\Recovery\Security;

defined( 'ABSPATH' ) || exit;

final class Capability {
    public static function manage_capability(): string {
        return (string) apply_filters( 'restorebase_manage_capability', 'manage_options' );
    }

    /**
     * Capability required for destructive actions (restore, rollback, staging swap).
     * Restoring can replace the database and executable code, so it follows the
     * core-update boundary rather than the broader options-management boundary.
     */
    public static function restore_capability(): string {
        return (string) apply_filters( 'restorebase_restore_capability', 'update_core' );
    }

    public static function can_manage(): bool {
        return current_user_can( self::manage_capability() );
    }

    public static function can_restore(): bool {
        if ( is_multisite() && ! is_super_admin() ) {
            return false;
        }
        return current_user_can( self::restore_capability() );
    }
}
