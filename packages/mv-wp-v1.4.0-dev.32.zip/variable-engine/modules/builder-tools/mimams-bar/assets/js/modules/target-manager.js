(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarTargetManager) return;

  function refresh(app, options) {
    if (!app || !app.target) return;
    options = options || {};
    var element = app.adapter.getSelectedElement();
    var nextId = element && element.id ? String(element.id) : '';

    /* Editing a class makes Bricks rebuild the element, and for a frame or two
       in the middle of that the selection reads as nothing at all. Taking that
       at face value emptied the class and attribute rows, which then refilled
       themselves a moment later with exactly what had been there — the flicker
       in the report. A selection that has just gone empty is treated as "not
       settled yet": the rows are left alone and looked at again shortly. Only a
       re-check that still finds nothing clears them, so a real deselection
       still empties the bar. */
    if (!element && app._lastKnownTargetId && !options.settled) {
      if (app._targetSettleTimer) window.clearTimeout(app._targetSettleTimer);
      app._targetSettleTimer = window.setTimeout(function () {
        app._targetSettleTimer = null;
        refresh(app, { settled: true });
      }, 140);
      return;
    }
    if (app._targetSettleTimer) {
      window.clearTimeout(app._targetSettleTimer);
      app._targetSettleTimer = null;
    }

    if (options.light && nextId === app._lastKnownTargetId) return;
    app._lastKnownTargetId = nextId;

    app.target.textContent = app.adapter.getElementLabel(element);
    app.target.setAttribute('title', app.adapter.getElementFullLabel(element));
    app.target.classList.toggle('is-empty', !element);
    renderIdentity(app, element);
    renderExistingAttributes(app, element);
  }

  function renderIdentity(app, element) {
    app.renderer.renderIdentity(app.identityList, element, app.adapter, {
      loadTextCommand: app.loadTextCommand.bind(app),
      deleteClass: function (className) {
        var parseResult = app.parser.parse('-' + className);
        if (parseResult.ok) {
          app.applyOperations(parseResult.ops || parseResult.attrs);
        }
      },
      renameClass: function (oldName, newName) {
        if (!newName || newName === oldName) return;
        var parseResult = app.parser.parse('.' + oldName + ' -> .' + newName);
        if (parseResult.ok) {
          app._pendingTokenFocus = { kind: 'class', key: newName };
          app.applyOperations(parseResult.ops || parseResult.attrs);
        }
      },
      duplicateClass: function (className) {
        if (!app.adapter || typeof app.adapter.duplicateGlobalClass !== 'function') return;
        var newName = app.adapter.duplicateGlobalClass(className);
        if (!newName) return;
        // Add the cloned class (styles copied) to the current element; the refresh renders
        // its chip so it's there to rename/edit.
        var parseResult = app.parser.parse('.' + newName);
        if (parseResult.ok) {
          app.applyOperations(parseResult.ops || parseResult.attrs);
        }
      },
      setId: function (newId) {
        if (!newId) return;
        var parseResult = app.parser.parse('#' + newId);
        if (parseResult.ok) {
          app._pendingTokenFocus = { kind: 'id', key: newId };
          app.applyOperations(parseResult.ops || parseResult.attrs);
        }
      },
      clearId: function () {
        app.applyOperations([ { type: 'set-id', value: '' } ]);
      }
    });
  }

  function toggleAttributesPanel(app) {
    app.attrsExpanded = !app.attrsExpanded;
    updateAttributesPanelState(app);
  }

  function updateAttributesPanelState(app) {
    if (!app.existingBox) return;
    app.existingBox.classList.toggle('is-collapsed', !app.attrsExpanded);
    if (app.attrToggleLabel) app.attrToggleLabel.textContent = app.attrsExpanded ? 'Hide' : 'Show';
  }

  function renderExistingAttributes(app, element) {
    if (!app.attrList) return;

    var result = app.renderer.renderExistingAttributes({
      list: app.attrList,
      element: element,
      adapter: app.adapter,
      callbacks: {
        loadAttributeCommand: app.loadAttributeCommand.bind(app),
        deleteAttribute: function (attr) {
          var command = 'delete ' + attr.name;
          var parseResult = app.parser.parse(command);
          if (parseResult.ok) {
            app.applyOperations(parseResult.ops || parseResult.attrs);
          }
        },
        editAttribute: function (attr, newValue) {
          var esc = String(newValue == null ? '' : newValue).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
          var command = attr.name + '="' + esc + '"';
          var parseResult = app.parser.parse(command);
          if (parseResult.ok) {
            app._pendingTokenFocus = { kind: 'attribute', key: attr.name };
            app.applyOperations(parseResult.ops || parseResult.attrs);
          }
        },
        toggleSavedAttribute: function (attr, star) {
          var manager = app.savedAttributes || window.MimamsBarSavedAttributes;
          if (!manager || typeof manager.toggle !== 'function') return;
          var wasSaved = typeof manager.isSaved === 'function' && manager.isSaved(attr.name);
          manager.toggle(attr.name, attr.value).then(function () {
            if (star && star.classList) {
              star.classList.toggle('is-saved', !wasSaved);
              star.setAttribute('title', wasSaved ? 'Save this attribute and value' : 'Remove from saved attributes');
            }
            if (app.toast && typeof app.toast.show === 'function') {
              app.toast.show(attr.name + (wasSaved ? ' removed from saved attributes.' : ' saved for this site.'));
            }
          }).catch(function (error) {
            if (app.toast && typeof app.toast.show === 'function') {
              app.toast.show(error && error.message ? error.message : 'Saved attributes could not be updated.', 'error');
            }
          });
        }
      }
    });

    if (app.attrCount) app.attrCount.textContent = String((result && result.count) || 0);
    if (result && result.collapse) app.attrsExpanded = false;
    updateAttributesPanelState(app);
  }

  function scheduleRefresh(app) {
    if (!app) return;

    // v1.2.48: keep refreshes light while the bar is open. The old flow
    // scheduled three separate refresh passes for every canvas click, which
    // could stack up in Bricks and make the builder feel frozen.
    if (app._targetRefreshTimer) {
      window.clearTimeout(app._targetRefreshTimer);
    }

    app._targetRefreshTimer = window.setTimeout(function () {
      app._targetRefreshTimer = null;
      refresh(app, { light: true });
    }, 260);
  }

  window.MimamsBarTargetManager = {
    refresh: refresh,
    renderIdentity: renderIdentity,
    renderExistingAttributes: renderExistingAttributes,
    toggleAttributesPanel: toggleAttributesPanel,
    updateAttributesPanelState: updateAttributesPanelState,
    scheduleRefresh: scheduleRefresh
  };
})();
