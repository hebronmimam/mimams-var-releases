<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

class DependencyGraph {

    /**
     * Register a dependency relationship.
     */
    public function register( int $parent_id, int $child_id, string $relation = 'generated' ): bool {
        global $wpdb;
        $table = Schema::table( 'dependencies' );

        // Avoid duplicates.
        $exists = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table} WHERE parent_id = %d AND child_id = %d",
            $parent_id,
            $child_id
        ) );

        if ( $exists ) {
            return true;
        }

        return (bool) $wpdb->insert( $table, [
            'parent_id' => $parent_id,
            'child_id'  => $child_id,
            'relation'  => $relation,
        ] );
    }

    /**
     * Remove a specific dependency.
     */
    public function remove( int $parent_id, int $child_id ): bool {
        global $wpdb;
        return (bool) $wpdb->delete( Schema::table( 'dependencies' ), [
            'parent_id' => $parent_id,
            'child_id'  => $child_id,
        ] );
    }

    /**
     * Get all variables that depend on $variable_id (children).
     */
    public function get_dependents( int $variable_id ): array {
        global $wpdb;
        $dep_table = Schema::table( 'dependencies' );
        $var_table = Schema::table( 'variables' );

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT v.*, d.relation
             FROM {$dep_table} d
             JOIN {$var_table} v ON v.id = d.child_id
             WHERE d.parent_id = %d
             ORDER BY v.name ASC",
            $variable_id
        ), ARRAY_A ) ?: [];
    }

    /**
     * Get all variables that $variable_id depends on (parents).
     */
    public function get_dependencies( int $variable_id ): array {
        global $wpdb;
        $dep_table = Schema::table( 'dependencies' );
        $var_table = Schema::table( 'variables' );

        return $wpdb->get_results( $wpdb->prepare(
            "SELECT v.*, d.relation
             FROM {$dep_table} d
             JOIN {$var_table} v ON v.id = d.parent_id
             WHERE d.child_id = %d
             ORDER BY v.name ASC",
            $variable_id
        ), ARRAY_A ) ?: [];
    }

    /**
     * Build a full impact tree for a variable (recursive).
     * Returns nested array: [ variable => ..., children => [ ... ] ]
     */
    public function get_impact_tree( int $variable_id, int $depth = 0, int $max_depth = 5 ): array {
        if ( $depth >= $max_depth ) {
            return [];
        }

        $var_manager = new VariableManager();
        $variable    = $var_manager->get( $variable_id );
        if ( ! $variable ) {
            return [];
        }

        $dependents = $this->get_dependents( $variable_id );
        $children   = [];

        foreach ( $dependents as $dep ) {
            $children[] = $this->get_impact_tree( (int) $dep['id'], $depth + 1, $max_depth );
        }

        return [
            'variable' => $variable,
            'children' => $children,
        ];
    }
}
