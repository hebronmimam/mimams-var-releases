<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

class VariableManager {

    // ── Reserved namespaces from V0.4 spec ─────────────────────────────
    private const RESERVED_NS = [
        'color', 'space', 'font', 'radius', 'shadow',
        'motion', 'opacity', 'breakpoint', 'size',
        'heading', 'text', 'grid',
    ];

    // ── Naming regex: lowercase, dot-separated, no spaces ──────────────
    public const NAME_PATTERN = '/^[a-z][a-z0-9]*(\.[a-z0-9][a-z0-9]*)*$/';

    /* ================================================================
     *  CREATE
     * ================================================================ */
    public function create( array $data ) {
        global $wpdb;
        $table = Schema::table( 'variables' );

        // Validate & sanitise.
        $prepared = $this->validate( $data );
        if ( is_wp_error( $prepared ) ) {
            return $prepared;
        }

        // Derive namespace from first segment.
        $prepared['namespace'] = explode( '.', $prepared['name'] )[0];

        // Compile CSS value.
        $prepared['css_value'] = $this->compile_css_value( $prepared );

        $inserted = $wpdb->insert( $table, [
            'name'           => $prepared['name'],
            'type'           => $prepared['type'],
            'namespace'      => $prepared['namespace'],
            'value'          => $prepared['value'],
            'css_value'      => $prepared['css_value'],
            'source_id'      => $prepared['source_id'] ?? null,
            'generator_type' => $prepared['generator_type'] ?? null,
        ], [ '%s', '%s', '%s', '%s', '%s', '%d', '%s' ] );

        if ( false === $inserted ) {
            return new \WP_Error( 've_create_failed', $wpdb->last_error, [ 'status' => 500 ] );
        }

        $id  = (int) $wpdb->insert_id;
        $var = $this->get( $id );

        // Register explicit parent/child relationships for imported dependents.
        if ( ! empty( $prepared['source_id'] ) && in_array( $prepared['type'], [ 'alias', 'generated' ], true ) ) {
            ( new DependencyGraph() )->register( (int) $prepared['source_id'], $id, $prepared['type'] );
        }

        // Re-export CSS.
        ( new CssExporter() )->export();

        return $var;
    }

    /* ================================================================
     *  READ
     * ================================================================ */
    public function get( int $id ): ?array {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'variables' ) . ' WHERE id = %d', $id ),
            ARRAY_A
        );
        return $row ?: null;
    }

    public function get_by_name( string $name ): ?array {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'variables' ) . ' WHERE name = %s', $name ),
            ARRAY_A
        );
        return $row ?: null;
    }

    public function get_all( array $args = [] ): array {
        global $wpdb;
        $table = Schema::table( 'variables' );
        $where = [];
        $vals  = [];

        if ( ! empty( $args['namespace'] ) ) {
            $where[] = 'namespace = %s';
            $vals[]  = $args['namespace'];
        }
        if ( ! empty( $args['type'] ) ) {
            $where[] = 'type = %s';
            $vals[]  = $args['type'];
        }

        $sql = "SELECT * FROM {$table}";
        if ( $where ) {
            $sql .= ' WHERE ' . implode( ' AND ', $where );
        }
        $sql .= ' ORDER BY namespace ASC, name ASC';

        if ( $vals ) {
            $sql = $wpdb->prepare( $sql, ...$vals );
        }

        return $wpdb->get_results( $sql, ARRAY_A ) ?: [];
    }

    /**
     * Recompile css_value for every fluid variable.
     *
     * Called when the global viewport settings change, since a fluid
     * variable's clamp() output depends on vw_min / vw_max. Runs a single
     * CSS export at the end rather than one per variable.
     *
     * @return int Number of fluid variables recompiled.
     */
    public function recompile_fluid(): int {
        global $wpdb;
        $table = Schema::table( 'variables' );
        $rows  = $wpdb->get_results( "SELECT id, value FROM {$table}", ARRAY_A ) ?: [];

        $count = 0;
        foreach ( $rows as $row ) {
            if ( ! FluidValue::is_fluid( (string) $row['value'] ) ) {
                continue;
            }
            $new_css = FluidValue::compile( (string) $row['value'], 'rem' );
            $wpdb->update(
                $table,
                [ 'css_value' => $new_css ],
                [ 'id' => (int) $row['id'] ],
                [ '%s' ],
                [ '%d' ]
            );
            $count++;
        }

        if ( $count > 0 ) {
            ( new CssExporter() )->export();
        }
        return $count;
    }

    /* ================================================================
     *  SEARCH (fuzzy — LIKE-based for MVP, upgrade to full-text later)
     * ================================================================ */
    public function search( string $query, int $limit = 50 ): array {
        global $wpdb;
        $table = Schema::table( 'variables' );
        $like  = '%' . $wpdb->esc_like( $query ) . '%';

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE name LIKE %s ORDER BY name ASC LIMIT %d",
                $like,
                $limit
            ),
            ARRAY_A
        ) ?: [];
    }

    /* ================================================================
     *  UPDATE
     * ================================================================ */
    public function update( int $id, array $data ) {
        global $wpdb;
        $table    = Schema::table( 'variables' );
        $existing = $this->get( $id );

        if ( ! $existing ) {
            return new \WP_Error( 've_not_found', 'Variable not found.', [ 'status' => 404 ] );
        }

        // Generated variables cannot be edited directly.
        if ( 'generated' === $existing['type'] ) {
            return new \WP_Error( 've_locked', 'Generated variables cannot be edited directly. Update the base variable.', [ 'status' => 403 ] );
        }

        $update = [];

        // Name change.
        if ( isset( $data['name'] ) && $data['name'] !== $existing['name'] ) {
            if ( ! preg_match( self::NAME_PATTERN, $data['name'] ) ) {
                return new \WP_Error( 've_invalid_name', 'Variable names must be lowercase, dot-separated.', [ 'status' => 400 ] );
            }
            $update['name']      = sanitize_text_field( $data['name'] );
            $update['namespace'] = explode( '.', $update['name'] )[0];
        }

        // Value change.
        if ( isset( $data['value'] ) ) {
            $update['value']     = $this->normalize_value_for_name( $existing['name'], sanitize_text_field( $data['value'] ) );
            $merged              = array_merge( $existing, $update );
            if ( isset( $update['name'] ) ) {
                $update['value'] = $this->normalize_value_for_name( $update['name'], $update['value'] );
                $merged['value'] = $update['value'];
            }
            $update['css_value'] = $this->compile_css_value( $merged );
        }

        if ( empty( $update ) ) {
            return $existing;
        }

        $wpdb->update( $table, $update, [ 'id' => $id ] );

        // Regenerate dependent generated variables when the value OR name changes.
        // Name changes alter generated token names/CSS names too, e.g.
        // font.space → size.space should rebuild --font-* into --size-*.
        if ( isset( $update['value'] ) || isset( $update['name'] ) ) {
            ( new GeneratorEngine() )->regenerate( $id );
        }

        // Re-export CSS.
        ( new CssExporter() )->export();

        return $this->get( $id );
    }

    /* ================================================================
     *  DELETE
     * ================================================================ */
    public function delete( int $id, bool $force = false ) {
        global $wpdb;
        $table    = Schema::table( 'variables' );
        $existing = $this->get( $id );

        if ( ! $existing ) {
            return new \WP_Error( 've_not_found', 'Variable not found.', [ 'status' => 404 ] );
        }

        // Check dependents.
        $deps = ( new DependencyGraph() )->get_dependents( $id );
        if ( ! empty( $deps ) && ! $force ) {
            return new \WP_Error(
                've_has_dependents',
                'This variable has dependents. Resolve them first or pass force=true.',
                [ 'status' => 409, 'dependents' => $deps ]
            );
        }

        $dep_table = Schema::table( 'dependencies' );
        $gen_table = Schema::table( 'generators' );

        // CASCADE: Delete all generated children first.
        if ( ! empty( $deps ) ) {
            foreach ( $deps as $dep ) {
                $child_id = (int) $dep['id'];
                $wpdb->delete( $dep_table, [ 'parent_id' => $child_id ] );
                $wpdb->delete( $dep_table, [ 'child_id' => $child_id ] );
                $wpdb->delete( $table, [ 'id' => $child_id ] );
            }
        }

        // Remove dependency records for this variable.
        $wpdb->delete( $dep_table, [ 'parent_id' => $id ] );
        $wpdb->delete( $dep_table, [ 'child_id' => $id ] );

        // Remove generator records.
        $wpdb->delete( $gen_table, [ 'variable_id' => $id ] );

        // Delete the variable itself.
        $wpdb->delete( $table, [ 'id' => $id ] );

        // Re-export CSS.
        ( new CssExporter() )->export();

        return true;
    }

    /* ================================================================
     *  VALIDATION
     * ================================================================ */
    private function validate( array $data ) {
        // Name is required.
        if ( empty( $data['name'] ) ) {
            return new \WP_Error( 've_missing_name', 'Variable name is required.', [ 'status' => 400 ] );
        }

        $name = sanitize_text_field( $data['name'] );

        if ( ! preg_match( self::NAME_PATTERN, $name ) ) {
            return new \WP_Error(
                've_invalid_name',
                'Variable names must be lowercase, dot-separated segments (e.g. color.primary).',
                [ 'status' => 400 ]
            );
        }

        // Check uniqueness.
        if ( $this->get_by_name( $name ) ) {
            return new \WP_Error( 've_duplicate', "Variable '{$name}' already exists.", [ 'status' => 409 ] );
        }

        $raw_type = isset( $data['type'] ) ? $data['type'] : 'base';
        $type = in_array( $raw_type, [ 'base', 'generated', 'alias' ], true )
            ? $raw_type
            : 'base';

        return [
            'name'           => $name,
            'type'           => $type,
            'value'          => $this->normalize_value_for_name( $name, sanitize_text_field( $data['value'] ?? '' ) ),
            'source_id'      => isset( $data['source_id'] ) ? absint( $data['source_id'] ) : null,
            'generator_type' => isset( $data['generator_type'] ) ? sanitize_text_field( $data['generator_type'] ) : null,
        ];
    }

    /* ================================================================
     *  CSS VALUE COMPILATION
     * ================================================================ */
    private function compile_css_value( array $var ): string {
        // For alias types, output var() reference.
        if ( 'alias' === $var['type'] && ! empty( $var['source_id'] ) ) {
            $source = $this->get( (int) $var['source_id'] );
            if ( $source ) {
                $css_name = $this->to_css_name( $source['name'] );
                return "var({$css_name})";
            }
        }

        // Fluid variables store a "fluid:min,max" marker — compile it to clamp().
        if ( FluidValue::is_fluid( (string) $var['value'] ) ) {
            return FluidValue::compile( (string) $var['value'], 'rem' );
        }

        // For base / generated, the value is used directly.
        return $var['value'];
    }



    /**
     * Numeric dimension tokens use the user's 10px rem system.
     * Example: space.20 = --space-20 = 20px = 2rem.
     * This keeps Figma FLOAT values and simple numeric inputs aligned with CSS rem output.
     */
    public function normalize_value_for_name( string $name, string $value ): string {
        $parts = explode( '.', $name );
        $ns    = $parts[0] ?? '';

        $dimension_namespaces = [ 'space', 'radius', 'heading', 'text', 'grid', 'font', 'size' ];
        if ( ! in_array( $ns, $dimension_namespaces, true ) ) {
            return $value;
        }

        $value = trim( $value );
        if ( $value === '' || stripos( $value, 'clamp(' ) !== false || stripos( $value, 'var(' ) !== false || FluidValue::is_fluid( $value ) ) {
            return $value;
        }

        if ( preg_match( '/^-?\d+(?:\.\d+)?$/', $value ) ) {
            return rtrim( rtrim( (string) round( (float) $value / 10, 4 ), '0' ), '.' ) . 'rem';
        }

        if ( preg_match( '/^(-?\d+(?:\.\d+)?)px$/i', $value, $m ) ) {
            return rtrim( rtrim( (string) round( (float) $m[1] / 10, 4 ), '0' ), '.' ) . 'rem';
        }

        return $value;
    }

    /**
     * Convert dot-notation name to CSS custom property name.
     *
     * Some namespaces are storage/category wrappers, not public token families.
     * Example: size.space should export as --space, not --size-space.
     * Generated children already use the public family name, e.g. space.20 → --space-20.
     */
    public function to_css_name( string $name ): string {
        $parts = array_values( array_filter( explode( '.', $name ), static fn( $p ) => '' !== $p ) );
        $storage_wrappers = [ 'size', 'font', 'typography' ];

        if ( count( $parts ) > 1 && in_array( $parts[0], $storage_wrappers, true ) ) {
            array_shift( $parts );
        }

        return '--' . str_replace( '.', '-', implode( '.', $parts ) );
    }
}
