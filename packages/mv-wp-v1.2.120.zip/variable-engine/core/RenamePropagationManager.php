<?php
namespace VE\Core;
defined( 'ABSPATH' ) || exit;

class RenamePropagationManager {
    private array $mappings = [];

    public function __construct( array $mappings = [] ) {
        foreach ( $mappings as $m ) {
            if ( empty( $m['old'] ) || empty( $m['new'] ) || $m['old'] === $m['new'] ) continue;
            $this->mappings[] = [ 'old' => (string) $m['old'], 'new' => (string) $m['new'] ];
        }
    }

    public static function css_mapping_for_names( string $old_name, string $new_name ): array {
        $vm = new VariableManager();
        return [ 'old' => $vm->to_css_name( $old_name ), 'new' => $vm->to_css_name( $new_name ) ];
    }

    public function preview(): array { return $this->scan_preview(); }
    public function apply(): array { return $this->scan( true ); }

    /**
     * Fast/safe preview scanner.
     *
     * Preview must never deserialize/update stored builder data. Older versions used
     * the same deep scanner for preview and apply, which could trigger a fatal error
     * when a stored meta/option value contained incompatible serialized objects.
     * This method only reads raw strings and counts simple token references.
     */
    private function scan_preview(): array {
        global $wpdb;

        $sum = [
            'mappings'        => $this->mappings,
            'total_matches'   => 0,
            'updated_records' => 0,
            'locations'       => [],
            'preview_only'    => true,
        ];

        if ( empty( $this->mappings ) ) {
            return $sum;
        }

        $this->scan_preview_table(
            $sum,
            $wpdb->posts,
            'post_content',
            'ID',
            "ID,post_type,post_title,post_content",
            function ( array $r ): string {
                return trim( ( $r['post_type'] ?? 'post' ) . ': ' . ( $r['post_title'] ?? '' ) );
            },
            'post_content',
            250
        );

        $this->scan_preview_table(
            $sum,
            $wpdb->postmeta,
            'meta_value',
            'meta_id',
            "meta_id,post_id,meta_key,meta_value",
            function ( array $r ): string {
                return ( $r['meta_key'] ?? 'meta' ) . ' / post ' . (int) ( $r['post_id'] ?? 0 );
            },
            'post_meta',
            500
        );

        $option_filter = "(option_name LIKE 'bricks_%' OR option_name LIKE '_bricks_%' OR option_name LIKE 'theme_mods_%' OR option_name LIKE '%custom_css%')";
        $this->scan_preview_table(
            $sum,
            $wpdb->options,
            'option_value',
            'option_id',
            "option_id,option_name,option_value",
            function ( array $r ): string {
                return (string) ( $r['option_name'] ?? 'option' );
            },
            'option',
            200,
            $option_filter
        );

        return $sum;
    }

    private function scan_preview_table( array &$sum, string $table, string $value_col, string $id_col, string $select, callable $label_cb, string $type, int $limit, string $extra_where = '' ): void {
        global $wpdb;

        try {
            $where = $this->like_where( $value_col );
            if ( ! $where ) {
                return;
            }

            if ( $extra_where ) {
                $where = "({$extra_where}) AND ({$where})";
            }

            $limit = max( 1, min( 1000, (int) $limit ) );
            $rows  = $wpdb->get_results( "SELECT {$select} FROM {$table} WHERE {$where} LIMIT {$limit}", ARRAY_A );

            foreach ( (array) $rows as $r ) {
                $raw = (string) ( $r[ $value_col ] ?? '' );

                // Avoid heavy memory usage on very large builder payloads during preview.
                if ( strlen( $raw ) > 1500000 ) {
                    $sum['locations'][] = [
                        'type'    => $type,
                        'id'      => (int) ( $r[ $id_col ] ?? 0 ),
                        'label'   => call_user_func( $label_cb, $r ),
                        'matches' => 1,
                        'note'    => 'Large stored value; exact count skipped in preview.',
                    ];
                    $sum['total_matches'] += 1;
                    continue;
                }

                $this->replace_string( $raw, $c );
                if ( $c > 0 ) {
                    $sum['total_matches'] += $c;
                    $sum['locations'][] = [
                        'type'    => $type,
                        'id'      => (int) ( $r[ $id_col ] ?? 0 ),
                        'label'   => call_user_func( $label_cb, $r ),
                        'matches' => $c,
                    ];
                }
            }
        } catch ( \Throwable $e ) {
            $sum['warnings'][] = ucfirst( str_replace( '_', ' ', $type ) ) . ' preview skipped: ' . $e->getMessage();
        }
    }

    private function scan( bool $apply = false ): array {
        global $wpdb;
        $sum = [ 'mappings' => $this->mappings, 'total_matches' => 0, 'updated_records' => 0, 'locations' => [] ];
        if ( empty( $this->mappings ) ) return $sum;

        try {
            $where = $this->like_where( 'post_content' );
            if ( $where ) {
                $rows = $wpdb->get_results( "SELECT ID,post_type,post_title,post_content FROM {$wpdb->posts} WHERE {$where} LIMIT 250", ARRAY_A );
                foreach ( (array) $rows as $r ) {
                    $new = $this->replace_string( (string) ( $r['post_content'] ?? '' ), $c );
                    if ( $c > 0 ) {
                        $sum['total_matches'] += $c;
                        $sum['locations'][] = [ 'type' => 'post_content', 'id' => (int) $r['ID'], 'label' => trim( ( $r['post_type'] ?? 'post' ) . ': ' . ( $r['post_title'] ?? '' ) ), 'matches' => $c ];
                        if ( $apply ) { $wpdb->update( $wpdb->posts, [ 'post_content' => $new ], [ 'ID' => (int) $r['ID'] ] ); $sum['updated_records']++; }
                    }
                }
            }
        } catch ( \Throwable $e ) {
            $sum['warnings'][] = 'Post content scan skipped: ' . $e->getMessage();
        }

        try {
            $where = $this->like_where( 'meta_value' );
            if ( $where ) {
                $rows = $wpdb->get_results( "SELECT meta_id,post_id,meta_key,meta_value FROM {$wpdb->postmeta} WHERE {$where} LIMIT 500", ARRAY_A );
                foreach ( (array) $rows as $r ) {
                    $new = $this->replace_maybe_serialized( $r['meta_value'] ?? '', $c );
                    if ( $c > 0 ) {
                        $sum['total_matches'] += $c;
                        $sum['locations'][] = [ 'type' => 'post_meta', 'id' => (int) $r['meta_id'], 'label' => ( $r['meta_key'] ?? 'meta' ) . ' / post ' . (int) $r['post_id'], 'matches' => $c ];
                        if ( $apply ) { update_metadata_by_mid( 'post', (int) $r['meta_id'], $new ); $sum['updated_records']++; }
                    }
                }
            }
        } catch ( \Throwable $e ) {
            $sum['warnings'][] = 'Post meta scan skipped: ' . $e->getMessage();
        }

        try {
            $where = $this->like_where( 'option_value' );
            if ( $where ) {
                $filter = "(option_name LIKE 'bricks_%' OR option_name LIKE '_bricks_%' OR option_name LIKE 'theme_mods_%' OR option_name LIKE '%custom_css%')";
                $rows = $wpdb->get_results( "SELECT option_id,option_name,option_value FROM {$wpdb->options} WHERE {$filter} AND {$where} LIMIT 200", ARRAY_A );
                foreach ( (array) $rows as $r ) {
                    $new = $this->replace_maybe_serialized( $r['option_value'] ?? '', $c );
                    if ( $c > 0 ) {
                        $sum['total_matches'] += $c;
                        $sum['locations'][] = [ 'type' => 'option', 'id' => (int) $r['option_id'], 'label' => $r['option_name'], 'matches' => $c ];
                        if ( $apply ) { update_option( $r['option_name'], $new ); $sum['updated_records']++; }
                    }
                }
            }
        } catch ( \Throwable $e ) {
            $sum['warnings'][] = 'Options scan skipped: ' . $e->getMessage();
        }

        return $sum;
    }

    private function like_where( string $col ): string {
        global $wpdb;
        $parts = [];
        foreach ( $this->mappings as $m ) {
            $parts[] = $wpdb->prepare( "{$col} LIKE %s", '%' . $wpdb->esc_like( $m['old'] ) . '%' );
        }
        return implode( ' OR ', $parts );
    }

    private function replace_string( string $v, ?int &$count = 0 ): string {
        $count = 0;
        $out   = $v;
        foreach ( $this->mappings as $m ) {
            $c   = 0;
            $out = str_replace( $m['old'], $m['new'], $out, $c );
            $count += $c;
        }
        return $out;
    }

    private function replace_maybe_serialized( $v, ?int &$count = 0 ) {
        $count = 0;
        if ( is_serialized( $v ) ) return $this->replace_recursive( maybe_unserialize( $v ), $count );
        return $this->replace_string( (string) $v, $count );
    }

    private function replace_recursive( $v, ?int &$count = 0 ) {
        if ( is_string( $v ) ) return $this->replace_string( $v, $count );
        if ( is_array( $v ) ) {
            $t = 0;
            foreach ( $v as $k => $x ) { $c = 0; $v[ $k ] = $this->replace_recursive( $x, $c ); $t += $c; }
            $count = $t;
            return $v;
        }
        if ( is_object( $v ) ) {
            $t = 0;
            foreach ( get_object_vars( $v ) as $k => $x ) { $c = 0; $v->{$k} = $this->replace_recursive( $x, $c ); $t += $c; }
            $count = $t;
            return $v;
        }
        return $v;
    }
}
