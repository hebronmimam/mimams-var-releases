<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

class CssExporter {

    /**
     * Export all variables to /wp-content/uploads/variable-engine/variables.css
     */
    public function export(): bool {
        $vars = ( new VariableManager() )->get_all();

        if ( empty( $vars ) ) {
            // Write an empty file so the enqueue doesn't error.
            return $this->write( "/* Variable Engine — no variables defined yet. */\n:root {}\n" );
        }

        $lines = [];
        foreach ( $vars as $v ) {
            $css_name = ( new VariableManager() )->to_css_name( $v['name'] );
            $value    = $v['css_value'] ?: $v['value'];
            $lines[]  = "  {$css_name}: {$value};";
        }

        $header = "/* Variable Engine v" . VE_VERSION . " - Auto-generated. Do not edit. */\n";
        $css    = $header . ":root {\n" . implode( "\n", $lines ) . "\n}\n";

        return $this->write( $css );
    }

    /**
     * Write CSS string to disk.
     */
    private function write( string $css ): bool {
        $dir = VE_CSS_OUTPUT_DIR;

        // Ensure directory exists.
        if ( ! is_dir( $dir ) ) {
            wp_mkdir_p( $dir );
        }

        $file = $dir . 'variables.css';

        // Use WP_Filesystem if available, fall back to file_put_contents.
        $written = file_put_contents( $file, $css );

        return false !== $written;
    }

    /**
     * Get the URL of the generated CSS file.
     */
    public function get_url(): string {
        return VE_CSS_OUTPUT_URL . 'variables.css';
    }

    /**
     * Get the path of the generated CSS file.
     */
    public function get_path(): string {
        return VE_CSS_OUTPUT_DIR . 'variables.css';
    }
}
