<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

class GeneratorEngine {

    private const HANDLERS = [
        'color'      => Generators\ColorGenerator::class,
        'spacing'    => Generators\FluidScaleGenerator::class,
        'typography' => Generators\FluidScaleGenerator::class,
        'radius'     => Generators\FluidScaleGenerator::class,
        'size'       => Generators\FluidScaleGenerator::class,
    ];

    /* ── ATTACH a generator to a base variable ───────────────────── */
    public function attach( int $variable_id, string $type, array $config = [] ) {
        global $wpdb;

        $vm       = new VariableManager();
        $variable = $vm->get( $variable_id );

        if ( ! $variable ) {
            return new \WP_Error( 've_not_found', 'Base variable not found.', [ 'status' => 404 ] );
        }
        if ( 'base' !== $variable['type'] ) {
            return new \WP_Error( 've_not_base', 'Generators can only attach to base variables.', [ 'status' => 400 ] );
        }
        if ( ! isset( self::HANDLERS[ $type ] ) ) {
            return new \WP_Error( 've_invalid_generator', "Unknown generator type: {$type}", [ 'status' => 400 ] );
        }

        $table = Schema::table( 'generators' );
        $wpdb->insert( $table, [
            'variable_id' => $variable_id,
            'type'        => $type,
            'config'      => wp_json_encode( $config ),
            'active'      => 1,
        ], [ '%d', '%s', '%s', '%d' ] );

        $generator_id  = (int) $wpdb->insert_id;
        $generated_ids = $this->run_generator( $generator_id, $variable, $type, $config );

        ( new CssExporter() )->export();

        return [
            'generator_id' => $generator_id,
            'type'         => $type,
            'config'       => $config,
            'generated'    => $generated_ids,
        ];
    }

    /* ── DETACH — remove generator + its generated variables ──────── */
    public function detach( int $generator_id ) {
        global $wpdb;
        $table = Schema::table( 'generators' );
        $gen   = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d", $generator_id
        ), ARRAY_A );

        if ( ! $gen ) {
            return new \WP_Error( 've_not_found', 'Generator not found.', [ 'status' => 404 ] );
        }

        $var_table = Schema::table( 'variables' );
        $dep_table = Schema::table( 'dependencies' );

        // Get IDs of generated variables before deleting.
        $gen_var_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT id FROM {$var_table} WHERE source_id = %d AND generator_type = %s AND type = 'generated'",
            $gen['variable_id'],
            $gen['type']
        ) );

        if ( $gen_var_ids ) {
            $ids_in = implode( ',', array_map( 'intval', $gen_var_ids ) );
            $wpdb->query( "DELETE FROM {$dep_table} WHERE child_id IN ({$ids_in})" );
            $wpdb->query( "DELETE FROM {$var_table} WHERE id IN ({$ids_in})" );
        }

        $wpdb->delete( $table, [ 'id' => $generator_id ] );
        ( new CssExporter() )->export();

        return true;
    }

    /* ── REGENERATE all active generators for a variable ──────────── */
    public function regenerate( int $variable_id ): void {
        global $wpdb;
        $vm    = new VariableManager();
        $variable = $vm->get( $variable_id );
        if ( ! $variable ) return;

        // Try generators table first
        $table = Schema::table( 'generators' );
        $generators = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE variable_id = %d",
            $variable_id
        ), ARRAY_A );

        if ( ! empty( $generators ) ) {
            foreach ( $generators as $gen ) {
                $config = json_decode( $gen['config'], true ) ?: [];
                $this->run_generator( (int) $gen['id'], $variable, $gen['type'], $config );
            }
            return;
        }

        // Fallback: check dependencies table for children, detect type from generator_type
        $dep_table = Schema::table( 'dependencies' );
        $children = $wpdb->get_results( $wpdb->prepare(
            "SELECT child_id FROM {$dep_table} WHERE parent_id = %d AND relation = 'generated'",
            $variable_id
        ), ARRAY_A );

        if ( empty( $children ) ) return;

        // Get one child to detect what kind of generator was used
        $child = $vm->get( (int) $children[0]['child_id'] );
        if ( ! $child || empty( $child['generator_type'] ) ) return;

        $gen_type = $child['generator_type'];
        // Count children to determine config
        $child_count = count( $children );

        // Build a reasonable config based on what exists
        if ( $gen_type === 'color' ) {
            $tints = $shades = $alphas = 0;
            foreach ( $children as $ch ) {
                $c = $vm->get( (int) $ch['child_id'] );
                if ( ! $c ) continue;
                $name = $c['name'];
                if ( strpos( $name, '.l.' ) !== false ) $tints++;
                elseif ( strpos( $name, '.d.' ) !== false ) $shades++;
                elseif ( strpos( $name, '.t.' ) !== false ) $alphas++;
            }
            $config = [
                'tint_count'    => $tints,
                'shade_count'   => $shades,
                'include_alpha' => $alphas > 0,
                'alpha_count'   => $alphas,
            ];
        } else {
            // For scale generators, we can't easily reconstruct config
            // Just skip — they don't change with base value typically
            return;
        }

        // Run the generator with reconstructed config
        $handler_class = self::HANDLERS[ $gen_type ] ?? null;
        if ( ! $handler_class || ! class_exists( $handler_class ) ) return;

        $handler = new $handler_class();
        $scales  = $handler->generate( $variable, $config );
        $var_table = Schema::table( 'variables' );

        foreach ( $scales as $item ) {
            $existing = $vm->get_by_name( $item['name'] );
            if ( $existing ) {
                $wpdb->update( $var_table, [
                    'value'     => $item['value'],
                    'css_value' => $item['value'],
                ], [ 'id' => $existing['id'] ], [ '%s', '%s' ], [ '%d' ] );
            }
        }
    }

    /* ── LIST generators for a variable ───────────────────────────── */
    public function list_for_variable( int $variable_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . Schema::table( 'generators' ) . " WHERE variable_id = %d ORDER BY id ASC",
            $variable_id
        ), ARRAY_A ) ?: [];
    }

    /* ── INTERNAL: execute a single generator ─────────────────────── */
    private function run_generator( int $generator_id, array $base_variable, string $type, array $config ): array {
        $handler_class = self::HANDLERS[ $type ] ?? null;
        if ( ! $handler_class || ! class_exists( $handler_class ) ) {
            return [];
        }

        $handler     = new $handler_class();
        $scales      = $handler->generate( $base_variable, $config );
        $vm          = new VariableManager();
        $graph       = new DependencyGraph();
        $created_ids = [];

        global $wpdb;
        $var_table = Schema::table( 'variables' );

        foreach ( $scales as $item ) {
            $existing = $vm->get_by_name( $item['name'] );

            if ( $existing ) {
                $wpdb->update( $var_table, [
                    'value'          => $item['value'],
                    'css_value'      => $item['value'],
                    'source_id'      => (int) $base_variable['id'],
                    'generator_type' => $type,
                    'type'           => 'generated',
                    'namespace'      => explode( '.', $item['name'] )[0],
                ], [ 'id' => $existing['id'] ], [ '%s', '%s', '%d', '%s', '%s', '%s' ], [ '%d' ] );
                $created_ids[] = (int) $existing['id'];
                $graph->register( (int) $base_variable['id'], (int) $existing['id'], 'generated' );
            } else {
                $namespace = explode( '.', $item['name'] )[0];
                $wpdb->insert( $var_table, [
                    'name'           => $item['name'],
                    'type'           => 'generated',
                    'namespace'      => $namespace,
                    'value'          => $item['value'],
                    'css_value'      => $item['value'],
                    'source_id'      => $base_variable['id'],
                    'generator_type' => $type,
                ], [ '%s', '%s', '%s', '%s', '%s', '%d', '%s' ] );

                $child_id      = (int) $wpdb->insert_id;
                $created_ids[] = $child_id;
                $graph->register( (int) $base_variable['id'], $child_id, 'generated' );
            }
        }

        // Remove generated rows from older naming patterns for this same base/generator.
        // This keeps a rename from `font.space` to `size.space` from leaving old
        // CSS variables like --font-107 behind after the new --size-107 set exists.
        $created_ids = array_values( array_unique( array_map( 'intval', $created_ids ) ) );
        $dep_table = Schema::table( 'dependencies' );
        if ( ! empty( $created_ids ) ) {
            $placeholders = implode( ',', array_fill( 0, count( $created_ids ), '%d' ) );
            $params = array_merge( [ (int) $base_variable['id'], $type ], $created_ids );
            $old_ids = $wpdb->get_col( $wpdb->prepare(
                "SELECT id FROM {$var_table}
                 WHERE source_id = %d
                   AND generator_type = %s
                   AND type = 'generated'
                   AND id NOT IN ({$placeholders})",
                $params
            ) ) ?: [];
        } else {
            $old_ids = $wpdb->get_col( $wpdb->prepare(
                "SELECT id FROM {$var_table}
                 WHERE source_id = %d
                   AND generator_type = %s
                   AND type = 'generated'",
                (int) $base_variable['id'],
                $type
            ) ) ?: [];
        }

        if ( ! empty( $old_ids ) ) {
            $old_ids = array_values( array_unique( array_map( 'intval', $old_ids ) ) );
            $old_placeholders = implode( ',', array_fill( 0, count( $old_ids ), '%d' ) );
            $wpdb->query( $wpdb->prepare( "DELETE FROM {$dep_table} WHERE parent_id IN ({$old_placeholders}) OR child_id IN ({$old_placeholders})", array_merge( $old_ids, $old_ids ) ) );
            $wpdb->query( $wpdb->prepare( "DELETE FROM {$var_table} WHERE id IN ({$old_placeholders})", $old_ids ) );
        }

        return $created_ids;
    }
}
