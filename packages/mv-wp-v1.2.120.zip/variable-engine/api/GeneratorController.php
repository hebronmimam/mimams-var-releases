<?php

namespace VE\API;

use VE\Core\GeneratorEngine;

defined( 'ABSPATH' ) || exit;

class GeneratorController {

    private GeneratorEngine $engine;

    public function __construct() {
        $this->engine = new GeneratorEngine();
    }

    /* ── ATTACH a generator ──────────────────────────────────────── */
    public function attach( \WP_REST_Request $request ) {
        $variable_id = (int) $request->get_param( 'variable_id' );
        $data        = $request->get_json_params();
        $type        = $data['type'] ?? '';
        $config      = $data['config'] ?? [];

        $result = $this->engine->attach( $variable_id, $type, $config );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return new \WP_REST_Response( $result, 201 );
    }

    /* ── DETACH a generator ──────────────────────────────────────── */
    public function detach( \WP_REST_Request $request ) {
        $generator_id = (int) $request->get_param( 'generator_id' );
        $result       = $this->engine->detach( $generator_id );

        if ( is_wp_error( $result ) ) {
            return $result;
        }

        return new \WP_REST_Response( [ 'deleted' => true ], 200 );
    }

    /* ── LIST generators for a variable ──────────────────────────── */
    public function list_generators( \WP_REST_Request $request ): \WP_REST_Response {
        $variable_id = (int) $request->get_param( 'variable_id' );
        $generators  = $this->engine->list_for_variable( $variable_id );

        return new \WP_REST_Response( $generators, 200 );
    }

    /* ── REGENERATE all generators for a variable ────────────────── */
    public function regenerate( \WP_REST_Request $request ): \WP_REST_Response {
        $variable_id = (int) $request->get_param( 'variable_id' );
        $this->engine->regenerate( $variable_id );

        return new \WP_REST_Response( [ 'regenerated' => true ], 200 );
    }
}
