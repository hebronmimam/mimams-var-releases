<?php
namespace VE\Sync;

use VE\Database\Schema;
use VE\Core\VariableManager;
use VE\Core\CssExporter;

defined('ABSPATH') || exit;

/**
 * SnapshotManager — captures full variable state before sync operations.
 * Enables rollback if a sync goes wrong.
 */
class SnapshotManager {

    /**
     * Create a snapshot of all current variables.
     *
     * @param string $trigger 'manual' | 'pre_import' | 'pre_export'
     * @return int Snapshot ID
     */
    public function create( string $trigger = 'manual' ): int {
        global $wpdb;

        $manager   = new VariableManager();
        $variables = $manager->get_all();

        $wpdb->insert(
            Schema::table('snapshots'),
            [
                'variables_state' => wp_json_encode( $variables ),
                'trigger_type'    => $trigger,
            ],
            ['%s', '%s']
        );

        return (int) $wpdb->insert_id;
    }

    /**
     * Restore variables from a snapshot.
     * Deletes all current variables and recreates from snapshot state.
     *
     * @param int $snapshot_id
     * @return array|false Restored variables or false on failure
     */
    public function rollback( int $snapshot_id ) {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . Schema::table('snapshots') . ' WHERE id = %d',
                $snapshot_id
            ),
            ARRAY_A
        );

        if ( ! $row ) {
            return false;
        }

        $snapshot_vars = json_decode( $row['variables_state'], true );
        if ( ! is_array( $snapshot_vars ) ) {
            return false;
        }

        // Create a pre-rollback snapshot for safety.
        $this->create('pre_rollback');

        $vars_table = Schema::table('variables');
        $deps_table = Schema::table('dependencies');
        $gens_table = Schema::table('generators');

        // Wipe current state.
        $wpdb->query("DELETE FROM {$deps_table}");
        $wpdb->query("DELETE FROM {$gens_table}");
        $wpdb->query("DELETE FROM {$vars_table}");

        // Restore variables.
        foreach ( $snapshot_vars as $v ) {
            $wpdb->insert( $vars_table, [
                'name'           => $v['name'],
                'type'           => $v['type'] ?? 'base',
                'namespace'      => $v['namespace'] ?? '',
                'value'          => $v['value'] ?? '',
                'css_value'      => $v['css_value'] ?? '',
                'source_id'      => $v['source_id'] ?? null,
                'generator_type' => $v['generator_type'] ?? null,
            ], ['%s','%s','%s','%s','%s','%d','%s'] );
        }

        // Re-export CSS.
        ( new CssExporter() )->export();

        return $snapshot_vars;
    }

    /**
     * List all snapshots (newest first).
     *
     * @param int $limit
     * @return array
     */
    public function list( int $limit = 20 ): array {
        global $wpdb;

        return $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, trigger_type, created_at FROM ' . Schema::table('snapshots') .
                ' ORDER BY id DESC LIMIT %d',
                $limit
            ),
            ARRAY_A
        ) ?: [];
    }

    /**
     * Get a single snapshot by ID.
     */
    public function get( int $id ): ?array {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . Schema::table('snapshots') . ' WHERE id = %d',
                $id
            ),
            ARRAY_A
        );

        return $row ?: null;
    }
}
