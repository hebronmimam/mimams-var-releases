# Mimam's Var - Figma v2.17.8

## What changed

- Refined number inputs and custom checkboxes so fields no longer clash with native spinner controls and checkbox labels align cleanly.
- Added live WordPress stats refresh while the Figma main view is open, so cleanup status updates shortly after either side cleans the database.
- Improved history-card spacing and collection dropdown chevron alignment.

## Previous v2.17.7 changes

- Refined the History tab into dedicated event cards so JSON imports and sync events no longer sit awkwardly on the left with empty space below.
- Re-centered the collection dropdown chevron for a cleaner collection picker.

## Previous v2.17.6 changes

- Moved the Figma collection picker directly into the Pull from WordPress flow and restyled the dropdown for the dark plugin UI.
- Replaced the previous glossy/jump hover buttons with cleaner color and GSAP scale feedback.
- Increased comfort around sync controls while keeping the existing brand colors.

## Previous v2.17.5 changes

- Added Figma collection targeting for sync. Pull from WordPress can write into the selected existing collection or create a typed new collection; Push to WordPress reads from the selected existing collection.
- Reduced the duplicate-header feel by treating the in-plugin header as a compact app/action strip under Figma's native plugin title bar.
- Updated button styling using the button UI inspiration direction: more restrained grouped-control surfaces, subtle borders, and cleaner active states.
- Increased line heights for helper text and longer messages.
- Renamed the Figma plugin UI/manifest from Variable Engine Sync to Mimam's Var - Figma.
- Added the Hebronmimam logo icon to the plugin header UI.
- Push-to-WordPress preview now displays WordPress color variant nesting repairs as `NEST` changes instead of looking empty.
- Improved spacing, borders, inputs, selection rows, and button finish while preserving the existing color system.

## Previous v2.17.2 changes

- Fixed Figma → WordPress push for nested Figma variable groups.
- Nested Figma paths such as `Color/Brand/primary-d-1` now normalize to valid WordPress names such as `color.brand.primary.d.1`.
- Existing Variable Engine public names still round-trip correctly, e.g. `color/color-primary-d-1` becomes `color.primary.d.1` and `space/space-20` becomes `space.20`.
- This prevents WordPress validation errors like "Variable names must be lowercase, dot-separated" when pushing third-party Figma collections.

## Previous v2.17.1 changes

- Generate tab now persists scan results across tab switches. Leaving Generate and coming back keeps the scan, the clusters, and any edits in place. Cancel still resets.
- Generate tab now supports **multiple bases per cluster**. Click any swatch in a cluster to toggle it as a base; click again to remove. Each selected base gets its own editable name input and produces its own variable plus full scale.
- The first base in a cluster defaults to the cluster's hue name (e.g. `primary`, `blue`, `neutral`); additional bases default to the same name with `-2`, `-3` suffixes. Every name is independently editable.
- Cluster summary now reads as e.g. "3 clusters from 12 unique colors. 5 bases selected → 125 new variables on WordPress."
- Same Apply tab improvement: switching tabs no longer wipes a Smart Apply scan.

## Update workflow

For development installs, replace the files inside the existing folder Figma is already referencing. Do not import a fresh manifest from a new folder unless you intentionally want a separate development plugin entry.
