<?php

namespace VE\API;

defined( 'ABSPATH' ) || exit;

class Routes {

    public function register(): void {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
        add_action( 'wp_ajax_ve_refresh_rest_nonce', [ $this, 'refresh_rest_nonce' ] );
    }

    public function refresh_rest_nonce(): void {
        if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Your WordPress session must be refreshed.' ], 403 );
        }

        wp_send_json_success( [ 'nonce' => wp_create_nonce( 'wp_rest' ) ] );
    }

    public function register_routes(): void {
        $ns         = VE_API_NAMESPACE;
        $controller = new VariableController();

        // ── Variables CRUD ──────────────────────────────────────────
        register_rest_route( $ns, '/variables', [
            [
                'methods'             => 'GET',
                'callback'            => [ $controller, 'list_variables' ],
                'permission_callback' => [ $this, 'can_read' ],
                'args'                => [
                    'namespace' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ],
                    'type'      => [ 'type' => 'string', 'enum' => [ 'base', 'generated', 'alias' ] ],
                    'dedupe'    => [ 'type' => 'boolean', 'default' => false ],
                ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $controller, 'create_variable' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );


        register_rest_route( $ns, '/variables/stats', [
            'methods'             => 'GET',
            'callback'            => [ $controller, 'stats_variables' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/variables/cleanup', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'cleanup_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/reorder', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'reorder_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/batch-delete', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'batch_delete_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variable-families/preview', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'preview_family_relationships' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variable-families/apply', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'apply_family_relationships' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/(?P<id>\d+)', [
            [
                'methods'             => 'GET',
                'callback'            => [ $controller, 'get_variable' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'PUT',
                'callback'            => [ $controller, 'update_variable' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $controller, 'delete_variable' ],
                'permission_callback' => [ $this, 'can_write' ],
                'args'                => [
                    'force' => [ 'type' => 'boolean', 'default' => false ],
                ],
            ],
        ] );

        register_rest_route( $ns, '/variables/(?P<id>\d+)/rename-preview', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'rename_preview' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/(?P<id>\d+)/usage', [
            'methods'             => 'GET',
            'callback'            => [ $controller, 'usage_variable' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        // ── Organizational variable categories ─────────────────────
        $variable_categories = new VariableCategoryController();
        register_rest_route( $ns, '/variable-categories', [
            [
                'methods'             => 'GET',
                'callback'            => [ $variable_categories, 'list_categories' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $variable_categories, 'create_category' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/variable-categories/(?P<slug>[a-z0-9-]+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $variable_categories, 'update_category' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $variable_categories, 'delete_category' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/variable-categories/(?P<slug>[a-z0-9-]+)/rename', [
            'methods'             => 'POST',
            'callback'            => [ $variable_categories, 'update_category' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/variable-categories/(?P<slug>[a-z0-9-]+)/remove', [
            'methods'             => 'POST',
            'callback'            => [ $variable_categories, 'delete_category' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/variable-categories/variables/move', [
            'methods'             => 'POST',
            'callback'            => [ $variable_categories, 'move_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Themes (legacy /palettes routes remain compatible) ──────
        $palettes = new PaletteController();
        register_rest_route( $ns, '/palettes', [
            [
                'methods'             => 'GET',
                'callback'            => [ $palettes, 'list_palettes' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $palettes, 'create_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/palettes/(?P<slug>[a-z0-9-]+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $palettes, 'update_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $palettes, 'delete_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/palettes/(?P<slug>[a-z0-9-]+)/activate', [
            'methods'             => 'POST',
            'callback'            => [ $palettes, 'activate_palette' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/palettes/(?P<slug>[a-z0-9-]+)/duplicate', [
            'methods'             => 'POST',
            'callback'            => [ $palettes, 'duplicate_palette' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        $themes = new ThemeController();
        register_rest_route( $ns, '/themes', [
            [
                'methods'             => 'GET',
                'callback'            => [ $themes, 'list_themes' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $themes, 'create_theme' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/themes/(?P<slug>[a-z0-9-]+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $themes, 'update_theme' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $themes, 'delete_theme' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/themes/(?P<slug>[a-z0-9-]+)/activate', [
            'methods'             => 'POST',
            'callback'            => [ $themes, 'activate_theme' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/themes/(?P<slug>[a-z0-9-]+)/duplicate', [
            'methods'             => 'POST',
            'callback'            => [ $themes, 'duplicate_theme' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Organizational color palettes ────────────────────────────
        $color_palettes = new ColorPaletteController();
        register_rest_route( $ns, '/color-palettes', [
            [
                'methods'             => 'GET',
                'callback'            => [ $color_palettes, 'list_palettes' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $color_palettes, 'create_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/color-palettes/(?P<id>\d+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $color_palettes, 'update_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $color_palettes, 'delete_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/color-palettes/(?P<id>\d+)/duplicate', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'duplicate_palette' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/color-palettes/(?P<id>\d+)/delete-preview', [
            'methods'             => 'GET',
            'callback'            => [ $color_palettes, 'preview_delete' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/color-palettes/reorder', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'reorder_palettes' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/color-palettes/variables/batch-move', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'batch_move_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/color-palettes/variables/(?P<variable_id>\d+)/move', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'move_variable' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/color-palettes/variables/(?P<variable_id>\d+)/copy', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'copy_variable' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Generators ────────────────────────────────────────────────
        $gen_controller = new GeneratorController();

        register_rest_route( $ns, '/variables/(?P<variable_id>\d+)/generators', [
            [
                'methods'             => 'GET',
                'callback'            => [ $gen_controller, 'list_generators' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $gen_controller, 'attach' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/variables/(?P<variable_id>\d+)/generators/regenerate', [
            'methods'             => 'POST',
            'callback'            => [ $gen_controller, 'regenerate' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/generators/(?P<generator_id>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $gen_controller, 'detach' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Search ──────────────────────────────────────────────────
        register_rest_route( $ns, '/search', [
            'methods'             => 'GET',
            'callback'            => [ $controller, 'search_variables' ],
            'permission_callback' => [ $this, 'can_read' ],
            'args'                => [
                'q'     => [ 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
                'limit' => [ 'type' => 'integer', 'default' => 50 ],
            ],
        ] );

        // ── Settings ────────────────────────────────────────────────
        register_rest_route( $ns, '/settings', [
            [
                'methods'             => 'GET',
                'callback'            => function () {
                    $defaults = [
                        'vw_min'              => 320,
                        'vw_max'              => 1440,
                        'delete_on_uninstall' => false,
                        'update_url'          => \VE\Core\Updater::DEFAULT_FEED_URL,
                        'update_channel'      => 'stable',
                        'auto_update'         => false,
                        'license_server_url'  => '',
                        'deactivated_tools'   => [],
                        'deactivated_tool_surfaces' => [
                            'admin'   => [],
                            'builder' => [],
                        ],
                        'allow_multi_panels'  => false,
                        'show_all_tab'        => true,
                        'media_replace_wp_library' => false,
                        'media_auto_sync_external_folders' => false,
                    ];
                    $settings = get_option( 've_settings', $defaults );
                    $out = wp_parse_args( $settings, $defaults );
                    $out['site_title'] = get_bloginfo( 'name' );
                    $out['license'] = ( new \VE\Core\LicenseManager() )->status();
                    return new \WP_REST_Response( $out, 200 );
                },
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => function ( \WP_REST_Request $request ) {
                    $data = $request->get_json_params();
                    $defaults = [
                        'vw_min'              => 320,
                        'vw_max'              => 1440,
                        'delete_on_uninstall' => false,
                        'update_url'          => \VE\Core\Updater::DEFAULT_FEED_URL,
                        'update_channel'      => 'stable',
                        'auto_update'         => false,
                        'license_server_url'  => '',
                        'deactivated_tools'   => [],
                        'deactivated_tool_surfaces' => [
                            'admin'   => [],
                            'builder' => [],
                        ],
                        'allow_multi_panels'  => false,
                        'show_all_tab'        => true,
                        'media_replace_wp_library' => false,
                        'media_auto_sync_external_folders' => false,
                    ];
                    $previous = get_option( 've_settings', $defaults );
                    $update_channel = sanitize_key( (string) ( $data['update_channel'] ?? ( $previous['update_channel'] ?? 'stable' ) ) );
                    if ( ! in_array( $update_channel, [ 'stable', 'beta', 'dev' ], true ) ) {
                        $update_channel = 'stable';
                    }
                    $update_url = isset( $data['update_url'] ) ? esc_url_raw( (string) $data['update_url'] ) : (string) ( $previous['update_url'] ?? $defaults['update_url'] );
                    if ( '' === $update_url || \VE\Core\Updater::LEGACY_FEED_URL === $update_url || \VE\Core\Updater::DEFAULT_FEED_URL === $update_url ) {
                        $update_url = \VE\Core\Updater::feed_url_for_channel( $update_channel );
                    }
                    $license_server_url = isset( $data['license_server_url'] ) ? esc_url_raw( (string) $data['license_server_url'] ) : (string) ( $previous['license_server_url'] ?? '' );
                    $deactivated_tools = isset( $data['deactivated_tools'] ) && is_array( $data['deactivated_tools'] )
                        ? array_map( 'sanitize_key', $data['deactivated_tools'] )
                        : ( isset( $previous['deactivated_tools'] ) && is_array( $previous['deactivated_tools'] ) ? array_map( 'sanitize_key', $previous['deactivated_tools'] ) : [] );
                    $surface_data = isset( $data['deactivated_tool_surfaces'] ) && is_array( $data['deactivated_tool_surfaces'] )
                        ? $data['deactivated_tool_surfaces']
                        : ( isset( $previous['deactivated_tool_surfaces'] ) && is_array( $previous['deactivated_tool_surfaces'] ) ? $previous['deactivated_tool_surfaces'] : [] );
                    $deactivated_tool_surfaces = [
                        'admin'   => isset( $surface_data['admin'] ) && is_array( $surface_data['admin'] )
                            ? array_values( array_unique( array_map( 'sanitize_key', $surface_data['admin'] ) ) )
                            : [],
                        'builder' => isset( $surface_data['builder'] ) && is_array( $surface_data['builder'] )
                            ? array_values( array_unique( array_map( 'sanitize_key', $surface_data['builder'] ) ) )
                            : [],
                    ];
                    $settings = [
                        'vw_min'              => isset( $data['vw_min'] ) ? absint( $data['vw_min'] ) : absint( $previous['vw_min'] ?? 320 ),
                        'vw_max'              => isset( $data['vw_max'] ) ? absint( $data['vw_max'] ) : absint( $previous['vw_max'] ?? 1440 ),
                        'delete_on_uninstall' => isset( $data['delete_on_uninstall'] ) ? ! empty( $data['delete_on_uninstall'] ) : ! empty( $previous['delete_on_uninstall'] ),
                        'update_url'          => $update_url,
                        'update_channel'      => $update_channel,
                        'auto_update'         => isset( $data['auto_update'] ) ? ! empty( $data['auto_update'] ) : ! empty( $previous['auto_update'] ),
                        'license_server_url'  => $license_server_url,
                        'deactivated_tools'   => $deactivated_tools,
                        'deactivated_tool_surfaces' => $deactivated_tool_surfaces,
                        'allow_multi_panels'  => isset( $data['allow_multi_panels'] ) ? ! empty( $data['allow_multi_panels'] ) : ! empty( $previous['allow_multi_panels'] ),
                        'show_all_tab'        => isset( $data['show_all_tab'] ) ? ! empty( $data['show_all_tab'] ) : ( isset( $previous['show_all_tab'] ) ? ! empty( $previous['show_all_tab'] ) : true ),
                        'media_replace_wp_library' => isset( $data['media_replace_wp_library'] ) ? ! empty( $data['media_replace_wp_library'] ) : ! empty( $previous['media_replace_wp_library'] ),
                        'media_auto_sync_external_folders' => isset( $data['media_auto_sync_external_folders'] ) ? ! empty( $data['media_auto_sync_external_folders'] ) : ! empty( $previous['media_auto_sync_external_folders'] ),
                    ];
                    $previous_surfaces = isset( $previous['deactivated_tool_surfaces'] ) && is_array( $previous['deactivated_tool_surfaces'] )
                        ? $previous['deactivated_tool_surfaces']
                        : [];
                    $previous_admin_disabled = isset( $previous_surfaces['admin'] ) && is_array( $previous_surfaces['admin'] )
                        && in_array( 'recovery', $previous_surfaces['admin'], true );
                    $previous_surface_choice = $previous_admin_disabled
                        || ( isset( $previous_surfaces['builder'] ) && is_array( $previous_surfaces['builder'] ) && in_array( 'recovery', $previous_surfaces['builder'], true ) );
                    if ( ! $previous_surface_choice && isset( $previous['deactivated_tools'] ) && is_array( $previous['deactivated_tools'] ) ) {
                        $previous_admin_disabled = in_array( 'recovery', $previous['deactivated_tools'], true );
                    }
                    $current_admin_disabled = in_array( 'recovery', $deactivated_tool_surfaces['admin'], true );
                    $recovery_enabled_now = $previous_admin_disabled && ! $current_admin_disabled;
                    update_option( 've_settings', $settings );
                    update_option( 've_delete_on_uninstall', $settings['delete_on_uninstall'] );
                    $update_feed_changed = (string) ( $previous['update_channel'] ?? 'stable' ) !== $settings['update_channel']
                        || (string) ( $previous['update_url'] ?? '' ) !== $settings['update_url'];
                    if ( $update_feed_changed ) {
                        ( new \VE\Core\Updater() )->clear_cache();
                        delete_site_transient( 'update_plugins' );
                        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
                            wp_clean_plugins_cache();
                        }
                    }

                    // If the fluid viewport range changed, every fluid variable's
                    // clamp() output is now stale — recompile them.
                    $vw_changed = ( (int) ( $previous['vw_min'] ?? 320 ) !== $settings['vw_min'] )
                               || ( (int) ( $previous['vw_max'] ?? 1440 ) !== $settings['vw_max'] );
                    $recompiled = 0;
                    if ( $vw_changed ) {
                        $recompiled = ( new \VE\Core\VariableManager() )->recompile_fluid();
                        if ( is_wp_error( $recompiled ) ) {
                            update_option( 've_settings', $previous );
                            update_option( 've_delete_on_uninstall', ! empty( $previous['delete_on_uninstall'] ) );
                            return $recompiled;
                        }
                    }

                    $response = $settings;
                    $response['fluid_recompiled'] = $recompiled;
                    $response['license'] = ( new \VE\Core\LicenseManager() )->status();
                    if ( $recovery_enabled_now && defined( 'VE_FILE' ) ) {
                        \VE\Modules\Recovery\RecoveryModule::init( VE_FILE );
                        if ( class_exists( '\VE\Modules\Recovery\Admin\AdminPage' ) ) {
                            $response['recovery_runtime'] = ( new \VE\Modules\Recovery\Admin\AdminPage() )->runtime_bootstrap_payload();
                        }
                    }
                    return new \WP_REST_Response( $response, 200 );
                },
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/user-preferences', [
            [
                'methods'             => 'GET',
                'callback'            => function () {
                    $preferences = get_user_meta( get_current_user_id(), 've_user_preferences', true );
                    return new \WP_REST_Response( [
                        'preferences' => is_array( $preferences ) ? $preferences : [],
                    ], 200 );
                },
                'permission_callback' => [ $this, 'can_save_user_preferences' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => function ( \WP_REST_Request $request ) {
                    $data = $request->get_json_params();
                    $preferences = isset( $data['preferences'] ) && is_array( $data['preferences'] )
                        ? $this->sanitize_user_preferences( $data['preferences'] )
                        : [];
                    update_user_meta( get_current_user_id(), 've_user_preferences', $preferences );
                    return new \WP_REST_Response( [
                        'preferences' => $preferences,
                        'saved'       => true,
                    ], 200 );
                },
                'permission_callback' => [ $this, 'can_save_user_preferences' ],
            ],
        ] );

        $settings_transfer = new \VE\Core\SettingsTransferManager();
        register_rest_route( $ns, '/settings-transfer/groups', [
            'methods'             => 'GET',
            'callback'            => static function () use ( $settings_transfer ) {
                return new \WP_REST_Response( [
                    'schema_version' => \VE\Core\SettingsTransferManager::SCHEMA_VERSION,
                    'groups'         => $settings_transfer->group_definitions(),
                ], 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/settings-transfer/export', [
            'methods'             => 'POST',
            'callback'            => static function ( \WP_REST_Request $request ) use ( $settings_transfer ) {
                $data = $request->get_json_params() ?: [];
                $groups = isset( $data['groups'] ) && is_array( $data['groups'] ) ? $data['groups'] : [];
                return new \WP_REST_Response( [
                    'success' => true,
                    'bundle'  => $settings_transfer->export_bundle( $groups, get_current_user_id() ),
                ], 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/settings-transfer/preview', [
            'methods'             => 'POST',
            'callback'            => static function ( \WP_REST_Request $request ) use ( $settings_transfer ) {
                $data = $request->get_json_params() ?: [];
                $bundle = isset( $data['bundle'] ) && is_array( $data['bundle'] ) ? $data['bundle'] : [];
                $groups = isset( $data['groups'] ) && is_array( $data['groups'] ) ? $data['groups'] : [];
                $preview = $settings_transfer->preview_bundle( $bundle, $groups );
                return is_wp_error( $preview ) ? $preview : new \WP_REST_Response( $preview, 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/settings-transfer/apply', [
            'methods'             => 'POST',
            'callback'            => static function ( \WP_REST_Request $request ) use ( $settings_transfer ) {
                $data = $request->get_json_params() ?: [];
                $bundle = isset( $data['bundle'] ) && is_array( $data['bundle'] ) ? $data['bundle'] : [];
                $groups = isset( $data['groups'] ) && is_array( $data['groups'] ) ? $data['groups'] : [];
                $fingerprint = sanitize_text_field( (string) ( $data['fingerprint'] ?? '' ) );
                $result = $settings_transfer->apply_bundle( $bundle, $groups, $fingerprint, get_current_user_id() );
                return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/license/status', [
            'methods'             => 'GET',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->status(), 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/license/activate', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                $data = $request->get_json_params();
                $key  = isset( $data['license_key'] ) ? (string) $data['license_key'] : '';
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->activate( $key ), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/license/check', [
            'methods'             => 'POST',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->check(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/license/deactivate', [
            'methods'             => 'POST',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->deactivate(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/update/check', [
            'methods'             => 'POST',
            'callback'            => function () {
                $updater = new \VE\Core\Updater();
                return new \WP_REST_Response( $updater->check_now(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/update/install', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                $payload = $request->get_json_params();
                if ( ! is_array( $payload ) ) {
                    $payload = [];
                }
                $target_version = isset( $payload['version'] ) ? (string) $payload['version'] : (string) $request->get_param( 'version' );
                $result = ( new \VE\Core\Updater() )->install_available_update( $target_version );
                if ( is_wp_error( $result ) ) {
                    $error_data = $result->get_error_data();
                    return new \WP_REST_Response(
                        [
                            'code'    => $result->get_error_code(),
                            'message' => $result->get_error_message(),
                            'data'    => is_array( $error_data ) ? $error_data : [],
                        ],
                        (int) ( is_array( $error_data ) && isset( $error_data['status'] ) ? $error_data['status'] : 500 )
                    );
                }
                return new \WP_REST_Response( $result, 200 );
            },
            'permission_callback' => static function (): bool {
                return current_user_can( 'update_plugins' );
            },
        ] );

        register_rest_route( $ns, '/advanced-css', [
            [
                'methods'             => 'GET',
                'callback'            => function () {
                    return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->get(), 200 );
                },
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => function ( \WP_REST_Request $request ) {
                    $data = $request->get_json_params();
                    $sheets = is_array( $data ) && isset( $data['stylesheets'] ) && is_array( $data['stylesheets'] )
                        ? $data['stylesheets']
                        : [];
                    return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->save( $sheets ), 200 );
                },
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/advanced-css/compile', [
            'methods'             => 'POST',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->compile(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/advanced-css/suggestions', [
            'methods'             => 'GET',
            'callback'            => function ( \WP_REST_Request $request ) {
                $refresh = rest_sanitize_boolean( $request->get_param( 'refresh' ) );
                return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->suggestions( $refresh ), 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/migration/sources', [
            'methods'             => 'GET',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\MigrationScanner() )->sources(), 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/migration/preview', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                $data = $request->get_json_params();
                $source = sanitize_key( (string) ( $data['source'] ?? 'all' ) );
                $scanner = new \VE\Core\MigrationScanner();
                $sync = new \VE\Sync\SyncEngine();
                $submitted_vars = isset( $data['variables'] ) && is_array( $data['variables'] )
                    ? $data['variables']
                    : [];
                $vars = ! empty( $submitted_vars )
                    ? $sync->normalize_import( $submitted_vars )
                    : $scanner->scan( $source ?: 'all' );
                $detected_count = count( $vars );
                $vars = $sync->prepare_import_rows( $vars );
                $partition = $sync->partition_resolvable_external_rows( $vars );
                $vars = $partition['variables'];
                $preview = $sync->preview_import( $vars );
                $preview['variables'] = $vars;
                $preview['variable_count'] = $detected_count;
                $preview['warnings'] = $partition['warnings'];
                $preview['skipped_aliases'] = $partition['skipped_aliases'];
                $preview['migration_counts'] = $sync->external_migration_metrics( $detected_count, $partition, $preview['changes'] );
                $preview['migration_payload'] = $vars;
                return new \WP_REST_Response( $preview, 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/migration/apply', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                // A reviewed migration is a server-owned transaction. Keep it
                // running if the builder panel closes and allow enough room for
                // large framework libraries.
                ignore_user_abort( true );
                if ( function_exists( 'wp_raise_memory_limit' ) ) {
                    wp_raise_memory_limit( 'admin' );
                }
                if ( function_exists( 'set_time_limit' ) ) {
                    @set_time_limit( 300 );
                }

                $data = $request->get_json_params();
                $source = sanitize_key( (string) ( $data['source'] ?? 'all' ) );
                $scanner = new \VE\Core\MigrationScanner();
                $sync = new \VE\Sync\SyncEngine();
                $submitted_vars = isset( $data['variables'] ) && is_array( $data['variables'] )
                    ? $data['variables']
                    : [];
                $vars = ! empty( $submitted_vars )
                    ? $sync->normalize_import( $submitted_vars )
                    : $scanner->scan( $source ?: 'all' );
                $detected_count = count( $vars );
                if ( empty( $vars ) ) {
                    return new \WP_REST_Response(
                        [ 'code' => 've_migration_empty', 'message' => 'No compatible variables were found in this source.' ],
                        422
                    );
                }

                $vars = $sync->prepare_import_rows( $vars );
                $partition = $sync->partition_resolvable_external_rows( $vars );
                $vars = $partition['variables'];
                if ( empty( $vars ) ) {
                    return new \WP_REST_Response(
                        [
                            'code'     => 've_migration_no_resolvable_rows',
                            'message'  => 'No importable variables remained after unresolved external aliases were skipped.',
                            'warnings' => $partition['warnings'],
                        ],
                        422
                    );
                }
                $preview = $sync->preview_import( $vars );
                $migration_counts = $sync->external_migration_metrics( $detected_count, $partition, $preview['changes'] );
                $changes = $sync->external_migration_changes( $preview['changes'] );
                if ( empty( $changes ) ) {
                    return new \WP_REST_Response(
                        [
                            'code'             => 've_migration_nothing_to_apply',
                            'message'          => 'The reviewed migration no longer contains any changes to apply. Run Preview Migration again.',
                            'warnings'         => $partition['warnings'],
                            'migration_counts' => $migration_counts,
                        ],
                        409
                    );
                }
                $affected_names = array_values( array_unique( array_filter( array_map( static function ( array $change ): string {
                    return sanitize_text_field( (string) ( $change['name'] ?? '' ) );
                }, $changes ) ) ) );
                $snapshot_manager = new \VE\Sync\SnapshotManager();
                $snapshot_id = $snapshot_manager->create( 'pre_import' );
                if ( is_wp_error( $snapshot_id ) ) {
                    return new \WP_REST_Response(
                        [ 'code' => $snapshot_id->get_error_code(), 'message' => $snapshot_id->get_error_message() ],
                        (int) ( $snapshot_id->get_error_data()['status'] ?? 500 )
                    );
                }
                $category_manager = new \VE\Core\VariableCategoryManager();
                $category_names = [
                    'advanced-themer' => 'Advanced Themer',
                    'core-framework'  => 'Core Framework',
                    'automatic-css'   => 'Automatic.css',
                ];
                $source_categories = [];
                foreach ( $vars as $incoming_variable ) {
                    $category_slug = sanitize_key( (string) ( $incoming_variable['category_slug'] ?? 'uncategorized' ) );
                    if ( 'uncategorized' === $category_slug || isset( $source_categories[ $category_slug ] ) ) {
                        continue;
                    }
                    $created_category = $category_manager->get_or_create( $category_names[ $category_slug ] ?? ucwords( str_replace( '-', ' ', $category_slug ) ) );
                    if ( is_wp_error( $created_category ) ) {
                        $snapshot_manager->rollback( (int) $snapshot_id );
                        return new \WP_REST_Response(
                            [ 'code' => $created_category->get_error_code(), 'message' => $created_category->get_error_message() ],
                            (int) ( $created_category->get_error_data()['status'] ?? 500 )
                        );
                    }
                    $source_categories[ $category_slug ] = $created_category;
                }
                $source_category = reset( $source_categories ) ?: $category_manager->get_by_slug( 'uncategorized' );

                $result = $sync->apply_changes( $changes, [
                    'skip_deletes'        => true,
                    'snapshot_id'         => (int) $snapshot_id,
                    'defer_palette_repair'=> true,
                    'snapshot_context'    => [ 'source' => $source ],
                ] );
                if ( ! empty( $result['errors'] ) ) {
                    return new \WP_REST_Response( $result, 422 );
                }
                // Rows apply_changes skipped (an alias whose source vanished between
                // preview and apply) were not written; drop them from the persistence
                // and verification sets so one orphan cannot fail or roll back the
                // rows that did land, and surface them as warnings.
                $apply_skipped = isset( $result['skipped_names'] ) && is_array( $result['skipped_names'] )
                    ? array_map( 'strtolower', array_map( 'strval', $result['skipped_names'] ) )
                    : [];
                if ( ! empty( $apply_skipped ) ) {
                    $affected_names = array_values( array_filter( $affected_names, static function ( $n ) use ( $apply_skipped ): bool {
                        return ! in_array( strtolower( (string) $n ), $apply_skipped, true );
                    } ) );
                    $vars = array_values( array_filter( $vars, static function ( $v ) use ( $apply_skipped ): bool {
                        return ! in_array( strtolower( (string) ( $v['name'] ?? '' ) ), $apply_skipped, true );
                    } ) );
                    $partition['warnings'] = array_merge(
                        isset( $partition['warnings'] ) && is_array( $partition['warnings'] ) ? $partition['warnings'] : [],
                        isset( $result['warnings'] ) && is_array( $result['warnings'] ) ? $result['warnings'] : []
                    );
                }
                if ( (int) ( $result['applied'] ?? 0 ) <= 0 ) {
                    $snapshot_manager->rollback( (int) $snapshot_id );
                    return new \WP_REST_Response(
                        [
                            'code'        => 've_migration_zero_writes',
                            'message'     => 'The migration completed without writing any variables, so its safety snapshot was restored. Run Preview Migration again.',
                            'applied'     => 0,
                            'snapshot_id' => (int) $snapshot_id,
                            'rolled_back' => true,
                        ],
                        422
                    );
                }

                $verification_issues = $sync->external_migration_verification_issues( $vars );
                if ( ! empty( $verification_issues ) ) {
                    $snapshot_manager->rollback( (int) $snapshot_id );
                    return new \WP_REST_Response(
                        [
                            'code'              => 've_migration_verification_failed',
                            'message'           => 'The imported variables did not match the reviewed preview, so the migration was rolled back.',
                            'applied'           => 0,
                            'snapshot_id'       => (int) $snapshot_id,
                            'rolled_back'       => true,
                            'verification_issues' => $verification_issues,
                        ],
                        422
                    );
                }

                $manager = new \VE\Core\VariableManager();
                $incoming_by_name = [];
                foreach ( $vars as $incoming_variable ) {
                    $incoming_by_name[ (string) ( $incoming_variable['name'] ?? '' ) ] = $incoming_variable;
                }
                $persisted_names = array_values( array_filter( $affected_names, static function ( string $name ) use ( $manager ): bool {
                    return null !== $manager->get_by_name( $name );
                } ) );
                if ( count( $persisted_names ) !== count( $affected_names ) ) {
                    $snapshot_manager->rollback( (int) $snapshot_id );
                    return new \WP_REST_Response(
                        [
                            'code'            => 've_migration_persistence_failed',
                            'message'         => 'The migration did not persist every reviewed variable, so the safety snapshot was restored.',
                            'applied'         => 0,
                            'snapshot_id'     => (int) $snapshot_id,
                            'rolled_back'     => true,
                            'persisted_names' => $persisted_names,
                        ],
                        422
                    );
                }

                $palette_manager = new \VE\Core\ColorPaletteManager();
                $palette_candidates = [];
                $category_candidate_ids = [];
                $origin_candidate_ids = [];
                foreach ( $vars as $incoming ) {
                    $incoming_name = (string) ( $incoming['name'] ?? '' );
                    if ( '' === $incoming_name ) {
                        continue;
                    }
                    $current = $manager->get_by_name( $incoming_name );
                    if ( ! $current ) {
                        continue;
                    }
                    $origin = sanitize_key( (string) ( $incoming['origin'] ?? '' ) );
                    if ( '' !== $origin ) {
                        $origin_candidate_ids[ $origin ][] = (int) $current['id'];
                    }
                    $palette_owner = $palette_manager->palette_owner_variable( $current );
                    if ( $palette_owner ) {
                        if ( '' !== $origin ) {
                            // Imported family roots own both Palette membership
                            // and the source badge shown for the whole family.
                            $origin_candidate_ids[ $origin ][] = (int) $palette_owner['id'];
                        }
                        $palette_slug = $palette_manager::source_palette_slug( $source ?: 'all', $incoming );
                        $palette_candidates[ $palette_slug ][ (int) $palette_owner['id'] ] = $palette_owner;
                    } else {
                        if ( '' !== $origin && 'generated' === (string) ( $current['type'] ?? '' ) && (int) ( $current['source_id'] ?? 0 ) > 0 ) {
                            $origin_candidate_ids[ $origin ][] = (int) $current['source_id'];
                        }
                        $category_slug = sanitize_key( (string) ( $incoming['category_slug'] ?? 'uncategorized' ) );
                        $category_candidate_ids[ $category_slug ][] = (int) $current['id'];
                    }
                }

                $palette = null;
                $palettes = [];
                $assigned = 0;
                foreach ( $palette_candidates as $palette_slug => $candidate_rows ) {
                    $palette_name = $palette_manager::source_palette_name(
                        $palette_slug,
                        $scanner->source_name( $source ?: 'all' )
                    );
                    $created_palette = $palette_manager->get_by_slug( sanitize_title( $palette_name ) );
                    if ( ! $created_palette ) {
                        $created_palette = $palette_manager->get_by_name( $palette_name );
                    }
                    if ( ! $created_palette && 'advanced-themer' === $palette_slug ) {
                        $legacy_palette = $palette_manager->get_by_slug( 'advanced-themer' );
                        if ( $legacy_palette ) {
                            $renamed_palette = $palette_manager->rename( (int) $legacy_palette['id'], $palette_name );
                            if ( is_wp_error( $renamed_palette ) ) {
                                $snapshot_manager->rollback( (int) $snapshot_id );
                                return new \WP_REST_Response(
                                    [ 'code' => $renamed_palette->get_error_code(), 'message' => $renamed_palette->get_error_message() ],
                                    (int) ( $renamed_palette->get_error_data()['status'] ?? 500 )
                                );
                            }
                            $created_palette = $palette_manager->get( (int) $legacy_palette['id'] );
                        }
                    }
                    if ( ! $created_palette ) {
                        $created_palette = $palette_manager->create( $palette_name );
                    }
                    if ( is_wp_error( $created_palette ) ) {
                        $snapshot_manager->rollback( (int) $snapshot_id );
                        return new \WP_REST_Response(
                            [ 'code' => $created_palette->get_error_code(), 'message' => $created_palette->get_error_message() ],
                            (int) ( $created_palette->get_error_data()['status'] ?? 500 )
                        );
                    }
                    $palettes[ $palette_slug ] = $created_palette;
                    if ( null === $palette ) {
                        $palette = $created_palette;
                    }
                }

                foreach ( $palette_candidates as $palette_slug => $candidate_rows ) {
                    $created_palette = $palettes[ $palette_slug ] ?? null;
                    if ( ! $created_palette ) {
                        continue;
                    }
                    foreach ( $candidate_rows as $current ) {
                        $assignment = $palette_manager->assign( (int) $current['id'], (int) $created_palette['id'] );
                        if ( is_wp_error( $assignment ) ) {
                            $snapshot_manager->rollback( (int) $snapshot_id );
                            return new \WP_REST_Response(
                                [ 'code' => $assignment->get_error_code(), 'message' => $assignment->get_error_message() ],
                                (int) ( $assignment->get_error_data()['status'] ?? 500 )
                            );
                        }
                        $assigned++;
                    }
                }

                foreach ( $category_candidate_ids as $category_slug => $variable_ids ) {
                    $category_move = $category_manager->move_variables(
                        $variable_ids,
                        $category_slug
                    );
                    if ( is_wp_error( $category_move ) ) {
                        $snapshot_manager->rollback( (int) $snapshot_id );
                        return new \WP_REST_Response(
                            [ 'code' => $category_move->get_error_code(), 'message' => $category_move->get_error_message() ],
                            (int) ( $category_move->get_error_data()['status'] ?? 500 )
                        );
                    }
                }
                foreach ( $origin_candidate_ids as $origin => $variable_ids ) {
                    if ( ! $category_manager->set_origin( $variable_ids, $origin ) ) {
                        $snapshot_manager->rollback( (int) $snapshot_id );
                        return new \WP_REST_Response(
                            [ 'code' => 've_migration_origin_failed', 'message' => 'Imported source labels could not be stored.' ],
                            500
                        );
                    }
                }
                $palette_manager->repair_memberships();
                $palette_assignment_issues = [];
                foreach ( $palette_candidates as $palette_slug => $candidate_rows ) {
                    $expected_palette = $palettes[ $palette_slug ] ?? null;
                    if ( ! $expected_palette ) {
                        continue;
                    }
                    foreach ( $candidate_rows as $current ) {
                        $stored_palette_id = $palette_manager->palette_id_for_variable( (int) $current['id'] );
                        if ( $stored_palette_id !== (int) $expected_palette['id'] ) {
                            $palette_assignment_issues[] = (string) ( $current['name'] ?? $current['id'] );
                        }
                    }
                }
                if ( ! empty( $palette_assignment_issues ) ) {
                    $snapshot_manager->rollback( (int) $snapshot_id );
                    return new \WP_REST_Response(
                        [
                            'code'              => 've_migration_palette_assignment_failed',
                            'message'           => 'The imported colors did not retain their reviewed source Palette, so the migration was rolled back.',
                            'applied'           => 0,
                            'snapshot_id'       => (int) $snapshot_id,
                            'rolled_back'       => true,
                            'palette_issues'    => array_values( array_unique( $palette_assignment_issues ) ),
                        ],
                        422
                    );
                }
                $scanner->remember_family_base_choices( $vars );

                return new \WP_REST_Response( array_merge( $result, [
                    'palette' => $palette,
                    'palettes' => array_values( $palettes ),
                    'palette_color_count' => $assigned,
                    'source' => $scanner->source_name( $source ?: 'all' ),
                    'warnings' => $partition['warnings'],
                    'skipped_aliases' => $partition['skipped_aliases'],
                    'migration_counts' => $migration_counts,
                    'affected_names' => $affected_names,
                    'persisted_count' => count( $persisted_names ),
                    'category' => $source_category,
                ] ), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Sync ──────────────────────────────────────────────────────
        $sync = new SyncController();

        register_rest_route( $ns, '/sync/export', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'export' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
            'args'                => [
                'format' => [ 'type' => 'string', 'default' => 'dtcg', 'enum' => [ 'dtcg', 'flat', 'figma' ] ],
            ],
        ] );

        register_rest_route( $ns, '/sync/export-css', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'export_css' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/export-bundle', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'export_bundle' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/preview', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'preview' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/preview-bundle', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'preview_bundle' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/apply', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'apply' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/apply-bundle', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'apply_bundle' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/snapshots', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'list_snapshots' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/sync/snapshot', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'create_snapshot' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/snapshot/(?P<snapshot_id>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $sync, 'delete_snapshot' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/rollback/(?P<snapshot_id>\d+)', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'rollback' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/logs', [
            [
                'methods'             => 'GET',
                'callback'            => [ $sync, 'list_logs' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $sync, 'write_log' ],
                'permission_callback' => [ SyncController::class, 'can_sync' ],
            ],
        ] );

        register_rest_route( $ns, '/diagnostics/logs', [
            [
                'methods'             => 'GET',
                'callback'            => [ $sync, 'diagnostics' ],
                'permission_callback' => [ $this, 'can_read' ],
                'args'                => [
                    'lines' => [ 'type' => 'integer', 'default' => 200 ],
                ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $sync, 'clear_diagnostics' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        // ── Pairing ─────────────────────────────────────────────────
        register_rest_route( $ns, '/sync/pair/generate', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'generate_pair' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/pair/validate', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'validate_pair' ],
            'permission_callback' => '__return_true', // Open — code is the auth
        ] );

        register_rest_route( $ns, '/sync/pair/register', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'register_figma_pair' ],
            'permission_callback' => '__return_true', // Open — Figma sends its code
        ] );

        register_rest_route( $ns, '/sync/pair/complete-figma', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'complete_figma_pair' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/pair/status', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'pair_status' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/pair/disconnect', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'disconnect' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/drift', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'drift_status' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/drift/report', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'drift_report' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/drift/preview', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'drift_preview' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/drift/apply', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'drift_apply' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/drift/command', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'drift_command' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/drift/complete', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'drift_complete' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        // ── Content Studio ─────────────────────────────────────────
        register_rest_route( $ns, '/content-studio/meta', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_content_studio_meta' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/content-studio/options/(?P<id>[a-zA-Z0-9_\-]+)', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'update_studio_option_page' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/posts', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'list_studio_posts' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'create_studio_post' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/content-studio/posts/(?P<id>\d+)', [
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'update_studio_post' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'delete_studio_post' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/content-studio/posts/(?P<id>\d+)/duplicate', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'duplicate_studio_post' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/import/preview', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'preview_studio_content_import' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/import/apply', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'apply_studio_content_import' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/cpts', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_or_update_studio_cpt' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/cpts/(?P<name>[a-zA-Z0-9_\-]+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_studio_cpt' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/fields', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_or_update_studio_fields' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/fields/(?P<id>[a-zA-Z0-9_\-]+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_studio_fields' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/migrate/jet-to-acf/preview', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'preview_jet_to_acf_migration' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/content-studio/migrate/jet-to-acf', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'run_jet_to_acf_migration' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );


        register_rest_route( $ns, '/media-studio/collections', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'list_media_collections' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'create_media_collection' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/media-studio/collections/sync', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'sync_media_collections' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/collections/assign', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'assign_media_collection' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/collections/(?P<collection>[^/]+)/items', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_media_collection_items' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/media-studio/collections/(?P<collection>[^/]+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $this, 'update_media_collection' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'delete_media_collection' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/media-studio/folders', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_media_folders' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/media-studio/folders/assign', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'assign_media_folder' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/replace', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'replace_media_file' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/convert', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'convert_media_file' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/compress', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'compress_media_file' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/rename', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'rename_media_file' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/collection-zip', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_media_collection_zip' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/media-studio/import-zip', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'import_zip_to_collection' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/metadata', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'update_media_metadata' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/unused-scan', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'scan_unused_media' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/media-studio/import-url/preview', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'preview_import_from_url' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/import-url', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'import_from_url' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/usage/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_media_usage' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );


        register_rest_route( $ns, '/media-studio/diagnostics', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_media_diagnostics' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/media-studio/url-history', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'get_media_url_history' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'clear_media_url_history' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/media-studio/rollback', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'rollback_media_action' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/plugin-studio/plugins', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'list_studio_plugins' ],
            'permission_callback' => [ $this, 'can_manage_plugins' ],
        ] );

        register_rest_route( $ns, '/plugin-studio/action', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'run_studio_plugin_action' ],
            'permission_callback' => [ $this, 'can_manage_plugins' ],
        ] );

        register_rest_route( $ns, '/plugin-studio/directory', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'search_plugin_directory' ],
            'permission_callback' => [ $this, 'can_manage_plugins' ],
            'args'                => [
                'search' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ],
            ],
        ] );

        register_rest_route( $ns, '/plugin-studio/install', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'install_directory_plugin' ],
            'permission_callback' => [ $this, 'can_manage_plugins' ],
        ] );

        register_rest_route( $ns, '/plugin-studio/upload', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'upload_plugin_zip' ],
            'permission_callback' => [ $this, 'can_manage_plugins' ],
        ] );
    }

    /* ── Permission callbacks ─────────────────────────────────────── */

    public function can_read( ?\WP_REST_Request $request = null ): bool {
        // Allow the paired Figma plugin to read VE data with X-VE-Key.
        if ( $request && SyncController::can_sync( $request ) ) {
            return true;
        }

        return current_user_can( 'edit_posts' );
    }

    public function can_write( ?\WP_REST_Request $request = null ): bool {
        // Allow the paired Figma plugin to create/update/delete VE data with X-VE-Key.
        if ( $request && SyncController::can_sync( $request ) ) {
            return true;
        }

        return current_user_can( 'manage_options' );
    }

    public function can_manage_plugins( ?\WP_REST_Request $request = null ): bool {
        return current_user_can( 'activate_plugins' ) || current_user_can( 'update_plugins' ) || current_user_can( 'delete_plugins' );
    }

    public function can_save_user_preferences( ?\WP_REST_Request $request = null ): bool {
        return get_current_user_id() > 0 && current_user_can( 'edit_posts' );
    }

    private function sanitize_user_preferences( array $preferences ): array {
        $allowed = [
            'mimamsBarSettings',
            've_skip_update_version',
            've_panel_mode',
            've_panel_pos',
            've_allow_multi_panels',
            've_deactivated_tools',
            've_deactivated_tool_surfaces',
            've_css_scss',
            've_css_source_order',
            've_css_disabled_sources',
            've_content_visible_groups',
            've_content_visible_groups_v2',
            've_content_status_filter',
            've_content_table_columns',
            've_content_editor_theme',
            've_content_studio_default_theme',
            've_content_studio_default_view',
            've_media_studio_default_view',
            've_content_media_picker_view',
            've_media_layout',
            've_media_filter',
            've_media_sort',
            've_media_collection_sort',
            've_media_collections',
            've_media_list_meta',
            've_media_list_meta_fields',
            've_media_quality_filter',
            've_media_quality_filters',
            've_media_saved_filters',
            've_media_detail_preview_mode',
            've_media_detail_preview_zoom',
            've_media_dynamic_collapsed',
            've_media_sidebar_width',
            've_media_hide_folders',
            've_media_collapsed_paths',
            've_media_replace_wp_library',
            've_media_auto_sync_external_folders',
            've_plugin_directory_view',
            've_fab_order',
            've_pos_ve_settings_pos',
            've_pos_ve_help_pos',
            've_pos_ve_css_studio_pos',
            've_pos_ve_css_recipes_pos',
            've_pos_ve_content_pos',
            've_pos_ve_media_pos',
            've_pos_ve_plugin_pos',
        ];
        $clean = [];
        foreach ( $allowed as $key ) {
            if ( ! array_key_exists( $key, $preferences ) ) {
                continue;
            }
            $value = $preferences[ $key ];
            if ( 've_media_collections' === $key ) {
                $clean[ $key ] = substr( sanitize_textarea_field( (string) $value ), 0, 200000 );
            } elseif ( is_array( $value ) ) {
                $clean[ $key ] = $this->sanitize_preference_value( $value, 0 );
            } elseif ( is_bool( $value ) || is_int( $value ) || is_float( $value ) ) {
                $clean[ $key ] = $value;
            } else {
                $clean[ $key ] = substr( sanitize_textarea_field( (string) $value ), 0, 20000 );
            }
        }
        return $clean;
    }

    private function sanitize_preference_value( array $value, int $depth ): array {
        if ( $depth >= 5 ) {
            return [];
        }
        $clean = [];
        $count = 0;
        foreach ( $value as $key => $item ) {
            if ( $count >= 200 ) {
                break;
            }
            $safe_key = is_int( $key ) ? $key : sanitize_key( (string) $key );
            if ( is_array( $item ) ) {
                $clean[ $safe_key ] = $this->sanitize_preference_value( $item, $depth + 1 );
            } elseif ( is_bool( $item ) || is_int( $item ) || is_float( $item ) ) {
                $clean[ $safe_key ] = $item;
            } else {
                $clean[ $safe_key ] = substr( sanitize_text_field( (string) $item ), 0, 2000 );
            }
            $count++;
        }
        return $clean;
    }


    private function media_collections_manager(): \VE\Core\MediaCollectionManager {
        $manager = new \VE\Core\MediaCollectionManager();
        $manager->register_taxonomy();
        return $manager;
    }

    public function list_media_collections(): \WP_REST_Response {
        $data = $this->media_collections_manager()->list_collections();
        return new \WP_REST_Response( [
            'success'     => true,
            'collections' => $data['collections'],
            'map'         => $data['map'],
            'taxonomy'    => \VE\Core\MediaCollectionManager::TAXONOMY,
        ], 200 );
    }

    public function create_media_collection( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $label = sanitize_text_field( (string) ( $params['label'] ?? $params['name'] ?? '' ) );
        if ( '' === trim( $label ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Collection name is required.' ], 400 );
        }
        $entry = [
            'icon'  => sanitize_key( (string) ( $params['icon'] ?? 'folder' ) ),
            'order' => absint( $params['order'] ?? 0 ),
        ];
        if ( isset( $params['ids'] ) && is_array( $params['ids'] ) ) {
            $entry['ids'] = array_values( array_unique( array_filter( array_map( 'absint', $params['ids'] ) ) ) );
        }
        $manager = $this->media_collections_manager();
        $term = $manager->ensure_collection( $label, $entry );
        if ( is_wp_error( $term ) || ! $term ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => is_wp_error( $term ) ? $term->get_error_message() : 'Collection could not be created.' ], 400 );
        }
        if ( isset( $entry['ids'] ) ) {
            $manager->set_collection_items( (int) $term->term_id, $entry['ids'] );
        }
        $data = $manager->list_collections();
        return new \WP_REST_Response( [ 'success' => true, 'collections' => $data['collections'], 'map' => $data['map'] ], 200 );
    }

    public function update_media_collection( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $collection = rawurldecode( (string) $request->get_param( 'collection' ) );
        $manager = $this->media_collections_manager();
        $term = $manager->get_term_by_any( $collection );
        if ( ! $term ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Collection not found.' ], 404 );
        }
        $label = sanitize_text_field( (string) ( $params['label'] ?? $params['name'] ?? $term->name ) );
        $entry = [
            'icon'  => sanitize_key( (string) ( $params['icon'] ?? get_term_meta( (int) $term->term_id, \VE\Core\MediaCollectionManager::META_ICON, true ) ?: 'folder' ) ),
            'order' => absint( $params['order'] ?? get_term_meta( (int) $term->term_id, \VE\Core\MediaCollectionManager::META_ORDER, true ) ),
        ];
        $new_term = $manager->ensure_collection( $label, $entry );
        if ( is_wp_error( $new_term ) || ! $new_term ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => is_wp_error( $new_term ) ? $new_term->get_error_message() : 'Collection could not be updated.' ], 400 );
        }
        if ( (int) $new_term->term_id !== (int) $term->term_id ) {
            $ids = $manager->collection_attachment_ids( (int) $term->term_id, -1 );
            $manager->set_collection_items( (int) $new_term->term_id, $ids );
            wp_delete_term( (int) $term->term_id, \VE\Core\MediaCollectionManager::TAXONOMY );
        }
        $data = $manager->list_collections();
        return new \WP_REST_Response( [ 'success' => true, 'collections' => $data['collections'], 'map' => $data['map'] ], 200 );
    }

    public function delete_media_collection( \WP_REST_Request $request ): \WP_REST_Response {
        $collection = rawurldecode( (string) $request->get_param( 'collection' ) );
        $manager = $this->media_collections_manager();
        $term = $manager->get_term_by_any( $collection );
        if ( ! $term ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Collection not found.' ], 404 );
        }
        $deleted = wp_delete_term( (int) $term->term_id, \VE\Core\MediaCollectionManager::TAXONOMY );
        if ( is_wp_error( $deleted ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $deleted->get_error_message() ], 400 );
        }
        $data = $manager->list_collections();
        return new \WP_REST_Response( [ 'success' => true, 'collections' => $data['collections'], 'map' => $data['map'] ], 200 );
    }

    public function sync_media_collections( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $collections = isset( $params['collections'] ) && is_array( $params['collections'] ) ? $params['collections'] : [];
        $delete_missing = ! empty( $params['delete_missing'] );
        $data = $this->media_collections_manager()->sync_from_map( $collections, $delete_missing );
        return new \WP_REST_Response( [ 'success' => true, 'collections' => $data['collections'], 'map' => $data['map'] ], 200 );
    }

    public function assign_media_collection( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $collection = $params['collection_id'] ?? ( $params['collection_key'] ?? ( $params['collection'] ?? '' ) );
        $checked = rest_sanitize_boolean( $params['checked'] ?? false );
        if ( ! $attachment_id || '' === (string) $collection ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Attachment and collection are required.' ], 400 );
        }
        $ok = $this->media_collections_manager()->assign_attachment( $attachment_id, $collection, $checked );
        if ( ! $ok ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Collection assignment failed.' ], 400 );
        }
        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function get_media_collection_items( \WP_REST_Request $request ): \WP_REST_Response {
        $collection = rawurldecode( (string) $request->get_param( 'collection' ) );
        $limit = absint( $request->get_param( 'limit' ) ?: 100 );
        $limit = $limit > 0 ? min( $limit, 500 ) : 100;
        $items = $this->media_collections_manager()->query_items( [
            'collection'       => $collection,
            'limit'            => $limit,
            'include_children' => rest_sanitize_boolean( $request->get_param( 'include_children' ) ?? false ),
            'mime'             => sanitize_text_field( (string) ( $request->get_param( 'mime' ) ?? '' ) ),
        ] );
        $payload = array_map( function ( $post ) {
            return $this->media_item_payload( (int) $post->ID );
        }, is_array( $items ) ? $items : [] );
        return new \WP_REST_Response( [ 'success' => true, 'items' => $payload, 'count' => count( $payload ) ], 200 );
    }

    public function get_media_folders(): \WP_REST_Response {
        $folders = [];
        $attachment_map = [];

        $taxonomies = [ 'happyfiles_category', 'media_folder', 'folder', 'attachment_category' ];
        $active_tax = null;

        foreach ( $taxonomies as $tax ) {
            if ( taxonomy_exists( $tax ) ) {
                $active_tax = $tax;
                break;
            }
        }

        if ( $active_tax ) {
            $terms = get_terms( [ 'taxonomy' => $active_tax, 'hide_empty' => false ] );
            if ( ! is_wp_error( $terms ) ) {
                foreach ( $terms as $term ) {
                    $folders[] = [
                        'id'     => (string) $term->term_id,
                        'name'   => $term->name,
                        'slug'   => $term->slug,
                        'parent' => (string) ( $term->parent ?? 0 ),
                    ];

                    $posts = get_posts( [
                        'post_type'      => 'attachment',
                        'posts_per_page' => -1,
                        'post_status'    => 'any',
                        'fields'         => 'ids',
                        'tax_query'      => [
                            [
                                'taxonomy' => $active_tax,
                                'field'    => 'term_id',
                                'terms'    => $term->term_id,
                            ],
                        ],
                    ] );
                    foreach ( $posts as $pid ) {
                        $attachment_map[ $pid ][] = (string) $term->term_id;
                    }
                }
            }
        }

        global $wpdb;
        $fb_table = $wpdb->prefix . 'fb_attachment_folders';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$fb_table'" ) === $fb_table ) {
            $fb_folders_table = $wpdb->prefix . 'fb_folders';
            $fb_columns = $wpdb->get_col( "DESC $fb_folders_table", 0 );
            $fb_parent_column = in_array( 'parent', $fb_columns, true ) ? 'parent' : ( in_array( 'parent_id', $fb_columns, true ) ? 'parent_id' : '' );
            $fb_parent_select = $fb_parent_column ? ', ' . $fb_parent_column . ' AS parent_id' : ', 0 AS parent_id';
            $fb_folders = $wpdb->get_results( "SELECT id, name $fb_parent_select FROM $fb_folders_table" );
            foreach ( $fb_folders as $f ) {
                $folders[] = [
                    'id'   => 'fb-' . $f->id,
                    'name' => $f->name,
                    'slug' => 'fb-' . $f->id,
                    'parent' => ! empty( $f->parent_id ) ? 'fb-' . $f->parent_id : '0',
                ];
            }
            $fb_relations = $wpdb->get_results( "SELECT attachment_id, folder_id FROM $fb_table" );
            foreach ( $fb_relations as $r ) {
                $attachment_map[ $r->attachment_id ][] = 'fb-' . $r->folder_id;
            }
        }

        return new \WP_REST_Response( [
            'folders' => $folders,
            'map'     => $attachment_map,
        ], 200 );
    }

    public function assign_media_folder( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = (int) ( $params['attachment_id'] ?? 0 );
        $folder_id = $params['folder_id'] ?? '';
        $checked = (bool) ( $params['checked'] ?? false );

        if ( ! $attachment_id ) {
            return new \WP_REST_Response( [ 'success' => false ], 400 );
        }

        $taxonomies = [ 'happyfiles_category', 'media_folder', 'folder', 'attachment_category' ];
        $active_tax = null;
        foreach ( $taxonomies as $tax ) {
            if ( taxonomy_exists( $tax ) ) {
                $active_tax = $tax;
                break;
            }
        }

        if ( $active_tax && is_numeric( $folder_id ) ) {
            $term_id = (int) $folder_id;
            $current_terms = wp_get_object_terms( $attachment_id, $active_tax, [ 'fields' => 'ids' ] );
            if ( is_wp_error( $current_terms ) ) {
                $current_terms = [];
            }
            if ( $checked ) {
                $current_terms[] = $term_id;
            } else {
                $current_terms = array_filter( $current_terms, function( $id ) use ( $term_id ) {
                    return $id !== $term_id;
                } );
            }
            wp_set_object_terms( $attachment_id, array_values( array_unique( $current_terms ) ), $active_tax );
            return new \WP_REST_Response( [ 'success' => true ], 200 );
        }

        global $wpdb;
        $fb_table = $wpdb->prefix . 'fb_attachment_folders';
        if ( strpos( $folder_id, 'fb-' ) === 0 && $wpdb->get_var( "SHOW TABLES LIKE '$fb_table'" ) === $fb_table ) {
            $fb_folder_id = (int) substr( $folder_id, 3 );
            if ( $checked ) {
                $wpdb->delete( $fb_table, [ 'attachment_id' => $attachment_id ] );
                $wpdb->insert( $fb_table, [ 'attachment_id' => $attachment_id, 'folder_id' => $fb_folder_id ] );
            } else {
                $wpdb->delete( $fb_table, [ 'attachment_id' => $attachment_id, 'folder_id' => $fb_folder_id ] );
            }
            return new \WP_REST_Response( [ 'success' => true ], 200 );
        }

        return new \WP_REST_Response( [ 'success' => false ], 400 );
    }

    private function media_item_payload( int $attachment_id ): array {
        $post = get_post( $attachment_id );
        $meta = wp_get_attachment_metadata( $attachment_id );
        if ( ! is_array( $meta ) ) {
            $meta = [];
        }

        $file = (string) get_attached_file( $attachment_id );
        $action_history = get_post_meta( $attachment_id, '_mv_media_action_history', true );
        if ( ! is_array( $action_history ) ) {
            $action_history = [];
        }
        $history = get_post_meta( $attachment_id, '_mv_media_replace_history', true );
        if ( ! is_array( $history ) ) {
            $history = $action_history;
        }

        return [
            'id'            => $attachment_id,
            'date'          => $post ? $post->post_date_gmt : '',
            'date_local'    => $post ? $post->post_date : '',
            'modified'      => $post ? $post->post_modified_gmt : '',
            'modified_local'=> $post ? $post->post_modified : '',
            'author'        => $post ? (int) $post->post_author : 0,
            'author_name'   => ( $post && $post->post_author ) ? get_the_author_meta( 'display_name', (int) $post->post_author ) : '',
            'slug'          => $post ? $post->post_name : '',
            'title'         => [ 'rendered' => $post ? get_the_title( $attachment_id ) : '', 'raw' => $post ? $post->post_title : '' ],
            'caption'       => [ 'rendered' => $post ? wp_kses_post( wpautop( $post->post_excerpt ) ) : '', 'raw' => $post ? $post->post_excerpt : '' ],
            'description'   => [ 'rendered' => $post ? wp_kses_post( wpautop( $post->post_content ) ) : '', 'raw' => $post ? $post->post_content : '' ],
            'source_url'    => wp_get_attachment_url( $attachment_id ),
            'filename'      => $file ? wp_basename( $file ) : '',
            'file_size'     => ( $file && file_exists( $file ) ) ? (int) filesize( $file ) : 0,
            'mime_type'     => get_post_mime_type( $attachment_id ),
            'alt_text'      => get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ),
            'media_details' => $meta,
            'replace_history' => array_slice( array_values( $history ), 0, 12 ),
            'action_history'  => array_slice( array_values( $action_history ), 0, 20 ),
            'mv_collections' => wp_get_object_terms( $attachment_id, \VE\Core\MediaCollectionManager::TAXONOMY, [ 'fields' => 'ids' ] ),
        ];
    }

    private function media_history_base_dir(): string {
        $upload = wp_upload_dir();
        $dir = trailingslashit( (string) ( $upload['basedir'] ?? '' ) ) . 'variable-engine/media-history';
        wp_mkdir_p( $dir );
        return $dir;
    }

    private function media_history_base_url(): string {
        $upload = wp_upload_dir();
        return trailingslashit( (string) ( $upload['baseurl'] ?? '' ) ) . 'variable-engine/media-history';
    }

    private function backup_media_file_for_history( int $attachment_id, string $file, string $reason = 'change' ): array {
        if ( ! $file || ! file_exists( $file ) || ! is_readable( $file ) ) {
            return [];
        }
        $dir = trailingslashit( $this->media_history_base_dir() ) . $attachment_id;
        wp_mkdir_p( $dir );
        $basename = wp_basename( $file );
        $safe_reason = sanitize_file_name( $reason ?: 'change' );
        $backup_name = gmdate( 'YmdHis' ) . '-' . $safe_reason . '-' . $basename;
        $backup_path = trailingslashit( $dir ) . $backup_name;
        if ( ! @copy( $file, $backup_path ) ) {
            return [];
        }
        return [
            'backup_path' => $backup_path,
            'backup_url'  => trailingslashit( $this->media_history_base_url() ) . $attachment_id . '/' . rawurlencode( $backup_name ),
        ];
    }

    private function push_media_action_history( int $attachment_id, array $entry ): array {
        $history = get_post_meta( $attachment_id, '_mv_media_action_history', true );
        if ( ! is_array( $history ) ) {
            $history = [];
        }
        $entry = array_merge( [
            'rollback_id' => wp_generate_uuid4(),
            'at'          => current_time( 'mysql' ),
            'user'        => get_current_user_id(),
        ], $entry );
        array_unshift( $history, $entry );
        $history = array_slice( array_values( $history ), 0, 24 );
        update_post_meta( $attachment_id, '_mv_media_action_history', $history );

        $replace_history = array_values( array_filter( $history, function( $row ) {
            return ! empty( $row['action'] ) && in_array( $row['action'], [ 'replace', 'convert', 'compress', 'rename', 'rollback' ], true );
        } ) );
        update_post_meta( $attachment_id, '_mv_media_replace_history', array_slice( $replace_history, 0, 12 ) );
        return $entry;
    }

    private function add_media_url_import_history( array $entry ): void {
        $history = get_option( 've_media_url_import_history', [] );
        if ( ! is_array( $history ) ) {
            $history = [];
        }
        $entry = array_merge( [
            'id'     => wp_generate_uuid4(),
            'at'     => current_time( 'mysql' ),
            'user'   => get_current_user_id(),
            'status' => 'complete',
        ], $entry );
        array_unshift( $history, $entry );
        update_option( 've_media_url_import_history', array_slice( array_values( $history ), 0, 30 ), false );
    }

    private function media_usage_report_for_attachment( int $attachment_id ) {
        $attachment = $attachment_id ? get_post( $attachment_id ) : null;
        if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
            return new \WP_Error( 'mv_media_not_found', 'Attachment not found.' );
        }

        global $wpdb;

        $url = (string) wp_get_attachment_url( $attachment_id );
        $file = (string) get_attached_file( $attachment_id );
        $path = $url ? (string) wp_parse_url( $url, PHP_URL_PATH ) : '';
        $basename = $file ? wp_basename( $file ) : ( $path ? wp_basename( $path ) : '' );
        $terms = array_values( array_unique( array_filter( [
            $url,
            $basename,
            'wp-image-' . $attachment_id,
            '"id":' . $attachment_id,
            '"id":"' . $attachment_id . '"',
            'attachment_' . $attachment_id,
            'attachment-' . $attachment_id,
        ] ) ) );

        $like_clause = function ( string $column ) use ( $wpdb, $terms ): string {
            $parts = [];
            foreach ( $terms as $term ) {
                $parts[] = $wpdb->prepare( "{$column} LIKE %s", '%' . $wpdb->esc_like( $term ) . '%' );
            }
            return $parts ? '(' . implode( ' OR ', $parts ) . ')' : '1=0';
        };

        $item_from_post = function ( $post, string $source, string $detail = '' ): array {
            return [
                'id'     => (int) $post->ID,
                'label'  => get_the_title( $post->ID ) ?: '(no title)',
                'type'   => $post->post_type,
                'status' => $post->post_status,
                'source' => $source,
                'detail' => $detail,
                'edit'   => get_edit_post_link( $post->ID, 'raw' ),
            ];
        };

        $groups = [
            'featured' => [],
            'content'  => [],
            'meta'     => [],
            'options'  => [],
        ];

        $featured_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_type, p.post_status
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
             WHERE pm.meta_key = '_thumbnail_id' AND pm.meta_value = %s
             ORDER BY p.post_modified_gmt DESC
             LIMIT 25",
            (string) $attachment_id
        ) );
        foreach ( $featured_rows as $row ) {
            $groups['featured'][] = $item_from_post( $row, 'Featured image' );
        }

        if ( $terms ) {
            $content_rows = $wpdb->get_results(
                "SELECT ID, post_title, post_type, post_status
                 FROM {$wpdb->posts}
                 WHERE post_type NOT IN ('attachment','revision','nav_menu_item')
                   AND " . $like_clause( 'post_content' ) . "
                 ORDER BY post_modified_gmt DESC
                 LIMIT 25"
            );
            foreach ( $content_rows as $row ) {
                $groups['content'][] = $item_from_post( $row, 'Post content' );
            }

            $ignored_meta_keys = [
                '_thumbnail_id',
                '_wp_attached_file',
                '_wp_attachment_metadata',
                '_wp_attachment_image_alt',
                '_wp_attachment_backup_sizes',
                '_wp_attachment_context',
                '_mv_media_replace_history',
                '_mv_media_action_history',
            ];
            $ignored_meta_placeholders = implode( ',', array_fill( 0, count( $ignored_meta_keys ), '%s' ) );
            $meta_sql = "SELECT pm.post_id, pm.meta_key, p.post_title, p.post_type, p.post_status
                 FROM {$wpdb->postmeta} pm
                 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                 WHERE pm.meta_key NOT IN ({$ignored_meta_placeholders})
                   AND pm.post_id <> %d
                   AND p.post_type NOT IN ('attachment','revision','nav_menu_item')
                   AND " . $like_clause( 'pm.meta_value' ) . "
                 ORDER BY p.post_modified_gmt DESC
                 LIMIT 25";
            $meta_rows = $wpdb->get_results( $wpdb->prepare(
                $meta_sql,
                array_merge( $ignored_meta_keys, [ $attachment_id ] )
            ) );
            foreach ( $meta_rows as $row ) {
                $post_stub = (object) [
                    'ID'          => (int) $row->post_id,
                    'post_title'  => $row->post_title,
                    'post_type'   => $row->post_type,
                    'post_status' => $row->post_status,
                ];
                $groups['meta'][] = $item_from_post( $post_stub, 'Post meta', (string) $row->meta_key );
            }

            $option_rows = $wpdb->get_results(
                "SELECT option_name
                 FROM {$wpdb->options}
                 WHERE option_name NOT LIKE '\\_transient\\_%'
                   AND option_name NOT LIKE '\\_site\\_transient\\_%'
                   AND " . $like_clause( 'option_value' ) . "
                 ORDER BY option_name ASC
                 LIMIT 15"
            );
            foreach ( $option_rows as $row ) {
                $groups['options'][] = [
                    'id'     => (string) $row->option_name,
                    'label'  => (string) $row->option_name,
                    'type'   => 'option',
                    'status' => '',
                    'source' => 'WordPress option',
                    'detail' => 'Stored option data',
                    'edit'   => '',
                ];
            }
        }

        $total = 0;
        foreach ( $groups as $rows ) {
            $total += count( $rows );
        }

        return [
            'success' => true,
            'total'   => $total,
            'unused'  => 0 === $total,
            'groups'  => $groups,
            'limited' => $total >= 90,
        ];
    }

    public function scan_unused_media( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $ids = isset( $params['attachment_ids'] ) && is_array( $params['attachment_ids'] ) ? $params['attachment_ids'] : [];
        $ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );

        if ( empty( $ids ) ) {
            $ids = get_posts( [
                'post_type'      => 'attachment',
                'post_status'    => 'inherit',
                'post_mime_type' => 'image',
                'posts_per_page' => 500,
                'fields'         => 'ids',
                'orderby'        => 'date',
                'order'          => 'DESC',
            ] );
        }

        $ids = array_slice( $ids, 0, 500 );
        if ( empty( $ids ) ) {
            return new \WP_REST_Response( [
                'success'     => true,
                'unused_ids'  => [],
                'used_ids'    => [],
                'skipped_ids' => [],
                'scanned'     => 0,
                'limited'     => false,
                'message'     => 'No image attachments were available to scan.',
            ], 200 );
        }

        global $wpdb;

        $refs_by_id = [];
        $used_map = [];
        $skipped = [];
        foreach ( $ids as $id ) {
            $id = absint( $id );
            if ( ! $id || get_post_type( $id ) !== 'attachment' || 0 !== strpos( (string) get_post_mime_type( $id ), 'image/' ) ) {
                $skipped[] = $id;
                continue;
            }

            $url = (string) wp_get_attachment_url( $id );
            $file = (string) get_attached_file( $id );
            $path = $url ? (string) wp_parse_url( $url, PHP_URL_PATH ) : '';
            $basename = $file ? wp_basename( $file ) : ( $path ? wp_basename( $path ) : '' );
            $refs_by_id[ $id ] = array_values( array_unique( array_filter( [
                $url,
                $path,
                $basename,
                'wp-image-' . $id,
                '"id":' . $id,
                '"id":"' . $id . '"',
                'attachment_' . $id,
                'attachment-' . $id,
            ] ) ) );
            $used_map[ $id ] = false;
        }

        if ( empty( $refs_by_id ) ) {
            return new \WP_REST_Response( [
                'success'     => true,
                'unused_ids'  => [],
                'used_ids'    => [],
                'skipped_ids' => $skipped,
                'scanned'     => 0,
                'limited'     => false,
                'message'     => 'No image attachments were available to scan.',
            ], 200 );
        }

        $basename_map = [];
        foreach ( $refs_by_id as $id => $terms ) {
            foreach ( $terms as $term ) {
                $term = (string) $term;
                if ( '' === $term ) {
                    continue;
                }
                $basename = wp_basename( $term );
                if ( $basename && false !== strpos( $basename, '.' ) ) {
                    $basename_map[ $basename ][] = (int) $id;
                }
            }
        }

        $mark_refs_in_text = function ( $text ) use ( &$used_map, $basename_map ): void {
            if ( ! is_string( $text ) || '' === $text ) {
                return;
            }

            if ( preg_match_all( '/(?:wp-image-|attachment[_-])(\d+)|["\']id["\']\s*:\s*["\']?(\d+)/i', $text, $matches, PREG_SET_ORDER ) ) {
                foreach ( $matches as $match ) {
                    $id = absint( ! empty( $match[1] ) ? $match[1] : ( $match[2] ?? 0 ) );
                    if ( $id && isset( $used_map[ $id ] ) ) {
                        $used_map[ $id ] = true;
                    }
                }
            }

            if ( empty( $basename_map ) ) {
                return;
            }

            $lower_text = strtolower( $text );
            if ( false === strpos( $lower_text, 'uploads' )
                && false === strpos( $lower_text, '.jpg' )
                && false === strpos( $lower_text, '.jpeg' )
                && false === strpos( $lower_text, '.png' )
                && false === strpos( $lower_text, '.webp' )
                && false === strpos( $lower_text, '.gif' )
                && false === strpos( $lower_text, '.svg' ) ) {
                return;
            }

            foreach ( $basename_map as $basename => $ids_for_basename ) {
                $first_id = (int) reset( $ids_for_basename );
                if ( $first_id && ! empty( $used_map[ $first_id ] ) ) {
                    continue;
                }
                if ( false !== strpos( $text, $basename ) ) {
                    foreach ( $ids_for_basename as $id ) {
                        if ( isset( $used_map[ $id ] ) ) {
                            $used_map[ $id ] = true;
                        }
                    }
                }
            }
        };

        $placeholders = implode( ',', array_fill( 0, count( $refs_by_id ), '%d' ) );
        $featured_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value IN ({$placeholders})",
            array_keys( $refs_by_id )
        ) );
        foreach ( $featured_ids as $featured_id ) {
            $featured_id = absint( $featured_id );
            if ( isset( $used_map[ $featured_id ] ) ) {
                $used_map[ $featured_id ] = true;
            }
        }

        $candidate_like = function ( string $column ) use ( $wpdb ): string {
            $needles = [ 'wp-image-', '/uploads/', 'wp-content/uploads', '"id":', 'attachment_', 'attachment-' ];
            $parts = [];
            foreach ( $needles as $needle ) {
                $parts[] = $wpdb->prepare( "{$column} LIKE %s", '%' . $wpdb->esc_like( $needle ) . '%' );
            }
            return '(' . implode( ' OR ', $parts ) . ')';
        };

        $limited = count( $ids ) >= 500;
        $scan_started = microtime( true );
        $scan_deadline = $scan_started + 18.0;
        $time_exceeded = function () use ( &$limited, $scan_deadline ): bool {
            if ( microtime( true ) > $scan_deadline ) {
                $limited = true;
                return true;
            }
            return false;
        };

        $content_rows = $wpdb->get_results(
            "SELECT post_content
             FROM {$wpdb->posts}
             WHERE post_type NOT IN ('attachment','revision','nav_menu_item')
               AND post_status NOT IN ('auto-draft','trash')
               AND " . $candidate_like( 'post_content' ) . "
             ORDER BY post_modified_gmt DESC
             LIMIT 900"
        );
        if ( count( $content_rows ) >= 900 ) {
            $limited = true;
        }
        foreach ( $content_rows as $index => $row ) {
            if ( 0 === ( $index % 25 ) && $time_exceeded() ) {
                break;
            }
            $mark_refs_in_text( (string) $row->post_content );
        }

        $ignored_meta_keys = [
            '_thumbnail_id',
            '_wp_attached_file',
            '_wp_attachment_metadata',
            '_wp_attachment_image_alt',
            '_wp_attachment_backup_sizes',
            '_wp_attachment_context',
            '_mv_media_replace_history',
        ];
        $ignored_meta_placeholders = implode( ',', array_fill( 0, count( $ignored_meta_keys ), '%s' ) );
        $attachment_placeholders = implode( ',', array_fill( 0, count( $refs_by_id ), '%d' ) );
        $meta_sql = "SELECT pm.meta_value
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key NOT IN ({$ignored_meta_placeholders})
               AND pm.post_id NOT IN ({$attachment_placeholders})
               AND p.post_type NOT IN ('attachment','revision','nav_menu_item')
               AND p.post_status NOT IN ('auto-draft','trash')
               AND " . $candidate_like( 'pm.meta_value' ) . "
             ORDER BY p.post_modified_gmt DESC
             LIMIT 1400";
        $meta_rows = $wpdb->get_results( $wpdb->prepare(
            $meta_sql,
            array_merge( $ignored_meta_keys, array_keys( $refs_by_id ) )
        ) );
        if ( count( $meta_rows ) >= 1400 ) {
            $limited = true;
        }
        foreach ( $meta_rows as $index => $row ) {
            if ( 0 === ( $index % 25 ) && $time_exceeded() ) {
                break;
            }
            $mark_refs_in_text( maybe_serialize( $row->meta_value ) );
        }

        $option_rows = $wpdb->get_results(
            "SELECT option_value
             FROM {$wpdb->options}
             WHERE option_name NOT LIKE '\\_transient\\_%'
               AND option_name NOT LIKE '\\_site\\_transient\\_%'
               AND " . $candidate_like( 'option_value' ) . "
             ORDER BY option_name ASC
             LIMIT 700"
        );
        if ( count( $option_rows ) >= 700 ) {
            $limited = true;
        }
        foreach ( $option_rows as $index => $row ) {
            if ( 0 === ( $index % 20 ) && $time_exceeded() ) {
                break;
            }
            $mark_refs_in_text( maybe_serialize( $row->option_value ) );
        }

        $used = [];
        $unused = [];
        foreach ( $used_map as $id => $is_used ) {
            if ( $is_used ) {
                $used[] = (int) $id;
            } else {
                $unused[] = (int) $id;
            }
        }

        return new \WP_REST_Response( [
            'success'     => true,
            'unused_ids'  => $unused,
            'used_ids'    => $used,
            'skipped_ids' => $skipped,
            'scanned'     => count( $unused ) + count( $used ),
            'limited'     => $limited,
            'message'     => $limited ? 'Scanned with a safety limit. Narrow the collection/search for a deeper pass.' : 'Scanned featured images, content, post meta, and options for references MV can safely detect.',
        ], 200 );
    }

    public function update_media_metadata( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $post = $attachment_id ? get_post( $attachment_id ) : null;
        if ( ! $post || 'attachment' !== $post->post_type ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Attachment not found.' ], 404 );
        }

        $update = [ 'ID' => $attachment_id ];
        if ( array_key_exists( 'title', $params ) ) {
            $title = sanitize_text_field( (string) $params['title'] );
            if ( '' !== trim( $title ) ) {
                $update['post_title'] = $title;
                $update['post_name']  = sanitize_title( $title );
            }
        }
        if ( array_key_exists( 'caption', $params ) ) {
            $update['post_excerpt'] = wp_kses_post( (string) $params['caption'] );
        }
        if ( array_key_exists( 'description', $params ) ) {
            $update['post_content'] = wp_kses_post( (string) $params['description'] );
        }

        if ( count( $update ) > 1 ) {
            $result = wp_update_post( $update, true );
            if ( is_wp_error( $result ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
            }
        }

        if ( array_key_exists( 'alt_text', $params ) ) {
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( (string) $params['alt_text'] ) );
        }

        return new \WP_REST_Response( [
            'success' => true,
            'item'    => $this->media_item_payload( $attachment_id ),
        ], 200 );
    }

    private function remove_directory_recursive( string $dir ): void {
        if ( ! is_dir( $dir ) ) {
            return;
        }
        $items = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS ),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ( $items as $item ) {
            $path = $item->getPathname();
            if ( $item->isDir() ) {
                @rmdir( $path );
            } else {
                @unlink( $path );
            }
        }
        @rmdir( $dir );
    }

    public function import_zip_to_collection( \WP_REST_Request $request ): \WP_REST_Response {
        $collection = sanitize_text_field( (string) $request->get_param( 'collection' ) );
        $manager = $this->media_collections_manager();
        $term = $manager->get_term_by_any( $collection );
        if ( ! $term ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Collection not found.' ], 404 );
        }
        if ( get_term_meta( (int) $term->term_id, \VE\Core\MediaCollectionManager::META_LOCKED, true ) === '1' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Unlock this collection before importing ZIP media.' ], 403 );
        }

        $files = $request->get_file_params();
        $zip_file = $files['zip_file'] ?? ( $files['file'] ?? null );
        if ( empty( $zip_file ) || empty( $zip_file['tmp_name'] ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Choose a ZIP file to import.' ], 400 );
        }

        $name = sanitize_file_name( (string) ( $zip_file['name'] ?? 'media.zip' ) );
        if ( strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) !== 'zip' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Only .zip files can be imported.' ], 400 );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        if ( function_exists( 'WP_Filesystem' ) ) {
            WP_Filesystem();
        }

        $upload = wp_upload_dir();
        $work_dir = trailingslashit( (string) ( $upload['basedir'] ?? sys_get_temp_dir() ) ) . 'variable-engine/import-zip/' . wp_generate_uuid4();
        if ( ! wp_mkdir_p( $work_dir ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Could not prepare the ZIP import folder.' ], 500 );
        }

        $unzipped = unzip_file( $zip_file['tmp_name'], $work_dir );
        if ( is_wp_error( $unzipped ) ) {
            $this->remove_directory_recursive( $work_dir );
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'ZIP import failed: ' . $unzipped->get_error_message() ], 400 );
        }

        $imported = [];
        $skipped = [];
        $max_files = 120;
        $iterator = new \RecursiveIteratorIterator( new \RecursiveDirectoryIterator( $work_dir, \FilesystemIterator::SKIP_DOTS ) );
        foreach ( $iterator as $file_info ) {
            if ( count( $imported ) >= $max_files ) {
                break;
            }
            if ( ! $file_info->isFile() ) {
                continue;
            }
            $path = $file_info->getPathname();
            $relative = str_replace( trailingslashit( $work_dir ), '', $path );
            $base = sanitize_file_name( wp_basename( $path ) );
            if ( '' === $base || 0 === strpos( $base, '.' ) || false !== strpos( $relative, '__MACOSX' ) ) {
                $skipped[] = $relative;
                continue;
            }
            $type = wp_check_filetype( $base );
            if ( empty( $type['type'] ) || ! preg_match( '#^(image|video|audio)/|^application/(pdf|zip)#', (string) $type['type'] ) ) {
                $skipped[] = $relative;
                continue;
            }
            $tmp = wp_tempnam( $base );
            if ( ! $tmp || ! @copy( $path, $tmp ) ) {
                if ( $tmp ) {
                    @unlink( $tmp );
                }
                $skipped[] = $relative;
                continue;
            }
            $file_array = [
                'name'     => $base,
                'tmp_name' => $tmp,
                'type'     => $type['type'],
            ];
            $attachment_id = media_handle_sideload( $file_array, 0 );
            if ( is_wp_error( $attachment_id ) ) {
                @unlink( $tmp );
                $skipped[] = $relative;
                continue;
            }
            $manager->assign_attachment( (int) $attachment_id, (int) $term->term_id, true );
            $imported[] = $this->media_item_payload( (int) $attachment_id );
        }

        $this->remove_directory_recursive( $work_dir );
        $data = $manager->list_collections();

        return new \WP_REST_Response( [
            'success'     => true,
            'count'       => count( $imported ),
            'skipped'     => count( $skipped ),
            'limited'     => count( $imported ) >= $max_files,
            'items'       => $imported,
            'collections' => $data['collections'],
            'map'         => $data['map'],
            'message'     => count( $imported ) ? 'Imported ZIP media into the collection.' : 'No supported media files were found in that ZIP.',
        ], count( $imported ) ? 200 : 400 );
    }

    public function get_media_usage( \WP_REST_Request $request ): \WP_REST_Response {
        $attachment_id = absint( $request->get_param( 'id' ) );
        $report = $this->media_usage_report_for_attachment( $attachment_id );
        if ( is_wp_error( $report ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $report->get_error_message() ], 404 );
        }
        return new \WP_REST_Response( $report, 200 );
    }

    public function get_media_diagnostics( \WP_REST_Request $request ): \WP_REST_Response {
        $limit = 800;
        $ids = get_posts( [
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'fields'         => 'ids',
            'posts_per_page' => $limit,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ] );

        $now = time();
        $recent_cutoff = $now - ( 14 * DAY_IN_SECONDS );
        $diagnostics = [
            'success'             => true,
            'total'               => 0,
            'total_size'          => 0,
            'missing_alt'         => 0,
            'unused'              => null,
            'large_files'         => 0,
            'recent_uploads'      => 0,
            'missing_files'       => 0,
            'empty_title'         => 0,
            'duplicate_filenames' => 0,
            'limited'             => false,
            'sample_limit'        => $limit,
            'issues'              => [],
        ];
        $filenames = [];

        foreach ( $ids as $id ) {
            $id = (int) $id;
            $diagnostics['total']++;
            $file = (string) get_attached_file( $id );
            $size = ( $file && file_exists( $file ) ) ? (int) filesize( $file ) : 0;
            $diagnostics['total_size'] += $size;
            if ( ! $file || ! file_exists( $file ) ) {
                $diagnostics['missing_files']++;
                $diagnostics['issues'][] = [ 'id' => $id, 'type' => 'missing_file', 'label' => get_the_title( $id ) ?: 'Media #' . $id ];
            }
            if ( $size >= 1024 * 1024 ) {
                $diagnostics['large_files']++;
            }
            $post = get_post( $id );
            if ( $post && strtotime( $post->post_date_gmt ?: $post->post_date ) >= $recent_cutoff ) {
                $diagnostics['recent_uploads']++;
            }
            if ( $post && '' === trim( (string) $post->post_title ) ) {
                $diagnostics['empty_title']++;
            }
            $mime = (string) get_post_mime_type( $id );
            if ( 0 === strpos( $mime, 'image/' ) && '' === trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) ) {
                $diagnostics['missing_alt']++;
            }
            $base = $file ? strtolower( wp_basename( $file ) ) : '';
            if ( $base ) {
                $filenames[ $base ] = ( $filenames[ $base ] ?? 0 ) + 1;
            }
        }

        foreach ( $filenames as $count ) {
            if ( $count > 1 ) {
                $diagnostics['duplicate_filenames'] += $count;
            }
        }
        $diagnostics['limited'] = count( $ids ) >= $limit;
        $diagnostics['total_size_human'] = size_format( (int) $diagnostics['total_size'], 1 );
        $diagnostics['issues'] = array_slice( $diagnostics['issues'], 0, 12 );

        return new \WP_REST_Response( $diagnostics, 200 );
    }

    public function get_media_url_history( \WP_REST_Request $request ): \WP_REST_Response {
        $history = get_option( 've_media_url_import_history', [] );
        if ( ! is_array( $history ) ) {
            $history = [];
        }
        return new \WP_REST_Response( [ 'success' => true, 'history' => array_values( $history ) ], 200 );
    }

    public function clear_media_url_history( \WP_REST_Request $request ): \WP_REST_Response {
        update_option( 've_media_url_import_history', [], false );
        return new \WP_REST_Response( [ 'success' => true, 'history' => [] ], 200 );
    }

    public function rollback_media_action( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $rollback_id = sanitize_text_field( (string) ( $params['rollback_id'] ?? '' ) );
        if ( ! $attachment_id || '' === $rollback_id || get_post_type( $attachment_id ) !== 'attachment' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Missing rollback target.' ], 400 );
        }

        $history = get_post_meta( $attachment_id, '_mv_media_action_history', true );
        if ( ! is_array( $history ) ) {
            $history = [];
        }
        $entry = null;
        foreach ( $history as $row ) {
            if ( isset( $row['rollback_id'] ) && $row['rollback_id'] === $rollback_id ) {
                $entry = $row;
                break;
            }
        }
        if ( ! is_array( $entry ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Rollback point was not found.' ], 404 );
        }

        require_once ABSPATH . 'wp-admin/includes/image.php';
        $current_file = (string) get_attached_file( $attachment_id );
        $current_mime = get_post_mime_type( $attachment_id );
        $current_meta = wp_get_attachment_metadata( $attachment_id );
        $current_backup = $current_file ? $this->backup_media_file_for_history( $attachment_id, $current_file, 'pre-rollback' ) : [];

        $restored_path = '';
        $source_path = '';
        if ( ! empty( $entry['backup_path'] ) && file_exists( (string) $entry['backup_path'] ) ) {
            $source_path = (string) $entry['backup_path'];
        } elseif ( ! empty( $entry['old_path'] ) && file_exists( (string) $entry['old_path'] ) ) {
            $source_path = (string) $entry['old_path'];
        }

        $action = (string) ( $entry['action'] ?? '' );
        if ( 'rename' === $action ) {
            $old_title = sanitize_text_field( (string) ( $entry['old_title'] ?? '' ) );
            if ( '' !== $old_title ) {
                wp_update_post( [
                    'ID'         => $attachment_id,
                    'post_title' => $old_title,
                    'post_name'  => sanitize_title( $entry['old_slug'] ?? $old_title ),
                ] );
            }
        }

        if ( $source_path ) {
            $desired_path = ( in_array( $action, [ 'convert', 'rename' ], true ) && ! empty( $entry['old_path'] ) ) ? (string) $entry['old_path'] : $current_file;
            if ( ! $desired_path ) {
                $desired_path = (string) ( $entry['old_path'] ?? $source_path );
            }
            if ( $desired_path && wp_mkdir_p( dirname( $desired_path ) ) && @copy( $source_path, $desired_path ) ) {
                $restored_path = $desired_path;
                if ( $restored_path !== $current_file ) {
                    update_attached_file( $attachment_id, $restored_path );
                }
            } elseif ( $current_file && file_exists( $current_file ) && is_writable( dirname( $current_file ) ) && @copy( $source_path, $current_file ) ) {
                $restored_path = $current_file;
            } else {
                return new \WP_REST_Response( [ 'success' => false, 'message' => 'Could not restore the backup file.' ], 500 );
            }
        } elseif ( 'rename' !== $action ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'The backup file for this rollback point is missing.' ], 404 );
        }

        if ( $restored_path ) {
            $filetype = wp_check_filetype( $restored_path );
            wp_update_post( [
                'ID'             => $attachment_id,
                'post_mime_type' => $entry['old_mime'] ?? ( $filetype['type'] ?: $current_mime ),
            ] );
            $metadata = is_array( $entry['old_metadata'] ?? null ) ? $entry['old_metadata'] : wp_generate_attachment_metadata( $attachment_id, $restored_path );
            if ( is_array( $metadata ) ) {
                wp_update_attachment_metadata( $attachment_id, $metadata );
            }
        }

        $this->push_media_action_history( $attachment_id, array_merge( [
            'action'       => 'rollback',
            'old_file'     => $current_file ? wp_basename( $current_file ) : '',
            'old_path'     => $current_file,
            'old_mime'     => $current_mime,
            'old_metadata' => is_array( $current_meta ) ? $current_meta : [],
            'new_file'     => $restored_path ? wp_basename( $restored_path ) : ( $entry['old_file'] ?? '' ),
            'new_path'     => $restored_path,
            'new_mime'     => $entry['old_mime'] ?? $current_mime,
            'source_action'=> $action,
        ], $current_backup ) );

        return new \WP_REST_Response( [ 'success' => true, 'item' => $this->media_item_payload( $attachment_id ) ], 200 );
    }

    public function replace_media_file( \WP_REST_Request $request ): \WP_REST_Response {
        $attachment_id = absint( $request->get_param( 'attachment_id' ) );
        $files = $request->get_file_params();

        if ( ! $attachment_id || empty( $files['file'] ) || ! get_post( $attachment_id ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Missing attachment or upload file.' ], 400 );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $old_file = (string) get_attached_file( $attachment_id );
        $old_url = wp_get_attachment_url( $attachment_id );
        $old_mime = get_post_mime_type( $attachment_id );
        $old_meta = wp_get_attachment_metadata( $attachment_id );
        $backup = $old_file ? $this->backup_media_file_for_history( $attachment_id, $old_file, 'replace' ) : [];

        $upload = wp_handle_upload( $files['file'], [ 'test_form' => false ] );
        if ( isset( $upload['error'] ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $upload['error'] ], 400 );
        }

        $new_file = $upload['file'];
        $target_file = $old_file ?: $new_file;

        if ( $old_file && file_exists( $old_file ) ) {
            @copy( $new_file, $old_file );
            @unlink( $new_file );
        } else {
            update_attached_file( $attachment_id, $new_file );
            $target_file = $new_file;
        }

        $filetype = wp_check_filetype( $target_file );
        wp_update_post( [
            'ID'             => $attachment_id,
            'post_mime_type' => $filetype['type'] ?: ( $upload['type'] ?? get_post_mime_type( $attachment_id ) ),
        ] );

        $metadata = wp_generate_attachment_metadata( $attachment_id, $target_file );
        if ( is_array( $metadata ) ) {
            wp_update_attachment_metadata( $attachment_id, $metadata );
        }

        $this->push_media_action_history( $attachment_id, array_merge( [
            'action'       => 'replace',
            'old_file'     => $old_file ? wp_basename( $old_file ) : '',
            'old_path'     => $old_file,
            'old_url'      => $old_url,
            'old_mime'     => $old_mime,
            'old_metadata' => is_array( $old_meta ) ? $old_meta : [],
            'new_file'     => $target_file ? wp_basename( $target_file ) : '',
            'new_path'     => $target_file,
            'new_mime'     => $filetype['type'] ?: ( $upload['type'] ?? '' ),
        ], $backup ) );

        return new \WP_REST_Response( [ 'success' => true, 'item' => $this->media_item_payload( $attachment_id ) ], 200 );
    }


    public function convert_media_file( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $format = sanitize_key( $params['format'] ?? 'webp' );
        $allowed = [ 'webp', 'avif', 'jpeg', 'jpg', 'png' ];

        if ( ! $attachment_id || ! in_array( $format, $allowed, true ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Invalid conversion request.' ], 400 );
        }

        $file = (string) get_attached_file( $attachment_id );
        if ( ! $file || ! file_exists( $file ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Source file not found.' ], 404 );
        }

        require_once ABSPATH . 'wp-admin/includes/image.php';

        $old_mime = get_post_mime_type( $attachment_id );
        $old_meta = wp_get_attachment_metadata( $attachment_id );
        $backup = $this->backup_media_file_for_history( $attachment_id, $file, 'convert' );

        $editor = wp_get_image_editor( $file );
        if ( is_wp_error( $editor ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $editor->get_error_message() ], 400 );
        }

        $ext = $format === 'jpg' ? 'jpeg' : $format;
        $mime = 'image/' . $ext;
        $base = preg_replace( '/\.[^.]+$/', '', $file );
        $dest = $base . '.' . ( $ext === 'jpeg' ? 'jpg' : $ext );
        $saved = $editor->save( $dest, $mime );

        if ( is_wp_error( $saved ) || empty( $saved['path'] ) ) {
            $message = is_wp_error( $saved ) ? $saved->get_error_message() : 'The server image editor could not save that format.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        update_attached_file( $attachment_id, $saved['path'] );
        wp_update_post( [
            'ID'             => $attachment_id,
            'post_mime_type' => $saved['mime-type'] ?? $mime,
        ] );

        $metadata = wp_generate_attachment_metadata( $attachment_id, $saved['path'] );
        if ( is_array( $metadata ) ) {
            wp_update_attachment_metadata( $attachment_id, $metadata );
        }

        $this->push_media_action_history( $attachment_id, array_merge( [
            'action'       => 'convert',
            'old_file'     => wp_basename( $file ),
            'old_path'     => $file,
            'old_url'      => wp_get_attachment_url( $attachment_id ),
            'old_mime'     => $old_mime,
            'old_metadata' => is_array( $old_meta ) ? $old_meta : [],
            'new_file'     => wp_basename( $saved['path'] ),
            'new_path'     => $saved['path'],
            'new_mime'     => $saved['mime-type'] ?? $mime,
        ], $backup ) );

        return new \WP_REST_Response( [ 'success' => true, 'item' => $this->media_item_payload( $attachment_id ) ], 200 );
    }


    public function compress_media_file( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $quality = isset( $params['quality'] ) ? absint( $params['quality'] ) : 82;
        $quality = max( 60, min( 92, $quality ) );

        if ( ! $attachment_id || ! get_post( $attachment_id ) || get_post_type( $attachment_id ) !== 'attachment' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Attachment not found.' ], 404 );
        }

        $file = (string) get_attached_file( $attachment_id );
        if ( ! $file || ! file_exists( $file ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Source file not found.' ], 404 );
        }

        $mime = get_post_mime_type( $attachment_id );
        if ( 0 !== strpos( (string) $mime, 'image/' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Only image files can be compressed.' ], 400 );
        }

        require_once ABSPATH . 'wp-admin/includes/image.php';

        $before = filesize( $file );
        $old_meta = wp_get_attachment_metadata( $attachment_id );
        $backup = $this->backup_media_file_for_history( $attachment_id, $file, 'compress' );
        $editor = wp_get_image_editor( $file );
        if ( is_wp_error( $editor ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $editor->get_error_message() ], 400 );
        }

        if ( method_exists( $editor, 'set_quality' ) ) {
            $editor->set_quality( $quality );
        }

        $saved = $editor->save( $file, $mime );
        if ( is_wp_error( $saved ) || empty( $saved['path'] ) ) {
            $message = is_wp_error( $saved ) ? $saved->get_error_message() : 'The server image editor could not compress that file.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        $metadata = wp_generate_attachment_metadata( $attachment_id, $saved['path'] );
        if ( is_array( $metadata ) ) {
            wp_update_attachment_metadata( $attachment_id, $metadata );
        }

        $after = file_exists( $saved['path'] ) ? filesize( $saved['path'] ) : 0;
        $this->push_media_action_history( $attachment_id, array_merge( [
            'action'       => 'compress',
            'old_file'     => wp_basename( $file ),
            'old_path'     => $file,
            'old_mime'     => $mime,
            'old_metadata' => is_array( $old_meta ) ? $old_meta : [],
            'new_file'     => wp_basename( $saved['path'] ),
            'new_path'     => $saved['path'],
            'new_mime'     => $mime,
            'before_bytes' => $before,
            'after_bytes'  => $after,
        ], $backup ) );

        return new \WP_REST_Response( [
            'success'      => true,
            'item'         => $this->media_item_payload( $attachment_id ),
            'before_bytes' => $before,
            'after_bytes'  => $after,
        ], 200 );
    }


    public function rename_media_file( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $title = sanitize_text_field( $params['title'] ?? '' );
        $rename_file = rest_sanitize_boolean( $params['rename_file'] ?? false );

        if ( ! $attachment_id || ! get_post( $attachment_id ) || get_post_type( $attachment_id ) !== 'attachment' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Attachment not found.' ], 404 );
        }

        if ( empty( $title ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'A filename/title is required.' ], 400 );
        }

        $post = get_post( $attachment_id );
        $old_title = $post ? $post->post_title : '';
        $old_slug = $post ? $post->post_name : '';
        $old_file = (string) get_attached_file( $attachment_id );
        $old_mime = get_post_mime_type( $attachment_id );
        $old_meta = wp_get_attachment_metadata( $attachment_id );
        $backup = $old_file ? $this->backup_media_file_for_history( $attachment_id, $old_file, 'rename' ) : [];
        $new_path = $old_file;

        wp_update_post( [
            'ID'         => $attachment_id,
            'post_title' => $title,
            'post_name'  => sanitize_title( $title ),
        ] );

        if ( $rename_file ) {
            $file = get_attached_file( $attachment_id );
            if ( $file && file_exists( $file ) && is_writable( dirname( $file ) ) ) {
                require_once ABSPATH . 'wp-admin/includes/image.php';
                $pathinfo = pathinfo( $file );
                $extension = isset( $pathinfo['extension'] ) ? '.' . strtolower( $pathinfo['extension'] ) : '';
                $new_name = wp_unique_filename( $pathinfo['dirname'], sanitize_file_name( $title ) . $extension );
                $new_path = trailingslashit( $pathinfo['dirname'] ) . $new_name;
                if ( @rename( $file, $new_path ) ) {
                    update_attached_file( $attachment_id, $new_path );
                    $metadata = wp_generate_attachment_metadata( $attachment_id, $new_path );
                    if ( is_array( $metadata ) ) {
                        wp_update_attachment_metadata( $attachment_id, $metadata );
                    }
                } else {
                    $new_path = $file;
                }
            }
        }

        $this->push_media_action_history( $attachment_id, array_merge( [
            'action'       => 'rename',
            'old_title'    => $old_title,
            'old_slug'     => $old_slug,
            'old_file'     => $old_file ? wp_basename( $old_file ) : '',
            'old_path'     => $old_file,
            'old_mime'     => $old_mime,
            'old_metadata' => is_array( $old_meta ) ? $old_meta : [],
            'new_title'    => $title,
            'new_file'     => $new_path ? wp_basename( $new_path ) : '',
            'new_path'     => $new_path,
            'new_mime'     => get_post_mime_type( $attachment_id ),
        ], $backup ) );

        return new \WP_REST_Response( [ 'success' => true, 'item' => $this->media_item_payload( $attachment_id ) ], 200 );
    }


    public function create_media_collection_zip( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! class_exists( '\ZipArchive' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'ZIP support is not available on this server.' ], 400 );
        }

        $params = $request->get_json_params() ?: [];
        $ids = isset( $params['attachment_ids'] ) && is_array( $params['attachment_ids'] ) ? $params['attachment_ids'] : [];
        $ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
        if ( empty( $ids ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'No media files were selected for this collection.' ], 400 );
        }

        $collection = sanitize_file_name( sanitize_text_field( (string) ( $params['collection'] ?? 'media-collection' ) ) );
        if ( '' === $collection ) {
            $collection = 'media-collection';
        }

        $upload = wp_upload_dir();
        $base_dir = trailingslashit( (string) ( $upload['basedir'] ?? '' ) ) . 'variable-engine/media-zips';
        $base_url = trailingslashit( (string) ( $upload['baseurl'] ?? '' ) ) . 'variable-engine/media-zips';
        if ( ! wp_mkdir_p( $base_dir ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Could not prepare the ZIP folder.' ], 500 );
        }

        $filename = $collection . '-' . gmdate( 'Y-m-d-His' ) . '.zip';
        $path = trailingslashit( $base_dir ) . $filename;
        $zip = new \ZipArchive();
        if ( true !== $zip->open( $path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Could not create the ZIP file.' ], 500 );
        }

        $added = 0;
        foreach ( $ids as $id ) {
            if ( get_post_type( $id ) !== 'attachment' ) {
                continue;
            }
            $file = get_attached_file( $id );
            if ( ! $file || ! file_exists( $file ) || ! is_readable( $file ) ) {
                continue;
            }
            $name = basename( $file );
            if ( $zip->locateName( $name ) !== false ) {
                $info = pathinfo( $name );
                $name = ( $info['filename'] ?? 'media' ) . '-' . $id . ( isset( $info['extension'] ) ? '.' . $info['extension'] : '' );
            }
            if ( $zip->addFile( $file, $name ) ) {
                $added++;
            }
        }
        $zip->close();

        if ( $added <= 0 ) {
            @unlink( $path );
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'No readable media files could be added to the ZIP.' ], 400 );
        }

        return new \WP_REST_Response( [
            'success' => true,
            'count'   => $added,
            'url'     => trailingslashit( $base_url ) . rawurlencode( $filename ),
        ], 200 );
    }

    private function validate_media_import_url( string $url ) {
        $url = esc_url_raw( trim( $url ) );
        if ( '' === $url ) {
            return new \WP_Error( 'mv_media_import_empty_url', 'No URL was provided.' );
        }
        $scheme = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );
        if ( 'http' !== $scheme && 'https' !== $scheme ) {
            return new \WP_Error( 'mv_media_import_bad_scheme', 'Only HTTP and HTTPS URLs are supported.' );
        }
        $host = (string) wp_parse_url( $url, PHP_URL_HOST );
        if ( '' === $host ) {
            return new \WP_Error( 'mv_media_import_bad_host', 'The URL does not contain a valid host.' );
        }
        $resolved = gethostbyname( $host );
        if ( $resolved === $host && ! filter_var( $host, FILTER_VALIDATE_IP ) ) {
            return new \WP_Error( 'mv_media_import_unresolved_host', 'Could not resolve the host.' );
        }
        if ( $this->is_private_ip( $resolved ) ) {
            return new \WP_Error( 'mv_media_import_private_host', 'Downloads from private or internal addresses are not allowed.' );
        }
        $path = (string) wp_parse_url( $url, PHP_URL_PATH );
        if ( preg_match( '/(^|\.)pexels\.com$/i', $host ) && preg_match( '#^/(video|photo)s?/#i', $path ) ) {
            return new \WP_Error( 'mv_media_import_protected_page', 'That Pexels link is a protected webpage, not a direct media file. Download it from Pexels first, or paste a direct .mp4/.jpg/.png file URL.' );
        }
        return [ 'url' => $url, 'host' => $host, 'path' => $path ];
    }

    private function media_import_filename_from_url( string $url ): string {
        $url_path = (string) wp_parse_url( $url, PHP_URL_PATH );
        $basename = $url_path ? wp_basename( $url_path ) : '';
        $basename = preg_replace( '/\?.*$/', '', $basename );
        if ( '' === $basename || '.' === $basename ) {
            $basename = 'imported-media-' . gmdate( 'YmdHis' );
        }
        return sanitize_file_name( $basename );
    }

    public function preview_import_from_url( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params();
        $raw_url = isset( $params['url'] ) ? (string) $params['url'] : '';
        $validated = $this->validate_media_import_url( $raw_url );
        if ( is_wp_error( $validated ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $validated->get_error_message() ], 400 );
        }

        $url = $validated['url'];
        $host = $validated['host'];
        $filename = $this->media_import_filename_from_url( $url );
        $max_bytes = 50 * 1024 * 1024;
        $content_type = '';
        $content_length = 0;
        $status = 0;

        $response = wp_remote_head( $url, [
            'timeout'     => 12,
            'redirection' => 5,
            'user-agent'  => 'MimamsVarMediaStudio/' . ( defined( 'VE_VERSION' ) ? VE_VERSION : '1.0' ) . '; ' . home_url( '/' ),
        ] );

        if ( ! is_wp_error( $response ) ) {
            $status = (int) wp_remote_retrieve_response_code( $response );
            $content_type = (string) wp_remote_retrieve_header( $response, 'content-type' );
            $len = wp_remote_retrieve_header( $response, 'content-length' );
            if ( is_numeric( $len ) ) {
                $content_length = (int) $len;
            }
            $disposition = (string) wp_remote_retrieve_header( $response, 'content-disposition' );
            if ( $disposition && preg_match( '/filename="?([^";]+)"?/i', $disposition, $m ) ) {
                $filename = sanitize_file_name( $m[1] );
            }
        }

        $ext = strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) );
        $looks_like_page = ( false !== stripos( $content_type, 'text/html' ) ) || ( ! $ext && ! preg_match( '#/(image|video|audio|application)/(?!json)#i', $content_type ) );

        return new \WP_REST_Response( [
            'success'      => true,
            'url'          => $url,
            'host'         => $host,
            'filename'     => $filename,
            'status'       => $status,
            'content_type' => $content_type ?: 'Unknown',
            'size'         => $content_length,
            'size_human'   => $content_length ? size_format( $content_length, 1 ) : 'Unknown',
            'max_bytes'    => $max_bytes,
            'max_human'    => size_format( $max_bytes, 0 ),
            'over_limit'   => $content_length > $max_bytes,
            'looks_like_page' => $looks_like_page,
        ], 200 );
    }

    /**
     * Download a file from an external URL and register it in the Media Library.
     */
    public function import_from_url( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params();
        $url    = isset( $params['url'] ) ? esc_url_raw( trim( (string) $params['url'] ) ) : '';

        $validated = $this->validate_media_import_url( $url );
        if ( is_wp_error( $validated ) ) {
            $this->add_media_url_import_history( [ 'status' => 'failed', 'url' => $url, 'message' => $validated->get_error_message() ] );
            return new \WP_REST_Response( [ 'success' => false, 'message' => $validated->get_error_message() ], 400 );
        }
        $url = $validated['url'];

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        // Download to a temp file (30 s timeout).
        $tmp_file = download_url( $url, 30 );
        if ( is_wp_error( $tmp_file ) ) {
            $download_error = $tmp_file->get_error_message();
            $message = 'Download failed: ' . $download_error;
            if ( stripos( $download_error, 'forbidden' ) !== false || stripos( $download_error, '403' ) !== false ) {
                $message .= ' This usually means the source blocks server-side downloads. Try a direct media file URL, or download the asset locally and upload it normally.';
            }
            $this->add_media_url_import_history( [ 'status' => 'failed', 'url' => $url, 'message' => $message ] );
            return new \WP_REST_Response( [
                'success' => false,
                'message' => $message,
            ], 400 );
        }

        // Enforce a 50 MB size limit.
        $max_bytes = 50 * 1024 * 1024;
        if ( filesize( $tmp_file ) > $max_bytes ) {
            @unlink( $tmp_file );
            $this->add_media_url_import_history( [ 'status' => 'failed', 'url' => $url, 'message' => 'The file exceeds the 50 MB size limit.' ] );
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'The file exceeds the 50 MB size limit.' ], 400 );
        }

        // Derive a clean filename from the URL path.
        $basename = $this->media_import_filename_from_url( $url );

        // Verify MIME type is allowed.
        $filetype = wp_check_filetype_and_ext( $tmp_file, $basename );
        if ( empty( $filetype['type'] ) ) {
            @unlink( $tmp_file );
            $this->add_media_url_import_history( [ 'status' => 'failed', 'url' => $url, 'message' => 'This file type is not allowed.' ] );
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'This file type is not allowed.' ], 400 );
        }

        // If the basename had no extension, append the detected one.
        if ( ! empty( $filetype['ext'] ) && ! pathinfo( $basename, PATHINFO_EXTENSION ) ) {
            $basename .= '.' . $filetype['ext'];
        }

        $file_array = [
            'name'     => $basename,
            'tmp_name' => $tmp_file,
        ];

        $attachment_id = media_handle_sideload( $file_array, 0 );

        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp_file );
            $message = 'Sideload failed: ' . $attachment_id->get_error_message();
            $this->add_media_url_import_history( [ 'status' => 'failed', 'url' => $url, 'message' => $message ] );
            return new \WP_REST_Response( [
                'success' => false,
                'message' => $message,
            ], 400 );
        }

        $collection = isset( $params['collection'] ) ? sanitize_text_field( (string) $params['collection'] ) : '';
        if ( '' !== $collection ) {
            $this->media_collections_manager()->assign_attachment( (int) $attachment_id, $collection, true );
        }

        $item = $this->media_item_payload( (int) $attachment_id );
        $this->add_media_url_import_history( [
            'status'        => 'complete',
            'url'           => $url,
            'attachment_id' => (int) $attachment_id,
            'title'         => $item['title']['rendered'] ?? $basename,
            'mime_type'     => $item['mime_type'] ?? ( $filetype['type'] ?? '' ),
            'size'          => $item['file_size'] ?? 0,
            'collection'    => $collection,
        ] );

        return new \WP_REST_Response( [
            'success' => true,
            'item'    => $item,
        ], 200 );
    }

    /**
     * Check if an IP address belongs to a private or reserved range.
     */
    private function is_private_ip( string $ip ): bool {
        // IPv6 loopback.
        if ( '::1' === $ip ) {
            return true;
        }
        // FILTER_FLAG_NO_PRIV_RANGE covers 10.*, 172.16-31.*, 192.168.*, fc00::/7.
        // FILTER_FLAG_NO_RES_RANGE covers 127.*, 0.*, 169.254.*, 240.*, ::1, etc.
        if ( false === filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        ) ) {
            return true;
        }
        return false;
    }

    public function get_content_studio_meta(): \WP_REST_Response {
        $cpts = [];
        $field_groups = [];
        $option_pages = [];

        $post_types = get_post_types( [], 'objects' );
        $exclude = [
            'attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset',
            'oembed_cache', 'user_request', 'wp_block', 'wp_template', 'wp_template_part',
            'acf-field-group', 'acf-field', 'wp_navigation', 'wp_global_styles', 'wp_font_family',
            'wp_font_face', 'action_scheduler', 'bricks_template'
        ];

        $acf_cpts = [];
        if ( function_exists( 'acf_get_post_types' ) ) {
            $acf_cpts = acf_get_post_types();
        }
        $jet_cpts = get_option( 'jet_engine_cpt', [] );
        if ( ! is_array( $jet_cpts ) ) {
            $jet_cpts = [];
        }

        foreach ( $post_types as $pt ) {
            if ( in_array( $pt->name, $exclude, true ) ) {
                continue;
            }

            $source = 'wp';
            foreach ( $acf_cpts as $ac ) {
                if ( ( $ac['post_type'] ?? '' ) === $pt->name ) {
                    $source = 'acf';
                    break;
                }
            }
            if ( $source === 'wp' ) {
                foreach ( $jet_cpts as $jc ) {
                    if ( ( $jc['slug'] ?? '' ) === $pt->name ) {
                        $source = 'jet';
                        break;
                    }
                }
            }

            $counts = wp_count_posts( $pt->name );
            $total_count = (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 ) + (int) ( $counts->pending ?? 0 ) + (int) ( $counts->private ?? 0 );
            $label = $pt->label ?: $pt->name;
            $is_content = ! preg_match( '/(taxonom|option pages?|custom fonts?|rm content editor|field groups?|template parts?|navigation)/i', $label );

            $cpts[] = [
                'name'         => $pt->name,
                'label'        => $label,
                'singular'     => $pt->labels->singular_name ?: $pt->name,
                'show_in_rest' => ! empty( $pt->show_in_rest ),
                'rest_base'    => $pt->rest_base ?: $pt->name,
                'count'        => $total_count,
                'source'       => $source,
                'is_builtin'   => ! empty( $pt->_builtin ),
                'is_content'   => $is_content,
                'supports_editor' => post_type_supports( $pt->name, 'editor' ),
                'supports_custom_fields' => post_type_supports( $pt->name, 'custom-fields' ),
                'bricks_editable' => $this->is_bricks_post_type_supported_for_studio( $pt->name ),
            ];
        }

        $known_cpt_names = array_fill_keys( array_map( static function( $pt ) {
            return $pt['name'];
        }, $cpts ), true );

        foreach ( (array) $acf_cpts as $acf_cpt ) {
            $name = sanitize_key( (string) ( $acf_cpt['post_type'] ?? $acf_cpt['name'] ?? '' ) );
            if ( empty( $name ) || in_array( $name, [ 'page', 'post' ], true ) || isset( $known_cpt_names[ $name ] ) || in_array( $name, $exclude, true ) ) {
                continue;
            }
            $label = sanitize_text_field( (string) ( $acf_cpt['title'] ?? $acf_cpt['labels']['name'] ?? $name ) );
            $singular = sanitize_text_field( (string) ( $acf_cpt['labels']['singular_name'] ?? ( $label ?: $name ) ) );
            $counts = wp_count_posts( $name );
            $total_count = is_object( $counts ) ? (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 ) + (int) ( $counts->pending ?? 0 ) + (int) ( $counts->private ?? 0 ) : 0;
            $cpts[] = [
                'name'         => $name,
                'label'        => $label ?: $name,
                'singular'     => $singular,
                'show_in_rest' => ! empty( $acf_cpt['show_in_rest'] ),
                'rest_base'    => sanitize_key( (string) ( $acf_cpt['rest_base'] ?? $name ) ),
                'count'        => $total_count,
                'source'       => 'acf',
                'is_builtin'   => false,
                'is_content'   => ! preg_match( '/(taxonom|option pages?|custom fonts?|rm content editor|field groups?|template parts?|navigation)/i', $label ),
                'supports_editor' => post_type_supports( $name, 'editor' ),
                'supports_custom_fields' => post_type_supports( $name, 'custom-fields' ),
                'bricks_editable' => $this->is_bricks_post_type_supported_for_studio( $name ),
            ];
            $known_cpt_names[ $name ] = true;
        }

        foreach ( (array) $jet_cpts as $jet_cpt ) {
            $name = sanitize_key( (string) ( $jet_cpt['slug'] ?? $jet_cpt['name'] ?? '' ) );
            if ( empty( $name ) || in_array( $name, [ 'page', 'post' ], true ) || isset( $known_cpt_names[ $name ] ) || in_array( $name, $exclude, true ) ) {
                continue;
            }
            $label = sanitize_text_field( (string) ( $jet_cpt['labels']['name'] ?? $jet_cpt['label'] ?? $name ) );
            $singular = sanitize_text_field( (string) ( $jet_cpt['labels']['singular_name'] ?? ( $label ?: $name ) ) );
            $counts = wp_count_posts( $name );
            $total_count = is_object( $counts ) ? (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 ) + (int) ( $counts->pending ?? 0 ) + (int) ( $counts->private ?? 0 ) : 0;
            $cpts[] = [
                'name'         => $name,
                'label'        => $label ?: $name,
                'singular'     => $singular,
                'show_in_rest' => ! empty( $jet_cpt['args']['show_in_rest'] ),
                'rest_base'    => sanitize_key( (string) ( $jet_cpt['args']['rest_base'] ?? $name ) ),
                'count'        => $total_count,
                'source'       => 'jet',
                'is_builtin'   => false,
                'is_content'   => ! preg_match( '/(taxonom|option pages?|custom fonts?|rm content editor|field groups?|template parts?|navigation)/i', $label ),
                'supports_editor' => post_type_supports( $name, 'editor' ),
                'supports_custom_fields' => post_type_supports( $name, 'custom-fields' ),
                'bricks_editable' => $this->is_bricks_post_type_supported_for_studio( $name ),
            ];
            $known_cpt_names[ $name ] = true;
        }

        if ( function_exists( 'acf_get_field_groups' ) ) {
            $acf_groups = acf_get_field_groups();
            foreach ( $acf_groups as $group ) {
                $group_title = (string) ( $group['title'] ?? '' );
                if ( preg_match( '/^option pages?$/i', $group_title ) ) {
                    continue;
                }
                $fields = [];
                $raw_fields = acf_get_fields( $group['ID'] ) ?: acf_get_fields( $group['key'] ) ?: [];
                foreach ( $raw_fields as $f ) {
                    $fields[] = [
                        'name'  => $f['name'] ?? '',
                        'label' => $f['label'] ?? ($f['name'] ?? ''),
                        'type'  => $f['type'] ?? 'text',
                    ];
                }

                $post_types_rules = [];
                if ( isset( $group['location'] ) && is_array( $group['location'] ) ) {
                    foreach ( $group['location'] as $rule_group ) {
                        foreach ( $rule_group as $rule ) {
                            if ( ( $rule['param'] ?? '' ) === 'options_page' ) {
                                continue 3;
                            }
                            if ( ( $rule['param'] ?? '' ) === 'post_type' && ( $rule['operator'] ?? '' ) === '==' ) {
                                $post_types_rules[] = $rule['value'];
                            }
                        }
                    }
                }

                $field_groups[] = [
                    'id'         => 'acf-' . $group['ID'],
                    'key'        => $group['key'],
                    'title'      => $group['title'] ?? 'ACF Field Group',
                    'fields'     => $fields,
                    'post_types' => array_values( array_unique( $post_types_rules ) ),
                    'source'     => 'acf',
                ];
            }
        }

        if ( function_exists( 'acf_get_options_pages' ) && function_exists( 'acf_get_field_groups' ) ) {
            $acf_option_pages = acf_get_options_pages();
            if ( is_array( $acf_option_pages ) ) {
                foreach ( $acf_option_pages as $slug => $page ) {
                    $menu_slug = sanitize_key( (string) ( $page['menu_slug'] ?? $slug ) );
                    if ( '' === $menu_slug ) {
                        continue;
                    }
                    $post_id = (string) ( $page['post_id'] ?? 'options' );
                    $fields = [];
                    foreach ( acf_get_field_groups( [ 'options_page' => $menu_slug ] ) as $group ) {
                        $raw_fields = acf_get_fields( $group['ID'] ) ?: acf_get_fields( $group['key'] ) ?: [];
                        foreach ( $raw_fields as $f ) {
                            $name = sanitize_key( (string) ( $f['name'] ?? '' ) );
                            if ( '' === $name ) {
                                continue;
                            }
                            $fields[] = [
                                'name'  => $name,
                                'label' => sanitize_text_field( (string) ( $f['label'] ?? $name ) ),
                                'type'  => sanitize_key( (string) ( $f['type'] ?? 'text' ) ),
                                'value' => $this->studio_meta_value_for_ui( function_exists( 'get_field' ) ? get_field( $name, $post_id ) : get_option( 'options_' . $name ) ),
                            ];
                        }
                    }
                    $option_pages[] = [
                        'id'      => 'option-' . $menu_slug,
                        'slug'    => $menu_slug,
                        'label'   => sanitize_text_field( (string) ( $page['page_title'] ?? $page['menu_title'] ?? $menu_slug ) ),
                        'post_id' => $post_id,
                        'source'  => 'acf',
                        'fields'  => $fields,
                    ];
                }
            }
        }

        $jet_groups = [];
        if ( function_exists( 'jet_engine' ) && isset( jet_engine()->meta_boxes ) ) {
            $boxes = [];
            if ( method_exists( jet_engine()->meta_boxes, 'get_meta_boxes' ) ) {
                $boxes = jet_engine()->meta_boxes->get_meta_boxes();
            } elseif ( isset( jet_engine()->meta_boxes->data ) && method_exists( jet_engine()->meta_boxes->data, 'get_items' ) ) {
                $boxes = jet_engine()->meta_boxes->data->get_items();
            }
            foreach ( (array) $boxes as $box ) {
                $box_id = '';
                $box_title = '';
                $args = [];
                if ( is_object( $box ) ) {
                    $box_id = $box->id ?? '';
                    $box_title = $box->name ?? ($box->title ?? '');
                    $args = (array) ($box->args ?? []);
                } elseif ( is_array( $box ) ) {
                    $box_id = $box['id'] ?? '';
                    $box_title = $box['name'] ?? ($box['title'] ?? '');
                    $args = $box['args'] ?? [];
                }
                $allowed_posts = $args['allowed_post_types'] ?? [];

                $fields = [];
                $raw_fields = [];
                if ( is_object( $box ) && method_exists( $box, 'get_meta_fields' ) ) {
                    $raw_fields = $box->get_meta_fields();
                } elseif ( is_array( $box ) && isset( $box['meta_fields'] ) ) {
                    $raw_fields = $box['meta_fields'];
                } elseif ( is_object( $box ) && isset( $box->meta_fields ) ) {
                    $raw_fields = $box->meta_fields;
                }

                foreach ( (array) $raw_fields as $f ) {
                    $f_name = '';
                    $f_title = '';
                    $f_type = 'text';
                    if ( is_object( $f ) ) {
                        $f_name = $f->name ?? '';
                        $f_title = $f->title ?? '';
                        $f_type = $f->type ?? 'text';
                    } elseif ( is_array( $f ) ) {
                        $f_name = $f['name'] ?? '';
                        $f_title = $f['title'] ?? '';
                        $f_type = $f['type'] ?? 'text';
                    }
                    if ( $f_name ) {
                        $fields[] = [
                            'name'  => $f_name,
                            'label' => $f_title ?: $f_name,
                            'type'  => $f_type,
                        ];
                    }
                }

                if ( $box_id && ! empty( $fields ) ) {
                    $jet_groups[ $box_id ] = [
                        'id'         => 'jet-' . $box_id,
                        'key'        => $box_id,
                        'title'      => $box_title ?: 'JetEngine Field Group',
                        'fields'     => $fields,
                        'post_types' => (array) $allowed_posts,
                        'source'     => 'jet',
                    ];
                }
            }
        }

        $jet_options = get_option( 'jet_engine_meta_boxes', [] );
        if ( is_array( $jet_options ) ) {
            foreach ( $jet_options as $box ) {
                $box_id = $box['id'] ?? '';
                if ( ! $box_id || isset( $jet_groups[ $box_id ] ) ) {
                    continue;
                }
                $box_title = $box['name'] ?? ($box['title'] ?? '');
                $args = $box['args'] ?? [];
                $allowed_posts = $args['allowed_post_types'] ?? [];
                $raw_fields = $box['meta_fields'] ?? [];
                $fields = [];
                foreach ( (array) $raw_fields as $f ) {
                    $f_name = $f['name'] ?? '';
                    if ( $f_name ) {
                        $fields[] = [
                            'name'  => $f_name,
                            'label' => $f['title'] ?? ($f['label'] ?? $f_name),
                            'type'  => $f['type'] ?? 'text',
                        ];
                    }
                }
                if ( ! empty( $fields ) ) {
                    $jet_groups[ $box_id ] = [
                        'id'         => 'jet-' . $box_id,
                        'key'        => $box_id,
                        'title'      => $box_title ?: 'JetEngine Field Group',
                        'fields'     => $fields,
                        'post_types' => (array) $allowed_posts,
                        'source'     => 'jet',
                    ];
                }
            }
        }

        $field_groups = array_merge( $field_groups, array_values( $jet_groups ) );
        $deduped_cpts = [];
        foreach ( $cpts as $pt ) {
            $name = $pt['name'] ?? '';
            if ( ! $name || isset( $deduped_cpts[ $name ] ) ) {
                continue;
            }
            $deduped_cpts[ $name ] = $pt;
        }
        $cpts = array_values( $deduped_cpts );

        $authors = [];
        foreach ( get_users( [ 'who' => 'authors', 'orderby' => 'display_name', 'order' => 'ASC' ] ) as $user ) {
            $authors[] = [
                'id'   => (int) $user->ID,
                'name' => $user->display_name,
            ];
        }

        $taxonomy_catalog = [];
        foreach ( $cpts as $pt ) {
            $post_type = sanitize_key( (string) ( $pt['name'] ?? '' ) );
            if ( '' === $post_type ) {
                continue;
            }
            $taxonomy_catalog[ $post_type ] = [];
            foreach ( get_object_taxonomies( $post_type, 'objects' ) as $taxonomy ) {
                if ( ! $taxonomy instanceof \WP_Taxonomy || 'post_format' === $taxonomy->name || ( ! $taxonomy->public && ! $taxonomy->show_ui ) ) {
                    continue;
                }
                $terms = get_terms( [
                    'taxonomy'   => $taxonomy->name,
                    'hide_empty' => false,
                    'number'     => 250,
                    'orderby'    => 'name',
                    'order'      => 'ASC',
                ] );
                if ( is_wp_error( $terms ) ) {
                    $terms = [];
                }
                $taxonomy_catalog[ $post_type ][] = [
                    'name'         => $taxonomy->name,
                    'label'        => $taxonomy->labels->name ?: $taxonomy->label,
                    'singular'     => $taxonomy->labels->singular_name ?: $taxonomy->label,
                    'hierarchical' => (bool) $taxonomy->hierarchical,
                    'terms'        => array_map( static function( $term ) {
                        return [
                            'id'   => (int) $term->term_id,
                            'name' => $term->name,
                            'slug' => $term->slug,
                        ];
                    }, $terms ),
                ];
            }
        }

        return new \WP_REST_Response( [
            'cpts'         => $cpts,
            'field_groups' => $field_groups,
            'option_pages' => $option_pages,
            'authors'      => $authors,
            'taxonomies'   => $taxonomy_catalog,
            'acf_active'   => function_exists( 'acf_get_field_groups' ),
            'jet_active'   => function_exists( 'jet_engine' ) || ! empty( $jet_options ),
        ], 200 );
    }

    private function is_bricks_post_type_supported_for_studio( string $post_type ): bool {
        if ( '' === $post_type ) {
            return false;
        }

        $supported = [];
        if ( class_exists( '\Bricks\Database' ) && method_exists( '\Bricks\Database', 'get_setting' ) ) {
            $supported = (array) \Bricks\Database::get_setting( 'postTypes', [] );
        } else {
            $settings = get_option( 'bricks_global_settings', [] );
            if ( is_array( $settings ) && isset( $settings['postTypes'] ) ) {
                $supported = (array) $settings['postTypes'];
            }
        }

        if ( defined( 'BRICKS_DB_TEMPLATE_SLUG' ) && $post_type === BRICKS_DB_TEMPLATE_SLUG ) {
            $supported[] = $post_type;
        }

        if ( has_filter( 'bricks/builder/supported_post_types' ) ) {
            $supported = (array) apply_filters( 'bricks/builder/supported_post_types', $supported, $post_type );
        }

        return in_array( $post_type, array_map( 'sanitize_key', $supported ), true );
    }

    private function studio_rank_math_summary( int $post_id ): array {
        $title = (string) get_post_meta( $post_id, 'rank_math_title', true );
        if ( '' === $title ) {
            $title = (string) get_post_meta( $post_id, '_rank_math_title', true );
        }
        $description = (string) get_post_meta( $post_id, 'rank_math_description', true );
        if ( '' === $description ) {
            $description = (string) get_post_meta( $post_id, '_rank_math_description', true );
        }
        $focus = (string) get_post_meta( $post_id, 'rank_math_focus_keyword', true );
        if ( '' === $focus ) {
            $focus = (string) get_post_meta( $post_id, '_rank_math_focus_keyword', true );
        }
        $score = get_post_meta( $post_id, 'rank_math_seo_score', true );
        if ( '' === $score || null === $score ) {
            $score = get_post_meta( $post_id, '_rank_math_seo_score', true );
        }
        $schema = (string) get_post_meta( $post_id, 'rank_math_rich_snippet', true );
        if ( '' === $schema ) {
            $schema = (string) get_post_meta( $post_id, '_rank_math_rich_snippet', true );
        }
        $robots = get_post_meta( $post_id, 'rank_math_robots', true );
        if ( empty( $robots ) ) {
            $robots = get_post_meta( $post_id, '_rank_math_robots', true );
        }
        if ( is_array( $robots ) ) {
            $robots = array_values( array_filter( array_map( 'sanitize_text_field', $robots ) ) );
        } else {
            $robots = array_values( array_filter( array_map( 'sanitize_text_field', preg_split( '/\s*,\s*/', (string) $robots ) ) ) );
        }
        if ( empty( $robots ) ) {
            $robots = [ 'index' ];
        }
        $advanced_robots = get_post_meta( $post_id, 'rank_math_advanced_robots', true );
        if ( ! is_array( $advanced_robots ) ) {
            $advanced_robots = [];
        }
        $canonical = (string) get_post_meta( $post_id, 'rank_math_canonical_url', true );
        $facebook_title = (string) get_post_meta( $post_id, 'rank_math_facebook_title', true );
        $facebook_description = (string) get_post_meta( $post_id, 'rank_math_facebook_description', true );
        $facebook_image = (string) get_post_meta( $post_id, 'rank_math_facebook_image', true );
        $twitter_title = (string) get_post_meta( $post_id, 'rank_math_twitter_title', true );
        $twitter_description = (string) get_post_meta( $post_id, 'rank_math_twitter_description', true );
        $twitter_image = (string) get_post_meta( $post_id, 'rank_math_twitter_image', true );
        $facebook_overlay = (string) get_post_meta( $post_id, 'rank_math_facebook_enable_image_overlay', true );
        $redirect_enabled = (string) get_post_meta( $post_id, 'rank_math_redirection_enabled', true );
        $redirect_type = (string) get_post_meta( $post_id, 'rank_math_redirection_type', true );
        $redirect_url = (string) get_post_meta( $post_id, 'rank_math_redirection_url', true );

        return [
            'title'                => sanitize_text_field( $title ),
            'description'          => sanitize_textarea_field( $description ),
            'focus_keyword'        => sanitize_text_field( $focus ),
            'score'                => is_numeric( $score ) ? (int) $score : null,
            'schema'               => sanitize_text_field( $schema ),
            'robots'               => $robots,
            'canonical_url'        => esc_url_raw( $canonical ),
            'facebook_title'       => sanitize_text_field( $facebook_title ),
            'facebook_description' => sanitize_textarea_field( $facebook_description ),
            'facebook_image'       => esc_url_raw( $facebook_image ),
            'twitter_title'        => sanitize_text_field( $twitter_title ),
            'twitter_description'  => sanitize_textarea_field( $twitter_description ),
            'twitter_image'        => esc_url_raw( $twitter_image ),
            'facebook_enable_image_overlay' => sanitize_text_field( $facebook_overlay ),
            'max_snippet'          => isset( $advanced_robots['max-snippet'] ) ? sanitize_text_field( (string) $advanced_robots['max-snippet'] ) : '-1',
            'max_video_preview'    => isset( $advanced_robots['max-video-preview'] ) ? sanitize_text_field( (string) $advanced_robots['max-video-preview'] ) : '-1',
            'max_image_preview'    => isset( $advanced_robots['max-image-preview'] ) ? sanitize_text_field( (string) $advanced_robots['max-image-preview'] ) : 'large',
            'redirect_enabled'     => sanitize_text_field( $redirect_enabled ),
            'redirect_type'        => sanitize_text_field( $redirect_type ?: '301' ),
            'redirect_url'         => esc_url_raw( $redirect_url ),
            'site_name'            => get_bloginfo( 'name' ),
            'site_url'             => home_url( '/' ),
            'has_plugin'           => defined( 'RANK_MATH_VERSION' ) || class_exists( '\RankMath' ) || class_exists( '\RankMath\Helper' ),
            'is_pro'               => defined( 'RANK_MATH_PRO_VERSION' ),
        ];
    }

    private function update_studio_rank_math_meta( int $post_id, array $seo ): void {
        $text_fields = [
            'rank_math_title'                  => 'title',
            'rank_math_focus_keyword'          => 'focus_keyword',
            'rank_math_rich_snippet'           => 'schema',
            'rank_math_facebook_title'         => 'facebook_title',
            'rank_math_twitter_title'          => 'twitter_title',
            'rank_math_facebook_enable_image_overlay' => 'facebook_enable_image_overlay',
            'rank_math_redirection_enabled'    => 'redirect_enabled',
            'rank_math_redirection_type'       => 'redirect_type',
        ];
        $textarea_fields = [
            'rank_math_description'            => 'description',
            'rank_math_facebook_description'   => 'facebook_description',
            'rank_math_twitter_description'    => 'twitter_description',
        ];
        $url_fields = [
            'rank_math_canonical_url'          => 'canonical_url',
            'rank_math_facebook_image'         => 'facebook_image',
            'rank_math_twitter_image'          => 'twitter_image',
            'rank_math_redirection_url'        => 'redirect_url',
        ];
        foreach ( $text_fields as $meta_key => $ui_key ) {
            if ( array_key_exists( $ui_key, $seo ) ) {
                update_post_meta( $post_id, $meta_key, sanitize_text_field( (string) $seo[ $ui_key ] ) );
            }
        }
        foreach ( $textarea_fields as $meta_key => $ui_key ) {
            if ( array_key_exists( $ui_key, $seo ) ) {
                update_post_meta( $post_id, $meta_key, sanitize_textarea_field( (string) $seo[ $ui_key ] ) );
            }
        }
        foreach ( $url_fields as $meta_key => $ui_key ) {
            if ( array_key_exists( $ui_key, $seo ) ) {
                update_post_meta( $post_id, $meta_key, esc_url_raw( (string) $seo[ $ui_key ] ) );
            }
        }
        if ( array_key_exists( 'robots', $seo ) ) {
            $robots = is_array( $seo['robots'] ) ? $seo['robots'] : preg_split( '/\s*,\s*/', (string) $seo['robots'] );
            $robots = array_values( array_filter( array_map( 'sanitize_text_field', (array) $robots ) ) );
            update_post_meta( $post_id, 'rank_math_robots', $robots );
        }
        $advanced = get_post_meta( $post_id, 'rank_math_advanced_robots', true );
        if ( ! is_array( $advanced ) ) {
            $advanced = [];
        }
        if ( array_key_exists( 'max_snippet', $seo ) ) {
            $advanced['max-snippet'] = sanitize_text_field( (string) $seo['max_snippet'] );
        }
        if ( array_key_exists( 'max_video_preview', $seo ) ) {
            $advanced['max-video-preview'] = sanitize_text_field( (string) $seo['max_video_preview'] );
        }
        if ( array_key_exists( 'max_image_preview', $seo ) ) {
            $advanced['max-image-preview'] = sanitize_text_field( (string) $seo['max_image_preview'] );
        }
        update_post_meta( $post_id, 'rank_math_advanced_robots', $advanced );
    }

    private function studio_post_payload( \WP_Post $post ): array {
        $link = get_permalink( $post->ID ) ?: '#';
        $edit_link = get_edit_post_link( $post->ID, 'raw' );
        if ( ! $edit_link ) {
            $edit_link = admin_url( 'post.php?post=' . $post->ID . '&action=edit' );
        }
        $bricks_editable = $this->is_bricks_post_type_supported_for_studio( $post->post_type );
        $bricks_link = '';
        if ( $bricks_editable ) {
            if ( class_exists( '\\Bricks\\Helpers' ) && method_exists( '\\Bricks\\Helpers', 'get_builder_edit_link' ) ) {
                $maybe_bricks_link = \Bricks\Helpers::get_builder_edit_link( $post->ID );
                $bricks_link = is_string( $maybe_bricks_link ) && '' !== $maybe_bricks_link ? $maybe_bricks_link : '';
            }
            if ( '' === $bricks_link ) {
                $bricks_link = $link && '#' !== $link ? add_query_arg( 'bricks', 'run', $link ) : '';
            }
        }

        $assigned_terms = [];
        foreach ( get_object_taxonomies( $post->post_type, 'objects' ) as $taxonomy ) {
            if ( ! $taxonomy instanceof \WP_Taxonomy || 'post_format' === $taxonomy->name || ( ! $taxonomy->public && ! $taxonomy->show_ui ) ) {
                continue;
            }
            $term_ids = wp_get_object_terms( $post->ID, $taxonomy->name, [ 'fields' => 'ids' ] );
            $assigned_terms[ $taxonomy->name ] = is_wp_error( $term_ids ) ? [] : array_map( 'intval', $term_ids );
        }

        return [
            'id'            => $post->ID,
            'type'          => $post->post_type,
            'title'         => [ 'rendered' => $post->post_title ],
            'slug'          => $post->post_name,
            'status'        => $post->post_status,
            'content'       => [ 'raw' => $post->post_content ],
            'excerpt'       => [ 'raw' => $post->post_excerpt ],
            'author'        => (int) $post->post_author,
            'terms'         => $assigned_terms,
            'parent'        => (int) $post->post_parent,
            'menu_order'    => (int) $post->menu_order,
            'featured_media'=> (int) get_post_thumbnail_id( $post->ID ),
            'comment_status'=> $post->comment_status,
            'ping_status'   => $post->ping_status,
            'template'      => get_page_template_slug( $post->ID ) ?: '',
            'date'          => $post->post_date_gmt,
            'modified'      => $post->post_modified_gmt,
            'link'          => $link,
            'edit_link'     => $edit_link,
            'bricks_link'   => $bricks_link,
            'bricks_editable' => $bricks_editable,
            'supports_editor' => post_type_supports( $post->post_type, 'editor' ),
            'seo_details'   => $this->studio_rank_math_summary( $post->ID ),
            'custom_fields' => $this->studio_post_custom_fields( $post->ID ),
        ];
    }

    private function studio_post_custom_fields( int $post_id ): array {
        $out = [];

        if ( function_exists( 'get_fields' ) ) {
            $acf_values = get_fields( $post_id );
            if ( is_array( $acf_values ) ) {
                foreach ( $acf_values as $key => $value ) {
                    $out[ sanitize_key( (string) $key ) ] = $this->studio_meta_value_for_ui( $value );
                }
            }
        }

        $raw_meta = get_post_meta( $post_id );
        foreach ( $raw_meta as $key => $values ) {
            if ( 0 === strpos( (string) $key, '_' ) || isset( $out[ $key ] ) ) {
                continue;
            }
            $value = is_array( $values ) ? reset( $values ) : $values;
            $out[ sanitize_key( (string) $key ) ] = $this->studio_meta_value_for_ui( $value );
        }

        return $out;
    }

    private function studio_meta_value_for_ui( $value ): string {
        if ( is_null( $value ) ) {
            return '';
        }

        if ( is_scalar( $value ) ) {
            return (string) $value;
        }

        $json = wp_json_encode( $value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
        return is_string( $json ) ? $json : '';
    }

    private function studio_meta_value_from_ui( $value ) {
        if ( ! is_string( $value ) ) {
            return $value;
        }

        $trimmed = trim( $value );
        if ( '' === $trimmed ) {
            return '';
        }

        $first = substr( $trimmed, 0, 1 );
        if ( '{' === $first || '[' === $first ) {
            $decoded = json_decode( $trimmed, true );
            if ( JSON_ERROR_NONE === json_last_error() ) {
                return $decoded;
            }
        }

        return $value;
    }

    private function studio_content_import_value( array $row, array $mapping, string $field ): string {
        foreach ( $mapping as $column => $mapped_field ) {
            if ( $field !== $mapped_field || ! array_key_exists( $column, $row ) ) {
                continue;
            }
            $value = $row[ $column ];
            if ( is_scalar( $value ) || null === $value ) {
                return trim( wp_check_invalid_utf8( (string) $value ) );
            }
        }
        return '';
    }

    private function studio_content_import_terms( string $value ): array {
        if ( '' === trim( $value ) ) {
            return [];
        }
        $parts = preg_split( '/[|,]+/', $value );
        if ( ! is_array( $parts ) ) {
            return [];
        }
        return array_values( array_unique( array_filter( array_map( static function( $term ) {
            return sanitize_text_field( trim( (string) $term ) );
        }, $parts ) ) ) );
    }

    private function studio_content_import_author( string $value, int $fallback ): int {
        $value = trim( $value );
        if ( '' === $value ) {
            return $fallback;
        }
        if ( ctype_digit( $value ) ) {
            $user = get_user_by( 'id', (int) $value );
            return $user ? (int) $user->ID : $fallback;
        }
        $user = is_email( $value ) ? get_user_by( 'email', $value ) : get_user_by( 'login', $value );
        if ( ! $user ) {
            $users = get_users( [
                'search'         => $value,
                'search_columns' => [ 'display_name' ],
                'number'         => 1,
            ] );
            $user = ! empty( $users ) ? $users[0] : null;
        }
        return $user ? (int) $user->ID : $fallback;
    }

    private function prepare_studio_content_import( array $params ) {
        $rows = isset( $params['rows'] ) && is_array( $params['rows'] ) ? array_values( $params['rows'] ) : [];
        $mapping_input = isset( $params['mapping'] ) && is_array( $params['mapping'] ) ? $params['mapping'] : [];
        $options_input = isset( $params['options'] ) && is_array( $params['options'] ) ? $params['options'] : [];

        if ( empty( $rows ) ) {
            return new \WP_Error( 'empty_content_import', 'The import file has no content rows.' );
        }
        if ( count( $rows ) > 5000 ) {
            return new \WP_Error( 'content_import_too_large', 'Content imports are limited to 5,000 rows per file.' );
        }

        $allowed_fields = [ 'ignore', 'title', 'content', 'excerpt', 'slug', 'status', 'date', 'author', 'categories', 'tags', 'featured_image_url', 'custom' ];
        $mapping = [];
        foreach ( $mapping_input as $column => $field ) {
            $column = sanitize_text_field( (string) $column );
            $field = sanitize_key( (string) $field );
            if ( '' !== $column && in_array( $field, $allowed_fields, true ) ) {
                $mapping[ $column ] = $field;
            }
        }
        if ( ! in_array( 'title', $mapping, true ) ) {
            return new \WP_Error( 'content_import_missing_title_map', 'Map one file column to Title before reviewing the import.' );
        }

        $post_type = sanitize_key( (string) ( $options_input['post_type'] ?? 'post' ) );
        if ( ! post_type_exists( $post_type ) ) {
            return new \WP_Error( 'content_import_bad_post_type', 'The selected post type does not exist.' );
        }
        $post_type_object = get_post_type_object( $post_type );
        if ( ! $post_type_object || ( ! $post_type_object->public && ! $post_type_object->show_ui ) || in_array( $post_type, [ 'attachment', 'revision', 'nav_menu_item' ], true ) ) {
            return new \WP_Error( 'content_import_bad_post_type', 'That post type cannot receive Content Studio imports.' );
        }
        $create_capability = isset( $post_type_object->cap->create_posts ) ? $post_type_object->cap->create_posts : 'edit_posts';
        if ( ! current_user_can( $create_capability ) ) {
            return new \WP_Error( 'content_import_forbidden_post_type', 'You cannot create content for the selected post type.' );
        }

        $allowed_statuses = [ 'publish', 'draft', 'pending', 'private' ];
        $default_status = sanitize_key( (string) ( $options_input['status'] ?? 'draft' ) );
        if ( ! in_array( $default_status, $allowed_statuses, true ) ) {
            $default_status = 'draft';
        }
        $default_author = absint( $options_input['author'] ?? get_current_user_id() );
        if ( ! $default_author || ! get_user_by( 'id', $default_author ) ) {
            $default_author = get_current_user_id();
        }
        $options = [
            'post_type'       => $post_type,
            'status'          => $default_status,
            'author'          => $default_author,
            'match_slug'      => rest_sanitize_boolean( $options_input['match_slug'] ?? true ),
            'import_media'    => rest_sanitize_boolean( $options_input['import_media'] ?? false ),
            'update_existing' => rest_sanitize_boolean( $options_input['update_existing'] ?? false ),
        ];

        $prepared_rows = [];
        $seen_slugs = [];
        $summary = [ 'total' => count( $rows ), 'create' => 0, 'update' => 0, 'skip' => 0, 'invalid' => 0, 'remote_images' => 0 ];
        foreach ( $rows as $index => $raw_row ) {
            if ( ! is_array( $raw_row ) ) {
                $raw_row = [];
            }
            $row = [];
            foreach ( $mapping as $column => $field ) {
                if ( ! array_key_exists( $column, $raw_row ) ) {
                    continue;
                }
                $value = $raw_row[ $column ];
                if ( is_scalar( $value ) || null === $value ) {
                    $row[ $column ] = substr( wp_check_invalid_utf8( (string) $value ), 0, 1000000 );
                }
            }

            $title = sanitize_text_field( $this->studio_content_import_value( $row, $mapping, 'title' ) );
            $content = wp_kses_post( $this->studio_content_import_value( $row, $mapping, 'content' ) );
            $excerpt = sanitize_textarea_field( $this->studio_content_import_value( $row, $mapping, 'excerpt' ) );
            $slug_input = $this->studio_content_import_value( $row, $mapping, 'slug' );
            $slug = sanitize_title( '' !== $slug_input ? $slug_input : $title );
            $row_status = sanitize_key( $this->studio_content_import_value( $row, $mapping, 'status' ) );
            $status = in_array( $row_status, $allowed_statuses, true ) ? $row_status : $default_status;
            $author = $this->studio_content_import_author( $this->studio_content_import_value( $row, $mapping, 'author' ), $default_author );
            $date_input = sanitize_text_field( $this->studio_content_import_value( $row, $mapping, 'date' ) );
            $date = '';
            if ( '' !== $date_input ) {
                $timestamp = strtotime( $date_input );
                if ( false !== $timestamp ) {
                    $date = wp_date( 'Y-m-d H:i:s', $timestamp );
                }
            }
            $categories = $this->studio_content_import_terms( $this->studio_content_import_value( $row, $mapping, 'categories' ) );
            $tags = $this->studio_content_import_terms( $this->studio_content_import_value( $row, $mapping, 'tags' ) );
            $featured_image_url = esc_url_raw( $this->studio_content_import_value( $row, $mapping, 'featured_image_url' ) );
            $custom_fields = [];
            foreach ( $mapping as $column => $field ) {
                if ( 'custom' !== $field || ! isset( $row[ $column ] ) ) {
                    continue;
                }
                $meta_key = sanitize_key( $column );
                if ( '' !== $meta_key && '_' !== substr( $meta_key, 0, 1 ) ) {
                    $custom_fields[ $meta_key ] = sanitize_textarea_field( (string) $row[ $column ] );
                }
            }

            $existing = null;
            if ( $options['match_slug'] && '' !== $slug ) {
                $existing = get_page_by_path( $slug, OBJECT, $post_type );
            }
            $duplicate_source_slug = $options['match_slug'] && '' !== $slug && isset( $seen_slugs[ $slug ] );
            $action = 'create';
            $reason = 'Create ' . $status;
            if ( '' === $title ) {
                $action = 'invalid';
                $reason = 'Title is required';
            } elseif ( $duplicate_source_slug ) {
                $action = 'skip';
                $reason = 'Duplicate slug in source file';
            } elseif ( $existing && $options['update_existing'] && ! current_user_can( 'edit_post', $existing->ID ) ) {
                $action = 'invalid';
                $reason = 'You cannot update the matching content';
            } elseif ( $existing && $options['update_existing'] ) {
                $action = 'update';
                $reason = 'Update existing ' . $post_type;
            } elseif ( $existing ) {
                $action = 'skip';
                $reason = 'Slug already exists';
            }
            if ( '' !== $title && $options['match_slug'] && '' !== $slug ) {
                $seen_slugs[ $slug ] = true;
            }
            $summary[ $action ]++;
            if ( '' !== $featured_image_url ) {
                $summary['remote_images']++;
            }

            $prepared_rows[] = [
                'source_index'       => $index,
                'title'              => $title ?: 'Untitled row ' . ( $index + 1 ),
                'slug'               => $slug,
                'action'             => $action,
                'reason'             => $reason,
                'status'             => $status,
                'existing_id'        => $existing ? (int) $existing->ID : 0,
                'categories_count'   => count( $categories ),
                'tags_count'         => count( $tags ),
                'remote_images'      => '' !== $featured_image_url ? 1 : 0,
                'post'               => [
                    'post_type'        => $post_type,
                    'post_title'       => $title,
                    'post_name'        => $slug,
                    'post_content'     => $content,
                    'post_excerpt'     => $excerpt,
                    'post_status'      => $status,
                    'post_author'      => $author,
                    'post_date'        => $date,
                    'categories'       => $categories,
                    'tags'             => $tags,
                    'featured_image_url' => $featured_image_url,
                    'custom_fields'    => $custom_fields,
                ],
            ];
        }

        $ready = $summary['create'] + $summary['update'];
        if ( $summary['remote_images'] > 100 ) {
            return new \WP_Error( 'content_import_media_limit', 'A single content import can download up to 100 mapped images.' );
        }
        $plural = sanitize_text_field( (string) ( $post_type_object->labels->name ?? $post_type ) );
        $confirmation = 'IMPORT ' . $ready . ' ' . strtoupper( $plural ?: $post_type );
        return [
            'rows'         => $prepared_rows,
            'summary'      => $summary,
            'mapping'      => $mapping,
            'options'      => $options,
            'confirmation' => $confirmation,
            'label'        => $plural,
        ];
    }

    public function preview_studio_content_import( \WP_REST_Request $request ): \WP_REST_Response {
        $prepared = $this->prepare_studio_content_import( $request->get_json_params() ?: [] );
        if ( is_wp_error( $prepared ) ) {
            return new \WP_REST_Response( [ 'code' => $prepared->get_error_code(), 'message' => $prepared->get_error_message() ], 400 );
        }
        $rows = array_map( static function( $row ) {
            unset( $row['post'] );
            return $row;
        }, $prepared['rows'] );
        return new \WP_REST_Response( [
            'success'      => true,
            'rows'         => $rows,
            'summary'      => $prepared['summary'],
            'confirmation' => $prepared['confirmation'],
            'label'        => $prepared['label'],
        ], 200 );
    }

    private function studio_content_import_featured_image( string $url, int $post_id ) {
        if ( '' === $url ) {
            return 0;
        }
        $existing_id = attachment_url_to_postid( $url );
        if ( $existing_id ) {
            set_post_thumbnail( $post_id, $existing_id );
            return (int) $existing_id;
        }
        $validated = $this->validate_media_import_url( $url );
        if ( is_wp_error( $validated ) ) {
            return $validated;
        }
        $validated_url = (string) ( $validated['url'] ?? '' );
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $tmp_file = download_url( $validated_url, 30 );
        if ( is_wp_error( $tmp_file ) ) {
            return $tmp_file;
        }
        if ( ! file_exists( $tmp_file ) || filesize( $tmp_file ) > 20 * 1024 * 1024 ) {
            @unlink( $tmp_file );
            return new \WP_Error( 'content_import_media_too_large', 'A mapped image exceeds the 20 MB import limit.' );
        }
        $filename = $this->media_import_filename_from_url( $validated_url );
        $filetype = wp_check_filetype_and_ext( $tmp_file, $filename );
        if ( empty( $filetype['type'] ) || 0 !== strpos( $filetype['type'], 'image/' ) ) {
            @unlink( $tmp_file );
            return new \WP_Error( 'content_import_media_type', 'A mapped media URL is not an allowed image.' );
        }
        if ( ! pathinfo( $filename, PATHINFO_EXTENSION ) && ! empty( $filetype['ext'] ) ) {
            $filename .= '.' . $filetype['ext'];
        }
        $attachment_id = media_handle_sideload( [ 'name' => $filename, 'tmp_name' => $tmp_file ], $post_id );
        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp_file );
            return $attachment_id;
        }
        set_post_thumbnail( $post_id, $attachment_id );
        return (int) $attachment_id;
    }

    public function apply_studio_content_import( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $prepared = $this->prepare_studio_content_import( $params );
        if ( is_wp_error( $prepared ) ) {
            return new \WP_REST_Response( [ 'code' => $prepared->get_error_code(), 'message' => $prepared->get_error_message() ], 400 );
        }
        $confirmation = sanitize_text_field( (string) ( $params['confirmation'] ?? '' ) );
        if ( ! hash_equals( $prepared['confirmation'], $confirmation ) ) {
            return new \WP_REST_Response( [ 'code' => 'content_import_confirmation', 'message' => 'Type the exact confirmation phrase before running this import.' ], 400 );
        }

        $results = [];
        $completed = [ 'created' => 0, 'updated' => 0, 'skipped' => 0, 'failed' => 0, 'images_imported' => 0, 'image_warnings' => 0 ];
        foreach ( $prepared['rows'] as $row ) {
            if ( in_array( $row['action'], [ 'skip', 'invalid' ], true ) ) {
                $completed['skipped']++;
                $results[] = [ 'source_index' => $row['source_index'], 'title' => $row['title'], 'status' => $row['action'], 'message' => $row['reason'] ];
                continue;
            }
            $post_data = $row['post'];
            $categories = $post_data['categories'];
            $tags = $post_data['tags'];
            $featured_image_url = $post_data['featured_image_url'];
            $custom_fields = $post_data['custom_fields'];
            unset( $post_data['categories'], $post_data['tags'], $post_data['featured_image_url'], $post_data['custom_fields'] );
            if ( empty( $post_data['post_date'] ) ) {
                unset( $post_data['post_date'] );
            } else {
                $post_data['post_date_gmt'] = get_gmt_from_date( $post_data['post_date'] );
            }

            if ( 'update' === $row['action'] ) {
                $post_data['ID'] = $row['existing_id'];
                $post_id = wp_update_post( $post_data, true );
            } else {
                $post_id = wp_insert_post( $post_data, true );
            }
            if ( is_wp_error( $post_id ) || ! $post_id ) {
                $completed['failed']++;
                $message = is_wp_error( $post_id ) ? $post_id->get_error_message() : 'WordPress could not save this row.';
                $results[] = [ 'source_index' => $row['source_index'], 'title' => $row['title'], 'status' => 'failed', 'message' => $message ];
                continue;
            }

            if ( taxonomy_exists( 'category' ) && is_object_in_taxonomy( $prepared['options']['post_type'], 'category' ) && ! empty( $categories ) ) {
                wp_set_object_terms( $post_id, $categories, 'category', false );
            }
            if ( taxonomy_exists( 'post_tag' ) && is_object_in_taxonomy( $prepared['options']['post_type'], 'post_tag' ) && ! empty( $tags ) ) {
                wp_set_object_terms( $post_id, $tags, 'post_tag', false );
            }
            foreach ( array_slice( $custom_fields, 0, 50, true ) as $meta_key => $meta_value ) {
                update_post_meta( $post_id, $meta_key, $meta_value );
            }

            $warnings = [];
            if ( $prepared['options']['import_media'] && '' !== $featured_image_url ) {
                $attachment_id = $this->studio_content_import_featured_image( $featured_image_url, (int) $post_id );
                if ( is_wp_error( $attachment_id ) ) {
                    $completed['image_warnings']++;
                    $warnings[] = $attachment_id->get_error_message();
                } elseif ( $attachment_id ) {
                    $completed['images_imported']++;
                }
            }
            if ( 'update' === $row['action'] ) {
                $completed['updated']++;
            } else {
                $completed['created']++;
            }
            $results[] = [
                'source_index' => $row['source_index'],
                'title'        => $row['title'],
                'status'       => 'update' === $row['action'] ? 'updated' : 'created',
                'post_id'      => (int) $post_id,
                'warnings'     => $warnings,
            ];
        }

        $report_id = 'content-import-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 6, false, false );
        $reports = get_option( 've_content_studio_import_reports', [] );
        if ( ! is_array( $reports ) ) {
            $reports = [];
        }
        array_unshift( $reports, [
            'id'         => $report_id,
            'created_at' => gmdate( 'c' ),
            'user_id'    => get_current_user_id(),
            'file_name'  => sanitize_file_name( (string) ( $params['file_name'] ?? 'content-import.csv' ) ),
            'mapping'    => $prepared['mapping'],
            'options'    => $prepared['options'],
            'preview'    => $prepared['summary'],
            'completed'  => $completed,
            'results'    => array_slice( $results, 0, 250 ),
            'results_truncated' => count( $results ) > 250,
        ] );
        update_option( 've_content_studio_import_reports', array_slice( $reports, 0, 10 ), false );

        return new \WP_REST_Response( [
            'success'   => 0 === $completed['failed'],
            'report_id' => $report_id,
            'summary'   => $completed,
            'results'   => $results,
        ], 200 );
    }

    public function list_studio_posts( \WP_REST_Request $request ): \WP_REST_Response {
        $post_type = sanitize_key( $request->get_param( 'post_type' ) ?: 'post' );
        $search = sanitize_text_field( $request->get_param( 'search' ) ?: '' );
        $status = sanitize_key( $request->get_param( 'status' ) ?: 'active' );
        $allowed_statuses = [ 'publish', 'draft', 'pending', 'private', 'trash' ];
        $post_status = [ 'publish', 'draft', 'pending', 'private', 'trash' ];
        if ( in_array( $status, $allowed_statuses, true ) ) {
            $post_status = [ $status ];
        }

        $args = [
            'post_type'      => $post_type,
            'posts_per_page' => 150,
            'post_status'    => $post_status,
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ];

        if ( $search ) {
            $args['s'] = $search;
        }

        $query = new \WP_Query( $args );
        $posts = [];

        foreach ( $query->posts as $post ) {
            $posts[] = $this->studio_post_payload( $post );
        }

        return new \WP_REST_Response( $posts, 200 );
    }

    public function update_studio_option_page( \WP_REST_Request $request ): \WP_REST_Response {
        $id = sanitize_key( (string) $request->get_param( 'id' ) );
        $params = $request->get_json_params() ?: [];
        $fields = isset( $params['fields'] ) && is_array( $params['fields'] ) ? $params['fields'] : [];
        $post_id = sanitize_text_field( (string) ( $params['post_id'] ?? 'options' ) );
        if ( '' === $id || 0 !== strpos( $id, 'option-' ) ) {
            return new \WP_REST_Response( [ 'code' => 'invalid_option_page', 'message' => 'Invalid option page.' ], 400 );
        }
        if ( empty( $fields ) ) {
            return new \WP_REST_Response( [ 'success' => true, 'fields' => [] ], 200 );
        }
        foreach ( $fields as $field_name => $value ) {
            $name = sanitize_key( (string) $field_name );
            if ( '' === $name ) {
                continue;
            }
            $clean_value = $this->studio_meta_value_from_ui( $value );
            if ( is_string( $clean_value ) ) {
                $clean_value = wp_kses_post( $clean_value );
            }
            if ( function_exists( 'update_field' ) ) {
                update_field( $name, $clean_value, $post_id ?: 'options' );
            } else {
                update_option( 'options_' . $name, $clean_value, false );
            }
        }
        return new \WP_REST_Response( [ 'success' => true, 'fields' => $fields ], 200 );
    }

    public function create_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $post_type = sanitize_key( $params['post_type'] ?? 'post' );
        $title = sanitize_text_field( $params['title'] ?? '' );
        $status = sanitize_key( $params['status'] ?? 'draft' );
        $slug = sanitize_title( $params['slug'] ?? '' );
        $content = array_key_exists( 'content', $params ) ? wp_kses_post( (string) $params['content'] ) : '';
        $excerpt = array_key_exists( 'excerpt', $params ) ? sanitize_textarea_field( (string) $params['excerpt'] ) : '';
        $allowed_statuses = [ 'publish', 'draft', 'pending', 'private' ];
        if ( ! in_array( $status, $allowed_statuses, true ) ) {
            $status = 'draft';
        }

        if ( empty( $title ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_title', 'message' => 'Post title is required.' ], 400 );
        }

        if ( ! post_type_exists( $post_type ) ) {
            return new \WP_REST_Response( [ 'code' => 'invalid_post_type', 'message' => 'Post type does not exist.' ], 400 );
        }

        $post_id = wp_insert_post([
            'post_type'    => $post_type,
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_content' => $content,
            'post_excerpt' => $excerpt,
            'post_status'  => $status,
        ]);

        if ( is_wp_error( $post_id ) ) {
            return new \WP_REST_Response( [ 'code' => 'create_failed', 'message' => $post_id->get_error_message() ], 500 );
        }

        if ( ! $post_id ) {
            return new \WP_REST_Response( [ 'code' => 'create_failed', 'message' => 'Could not create post.' ], 500 );
        }

        $post = get_post( $post_id );
        return new \WP_REST_Response( $this->studio_post_payload( $post ), 200 );
    }

    public function update_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $id = absint( $request->get_param( 'id' ) );
        $params = $request->get_json_params() ?: [];
        $status = sanitize_key( $params['status'] ?? '' );
        $title = sanitize_text_field( $params['title'] ?? '' );
        $slug = sanitize_title( $params['slug'] ?? '' );
        $content_provided = array_key_exists( 'content', $params );
        $excerpt_provided = array_key_exists( 'excerpt', $params );

        if ( ! $id || ! get_post( $id ) ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'Post not found.' ], 404 );
        }

        $update = [ 'ID' => $id ];
        if ( $status ) {
            $update['post_status'] = $status;
        }
        if ( $title ) {
            $update['post_title'] = $title;
        }
        if ( $slug ) {
            $update['post_name'] = $slug;
        }
        if ( $content_provided ) {
            $update['post_content'] = wp_kses_post( (string) $params['content'] );
        }
        if ( $excerpt_provided ) {
            $update['post_excerpt'] = sanitize_textarea_field( (string) $params['excerpt'] );
        }
        if ( array_key_exists( 'parent', $params ) ) {
            $update['post_parent'] = absint( $params['parent'] );
        }
        if ( array_key_exists( 'menu_order', $params ) ) {
            $update['menu_order'] = intval( $params['menu_order'] );
        }
        if ( array_key_exists( 'author', $params ) ) {
            $author_id = absint( $params['author'] );
            if ( $author_id && get_user_by( 'id', $author_id ) ) {
                $update['post_author'] = $author_id;
            }
        }
        if ( array_key_exists( 'comment_status', $params ) ) {
            $update['comment_status'] = rest_sanitize_boolean( $params['comment_status'] ) ? 'open' : 'closed';
        }
        if ( array_key_exists( 'ping_status', $params ) ) {
            $update['ping_status'] = rest_sanitize_boolean( $params['ping_status'] ) ? 'open' : 'closed';
        }

        if ( count( $update ) > 1 ) {
            $updated_id = wp_update_post( $update, true );
            if ( is_wp_error( $updated_id ) ) {
                return new \WP_REST_Response( [ 'code' => 'update_failed', 'message' => $updated_id->get_error_message() ], 500 );
            }
        }
        if ( array_key_exists( 'featured_media', $params ) ) {
            $featured_media = absint( $params['featured_media'] );
            if ( $featured_media ) {
                set_post_thumbnail( $id, $featured_media );
            } else {
                delete_post_thumbnail( $id );
            }
        }
        if ( array_key_exists( 'template', $params ) ) {
            update_post_meta( $id, '_wp_page_template', sanitize_text_field( (string) $params['template'] ) );
        }
        if ( isset( $params['custom_fields'] ) && is_array( $params['custom_fields'] ) ) {
            foreach ( $params['custom_fields'] as $meta_key => $meta_value ) {
                $key = sanitize_key( (string) $meta_key );
                if ( '' === $key || 0 === strpos( $key, '_' ) ) {
                    continue;
                }
                $value = $this->studio_meta_value_from_ui( $meta_value );
                if ( is_string( $value ) ) {
                    $value = wp_kses_post( $value );
                }
                $updated = false;
                if ( function_exists( 'update_field' ) ) {
                    $updated = (bool) update_field( $key, $value, $id );
                }
                if ( ! $updated ) {
                    update_post_meta( $id, $key, $value );
                }
            }
        }
        if ( isset( $params['seo_details'] ) && is_array( $params['seo_details'] ) ) {
            $this->update_studio_rank_math_meta( $id, $params['seo_details'] );
        }
        if ( isset( $params['terms'] ) && is_array( $params['terms'] ) ) {
            $allowed_taxonomies = array_fill_keys( get_object_taxonomies( get_post_type( $id ), 'names' ), true );
            foreach ( $params['terms'] as $taxonomy => $term_ids ) {
                $taxonomy = sanitize_key( (string) $taxonomy );
                if ( ! isset( $allowed_taxonomies[ $taxonomy ] ) || 'post_format' === $taxonomy || ! is_array( $term_ids ) ) {
                    continue;
                }
                $clean_ids = array_values( array_unique( array_filter( array_map( 'absint', $term_ids ) ) ) );
                wp_set_object_terms( $id, $clean_ids, $taxonomy, false );
            }
        }

        $post = get_post( $id );
        return new \WP_REST_Response( $this->studio_post_payload( $post ), 200 );
    }

    public function duplicate_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $id = absint( $request->get_param( 'id' ) );
        $params = $request->get_json_params() ?: [];
        $status = sanitize_key( $params['status'] ?? 'draft' );
        if ( ! in_array( $status, [ 'draft', 'pending', 'private' ], true ) ) {
            $status = 'draft';
        }

        $source = get_post( $id );
        if ( ! $source ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'Post not found.' ], 404 );
        }

        if ( ! current_user_can( 'edit_post', $id ) ) {
            return new \WP_REST_Response( [ 'code' => 'forbidden', 'message' => 'You cannot duplicate this content item.' ], 403 );
        }

        $new_id = wp_insert_post( [
            'post_type'      => $source->post_type,
            'post_title'     => sprintf( '%s Copy', $source->post_title ?: 'Untitled' ),
            'post_content'   => $source->post_content,
            'post_excerpt'   => $source->post_excerpt,
            'post_status'    => $status,
            'post_author'    => get_current_user_id() ?: $source->post_author,
            'post_parent'    => (int) $source->post_parent,
            'menu_order'     => (int) $source->menu_order,
            'comment_status' => $source->comment_status,
            'ping_status'    => $source->ping_status,
        ], true );

        if ( is_wp_error( $new_id ) ) {
            return new \WP_REST_Response( [ 'code' => 'duplicate_failed', 'message' => $new_id->get_error_message() ], 500 );
        }

        $meta = get_post_meta( $id );
        foreach ( $meta as $key => $values ) {
            if ( '_edit_lock' === $key || '_edit_last' === $key ) {
                continue;
            }
            foreach ( (array) $values as $value ) {
                add_post_meta( $new_id, $key, maybe_unserialize( $value ) );
            }
        }

        $taxonomies = get_object_taxonomies( $source->post_type );
        foreach ( $taxonomies as $taxonomy ) {
            $terms = wp_get_object_terms( $id, $taxonomy, [ 'fields' => 'ids' ] );
            if ( ! is_wp_error( $terms ) ) {
                wp_set_object_terms( $new_id, array_map( 'intval', $terms ), $taxonomy, false );
            }
        }

        $thumb_id = get_post_thumbnail_id( $id );
        if ( $thumb_id ) {
            set_post_thumbnail( $new_id, $thumb_id );
        }

        $post = get_post( $new_id );
        return new \WP_REST_Response( $this->studio_post_payload( $post ), 200 );
    }

    public function delete_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $id = absint( $request->get_param( 'id' ) );
        $force = rest_sanitize_boolean( $request->get_param( 'force' ) );

        if ( ! $id || ! get_post( $id ) ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'Post not found.' ], 404 );
        }

        $res = wp_delete_post( $id, $force );
        if ( $res ) {
            return new \WP_REST_Response( [ 'id' => $id ], 200 );
        }

        return new \WP_REST_Response( [ 'code' => 'delete_failed', 'message' => 'Could not delete post.' ], 500 );
    }

    public function create_or_update_studio_cpt( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $name = sanitize_key( $params['name'] ?? '' );
        $singular = sanitize_text_field( $params['singular'] ?? '' );
        $plural = sanitize_text_field( $params['plural'] ?? '' );
        $source = sanitize_key( $params['source'] ?? 'acf' );

        if ( empty( $name ) || empty( $singular ) || empty( $plural ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_params', 'message' => 'Name, singular label, and plural label are required.' ], 400 );
        }

        if ( $source === 'jet' ) {
            $cpts = get_option( 'jet_engine_cpt', [] );
            if ( ! is_array( $cpts ) ) {
                $cpts = [];
            }
            $found = false;
            foreach ( $cpts as &$c ) {
                if ( ( $c['slug'] ?? '' ) === $name ) {
                    $c['labels']['name'] = $plural;
                    $c['labels']['singular_name'] = $singular;
                    $found = true;
                    break;
                }
            }
            if ( ! $found ) {
                $cpts[] = [
                    'slug'   => $name,
                    'labels' => [
                        'name'          => $plural,
                        'singular_name' => $singular,
                    ],
                    'args'   => [
                        'public'       => true,
                        'show_in_rest' => true,
                    ],
                ];
            }
            update_option( 'jet_engine_cpt', $cpts );
        } else {
            if ( function_exists( 'acf_update_post_type' ) ) {
                acf_update_post_type([
                    'post_type' => $name,
                    'title'     => $plural,
                    'labels'    => [
                        'name'          => $plural,
                        'singular_name' => $singular,
                    ],
                    'active'    => true,
                    'show_in_rest' => true,
                ]);
            } else {
                $cpts = get_option( 'jet_engine_cpt', [] );
                if ( ! is_array( $cpts ) ) {
                    $cpts = [];
                }
                $found = false;
                foreach ( $cpts as &$c ) {
                    if ( ( $c['slug'] ?? '' ) === $name ) {
                        $c['labels']['name'] = $plural;
                        $c['labels']['singular_name'] = $singular;
                        $found = true;
                        break;
                    }
                }
                if ( ! $found ) {
                    $cpts[] = [
                        'slug'   => $name,
                        'labels' => [
                            'name'          => $plural,
                            'singular_name' => $singular,
                        ],
                        'args'   => [
                            'public'       => true,
                            'show_in_rest' => true,
                        ],
                    ];
                }
                update_option( 'jet_engine_cpt', $cpts );
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function delete_studio_cpt( \WP_REST_Request $request ): \WP_REST_Response {
        $name = sanitize_key( $request->get_param( 'name' ) );

        $jet_cpts = get_option( 'jet_engine_cpt', [] );
        if ( is_array( $jet_cpts ) ) {
            $filtered = [];
            $found = false;
            foreach ( $jet_cpts as $c ) {
                if ( ( $c['slug'] ?? '' ) === $name ) {
                    $found = true;
                } else {
                    $filtered[] = $c;
                }
            }
            if ( $found ) {
                update_option( 'jet_engine_cpt', $filtered );
            }
        }

        if ( function_exists( 'acf_delete_post_type' ) ) {
            acf_delete_post_type( $name );
        } else {
            $acf_posts = get_posts([
                'post_type'   => 'acf-post-type',
                'name'        => $name,
                'post_status' => 'any',
                'numberposts' => 1,
            ]);
            if ( ! empty( $acf_posts ) ) {
                wp_delete_post( $acf_posts[0]->ID, true );
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function create_or_update_studio_fields( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $title = sanitize_text_field( $params['title'] ?? '' );
        $post_types = is_array( $params['post_types'] ?? null ) ? array_map( 'sanitize_key', $params['post_types'] ) : [ 'post' ];
        $fields = is_array( $params['fields'] ?? null ) ? $params['fields'] : [];
        $source = sanitize_key( $params['source'] ?? 'acf' );

        if ( empty( $title ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_title', 'message' => 'Title is required.' ], 400 );
        }

        $sanitized_fields = [];
        foreach ( $fields as $f ) {
            $f_name = sanitize_key( $f['name'] ?? '' );
            if ( $f_name ) {
                $sanitized_fields[] = [
                    'name'  => $f_name,
                    'label' => sanitize_text_field( $f['label'] ?? $f_name ),
                    'type'  => sanitize_key( $f['type'] ?? 'text' ),
                ];
            }
        }

        if ( $source === 'jet' ) {
            $boxes = get_option( 'jet_engine_meta_boxes', [] );
            if ( ! is_array( $boxes ) ) {
                $boxes = [];
            }
            $key = sanitize_key( $title );
            $meta_fields = [];
            foreach ( $sanitized_fields as $f ) {
                $meta_fields[] = [
                    'name'  => $f['name'],
                    'title' => $f['label'],
                    'type'  => $f['type'],
                ];
            }
            $new_box = [
                'id'           => $key,
                'name'         => $title,
                'args'         => [
                    'allowed_post_types' => $post_types,
                ],
                'meta_fields'  => $meta_fields,
            ];
            $found = false;
            foreach ( $boxes as &$b ) {
                if ( ( $b['id'] ?? '' ) === $key ) {
                    $b = $new_box;
                    $found = true;
                    break;
                }
            }
            if ( ! $found ) {
                $boxes[] = $new_box;
            }
            update_option( 'jet_engine_meta_boxes', $boxes );
        } else {
            if ( function_exists( 'acf_update_field_group' ) ) {
                $key = 'group_cs_' . sanitize_key( $title );
                $field_group = [
                    'key'      => $key,
                    'title'    => $title,
                    'location' => [],
                    'active'   => true,
                ];
                foreach ( $post_types as $pt ) {
                    $field_group['location'][] = [
                        [
                            'param'    => 'post_type',
                            'operator' => '==',
                            'value'    => $pt,
                        ]
                    ];
                }
                $group = acf_update_field_group( $field_group );
                if ( $group && isset( $group['ID'] ) ) {
                    $existing = acf_get_fields( $group['ID'] ) ?: [];
                    foreach ( $existing as $ef ) {
                        acf_delete_field( $ef['ID'] );
                    }
                    foreach ( $sanitized_fields as $f ) {
                        $f_key = 'field_' . sanitize_key( $group['key'] . '_' . $f['name'] );
                        acf_update_field([
                            'key'          => $f_key,
                            'parent'       => $group['ID'],
                            'name'         => $f['name'],
                            'label'        => $f['label'],
                            'type'         => $f['type'],
                        ]);
                    }
                }
            } else {
                $boxes = get_option( 'jet_engine_meta_boxes', [] );
                if ( ! is_array( $boxes ) ) {
                    $boxes = [];
                }
                $key = sanitize_key( $title );
                $meta_fields = [];
                foreach ( $sanitized_fields as $f ) {
                    $meta_fields[] = [
                        'name'  => $f['name'],
                        'title' => $f['label'],
                        'type'  => $f['type'],
                    ];
                }
                $new_box = [
                    'id'           => $key,
                    'name'         => $title,
                    'args'         => [
                        'allowed_post_types' => $post_types,
                    ],
                    'meta_fields'  => $meta_fields,
                ];
                $found = false;
                foreach ( $boxes as &$b ) {
                    if ( ( $b['id'] ?? '' ) === $key ) {
                        $b = $new_box;
                        $found = true;
                        break;
                    }
                }
                if ( ! $found ) {
                    $boxes[] = $new_box;
                }
                update_option( 'jet_engine_meta_boxes', $boxes );
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function delete_studio_fields( \WP_REST_Request $request ): \WP_REST_Response {
        $id = sanitize_key( $request->get_param( 'id' ) );

        if ( 0 === strpos( $id, 'jet-' ) ) {
            $key = substr( $id, 4 );
            $boxes = get_option( 'jet_engine_meta_boxes', [] );
            if ( is_array( $boxes ) ) {
                $filtered = [];
                foreach ( $boxes as $b ) {
                    if ( ( $b['id'] ?? '' ) !== $key ) {
                        $filtered[] = $b;
                    }
                }
                update_option( 'jet_engine_meta_boxes', $filtered );
            }
        } elseif ( 0 === strpos( $id, 'acf-' ) ) {
            $acf_id = (int) substr( $id, 4 );
            if ( function_exists( 'acf_delete_field_group' ) ) {
                acf_delete_field_group( $acf_id );
            } else {
                wp_delete_post( $acf_id, true );
            }
        } else {
            $boxes = get_option( 'jet_engine_meta_boxes', [] );
            if ( is_array( $boxes ) ) {
                $filtered = [];
                $found = false;
                foreach ( $boxes as $b ) {
                    if ( ( $b['id'] ?? '' ) === $id ) {
                        $found = true;
                    } else {
                        $filtered[] = $b;
                    }
                }
                if ( $found ) {
                    update_option( 'jet_engine_meta_boxes', $filtered );
                }
            }

            if ( function_exists( 'acf_delete_field_group' ) ) {
                acf_delete_field_group( $id );
            } else {
                $acf_id = (int) $id;
                if ( $acf_id ) {
                    wp_delete_post( $acf_id, true );
                }
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    private function studio_jet_to_acf_field_type( string $type ): string {
        $type = sanitize_key( $type );
        $map = [
            'text'      => 'text',
            'textarea'  => 'textarea',
            'wysiwyg'   => 'wysiwyg',
            'editor'    => 'wysiwyg',
            'number'    => 'number',
            'date'      => 'date_picker',
            'date_time' => 'date_time_picker',
            'datetime'  => 'date_time_picker',
            'time'      => 'time_picker',
            'media'     => 'image',
            'image'     => 'image',
            'gallery'   => 'gallery',
            'select'    => 'select',
            'radio'     => 'radio',
            'checkbox'  => 'checkbox',
            'switcher'  => 'true_false',
            'toggle'    => 'true_false',
            'colorpicker' => 'color_picker',
            'color'     => 'color_picker',
            'repeater'  => 'repeater',
        ];

        return $map[ $type ] ?? 'text';
    }

    private function studio_collect_jet_cpts(): array {
        $raw = get_option( 'jet_engine_cpt', [] );
        if ( ! is_array( $raw ) ) {
            return [];
        }

        $out = [];
        foreach ( $raw as $key => $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            $slug = sanitize_key( $item['slug'] ?? $item['post_type'] ?? $item['name'] ?? $key );
            if ( '' === $slug ) {
                continue;
            }
            $labels = is_array( $item['labels'] ?? null ) ? $item['labels'] : [];
            $plural = sanitize_text_field( $labels['name'] ?? $item['label'] ?? $item['title'] ?? ucwords( str_replace( [ '-', '_' ], ' ', $slug ) ) );
            $singular = sanitize_text_field( $labels['singular_name'] ?? $item['singular'] ?? $plural );
            $args = is_array( $item['args'] ?? null ) ? $item['args'] : [];
            $out[] = [
                'slug'     => $slug,
                'plural'   => $plural,
                'singular' => $singular,
                'public'   => isset( $args['public'] ) ? (bool) $args['public'] : true,
                'rest'     => isset( $args['show_in_rest'] ) ? (bool) $args['show_in_rest'] : true,
            ];
        }

        return $out;
    }

    private function studio_collect_jet_field_groups(): array {
        $boxes = get_option( 'jet_engine_meta_boxes', [] );
        if ( ! is_array( $boxes ) ) {
            return [];
        }

        $out = [];
        foreach ( $boxes as $index => $box ) {
            if ( ! is_array( $box ) ) {
                continue;
            }
            $id = sanitize_key( $box['id'] ?? $box['slug'] ?? $index );
            $title = sanitize_text_field( $box['name'] ?? $box['title'] ?? $id );
            $args = is_array( $box['args'] ?? null ) ? $box['args'] : [];
            $post_types = [];
            $allowed = $args['allowed_post_types'] ?? $args['post_types'] ?? $box['post_types'] ?? [];
            if ( is_string( $allowed ) ) {
                $allowed = [ $allowed ];
            }
            if ( is_array( $allowed ) ) {
                foreach ( $allowed as $pt ) {
                    $pt = sanitize_key( (string) $pt );
                    if ( $pt ) {
                        $post_types[] = $pt;
                    }
                }
            }
            if ( empty( $post_types ) ) {
                $post_types = [ 'post' ];
            }

            $fields = [];
            $raw_fields = is_array( $box['meta_fields'] ?? null ) ? $box['meta_fields'] : [];
            foreach ( $raw_fields as $field_index => $field ) {
                if ( ! is_array( $field ) ) {
                    continue;
                }
                $name = sanitize_key( $field['name'] ?? $field['id'] ?? $field['key'] ?? 'field_' . $field_index );
                if ( ! $name ) {
                    continue;
                }
                $fields[] = [
                    'name'  => $name,
                    'label' => sanitize_text_field( $field['title'] ?? $field['label'] ?? ucwords( str_replace( [ '-', '_' ], ' ', $name ) ) ),
                    'type'  => $this->studio_jet_to_acf_field_type( (string) ( $field['type'] ?? 'text' ) ),
                ];
            }

            $out[] = [
                'id'         => $id,
                'title'      => $title,
                'post_types' => array_values( array_unique( $post_types ) ),
                'fields'     => $fields,
            ];
        }

        return $out;
    }

    private function studio_jet_to_acf_plan(): array {
        return [
            'has_acf_fields_api' => function_exists( 'acf_update_field_group' ),
            'has_acf_cpt_api'    => function_exists( 'acf_update_post_type' ),
            'cpts'               => $this->studio_collect_jet_cpts(),
            'field_groups'       => $this->studio_collect_jet_field_groups(),
        ];
    }

    public function preview_jet_to_acf_migration(): \WP_REST_Response {
        $plan = $this->studio_jet_to_acf_plan();
        $plan['mode'] = 'preview';
        $plan['note'] = 'Preview only. Applying this creates ACF mirrors and does not delete JetEngine data.';
        return new \WP_REST_Response( $plan, 200 );
    }

    public function run_jet_to_acf_migration(): \WP_REST_Response {
        $plan = $this->studio_jet_to_acf_plan();
        if ( ! $plan['has_acf_fields_api'] ) {
            return new \WP_REST_Response( [
                'code'    => 'acf_unavailable',
                'message' => 'ACF field group APIs are not available. Activate ACF before running the JetEngine migration.',
            ], 400 );
        }

        $results = [
            'cpts'         => [],
            'field_groups' => [],
            'warnings'     => [],
        ];

        if ( ! $plan['has_acf_cpt_api'] ) {
            $results['warnings'][] = 'ACF post type API is unavailable, so CPT definitions were previewed but not mirrored.';
        } else {
            foreach ( $plan['cpts'] as $cpt ) {
                $updated = acf_update_post_type( [
                    'post_type'    => $cpt['slug'],
                    'title'        => $cpt['plural'],
                    'labels'       => [
                        'name'          => $cpt['plural'],
                        'singular_name' => $cpt['singular'],
                    ],
                    'active'       => true,
                    'public'       => $cpt['public'],
                    'show_in_rest' => $cpt['rest'],
                ] );
                $results['cpts'][] = [
                    'slug'    => $cpt['slug'],
                    'success' => ! empty( $updated ),
                ];
            }
        }

        foreach ( $plan['field_groups'] as $group ) {
            $group_key = 'group_mv_jet_' . sanitize_key( $group['id'] );
            $field_group = [
                'key'      => $group_key,
                'title'    => $group['title'],
                'location' => [],
                'active'   => true,
            ];
            foreach ( $group['post_types'] as $post_type ) {
                $field_group['location'][] = [
                    [
                        'param'    => 'post_type',
                        'operator' => '==',
                        'value'    => $post_type,
                    ],
                ];
            }
            $acf_group = acf_update_field_group( $field_group );
            $field_count = 0;
            if ( $acf_group && isset( $acf_group['ID'] ) ) {
                $existing = function_exists( 'acf_get_fields' ) ? acf_get_fields( $acf_group['ID'] ) : [];
                if ( is_array( $existing ) ) {
                    foreach ( $existing as $existing_field ) {
                        if ( isset( $existing_field['ID'] ) && function_exists( 'acf_delete_field' ) ) {
                            acf_delete_field( $existing_field['ID'] );
                        }
                    }
                }
                foreach ( $group['fields'] as $field ) {
                    acf_update_field( [
                        'key'    => 'field_mv_jet_' . sanitize_key( $group['id'] . '_' . $field['name'] ),
                        'parent' => $acf_group['ID'],
                        'name'   => $field['name'],
                        'label'  => $field['label'],
                        'type'   => $field['type'],
                    ] );
                    $field_count++;
                }
            }
            $results['field_groups'][] = [
                'id'          => $group['id'],
                'title'       => $group['title'],
                'field_count' => $field_count,
                'success'     => $field_count === count( $group['fields'] ),
            ];
        }

        return new \WP_REST_Response( [
            'success' => true,
            'results' => $results,
            'note'    => 'JetEngine data was left in place. Review ACF mirrors before disabling JetEngine.',
        ], 200 );
    }

    public function list_studio_plugins(): \WP_REST_Response {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins = get_plugins();
        $active = (array) get_option( 'active_plugins', [] );
        $auto_updates = (array) get_site_option( 'auto_update_plugins', [] );
        $updates = get_site_transient( 'update_plugins' );
        $response = is_object( $updates ) && isset( $updates->response ) && is_array( $updates->response ) ? $updates->response : [];
        $rows = [];

        foreach ( $plugins as $file => $data ) {
            $update = $response[ $file ] ?? null;
            $rows[] = [
                'file'             => $file,
                'slug'             => sanitize_key( dirname( $file ) === '.' ? basename( $file, '.php' ) : dirname( $file ) ),
                'name'             => $data['Name'] ?? $file,
                'description'      => wp_strip_all_tags( $data['Description'] ?? '' ),
                'author'           => wp_strip_all_tags( $data['Author'] ?? '' ),
                'version'          => $data['Version'] ?? '',
                'active'           => in_array( $file, $active, true ),
                'auto_update'      => in_array( $file, $auto_updates, true ),
                'update_available' => ! empty( $update ),
                'new_version'      => is_object( $update ) ? ( $update->new_version ?? '' ) : '',
                'update_url'       => ! empty( $update ) ? wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . urlencode( $file ) ), 'upgrade-plugin_' . $file ) : '',
            ];
        }

        usort( $rows, function( $a, $b ) {
            return strcasecmp( $a['name'], $b['name'] );
        } );

        return new \WP_REST_Response( [ 'plugins' => $rows ], 200 );
    }

    public function run_studio_plugin_action( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! function_exists( 'activate_plugin' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        $params = $request->get_json_params() ?: [];
        $plugin = plugin_basename( sanitize_text_field( $params['plugin'] ?? '' ) );
        $action = sanitize_key( $params['action'] ?? '' );

        if ( empty( $plugin ) || ! file_exists( WP_PLUGIN_DIR . '/' . $plugin ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Plugin not found.' ], 404 );
        }

        if ( $action === 'activate' ) {
            $result = activate_plugin( $plugin );
            if ( is_wp_error( $result ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
            }
            return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin activated.' ], 200 );
        }

        if ( $action === 'deactivate' ) {
            deactivate_plugins( [ $plugin ], false, false );
            return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin deactivated.' ], 200 );
        }

        if ( $action === 'auto_update_on' || $action === 'auto_update_off' ) {
            $list = (array) get_site_option( 'auto_update_plugins', [] );
            if ( $action === 'auto_update_on' ) {
                $list[] = $plugin;
                $list = array_values( array_unique( $list ) );
                update_site_option( 'auto_update_plugins', $list );
                return new \WP_REST_Response( [ 'success' => true, 'message' => 'Auto-update enabled.' ], 200 );
            }
            $list = array_values( array_diff( $list, [ $plugin ] ) );
            update_site_option( 'auto_update_plugins', $list );
            return new \WP_REST_Response( [ 'success' => true, 'message' => 'Auto-update disabled.' ], 200 );
        }

        if ( $action === 'delete' ) {
            if ( is_plugin_active( $plugin ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => 'Deactivate the plugin before deleting it.' ], 400 );
            }
            $result = delete_plugins( [ $plugin ] );
            if ( is_wp_error( $result ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
            }
            return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin deleted.' ], 200 );
        }

        return new \WP_REST_Response( [ 'success' => false, 'message' => 'Unknown plugin action.' ], 400 );
    }

    private function load_plugin_installer_dependencies(): void {
        if ( ! function_exists( 'plugins_api' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    }

    public function search_plugin_directory( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! current_user_can( 'install_plugins' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'You do not have permission to install plugins.' ], 403 );
        }

        $search = sanitize_text_field( (string) ( $request->get_param( 'search' ) ?: '' ) );
        $this->load_plugin_installer_dependencies();
        $args = [
            'per_page' => 12,
            'page'     => 1,
            'fields'   => [
                'short_description' => true,
                'description'       => false,
                'sections'          => false,
                'icons'             => true,
                'rating'            => true,
                'ratings'           => false,
                'downloaded'        => false,
                'active_installs'   => true,
                'last_updated'      => true,
                'homepage'          => true,
            ],
        ];
        if ( strlen( $search ) >= 2 ) {
            $args['search'] = $search;
        } else {
            $args['browse'] = 'popular';
        }
        $api = plugins_api( 'query_plugins', $args );

        if ( is_wp_error( $api ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $api->get_error_message(), 'plugins' => [] ], 400 );
        }

        $rows = [];
        foreach ( (array) ( $api->plugins ?? [] ) as $plugin ) {
            $rows[] = [
                'slug'              => sanitize_key( $plugin['slug'] ?? '' ),
                'name'              => wp_strip_all_tags( $plugin['name'] ?? '' ),
                'version'           => sanitize_text_field( $plugin['version'] ?? '' ),
                'author'            => wp_strip_all_tags( $plugin['author'] ?? '' ),
                'short_description' => wp_strip_all_tags( $plugin['short_description'] ?? '' ),
                'rating'            => isset( $plugin['rating'] ) ? (float) $plugin['rating'] : 0,
                'active_installs'   => isset( $plugin['active_installs'] ) ? absint( $plugin['active_installs'] ) : 0,
                'last_updated'      => sanitize_text_field( $plugin['last_updated'] ?? '' ),
                'homepage'          => esc_url_raw( $plugin['homepage'] ?? '' ),
                'icons'             => is_array( $plugin['icons'] ?? null ) ? array_map( 'esc_url_raw', $plugin['icons'] ) : [],
            ];
        }

        return new \WP_REST_Response( [ 'plugins' => $rows ], 200 );
    }

    public function install_directory_plugin( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! current_user_can( 'install_plugins' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'You do not have permission to install plugins.' ], 403 );
        }

        $params = $request->get_json_params() ?: [];
        $slug = sanitize_key( (string) ( $params['slug'] ?? '' ) );
        if ( empty( $slug ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Missing plugin slug.' ], 400 );
        }

        $this->load_plugin_installer_dependencies();
        $api = plugins_api( 'plugin_information', [
            'slug'   => $slug,
            'fields' => [ 'sections' => false ],
        ] );
        if ( is_wp_error( $api ) || empty( $api->download_link ) ) {
            $message = is_wp_error( $api ) ? $api->get_error_message() : 'Could not find plugin download URL.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        $skin = new \Automatic_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader( $skin );
        $result = $upgrader->install( $api->download_link );
        if ( is_wp_error( $result ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
        }
        if ( ! $result ) {
            $errors = $skin->get_errors();
            $message = is_wp_error( $errors ) && $errors->has_errors() ? $errors->get_error_message() : 'Plugin install failed.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin installed.' ], 200 );
    }

    public function upload_plugin_zip( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! current_user_can( 'install_plugins' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'You do not have permission to upload plugins.' ], 403 );
        }

        $files = $request->get_file_params();
        if ( empty( $files['plugin_zip'] ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Choose a plugin ZIP first.' ], 400 );
        }

        $this->load_plugin_installer_dependencies();
        $upload = wp_handle_upload( $files['plugin_zip'], [
            'test_form' => false,
            'mimes'     => [ 'zip' => 'application/zip' ],
        ] );
        if ( isset( $upload['error'] ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $upload['error'] ], 400 );
        }

        $skin = new \Automatic_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader( $skin );
        $result = $upgrader->install( $upload['file'] );
        @unlink( $upload['file'] );

        if ( is_wp_error( $result ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
        }
        if ( ! $result ) {
            $errors = $skin->get_errors();
            $message = is_wp_error( $errors ) && $errors->has_errors() ? $errors->get_error_message() : 'Plugin upload install failed.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin uploaded and installed.' ], 200 );
    }
}
