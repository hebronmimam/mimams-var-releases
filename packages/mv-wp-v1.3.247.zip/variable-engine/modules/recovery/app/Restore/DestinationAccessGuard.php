<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Utils\Logger;

// phpcs:disable WordPress.DB.DirectDatabaseQuery.DirectQuery
// phpcs:disable WordPress.DB.DirectDatabaseQuery.NoCaching

defined( 'ABSPATH' ) || exit;

/**
 * Keeps the destination administrator access available after a restore.
 *
 * A full WordPress restore swaps the users/usermeta tables, so the login that
 * existed on the destination site can disappear. This guard captures the
 * current destination administrator accounts before the swap and reapplies them
 * after the backup database is live. The backup users are still restored; this
 * only guarantees the destination admin can still get back in.
 */
final class DestinationAccessGuard {
    public function capture(): array {
        global $wpdb;

        $user_ids = $this->destination_admin_ids();
        $users = [];
        $meta = [];

        foreach ( $user_ids as $user_id ) {
            $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$wpdb->users} WHERE ID = %d", $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            if ( ! is_array( $row ) || empty( $row['user_login'] ) ) {
                continue;
            }

            $rows = $wpdb->get_results( $wpdb->prepare( "SELECT meta_key, meta_value FROM {$wpdb->usermeta} WHERE user_id = %d", $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            $users[] = $row;
            $meta[ (string) $row['user_login'] ] = $this->destination_access_meta( is_array( $rows ) ? $rows : [] );
        }

        $current_user_id = get_current_user_id();
        $current_user_login = '';
        foreach ( $users as $user_row ) {
            if ( isset( $user_row['ID'], $user_row['user_login'] ) && (int) $user_row['ID'] === (int) $current_user_id ) {
                $current_user_login = (string) $user_row['user_login'];
                break;
            }
        }

        return [
            'ok'                 => true,
            'message'            => 'Destination admin access captured.',
            'strategy'           => 'preserve_destination_admin_login_after_restore',
            'users'              => $users,
            'user_meta'          => $meta,
            'captured'           => count( $users ),
            'current_user'       => $current_user_id,
            'current_user_login' => $current_user_login,
            'prefix'             => (string) $wpdb->prefix,
            'cap_key'            => $wpdb->prefix . 'capabilities',
            'level_key'          => $wpdb->prefix . 'user_level',
        ];
    }

    public function reapply( array $state ): array {
        global $wpdb;

        $users = isset( $state['users'] ) && is_array( $state['users'] ) ? $state['users'] : [];
        $all_meta = isset( $state['user_meta'] ) && is_array( $state['user_meta'] ) ? $state['user_meta'] : [];
        $current_login = isset( $state['current_user_login'] ) ? sanitize_user( (string) $state['current_user_login'], true ) : '';
        $kept = [];
        $errors = [];

        if ( '' !== $current_login ) {
            usort( $users, static function ( $a, $b ) use ( $current_login ) {
                $a_login = is_array( $a ) && isset( $a['user_login'] ) ? sanitize_user( (string) $a['user_login'], true ) : '';
                $b_login = is_array( $b ) && isset( $b['user_login'] ) ? sanitize_user( (string) $b['user_login'], true ) : '';
                if ( $a_login === $current_login && $b_login !== $current_login ) { return -1; }
                if ( $b_login === $current_login && $a_login !== $current_login ) { return 1; }
                return 0;
            } );
        }

        foreach ( $users as $user_row ) {
            if ( ! is_array( $user_row ) || empty( $user_row['user_login'] ) ) {
                continue;
            }

            $login = sanitize_user( (string) $user_row['user_login'], true );
            if ( '' === $login ) {
                continue;
            }

            $target_id = $this->find_user_id_by_login( $login );
            $data = $this->clean_user_row( $user_row );

            if ( $target_id > 0 ) {
                unset( $data['ID'] );
                $updated = $wpdb->update( $wpdb->users, $data, [ 'ID' => $target_id ] );
                if ( false === $updated ) {
                    $errors[] = $login;
                    continue;
                }
            } else {
                $preferred_id = isset( $user_row['ID'] ) ? absint( $user_row['ID'] ) : 0;
                if ( $preferred_id > 0 && $this->user_id_is_free( $preferred_id ) ) {
                    $data['ID'] = $preferred_id;
                } else {
                    unset( $data['ID'] );
                }

                $inserted = $wpdb->insert( $wpdb->users, $data );
                if ( false === $inserted ) {
                    $errors[] = $login;
                    continue;
                }
                $target_id = (int) $wpdb->insert_id;
            }

            $meta_rows = isset( $all_meta[ $login ] ) && is_array( $all_meta[ $login ] ) ? $all_meta[ $login ] : [];
            $this->restore_user_meta( $target_id, $meta_rows );
            $this->ensure_admin_meta( $target_id );

            $auth_refreshed = false;
            if ( '' !== $current_login && $login === $current_login ) {
                $auth_refreshed = $this->refresh_current_auth_cookie( $target_id );
            }

            $kept[] = [ 'user_login' => $login, 'user_id' => $target_id, 'auth_cookie_refreshed' => $auth_refreshed ];
        }

        if ( function_exists( 'clean_user_cache' ) ) {
            foreach ( $kept as $entry ) {
                clean_user_cache( (int) $entry['user_id'] );
            }
        }

        Logger::info( 'destination_access_guard_reapplied', 'RestoreBase reapplied destination admin access after restore.', [
            'kept'   => count( $kept ),
            'errors' => count( $errors ),
        ] );

        return [
            'ok'      => empty( $errors ),
            'message' => empty( $errors ) ? 'Destination admin login was preserved.' : 'Some destination admin logins could not be preserved.',
            'kept'    => $kept,
            'errors'  => $errors,
        ];
    }

    private function destination_admin_ids(): array {
        $ids = [];
        $current = get_current_user_id();
        if ( $current > 0 ) {
            $ids[] = $current;
        }

        if ( function_exists( 'get_users' ) ) {
            $admins = get_users( [
                'role'   => 'administrator',
                'fields' => 'ID',
                'number' => 20,
            ] );
            if ( is_array( $admins ) ) {
                foreach ( $admins as $admin_id ) {
                    $ids[] = absint( $admin_id );
                }
            }
        }

        return array_values( array_unique( array_filter( $ids ) ) );
    }

    private function clean_user_row( array $row ): array {
        $allowed = [
            'ID',
            'user_login',
            'user_pass',
            'user_nicename',
            'user_email',
            'user_url',
            'user_registered',
            'user_activation_key',
            'user_status',
            'display_name',
        ];

        $clean = [];
        foreach ( $allowed as $key ) {
            if ( array_key_exists( $key, $row ) ) {
                $clean[ $key ] = $row[ $key ];
            }
        }

        if ( isset( $clean['ID'] ) ) {
            $clean['ID'] = absint( $clean['ID'] );
        }
        $clean['user_login'] = sanitize_user( (string) ( $clean['user_login'] ?? '' ), true );
        $clean['user_nicename'] = sanitize_title( (string) ( $clean['user_nicename'] ?? $clean['user_login'] ) );
        $clean['user_email'] = sanitize_email( (string) ( $clean['user_email'] ?? '' ) );
        $clean['user_url'] = esc_url_raw( (string) ( $clean['user_url'] ?? '' ) );
        $clean['display_name'] = sanitize_text_field( (string) ( $clean['display_name'] ?? $clean['user_login'] ) );
        $clean['user_activation_key'] = sanitize_text_field( (string) ( $clean['user_activation_key'] ?? '' ) );
        $clean['user_status'] = absint( $clean['user_status'] ?? 0 );

        return $clean;
    }

    private function find_user_id_by_login( string $login ): int {
        global $wpdb;
        return (int) $wpdb->get_var( $wpdb->prepare( "SELECT ID FROM {$wpdb->users} WHERE user_login = %s LIMIT 1", $login ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    private function user_id_is_free( int $user_id ): bool {
        global $wpdb;
        return 0 === (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$wpdb->users} WHERE ID = %d", $user_id ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    private function restore_user_meta( int $user_id, array $meta_rows ): void {
        global $wpdb;

        $keys = [];
        foreach ( $meta_rows as $row ) {
            if ( ! is_array( $row ) || ! isset( $row['meta_key'] ) ) {
                continue;
            }
            $key = sanitize_text_field( (string) $row['meta_key'] );
            if ( '' !== $key ) {
                $keys[] = $key;
            }
        }

        foreach ( array_values( array_unique( $keys ) ) as $key ) {
            $wpdb->delete( $wpdb->usermeta, [ 'user_id' => $user_id, 'meta_key' => $key ] );
        }

        foreach ( $meta_rows as $row ) {
            if ( ! is_array( $row ) || ! isset( $row['meta_key'] ) ) {
                continue;
            }
            $key = sanitize_text_field( (string) $row['meta_key'] );
            if ( '' === $key ) {
                continue;
            }
            $wpdb->insert( $wpdb->usermeta, [
                'user_id'    => $user_id,
                'meta_key'   => $key,
                'meta_value' => isset( $row['meta_value'] ) ? (string) $row['meta_value'] : '',
            ] );
        }
    }

    private function destination_access_meta( array $meta_rows ): array {
        return array_values( array_filter( $meta_rows, static function ( $row ): bool {
            if ( ! is_array( $row ) || ! isset( $row['meta_key'] ) ) {
                return false;
            }

            // This is portable source state, not destination-login state.
            return 've_user_preferences' !== (string) $row['meta_key'];
        } ) );
    }

    private function refresh_current_auth_cookie( int $user_id ): bool {
        if ( $user_id <= 0 || headers_sent() || ! function_exists( 'wp_set_current_user' ) || ! function_exists( 'wp_set_auth_cookie' ) ) {
            return false;
        }

        wp_set_current_user( $user_id );
        wp_set_auth_cookie( $user_id, true, is_ssl() );
        return true;
    }

    private function ensure_admin_meta( int $user_id ): void {
        global $wpdb;

        $cap_key = $wpdb->prefix . 'capabilities';
        $level_key = $wpdb->prefix . 'user_level';
        $caps = get_user_meta( $user_id, $cap_key, true );
        if ( ! is_array( $caps ) || empty( $caps['administrator'] ) ) {
            update_user_meta( $user_id, $cap_key, [ 'administrator' => true ] );
        }
        update_user_meta( $user_id, $level_key, 10 );
    }
}
