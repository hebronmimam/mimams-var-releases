<?php

namespace VE\Modules\Recovery\Restore;

use VE\Core\SettingsTransferManager;

defined( 'ABSPATH' ) || exit;

/**
 * Carries secret-safe MV settings independently of WordPress user IDs.
 */
final class MVSettingsPortability {
    private const GROUPS = [ 'mv_core', 'mv_modules', 'mv_bar', 'mv_studio' ];

    public function capture( int $source_user_id = 0 ): array {
        $source_user_id = $source_user_id > 0 ? $source_user_id : $this->source_user_id();
        $bundle = ( new SettingsTransferManager() )->export_bundle( self::GROUPS, $source_user_id );

        return [
            'ok'             => true,
            'source_user_id' => $source_user_id,
            'groups'         => self::GROUPS,
            'bundle'         => $bundle,
        ];
    }

    public function apply_from_manifest( array $manifest, int $target_user_id = 0 ): array {
        $transfer = $manifest['restore_safety']['config_transfer']['mv_settings'] ?? [];
        $bundle = is_array( $transfer ) && isset( $transfer['bundle'] ) && is_array( $transfer['bundle'] )
            ? $transfer['bundle']
            : [];

        if ( [] === $bundle ) {
            return [
                'ok'      => true,
                'applied' => false,
                'legacy'  => true,
                'message' => 'This package predates portable MV settings; database-restored MV data was left unchanged.',
            ];
        }

        $groups = isset( $transfer['groups'] ) && is_array( $transfer['groups'] )
            ? array_values( array_intersect( self::GROUPS, $transfer['groups'] ) )
            : self::GROUPS;
        $target_user_id = $target_user_id > 0 ? $target_user_id : get_current_user_id();
        if ( $target_user_id <= 0 ) {
            $groups = array_values( array_intersect( $groups, [ 'mv_core', 'mv_modules' ] ) );
        }

        $manager = new SettingsTransferManager();
        $preview = $manager->preview_bundle( $bundle, $groups );
        if ( is_wp_error( $preview ) ) {
            return [ 'ok' => false, 'applied' => false, 'message' => $preview->get_error_message() ];
        }

        $result = $manager->apply_bundle( $bundle, $groups, (string) $preview['fingerprint'], $target_user_id );
        if ( is_wp_error( $result ) ) {
            return [ 'ok' => false, 'applied' => false, 'message' => $result->get_error_message() ];
        }

        return [
            'ok'             => true,
            'applied'        => true,
            'target_user_id' => $target_user_id,
            'groups'         => $groups,
            'result'         => $result,
            'message'        => 'MV core, module, Bar, and Studio settings were restored.',
        ];
    }

    private function source_user_id(): int {
        $current = get_current_user_id();
        if ( $current > 0 ) {
            return $current;
        }
        if ( ! function_exists( 'get_users' ) ) {
            return 0;
        }

        $admins = get_users( [ 'role' => 'administrator', 'fields' => 'ID', 'number' => 1 ] );
        return is_array( $admins ) && isset( $admins[0] ) ? absint( $admins[0] ) : 0;
    }
}
