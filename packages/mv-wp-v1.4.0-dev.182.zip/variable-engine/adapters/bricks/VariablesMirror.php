<?php

namespace VE\Adapters\Bricks;

use VE\Core\VariableManager;

defined( 'ABSPATH' ) || exit;

class VariablesMirror {

    private const CATEGORY_ID = 'mimams-var';
    private const ID_PREFIX   = 'mv-';
    /** R47: where a variable made in Bricks lands in MV. */
    private const FROM_BRICKS = 'From Bricks';

    /* R47, 2026-09-23 - "a clean 2 way sync", and on a clash "the newer change
       wins and you're told". The owner's words.

       It went one way: every MV save rewrote MV's copies in Bricks, so a
       variable changed in Bricks' own panel was put back by the next MV save.
       Two-way needs one fact the mirror never kept - the value both sides last
       AGREED on. Bricks' Save sends every variable it holds, including copies
       loaded before an MV edit, so "Bricks has a different value" means nothing
       by itself: equal to the agreed value is a stale copy, anything else is an
       edit made in Bricks.

       R47, 2026-09-24 - "I want a complete total sync between mv and bricks."
       So a variable made in Bricks comes into MV (under From Bricks), and a
       rename or a delete in either reaches the other.
       - A Bricks entry keeps its own id and category. Advanced Themer and the
         owner's own Bricks categories are left as they were; MV remembers which
         of its variables each entry is (`mv` in the agreed record).
       - One CSS name is one variable: a Bricks entry named like an MV variable
         IS that variable. 78 of the 87 Bricks-only entries on the owner's site
         were already MV variables of the same name, all but one equal.
       - A delete in Bricks is read from Bricks' own trash, never from absence:
         the builder's Save sends whatever it loaded, so a variable made in MV
         after the builder opened is missing from it without being deleted.
         Bricks 2.4 writes the trash before the variables (ajax.php), so it is
         current when MV hears the save. */
    public const BASE_OPTION    = 've_bricks_mirror_base';
    public const NOTICES_OPTION = 've_bricks_sync_notices';
    private const NOTICES_KEEP  = 30;
    /** How many earlier agreed values are remembered per variable, to recognise a stale copy. */
    private const HISTORY_KEEP  = 12;
    /** How many deleted variables are remembered, so a stale copy of one is not brought back. */
    private const GONE_KEEP     = 200;

    /** @var bool Set while this class writes Bricks' option, so its own write is not read back as a Bricks edit. */
    private static $writing = false;
    /** @var bool Set while pulling Bricks' values into MV, so the export that follows cannot start another pull. */
    private static $pulling = false;

    public static function register(): void {
        add_action( 'update_option_bricks_global_variables', [ self::class, 'on_bricks_saved' ], 10, 2 );
    }

    public function sync( ?array $variables = null ): bool {
        if ( ! $this->bricks_available() ) {
            return true;
        }

        if ( null === $variables ) {
            $variables = ( new VariableManager() )->get_all();
        }

        $current = get_option( 'bricks_global_variables', [] );
        $current = is_array( $current ) ? $current : [];

        /* R47, MV's side. MV is writing now, so on a clash MV's value is the
           newer one - but a variable changed or made only in Bricks (say while
           MV was switched off) is brought in first rather than written over. */
        if ( ! self::$pulling && ! self::in_workspace_session() ) {
            $plan = self::reconcile( $current, self::with_css_names( $variables ), self::raw_values(), self::base(), 'mv', [], [ self::class, 'framework_owned' ] );
            if ( $plan['pulls'] || $plan['imports'] || $plan['renames'] ) {
                self::apply_plan( $plan );
                // The CSS file and this mirror are rebuilt from what came in.
                return ( new \VE\Core\CssExporter() )->export();
            }
            self::add_notices( $plan['notices'] );
        }

        $merged  = self::merge_variables( $current, $variables, self::base() );

        /* §112, and slice 7 does not ship without this.

           This mirror writes `bricks_global_variables` straight through the
           option API, which is how it bypasses the builder - and it is also why
           WorkspaceRuntime's `pre_update_option_*` catches it: a sync during a
           workspace session is held and put in the workspace rather than on the
           site. That part needs no change here.

           What DOES need changing is how the answer is read. Holding the write
           makes core's own equality check return false, and this line treated a
           false from update_option() as a failure - so a sync inside a workspace
           would have reported "the mirror is broken" while doing exactly the
           right thing. Under a session, false is success. */
        self::$writing = true;
        $wrote = $merged === $current || update_option( 'bricks_global_variables', $merged, false );
        self::$writing = false;
        if ( ! $wrote ) {
            if ( ! self::in_workspace_session() ) {
                return false;
            }
        }
        if ( ! self::in_workspace_session() ) {
            self::remember_base( $merged, $variables );
        }

        $categories = get_option( 'bricks_global_variables_categories', [] );
        $categories = is_array( $categories ) ? $categories : [];
        $has_category = false;
        foreach ( $categories as $category ) {
            if ( is_array( $category ) && ( $category['id'] ?? '' ) === self::CATEGORY_ID ) {
                $has_category = true;
                break;
            }
        }
        if ( ! $has_category ) {
            $categories[] = [
                'id'   => self::CATEGORY_ID,
                'name' => "Mimam's Var",
            ];
            if ( ! update_option( 'bricks_global_variables_categories', array_values( $categories ), false ) ) {
                /* Slice 9 changed the answer here, and left the previous one in
                   view because the change is the interesting part.

                   Under slice 7 the categories option was NOT overlaid, so a
                   false was a real failure and this returned false. Slice 9
                   overlays it along with every other global the builder's Save
                   writes - so under a session a false now means the same thing
                   it means on the line above: held, filed into the workspace,
                   nothing wrong. Judging the two lines differently would now be
                   the bug rather than the care. */
                if ( ! self::in_workspace_session() ) {
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Bricks' variables with MV's written in.
     *
     * An entry that is one of MV's variables keeps its id, category and any
     * other field, and takes MV's name and value. A variable Bricks does not
     * hold yet is added as `mv-<id>` in Mimam's Var. An entry of a variable MV
     * deleted is dropped. A variable a framework plugin owns in Bricks (Core
     * Framework, Automatic.css) keeps its entry, and MV's same-named copy is
     * not mirrored - that plugin writes it.
     */
    public static function merge_variables( array $current, array $variables, array $base = [] ): array {
        $vars  = self::with_css_names( $variables );
        $plan  = self::resolve( $current, $vars, $base, [ self::class, 'framework_owned' ] );
        $by_id = [];
        foreach ( $vars as $v ) {
            if ( is_array( $v ) && ! empty( $v['id'] ) && '' !== $v['css'] ) {
                $by_id[ (int) $v['id'] ] = $v;
            }
        }

        $out        = [];
        $written    = [];
        $held_names = [];
        foreach ( $current as $entry ) {
            if ( ! is_array( $entry ) ) {
                continue;
            }
            $bid = (string) ( $entry['id'] ?? '' );
            if ( isset( $plan['drop'][ $bid ] ) ) {
                continue;
            }
            if ( isset( $plan['links'][ $bid ] ) ) {
                $v = $by_id[ $plan['links'][ $bid ] ] ?? null;
                if ( ! $v ) {
                    continue;
                }
                $entry['name']  = $v['css'];
                $entry['value'] = self::mv_value( $v );
                $out[]          = $entry;
                $written[ (int) $v['id'] ] = true;
                continue;
            }
            $name = ltrim( (string) ( $entry['name'] ?? '' ), '-' );
            if ( '' !== $name ) {
                $held_names[ $name ] = true;
            }
            $out[] = $entry;
        }

        $added = [];
        foreach ( $by_id as $id => $v ) {
            if ( isset( $written[ $id ] ) || isset( $held_names[ $v['css'] ] ) ) {
                continue;
            }
            /* A variable Bricks does not hold. If it was linked to an entry
               before (a refused delete puts it back), that entry comes back
               under its own id and category. */
            $bid = self::ID_PREFIX . $id;
            $cat = self::CATEGORY_ID;
            foreach ( $base as $key => $rec ) {
                if ( is_array( $rec ) && empty( $rec['gone'] ) && (int) ( $rec['mv'] ?? 0 ) === $id ) {
                    $bid = (string) $key;
                    $cat = (string) ( $rec['c'] ?? '' ) ?: self::CATEGORY_ID;
                    break;
                }
            }
            $added[] = [
                'id'       => $bid,
                'name'     => $v['css'],
                'value'    => self::mv_value( $v ),
                'category' => $cat,
            ];
        }

        usort( $added, static function ( array $a, array $b ): int {
            return strnatcasecmp( $a['name'], $b['name'] );
        } );

        return array_values( array_merge( $out, $added ) );
    }

    /**
     * Which of MV's variables each Bricks entry is. Pure.
     *
     * @param array         $bricks Bricks' variables.
     * @param array         $vars   MV's variables, each with `css` (its CSS name, no leading dashes).
     * @param array         $base   Bricks id => what both sides last agreed on.
     * @param callable|null $owned  Whether a framework plugin owns an entry.
     * @return array{links:array<string,int>,drop:array<string,bool>,imports:array}
     */
    public static function resolve( array $bricks, array $vars, array $base, ?callable $owned = null ): array {
        $ids = [];
        $css = [];
        foreach ( $vars as $v ) {
            if ( ! is_array( $v ) || empty( $v['id'] ) ) {
                continue;
            }
            $ids[ (int) $v['id'] ] = true;
            $name = (string) ( $v['css'] ?? '' );
            if ( '' !== $name && ! isset( $css[ $name ] ) ) {
                $css[ $name ] = (int) $v['id'];
            }
        }
        $out     = [ 'links' => [], 'drop' => [], 'imports' => [] ];
        $claimed = [];
        foreach ( $bricks as $b ) {
            if ( ! is_array( $b ) ) {
                continue;
            }
            $bid  = (string) ( $b['id'] ?? '' );
            $name = ltrim( (string) ( $b['name'] ?? '' ), '-' );
            $rec  = $base[ $bid ] ?? null;
            /* Deleted in Bricks and now back: restored from Bricks' trash, so
               it comes into MV again. */
            $restored = is_array( $rec ) && ! empty( $rec['gone'] ) && 'bricks' === ( $rec['by'] ?? '' );
            if ( is_array( $rec ) && ! empty( $rec['gone'] ) && ! $restored ) {
                // Deleted in MV: a builder that loaded before the delete sends it back.
                $out['drop'][ $bid ] = true;
                continue;
            }
            if ( is_array( $rec ) && isset( $rec['mv'] ) && ! isset( $ids[ (int) $rec['mv'] ] ) && ! $restored ) {
                // Linked to a variable MV has since deleted: this is its leftover.
                $out['drop'][ $bid ] = true;
                continue;
            }
            $id = null;
            if ( is_array( $rec ) && isset( $rec['mv'], $ids[ (int) $rec['mv'] ] ) ) {
                $id = (int) $rec['mv'];
            } elseif ( 0 === strpos( $bid, self::ID_PREFIX ) && isset( $ids[ (int) substr( $bid, strlen( self::ID_PREFIX ) ) ] ) ) {
                $id = (int) substr( $bid, strlen( self::ID_PREFIX ) );
            } elseif ( '' !== $name && isset( $css[ $name ] ) && ! ( $owned && $owned( $b ) ) ) {
                $id = $css[ $name ];
            }
            if ( null !== $id ) {
                if ( isset( $claimed[ $id ] ) ) {
                    $out['drop'][ $bid ] = true;      // a second entry for one variable
                } else {
                    $claimed[ $id ]       = true;
                    $out['links'][ $bid ] = $id;
                }
                continue;
            }
            if ( 0 === strpos( $bid, self::ID_PREFIX ) && ! $restored ) {
                $out['drop'][ $bid ] = true;          // MV's copy of a variable MV no longer has
                continue;
            }
            if ( '' === $name || ( $owned && $owned( $b ) ) ) {
                continue;
            }
            $out['imports'][] = $b;
        }
        return $out;
    }

    /**
     * R47, Bricks' side: Bricks has just saved its variables.
     *
     * Bricks is writing now, so on a clash its value is the newer one. A copy
     * that is merely stale - equal to what both last agreed on - is not an
     * edit, and MV's newer value is put back.
     *
     * @param mixed $old
     * @param mixed $new
     */
    public static function on_bricks_saved( $old, $new ): void {
        if ( self::$writing || self::$pulling || ! is_array( $new ) || self::in_workspace_session() ) {
            return;
        }
        $vars  = ( new \VE\Core\ThemeManager() )->apply_to_variables( ( new VariableManager() )->get_all() );
        $trash = get_option( 'bricks_global_variables_trash', [] );
        $plan  = self::reconcile( $new, self::with_css_names( $vars ), self::raw_values(), self::base(), 'bricks', is_array( $trash ) ? $trash : [], [ self::class, 'framework_owned' ] );
        $changed = self::apply_plan( $plan );
        if ( $changed || $plan['restores'] || $plan['drops'] ) {
            // Rebuilds variables.css from MV, and writes MV's values back over any stale copy - or takes it out.
            ( new \VE\Core\CssExporter() )->export();
        } else {
            self::remember_base( $new, $vars );
        }
    }

    /**
     * What to do with each of MV's copies in Bricks. Pure, so a guard can walk
     * every case.
     *
     * @param array         $bricks Bricks' variables.
     * @param array         $vars   MV's variables as the mirror writes them (themes applied), each with `css`.
     * @param array         $raw    id => the value typed into MV, before any theme or formula.
     * @param array         $base   Bricks id => the value (and name) both sides last agreed on.
     * @param string        $side   Who is writing now, and so whose change is newer: 'bricks' or 'mv'.
     * @param array         $trash  Bricks' variables trash: what was deleted in Bricks.
     * @param callable|null $owned  Whether a framework plugin owns an entry.
     * @return array{pulls:array<int,string>,restores:array<int,bool>,notices:array,imports:array,renames:array<int,string>,deletes:array<int,string>,links:array<string,int>,drops:array<string,bool>}
     */
    public static function reconcile( array $bricks, array $vars, array $raw, array $base, string $side, array $trash = [], ?callable $owned = null ): array {
        $mirrored = [];
        $names    = [];
        $css      = [];
        foreach ( $vars as $v ) {
            if ( ! is_array( $v ) || empty( $v['id'] ) ) {
                continue;
            }
            $mirrored[ (int) $v['id'] ] = (string) ( ( $v['css_value'] ?? '' ) !== '' ? $v['css_value'] : ( $v['value'] ?? '' ) );
            $names[ (int) $v['id'] ]    = (string) ( $v['name'] ?? '' );
            $css[ (int) $v['id'] ]      = (string) ( $v['css'] ?? '' );
        }
        $map = self::resolve( $bricks, $vars, $base, $owned );
        $out = [ 'pulls' => [], 'restores' => [], 'notices' => [], 'imports' => [], 'renames' => [], 'deletes' => [], 'links' => $map['links'], 'drops' => $map['drop'] ];
        $active = [];
        foreach ( $bricks as $b ) {
            if ( ! is_array( $b ) ) {
                continue;
            }
            $bid = (string) ( $b['id'] ?? '' );
            $active[ $bid ] = true;
            if ( ! isset( $map['links'][ $bid ] ) ) {
                continue;
            }
            $id    = $map['links'][ $bid ];
            $entry = $base[ $bid ] ?? null;

            /* The name. Bricks renames an entry in place (same id), and rewrites
               every var(--old) on the site to the new name as it saves - so MV
               has to follow, or its variable stops matching the pages. */
            $bn = ltrim( (string) ( $b['name'] ?? '' ), '-' );
            $mn = $css[ $id ];
            if ( '' !== $bn && '' !== $mn && $bn !== $mn ) {
                $agreed_n  = is_array( $entry ) && isset( $entry['n'] ) ? (string) $entry['n'] : null;
                $earlier_n = is_array( $entry ) ? array_map( 'strval', (array) ( $entry['nh'] ?? [] ) ) : [];
                if ( null === $agreed_n || $bn === $agreed_n || in_array( $bn, $earlier_n, true ) ) {
                    $out['restores'][ $id ] = true;                   // a stale name
                } elseif ( $mn !== $agreed_n && 'mv' === $side ) {
                    $out['restores'][ $id ] = true;
                    $out['notices'][] = [ 'name' => $names[ $id ], 'reason' => 'renamed-both', 'kept' => 'mv', 'mv_value' => $mn, 'bricks_value' => $bn ];
                } else {
                    $out['renames'][ $id ] = $bn;
                }
            }

            $bv = (string) ( $b['value'] ?? '' );
            $mv = $mirrored[ $id ];
            if ( $bv === $mv ) {
                continue;
            }
            $agreed  = is_array( $entry ) ? ( isset( $entry['v'] ) ? (string) $entry['v'] : null ) : ( null === $entry ? null : (string) $entry );
            $earlier = is_array( $entry ) ? array_map( 'strval', (array) ( $entry['h'] ?? [] ) ) : [];
            if ( null === $agreed ) {
                // Never agreed on anything: nothing to tell an edit from a stale copy by.
                if ( 'bricks' === $side ) {
                    $out['restores'][ $id ] = true;
                }
                if ( 0 !== strpos( $bid, self::ID_PREFIX ) ) {
                    // An entry of Bricks' own, joined to MV's variable of the same name for the first time.
                    $out['restores'][ $id ] = true;
                    $out['notices'][] = [ 'name' => $names[ $id ], 'mv_value' => $mv, 'bricks_value' => $bv, 'kept' => 'mv', 'reason' => 'linked' ];
                }
                continue;
            }
            /* A stale copy is ANY value the two once agreed on, not only the
               latest. The builder can be holding a value from two MV edits ago;
               checking only the newest agreement read that copy as a Bricks edit
               and put the old value back over MV's newer one. (A value typed in
               Bricks that happens to equal an earlier one reads as stale too -
               the one case this cannot tell apart, and MV's newer value stands.) */
            if ( $bv === $agreed || in_array( $bv, $earlier, true ) ) {
                $out['restores'][ $id ] = true;
                continue;
            }
            // Changed in Bricks.
            $both     = $mv !== $agreed;
            $pullable = isset( $raw[ $id ] ) && (string) $raw[ $id ] === $mv;
            $notice   = [ 'name' => $names[ $id ], 'mv_value' => $mv, 'bricks_value' => $bv ];
            if ( ! $pullable ) {
                // MV works this value out (a theme, a generator, a formula); a typed value cannot flow back.
                $out['restores'][ $id ] = true;
                $out['notices'][] = $notice + [ 'kept' => 'mv', 'reason' => 'worked-out' ];
                continue;
            }
            if ( $both && 'mv' === $side ) {
                $out['restores'][ $id ] = true;
                $out['notices'][] = $notice + [ 'kept' => 'mv', 'reason' => 'both' ];
                continue;
            }
            $out['pulls'][ $id ] = $bv;
            if ( $both ) {
                $out['notices'][] = $notice + [ 'kept' => 'bricks', 'reason' => 'both' ];
            }
        }

        // Made in Bricks: comes into MV.
        $out['imports'] = $map['imports'];

        /* Deleted in Bricks: gone from its list AND in its trash. Only on Bricks'
           save - it is the one that deleted. */
        if ( 'bricks' === $side ) {
            $trashed = [];
            foreach ( $trash as $t ) {
                if ( is_array( $t ) && isset( $t['id'] ) ) {
                    $trashed[ (string) $t['id'] ] = true;
                }
            }
            $linked = array_flip( $map['links'] );
            foreach ( $base as $bid => $rec ) {
                $bid = (string) $bid;
                if ( isset( $active[ $bid ] ) || ! isset( $trashed[ $bid ] ) || ( is_array( $rec ) && ! empty( $rec['gone'] ) ) ) {
                    continue;
                }
                $id = is_array( $rec ) && isset( $rec['mv'] ) ? (int) $rec['mv']
                    : ( 0 === strpos( $bid, self::ID_PREFIX ) ? (int) substr( $bid, strlen( self::ID_PREFIX ) ) : 0 );
                if ( $id && isset( $mirrored[ $id ] ) && ! isset( $linked[ $id ] ) ) {
                    $out['deletes'][ $id ] = $bid;
                }
            }
        }
        return $out;
    }

    /**
     * Carry out what reconcile() decided, all inside one pull so the exports it
     * causes cannot start another. Returns whether MV changed.
     */
    private static function apply_plan( array $plan ): bool {
        $manager = new VariableManager();
        $base    = self::base();
        $notices = $plan['notices'];
        $changed = false;
        self::$pulling = true;

        foreach ( $plan['deletes'] as $id => $bid ) {
            $var = $manager->get( (int) $id );
            if ( ! $var ) {
                continue;
            }
            $res = $manager->delete( (int) $id, false, true );
            if ( is_wp_error( $res ) && 've_has_dependents' === $res->get_error_code() ) {
                /* A family's base deleted in Bricks with its shades still there:
                   deleting it in MV takes the shades with it. Only when every
                   one of them went in Bricks too. */
                $deps    = (array) ( ( $res->get_error_data()['dependents'] ?? [] ) );
                $staying = array_filter( $deps, static function ( $d ) use ( $plan ): bool {
                    return ! isset( $plan['deletes'][ (int) ( $d['id'] ?? 0 ) ] );
                } );
                if ( $staying ) {
                    $notices[] = [ 'name' => $var['name'], 'reason' => 'delete-kept', 'kept' => 'mv',
                        'dependents' => array_values( array_map( static function ( $d ) { return (string) ( $d['name'] ?? '' ); }, array_slice( $staying, 0, 5 ) ) ) ];
                    continue;
                }
                $res = $manager->delete( (int) $id, true, true );
            }
            if ( is_wp_error( $res ) ) {
                $notices[] = [ 'name' => $var['name'], 'reason' => 'delete-kept', 'kept' => 'mv', 'why' => $res->get_error_message() ];
                continue;
            }
            $base[ $bid ] = [ 'gone' => 1, 'by' => 'bricks', 'mv' => (int) $id, 'at' => time() ];
            $notices[]    = [ 'name' => $var['name'], 'reason' => 'deleted', 'kept' => 'bricks' ];
            $changed      = true;
        }
        // A family's shades went with its base; they were deleted in Bricks too.
        foreach ( $plan['deletes'] as $id => $bid ) {
            if ( empty( $base[ $bid ]['gone'] ) && ! $manager->get( (int) $id ) ) {
                $base[ $bid ] = [ 'gone' => 1, 'by' => 'bricks', 'mv' => (int) $id, 'at' => time() ];
            }
        }

        foreach ( $plan['renames'] as $id => $css_name ) {
            $var = $manager->get( (int) $id );
            if ( ! $var ) {
                continue;
            }
            $to  = self::mv_name_for( (string) $var['name'], (string) $css_name, $manager );
            $res = $to ? $manager->update( (int) $id, [ 'name' => $to ], true ) : new \WP_Error( 've_invalid_name', 'MV names use lowercase letters, numbers and hyphens.' );
            if ( is_wp_error( $res ) ) {
                $notices[] = [ 'name' => $var['name'], 'reason' => 'rename-kept', 'kept' => 'mv', 'bricks_value' => $css_name, 'why' => $res->get_error_message() ];
                continue;
            }
            $notices[] = [ 'name' => $var['name'], 'reason' => 'renamed', 'kept' => 'bricks', 'bricks_value' => $css_name ];
            $changed   = true;
        }

        if ( $plan['imports'] ) {
            $cat = ( new \VE\Core\VariableCategoryManager() )->get_or_create( self::FROM_BRICKS );
            $slug = is_array( $cat ) ? (string) ( $cat['slug'] ?? '' ) : '';
            foreach ( $plan['imports'] as $b ) {
                $bid   = (string) ( $b['id'] ?? '' );
                $name  = ltrim( (string) ( $b['name'] ?? '' ), '-' );
                $value = (string) ( $b['value'] ?? '' );
                /* MV writes its own value back to Bricks, so a value MV would
                   store differently (a bare number it turns into rem, say) would
                   change the site. That one stays in Bricks only, and you are told. */
                $normal = VariableManager::normalize_name( $name );
                if ( $normal !== $name || $manager->normalize_value_for_name( $name, $value ) !== $value || sanitize_text_field( $value ) !== $value ) {
                    $notices[] = [ 'name' => $name, 'reason' => 'not-imported', 'bricks_value' => $value ];
                    continue;
                }
                $made = $manager->create( [ 'name' => $name, 'value' => $value, 'category_slug' => $slug, 'origin' => 'bricks' ], true );
                if ( is_wp_error( $made ) ) {
                    $notices[] = [ 'name' => $name, 'reason' => 'not-imported', 'bricks_value' => $value, 'why' => $made->get_error_message() ];
                    continue;
                }
                $base[ $bid ] = [ 'v' => $value, 'h' => [], 'n' => $name, 'nh' => [], 'mv' => (int) $made['id'], 'c' => (string) ( $b['category'] ?? '' ) ];
                $notices[]    = [ 'name' => $name, 'reason' => 'imported', 'kept' => 'bricks', 'bricks_value' => $value ];
                $changed      = true;
            }
        }

        foreach ( $plan['pulls'] as $id => $value ) {
            $manager->update( (int) $id, [ 'value' => (string) $value ], true );
            $changed = true;
        }

        self::$pulling = false;
        self::save_base( $base );
        self::add_notices( $notices );
        return $changed;
    }

    /**
     * MV's name for a variable Bricks renamed. MV keeps a dot where its name
     * had one (`color.primary` -> `color.brand`), so its namespace, and the
     * category it sits in, stay the same.
     */
    private static function mv_name_for( string $old, string $css, VariableManager $manager ): string {
        $parts   = array_values( array_filter( explode( '.', $old ), static fn( $p ) => '' !== $p ) );
        $wrapper = '';
        if ( count( $parts ) > 1 && in_array( $parts[0], [ 'size', 'font', 'typography' ], true ) ) {
            $wrapper = array_shift( $parts ) . '.';
        }
        $tries = [];
        if ( count( $parts ) > 1 && 0 === strpos( $css, $parts[0] . '-' ) ) {
            $tries[] = $wrapper . $parts[0] . '.' . substr( $css, strlen( $parts[0] ) + 1 );
        }
        if ( '' !== $wrapper ) {
            $tries[] = $wrapper . $css;
        }
        $tries[] = $css;
        foreach ( $tries as $try ) {
            if ( preg_match( VariableManager::NAME_PATTERN, $try ) && $manager->to_css_name( $try ) === '--' . $css ) {
                return $try;
            }
        }
        return '';
    }

    /**
     * Whether a framework plugin writes this entry into Bricks itself (Core
     * Framework, Automatic.css) - the same test the migration scanner uses.
     * Those stay theirs: not brought in, not taken over by name.
     */
    public static function framework_owned( array $entry ): bool {
        static $names = null;
        static $core = null;
        static $acss = null;
        if ( null === $names ) {
            $names = [];
            $cats  = function_exists( 'get_option' ) ? get_option( 'bricks_global_variables_categories', [] ) : [];
            foreach ( is_array( $cats ) ? $cats : [] as $c ) {
                if ( is_array( $c ) && isset( $c['id'] ) ) {
                    $names[ (string) $c['id'] ] = (string) ( $c['name'] ?? '' );
                }
            }
            $core = false;
            foreach ( function_exists( 'get_option' ) ? (array) get_option( 'active_plugins', [] ) : [] as $p ) {
                if ( is_string( $p ) && preg_match( '/core[-_]?framework/i', $p ) ) {
                    $core = true;
                }
            }
            $acss = function_exists( 'get_option' ) && (bool) get_option( 'automatic_css_settings', false );
        }
        $cat   = strtolower( (string) ( $entry['category'] ?? '' ) );
        $owner = $cat . ' ' . strtolower( $names[ (string) ( $entry['category'] ?? '' ) ] ?? '' );
        if ( $core && ( false !== strpos( $owner, 'core-framework' ) || false !== strpos( $owner, 'core framework' ) ) ) {
            return true;
        }
        return $acss && ( false !== strpos( $owner, 'automatic.css' ) || false !== strpos( $owner, 'automatic css' )
            || 1 === preg_match( '/(?:^|[\s_-])acss(?:$|[\s_-])/', $owner ) );
    }

    /** MV's variables with their CSS names, which is how Bricks knows them. */
    private static function with_css_names( array $vars ): array {
        $manager = new VariableManager();
        foreach ( $vars as $i => $v ) {
            if ( is_array( $v ) ) {
                $vars[ $i ]['css'] = empty( $v['name'] ) ? '' : ltrim( $manager->to_css_name( (string) $v['name'] ), '-' );
            }
        }
        return $vars;
    }

    private static function mv_value( array $v ): string {
        return (string) ( $v['css_value'] ?? $v['value'] ?? '' );
    }

    /** id => the value typed into MV. */
    private static function raw_values(): array {
        $raw = [];
        foreach ( ( new VariableManager() )->get_all() as $v ) {
            if ( is_array( $v ) && ! empty( $v['id'] ) && 'base' === (string) ( $v['type'] ?? 'base' ) ) {
                $raw[ (int) $v['id'] ] = (string) ( $v['value'] ?? '' );
            }
        }
        return $raw;
    }

    private static function base(): array {
        $b = get_option( self::BASE_OPTION, [] );
        return is_array( $b ) ? $b : [];
    }

    private static function save_base( array $base ): void {
        if ( $base !== self::base() ) {
            update_option( self::BASE_OPTION, $base, false );
        }
    }

    /**
     * What both sides now agree on - value, name, and which MV variable each
     * entry is - and what they agreed on before it. A variable MV deleted is
     * remembered as gone, so a stale copy of it is not brought back.
     */
    private static function remember_base( array $bricks, array $variables ): void {
        $before = self::base();
        $vars   = self::with_css_names( $variables );
        $map    = self::resolve( $bricks, $vars, $before, [ self::class, 'framework_owned' ] );
        $alive  = [];
        foreach ( $vars as $v ) {
            if ( is_array( $v ) && ! empty( $v['id'] ) ) {
                $alive[ (int) $v['id'] ] = true;
            }
        }
        $base = [];
        foreach ( $bricks as $b ) {
            $bid = is_array( $b ) ? (string) ( $b['id'] ?? '' ) : '';
            if ( ! isset( $map['links'][ $bid ] ) ) {
                continue;
            }
            $now  = (string) ( $b['value'] ?? '' );
            $name = ltrim( (string) ( $b['name'] ?? '' ), '-' );
            $old  = $before[ $bid ] ?? null;
            $was  = is_array( $old ) ? ( isset( $old['v'] ) ? (string) $old['v'] : null ) : ( null === $old ? null : (string) $old );
            $h    = is_array( $old ) ? array_values( (array) ( $old['h'] ?? [] ) ) : [];
            if ( null !== $was && $was !== $now ) {
                $h[] = $was;
            }
            $h = array_values( array_diff( array_unique( $h ), [ $now ] ) );
            $was_n = is_array( $old ) && isset( $old['n'] ) ? (string) $old['n'] : null;
            $nh    = is_array( $old ) ? array_values( (array) ( $old['nh'] ?? [] ) ) : [];
            if ( null !== $was_n && $was_n !== $name ) {
                $nh[] = $was_n;
            }
            $nh = array_values( array_diff( array_unique( $nh ), [ $name ] ) );
            $base[ $bid ] = [ 'v' => $now, 'h' => array_slice( $h, -self::HISTORY_KEEP ), 'n' => $name, 'nh' => array_slice( $nh, -self::HISTORY_KEEP ),
                'mv' => $map['links'][ $bid ], 'c' => (string) ( $b['category'] ?? '' ) ];
        }
        $gone = [];
        foreach ( $before as $bid => $rec ) {
            if ( isset( $base[ $bid ] ) ) {
                continue;
            }
            if ( is_array( $rec ) && ! empty( $rec['gone'] ) ) {
                $gone[ $bid ] = $rec;
                continue;
            }
            $id = is_array( $rec ) && isset( $rec['mv'] ) ? (int) $rec['mv']
                : ( 0 === strpos( (string) $bid, self::ID_PREFIX ) ? (int) substr( (string) $bid, strlen( self::ID_PREFIX ) ) : 0 );
            if ( $id && ! isset( $alive[ $id ] ) ) {
                $gone[ $bid ] = [ 'gone' => 1, 'mv' => $id, 'at' => time() ];   // deleted in MV
            }
        }
        uasort( $gone, static function ( $a, $b ): int { return (int) ( $b['at'] ?? 0 ) <=> (int) ( $a['at'] ?? 0 ); } );
        self::save_base( $base + array_slice( $gone, 0, self::GONE_KEEP, true ) );
    }

    private static function add_notices( array $notices ): void {
        if ( ! $notices ) {
            return;
        }
        $list = get_option( self::NOTICES_OPTION, [] );
        $list = is_array( $list ) ? $list : [];
        foreach ( $notices as $n ) {
            $list[] = $n + [ 'at' => time() ];
        }
        update_option( self::NOTICES_OPTION, array_slice( $list, -self::NOTICES_KEEP ), false );
    }

    /**
     * Whether this write is happening inside a workspace session.
     *
     * Asked of the module rather than worked out here: one place decides what a
     * session is, and a second copy of that rule would be the way the two come
     * to disagree. Absent module, absent session - which is also the answer on
     * any site where Workspaces is switched off.
     */
    private static function in_workspace_session(): bool {
        if ( ! class_exists( '\\VE\\Modules\\Workspaces\\WorkspaceRuntime' ) ) {
            return false;
        }
        return \VE\Modules\Workspaces\WorkspaceRuntime::session_id() > 0;
    }

    private function bricks_available(): bool {
        return defined( 'BRICKS_VERSION' )
            || function_exists( 'bricks_is_builder' )
            || false !== get_option( 'bricks_global_variables', false );
    }
}
