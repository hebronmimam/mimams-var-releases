<?php

namespace VE\Modules\Recovery\Backup;

use VE\Modules\Recovery\Database\Schema;
use VE\Modules\Recovery\Jobs\JobRunner;
use VE\Modules\Recovery\Jobs\JobStore;
use VE\Modules\Recovery\Jobs\TaskResponse;
use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class PackageBuilder {
    private JobStore $jobs;

    public function __construct( ?JobStore $jobs = null ) {
        $this->jobs = $jobs ?: new JobStore();
    }

    public function create( string $label = '' ): array {
        $begin = $this->begin( $label );
        if ( empty( $begin['ok'] ) || empty( $begin['job_key'] ) ) {
            return $begin;
        }

        return $this->execute_job( (string) $begin['job_key'] );
    }

    public function begin( string $label = '' ): array {
        $label = $label ? sanitize_text_field( $label ) : 'Backup ' . current_time( 'mysql' );
        $snapshot_key = $this->generate_key();
        $created_by = get_current_user_id();
        $work_dir = LocalStorage::ensure_package_dir( $snapshot_key );
        $tasks = $this->tasks( $snapshot_key, $label, $created_by, $work_dir );
        $job = $this->jobs->create( 'backup_package', $label, $tasks );
        $job_key = isset( $job['job_key'] ) ? (string) $job['job_key'] : '';

        if ( '' === $job_key ) {
            return [ 'ok' => false, 'message' => 'Backup job could not be created.' ];
        }

        $meta = [
            'snapshot_key' => $snapshot_key,
            'label'        => $label,
            'created_by'   => $created_by,
            'work_dir'     => $work_dir,
        ];
        $this->jobs->merge_result( $job_key, [ 'backup_job_meta' => $meta ] );

        return [
            'ok'           => true,
            'message'      => 'Backup job created.',
            'job_key'      => $job_key,
            'snapshot_key' => $snapshot_key,
            'job'          => $this->jobs->get( $job_key ),
        ];
    }

    public function execute_job( string $job_key = '' ): array {
        $job_key = sanitize_text_field( $job_key );
        $job = '' !== $job_key ? $this->jobs->get( $job_key ) : null;
        if ( ! $job ) {
            return [ 'ok' => false, 'message' => 'Backup job not found.' ];
        }
        if ( in_array( (string) ( $job['status'] ?? '' ), [ 'completed', 'failed', 'cancelled' ], true ) ) {
            return [ 'ok' => 'completed' === (string) ( $job['status'] ?? '' ), 'message' => (string) ( $job['message'] ?? 'Backup job already finished.' ), 'job' => $job ];
        }

        $result = isset( $job['result'] ) && is_array( $job['result'] ) ? $job['result'] : [];
        $meta = isset( $result['backup_job_meta'] ) && is_array( $result['backup_job_meta'] ) ? $result['backup_job_meta'] : [];
        if ( empty( $meta['snapshot_key'] ) || empty( $meta['work_dir'] ) ) {
            return [ 'ok' => false, 'message' => 'Backup job metadata is missing.', 'job' => $job ];
        }

        $snapshot_key = sanitize_text_field( (string) $meta['snapshot_key'] );
        $label = sanitize_text_field( (string) ( $meta['label'] ?? 'Backup ' . current_time( 'mysql' ) ) );
        $created_by = absint( $meta['created_by'] ?? get_current_user_id() );
        $work_dir = trailingslashit( (string) $meta['work_dir'] );
        $tasks = $this->tasks( $snapshot_key, $label, $created_by, $work_dir );
        $run = ( new JobRunner( $this->jobs ) )->run( $job_key, $tasks, [
            'snapshot_key'    => $snapshot_key,
            'label'           => $label,
            'created_by'      => $created_by,
            'work_dir'        => $work_dir,
            'backup_job_meta' => $meta,
        ] );

        $finish = isset( $run['context']['finish_package'] ) && is_array( $run['context']['finish_package'] ) ? $run['context']['finish_package'] : [];
        if ( ! empty( $run['deferred'] ) ) {
            return [
                'ok'           => true,
                'deferred'     => true,
                'snapshot_key' => $snapshot_key,
                'label'        => $label,
                'status'       => 'running',
                'message'      => (string) ( $run['message'] ?? 'Backup job still running.' ),
                'job'          => $this->jobs->get( $job_key ),
            ];
        }
        if ( empty( $run['ok'] ) ) {
            Logger::error( 'backup_package_failed', 'Local backup package job failed.', [
                'snapshot_key' => $snapshot_key,
                'job_key'      => $job_key,
                'message'      => (string) ( $run['message'] ?? '' ),
            ] );
            return [
                'id'           => 0,
                'snapshot_key' => $snapshot_key,
                'label'        => $label,
                'status'       => 'failed',
                'job'          => $this->jobs->get( $job_key ),
                'ok'           => false,
                'message'      => (string) ( $run['message'] ?? 'Backup package job failed.' ),
            ];
        }

        $finish['job'] = $this->jobs->get( $job_key );
        $finish['ok'] = true;
        return $finish;
    }

    public function status( string $job_key = '' ): array {
        $job_key = sanitize_text_field( $job_key );
        $job = '' !== $job_key ? $this->jobs->get( $job_key ) : null;
        if ( ! $job ) {
            return [ 'ok' => false, 'message' => 'Backup job not found.' ];
        }
        $response = [ 'ok' => true, 'message' => (string) ( $job['message'] ?? 'Backup status loaded.' ), 'job' => $job ];
        $result = isset( $job['result'] ) && is_array( $job['result'] ) ? $job['result'] : [];
        if ( isset( $result['finish_package'] ) && is_array( $result['finish_package'] ) ) {
            $response = array_merge( $response, $result['finish_package'] );
            $response['job'] = $job;
            $response['ok'] = true;
        }
        return $response;
    }

    public function download_url( string $snapshot_key ): string {
        return add_query_arg(
            [
                'action'       => 'restorebase_download_package',
                'snapshot_key' => $snapshot_key,
                '_wpnonce'     => wp_create_nonce( 'restorebase_download_' . $snapshot_key ),
            ],
            admin_url( 'admin-post.php' )
        );
    }

    private function tasks( string $snapshot_key, string $label, int $created_by, string $work_dir ): array {
        return [
            [
                'id'       => 'requirements_check',
                'label'    => 'Requirements Check',
                'callback' => function ( array $context ) {
                    $warnings = [];
                    if ( ! class_exists( '\ZipArchive' ) ) {
                        return TaskResponse::fail( 'ZipArchive is required to create RestoreBase packages.', [ 'ziparchive' => false ] );
                    }
                    if ( ! is_writable( LocalStorage::packages_dir() ) ) {
                        $warnings[] = 'RestoreBase packages directory is not writable.';
                    }
                    return TaskResponse::ok( 'Requirements checked.', [ 'warnings' => $warnings, 'ziparchive' => true ] );
                },
            ],
            [
                'id'       => 'site_scan',
                'label'    => 'Site Scan',
                'callback' => function ( array $context ) {
                    $scan = ( new SiteScanner() )->scan();
                    return TaskResponse::ok( 'Site scan completed.', $scan );
                },
            ],
            [
                'id'       => 'database_export',
                'label'    => 'Database Export',
                'callback' => function ( array $context ) use ( $work_dir ) {
                    $db_export = ( new DatabaseExporter() )->export( $work_dir . 'database.sql' );
                    return ! empty( $db_export['ok'] ) ? TaskResponse::ok( 'Database exported.', $db_export ) : TaskResponse::fail( (string) ( $db_export['message'] ?? 'Database export failed.' ), $db_export );
                },
            ],
            [
                'id'       => 'file_inventory',
                'label'    => 'File Inventory',
                'callback' => function ( array $context ) use ( $work_dir ) {
                    $inventory = ( new FileInventory( 100000 ) )->scan();
                    $write = LocalStorage::write_json_file( $work_dir . 'file-inventory.json', $inventory, 'File inventory' );
                    // PERF: never put the full file list in the job context — JobRunner
                    // persists the whole context to result_json, and JobStore::get()
                    // json_decodes it. With 15k+ files that turns every job read into a
                    // multi-MB decode. Keep only the summary; the list lives on disk.
                    $data = [
                        'summary' => isset( $inventory['summary'] ) && is_array( $inventory['summary'] ) ? $inventory['summary'] : [],
                        'write'   => $write,
                        'path'    => $work_dir . 'file-inventory.json',
                    ];
                    return ! empty( $write['ok'] ) ? TaskResponse::ok( 'File inventory written.', $data ) : TaskResponse::fail( (string) ( $write['message'] ?? 'File inventory write failed.' ), $data );
                },
            ],
            [
                'id'       => 'file_archive',
                'label'    => 'File Archive',
                'callback' => function ( array $context ) use ( $work_dir ) {
                    // Read the file list from disk rather than the job context (see file_inventory).
                    $inventory = $this->read_inventory( (string) ( $context['file_inventory']['path'] ?? ( $work_dir . 'file-inventory.json' ) ) );
                    $job_key = isset( $context['job_key'] ) ? (string) $context['job_key'] : '';
                    $task_index = isset( $context['_current_task_index'] ) ? (int) $context['_current_task_index'] : 0;
                    $store = $this->jobs;
                    $progress = function ( string $message, float $within, array $data = [] ) use ( $store, $job_key, $task_index ) {
                        if ( '' === $job_key ) { return; }
                        $data['_task_progress'] = $within;
                        $store->update_task( $job_key, $task_index, 'file_archive', 'running', $message, $data );
                    };
                    // PERF: this runs once per file. A full job read here cost ~50ms/file.
                    // Use a scalar status query, throttled to at most once every 2s.
                    $cancel_checked_at = 0.0;
                    $cancelled = false;
                    $should_cancel = function () use ( $store, $job_key, &$cancel_checked_at, &$cancelled ): bool {
                        if ( '' === $job_key || $cancelled ) { return $cancelled; }
                        $now = microtime( true );
                        if ( $now - $cancel_checked_at < 2.0 ) { return false; }
                        $cancel_checked_at = $now;
                        $cancelled = 'cancelled' === $store->status( $job_key );
                        return $cancelled;
                    };
                    $previous = isset( $context['file_archive'] ) && is_array( $context['file_archive'] ) ? $context['file_archive'] : [];
                    $state = isset( $previous['state'] ) && is_array( $previous['state'] ) ? $previous['state'] : [];
                    $archive = ( new FileBundleArchiver( 100000, 5368709120, 536870912 ) )->archive( $work_dir . 'files.restorebase', $inventory, $progress, $should_cancel, $state );
                    if ( ! empty( $archive['cancelled'] ) ) {
                        return TaskResponse::fail( 'Backup cancelled while creating files archive.', $archive );
                    }
                    if ( ! empty( $archive['deferred'] ) ) {
                        return TaskResponse::defer( (string) ( $archive['message'] ?? 'Files archive still running.' ), $archive );
                    }
                    return ! empty( $archive['ok'] ) ? TaskResponse::ok( 'Files archive created.', $archive ) : TaskResponse::fail( (string) ( $archive['message'] ?? 'Files archive failed.' ), $archive );
                },
            ],
            [
                'id'       => 'manifest_build',
                'label'    => 'Manifest Build',
                'callback' => function ( array $context ) use ( $snapshot_key, $label, $created_by, $work_dir ) {
                    $db_export = isset( $context['database_export'] ) && is_array( $context['database_export'] ) ? $context['database_export'] : [];
                    $inventory_write = isset( $context['file_inventory']['write'] ) && is_array( $context['file_inventory']['write'] ) ? $context['file_inventory']['write'] : [];
                    $inventory = $this->inventory_summary( $context );
                    $files_archive = isset( $context['file_archive'] ) && is_array( $context['file_archive'] ) ? $context['file_archive'] : [];
                    $files_archive_relative = isset( $files_archive['relative_path'] ) ? (string) $files_archive['relative_path'] : 'files.restorebase';

                    $snapshot = [
                        'snapshot_key' => $snapshot_key,
                        'label'        => $label,
                        'trigger_type' => 'backup_package',
                        'created_by'   => $created_by,
                    ];

                    $manifest = ( new ManifestBuilder() )->build( $snapshot, [
                        'contains_database_dump'  => ! empty( $db_export['ok'] ),
                        'contains_files_archive'  => ! empty( $files_archive['ok'] ),
                        'contains_file_inventory' => ! empty( $inventory_write['ok'] ),
                        'database_dump'           => [
                            'relative_path' => 'database.sql',
                            'method'        => (string) ( $db_export['method'] ?? 'php' ),
                            'hash'          => (string) ( $db_export['hash'] ?? '' ),
                            'size'          => (int) ( $db_export['size'] ?? 0 ),
                            'tables'        => (int) ( $db_export['tables'] ?? 0 ),
                            'rows'          => (int) ( $db_export['rows'] ?? 0 ),
                        ],
                        'file_inventory'          => [
                            'relative_path' => 'file-inventory.json',
                            'hash'          => (string) ( $inventory_write['hash'] ?? '' ),
                            'size'          => (int) ( $inventory_write['size'] ?? 0 ),
                            'summary'       => $inventory['summary'] ?? [],
                        ],
                        'files_archive'           => [
                            'relative_path' => $files_archive_relative,
                            'hash'          => (string) ( $files_archive['hash'] ?? '' ),
                            'size'          => (int) ( $files_archive['size'] ?? 0 ),
                            'summary'       => $files_archive['summary'] ?? [],
                        ],
                        'migration_ready'         => true,
                        'package_use'             => [ 'backup', 'migration' ],
                        'migration'               => [
                            'source_site_url' => site_url(),
                            'source_home_url' => home_url(),
                            'import_supported' => true,
                            'destination_flow' => [ 'import', 'validate', 'preview', 'dry_run', 'restore' ],
                        ],
                        'size_breakdown'          => $this->size_breakdown( $db_export, $inventory, $files_archive, [] ),
                        'note'                    => 'RestoreBase backups are restorable: the same ZIP works as a normal backup or as an import on another site.',
                    ] );

                    $manifest_write = LocalStorage::write_json_file( $work_dir . 'manifest.json', $manifest, 'Package manifest' );
                    $manifest_store = LocalStorage::write_manifest( $snapshot_key, $manifest );

                    $data = [ 'manifest' => $manifest, 'manifest_write' => $manifest_write, 'manifest_store' => $manifest_store ];
                    return ( ! empty( $manifest_write['ok'] ) && ! empty( $manifest_store['ok'] ) ) ? TaskResponse::ok( 'Package manifest written.', $data ) : TaskResponse::fail( 'Package manifest write failed.', $data );
                },
            ],
            [
                'id'       => 'checksums_signing',
                'label'    => 'Checksums & Signing',
                'callback' => function ( array $context ) use ( $work_dir ) {
                    $manifest_write = isset( $context['manifest_build']['manifest_write'] ) && is_array( $context['manifest_build']['manifest_write'] ) ? $context['manifest_build']['manifest_write'] : [];
                    $db_export = isset( $context['database_export'] ) && is_array( $context['database_export'] ) ? $context['database_export'] : [];
                    $inventory_write = isset( $context['file_inventory']['write'] ) && is_array( $context['file_inventory']['write'] ) ? $context['file_inventory']['write'] : [];
                    $files_archive = isset( $context['file_archive'] ) && is_array( $context['file_archive'] ) ? $context['file_archive'] : [];
                    $files_archive_relative = isset( $files_archive['relative_path'] ) ? (string) $files_archive['relative_path'] : 'files.restorebase';

                    $checksums = ( new PackageSigner() )->build_checksums( [
                        'manifest'       => [ 'relative_path' => 'manifest.json', 'hash' => (string) ( $manifest_write['hash'] ?? '' ), 'size' => (int) ( $manifest_write['size'] ?? 0 ) ],
                        'database'       => [ 'relative_path' => 'database.sql', 'hash' => (string) ( $db_export['hash'] ?? '' ), 'size' => (int) ( $db_export['size'] ?? 0 ) ],
                        'file_inventory' => [ 'relative_path' => 'file-inventory.json', 'hash' => (string) ( $inventory_write['hash'] ?? '' ), 'size' => (int) ( $inventory_write['size'] ?? 0 ) ],
                        'files_archive'  => [ 'relative_path' => $files_archive_relative, 'hash' => (string) ( $files_archive['hash'] ?? '' ), 'size' => (int) ( $files_archive['size'] ?? 0 ) ],
                    ] );

                    $write = LocalStorage::write_json_file( $work_dir . 'checksums.json', $checksums, 'Package checksums' );
                    return ! empty( $write['ok'] ) ? TaskResponse::ok( 'Checksums written.', [ 'checksums' => $checksums, 'write' => $write ] ) : TaskResponse::fail( 'Checksums write failed.', [ 'checksums' => $checksums, 'write' => $write ] );
                },
            ],
            [
                'id'       => 'zip_package',
                'label'    => 'Package ZIP',
                'callback' => function ( array $context ) use ( $snapshot_key, $label, $work_dir ) {
                    $zip = $this->zip_package( $snapshot_key, $work_dir, $label );
                    return ! empty( $zip['ok'] ) ? TaskResponse::ok( 'Package ZIP created.', $zip ) : TaskResponse::fail( (string) ( $zip['message'] ?? 'Package ZIP creation failed.' ), $zip );
                },
            ],
            [
                'id'       => 'finish_package',
                'label'    => 'Finish Package',
                'callback' => function ( array $context ) use ( $snapshot_key, $label, $created_by, $work_dir ) {
                    return TaskResponse::ok( 'Package snapshot record created.', $this->store_snapshot_record( $snapshot_key, $label, $created_by, $work_dir, $context ) );
                },
            ],
        ];
    }

    /** Load the file inventory from disk (kept out of the job row for performance). */
    private function read_inventory( string $path ): array {
        if ( '' === $path || ! is_readable( $path ) ) {
            return [];
        }
        $json = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        $decoded = json_decode( (string) $json, true );
        return is_array( $decoded ) ? $decoded : [];
    }

    /** Summary-only inventory shape for manifest/size reporting. */
    private function inventory_summary( array $context ): array {
        $summary = isset( $context['file_inventory']['summary'] ) && is_array( $context['file_inventory']['summary'] ) ? $context['file_inventory']['summary'] : [];
        return [ 'summary' => $summary ];
    }

    private function store_snapshot_record( string $snapshot_key, string $label, int $created_by, string $work_dir, array $context ): array {
        global $wpdb;

        $zip = isset( $context['zip_package'] ) && is_array( $context['zip_package'] ) ? $context['zip_package'] : [];
        $manifest_store = isset( $context['manifest_build']['manifest_store'] ) && is_array( $context['manifest_build']['manifest_store'] ) ? $context['manifest_build']['manifest_store'] : [];
        $db_export = isset( $context['database_export'] ) && is_array( $context['database_export'] ) ? $context['database_export'] : [];
        $inventory_write = isset( $context['file_inventory']['write'] ) && is_array( $context['file_inventory']['write'] ) ? $context['file_inventory']['write'] : [];
        $files_archive = isset( $context['file_archive'] ) && is_array( $context['file_archive'] ) ? $context['file_archive'] : [];
        $checksums_write = isset( $context['checksums_signing']['write'] ) && is_array( $context['checksums_signing']['write'] ) ? $context['checksums_signing']['write'] : [];
        $manifest = isset( $context['manifest_build']['manifest'] ) && is_array( $context['manifest_build']['manifest'] ) ? $context['manifest_build']['manifest'] : [];

        $status = ! empty( $zip['ok'] ) ? 'completed' : 'failed';
        $meta = [
            'package_version'   => '1.0-universal',
            'restorebase_version'=> VE_RECOVERY_VERSION,
            'created_with_version' => VE_RECOVERY_VERSION,
            'migration_ready'   => true,
            'package_use'       => [ 'backup', 'migration' ],
            'source_site_url'   => site_url(),
            'source_home_url'   => home_url(),
            'package_message'   => (string) ( $zip['message'] ?? '' ),
            'package_path'      => (string) ( $zip['path'] ?? '' ),
            'package_filename'  => (string) ( $zip['filename'] ?? '' ),
            'package_hash'      => (string) ( $zip['hash'] ?? '' ),
            'package_size'      => (int) ( $zip['size'] ?? 0 ),
            'encrypted'         => ! empty( $zip['encrypted'] ),
            'work_dir'          => $work_dir,
            'database_export'   => $db_export,
            'file_inventory'    => $inventory_write,
            'files_archive'     => $files_archive,
            'checksums_write'   => $checksums_write,
            'contents'          => $manifest['contents'] ?? [],
            'size_breakdown'    => $this->size_breakdown( $db_export, $this->inventory_summary( $context ), $files_archive, $zip ),
            'job_key'           => isset( $context['job_key'] ) ? (string) $context['job_key'] : '',
        ];

        $wpdb->insert(
            Schema::table( 'snapshots' ),
            [
                'snapshot_key'  => $snapshot_key,
                'label'         => $label,
                'trigger_type'  => 'backup_package',
                'status'        => $status,
                'manifest_path' => (string) ( $manifest_store['path'] ?? '' ),
                'manifest_hash' => (string) ( $manifest_store['hash'] ?? '' ),
                'size_bytes'    => absint( $zip['size'] ?? 0 ),
                'meta_json'     => wp_json_encode( $meta ),
                'created_by'    => absint( $created_by ),
                'created_at'    => current_time( 'mysql' ),
                'updated_at'    => current_time( 'mysql' ),
            ],
            [ '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s' ]
        );

        $id = (int) $wpdb->insert_id;

        Logger::info( 'backup_package_created', 'Backup creation finished.', [
            'snapshot_key' => $snapshot_key,
            'status'       => $status,
            'id'           => $id,
            'package_size' => (int) ( $zip['size'] ?? 0 ),
        ] );

        return [
            'id'            => $id,
            'snapshot_key'  => $snapshot_key,
            'label'         => $label,
            'trigger_type'  => 'backup_package',
            'status'        => $status,
            'manifest_path' => (string) ( $manifest_store['path'] ?? '' ),
            'manifest_hash' => (string) ( $manifest_store['hash'] ?? '' ),
            'size_bytes'    => absint( $zip['size'] ?? 0 ),
            'created_at'    => current_time( 'mysql' ),
            'package'       => [
                'path'         => (string) ( $zip['path'] ?? '' ),
                'hash'         => (string) ( $zip['hash'] ?? '' ),
                'size'         => (int) ( $zip['size'] ?? 0 ),
                'download_url'  => $this->download_url( $snapshot_key ),
                'download_name' => (string) ( $zip['filename'] ?? $this->package_file_name( $snapshot_key ) ),
            ],
            'meta'          => $meta,
        ];
    }

    private function size_breakdown( array $db_export, array $inventory, array $files_archive, array $zip ): array {
        $inventory_summary = isset( $inventory['summary'] ) && is_array( $inventory['summary'] ) ? $inventory['summary'] : [];
        $category_bytes = isset( $inventory_summary['category_bytes'] ) && is_array( $inventory_summary['category_bytes'] ) ? $inventory_summary['category_bytes'] : [];
        $archive_summary = isset( $files_archive['summary'] ) && is_array( $files_archive['summary'] ) ? $files_archive['summary'] : [];
        $archive_bytes = isset( $archive_summary['group_bytes'] ) && is_array( $archive_summary['group_bytes'] ) ? $archive_summary['group_bytes'] : [];
        $db_size = (int) ( $db_export['size'] ?? 0 );
        $files_zip_size = (int) ( $files_archive['size'] ?? 0 );
        $package_size = (int) ( $zip['size'] ?? 0 );
        $known = $db_size + $files_zip_size;
        return [
            'database'        => $db_size,
            'files_archive'   => $files_zip_size,
            'package_total'   => $package_size,
            'package_overhead'=> max( 0, $package_size - $known ),
            'source_file_bytes' => $category_bytes,
            'archived_file_bytes' => $archive_bytes,
            'file_count'      => (int) ( $inventory_summary['file_count'] ?? 0 ),
            'archived_files'  => (int) ( $archive_summary['included_files'] ?? 0 ),
            'skipped_files'   => (int) ( $archive_summary['skipped_files'] ?? 0 ),
            'truncated'       => ! empty( $archive_summary['truncated'] ) || ! empty( $inventory_summary['truncated'] ),
        ];
    }

    private function zip_package( string $snapshot_key, string $work_dir, string $label = '' ): array {
        if ( ! class_exists( '\ZipArchive' ) ) {
            return [ 'ok' => false, 'message' => 'ZipArchive is not available.', 'path' => '', 'hash' => '', 'size' => 0 ];
        }

        $filename = $this->package_file_name( $snapshot_key, $label );
        $zip_path = LocalStorage::packages_dir() . $filename;
        $zip = new \ZipArchive();
        if ( true !== $zip->open( $zip_path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE ) ) {
            return [ 'ok' => false, 'message' => 'Package ZIP could not be created.', 'path' => '', 'hash' => '', 'size' => 0 ];
        }

        foreach ( [ 'manifest.json', 'database.sql', 'file-inventory.json', 'files.restorebase', 'files.zip', 'checksums.json' ] as $file ) {
            $path = trailingslashit( $work_dir ) . $file;
            if ( file_exists( $path ) ) {
                if ( $zip->addFile( $path, $file ) && method_exists( $zip, 'setCompressionName' ) && in_array( $file, [ 'files.restorebase', 'files.zip' ], true ) ) {
                    $zip->setCompressionName( $file, \ZipArchive::CM_STORE );
                }
            }
        }
        $zip->close();

        $encrypted = false;
        if ( file_exists( $zip_path ) && PackageCipher::is_configured() && PackageCipher::available() ) {
            $enc_path = $zip_path . '.enc';
            $enc = PackageCipher::encrypt_file( $zip_path, $enc_path, PackageCipher::passphrase() );
            if ( ! empty( $enc['ok'] ) && file_exists( $enc_path ) ) {
                @unlink( $zip_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
                @rename( $enc_path, $zip_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
                $encrypted = file_exists( $zip_path );
            } else {
                @unlink( $enc_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
                Logger::warning( 'package_encryption_failed', 'Package encryption failed; kept the unencrypted package.', [ 'message' => (string) ( $enc['message'] ?? '' ) ] );
            }
        }

        return [
            'ok'       => file_exists( $zip_path ),
            'message'  => file_exists( $zip_path ) ? ( $encrypted ? 'Encrypted package ZIP created.' : 'Package ZIP created.' ) : 'Package ZIP was not found after creation.',
            'path'     => file_exists( $zip_path ) ? $zip_path : '',
            'filename' => $filename,
            'encrypted'=> $encrypted,
            'hash'     => is_readable( $zip_path ) ? (string) hash_file( 'sha256', $zip_path ) : '',
            'size'     => file_exists( $zip_path ) ? (int) filesize( $zip_path ) : 0,
        ];
    }


    private function package_file_name( string $snapshot_key, string $label = '' ): string {
        $host = (string) wp_parse_url( home_url(), PHP_URL_HOST );
        if ( '' === self::safe_component( $host ) ) {
            $host = (string) get_bloginfo( 'name' );
        }
        $name = self::build_file_name( $host, current_time( 'Y-m-d-Hi' ), $this->version_slug() );
        return $this->unique_file_name( $name );
    }

    /**
     * Human-readable package filename.
     *
     *   mv-backup-blueprint.hebronmimam.com-2026-07-15-1437-v1.0.0-rc64.zip
     *
     * The domain keeps its dots (sanitize_title() flattened it to
     * "blueprint-hebronmimam-com") and the timestamp is local, readable and sortable.
     *
     * sanitize_file_name() is deliberately NOT used on the assembled name: it treats
     * every dot as an extension boundary and appends "_" after short segments, turning
     * example.com.zip into example.com_.zip. Each component is whitelisted instead.
     */
    public static function build_file_name( string $host, string $stamp, string $version = '' ): string {
        $site = self::safe_component( $host );
        if ( '' === $site ) {
            $site = 'wordpress-site';
        }
        $stamp = self::safe_component( $stamp );
        $name = 'mv-backup-' . $site . '-' . $stamp;

        $version = self::safe_component( $version );
        if ( '' !== $version ) {
            $name .= '-v' . $version;
        }

        return $name . '.zip';
    }

    /** Filename-safe component: lowercase, keeps dots so domains stay readable. */
    private static function safe_component( string $value ): string {
        $value = strtolower( $value );
        $value = (string) preg_replace( '/[^a-z0-9.\-]/', '', $value );
        return trim( $value, '.-' );
    }

    /** Minute-precision names can collide for the same site; never overwrite a package. */
    private function unique_file_name( string $name ): string {
        $dir = LocalStorage::packages_dir();
        if ( ! file_exists( $dir . $name ) ) {
            return $name;
        }
        $base = (string) preg_replace( '/\.zip$/i', '', $name );
        for ( $i = 2; $i <= 99; $i++ ) {
            if ( ! file_exists( $dir . $base . '-' . $i . '.zip' ) ) {
                return $base . '-' . $i . '.zip';
            }
        }
        return $base . '-' . strtolower( wp_generate_password( 4, false, false ) ) . '.zip';
    }

    /** Readable version for filenames: keeps dots, so 1.0.0-rc64 stays 1.0.0-rc64. */
    private function version_slug(): string {
        // Name the package after the host plugin (MV) so downloads read v1.3.252, not the
        // Recovery module's own internal version (1.0.0-rcNN). Standalone hosts with no
        // VE_VERSION fall back to the module version.
        $version = defined( 'VE_VERSION' ) ? (string) VE_VERSION : ( defined( 'VE_RECOVERY_VERSION' ) ? (string) VE_RECOVERY_VERSION : '' );
        $version = strtolower( (string) preg_replace( '/[^A-Za-z0-9.\-]/', '', $version ) );
        $version = trim( $version, '.-' );
        $version = (string) preg_replace( '/^v+/', '', $version );
        return $version;
    }

    private function generate_key(): string {
        return 'rb-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 8, false, false );
    }
}
