<?php
/**
 * Slice 7 — the first runtime family: Bricks variables.
 *
 * Slices 1–6 isolated STRUCTURAL objects: a page becomes a private shadow post,
 * and WordPress keeps a draft out of public queries without any help from MV.
 * That isolation survives MV being switched off, which is why §100.1.a could be
 * claimed plainly.
 *
 * A runtime family has no post to hide in. `bricks_global_variables` is one site
 * option that every request reads, so isolating it means answering that read
 * differently depending on who is asking. That is a weaker kind of isolation and
 * the wording matters: **isolation while MV runs**. Switch MV off and every
 * request sees the live option again, which is the honest behaviour and is what
 * §109.1 permits this slice to claim — no more.
 *
 * ── What the object-cache test settled (2026-09-16) ──────────────────────────
 *
 * Running WordPress's own option.php proved the read path is safe:
 * `get_option()` returns on `pre_option_{$option}` BEFORE it touches
 * `wp_load_alloptions()` or any `wp_cache_*`. An overlaid value therefore never
 * enters a persistent object cache, never enters `alloptions`, and a public
 * request reads the live row. See `scripts/check-workspace-object-cache.php`.
 *
 * The same test found the leak that is NOT obvious, and this class exists as
 * much for it as for the overlay: `update_option()` takes its old value THROUGH
 * `get_option()`, and therefore through the overlay. So a write during a
 * workspace session is compared against the workspace value rather than the live
 * one, and when they differ core writes it to the real row and caches it for
 * every visitor. `pre_update_option_*` is not tidiness. It is the only thing
 * standing between a workspace session and a real write.
 *
 * ── Why registration is early and resolution is late ─────────────────────────
 *
 * From core's own wp-settings.php: pluggable.php loads at line 623,
 * `plugins_loaded` fires at 641, `init` at 790. So the filters can be registered
 * on `plugins_loaded` — early enough to precede Bricks constructing its
 * `Database` and caching globals into a static, which a later filter could never
 * reach.
 *
 * But WHO is asking cannot be answered that early without deciding the current
 * user before other plugins have had their say on `determine_current_user`. So
 * registration is early and resolution is lazy: before `init`, this class
 * answers "no session", and a request that cannot know who it is serves LIVE.
 * Every uncertainty in here falls the same way. A workspace value reaching a
 * visitor is the failure §85 exists to prevent; an editor seeing the live value
 * for one early read is an inconvenience.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceRuntime {

    /** The one family this slice covers. Slice 9 adds the others. */
    public const FAMILY_VARIABLES = 'bricks_global_variables';

    /** Where a user's current workspace is remembered. */
    public const SESSION_META = '_ve_workspace_session';

    /** @var int|null Resolved session, per request. Null means "not yet". */
    private static $session = null;

    /** @var bool Re-entrancy: our own reads must not come back through us. */
    private static $resolving = false;

    /** @var bool|null Cached per request. */
    private static $inline_mode = null;

    public static function register(): void {
        add_filter( 'pre_option_' . self::FAMILY_VARIABLES, [ self::class, 'read_overlay' ], 10, 1 );
        add_filter( 'pre_update_option_' . self::FAMILY_VARIABLES, [ self::class, 'hold_write' ], 10, 2 );
    }

    /**
     * The workspace this request is working inside, or 0.
     *
     * Not cached before `init`: the answer there is "cannot know", which is a
     * different thing from "none", and caching it would make the rest of the
     * request wrong.
     */
    public static function session_id(): int {
        if ( null !== self::$session ) {
            return self::$session;
        }
        if ( ! did_action( 'init' ) ) {
            return 0;
        }
        if ( ! function_exists( 'get_current_user_id' ) ) {
            return 0;
        }

        $user_id = (int) get_current_user_id();
        if ( $user_id <= 0 ) {
            // A logged-out visitor is never inside a workspace. This is §85.
            self::$session = 0;
            return 0;
        }

        $id = (int) get_user_meta( $user_id, self::SESSION_META, true );
        if ( $id <= 0 ) {
            self::$session = 0;
            return 0;
        }

        /* A session pointing at a workspace that has been discarded, archived or
           published is not a session. Checked every request rather than trusted,
           because the meta outlives the workspace. */
        $workspace = class_exists( __NAMESPACE__ . '\WorkspaceStore' ) ? WorkspaceStore::get( $id ) : null;
        $open      = is_array( $workspace ) && in_array( (string) ( $workspace['status'] ?? '' ), [ 'open', 'active', 'draft' ], true );

        self::$session = $open ? $id : 0;
        return self::$session;
    }

    /** Somebody opened a workspace. */
    public static function begin_session( int $user_id, int $workspace_id ): bool {
        if ( $user_id <= 0 || $workspace_id <= 0 ) {
            return false;
        }
        self::$session = null;
        return (bool) update_user_meta( $user_id, self::SESSION_META, $workspace_id );
    }

    /** …and closed it. */
    public static function end_session( int $user_id ): bool {
        if ( $user_id <= 0 ) {
            return false;
        }
        self::$session = null;
        return (bool) delete_user_meta( $user_id, self::SESSION_META );
    }

    /**
     * §109.1 — inline CSS mode only.
     *
     * In file mode Bricks writes the variables into shared .css files on save,
     * and overlaying the option would leave those files holding workspace
     * values for every visitor. The option would be isolated and the site would
     * not be. Slice 10 is where file mode is dealt with; until then this slice
     * declines rather than claims something it cannot deliver.
     */
    public static function enabled(): bool {
        if ( null !== self::$inline_mode ) {
            return self::$inline_mode;
        }
        self::$resolving = true;
        $settings = get_option( 'bricks_global_settings', [] );
        self::$resolving = false;

        $settings = is_array( $settings ) ? $settings : [];
        $mode     = isset( $settings['cssLoading'] ) ? (string) $settings['cssLoading'] : '';

        self::$inline_mode = ( 'file' !== $mode );
        return self::$inline_mode;
    }

    /** Where a workspace keeps its runtime values. One option per workspace. */
    public static function store_key( int $workspace_id ): string {
        return 've_ws_runtime_' . $workspace_id;
    }

    /**
     * @return mixed The workspace's value for a family, or null if it has none.
     *               Null is not "empty" — it means the workspace has never been
     *               told about this family, and the answer is Live.
     */
    public static function payload( int $workspace_id, string $family ) {
        if ( $workspace_id <= 0 ) {
            return null;
        }
        self::$resolving = true;
        $all = get_option( self::store_key( $workspace_id ), [] );
        self::$resolving = false;

        if ( ! is_array( $all ) || ! array_key_exists( $family, $all ) ) {
            return null;
        }
        return $all[ $family ];
    }

    public static function set_payload( int $workspace_id, string $family, $value ): bool {
        if ( $workspace_id <= 0 ) {
            return false;
        }
        self::$resolving = true;
        $key = self::store_key( $workspace_id );
        $all = get_option( $key, [] );
        $all = is_array( $all ) ? $all : [];
        $all[ $family ] = $value;
        $ok = update_option( $key, $all, false );
        self::$resolving = false;

        return (bool) $ok;
    }

    /** Forget everything a workspace held. Used when one is discarded. */
    public static function forget( int $workspace_id ): bool {
        if ( $workspace_id <= 0 ) {
            return false;
        }
        self::$resolving = true;
        $ok = delete_option( self::store_key( $workspace_id ) );
        self::$resolving = false;
        return (bool) $ok;
    }

    /**
     * The read side. Returning anything but false short-circuits get_option(),
     * BEFORE it reads or writes any cache — which is the whole reason this is
     * safe, and is proved against core rather than assumed.
     *
     * @param mixed $pre False to carry on to the real option.
     * @return mixed
     */
    public static function read_overlay( $pre ) {
        if ( self::$resolving ) {
            return $pre;
        }
        if ( ! self::enabled() ) {
            return $pre;
        }
        $workspace_id = self::session_id();
        if ( $workspace_id <= 0 ) {
            return $pre;
        }

        $value = self::payload( $workspace_id, self::FAMILY_VARIABLES );
        if ( null === $value ) {
            /* The workspace has not touched variables, so there is nothing to
               overlay and Live is the correct answer. Inventing an empty array
               here would blank every variable on the site for the editor. */
            return $pre;
        }
        return $value;
    }

    /**
     * The write side, and the half the object-cache test made non-optional.
     *
     * Returning $old is what makes core's own equality check return false
     * before it writes the row or the cache. The value goes to the workspace
     * instead.
     *
     * @param mixed $value The value somebody is trying to store.
     * @param mixed $old   What get_option() said — and get_option() went
     *                     through the overlay above, so this is the WORKSPACE
     *                     value when a session is on.
     * @return mixed
     */
    public static function hold_write( $value, $old ) {
        if ( self::$resolving ) {
            return $value;
        }
        if ( ! self::enabled() ) {
            return $value;
        }
        $workspace_id = self::session_id();
        if ( $workspace_id <= 0 ) {
            return $value;
        }

        self::set_payload( $workspace_id, self::FAMILY_VARIABLES, $value );

        /* Hand core back what it already believes, so it writes nothing. */
        return $old;
    }

    /** For tests and for a request that has genuinely changed identity. */
    public static function forget_session_cache(): void {
        self::$session     = null;
        self::$inline_mode = null;
    }
}
