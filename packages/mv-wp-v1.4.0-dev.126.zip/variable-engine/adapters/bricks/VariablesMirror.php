<?php

namespace VE\Adapters\Bricks;

use VE\Core\VariableManager;

defined( 'ABSPATH' ) || exit;

class VariablesMirror {

    private const CATEGORY_ID = 'mimams-var';
    private const ID_PREFIX   = 'mv-';

    public function sync( ?array $variables = null ): bool {
        if ( ! $this->bricks_available() ) {
            return true;
        }

        if ( null === $variables ) {
            $variables = ( new VariableManager() )->get_all();
        }

        $current = get_option( 'bricks_global_variables', [] );
        $current = is_array( $current ) ? $current : [];
        $merged  = self::merge_variables( $current, $variables );

        /* §112, and slice 7 does not ship without this.

           This mirror writes `bricks_global_variables` straight through the
           option API, which is how it bypasses the builder - and it is also why
           WorkspaceRuntime's `pre_update_option_*` catches it: a sync during a
           workspace session is held and put in the workspace rather than on the
           site. That part needs no change here.

           What DOES need changing is how the answer is read. Holding the write
           makes core's own equality check return false, and this line treated a
           false from update_option() as a failure - so a sync inside a workspace
           would have reported "the mirror is broken" while doing exactly the
           right thing. Under a session, false is success. */
        if ( $merged !== $current && ! update_option( 'bricks_global_variables', $merged, false ) ) {
            if ( ! self::in_workspace_session() ) {
                return false;
            }
        }

        $categories = get_option( 'bricks_global_variables_categories', [] );
        $categories = is_array( $categories ) ? $categories : [];
        $has_category = false;
        foreach ( $categories as $category ) {
            if ( is_array( $category ) && ( $category['id'] ?? '' ) === self::CATEGORY_ID ) {
                $has_category = true;
                break;
            }
        }
        if ( ! $has_category ) {
            $categories[] = [
                'id'   => self::CATEGORY_ID,
                'name' => "Mimam's Var",
            ];
            if ( ! update_option( 'bricks_global_variables_categories', array_values( $categories ), false ) ) {
                /* The categories option is NOT overlaid by slice 7 - only the
                   variables themselves are - so a false here is a real failure
                   and stays one. Said out loud because the two lines now look
                   alike and the difference is the whole point. */
                return false;
            }
        }

        return true;
    }

    public static function merge_variables( array $current, array $variables ): array {
        $manager = new VariableManager();
        $external = [];
        $external_names = [];

        foreach ( $current as $variable ) {
            if ( ! is_array( $variable ) ) {
                continue;
            }
            $id = (string) ( $variable['id'] ?? '' );
            $category = (string) ( $variable['category'] ?? '' );
            if ( self::CATEGORY_ID === $category || 0 === strpos( $id, self::ID_PREFIX ) ) {
                continue;
            }
            $name = ltrim( (string) ( $variable['name'] ?? '' ), '-' );
            if ( '' !== $name ) {
                $external_names[ $name ] = true;
            }
            $external[] = $variable;
        }

        $mirrored = [];
        foreach ( $variables as $variable ) {
            if ( ! is_array( $variable ) || empty( $variable['id'] ) || empty( $variable['name'] ) ) {
                continue;
            }
            $name = ltrim( $manager->to_css_name( (string) $variable['name'] ), '-' );
            if ( '' === $name || isset( $external_names[ $name ] ) ) {
                continue;
            }
            $mirrored[] = [
                'id'       => self::ID_PREFIX . (int) $variable['id'],
                'name'     => $name,
                'value'    => (string) ( $variable['css_value'] ?? $variable['value'] ?? '' ),
                'category' => self::CATEGORY_ID,
            ];
        }

        usort( $mirrored, static function ( array $a, array $b ): int {
            return strnatcasecmp( $a['name'], $b['name'] );
        } );

        return array_values( array_merge( $external, $mirrored ) );
    }

    /**
     * Whether this write is happening inside a workspace session.
     *
     * Asked of the module rather than worked out here: one place decides what a
     * session is, and a second copy of that rule would be the way the two come
     * to disagree. Absent module, absent session - which is also the answer on
     * any site where Workspaces is switched off.
     */
    private static function in_workspace_session(): bool {
        if ( ! class_exists( '\\VE\\Modules\\Workspaces\\WorkspaceRuntime' ) ) {
            return false;
        }
        return \VE\Modules\Workspaces\WorkspaceRuntime::session_id() > 0;
    }

    private function bricks_available(): bool {
        return defined( 'BRICKS_VERSION' )
            || function_exists( 'bricks_is_builder' )
            || false !== get_option( 'bricks_global_variables', false );
    }
}
