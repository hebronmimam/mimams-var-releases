(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarQuickAdd) return;

  var Core = window.MimamsBarCore || {};
  var config = Core.config || window.baqaConfig || {};
  var log = Core.log || function () {};

  // The bar is chrome over someone else's canvas, so it only exists in the
  // builder, and only while the setting says so.
  if ((config.surface || 'admin') !== 'builder') return;

  var STORE_KEY = 'mvQuickAddBar';
  var DEFAULT_SLOTS = ['el:section', 'el:container', 'el:block', 'el:heading', 'el:text', 'el:image'];

  var state = {
    slots: DEFAULT_SLOTS.slice(),
    enabled: true,
    sheet: false,      // the Edit bar list
    query: '',
    arranging: false,  // O: pick up, then place
    lifted: null,
    catalog: null,     // built once Bricks has told us what exists
    catalogAt: 0
  };

  var root = null;

  /* ── Storage ──────────────────────────────────────────────────────────
     The bar contents live on the browser, the on/off switch comes from MV's
     settings so it is the same answer in every browser. A stored `enabled`
     is only a same-session echo of the server value. */
  function read() {
    try {
      var raw = window.localStorage ? window.localStorage.getItem(STORE_KEY) : '';
      var parsed = raw ? JSON.parse(raw) : null;
      if (parsed && Array.isArray(parsed.slots) && parsed.slots.length) {
        state.slots = parsed.slots.filter(function (key) { return typeof key === 'string'; });
      }
    } catch (e) {}
    var setting = config.quickAdd && typeof config.quickAdd.enabled !== 'undefined'
      ? !!config.quickAdd.enabled
      : true;
    state.enabled = setting;
  }
  function write() {
    try {
      if (window.localStorage) {
        window.localStorage.setItem(STORE_KEY, JSON.stringify({ slots: state.slots }));
      }
    } catch (e) {}
  }

  /* ── What can be added ────────────────────────────────────────────────
     Both halves come from Bricks itself: the element configs it registered,
     and the components this site has. Nothing here is a hand-kept list. */
  function adapter() {
    return window.MimamsBarBricksAdapter || null;
  }
  function catalog(options) {
    options = options || {};
    var now = Date.now ? Date.now() : new Date().getTime();
    if (!options.fresh && state.catalog && now - state.catalogAt < 4000) return state.catalog;

    var api = adapter();
    var items = [];
    if (api) {
      try {
        (api.getBricksElementConfigs() || []).forEach(function (element) {
          if (!element || !element.name) return;
          items.push({
            key: 'el:' + element.name,
            kind: 'element',
            name: element.name,
            label: element.label || element.name,
            category: element.category || '',
            icon: element.icon || ''
          });
        });
      } catch (e0) { log('quick add: element configs failed', e0); }
      try {
        (api.getBricksComponents() || []).forEach(function (component) {
          if (!component || !component.id) return;
          items.push({
            key: 'cmp:' + component.id,
            kind: 'component',
            componentId: component.id,
            label: component.label || component.id,
            category: component.category || 'Components',
            icon: '',
            config: component
          });
        });
      } catch (e1) { log('quick add: components failed', e1); }
    }
    if (items.length) {
      state.catalog = items;
      state.catalogAt = now;
    }
    return items;
  }
  function byKey(key) {
    var list = catalog();
    for (var i = 0; i < list.length; i++) {
      if (list[i].key === key) return list[i];
    }
    // A slot can outlive the thing it points at — a deleted component, a
    // plugin that stopped registering its element. Show it, do not crash.
    var parts = String(key || '').split(':');
    return {
      key: key,
      kind: parts[0] === 'cmp' ? 'component' : 'element',
      name: parts[1] || '',
      label: parts[1] || 'Unknown',
      missing: true,
      icon: ''
    };
  }

  /* ── Markup ───────────────────────────────────────────────────────────── */
  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  function glyph(item) {
    // Bricks ships its own icon font and its element configs name the class,
    // so the bar shows the same glyph the element panel does. A component has
    // no icon of its own; it gets the mark and its initial.
    if (item.icon) return '<i class="' + escapeHtml(item.icon) + '" aria-hidden="true"></i>';
    var initial = String(item.label || '?').trim().charAt(0).toUpperCase();
    return '<span class="mvqa-initial" aria-hidden="true">' + escapeHtml(initial) + '</span>';
  }
  function slotButton(key, extraClass) {
    var item = byKey(key);
    var kindWord = item.kind === 'component' ? 'component' : 'element';
    return '<button type="button" class="mvqa-slot' + (extraClass ? ' ' + extraClass : '') +
      (item.missing ? ' is-missing' : '') + '" data-key="' + escapeHtml(key) + '" ' +
      'aria-label="' + escapeHtml(item.label) + ', ' + kindWord + '">' +
      glyph(item) +
      '<span class="mvqa-kind mvqa-kind-' + kindWord + '" aria-hidden="true"></span>' +
      '<span class="mvqa-tip">' + escapeHtml(item.label) +
        ' <em>· ' + (item.missing ? 'missing' : kindWord) + '</em></span>' +
      '</button>';
  }
  var ICON_EDIT = '<svg viewBox="0 0 24 24" aria-hidden="true" class="mvqa-svg">' +
    '<path d="M5 6h14M5 12h14M5 18h14"/><circle cx="9" cy="6" r="2"/><circle cx="15" cy="12" r="2"/>' +
    '<circle cx="8" cy="18" r="2"/></svg>';
  var ICON_ARRANGE = '<svg viewBox="0 0 24 24" aria-hidden="true" class="mvqa-svg">' +
    '<path d="M7 6h13M7 12h13M7 18h13"/><path d="M3 5l1.5 1.5L3 8M3 11l1.5 1.5L3 14M3 17l1.5 1.5L3 20"/></svg>';
  var ICON_TICK = '<svg viewBox="0 0 24 24" aria-hidden="true" class="mvqa-svg">' +
    '<path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

  function barHtml() {
    var parts = [];
    if (state.arranging) parts.push('<span class="mvqa-mode">arrange</span>');

    state.slots.forEach(function (key, index) {
      // While something is lifted, every place it could go is a gap you can
      // press. Nothing is dragged and nothing has to be aimed at.
      if (state.arranging && state.lifted && index === 0) {
        parts.push(gapHtml(0));
      }
      parts.push(slotButton(key, state.lifted === key ? 'is-lifted' : ''));
      if (state.arranging && state.lifted) parts.push(gapHtml(index + 1));
    });

    if (!state.slots.length) {
      parts.push('<span class="mvqa-empty">Nothing in the bar yet</span>');
    }

    parts.push('<span class="mvqa-sep"></span>');
    if (state.arranging) {
      parts.push('<button type="button" class="mvqa-tail mvqa-tick" data-arrange-done ' +
        'aria-label="Done arranging">' + ICON_TICK + '<span class="mvqa-tip">Done</span></button>');
    } else {
      parts.push('<button type="button" class="mvqa-tail' + (state.sheet ? ' is-on' : '') + '" ' +
        'data-sheet aria-label="Edit bar">' + ICON_EDIT + '<span class="mvqa-tip">Edit bar</span></button>');
      parts.push('<button type="button" class="mvqa-tail" data-arrange aria-label="Arrange the bar">' +
        ICON_ARRANGE + '<span class="mvqa-tip">Arrange</span></button>');
    }
    return parts.join('');
  }
  function gapHtml(index) {
    return '<button type="button" class="mvqa-gap" data-gap="' + index + '" ' +
      'aria-label="Put it here"></button>';
  }

  function sheetHtml() {
    var query = state.query.toLowerCase();
    var list = catalog().filter(function (item) {
      return !query || String(item.label).toLowerCase().indexOf(query) !== -1;
    });
    var elements = list.filter(function (item) { return item.kind === 'element'; });
    var components = list.filter(function (item) { return item.kind === 'component'; });

    function row(item) {
      var inBar = state.slots.indexOf(item.key) !== -1;
      return '<button type="button" class="mvqa-row' + (inBar ? ' is-on' : '') + '" ' +
        'data-pick="' + escapeHtml(item.key) + '">' +
        '<span class="mvqa-row-icon">' + glyph(item) + '</span>' +
        '<span class="mvqa-row-name">' + escapeHtml(item.label) + '</span>' +
        '<span class="mvqa-row-kind"><i class="mvqa-kind mvqa-kind-' +
          (item.kind === 'component' ? 'component' : 'element') + '"></i>' + item.kind + '</span>' +
        '<span class="mvqa-tick-box">✓</span></button>';
    }

    return '<div class="mvqa-sheet">' +
      '<h6>What sits in the bar</h6>' +
      '<p class="mvqa-note">Ticked items are in it, in this order. Search reaches every element Bricks ' +
        'registered and every component on this site.</p>' +
      '<input class="mvqa-find" type="search" placeholder="Search elements and components…" ' +
        'value="' + escapeHtml(state.query) + '" autocomplete="off" spellcheck="false">' +
      '<div class="mvqa-list">' +
        (list.length
          ? (elements.length ? '<div class="mvqa-group">Elements</div>' + elements.map(row).join('') : '') +
            (components.length ? '<div class="mvqa-group">Components · this site</div>' +
              components.map(row).join('') : '')
          : '<div class="mvqa-none">Nothing on this site matches that.</div>') +
      '</div>' +
      '<div class="mvqa-foot"><span>' + state.slots.length + ' in the bar · ' + list.length + ' of ' +
        catalog().length + ' shown</span>' +
        '<button type="button" class="mvqa-done" data-sheet-close>Done</button></div>' +
      '</div>';
  }

  /* ── Placement ────────────────────────────────────────────────────────
     The bar belongs over the canvas, not over the Bricks panel, so it is
     centred on the canvas frame when there is one and on the window when
     there is not. */
  function canvasRect() {
    var frame = document.getElementById('bricks-builder-iframe') ||
      document.getElementById('brx-iframe') ||
      document.querySelector('iframe#bricks-builder-iframe, iframe.bricks-builder-iframe');
    if (frame && frame.getBoundingClientRect) {
      var rect = frame.getBoundingClientRect();
      if (rect && rect.width > 120) return rect;
    }
    return null;
  }
  function place() {
    if (!root) return;
    var rect = canvasRect();
    var centre = rect ? rect.left + (rect.width / 2) : (window.innerWidth / 2);
    // Through a custom property, not `style.left`: the stylesheet has to say
    // !important to survive Bricks, and !important beats an inline value.
    root.style.setProperty('--mvqa-left', Math.round(centre) + 'px');
  }

  /* ── Render ───────────────────────────────────────────────────────────── */
  function ensureRoot() {
    if (root && root.isConnected) return root;
    root = document.createElement('div');
    root.className = 'mvqa-root';
    root.setAttribute('role', 'toolbar');
    root.setAttribute('aria-label', 'Quick add');
    document.body.appendChild(root);
    return root;
  }
  function render() {
    if (!state.enabled) {
      if (root && root.parentNode) root.parentNode.removeChild(root);
      root = null;
      return;
    }
    ensureRoot();
    var caret = null;
    var open = root.querySelector('.mvqa-find');
    if (open) caret = { value: open.value, start: open.selectionStart };

    root.innerHTML =
      (state.sheet ? sheetHtml() : '') +
      '<div class="mvqa-bar' + (state.arranging ? ' is-arranging' : '') + '">' + barHtml() + '</div>';
    place();

    // Rebuilding the sheet must not take the caret away mid-word.
    if (caret) {
      var field = root.querySelector('.mvqa-find');
      if (field) {
        field.focus();
        try { field.setSelectionRange(caret.start, caret.start); } catch (e) {}
      }
    }
  }

  /* ── Inserting ────────────────────────────────────────────────────────── */
  function toast(message, type) {
    try {
      if (window.MimamsBarToast && typeof window.MimamsBarToast.show === 'function') {
        window.MimamsBarToast.show(message, type || 'info');
        return;
      }
    } catch (e) {}
    log('quick add: ' + message);
  }
  function insert(key) {
    var api = adapter();
    if (!api) { toast('Bricks is not ready yet.', 'error'); return; }
    var item = byKey(key);
    if (item.missing) {
      toast(item.label + ' is no longer registered on this site.', 'error');
      return;
    }
    var result;
    try {
      result = item.kind === 'component'
        ? api.addBricksComponent(item.config || { componentId: item.componentId }, {})
        : api.addBricksElement(item.name, {});
    } catch (e) {
      log('quick add: insert threw', e);
      result = { ok: false, reason: 'threw' };
    }
    if (result && result.ok) {
      toast(item.label + ' added. Save in Bricks to keep it.', 'success');
    } else {
      toast('Could not add ' + item.label + ((result && result.reason) ? ' (' + result.reason + ')' : '') + '.', 'error');
    }
  }

  /* ── Events ───────────────────────────────────────────────────────────── */
  function closest(target, selector) {
    return target && target.closest ? target.closest(selector) : null;
  }
  document.addEventListener('click', function (event) {
    if (!state.enabled || !root) return;
    var inside = closest(event.target, '.mvqa-root');
    if (!inside) {
      if (state.sheet || state.arranging) {
        state.sheet = false;
        state.arranging = false;
        state.lifted = null;
        render();
      }
      return;
    }

    if (closest(event.target, '[data-sheet]')) {
      state.sheet = !state.sheet;
      state.query = '';
      state.arranging = false;
      state.lifted = null;
      render();
      return;
    }
    if (closest(event.target, '[data-sheet-close]')) {
      state.sheet = false;
      render();
      return;
    }
    if (closest(event.target, '[data-arrange]')) {
      state.arranging = true;
      state.sheet = false;
      state.lifted = null;
      render();
      return;
    }
    if (closest(event.target, '[data-arrange-done]')) {
      state.arranging = false;
      state.lifted = null;
      render();
      return;
    }

    var pick = closest(event.target, '[data-pick]');
    if (pick) {
      var key = pick.getAttribute('data-key') || pick.dataset.pick;
      var at = state.slots.indexOf(key);
      if (at !== -1) state.slots.splice(at, 1);
      else state.slots.push(key);           // a new pick lands at the end
      write();
      render();
      return;
    }

    var gap = closest(event.target, '[data-gap]');
    if (gap && state.lifted) {
      var to = parseInt(gap.getAttribute('data-gap'), 10) || 0;
      var from = state.slots.indexOf(state.lifted);
      if (from !== -1) {
        var next = state.slots.slice();
        next.splice(from, 1);
        if (to > from) to -= 1;
        next.splice(to, 0, state.lifted);
        state.slots = next;
        write();
      }
      state.lifted = null;
      render();
      return;
    }

    var slot = closest(event.target, '.mvqa-slot');
    if (slot) {
      var slotKey = slot.getAttribute('data-key');
      if (state.arranging) {
        state.lifted = state.lifted === slotKey ? null : slotKey;
        render();
      } else {
        insert(slotKey);
      }
    }
  }, true);

  document.addEventListener('input', function (event) {
    if (!root || !event.target || !event.target.classList) return;
    if (!event.target.classList.contains('mvqa-find')) return;
    state.query = String(event.target.value || '').trim();
    render();
  });

  document.addEventListener('keydown', function (event) {
    if (!state.enabled || event.key !== 'Escape') return;
    if (!state.sheet && !state.arranging) return;
    state.sheet = false;
    state.arranging = false;
    state.lifted = null;
    render();
  });

  window.addEventListener('resize', place);

  // MV's settings panel lives in the same window; when the switch moves there,
  // the bar appears or leaves without a reload.
  window.addEventListener('ve-quick-add-changed', function (event) {
    state.enabled = !!(event && event.detail);
    render();
  });

  /* ── Start ────────────────────────────────────────────────────────────── */
  function boot() {
    read();
    render();
    // Bricks fills window.bricksData after its own boot; the first catalog
    // read that succeeds is the one that sticks.
    var tries = 0;
    var timer = window.setInterval(function () {
      tries += 1;
      if (catalog({ fresh: true }).length || tries > 24) {
        window.clearInterval(timer);
        if (state.enabled) render();
      }
    }, 250);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.MimamsBarQuickAdd = {
    render: render,
    state: state,
    setEnabled: function (value) { state.enabled = !!value; render(); }
  };
})();
