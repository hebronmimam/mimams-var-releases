<?php
/**
 * Workspaces module registrar.
 *
 * Direction C ("The Desk") from
 * docs/mocks/tools/2026-09-04-workspaces-desk.html, built against
 * docs/MV-Workspace-First-Release-Deploy-Handoff-v5.md (v6) and
 * docs/BRICKS-WORKSPACE-STORAGE-AUDIT.md.
 *
 * SLICE 3 — the record, structural shadows, and a private preview of one.
 *
 * What this ships: a workspace exists, is named, and is dated against the Live
 * state it started from. It can hold Bricks pages and templates, each shadowed
 * as its own private post that Bricks edits in place of the live one.
 *
 * What this deliberately does NOT ship, and why it is still safe:
 *   - no `bricks_*` site option is read or written, so global classes,
 *     variables and theme styles are untouched and NOT isolated;
 *   - no publish, no release, no rollback;
 *   - no runtime resolver: a preview resolves a STRUCTURAL object to its shadow
 *     and nothing else, because runtime families have no workspace state yet.
 *
 * The preview added in slice 3 needs a valid token AND a user who could have
 * edited the object anyway. §18 allows that: a shareable link for logged-out
 * reviewers "is not required for the first technical proof". It makes "public
 * visitors receive Live state" true by construction rather than by a rule that
 * has to be got right, and a leaked link is worth nothing on its own.
 *
 * The live post is read when a shadow is created and never written. The shadow
 * is a WordPress draft, which WordPress itself keeps out of public queries with
 * no help from MV - so the isolation survives MV being deactivated or deleted,
 * as §102 requires. That is §100.1.a structural isolation, and it is the only
 * class this slice may claim.
 *
 * Registration mirrors MimamsBarModule and RecoveryModule: the file is inert
 * until variable-engine.php calls init(), and it self-gates on capability.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspacesModule {

    public const VERSION = '0.12.0-slice12';

    /** Ordered load list — dependencies first. */
    private const FILES = [
        'app/WorkspaceStore.php',
        'app/WorkspaceObjectMap.php',
        'app/BricksPageAdapter.php',
        'app/WorkspaceSnapshot.php',
        'app/WorkspaceRelease.php',
        'app/WorkspaceJournal.php',
        'app/WorkspacePublish.php',
        'app/WorkspaceRollback.php',
        'app/WorkspaceRuntime.php',
        'app/WorkspaceFingerprint.php',
        'app/WorkspaceCss.php',
        'app/WorkspaceDependencies.php',
        'app/WorkspacePreview.php',
        'app/WorkspaceLifecycle.php',
        'app/WorkspacesController.php',
    ];

    /** @var bool */
    private static $booted = false;

    /**
     * @param \VE\API\Routes|null $routes Passed so the module reuses MV's
     *                                    existing permission callbacks rather
     *                                    than inventing a second model.
     */
    public static function init( $routes = null ): void {
        if ( self::$booted ) {
            return;
        }
        self::$booted = true;

        $dir = __DIR__ . '/';
        foreach ( self::FILES as $file ) {
            $path = $dir . $file;
            if ( is_readable( $path ) ) {
                require_once $path;
            }
        }

        if ( ! class_exists( __NAMESPACE__ . '\WorkspacesController' ) ) {
            return;
        }

        ( new WorkspacesController( $routes ) )->register();

        /* SLICE 7. The runtime overlay, registered here because here is inside
           `plugins_loaded` - and core's own wp-settings.php puts plugins at 593,
           `plugins_loaded` at 641 and THEMES at 752. Bricks is a theme, so a
           filter added here is guaranteed to precede Bricks constructing its
           Database and caching the globals into a static that no later filter
           could reach.

           Registered early, resolved late: WorkspaceRuntime answers "no
           session" until `init`, because deciding who the current user is on
           `plugins_loaded` would settle it before other plugins have had their
           say on `determine_current_user`. A request that cannot know who it is
           serves LIVE. */
        if ( class_exists( __NAMESPACE__ . '\WorkspaceRuntime' ) ) {
            WorkspaceRuntime::register();
        }

        /* SLICE 8. The repair contract, §100.1.b.

           Registered here but ACTING on `init`, and the difference matters: the
           overlay has to be in place before Bricks reads anything, whereas an
           inspection needs to know who is asking, which nothing can answer this
           early. So this call only adds the hook.

           It is also deliberately not tied to the activation hook. §92 says no
           lifecycle cleanup may depend on the deactivation hook having been
           called successfully, and the mirror image is just as true: a plugin
           directory that was deleted and restored fires no activation hook at
           all, and that is one of the exact ways the leak this slice repairs
           gets created. So the inspection runs from an ordinary request. */
        if ( class_exists( __NAMESPACE__ . '\WorkspaceFingerprint' ) ) {
            WorkspaceFingerprint::register();
        }

        /* SLICE 10. File CSS-loading mode.

           Registered here, acting on `init` at 21 - after the fingerprint, and
           for the same reason both wait: neither can be answered before the
           current user is settled. Bricks has set `Assets::$css_dir` in its own
           constructor by then, because the theme loads at wp-settings.php:752
           and `init` is at 790, and nothing reads the directory until
           `wp_enqueue_scripts`. */
        if ( class_exists( __NAMESPACE__ . '\WorkspaceCss' ) ) {
            WorkspaceCss::register();
        }

        /* Preview links are redeemed on the FRONT END, not through REST, because
           REST cookie authentication cannot serve a link a person opens in a
           browser - see WorkspacePreview::url() for the two ways it fails.
           `template_redirect` is early enough that nothing has rendered and late
           enough that the current user is resolved from the ordinary login
           cookie, which is all this needs. */
        if ( class_exists( __NAMESPACE__ . '\WorkspacePreview' ) ) {
            add_action( 'template_redirect', [ WorkspacePreview::class, 'handle_request' ], 0 );
        }
    }

    /**
     * Whether the module is switched off in MV settings, mirroring how the other
     * modules gate themselves. Unknown settings shape means "on" — a module that
     * disappears because an option was reshaped is worse than one that stays.
     */
    public static function is_disabled(): bool {
        $settings = get_option( 've_settings', [] );
        if ( ! is_array( $settings ) ) {
            return false;
        }
        $off = isset( $settings['deactivated_tools'] ) ? $settings['deactivated_tools'] : [];
        if ( is_array( $off ) && in_array( 'workspaces', $off, true ) ) {
            return true;
        }

        /* R21. Settings had no Workspaces card at all, so this only ever read the
         * legacy global list. The card writes the per-SURFACE lists like every
         * other module, and this has to answer to them or turning it off in both
         * places would leave the REST layer running.
         *
         * Off on BOTH surfaces, not either: a request that is neither admin nor
         * builder - a preview link, a cron, a REST call from somewhere else - has
         * no surface to be judged against, and hiding the panel in the builder is
         * not the same instruction as switching the module off. Panels hide
         * per-surface in the panel; the module goes off when it is off
         * everywhere. */
        $surfaces = isset( $settings['deactivated_tool_surfaces'] ) ? $settings['deactivated_tool_surfaces'] : [];
        if ( ! is_array( $surfaces ) ) {
            return false;
        }
        $admin   = isset( $surfaces['admin'] ) && is_array( $surfaces['admin'] ) ? $surfaces['admin'] : [];
        $builder = isset( $surfaces['builder'] ) && is_array( $surfaces['builder'] ) ? $surfaces['builder'] : [];

        return in_array( 'workspaces', $admin, true ) && in_array( 'workspaces', $builder, true );
    }
}
