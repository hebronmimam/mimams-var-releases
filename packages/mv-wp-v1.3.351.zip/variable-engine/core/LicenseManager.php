<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

class LicenseManager {

    private const OPTION = 've_license';

    public function status(): array {
        return $this->public_status( $this->license() );
    }

    public function activate( string $key ): array {
        $key = trim( sanitize_text_field( $key ) );
        if ( '' === $key ) {
            return $this->save_status( [
                'key'     => '',
                'status'  => 'inactive',
                'message' => 'Enter a license key to activate.',
            ] );
        }

        $settings = $this->settings();
        $server   = defined( 'VE_LICENSE_SERVER_URL' ) && VE_LICENSE_SERVER_URL ? (string) VE_LICENSE_SERVER_URL : trim( (string) ( $settings['license_server_url'] ?? '' ) );

        if ( '' === $server ) {
            return $this->save_status( [
                'key'          => $key,
                'status'       => 'pending',
                'message'      => 'License key saved. Add a license server URL when validation is ready.',
                'last_checked' => current_time( 'mysql' ),
                'site_url'     => home_url(),
            ] );
        }

        return $this->remote_check( $server, $key, 'activate' );
    }

    public function check(): array {
        $license = $this->license();
        $key     = (string) ( $license['key'] ?? '' );
        if ( '' === $key ) {
            return $this->save_status( [
                'status'  => 'inactive',
                'message' => 'No license key saved.',
            ] );
        }

        $settings = $this->settings();
        $server   = defined( 'VE_LICENSE_SERVER_URL' ) && VE_LICENSE_SERVER_URL ? (string) VE_LICENSE_SERVER_URL : trim( (string) ( $settings['license_server_url'] ?? '' ) );
        if ( '' === $server ) {
            return $this->save_status( array_merge( $license, [
                'status'       => 'pending',
                'message'      => 'License key saved. Add a license server URL when validation is ready.',
                'last_checked' => current_time( 'mysql' ),
                'site_url'     => home_url(),
            ] ) );
        }

        return $this->remote_check( $server, $key, 'check' );
    }

    public function deactivate(): array {
        $license = $this->license();
        $key     = (string) ( $license['key'] ?? '' );
        $settings = $this->settings();
        $server   = defined( 'VE_LICENSE_SERVER_URL' ) && VE_LICENSE_SERVER_URL ? (string) VE_LICENSE_SERVER_URL : trim( (string) ( $settings['license_server_url'] ?? '' ) );

        if ( '' !== $key && '' !== $server ) {
            $this->remote_check( $server, $key, 'deactivate', false );
        }

        return $this->save_status( [
            'key'     => '',
            'status'  => 'inactive',
            'message' => 'License disconnected from this site.',
        ] );
    }

    public function is_active(): bool {
        return 'active' === (string) ( $this->license()['status'] ?? '' );
    }

    private function remote_check( string $server, string $key, string $action, bool $save_errors = true ): array {
        $response = wp_remote_post( $server, [
            'timeout' => 15,
            'headers' => [
                'Accept'       => 'application/json',
                'Content-Type' => 'application/json',
                'User-Agent'   => "Mimam's Var - WP/" . VE_VERSION . '; ' . home_url(),
            ],
            'body' => wp_json_encode( [
                'action'      => $action,
                'license_key' => $key,
                'site_url'    => home_url(),
                'version'     => VE_VERSION,
            ] ),
        ] );

        if ( is_wp_error( $response ) ) {
            $status = [
                'key'          => $key,
                'status'       => 'error',
                'message'      => $response->get_error_message(),
                'last_checked' => current_time( 'mysql' ),
                'site_url'     => home_url(),
            ];
            return $save_errors ? $this->save_status( $status ) : $this->public_status( $status );
        }

        $body = json_decode( wp_remote_retrieve_body( $response ), true );
        if ( ! is_array( $body ) ) {
            $body = [];
        }

        $active = ! empty( $body['active'] ) || 'active' === (string) ( $body['status'] ?? '' ) || ! empty( $body['success'] );
        return $this->save_status( [
            'key'            => $key,
            'status'         => $active ? 'active' : 'invalid',
            'plan'           => sanitize_text_field( (string) ( $body['plan'] ?? '' ) ),
            'expires'        => sanitize_text_field( (string) ( $body['expires'] ?? '' ) ),
            'customer_email' => sanitize_email( (string) ( $body['customer_email'] ?? '' ) ),
            'message'        => sanitize_text_field( (string) ( $body['message'] ?? ( $active ? 'License active.' : 'License could not be validated.' ) ) ),
            'last_checked'   => current_time( 'mysql' ),
            'site_url'       => home_url(),
        ] );
    }

    private function save_status( array $patch ): array {
        $license = array_merge( $this->license(), $patch );
        update_option( self::OPTION, $license, false );
        return $this->public_status( $license );
    }

    private function license(): array {
        $defaults = [
            'key'            => '',
            'status'         => 'inactive',
            'plan'           => '',
            'expires'        => '',
            'customer_email' => '',
            'message'        => 'No license key saved.',
            'last_checked'   => '',
            'site_url'       => '',
        ];

        $license = get_option( self::OPTION, [] );
        return wp_parse_args( is_array( $license ) ? $license : [], $defaults );
    }

    private function settings(): array {
        $settings = get_option( 've_settings', [] );
        return is_array( $settings ) ? $settings : [];
    }

    private function public_status( array $license ): array {
        $key = (string) ( $license['key'] ?? '' );
        $masked = '';
        if ( '' !== $key ) {
            $masked = strlen( $key ) > 8 ? substr( $key, 0, 4 ) . '...' . substr( $key, -4 ) : 'saved';
        }

        return [
            'configured'     => '' !== $key,
            'key_masked'     => $masked,
            'status'         => sanitize_text_field( (string) ( $license['status'] ?? 'inactive' ) ),
            'active'         => 'active' === (string) ( $license['status'] ?? '' ),
            'plan'           => sanitize_text_field( (string) ( $license['plan'] ?? '' ) ),
            'expires'        => sanitize_text_field( (string) ( $license['expires'] ?? '' ) ),
            'customer_email' => sanitize_email( (string) ( $license['customer_email'] ?? '' ) ),
            'message'        => sanitize_text_field( (string) ( $license['message'] ?? '' ) ),
            'last_checked'   => sanitize_text_field( (string) ( $license['last_checked'] ?? '' ) ),
            'site_url'       => esc_url_raw( (string) ( $license['site_url'] ?? '' ) ),
        ];
    }
}
