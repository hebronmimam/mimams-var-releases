<?php

namespace VE\API;

defined( 'ABSPATH' ) || exit;

class Routes {

    public function register(): void {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
        add_action( 'wp_ajax_ve_refresh_rest_nonce', [ $this, 'refresh_rest_nonce' ] );
        // Capture the admin menu on every wp-admin load so the Everything palette can
        // navigate to any admin destination (settings, tools, ACF, plugin pages, Bricks)
        // without rebuilding the menu inside a REST request. Runs last so plugin menus exist.
        add_action( 'admin_menu', [ $this, 'capture_admin_menu' ], PHP_INT_MAX );
    }

    // Snapshot $menu/$submenu (title, capability, slug, parent) into an option for the
    // Everything index endpoint. Cheap; only writes when the snapshot actually changes.
    public function capture_admin_menu(): void {
        global $menu, $submenu;
        if ( ! is_array( $menu ) ) {
            return;
        }
        $clean = static function ( $raw ) {
            $raw = (string) preg_replace( '/<span[^>]*>.*?<\/span>/is', '', (string) $raw );
            return trim( wp_strip_all_tags( $raw ) );
        };
        $titles = [];
        foreach ( $menu as $m ) {
            if ( isset( $m[2] ) ) {
                $titles[ (string) $m[2] ] = $clean( $m[0] ?? '' );
            }
        }
        $items = [];
        foreach ( $menu as $m ) {
            if ( empty( $m[2] ) ) {
                continue;
            }
            $title = $clean( $m[0] ?? '' );
            if ( $title === '' || strpos( (string) $m[2], 'separator' ) === 0 ) {
                continue;
            }
            $items[] = [ 't' => $title, 'c' => (string) ( $m[1] ?? 'read' ), 's' => (string) $m[2], 'pt' => '' ];
        }
        if ( is_array( $submenu ) ) {
            foreach ( $submenu as $parent => $subs ) {
                $ptitle = $titles[ (string) $parent ] ?? '';
                foreach ( (array) $subs as $s ) {
                    if ( empty( $s[2] ) ) {
                        continue;
                    }
                    $title = $clean( $s[0] ?? '' );
                    if ( $title === '' ) {
                        continue;
                    }
                    $items[] = [ 't' => $title, 'c' => (string) ( $s[1] ?? 'read' ), 's' => (string) $s[2], 'pt' => $ptitle, 'parent' => (string) $parent ];
                }
            }
        }
        $current = get_option( 've_everything_admin_menu', null );
        if ( $current !== $items ) {
            update_option( 've_everything_admin_menu', $items, false );
        }
    }

    // GET everything-index — admin destinations (cap-filtered per current user) + plugins,
    // split into settings / plugins / bricks buckets for the Everything scopes.
    public function everything_index(): \WP_REST_Response {
        $menu     = get_option( 've_everything_admin_menu', [] );
        $settings = [];
        $bricks   = [];
        if ( is_array( $menu ) ) {
            foreach ( $menu as $it ) {
                $cap = $it['c'] ?? 'read';
                if ( ! current_user_can( $cap ) ) {
                    continue;
                }
                $slug  = (string) ( $it['s'] ?? '' );
                $url   = ( strpos( $slug, '://' ) !== false )
                    ? $slug
                    : ( ( strpos( $slug, '.php' ) !== false )
                        ? admin_url( $slug )
                        : admin_url( 'admin.php?page=' . $slug ) );
                $ptitle = (string) ( $it['pt'] ?? '' );
                $title  = ( $ptitle !== '' && $ptitle !== $it['t'] ) ? $ptitle . ' ▸ ' . $it['t'] : $it['t'];
                if ( stripos( $slug . ' ' . $title, 'bricks' ) !== false ) {
                    $bricks[] = [ 'title' => $title, 'url' => $url, 'cat' => 'bricks' ];
                } else {
                    $settings[] = [ 'title' => $title, 'url' => $url, 'cat' => 'setting' ];
                }
            }
        }
        $plugins = [];
        if ( current_user_can( 'activate_plugins' ) ) {
            if ( ! function_exists( 'get_plugins' ) ) {
                require_once ABSPATH . 'wp-admin/includes/plugin.php';
            }
            foreach ( get_plugins() as $file => $data ) {
                $plugins[] = [
                    'title'  => (string) ( $data['Name'] ?? $file ),
                    'url'    => admin_url( 'plugins.php' ),
                    'active' => is_plugin_active( $file ),
                    'cat'    => 'plugin',
                ];
            }
        }
        // Bricks templates are content, not menu entries — list them so Everything can
        // jump straight into a header/footer/single template.
        if ( post_type_exists( 'bricks_template' ) && current_user_can( 'edit_posts' ) ) {
            $templates = get_posts( [
                'post_type'      => 'bricks_template',
                'post_status'    => [ 'publish', 'draft' ],
                'posts_per_page' => 100,
                'orderby'        => 'title',
                'order'          => 'ASC',
            ] );
            foreach ( $templates as $template ) {
                $type = (string) get_post_meta( $template->ID, '_bricks_template_type', true );
                $bricks[] = [
                    'title' => get_the_title( $template ) . ( $type ? ' — ' . ucfirst( $type ) : '' ) . ' template',
                    'url'   => add_query_arg( 'bricks', 'run', get_permalink( $template ) ),
                    'id'    => (int) $template->ID,
                    'cat'   => 'bricks',
                ];
            }
        }

        return new \WP_REST_Response( [ 'settings' => $settings, 'plugins' => $plugins, 'bricks' => $bricks ], 200 );
    }

    public function refresh_rest_nonce(): void {
        if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
            wp_send_json_error( [ 'message' => 'Your WordPress session must be refreshed.' ], 403 );
        }

        wp_send_json_success( [ 'nonce' => wp_create_nonce( 'wp_rest' ) ] );
    }

    private function sanitize_saved_attributes( $raw ): array {
        if ( ! is_array( $raw ) ) {
            return [];
        }

        $saved = [];
        foreach ( array_slice( $raw, 0, 100 ) as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            $name = trim( sanitize_text_field( (string) ( $item['name'] ?? '' ) ) );
            if ( '' === $name || ! preg_match( '/^[A-Za-z_:][A-Za-z0-9:._-]*$/', $name ) ) {
                continue;
            }
            /* A name holds several values, newest first, and `value` is always
               the first of them so every older reader still works. This used to
               keep one value per name and REPLACE it, which is how starring a
               second value for the same name lost the first (R9). */
            $values = [];
            $candidates = [ $item['value'] ?? '' ];
            if ( isset( $item['values'] ) && is_array( $item['values'] ) ) {
                $candidates = array_merge( $candidates, $item['values'] );
            }
            foreach ( $candidates as $candidate ) {
                if ( is_array( $candidate ) || is_object( $candidate ) ) {
                    continue;
                }
                $clean = substr( sanitize_textarea_field( (string) $candidate ), 0, 500 );
                if ( ! in_array( $clean, $values, true ) && count( $values ) < 20 ) {
                    $values[] = $clean;
                }
            }
            /* A blank carries no information once a real value is known.
               A client sending { name, values: ['970'] } with no `value`
               beside it landed here as [ '', '970' ] - and `value`, which
               is what every reader keys on, became the blank. That is how
               a starred attribute stopped being findable by its own value. */
            if ( count( $values ) > 1 ) {
                $values = array_values( array_filter( $values, static function ( $v ) {
                    return '' !== $v;
                } ) );
            }
            if ( ! $values ) {
                $values = [ '' ];
            }

            $existing = null;
            foreach ( $saved as $index => $current ) {
                if ( $current['name'] === $name ) {
                    $existing = $index;
                    break;
                }
            }
            if ( null === $existing ) {
                $saved[] = [
                    'name'   => $name,
                    'value'  => $values[0],
                    'values' => $values,
                ];
            } else {
                // Merged, not overwritten - overwriting is what lost the values.
                $merged = $saved[ $existing ]['values'];
                foreach ( $values as $candidate ) {
                    if ( ! in_array( $candidate, $merged, true ) && count( $merged ) < 20 ) {
                        $merged[] = $candidate;
                    }
                }
                if ( count( $merged ) > 1 ) {
                    $merged = array_values( array_filter( $merged, static function ( $v ) {
                        return '' !== $v;
                    } ) );
                }
                $saved[ $existing ] = [
                    'name'   => $name,
                    'value'  => $merged[0],
                    'values' => $merged,
                ];
            }
        }

        return array_values( $saved );
    }

    /* How long MV's own callback took, on every MV response.
     *
     * The owner's diagnostics said pre_route_ms: 337 - WordPress, nine active
     * plugins, the theme and REST init all boot in a third of a second. Yet
     * individual reads were coming back at 2,900ms, and three unrelated routes
     * all at almost exactly 2,900ms, which is the signature of requests waiting
     * on each other rather than of three slow handlers.
     *
     * Guessing between those two is how the last five builds would have gone,
     * so every MV response now carries the time its own callback took. Total
     * minus callback minus boot is time the request spent waiting.
     *
     * Scoped to MV's namespace only. It never touches another plugin's routes,
     * and it adds one header rather than changing any payload.
     */
    private function register_route_timing(): void {
        $started = null;
        add_filter( 'rest_dispatch_request', function ( $result, $request, $route ) use ( &$started ) {
            if ( 0 === strpos( (string) $route, '/' . VE_API_NAMESPACE ) ) {
                $started = microtime( true );
            }
            return $result;
        }, 10, 3 );
        add_filter( 'rest_post_dispatch', function ( $response, $server, $request ) use ( &$started ) {
            if ( null === $started ) {
                return $response;
            }
            $route = (string) $request->get_route();
            if ( 0 !== strpos( $route, '/' . VE_API_NAMESPACE ) ) {
                return $response;
            }
            $callbackMs = (int) round( ( microtime( true ) - $started ) * 1000 );
            $bootMs     = isset( $_SERVER['REQUEST_TIME_FLOAT'] )
                ? (int) round( ( $started - (float) $_SERVER['REQUEST_TIME_FLOAT'] ) * 1000 )
                : -1;
            $started = null;
            if ( $response instanceof \WP_REST_Response ) {
                $response->header( 'X-MV-Callback-Ms', (string) $callbackMs );
                $response->header( 'X-MV-Boot-Ms', (string) $bootMs );
                /* How big the answer is. Two of the owner's sites, same MV build
                 * and the same route, reported `server 445ms` and `server 8282ms`
                 * - eight seconds that is neither this callback (0-17ms) nor
                 * WordPress booting (~270ms), and therefore entirely invisible
                 * from here. Everything after rest_post_dispatch is unmeasured:
                 * serialisation, other plugins' response filters, output, gzip
                 * and the wire.
                 *
                 * Size is the cheapest cut through that. A payload that is large
                 * on the slow site and small on the fast one makes it transfer;
                 * the same size on both makes it the host. Measured here rather
                 * than guessed at for a third build running. */
                $bytes = strlen( (string) wp_json_encode( $response->get_data() ) );
                $response->header( 'X-MV-Bytes', (string) $bytes );
            }
            return $response;
        }, 10, 3 );
    }

    public function register_routes(): void {
        $this->register_route_timing();
        $ns         = VE_API_NAMESPACE;
        $controller = new VariableController();

        /* ── One request for the first useful screen ─────────────────
         * The owner's veOpenReport showed 35 calls and 42 seconds of server
         * time for one session of panel switching, with a single read taking
         * 5,598ms. When the expensive part is WordPress starting up rather
         * than the query, the number of ROUND TRIPS is the number that
         * matters: six independent REST reads pay for six bootstraps.
         *
         * This is deliberately not "everything". It is the small, first-screen
         * shape of each family - lists and counts, never a media library, never
         * a post table, never a diagnostic scan. Heavy and destructive work
         * stays where it was: on demand, in its own route.
         *
         * Each part is wrapped, because one family failing must not cost the
         * caller the other eight - the whole point is that this replaces
         * several requests, and it cannot be more fragile than they were.
         */
        register_rest_route( $ns, '/workspace/bootstrap', [
            'methods'             => 'GET',
            'callback'            => function ( $request ) {
                $started = microtime( true );
                $out     = [
                    'schema'       => 3,
                    'generated_at' => time(),
                ];

                $part = static function ( callable $fn ) {
                    try {
                        return $fn();
                    } catch ( \Throwable $e ) {
                        return null;
                    }
                };

                $settings = $part( static function () {
                    $stored = get_option( 've_settings', [] );
                    return is_array( $stored ) ? $stored : [];
                } );
                if ( null !== $settings ) {
                    $out['settings'] = $settings;
                }

                $out['user-preferences'] = $part( function () {
                    $prefs = get_user_meta( get_current_user_id(), 've_user_preferences', true );
                    return is_array( $prefs ) ? $prefs : [];
                } );

                /* Code Studio's sheet list: names and ids, not the code. The
                 * lane needs the list to draw; it fetches a sheet's body when
                 * you select one. */
                /* C72. This read `get_option('ve_code_studio_items')`. Nothing has
                   ever written that name - CodeItemManager stores under
                   `ve_code_items`, and stores `[ 'items' => [...] ]` rather than a
                   bare list, so even the right name read the wrong shape. The
                   prefetched answer was therefore ALWAYS an empty list, and the
                   panel could hold that empty answer as fresh for 30 seconds.
                   Reading through the manager is what stops the two drifting: one
                   place knows where the items live. */
                $out['code-studio/items'] = $part( function () use ( $request ) {
                    return $this->code_studio_items( $request )->get_data();
                } );

                /* Same rule: this read the option itself and skipped the
                   sanitising the route does, so a prefetched tag list could
                   differ from the one the same panel gets a moment later. */
                $out['bricks-settings/custom-tags'] = $part( function () {
                    return $this->get_bricks_custom_tags()->get_data();
                } );

                /* This read `get_option('ve_font_families')`. Nothing has ever
                   written that name, and the real answer is a list of Bricks font
                   POSTS carrying `available`, `can_manage` and a `bricks_url` -
                   so the prefetched answer was always an empty list with no
                   `available` in it, and the panel read that as "Bricks Custom
                   Fonts is unavailable" until something re-fetched.

                   The owner: "that always happens, I have to refresh before I see
                   my fonts."

                   Exactly the fault C72 found in `code-studio/items` one part
                   above, and it has the same remedy: ask the route that owns the
                   answer, so a prefetch cannot drift from what it is prefetching. */
                $out['font-manager/families'] = $part( function () {
                    return $this->get_font_manager_families()->get_data();
                } );

                $out['generated_ms'] = (int) round( ( microtime( true ) - $started ) * 1000 );

                return rest_ensure_response( array_filter(
                    $out,
                    static function ( $value ) {
                        return null !== $value;
                    }
                ) );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        /* ── Where the time goes ─────────────────────────────────────
         * "Do not claim the server is slow without finding which half is
         * slow." REQUEST_TIME_FLOAT is when PHP began; by the time a route
         * callback runs, WordPress has already booted, loaded every plugin and
         * initialised REST. The difference between those two is somebody
         * else's five seconds or ours, and they need completely different
         * fixes.
         */
        register_rest_route( $ns, '/diagnostics/request-timing', [
            'methods'             => 'GET',
            'callback'            => static function () {
                $now      = microtime( true );
                $start    = isset( $_SERVER['REQUEST_TIME_FLOAT'] ) ? (float) $_SERVER['REQUEST_TIME_FLOAT'] : $now;
                $preRoute = (int) round( ( $now - $start ) * 1000 );

                $callbackStart = microtime( true );
                $probe         = get_option( 've_settings', [] );
                $optionMs      = (int) round( ( microtime( true ) - $callbackStart ) * 1000 );

                return rest_ensure_response( [
                    /* Everything before MV's code ran: WordPress core, every
                     * active plugin, the theme, and REST initialisation. */
                    'pre_route_ms'   => $preRoute,
                    /* One representative option read, so a slow database shows
                     * up as itself rather than as "the plugin". */
                    'option_read_ms' => $optionMs,
                    'plugins_active' => count( (array) get_option( 'active_plugins', [] ) ),
                    'object_cache'   => wp_using_ext_object_cache() ? 'external' : 'none',
                    'php'            => PHP_VERSION,
                    'settings_bytes' => strlen( (string) wp_json_encode( $probe ) ),
                ] );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        // ── Variables CRUD ──────────────────────────────────────────
        register_rest_route( $ns, '/variables', [
            [
                'methods'             => 'GET',
                'callback'            => [ $controller, 'list_variables' ],
                'permission_callback' => [ $this, 'can_read' ],
                'args'                => [
                    'namespace' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ],
                    'type'      => [ 'type' => 'string', 'enum' => [ 'base', 'generated', 'alias' ] ],
                    'dedupe'    => [ 'type' => 'boolean', 'default' => false ],
                ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $controller, 'create_variable' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/variables/stats', [
            'methods'             => 'GET',
            'callback'            => [ $controller, 'stats_variables' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        // ── ACF content model (Content Studio) ──────────────────────
        register_rest_route( $ns, '/acf/models', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'acf_list_models' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );
        register_rest_route( $ns, '/acf/field-group/(?P<id>\d+)', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'acf_get_field_group' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'PUT',
                'callback'            => [ $this, 'acf_save_field_group' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        // Everything palette index — admin destinations + plugins + Bricks (Phase B).
        register_rest_route( $ns, '/everything-index', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'everything_index' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/variables/cleanup', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'cleanup_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/reorder', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'reorder_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/batch-delete', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'batch_delete_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/reconvert-units', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                $data = $request->get_json_params();
                $unit = sanitize_key( (string) ( $data['unit'] ?? '' ) );
                if ( ! in_array( $unit, [ 'rem10', 'rem16', 'px', 'raw' ], true ) ) {
                    return new \WP_Error( 've_bad_unit', 'Choose a unit: rem10, rem16, px, or raw.', [ 'status' => 400 ] );
                }
                $result = ( new \VE\Core\VariableManager() )->reconvert_units( $unit );
                if ( is_wp_error( $result ) ) {
                    return $result;
                }
                return new \WP_REST_Response( [ 'converted' => (int) $result, 'unit' => $unit ], 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/bricks-settings', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'get_bricks_settings' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'update_bricks_settings' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        /* C26, second half. The capability EDITOR - what is INSIDE a
           capability - as opposed to the matrix, which is about which one each
           role holds. Both are Bricks' own data; neither is a copy of it. */
        register_rest_route( $ns, '/content-studio/import/field-targets', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_studio_import_field_targets' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/bricks-settings/capabilities', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'get_bricks_capabilities' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'update_bricks_capabilities' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/bricks-settings/regenerate-css', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'bricks_regenerate_css' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/bricks-settings/custom-tags', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'get_bricks_custom_tags' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'update_bricks_custom_tags' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

                register_rest_route( $ns, '/bricks-theme-styles', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'get_bricks_theme_styles' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'update_bricks_theme_styles' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/variable-families/preview', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'preview_family_relationships' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variable-families/apply', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'apply_family_relationships' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/(?P<id>\d+)', [
            [
                'methods'             => 'GET',
                'callback'            => [ $controller, 'get_variable' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'PUT',
                'callback'            => [ $controller, 'update_variable' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $controller, 'delete_variable' ],
                'permission_callback' => [ $this, 'can_write' ],
                'args'                => [
                    'force' => [ 'type' => 'boolean', 'default' => false ],
                ],
            ],
        ] );

        register_rest_route( $ns, '/variables/(?P<id>\d+)/rename-preview', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'rename_preview' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/(?P<id>\d+)/usage', [
            'methods'             => 'GET',
            'callback'            => [ $controller, 'usage_variable' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        // ── Organizational variable categories ─────────────────────
        $variable_categories = new VariableCategoryController();
        register_rest_route( $ns, '/variable-categories', [
            [
                'methods'             => 'GET',
                'callback'            => [ $variable_categories, 'list_categories' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $variable_categories, 'create_category' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/variable-categories/(?P<slug>[a-z0-9-]+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $variable_categories, 'update_category' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $variable_categories, 'delete_category' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/variable-categories/(?P<slug>[a-z0-9-]+)/rename', [
            'methods'             => 'POST',
            'callback'            => [ $variable_categories, 'update_category' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/variable-categories/(?P<slug>[a-z0-9-]+)/remove', [
            'methods'             => 'POST',
            'callback'            => [ $variable_categories, 'delete_category' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/variable-categories/variables/move', [
            'methods'             => 'POST',
            'callback'            => [ $variable_categories, 'move_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Themes (legacy /palettes routes remain compatible) ──────
        $palettes = new PaletteController();
        register_rest_route( $ns, '/palettes', [
            [
                'methods'             => 'GET',
                'callback'            => [ $palettes, 'list_palettes' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $palettes, 'create_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/palettes/(?P<slug>[a-z0-9-]+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $palettes, 'update_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $palettes, 'delete_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/palettes/(?P<slug>[a-z0-9-]+)/activate', [
            'methods'             => 'POST',
            'callback'            => [ $palettes, 'activate_palette' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/palettes/(?P<slug>[a-z0-9-]+)/duplicate', [
            'methods'             => 'POST',
            'callback'            => [ $palettes, 'duplicate_palette' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        $themes = new ThemeController();
        register_rest_route( $ns, '/themes', [
            [
                'methods'             => 'GET',
                'callback'            => [ $themes, 'list_themes' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $themes, 'create_theme' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/themes/(?P<slug>[a-z0-9-]+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $themes, 'update_theme' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $themes, 'delete_theme' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/themes/(?P<slug>[a-z0-9-]+)/activate', [
            'methods'             => 'POST',
            'callback'            => [ $themes, 'activate_theme' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/themes/(?P<slug>[a-z0-9-]+)/duplicate', [
            'methods'             => 'POST',
            'callback'            => [ $themes, 'duplicate_theme' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Organizational color palettes ────────────────────────────
        $color_palettes = new ColorPaletteController();
        register_rest_route( $ns, '/color-palettes', [
            [
                'methods'             => 'GET',
                'callback'            => [ $color_palettes, 'list_palettes' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $color_palettes, 'create_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/color-palettes/(?P<id>\d+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $color_palettes, 'update_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $color_palettes, 'delete_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/color-palettes/(?P<id>\d+)/duplicate', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'duplicate_palette' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/color-palettes/(?P<id>\d+)/delete-preview', [
            'methods'             => 'GET',
            'callback'            => [ $color_palettes, 'preview_delete' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/color-palettes/reorder', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'reorder_palettes' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/color-palettes/variables/batch-move', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'batch_move_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/color-palettes/variables/(?P<variable_id>\d+)/move', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'move_variable' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/color-palettes/variables/(?P<variable_id>\d+)/copy', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'copy_variable' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Generators ────────────────────────────────────────────────
        $gen_controller = new GeneratorController();

        register_rest_route( $ns, '/variables/(?P<variable_id>\d+)/generators', [
            [
                'methods'             => 'GET',
                'callback'            => [ $gen_controller, 'list_generators' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $gen_controller, 'attach' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/variables/(?P<variable_id>\d+)/generators/regenerate', [
            'methods'             => 'POST',
            'callback'            => [ $gen_controller, 'regenerate' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/generators/(?P<generator_id>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $gen_controller, 'detach' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Search ──────────────────────────────────────────────────
        register_rest_route( $ns, '/search', [
            'methods'             => 'GET',
            'callback'            => [ $controller, 'search_variables' ],
            'permission_callback' => [ $this, 'can_read' ],
            'args'                => [
                'q'     => [ 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
                'limit' => [ 'type' => 'integer', 'default' => 50 ],
            ],
        ] );

        // ── Settings ────────────────────────────────────────────────
        register_rest_route( $ns, '/settings', [
            [
                'methods'             => 'GET',
                'callback'            => function () {
                    $defaults = [
                        'vw_min'              => 320,
                        'vw_max'              => 1440,
                        'delete_on_uninstall' => false,
                        'update_url'          => \VE\Core\Updater::DEFAULT_FEED_URL,
                        'update_channel'      => 'stable',
                        'auto_update'         => false,
                        'license_server_url'  => '',
                        'deactivated_tools'   => [],
                        'deactivated_tool_surfaces' => [
                            'admin'   => [],
                            'builder' => [],
                        ],
                        'allow_multi_panels'  => false,
                        'quick_add_bar'       => true,
                        'show_all_tab'        => true,
                        'media_replace_wp_library' => false,
                        'media_auto_sync_external_folders' => false,
                        'output_unit'         => 'rem10',
                        'saved_attributes'    => [],
                    ];
                    $settings = get_option( 've_settings', $defaults );
                    $out = wp_parse_args( $settings, $defaults );
                    $out['site_title'] = get_bloginfo( 'name' );
                    $out['license'] = ( new \VE\Core\LicenseManager() )->status();
                    return new \WP_REST_Response( $out, 200 );
                },
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => function ( \WP_REST_Request $request ) {
                    $data = $request->get_json_params();
                    $defaults = [
                        'vw_min'              => 320,
                        'vw_max'              => 1440,
                        'delete_on_uninstall' => false,
                        'update_url'          => \VE\Core\Updater::DEFAULT_FEED_URL,
                        'update_channel'      => 'stable',
                        'auto_update'         => false,
                        'license_server_url'  => '',
                        'deactivated_tools'   => [],
                        'deactivated_tool_surfaces' => [
                            'admin'   => [],
                            'builder' => [],
                        ],
                        'allow_multi_panels'  => false,
                        'quick_add_bar'       => true,
                        'show_all_tab'        => true,
                        'media_replace_wp_library' => false,
                        'media_auto_sync_external_folders' => false,
                        'output_unit'         => 'rem10',
                        'saved_attributes'    => [],
                    ];
                    $previous = get_option( 've_settings', $defaults );
                    $previous_channel = sanitize_key( (string) ( $previous['update_channel'] ?? 'stable' ) );
                    $update_channel = \VE\Core\Updater::sanitize_update_channel(
                        (string) ( $data['update_channel'] ?? $previous_channel ),
                        $previous_channel
                    );
                    $update_url = isset( $data['update_url'] ) ? esc_url_raw( (string) $data['update_url'] ) : (string) ( $previous['update_url'] ?? $defaults['update_url'] );
                    if ( '' === $update_url || \VE\Core\Updater::LEGACY_FEED_URL === $update_url || \VE\Core\Updater::DEFAULT_FEED_URL === $update_url ) {
                        $update_url = \VE\Core\Updater::feed_url_for_channel( $update_channel );
                    }
                    $license_server_url = isset( $data['license_server_url'] ) ? esc_url_raw( (string) $data['license_server_url'] ) : (string) ( $previous['license_server_url'] ?? '' );
                    $deactivated_tools = isset( $data['deactivated_tools'] ) && is_array( $data['deactivated_tools'] )
                        ? array_map( 'sanitize_key', $data['deactivated_tools'] )
                        : ( isset( $previous['deactivated_tools'] ) && is_array( $previous['deactivated_tools'] ) ? array_map( 'sanitize_key', $previous['deactivated_tools'] ) : [] );
                    $surface_data = isset( $data['deactivated_tool_surfaces'] ) && is_array( $data['deactivated_tool_surfaces'] )
                        ? $data['deactivated_tool_surfaces']
                        : ( isset( $previous['deactivated_tool_surfaces'] ) && is_array( $previous['deactivated_tool_surfaces'] ) ? $previous['deactivated_tool_surfaces'] : [] );
                    $deactivated_tool_surfaces = [
                        'admin'   => isset( $surface_data['admin'] ) && is_array( $surface_data['admin'] )
                            ? array_values( array_unique( array_map( 'sanitize_key', $surface_data['admin'] ) ) )
                            : [],
                        'builder' => isset( $surface_data['builder'] ) && is_array( $surface_data['builder'] )
                            ? array_values( array_unique( array_map( 'sanitize_key', $surface_data['builder'] ) ) )
                            : [],
                    ];
                    $surface_patch = isset( $data['deactivated_tool_surface_patch'] ) && is_array( $data['deactivated_tool_surface_patch'] )
                        ? $data['deactivated_tool_surface_patch']
                        : null;
                    if ( $surface_patch ) {
                        // Migrate unresolved legacy choices before applying the
                        // atomic change, then mutate only the requested surface.
                        // This prevents a stale Admin/Builder window from
                        // replacing the other surface's newer module state.
                        foreach ( $deactivated_tools as $legacy_module ) {
                            $has_surface_choice = in_array( $legacy_module, $deactivated_tool_surfaces['admin'], true )
                                || in_array( $legacy_module, $deactivated_tool_surfaces['builder'], true );
                            if ( ! $has_surface_choice ) {
                                $deactivated_tool_surfaces['admin'][] = $legacy_module;
                                $deactivated_tool_surfaces['builder'][] = $legacy_module;
                            }
                        }
                        $deactivated_tools = [];
                        $patch_surface = sanitize_key( (string) ( $surface_patch['surface'] ?? '' ) );
                        $patch_module = sanitize_key( (string) ( $surface_patch['module'] ?? '' ) );
                        if ( in_array( $patch_surface, [ 'admin', 'builder' ], true ) && '' !== $patch_module ) {
                            $deactivated_tool_surfaces[ $patch_surface ] = array_values( array_diff( $deactivated_tool_surfaces[ $patch_surface ], [ $patch_module ] ) );
                            if ( ! empty( $surface_patch['disabled'] ) ) {
                                $deactivated_tool_surfaces[ $patch_surface ][] = $patch_module;
                            }
                        }
                        $deactivated_tool_surfaces['admin'] = array_values( array_unique( $deactivated_tool_surfaces['admin'] ) );
                        $deactivated_tool_surfaces['builder'] = array_values( array_unique( $deactivated_tool_surfaces['builder'] ) );
                    }
                    $saved_attributes = array_key_exists( 'saved_attributes', $data )
                        ? $this->sanitize_saved_attributes( $data['saved_attributes'] )
                        : $this->sanitize_saved_attributes( $previous['saved_attributes'] ?? [] );
                    $settings = [
                        'vw_min'              => isset( $data['vw_min'] ) ? absint( $data['vw_min'] ) : absint( $previous['vw_min'] ?? 320 ),
                        'vw_max'              => isset( $data['vw_max'] ) ? absint( $data['vw_max'] ) : absint( $previous['vw_max'] ?? 1440 ),
                        'delete_on_uninstall' => isset( $data['delete_on_uninstall'] ) ? ! empty( $data['delete_on_uninstall'] ) : ! empty( $previous['delete_on_uninstall'] ),
                        'update_url'          => $update_url,
                        'update_channel'      => $update_channel,
                        'auto_update'         => isset( $data['auto_update'] ) ? ! empty( $data['auto_update'] ) : ! empty( $previous['auto_update'] ),
                        'license_server_url'  => $license_server_url,
                        'deactivated_tools'   => $deactivated_tools,
                        'deactivated_tool_surfaces' => $deactivated_tool_surfaces,
                        'allow_multi_panels'  => isset( $data['allow_multi_panels'] ) ? ! empty( $data['allow_multi_panels'] ) : ! empty( $previous['allow_multi_panels'] ),
                        'quick_add_bar'       => isset( $data['quick_add_bar'] ) ? ! empty( $data['quick_add_bar'] ) : ( isset( $previous['quick_add_bar'] ) ? ! empty( $previous['quick_add_bar'] ) : true ),
                        'show_all_tab'        => isset( $data['show_all_tab'] ) ? ! empty( $data['show_all_tab'] ) : ( isset( $previous['show_all_tab'] ) ? ! empty( $previous['show_all_tab'] ) : true ),
                        'media_replace_wp_library' => isset( $data['media_replace_wp_library'] ) ? ! empty( $data['media_replace_wp_library'] ) : ! empty( $previous['media_replace_wp_library'] ),
                        'media_auto_sync_external_folders' => isset( $data['media_auto_sync_external_folders'] ) ? ! empty( $data['media_auto_sync_external_folders'] ) : ! empty( $previous['media_auto_sync_external_folders'] ),
                        'output_unit'         => ( isset( $data['output_unit'] ) && in_array( $data['output_unit'], [ 'rem10', 'rem16', 'px', 'raw' ], true ) )
                            ? $data['output_unit']
                            : ( ( isset( $previous['output_unit'] ) && in_array( $previous['output_unit'], [ 'rem10', 'rem16', 'px', 'raw' ], true ) ) ? $previous['output_unit'] : 'rem10' ),
                        'saved_attributes'    => $saved_attributes,
                    ];
                    $previous_surfaces = isset( $previous['deactivated_tool_surfaces'] ) && is_array( $previous['deactivated_tool_surfaces'] )
                        ? $previous['deactivated_tool_surfaces']
                        : [];
                    $previous_admin_disabled = isset( $previous_surfaces['admin'] ) && is_array( $previous_surfaces['admin'] )
                        && in_array( 'recovery', $previous_surfaces['admin'], true );
                    $previous_surface_choice = $previous_admin_disabled
                        || ( isset( $previous_surfaces['builder'] ) && is_array( $previous_surfaces['builder'] ) && in_array( 'recovery', $previous_surfaces['builder'], true ) );
                    if ( ! $previous_surface_choice && isset( $previous['deactivated_tools'] ) && is_array( $previous['deactivated_tools'] ) ) {
                        $previous_admin_disabled = in_array( 'recovery', $previous['deactivated_tools'], true );
                    }
                    $current_admin_disabled = in_array( 'recovery', $deactivated_tool_surfaces['admin'], true );
                    $recovery_enabled_now = $previous_admin_disabled && ! $current_admin_disabled;
                    update_option( 've_settings', $settings );
                    update_option( 've_delete_on_uninstall', $settings['delete_on_uninstall'] );
                    $update_feed_changed = (string) ( $previous['update_channel'] ?? 'stable' ) !== $settings['update_channel']
                        || (string) ( $previous['update_url'] ?? '' ) !== $settings['update_url'];
                    if ( $update_feed_changed ) {
                        ( new \VE\Core\Updater() )->clear_cache();
                        delete_site_transient( 'update_plugins' );
                        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
                            wp_clean_plugins_cache();
                        }
                    }

                    // If the fluid viewport range changed, every fluid variable's
                    // clamp() output is now stale — recompile them.
                    $vw_changed = ( (int) ( $previous['vw_min'] ?? 320 ) !== $settings['vw_min'] )
                               || ( (int) ( $previous['vw_max'] ?? 1440 ) !== $settings['vw_max'] );
                    $recompiled = 0;
                    if ( $vw_changed ) {
                        $recompiled = ( new \VE\Core\VariableManager() )->recompile_fluid();
                        if ( is_wp_error( $recompiled ) ) {
                            update_option( 've_settings', $previous );
                            update_option( 've_delete_on_uninstall', ! empty( $previous['delete_on_uninstall'] ) );
                            return $recompiled;
                        }
                    }

                    $response = $settings;
                    $response['fluid_recompiled'] = $recompiled;
                    $response['license'] = ( new \VE\Core\LicenseManager() )->status();
                    if ( $recovery_enabled_now && defined( 'VE_FILE' ) ) {
                        \VE\Modules\Recovery\RecoveryModule::init( VE_FILE );
                        if ( class_exists( '\VE\Modules\Recovery\Admin\AdminPage' ) ) {
                            $response['recovery_runtime'] = ( new \VE\Modules\Recovery\Admin\AdminPage() )->runtime_bootstrap_payload();
                        }
                    }
                    return new \WP_REST_Response( $response, 200 );
                },
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/site-visibility', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'get_site_visibility' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'update_site_visibility' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/site-visibility/content', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'search_site_visibility_content' ],
            'permission_callback' => [ $this, 'can_read' ],
            'args'                => [
                'q' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ],
            ],
        ] );

        // Bricks remains the source of truth for custom fonts. MV only provides
        // an adapter UI over Bricks' own CPT, face metadata, attachments, and
        // generated @font-face option so the native Font Manager stays usable.
        register_rest_route( $ns, '/font-manager/families', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'get_font_manager_families' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'import_font_manager_variant' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        // Broken-variant recovery: find replacement files, then repoint the variant.
        /* What Bricks itself would say the custom fonts are, right now. The
           builder localises this once at page load, so after an import it is
           holding a list from before it - which is the refresh the owner keeps
           having to do. */
        register_rest_route( $ns, '/font-manager/bricks-fonts', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_bricks_custom_fonts' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/font-manager/relink-candidates', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'font_manager_relink_candidates' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/font-manager/relink', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'font_manager_relink' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/font-manager/families/(?P<id>\d+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $this, 'update_font_manager_family' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'delete_font_manager_family' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        /* One import of Inter arrives as eight families, because a static font
           has to carry its weight in its family name for applications that can
           only hold four styles. Fixing that at import does nothing for the
           eight already sitting in the library. */
        register_rest_route( $ns, '/font-manager/families/(?P<id>\d+)/merge', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'merge_font_manager_families' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/font-manager/families/(?P<id>\d+)/variants/(?P<variant>[A-Za-z0-9_-]+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_font_manager_variant' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/user-preferences', [
            [
                'methods'             => 'GET',
                'callback'            => function () {
                    $preferences = get_user_meta( get_current_user_id(), 've_user_preferences', true );
                    return new \WP_REST_Response( [
                        'preferences' => is_array( $preferences ) ? $preferences : [],
                    ], 200 );
                },
                'permission_callback' => [ $this, 'can_save_user_preferences' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => function ( \WP_REST_Request $request ) {
                    $data = $request->get_json_params();
                    $preferences = isset( $data['preferences'] ) && is_array( $data['preferences'] )
                        ? $this->sanitize_user_preferences( $data['preferences'] )
                        : [];
                    update_user_meta( get_current_user_id(), 've_user_preferences', $preferences );
                    return new \WP_REST_Response( [
                        'preferences' => $preferences,
                        'saved'       => true,
                    ], 200 );
                },
                'permission_callback' => [ $this, 'can_save_user_preferences' ],
            ],
        ] );

        $settings_transfer = new \VE\Core\SettingsTransferManager();
        register_rest_route( $ns, '/settings-transfer/groups', [
            'methods'             => 'GET',
            'callback'            => static function () use ( $settings_transfer ) {
                return new \WP_REST_Response( [
                    'schema_version' => \VE\Core\SettingsTransferManager::SCHEMA_VERSION,
                    'groups'         => $settings_transfer->group_definitions(),
                ], 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/settings-transfer/export', [
            'methods'             => 'POST',
            'callback'            => static function ( \WP_REST_Request $request ) use ( $settings_transfer ) {
                $data = $request->get_json_params() ?: [];
                $groups = isset( $data['groups'] ) && is_array( $data['groups'] ) ? $data['groups'] : [];
                return new \WP_REST_Response( [
                    'success' => true,
                    'bundle'  => $settings_transfer->export_bundle( $groups, get_current_user_id() ),
                ], 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/settings-transfer/preview', [
            'methods'             => 'POST',
            'callback'            => static function ( \WP_REST_Request $request ) use ( $settings_transfer ) {
                $data = $request->get_json_params() ?: [];
                $bundle = isset( $data['bundle'] ) && is_array( $data['bundle'] ) ? $data['bundle'] : [];
                $groups = isset( $data['groups'] ) && is_array( $data['groups'] ) ? $data['groups'] : [];
                $preview = $settings_transfer->preview_bundle( $bundle, $groups );
                return is_wp_error( $preview ) ? $preview : new \WP_REST_Response( $preview, 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/settings-transfer/apply', [
            'methods'             => 'POST',
            'callback'            => static function ( \WP_REST_Request $request ) use ( $settings_transfer ) {
                $data = $request->get_json_params() ?: [];
                $bundle = isset( $data['bundle'] ) && is_array( $data['bundle'] ) ? $data['bundle'] : [];
                $groups = isset( $data['groups'] ) && is_array( $data['groups'] ) ? $data['groups'] : [];
                $fingerprint = sanitize_text_field( (string) ( $data['fingerprint'] ?? '' ) );
                $result = $settings_transfer->apply_bundle( $bundle, $groups, $fingerprint, get_current_user_id() );
                return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/license/status', [
            'methods'             => 'GET',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->status(), 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/license/activate', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                $data = $request->get_json_params();
                $key  = isset( $data['license_key'] ) ? (string) $data['license_key'] : '';
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->activate( $key ), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/license/check', [
            'methods'             => 'POST',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->check(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/license/deactivate', [
            'methods'             => 'POST',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->deactivate(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/update/check', [
            'methods'             => 'POST',
            'callback'            => function () {
                $updater = new \VE\Core\Updater();
                return new \WP_REST_Response( $updater->check_now(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/update/install', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                $payload = $request->get_json_params();
                if ( ! is_array( $payload ) ) {
                    $payload = [];
                }
                $target_version = isset( $payload['version'] ) ? (string) $payload['version'] : (string) $request->get_param( 'version' );
                $result = ( new \VE\Core\Updater() )->install_available_update( $target_version );
                if ( is_wp_error( $result ) ) {
                    $error_data = $result->get_error_data();
                    $error_data = is_array( $error_data ) ? $error_data : [];
                    $error_data['update_step'] = \VE\Core\Updater::failure_step_for_code( (string) $result->get_error_code() );
                    return new \WP_REST_Response(
                        [
                            'code'    => $result->get_error_code(),
                            'message' => $result->get_error_message(),
                            'data'    => $error_data,
                        ],
                        (int) ( isset( $error_data['status'] ) ? $error_data['status'] : 500 )
                    );
                }
                return new \WP_REST_Response( $result, 200 );
            },
            'permission_callback' => static function (): bool {
                return current_user_can( 'update_plugins' );
            },
        ] );

        register_rest_route( $ns, '/advanced-css', [
            [
                'methods'             => 'GET',
                'callback'            => function () {
                    return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->get(), 200 );
                },
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => function ( \WP_REST_Request $request ) {
                    $data = $request->get_json_params();
                    $sheets = is_array( $data ) && isset( $data['stylesheets'] ) && is_array( $data['stylesheets'] )
                        ? $data['stylesheets']
                        : [];
                    return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->save( $sheets ), 200 );
                },
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/advanced-css/compile', [
            'methods'             => 'POST',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->compile(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // History for one stylesheet: the list carries no CSS, because drawing
        // twenty-five dates does not need twenty-five stylesheets on the wire.
        register_rest_route( $ns, '/advanced-css/versions', [
            'methods'             => 'GET',
            'callback'            => function ( \WP_REST_Request $request ) {
                $sheet_id = sanitize_key( (string) $request->get_param( 'sheet_id' ) );
                return new \WP_REST_Response(
                    [ 'versions' => ( new \VE\Core\AdvancedCssManager() )->versions( $sheet_id ) ],
                    200
                );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/advanced-css/versions/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => function ( \WP_REST_Request $request ) {
                $version = ( new \VE\Core\AdvancedCssManager() )->version( absint( $request['id'] ) );
                if ( ! $version ) {
                    return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'That version no longer exists.' ], 404 );
                }
                return new \WP_REST_Response( $version, 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/advanced-css/versions/(?P<id>\d+)/restore', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                $result = ( new \VE\Core\AdvancedCssManager() )->restore_version( absint( $request['id'] ) );
                return new \WP_REST_Response( $result, empty( $result['restored'] ) ? 400 : 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/advanced-css/suggestions', [
            'methods'             => 'GET',
            'callback'            => function ( \WP_REST_Request $request ) {
                $refresh = rest_sanitize_boolean( $request->get_param( 'refresh' ) );
                return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->suggestions( $refresh ), 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/migration/sources', [
            'methods'             => 'GET',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\MigrationScanner() )->sources(), 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/migration/preview', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                $data = $request->get_json_params();
                $source = sanitize_key( (string) ( $data['source'] ?? 'all' ) );
                $scanner = new \VE\Core\MigrationScanner();
                $sync = new \VE\Sync\SyncEngine();
                $submitted_vars = isset( $data['variables'] ) && is_array( $data['variables'] )
                    ? $data['variables']
                    : [];
                $vars = ! empty( $submitted_vars )
                    ? $sync->normalize_import( $submitted_vars )
                    : $scanner->scan( $source ?: 'all' );
                $detected_count = count( $vars );
                $vars = $sync->prepare_import_rows( $vars );
                $partition = $sync->partition_resolvable_external_rows( $vars );
                $vars = $partition['variables'];
                $preview = $sync->preview_import( $vars );
                $preview['variables'] = $vars;
                $preview['variable_count'] = $detected_count;
                $preview['warnings'] = $partition['warnings'];
                $preview['skipped_aliases'] = $partition['skipped_aliases'];
                $preview['migration_counts'] = $sync->external_migration_metrics( $detected_count, $partition, $preview['changes'] );
                $preview['migration_payload'] = $vars;
                return new \WP_REST_Response( $preview, 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/migration/apply', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                // A reviewed migration is a server-owned transaction. Keep it
                // running if the builder panel closes and allow enough room for
                // large framework libraries.
                ignore_user_abort( true );
                if ( function_exists( 'wp_raise_memory_limit' ) ) {
                    wp_raise_memory_limit( 'admin' );
                }
                if ( function_exists( 'set_time_limit' ) ) {
                    @set_time_limit( 300 );
                }

                $data = $request->get_json_params();
                $source = sanitize_key( (string) ( $data['source'] ?? 'all' ) );
                $scanner = new \VE\Core\MigrationScanner();
                $sync = new \VE\Sync\SyncEngine();
                $submitted_vars = isset( $data['variables'] ) && is_array( $data['variables'] )
                    ? $data['variables']
                    : [];
                $vars = ! empty( $submitted_vars )
                    ? $sync->normalize_import( $submitted_vars )
                    : $scanner->scan( $source ?: 'all' );
                $detected_count = count( $vars );
                if ( empty( $vars ) ) {
                    return new \WP_REST_Response(
                        [ 'code' => 've_migration_empty', 'message' => 'No compatible variables were found in this source.' ],
                        422
                    );
                }

                $vars = $sync->prepare_import_rows( $vars );
                $partition = $sync->partition_resolvable_external_rows( $vars );
                $vars = $partition['variables'];
                if ( empty( $vars ) ) {
                    return new \WP_REST_Response(
                        [
                            'code'     => 've_migration_no_resolvable_rows',
                            'message'  => 'No importable variables remained after unresolved external aliases were skipped.',
                            'warnings' => $partition['warnings'],
                        ],
                        422
                    );
                }
                $preview = $sync->preview_import( $vars );
                $migration_counts = $sync->external_migration_metrics( $detected_count, $partition, $preview['changes'] );
                $changes = $sync->external_migration_changes( $preview['changes'] );
                if ( empty( $changes ) ) {
                    return new \WP_REST_Response(
                        [
                            'code'             => 've_migration_nothing_to_apply',
                            'message'          => 'The reviewed migration no longer contains any changes to apply. Run Preview Migration again.',
                            'warnings'         => $partition['warnings'],
                            'migration_counts' => $migration_counts,
                        ],
                        409
                    );
                }
                $affected_names = array_values( array_unique( array_filter( array_map( static function ( array $change ): string {
                    return sanitize_text_field( (string) ( $change['name'] ?? '' ) );
                }, $changes ) ) ) );
                $snapshot_manager = new \VE\Sync\SnapshotManager();
                $snapshot_id = $snapshot_manager->create( 'pre_import' );
                if ( is_wp_error( $snapshot_id ) ) {
                    return new \WP_REST_Response(
                        [ 'code' => $snapshot_id->get_error_code(), 'message' => $snapshot_id->get_error_message() ],
                        (int) ( $snapshot_id->get_error_data()['status'] ?? 500 )
                    );
                }
                $category_manager = new \VE\Core\VariableCategoryManager();
                $category_names = [
                    'advanced-themer' => 'Advanced Themer',
                    'core-framework'  => 'Core Framework',
                    'automatic-css'   => 'Automatic.css',
                ];
                $source_categories = [];
                foreach ( $vars as $incoming_variable ) {
                    $category_slug = sanitize_key( (string) ( $incoming_variable['category_slug'] ?? 'uncategorized' ) );
                    if ( 'uncategorized' === $category_slug || isset( $source_categories[ $category_slug ] ) ) {
                        continue;
                    }
                    $created_category = $category_manager->get_or_create( $category_names[ $category_slug ] ?? ucwords( str_replace( '-', ' ', $category_slug ) ) );
                    if ( is_wp_error( $created_category ) ) {
                        $snapshot_manager->rollback( (int) $snapshot_id );
                        return new \WP_REST_Response(
                            [ 'code' => $created_category->get_error_code(), 'message' => $created_category->get_error_message() ],
                            (int) ( $created_category->get_error_data()['status'] ?? 500 )
                        );
                    }
                    $source_categories[ $category_slug ] = $created_category;
                }
                $source_category = reset( $source_categories ) ?: $category_manager->get_by_slug( 'uncategorized' );

                $result = $sync->apply_changes( $changes, [
                    'skip_deletes'        => true,
                    'snapshot_id'         => (int) $snapshot_id,
                    'defer_palette_repair'=> true,
                    'snapshot_context'    => [ 'source' => $source ],
                ] );
                if ( ! empty( $result['errors'] ) ) {
                    return new \WP_REST_Response( $result, 422 );
                }
                // Rows apply_changes skipped (an alias whose source vanished between
                // preview and apply) were not written; drop them from the persistence
                // and verification sets so one orphan cannot fail or roll back the
                // rows that did land, and surface them as warnings.
                $apply_skipped = isset( $result['skipped_names'] ) && is_array( $result['skipped_names'] )
                    ? array_map( 'strtolower', array_map( 'strval', $result['skipped_names'] ) )
                    : [];
                if ( ! empty( $apply_skipped ) ) {
                    $affected_names = array_values( array_filter( $affected_names, static function ( $n ) use ( $apply_skipped ): bool {
                        return ! in_array( strtolower( (string) $n ), $apply_skipped, true );
                    } ) );
                    $vars = array_values( array_filter( $vars, static function ( $v ) use ( $apply_skipped ): bool {
                        return ! in_array( strtolower( (string) ( $v['name'] ?? '' ) ), $apply_skipped, true );
                    } ) );
                    $partition['warnings'] = array_merge(
                        isset( $partition['warnings'] ) && is_array( $partition['warnings'] ) ? $partition['warnings'] : [],
                        isset( $result['warnings'] ) && is_array( $result['warnings'] ) ? $result['warnings'] : []
                    );
                }
                if ( (int) ( $result['applied'] ?? 0 ) <= 0 ) {
                    $snapshot_manager->rollback( (int) $snapshot_id );
                    return new \WP_REST_Response(
                        [
                            'code'        => 've_migration_zero_writes',
                            'message'     => 'The migration completed without writing any variables, so its safety snapshot was restored. Run Preview Migration again.',
                            'applied'     => 0,
                            'snapshot_id' => (int) $snapshot_id,
                            'rolled_back' => true,
                        ],
                        422
                    );
                }

                $verification_issues = $sync->external_migration_verification_issues( $vars );
                if ( ! empty( $verification_issues ) ) {
                    $snapshot_manager->rollback( (int) $snapshot_id );
                    return new \WP_REST_Response(
                        [
                            'code'              => 've_migration_verification_failed',
                            'message'           => 'The imported variables did not match the reviewed preview, so the migration was rolled back.',
                            'applied'           => 0,
                            'snapshot_id'       => (int) $snapshot_id,
                            'rolled_back'       => true,
                            'verification_issues' => $verification_issues,
                        ],
                        422
                    );
                }

                $manager = new \VE\Core\VariableManager();
                $incoming_by_name = [];
                foreach ( $vars as $incoming_variable ) {
                    $incoming_by_name[ (string) ( $incoming_variable['name'] ?? '' ) ] = $incoming_variable;
                }
                $persisted_names = array_values( array_filter( $affected_names, static function ( string $name ) use ( $manager ): bool {
                    return null !== $manager->get_by_name( $name );
                } ) );
                if ( count( $persisted_names ) !== count( $affected_names ) ) {
                    $snapshot_manager->rollback( (int) $snapshot_id );
                    return new \WP_REST_Response(
                        [
                            'code'            => 've_migration_persistence_failed',
                            'message'         => 'The migration did not persist every reviewed variable, so the safety snapshot was restored.',
                            'applied'         => 0,
                            'snapshot_id'     => (int) $snapshot_id,
                            'rolled_back'     => true,
                            'persisted_names' => $persisted_names,
                        ],
                        422
                    );
                }

                $palette_manager = new \VE\Core\ColorPaletteManager();
                $palette_candidates = [];
                $category_candidate_ids = [];
                $origin_candidate_ids = [];
                foreach ( $vars as $incoming ) {
                    $incoming_name = (string) ( $incoming['name'] ?? '' );
                    if ( '' === $incoming_name ) {
                        continue;
                    }
                    $current = $manager->get_by_name( $incoming_name );
                    if ( ! $current ) {
                        continue;
                    }
                    $origin = sanitize_key( (string) ( $incoming['origin'] ?? '' ) );
                    if ( '' !== $origin ) {
                        $origin_candidate_ids[ $origin ][] = (int) $current['id'];
                    }
                    $palette_owner = $palette_manager->palette_owner_variable( $current );
                    if ( $palette_owner ) {
                        if ( '' !== $origin ) {
                            // Imported family roots own both Palette membership
                            // and the source badge shown for the whole family.
                            $origin_candidate_ids[ $origin ][] = (int) $palette_owner['id'];
                        }
                        $palette_slug = $palette_manager::source_palette_slug( $source ?: 'all', $incoming );
                        $palette_candidates[ $palette_slug ][ (int) $palette_owner['id'] ] = $palette_owner;
                    } else {
                        if ( '' !== $origin && 'generated' === (string) ( $current['type'] ?? '' ) && (int) ( $current['source_id'] ?? 0 ) > 0 ) {
                            $origin_candidate_ids[ $origin ][] = (int) $current['source_id'];
                        }
                        $category_slug = sanitize_key( (string) ( $incoming['category_slug'] ?? 'uncategorized' ) );
                        $category_candidate_ids[ $category_slug ][] = (int) $current['id'];
                    }
                }

                $palette = null;
                $palettes = [];
                $assigned = 0;
                foreach ( $palette_candidates as $palette_slug => $candidate_rows ) {
                    $palette_name = $palette_manager::source_palette_name(
                        $palette_slug,
                        $scanner->source_name( $source ?: 'all' )
                    );
                    $created_palette = $palette_manager->get_by_slug( sanitize_title( $palette_name ) );
                    if ( ! $created_palette ) {
                        $created_palette = $palette_manager->get_by_name( $palette_name );
                    }
                    if ( ! $created_palette && 'advanced-themer' === $palette_slug ) {
                        $legacy_palette = $palette_manager->get_by_slug( 'advanced-themer' );
                        if ( $legacy_palette ) {
                            $renamed_palette = $palette_manager->rename( (int) $legacy_palette['id'], $palette_name );
                            if ( is_wp_error( $renamed_palette ) ) {
                                $snapshot_manager->rollback( (int) $snapshot_id );
                                return new \WP_REST_Response(
                                    [ 'code' => $renamed_palette->get_error_code(), 'message' => $renamed_palette->get_error_message() ],
                                    (int) ( $renamed_palette->get_error_data()['status'] ?? 500 )
                                );
                            }
                            $created_palette = $palette_manager->get( (int) $legacy_palette['id'] );
                        }
                    }
                    if ( ! $created_palette ) {
                        $created_palette = $palette_manager->create( $palette_name );
                    }
                    if ( is_wp_error( $created_palette ) ) {
                        $snapshot_manager->rollback( (int) $snapshot_id );
                        return new \WP_REST_Response(
                            [ 'code' => $created_palette->get_error_code(), 'message' => $created_palette->get_error_message() ],
                            (int) ( $created_palette->get_error_data()['status'] ?? 500 )
                        );
                    }
                    $palettes[ $palette_slug ] = $created_palette;
                    if ( null === $palette ) {
                        $palette = $created_palette;
                    }
                }

                foreach ( $palette_candidates as $palette_slug => $candidate_rows ) {
                    $created_palette = $palettes[ $palette_slug ] ?? null;
                    if ( ! $created_palette ) {
                        continue;
                    }
                    foreach ( $candidate_rows as $current ) {
                        $assignment = $palette_manager->assign( (int) $current['id'], (int) $created_palette['id'] );
                        if ( is_wp_error( $assignment ) ) {
                            $snapshot_manager->rollback( (int) $snapshot_id );
                            return new \WP_REST_Response(
                                [ 'code' => $assignment->get_error_code(), 'message' => $assignment->get_error_message() ],
                                (int) ( $assignment->get_error_data()['status'] ?? 500 )
                            );
                        }
                        $assigned++;
                    }
                }

                foreach ( $category_candidate_ids as $category_slug => $variable_ids ) {
                    $category_move = $category_manager->move_variables(
                        $variable_ids,
                        $category_slug
                    );
                    if ( is_wp_error( $category_move ) ) {
                        $snapshot_manager->rollback( (int) $snapshot_id );
                        return new \WP_REST_Response(
                            [ 'code' => $category_move->get_error_code(), 'message' => $category_move->get_error_message() ],
                            (int) ( $category_move->get_error_data()['status'] ?? 500 )
                        );
                    }
                }
                foreach ( $origin_candidate_ids as $origin => $variable_ids ) {
                    if ( ! $category_manager->set_origin( $variable_ids, $origin ) ) {
                        $snapshot_manager->rollback( (int) $snapshot_id );
                        return new \WP_REST_Response(
                            [ 'code' => 've_migration_origin_failed', 'message' => 'Imported source labels could not be stored.' ],
                            500
                        );
                    }
                }
                $palette_manager->repair_memberships();
                $palette_assignment_issues = [];
                foreach ( $palette_candidates as $palette_slug => $candidate_rows ) {
                    $expected_palette = $palettes[ $palette_slug ] ?? null;
                    if ( ! $expected_palette ) {
                        continue;
                    }
                    foreach ( $candidate_rows as $current ) {
                        $stored_palette_id = $palette_manager->palette_id_for_variable( (int) $current['id'] );
                        if ( $stored_palette_id !== (int) $expected_palette['id'] ) {
                            $palette_assignment_issues[] = (string) ( $current['name'] ?? $current['id'] );
                        }
                    }
                }
                if ( ! empty( $palette_assignment_issues ) ) {
                    $snapshot_manager->rollback( (int) $snapshot_id );
                    return new \WP_REST_Response(
                        [
                            'code'              => 've_migration_palette_assignment_failed',
                            'message'           => 'The imported colors did not retain their reviewed source Palette, so the migration was rolled back.',
                            'applied'           => 0,
                            'snapshot_id'       => (int) $snapshot_id,
                            'rolled_back'       => true,
                            'palette_issues'    => array_values( array_unique( $palette_assignment_issues ) ),
                        ],
                        422
                    );
                }
                $scanner->remember_family_base_choices( $vars );

                return new \WP_REST_Response( array_merge( $result, [
                    'palette' => $palette,
                    'palettes' => array_values( $palettes ),
                    'palette_color_count' => $assigned,
                    'source' => $scanner->source_name( $source ?: 'all' ),
                    'warnings' => $partition['warnings'],
                    'skipped_aliases' => $partition['skipped_aliases'],
                    'migration_counts' => $migration_counts,
                    'affected_names' => $affected_names,
                    'persisted_count' => count( $persisted_names ),
                    'category' => $source_category,
                ] ), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Sync ──────────────────────────────────────────────────────
        $sync = new SyncController();

        register_rest_route( $ns, '/sync/export', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'export' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
            'args'                => [
                'format' => [ 'type' => 'string', 'default' => 'dtcg', 'enum' => [ 'dtcg', 'flat', 'figma' ] ],
            ],
        ] );

        register_rest_route( $ns, '/sync/export-css', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'export_css' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/export-bundle', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'export_bundle' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/preview', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'preview' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/preview-bundle', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'preview_bundle' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/apply', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'apply' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/apply-bundle', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'apply_bundle' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/snapshots', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'list_snapshots' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/sync/snapshot', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'create_snapshot' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/snapshot/(?P<snapshot_id>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $sync, 'delete_snapshot' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/rollback/(?P<snapshot_id>\d+)', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'rollback' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/logs', [
            [
                'methods'             => 'GET',
                'callback'            => [ $sync, 'list_logs' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $sync, 'write_log' ],
                'permission_callback' => [ SyncController::class, 'can_sync' ],
            ],
        ] );

        register_rest_route( $ns, '/diagnostics/logs', [
            [
                'methods'             => 'GET',
                'callback'            => [ $sync, 'diagnostics' ],
                'permission_callback' => [ $this, 'can_read' ],
                'args'                => [
                    'lines' => [ 'type' => 'integer', 'default' => 200 ],
                ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $sync, 'clear_diagnostics' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        /* A panel that stopped drawing itself, recorded where the fatals are.
           MV used to throw away every PHP fatal that was not its own, and the
           browser side had the same hole: dev.77 took Content Studio down and
           left nothing behind at all. Same log, same reader. */
        register_rest_route( $ns, '/diagnostics/client-error', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'diagnostics_client_error' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        /* C81. The damage MV already did, and undoing it from inside the panel.
           The owner cannot be told to open a database or a debug log: they said
           so - "what if I can't get there?" */
        register_rest_route( $ns, '/diagnostics/meta-repair', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'diagnostics_meta_scan' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'diagnostics_meta_repair' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        // ── Pairing ─────────────────────────────────────────────────
        register_rest_route( $ns, '/sync/pair/generate', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'generate_pair' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/pair/validate', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'validate_pair' ],
            'permission_callback' => '__return_true', // WP-issued, rate-limited code is the auth.
        ] );

        register_rest_route( $ns, '/sync/pair/register', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'register_figma_pair' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/pair/complete-figma', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'complete_figma_pair' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/pair/status', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'pair_status' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/pair/disconnect', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'disconnect' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/drift', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'drift_status' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/drift/report', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'drift_report' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/drift/preview', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'drift_preview' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/drift/apply', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'drift_apply' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/drift/command', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'drift_command' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/drift/complete', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'drift_complete' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        // ── Content Studio ─────────────────────────────────────────
        register_rest_route( $ns, '/content-studio/meta', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_content_studio_meta' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/content-studio/options/(?P<id>[a-zA-Z0-9_\-]+)', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'update_studio_option_page' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // Every candidate parent for a hierarchical type. The posts list is capped
        // at 150 by modified date, which is right for a working list and wrong for
        // a parent picker: the page you want to nest under is usually an old one
        // nobody has touched in months.
        register_rest_route( $ns, '/content-studio/parent-options', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'list_studio_parent_options' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
        ] );

        register_rest_route( $ns, '/content-studio/posts', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'list_studio_posts' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'create_studio_post' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        /* R29. What a relationship, post object or taxonomy field will accept. */
        register_rest_route( $ns, '/content-studio/field-options', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'studio_field_options' ],
            'permission_callback' => [ $this, 'can_read' ],
            'args'                => [
                'search'    => [ 'type' => 'string' ],
                'taxonomy'  => [ 'type' => 'string' ],
                'post_type' => [ 'type' => 'string' ],
            ],
        ] );

        register_rest_route( $ns, '/content-studio/posts/(?P<id>\d+)', [
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'update_studio_post' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'delete_studio_post' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        // R19: does this post's published address actually reach this post?
        // Read-only, and only ever asked about one post at a time.
        /* 2026-09-15: "turning that off isn't really work, because I still get
           comments." The per-post switch does exactly what it says - proved by
           running it - and it was never the whole answer, because it governs
           ONE post. The four comments in their inbox were on four posts, and
           new posts keep arriving with WordPress's site default, which is on.
           So the panel can see the site default, and change it. */
        /* B57, built on "build it" of 2026-09-15. The rules are the owner's
           and live in one option; the review is computed per post and never
           stored, so editing a rule re-answers every post rather than leaving
           stale marks behind. */
        register_rest_route( $ns, '/content-studio/readiness', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'get_readiness_rules' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'set_readiness_rules' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/content-studio/posts/(?P<id>\d+)/readiness', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_post_readiness' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/content-studio/discussion', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'get_studio_discussion' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'set_studio_discussion' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/content-studio/posts/(?P<id>\d+)/address', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'studio_post_address' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        /* R47 - what the two-way variable sync did that the owner should know:
           a clash settled one way, or a Bricks edit to a value MV works out. */
        register_rest_route( $ns, '/bricks-sync/notices', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_bricks_sync_notices' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/bricks-sync/notices/clear', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'clear_bricks_sync_notices' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        /* R44 - the Rank Math schema the post already has, read and written as
           the array it is. Route 1: nothing is created here. */
        register_rest_route( $ns, '/content-studio/posts/(?P<id>\d+)/schema', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'get_studio_post_schema' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'save_studio_post_schema' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/content-studio/posts/(?P<id>\d+)/duplicate', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'duplicate_studio_post' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/import/preview', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'preview_studio_content_import' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/import/apply', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'apply_studio_content_import' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/cpts', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_or_update_studio_cpt' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/cpts/(?P<name>[a-zA-Z0-9_\-]+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_studio_cpt' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/taxonomies', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_or_update_studio_taxonomy' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/taxonomies/(?P<name>[a-zA-Z0-9_\-]+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_studio_taxonomy' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // A term inside a taxonomy, which is not the same thing as the taxonomy
        // above: this is the category you add while writing a post.
        register_rest_route( $ns, '/content-studio/terms', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_studio_term' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        /* Code Studio. One list, four languages: CSS has a destination and
           compiles to a file; PHP, JS and HTML carry a hook they do not yet run
           on. Reading needs read; writing needs the same capability as any other
           MV code surface. */
        register_rest_route( $ns, '/code-studio/items', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'code_studio_items' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'code_studio_create' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/code-studio/items/(?P<id>[A-Za-z0-9_-]+)', [
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'code_studio_update' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'code_studio_delete' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        /* The Classes lane. Reading is a GET; the two writes are separate
           routes because they are different promises: `rule` edits a rule where
           it already lives, and `adopt` moves one out of Bricks and clears the
           copy there, which is one way. Bundling them behind an `action` field
           would let a typo turn an edit into a move. */
        register_rest_route( $ns, '/code-studio/classes', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'code_studio_classes' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/code-studio/classes/rule', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'code_studio_class_rule' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/code-studio/classes/adopt', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'code_studio_class_adopt' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/code-studio/compile', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'code_studio_compile' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // History. Reading a list or one version needs no more than reading the
        // items themselves; restoring changes what the site serves, so it is a
        // write.
        register_rest_route( $ns, '/code-studio/items/(?P<id>[A-Za-z0-9_-]+)/versions', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'code_studio_versions' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );
        register_rest_route( $ns, '/code-studio/versions/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'code_studio_version' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );
        register_rest_route( $ns, '/code-studio/versions/(?P<id>\d+)/restore', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'code_studio_restore_version' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // Who else has this post open. Advisory: it reports and refreshes a
        // WordPress post lock, and never refuses anything.
        register_rest_route( $ns, '/content-studio/lock', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'studio_post_lock' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/options-pages', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_or_update_studio_options_page' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/options-pages/(?P<slug>[a-zA-Z0-9_\-]+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_studio_options_page' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/fields', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_or_update_studio_fields' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/fields/(?P<id>[a-zA-Z0-9_\-]+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_studio_fields' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/migrate/jet-to-acf/preview', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'preview_jet_to_acf_migration' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/content-studio/migrate/jet-to-acf', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'run_jet_to_acf_migration' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/collections', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'list_media_collections' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'create_media_collection' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/media-studio/collections/sync', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'sync_media_collections' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/collections/assign', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'assign_media_collection' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/collections/(?P<collection>[^/]+)/items', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_media_collection_items' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/media-studio/collections/(?P<collection>[^/]+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $this, 'update_media_collection' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'delete_media_collection' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/media-studio/folders', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_media_folders' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/media-studio/folders/assign', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'assign_media_folder' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/replace', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'replace_media_file' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/convert', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'convert_media_file' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/compress', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'compress_media_file' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/rename', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'rename_media_file' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/collection-zip', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_media_collection_zip' ],
            'permission_callback' => [ $this, 'can_export_media' ],
        ] );

        register_rest_route( $ns, '/media-studio/import-zip', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'import_zip_to_collection' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/metadata', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'update_media_metadata' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/unused-scan', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'scan_unused_media' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/media-studio/import-url/preview', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'preview_import_from_url' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/import-url', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'import_from_url' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/usage/(?P<id>\d+)', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_media_usage' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/media-studio/diagnostics', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_media_diagnostics' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/media-studio/url-history', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'get_media_url_history' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'clear_media_url_history' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/media-studio/rollback', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'rollback_media_action' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/plugin-studio/plugins', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'list_studio_plugins' ],
            'permission_callback' => [ $this, 'can_manage_plugins' ],
        ] );

        register_rest_route( $ns, '/plugin-studio/action', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'run_studio_plugin_action' ],
            'permission_callback' => [ $this, 'can_run_plugin_action' ],
        ] );

        register_rest_route( $ns, '/plugin-studio/directory', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'search_plugin_directory' ],
            'permission_callback' => [ $this, 'can_install_plugins' ],
            'args'                => [
                'search' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ],
            ],
        ] );

        register_rest_route( $ns, '/plugin-studio/install', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'install_directory_plugin' ],
            'permission_callback' => [ $this, 'can_install_plugins' ],
        ] );

        register_rest_route( $ns, '/plugin-studio/upload', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'upload_plugin_zip' ],
            'permission_callback' => [ $this, 'can_upload_plugins' ],
        ] );
    }

    /* ── Permission callbacks ─────────────────────────────────────── */

    /** Is Bricks' permission layer here to be asked? */
    private function bricks_permissions_ready(): bool {
        return class_exists( '\\Bricks\\Builder_Permissions' )
            && method_exists( '\\Bricks\\Builder_Permissions', 'get_sections' );
    }

    /**
     * C26 - every capability, and every permission that could be in one.
     *
     * The sections come from Bricks: `get_sections()` returns each group, its
     * label, and the permissions inside it, including the post-type list that
     * is built from the site's own post types. So MV renders what Bricks
     * defines - including anything Bricks adds in a later version - rather than
     * keeping a list that would be wrong the day they add one.
     *
     * The three built-in capabilities are returned as read-only: Bricks refuses
     * to overwrite them in save_custom_capabilities(), so offering to edit them
     * would be offering something that silently does not happen.
     */
    public function get_bricks_capabilities(): \WP_REST_Response {
        if ( ! $this->bricks_permissions_ready() ) {
            return new \WP_REST_Response( [
                'available'    => false,
                'sections'     => [],
                'capabilities' => [],
                'message'      => 'This version of Bricks does not have the capability editor.',
            ], 200 );
        }

        $sections = [];
        foreach ( (array) \Bricks\Builder_Permissions::get_sections( true ) as $key => $section ) {
            if ( ! is_array( $section ) ) {
                continue;
            }
            $sections[] = [
                'key'         => (string) $key,
                'label'       => (string) ( $section['label'] ?? $key ),
                'description' => (string) ( $section['description'] ?? '' ),
                'permissions' => array_map(
                    static function ( $label, $permission ) {
                        return [ 'key' => (string) $permission, 'label' => (string) $label ];
                    },
                    array_values( (array) ( $section['permissions'] ?? [] ) ),
                    array_keys( (array) ( $section['permissions'] ?? [] ) )
                ),
            ];
        }

        $stored   = get_option( 'bricks_capabilities_permissions', [] );
        $stored   = is_array( $stored ) ? $stored : [];
        $defaults = (array) \Bricks\Builder_Permissions::DEFAULT_CAPABILITIES;

        $out = [];
        foreach ( $defaults as $id => $label ) {
            $row = $stored[ $id ] ?? null;
            if ( ! is_array( $row ) && method_exists( '\\Bricks\\Builder_Permissions', 'get_default_capability_permissions' ) ) {
                $row = \Bricks\Builder_Permissions::get_default_capability_permissions( $id );
            }
            $out[] = [
                'id'          => (string) $id,
                'label'       => (string) ( $row['label'] ?? $label ),
                'description' => (string) ( $row['description'] ?? '' ),
                'permissions' => array_values( array_map( 'strval', (array) ( $row['permissions'] ?? [] ) ) ),
                'is_default'  => true,
            ];
        }
        foreach ( $stored as $id => $row ) {
            if ( isset( $defaults[ $id ] ) || ! is_array( $row ) ) {
                continue;
            }
            $out[] = [
                'id'          => (string) $id,
                'label'       => (string) ( $row['label'] ?? $id ),
                'description' => (string) ( $row['description'] ?? '' ),
                'permissions' => array_values( array_map( 'strval', (array) ( $row['permissions'] ?? [] ) ) ),
                'is_default'  => false,
            ];
        }

        return new \WP_REST_Response( [
            'available'    => true,
            'sections'     => $sections,
            'capabilities' => $out,
        ], 200 );
    }

    /**
     * Save them. All of them.
     *
     * Bricks' save_custom_capabilities() REPLACES the set: any capability not
     * in the list it is handed is removed from the site. So a panel that sent
     * only the one being edited would delete every other custom capability, and
     * it would look like it had worked. MV refuses a payload that does not
     * carry every custom capability the site currently has, rather than trust
     * that the panel remembered.
     */
    public function update_bricks_capabilities( \WP_REST_Request $request ) {
        if ( ! $this->bricks_permissions_ready()
            || ! method_exists( '\\Bricks\\Builder_Permissions', 'save_custom_capabilities' ) ) {
            return new \WP_Error( 've_bricks_missing', 'Bricks is not active on this site.', [ 'status' => 400 ] );
        }

        $data     = $request->get_json_params();
        $incoming = ( is_array( $data ) && isset( $data['capabilities'] ) && is_array( $data['capabilities'] ) )
            ? $data['capabilities'] : null;
        if ( null === $incoming ) {
            return new \WP_Error( 've_bricks_caps_missing', 'No capabilities were sent.', [ 'status' => 400 ] );
        }

        $defaults = (array) \Bricks\Builder_Permissions::DEFAULT_CAPABILITIES;
        $valid    = method_exists( '\\Bricks\\Builder_Permissions', 'get_all_permissions' )
            ? array_keys( (array) \Bricks\Builder_Permissions::get_all_permissions() )
            : [];

        $clean = [];
        $seen  = [];
        foreach ( $incoming as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }
            $id = sanitize_key( (string) ( $row['id'] ?? '' ) );
            if ( '' === $id || isset( $seen[ $id ] ) ) {
                continue;
            }
            $seen[ $id ] = true;
            $permissions = array_values( array_unique( array_map( 'sanitize_text_field', (array) ( $row['permissions'] ?? [] ) ) ) );
            if ( $valid ) {
                // A permission Bricks does not define is not a permission.
                $permissions = array_values( array_intersect( $permissions, $valid ) );
            }
            $clean[] = [
                'id'          => $id,
                'label'       => sanitize_text_field( (string) ( $row['label'] ?? $id ) ),
                'description' => sanitize_textarea_field( (string) ( $row['description'] ?? '' ) ),
                'permissions' => $permissions,
            ];
        }

        /* The refusal that matters. Anything custom the site has and the
           payload does not is about to be deleted by Bricks, so say so instead
           of doing it.

           But deleting has to remain POSSIBLE, or the only way to remove a
           capability is outside MV - the first version of this refused every
           payload that dropped one, which protected the accident and forbade
           the intention with the same line. So a delete is named: an id in
           `remove` is one somebody meant, and anything neither kept nor named
           is the accident. */
        $remove = ( is_array( $data ) && isset( $data['remove'] ) && is_array( $data['remove'] ) )
            ? array_map( 'sanitize_key', $data['remove'] ) : [];
        $stored  = get_option( 'bricks_capabilities_permissions', [] );
        $stored  = is_array( $stored ) ? $stored : [];
        $missing = [];
        foreach ( array_keys( $stored ) as $id ) {
            if ( isset( $defaults[ $id ] ) ) {
                continue;
            }
            if ( ! isset( $seen[ (string) $id ] ) && ! in_array( (string) $id, $remove, true ) ) {
                $missing[] = (string) $id;
            }
        }
        if ( $missing ) {
            return new \WP_Error(
                've_bricks_caps_partial',
                'Saving this would delete ' . implode( ', ', $missing )
                    . '. Send every capability, not only the one being edited.',
                [ 'status' => 409, 'missing' => $missing ]
            );
        }

        \Bricks\Builder_Permissions::save_custom_capabilities( $clean );

        return $this->get_bricks_capabilities();
    }

    private function bricks_settings_option_name(): string {
        return defined( 'BRICKS_DB_GLOBAL_SETTINGS' ) ? BRICKS_DB_GLOBAL_SETTINGS : 'bricks_global_settings';
    }

    /**
     * #29 — Which theme-style group owns each control key.
     *
     * Generated from Bricks' own includes/theme-styles/controls/*.php. Bricks reads
     * settings[ group ][ key ] (see Theme_Styles::get_setting_by_key), so a value
     * written at the top level of `settings` is stored but never applied. MV wrote
     * flat keys before v1.3.452; this map is what lets those be lifted into place.
     *
     * @return array<string,string>
     */
    private function bricks_theme_style_group_map(): array {
        static $map = null;
        if ( null !== $map ) {
            return $map;
        }
        $map = [
            'siteLayout' => 'general',
            'siteLayoutBoxedMaxWidth' => 'general',
            'contentBoxShadow' => 'general',
            'contentBackground' => 'general',
            'siteBackground' => 'general',
            'siteBorder' => 'general',
            'elementMargin' => 'general',
            'sectionMargin' => 'general',
            'sectionPadding' => 'general',
            'containerMaxWidth' => 'general',
            'lightboxBackground' => 'general',
            'lightboxCloseColor' => 'general',
            'lightboxCloseSize' => 'general',
            'lightboxWidth' => 'general',
            'lightboxHeight' => 'general',
            'colorPrimary' => 'colors',
            'colorSecondary' => 'colors',
            'colorLight' => 'colors',
            'colorDark' => 'colors',
            'colorMuted' => 'colors',
            'colorBorder' => 'colors',
            'colorInfo' => 'colors',
            'colorSuccess' => 'colors',
            'colorWarning' => 'colors',
            'colorDanger' => 'colors',
            'cssSelectors' => 'links',
            'typography' => 'links',
            'background' => 'links',
            'border' => 'links',
            'padding' => 'links',
            'textDecoration' => 'links',
            'transition' => 'links',
            'contextualSpacingRemoveDefaultMargins' => 'contextualSpacing',
            'contextualSpacingHeading' => 'contextualSpacing',
            'contextualSpacingParagraph' => 'contextualSpacing',
            'contextualSpacingFallback' => 'contextualSpacing',
            'contextualSpacingCustomTarget' => 'contextualSpacing',
            'contextualSpacingApplyTo' => 'contextualSpacing',
            'contentMargin' => 'content',
            'contentBlockquoteMargin' => 'content',
            'contentBlockquotePadding' => 'content',
            'contentBlockquoteBorder' => 'content',
            'contentBlockquoteTypography' => 'content',
            'typographyFluidPopup' => 'typography',
            'typographyHtml' => 'typography',
            'typographyBody' => 'typography',
            'typographyHeadings' => 'typography',
            'typographyHeadingH1' => 'typography',
            'h1Margin' => 'typography',
            'typographyHeadingH2' => 'typography',
            'h2Margin' => 'typography',
            'typographyHeadingH3' => 'typography',
            'h3Margin' => 'typography',
            'typographyHeadingH4' => 'typography',
            'h4Margin' => 'typography',
            'typographyHeadingH5' => 'typography',
            'h5Margin' => 'typography',
            'typographyHeadingH6' => 'typography',
            'h6Margin' => 'typography',
            'typographyHero' => 'typography',
            'typographyLead' => 'typography',
            'focusOutline' => 'typography',
            'blockquoteMargin' => 'typography',
            'blockquotePadding' => 'typography',
            'blockquoteBorder' => 'typography',
            'blockquoteTypography' => 'typography',
            'popupPadding' => 'popup',
            'popupJustifyConent' => 'popup',
            'popupAlignItems' => 'popup',
            'popupZindex' => 'popup',
            'popupBreakpointMode' => 'popup',
            'popupShowAt' => 'popup',
            'popupShowOn' => 'popup',
            'popupDisableBackdrop' => 'popup',
            'popupBackground' => 'popup',
            'popupBackdropTransition' => 'popup',
            'popupContentPadding' => 'popup',
            'popupContentWidth' => 'popup',
            'popupContentMinWidth' => 'popup',
            'popupContentMaxWidth' => 'popup',
            'popupContentHeight' => 'popup',
            'popupContentMinHeight' => 'popup',
            'popupContentMaxHeight' => 'popup',
            'popupContentBackground' => 'popup',
            'popupContentBorder' => 'popup',
            'popupContentBoxShadow' => 'popup',
            'stylesheet' => 'css',
        ];
        return $map;
    }

    /**
     * The groups MV renders. Anything else in a style — Bricks' ~40 per-element
     * groups above all — is passed through untouched so saving from MV never
     * wipes styling the owner set in Bricks itself.
     *
     * @return array<int,string>
     */
    private function bricks_theme_style_known_groups(): array {
        return [ 'conditions', 'css', 'general', 'colors', 'links', 'contextualSpacing', 'content', 'typography', 'popup' ];
    }

    /**
     * Lift pre-v1.3.452 flat keys into the group Bricks actually reads them from.
     * A key already present in its group wins, so a repaired value is never
     * clobbered by the stale copy sitting alongside it.
     *
     * @param array<mixed> $settings
     * @return array<mixed>
     */
    private function migrate_flat_theme_style_settings( array $settings ): array {
        $map = $this->bricks_theme_style_group_map();
        $groups = $this->bricks_theme_style_known_groups();
        foreach ( $settings as $key => $value ) {
            if ( ! isset( $map[ $key ] ) ) {
                continue;
            }
            /* 2026-09-24, found checking C30 on test7: `typography` is BOTH the
               old flat key for link typography (Links group) AND the name of the
               Typography group. Every style with a Typography group had the whole
               group - body, headings, HTML size - filed under Links on every read,
               and the next save from MV stored it there, where Bricks reads it as
               link typography and the real typography is gone. A key that names a
               group and holds that group's own controls IS the group. */
            if ( in_array( $key, $groups, true ) && is_array( $value ) ) {
                $own = false;
                foreach ( array_keys( $value ) as $inner ) {
                    if ( ( $map[ $inner ] ?? '' ) === $key ) { $own = true; break; }
                }
                if ( $own ) {
                    continue;
                }
            }
            $group = $map[ $key ];
            if ( ! isset( $settings[ $group ] ) || ! is_array( $settings[ $group ] ) ) {
                $settings[ $group ] = [];
            }
            if ( ! array_key_exists( $key, $settings[ $group ] ) ) {
                $settings[ $group ][ $key ] = $value;
            }
            unset( $settings[ $key ] );
        }
        // MV also wrote the stylesheet flat; Bricks reads it from the 'css' group.
        if ( isset( $settings['stylesheet'] ) ) {
            if ( ! isset( $settings['css'] ) || ! is_array( $settings['css'] ) ) {
                $settings['css'] = [];
            }
            if ( ! isset( $settings['css']['stylesheet'] ) ) {
                $settings['css']['stylesheet'] = $settings['stylesheet'];
            }
            unset( $settings['stylesheet'] );
        }
        return $settings;
    }

    /**
     * Bricks names each generated CSS file after the style label, so two styles
     * sharing a label would overwrite each other's file. Suffix duplicates.
     *
     * @param array<mixed> $styles
     */
    private function unique_theme_style_label( array $styles, string $label, string $skip_id ): string {
        $taken = [];
        foreach ( $styles as $id => $style ) {
            if ( (string) $id === $skip_id || ! is_array( $style ) ) {
                continue;
            }
            $taken[] = strtolower( trim( (string) ( $style['label'] ?? '' ) ) );
        }
        $candidate = $label;
        $suffix    = 2;
        while ( in_array( strtolower( trim( $candidate ) ), $taken, true ) ) {
            $candidate = $label . ' ' . $suffix;
            $suffix++;
        }
        return $candidate;
    }

    private function bricks_theme_styles_option_name(): string {
        return defined( 'BRICKS_DB_THEME_STYLES' ) ? BRICKS_DB_THEME_STYLES : 'bricks_theme_styles';
    }

    /**
     * Keep Bricks' camelCase control keys and structured values intact while
     * rejecting object/resource input and unsafe key names. The stylesheet is
     * deliberately raw: this endpoint has the same administrator gate as
     * Bricks' own Theme Styles editor.
     *
     * @param mixed  $value
     * @param string $path
     * @return mixed
     */
    private function sanitize_bricks_theme_style_node( $value, string $path = '' ) {
        if ( is_array( $value ) ) {
            $clean = [];
            foreach ( $value as $key => $child ) {
                if ( is_int( $key ) ) {
                    $clean[] = $this->sanitize_bricks_theme_style_node( $child, $path . '[]' );
                    continue;
                }
                $key = (string) $key;
                if ( ! preg_match( '/^[A-Za-z0-9_-]+$/', $key ) ) {
                    continue;
                }
                $clean[ $key ] = $this->sanitize_bricks_theme_style_node(
                    $child,
                    '' === $path ? $key : $path . '.' . $key
                );
            }
            return $clean;
        }
        if ( is_bool( $value ) || is_int( $value ) || is_float( $value ) || null === $value ) {
            return $value;
        }
        if ( ! is_scalar( $value ) ) {
            return '';
        }
        $text = (string) $value;
        // Stylesheets and selector lists are stored verbatim: sanitize_textarea_field
        // strips %xx octets and anything resembling a tag, which corrupts CSS. This
        // endpoint carries the same administrator gate as Bricks' own editor.
        if ( preg_match( '/(?:^|\.)(stylesheet|cssSelectors|contextualSpacingApplyTo)$/', $path ) ) {
            return wp_unslash( $text );
        }
        return sanitize_textarea_field( $text );
    }

    /**
     * Return Bricks' native associative store as stable list rows for the UI.
     *
     * @param array<mixed> $styles
     * @return array<int,array<string,mixed>>
     */
    private function bricks_theme_style_rows( array $styles ): array {
        $rows = [];
        foreach ( $styles as $id => $style ) {
            if ( ! is_array( $style ) ) {
                continue;
            }
            $settings = is_array( $style['settings'] ?? null ) ? $style['settings'] : [];
            $settings = $this->migrate_flat_theme_style_settings( $settings );
            $foreign  = array_values( array_diff( array_keys( $settings ), $this->bricks_theme_style_known_groups() ) );
            $rows[]   = [
                'id'       => (string) $id,
                'label'    => sanitize_text_field( (string) ( $style['label'] ?? $id ) ),
                'settings' => $settings,
                // Groups edited in Bricks that MV does not render (element styles).
                // Surfaced so the panel can say they exist and are preserved.
                'other_groups' => $foreign,
            ];
        }
        return $rows;
    }

    /**
     * Font families offered by the Typography control: Bricks' custom fonts first,
     * then the standard/system stack. Empty when Bricks is inactive, in which case
     * the control falls back to free text.
     *
     * @return array<int,string>
     */
    /**
     * Theme style ids whose conditions currently match a post, newest-specific
     * last — the same order Bricks' builder uses for themeStyleActiveIds.
     *
     * @return array<int,string>
     */
    private function bricks_active_theme_style_ids( int $post_id ): array {
        if ( ! $post_id || ! class_exists( '\Bricks\Theme_Styles' ) || ! method_exists( '\Bricks\Theme_Styles', 'set_active_style' ) ) {
            return [];
        }
        // set_active_style() repopulates the static it reads from, so the
        // previous value is restored to avoid disturbing the current request.
        $previous = property_exists( '\Bricks\Theme_Styles', 'settings_by_id' ) ? \Bricks\Theme_Styles::$settings_by_id : null;
        if ( null !== $previous ) {
            \Bricks\Theme_Styles::$settings_by_id = [];
        }
        $ids = [];
        try {
            $result = \Bricks\Theme_Styles::set_active_style( $post_id, true );
            $ids    = is_array( $result ) ? array_values( array_map( 'strval', $result ) ) : [];
        } catch ( \Throwable $e ) {
            $ids = [];
        }
        if ( null !== $previous ) {
            \Bricks\Theme_Styles::$settings_by_id = $previous;
        }
        return $ids;
    }

    private function bricks_font_families(): array {
        $fonts = [];
        if ( class_exists( '\Bricks\Custom_Fonts' ) && method_exists( '\Bricks\Custom_Fonts', 'get_custom_fonts' ) ) {
            $custom = \Bricks\Custom_Fonts::get_custom_fonts();
            if ( is_array( $custom ) ) {
                foreach ( $custom as $font ) {
                    $family = is_array( $font ) ? (string) ( $font['family'] ?? '' ) : (string) $font;
                    if ( '' !== $family ) {
                        $fonts[] = $family;
                    }
                }
            }
        }
        foreach ( [ 'Arial', 'Georgia', 'Helvetica', 'Tahoma', 'Times New Roman', 'Trebuchet MS', 'Verdana' ] as $standard ) {
            $fonts[] = $standard;
        }
        return array_values( array_unique( array_filter( $fonts ) ) );
    }

    /**
     * The site's real breakpoints, which is what Bricks fills the popup
     * "show at / show on breakpoint" selects with.
     *
     * @return array<int,array<string,string>>
     */
    private function bricks_breakpoint_list(): array {
        if ( ! class_exists( '\Bricks\Breakpoints' ) || ! method_exists( '\Bricks\Breakpoints', 'get_breakpoints' ) ) {
            return [];
        }
        $out = [];
        foreach ( (array) \Bricks\Breakpoints::get_breakpoints() as $breakpoint ) {
            if ( ! is_array( $breakpoint ) || empty( $breakpoint['key'] ) ) {
                continue;
            }
            $out[] = [
                'key'   => (string) $breakpoint['key'],
                'label' => (string) ( $breakpoint['label'] ?? $breakpoint['key'] ),
            ];
        }
        return $out;
    }

    private function bricks_theme_styles_response( array $styles, int $post_id = 0 ): \WP_REST_Response {
        $post_types = [];
        foreach ( get_post_types( [ 'public' => true ], 'objects' ) as $post_type ) {
            if ( 'attachment' === $post_type->name ) {
                continue;
            }
            $post_types[] = [
                'slug'  => (string) $post_type->name,
                'label' => (string) ( $post_type->labels->singular_name ?? $post_type->name ),
            ];
        }
        return new \WP_REST_Response( [
            'styles'  => $this->bricks_theme_style_rows( $styles ),
            'context' => [
                'bricks_active' => defined( 'BRICKS_VERSION' ),
                'post_types'    => $post_types,
                'fonts'         => $this->bricks_font_families(),
                'breakpoints'   => $this->bricks_breakpoint_list(),
                'active_ids'    => $this->bricks_active_theme_style_ids( $post_id ),
            ],
        ], 200 );
    }

    public function get_bricks_theme_styles( \WP_REST_Request $request ): \WP_REST_Response {
        $styles = get_option( $this->bricks_theme_styles_option_name(), [] );
        return $this->bricks_theme_styles_response( is_array( $styles ) ? $styles : [], (int) $request->get_param( 'post_id' ) );
    }

    /**
     * Whether this request is happening inside a workspace session.
     *
     * Asked of the module rather than worked out here, the same way
     * VariablesMirror asks: one place decides what a session is, and a second
     * copy of that rule is how the two come to disagree. Absent module, absent
     * session — which is also the answer wherever Workspaces is switched off.
     */
    private static function in_workspace_session(): bool {
        if ( ! class_exists( '\VE\Modules\Workspaces\WorkspaceRuntime' ) ) {
            return false;
        }
        return \VE\Modules\Workspaces\WorkspaceRuntime::session_id() > 0;
    }

    public function update_bricks_theme_styles( \WP_REST_Request $request ) {
        if ( ! defined( 'BRICKS_VERSION' ) && ! class_exists( '\Bricks\Theme_Styles' ) ) {
            return new \WP_Error( 've_bricks_missing', 'Bricks is not active on this site.', [ 'status' => 400 ] );
        }

        $data   = $request->get_json_params();
        $data   = is_array( $data ) ? $data : [];
        $action = sanitize_key( (string) ( $data['action'] ?? '' ) );
        $option = $this->bricks_theme_styles_option_name();
        $styles = get_option( $option, [] );
        $styles = is_array( $styles ) ? $styles : [];

        if ( 'create' === $action ) {
            $label = sanitize_text_field( (string) ( $data['label'] ?? 'New theme style' ) );
            $id    = 'mv-' . substr( str_replace( '-', '', wp_generate_uuid4() ), 0, 10 );
            $styles[ $id ] = [
                'label'    => '' !== $label ? $label : 'New theme style',
                'settings' => [
                    'conditions' => [
                        'conditions' => [
                            [ 'main' => 'any' ],
                        ],
                    ],
                ],
            ];
            $styles[ $id ]['label'] = $this->unique_theme_style_label( $styles, $styles[ $id ]['label'], $id );
        } elseif ( 'duplicate' === $action ) {
            $source_id = (string) ( $data['id'] ?? '' );
            if ( ! isset( $styles[ $source_id ] ) || ! is_array( $styles[ $source_id ] ) ) {
                return new \WP_Error( 've_theme_style_missing', 'The source theme style no longer exists.', [ 'status' => 404 ] );
            }
            $id = 'mv-' . substr( str_replace( '-', '', wp_generate_uuid4() ), 0, 10 );
            $styles[ $id ] = $styles[ $source_id ];
            $styles[ $id ]['label'] = $this->unique_theme_style_label(
                $styles,
                sanitize_text_field( (string) ( $styles[ $source_id ]['label'] ?? 'Theme style' ) ) . ' copy',
                $id
            );
        } elseif ( 'save' === $action ) {
            $id = (string) ( $data['id'] ?? '' );
            if ( ! isset( $styles[ $id ] ) ) {
                return new \WP_Error( 've_theme_style_missing', 'This theme style no longer exists. Reload the list.', [ 'status' => 404 ] );
            }
            $label    = sanitize_text_field( (string) ( $data['label'] ?? '' ) );
            $settings = $data['settings'] ?? [];
            if ( '' === $label || ! is_array( $settings ) ) {
                return new \WP_Error( 've_theme_style_invalid', 'A label and valid style settings are required.', [ 'status' => 400 ] );
            }
            // Merge rather than replace. MV renders nine of Bricks' groups; a style
            // may also carry ~40 per-element groups set in Bricks itself, and a
            // straight overwrite would delete every one of them.
            $existing = is_array( $styles[ $id ]['settings'] ?? null ) ? $styles[ $id ]['settings'] : [];
            $existing = $this->migrate_flat_theme_style_settings( $existing );
            $incoming = $this->sanitize_bricks_theme_style_node( $settings );
            $known    = $this->bricks_theme_style_known_groups();
            $merged   = $existing;
            foreach ( $known as $group ) {
                // An absent or emptied group means "cleared", so it is removed
                // rather than left behind at its old value.
                if ( isset( $incoming[ $group ] ) && is_array( $incoming[ $group ] ) && $incoming[ $group ] ) {
                    $merged[ $group ] = $incoming[ $group ];
                } else {
                    unset( $merged[ $group ] );
                }
            }
            $styles[ $id ] = [
                'label'    => $this->unique_theme_style_label( $styles, $label, $id ),
                'settings' => $merged,
            ];
        } elseif ( 'delete' === $action ) {
            $id = (string) ( $data['id'] ?? '' );
            if ( '' === $id || ! isset( $styles[ $id ] ) ) {
                return new \WP_Error( 've_theme_style_missing', 'This theme style no longer exists.', [ 'status' => 404 ] );
            }
            if ( ! isset( $data['confirm'] ) || ! hash_equals( $id, (string) $data['confirm'] ) ) {
                return new \WP_Error( 've_theme_style_confirmation', 'Confirm the exact theme style before deleting it.', [ 'status' => 400 ] );
            }
            unset( $styles[ $id ] );
        } else {
            return new \WP_Error( 've_theme_style_action', 'Choose create, duplicate, save, or delete.', [ 'status' => 400 ] );
        }

        update_option( $option, $styles );
        if ( class_exists( '\Bricks\Theme_Styles' ) ) {
            \Bricks\Theme_Styles::$styles = [];
            if ( property_exists( '\Bricks\Theme_Styles', 'settings_by_id' ) ) {
                \Bricks\Theme_Styles::$settings_by_id = [];
            }
        }
        /* Bricks writes one theme-style-{name}.min.css per style and normally
           regenerates it on its own update_option hook. Called directly as well,
           because that hook only fires when the stored value actually changed —
           a re-save with identical settings would otherwise leave a stale file.

           Slice 9: not inside a workspace session. That “normally” is doing a
           lot of work now. The overlay holds the option write, which means core
           returns before `update_option_bricks_theme_styles` fires, which
           is what stops Bricks regenerating the shared file — and this line, by
           being deliberate rather than hooked, walks straight past that and
           writes a workspace’s theme style into a file every visitor is served.
           Isolating the option while rewriting the site’s CSS would isolate
           nothing, which is the same argument §109.1 makes about file mode. */
        if ( ! self::in_workspace_session()
            && class_exists( '\Bricks\Assets_Theme_Styles' )
            && method_exists( '\Bricks\Assets_Theme_Styles', 'generate_css_file' ) ) {
            \Bricks\Assets_Theme_Styles::generate_css_file( $styles );
        }
        return $this->bricks_theme_styles_response( $styles, (int) ( $data['post_id'] ?? 0 ) );
    }

    /**
     * #23 Bricks Settings — allowlist of writable keys and their types.
     *
     * Bricks 2.4 removed `builderCheckForCorruptData` and
     * `templateManagerThumbnailHeight` outright - not renamed, not moved, zero
     * references left in the theme - so they are gone from here too. A control
     * that writes a key nothing reads is a switch with no wire behind it, and
     * the person flipping it has no way of knowing.
     * bool = checkbox (presence semantics), str = text/enum, int = number, code = raw CSS/JS.
     * Only these keys are ever read back or written; everything else in the Bricks
     * option is left untouched. Destructive/complex settings are intentionally excluded.
     */
    private function bricks_settings_type_map(): array {
        return [
            // General
            'bricksComponentsInBlockEditor' => 'str',
            'wp_to_bricks' => 'bool', 'bricks_to_wp' => 'bool', 'deleteBricksData' => 'bool',
            'postTypes' => 'arr_key', 'uploadSvgCapabilities' => 'caps_svg',
            /* C26 - the rest of Bricks' builder-access matrix.
               Bricks keeps two different things here and MV only carried one of
               them. The four `caps_*` keys are INDEPENDENT capabilities, each
               held by any set of roles. `builderAccessMatrix` is the other
               shape: one mutually exclusive level per role - no access, edit
               content, full access, plus whatever custom levels the site has
               added - and Bricks has its own method for writing it, which
               clears the other levels off the role first. None of these is a
               key in bricks_global_settings; they are role capabilities, and
               they are listed here because this map is what the panel reads to
               know a control exists. */
            'bypassMaintenanceCapabilities' => 'caps_maint',
            'formSubmissionCapabilities' => 'caps_forms',
            'builderAccessMatrix' => 'caps_level',
            'disableClassManager' => 'bool', 'disableVariablesManager' => 'bool',
            'disableOpenGraph' => 'bool', 'disableSeo' => 'bool', 'customImageSizes' => 'bool',
            'elementAttsAsNeeded' => 'bool', 'disableSkipLinks' => 'bool', 'smoothScroll' => 'bool',
            'searchResultsQueryBricksData' => 'bool', 'themeStylesLoadingMethod' => 'str',
            'duplicateContent' => 'str', 'saveFormSubmissions' => 'bool', 'enableQueryFilters' => 'bool',
            'customBreakpoints' => 'bool', 'passwordProtectionEnabled' => 'bool',
            // Templates
            'generateTemplateScreenshots' => 'bool',
            'templateScreenshotsAdminColumn' => 'bool', 'defaultTemplatesDisabled' => 'bool', 'publicTemplates' => 'bool',
            'excludedTemplates' => 'arr_int',
            // Builder
            'builderAutosaveDisabled' => 'bool', 'builderAutosaveInterval' => 'int', 'builderMode' => 'str',
            'builderDisablePanelAutoExpand' => 'bool', 'builderDisableGlobalClassesInterface' => 'bool',
            'builderVariablePickerHideValue' => 'bool', 'builderCodeVim' => 'bool', 'builderElementBreadcrumbs' => 'bool',
            'structureAutoSync' => 'bool', 'importImageOnPaste' => 'bool', 'builderQueryObjectType' => 'str',
            'builderQueryMaxResults' => 'int', 'enableDynamicDataPreview' => 'bool', 'builderGlobalClassesSync' => 'bool',
            'builderDisableRestApi' => 'bool',
            // Performance
            'disableEmojis' => 'bool', 'disableEmbed' => 'bool', 'disableGoogleFonts' => 'bool',
            'disableLazyLoad' => 'bool', 'offsetLazyLoad' => 'int', 'disableJqueryMigrate' => 'bool',
            'cacheQueryLoops' => 'bool', 'disableClassChaining' => 'bool', 'cssLoading' => 'str',
            'webfontLoading' => 'str', 'customFontsPreload' => 'bool', 'disableBricksCascadeLayer' => 'bool',
            // API keys
            'adobeFontsProjectId' => 'str', 'apiKeyUnsplash' => 'str', 'apiKeyGoogleMaps' => 'str',
            'apiKeyGoogleRecaptcha' => 'str', 'apiSecretKeyGoogleRecaptcha' => 'str', 'apiKeyHCaptcha' => 'str',
            'apiKeyTurnstile' => 'str', 'apiKeyMailchimp' => 'str', 'apiKeySendgrid' => 'str',
            'facebookAppId' => 'str', 'instagramAccessToken' => 'str',
            // Custom code
            'executeCodeEnabled' => 'bool', 'executeCodeCapabilities' => 'caps_exec',
            'customCss' => 'code', 'customScriptsHeader' => 'code',
            'customScriptsBodyHeader' => 'code', 'customScriptsBodyFooter' => 'code',
            // WooCommerce
            'woocommerceDisableBuilder' => 'bool', 'woocommerceUseBricksWooNotice' => 'bool',
            'woocommerceUseQtyInLoop' => 'bool', 'woocommerceUseVariationSwatches' => 'bool',
            'woocommerceEnableAjaxAddToCart' => 'bool', 'woocommerceAjaxAddingText' => 'str',
            'woocommerceAjaxAddedText' => 'str',
        ];
    }

    /** Roles eligible for Bricks capability toggles (those that can edit_posts), as {slug,label}. */
    private function bricks_eligible_roles(): array {
        $out = [];
        $roles = wp_roles();
        if ( $roles && is_array( $roles->roles ) ) {
            foreach ( $roles->get_names() as $slug => $label ) {
                $role = get_role( $slug );
                if ( $role && $role->has_cap( 'edit_posts' ) ) {
                    $out[] = [ 'slug' => sanitize_key( (string) $slug ), 'label' => translate_user_role( (string) $label ) ];
                }
            }
        }
        return $out;
    }

    /**
     * Which Bricks capability each `caps_*` type stands for.
     *
     * Read from Bricks' own constants when it is here, so MV never keeps a
     * second copy of a name Bricks could rename. The literals are the fallback
     * for a site where the class has not loaded yet - they are what Bricks'
     * includes/capabilities.php declares.
     */
    private function bricks_cap_for_type( string $type ): string {
        $has = class_exists( '\Bricks\Capabilities' );
        switch ( $type ) {
            case 'caps_svg':
                return $has ? \Bricks\Capabilities::UPLOAD_SVG : 'bricks_upload_svg';
            case 'caps_exec':
                return $has ? \Bricks\Capabilities::EXECUTE_CODE : 'bricks_execute_code';
            case 'caps_maint':
                return $has ? \Bricks\Capabilities::BYPASS_MAINTENANCE : 'bricks_bypass_maintenance';
            case 'caps_forms':
                return $has ? \Bricks\Capabilities::FORM_SUBMISSION_ACCESS : 'bricks_form_submission_access';
        }
        return '';
    }

    /**
     * The builder-access levels, as Bricks itself lists them.
     *
     * builder_caps() is where Bricks builds this - No access, Edit content, any
     * custom levels the site has defined, then Full access - so asking it is
     * the only way the matrix can show a custom level somebody added. The
     * fallback is the three Bricks ships with.
     */
    private function bricks_builder_levels(): array {
        if ( class_exists( '\Bricks\Capabilities' )
            && method_exists( '\Bricks\Capabilities', 'builder_caps' ) ) {
            $out = [];
            foreach ( (array) \Bricks\Capabilities::builder_caps() as $row ) {
                if ( ! is_array( $row ) || ! array_key_exists( 'capability', $row ) ) {
                    continue;
                }
                $out[] = [
                    'capability' => (string) $row['capability'],
                    'label'      => (string) ( $row['label'] ?? $row['capability'] ),
                ];
            }
            if ( $out ) {
                return $out;
            }
        }
        return [
            [ 'capability' => '', 'label' => 'No access' ],
            [ 'capability' => 'bricks_edit_content', 'label' => 'Edit content' ],
            [ 'capability' => 'bricks_full_access', 'label' => 'Full access' ],
        ];
    }

    /**
     * Which access level each role currently holds.
     *
     * A role can only hold one, so the first match wins and the empty string -
     * Bricks' own name for "no access" - is the answer when it holds none.
     * Read in the order Bricks lists them, most permissive last, so a role
     * that somehow holds two is reported as the stronger one rather than
     * whichever happened to be checked first.
     */
    private function bricks_access_matrix(): array {
        $levels = array_values( array_filter( array_column( $this->bricks_builder_levels(), 'capability' ) ) );
        $out    = [];
        foreach ( $this->bricks_all_roles() as $r ) {
            $role = get_role( $r['slug'] );
            $held = '';
            if ( $role ) {
                foreach ( $levels as $cap ) {
                    if ( $role->has_cap( $cap ) ) {
                        $held = $cap;
                    }
                }
            }
            $out[ $r['slug'] ] = $held;
        }
        return $out;
    }

    /**
     * Every role, which is what Bricks puts on its Builder access screen.
     *
     * Bricks has two lists and MV had copied one of them to both jobs. Its
     * Builder access loop is `wp_roles()->get_names()` with no filter at all -
     * that is why Subscriber is on that screen - while its SVG and code
     * settings loop the same names and `continue` on a role without
     * `edit_posts`. So the access LEVEL is offered to every role and the four
     * PERMISSIONS only to roles that can edit posts, exactly as Bricks does.
     */
    private function bricks_all_roles(): array {
        $out   = [];
        $roles = wp_roles();
        if ( $roles && is_array( $roles->roles ) ) {
            foreach ( $roles->get_names() as $slug => $label ) {
                $out[] = [
                    'slug'  => sanitize_key( (string) $slug ),
                    'label' => translate_user_role( (string) $label ),
                ];
            }
        }
        return $out;
    }

    /** Slugs of eligible roles that currently hold the given capability. */
    private function bricks_roles_with_cap( string $cap ): array {
        $out = [];
        foreach ( $this->bricks_eligible_roles() as $r ) {
            $role = get_role( $r['slug'] );
            if ( $role && $role->has_cap( $cap ) ) {
                $out[] = $r['slug'];
            }
        }
        return $out;
    }

    public function get_bricks_settings(): \WP_REST_Response {
        $settings = get_option( $this->bricks_settings_option_name(), [] );
        $settings = is_array( $settings ) ? $settings : [];
        $map      = $this->bricks_settings_type_map();
        $values   = [];
        foreach ( $map as $key => $type ) {
            if ( 'caps_level' === $type ) {
                $values[ $key ] = $this->bricks_access_matrix();
                continue;
            }
            $cap = $this->bricks_cap_for_type( $type );
            if ( '' !== $cap ) {
                $values[ $key ] = $this->bricks_roles_with_cap( $cap );
                continue;
            }
            if ( ! array_key_exists( $key, $settings ) ) {
                continue;
            }
            $raw = $settings[ $key ];
            if ( 'bool' === $type ) {
                $values[ $key ] = (bool) $raw;
            } elseif ( 'int' === $type ) {
                $values[ $key ] = (int) $raw;
            } elseif ( 'arr_key' === $type ) {
                $values[ $key ] = array_values( array_filter( array_map( 'sanitize_key', (array) $raw ) ) );
            } elseif ( 'arr_int' === $type ) {
                $values[ $key ] = array_values( array_filter( array_map( 'absint', (array) $raw ) ) );
            } else {
                $values[ $key ] = is_scalar( $raw ) ? (string) $raw : '';
            }
        }

        // Post types Bricks can edit (public, minus attachment) — mirrors Bricks' own list.
        $post_types = [];
        foreach ( get_post_types( [ 'public' => true ], 'objects' ) as $pt ) {
            if ( 'attachment' === $pt->name ) {
                continue;
            }
            $post_types[] = [ 'slug' => $pt->name, 'label' => (string) ( $pt->labels->singular_name ?? $pt->name ) ];
        }

        // Bricks content templates (for "excluded templates").
        $templates = [];
        $template_slug = defined( 'BRICKS_DB_TEMPLATE_SLUG' ) ? BRICKS_DB_TEMPLATE_SLUG : 'bricks_template';
        if ( post_type_exists( $template_slug ) ) {
            foreach ( get_posts( [ 'post_type' => $template_slug, 'post_status' => 'publish', 'posts_per_page' => 200, 'orderby' => 'title', 'order' => 'ASC' ] ) as $tpl ) {
                $templates[] = [ 'id' => (int) $tpl->ID, 'title' => get_the_title( $tpl ) ?: ( 'Untitled #' . $tpl->ID ) ];
            }
        }

        return new \WP_REST_Response( [
            'values'  => $values,
            'context' => [
                'woo_active'    => class_exists( 'WooCommerce' ),
                'bricks_active' => defined( 'BRICKS_VERSION' ),
                'post_types'    => $post_types,
                'templates'     => $templates,
                'roles'         => $this->bricks_eligible_roles(),
                /* The levels come from Bricks rather than from MV, so a custom
                   one somebody added shows up in the matrix without MV being
                   told about it. */
                'builder_levels' => $this->bricks_builder_levels(),
                /* Two lists, because Bricks has two: every role gets an access
                   level, and only roles that can edit posts are offered the
                   four permissions. */
                'level_roles'    => $this->bricks_all_roles(),
            ],
        ], 200 );
    }

    public function update_bricks_settings( \WP_REST_Request $request ) {
        if ( ! defined( 'BRICKS_VERSION' ) && ! class_exists( '\Bricks\Database' ) ) {
            return new \WP_Error( 've_bricks_missing', 'Bricks is not active on this site.', [ 'status' => 400 ] );
        }
        $data   = $request->get_json_params();
        $data   = is_array( $data ) ? $data : [];
        $incoming = isset( $data['values'] ) && is_array( $data['values'] ) ? $data['values'] : [];
        $map    = $this->bricks_settings_type_map();

        $option_name = $this->bricks_settings_option_name();
        $settings    = get_option( $option_name, [] );
        $settings    = is_array( $settings ) ? $settings : [];

        $saved = 0;
        foreach ( $incoming as $key => $raw ) {
            if ( ! isset( $map[ $key ] ) ) {
                continue; // never write outside the allowlist
            }
            $type = $map[ $key ];
            if ( 'caps_level' === $type ) {
                /* One level per role, and Bricks' own save_builder_capabilities
                   is what writes it - it removes every other level from the
                   role first, which is the whole reason not to do this with
                   add_cap by hand. An empty string is Bricks' own name for
                   "no access" and is passed through as one. */
                // Every role, for the level - Bricks does not filter this one.
                $eligible = array_column( $this->bricks_all_roles(), 'slug' );
                $allowed  = array_column( $this->bricks_builder_levels(), 'capability' );
                $matrix   = [];
                foreach ( (array) $raw as $role => $level ) {
                    $role  = sanitize_key( (string) $role );
                    $level = is_string( $level ) ? trim( $level ) : '';
                    if ( ! in_array( $role, $eligible, true ) ) {
                        continue;
                    }
                    if ( '' !== $level && ! in_array( $level, $allowed, true ) ) {
                        continue;
                    }
                    $matrix[ $role ] = $level;
                }
                if ( $matrix && class_exists( '\Bricks\Capabilities' )
                    && method_exists( '\Bricks\Capabilities', 'save_builder_capabilities' ) ) {
                    \Bricks\Capabilities::save_builder_capabilities( $matrix );
                }
                $saved++;
                continue;
            }
            $cap_for = $this->bricks_cap_for_type( $type );
            if ( '' !== $cap_for ) {
                // Capability keys mutate role caps via Bricks' own method, not the option.
                $roles = array_values( array_filter( array_map( 'sanitize_key', (array) $raw ) ) );
                // Only allow eligible roles to be granted.
                $eligible = array_column( $this->bricks_eligible_roles(), 'slug' );
                $roles = array_values( array_intersect( $roles, $eligible ) );
                // Mirror Bricks: never grant code-execution roles while the feature is off.
                if ( 'caps_exec' === $type && empty( $settings['executeCodeEnabled'] ) ) {
                    $roles = [];
                }
                if ( class_exists( '\Bricks\Capabilities' ) ) {
                    \Bricks\Capabilities::save_capabilities( $cap_for, $roles );
                }
                $saved++;
                continue;
            }
            if ( 'arr_key' === $type ) {
                $arr = array_values( array_filter( array_map( 'sanitize_key', (array) $raw ) ) );
                if ( $arr ) {
                    $settings[ $key ] = $arr;
                } else {
                    unset( $settings[ $key ] );
                }
                $saved++;
                continue;
            }
            if ( 'arr_int' === $type ) {
                $arr = array_values( array_filter( array_map( 'absint', (array) $raw ) ) );
                if ( $arr ) {
                    $settings[ $key ] = $arr;
                } else {
                    unset( $settings[ $key ] );
                }
                $saved++;
                continue;
            }
            if ( 'bool' === $type ) {
                // Bricks stores checkbox settings by presence — set true when on, unset when off.
                if ( ! empty( $raw ) ) {
                    $settings[ $key ] = true;
                } else {
                    unset( $settings[ $key ] );
                }
            } elseif ( 'int' === $type ) {
                if ( $raw === '' || $raw === null ) {
                    unset( $settings[ $key ] );
                } else {
                    $settings[ $key ] = (int) $raw;
                }
            } elseif ( 'code' === $type ) {
                $val = (string) wp_unslash( $raw );
                if ( '' === trim( $val ) ) {
                    unset( $settings[ $key ] );
                } else {
                    $settings[ $key ] = $val; // raw CSS/JS, admin-gated (same as Bricks)
                }
            } else { // str / enum
                $val = sanitize_text_field( (string) wp_unslash( $raw ) );
                if ( '' === $val ) {
                    unset( $settings[ $key ] );
                } else {
                    $settings[ $key ] = $val;
                }
            }
            $saved++;
        }

        update_option( $option_name, $settings );

        // Bricks caches settings statically; refresh so the running request sees new values.
        if ( class_exists( '\Bricks\Database' ) && isset( \Bricks\Database::$global_settings ) ) {
            \Bricks\Database::$global_settings = $settings;
        }

        return new \WP_REST_Response( [ 'saved' => (int) $saved ], 200 );
    }

    public function bricks_regenerate_css( \WP_REST_Request $request ) {
        if ( ! class_exists( '\Bricks\Assets_Files' ) || ! method_exists( '\Bricks\Assets_Files', 'regenerate_css_files' ) ) {
            return new \WP_Error( 've_bricks_regen_unavailable', 'Bricks CSS file generation is not available (external-files mode may be off).', [ 'status' => 400 ] );
        }
        \Bricks\Assets_Files::regenerate_css_files();
        return new \WP_REST_Response( [ 'ok' => true ], 200 );
    }

    /**
     * Custom HTML tags the site owner wants Bricks to allow (e.g. picture, source,
     * dialog, custom elements). Stored as a flat option and merged into Bricks via
     * the `bricks/allowed_html_tags` filter (see BricksAdapter::allowed_html_tags).
     */
    private function bricks_custom_tags_option(): string {
        return 've_bricks_custom_tags';
    }

    private function sanitize_bricks_custom_tags( $tags ): array {
        if ( ! is_array( $tags ) ) {
            $tags = preg_split( '/[\s,]+/', (string) $tags );
        }
        $clean = [];
        foreach ( (array) $tags as $tag ) {
            // Tag names: ASCII letters, digits and hyphens (hyphen enables custom elements).
            $tag = strtolower( trim( (string) $tag ) );
            $tag = preg_replace( '/[^a-z0-9-]/', '', $tag );
            if ( '' === $tag || in_array( $tag, $clean, true ) ) {
                continue;
            }
            $clean[] = $tag;
        }
        return array_values( $clean );
    }

    public function get_bricks_custom_tags(): \WP_REST_Response {
        $tags = get_option( $this->bricks_custom_tags_option(), [] );
        return new \WP_REST_Response( [ 'tags' => $this->sanitize_bricks_custom_tags( $tags ) ], 200 );
    }

    public function update_bricks_custom_tags( \WP_REST_Request $request ): \WP_REST_Response {
        $tags = $this->sanitize_bricks_custom_tags( $request->get_param( 'tags' ) );
        update_option( $this->bricks_custom_tags_option(), $tags, false );
        return new \WP_REST_Response( [ 'ok' => true, 'tags' => $tags ], 200 );
    }

    /**
     * #11 — Minimum canvas viewport settings (Bricks builder / Code2Bricks).
     */
    private function site_visibility_item( \WP_Post $post ): array {
        $type = get_post_type_object( $post->post_type );

        return [
            'id'    => (int) $post->ID,
            'title' => get_the_title( $post ) ?: sprintf( 'Untitled #%d', $post->ID ),
            'type'  => $type ? (string) $type->labels->singular_name : (string) $post->post_type,
        ];
    }

    public function get_site_visibility(): \WP_REST_Response {
        $settings   = get_option( $this->bricks_settings_option_name(), [] );
        $settings   = is_array( $settings ) ? $settings : [];
        $mode_value = (string) ( $settings['maintenanceMode'] ?? '' );
        $mode       = $mode_value === 'maintenance' ? 'maintenance' : ( $mode_value === 'comingSoon' ? 'coming' : 'live' );
        $excluded   = array_values( array_filter( array_map( 'absint', (array) ( $settings['maintenanceExcludedPosts'] ?? [] ) ) ) );
        $items      = [];

        if ( $excluded ) {
            $posts = get_posts( [
                'post_type'      => 'any',
                'post_status'    => 'publish',
                'posts_per_page' => count( $excluded ),
                'post__in'       => $excluded,
                'orderby'        => 'post__in',
            ] );
            $items = array_map( [ $this, 'site_visibility_item' ], $posts );
        }

        $template_slug = defined( 'BRICKS_DB_TEMPLATE_SLUG' ) ? BRICKS_DB_TEMPLATE_SLUG : 'bricks_template';
        $template_type = defined( 'BRICKS_DB_TEMPLATE_TYPE' ) ? BRICKS_DB_TEMPLATE_TYPE : '_bricks_template_type';
        $templates     = get_posts( [
            'post_type'      => $template_slug,
            'post_status'    => 'publish',
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
            'meta_key'       => $template_type,
            'meta_value'     => 'content',
        ] );
        $template_items = array_map(
            static function ( \WP_Post $template ): array {
                return [ 'id' => (int) $template->ID, 'title' => get_the_title( $template ) ?: sprintf( 'Untitled #%d', $template->ID ) ];
            },
            $templates
        );

        $site_url    = untrailingslashit( home_url( '/' ) );
        $preview_key = \VE\Core\SiteVisibility::get_preview_key();
        $selected_roles = array_values( array_filter( array_map( 'sanitize_key', (array) ( $settings['bypassMaintenanceUserRoles'] ?? [] ) ) ) );
        $role_items = [];
        $roles = wp_roles();
        if ( $roles && is_array( $roles->roles ) ) {
            foreach ( $roles->roles as $slug => $role ) {
                $slug = sanitize_key( (string) $slug );
                if ( $slug === '' || $slug === 'administrator' ) {
                    continue;
                }
                $role_items[] = [
                    'slug'  => $slug,
                    'label' => translate_user_role( (string) ( $role['name'] ?? $slug ) ),
                ];
            }
        }

        return new \WP_REST_Response( [
            'bricks_available' => post_type_exists( $template_slug ),
            'mode'             => $mode,
            'template'         => absint( $settings['maintenanceTemplate'] ?? 0 ),
            'templates'        => $template_items,
            'bypass_policy'    => $selected_roles ? 'custom' : 'logged_in',
            'bypass_roles'     => $selected_roles,
            'roles'            => $role_items,
            'render_header'    => ! empty( $settings['maintenanceRenderHeader'] ),
            'render_footer'    => ! empty( $settings['maintenanceRenderFooter'] ),
            'render_popups'    => ! empty( $settings['maintenanceRenderPopups'] ),
            'excluded'         => $items,
            'site_url'         => $site_url,
            'preview_key'      => $preview_key,
            'preview_url'      => add_query_arg( 'preview_key', rawurlencode( $preview_key ), $site_url ),
            'preview_enabled'  => \VE\Core\SiteVisibility::is_preview_enabled(),
        ], 200 );
    }

    public function update_site_visibility( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $data = is_array( $data ) ? $data : [];
        $mode = sanitize_key( (string) ( $data['mode'] ?? 'live' ) );

        if ( ! in_array( $mode, [ 'live', 'coming', 'maintenance' ], true ) ) {
            return new \WP_Error( 've_invalid_visibility_mode', 'Choose Live, Coming soon, or Maintenance.', [ 'status' => 400 ] );
        }

        $preview_key = sanitize_text_field( (string) ( $data['preview_key'] ?? '' ) );
        $preview_key = preg_replace( '/[^A-Za-z0-9_-]/', '', $preview_key );
        $preview_key = substr( (string) $preview_key, 0, 64 );
        if ( $preview_key === '' ) {
            return new \WP_Error( 've_invalid_preview_key', 'Enter a preview key using letters, numbers, dashes, or underscores.', [ 'status' => 400 ] );
        }

        $option_name = $this->bricks_settings_option_name();
        $settings    = get_option( $option_name, [] );
        $settings    = is_array( $settings ) ? $settings : [];

        if ( $mode === 'live' ) {
            unset( $settings['maintenanceMode'] );
        } else {
            $settings['maintenanceMode'] = $mode === 'coming' ? 'comingSoon' : 'maintenance';
        }

        $template = absint( $data['template'] ?? 0 );
        if ( $template ) {
            $settings['maintenanceTemplate'] = $template;
        } else {
            unset( $settings['maintenanceTemplate'] );
        }

        foreach ( [
            'render_header' => 'maintenanceRenderHeader',
            'render_footer' => 'maintenanceRenderFooter',
            'render_popups' => 'maintenanceRenderPopups',
        ] as $request_key => $setting_key ) {
            if ( ! empty( $data[ $request_key ] ) ) {
                $settings[ $setting_key ] = true;
            } else {
                unset( $settings[ $setting_key ] );
            }
        }

        if ( ( $data['bypass_policy'] ?? 'logged_in' ) === 'custom' ) {
            $available_roles = array_keys( wp_roles()->roles );
            $available_roles = array_values( array_diff( array_map( 'sanitize_key', $available_roles ), [ 'administrator' ] ) );
            $selected_roles  = array_values( array_unique( array_intersect(
                array_map( 'sanitize_key', (array) ( $data['bypass_roles'] ?? [] ) ),
                $available_roles
            ) ) );
            if ( $selected_roles ) {
                $settings['bypassMaintenanceUserRoles'] = $selected_roles;
            } else {
                unset( $settings['bypassMaintenanceUserRoles'] );
            }
        } else {
            unset( $settings['bypassMaintenanceUserRoles'] );
        }

        $excluded = array_values( array_unique( array_filter( array_map( 'absint', (array) ( $data['excluded'] ?? [] ) ) ) ) );
        if ( $excluded ) {
            $settings['maintenanceExcludedPosts'] = $excluded;
        } else {
            unset( $settings['maintenanceExcludedPosts'] );
        }

        update_option( $option_name, $settings );
        \VE\Core\SiteVisibility::save_preview_settings( ! empty( $data['preview_enabled'] ), $preview_key );

        return $this->get_site_visibility();
    }

    public function search_site_visibility_content( \WP_REST_Request $request ): \WP_REST_Response {
        $query = sanitize_text_field( (string) $request->get_param( 'q' ) );
        $posts = get_posts( [
            'post_type'      => 'any',
            'post_status'    => 'publish',
            'posts_per_page' => 20,
            'orderby'        => 'relevance title',
            'order'          => 'ASC',
            's'              => $query,
        ] );

        return new \WP_REST_Response( [
            'items' => array_map( [ $this, 'site_visibility_item' ], $posts ),
        ], 200 );
    }

    private function bricks_font_manager_available(): bool {
        return defined( 'BRICKS_DB_CUSTOM_FONTS' )
            && defined( 'BRICKS_DB_CUSTOM_FONT_FACES' )
            && defined( 'BRICKS_DB_CUSTOM_FONT_FACE_RULES' )
            && class_exists( '\Bricks\Custom_Fonts' );
    }

    private function can_manage_bricks_fonts(): bool {
        if ( ! $this->bricks_font_manager_available() || ! current_user_can( 'upload_files' ) ) {
            return false;
        }
        if ( class_exists( '\Bricks\Builder_Permissions' ) ) {
            return (bool) \Bricks\Builder_Permissions::user_has_permission( 'access_font_manager' );
        }
        return current_user_can( 'manage_options' );
    }

    private function font_manager_unavailable_response(): \WP_REST_Response {
        return new \WP_REST_Response( [
            'success'     => false,
            'available'   => $this->bricks_font_manager_available(),
            'can_manage'  => $this->can_manage_bricks_fonts(),
            'message'     => $this->bricks_font_manager_available()
                ? 'Your Bricks role does not allow access to the Font Manager.'
                : 'Bricks Custom Fonts is not available on this site.',
            'bricks_url'  => admin_url( 'edit.php?post_type=bricks_fonts' ),
        ], $this->bricks_font_manager_available() ? 403 : 409 );
    }

    private function font_variant_parts( string $key ): array {
        preg_match( '/^\d+/', $key, $match );
        $weight = isset( $match[0] ) ? max( 1, min( 1000, (int) $match[0] ) ) : 400;
        $style  = strtolower( str_replace( (string) $weight, '', $key ) );
        if ( ! in_array( $style, [ 'italic', 'oblique' ], true ) ) {
            $style = 'normal';
        }
        return [ $weight, $style ];
    }

    private function font_variant_key( $weight, $style ): string {
        $weight = max( 1, min( 1000, absint( $weight ) ?: 400 ) );
        $style  = sanitize_key( (string) $style );
        return (string) $weight . ( in_array( $style, [ 'italic', 'oblique' ], true ) ? $style : '' );
    }

    private function bricks_font_post( int $id ): ?\WP_Post {
        $post = get_post( $id );
        if ( ! $post || $post->post_type !== BRICKS_DB_CUSTOM_FONTS ) {
            return null;
        }
        return $post;
    }

    private function font_manager_file_payload( string $format, $source ): array {
        $attachment_id = 0;
        $url           = '';

        if ( is_array( $source ) ) {
            $attachment_id = absint( $source['attachment_id'] ?? $source['id'] ?? $source['ID'] ?? 0 );
            $url           = isset( $source['url'] ) ? esc_url_raw( (string) $source['url'] ) : '';
        } elseif ( is_numeric( $source ) ) {
            $attachment_id = absint( $source );
        } elseif ( is_string( $source ) && filter_var( $source, FILTER_VALIDATE_URL ) ) {
            $url           = esc_url_raw( $source );
            $attachment_id = absint( attachment_url_to_postid( $url ) );
        }

        if ( $attachment_id ) {
            $attachment_url = wp_get_attachment_url( $attachment_id );
            if ( $attachment_url ) {
                $url = esc_url_raw( $attachment_url );
            } elseif ( ! $url ) {
                $attachment = get_post( $attachment_id );
                if ( $attachment && $attachment->post_type === 'attachment' ) {
                    $url = esc_url_raw( (string) $attachment->guid );
                }
            }
        }

        $path = $attachment_id ? get_attached_file( $attachment_id ) : '';
        $name = $path ? wp_basename( (string) $path ) : wp_basename( (string) wp_parse_url( $url, PHP_URL_PATH ) );

        return [
            'format'        => sanitize_key( $format ),
            'attachment_id' => $attachment_id,
            'url'           => $url,
            'name'          => $name ?: strtoupper( sanitize_key( $format ) ) . ' font file',
            'size'          => $path && is_file( $path ) ? (int) filesize( $path ) : 0,
            'missing'       => $url === '',
        ];
    }

    private function font_manager_family_payload( \WP_Post $post ): array {
        $faces = get_post_meta( $post->ID, BRICKS_DB_CUSTOM_FONT_FACES, true );
        $faces = is_array( $faces ) ? $faces : [];
        $variants = [];
        foreach ( $faces as $key => $sources ) {
            if ( ! is_array( $sources ) ) {
                continue;
            }
            [ $weight, $style ] = $this->font_variant_parts( (string) $key );
            $files = [];
            foreach ( $sources as $format => $source ) {
                $files[] = $this->font_manager_file_payload( (string) $format, $source );
            }
            $variants[] = [
                'key'    => (string) $key,
                'weight' => $weight,
                'style'  => $style,
                'files'  => $files,
            ];
        }
        usort( $variants, static function ( $a, $b ) {
            return ( $a['weight'] <=> $b['weight'] ) ?: strcmp( $a['style'], $b['style'] );
        } );
        return [
            'id'       => (int) $post->ID,
            'family'   => get_the_title( $post ),
            'status'   => $post->post_status,
            'variants' => $variants,
        ];
    }

    private function refresh_bricks_font_rules(): void {
        if ( ! $this->bricks_font_manager_available() ) {
            return;
        }
        \Bricks\Custom_Fonts::$fonts = [];
        \Bricks\Custom_Fonts::$font_face_rules = '';
        \Bricks\Custom_Fonts::get_custom_fonts();
        if ( is_string( \Bricks\Custom_Fonts::$font_face_rules ) && \Bricks\Custom_Fonts::$font_face_rules !== '' ) {
            update_option( BRICKS_DB_CUSTOM_FONT_FACE_RULES, \Bricks\Custom_Fonts::$font_face_rules );
        } else {
            delete_option( BRICKS_DB_CUSTOM_FONT_FACE_RULES );
        }
    }

    /**
     * Score a media filename against the font file we are trying to recover.
     * 100 = same filename, 70 = same stem, 40 = family + weight both present.
     */
    /** Foundry-agnostic names for each numeric weight (Lato calls 100 "Hairline", etc.). */
    private function font_weight_synonyms( int $weight ): array {
        $map = [
            100 => [ 'thin', 'hairline' ],
            200 => [ 'extralight', 'ultralight' ],
            300 => [ 'light' ],
            400 => [ 'regular', 'normal', 'book' ],
            500 => [ 'medium' ],
            600 => [ 'semibold', 'demibold' ],
            700 => [ 'bold' ],
            800 => [ 'extrabold', 'ultrabold' ],
            900 => [ 'black', 'heavy' ],
        ];
        return $map[ $weight ] ?? [];
    }

    /**
     * Score a media filename against the variant we are recovering.
     * Returns 0 for anything that must never be offered (wrong family, wrong slant).
     */
    private function font_relink_score( string $candidate, string $expected, string $family, int $weight, string $style ): int {
        $c     = strtolower( $candidate );
        $e     = strtolower( $expected );
        $cstem = (string) preg_replace( '/\.[a-z0-9]+$/', '', $c );
        $cflat = (string) preg_replace( '/[^a-z0-9]+/', '', $cstem );
        $slug  = strtolower( (string) preg_replace( '/[^a-z0-9]+/i', '', $family ) );

        // The family must be present, otherwise this is somebody else's font.
        if ( $slug !== '' && strpos( $cflat, $slug ) === false ) {
            return 0;
        }

        // Slant must agree both ways — an upright variant must never take an italic file.
        $candidate_italic = ( strpos( $cflat, 'italic' ) !== false || strpos( $cflat, 'oblique' ) !== false );
        $wants_italic     = ( $style === 'italic' || $style === 'oblique' );
        if ( $candidate_italic !== $wants_italic ) {
            return 0;
        }

        // A real filename match still wins outright when we have one to compare.
        if ( $e !== '' && strpos( $e, ' ' ) === false ) {
            if ( $c === $e ) {
                return 100;
            }
            if ( $cstem === (string) preg_replace( '/\.[a-z0-9]+$/', '', $e ) ) {
                return 95;
            }
        }

        // Otherwise identify by weight: numeric (700) or foundry name (bold / hairline…).
        $score = 40; // family + slant already agree
        $matched_weight = false;
        if ( $weight && preg_match( '/(^|[^0-9])' . $weight . '([^0-9]|$)/', $cstem ) ) {
            $score         += 45;
            $matched_weight = true;
        } else {
            foreach ( $this->font_weight_synonyms( $weight ) as $name ) {
                if ( strpos( $cflat, $name ) !== false ) {
                    // "extrabold" also contains "bold", so require the longest sensible hit.
                    if ( $weight === 700 && ( strpos( $cflat, 'extrabold' ) !== false || strpos( $cflat, 'ultrabold' ) !== false || strpos( $cflat, 'semibold' ) !== false || strpos( $cflat, 'demibold' ) !== false ) ) {
                        continue;
                    }
                    if ( $weight === 300 && strpos( $cflat, 'extralight' ) !== false ) {
                        continue;
                    }
                    $score         += 45;
                    $matched_weight = true;
                    break;
                }
            }
        }

        // Regular/400 files are often unsuffixed — "Lato.woff2", or "Lato-Italic.woff2"
        // for the upright-weight italic. Drop the slant token before comparing.
        if ( ! $matched_weight && $weight === 400 ) {
            $bare = (string) preg_replace( '/(italic|oblique)/', '', $cflat );
            if ( $bare === $slug ) {
                $score         += 40;
                $matched_weight = true;
            }
        }

        return $matched_weight ? $score : 20;
    }

    /** True when ACF (free or Pro) is active. */
    private function acf_available(): bool {
        return function_exists( 'acf_get_field_groups' );
    }

    private function acf_unavailable_response(): \WP_REST_Response {
        return new \WP_REST_Response( [
            'available' => false,
            'message'   => 'Advanced Custom Fields is not active on this site.',
        ], 200 );
    }

    /**
     * GET — every ACF model in one payload: field groups, post types, taxonomies and
     * options pages. Used by Content Studio's content-model section.
     */
    public function acf_list_models(): \WP_REST_Response {
        if ( ! $this->acf_available() ) {
            return $this->acf_unavailable_response();
        }

        $groups = [];
        foreach ( acf_get_field_groups() as $group ) {
            $fields = function_exists( 'acf_get_fields' ) ? (array) acf_get_fields( $group ) : [];
            $groups[] = [
                'id'          => (int) ( $group['ID'] ?? 0 ),
                'key'         => (string) ( $group['key'] ?? '' ),
                'title'       => (string) ( $group['title'] ?? '' ),
                'active'      => ! isset( $group['active'] ) || (bool) $group['active'],
                'description' => (string) ( $group['description'] ?? '' ),
                'location'    => $group['location'] ?? [],
                'position'    => (string) ( $group['position'] ?? 'normal' ),
                'style'       => (string) ( $group['style'] ?? 'default' ),
                'label_placement'       => (string) ( $group['label_placement'] ?? 'top' ),
                'instruction_placement' => (string) ( $group['instruction_placement'] ?? 'label' ),
                'menu_order'            => (int) ( $group['menu_order'] ?? 0 ),
                'show_in_rest'          => (bool) ( $group['show_in_rest'] ?? false ),
                'hide_on_screen'        => (array) ( $group['hide_on_screen'] ?? [] ),
                'field_count' => count( $fields ),
                'fields'      => array_map( [ $this, 'acf_field_payload' ], $fields ),
            ];
        }

        $collect = static function ( string $fn ): array {
            if ( ! function_exists( $fn ) ) {
                return [];
            }
            $out = [];
            foreach ( (array) call_user_func( $fn ) as $item ) {
                $out[] = [
                    'id'       => (int) ( $item['ID'] ?? 0 ),
                    'key'      => (string) ( $item['key'] ?? '' ),
                    'title'    => (string) ( $item['title'] ?? ( $item['labels']['name'] ?? '' ) ),
                    'name'     => (string) ( $item['post_type'] ?? $item['taxonomy'] ?? $item['menu_slug'] ?? '' ),
                    'active'   => ! isset( $item['active'] ) || (bool) $item['active'],
                    'public'   => (bool) ( $item['public'] ?? false ),
                    'rest'     => (bool) ( $item['show_in_rest'] ?? false ),
                    'raw'      => $item,
                ];
            }
            return $out;
        };

        return new \WP_REST_Response( [
            'available'    => true,
            'field_groups' => $groups,
            'post_types'   => $collect( 'acf_get_acf_post_types' ),
            'taxonomies'   => $collect( 'acf_get_acf_taxonomies' ),
            'options_pages'=> $collect( 'acf_get_ui_options_pages' ),
        ], 200 );
    }

    /** Reduce an ACF field array to what the builder UI needs. */
    private function acf_field_payload( $field ): array {
        $field = (array) $field;
        return [
            'key'          => (string) ( $field['key'] ?? '' ),
            'label'        => (string) ( $field['label'] ?? '' ),
            'name'         => (string) ( $field['name'] ?? '' ),
            'type'         => (string) ( $field['type'] ?? 'text' ),
            'required'     => (bool) ( $field['required'] ?? false ),
            'instructions' => (string) ( $field['instructions'] ?? '' ),
            'placeholder'  => (string) ( $field['placeholder'] ?? '' ),
            'default_value'=> $field['default_value'] ?? '',
            'maxlength'    => (string) ( $field['maxlength'] ?? '' ),
            'wrapper'      => $field['wrapper'] ?? [ 'width' => '', 'class' => '', 'id' => '' ],
            'conditional'  => ! empty( $field['conditional_logic'] ),
        ];
    }

    public function acf_get_field_group( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! $this->acf_available() ) {
            return $this->acf_unavailable_response();
        }
        $group = acf_get_field_group( absint( $request->get_param( 'id' ) ) );
        if ( ! $group ) {
            return new \WP_REST_Response( [ 'message' => 'Field group not found.' ], 404 );
        }
        $fields = function_exists( 'acf_get_fields' ) ? (array) acf_get_fields( $group ) : [];
        return new \WP_REST_Response( [
            'available' => true,
            'group'     => $group,
            'fields'    => array_map( [ $this, 'acf_field_payload' ], $fields ),
        ], 200 );
    }

    /** PUT — persist group settings and its field list through ACF's own API. */
    public function acf_save_field_group( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! $this->acf_available() || ! function_exists( 'acf_update_field_group' ) ) {
            return $this->acf_unavailable_response();
        }
        $id    = absint( $request->get_param( 'id' ) );
        $group = acf_get_field_group( $id );
        if ( ! $group ) {
            return new \WP_REST_Response( [ 'message' => 'Field group not found.' ], 404 );
        }

        // Everything ACF's own Settings card exposes: Location Rules, Presentation and
        // Group Settings.
        foreach ( [ 'title', 'description', 'position', 'style', 'label_placement', 'instruction_placement' ] as $key ) {
            $value = $request->get_param( $key );
            if ( null !== $value ) {
                $group[ $key ] = sanitize_text_field( (string) $value );
            }
        }
        foreach ( [ 'active', 'show_in_rest' ] as $flag ) {
            if ( null !== $request->get_param( $flag ) ) {
                $group[ $flag ] = (bool) $request->get_param( $flag ) ? 1 : 0;
            }
        }
        if ( null !== $request->get_param( 'menu_order' ) ) {
            $group['menu_order'] = (int) $request->get_param( 'menu_order' );
        }
        if ( null !== $request->get_param( 'label' ) ) {
            $group['label'] = sanitize_text_field( (string) $request->get_param( 'label' ) );
        }
        if ( is_array( $request->get_param( 'hide_on_screen' ) ) ) {
            $group['hide_on_screen'] = array_values( array_map( 'sanitize_key', $request->get_param( 'hide_on_screen' ) ) );
        }
        if ( is_array( $request->get_param( 'location' ) ) ) {
            $group['location'] = $request->get_param( 'location' );
        }
        acf_update_field_group( $group );

        // Field list: update existing fields in place, append new ones, delete removed.
        $incoming = $request->get_param( 'fields' );
        if ( is_array( $incoming ) && function_exists( 'acf_update_field' ) ) {
            $existing = function_exists( 'acf_get_fields' ) ? (array) acf_get_fields( $group ) : [];
            $seen     = [];
            $order    = 0;
            foreach ( $incoming as $row ) {
                $row = (array) $row;
                $key = (string) ( $row['key'] ?? '' );
                $base = $key ? (array) acf_get_field( $key ) : [];
                $field = array_merge( $base, [
                    'label'         => sanitize_text_field( (string) ( $row['label'] ?? '' ) ),
                    'name'          => sanitize_key( (string) ( $row['name'] ?? '' ) ),
                    'type'          => sanitize_key( (string) ( $row['type'] ?? 'text' ) ),
                    'required'      => ! empty( $row['required'] ) ? 1 : 0,
                    'instructions'  => sanitize_textarea_field( (string) ( $row['instructions'] ?? '' ) ),
                    'placeholder'   => sanitize_text_field( (string) ( $row['placeholder'] ?? '' ) ),
                    'default_value' => $row['default_value'] ?? '',
                    'maxlength'     => (string) ( $row['maxlength'] ?? '' ),
                    'parent'        => $group['ID'],
                    'menu_order'    => $order++,
                ] );
                if ( isset( $row['wrapper'] ) && is_array( $row['wrapper'] ) ) {
                    $field['wrapper'] = [
                        'width' => sanitize_text_field( (string) ( $row['wrapper']['width'] ?? '' ) ),
                        'class' => sanitize_text_field( (string) ( $row['wrapper']['class'] ?? '' ) ),
                        'id'    => sanitize_text_field( (string) ( $row['wrapper']['id'] ?? '' ) ),
                    ];
                }
                $saved = acf_update_field( $field );
                if ( is_array( $saved ) && ! empty( $saved['key'] ) ) {
                    $seen[] = $saved['key'];
                }
            }
            if ( function_exists( 'acf_delete_field' ) ) {
                foreach ( $existing as $old ) {
                    $old_key = (string) ( $old['key'] ?? '' );
                    if ( $old_key && ! in_array( $old_key, $seen, true ) ) {
                        acf_delete_field( $old_key );
                    }
                }
            }
        }

        $group  = acf_get_field_group( $id );
        $fields = function_exists( 'acf_get_fields' ) ? (array) acf_get_fields( $group ) : [];
        return new \WP_REST_Response( [
            'ok'     => true,
            'group'  => $group,
            'fields' => array_map( [ $this, 'acf_field_payload' ], $fields ),
        ], 200 );
    }

    /** GET — rank media-library files that could replace a broken variant. */
    public function font_manager_relink_candidates( \WP_REST_Request $request ): \WP_REST_Response {
        $family   = sanitize_text_field( (string) $request->get_param( 'family' ) );
        $expected = sanitize_file_name( (string) $request->get_param( 'expected' ) );
        $weight   = absint( $request->get_param( 'weight' ) );
        $style    = sanitize_key( (string) ( $request->get_param( 'style' ) ?: 'normal' ) );

        $attachments = get_posts( [
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => 200,
            'fields'         => 'ids',
            's'              => $family ?: '',
        ] );
        if ( count( $attachments ) < 5 ) {
            $attachments = array_unique( array_merge( $attachments, get_posts( [
                'post_type'      => 'attachment',
                'post_status'    => 'inherit',
                'posts_per_page' => 300,
                'fields'         => 'ids',
            ] ) ) );
        }

        $allowed = [ 'woff2', 'woff', 'ttf', 'otf', 'eot', 'svg' ];
        $out     = [];
        foreach ( $attachments as $id ) {
            $path = get_attached_file( (int) $id );
            if ( ! $path ) {
                continue;
            }
            $name = wp_basename( (string) $path );
            $ext  = strtolower( (string) pathinfo( $name, PATHINFO_EXTENSION ) );
            if ( ! in_array( $ext, $allowed, true ) ) {
                continue;
            }
            $score = $this->font_relink_score( $name, $expected, $family, $weight, $style );
            if ( $score <= 0 ) {
                continue;
            }
            $out[] = [
                'attachment_id' => (int) $id,
                'name'          => $name,
                'url'           => (string) wp_get_attachment_url( (int) $id ),
                'format'        => $ext === 'ttf' ? 'truetype' : ( $ext === 'otf' ? 'opentype' : $ext ),
                'size'          => is_file( $path ) ? (int) filesize( $path ) : 0,
                'uploaded'      => get_the_date( 'Y-m-d', (int) $id ),
                'score'         => $score,
                'reason'        => $score >= 95 ? 'exact file' : ( $score >= 80 ? 'weight + style match' : 'same family only' ),
            ];
        }
        usort( $out, static function ( $a, $b ) {
            return $b['score'] <=> $a['score'];
        } );

        return new \WP_REST_Response( [ 'candidates' => array_slice( $out, 0, 12 ) ], 200 );
    }

    /** POST — repoint one variant/format at an existing attachment. */
    public function font_manager_relink( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! $this->bricks_font_manager_available() ) {
            return $this->font_manager_unavailable_response();
        }
        $id            = absint( $request->get_param( 'id' ) );
        $key           = (string) $request->get_param( 'variant' );
        $attachment_id = absint( $request->get_param( 'attachment_id' ) );
        $post          = $this->bricks_font_post( $id );

        if ( ! $post || ! $key || ! $attachment_id ) {
            return new \WP_REST_Response( [ 'message' => 'Font family, variant and attachment are required.' ], 400 );
        }
        $file = get_attached_file( $attachment_id );
        if ( ! $file || ! is_file( $file ) ) {
            return new \WP_REST_Response( [ 'message' => 'That attachment has no file on disk.' ], 400 );
        }

        $ext    = strtolower( (string) pathinfo( $file, PATHINFO_EXTENSION ) );
        $format = (string) ( $request->get_param( 'format' ) ?: ( $ext === 'ttf' ? 'truetype' : ( $ext === 'otf' ? 'opentype' : $ext ) ) );
        $format = sanitize_key( $format );

        $faces = get_post_meta( $post->ID, BRICKS_DB_CUSTOM_FONT_FACES, true );
        $faces = is_array( $faces ) ? $faces : [];
        if ( ! isset( $faces[ $key ] ) || ! is_array( $faces[ $key ] ) ) {
            $faces[ $key ] = [];
        }
        $faces[ $key ][ $format ] = $attachment_id;

        update_post_meta( $post->ID, BRICKS_DB_CUSTOM_FONT_FACES, $faces );
        $this->refresh_bricks_font_rules();

        return new \WP_REST_Response( [
            'ok'     => true,
            'family' => $this->font_manager_family_payload( $this->bricks_font_post( $id ) ?: $post ),
        ], 200 );
    }

    /**
     * Bricks' own custom-font list, freshly built.
     *
     * `Custom_Fonts::get_custom_fonts()` is Bricks' function and its static
     * cache lives for one request, so a REST call gets the list as it is now -
     * including the `fontFaces` CSS the builder needs to draw a preview of a
     * family it has never seen. Re-implementing that here would be a second
     * copy of somebody else's format, and the format is theirs to change.
     */
    public function get_bricks_custom_fonts(): \WP_REST_Response {
        if ( ! class_exists( '\Bricks\Custom_Fonts' ) ) {
            return new \WP_REST_Response( [ 'available' => false, 'custom' => [] ], 200 );
        }
        $fonts = \Bricks\Custom_Fonts::get_custom_fonts();
        return new \WP_REST_Response( [
            'available' => true,
            'custom'    => is_array( $fonts ) ? $fonts : [],
        ], 200 );
    }

    public function get_font_manager_families(): \WP_REST_Response {
        if ( ! $this->bricks_font_manager_available() ) {
            return $this->font_manager_unavailable_response();
        }
        $posts = get_posts( [
            'post_type'      => BRICKS_DB_CUSTOM_FONTS,
            'post_status'    => [ 'publish', 'draft' ],
            'posts_per_page' => -1,
            'orderby'        => 'title',
            'order'          => 'ASC',
        ] );
        return new \WP_REST_Response( [
            'success'    => true,
            'available'  => true,
            'can_manage' => $this->can_manage_bricks_fonts(),
            'bricks_url' => admin_url( 'edit.php?post_type=' . BRICKS_DB_CUSTOM_FONTS ),
            'families'   => array_map( [ $this, 'font_manager_family_payload' ], $posts ),
        ], 200 );
    }

    public function import_font_manager_variant( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! $this->can_manage_bricks_fonts() ) {
            return $this->font_manager_unavailable_response();
        }
        /* A font picked from the Media Library is already on this site. Uploading
           the same bytes again would leave two attachments for one file and a
           library that grows every time somebody reuses a font. */
        $existing = absint( $request->get_param( 'attachment_id' ) );
        if ( $existing ) {
            $mime = get_post_mime_type( $existing );
            if ( 'attachment' !== get_post_type( $existing ) || 'font/woff2' !== $mime ) {
                return new \WP_REST_Response( [
                    'success' => false,
                    'message' => 'That media item is not a WOFF2 font file.',
                ], 400 );
            }
        }

        $files = $request->get_file_params();
        $font_file = $files['font_file'] ?? null;
        if ( ! $existing && ( ! is_array( $font_file ) || empty( $font_file['tmp_name'] ) || ! is_uploaded_file( $font_file['tmp_name'] ) ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Choose a converted WOFF2 font file.' ], 400 );
        }
        $name = $existing
            ? sanitize_file_name( (string) basename( (string) get_attached_file( $existing ) ) )
            : sanitize_file_name( (string) ( $font_file['name'] ?? 'font.woff2' ) );
        if ( ! $existing ) {
            if ( strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) !== 'woff2' || (int) ( $font_file['size'] ?? 0 ) > 10 * MB_IN_BYTES ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => 'The imported font must be a WOFF2 file no larger than 10 MB.' ], 400 );
            }
            $handle = @fopen( $font_file['tmp_name'], 'rb' );
            $signature = $handle ? fread( $handle, 4 ) : '';
            if ( $handle ) {
                fclose( $handle );
            }
            if ( $signature !== 'wOF2' ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => 'That file is not a valid WOFF2 font.' ], 400 );
            }
        }

        $family = trim( sanitize_text_field( (string) $request->get_param( 'family' ) ) );
        if ( $family === '' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Enter a font family name.' ], 400 );
        }
        $family_id = absint( $request->get_param( 'family_id' ) );
        $post = $family_id ? $this->bricks_font_post( $family_id ) : null;
        if ( ! $post ) {
            $found = get_page_by_title( $family, OBJECT, BRICKS_DB_CUSTOM_FONTS );
            $post = $found instanceof \WP_Post ? $found : null;
        }
        if ( ! $post ) {
            $family_id = wp_insert_post( [
                'post_type'   => BRICKS_DB_CUSTOM_FONTS,
                'post_status' => 'publish',
                'post_title'  => $family,
            ], true );
            if ( is_wp_error( $family_id ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => $family_id->get_error_message() ], 500 );
            }
            $post = get_post( $family_id );
        }

        if ( $existing ) {
            $attachment_id = $existing;
            $uploaded      = [ 'file' => '' ];
        } else {
            require_once ABSPATH . 'wp-admin/includes/file.php';
            $uploaded = wp_handle_sideload( $font_file, [
                'test_form' => false,
                'mimes'     => [ 'woff2' => 'font/woff2' ],
            ] );
            if ( isset( $uploaded['error'] ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => (string) $uploaded['error'] ], 400 );
            }
            $attachment_id = wp_insert_attachment( [
                'post_mime_type' => 'font/woff2',
                'post_title'     => sanitize_text_field( pathinfo( $name, PATHINFO_FILENAME ) ),
                'post_status'    => 'inherit',
            ], $uploaded['file'], 0, true );
            if ( is_wp_error( $attachment_id ) ) {
                @unlink( $uploaded['file'] );
                return new \WP_REST_Response( [ 'success' => false, 'message' => $attachment_id->get_error_message() ], 500 );
            }
        }

        $variant_key = $this->font_variant_key( $request->get_param( 'weight' ), $request->get_param( 'style' ) );
        $faces = get_post_meta( $post->ID, BRICKS_DB_CUSTOM_FONT_FACES, true );
        $faces = is_array( $faces ) ? $faces : [];
        if ( isset( $faces[ $variant_key ]['woff2'] ) && empty( $request['replace'] ) ) {
            /* Only clean up what this request created. An attachment that was
               already in the library belongs to the library, and deleting it
               because a font family refused a duplicate would take a file the
               owner may be using somewhere else. */
            if ( ! $existing ) {
                wp_delete_attachment( $attachment_id, true );
            }
            return new \WP_REST_Response( [ 'success' => false, 'code' => 've_font_variant_exists', 'message' => 'That family already has this weight and style. Confirm replacement first.' ], 409 );
        }
        $faces[ $variant_key ] = [ 'woff2' => (int) $attachment_id ];
        update_post_meta( $post->ID, BRICKS_DB_CUSTOM_FONT_FACES, $faces );
        $this->refresh_bricks_font_rules();
        return new \WP_REST_Response( [
            'success' => true,
            'family'  => $this->font_manager_family_payload( get_post( $post->ID ) ),
            'message' => 'Imported into Bricks Font Manager.',
        ], 200 );
    }

    public function update_font_manager_family( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! $this->can_manage_bricks_fonts() ) {
            return $this->font_manager_unavailable_response();
        }
        $post = $this->bricks_font_post( absint( $request['id'] ) );
        if ( ! $post ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Font family not found.' ], 404 );
        }
        $params = $request->get_json_params();
        $family = trim( sanitize_text_field( (string) ( $params['family'] ?? $post->post_title ) ) );
        if ( $family === '' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Enter a font family name.' ], 400 );
        }
        if ( $family !== $post->post_title ) {
            $updated = wp_update_post( [ 'ID' => $post->ID, 'post_title' => $family ], true );
            if ( is_wp_error( $updated ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => $updated->get_error_message() ], 400 );
            }
        }
        $rename_from = sanitize_key( (string) ( $params['rename_from'] ?? '' ) );
        if ( $rename_from !== '' ) {
            $faces = get_post_meta( $post->ID, BRICKS_DB_CUSTOM_FONT_FACES, true );
            $faces = is_array( $faces ) ? $faces : [];
            $rename_to = $this->font_variant_key( $params['weight'] ?? 400, $params['style'] ?? 'normal' );
            if ( isset( $faces[ $rename_from ] ) && $rename_to !== $rename_from ) {
                if ( isset( $faces[ $rename_to ] ) ) {
                    return new \WP_REST_Response( [ 'success' => false, 'message' => 'That weight and style already exists.' ], 409 );
                }
                $faces[ $rename_to ] = $faces[ $rename_from ];
                unset( $faces[ $rename_from ] );
                update_post_meta( $post->ID, BRICKS_DB_CUSTOM_FONT_FACES, $faces );
            }
        }
        $this->refresh_bricks_font_rules();
        return new \WP_REST_Response( [
            'success' => true,
            'family'  => $this->font_manager_family_payload( get_post( $post->ID ) ),
            'message' => 'Bricks font updated.',
        ], 200 );
    }

    public function delete_font_manager_variant( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! $this->can_manage_bricks_fonts() ) {
            return $this->font_manager_unavailable_response();
        }
        $post = $this->bricks_font_post( absint( $request['id'] ) );
        $key = sanitize_key( (string) $request['variant'] );
        if ( ! $post ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Font family not found.' ], 404 );
        }
        $faces = get_post_meta( $post->ID, BRICKS_DB_CUSTOM_FONT_FACES, true );
        $faces = is_array( $faces ) ? $faces : [];
        if ( ! isset( $faces[ $key ] ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Font variant not found.' ], 404 );
        }
        unset( $faces[ $key ] );
        update_post_meta( $post->ID, BRICKS_DB_CUSTOM_FONT_FACES, $faces );
        $this->refresh_bricks_font_rules();
        return new \WP_REST_Response( [ 'success' => true, 'family' => $this->font_manager_family_payload( $post ) ], 200 );
    }

    public function delete_font_manager_family( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! $this->can_manage_bricks_fonts() ) {
            return $this->font_manager_unavailable_response();
        }
        $post = $this->bricks_font_post( absint( $request['id'] ) );
        if ( ! $post ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Font family not found.' ], 404 );
        }
        $trashed = wp_trash_post( $post->ID );
        if ( ! $trashed ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Font family could not be moved to Trash.' ], 500 );
        }
        $this->refresh_bricks_font_rules();
        return new \WP_REST_Response( [ 'success' => true, 'message' => 'Font family moved to Trash. Bricks can restore it.' ], 200 );
    }

    /**
     * Fold several Bricks font families into one.
     *
     * The faces move, the sources go to Trash, and nothing is deleted: a face
     * is a pointer to a Media Library attachment, and both the attachments and
     * the trashed families survive, so a merge the owner regrets is undone by
     * restoring them in Bricks.
     *
     * A weight and style the target already has is KEPT rather than overwritten
     * unless asked: the target is the family somebody chose to keep, and
     * silently replacing one of its faces with a same-named one from a family
     * being dissolved is a change nobody asked for.
     */
    public function merge_font_manager_families( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! $this->can_manage_bricks_fonts() ) {
            return $this->font_manager_unavailable_response();
        }
        $target = $this->bricks_font_post( absint( $request['id'] ) );
        if ( ! $target ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Font family not found.' ], 404 );
        }

        $params = $request->get_json_params();
        $from   = is_array( $params['from'] ?? null ) ? $params['from'] : [];
        $from   = array_values( array_unique( array_filter( array_map( 'absint', $from ) ) ) );
        if ( ! $from ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Name the families to merge in.' ], 400 );
        }
        $replace = ! empty( $params['replace'] );

        $faces = get_post_meta( $target->ID, BRICKS_DB_CUSTOM_FONT_FACES, true );
        $faces = is_array( $faces ) ? $faces : [];

        $moved  = 0;
        $kept   = [];
        $merged = [];
        foreach ( $from as $source_id ) {
            if ( $source_id === $target->ID ) {
                continue;   // a family cannot be merged into itself
            }
            $source = $this->bricks_font_post( $source_id );
            if ( ! $source ) {
                continue;
            }
            $source_faces = get_post_meta( $source->ID, BRICKS_DB_CUSTOM_FONT_FACES, true );
            $source_faces = is_array( $source_faces ) ? $source_faces : [];

            foreach ( $source_faces as $key => $face ) {
                if ( isset( $faces[ $key ] ) && ! $replace ) {
                    $kept[] = $source->post_title . ' · ' . $key;
                    continue;
                }
                $faces[ $key ] = $face;
                $moved++;
            }
            wp_trash_post( $source->ID );
            $merged[] = $source->post_title;
        }

        update_post_meta( $target->ID, BRICKS_DB_CUSTOM_FONT_FACES, $faces );
        $this->refresh_bricks_font_rules();

        return new \WP_REST_Response( [
            'success' => true,
            'family'  => $this->font_manager_family_payload( get_post( $target->ID ) ),
            'moved'   => $moved,
            'kept'    => $kept,
            'merged'  => $merged,
            'message' => $moved . ' ' . ( 1 === $moved ? 'variant' : 'variants' ) . ' moved into '
                . $target->post_title . '.'
                . ( $kept ? ' ' . count( $kept ) . ' already existed and were left alone.' : '' ),
        ], 200 );
    }

    public function can_read( ?\WP_REST_Request $request = null ): bool {
        if ( current_user_can( 'edit_posts' ) ) {
            return true;
        }

        return $request ? $this->sync_key_allowed_for_request( $request, false ) : false;
    }

    public function can_write( ?\WP_REST_Request $request = null ): bool {
        if ( current_user_can( 'manage_options' ) ) {
            return true;
        }

        return $request ? $this->sync_key_allowed_for_request( $request, true ) : false;
    }

    /**
     * The Figma credential is an integration principal, not a WordPress user.
     * Keep it on the token-model surface that the integration actually consumes.
     */
    private function sync_key_allowed_for_request( \WP_REST_Request $request, bool $write ): bool {
        $key = (string) $request->get_header( 'X-VE-Key' );
        if ( '' === $key || ! ( new \VE\Sync\PairingManager() )->validate_key( $key ) ) {
            return false;
        }

        $route  = (string) $request->get_route();
        $method = strtoupper( (string) $request->get_method() );
        if ( ! $write && 'GET' === $method && '/variable-engine/v1/settings' === $route ) {
            return true;
        }

        return (bool) preg_match(
            '#^/variable-engine/v1/(?:variables|generators|categories|palettes|themes|color-palettes|families)(?:/|$)#',
            $route
        );
    }

    public function can_manage_plugins( ?\WP_REST_Request $request = null ): bool {
        return current_user_can( 'activate_plugins' ) || current_user_can( 'update_plugins' ) || current_user_can( 'delete_plugins' );
    }

    public function can_run_plugin_action( \WP_REST_Request $request ): bool {
        $params = $request->get_json_params() ?: [];
        $action = sanitize_key( (string) ( $params['action'] ?? '' ) );
        $capability = [
            'activate'        => 'activate_plugins',
            'deactivate'      => 'activate_plugins',
            'auto_update_on'  => 'update_plugins',
            'auto_update_off' => 'update_plugins',
            'delete'          => 'delete_plugins',
        ][ $action ] ?? '';

        return '' !== $capability && current_user_can( $capability );
    }

    public function can_install_plugins(): bool {
        return current_user_can( 'install_plugins' );
    }

    public function can_upload_plugins(): bool {
        return current_user_can( 'install_plugins' ) && current_user_can( 'upload_plugins' );
    }

    public function can_export_media(): bool {
        return current_user_can( 'upload_files' );
    }

    public function can_save_user_preferences( ?\WP_REST_Request $request = null ): bool {
        return get_current_user_id() > 0 && current_user_can( 'edit_posts' );
    }

    private function sanitize_user_preferences( array $preferences ): array {
        $allowed = [
            'mimamsBarSettings',
            'mvQuickAddBar',
            've_skip_update_version',
            've_panel_mode',
            've_panel_pos',
            've_allow_multi_panels',
            've_deactivated_tools',
            've_deactivated_tool_surfaces',
            've_css_scss',
            've_css_source_order',
            've_css_disabled_sources',
            've_content_visible_groups',
            've_content_visible_groups_v2',
            've_content_status_filter',
            've_content_table_columns',
            've_content_editor_theme',
            've_content_studio_default_theme',
            've_content_studio_default_view',
            've_media_studio_default_view',
            've_content_media_picker_view',
            've_media_layout',
            've_media_filter',
            've_media_sort',
            've_media_collection_sort',
            've_media_collections',
            've_media_list_meta',
            've_media_list_meta_fields',
            've_media_quality_filter',
            've_media_quality_filters',
            've_media_saved_filters',
            've_media_detail_preview_mode',
            've_media_detail_preview_zoom',
            've_media_dynamic_collapsed',
            've_media_sidebar_width',
            've_media_hide_folders',
            've_media_collapsed_paths',
            've_media_replace_wp_library',
            've_media_auto_sync_external_folders',
            've_plugin_directory_view',
            've_fab_order',
            've_pos_ve_settings_pos',
            've_pos_ve_help_pos',
            've_pos_ve_css_studio_pos',
            've_pos_ve_css_recipes_pos',
            've_pos_ve_content_pos',
            've_pos_ve_media_pos',
            've_pos_ve_plugin_pos',
        ];
        $clean = [];
        foreach ( $allowed as $key ) {
            if ( ! array_key_exists( $key, $preferences ) ) {
                continue;
            }
            $value = $preferences[ $key ];
            if ( 'mvQuickAddBar' === $key ) {
                $slots = is_array( $value ) && isset( $value['slots'] ) && is_array( $value['slots'] )
                    ? $value['slots']
                    : [];
                $safe_slots = [];
                foreach ( array_slice( $slots, 0, 60 ) as $slot ) {
                    $slot = is_string( $slot ) ? trim( $slot ) : '';
                    if ( ! preg_match( '/^(?:el|cmp):[A-Za-z0-9_.:-]{1,190}$/', $slot ) ) {
                        continue;
                    }
                    if ( ! in_array( $slot, $safe_slots, true ) ) {
                        $safe_slots[] = $slot;
                    }
                }
                $clean[ $key ] = [ 'slots' => $safe_slots ];
            } elseif ( 've_media_collections' === $key ) {
                $clean[ $key ] = substr( sanitize_textarea_field( (string) $value ), 0, 200000 );
            } elseif ( is_array( $value ) ) {
                $clean[ $key ] = $this->sanitize_preference_value( $value, 0 );
            } elseif ( is_bool( $value ) || is_int( $value ) || is_float( $value ) ) {
                $clean[ $key ] = $value;
            } else {
                $clean[ $key ] = substr( sanitize_textarea_field( (string) $value ), 0, 20000 );
            }
        }
        return $clean;
    }

    private function sanitize_preference_value( array $value, int $depth ): array {
        if ( $depth >= 5 ) {
            return [];
        }
        $clean = [];
        $count = 0;
        foreach ( $value as $key => $item ) {
            if ( $count >= 200 ) {
                break;
            }
            $safe_key = is_int( $key ) ? $key : sanitize_key( (string) $key );
            if ( is_array( $item ) ) {
                $clean[ $safe_key ] = $this->sanitize_preference_value( $item, $depth + 1 );
            } elseif ( is_bool( $item ) || is_int( $item ) || is_float( $item ) ) {
                $clean[ $safe_key ] = $item;
            } else {
                $clean[ $safe_key ] = substr( sanitize_text_field( (string) $item ), 0, 2000 );
            }
            $count++;
        }
        return $clean;
    }

    private function media_collections_manager(): \VE\Core\MediaCollectionManager {
        $manager = new \VE\Core\MediaCollectionManager();
        $manager->register_taxonomy();
        return $manager;
    }

    public function list_media_collections(): \WP_REST_Response {
        $data = $this->media_collections_manager()->list_collections();
        return new \WP_REST_Response( [
            'success'     => true,
            'collections' => $data['collections'],
            'map'         => $data['map'],
            'taxonomy'    => \VE\Core\MediaCollectionManager::TAXONOMY,
        ], 200 );
    }

    public function create_media_collection( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $label = sanitize_text_field( (string) ( $params['label'] ?? $params['name'] ?? '' ) );
        if ( '' === trim( $label ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Collection name is required.' ], 400 );
        }
        $entry = [
            'icon'  => sanitize_key( (string) ( $params['icon'] ?? 'folder' ) ),
            'order' => absint( $params['order'] ?? 0 ),
        ];
        if ( isset( $params['ids'] ) && is_array( $params['ids'] ) ) {
            $entry['ids'] = array_values( array_unique( array_filter( array_map( 'absint', $params['ids'] ) ) ) );
        }
        $manager = $this->media_collections_manager();
        $term = $manager->ensure_collection( $label, $entry );
        if ( is_wp_error( $term ) || ! $term ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => is_wp_error( $term ) ? $term->get_error_message() : 'Collection could not be created.' ], 400 );
        }
        if ( isset( $entry['ids'] ) ) {
            $manager->set_collection_items( (int) $term->term_id, $entry['ids'] );
        }
        $data = $manager->list_collections();
        return new \WP_REST_Response( [ 'success' => true, 'collections' => $data['collections'], 'map' => $data['map'] ], 200 );
    }

    public function update_media_collection( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $collection = rawurldecode( (string) $request->get_param( 'collection' ) );
        $manager = $this->media_collections_manager();
        $term = $manager->get_term_by_any( $collection );
        if ( ! $term ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Collection not found.' ], 404 );
        }
        $label = sanitize_text_field( (string) ( $params['label'] ?? $params['name'] ?? $term->name ) );
        $entry = [
            'icon'  => sanitize_key( (string) ( $params['icon'] ?? get_term_meta( (int) $term->term_id, \VE\Core\MediaCollectionManager::META_ICON, true ) ?: 'folder' ) ),
            'order' => absint( $params['order'] ?? get_term_meta( (int) $term->term_id, \VE\Core\MediaCollectionManager::META_ORDER, true ) ),
        ];
        $new_term = $manager->ensure_collection( $label, $entry );
        if ( is_wp_error( $new_term ) || ! $new_term ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => is_wp_error( $new_term ) ? $new_term->get_error_message() : 'Collection could not be updated.' ], 400 );
        }
        if ( (int) $new_term->term_id !== (int) $term->term_id ) {
            $ids = $manager->collection_attachment_ids( (int) $term->term_id, -1 );
            $manager->set_collection_items( (int) $new_term->term_id, $ids );
            wp_delete_term( (int) $term->term_id, \VE\Core\MediaCollectionManager::TAXONOMY );
        }
        $data = $manager->list_collections();
        return new \WP_REST_Response( [ 'success' => true, 'collections' => $data['collections'], 'map' => $data['map'] ], 200 );
    }

    public function delete_media_collection( \WP_REST_Request $request ): \WP_REST_Response {
        $collection = rawurldecode( (string) $request->get_param( 'collection' ) );
        $manager = $this->media_collections_manager();
        $term = $manager->get_term_by_any( $collection );
        if ( ! $term ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Collection not found.' ], 404 );
        }
        $deleted = wp_delete_term( (int) $term->term_id, \VE\Core\MediaCollectionManager::TAXONOMY );
        if ( is_wp_error( $deleted ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $deleted->get_error_message() ], 400 );
        }
        $data = $manager->list_collections();
        return new \WP_REST_Response( [ 'success' => true, 'collections' => $data['collections'], 'map' => $data['map'] ], 200 );
    }

    public function sync_media_collections( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $collections = isset( $params['collections'] ) && is_array( $params['collections'] ) ? $params['collections'] : [];
        $delete_missing = ! empty( $params['delete_missing'] );
        $data = $this->media_collections_manager()->sync_from_map( $collections, $delete_missing );
        return new \WP_REST_Response( [ 'success' => true, 'collections' => $data['collections'], 'map' => $data['map'] ], 200 );
    }

    public function assign_media_collection( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $collection = $params['collection_id'] ?? ( $params['collection_key'] ?? ( $params['collection'] ?? '' ) );
        $checked = rest_sanitize_boolean( $params['checked'] ?? false );
        if ( ! $attachment_id || '' === (string) $collection ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Attachment and collection are required.' ], 400 );
        }
        $ok = $this->media_collections_manager()->assign_attachment( $attachment_id, $collection, $checked );
        if ( ! $ok ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Collection assignment failed.' ], 400 );
        }
        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function get_media_collection_items( \WP_REST_Request $request ): \WP_REST_Response {
        $collection = rawurldecode( (string) $request->get_param( 'collection' ) );
        $limit = absint( $request->get_param( 'limit' ) ?: 100 );
        $limit = $limit > 0 ? min( $limit, 500 ) : 100;
        $items = $this->media_collections_manager()->query_items( [
            'collection'       => $collection,
            'limit'            => $limit,
            'include_children' => rest_sanitize_boolean( $request->get_param( 'include_children' ) ?? false ),
            'mime'             => sanitize_text_field( (string) ( $request->get_param( 'mime' ) ?? '' ) ),
        ] );
        $payload = array_map( function ( $post ) {
            return $this->media_item_payload( (int) $post->ID );
        }, is_array( $items ) ? $items : [] );
        return new \WP_REST_Response( [ 'success' => true, 'items' => $payload, 'count' => count( $payload ) ], 200 );
    }

    public function get_media_folders(): \WP_REST_Response {
        $folders = [];
        $attachment_map = [];

        $taxonomies = [ 'happyfiles_category', 'media_folder', 'folder', 'attachment_category' ];
        $active_tax = null;

        foreach ( $taxonomies as $tax ) {
            if ( taxonomy_exists( $tax ) ) {
                $active_tax = $tax;
                break;
            }
        }

        if ( $active_tax ) {
            $terms = get_terms( [ 'taxonomy' => $active_tax, 'hide_empty' => false ] );
            if ( ! is_wp_error( $terms ) ) {
                foreach ( $terms as $term ) {
                    $folders[] = [
                        'id'     => (string) $term->term_id,
                        'name'   => $term->name,
                        'slug'   => $term->slug,
                        'parent' => (string) ( $term->parent ?? 0 ),
                    ];

                    $posts = get_posts( [
                        'post_type'      => 'attachment',
                        'posts_per_page' => -1,
                        'post_status'    => 'any',
                        'fields'         => 'ids',
                        'tax_query'      => [
                            [
                                'taxonomy' => $active_tax,
                                'field'    => 'term_id',
                                'terms'    => $term->term_id,
                            ],
                        ],
                    ] );
                    foreach ( $posts as $pid ) {
                        $attachment_map[ $pid ][] = (string) $term->term_id;
                    }
                }
            }
        }

        global $wpdb;
        $fb_table = $wpdb->prefix . 'fb_attachment_folders';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$fb_table'" ) === $fb_table ) {
            $fb_folders_table = $wpdb->prefix . 'fb_folders';
            $fb_columns = $wpdb->get_col( "DESC $fb_folders_table", 0 );
            $fb_parent_column = in_array( 'parent', $fb_columns, true ) ? 'parent' : ( in_array( 'parent_id', $fb_columns, true ) ? 'parent_id' : '' );
            $fb_parent_select = $fb_parent_column ? ', ' . $fb_parent_column . ' AS parent_id' : ', 0 AS parent_id';
            $fb_folders = $wpdb->get_results( "SELECT id, name $fb_parent_select FROM $fb_folders_table" );
            foreach ( $fb_folders as $f ) {
                $folders[] = [
                    'id'   => 'fb-' . $f->id,
                    'name' => $f->name,
                    'slug' => 'fb-' . $f->id,
                    'parent' => ! empty( $f->parent_id ) ? 'fb-' . $f->parent_id : '0',
                ];
            }
            $fb_relations = $wpdb->get_results( "SELECT attachment_id, folder_id FROM $fb_table" );
            foreach ( $fb_relations as $r ) {
                $attachment_map[ $r->attachment_id ][] = 'fb-' . $r->folder_id;
            }
        }

        return new \WP_REST_Response( [
            'folders' => $folders,
            'map'     => $attachment_map,
        ], 200 );
    }

    public function assign_media_folder( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = (int) ( $params['attachment_id'] ?? 0 );
        $folder_id = $params['folder_id'] ?? '';
        $checked = (bool) ( $params['checked'] ?? false );

        if ( ! $attachment_id ) {
            return new \WP_REST_Response( [ 'success' => false ], 400 );
        }

        $taxonomies = [ 'happyfiles_category', 'media_folder', 'folder', 'attachment_category' ];
        $active_tax = null;
        foreach ( $taxonomies as $tax ) {
            if ( taxonomy_exists( $tax ) ) {
                $active_tax = $tax;
                break;
            }
        }

        if ( $active_tax && is_numeric( $folder_id ) ) {
            $term_id = (int) $folder_id;
            $current_terms = wp_get_object_terms( $attachment_id, $active_tax, [ 'fields' => 'ids' ] );
            if ( is_wp_error( $current_terms ) ) {
                $current_terms = [];
            }
            if ( $checked ) {
                $current_terms[] = $term_id;
            } else {
                $current_terms = array_filter( $current_terms, function( $id ) use ( $term_id ) {
                    return $id !== $term_id;
                } );
            }
            wp_set_object_terms( $attachment_id, array_values( array_unique( $current_terms ) ), $active_tax );
            return new \WP_REST_Response( [ 'success' => true ], 200 );
        }

        global $wpdb;
        $fb_table = $wpdb->prefix . 'fb_attachment_folders';
        if ( strpos( $folder_id, 'fb-' ) === 0 && $wpdb->get_var( "SHOW TABLES LIKE '$fb_table'" ) === $fb_table ) {
            $fb_folder_id = (int) substr( $folder_id, 3 );
            if ( $checked ) {
                $wpdb->delete( $fb_table, [ 'attachment_id' => $attachment_id ] );
                $wpdb->insert( $fb_table, [ 'attachment_id' => $attachment_id, 'folder_id' => $fb_folder_id ] );
            } else {
                $wpdb->delete( $fb_table, [ 'attachment_id' => $attachment_id, 'folder_id' => $fb_folder_id ] );
            }
            return new \WP_REST_Response( [ 'success' => true ], 200 );
        }

        return new \WP_REST_Response( [ 'success' => false ], 400 );
    }

    private function media_item_payload( int $attachment_id ): array {
        $post = get_post( $attachment_id );
        $meta = wp_get_attachment_metadata( $attachment_id );
        if ( ! is_array( $meta ) ) {
            $meta = [];
        }

        $file = (string) get_attached_file( $attachment_id );
        $action_history = get_post_meta( $attachment_id, '_mv_media_action_history', true );
        if ( ! is_array( $action_history ) ) {
            $action_history = [];
        }
        $history = get_post_meta( $attachment_id, '_mv_media_replace_history', true );
        if ( ! is_array( $history ) ) {
            $history = $action_history;
        }

        return [
            'id'            => $attachment_id,
            'date'          => $post ? $post->post_date_gmt : '',
            'date_local'    => $post ? $post->post_date : '',
            'modified'      => $post ? $post->post_modified_gmt : '',
            'modified_local'=> $post ? $post->post_modified : '',
            'author'        => $post ? (int) $post->post_author : 0,
            'author_name'   => ( $post && $post->post_author ) ? get_the_author_meta( 'display_name', (int) $post->post_author ) : '',
            'slug'          => $post ? $post->post_name : '',
            'title'         => [ 'rendered' => $post ? get_the_title( $attachment_id ) : '', 'raw' => $post ? $post->post_title : '' ],
            'caption'       => [ 'rendered' => $post ? wp_kses_post( wpautop( $post->post_excerpt ) ) : '', 'raw' => $post ? $post->post_excerpt : '' ],
            'description'   => [ 'rendered' => $post ? wp_kses_post( wpautop( $post->post_content ) ) : '', 'raw' => $post ? $post->post_content : '' ],
            'source_url'    => wp_get_attachment_url( $attachment_id ),
            'filename'      => $file ? wp_basename( $file ) : '',
            'file_size'     => ( $file && file_exists( $file ) ) ? (int) filesize( $file ) : 0,
            'mime_type'     => get_post_mime_type( $attachment_id ),
            'alt_text'      => get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ),
            'media_details' => $meta,
            'replace_history' => array_slice( array_values( $history ), 0, 12 ),
            'action_history'  => array_slice( array_values( $action_history ), 0, 20 ),
            'mv_collections' => wp_get_object_terms( $attachment_id, \VE\Core\MediaCollectionManager::TAXONOMY, [ 'fields' => 'ids' ] ),
        ];
    }

    private function media_history_base_dir(): string {
        $upload = wp_upload_dir();
        $dir = trailingslashit( (string) ( $upload['basedir'] ?? '' ) ) . 'variable-engine/media-history';
        wp_mkdir_p( $dir );
        return $dir;
    }

    private function media_history_base_url(): string {
        $upload = wp_upload_dir();
        return trailingslashit( (string) ( $upload['baseurl'] ?? '' ) ) . 'variable-engine/media-history';
    }

    private function backup_media_file_for_history( int $attachment_id, string $file, string $reason = 'change' ): array {
        if ( ! $file || ! file_exists( $file ) || ! is_readable( $file ) ) {
            return [];
        }
        $dir = trailingslashit( $this->media_history_base_dir() ) . $attachment_id;
        wp_mkdir_p( $dir );
        $basename = wp_basename( $file );
        $safe_reason = sanitize_file_name( $reason ?: 'change' );
        $backup_name = gmdate( 'YmdHis' ) . '-' . $safe_reason . '-' . $basename;
        $backup_path = trailingslashit( $dir ) . $backup_name;
        if ( ! @copy( $file, $backup_path ) ) {
            return [];
        }
        return [
            'backup_path' => $backup_path,
            'backup_url'  => trailingslashit( $this->media_history_base_url() ) . $attachment_id . '/' . rawurlencode( $backup_name ),
        ];
    }

    private function push_media_action_history( int $attachment_id, array $entry ): array {
        $history = get_post_meta( $attachment_id, '_mv_media_action_history', true );
        if ( ! is_array( $history ) ) {
            $history = [];
        }
        $entry = array_merge( [
            'rollback_id' => wp_generate_uuid4(),
            'at'          => current_time( 'mysql' ),
            'user'        => get_current_user_id(),
        ], $entry );
        array_unshift( $history, $entry );
        $history = array_slice( array_values( $history ), 0, 24 );
        update_post_meta( $attachment_id, '_mv_media_action_history', $history );

        $replace_history = array_values( array_filter( $history, function( $row ) {
            return ! empty( $row['action'] ) && in_array( $row['action'], [ 'replace', 'convert', 'compress', 'rename', 'rollback' ], true );
        } ) );
        update_post_meta( $attachment_id, '_mv_media_replace_history', array_slice( $replace_history, 0, 12 ) );
        return $entry;
    }

    private function add_media_url_import_history( array $entry ): void {
        $history = get_option( 've_media_url_import_history', [] );
        if ( ! is_array( $history ) ) {
            $history = [];
        }
        $entry = array_merge( [
            'id'     => wp_generate_uuid4(),
            'at'     => current_time( 'mysql' ),
            'user'   => get_current_user_id(),
            'status' => 'complete',
        ], $entry );
        array_unshift( $history, $entry );
        update_option( 've_media_url_import_history', array_slice( array_values( $history ), 0, 30 ), false );
    }

    private function media_usage_report_for_attachment( int $attachment_id ) {
        $attachment = $attachment_id ? get_post( $attachment_id ) : null;
        if ( ! $attachment || 'attachment' !== $attachment->post_type ) {
            return new \WP_Error( 'mv_media_not_found', 'Attachment not found.' );
        }

        global $wpdb;

        $url = (string) wp_get_attachment_url( $attachment_id );
        $file = (string) get_attached_file( $attachment_id );
        $path = $url ? (string) wp_parse_url( $url, PHP_URL_PATH ) : '';
        $basename = $file ? wp_basename( $file ) : ( $path ? wp_basename( $path ) : '' );
        $terms = array_values( array_unique( array_filter( [
            $url,
            $basename,
            'wp-image-' . $attachment_id,
            '"id":' . $attachment_id,
            '"id":"' . $attachment_id . '"',
            'attachment_' . $attachment_id,
            'attachment-' . $attachment_id,
        ] ) ) );

        $like_clause = function ( string $column ) use ( $wpdb, $terms ): string {
            $parts = [];
            foreach ( $terms as $term ) {
                $parts[] = $wpdb->prepare( "{$column} LIKE %s", '%' . $wpdb->esc_like( $term ) . '%' );
            }
            return $parts ? '(' . implode( ' OR ', $parts ) . ')' : '1=0';
        };

        $item_from_post = function ( $post, string $source, string $detail = '' ): array {
            return [
                'id'     => (int) $post->ID,
                'label'  => get_the_title( $post->ID ) ?: '(no title)',
                'type'   => $post->post_type,
                'status' => $post->post_status,
                'source' => $source,
                'detail' => $detail,
                'edit'   => get_edit_post_link( $post->ID, 'raw' ),
            ];
        };

        $groups = [
            'featured' => [],
            'content'  => [],
            'meta'     => [],
            'options'  => [],
        ];

        $featured_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT p.ID, p.post_title, p.post_type, p.post_status
             FROM {$wpdb->posts} p
             INNER JOIN {$wpdb->postmeta} pm ON pm.post_id = p.ID
             WHERE pm.meta_key = '_thumbnail_id' AND pm.meta_value = %s
             ORDER BY p.post_modified_gmt DESC
             LIMIT 25",
            (string) $attachment_id
        ) );
        foreach ( $featured_rows as $row ) {
            $groups['featured'][] = $item_from_post( $row, 'Featured image' );
        }

        if ( $terms ) {
            $content_rows = $wpdb->get_results(
                "SELECT ID, post_title, post_type, post_status
                 FROM {$wpdb->posts}
                 WHERE post_type NOT IN ('attachment','revision','nav_menu_item')
                   AND " . $like_clause( 'post_content' ) . "
                 ORDER BY post_modified_gmt DESC
                 LIMIT 25"
            );
            foreach ( $content_rows as $row ) {
                $groups['content'][] = $item_from_post( $row, 'Post content' );
            }

            $ignored_meta_keys = [
                '_thumbnail_id',
                '_wp_attached_file',
                '_wp_attachment_metadata',
                '_wp_attachment_image_alt',
                '_wp_attachment_backup_sizes',
                '_wp_attachment_context',
                '_mv_media_replace_history',
                '_mv_media_action_history',
            ];
            $ignored_meta_placeholders = implode( ',', array_fill( 0, count( $ignored_meta_keys ), '%s' ) );
            $meta_sql = "SELECT pm.post_id, pm.meta_key, p.post_title, p.post_type, p.post_status
                 FROM {$wpdb->postmeta} pm
                 INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
                 WHERE pm.meta_key NOT IN ({$ignored_meta_placeholders})
                   AND pm.post_id <> %d
                   AND p.post_type NOT IN ('attachment','revision','nav_menu_item')
                   AND " . $like_clause( 'pm.meta_value' ) . "
                 ORDER BY p.post_modified_gmt DESC
                 LIMIT 25";
            $meta_rows = $wpdb->get_results( $wpdb->prepare(
                $meta_sql,
                array_merge( $ignored_meta_keys, [ $attachment_id ] )
            ) );
            foreach ( $meta_rows as $row ) {
                $post_stub = (object) [
                    'ID'          => (int) $row->post_id,
                    'post_title'  => $row->post_title,
                    'post_type'   => $row->post_type,
                    'post_status' => $row->post_status,
                ];
                $groups['meta'][] = $item_from_post( $post_stub, 'Post meta', (string) $row->meta_key );
            }

            $option_rows = $wpdb->get_results(
                "SELECT option_name
                 FROM {$wpdb->options}
                 WHERE option_name NOT LIKE '\\_transient\\_%'
                   AND option_name NOT LIKE '\\_site\\_transient\\_%'
                   AND " . $like_clause( 'option_value' ) . "
                 ORDER BY option_name ASC
                 LIMIT 15"
            );
            foreach ( $option_rows as $row ) {
                $groups['options'][] = [
                    'id'     => (string) $row->option_name,
                    'label'  => (string) $row->option_name,
                    'type'   => 'option',
                    'status' => '',
                    'source' => 'WordPress option',
                    'detail' => 'Stored option data',
                    'edit'   => '',
                ];
            }
        }

        $total = 0;
        foreach ( $groups as $rows ) {
            $total += count( $rows );
        }

        return [
            'success' => true,
            'total'   => $total,
            'unused'  => 0 === $total,
            'groups'  => $groups,
            'limited' => $total >= 90,
        ];
    }

    public function scan_unused_media( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $ids = isset( $params['attachment_ids'] ) && is_array( $params['attachment_ids'] ) ? $params['attachment_ids'] : [];
        $ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );

        if ( empty( $ids ) ) {
            $ids = get_posts( [
                'post_type'      => 'attachment',
                'post_status'    => 'inherit',
                'post_mime_type' => 'image',
                'posts_per_page' => 500,
                'fields'         => 'ids',
                'orderby'        => 'date',
                'order'          => 'DESC',
            ] );
        }

        $ids = array_slice( $ids, 0, 500 );
        if ( empty( $ids ) ) {
            return new \WP_REST_Response( [
                'success'     => true,
                'unused_ids'  => [],
                'used_ids'    => [],
                'skipped_ids' => [],
                'scanned'     => 0,
                'limited'     => false,
                'message'     => 'No image attachments were available to scan.',
            ], 200 );
        }

        global $wpdb;

        $refs_by_id = [];
        $used_map = [];
        $skipped = [];
        foreach ( $ids as $id ) {
            $id = absint( $id );
            if ( ! $id || get_post_type( $id ) !== 'attachment' || 0 !== strpos( (string) get_post_mime_type( $id ), 'image/' ) ) {
                $skipped[] = $id;
                continue;
            }

            $url = (string) wp_get_attachment_url( $id );
            $file = (string) get_attached_file( $id );
            $path = $url ? (string) wp_parse_url( $url, PHP_URL_PATH ) : '';
            $basename = $file ? wp_basename( $file ) : ( $path ? wp_basename( $path ) : '' );
            $refs_by_id[ $id ] = array_values( array_unique( array_filter( [
                $url,
                $path,
                $basename,
                'wp-image-' . $id,
                '"id":' . $id,
                '"id":"' . $id . '"',
                'attachment_' . $id,
                'attachment-' . $id,
            ] ) ) );
            $used_map[ $id ] = false;
        }

        if ( empty( $refs_by_id ) ) {
            return new \WP_REST_Response( [
                'success'     => true,
                'unused_ids'  => [],
                'used_ids'    => [],
                'skipped_ids' => $skipped,
                'scanned'     => 0,
                'limited'     => false,
                'message'     => 'No image attachments were available to scan.',
            ], 200 );
        }

        $basename_map = [];
        foreach ( $refs_by_id as $id => $terms ) {
            foreach ( $terms as $term ) {
                $term = (string) $term;
                if ( '' === $term ) {
                    continue;
                }
                $basename = wp_basename( $term );
                if ( $basename && false !== strpos( $basename, '.' ) ) {
                    $basename_map[ $basename ][] = (int) $id;
                }
            }
        }

        $mark_refs_in_text = function ( $text ) use ( &$used_map, $basename_map ): void {
            if ( ! is_string( $text ) || '' === $text ) {
                return;
            }

            if ( preg_match_all( '/(?:wp-image-|attachment[_-])(\d+)|["\']id["\']\s*:\s*["\']?(\d+)/i', $text, $matches, PREG_SET_ORDER ) ) {
                foreach ( $matches as $match ) {
                    $id = absint( ! empty( $match[1] ) ? $match[1] : ( $match[2] ?? 0 ) );
                    if ( $id && isset( $used_map[ $id ] ) ) {
                        $used_map[ $id ] = true;
                    }
                }
            }

            if ( empty( $basename_map ) ) {
                return;
            }

            $lower_text = strtolower( $text );
            if ( false === strpos( $lower_text, 'uploads' )
                && false === strpos( $lower_text, '.jpg' )
                && false === strpos( $lower_text, '.jpeg' )
                && false === strpos( $lower_text, '.png' )
                && false === strpos( $lower_text, '.webp' )
                && false === strpos( $lower_text, '.gif' )
                && false === strpos( $lower_text, '.svg' ) ) {
                return;
            }

            foreach ( $basename_map as $basename => $ids_for_basename ) {
                $first_id = (int) reset( $ids_for_basename );
                if ( $first_id && ! empty( $used_map[ $first_id ] ) ) {
                    continue;
                }
                if ( false !== strpos( $text, $basename ) ) {
                    foreach ( $ids_for_basename as $id ) {
                        if ( isset( $used_map[ $id ] ) ) {
                            $used_map[ $id ] = true;
                        }
                    }
                }
            }
        };

        $placeholders = implode( ',', array_fill( 0, count( $refs_by_id ), '%d' ) );
        $featured_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT DISTINCT meta_value FROM {$wpdb->postmeta} WHERE meta_key = '_thumbnail_id' AND meta_value IN ({$placeholders})",
            array_keys( $refs_by_id )
        ) );
        foreach ( $featured_ids as $featured_id ) {
            $featured_id = absint( $featured_id );
            if ( isset( $used_map[ $featured_id ] ) ) {
                $used_map[ $featured_id ] = true;
            }
        }

        $candidate_like = function ( string $column ) use ( $wpdb ): string {
            $needles = [ 'wp-image-', '/uploads/', 'wp-content/uploads', '"id":', 'attachment_', 'attachment-' ];
            $parts = [];
            foreach ( $needles as $needle ) {
                $parts[] = $wpdb->prepare( "{$column} LIKE %s", '%' . $wpdb->esc_like( $needle ) . '%' );
            }
            return '(' . implode( ' OR ', $parts ) . ')';
        };

        $limited = count( $ids ) >= 500;
        $scan_started = microtime( true );
        $scan_deadline = $scan_started + 18.0;
        $time_exceeded = function () use ( &$limited, $scan_deadline ): bool {
            if ( microtime( true ) > $scan_deadline ) {
                $limited = true;
                return true;
            }
            return false;
        };

        $content_rows = $wpdb->get_results(
            "SELECT post_content
             FROM {$wpdb->posts}
             WHERE post_type NOT IN ('attachment','revision','nav_menu_item')
               AND post_status NOT IN ('auto-draft','trash')
               AND " . $candidate_like( 'post_content' ) . "
             ORDER BY post_modified_gmt DESC
             LIMIT 900"
        );
        if ( count( $content_rows ) >= 900 ) {
            $limited = true;
        }
        foreach ( $content_rows as $index => $row ) {
            if ( 0 === ( $index % 25 ) && $time_exceeded() ) {
                break;
            }
            $mark_refs_in_text( (string) $row->post_content );
        }

        $ignored_meta_keys = [
            '_thumbnail_id',
            '_wp_attached_file',
            '_wp_attachment_metadata',
            '_wp_attachment_image_alt',
            '_wp_attachment_backup_sizes',
            '_wp_attachment_context',
            '_mv_media_replace_history',
        ];
        $ignored_meta_placeholders = implode( ',', array_fill( 0, count( $ignored_meta_keys ), '%s' ) );
        $attachment_placeholders = implode( ',', array_fill( 0, count( $refs_by_id ), '%d' ) );
        $meta_sql = "SELECT pm.meta_value
             FROM {$wpdb->postmeta} pm
             INNER JOIN {$wpdb->posts} p ON p.ID = pm.post_id
             WHERE pm.meta_key NOT IN ({$ignored_meta_placeholders})
               AND pm.post_id NOT IN ({$attachment_placeholders})
               AND p.post_type NOT IN ('attachment','revision','nav_menu_item')
               AND p.post_status NOT IN ('auto-draft','trash')
               AND " . $candidate_like( 'pm.meta_value' ) . "
             ORDER BY p.post_modified_gmt DESC
             LIMIT 1400";
        $meta_rows = $wpdb->get_results( $wpdb->prepare(
            $meta_sql,
            array_merge( $ignored_meta_keys, array_keys( $refs_by_id ) )
        ) );
        if ( count( $meta_rows ) >= 1400 ) {
            $limited = true;
        }
        foreach ( $meta_rows as $index => $row ) {
            if ( 0 === ( $index % 25 ) && $time_exceeded() ) {
                break;
            }
            $mark_refs_in_text( maybe_serialize( $row->meta_value ) );
        }

        $option_rows = $wpdb->get_results(
            "SELECT option_value
             FROM {$wpdb->options}
             WHERE option_name NOT LIKE '\\_transient\\_%'
               AND option_name NOT LIKE '\\_site\\_transient\\_%'
               AND " . $candidate_like( 'option_value' ) . "
             ORDER BY option_name ASC
             LIMIT 700"
        );
        if ( count( $option_rows ) >= 700 ) {
            $limited = true;
        }
        foreach ( $option_rows as $index => $row ) {
            if ( 0 === ( $index % 20 ) && $time_exceeded() ) {
                break;
            }
            $mark_refs_in_text( maybe_serialize( $row->option_value ) );
        }

        $used = [];
        $unused = [];
        foreach ( $used_map as $id => $is_used ) {
            if ( $is_used ) {
                $used[] = (int) $id;
            } else {
                $unused[] = (int) $id;
            }
        }

        return new \WP_REST_Response( [
            'success'     => true,
            'unused_ids'  => $unused,
            'used_ids'    => $used,
            'skipped_ids' => $skipped,
            'scanned'     => count( $unused ) + count( $used ),
            'limited'     => $limited,
            'message'     => $limited ? 'Scanned with a safety limit. Narrow the collection/search for a deeper pass.' : 'Scanned featured images, content, post meta, and options for references MV can safely detect.',
        ], 200 );
    }

    public function update_media_metadata( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $post = $attachment_id ? get_post( $attachment_id ) : null;
        if ( ! $post || 'attachment' !== $post->post_type ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Attachment not found.' ], 404 );
        }

        $update = [ 'ID' => $attachment_id ];
        if ( array_key_exists( 'title', $params ) ) {
            $title = sanitize_text_field( (string) $params['title'] );
            if ( '' !== trim( $title ) ) {
                $update['post_title'] = $title;
                $update['post_name']  = sanitize_title( $title );
            }
        }
        if ( array_key_exists( 'caption', $params ) ) {
            $update['post_excerpt'] = wp_kses_post( (string) $params['caption'] );
        }
        if ( array_key_exists( 'description', $params ) ) {
            $update['post_content'] = wp_kses_post( (string) $params['description'] );
        }

        if ( count( $update ) > 1 ) {
            $result = wp_update_post( $update, true );
            if ( is_wp_error( $result ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
            }
        }

        if ( array_key_exists( 'alt_text', $params ) ) {
            update_post_meta( $attachment_id, '_wp_attachment_image_alt', sanitize_text_field( (string) $params['alt_text'] ) );
        }

        return new \WP_REST_Response( [
            'success' => true,
            'item'    => $this->media_item_payload( $attachment_id ),
        ], 200 );
    }

    private function remove_directory_recursive( string $dir ): void {
        if ( ! is_dir( $dir ) ) {
            return;
        }
        $items = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator( $dir, \FilesystemIterator::SKIP_DOTS ),
            \RecursiveIteratorIterator::CHILD_FIRST
        );
        foreach ( $items as $item ) {
            $path = $item->getPathname();
            if ( $item->isDir() ) {
                @rmdir( $path );
            } else {
                @unlink( $path );
            }
        }
        @rmdir( $dir );
    }

    private function validate_media_zip_archive( string $path ) {
        if ( ! class_exists( '\ZipArchive' ) ) {
            return new \WP_Error( 'mv_media_zip_inspection_unavailable', 'ZIP inspection is not available on this server.' );
        }
        if ( ! is_readable( $path ) || filesize( $path ) > 50 * 1024 * 1024 ) {
            return new \WP_Error( 'mv_media_zip_too_large', 'The ZIP file must be readable and no larger than 50 MB.' );
        }

        $zip = new \ZipArchive();
        if ( true !== $zip->open( $path ) ) {
            return new \WP_Error( 'mv_media_zip_invalid', 'The ZIP file could not be inspected.' );
        }

        $max_files = 120;
        $max_entry = 50 * 1024 * 1024;
        $max_total = 250 * 1024 * 1024;
        $files = 0;
        $total = 0;
        $error = '';
        for ( $i = 0; $i < $zip->numFiles; $i++ ) {
            $stat = $zip->statIndex( $i );
            $name = is_array( $stat ) ? (string) ( $stat['name'] ?? '' ) : '';
            if ( '' === $name || '/' === substr( $name, -1 ) ) {
                continue;
            }
            $files++;
            $size = (int) ( $stat['size'] ?? 0 );
            $compressed = (int) ( $stat['comp_size'] ?? 0 );
            $total += $size;
            $normalized = str_replace( '\\', '/', $name );
            if ( $files > $max_files || $size > $max_entry || $total > $max_total ) {
                $error = 'The ZIP exceeds the import entry or expanded-size budget.';
                break;
            }
            if ( 0 === strpos( $normalized, '/' ) || preg_match( '#(?:^|/)\.\.(?:/|$)#', $normalized ) ) {
                $error = 'The ZIP contains an unsafe path.';
                break;
            }
            if ( preg_match( '/\.(?:zip|restorebase)$/i', $normalized ) ) {
                $error = 'Nested archives are not allowed in media imports.';
                break;
            }
            if ( $compressed > 0 && $size > $compressed * 100 ) {
                $error = 'The ZIP contains an unsafe compression ratio.';
                break;
            }
            if ( ! empty( $stat['encryption_method'] ) ) {
                $error = 'Encrypted ZIP entries are not supported.';
                break;
            }
            if ( method_exists( $zip, 'getExternalAttributesIndex' ) ) {
                $opsys = 0;
                $attributes = 0;
                if ( $zip->getExternalAttributesIndex( $i, $opsys, $attributes ) && 0xA000 === ( ( $attributes >> 16 ) & 0xF000 ) ) {
                    $error = 'Symbolic links are not allowed in media ZIP imports.';
                    break;
                }
            }
        }
        $zip->close();

        return '' === $error ? true : new \WP_Error( 'mv_media_zip_unsafe', $error );
    }

    public function import_zip_to_collection( \WP_REST_Request $request ): \WP_REST_Response {
        $collection = sanitize_text_field( (string) $request->get_param( 'collection' ) );
        $manager = $this->media_collections_manager();
        $term = $manager->get_term_by_any( $collection );
        if ( ! $term ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Collection not found.' ], 404 );
        }
        if ( get_term_meta( (int) $term->term_id, \VE\Core\MediaCollectionManager::META_LOCKED, true ) === '1' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Unlock this collection before importing ZIP media.' ], 403 );
        }

        $files = $request->get_file_params();
        $zip_file = $files['zip_file'] ?? ( $files['file'] ?? null );
        if ( empty( $zip_file ) || empty( $zip_file['tmp_name'] ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Choose a ZIP file to import.' ], 400 );
        }

        $name = sanitize_file_name( (string) ( $zip_file['name'] ?? 'media.zip' ) );
        if ( strtolower( pathinfo( $name, PATHINFO_EXTENSION ) ) !== 'zip' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Only .zip files can be imported.' ], 400 );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        if ( function_exists( 'WP_Filesystem' ) ) {
            WP_Filesystem();
        }

        $zip_check = $this->validate_media_zip_archive( (string) $zip_file['tmp_name'] );
        if ( is_wp_error( $zip_check ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $zip_check->get_error_message() ], 400 );
        }

        $upload = wp_upload_dir();
        $work_dir = trailingslashit( (string) ( $upload['basedir'] ?? sys_get_temp_dir() ) ) . 'variable-engine/import-zip/' . wp_generate_uuid4();
        if ( ! wp_mkdir_p( $work_dir ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Could not prepare the ZIP import folder.' ], 500 );
        }

        $unzipped = unzip_file( $zip_file['tmp_name'], $work_dir );
        if ( is_wp_error( $unzipped ) ) {
            $this->remove_directory_recursive( $work_dir );
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'ZIP import failed: ' . $unzipped->get_error_message() ], 400 );
        }

        $imported = [];
        $skipped = [];
        $max_files = 120;
        $iterator = new \RecursiveIteratorIterator( new \RecursiveDirectoryIterator( $work_dir, \FilesystemIterator::SKIP_DOTS ) );
        foreach ( $iterator as $file_info ) {
            if ( count( $imported ) >= $max_files ) {
                break;
            }
            if ( ! $file_info->isFile() ) {
                continue;
            }
            $path = $file_info->getPathname();
            $relative = str_replace( trailingslashit( $work_dir ), '', $path );
            // Decode percent-encoding first so an archived "high%20image.jpg" becomes
            // "high image" rather than "high20image" (sanitize_file_name strips the %).
            $base = sanitize_file_name( rawurldecode( wp_basename( $path ) ) );
            if ( '' === $base || 0 === strpos( $base, '.' ) || false !== strpos( $relative, '__MACOSX' ) ) {
                $skipped[] = $relative;
                continue;
            }
            $type = wp_check_filetype( $base );
            if ( empty( $type['type'] ) || ! preg_match( '#^(image|video|audio)/|^application/(pdf|zip)#', (string) $type['type'] ) ) {
                $skipped[] = $relative;
                continue;
            }
            $tmp = wp_tempnam( $base );
            if ( ! $tmp || ! @copy( $path, $tmp ) ) {
                if ( $tmp ) {
                    @unlink( $tmp );
                }
                $skipped[] = $relative;
                continue;
            }
            $file_array = [
                'name'     => $base,
                'tmp_name' => $tmp,
                'type'     => $type['type'],
            ];
            $attachment_id = media_handle_sideload( $file_array, 0 );
            if ( is_wp_error( $attachment_id ) ) {
                @unlink( $tmp );
                $skipped[] = $relative;
                continue;
            }
            $manager->assign_attachment( (int) $attachment_id, (int) $term->term_id, true );
            $imported[] = $this->media_item_payload( (int) $attachment_id );
        }

        $this->remove_directory_recursive( $work_dir );
        $data = $manager->list_collections();

        return new \WP_REST_Response( [
            'success'     => true,
            'count'       => count( $imported ),
            'skipped'     => count( $skipped ),
            'limited'     => count( $imported ) >= $max_files,
            'items'       => $imported,
            'collections' => $data['collections'],
            'map'         => $data['map'],
            'message'     => count( $imported ) ? 'Imported ZIP media into the collection.' : 'No supported media files were found in that ZIP.',
        ], count( $imported ) ? 200 : 400 );
    }

    public function get_media_usage( \WP_REST_Request $request ): \WP_REST_Response {
        $attachment_id = absint( $request->get_param( 'id' ) );
        $report = $this->media_usage_report_for_attachment( $attachment_id );
        if ( is_wp_error( $report ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $report->get_error_message() ], 404 );
        }
        return new \WP_REST_Response( $report, 200 );
    }

    public function get_media_diagnostics( \WP_REST_Request $request ): \WP_REST_Response {
        $limit = 800;
        $ids = get_posts( [
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'fields'         => 'ids',
            'posts_per_page' => $limit,
            'orderby'        => 'date',
            'order'          => 'DESC',
        ] );

        $now = time();
        $recent_cutoff = $now - ( 14 * DAY_IN_SECONDS );
        $diagnostics = [
            'success'             => true,
            'total'               => 0,
            'total_size'          => 0,
            'missing_alt'         => 0,
            'unused'              => null,
            'large_files'         => 0,
            'recent_uploads'      => 0,
            'missing_files'       => 0,
            'empty_title'         => 0,
            'duplicate_filenames' => 0,
            'limited'             => false,
            'sample_limit'        => $limit,
            'issues'              => [],
        ];
        $filenames = [];

        foreach ( $ids as $id ) {
            $id = (int) $id;
            $diagnostics['total']++;
            $file = (string) get_attached_file( $id );
            $size = ( $file && file_exists( $file ) ) ? (int) filesize( $file ) : 0;
            $diagnostics['total_size'] += $size;
            if ( ! $file || ! file_exists( $file ) ) {
                $diagnostics['missing_files']++;
                $diagnostics['issues'][] = [ 'id' => $id, 'type' => 'missing_file', 'label' => get_the_title( $id ) ?: 'Media #' . $id ];
            }
            if ( $size >= 1024 * 1024 ) {
                $diagnostics['large_files']++;
            }
            $post = get_post( $id );
            if ( $post && strtotime( $post->post_date_gmt ?: $post->post_date ) >= $recent_cutoff ) {
                $diagnostics['recent_uploads']++;
            }
            if ( $post && '' === trim( (string) $post->post_title ) ) {
                $diagnostics['empty_title']++;
            }
            $mime = (string) get_post_mime_type( $id );
            if ( 0 === strpos( $mime, 'image/' ) && '' === trim( (string) get_post_meta( $id, '_wp_attachment_image_alt', true ) ) ) {
                $diagnostics['missing_alt']++;
            }
            $base = $file ? strtolower( wp_basename( $file ) ) : '';
            if ( $base ) {
                $filenames[ $base ] = ( $filenames[ $base ] ?? 0 ) + 1;
            }
        }

        foreach ( $filenames as $count ) {
            if ( $count > 1 ) {
                $diagnostics['duplicate_filenames'] += $count;
            }
        }
        $diagnostics['limited'] = count( $ids ) >= $limit;
        $diagnostics['total_size_human'] = size_format( (int) $diagnostics['total_size'], 1 );
        $diagnostics['issues'] = array_slice( $diagnostics['issues'], 0, 12 );

        return new \WP_REST_Response( $diagnostics, 200 );
    }

    public function get_media_url_history( \WP_REST_Request $request ): \WP_REST_Response {
        $history = get_option( 've_media_url_import_history', [] );
        if ( ! is_array( $history ) ) {
            $history = [];
        }
        return new \WP_REST_Response( [ 'success' => true, 'history' => array_values( $history ) ], 200 );
    }

    public function clear_media_url_history( \WP_REST_Request $request ): \WP_REST_Response {
        update_option( 've_media_url_import_history', [], false );
        return new \WP_REST_Response( [ 'success' => true, 'history' => [] ], 200 );
    }

    public function rollback_media_action( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $rollback_id = sanitize_text_field( (string) ( $params['rollback_id'] ?? '' ) );
        if ( ! $attachment_id || '' === $rollback_id || get_post_type( $attachment_id ) !== 'attachment' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Missing rollback target.' ], 400 );
        }

        $history = get_post_meta( $attachment_id, '_mv_media_action_history', true );
        if ( ! is_array( $history ) ) {
            $history = [];
        }
        $entry = null;
        foreach ( $history as $row ) {
            if ( isset( $row['rollback_id'] ) && $row['rollback_id'] === $rollback_id ) {
                $entry = $row;
                break;
            }
        }
        if ( ! is_array( $entry ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Rollback point was not found.' ], 404 );
        }

        require_once ABSPATH . 'wp-admin/includes/image.php';
        $current_file = (string) get_attached_file( $attachment_id );
        $current_mime = get_post_mime_type( $attachment_id );
        $current_meta = wp_get_attachment_metadata( $attachment_id );
        $current_backup = $current_file ? $this->backup_media_file_for_history( $attachment_id, $current_file, 'pre-rollback' ) : [];

        $restored_path = '';
        $source_path = '';
        if ( ! empty( $entry['backup_path'] ) && file_exists( (string) $entry['backup_path'] ) ) {
            $source_path = (string) $entry['backup_path'];
        } elseif ( ! empty( $entry['old_path'] ) && file_exists( (string) $entry['old_path'] ) ) {
            $source_path = (string) $entry['old_path'];
        }

        $action = (string) ( $entry['action'] ?? '' );
        if ( 'rename' === $action ) {
            $old_title = sanitize_text_field( (string) ( $entry['old_title'] ?? '' ) );
            if ( '' !== $old_title ) {
                wp_update_post( [
                    'ID'         => $attachment_id,
                    'post_title' => $old_title,
                    'post_name'  => sanitize_title( $entry['old_slug'] ?? $old_title ),
                ] );
            }
        }

        if ( $source_path ) {
            $desired_path = ( in_array( $action, [ 'convert', 'rename' ], true ) && ! empty( $entry['old_path'] ) ) ? (string) $entry['old_path'] : $current_file;
            if ( ! $desired_path ) {
                $desired_path = (string) ( $entry['old_path'] ?? $source_path );
            }
            if ( $desired_path && wp_mkdir_p( dirname( $desired_path ) ) && @copy( $source_path, $desired_path ) ) {
                $restored_path = $desired_path;
                if ( $restored_path !== $current_file ) {
                    update_attached_file( $attachment_id, $restored_path );
                }
            } elseif ( $current_file && file_exists( $current_file ) && is_writable( dirname( $current_file ) ) && @copy( $source_path, $current_file ) ) {
                $restored_path = $current_file;
            } else {
                return new \WP_REST_Response( [ 'success' => false, 'message' => 'Could not restore the backup file.' ], 500 );
            }
        } elseif ( 'rename' !== $action ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'The backup file for this rollback point is missing.' ], 404 );
        }

        if ( $restored_path ) {
            $filetype = wp_check_filetype( $restored_path );
            wp_update_post( [
                'ID'             => $attachment_id,
                'post_mime_type' => $entry['old_mime'] ?? ( $filetype['type'] ?: $current_mime ),
            ] );
            $metadata = is_array( $entry['old_metadata'] ?? null ) ? $entry['old_metadata'] : wp_generate_attachment_metadata( $attachment_id, $restored_path );
            if ( is_array( $metadata ) ) {
                wp_update_attachment_metadata( $attachment_id, $metadata );
            }
        }

        $this->push_media_action_history( $attachment_id, array_merge( [
            'action'       => 'rollback',
            'old_file'     => $current_file ? wp_basename( $current_file ) : '',
            'old_path'     => $current_file,
            'old_mime'     => $current_mime,
            'old_metadata' => is_array( $current_meta ) ? $current_meta : [],
            'new_file'     => $restored_path ? wp_basename( $restored_path ) : ( $entry['old_file'] ?? '' ),
            'new_path'     => $restored_path,
            'new_mime'     => $entry['old_mime'] ?? $current_mime,
            'source_action'=> $action,
        ], $current_backup ) );

        return new \WP_REST_Response( [ 'success' => true, 'item' => $this->media_item_payload( $attachment_id ) ], 200 );
    }

    public function replace_media_file( \WP_REST_Request $request ): \WP_REST_Response {
        $attachment_id = absint( $request->get_param( 'attachment_id' ) );
        $files = $request->get_file_params();

        if ( ! $attachment_id || empty( $files['file'] ) || ! get_post( $attachment_id ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Missing attachment or upload file.' ], 400 );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $old_file = (string) get_attached_file( $attachment_id );
        $old_url = wp_get_attachment_url( $attachment_id );
        $old_mime = get_post_mime_type( $attachment_id );
        $old_meta = wp_get_attachment_metadata( $attachment_id );
        $backup = $old_file ? $this->backup_media_file_for_history( $attachment_id, $old_file, 'replace' ) : [];

        $upload = wp_handle_upload( $files['file'], [ 'test_form' => false ] );
        if ( isset( $upload['error'] ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $upload['error'] ], 400 );
        }

        $new_file = $upload['file'];
        $target_file = $old_file ?: $new_file;

        if ( $old_file && file_exists( $old_file ) ) {
            @copy( $new_file, $old_file );
            @unlink( $new_file );
        } else {
            update_attached_file( $attachment_id, $new_file );
            $target_file = $new_file;
        }

        $filetype = wp_check_filetype( $target_file );
        wp_update_post( [
            'ID'             => $attachment_id,
            'post_mime_type' => $filetype['type'] ?: ( $upload['type'] ?? get_post_mime_type( $attachment_id ) ),
        ] );

        $metadata = wp_generate_attachment_metadata( $attachment_id, $target_file );
        if ( is_array( $metadata ) ) {
            wp_update_attachment_metadata( $attachment_id, $metadata );
        }

        $this->push_media_action_history( $attachment_id, array_merge( [
            'action'       => 'replace',
            'old_file'     => $old_file ? wp_basename( $old_file ) : '',
            'old_path'     => $old_file,
            'old_url'      => $old_url,
            'old_mime'     => $old_mime,
            'old_metadata' => is_array( $old_meta ) ? $old_meta : [],
            'new_file'     => $target_file ? wp_basename( $target_file ) : '',
            'new_path'     => $target_file,
            'new_mime'     => $filetype['type'] ?: ( $upload['type'] ?? '' ),
        ], $backup ) );

        return new \WP_REST_Response( [ 'success' => true, 'item' => $this->media_item_payload( $attachment_id ) ], 200 );
    }

    public function convert_media_file( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $format = sanitize_key( $params['format'] ?? 'webp' );
        $allowed = [ 'webp', 'avif', 'jpeg', 'jpg', 'png' ];

        if ( ! $attachment_id || ! in_array( $format, $allowed, true ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Invalid conversion request.' ], 400 );
        }

        $file = (string) get_attached_file( $attachment_id );
        if ( ! $file || ! file_exists( $file ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Source file not found.' ], 404 );
        }

        require_once ABSPATH . 'wp-admin/includes/image.php';

        $old_mime = get_post_mime_type( $attachment_id );
        $old_meta = wp_get_attachment_metadata( $attachment_id );
        $backup = $this->backup_media_file_for_history( $attachment_id, $file, 'convert' );

        $editor = wp_get_image_editor( $file );
        if ( is_wp_error( $editor ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $editor->get_error_message() ], 400 );
        }

        $ext = $format === 'jpg' ? 'jpeg' : $format;
        $mime = 'image/' . $ext;
        $base = preg_replace( '/\.[^.]+$/', '', $file );
        $dest = $base . '.' . ( $ext === 'jpeg' ? 'jpg' : $ext );
        $saved = $editor->save( $dest, $mime );

        if ( is_wp_error( $saved ) || empty( $saved['path'] ) ) {
            $message = is_wp_error( $saved ) ? $saved->get_error_message() : 'The server image editor could not save that format.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        update_attached_file( $attachment_id, $saved['path'] );
        wp_update_post( [
            'ID'             => $attachment_id,
            'post_mime_type' => $saved['mime-type'] ?? $mime,
        ] );

        $metadata = wp_generate_attachment_metadata( $attachment_id, $saved['path'] );
        if ( is_array( $metadata ) ) {
            wp_update_attachment_metadata( $attachment_id, $metadata );
        }

        $this->push_media_action_history( $attachment_id, array_merge( [
            'action'       => 'convert',
            'old_file'     => wp_basename( $file ),
            'old_path'     => $file,
            'old_url'      => wp_get_attachment_url( $attachment_id ),
            'old_mime'     => $old_mime,
            'old_metadata' => is_array( $old_meta ) ? $old_meta : [],
            'new_file'     => wp_basename( $saved['path'] ),
            'new_path'     => $saved['path'],
            'new_mime'     => $saved['mime-type'] ?? $mime,
        ], $backup ) );

        return new \WP_REST_Response( [ 'success' => true, 'item' => $this->media_item_payload( $attachment_id ) ], 200 );
    }

    public function compress_media_file( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $quality = isset( $params['quality'] ) ? absint( $params['quality'] ) : 82;
        $quality = max( 60, min( 92, $quality ) );

        if ( ! $attachment_id || ! get_post( $attachment_id ) || get_post_type( $attachment_id ) !== 'attachment' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Attachment not found.' ], 404 );
        }

        $file = (string) get_attached_file( $attachment_id );
        if ( ! $file || ! file_exists( $file ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Source file not found.' ], 404 );
        }

        $mime = get_post_mime_type( $attachment_id );
        if ( 0 !== strpos( (string) $mime, 'image/' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Only image files can be compressed.' ], 400 );
        }

        require_once ABSPATH . 'wp-admin/includes/image.php';

        $before = filesize( $file );
        $old_meta = wp_get_attachment_metadata( $attachment_id );
        $backup = $this->backup_media_file_for_history( $attachment_id, $file, 'compress' );
        $editor = wp_get_image_editor( $file );
        if ( is_wp_error( $editor ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $editor->get_error_message() ], 400 );
        }

        if ( method_exists( $editor, 'set_quality' ) ) {
            $editor->set_quality( $quality );
        }

        $saved = $editor->save( $file, $mime );
        if ( is_wp_error( $saved ) || empty( $saved['path'] ) ) {
            $message = is_wp_error( $saved ) ? $saved->get_error_message() : 'The server image editor could not compress that file.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        $metadata = wp_generate_attachment_metadata( $attachment_id, $saved['path'] );
        if ( is_array( $metadata ) ) {
            wp_update_attachment_metadata( $attachment_id, $metadata );
        }

        $after = file_exists( $saved['path'] ) ? filesize( $saved['path'] ) : 0;
        $this->push_media_action_history( $attachment_id, array_merge( [
            'action'       => 'compress',
            'old_file'     => wp_basename( $file ),
            'old_path'     => $file,
            'old_mime'     => $mime,
            'old_metadata' => is_array( $old_meta ) ? $old_meta : [],
            'new_file'     => wp_basename( $saved['path'] ),
            'new_path'     => $saved['path'],
            'new_mime'     => $mime,
            'before_bytes' => $before,
            'after_bytes'  => $after,
        ], $backup ) );

        return new \WP_REST_Response( [
            'success'      => true,
            'item'         => $this->media_item_payload( $attachment_id ),
            'before_bytes' => $before,
            'after_bytes'  => $after,
        ], 200 );
    }

    public function rename_media_file( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $title = sanitize_text_field( $params['title'] ?? '' );
        $rename_file = rest_sanitize_boolean( $params['rename_file'] ?? false );

        if ( ! $attachment_id || ! get_post( $attachment_id ) || get_post_type( $attachment_id ) !== 'attachment' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Attachment not found.' ], 404 );
        }

        if ( empty( $title ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'A filename/title is required.' ], 400 );
        }

        $post = get_post( $attachment_id );
        $old_title = $post ? $post->post_title : '';
        $old_slug = $post ? $post->post_name : '';
        $old_file = (string) get_attached_file( $attachment_id );
        $old_mime = get_post_mime_type( $attachment_id );
        $old_meta = wp_get_attachment_metadata( $attachment_id );
        $backup = $old_file ? $this->backup_media_file_for_history( $attachment_id, $old_file, 'rename' ) : [];
        $new_path = $old_file;

        wp_update_post( [
            'ID'         => $attachment_id,
            'post_title' => $title,
            'post_name'  => sanitize_title( $title ),
        ] );

        if ( $rename_file ) {
            $file = get_attached_file( $attachment_id );
            if ( $file && file_exists( $file ) && is_writable( dirname( $file ) ) ) {
                require_once ABSPATH . 'wp-admin/includes/image.php';
                $pathinfo = pathinfo( $file );
                $extension = isset( $pathinfo['extension'] ) ? '.' . strtolower( $pathinfo['extension'] ) : '';
                $new_name = wp_unique_filename( $pathinfo['dirname'], sanitize_file_name( $title ) . $extension );
                $new_path = trailingslashit( $pathinfo['dirname'] ) . $new_name;
                if ( @rename( $file, $new_path ) ) {
                    update_attached_file( $attachment_id, $new_path );
                    $metadata = wp_generate_attachment_metadata( $attachment_id, $new_path );
                    if ( is_array( $metadata ) ) {
                        wp_update_attachment_metadata( $attachment_id, $metadata );
                    }
                } else {
                    $new_path = $file;
                }
            }
        }

        $this->push_media_action_history( $attachment_id, array_merge( [
            'action'       => 'rename',
            'old_title'    => $old_title,
            'old_slug'     => $old_slug,
            'old_file'     => $old_file ? wp_basename( $old_file ) : '',
            'old_path'     => $old_file,
            'old_mime'     => $old_mime,
            'old_metadata' => is_array( $old_meta ) ? $old_meta : [],
            'new_title'    => $title,
            'new_file'     => $new_path ? wp_basename( $new_path ) : '',
            'new_path'     => $new_path,
            'new_mime'     => get_post_mime_type( $attachment_id ),
        ], $backup ) );

        return new \WP_REST_Response( [ 'success' => true, 'item' => $this->media_item_payload( $attachment_id ) ], 200 );
    }

    public function create_media_collection_zip( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! class_exists( '\ZipArchive' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'ZIP support is not available on this server.' ], 400 );
        }

        $params = $request->get_json_params() ?: [];
        // "Download all media" (the All media view) zips the entire library. The
        // client can't be trusted to hold every attachment id (the grid is
        // paginated/cached), so gather them server-side when `all` is set.
        if ( ! empty( $params['all'] ) ) {
            $ids = get_posts( [
                'post_type'      => 'attachment',
                'post_status'    => 'inherit',
                'posts_per_page' => -1,
                'fields'         => 'ids',
                'orderby'        => 'ID',
                'order'          => 'ASC',
            ] );
        } else {
            $ids = isset( $params['attachment_ids'] ) && is_array( $params['attachment_ids'] ) ? $params['attachment_ids'] : [];
        }
        $ids = array_values( array_unique( array_filter( array_map( 'absint', (array) $ids ) ) ) );
        $ids = array_values( array_filter( $ids, static function ( $id ) {
            return 'attachment' === get_post_type( $id ) && current_user_can( 'read_post', $id );
        } ) );
        if ( empty( $ids ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'No media files were found to download.' ], 400 );
        }

        $collection = sanitize_file_name( sanitize_text_field( (string) ( $params['collection'] ?? 'media-collection' ) ) );
        if ( '' === $collection ) {
            $collection = 'media-collection';
        }

        $upload = wp_upload_dir();
        $base_dir = trailingslashit( (string) ( $upload['basedir'] ?? '' ) ) . 'variable-engine/media-zips';
        $base_url = trailingslashit( (string) ( $upload['baseurl'] ?? '' ) ) . 'variable-engine/media-zips';
        if ( ! wp_mkdir_p( $base_dir ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Could not prepare the ZIP folder.' ], 500 );
        }

        $filename = $collection . '-' . gmdate( 'Y-m-d-His' ) . '-' . strtolower( wp_generate_password( 12, false, false ) ) . '.zip';
        $path = trailingslashit( $base_dir ) . $filename;
        $zip = new \ZipArchive();
        if ( true !== $zip->open( $path, \ZipArchive::CREATE | \ZipArchive::OVERWRITE ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Could not create the ZIP file.' ], 500 );
        }

        $added = 0;
        foreach ( $ids as $id ) {
            if ( get_post_type( $id ) !== 'attachment' || ! current_user_can( 'read_post', $id ) ) {
                continue;
            }
            $file = get_attached_file( $id );
            if ( ! $file || ! file_exists( $file ) || ! is_readable( $file ) ) {
                continue;
            }
            $name = basename( $file );
            if ( $zip->locateName( $name ) !== false ) {
                $info = pathinfo( $name );
                $name = ( $info['filename'] ?? 'media' ) . '-' . $id . ( isset( $info['extension'] ) ? '.' . $info['extension'] : '' );
            }
            if ( $zip->addFile( $file, $name ) ) {
                $added++;
            }
        }
        $zip->close();

        if ( $added <= 0 ) {
            @unlink( $path );
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'No readable media files could be added to the ZIP.' ], 400 );
        }

        return new \WP_REST_Response( [
            'success' => true,
            'count'   => $added,
            'url'     => trailingslashit( $base_url ) . rawurlencode( $filename ),
        ], 200 );
    }

    private function validate_media_import_url( string $url ) {
        $url = esc_url_raw( trim( $url ) );
        if ( '' === $url ) {
            return new \WP_Error( 'mv_media_import_empty_url', 'No URL was provided.' );
        }
        $scheme = strtolower( (string) wp_parse_url( $url, PHP_URL_SCHEME ) );
        if ( 'http' !== $scheme && 'https' !== $scheme ) {
            return new \WP_Error( 'mv_media_import_bad_scheme', 'Only HTTP and HTTPS URLs are supported.' );
        }
        $host = (string) wp_parse_url( $url, PHP_URL_HOST );
        if ( '' === $host ) {
            return new \WP_Error( 'mv_media_import_bad_host', 'The URL does not contain a valid host.' );
        }
        $resolved = gethostbyname( $host );
        if ( $resolved === $host && ! filter_var( $host, FILTER_VALIDATE_IP ) ) {
            return new \WP_Error( 'mv_media_import_unresolved_host', 'Could not resolve the host.' );
        }
        if ( $this->is_private_ip( $resolved ) ) {
            return new \WP_Error( 'mv_media_import_private_host', 'Downloads from private or internal addresses are not allowed.' );
        }
        $path = (string) wp_parse_url( $url, PHP_URL_PATH );
        /* R30. This used to refuse any pexels.com host with a /photos/ or
         * /videos/ path as "a protected webpage". It was meant to catch
         * `www.pexels.com/photo/...`, and it caught the real image files too:
         *
         *     images.pexels.com/photos/2161856/pexels-photo-2161856.jpeg
         *     host matches (^|\.)pexels\.com$   -> yes
         *     path matches ^/(video|photo)s?/   -> yes  -> refused
         *
         * So every direct Pexels image was rejected before anything was even
         * requested, which is why an import of seven of them reported
         * "0 imported images" and nothing appeared in the library.
         *
         * There is no rule about URLs that gets this right. "No file extension
         * means a webpage" would refuse every Unsplash file, which are all
         * extensionless. So MV no longer guesses in advance: it fetches, and
         * decides on what actually came back. A page that returns HTML is
         * identified as HTML, once, wherever it is fetched - and that is true
         * for every stock library, including the ones nobody has named.
         */
        return [ 'url' => $url, 'host' => $host, 'path' => $path ];
    }

    /**
     * The one thing MV says when a "media URL" turns out to be a web page.
     *
     * R30. Said once, from the fact rather than from a hostname, so Pexels,
     * Unsplash, Pixabay and whatever comes next all get the same accurate answer
     * without a list that has to be kept up to date.
     */
    private function media_import_page_error(): \WP_Error {
        return new \WP_Error(
            'mv_media_import_protected_page',
            'That link is a web page, not a media file. Open it, then copy the direct image or video URL - on Pexels that is the images.pexels.com or videos.pexels.com address behind the download button.'
        );
    }

    /**
     * The preview's warning, before anything is downloaded.
     *
     * R30. This read `#/(image|video|audio|application)/(?!json)#` against a
     * content type of `image/jpeg` - which has no slash BEFORE the word, so it
     * never matched, and any URL with no file extension was called a page. Every
     * Unsplash file is extensionless, so every Unsplash file was warned about.
     * The type is anchored at the start now, which is where a MIME type's type
     * actually is.
     */
    private function media_import_looks_like_page( string $content_type, string $filename, int $status ): bool {
        if ( $this->media_import_is_html( $content_type ) ) {
            return true;
        }
        $ext = strtolower( (string) pathinfo( $filename, PATHINFO_EXTENSION ) );
        if ( '' !== $ext ) {
            return false;   // it names a file; the download will settle the rest
        }
        $is_media = (bool) preg_match( '#^\s*(image|video|audio)/#i', $content_type )
            || (bool) preg_match( '#^\s*application/(pdf|zip|octet-stream)#i', $content_type );
        if ( '' !== $content_type ) {
            return ! $is_media;
        }
        // No extension, no type, and the HEAD did not answer: nothing says file.
        return $status <= 0;
    }

    /** Does this response body claim to be a web page rather than a file? */
    private function media_import_is_html( string $content_type, string $file = '' ): bool {
        if ( '' !== $content_type && preg_match( '#^(text/html|application/xhtml)#i', trim( $content_type ) ) ) {
            return true;
        }
        /* Servers that send no content type at all, or lie about it. The first
           bytes of an HTML document say what it is. */
        if ( '' !== $file && is_readable( $file ) ) {
            $head = (string) file_get_contents( $file, false, null, 0, 512 );
            if ( preg_match( '/^\s*(<!doctype\s+html|<html[\s>])/i', $head ) ) {
                return true;
            }
        }
        return false;
    }

    /** Stream a remote media response into a bounded temporary file. */
    private function download_media_import_url( string $url, int $max_bytes, int $timeout = 30 ) {
        $tmp_file = wp_tempnam( $url );
        if ( ! $tmp_file ) {
            return new \WP_Error( 'mv_media_import_temp_failed', 'Could not create a temporary download file.' );
        }

        $response = wp_safe_remote_get( $url, [
            'timeout'             => $timeout,
            'redirection'         => 5,
            'reject_unsafe_urls'  => true,
            'stream'              => true,
            'filename'            => $tmp_file,
            'limit_response_size' => $max_bytes + 1,
            'user-agent'          => 'MimamsVarMediaStudio/' . ( defined( 'VE_VERSION' ) ? VE_VERSION : '1.0' ) . '; ' . home_url( '/' ),
        ] );
        if ( is_wp_error( $response ) ) {
            @unlink( $tmp_file );
            return $response;
        }

        $status = (int) wp_remote_retrieve_response_code( $response );
        $size = file_exists( $tmp_file ) ? (int) filesize( $tmp_file ) : 0;
        if ( $status < 200 || $status >= 300 ) {
            @unlink( $tmp_file );
            return new \WP_Error( 'mv_media_import_http_error', 'The remote server returned HTTP ' . $status . '.' );
        }
        /* C60, 2026-09-24: "report the limit". The download already stopped at
           the budget; the message now says which way it failed and what the
           budget is (50 MB for Media Studio, 20 MB for an import's images). */
        if ( $size <= 0 ) {
            @unlink( $tmp_file );
            return new \WP_Error( 'mv_media_import_size_limit', 'The remote file is empty.' );
        }
        if ( $size > $max_bytes ) {
            @unlink( $tmp_file );
            return new \WP_Error( 'mv_media_import_size_limit', sprintf( 'The remote file is larger than the %s allowed here, so the download was stopped.', size_format( $max_bytes, 0 ) ) );
        }
        /* R30. The webpage check, moved here from a guess about the hostname to
           the answer the server actually gave. Every caller of this downloader
           gets it, so Media Studio's URL box and Content Studio's import say the
           same accurate thing about the same link. */
        if ( $this->media_import_is_html( (string) wp_remote_retrieve_header( $response, 'content-type' ), $tmp_file ) ) {
            @unlink( $tmp_file );
            return $this->media_import_page_error();
        }

        return $tmp_file;
    }

    private function media_import_filename_from_url( string $url ): string {
        $url_path = (string) wp_parse_url( $url, PHP_URL_PATH );
        $basename = $url_path ? wp_basename( $url_path ) : '';
        $basename = preg_replace( '/\?.*$/', '', $basename );
        // Decode percent-encoding first: a URL space is "%20", and sanitize_file_name()
        // strips the "%" but keeps the "20", turning "lagos image" into "lagos20image".
        $basename = rawurldecode( $basename );
        if ( '' === $basename || '.' === $basename ) {
            $basename = 'imported-media-' . gmdate( 'YmdHis' );
        }
        return sanitize_file_name( $basename );
    }

    /** C59. What a person is told when a link bounces into the private network. */
    private const MEDIA_IMPORT_REDIRECT_REFUSED = 'This link redirects to a private or internal address, so it cannot be downloaded. Use the address of the file itself.';

    /**
     * Whether WordPress refused to follow a redirect because of where it led.
     *
     * `WP_Http::validate_redirects()` throws with the type
     * `wp_http.redirect_failed_validation`, and WordPress hands that back as a
     * plain `http_request_failed` error carrying only the (translated) message.
     * The message is therefore the one thing left to recognise it by, compared
     * through the same translation call core used to write it.
     *
     * @param mixed $result A response array or a WP_Error.
     */
    private function media_import_redirect_refused( $result ): bool {
        return is_wp_error( $result )
            && $result->get_error_message() === __( 'A valid URL was not provided.' );
    }

    public function preview_import_from_url( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params();
        $raw_url = isset( $params['url'] ) ? (string) $params['url'] : '';
        $validated = $this->validate_media_import_url( $raw_url );
        if ( is_wp_error( $validated ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $validated->get_error_message() ], 400 );
        }

        $url = $validated['url'];
        $host = $validated['host'];
        $filename = $this->media_import_filename_from_url( $url );
        $max_bytes = 50 * 1024 * 1024;
        $content_type = '';
        $content_length = 0;
        $status = 0;

        $response = wp_safe_remote_head( $url, [
            'timeout'     => 12,
            'redirection' => 5,
            'reject_unsafe_urls' => true,
            'user-agent'  => 'MimamsVarMediaStudio/' . ( defined( 'VE_VERSION' ) ? VE_VERSION : '1.0' ) . '; ' . home_url( '/' ),
        ] );

        /* C59. WordPress refuses a redirect into a private address and says so
           as a transport error. The preview used to treat every transport error
           as "could not look, carry on" and answered success - status 0, type
           Unknown - so a link that bounces into the private network looked
           importable. The import itself was always refused; the preview now
           says so first, in words. Other transport errors stay lenient: some
           hosts refuse HEAD and still serve the file. */
        if ( $this->media_import_redirect_refused( $response ) ) {
            return new \WP_REST_Response( [ 'success' => false,
                'message' => self::MEDIA_IMPORT_REDIRECT_REFUSED ], 400 );
        }

        if ( ! is_wp_error( $response ) ) {
            $status = (int) wp_remote_retrieve_response_code( $response );
            $content_type = (string) wp_remote_retrieve_header( $response, 'content-type' );
            $len = wp_remote_retrieve_header( $response, 'content-length' );
            if ( is_numeric( $len ) ) {
                $content_length = (int) $len;
            }
            $disposition = (string) wp_remote_retrieve_header( $response, 'content-disposition' );
            if ( $disposition && preg_match( '/filename="?([^";]+)"?/i', $disposition, $m ) ) {
                $filename = sanitize_file_name( rawurldecode( $m[1] ) );
            }
        }

        $looks_like_page = $this->media_import_looks_like_page( $content_type, $filename, $status );

        return new \WP_REST_Response( [
            'success'      => true,
            'url'          => $url,
            'host'         => $host,
            'filename'     => $filename,
            'status'       => $status,
            'content_type' => $content_type ?: 'Unknown',
            'size'         => $content_length,
            'size_human'   => $content_length ? size_format( $content_length, 1 ) : 'Unknown',
            'max_bytes'    => $max_bytes,
            'max_human'    => size_format( $max_bytes, 0 ),
            'over_limit'   => $content_length > $max_bytes,
            'looks_like_page' => $looks_like_page,
        ], 200 );
    }

    /**
     * Download a file from an external URL and register it in the Media Library.
     */
    public function import_from_url( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params();
        $url    = isset( $params['url'] ) ? esc_url_raw( trim( (string) $params['url'] ) ) : '';

        $validated = $this->validate_media_import_url( $url );
        if ( is_wp_error( $validated ) ) {
            $this->add_media_url_import_history( [ 'status' => 'failed', 'url' => $url, 'message' => $validated->get_error_message() ] );
            return new \WP_REST_Response( [ 'success' => false, 'message' => $validated->get_error_message() ], 400 );
        }
        $url = $validated['url'];

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';

        // Stream into a bounded temp file so oversized responses never fill disk first.
        $max_bytes = 50 * 1024 * 1024;
        $tmp_file = $this->download_media_import_url( $url, $max_bytes, 30 );
        if ( is_wp_error( $tmp_file ) ) {
            $download_error = $tmp_file->get_error_message();
            $message = $this->media_import_redirect_refused( $tmp_file )
                ? self::MEDIA_IMPORT_REDIRECT_REFUSED
                : 'Download failed: ' . $download_error;
            if ( stripos( $download_error, 'forbidden' ) !== false || stripos( $download_error, '403' ) !== false ) {
                $message .= ' This usually means the source blocks server-side downloads. Try a direct media file URL, or download the asset locally and upload it normally.';
            }
            $this->add_media_url_import_history( [ 'status' => 'failed', 'url' => $url, 'message' => $message ] );
            return new \WP_REST_Response( [
                'success' => false,
                'message' => $message,
            ], 400 );
        }

        // Enforce a 50 MB size limit.
        if ( filesize( $tmp_file ) > $max_bytes ) {
            @unlink( $tmp_file );
            $this->add_media_url_import_history( [ 'status' => 'failed', 'url' => $url, 'message' => 'The file exceeds the 50 MB size limit.' ] );
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'The file exceeds the 50 MB size limit.' ], 400 );
        }

        // Derive a clean filename from the URL path.
        $basename = $this->media_import_filename_from_url( $url );

        // Verify MIME type is allowed.
        $filetype = wp_check_filetype_and_ext( $tmp_file, $basename );
        if ( empty( $filetype['type'] ) ) {
            @unlink( $tmp_file );
            $this->add_media_url_import_history( [ 'status' => 'failed', 'url' => $url, 'message' => 'This file type is not allowed.' ] );
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'This file type is not allowed.' ], 400 );
        }

        // If the basename had no extension, append the detected one.
        if ( ! empty( $filetype['ext'] ) && ! pathinfo( $basename, PATHINFO_EXTENSION ) ) {
            $basename .= '.' . $filetype['ext'];
        }

        $file_array = [
            'name'     => $basename,
            'tmp_name' => $tmp_file,
        ];

        $attachment_id = media_handle_sideload( $file_array, 0 );

        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp_file );
            $message = 'Sideload failed: ' . $attachment_id->get_error_message();
            $this->add_media_url_import_history( [ 'status' => 'failed', 'url' => $url, 'message' => $message ] );
            return new \WP_REST_Response( [
                'success' => false,
                'message' => $message,
            ], 400 );
        }

        $collection = isset( $params['collection'] ) ? sanitize_text_field( (string) $params['collection'] ) : '';
        if ( '' !== $collection ) {
            $this->media_collections_manager()->assign_attachment( (int) $attachment_id, $collection, true );
        }

        $item = $this->media_item_payload( (int) $attachment_id );
        $this->add_media_url_import_history( [
            'status'        => 'complete',
            'url'           => $url,
            'attachment_id' => (int) $attachment_id,
            'title'         => $item['title']['rendered'] ?? $basename,
            'mime_type'     => $item['mime_type'] ?? ( $filetype['type'] ?? '' ),
            'size'          => $item['file_size'] ?? 0,
            'collection'    => $collection,
        ] );

        return new \WP_REST_Response( [
            'success' => true,
            'item'    => $item,
        ], 200 );
    }

    /**
     * Check if an IP address belongs to a private or reserved range.
     */
    private function is_private_ip( string $ip ): bool {
        // IPv6 loopback.
        if ( '::1' === $ip ) {
            return true;
        }
        // FILTER_FLAG_NO_PRIV_RANGE covers 10.*, 172.16-31.*, 192.168.*, fc00::/7.
        // FILTER_FLAG_NO_RES_RANGE covers 127.*, 0.*, 169.254.*, 240.*, ::1, etc.
        if ( false === filter_var(
            $ip,
            FILTER_VALIDATE_IP,
            FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE
        ) ) {
            return true;
        }
        return false;
    }

    public function get_content_studio_meta(): \WP_REST_Response {
        $cpts = [];
        $field_groups = [];
        $option_pages = [];

        $post_types = get_post_types( [], 'objects' );
        $exclude = [
            'attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset',
            'oembed_cache', 'user_request', 'wp_block', 'wp_template', 'wp_template_part',
            'acf-field-group', 'acf-field', 'wp_navigation', 'wp_global_styles', 'wp_font_family',
            'wp_font_face', 'action_scheduler', 'bricks_template'
        ];

        // Use ACF's UI-created post-type definitions (arrays with 'post_type') so the
        // source is reliably tagged 'acf'; acf_get_post_types() returns name strings.
        $acf_cpts = [];
        if ( function_exists( 'acf_get_acf_post_types' ) ) {
            $acf_cpts = (array) acf_get_acf_post_types();
        } elseif ( function_exists( 'acf_get_post_types' ) ) {
            $acf_cpts = (array) acf_get_post_types();
        }
        $jet_cpts = get_option( 'jet_engine_cpt', [] );
        if ( ! is_array( $jet_cpts ) ) {
            $jet_cpts = [];
        }

        foreach ( $post_types as $pt ) {
            if ( in_array( $pt->name, $exclude, true ) ) {
                continue;
            }

            $source = 'wp';
            foreach ( $acf_cpts as $ac ) {
                $ac_pt = is_array( $ac ) ? (string) ( $ac['post_type'] ?? $ac['name'] ?? '' ) : (string) $ac;
                if ( '' !== $ac_pt && $ac_pt === $pt->name ) {
                    $source = 'acf';
                    break;
                }
            }
            if ( $source === 'wp' ) {
                foreach ( $jet_cpts as $jc ) {
                    if ( ( $jc['slug'] ?? '' ) === $pt->name ) {
                        $source = 'jet';
                        break;
                    }
                }
            }

            $counts = wp_count_posts( $pt->name );
            $total_count = (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 ) + (int) ( $counts->pending ?? 0 ) + (int) ( $counts->private ?? 0 );
            $label = $pt->label ?: $pt->name;
            $is_content = ! preg_match( '/(taxonom|option pages?|custom fonts?|rm content editor|field groups?|template parts?|navigation)/i', $label );

            $cpts[] = [
                'name'         => $pt->name,
                'label'        => $label,
                'singular'     => $pt->labels->singular_name ?: $pt->name,
                'show_in_rest' => ! empty( $pt->show_in_rest ),
                'rest_base'    => $pt->rest_base ?: $pt->name,
                'count'        => $total_count,
                'source'       => $source,
                'is_builtin'   => ! empty( $pt->_builtin ),
                // Whether this type can nest at all. The editor asks before it offers
                // a parent, the way WordPress only shows Page attributes on a
                // hierarchical type.
                'hierarchical' => (bool) $pt->hierarchical,
                'is_content'   => $is_content,
                'supports_editor' => post_type_supports( $pt->name, 'editor' ),
                'supports_custom_fields' => post_type_supports( $pt->name, 'custom-fields' ),
                'bricks_editable' => $this->is_bricks_post_type_supported_for_studio( $pt->name ),
                'settings'     => $this->studio_cpt_object_settings( $pt ),
            ];
        }

        $known_cpt_names = array_fill_keys( array_map( static function( $pt ) {
            return $pt['name'];
        }, $cpts ), true );

        foreach ( (array) $acf_cpts as $acf_cpt ) {
            $name = sanitize_key( (string) ( $acf_cpt['post_type'] ?? $acf_cpt['name'] ?? '' ) );
            if ( empty( $name ) || in_array( $name, [ 'page', 'post' ], true ) || isset( $known_cpt_names[ $name ] ) || in_array( $name, $exclude, true ) ) {
                continue;
            }
            $label = sanitize_text_field( (string) ( $acf_cpt['title'] ?? $acf_cpt['labels']['name'] ?? $name ) );
            $singular = sanitize_text_field( (string) ( $acf_cpt['labels']['singular_name'] ?? ( $label ?: $name ) ) );
            $counts = wp_count_posts( $name );
            $total_count = is_object( $counts ) ? (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 ) + (int) ( $counts->pending ?? 0 ) + (int) ( $counts->private ?? 0 ) : 0;
            $cpts[] = [
                'name'         => $name,
                'label'        => $label ?: $name,
                'singular'     => $singular,
                'show_in_rest' => ! empty( $acf_cpt['show_in_rest'] ),
                'rest_base'    => sanitize_key( (string) ( $acf_cpt['rest_base'] ?? $name ) ),
                'count'        => $total_count,
                'source'       => 'acf',
                'is_builtin'   => false,
                'is_content'   => ! preg_match( '/(taxonom|option pages?|custom fonts?|rm content editor|field groups?|template parts?|navigation)/i', $label ),
                'supports_editor' => post_type_supports( $name, 'editor' ),
                'supports_custom_fields' => post_type_supports( $name, 'custom-fields' ),
                'bricks_editable' => $this->is_bricks_post_type_supported_for_studio( $name ),
            ];
            $known_cpt_names[ $name ] = true;
        }

        foreach ( (array) $jet_cpts as $jet_cpt ) {
            $name = sanitize_key( (string) ( $jet_cpt['slug'] ?? $jet_cpt['name'] ?? '' ) );
            if ( empty( $name ) || in_array( $name, [ 'page', 'post' ], true ) || isset( $known_cpt_names[ $name ] ) || in_array( $name, $exclude, true ) ) {
                continue;
            }
            $label = sanitize_text_field( (string) ( $jet_cpt['labels']['name'] ?? $jet_cpt['label'] ?? $name ) );
            $singular = sanitize_text_field( (string) ( $jet_cpt['labels']['singular_name'] ?? ( $label ?: $name ) ) );
            $counts = wp_count_posts( $name );
            $total_count = is_object( $counts ) ? (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 ) + (int) ( $counts->pending ?? 0 ) + (int) ( $counts->private ?? 0 ) : 0;
            $cpts[] = [
                'name'         => $name,
                'label'        => $label ?: $name,
                'singular'     => $singular,
                'show_in_rest' => ! empty( $jet_cpt['args']['show_in_rest'] ),
                'rest_base'    => sanitize_key( (string) ( $jet_cpt['args']['rest_base'] ?? $name ) ),
                'count'        => $total_count,
                'source'       => 'jet',
                'is_builtin'   => false,
                'is_content'   => ! preg_match( '/(taxonom|option pages?|custom fonts?|rm content editor|field groups?|template parts?|navigation)/i', $label ),
                'supports_editor' => post_type_supports( $name, 'editor' ),
                'supports_custom_fields' => post_type_supports( $name, 'custom-fields' ),
                'bricks_editable' => $this->is_bricks_post_type_supported_for_studio( $name ),
            ];
            $known_cpt_names[ $name ] = true;
        }

        if ( function_exists( 'acf_get_field_groups' ) ) {
            $acf_groups = acf_get_field_groups();
            foreach ( $acf_groups as $group ) {
                $group_title = (string) ( $group['title'] ?? '' );
                if ( preg_match( '/^option pages?$/i', $group_title ) ) {
                    continue;
                }
                $fields = [];
                $raw_fields = acf_get_fields( $group['ID'] ) ?: acf_get_fields( $group['key'] ) ?: [];
                foreach ( $raw_fields as $f ) {
                    $fields[] = $this->studio_acf_field_shape( (array) $f );
                }

                $post_types_rules = [];
                if ( isset( $group['location'] ) && is_array( $group['location'] ) ) {
                    foreach ( $group['location'] as $rule_group ) {
                        foreach ( $rule_group as $rule ) {
                            if ( ( $rule['param'] ?? '' ) === 'options_page' ) {
                                continue 3;
                            }
                            if ( ( $rule['param'] ?? '' ) === 'post_type' && ( $rule['operator'] ?? '' ) === '==' ) {
                                $post_types_rules[] = $rule['value'];
                            }
                        }
                    }
                }

                $field_groups[] = [
                    'id'         => 'acf-' . $group['ID'],
                    'key'        => $group['key'],
                    'title'      => $group['title'] ?? 'ACF Field Group',
                    'fields'     => $fields,
                    'post_types' => array_values( array_unique( $post_types_rules ) ),
                    'source'     => 'acf',
                    /* R29 - "the fields should be placed exactly as how the wp editor
                       has it, and that's under the main content, and it can change
                       position depending on the settings from the acf."
                       That setting is this one. ACF puts a group after the content
                       (`normal`, its default), after the title (`acf_after_title`) or
                       in the side column (`side`), and orders groups by menu_order.
                       MV was ignoring all of it and putting every field in a rail,
                       which is why the fields did not turn up where the owner set
                       them to turn up. */
                    'position'   => in_array( (string) ( $group['position'] ?? 'normal' ), [ 'normal', 'acf_after_title', 'side' ], true )
                        ? (string) $group['position'] : 'normal',
                    'menu_order' => (int) ( $group['menu_order'] ?? 0 ),
                    'style'      => (string) ( $group['style'] ?? 'default' ),
                    'label_placement' => (string) ( $group['label_placement'] ?? 'top' ),
                ];
            }
        }

        if ( function_exists( 'acf_get_options_pages' ) && function_exists( 'acf_get_field_groups' ) ) {
            // Only surface options pages created through ACF's own UI; hide ones registered
            // in code by plugins/themes (e.g. Advanced Themer's Theme Settings). When ACF is
            // too old to expose the UI-created set, fall back to showing all.
            $ui_option_slugs = null;
            if ( function_exists( 'acf_get_ui_options_pages' ) ) {
                $ui_option_slugs = [];
                foreach ( (array) acf_get_ui_options_pages() as $uop ) {
                    $uslug = sanitize_key( (string) ( $uop['menu_slug'] ?? '' ) );
                    if ( '' !== $uslug ) {
                        $ui_option_slugs[ $uslug ] = true;
                    }
                }
            }
            $acf_option_pages = acf_get_options_pages();
            if ( is_array( $acf_option_pages ) ) {
                foreach ( $acf_option_pages as $slug => $page ) {
                    $menu_slug = sanitize_key( (string) ( $page['menu_slug'] ?? $slug ) );
                    if ( '' === $menu_slug ) {
                        continue;
                    }
                    if ( is_array( $ui_option_slugs ) && ! isset( $ui_option_slugs[ $menu_slug ] ) ) {
                        continue;
                    }
                    $post_id = (string) ( $page['post_id'] ?? 'options' );
                    $fields = [];
                    $group_titles = [];
                    foreach ( acf_get_field_groups( [ 'options_page' => $menu_slug ] ) as $group ) {
                        $group_titles[] = sanitize_text_field( (string) ( $group['title'] ?? '' ) );
                        $raw_fields = acf_get_fields( $group['ID'] ) ?: acf_get_fields( $group['key'] ) ?: [];
                        foreach ( $raw_fields as $f ) {
                            $name = sanitize_key( (string) ( $f['name'] ?? '' ) );
                            if ( '' === $name ) {
                                continue;
                            }
                            $fields[] = [
                                'name'  => $name,
                                'label' => sanitize_text_field( (string) ( $f['label'] ?? $name ) ),
                                'type'  => sanitize_key( (string) ( $f['type'] ?? 'text' ) ),
                                'value' => $this->studio_meta_value_for_ui( function_exists( 'get_field' ) ? get_field( $name, $post_id ) : get_option( 'options_' . $name ) ),
                            ];
                        }
                    }
                    $option_pages[] = [
                        'id'      => 'option-' . $menu_slug,
                        'slug'    => $menu_slug,
                        'label'   => sanitize_text_field( (string) ( $page['page_title'] ?? $page['menu_title'] ?? $menu_slug ) ),
                        'post_id' => $post_id,
                        'source'  => 'acf',
                        'fields'  => $fields,
                        'field_groups' => $group_titles,
                        'editable' => is_array( $ui_option_slugs ) && isset( $ui_option_slugs[ $menu_slug ] ),
                        'settings' => [
                            'page_title'  => (string) ( $page['page_title'] ?? '' ),
                            'menu_title'  => (string) ( $page['menu_title'] ?? '' ),
                            'menu_slug'   => $menu_slug,
                            'parent_slug' => (string) ( $page['parent_slug'] ?? '' ),
                            'position'    => ( isset( $page['position'] ) && '' !== $page['position'] && null !== $page['position'] ) ? (string) $page['position'] : '',
                            'icon_url'    => (string) ( $page['icon_url'] ?? '' ),
                            'capability'  => (string) ( $page['capability'] ?? 'edit_posts' ),
                            'redirect'    => (bool) ( $page['redirect'] ?? false ),
                            'autoload'    => (bool) ( $page['autoload'] ?? false ),
                            'description' => (string) ( $page['description'] ?? '' ),
                        ],
                    ];
                }
            }
        }

        $jet_groups = [];
        if ( function_exists( 'jet_engine' ) && isset( jet_engine()->meta_boxes ) ) {
            $boxes = [];
            if ( method_exists( jet_engine()->meta_boxes, 'get_meta_boxes' ) ) {
                $boxes = jet_engine()->meta_boxes->get_meta_boxes();
            } elseif ( isset( jet_engine()->meta_boxes->data ) && method_exists( jet_engine()->meta_boxes->data, 'get_items' ) ) {
                $boxes = jet_engine()->meta_boxes->data->get_items();
            }
            foreach ( (array) $boxes as $box ) {
                $box_id = '';
                $box_title = '';
                $args = [];
                if ( is_object( $box ) ) {
                    $box_id = $box->id ?? '';
                    $box_title = $box->name ?? ($box->title ?? '');
                    $args = (array) ($box->args ?? []);
                } elseif ( is_array( $box ) ) {
                    $box_id = $box['id'] ?? '';
                    $box_title = $box['name'] ?? ($box['title'] ?? '');
                    $args = $box['args'] ?? [];
                }
                $allowed_posts = $args['allowed_post_types'] ?? [];

                $fields = [];
                $raw_fields = [];
                if ( is_object( $box ) && method_exists( $box, 'get_meta_fields' ) ) {
                    $raw_fields = $box->get_meta_fields();
                } elseif ( is_array( $box ) && isset( $box['meta_fields'] ) ) {
                    $raw_fields = $box['meta_fields'];
                } elseif ( is_object( $box ) && isset( $box->meta_fields ) ) {
                    $raw_fields = $box->meta_fields;
                }

                foreach ( (array) $raw_fields as $f ) {
                    $f_name = '';
                    $f_title = '';
                    $f_type = 'text';
                    if ( is_object( $f ) ) {
                        $f_name = $f->name ?? '';
                        $f_title = $f->title ?? '';
                        $f_type = $f->type ?? 'text';
                    } elseif ( is_array( $f ) ) {
                        $f_name = $f['name'] ?? '';
                        $f_title = $f['title'] ?? '';
                        $f_type = $f['type'] ?? 'text';
                    }
                    if ( $f_name ) {
                        $fields[] = [
                            'name'  => $f_name,
                            'label' => $f_title ?: $f_name,
                            'type'  => $f_type,
                        ];
                    }
                }

                if ( $box_id && ! empty( $fields ) ) {
                    $jet_groups[ $box_id ] = [
                        'id'         => 'jet-' . $box_id,
                        'key'        => $box_id,
                        'title'      => $box_title ?: 'JetEngine Field Group',
                        'fields'     => $fields,
                        'post_types' => (array) $allowed_posts,
                        'source'     => 'jet',
                    ];
                }
            }
        }

        $jet_options = get_option( 'jet_engine_meta_boxes', [] );
        if ( is_array( $jet_options ) ) {
            foreach ( $jet_options as $box ) {
                $box_id = $box['id'] ?? '';
                if ( ! $box_id || isset( $jet_groups[ $box_id ] ) ) {
                    continue;
                }
                $box_title = $box['name'] ?? ($box['title'] ?? '');
                $args = $box['args'] ?? [];
                $allowed_posts = $args['allowed_post_types'] ?? [];
                $raw_fields = $box['meta_fields'] ?? [];
                $fields = [];
                foreach ( (array) $raw_fields as $f ) {
                    $f_name = $f['name'] ?? '';
                    if ( $f_name ) {
                        $fields[] = [
                            'name'  => $f_name,
                            'label' => $f['title'] ?? ($f['label'] ?? $f_name),
                            'type'  => $f['type'] ?? 'text',
                        ];
                    }
                }
                if ( ! empty( $fields ) ) {
                    $jet_groups[ $box_id ] = [
                        'id'         => 'jet-' . $box_id,
                        'key'        => $box_id,
                        'title'      => $box_title ?: 'JetEngine Field Group',
                        'fields'     => $fields,
                        'post_types' => (array) $allowed_posts,
                        'source'     => 'jet',
                    ];
                }
            }
        }

        $field_groups = array_merge( $field_groups, array_values( $jet_groups ) );
        $deduped_cpts = [];
        foreach ( $cpts as $pt ) {
            $name = $pt['name'] ?? '';
            if ( ! $name || isset( $deduped_cpts[ $name ] ) ) {
                continue;
            }
            $deduped_cpts[ $name ] = $pt;
        }
        $cpts = array_values( $deduped_cpts );

        $authors = [];
        foreach ( get_users( [ 'who' => 'authors', 'orderby' => 'display_name', 'order' => 'ASC' ] ) as $user ) {
            $authors[] = [
                'id'   => (int) $user->ID,
                'name' => $user->display_name,
            ];
        }

        $taxonomy_catalog = [];
        foreach ( $cpts as $pt ) {
            $post_type = sanitize_key( (string) ( $pt['name'] ?? '' ) );
            if ( '' === $post_type ) {
                continue;
            }
            $taxonomy_catalog[ $post_type ] = [];
            foreach ( get_object_taxonomies( $post_type, 'objects' ) as $taxonomy ) {
                if ( ! $taxonomy instanceof \WP_Taxonomy || 'post_format' === $taxonomy->name || ( ! $taxonomy->public && ! $taxonomy->show_ui ) ) {
                    continue;
                }
                $terms = get_terms( [
                    'taxonomy'   => $taxonomy->name,
                    'hide_empty' => false,
                    'number'     => 250,
                    'orderby'    => 'name',
                    'order'      => 'ASC',
                ] );
                if ( is_wp_error( $terms ) ) {
                    $terms = [];
                }
                $taxonomy_catalog[ $post_type ][] = [
                    'name'         => $taxonomy->name,
                    'label'        => $taxonomy->labels->name ?: $taxonomy->label,
                    'singular'     => $taxonomy->labels->singular_name ?: $taxonomy->label,
                    'hierarchical' => (bool) $taxonomy->hierarchical,
                    'terms'        => array_map( static function( $term ) {
                        return [
                            'id'   => (int) $term->term_id,
                            'name' => $term->name,
                            'slug' => $term->slug,
                        ];
                    }, $terms ),
                ];
            }
        }

        // Flat custom-taxonomy list with editable settings for the Taxonomies editor (#8).
        $taxonomies_list = [];
        $acf_tax_slugs = [];
        if ( function_exists( 'acf_get_acf_taxonomies' ) ) {
            foreach ( (array) acf_get_acf_taxonomies() as $at ) {
                $tslug = sanitize_key( (string) ( $at['taxonomy'] ?? '' ) );
                if ( $tslug ) {
                    $acf_tax_slugs[ $tslug ] = true;
                }
            }
        }
        // Hide WordPress built-ins plus MV's own plumbing taxonomy and Bricks' template
        // taxonomies — these are not user content models.
        $builtin_tax = [ 'category', 'post_tag', 'post_format', 'nav_menu', 'link_category', 'wp_pattern_category', 'wp_theme', 'wp_template_part_area',
            \VE\Core\MediaCollectionManager::TAXONOMY, 'template_tag', 'template_bundle', 'element_category' ];
        foreach ( get_taxonomies( [], 'objects' ) as $tax ) {
            if ( ! $tax instanceof \WP_Taxonomy ) {
                continue;
            }
            $tslug = $tax->name;
            if ( in_array( $tslug, $builtin_tax, true ) || ! empty( $tax->_builtin ) ) {
                continue;
            }
            $term_ids = get_terms( [ 'taxonomy' => $tslug, 'hide_empty' => false, 'fields' => 'ids' ] );
            $taxonomies_list[] = [
                'name'     => $tslug,
                'label'    => $tax->labels->name ?: $tax->label,
                'singular' => $tax->labels->singular_name ?: $tax->label,
                'source'   => isset( $acf_tax_slugs[ $tslug ] ) ? 'acf' : ( ( function_exists( 'jet_engine' ) && ! isset( $acf_tax_slugs[ $tslug ] ) ) ? 'wp' : 'wp' ),
                'count'    => is_array( $term_ids ) ? count( $term_ids ) : 0,
                'settings' => $this->studio_taxonomy_object_settings( $tax ),
            ];
        }

        return new \WP_REST_Response( [
            'cpts'         => $cpts,
            'field_groups' => $field_groups,
            'option_pages' => $option_pages,
            'authors'      => $authors,
            'current_user_id' => get_current_user_id(),
            'taxonomies'   => $taxonomy_catalog,
            'taxonomies_list' => $taxonomies_list,
            'acf_active'   => function_exists( 'acf_get_field_groups' ),
            'jet_active'   => function_exists( 'jet_engine' ) || ! empty( $jet_options ),
        ], 200 );
    }

    private function is_bricks_post_type_supported_for_studio( string $post_type ): bool {
        if ( '' === $post_type ) {
            return false;
        }

        $supported = [];
        if ( class_exists( '\Bricks\Database' ) && method_exists( '\Bricks\Database', 'get_setting' ) ) {
            $supported = (array) \Bricks\Database::get_setting( 'postTypes', [] );
        } else {
            $settings = get_option( 'bricks_global_settings', [] );
            if ( is_array( $settings ) && isset( $settings['postTypes'] ) ) {
                $supported = (array) $settings['postTypes'];
            }
        }

        if ( defined( 'BRICKS_DB_TEMPLATE_SLUG' ) && $post_type === BRICKS_DB_TEMPLATE_SLUG ) {
            $supported[] = $post_type;
        }

        if ( has_filter( 'bricks/builder/supported_post_types' ) ) {
            $supported = (array) apply_filters( 'bricks/builder/supported_post_types', $supported, $post_type );
        }

        return in_array( $post_type, array_map( 'sanitize_key', $supported ), true );
    }

    private function studio_rank_math_active(): bool {
        return defined( 'RANK_MATH_VERSION' ) || class_exists( '\RankMath' ) || class_exists( '\RankMath\Helper' );
    }

    private function studio_rank_math_summary( int $post_id ): array {
        $title = (string) get_post_meta( $post_id, 'rank_math_title', true );
        if ( '' === $title ) {
            $title = (string) get_post_meta( $post_id, '_rank_math_title', true );
        }
        $description = (string) get_post_meta( $post_id, 'rank_math_description', true );
        if ( '' === $description ) {
            $description = (string) get_post_meta( $post_id, '_rank_math_description', true );
        }
        $focus = (string) get_post_meta( $post_id, 'rank_math_focus_keyword', true );
        if ( '' === $focus ) {
            $focus = (string) get_post_meta( $post_id, '_rank_math_focus_keyword', true );
        }
        $rank_math_active = $this->studio_rank_math_active();
        $score = null;
        if ( $rank_math_active ) {
            $score = get_post_meta( $post_id, 'rank_math_seo_score', true );
            if ( '' === $score || null === $score ) {
                $score = get_post_meta( $post_id, '_rank_math_seo_score', true );
            }
        } else {
            $score = get_post_meta( $post_id, 've_content_seo_score', true );
        }
        $schema = (string) get_post_meta( $post_id, 'rank_math_rich_snippet', true );
        if ( '' === $schema ) {
            $schema = (string) get_post_meta( $post_id, '_rank_math_rich_snippet', true );
        }
        $robots = get_post_meta( $post_id, 'rank_math_robots', true );
        if ( empty( $robots ) ) {
            $robots = get_post_meta( $post_id, '_rank_math_robots', true );
        }
        if ( is_array( $robots ) ) {
            $robots = array_values( array_filter( array_map( 'sanitize_text_field', $robots ) ) );
        } else {
            $robots = array_values( array_filter( array_map( 'sanitize_text_field', preg_split( '/\s*,\s*/', (string) $robots ) ) ) );
        }
        if ( empty( $robots ) ) {
            $robots = [ 'index' ];
        }
        $advanced_robots = get_post_meta( $post_id, 'rank_math_advanced_robots', true );
        if ( ! is_array( $advanced_robots ) ) {
            $advanced_robots = [];
        }
        $canonical = (string) get_post_meta( $post_id, 'rank_math_canonical_url', true );
        $facebook_title = (string) get_post_meta( $post_id, 'rank_math_facebook_title', true );
        $facebook_description = (string) get_post_meta( $post_id, 'rank_math_facebook_description', true );
        $facebook_image = (string) get_post_meta( $post_id, 'rank_math_facebook_image', true );
        $twitter_title = (string) get_post_meta( $post_id, 'rank_math_twitter_title', true );
        $twitter_description = (string) get_post_meta( $post_id, 'rank_math_twitter_description', true );
        $twitter_image = (string) get_post_meta( $post_id, 'rank_math_twitter_image', true );
        $facebook_overlay = (string) get_post_meta( $post_id, 'rank_math_facebook_enable_image_overlay', true );
        $redirect_enabled = (string) get_post_meta( $post_id, 'rank_math_redirection_enabled', true );
        $redirect_type = (string) get_post_meta( $post_id, 'rank_math_redirection_type', true );
        $redirect_url = (string) get_post_meta( $post_id, 'rank_math_redirection_url', true );

        return [
            'title'                => sanitize_text_field( $title ),
            'description'          => sanitize_textarea_field( $description ),
            'focus_keyword'        => sanitize_text_field( $focus ),
            'score'                => is_numeric( $score ) ? (int) $score : null,
            'score_source'         => $rank_math_active ? 'rank_math' : 'content_studio',
            'schema'               => sanitize_text_field( $schema ),
            'robots'               => $robots,
            'canonical_url'        => esc_url_raw( $canonical ),
            'facebook_title'       => sanitize_text_field( $facebook_title ),
            'facebook_description' => sanitize_textarea_field( $facebook_description ),
            'facebook_image'       => esc_url_raw( $facebook_image ),
            'twitter_title'        => sanitize_text_field( $twitter_title ),
            'twitter_description'  => sanitize_textarea_field( $twitter_description ),
            'twitter_image'        => esc_url_raw( $twitter_image ),
            'facebook_enable_image_overlay' => sanitize_text_field( $facebook_overlay ),
            'max_snippet'          => isset( $advanced_robots['max-snippet'] ) ? sanitize_text_field( (string) $advanced_robots['max-snippet'] ) : '-1',
            'max_video_preview'    => isset( $advanced_robots['max-video-preview'] ) ? sanitize_text_field( (string) $advanced_robots['max-video-preview'] ) : '-1',
            'max_image_preview'    => isset( $advanced_robots['max-image-preview'] ) ? sanitize_text_field( (string) $advanced_robots['max-image-preview'] ) : 'large',
            'redirect_enabled'     => sanitize_text_field( $redirect_enabled ),
            'redirect_type'        => sanitize_text_field( $redirect_type ?: '301' ),
            'redirect_url'         => esc_url_raw( $redirect_url ),
            'site_name'            => get_bloginfo( 'name' ),
            'site_url'             => home_url( '/' ),
            'has_plugin'           => $rank_math_active,
            'is_pro'               => defined( 'RANK_MATH_PRO_VERSION' ),
        ];
    }

    private function update_studio_rank_math_meta( int $post_id, array $seo ): void {
        $text_fields = [
            'rank_math_title'                  => 'title',
            'rank_math_focus_keyword'          => 'focus_keyword',
            'rank_math_rich_snippet'           => 'schema',
            'rank_math_facebook_title'         => 'facebook_title',
            'rank_math_twitter_title'          => 'twitter_title',
            'rank_math_facebook_enable_image_overlay' => 'facebook_enable_image_overlay',
            'rank_math_redirection_enabled'    => 'redirect_enabled',
            'rank_math_redirection_type'       => 'redirect_type',
        ];
        $textarea_fields = [
            'rank_math_description'            => 'description',
            'rank_math_facebook_description'   => 'facebook_description',
            'rank_math_twitter_description'    => 'twitter_description',
        ];
        $url_fields = [
            'rank_math_canonical_url'          => 'canonical_url',
            'rank_math_facebook_image'         => 'facebook_image',
            'rank_math_twitter_image'          => 'twitter_image',
            'rank_math_redirection_url'        => 'redirect_url',
        ];
        /* C55, and the line that caused it.
         *
         * This used to read "Rank Math owns its score ... never overwrite
         * rank_math_seo_score", and that rule is the whole of what the owner
         * has been reporting for days: they publish from Content Studio, the
         * title, description, focus keyword and schema are all there in Rank
         * Math - their own screenshot of the Posts list proves it - and the SEO
         * column says **N/A**, until they open the post in the WordPress editor
         * and Rank Math's own JavaScript computes a score and saves it.
         *
         * Rank Math prints N/A when `rank_math_seo_score` is absent. Nothing was
         * failing to write. MV was declining to write the one field the column
         * reads.
         *
         * So it is written now, and only from the right number: the panel sends
         * `score_source` and MV stores the score ONLY when that says the figure
         * came from Rank Math's own analyzer running Rank Math's own research
         * list. MV's internal fallback heuristic is never stored under Rank
         * Math's key - a wrong number wearing Rank Math's name is worse than no
         * number at all, which is the reason the old rule existed.
         *
         * Rank Math overwrites this key on every editor save, so MV writing it
         * on every Content Studio save is the same contract, not a new one.
         */
        $score_given  = array_key_exists( 'score', $seo ) && is_numeric( $seo['score'] );
        $from_analyzer = isset( $seo['score_source'] )
            && 'rank-math-analyzer' === (string) $seo['score_source'];
        $rank_math_on = $this->studio_rank_math_active();

        if ( $score_given && ! $rank_math_on ) {
            update_post_meta( $post_id, 've_content_seo_score', max( 0, min( 100, (int) $seo['score'] ) ) );
        }
        if ( $score_given && $rank_math_on && $from_analyzer ) {
            update_post_meta( $post_id, 'rank_math_seo_score', max( 0, min( 100, (int) $seo['score'] ) ) );
        }
        // Rank Math deletes a key rather than storing an empty value, and the two
        // are not equivalent: a stored '' reads as an explicit blank and stops the
        // site template being used. The panel posts every field back on save,
        // empties included, so the empties have to be turned back into deletions.
        $write = static function ( $meta_key, $value ) use ( $post_id ) {
            if ( '' === $value || null === $value ) {
                delete_post_meta( $post_id, $meta_key );
                return;
            }
            update_post_meta( $post_id, $meta_key, $value );
        };
        foreach ( $text_fields as $meta_key => $ui_key ) {
            if ( array_key_exists( $ui_key, $seo ) ) {
                $write( $meta_key, sanitize_text_field( (string) $seo[ $ui_key ] ) );
            }
        }
        foreach ( $textarea_fields as $meta_key => $ui_key ) {
            if ( array_key_exists( $ui_key, $seo ) ) {
                $write( $meta_key, sanitize_textarea_field( (string) $seo[ $ui_key ] ) );
            }
        }
        foreach ( $url_fields as $meta_key => $ui_key ) {
            if ( array_key_exists( $ui_key, $seo ) ) {
                $write( $meta_key, esc_url_raw( (string) $seo[ $ui_key ] ) );
            }
        }
        if ( array_key_exists( 'robots', $seo ) ) {
            $robots = is_array( $seo['robots'] ) ? $seo['robots'] : preg_split( '/\s*,\s*/', (string) $seo['robots'] );
            $robots = array_values( array_filter( array_map( 'sanitize_text_field', (array) $robots ) ) );
            // The summary substitutes ['index'] when nothing is stored, so that exact
            // value coming back on a post with no robots meta is the untouched
            // default rather than a choice — writing it would override the site's own
            // setting for the post type.
            $stored_robots = get_post_meta( $post_id, 'rank_math_robots', true );
            $is_untouched_default = ( [ 'index' ] === $robots ) && empty( $stored_robots );
            if ( ! $is_untouched_default ) {
                if ( empty( $robots ) ) {
                    delete_post_meta( $post_id, 'rank_math_robots' );
                } else {
                    update_post_meta( $post_id, 'rank_math_robots', $robots );
                }
            }
        }
        $advanced = get_post_meta( $post_id, 'rank_math_advanced_robots', true );
        if ( ! is_array( $advanced ) ) {
            $advanced = [];
        }
        if ( array_key_exists( 'max_snippet', $seo ) ) {
            $advanced['max-snippet'] = sanitize_text_field( (string) $seo['max_snippet'] );
        }
        if ( array_key_exists( 'max_video_preview', $seo ) ) {
            $advanced['max-video-preview'] = sanitize_text_field( (string) $seo['max_video_preview'] );
        }
        if ( array_key_exists( 'max_image_preview', $seo ) ) {
            $advanced['max-image-preview'] = sanitize_text_field( (string) $seo['max_image_preview'] );
        }
        update_post_meta( $post_id, 'rank_math_advanced_robots', $advanced );
    }

    private function studio_post_payload( \WP_Post $post ): array {
        $link = get_permalink( $post->ID ) ?: '#';
        $edit_link = get_edit_post_link( $post->ID, 'raw' );
        if ( ! $edit_link ) {
            $edit_link = admin_url( 'post.php?post=' . $post->ID . '&action=edit' );
        }
        $bricks_editable = $this->is_bricks_post_type_supported_for_studio( $post->post_type );
        $bricks_link = '';
        if ( $bricks_editable ) {
            if ( class_exists( '\\Bricks\\Helpers' ) && method_exists( '\\Bricks\\Helpers', 'get_builder_edit_link' ) ) {
                $maybe_bricks_link = \Bricks\Helpers::get_builder_edit_link( $post->ID );
                $bricks_link = is_string( $maybe_bricks_link ) && '' !== $maybe_bricks_link ? $maybe_bricks_link : '';
            }
            if ( '' === $bricks_link ) {
                $bricks_link = $link && '#' !== $link ? add_query_arg( 'bricks', 'run', $link ) : '';
            }
        }

        /* Read once: the payload needs the fields themselves and the
           attachments they name, and reading them twice is a second pass
           over every meta row on the post. */
        $custom_fields = $this->studio_post_custom_fields( $post->ID );

        $assigned_terms = [];
        foreach ( get_object_taxonomies( $post->post_type, 'objects' ) as $taxonomy ) {
            if ( ! $taxonomy instanceof \WP_Taxonomy || 'post_format' === $taxonomy->name || ( ! $taxonomy->public && ! $taxonomy->show_ui ) ) {
                continue;
            }
            $term_ids = wp_get_object_terms( $post->ID, $taxonomy->name, [ 'fields' => 'ids' ] );
            $assigned_terms[ $taxonomy->name ] = is_wp_error( $term_ids ) ? [] : array_map( 'intval', $term_ids );
        }

        return [
            'id'            => $post->ID,
            'type'          => $post->post_type,
            'title'         => [ 'rendered' => $post->post_title ],
            'slug'          => $post->post_name,
            'status'        => $post->post_status,
            'content'       => [ 'raw' => $post->post_content ],
            'excerpt'       => [ 'raw' => $post->post_excerpt ],
            'author'        => (int) $post->post_author,
            'terms'         => $assigned_terms,
            'parent'        => (int) $post->post_parent,
            'menu_order'    => (int) $post->menu_order,
            'featured_media'=> (int) get_post_thumbnail_id( $post->ID ),
            'featured_media_url' => get_post_thumbnail_id( $post->ID ) ? (string) wp_get_attachment_image_url( (int) get_post_thumbnail_id( $post->ID ), 'medium' ) : '',
            'comment_status'=> $post->comment_status,
            'ping_status'   => $post->ping_status,
            'template'      => get_page_template_slug( $post->ID ) ?: '',
            'date'          => $post->post_date_gmt,
            // WordPress gives every draft a creation date, which is not the same
            // thing as a Calendar target date. Keep that intent explicit so the
            // Content Studio Unscheduled rail can separate the two reliably.
            'calendar_scheduled' => in_array( $post->post_status, [ 'publish', 'future' ], true ) || (bool) get_post_meta( $post->ID, '_ve_content_calendar_scheduled', true ),
            'modified'      => $post->post_modified_gmt,
            'link'          => $link,
            'edit_link'     => $edit_link,
            'bricks_link'   => $bricks_link,
            /* C8, 2026-09-05. The owner published an article from Content Studio,
             * purged every cache, and the page still showed the old copy with
             * `[Insert Image: ...]` markers in it - while the stored post content
             * held four images and no markers. Both were true: the front end runs
             * `bricks renders this page: true`.
             *
             * Bricks renders from its OWN store, so a post it owns will never show
             * what Content Studio writes into post_content, however many times it
             * is saved. Reporting it is not the whole fix, but silently succeeding
             * is the actual bug - the panel said published and nothing changed.
             *
             * The meta is read directly rather than through
             * BricksPageAdapter::is_bricks_post(), which is the canonical
             * definition of the same test: Workspaces is a module and can be
             * switched off, and this payload must not depend on that. If the key
             * ever changes, both move together. */
            'rendered_by_bricks' => ! empty( get_post_meta( $post->ID, '_bricks_page_content_2', true ) ),
            'bricks_editable' => $bricks_editable,
            'supports_editor' => post_type_supports( $post->post_type, 'editor' ),
            'seo_details'   => $this->studio_rank_math_summary( $post->ID ),
            'custom_fields' => $custom_fields,
            /* R29. An ACF image, file or gallery field stores an attachment ID,
               and the editor was showing the owner "1768". The panel cannot draw
               a picture from a number, and asking it to fetch each one would be a
               request per field on a post that has three of them - so the whole
               map comes with the post, in the payload the panel already waits
               for. */
            'field_media'   => $this->studio_field_media_previews( $custom_fields ),
            /* R29. The same idea for the fields that store post and term ids: a
               relationship showing "1751, 1753" is the image field showing 1768
               all over again. Posts and terms are kept apart, because a post id
               and a term id can be the same number and only the field knows
               which it meant. */
            'field_refs'    => $this->studio_field_reference_previews( $custom_fields ),
        ];
    }

    /**
     * Every attachment named by a custom field, as something drawable.
     *
     * Values arrive from `studio_post_custom_fields()` already flattened, so an
     * image field is "1768" and a gallery is a JSON array of ids. Both are read
     * here rather than guessing from the field type, which means it holds for
     * JetEngine and plain meta as well as ACF.
     */
    private function studio_field_media_previews( array $fields ): array {
        $ids = [];
        foreach ( $fields as $value ) {
            $value = (string) $value;
            if ( '' === $value ) {
                continue;
            }
            if ( ctype_digit( $value ) ) {
                $ids[] = (int) $value;
                continue;
            }
            /* A gallery or a repeater of images. Only bare integers are taken;
               anything else in there is not an attachment reference. */
            if ( '[' === substr( ltrim( $value ), 0, 1 ) ) {
                $decoded = json_decode( $value, true );
                if ( is_array( $decoded ) ) {
                    foreach ( $decoded as $entry ) {
                        if ( is_int( $entry ) || ( is_string( $entry ) && ctype_digit( $entry ) ) ) {
                            $ids[] = (int) $entry;
                        }
                    }
                }
            }
        }

        $ids = array_slice( array_values( array_unique( array_filter( $ids ) ) ), 0, 120 );
        $out = [];
        foreach ( $ids as $id ) {
            if ( 'attachment' !== get_post_type( $id ) ) {
                continue;   // a post id in a relationship field is not media
            }
            $mime = (string) get_post_mime_type( $id );
            $out[ (string) $id ] = [
                'id'    => $id,
                'url'   => (string) wp_get_attachment_url( $id ),
                'thumb' => (string) ( wp_get_attachment_image_url( $id, 'thumbnail' ) ?: '' ),
                'title' => (string) get_the_title( $id ),
                'mime'  => $mime,
                'kind'  => 0 === strpos( $mime, 'image/' ) ? 'image'
                    : ( 0 === strpos( $mime, 'audio/' ) ? 'audio'
                    : ( 0 === strpos( $mime, 'video/' ) ? 'video' : 'file' ) ),
            ];
        }

        return $out;
    }

    /**
     * Meta this route must never hand to the editor or write back.
     *
     * C81, 2026-09-09, and it is MV's own doing. One article on the owner's site
     * answered HTTP 500 for days. MV's new fatal log named it:
     *
     *   Cannot access offset of type string on string
     *   seo-by-rank-math/includes/modules/schema/class-frontend.php:73
     *   ... array_filter() -> add_schema() -> json_ld() -> wp_head()
     *
     * Rank Math stores its schema as an ARRAY in `rank_math_schema_*`. Content
     * Studio read every non-underscore meta key, flattened each one to a string
     * for a text box, and wrote them all back on save - so a schema array became
     * a JSON string, and Rank Math's reader indexed a string and died on every
     * front-end request for that post.
     *
     * The editor never showed those keys: the panel hides anything in a plugin
     * namespace. It sent them anyway, because it was handed them. So they are not
     * handed over at all now, and the write side refuses them independently -
     * either alone would have prevented this, and neither was there.
     *
     * Rank Math's SEO fields are still editable; they go through
     * `update_studio_rank_math_meta()`, which knows their shape.
     */
    private function is_plugin_owned_meta( string $key ): bool {
        return (bool) preg_match(
            '/^(rank_math|rankmath|wpseo|yoast|aioseo|all_in_one_seo|monsterinsights|analytify|jetpack|elementor|et_pb|fusion|avada|wpml|polylang|woocommerce)_/i',
            $key
        );
    }

    private function studio_post_custom_fields( int $post_id ): array {
        $out = [];

        if ( function_exists( 'get_fields' ) ) {
            $acf_values = get_fields( $post_id );
            if ( is_array( $acf_values ) ) {
                foreach ( $acf_values as $key => $value ) {
                    $key = sanitize_key( (string) $key );
                    if ( $this->is_plugin_owned_meta( $key ) ) {
                        continue;
                    }
                    $out[ $key ] = $this->studio_meta_value_for_ui( $value );
                }
            }
        }

        $raw_meta = get_post_meta( $post_id );
        foreach ( $raw_meta as $key => $values ) {
            if ( 0 === strpos( (string) $key, '_' ) || isset( $out[ $key ] ) ) {
                continue;
            }
            $clean = sanitize_key( (string) $key );
            if ( $this->is_plugin_owned_meta( $clean ) ) {
                continue;
            }
            $value = is_array( $values ) ? reset( $values ) : $values;
            $out[ $clean ] = $this->studio_meta_value_for_ui( $value );
        }

        return $out;
    }

    /**
     * Every meta value that was an array and is now a string of its own JSON.
     *
     * C81. This is the fingerprint of the bug above, and only of it: a value
     * `wp_json_encode`d with JSON_PRETTY_PRINT by `studio_meta_value_for_ui()`
     * and written straight back. Re-encoding the decoded array has to produce
     * the stored string exactly, or it is somebody's genuine JSON string and is
     * left alone.
     *
     * Scoped to plugin-owned keys, because those are the ones whose owners read
     * them back as arrays and die. A JSON string sitting in a field MV renders
     * is visible and editable; this is about the ones nobody could see.
     */
    /**
     * Keys whose owning plugin ALWAYS stores an array, so a plain string in one
     * is damage by definition rather than a judgement call.
     *
     * Rank Math keeps every schema under `rank_math_schema_<Type>` and reads them
     * with `array_filter()` over `$schema['@type']`. A string there kills every
     * front-end request for that post, which is C81.
     */
    /** R47. Newest first. */
    public function get_bricks_sync_notices(): \WP_REST_Response {
        $list = get_option( \VE\Adapters\Bricks\VariablesMirror::NOTICES_OPTION, [] );
        $list = is_array( $list ) ? array_reverse( $list ) : [];
        return new \WP_REST_Response( [ 'notices' => $list ], 200 );
    }

    public function clear_bricks_sync_notices(): \WP_REST_Response {
        delete_option( \VE\Adapters\Bricks\VariablesMirror::NOTICES_OPTION );
        return new \WP_REST_Response( [ 'cleared' => true ], 200 );
    }

    private function is_array_only_meta_key( string $key ): bool {
        return (bool) preg_match( '/^rank_math_schema_/i', $key );
    }

    /**
     * R44, direction 2 - "the form that follows the type". Route 1 as the owner
     * chose it: read what is there, edit only that.
     *
     * Every schema the post already has, as the array Rank Math stored. A key
     * holding anything but an array is left out: that is C81's damage, and
     * editing it here would be editing the wreckage.
     */
    public function get_studio_post_schema( \WP_REST_Request $request ) {
        $post_id = (int) $request['id'];
        if ( ! get_post( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
            return new \WP_Error( 've_schema_forbidden', 'You cannot edit that post.', [ 'status' => 403 ] );
        }
        $out = [];
        foreach ( (array) get_post_meta( $post_id ) as $key => $values ) {
            if ( ! $this->is_array_only_meta_key( (string) $key ) ) {
                continue;
            }
            $value = maybe_unserialize( is_array( $values ) ? reset( $values ) : $values );
            if ( ! is_array( $value ) ) {
                continue;
            }
            $out[] = [
                'key'   => (string) $key,
                'type'  => (string) ( $value['@type'] ?? preg_replace( '/^rank_math_schema_/i', '', (string) $key ) ),
                'value' => $value,
            ];
        }
        return new \WP_REST_Response( [ 'schemas' => $out ], 200 );
    }

    /**
     * Write one schema back, merged into what is stored rather than replacing it.
     */
    public function save_studio_post_schema( \WP_REST_Request $request ) {
        $post_id = (int) $request['id'];
        if ( ! get_post( $post_id ) || ! current_user_can( 'edit_post', $post_id ) ) {
            return new \WP_Error( 've_schema_forbidden', 'You cannot edit that post.', [ 'status' => 403 ] );
        }
        $params = (array) $request->get_json_params();
        $key    = (string) ( $params['key'] ?? '' );
        $sent   = $params['value'] ?? null;
        if ( ! $this->is_array_only_meta_key( $key ) ) {
            return new \WP_Error( 've_schema_key', 'That is not a Rank Math schema.', [ 'status' => 400 ] );
        }
        $stored = maybe_unserialize( get_post_meta( $post_id, $key, true ) );
        if ( ! is_array( $stored ) ) {
            // Route 1: a schema the post does not have is not made here.
            return new \WP_Error( 've_schema_missing', 'This post has no such schema to edit.', [ 'status' => 404 ] );
        }
        if ( ! is_array( $sent ) ) {
            return new \WP_Error( 've_schema_shape', 'A schema is saved as a list of properties, not as text.', [ 'status' => 400 ] );
        }
        $merged = self::studio_schema_merge( $stored, $sent );
        if ( $merged !== $stored ) {
            update_post_meta( $post_id, $key, $merged );
        }
        return new \WP_REST_Response( [ 'key' => $key, 'value' => $merged, 'changed' => $merged !== $stored ], 200 );
    }

    /**
     * What was stored, with the edits laid over it - and nothing else.
     *
     * - every stored key stays, whether or not the edit mentions it;
     * - a key the edit invents is ignored (route 1: never invent one);
     * - a list or object stays a list or object, and is merged the same way
     *   one level down - what took the Bitcoin article down was an array
     *   written back as a string;
     * - a single value takes the edit only if the edit is a single value too;
     * - `metadata` is Rank Math's own bookkeeping and is never changed here;
     * - `@type` is what the schema IS, and is never changed here either.
     *
     * Pure, so a guard can walk it.
     */
    public static function studio_schema_merge( array $stored, array $sent ): array {
        $out = $stored;
        foreach ( $stored as $k => $old ) {
            if ( 'metadata' === $k || '@type' === $k ) {
                continue;
            }
            if ( ! array_key_exists( $k, $sent ) ) {
                continue;
            }
            $new = $sent[ $k ];
            if ( is_array( $old ) ) {
                if ( is_array( $new ) ) {
                    $out[ $k ] = self::studio_schema_merge( $old, $new );
                }
                continue;
            }
            if ( is_array( $new ) || is_object( $new ) ) {
                continue;
            }
            if ( is_bool( $old ) ) {
                $out[ $k ] = (bool) $new;
            } elseif ( is_int( $old ) && is_numeric( $new ) && (string) (int) $new === (string) $new ) {
                $out[ $k ] = (int) $new;
            } else {
                $out[ $k ] = null === $new ? '' : (string) $new;
            }
        }
        return $out;
    }

    /**
     * Meta a Content Studio save turned from structure into text.
     *
     * C81, second pass - and the first pass looked for the wrong thing. It asked
     * for a value that decodes to an array AND re-encodes to exactly what is
     * stored. That can never match: `studio_meta_value_from_ui()` decodes any
     * string that parses as JSON back into an array before writing, so anything
     * left as a STRING in the database is precisely the case that did NOT parse.
     * The owner installed dev.75, opened Diagnostics, and the card never appeared
     * while the article was still answering 500.
     *
     * Two kinds are looked for now:
     *
     *   restore - a plugin-owned key holding JSON that still decodes to an array.
     *             Reachable through other writers, and repaired by decoding it.
     *   remove  - a key whose plugin only ever stores an array, holding a plain
     *             string. There is nothing to decode; the value stopped being the
     *             plugin's data. Removing it is the repair, and it is called
     *             removal rather than dressed up as something gentler.
     */
    private function find_flattened_plugin_meta( int $limit = 500 ): array {
        global $wpdb;
        $limit = max( 1, $limit );
        $found = [];
        $seen  = [];

        $add = function ( $row, string $action, $value, string $reason ) use ( &$found, &$seen ) {
            $id = (int) $row->meta_id;
            if ( isset( $seen[ $id ] ) ) {
                return;
            }
            $seen[ $id ] = true;
            $found[] = [
                'meta_id'  => $id,
                'post_id'  => (int) $row->post_id,
                'title'    => (string) get_the_title( (int) $row->post_id ),
                'meta_key' => (string) $row->meta_key,
                'action'   => $action,
                'reason'   => $reason,
                'value'    => $value,
            ];
        };

        /* ONE query, on the meta KEY, which is indexed.
           The first version had a pass that matched on `meta_value LIKE '{%'`
           across every non-underscore key on the site. `meta_value` is LONGTEXT
           and is not indexed, so that reads every meta value the site holds -
           on a Bricks site that is megabytes per page - and it existed only to
           find keys this function then narrowed to `rank_math_schema_*` anyway.
           Both classes are scoped to array-only keys now, so both come from the
           same indexed prefix and the full scan is simply gone. */
        $strict_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT meta_id, post_id, meta_key, meta_value FROM {$wpdb->postmeta}
              WHERE meta_key LIKE %s
              ORDER BY meta_id DESC LIMIT %d",
            $wpdb->esc_like( 'rank_math_schema_' ) . '%', $limit
        ) );
        foreach ( (array) $strict_rows as $row ) {
            /* Still readable as JSON, so it can be put back exactly as it was
               rather than removed. */
            $decoded = json_decode( (string) $row->meta_value, true );
            if ( is_array( $decoded ) && $this->is_array_only_meta_key( (string) $row->meta_key ) ) {
                $add( $row, 'restore', $decoded, 'held as text, and it decodes cleanly back to its own structure' );
                continue;
            }
            $key   = (string) $row->meta_key;
            $value = (string) $row->meta_value;
            if ( ! $this->is_array_only_meta_key( $key ) ) {
                continue;
            }
            /* Healthy means it unserializes to an ARRAY - not merely that it is
               serialized.
               C81, third pass. dev.76 skipped anything `is_serialized()` called
               true, and that is true of a serialized STRING as well: `s:5:"..."`.
               Rank Math reads these keys through `maybe_unserialize`, so a
               serialized string comes back as a string, lands in its `array_filter`
               over schemas, and dies on `$schema['@type']` exactly as an empty
               value does. The owner installed dev.82, opened Diagnostics, and read
               "none found" on a site whose article was still failing. */
            $unserialized = is_serialized( $value ) ? @unserialize( $value ) : null;
            if ( is_array( $unserialized ) ) {
                continue;   // the plugin's own array, untouched
            }
            $reason = 'plain text where its plugin stores a schema, and it no longer parses';
            if ( '' === trim( $value ) ) {
                $reason = 'empty where its plugin stores a schema, which is what makes the page fail';
            } elseif ( is_string( $unserialized ) ) {
                $reason = 'a single stored string where its plugin stores a list of schemas';
            }
            $add( $row, 'remove', null, $reason );
        }

        return $found;
    }

    /**
     * Every post and every term named by a custom field, as something readable.
     *
     * Read from the values rather than the field definitions, the same way the
     * media previews are, so it holds for JetEngine and plain meta too. Both maps
     * are filled for every id found; the panel picks the one its field type means,
     * which is why a post id and a term id sharing a number costs nothing here.
     */
    private function studio_field_reference_previews( array $fields ): array {
        $ids = [];
        foreach ( $fields as $value ) {
            $value = trim( (string) $value );
            if ( '' === $value ) {
                continue;
            }
            if ( ctype_digit( $value ) ) {
                $ids[] = (int) $value;
                continue;
            }
            if ( '[' === substr( $value, 0, 1 ) || '{' === substr( $value, 0, 1 ) ) {
                $decoded = json_decode( $value, true );
                if ( is_array( $decoded ) ) {
                    /* Recursive on purpose: a relationship inside a repeater row
                       is a list inside a list, and its ids are just as unreadable. */
                    array_walk_recursive( $decoded, static function ( $entry ) use ( &$ids ) {
                        if ( is_int( $entry ) || ( is_string( $entry ) && ctype_digit( $entry ) ) ) {
                            $ids[] = (int) $entry;
                        }
                    } );
                }
            }
        }

        $ids = array_slice( array_values( array_unique( array_filter( $ids ) ) ), 0, 120 );
        $posts = [];
        $terms = [];
        /* C89, 2026-09-24, measured on test7: a user field holding user 1 was
           drawn as "Hello world!" - post 1. A user id and a post id can be the
           same number, as a term id can, so users get their own map and only the
           field type says which one is meant. The name only: no email. */
        $users = [];
        foreach ( $ids as $id ) {
            $person = get_userdata( $id );
            if ( $person instanceof \WP_User ) {
                $users[ (string) $id ] = [
                    'id'    => $id,
                    'label' => (string) $person->display_name,
                    'role'  => (string) ( $person->roles[0] ?? '' ),
                ];
            }
            $found = get_post( $id );
            if ( $found instanceof \WP_Post && 'attachment' !== $found->post_type ) {
                $posts[ (string) $id ] = [
                    'id'     => $id,
                    'label'  => (string) get_the_title( $id ),
                    'type'   => (string) $found->post_type,
                    'status' => (string) $found->post_status,
                ];
            }
            $term = get_term( $id );
            if ( $term instanceof \WP_Term ) {
                $terms[ (string) $id ] = [
                    'id'       => $id,
                    'label'    => (string) $term->name,
                    'taxonomy' => (string) $term->taxonomy,
                ];
            }
        }

        return [ 'posts' => $posts, 'terms' => $terms, 'users' => $users ];
    }

    /**
     * What a reference field will accept, for its picker.
     *
     * One route for both kinds: a taxonomy asks for terms, everything else asks
     * for posts of the types the field allows. Capped and searchable, because a
     * site with four thousand posts must not send four thousand options to draw
     * one dropdown - and because `content-studio/posts` returns a full studio
     * payload per item, which is far more than a dropdown needs.
     */
    public function studio_field_options( $request ) {
        $search   = sanitize_text_field( (string) ( $request->get_param( 'search' ) ?: '' ) );
        $taxonomy = sanitize_key( (string) ( $request->get_param( 'taxonomy' ) ?: '' ) );
        $items    = [];

        /* C89: a user field's picker offers people, not posts. Only to someone
           who may list the site's users; anyone else is told why the list is
           empty rather than shown one that looks complete. */
        if ( rest_sanitize_boolean( $request->get_param( 'users' ) ?? false ) ) {
            if ( ! current_user_can( 'list_users' ) ) {
                return rest_ensure_response( [ 'items' => [], 'message' => 'Only someone who can list users can choose one here.' ] );
            }
            $people = get_users( [
                'number'         => 60,
                'orderby'        => 'display_name',
                'search'         => '' !== $search ? '*' . $search . '*' : '',
                'search_columns' => [ 'display_name', 'user_login', 'user_nicename' ],
            ] );
            foreach ( $people as $person ) {
                $items[] = [
                    'id'    => (int) $person->ID,
                    'label' => (string) $person->display_name,
                    'sub'   => (string) ( $person->roles[0] ?? 'user' ),
                ];
            }
            return rest_ensure_response( [ 'items' => $items ] );
        }

        if ( '' !== $taxonomy ) {
            if ( ! taxonomy_exists( $taxonomy ) ) {
                return rest_ensure_response( [ 'items' => [] ] );
            }
            $found = get_terms( [
                'taxonomy'   => $taxonomy,
                'hide_empty' => false,
                'number'     => 60,
                'search'     => $search,
                'orderby'    => 'name',
            ] );
            foreach ( is_wp_error( $found ) ? [] : $found as $term ) {
                $items[] = [ 'id' => (int) $term->term_id, 'label' => (string) $term->name, 'sub' => $taxonomy ];
            }
            return rest_ensure_response( [ 'items' => $items ] );
        }

        $types = array_values( array_filter( array_map(
            'sanitize_key',
            explode( ',', (string) ( $request->get_param( 'post_type' ) ?: '' ) )
        ) ) );
        $types = array_values( array_filter( $types, 'post_type_exists' ) );
        if ( ! $types ) {
            $types = [ 'post', 'page' ];
        }

        $found = get_posts( [
            'post_type'      => $types,
            'post_status'    => [ 'publish', 'future', 'draft', 'pending', 'private' ],
            'posts_per_page' => 60,
            'orderby'        => 'modified',
            'order'          => 'DESC',
            's'              => $search,
            'perm'           => 'readable',
        ] );
        foreach ( $found as $found_post ) {
            $items[] = [
                'id'    => (int) $found_post->ID,
                'label' => (string) get_the_title( $found_post ),
                'sub'   => (string) $found_post->post_type
                    . ( 'publish' === $found_post->post_status ? '' : ' - ' . $found_post->post_status ),
            ];
        }

        return rest_ensure_response( [ 'items' => $items ] );
    }

    public function diagnostics_client_error( $request ) {
        $params = (array) $request->get_json_params();
        $cut = static function ( $value, int $max ): string {
            return substr( sanitize_textarea_field( (string) $value ), 0, $max );
        };

        \VE\Core\Logger::error( 'panel_crash', [
            'panel'   => sanitize_key( (string) ( $params['panel'] ?? 'panel' ) ),
            'message' => $cut( $params['message'] ?? '', 500 ),
            'file'    => $cut( $params['panel'] ?? '', 60 ) . ' (browser)',
            'stack'   => $cut( $params['stack'] ?? '', 2000 ),
            'url'     => esc_url_raw( (string) ( $params['url'] ?? '' ) ),
            'mv'      => true,
        ] );

        return rest_ensure_response( [ 'recorded' => true ] );
    }

    public function diagnostics_meta_scan( $request ) {
        $found = $this->find_flattened_plugin_meta();
        $posts = [];
        foreach ( $found as $row ) {
            $id = $row['post_id'];
            if ( ! isset( $posts[ $id ] ) ) {
                $posts[ $id ] = [
                    'post_id' => $id,
                    'title'   => $row['title'],
                    'link'    => (string) get_permalink( $id ),
                    'keys'    => [],
                ];
            }
            $posts[ $id ]['keys'][] = [
                'key'    => $row['meta_key'],
                'action' => $row['action'],
                'reason' => $row['reason'],
            ];
        }

        return rest_ensure_response( [
            'damaged'  => array_values( $posts ),
            'count'    => count( $found ),
            'restores' => count( array_filter( $found, static function ( $r ) { return 'restore' === $r['action']; } ) ),
            'removals' => count( array_filter( $found, static function ( $r ) { return 'remove' === $r['action']; } ) ),
            /* C81. The first version drew nothing when it found nothing, so a scan
               that found nothing and a scan that never ran looked identical - and
               the one that mattered was the second. */
            'checked'  => true,
        ] );
    }

    public function diagnostics_meta_repair( $request ) {
        $found    = $this->find_flattened_plugin_meta();
        $restored = [];
        $removed  = [];
        foreach ( $found as $row ) {
            $where = $row['post_id'] . ' / ' . $row['meta_key'];
            if ( 'remove' === $row['action'] ) {
                delete_post_meta( $row['post_id'], $row['meta_key'] );
                $removed[] = $where;
                continue;
            }
            update_post_meta( $row['post_id'], $row['meta_key'], wp_slash( $row['value'] ) );
            $restored[] = $where;
        }
        if ( $restored || $removed ) {
            \VE\Core\Logger::event( 'meta_repair', [ 'restored' => $restored, 'removed' => $removed ] );
        }

        $said = [];
        if ( $restored ) {
            $said[] = sprintf( '%d field%s put back as structured data', count( $restored ), 1 === count( $restored ) ? '' : 's' );
        }
        if ( $removed ) {
            $said[] = sprintf( '%d unreadable field%s removed', count( $removed ), 1 === count( $removed ) ? '' : 's' );
        }

        return rest_ensure_response( [
            'repaired' => count( $restored ) + count( $removed ),
            'restored' => count( $restored ),
            'removed'  => count( $removed ),
            'items'    => array_merge( $restored, $removed ),
            'message'  => $said ? ( ucfirst( implode( ', and ', $said ) ) . '.' ) : 'Nothing to repair.',
        ] );
    }

    /**
     * One ACF field as the panel needs it, sub-fields and all.
     *
     * R29 - "the repeater yet to work as it should." A repeater's rows are made
     * of its `sub_fields`, and MV was only ever reading the top level, so a
     * repeater arrived as a name and a type with nothing to build a row from.
     * Groups and flexible-content layouts nest the same way.
     *
     * Depth is capped rather than trusted. ACF will not stop you putting a
     * repeater inside a repeater inside a repeater, and a payload that grows
     * with the nesting is a payload that can stop arriving.
     */
    private function studio_acf_field_shape( array $f, int $depth = 0 ): array {
        $shape = [
            'name'  => $f['name'] ?? '',
            'label' => $f['label'] ?? ( $f['name'] ?? '' ),
            'type'  => $f['type'] ?? 'text',
            /* R29. The sentence ACF shows under a field, and whether it is
               required. Both are already written on the field; not sending them
               was the only reason MV could not show them. */
            'instructions' => (string) ( $f['instructions'] ?? '' ),
            'required'     => ! empty( $f['required'] ),
            'choices'      => is_array( $f['choices'] ?? null ) ? $f['choices'] : null,
            /* R29, design pass - "it shold follow exactly like wp editor, but
               mv's style." How wide the field is set to be, and the unit that
               sits against the input ("min" beside Reading Time Override). */
            'width'   => (string) ( $f['wrapper']['width'] ?? '' ),
            'append'  => (string) ( $f['append'] ?? '' ),
            'prepend' => (string) ( $f['prepend'] ?? '' ),
            'placeholder' => (string) ( $f['placeholder'] ?? '' ),
            'key'     => (string) ( $f['key'] ?? '' ),
            /* R29 - "If that is off, then the others shouldn't show, that's the
               condition." `conditional_logic` is a list of OR groups, each an AND
               list of {field, operator, value}, where the field is a KEY. */
            'conditional_logic' => is_array( $f['conditional_logic'] ?? null )
                ? $f['conditional_logic'] : [],
        ];

        $type = (string) $shape['type'];

        /* R29. A relationship, a post object or a taxonomy field stores IDs, and
           what it will accept is written on the field: which post types, which
           taxonomy, and whether it takes one or many. Without those the panel can
           only offer a text box, which is what it was doing. */
        if ( in_array( $type, [ 'post_object', 'relationship', 'page_link', 'user', 'taxonomy' ], true ) ) {
            $shape['post_type'] = array_values( array_filter( array_map( 'sanitize_key', (array) ( $f['post_type'] ?? [] ) ) ) );
            $shape['taxonomy_name'] = 'taxonomy' === $type
                ? sanitize_key( (string) ( $f['taxonomy'] ?? '' ) )
                : '';
            /* ACF says "many" in three different ways depending on the field. A
               relationship is always many; a post object and a user say so with
               `multiple`; a taxonomy says so with `field_type`. */
            $shape['multiple'] = 'relationship' === $type
                || ! empty( $f['multiple'] )
                || in_array( (string) ( $f['field_type'] ?? '' ), [ 'checkbox', 'multi_select' ], true );
            $shape['allow_null'] = ! empty( $f['allow_null'] );
            $shape['min'] = (int) ( $f['min'] ?? 0 );
            $shape['max'] = (int) ( $f['max'] ?? 0 );
        }

        if ( in_array( $type, [ 'repeater', 'group' ], true ) && $depth < 3 ) {
            $shape['sub_fields'] = [];
            foreach ( (array) ( $f['sub_fields'] ?? [] ) as $sub ) {
                $shape['sub_fields'][] = $this->studio_acf_field_shape( (array) $sub, $depth + 1 );
            }
            /* A repeater says how few and how many rows it will hold, and a
               button that adds a row past the maximum is a button that fails. */
            $shape['min'] = (int) ( $f['min'] ?? 0 );
            $shape['max'] = (int) ( $f['max'] ?? 0 );
            $shape['button_label'] = (string) ( $f['button_label'] ?? '' );
        }

        return $shape;
    }

    private function studio_meta_value_for_ui( $value ): string {
        if ( is_null( $value ) ) {
            return '';
        }

        if ( is_scalar( $value ) ) {
            return (string) $value;
        }

        $json = wp_json_encode( $value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
        return is_string( $json ) ? $json : '';
    }

    private function studio_meta_value_from_ui( $value ) {
        if ( ! is_string( $value ) ) {
            return $value;
        }

        $trimmed = trim( $value );
        if ( '' === $trimmed ) {
            return '';
        }

        $first = substr( $trimmed, 0, 1 );
        if ( '{' === $first || '[' === $first ) {
            $decoded = json_decode( $trimmed, true );
            if ( JSON_ERROR_NONE === json_last_error() ) {
                return $decoded;
            }
        }

        return $value;
    }

    private function studio_content_import_value( array $row, array $mapping, string $field ): string {
        foreach ( $mapping as $column => $mapped_field ) {
            if ( $field !== $mapped_field || ! array_key_exists( $column, $row ) ) {
                continue;
            }
            $value = $row[ $column ];
            if ( is_scalar( $value ) || null === $value ) {
                return trim( wp_check_invalid_utf8( (string) $value ) );
            }
        }
        return '';
    }

    private function studio_content_import_terms( string $value ): array {
        if ( '' === trim( $value ) ) {
            return [];
        }
        $parts = preg_split( '/[|,]+/', $value );
        if ( ! is_array( $parts ) ) {
            return [];
        }
        return array_values( array_unique( array_filter( array_map( static function( $term ) {
            return sanitize_text_field( trim( (string) $term ) );
        }, $parts ) ) ) );
    }

    private function studio_content_import_author( string $value, int $fallback ): int {
        $value = trim( $value );
        if ( '' === $value ) {
            return $fallback;
        }
        if ( ctype_digit( $value ) ) {
            $user = get_user_by( 'id', (int) $value );
            return $user ? (int) $user->ID : $fallback;
        }
        $user = is_email( $value ) ? get_user_by( 'email', $value ) : get_user_by( 'login', $value );
        if ( ! $user ) {
            $users = get_users( [
                'search'         => $value,
                'search_columns' => [ 'display_name' ],
                'number'         => 1,
            ] );
            $user = ! empty( $users ) ? $users[0] : null;
        }
        return $user ? (int) $user->ID : $fallback;
    }

    private function prepare_studio_content_import( array $params ) {
        $rows = isset( $params['rows'] ) && is_array( $params['rows'] ) ? array_values( $params['rows'] ) : [];
        $mapping_input = isset( $params['mapping'] ) && is_array( $params['mapping'] ) ? $params['mapping'] : [];
        $options_input = isset( $params['options'] ) && is_array( $params['options'] ) ? $params['options'] : [];

        if ( empty( $rows ) ) {
            return new \WP_Error( 'empty_content_import', 'The import file has no content rows.' );
        }
        if ( count( $rows ) > 5000 ) {
            return new \WP_Error( 'content_import_too_large', 'Content imports are limited to 5,000 rows per file.' );
        }

        /* R27: `media_id` downloads whatever the site allows - audio, PDF, video -
           and stores the ATTACHMENT ID under the column's own name, which is what
           an ACF Image or File field reads. `custom` stores the cell as text, and
           a URL as text is exactly what those fields cannot use. */
        $allowed_fields = [ 'ignore', 'title', 'content', 'excerpt', 'slug', 'status', 'date', 'author', 'categories', 'tags', 'featured_image_url', 'media_id', 'custom' ];

        /* R43. `custom` and `media_id` may name the meta key they land on -
           `custom:role_description` - so the kind is split off before anything
           is sanitised. sanitize_key() eats a colon, and running it first would
           turn that into one meaningless word that failed the check below and
           silently dropped the column. */
        $keyed_fields = [ 'custom', 'media_id' ];
        $mapping = [];
        foreach ( $mapping_input as $column => $field ) {
            $column = sanitize_text_field( (string) $column );
            if ( '' === $column ) {
                continue;
            }
            $dest = $this->studio_import_destination( $field );
            if ( ! in_array( $dest['kind'], $allowed_fields, true ) ) {
                continue;
            }
            if ( '' !== $dest['key'] && ! in_array( $dest['kind'], $keyed_fields, true ) ) {
                // Title does not get to choose a meta key. Keep the kind, drop
                // the rest, rather than refusing the whole import over it.
                $dest['key'] = '';
            }
            if ( '_' === substr( $dest['key'], 0, 1 ) ) {
                $dest['key'] = '';
            }
            $mapping[ $column ] = '' !== $dest['key']
                ? $dest['kind'] . ':' . $dest['key']
                : $dest['kind'];
        }
        if ( ! in_array( 'title', $mapping, true ) ) {
            return new \WP_Error( 'content_import_missing_title_map', 'Map one file column to Title before reviewing the import.' );
        }

        $post_type = sanitize_key( (string) ( $options_input['post_type'] ?? 'post' ) );
        if ( ! post_type_exists( $post_type ) ) {
            return new \WP_Error( 'content_import_bad_post_type', 'The selected post type does not exist.' );
        }
        $post_type_object = get_post_type_object( $post_type );
        if ( ! $post_type_object || ( ! $post_type_object->public && ! $post_type_object->show_ui ) || in_array( $post_type, [ 'attachment', 'revision', 'nav_menu_item' ], true ) ) {
            return new \WP_Error( 'content_import_bad_post_type', 'That post type cannot receive Content Studio imports.' );
        }
        $create_capability = isset( $post_type_object->cap->create_posts ) ? $post_type_object->cap->create_posts : 'edit_posts';
        if ( ! current_user_can( $create_capability ) ) {
            return new \WP_Error( 'content_import_forbidden_post_type', 'You cannot create content for the selected post type.' );
        }

        $allowed_statuses = [ 'publish', 'draft', 'pending', 'private' ];
        $default_status = sanitize_key( (string) ( $options_input['status'] ?? 'draft' ) );
        if ( ! in_array( $default_status, $allowed_statuses, true ) ) {
            $default_status = 'draft';
        }
        $default_author = absint( $options_input['author'] ?? get_current_user_id() );
        if ( ! $default_author || ! get_user_by( 'id', $default_author ) ) {
            $default_author = get_current_user_id();
        }
        $options = [
            'post_type'       => $post_type,
            'status'          => $default_status,
            'author'          => $default_author,
            'match_slug'      => rest_sanitize_boolean( $options_input['match_slug'] ?? true ),
            'import_media'    => rest_sanitize_boolean( $options_input['import_media'] ?? false ),
            'update_existing' => rest_sanitize_boolean( $options_input['update_existing'] ?? false ),
        ];

        $prepared_rows = [];
        $seen_slugs = [];
        $summary = [ 'total' => count( $rows ), 'create' => 0, 'update' => 0, 'skip' => 0, 'invalid' => 0, 'remote_images' => 0 ];
        foreach ( $rows as $index => $raw_row ) {
            if ( ! is_array( $raw_row ) ) {
                $raw_row = [];
            }
            $row = [];
            foreach ( $mapping as $column => $field ) {
                if ( ! array_key_exists( $column, $raw_row ) ) {
                    continue;
                }
                $value = $raw_row[ $column ];
                if ( is_scalar( $value ) || null === $value ) {
                    $row[ $column ] = substr( wp_check_invalid_utf8( (string) $value ), 0, 1000000 );
                }
            }

            $title = sanitize_text_field( $this->studio_content_import_value( $row, $mapping, 'title' ) );
            $content = wp_kses_post( $this->studio_content_import_value( $row, $mapping, 'content' ) );
            $excerpt = sanitize_textarea_field( $this->studio_content_import_value( $row, $mapping, 'excerpt' ) );
            $slug_input = $this->studio_content_import_value( $row, $mapping, 'slug' );
            $slug = sanitize_title( '' !== $slug_input ? $slug_input : $title );
            $row_status = sanitize_key( $this->studio_content_import_value( $row, $mapping, 'status' ) );
            $status = in_array( $row_status, $allowed_statuses, true ) ? $row_status : $default_status;
            $author = $this->studio_content_import_author( $this->studio_content_import_value( $row, $mapping, 'author' ), $default_author );
            $date_input = sanitize_text_field( $this->studio_content_import_value( $row, $mapping, 'date' ) );
            $date = '';
            if ( '' !== $date_input ) {
                $timestamp = strtotime( $date_input );
                if ( false !== $timestamp ) {
                    $date = wp_date( 'Y-m-d H:i:s', $timestamp );
                }
            }
            $categories = $this->studio_content_import_terms( $this->studio_content_import_value( $row, $mapping, 'categories' ) );
            $tags = $this->studio_content_import_terms( $this->studio_content_import_value( $row, $mapping, 'tags' ) );
            $featured_image_url = esc_url_raw( $this->studio_content_import_value( $row, $mapping, 'featured_image_url' ) );
            $custom_fields = [];
            $media_fields  = [];
            foreach ( $mapping as $column => $field ) {
                if ( ! isset( $row[ $column ] ) ) {
                    continue;
                }
                // R43. The column's name only when nothing else was chosen.
                $kind     = $this->studio_import_destination( $field )['kind'];
                $meta_key = $this->studio_import_meta_key( $field, $column );
                if ( '' === $meta_key || '_' === substr( $meta_key, 0, 1 ) ) {
                    continue;
                }
                if ( 'custom' === $kind ) {
                    $custom_fields[ $meta_key ] = sanitize_textarea_field( (string) $row[ $column ] );
                    continue;
                }
                // R27: one download per mapped media column, per row.
                if ( 'media_id' === $kind ) {
                    $media_url = esc_url_raw( trim( (string) $row[ $column ] ) );
                    if ( '' !== $media_url ) {
                        $media_fields[ $meta_key ] = $media_url;
                    }
                }
            }

            $existing = null;
            if ( $options['match_slug'] && '' !== $slug ) {
                $existing = get_page_by_path( $slug, OBJECT, $post_type );
            }
            $duplicate_source_slug = $options['match_slug'] && '' !== $slug && isset( $seen_slugs[ $slug ] );
            $action = 'create';
            $reason = 'Create ' . $status;
            if ( '' === $title ) {
                $action = 'invalid';
                $reason = 'Title is required';
            } elseif ( $duplicate_source_slug ) {
                $action = 'skip';
                $reason = 'Duplicate slug in source file';
            } elseif ( $existing && $options['update_existing'] && ! current_user_can( 'edit_post', $existing->ID ) ) {
                $action = 'invalid';
                $reason = 'You cannot update the matching content';
            } elseif ( $existing && $options['update_existing'] ) {
                $action = 'update';
                $reason = 'Update existing ' . $post_type;
            } elseif ( $existing ) {
                $action = 'skip';
                $reason = 'Slug already exists';
            }
            if ( '' !== $title && $options['match_slug'] && '' !== $slug ) {
                $seen_slugs[ $slug ] = true;
            }
            $summary[ $action ]++;
            $row_downloads = ( '' !== $featured_image_url ? 1 : 0 ) + count( $media_fields );
            $summary['remote_images'] += $row_downloads;

            $prepared_rows[] = [
                'source_index'       => $index,
                'title'              => $title ?: 'Untitled row ' . ( $index + 1 ),
                'slug'               => $slug,
                'action'             => $action,
                'reason'             => $reason,
                'status'             => $status,
                'existing_id'        => $existing ? (int) $existing->ID : 0,
                'categories_count'   => count( $categories ),
                'tags_count'         => count( $tags ),
                'remote_images'      => $row_downloads,
                'post'               => [
                    'post_type'        => $post_type,
                    'post_title'       => $title,
                    'post_name'        => $slug,
                    'post_content'     => $content,
                    'post_excerpt'     => $excerpt,
                    'post_status'      => $status,
                    'post_author'      => $author,
                    'post_date'        => $date,
                    'categories'       => $categories,
                    'tags'             => $tags,
                    'featured_image_url' => $featured_image_url,
                    'custom_fields'    => $custom_fields,
                    'media_fields'     => $media_fields,
                ],
            ];
        }

        $ready = $summary['create'] + $summary['update'];
        if ( $summary['remote_images'] > 100 ) {
            return new \WP_Error( 'content_import_media_limit', 'A single content import can download up to 100 mapped images.' );
        }
        $plural = sanitize_text_field( (string) ( $post_type_object->labels->name ?? $post_type ) );
        $confirmation = 'IMPORT ' . $ready . ' ' . strtoupper( $plural ?: $post_type );
        /* R27. Carried through rather than read straight off the request in
           the creator: everything else the import acts on comes out of here
           sanitised, and one value taking a different route is how the two come
           to disagree about what was asked for. Unknown types are dropped here,
           so the creator can trust what it is handed. */
        $field_types = [];
        foreach ( (array) ( $params['field_types'] ?? [] ) as $column => $type ) {
            $type = sanitize_key( (string) $type );
            if ( '' !== $type && 'auto' !== $type && $this->studio_field_type_exists( $type ) ) {
                $field_types[ (string) $column ] = $type;
            }
        }

        return [
            'rows'         => $prepared_rows,
            'summary'      => $summary,
            'mapping'      => $mapping,
            'options'      => $options,
            'field_types'  => $field_types,
            'confirmation' => $confirmation,
            'label'        => $plural,
        ];
    }

    public function preview_studio_content_import( \WP_REST_Request $request ): \WP_REST_Response {
        $prepared = $this->prepare_studio_content_import( $request->get_json_params() ?: [] );
        if ( is_wp_error( $prepared ) ) {
            return new \WP_REST_Response( [ 'code' => $prepared->get_error_code(), 'message' => $prepared->get_error_message() ], 400 );
        }
        $rows = array_map( static function( $row ) {
            unset( $row['post'] );
            return $row;
        }, $prepared['rows'] );
        return new \WP_REST_Response( [
            'success'      => true,
            'rows'         => $rows,
            'summary'      => $prepared['summary'],
            'confirmation' => $prepared['confirmation'],
            'label'        => $prepared['label'],
        ], 200 );
    }

    /** The featured image is one media column with one extra step. */
    private function studio_content_import_featured_image( string $url, int $post_id ) {
        $attachment_id = $this->studio_content_import_media( $url, $post_id, true );
        if ( is_wp_error( $attachment_id ) || ! $attachment_id ) {
            return $attachment_id;
        }
        set_post_thumbnail( $post_id, (int) $attachment_id );
        return (int) $attachment_id;
    }

    /**
     * Bring one URL into the media library and attach it to the post.
     *
     * R27. This was image-only and always the featured image, which is both of
     * the limitations the owner sent: an ACF File field could not be filled with
     * an audio attachment, and there was no way to get an attachment ID into a
     * field at all. `$image_only` keeps the featured-image column strict - a
     * featured image that is a PDF is a mistake, not a feature - while a mapped
     * media column takes whatever this site already allows to be uploaded.
     *
     * @param bool $image_only Refuse anything that is not an image.
     * @return int|\WP_Error Attachment id, 0 for an empty URL, or the reason.
     */
    /**
     * R27 - "posts, with images in it."
     *
     * Only the featured image and the mapped media columns were ever
     * downloaded. An `<img>` inside the body kept pointing at whichever site
     * the CSV came from, so the post looked right on the day it was imported
     * and broke whenever that other site did.
     *
     * Every distinct remote src in the body is fetched once and the body
     * rewritten to the local copy. A src that cannot be fetched is left exactly
     * as it was and reported as a warning rather than failing the row: a post
     * with one external image is better than no post, and far better than a
     * post with a broken one.
     *
     * @param array $completed Counters, by reference - the same ones the
     *                         featured image and media columns report into.
     * @param array $warnings  Row warnings, by reference.
     */
    private function studio_content_import_inline_images( string $html, int $post_id, array &$completed, array &$warnings ): string {
        if ( false === stripos( $html, '<img' ) ) {
            return $html;
        }
        if ( ! preg_match_all( '/<img\\b[^>]*?\\bsrc=("|\')(.*?)\\1/i', $html, $matches ) ) {
            return $html;
        }

        $home = (string) home_url();
        $seen = [];
        $done = 0;

        foreach ( $matches[2] as $raw ) {
            $url = trim( (string) html_entity_decode( $raw, ENT_QUOTES ) );
            if ( '' === $url || isset( $seen[ $url ] ) ) {
                continue;
            }
            $seen[ $url ] = true;

            // A data: URI is already in the post, and a relative path is
            // already this site's. Neither is something to go and fetch.
            if ( ! preg_match( '#^https?://#i', $url ) ) {
                continue;
            }
            if ( '' !== $home && 0 === strpos( $url, $home ) ) {
                continue;
            }

            /* One row should not be able to spend the whole request
               downloading. Twenty is past any honest article. */
            if ( $done >= 20 ) {
                $warnings[] = 'More than 20 images in the body; the rest were left pointing at their original addresses.';
                break;
            }

            $attachment_id = $this->studio_content_import_media( $url, $post_id, true );
            if ( is_wp_error( $attachment_id ) || ! $attachment_id ) {
                $completed['image_warnings']++;
                $warnings[] = is_wp_error( $attachment_id )
                    ? $attachment_id->get_error_message()
                    : ( 'Could not fetch the image at ' . $url );
                continue;
            }

            $local = wp_get_attachment_url( (int) $attachment_id );
            if ( ! $local ) {
                continue;
            }
            $html = str_replace( $raw, esc_url( $local ), $html );
            $completed['images_imported']++;
            $done++;
        }

        return $html;
    }

    /**
     * R27 - "I also want to be able to create fields either ACF or whatever
     * during import if they do not exists. and i mean the correct field types."
     *
     * The type has to come from the column's VALUES, never from its name. A
     * column called `photo` holding sentences is a Textarea; a column called
     * `ref` holding image URLs is an Image. Getting it wrong is worse than not
     * doing it at all: a Text field holding an image URL looks right in the CSV
     * and is useless in a template, and nobody finds out until they build one.
     *
     * The order below is the whole design. Most specific first, and each rule
     * requires EVERY non-empty value to match - one row that disagrees drops it
     * to something that can hold both.
     *
     * @param array $values The column's values across the sampled rows.
     * @return array{type:string,choices:array}
     */
    /**
     * R27 - "a new acf group or one already available, I should be able to
     * choose. Jet engine matters."
     *
     * So both engines, and both destinations. What comes back is what the
     * mapping screen offers: which engines are here, and the groups each one
     * already has.
     */
    public function get_studio_import_field_targets(): \WP_REST_Response {
        /* R27. The panel offers what this returns, and `studio_field_types()`
           is the same list the importer checks against on the way back in. */
        $types = [];
        foreach ( $this->studio_field_types() as $value => $label ) {
            $types[] = [ 'value' => $value, 'label' => $label ];
        }

        $acf_groups = [];
        if ( $this->acf_available() ) {
            foreach ( (array) acf_get_field_groups() as $group ) {
                if ( ! is_array( $group ) || empty( $group['key'] ) ) {
                    continue;
                }
                $acf_groups[] = [
                    'key'   => (string) $group['key'],
                    'title' => (string) ( $group['title'] ?? $group['key'] ),
                ];
            }
        }

        $jet_groups = [];
        if ( $this->jet_meta_boxes_available() ) {
            foreach ( $this->jet_meta_boxes() as $box ) {
                $jet_groups[] = [
                    'key'   => (string) ( $box['id'] ?? '' ),
                    'title' => (string) ( $box['name'] ?? $box['id'] ?? '' ),
                ];
            }
        }

        /* R43. The fields that already exist, so a column can be pointed at one
           instead of only ever making a new one named after itself. Sent from
           here because the panel is already asking this route what a field can
           be; a second route would be a second answer to keep in step. */
        $fields = [];
        $seen   = [];
        foreach ( [ 'acf', 'jet' ] as $engine ) {
            foreach ( $this->studio_existing_fields( $engine ) as $field ) {
                if ( '_' === substr( $field['key'], 0, 1 ) ) {
                    continue;
                }
                /* One entry per key, but a key used by two groups belongs to
                   both groups' post types - dropping the second group's would
                   make the file's post type guess blind to it. */
                if ( isset( $seen[ $field['key'] ] ) ) {
                    $at = $seen[ $field['key'] ];
                    $fields[ $at ]['post_types'] = array_values( array_unique( array_merge(
                        (array) ( $fields[ $at ]['post_types'] ?? [] ), (array) ( $field['post_types'] ?? [] ) ) ) );
                    continue;
                }
                $seen[ $field['key'] ] = count( $fields );
                $fields[] = $field;
            }
        }
        usort( $fields, static function ( $a, $b ) {
            return strcasecmp( $a['label'] . $a['key'], $b['label'] . $b['key'] );
        } );

        return new \WP_REST_Response( [
            'engines' => [
                'acf' => [ 'available' => $this->acf_available(), 'groups' => $acf_groups ],
                'jet' => [ 'available' => $this->jet_meta_boxes_available(), 'groups' => $jet_groups ],
            ],
            'types'   => $types,
            'fields'  => $fields,
        ], 200 );
    }

    private function jet_meta_boxes_available(): bool {
        return function_exists( 'jet_engine' ) && isset( jet_engine()->meta_boxes );
    }

    /** JetEngine's meta boxes, however this version of it stores them. */
    private function jet_meta_boxes(): array {
        if ( ! $this->jet_meta_boxes_available() ) {
            return [];
        }
        $boxes = [];
        try {
            if ( method_exists( jet_engine()->meta_boxes, 'get_meta_boxes' ) ) {
                $boxes = (array) jet_engine()->meta_boxes->get_meta_boxes();
            } elseif ( isset( jet_engine()->meta_boxes->data )
                && method_exists( jet_engine()->meta_boxes->data, 'get_items' ) ) {
                $boxes = (array) jet_engine()->meta_boxes->data->get_items();
            }
        } catch ( \Throwable $e ) {
            return [];
        }
        return array_values( array_filter( array_map( static function ( $b ) {
            $b = (array) $b;
            return [ 'id' => (string) ( $b['id'] ?? '' ), 'name' => (string) ( $b['name'] ?? '' ),
                     'raw' => $b ];
        }, $boxes ), static function ( $b ) { return '' !== $b['id']; } ) );
    }

    /**
     * Create one field, in whichever engine was chosen, in a group that either
     * already exists or is made now.
     *
     * Returns a WP_Error rather than throwing: a field that could not be made
     * must never fail the import. The row is already correct without it, and
     * the value is in post meta either way - a missing field definition means
     * the value is not shown in the editor, not that it was lost.
     */
    /**
     * Every column mapped as a custom field, given a real field definition.
     *
     * The type comes from that column's own values across the rows being
     * imported - see studio_infer_field_type() - and a column that already has
     * a field is left alone rather than rewritten: somebody may have set it up
     * deliberately, and a "correct type" guessed from a sample has no business
     * overruling that.
     */
    private function studio_import_create_mapped_fields( array $prepared, array &$warnings ): array {
        $options = (array) ( $prepared['options'] ?? [] );
        $mapping = (array) ( $prepared['mapping'] ?? [] );
        $rows    = (array) ( $prepared['rows'] ?? [] );
        $engine  = 'jet' === ( $options['field_engine'] ?? '' ) ? 'jet' : 'acf';
        $group   = (string) ( $options['field_group'] ?? '' );
        $title   = (string) ( $options['field_group_title'] ?? '' );

        $existing = $this->studio_existing_field_keys( $engine );
        $types    = (array) ( $prepared['field_types'] ?? [] );
        $made     = [];

        foreach ( $mapping as $column => $field ) {
            $kind = $this->studio_import_destination( $field )['kind'];
            if ( 'custom' !== $kind && 'media_id' !== $kind ) {
                continue;
            }
            /* R43. The chosen key, not the column's. `isset( $existing )` then
               does the rest of the work on its own: pointing a column at a field
               that already exists is exactly the case where nothing should be
               created, and that is the same line that has always said so. */
            $meta_key = $this->studio_import_meta_key( $field, (string) $column );
            if ( '' === $meta_key || isset( $existing[ $meta_key ] ) ) {
                continue;
            }

            $values = [];
            foreach ( $rows as $row ) {
                if ( isset( $row[ $column ] ) ) {
                    $values[] = $row[ $column ];
                }
            }

            $guess = $this->studio_import_field_guess( $kind, $values );

            // R27. One named decision, so it can be driven on its own.
            $guess = $this->studio_field_type_decision( $guess, $types[ $column ] ?? '' );

            $result = $this->studio_import_create_field( [
                'engine'      => $engine,
                'group'       => $group,
                'group_title' => $title,
                'meta_key'    => $meta_key,
                'label'       => ucwords( str_replace( [ '_', '-' ], ' ', $meta_key ) ),
                'type'        => $guess['type'],
                'choices'     => $guess['choices'],
            ] );

            if ( is_wp_error( $result ) ) {
                /* Never fatal. The value still lands in post meta; what is
                   missing is the definition that would show it in the editor. */
                $warnings[] = $meta_key . ': ' . $result->get_error_message();
                continue;
            }
            $made[] = $result;
            $existing[ $meta_key ] = true;
        }

        return $made;
    }

    /**
     * R43. The fields that already exist, with enough to put in a list a person
     * reads: the meta key, what it is called, what kind it is, and which group
     * it lives in.
     *
     * `studio_existing_field_keys()` now comes out of this rather than walking
     * the same structures again, so "does this key exist" and "what can I
     * choose" can never end up disagreeing about what is on the site.
     *
     * @return array<int,array{key:string,label:string,type:string,group:string,engine:string}>
     */
    public function studio_existing_fields( string $engine ): array {
        $out = [];

        if ( 'acf' === $engine && $this->acf_available() && function_exists( 'acf_get_fields' ) ) {
            foreach ( (array) acf_get_field_groups() as $group ) {
                $post_types = self::studio_acf_group_post_types( (array) ( $group['location'] ?? [] ) );
                foreach ( (array) acf_get_fields( $group ) as $field ) {
                    if ( empty( $field['name'] ) ) {
                        continue;
                    }
                    $out[] = [
                        'key'        => (string) $field['name'],
                        'label'      => (string) ( $field['label'] ?? $field['name'] ),
                        'type'       => (string) ( $field['type'] ?? 'text' ),
                        'group'      => (string) ( $group['title'] ?? '' ),
                        'engine'     => 'acf',
                        'post_types' => $post_types,
                    ];
                }
            }
            return $out;
        }

        if ( 'jet' === $engine ) {
            foreach ( $this->jet_meta_boxes() as $box ) {
                foreach ( (array) ( ( $box['raw'] ?? [] )['meta_fields'] ?? [] ) as $field ) {
                    if ( empty( $field['name'] ) ) {
                        continue;
                    }
                    $out[] = [
                        'key'        => (string) $field['name'],
                        'label'      => (string) ( $field['title'] ?? $field['name'] ),
                        'type'       => (string) ( $field['type'] ?? 'text' ),
                        'group'      => (string) ( $box['name'] ?? '' ),
                        'engine'     => 'jet',
                        'post_types' => array_values( array_filter( array_map( 'strval',
                            (array) ( ( ( $box['raw'] ?? [] )['args'] ?? [] )['allowed_post_type'] ?? [] ) ) ) ),
                    ];
                }
            }
        }

        return $out;
    }

    /**
     * R43. The post types an ACF group is shown on, read off its location rules.
     *
     * Only `post_type == x` is a claim about a type; a rule on a template, a
     * taxonomy or a user role says nothing about one, and `!=` says where the
     * group is NOT. An empty list means "the rules do not say" - which the
     * panel reads as no evidence either way, never as "every type".
     *
     * @return string[]
     */
    public static function studio_acf_group_post_types( array $location ): array {
        $types = [];
        foreach ( $location as $and ) {
            foreach ( (array) $and as $rule ) {
                $rule = (array) $rule;
                if ( 'post_type' === ( $rule['param'] ?? '' ) && '==' === ( $rule['operator'] ?? '' )
                    && '' !== (string) ( $rule['value'] ?? '' ) && 'all' !== ( $rule['value'] ?? '' ) ) {
                    $types[ (string) $rule['value'] ] = true;
                }
            }
        }
        return array_keys( $types );
    }

    /** Meta keys that already have a field in the chosen engine. */
    private function studio_existing_field_keys( string $engine ): array {
        $keys = [];
        foreach ( $this->studio_existing_fields( $engine ) as $field ) {
            $keys[ $field['key'] ] = true;
        }
        return $keys;
    }

    private function studio_import_create_field( array $spec ) {
        $engine = 'jet' === ( $spec['engine'] ?? '' ) ? 'jet' : 'acf';
        $key    = sanitize_key( (string) ( $spec['meta_key'] ?? '' ) );
        if ( '' === $key ) {
            return new \WP_Error( 've_field_no_key', 'A field needs a meta key.' );
        }
        $label   = (string) ( $spec['label'] ?? $key );
        $type    = (string) ( $spec['type'] ?? 'text' );
        $choices = (array) ( $spec['choices'] ?? [] );

        if ( 'acf' === $engine ) {
            if ( ! $this->acf_available() || ! function_exists( 'acf_update_field' ) ) {
                return new \WP_Error( 've_field_no_acf', 'ACF is not active on this site.' );
            }
            $group_key = (string) ( $spec['group'] ?? '' );
            if ( '' === $group_key || 'new' === $group_key ) {
                $group_key = $this->studio_import_create_acf_group( (string) ( $spec['group_title'] ?? 'Imported fields' ) );
                if ( is_wp_error( $group_key ) ) {
                    return $group_key;
                }
            }
            $field = [
                'key'    => 'field_' . substr( md5( $group_key . '|' . $key ), 0, 16 ),
                'label'  => $label,
                'name'   => $key,
                'type'   => $this->studio_acf_type_for( $type ),
                'parent' => $group_key,
            ];
            if ( 'select' === $field['type'] && $choices ) {
                $field['choices'] = array_combine( $choices, $choices );
            }
            if ( 'image' === $field['type'] || 'file' === $field['type'] ) {
                // MV stores the attachment ID, which is what these read.
                $field['return_format'] = 'id';
            }
            acf_update_field( $field );
            return [ 'engine' => 'acf', 'group' => $group_key, 'key' => $key, 'type' => $field['type'] ];
        }

        // JetEngine.
        if ( ! $this->jet_meta_boxes_available() ) {
            return new \WP_Error( 've_field_no_jet', 'JetEngine is not active on this site.' );
        }
        return $this->studio_import_create_jet_field( $spec, $key, $label, $type, $choices );
    }

    /** ACF's own type names, from MV's. */
    /**
     * The field types a person can pick, and what each one is for.
     *
     * One list, sent to the panel and checked on the way back, because two
     * lists is how a picker comes to offer something the importer refuses.
     *
     * @return array<string,string>
     */
    public function studio_field_types(): array {
        return [
            'text'        => 'Text',
            'textarea'    => 'Text area',
            'number'      => 'Number',
            'true_false'  => 'True / false',
            'date_picker' => 'Date',
            'url'         => 'URL',
            'email'       => 'Email',
            'select'      => 'Select',
            'image'       => 'Image',
            'file'        => 'File',
        ];
    }

    /**
     * R43, 2026-09-16: "I'm unable to pick exact custom field or create a new one."
     *
     * A destination used to be one word and the meta key was always the column
     * heading. That is fine for a file you are importing into an empty site and
     * useless for one whose fields already exist - a column called
     * `why_this_matters` had no way of reaching a field called
     * `role_description`.
     *
     * So a destination is now `kind` or `kind:meta_key`. The bare form is
     * exactly what it was, which is why every mapping saved before this still
     * means what it meant.
     *
     * Parsed here rather than inline, because the same answer is needed in
     * three places - validating the mapping, writing the values, and deciding
     * whether a field has to be created - and three copies of a parser is how
     * an import writes to one key and creates another.
     *
     * @return array{kind:string,key:string}
     */
    public function studio_import_destination( $field ): array {
        $raw  = (string) $field;
        $at   = strpos( $raw, ':' );
        $kind = false === $at ? $raw : substr( $raw, 0, $at );
        $key  = false === $at ? '' : substr( $raw, $at + 1 );

        return [
            'kind' => sanitize_key( $kind ),
            // sanitize_key drops the colon, so the split has to come first.
            'key'  => sanitize_key( $key ),
        ];
    }

    /**
     * The meta key a column writes to: the one that was chosen, or the column's
     * own name when nothing was.
     *
     * A key beginning with an underscore is refused wherever this is used, the
     * way it always was - those are WordPress's own, and an import is not the
     * place to start writing them.
     */
    public function studio_import_meta_key( $field, string $column ): string {
        $dest = $this->studio_import_destination( $field );

        return '' !== $dest['key'] ? $dest['key'] : sanitize_key( $column );
    }

    /**
     * What kind of field a column looks like it wants.
     *
     * A media column is not guessed at: it was mapped as one, which already
     * says what it holds. Everything else is read off the values.
     *
     * Its own method for the same reason `studio_field_type_decision()` is -
     * a branch buried in a loop over rows is one nothing can drive, and this
     * one decides whether somebody's audio column comes out as an Image field
     * or as a line of text.
     */
    public function studio_import_field_guess( string $kind, array $values ): array {
        if ( 'media_id' === $kind ) {
            return [ 'type' => 'image', 'choices' => [] ];
        }
        return $this->studio_infer_field_type( $values );
    }

    private function studio_field_type_exists( string $type ): bool {
        return isset( $this->studio_field_types()[ $type ] );
    }

    /**
     * R27, 2026-09-16: "why wasn't I able to choose the kind of custom field?"
     *
     * Because nothing offered. Inferring from the column's own values is a good
     * default and a bad only-option - a column of 1s and 0s is a true/false OR a
     * number, and the file cannot say which. So a chosen type wins, and the
     * guess becomes what the picker starts on rather than what it settles.
     *
     * Its own method because it is the whole of the answer to that question,
     * and a decision buried in a loop over rows is one nothing can drive.
     *
     * `choices` survive whatever happens to `type`: a Select whose options were
     * read off the column is still the Select the person asked for, and dropping
     * them would make choosing the type worse than not choosing.
     *
     * @param array $guess  What the values suggested.
     * @param mixed $chosen What the person picked, if anything.
     * @return array
     */
    public function studio_field_type_decision( array $guess, $chosen ): array {
        $chosen = sanitize_key( (string) $chosen );

        if ( '' === $chosen || 'auto' === $chosen || ! $this->studio_field_type_exists( $chosen ) ) {
            return $guess;
        }
        $guess['type'] = $chosen;

        return $guess;
    }

    private function studio_acf_type_for( string $type ): string {
        $map = [
            'text' => 'text', 'textarea' => 'textarea', 'number' => 'number',
            'true_false' => 'true_false', 'date_picker' => 'date_picker',
            'url' => 'url', 'email' => 'email', 'image' => 'image',
            'file' => 'file', 'select' => 'select',
        ];
        return $map[ $type ] ?? 'text';
    }

    private function studio_import_create_acf_group( string $title ) {
        if ( ! function_exists( 'acf_update_field_group' ) ) {
            return new \WP_Error( 've_field_no_acf', 'ACF cannot create a group on this site.' );
        }
        $title = '' !== trim( $title ) ? trim( $title ) : 'Imported fields';
        $key   = 'group_' . substr( md5( 'mv-import|' . $title ), 0, 16 );
        acf_update_field_group( [
            'key'      => $key,
            'title'    => $title,
            'location' => [ [ [ 'param' => 'post_type', 'operator' => '==', 'value' => 'post' ] ] ],
        ] );
        return $key;
    }

    private function studio_import_create_jet_field( array $spec, string $key, string $label, string $type, array $choices ) {
        $map = [
            'text' => 'text', 'textarea' => 'textarea', 'number' => 'number',
            'true_false' => 'checkbox', 'date_picker' => 'date',
            'url' => 'text', 'email' => 'text', 'image' => 'media',
            'file' => 'media', 'select' => 'select',
        ];
        $jet_type = $map[ $type ] ?? 'text';

        $box_id = (string) ( $spec['group'] ?? '' );
        $boxes  = $this->jet_meta_boxes();
        $target = null;
        foreach ( $boxes as $b ) {
            if ( $b['id'] === $box_id ) {
                $target = $b;
                break;
            }
        }
        if ( ! $target ) {
            /* JetEngine's meta boxes are created through its own UI, and
               building one from here would mean writing its storage shape by
               hand - the one thing this whole feature is trying not to do. So
               MV says which box it needed rather than inventing one. */
            return new \WP_Error(
                've_field_no_jet_box',
                'Choose an existing JetEngine meta box for these fields, or use ACF to have MV create the group.'
            );
        }

        $raw    = (array) ( $target['raw'] ?? [] );
        $fields = isset( $raw['meta_fields'] ) ? (array) $raw['meta_fields'] : [];
        foreach ( $fields as $f ) {
            if ( isset( $f['name'] ) && (string) $f['name'] === $key ) {
                return [ 'engine' => 'jet', 'group' => $box_id, 'key' => $key, 'type' => $jet_type, 'existed' => true ];
            }
        }
        $new = [ 'type' => $jet_type, 'name' => $key, 'title' => $label ];
        if ( 'select' === $jet_type && $choices ) {
            $new['options'] = array_map( static function ( $c ) {
                return [ 'key' => $c, 'value' => $c ];
            }, $choices );
        }
        $fields[] = $new;
        $raw['meta_fields'] = $fields;

        try {
            if ( isset( jet_engine()->meta_boxes->data )
                && method_exists( jet_engine()->meta_boxes->data, 'update_item' ) ) {
                jet_engine()->meta_boxes->data->update_item( $raw );
            } else {
                return new \WP_Error( 've_field_jet_unsupported',
                    'This version of JetEngine does not let MV add a field to a meta box.' );
            }
        } catch ( \Throwable $e ) {
            return new \WP_Error( 've_field_jet_failed', $e->getMessage() );
        }

        return [ 'engine' => 'jet', 'group' => $box_id, 'key' => $key, 'type' => $jet_type ];
    }

    private function studio_infer_field_type( array $values ): array {
        $seen = [];
        foreach ( $values as $v ) {
            $v = is_scalar( $v ) ? trim( (string) $v ) : '';
            if ( '' !== $v ) {
                $seen[] = $v;
            }
        }
        if ( ! $seen ) {
            // Nothing to read. Text holds anything, which is the honest answer.
            return [ 'type' => 'text', 'choices' => [] ];
        }

        /* mbstring is not guaranteed. WordPress runs on hosts without it, and a
           bare mb_strlen() here would fatal the whole import on one of them -
           which is how this was found: the guard ran on a PHP build without it.
           Bytes over-count a multibyte string, which can only nudge the
           long-enough-to-be-a-textarea threshold, and never crashes. */
        $len = static function ( $v ): int {
            return function_exists( 'mb_strlen' ) ? mb_strlen( $v ) : strlen( $v );
        };

        $all = static function ( array $rows, callable $test ): bool {
            foreach ( $rows as $r ) {
                if ( ! $test( $r ) ) {
                    return false;
                }
            }
            return true;
        };

        $is_url = static function ( $v ) {
            return (bool) preg_match( '#^https?://\\S+$#i', $v );
        };
        $ext = static function ( $v ) {
            $path = (string) parse_url( $v, PHP_URL_PATH );
            return strtolower( (string) pathinfo( $path, PATHINFO_EXTENSION ) );
        };

        // A URL that is an image, every time.
        if ( $all( $seen, static function ( $v ) use ( $is_url, $ext ) {
            return $is_url( $v ) && in_array( $ext( $v ), [ 'jpg', 'jpeg', 'png', 'gif', 'webp', 'avif', 'svg' ], true );
        } ) ) {
            return [ 'type' => 'image', 'choices' => [] ];
        }

        // A URL that is some other file MV can sideload.
        if ( $all( $seen, static function ( $v ) use ( $is_url, $ext ) {
            return $is_url( $v ) && in_array( $ext( $v ), [ 'pdf', 'mp3', 'm4a', 'wav', 'ogg', 'mp4', 'mov', 'zip', 'doc', 'docx' ], true );
        } ) ) {
            return [ 'type' => 'file', 'choices' => [] ];
        }

        if ( $all( $seen, $is_url ) ) {
            return [ 'type' => 'url', 'choices' => [] ];
        }

        if ( $all( $seen, static function ( $v ) {
            return (bool) filter_var( $v, FILTER_VALIDATE_EMAIL );
        } ) ) {
            return [ 'type' => 'email', 'choices' => [] ];
        }

        /* True/false, but only when the column SAYS so. A column of 1s and 0s
           is a number as far as anybody can tell from here, and turning it into
           a checkbox would quietly destroy the difference between 0 and empty. */
        $words = [ 'yes', 'no', 'true', 'false', 'y', 'n' ];
        $lower = array_map( 'strtolower', $seen );
        if ( $all( $lower, static function ( $v ) use ( $words ) {
            return in_array( $v, $words, true ) || '1' === $v || '0' === $v;
        } ) && array_intersect( $lower, $words ) ) {
            return [ 'type' => 'true_false', 'choices' => [] ];
        }

        // A date, in a shape WordPress and ACF both read.
        if ( $all( $seen, static function ( $v ) {
            return (bool) preg_match( '/^\\d{4}-\\d{2}-\\d{2}( \\d{2}:\\d{2}(:\\d{2})?)?$/', $v )
                && false !== strtotime( $v );
        } ) ) {
            return [ 'type' => 'date_picker', 'choices' => [] ];
        }

        if ( $all( $seen, static function ( $v ) {
            return is_numeric( $v );
        } ) ) {
            return [ 'type' => 'number', 'choices' => [] ];
        }

        /* A short list of repeating values is a Select, and its choices are the
           values themselves. Two conditions, both needed: few enough distinct
           values to be a list, and enough repetition that they are a SET rather
           than simply a small sample. */
        $distinct = array_values( array_unique( $seen ) );
        $short    = $all( $distinct, static function ( $v ) use ( $len ) {
            return $len( $v ) <= 40 && false === strpos( $v, "\n" );
        } );
        if ( $short && count( $distinct ) <= 10 && count( $seen ) >= ( 2 * count( $distinct ) ) ) {
            return [ 'type' => 'select', 'choices' => $distinct ];
        }

        // Long, or with line breaks in it.
        foreach ( $seen as $v ) {
            if ( $len( $v ) > 120 || false !== strpos( $v, "\n" ) ) {
                return [ 'type' => 'textarea', 'choices' => [] ];
            }
        }

        return [ 'type' => 'text', 'choices' => [] ];
    }

    private function studio_content_import_media( string $url, int $post_id, bool $image_only = true ) {
        if ( '' === $url ) {
            return 0;
        }
        // Already here: reuse it rather than downloading a second copy.
        $existing_id = attachment_url_to_postid( $url );
        if ( $existing_id ) {
            return (int) $existing_id;
        }
        $validated = $this->validate_media_import_url( $url );
        if ( is_wp_error( $validated ) ) {
            return $validated;
        }
        $validated_url = (string) ( $validated['url'] ?? '' );
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/media.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';
        $tmp_file = $this->download_media_import_url( $validated_url, 20 * 1024 * 1024, 30 );
        if ( is_wp_error( $tmp_file ) ) {
            return $tmp_file;
        }
        if ( ! file_exists( $tmp_file ) || filesize( $tmp_file ) > 20 * 1024 * 1024 ) {
            @unlink( $tmp_file );
            return new \WP_Error( 'content_import_media_too_large', 'A mapped image exceeds the 20 MB import limit.' );
        }
        $filename = $this->media_import_filename_from_url( $validated_url );
        $filetype = wp_check_filetype_and_ext( $tmp_file, $filename );
        /* The type is sniffed from the FILE, not taken from the URL, so a .jpg
           that is really a script is refused either way. What changes with
           $image_only is only how narrow "allowed" is: images for the featured
           image column, and whatever this site accepts for a media column -
           which is the WordPress upload policy, not a list of MV's own. */
        if ( empty( $filetype['type'] ) ) {
            @unlink( $tmp_file );
            return new \WP_Error( 'content_import_media_type', 'A mapped media URL is a file type this site does not allow.' );
        }
        if ( $image_only && 0 !== strpos( $filetype['type'], 'image/' ) ) {
            @unlink( $tmp_file );
            return new \WP_Error( 'content_import_media_type', 'A mapped media URL is not an allowed image.' );
        }
        if ( ! $image_only && ! in_array( $filetype['type'], array_values( get_allowed_mime_types() ), true ) ) {
            @unlink( $tmp_file );
            return new \WP_Error( 'content_import_media_type', 'A mapped media URL is a file type this site does not allow.' );
        }
        if ( ! pathinfo( $filename, PATHINFO_EXTENSION ) && ! empty( $filetype['ext'] ) ) {
            $filename .= '.' . $filetype['ext'];
        }
        $attachment_id = media_handle_sideload( [ 'name' => $filename, 'tmp_name' => $tmp_file ], $post_id );
        if ( is_wp_error( $attachment_id ) ) {
            @unlink( $tmp_file );
            return $attachment_id;
        }
        // Attached to the post, and nothing more: whether it becomes the featured
        // image or the value of a field is the caller's decision, not this one's.
        return (int) $attachment_id;
    }

    public function apply_studio_content_import( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $prepared = $this->prepare_studio_content_import( $params );
        if ( is_wp_error( $prepared ) ) {
            return new \WP_REST_Response( [ 'code' => $prepared->get_error_code(), 'message' => $prepared->get_error_message() ], 400 );
        }
        $confirmation = sanitize_text_field( (string) ( $params['confirmation'] ?? '' ) );
        if ( ! hash_equals( $prepared['confirmation'], $confirmation ) ) {
            return new \WP_REST_Response( [ 'code' => 'content_import_confirmation', 'message' => 'Type the exact confirmation phrase before running this import.' ], 400 );
        }

        $results = [];
        /* R27 - create the fields BEFORE the rows, once each.
           Per row it would be the same field written as many times as there are
           rows, and on a thousand-row import that is a thousand writes to ACF
           for a field that existed after the first one. */
        $created_fields = [];
        $field_warnings = [];
        if ( ! empty( $prepared['options']['create_fields'] ) ) {
            $created_fields = $this->studio_import_create_mapped_fields( $prepared, $field_warnings );
        }

        $completed = [ 'created' => 0, 'updated' => 0, 'skipped' => 0, 'failed' => 0, 'images_imported' => 0, 'image_warnings' => 0 ];
        foreach ( $prepared['rows'] as $row ) {
            if ( in_array( $row['action'], [ 'skip', 'invalid' ], true ) ) {
                $completed['skipped']++;
                $results[] = [ 'source_index' => $row['source_index'], 'title' => $row['title'], 'status' => $row['action'], 'message' => $row['reason'] ];
                continue;
            }
            $post_data = $row['post'];
            $categories = $post_data['categories'];
            $tags = $post_data['tags'];
            $featured_image_url = $post_data['featured_image_url'];
            $custom_fields = $post_data['custom_fields'];
            $media_fields  = isset( $post_data['media_fields'] ) && is_array( $post_data['media_fields'] ) ? $post_data['media_fields'] : [];
            unset( $post_data['categories'], $post_data['tags'], $post_data['featured_image_url'], $post_data['custom_fields'], $post_data['media_fields'] );
            if ( empty( $post_data['post_date'] ) ) {
                unset( $post_data['post_date'] );
            } else {
                $post_data['post_date_gmt'] = get_gmt_from_date( $post_data['post_date'] );
            }

            if ( 'update' === $row['action'] ) {
                $post_data['ID'] = $row['existing_id'];
                $post_id = wp_update_post( $post_data, true );
            } else {
                $post_id = wp_insert_post( $post_data, true );
            }
            if ( is_wp_error( $post_id ) || ! $post_id ) {
                $completed['failed']++;
                $message = is_wp_error( $post_id ) ? $post_id->get_error_message() : 'WordPress could not save this row.';
                $results[] = [ 'source_index' => $row['source_index'], 'title' => $row['title'], 'status' => 'failed', 'message' => $message ];
                continue;
            }

            if ( taxonomy_exists( 'category' ) && is_object_in_taxonomy( $prepared['options']['post_type'], 'category' ) && ! empty( $categories ) ) {
                wp_set_object_terms( $post_id, $categories, 'category', false );
            }
            if ( taxonomy_exists( 'post_tag' ) && is_object_in_taxonomy( $prepared['options']['post_type'], 'post_tag' ) && ! empty( $tags ) ) {
                wp_set_object_terms( $post_id, $tags, 'post_tag', false );
            }
            foreach ( array_slice( $custom_fields, 0, 50, true ) as $meta_key => $meta_value ) {
                update_post_meta( $post_id, $meta_key, $meta_value );
            }

            $warnings = [];
            if ( $prepared['options']['import_media'] && '' !== $featured_image_url ) {
                $attachment_id = $this->studio_content_import_featured_image( $featured_image_url, (int) $post_id );
                if ( is_wp_error( $attachment_id ) ) {
                    $completed['image_warnings']++;
                    $warnings[] = $attachment_id->get_error_message();
                } elseif ( $attachment_id ) {
                    $completed['images_imported']++;
                }
            }
            /* R27. Each mapped media column: sideload whatever the site allows,
               then store the ATTACHMENT ID under the column's own name. That is
               what an ACF Image or File field reads - the same column mapped as a
               custom field would store the URL as text, which ACF cannot use.
               A failure is a warning on the row, never a failed import: the post
               is already created and correct without its audio file. */
            /* Body images, once the post exists - the attachment is attached to
               it, and the rewritten body is saved back. */
            if ( $prepared['options']['import_media'] && ! empty( $post_data['post_content'] ) ) {
                $rewritten = $this->studio_content_import_inline_images(
                    (string) $post_data['post_content'], (int) $post_id, $completed, $warnings );
                if ( $rewritten !== $post_data['post_content'] ) {
                    wp_update_post( [ 'ID' => (int) $post_id, 'post_content' => $rewritten ] );
                }
            }
            if ( $prepared['options']['import_media'] && $media_fields ) {
                foreach ( $media_fields as $meta_key => $media_url ) {
                    $media_id = $this->studio_content_import_media( $media_url, (int) $post_id, false );
                    if ( is_wp_error( $media_id ) ) {
                        $completed['image_warnings']++;
                        $warnings[] = $meta_key . ': ' . $media_id->get_error_message();
                        continue;
                    }
                    if ( $media_id ) {
                        update_post_meta( $post_id, $meta_key, (int) $media_id );
                        $completed['images_imported']++;
                    }
                }
            }
            if ( 'update' === $row['action'] ) {
                $completed['updated']++;
            } else {
                $completed['created']++;
            }
            $results[] = [
                'source_index' => $row['source_index'],
                'title'        => $row['title'],
                'status'       => 'update' === $row['action'] ? 'updated' : 'created',
                'post_id'      => (int) $post_id,
                'warnings'     => $warnings,
            ];
        }

        $report_id = 'content-import-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 6, false, false );
        $reports = get_option( 've_content_studio_import_reports', [] );
        if ( ! is_array( $reports ) ) {
            $reports = [];
        }
        array_unshift( $reports, [
            'id'         => $report_id,
            'created_at' => gmdate( 'c' ),
            'user_id'    => get_current_user_id(),
            'file_name'  => sanitize_file_name( (string) ( $params['file_name'] ?? 'content-import.csv' ) ),
            'mapping'    => $prepared['mapping'],
            'options'    => $prepared['options'],
            'preview'    => $prepared['summary'],
            'completed'  => $completed,
            'results'    => array_slice( $results, 0, 250 ),
            'results_truncated' => count( $results ) > 250,
        ] );
        update_option( 've_content_studio_import_reports', array_slice( $reports, 0, 10 ), false );

        return new \WP_REST_Response( [
            'success'   => 0 === $completed['failed'],
            'report_id' => $report_id,
            'summary'   => $completed,
            /* R27 - say which fields were made and what type each came out as.
               "the correct field types" is the whole ask, and a number would not
               let anybody check it. */
            'fields_created'  => $created_fields,
            'field_warnings'  => $field_warnings,
            'results'   => $results,
        ], 200 );
    }

    /**
     * Id, title and parent for every post of a hierarchical type — nothing else,
     * because that is all a parent picker draws. Read straight from the posts
     * table: hydrating thousands of WP_Post objects to show a dropdown would cost
     * more than the whole editor.
     */
    public function list_studio_parent_options( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;

        $post_type = sanitize_key( (string) ( $request->get_param( 'post_type' ) ?: 'page' ) );
        $type_object = get_post_type_object( $post_type );
        if ( ! $type_object || ! $type_object->hierarchical ) {
            return new \WP_REST_Response( [ 'items' => [], 'truncated' => false ], 200 );
        }
        if ( ! current_user_can( $type_object->cap->edit_posts ) ) {
            return new \WP_REST_Response( [ 'items' => [], 'truncated' => false ], 200 );
        }

        // Enough that no real site hits it, small enough that a runaway table
        // cannot fill the response.
        $limit = 5000;
        $rows = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT ID, post_title, post_parent FROM {$wpdb->posts}
                 WHERE post_type = %s
                   AND post_status NOT IN ( 'trash', 'auto-draft', 'inherit' )
                 ORDER BY post_title ASC
                 LIMIT %d",
                $post_type,
                $limit + 1
            )
        );
        $truncated = is_array( $rows ) && count( $rows ) > $limit;
        if ( $truncated ) {
            array_pop( $rows );
        }

        $items = [];
        foreach ( (array) $rows as $row ) {
            if ( ! current_user_can( 'read_post', (int) $row->ID ) ) {
                continue;
            }
            $items[] = [
                'id'     => (int) $row->ID,
                'title'  => (string) $row->post_title,
                'parent' => (int) $row->post_parent,
            ];
        }

        return new \WP_REST_Response( [ 'items' => $items, 'truncated' => $truncated ], 200 );
    }

    public function list_studio_posts( \WP_REST_Request $request ): \WP_REST_Response {
        $post_type = sanitize_key( $request->get_param( 'post_type' ) ?: 'post' );
        $search = sanitize_text_field( $request->get_param( 'search' ) ?: '' );
        $status = sanitize_key( $request->get_param( 'status' ) ?: 'active' );
        $allowed_statuses = [ 'publish', 'future', 'draft', 'pending', 'private', 'trash' ];
        $post_status = [ 'publish', 'future', 'draft', 'pending', 'private', 'trash' ];
        if ( in_array( $status, $allowed_statuses, true ) ) {
            $post_status = [ $status ];
        }

        $args = [
            'post_type'      => $post_type,
            'posts_per_page' => 150,
            'post_status'    => $post_status,
            'perm'           => 'readable',
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ];

        $type_object = get_post_type_object( $post_type );
        $edit_others = $type_object && isset( $type_object->cap->edit_others_posts )
            ? (string) $type_object->cap->edit_others_posts
            : 'edit_others_posts';
        if ( ! current_user_can( $edit_others ) ) {
            $args['author'] = get_current_user_id();
        }

        if ( $search ) {
            $args['s'] = $search;
        }

        $query = new \WP_Query( $args );
        $posts = [];

        foreach ( $query->posts as $post ) {
            if ( ! current_user_can( 'read_post', (int) $post->ID ) ) {
                continue;
            }
            $posts[] = $this->studio_post_payload( $post );
        }

        return new \WP_REST_Response( $posts, 200 );
    }

    public function update_studio_option_page( \WP_REST_Request $request ): \WP_REST_Response {
        $id = sanitize_key( (string) $request->get_param( 'id' ) );
        $params = $request->get_json_params() ?: [];
        $fields = isset( $params['fields'] ) && is_array( $params['fields'] ) ? $params['fields'] : [];
        $post_id = sanitize_text_field( (string) ( $params['post_id'] ?? 'options' ) );
        if ( '' === $id || 0 !== strpos( $id, 'option-' ) ) {
            return new \WP_REST_Response( [ 'code' => 'invalid_option_page', 'message' => 'Invalid option page.' ], 400 );
        }
        if ( empty( $fields ) ) {
            return new \WP_REST_Response( [ 'success' => true, 'fields' => [] ], 200 );
        }
        foreach ( $fields as $field_name => $value ) {
            $name = sanitize_key( (string) $field_name );
            if ( '' === $name ) {
                continue;
            }
            $clean_value = $this->studio_meta_value_from_ui( $value );
            if ( is_string( $clean_value ) ) {
                $clean_value = wp_kses_post( $clean_value );
            }
            if ( function_exists( 'update_field' ) ) {
                update_field( $name, $clean_value, $post_id ?: 'options' );
            } else {
                update_option( 'options_' . $name, $clean_value, false );
            }
        }
        return new \WP_REST_Response( [ 'success' => true, 'fields' => $fields ], 200 );
    }

    /**
     * Normalise a client-supplied date into site-local 'Y-m-d H:i:s'.
     * Accepts 'Y-m-d' (assumes 09:00 local so a dragged post lands mid-morning,
     * not midnight) or a full 'Y-m-d H:i:s'. Returns '' when unparseable.
     */
    private function studio_normalize_local_datetime( $raw ): string {
        $value = trim( sanitize_text_field( (string) $raw ) );
        if ( '' === $value ) {
            return '';
        }
        if ( preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
            $value .= ' 09:00:00';
        }
        $ts = strtotime( $value );
        if ( ! $ts ) {
            return '';
        }
        return gmdate( 'Y-m-d H:i:s', $ts );
    }

    /**
     * Everything a studio save stores outside the posts table.
     *
     * It runs before the post's status is set, so that a transition to publish
     * happens with the SEO fields, custom fields and terms already in place —
     * Rank Math and anything else on save_post/transition_post_status read the
     * finished state rather than the previous one.
     */
    private function apply_studio_post_extras( int $post_id, array $params ): void {
        if ( array_key_exists( 'featured_media', $params ) ) {
            $featured_media = absint( $params['featured_media'] );
            if ( $featured_media ) {
                set_post_thumbnail( $post_id, $featured_media );
            } else {
                delete_post_thumbnail( $post_id );
            }
        }
        if ( array_key_exists( 'template', $params ) ) {
            update_post_meta( $post_id, '_wp_page_template', sanitize_text_field( (string) $params['template'] ) );
        }
        if ( isset( $params['custom_fields'] ) && is_array( $params['custom_fields'] ) ) {
            /* R29, 2026-09-09. "If I update acf/meta fields via the wp editor and
             * then I edit something else via the content studio, it deletes
             * everything on the acf fields on save."
             *
             * It did, and this is where. The editor is handed EVERY custom field,
             * flattened to a string - `studio_meta_value_for_ui()` turns a
             * repeater, a gallery, a relationship into pretty-printed JSON,
             * because a text box is all there was to show it in. Saving then
             * wrote every one of them back. So changing a title wrote a JSON
             * STRING over a repeater, and `update_field()` stored something ACF
             * cannot read back: the field reads as empty, and it looks deleted.
             *
             * A save may only write a field the person actually changed. What
             * they were given is regenerated here and compared: identical means
             * untouched, and an untouched field is never written. That is the
             * whole fix, and it holds for every field type including the ones MV
             * cannot render properly yet.
             *
             * The real repair is MV rendering ACF's own fields rather than
             * flattening them, which is the rest of R29. Until then, nothing MV
             * cannot represent can be destroyed by a save that never meant to
             * touch it. */
            $before = $this->studio_post_custom_fields( $post_id );
            foreach ( $params['custom_fields'] as $meta_key => $meta_value ) {
                $key = sanitize_key( (string) $meta_key );
                if ( '' === $key || 0 === strpos( $key, '_' ) ) {
                    continue;
                }
                /* C81: and never a key belonging to another plugin, whatever the
                   client sent. Not showing it was never the same as not writing
                   it - the panel hid `rank_math_schema_*` and posted it back
                   anyway, which is what killed the article. */
                if ( $this->is_plugin_owned_meta( $key ) ) {
                    continue;
                }
                if ( array_key_exists( $key, $before )
                    && is_scalar( $meta_value )
                    && (string) $meta_value === (string) $before[ $key ] ) {
                    continue;   // came back exactly as it went out: not an edit
                }
                $value = $this->studio_meta_value_from_ui( $meta_value );
                if ( is_string( $value ) ) {
                    $value = wp_kses_post( $value );
                }
                $updated = false;
                if ( function_exists( 'update_field' ) ) {
                    $updated = (bool) update_field( $key, $value, $post_id );
                }
                if ( ! $updated ) {
                    update_post_meta( $post_id, $key, $value );
                }
            }
        }
        if ( isset( $params['seo_details'] ) && is_array( $params['seo_details'] ) ) {
            $this->update_studio_rank_math_meta( $post_id, $params['seo_details'] );
        }
        if ( isset( $params['terms'] ) && is_array( $params['terms'] ) ) {
            $allowed_taxonomies = array_fill_keys( get_object_taxonomies( get_post_type( $post_id ), 'names' ), true );
            foreach ( $params['terms'] as $taxonomy => $term_ids ) {
                $taxonomy = sanitize_key( (string) $taxonomy );
                if ( ! isset( $allowed_taxonomies[ $taxonomy ] ) || 'post_format' === $taxonomy || ! is_array( $term_ids ) ) {
                    continue;
                }
                $clean_ids = array_values( array_unique( array_filter( array_map( 'absint', $term_ids ) ) ) );
                wp_set_object_terms( $post_id, $clean_ids, $taxonomy, false );
            }
        }
    }

    /** Everything Code Studio shows, plus what the panel needs to describe it. */
    public function code_studio_items( \WP_REST_Request $request ): \WP_REST_Response {
        $manager = new \VE\Core\CodeItemManager();
        return new \WP_REST_Response( [
            'items'        => $manager->all(),
            'languages'    => \VE\Core\CodeItemManager::LANGUAGES,
            'destinations' => \VE\Core\CodeItemManager::DESTINATIONS,
            /* Said out loud rather than implied: a stored PHP snippet does not
               run yet, and the panel has to be able to say so. */
            'executes'     => [ 'css' => true, 'php' => false, 'js' => false, 'html' => false ],
        ], 200 );
    }

    /**
     * Did the CSS this save was for actually reach the site?
     *
     * C73. `save()` compiled and threw the answer away, so a write that failed -
     * a read-only uploads directory, a full disk, a permissions change - left the
     * item saved in the database, the site still serving the OLD stylesheet, and
     * the panel saying "Saved". Saved and served are two different claims and the
     * response now makes both.
     */
    private function code_studio_compile_report( \VE\Core\CodeItemManager $manager ): array {
        $compile = $manager->last_compile();
        $failed  = (array) ( $compile['failed'] ?? [] );
        if ( ! $failed ) {
            return [ 'compiled' => true, 'compile_message' => '' ];
        }
        return [
            'compiled'        => false,
            'compile_message' => sprintf(
                'Saved, but the stylesheet could not be written (%s), so the site is still serving the previous CSS. Check that the uploads directory is writable.',
                implode( ', ', array_map( 'strval', $failed ) )
            ),
        ];
    }

    public function code_studio_create( \WP_REST_Request $request ): \WP_REST_Response {
        $params  = $request->get_json_params() ?: [];
        $manager = new \VE\Core\CodeItemManager();
        $item    = $manager->create( $params );
        return new \WP_REST_Response(
            [ 'success' => true, 'item' => $item ] + $this->code_studio_compile_report( $manager ),
            200
        );
    }

    public function code_studio_update( \WP_REST_Request $request ): \WP_REST_Response {
        $id      = sanitize_key( (string) $request->get_param( 'id' ) );
        $params  = $request->get_json_params() ?: [];
        $manager = new \VE\Core\CodeItemManager();
        $item    = $manager->update( $id, $params );
        if ( ! $item ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'No such item.' ], 404 );
        }
        return new \WP_REST_Response(
            [ 'success' => true, 'item' => $item, 'items' => $manager->all() ] + $this->code_studio_compile_report( $manager ),
            200
        );
    }

    public function code_studio_delete( \WP_REST_Request $request ): \WP_REST_Response {
        $id      = sanitize_key( (string) $request->get_param( 'id' ) );
        $manager = new \VE\Core\CodeItemManager();
        if ( ! $manager->delete( $id ) ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'No such item.' ], 404 );
        }
        return new \WP_REST_Response(
            [ 'success' => true, 'items' => $manager->all() ] + $this->code_studio_compile_report( $manager ),
            200
        );
    }

    /** Every version of one item, newest first, without the code. */
    public function code_studio_versions( \WP_REST_Request $request ): \WP_REST_Response {
        $id = (string) $request->get_param( 'id' );
        return new \WP_REST_Response( [ 'versions' => ( new \VE\Core\CodeItemManager() )->versions( $id ) ], 200 );
    }

    /** One version, code included, for the preview. */
    public function code_studio_version( \WP_REST_Request $request ) {
        $version = ( new \VE\Core\CodeItemManager() )->version( (int) $request->get_param( 'id' ) );
        if ( ! $version ) {
            return new \WP_Error( 've_code_version_missing', 'That version no longer exists.', [ 'status' => 404 ] );
        }
        return new \WP_REST_Response( $version, 200 );
    }

    /**
     * Put a version back.
     *
     * The manager records the current code first, so this is undoable by the
     * same panel that pressed it, and recompiles afterwards - a restore that
     * changed the stored item and left the old CSS on the site would be worse
     * than no restore at all.
     */
    public function code_studio_restore_version( \WP_REST_Request $request ) {
        $result = ( new \VE\Core\CodeItemManager() )->restore_version( (int) $request->get_param( 'id' ) );
        if ( empty( $result['restored'] ) ) {
            return new \WP_Error( 've_code_restore_failed', (string) ( $result['message'] ?? 'Restore failed.' ), [ 'status' => 404 ] );
        }
        return new \WP_REST_Response( $result, 200 );
    }
    public function code_studio_compile( \WP_REST_Request $request ): \WP_REST_Response {
        return new \WP_REST_Response( ( new \VE\Core\CodeItemManager() )->compile(), 200 );
    }

    /**
     * Every class on the site, and where its rule actually lives.
     *
     * `writable` is part of the answer rather than something the panel infers: a
     * rule on a Bricks global class can be edited from here, and a rule that only
     * exists inside one element own custom CSS cannot, because that lives in the
     * page element tree. Saying so in the payload is what stops the panel
     * offering a button that would quietly do nothing.
     */
    public function code_studio_classes( \WP_REST_Request $request ): \WP_REST_Response {
        /* R13. The list is kept for half an hour because building it reads and
           unserializes up to 800 Bricks element trees. Refresh in the panel asks
           for a fresh one, which is the only time that cost is paid on purpose. */
        $refresh = rest_sanitize_boolean( $request->get_param( 'refresh' ) );
        if ( $refresh ) {
            \VE\Core\ClassLensManager::forget();
        }
        $classes = $refresh ? false : get_transient( \VE\Core\ClassLensManager::LIST_KEY );
        $lens    = new \VE\Core\ClassLensManager();
        if ( ! is_array( $classes ) ) {
            $classes = $lens->classes();
            set_transient( \VE\Core\ClassLensManager::LIST_KEY, $classes, \VE\Core\ClassLensManager::LIST_LIFE );
        }
        $sheets  = [];
        foreach ( ( new \VE\Core\CodeItemManager() )->all() as $item ) {
            if ( 'css' === ( $item['language'] ?? '' ) ) {
                $sheets[] = [ 'id' => $item['id'], 'name' => $item['name'] ];
            }
        }
        return new \WP_REST_Response( [
            'classes'  => $classes,
            'sheets'   => $sheets,
            'writable' => [ 'bricks' => true, 'studio' => true, 'element' => false, 'none' => true ],
        ], 200 );
    }

    /**
     * Save a class rule where it already lives.
     *
     * A rule owned by Code Studio is saved into its stylesheet; a rule on a
     * Bricks global class is written back to that class. Nothing else is
     * writable, and asking to write one of those is a 400 rather than a silent
     * success - a save that reports OK and changes nothing is the worst answer
     * available.
     */
    public function code_studio_class_rule( \WP_REST_Request $request ) {
        $selector = (string) $request->get_param( 'selector' );
        $css      = (string) $request->get_param( 'css' );
        \VE\Core\ClassLensManager::forget();   // R13: MV's own write must not read stale
        $lens     = new \VE\Core\ClassLensManager();
        $entry    = $lens->find( $selector );
        if ( ! $entry ) {
            return new \WP_Error( 've_class_unknown', 'That class is not on this site.', [ 'status' => 404 ] );
        }

        if ( 'studio' === $entry['origin'] ) {
            $items = new \VE\Core\CodeItemManager();
            $item  = $items->find( (string) $entry['sheet_id'] );
            if ( ! $item ) {
                return new \WP_Error( 've_class_sheet_missing', 'That stylesheet is gone.', [ 'status' => 404 ] );
            }
            $items->update(
                (string) $item['id'],
                [ 'code' => $this->replace_class_rule( (string) $item['code'], (string) $entry['selector'], $css ) ]
            );
            return new \WP_REST_Response( [ 'saved' => 'studio', 'class' => $lens->find( $selector ) ], 200 );
        }

        if ( 'bricks' === $entry['origin'] || 'none' === $entry['origin'] ) {
            if ( ! $lens->save_to_bricks( $selector, $css ) ) {
                return new \WP_Error( 've_class_not_writable', 'That class has no Bricks record to save to.', [ 'status' => 400 ] );
            }
            // The builder, if it is open, is holding its own copy of this class
            // and will save the whole option back from memory. It gets the rule
            // in Bricks' own spelling so its next save carries the edit rather
            // than reverting it.
            \VE\Core\ClassLensManager::forget();
            return new \WP_REST_Response( [
                'saved'      => 'bricks',
                'class'      => $lens->find( $selector ),
                'bricks_css' => $lens->bricks_rule( $selector ),
            ], 200 );
        }

        return new \WP_Error(
            've_class_not_writable',
            'This rule lives inside one element custom CSS, which only the builder can change.',
            [ 'status' => 400 ]
        );
    }

    /**
     * Move a Bricks class rule into a Code Studio stylesheet.
     *
     * One way, and it clears the Bricks copy so the rule has one owner
     * afterwards. The same route serves a class nothing styles yet: there is
     * nothing to move, so it opens an empty rule instead.
     */
    public function code_studio_class_adopt( \WP_REST_Request $request ) {
        $selector = (string) $request->get_param( 'selector' );
        $item_id  = (string) $request->get_param( 'item_id' );
        \VE\Core\ClassLensManager::forget();   // R13: MV's own write must not read stale
        $lens     = new \VE\Core\ClassLensManager();
        $entry    = $lens->find( $selector );
        if ( ! $entry ) {
            return new \WP_Error( 've_class_unknown', 'That class is not on this site.', [ 'status' => 404 ] );
        }

        $item = 'bricks' === $entry['origin']
            ? $lens->adopt( $selector, $item_id )
            : $lens->start( $selector, $item_id );
        if ( ! $item ) {
            return new \WP_Error( 've_class_adopt_failed', 'That stylesheet cannot take this rule.', [ 'status' => 400 ] );
        }

        return new \WP_REST_Response( [
            'item'    => $item,
            'items'   => ( new \VE\Core\CodeItemManager() )->all(),
            'class'   => $lens->find( $selector ),
            'adopted' => 'bricks' === $entry['origin'],
        ], 200 );
    }

    /**
     * Replace one class rule inside a stylesheet, leaving the rest alone.
     *
     * The whole file is not rewritten from a parse tree, because a stylesheet is
     * somebody writing: comments, blank lines and ordering all survive, and only
     * the blocks whose selector starts with this class are swapped.
     */
    private function replace_class_rule( string $code, string $selector, string $css ): string {
        $name = ltrim( trim( $selector ), '.' );
        if ( '' === $name ) {
            return $code;
        }
        $written = false;
        $out = preg_replace_callback(
            '/([^{}]*)\{([^{}]*)\}/',
            static function ( $match ) use ( $name, $css, &$written ) {
                // Whatever sat in front of the selector - blank lines, a
                // comment explaining the rule - is the author writing, and it
                // stays. Reading it as part of the selector is what made a
                // commented rule invisible to this rewriter in the first place.
                $split    = \VE\Core\ClassLensManager::split_selector( $match[1] );
                $lead     = $split[0];
                $selector = $split[1];
                if ( \VE\Core\ClassLensManager::head_class( $selector ) !== $name ) {
                    return $match[0];
                }
                if ( $written ) {
                    return rtrim( $lead );
                }
                $written = true;
                return $lead . trim( $css );
            },
            $code
        );
        if ( ! $written ) {
            $out = rtrim( $code ) . ( '' === trim( $code ) ? '' : "\n\n" ) . trim( $css );
        }
        return $out;
    }

    /**
     * Who else has this post open, using WordPress's own post lock.
     *
     * `take` reports the holder if someone else has it and otherwise takes the
     * lock for this user; calling it again refreshes the timestamp, which is how
     * the lock stays alive while someone is actually typing. `release` clears
     * only this user's own lock - someone else's is not ours to drop.
     *
     * The lock is deliberately advisory. A lock that refused the save would
     * strand a post every time somebody closed a laptop without saving; the
     * refusal belongs on the conflict check in update_studio_post(), which
     * triggers on real divergence rather than on presence.
     */
    public function studio_post_lock( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $id     = absint( $params['id'] ?? 0 );
        $action = sanitize_key( $params['action'] ?? 'take' );
        $post   = $id ? get_post( $id ) : null;

        if ( ! $post ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'Post not found.' ], 404 );
        }
        if ( ! current_user_can( 'edit_post', $id ) ) {
            return new \WP_REST_Response( [ 'code' => 'forbidden', 'message' => 'You cannot edit this post.' ], 403 );
        }

        $lock_file = defined( 'ABSPATH' ) ? ABSPATH . 'wp-admin/includes/post.php' : '';
        if ( ! function_exists( 'wp_check_post_lock' ) && $lock_file && file_exists( $lock_file ) ) {
            require_once $lock_file;
        }

        $stored = (string) get_post_meta( $id, '_edit_lock', true );
        $parts  = $stored ? explode( ':', $stored ) : [];
        $since  = isset( $parts[0] ) ? absint( $parts[0] ) : 0;
        $owner  = isset( $parts[1] ) ? absint( $parts[1] ) : 0;

        if ( 'release' === $action ) {
            if ( $owner && $owner === get_current_user_id() ) {
                delete_post_meta( $id, '_edit_lock' );
            }
            return new \WP_REST_Response( [ 'success' => true, 'held_by' => null ], 200 );
        }

        $holder = function_exists( 'wp_check_post_lock' ) ? wp_check_post_lock( $id ) : false;
        if ( $holder ) {
            $user = get_userdata( $holder );
            return new \WP_REST_Response( [
                'success' => true,
                'mine'    => false,
                'held_by' => [
                    'id'    => (int) $holder,
                    'name'  => $user ? $user->display_name : 'Someone else',
                    'since' => $since,
                ],
            ], 200 );
        }

        if ( function_exists( 'wp_set_post_lock' ) ) {
            wp_set_post_lock( $id );
        } else {
            update_post_meta( $id, '_edit_lock', time() . ':' . get_current_user_id() );
        }
        return new \WP_REST_Response( [ 'success' => true, 'mine' => true, 'held_by' => null ], 200 );
    }

    /**
     * Turn the editor's HTML into WordPress block markup.
     *
     * Content Studio stored plain HTML, so the block editor wrapped the whole
     * post in a Classic block and asked to convert it before anything could be
     * edited - and an image inside that block is laid out by the theme rather
     * than by the editor, which is why it broke out of its column.
     *
     * The conversion is deliberately shallow: each top-level element becomes the
     * block WordPress would have produced for it, and anything unrecognised
     * becomes an HTML block, which renders exactly as written and stays editable.
     * Nothing is reordered, no attribute is dropped, and content that already
     * carries block delimiters is returned untouched.
     */
    /**
     * Strip the browser extension's own markup out of saved content.
     *
     * The owner's saved heading came back carrying
     * `class="PDq2pG_selectionAnchorContainer wp-block-heading"`. That class is
     * Grammarly's, not WordPress's and not MV's: the extension attaches itself to
     * the editor and writes its anchors into the live DOM, and whatever is in the
     * DOM is what gets saved. Harmless in one article, cumulative over a year of
     * them. Approved by the owner on 2026-09-05: "Yes, stript them on save."
     *
     * Deliberately narrow. It removes only markup that is unambiguously the
     * extension's - a named element, its own data attributes, and class tokens
     * carrying its signature - and never a class it cannot name. A broad rule
     * ("drop anything that looks hashed") would eat the owner's own utility
     * classes, and a strip that removes more than its target is worse than the
     * problem it was written for.
     */
    private function studio_strip_editor_extension_markup( string $html ): string {
        if ( '' === $html || false === strpos( $html, '<' ) ) {
            return $html;
        }

        // The extension's own elements, with whatever they wrap.
        $html = preg_replace( '#<grammarly-extension\b[^>]*>.*?</grammarly-extension>#is', '', $html );
        $html = preg_replace( '#<grammarly-extension\b[^>]*/?>#i', '', $html );

        // Its attributes: data-gramm, data-gramm_editor, data-enable-grammarly, data-gr-*.
        $html = preg_replace(
            '#\s+data-(?:gramm(?:_editor)?|enable-grammarly|gr-[a-z0-9_-]+)(?:=(?:"[^"]*"|\'[^\']*\'|[^\s>]*))?#i',
            '',
            $html
        );

        // Its class tokens. The attribute goes entirely when nothing else is left,
        // rather than leaving a bare class="" on every paragraph it touched.
        $html = preg_replace_callback(
            '#\sclass=("[^"]*"|\'[^\']*\')#i',
            static function ( $m ) {
                $quote = $m[1][0];
                $value = substr( $m[1], 1, -1 );
                $kept  = [];
                foreach ( preg_split( '#\s+#', $value, -1, PREG_SPLIT_NO_EMPTY ) as $token ) {
                    if ( preg_match( '#_selectionAnchorContainer$#', $token ) ) {
                        continue;
                    }
                    if ( preg_match( '#^_?grammarly#i', $token ) ) {
                        continue;
                    }
                    $kept[] = $token;
                }
                if ( ! $kept ) {
                    return '';
                }
                return ' class=' . $quote . implode( ' ', $kept ) . $quote;
            },
            $html
        );

        return $html;
    }

    private function studio_blocks_from_html( string $html ): string {
        $html = $this->studio_strip_editor_extension_markup( $html );
        $html = trim( $html );
        if ( '' === $html ) {
            return '';
        }
        // Already blocks - from the WordPress editor, or from an earlier save.
        // Converting again would nest delimiters and destroy the post, so the
        // only thing done here is repairing the two shapes MV itself used to
        // write wrongly. Everything else is returned exactly as it arrived.
        if ( false !== strpos( $html, '<!-- wp:' ) ) {
            return $this->studio_repair_blocks( $html );
        }
        if ( ! class_exists( '\DOMDocument' ) ) {
            return $html;
        }

        $dom      = new \DOMDocument();
        $previous = libxml_use_internal_errors( true );
        $loaded   = $dom->loadHTML(
            '<?xml encoding="utf-8"?><body>' . $html . '</body>',
            defined( 'LIBXML_HTML_NOIMPLIED' ) && defined( 'LIBXML_HTML_NODEFDTD' )
                ? LIBXML_HTML_NOIMPLIED | LIBXML_HTML_NODEFDTD
                : 0
        );
        libxml_clear_errors();
        libxml_use_internal_errors( $previous );
        if ( ! $loaded ) {
            return $html;
        }

        $body = $dom->getElementsByTagName( 'body' )->item( 0 );
        if ( ! $body ) {
            $body = $dom->documentElement;
        }
        if ( ! $body ) {
            return $html;
        }

        // Editor artefacts first, on the whole tree: a `data-start` left on a
        // paragraph is enough on its own to make the block refuse to validate.
        $this->studio_scrub_pasted( $body );

        $blocks = [];
        foreach ( iterator_to_array( $body->childNodes ) as $node ) {
            $block = $this->studio_block_for_node( $dom, $node );
            if ( '' !== $block ) {
                $blocks[] = $block;
            }
        }

        $out = implode( "\n\n", $blocks );
        return '' === trim( $out ) ? $html : $out;
    }

    /** One top-level node as one block, or '' for whitespace. */
    private function studio_block_for_node( \DOMDocument $dom, \DOMNode $node ): string {
        if ( XML_TEXT_NODE === $node->nodeType ) {
            $text = trim( $node->textContent );
            if ( '' === $text ) {
                return '';
            }
            // Loose text is a paragraph; that is what the editor would make of it.
            return $this->studio_block( 'paragraph', '<p>' . esc_html( $text ) . '</p>' );
        }
        if ( XML_ELEMENT_NODE !== $node->nodeType ) {
            return '';
        }

        $tag   = strtolower( $node->nodeName );
        $outer = trim( (string) $dom->saveHTML( $node ) );
        if ( '' === $outer ) {
            return '';
        }

        if ( 'p' === $tag ) {
            if ( '' === trim( $node->textContent ) && ! $node->getElementsByTagName( 'img' )->length ) {
                return '';
            }
            // Core writes a class on a paragraph only when the block records it
            // as `className`. A class with nothing behind it in the delimiter is
            // markup core would not have written, and the block is then invalid.
            return $this->studio_block(
                'paragraph',
                $outer,
                $this->studio_block_attrs(
                    $this->studio_class_name_attr( $node ) + $this->studio_anchor_attr( $node )
                )
            );
        }

        if ( preg_match( '/^h([1-6])$/', $tag, $level ) ) {
            $depth = (int) $level[1];
            // WordPress writes no level attribute for h2, its default.
            $attrs = 2 === $depth ? [] : [ 'level' => $depth ];
            // Core saves every heading with wp-block-heading. Markup core
            // would not have written is markup it can refuse to validate, and
            // any OTHER class on it has to be recorded as `className` for the
            // same reason.
            $attrs += $this->studio_class_name_attr( $node, [ 'wp-block-heading' ] ) + $this->studio_anchor_attr( $node );
            return $this->studio_block(
                'heading',
                $this->studio_with_class( $dom, $node, 'wp-block-heading' ),
                $this->studio_block_attrs( $attrs )
            );
        }

        if ( 'ul' === $tag || 'ol' === $tag ) {
            return $this->studio_list_block( $dom, $node, 'ol' === $tag );
        }

        if ( 'blockquote' === $tag ) {
            return $this->studio_quote_block( $dom, $node );
        }

        if ( 'pre' === $tag ) {
            return $this->studio_block( 'code', $this->studio_with_class( $dom, $node, 'wp-block-code' ) );
        }

        if ( 'hr' === $tag ) {
            return $this->studio_block( 'separator', '<hr class="wp-block-separator has-alpha-channel-opacity"/>' );
        }

        if ( 'table' === $tag ) {
            return $this->studio_block( 'table', '<figure class="wp-block-table">' . $outer . '</figure>' );
        }

        if ( 'figure' === $tag || 'img' === $tag ) {
            return $this->studio_image_block( $dom, $node, $tag );
        }

        // Anything else keeps working exactly as written, and stays editable.
        return $this->studio_block( 'html', $outer );
    }

    /**
     * Repair the invalid blocks MV wrote before v1.3.591.
     *
     * WordPress validates stored markup against what a block would have saved.
     * MV wrote quotes with bare paragraphs inside them and headings without the
     * class core gives them, so those posts open with "Attempt recovery" until
     * the markup is corrected. New saves are already correct; this is for the
     * posts already written.
     *
     * Narrow on purpose. A quote that already holds inner blocks is left alone,
     * a heading that already has its class is left alone, and nothing else in
     * the post is touched at all - reformatting blocks MV did not write would
     * be a worse bug than the one being fixed.
     */
    /**
     * A heading block that holds more than its heading, split apart.
     *
     * The owner's post carried this, and the editor's own verdict named it:
     *
     *     <h2 class="wp-block-heading">Rights Management</h2>
     *     <p><code><img src="...webp"></code></p>
     *
     * inside ONE `<!-- wp:heading -->`. Core's heading `save()` writes the
     * `<hN>` and nothing else, so it cannot reproduce that content from the
     * block's attributes and refuses the whole block: "Block contains
     * unexpected or invalid content".
     *
     * The converter has not written this shape for a long time - given that
     * same HTML it produces a heading block and a separate paragraph block -
     * but nothing ever repaired the posts already holding one, so every resave
     * handed it back unchanged. "I resaved this in content studio, but that's
     * still there."
     *
     * Whatever sits either side of the heading is run back through the
     * ordinary converter and takes its own block, so it is neither lost nor
     * given a shape invented here. A block with nothing but its heading, or
     * with no heading at all, is left exactly as it was.
     */
    private function studio_split_overfull_headings( string $html ): string {
        if ( false === stripos( $html, '<!-- wp:heading' ) ) {
            return $html;
        }

        return (string) preg_replace_callback(
            '/<!--\s*wp:heading(\s+\{[^}]*\})?\s*-->(.*?)<!--\s*\/wp:heading\s*-->/is',
            function ( $m ) {
                $attrs = isset( $m[1] ) ? rtrim( $m[1] ) : '';
                $inner = $m[2];

                if ( ! preg_match( '/<h([1-6])\b[^>]*>.*?<\/h\1>/is', $inner, $head, PREG_OFFSET_CAPTURE ) ) {
                    /* No heading element at all. If the block holds block-level
                       content - a <p>, a <div> - it is not obviously a heading, and
                       guessing would put words in the owner's mouth, so it is left.
                    
                       But a heading's content model is phrasing content: text and
                       inline elements. C132's last block was exactly that - level 1,
                       and a pasted <span style="..."> with no <h1> round it - so core
                       read its content as empty and refused the block. When inline text
                       is all there is, those words ARE the heading, and the delimiter
                       says which level; wrapping them restores the element the block
                       says it is. The level pass below then has a tag to read. */
                    $text = trim( $inner );
                    $block_level = '/<\/?(?:p|div|section|article|aside|header|footer|nav|figure|figcaption|blockquote|ul|ol|li|dl|table|pre|hr|form|h[1-6])\b/i';
                    if ( '' === trim( wp_strip_all_tags( $text ) ) || preg_match( $block_level, $text ) ) {
                        return $m[0];
                    }
                    $decoded = '' === $attrs ? [] : json_decode( trim( $attrs ), true );
                    $level   = ( is_array( $decoded ) && isset( $decoded['level'] ) )
                        ? max( 1, min( 6, (int) $decoded['level'] ) )
                        : 2;
                    return '<!-- wp:heading' . $attrs . ' -->' . "\n"
                        . '<h' . $level . ' class="wp-block-heading">' . $text . '</h' . $level . '>'
                        . "\n" . '<!-- /wp:heading -->';
                }

                $at     = $head[0][1];
                $only   = $head[0][0];
                $before = substr( $inner, 0, $at );
                $after  = substr( $inner, $at + strlen( $only ) );

                if ( '' === trim( $before ) && '' === trim( $after ) ) {
                    return $m[0];
                }

                $heading = '<!-- wp:heading' . $attrs . ' -->' . "\n" . $only . "\n" . '<!-- /wp:heading -->';
                $out     = [];
                if ( '' !== trim( $before ) ) {
                    $out[] = $this->studio_blocks_from_html( trim( $before ) );
                }
                $out[] = $heading;
                if ( '' !== trim( $after ) ) {
                    $out[] = $this->studio_blocks_from_html( trim( $after ) );
                }
                return implode( "\n\n", array_filter( $out, static function ( $piece ) {
                    return '' !== trim( (string) $piece );
                } ) );
            },
            $html
        );
    }

    private function studio_repair_blocks( string $html ): string {
        if ( '' === trim( $html ) ) {
            return $html;
        }

        /* First, because a heading block holding a paragraph is a block the
           editor refuses outright, and because whatever comes out of it
           should then go through the two repairs below like anything else. */
        $html = $this->studio_split_overfull_headings( $html );

        /* Headings, two repairs on one pass.
         *
         * The LEVEL first, because that is the one that makes the editor
         * say "Block contains unexpected or invalid content". Core's own
         * heading/block.json, read on a running WordPress:
         *
         *     "level": { "type": "number", "default": 2 }
         *
         * so a delimiter carrying no `level` regenerates as `<h2>`. Wrap an
         * `<h1>` in a bare `<!-- wp:heading -->` and core cannot reproduce
         * the markup from the attributes, and refuses the block. MV's own
         * writer has always recorded the level - this is for the posts
         * already carrying one, which otherwise stay broken through every
         * resave: "I resaved this in content studio, but that's still
         * there."
         *
         * The tag is believed rather than the delimiter: the saved HTML is
         * what the front end serves and what the author sees. So a
         * delimiter that DISAGREES with its tag is corrected too -
         * `{"level":3}` around an `<h1>` is refused by core exactly like a
         * missing level is, and leaving it alone leaves the post broken.
         * One that agrees is not touched at all.
         */
        $html = (string) preg_replace_callback(
            '/<!--\s*wp:heading(\s+\{[^}]*\})?\s*-->(\s*)<h([1-6])\b/i',
            static function ( $m ) {
                $json  = trim( (string) ( $m[1] ?? '' ) );
                $depth = (int) $m[3];
                $attrs = '' === $json ? [] : json_decode( $json, true );
                if ( ! is_array( $attrs ) ) {
                    return $m[0];
                }
                // What core would regenerate from these attributes.
                $stated = isset( $attrs['level'] ) ? (int) $attrs['level'] : 2;
                if ( $stated === $depth ) {
                    return $m[0];
                }
                // Added to what is already there rather than replacing it,
                // so a className or an anchor beside it survives. `level`
                // goes first, which is the order core writes them in.
                // `+`, not array_merge: for a duplicate key array_merge keeps the
                // RIGHT value, so a stale {"level":3} would survive being
                // corrected. `+` keeps the left one and puts it first, which is
                // also the order core writes them in.
                $attrs = [ 'level' => $depth ] + $attrs;
                return '<!-- wp:heading '
                    . wp_json_encode( $attrs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
                    . ' -->' . $m[2] . '<h' . $depth;
            },
            $html
        );

        // And the class: core saves every heading with wp-block-heading.
        // Only headings that are the whole of a heading block are touched,
        // and only when the class is absent.
        $html = (string) preg_replace_callback(
            '/(<!--\s*wp:heading[^>]*-->\s*)(<h([1-6])([^>]*)>)/i',
            static function ( $m ) {
                /* And `dir`, which core's heading block cannot hold - see
                   studio_scrub_pasted(). Stripped here for the posts already
                   stored with it, which otherwise keep the warning through
                   every resave. */
                $attrs = (string) preg_replace( '/\s+dir\s*=\s*(["\'])[^"\']*\1/i', '', $m[4] );
                if ( false !== stripos( $attrs, 'wp-block-heading' ) ) {
                    return $m[1] . '<h' . $m[3] . $attrs . '>';
                }
                if ( preg_match( '/class=(["\'])(.*?)\\1/i', $attrs, $has ) ) {
                    $replaced = str_replace(
                        $has[0],
                        'class=' . $has[1] . trim( $has[2] . ' wp-block-heading' ) . $has[1],
                        $attrs
                    );
                    return $m[1] . '<h' . $m[3] . $replaced . '>';
                }
                return $m[1] . '<h' . $m[3] . $attrs . ' class="wp-block-heading">';
            },
            $html
        );

        /* C132: "I resaved this in content studio, but that's still there."
         *
         * Correct, and it would not have been. dev.117 stopped MV WRITING
         * `size-full` over the size an image already had - it did nothing for
         * the posts already carrying it, and those posts arrive here with their
         * delimiters intact, so nothing else in this file touches them.
         *
         * This is the same repair the headings above get, for the same reason:
         * a fix that only helps content arriving now leaves every post already
         * written sitting there offering "Attempt Block Recovery".
         *
         * Narrow. Only an image block whose figure carries TWO size classes is
         * touched, which is a shape core never writes and MV only wrote by
         * accident. The slug in the delimiter is set to the size that is not
         * `full`, because `full` is the one MV added.
         */
        $html = (string) preg_replace_callback(
            '/<!--\s*wp:image([^>]*?)-->(\s*)<figure([^>]*?)class=(["\'])([^"\']*)\\4/i',
            static function ( $m ) {
                $classes = preg_split( '/\s+/', trim( $m[5] ) );
                $sizes   = array_values( array_filter( $classes, static function ( $c ) {
                    return (bool) preg_match( '/^size-[a-z0-9_-]+$/i', $c );
                } ) );
                if ( count( $sizes ) < 2 ) {
                    return $m[0];
                }
                // `full` is what MV added; whatever else is there is the real one.
                $real = null;
                foreach ( $sizes as $size ) {
                    if ( 'size-full' !== strtolower( $size ) ) {
                        $real = $size;
                        break;
                    }
                }
                if ( null === $real ) {
                    return $m[0];
                }
                $kept = [];
                foreach ( $classes as $c ) {
                    if ( preg_match( '/^size-[a-z0-9_-]+$/i', $c ) && strtolower( $c ) !== strtolower( $real ) ) {
                        continue;
                    }
                    $kept[] = $c;
                }
                $slug  = strtolower( substr( $real, 5 ) );
                $attrs = (string) preg_replace(
                    '/"sizeSlug"\s*:\s*"[^"]*"/',
                    '"sizeSlug":"' . $slug . '"',
                    $m[1]
                );
                return '<!-- wp:image' . $attrs . '-->' . $m[2]
                    . '<figure' . $m[3] . 'class=' . $m[4] . implode( ' ', $kept ) . $m[4];
            },
            $html
        );

        // Editor artefacts, on a post that was already saved carrying them. The
        // scrub on conversion only helps content arriving now; a post published
        // last week is still sitting there offering "Attempt Block Recovery".
        // Only tags are rewritten - a block delimiter is an HTML comment, and
        // the JSON inside it is not markup, so comments are skipped outright.
        $html = (string) preg_replace_callback(
            '/<(?!!)[^<>]*>/',
            static function ( $m ) {
                $tag = (string) preg_replace(
                    '/\s+data-[A-Za-z0-9_:.-]+\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+)/',
                    '',
                    $m[0]
                );
                $tag = (string) preg_replace( '/\s+(class|style)\s*=\s*("\s*"|\'\s*\')/', '', $tag );
                return (string) preg_replace( '/\s+(\/?)>$/', '$1>', $tag );
            },
            $html
        );
        // Those attributes were hanging on selection markers, which are left as
        // spans with nothing in them. An empty span renders nothing and core's
        // rich text does not write one, so a block holding one is a block the
        // owner is asked to recover. They go, attributes and all - the two in
        // the reported post were `PDq2pG_selectionAnchor` and `contents`.
        // Nested markers need more than one pass: removing the inner span is
        // what makes the outer one empty. Bounded, so a pathological post
        // cannot spin here.
        for ( $pass = 0; $pass < 8; $pass++ ) {
            $stripped = (string) preg_replace( '/<span(?:\s[^<>]*)?>\s*<\/span>/i', '', $html );
            if ( $stripped === $html ) {
                break;
            }
            $html = $stripped;
        }

        // A class on the markup with nothing in the delimiter to explain it
        // fails validation exactly like a data attribute does, so it is
        // recorded as `className` rather than dropped: it may be somebody's
        // design. Headings keep `wp-block-heading`, which core writes itself.
        $html = $this->studio_record_wrapper_class( $html, 'paragraph', 'p', [] );
        $html = $this->studio_record_wrapper_class( $html, 'heading', 'h[1-6]', [ 'wp-block-heading' ] );

        // Quotes: core's quote holds inner blocks. A bare paragraph inside one
        // is markup core would never have written, so it is wrapped. A quote
        // that already has inner blocks is skipped entirely.
        $html = (string) preg_replace_callback(
            '/<!--\s*wp:quote[^>]*-->([\s\S]*?)<!--\s*\/wp:quote\s*-->/i',
            static function ( $m ) {
                $inner = $m[1];
                if ( false !== strpos( $inner, '<!-- wp:' ) ) {
                    return $m[0];
                }
                $fixed = preg_replace(
                    '/(<p(?:\s[^>]*)?>[\s\S]*?<\/p>)/i',
                    "<!-- wp:paragraph -->\n$1\n<!-- /wp:paragraph -->",
                    $inner
                );
                return str_replace( $inner, (string) $fixed, $m[0] );
            },
            $html
        );

        return $html;
    }

    /**
     * A quote, whose contents are blocks in their own right.
     *
     * Core's quote has used inner blocks since v2: the paragraphs inside the
     * blockquote each carry their own delimiters. A bare <p> in there is
     * markup core would never have saved, so it refuses to validate the block
     * and offers 'Attempt recovery' - which is exactly what the owner saw.
     */
    private function studio_quote_block( \DOMDocument $dom, \DOMNode $node ): string {
        $inner = [];
        foreach ( $node->childNodes as $child ) {
            if ( XML_TEXT_NODE === $child->nodeType ) {
                $text = trim( $child->textContent );
                if ( '' !== $text ) {
                    $inner[] = $this->studio_block( 'paragraph', '<p>' . esc_html( $text ) . '</p>' );
                }
                continue;
            }
            if ( XML_ELEMENT_NODE !== $child->nodeType ) {
                continue;
            }
            // The citation is not one of the quote inner blocks; it is written
            // after them, so taking it here would print it twice.
            if ( 'cite' === strtolower( $child->nodeName ) ) {
                continue;
            }
            $block = $this->studio_block_for_node( $dom, $child );
            if ( '' !== $block ) {
                $inner[] = $block;
            }
        }
        if ( ! $inner ) {
            $inner[] = $this->studio_block( 'paragraph', '<p></p>' );
        }
        // The citation, if there is one, sits outside the inner blocks.
        $cite = '';
        foreach ( $node->getElementsByTagName( 'cite' ) as $found ) {
            $cite = trim( (string) $dom->saveHTML( $found ) );
            break;
        }
        $body = '<blockquote class="wp-block-quote">' . "\n" . implode( "\n\n", $inner ) . "\n" . $cite . '</blockquote>';
        return $this->studio_block( 'quote', $body );
    }

    /** A list, with each item as its own list-item block, as WordPress writes it. */
    private function studio_list_block( \DOMDocument $dom, \DOMNode $node, bool $ordered ): string {
        $items = [];
        foreach ( $node->childNodes as $child ) {
            if ( XML_ELEMENT_NODE !== $child->nodeType || 'li' !== strtolower( $child->nodeName ) ) {
                continue;
            }
            $items[] = "<!-- wp:list-item -->\n" . trim( (string) $dom->saveHTML( $child ) ) . "\n<!-- /wp:list-item -->";
        }
        if ( ! $items ) {
            return $this->studio_block( 'html', trim( (string) $dom->saveHTML( $node ) ) );
        }
        $tag   = $ordered ? 'ol' : 'ul';
        $attrs = $ordered ? ' {"ordered":true}' : '';
        $inner = '<' . $tag . ' class="wp-block-list">' . "\n" . implode( "\n", $items ) . "\n</" . $tag . '>';
        return $this->studio_block( 'list', $inner, $attrs );
    }

    /** An image, carrying its attachment id when the class names one. */
    private function studio_image_block( \DOMDocument $dom, \DOMNode $node, string $tag ): string {
        $img = 'img' === $tag ? $node : null;
        if ( ! $img ) {
            $found = $node->getElementsByTagName( 'img' );
            $img   = $found->length ? $found->item( 0 ) : null;
        }
        if ( ! $img ) {
            return $this->studio_block( 'html', trim( (string) $dom->saveHTML( $node ) ) );
        }

        $classes = $img->getAttribute( 'class' );
        $id      = 0;
        if ( preg_match( '/wp-image-(\d+)/', $classes, $match ) ) {
            $id = (int) $match[1];
        }

        /* C132. No class, so no id, so no id in the delimiter either - and the
           next save reads the markup it just wrote and loses it again. An
           image that reaches this site some other way (an import, a paste,
           anything that did not come from the media button) has never had one.
           Without it WordPress cannot resolve the attachment, adds no srcset,
           no sizes, no width and no height, and serves the full-size file
           whatever size was chosen: "an image keeps the size it was saved at".
           The src is a file in this site's uploads, so the id is recoverable.
           Nothing is invented - a URL that does not resolve is left alone. */
        if ( ! $id ) {
            $id = $this->studio_attachment_from_src( (string) $img->getAttribute( 'src' ) );
            if ( $id ) {
                $classes = trim( $classes . ' wp-image-' . $id );
                $img->setAttribute( 'class', $classes );
            }
        }

        /* The size is READ, not assumed.
         *
         * This wrote `size-full` every time, and `studio_with_class` ADDS a
         * class rather than replacing one - so an image the editor had stored
         * as `size-large` came back as
         *
         *     <figure class="wp-block-image size-large size-full">
         *     <!-- wp:image {"id":1024,"sizeSlug":"full"} -->
         *
         * which is two size classes and a slug that agrees with neither. Two
         * things follow from that one line, and the owner reported both on the
         * same post:
         *
         *   - WordPress decides a block is valid by regenerating what `save()`
         *     would have written. Core writes ONE size class, matching the
         *     slug, so this is "Block contains unexpected or invalid content".
         *   - `size-full` is the full-size rendering. A large image in a
         *     narrow column is suddenly laid out at its natural width - "why is
         *     the image breaking out of the normal way".
         *
         * `full` remains the fallback, and only when the markup carries no size
         * of its own: an image pasted as bare HTML genuinely has no slug, and
         * core uses `full` for that too.
         */
        $slug = $this->studio_image_size_slug( $node, $img );

        if ( 'figure' === $tag ) {
            $inner = $this->studio_with_class( $dom, $node, 'wp-block-image size-' . $slug );
        } else {
            $inner = '<figure class="wp-block-image size-' . $slug . '">'
                . trim( (string) $dom->saveHTML( $img ) ) . '</figure>';
        }

        $attrs = $id
            ? ' {"id":' . $id . ',"sizeSlug":"' . $slug . '"}'
            : ' {"sizeSlug":"' . $slug . '"}';
        return $this->studio_block( 'image', $inner, $attrs );
    }

    /**
     * Which attachment a `src` points at, or 0.
     *
     * `attachment_url_to_postid()` matches the ONE file the attachment is keyed
     * on and nothing else, so a resized copy in `src` - `name-1024x768.jpg`,
     * which is most of what the editor writes - misses it.
     *
     * Which file it is keyed on is the part worth knowing, and it was measured
     * rather than assumed. Upload something over the big-image threshold and
     * WordPress keeps `name-scaled.jpg` as the attachment's file - the original
     * `name.jpg` is kept on disk but nothing is keyed on it - while naming the
     * sized copies after the base: `name-300x188.jpg`, with no `-scaled` in
     * them. So for a big upload the way back from a size is to take the
     * dimensions off and put `-scaled` ON, not to take `-scaled` off.
     *
     * Four forms are asked about, exact first so a file whose own name ends in
     * `-scaled` is never mistaken for another one's stand-in.
     *
     * Only ever a read. A URL from another site, or one whose file has since
     * been deleted, answers 0 and the markup is left exactly as it was.
     */
    private function studio_attachment_from_src( string $src ): int {
        $src = trim( $src );
        if ( '' === $src || ! function_exists( 'attachment_url_to_postid' ) ) {
            return 0;
        }

        $sizeless = preg_replace( '/-\d+x\d+(?=\.[A-Za-z0-9]+$)/', '', $src );

        $tries = [
            // Exactly what is in the markup. A small upload's own file, and a
            // big one's `-scaled` stand-in, both land here.
            $src,
            // A size off a small upload: `name-300x200.jpg` -> `name.jpg`.
            $sizeless,
            // A size off a big one: `name-300x188.jpg` -> `name-scaled.jpg`.
            preg_replace( '/(\.[A-Za-z0-9]+)$/', '-scaled$1', $sizeless ),
            // And a name that carries both, which older uploads can.
            preg_replace( '/-scaled(?=\.[A-Za-z0-9]+$)/', '', $sizeless ),
        ];

        foreach ( array_unique( $tries ) as $candidate ) {
            $found = absint( attachment_url_to_postid( $candidate ) );
            if ( $found ) {
                return $found;
            }
        }
        return 0;
    }

    /**
     * The size WordPress stored on this image, or `full` when it stored none.
     *
     * Core records it twice - as `size-<slug>` on the figure and as
     * `sizeSlug` in the delimiter - and writes `attachment-<slug>` on the image
     * itself. Any of the three is an answer; the figure is checked first
     * because that is the one the block's own markup carries.
     */
    private function studio_image_size_slug( \DOMNode $figure, \DOMNode $img ): string {
        $sources = [];
        if ( $figure instanceof \DOMElement ) {
            $sources[] = $figure->getAttribute( 'class' );
        }
        if ( $img instanceof \DOMElement ) {
            $sources[] = $img->getAttribute( 'class' );
        }
        foreach ( $sources as $class ) {
            if ( preg_match( '/\bsize-([a-z0-9_-]+)\b/i', (string) $class, $m ) ) {
                return strtolower( $m[1] );
            }
            if ( preg_match( '/\battachment-([a-z0-9_-]+)\b/i', (string) $class, $m ) ) {
                return strtolower( $m[1] );
            }
        }
        return 'full';
    }

    /** The node's own HTML with a class added rather than replaced. */
    private function studio_with_class( \DOMDocument $dom, \DOMNode $node, string $class ): string {
        if ( ! $node instanceof \DOMElement ) {
            return trim( (string) $dom->saveHTML( $node ) );
        }
        $clone    = $node->cloneNode( true );
        $existing = trim( $clone->getAttribute( 'class' ) );
        $wanted   = array_unique( array_filter( array_merge(
            $existing ? preg_split( '/\s+/', $existing ) : [],
            preg_split( '/\s+/', $class )
        ) ) );
        $clone->setAttribute( 'class', implode( ' ', $wanted ) );
        return trim( (string) $dom->saveHTML( $clone ) );
    }

    /**
     * Strip the editor artefacts a paste carries in, before anything is a block.
     *
     * WordPress decides a block is valid by regenerating what `save()` would
     * have written and comparing it to what is stored. Anything on the markup
     * that core would not have written makes the block invalid, and the editor
     * offers "Attempt Block Recovery" - which is exactly what the owner kept
     * seeing on published posts.
     *
     * The markup they pasted came out of a chat assistant and carried
     * `data-start`, `data-end`, `data-section-id`, `data-content-reference-*`
     * and empty anchor spans on almost every paragraph. None of that is content
     * and none of it survives a round trip through core, so it goes here rather
     * than becoming a block nobody can edit.
     *
     * Only provably-inert markup is removed: `data-*` attributes, empty `class`
     * and `style` attributes, and a `<span>` left with nothing in it and nothing
     * on it. Classes are NOT dropped - they may be somebody's design - they are
     * carried into the block's own `className` instead, where core writes them.
     */
    private function studio_scrub_pasted( \DOMNode $node ): void {
        if ( $node instanceof \DOMElement ) {
            foreach ( iterator_to_array( $node->attributes ) as $attribute ) {
                $name = strtolower( $attribute->nodeName );
                if ( 0 === strpos( $name, 'data-' ) ) {
                    $node->removeAttribute( $attribute->nodeName );
                    continue;
                }
                if ( ( 'class' === $name || 'style' === $name ) && '' === trim( $attribute->nodeValue ) ) {
                    $node->removeAttribute( $attribute->nodeName );
                    continue;
                }
                /* 2026-09-24, kryptfo: "why is this error back again?" Text
                   pasted from a chat or a document arrives with `dir="auto"` on
                   every tag. Core's paragraph block accepts it; core's HEADING
                   block has nowhere to keep it, regenerates without it, and
                   refuses the block - measured with the editor's own validator
                   on WordPress 7.1.2. "Attempt recovery" drops it too, so this
                   is the same outcome without the warning. Headings only. */
                if ( 'dir' === $name && preg_match( '/^h[1-6]$/i', $node->nodeName ) ) {
                    $node->removeAttribute( $attribute->nodeName );
                }
            }
        }

        foreach ( iterator_to_array( $node->childNodes ) as $child ) {
            $this->studio_scrub_pasted( $child );
        }

        // A span with nothing on it and nothing in it was a selection marker,
        // not writing. It is removed after its children, so a nested pair of
        // them collapses in one pass rather than leaving the outer one behind.
        if ( $node instanceof \DOMElement
            && 'span' === strtolower( $node->nodeName )
            && ! $node->attributes->length
            && '' === trim( $node->textContent )
            && ! $node->getElementsByTagName( '*' )->length
            && $node->parentNode ) {
            $node->parentNode->removeChild( $node );
        }
    }

    /**
     * The classes on a node, as the block attribute core records them in.
     *
     * A class on the markup with nothing in the block comment to explain it is
     * markup core would not have written. Recording it as `className` keeps the
     * class - it may be somebody's design - and keeps the block valid, which
     * dropping it would also do but at the owner's expense.
     */
    private function studio_class_name_attr( \DOMNode $node, array $expected = [] ): array {
        if ( ! $node instanceof \DOMElement ) {
            return [];
        }
        $existing = trim( $node->getAttribute( 'class' ) );
        if ( '' === $existing ) {
            return [];
        }
        $classes = array_values( array_diff(
            array_unique( array_filter( preg_split( '/\s+/', $existing ) ) ),
            $expected
        ) );
        return $classes ? [ 'className' => implode( ' ', $classes ) ] : [];
    }

    /**
     * An `id` on the markup, as the block attribute core records it in.
     *
     * Core writes `id` on a block only from its `anchor` attribute, so an id
     * with nothing behind it in the delimiter fails validation the same way a
     * loose class does.
     */
    private function studio_anchor_attr( \DOMNode $node ): array {
        if ( ! $node instanceof \DOMElement ) {
            return [];
        }
        $id = trim( $node->getAttribute( 'id' ) );
        return '' === $id ? [] : [ 'anchor' => $id ];
    }

    /** Block attributes as the delimiter carries them, or '' for none. */
    private function studio_block_attrs( array $attrs ): string {
        if ( ! $attrs ) {
            return '';
        }
        return ' ' . wp_json_encode( $attrs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
    }

    /**
     * Put a wrapper's loose classes into the block delimiter that owns them.
     *
     * For a post already saved with them. Core writes a class on a block only
     * from its `className` attribute, so `<p class="lead">` under a bare
     * `<!-- wp:paragraph -->` cannot be regenerated and the block is invalid.
     * Moving the class into the delimiter keeps the class and makes the block
     * valid; dropping it would also work, at the owner's expense.
     *
     * A delimiter that already records a className is left alone - it is either
     * right, or somebody's decision, and neither is this function's business.
     */
    private function studio_record_wrapper_class( string $html, string $block, string $tags, array $expected ): string {
        $pattern = '/<!--\s*wp:' . $block . '(\s+\{[^}]*\})?\s*-->(\s*)<(' . $tags . ')([^>]*)>/i';
        return (string) preg_replace_callback(
            $pattern,
            static function ( $m ) use ( $block, $expected ) {
                $json = trim( (string) ( $m[1] ?? '' ) );
                $attrs = '' === $json ? [] : json_decode( $json, true );
                if ( ! is_array( $attrs ) || isset( $attrs['className'] ) ) {
                    return $m[0];
                }
                if ( ! preg_match( '/\sclass=(["\'])(.*?)\1/i', $m[4], $has ) ) {
                    return $m[0];
                }
                // A class core generates from some OTHER attribute is already
                // explained by the delimiter: `{"align":"center"}` is what
                // writes `has-text-align-center`, and `{"fontSize":"large"}`
                // writes `has-large-font-size`. Recording those as `className`
                // as well would rewrite blocks that were already valid.
                $classes = array_values( array_filter(
                    array_diff(
                        array_unique( array_filter( preg_split( '/\s+/', trim( $has[2] ) ) ) ),
                        $expected
                    ),
                    static function ( $class ) {
                        return ! preg_match( '/^(has|is|wp)-/', $class );
                    }
                ) );
                if ( ! $classes ) {
                    return $m[0];
                }
                $attrs['className'] = implode( ' ', $classes );
                return '<!-- wp:' . $block . ' '
                    . wp_json_encode( $attrs, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE )
                    . ' -->' . $m[2] . '<' . $m[3] . $m[4] . '>';
            },
            $html
        );
    }

    /** One block, delimiters and all. */
    private function studio_block( string $name, string $inner, string $attrs = '' ): string {
        return '<!-- wp:' . $name . $attrs . " -->\n" . $inner . "\n<!-- /wp:" . $name . ' -->';
    }

    /**
     * Create one term from the Content Studio taxonomy picker.
     *
     * `can_write` is the studio's own gate, but creating a term is a separate
     * WordPress capability, so the taxonomy's own `edit_terms` is checked as
     * well: being allowed to write a post does not make someone allowed to
     * invent categories. The taxonomy must also be one the studio actually
     * shows, so this cannot be used to reach a hidden or private one.
     */
    public function create_studio_term( \WP_REST_Request $request ): \WP_REST_Response {
        $params   = $request->get_json_params() ?: [];
        $taxonomy = sanitize_key( (string) ( $params['taxonomy'] ?? '' ) );
        $name     = sanitize_text_field( (string) ( $params['name'] ?? '' ) );
        $parent   = absint( $params['parent'] ?? 0 );

        if ( '' === $name ) {
            return new \WP_REST_Response( [ 'code' => 'empty_name', 'message' => 'Give the term a name.' ], 400 );
        }

        $tax = $taxonomy ? get_taxonomy( $taxonomy ) : null;
        if ( ! $tax instanceof \WP_Taxonomy || 'post_format' === $tax->name || ( ! $tax->public && ! $tax->show_ui ) ) {
            return new \WP_REST_Response( [ 'code' => 'unknown_taxonomy', 'message' => 'Unknown taxonomy.' ], 400 );
        }
        if ( ! current_user_can( $tax->cap->edit_terms ) ) {
            return new \WP_REST_Response( [ 'code' => 'forbidden', 'message' => 'You are not allowed to create terms in this taxonomy.' ], 403 );
        }

        if ( $parent ) {
            $parent_term = get_term( $parent, $tax->name );
            if ( ! $tax->hierarchical || ! $parent_term || is_wp_error( $parent_term ) ) {
                $parent = 0;
            }
        }

        $created = wp_insert_term( $name, $tax->name, [ 'parent' => $parent ] );
        $existed = false;

        if ( is_wp_error( $created ) ) {
            // A term with that name is already there. Selecting it is what was
            // meant, so hand it back instead of an error the person then has to
            // translate into "find it in the list yourself".
            $existing = $created->get_error_data( 'term_exists' );
            if ( ! $existing ) {
                return new \WP_REST_Response( [ 'code' => 'create_failed', 'message' => $created->get_error_message() ], 500 );
            }
            if ( is_array( $existing ) ) {
                $existing = $existing['term_id'] ?? 0;
            } elseif ( $existing instanceof \WP_Term ) {
                $existing = $existing->term_id;
            }
            $created = [ 'term_id' => (int) $existing ];
            $existed = true;
        }

        $term = get_term( (int) ( $created['term_id'] ?? 0 ), $tax->name );
        if ( ! $term instanceof \WP_Term ) {
            return new \WP_REST_Response( [ 'code' => 'create_failed', 'message' => 'The term could not be read back.' ], 500 );
        }

        return new \WP_REST_Response( [
            'success'  => true,
            'existed'  => $existed,
            'taxonomy' => $tax->name,
            'term'     => [
                'id'     => (int) $term->term_id,
                'name'   => $term->name,
                'slug'   => $term->slug,
                'parent' => (int) $term->parent,
            ],
        ], 200 );
    }

    public function create_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $post_type = sanitize_key( $params['post_type'] ?? 'post' );
        $title = sanitize_text_field( $params['title'] ?? '' );
        $status = sanitize_key( $params['status'] ?? 'draft' );
        $slug = sanitize_title( $params['slug'] ?? '' );
        $content = array_key_exists( 'content', $params ) ? wp_kses_post( (string) $params['content'] ) : '';
        // Stored as blocks, so the post opens in the block editor as itself rather
        // than as one Classic block asking to be converted first.
        $content = $this->studio_blocks_from_html( $content );
        $excerpt = array_key_exists( 'excerpt', $params ) ? sanitize_textarea_field( (string) $params['excerpt'] ) : '';
        $allowed_statuses = [ 'publish', 'draft', 'pending', 'private' ];
        if ( ! in_array( $status, $allowed_statuses, true ) ) {
            $status = 'draft';
        }

        if ( empty( $title ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_title', 'message' => 'Post title is required.' ], 400 );
        }

        if ( ! post_type_exists( $post_type ) ) {
            return new \WP_REST_Response( [ 'code' => 'invalid_post_type', 'message' => 'Post type does not exist.' ], 400 );
        }

        $insert = [
            'post_type'    => $post_type,
            'post_title'   => $title,
            'post_name'    => $slug,
            'post_content' => $content,
            'post_excerpt' => $excerpt,
            'post_status'  => $status,
        ];
        $has_calendar_date = false;
        // Optional publish date (Content Studio calendar "+ on this day").
        if ( array_key_exists( 'date', $params ) ) {
            $local = $this->studio_normalize_local_datetime( $params['date'] );
            if ( $local ) {
                $has_calendar_date = true;
                $insert['post_date']     = $local;
                $insert['post_date_gmt'] = get_gmt_from_date( $local );
                if ( 'publish' === $status && strtotime( $insert['post_date_gmt'] . ' UTC' ) > time() ) {
                    $insert['post_status'] = 'future';
                }
            }
        }
        // A post must not become public before its SEO fields exist: the publish
        // transition is what Rank Math (and sitemaps, and redirections) react to,
        // and it only happens once. Insert as a draft, write everything, then set
        // the status that was actually asked for.
        $intended_status = $insert['post_status'];
        $defer_status = in_array( $intended_status, [ 'publish', 'future', 'private' ], true );
        if ( $defer_status ) {
            $insert['post_status'] = 'draft';
        }

        $post_id = wp_insert_post( $insert );

        if ( is_wp_error( $post_id ) ) {
            return new \WP_REST_Response( [ 'code' => 'create_failed', 'message' => $post_id->get_error_message() ], 500 );
        }

        if ( ! $post_id ) {
            return new \WP_REST_Response( [ 'code' => 'create_failed', 'message' => 'Could not create post.' ], 500 );
        }

        if ( $has_calendar_date ) {
            update_post_meta( $post_id, '_ve_content_calendar_scheduled', '1' );
        }

        $this->apply_studio_post_extras( $post_id, $params );

        if ( $defer_status ) {
            wp_update_post( [ 'ID' => $post_id, 'post_status' => $intended_status ] );
        }

        $post = get_post( $post_id );
        return new \WP_REST_Response( $this->studio_post_payload( $post ), 200 );
    }

    /**
     * What the SITE does about comments, and how many posts disagree with it.
     *
     * A per-post switch answers for one post. This answers the question the
     * owner was actually asking: why do comments keep arriving after I turned
     * them off? Because the site default is on, and because every other post
     * still has its own setting.
     */
    public function get_readiness_rules( $request = null ): \WP_REST_Response {
        $checks = [];
        foreach ( \VE\Core\ContentReadiness::checks() as $id => $spec ) {
            $checks[] = [ 'id' => $id, 'label' => $spec['label'], 'needs' => $spec['needs'] ];
        }
        return rest_ensure_response( [
            'rules'  => \VE\Core\ContentReadiness::rules(),
            'checks' => $checks,
        ] );
    }

    public function set_readiness_rules( \WP_REST_Request $request ): \WP_REST_Response {
        $rules = $request->get_param( 'rules' );
        return rest_ensure_response( [
            'rules' => \VE\Core\ContentReadiness::save( is_array( $rules ) ? $rules : [] ),
        ] );
    }

    public function get_post_readiness( \WP_REST_Request $request ): \WP_REST_Response {
        return rest_ensure_response(
            \VE\Core\ContentReadiness::review( (int) $request['id'] )
        );
    }

    public function get_studio_discussion( $request = null ): \WP_REST_Response {
        global $wpdb;
        $open = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->posts}
              WHERE post_status NOT IN ( 'trash', 'auto-draft' )
                AND post_type NOT IN ( 'revision', 'attachment', 'nav_menu_item' )
                AND comment_status = 'open'"
        );
        $pending = (int) $wpdb->get_var(
            "SELECT COUNT(*) FROM {$wpdb->comments} WHERE comment_approved = '0'"
        );
        return rest_ensure_response( [
            'default_comments' => 'open' === get_option( 'default_comment_status', 'open' ),
            'default_pings'    => 'open' === get_option( 'default_ping_status', 'open' ),
            'posts_open'       => $open,
            'pending'          => $pending,
        ] );
    }

    /**
     * Change it. Two separate things, and the difference matters enough that
     * the caller has to ask for each by name:
     *
     *   `default`  - what NEW posts get. Nothing already written changes.
     *   `existing` - close comments on everything already published.
     *
     * The second is the one that cannot be undone by pressing it again: MV does
     * not know which posts were open by choice. So it reports how many it
     * closed, and the panel says what it is about to do before it does it.
     */
    public function set_studio_discussion( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $params  = $request->get_params();
        $changed = [];

        if ( array_key_exists( 'default', $params ) ) {
            $open = rest_sanitize_boolean( $params['default'] ) ? 'open' : 'closed';
            update_option( 'default_comment_status', $open );
            update_option( 'default_ping_status', $open );
            $changed['default'] = 'open' === $open;
        }

        if ( ! empty( $params['existing'] ) ) {
            $ids = $wpdb->get_col(
                "SELECT ID FROM {$wpdb->posts}
                  WHERE post_status NOT IN ( 'trash', 'auto-draft' )
                    AND post_type NOT IN ( 'revision', 'attachment', 'nav_menu_item' )
                    AND comment_status = 'open'"
            );
            $n = 0;
            foreach ( (array) $ids as $id ) {
                wp_update_post( [
                    'ID'             => (int) $id,
                    'comment_status' => 'closed',
                    'ping_status'    => 'closed',
                ] );
                $n++;
            }
            $changed['closed'] = $n;
        }

        $now = $this->get_studio_discussion();
        return rest_ensure_response( [
            'changed' => $changed,
            'site'    => $now->get_data(),
        ] );
    }

    public function update_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $id = absint( $request->get_param( 'id' ) );
        $params = $request->get_json_params() ?: [];
        $status = sanitize_key( $params['status'] ?? '' );
        $title = sanitize_text_field( $params['title'] ?? '' );
        $slug = sanitize_title( $params['slug'] ?? '' );
        $content_provided = array_key_exists( 'content', $params );
        $excerpt_provided = array_key_exists( 'excerpt', $params );

        if ( ! $id || ! get_post( $id ) ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'Post not found.' ], 404 );
        }

        // The panel sends the modified stamp it loaded with. If the post has moved
        // on since, someone else saved while this copy was being edited, and
        // writing now would erase their work with no trace. Refuse and say who,
        // rather than picking a winner. `force` is the person choosing.
        $base_modified = sanitize_text_field( (string) ( $params['base_modified'] ?? '' ) );
        $force_save    = ! empty( $params['force'] );
        if ( $base_modified && ! $force_save ) {
            $current_post = get_post( $id );
            $current_stamp = $current_post ? (string) $current_post->post_modified_gmt : '';
            if ( $current_stamp && $current_stamp !== $base_modified ) {
                $last_editor = absint( get_post_meta( $id, '_edit_last', true ) );
                $editor_user = $last_editor ? get_userdata( $last_editor ) : null;
                return new \WP_REST_Response( [
                    'code'        => 'conflict',
                    'message'     => 'This post changed while you were editing it.',
                    'modified'    => $current_stamp,
                    'modified_by' => $editor_user ? $editor_user->display_name : '',
                ], 409 );
            }
        }

        $update = [ 'ID' => $id ];
        if ( $status ) {
            $update['post_status'] = $status;
        }
        if ( $title ) {
            $update['post_title'] = $title;
        }
        if ( $slug ) {
            $update['post_name'] = $slug;
        }
        if ( $content_provided ) {
            $update['post_content'] = $this->studio_blocks_from_html( wp_kses_post( (string) $params['content'] ) );
        }
        if ( $excerpt_provided ) {
            $update['post_excerpt'] = sanitize_textarea_field( (string) $params['excerpt'] );
        }
        if ( array_key_exists( 'parent', $params ) ) {
            $update['post_parent'] = absint( $params['parent'] );
        }
        if ( array_key_exists( 'menu_order', $params ) ) {
            $update['menu_order'] = intval( $params['menu_order'] );
        }
        if ( array_key_exists( 'author', $params ) ) {
            $author_id = absint( $params['author'] );
            if ( $author_id && get_user_by( 'id', $author_id ) ) {
                $update['post_author'] = $author_id;
            }
        }
        if ( array_key_exists( 'comment_status', $params ) ) {
            $update['comment_status'] = rest_sanitize_boolean( $params['comment_status'] ) ? 'open' : 'closed';
        }
        if ( array_key_exists( 'ping_status', $params ) ) {
            $update['ping_status'] = rest_sanitize_boolean( $params['ping_status'] ) ? 'open' : 'closed';
        }
        $has_calendar_date = false;
        // Reschedule / backdate (Content Studio calendar drag). The value is site-local
        // 'Y-m-d H:i:s'. edit_date is required or wp_update_post ignores post_date.
        if ( array_key_exists( 'date', $params ) ) {
            $local = $this->studio_normalize_local_datetime( $params['date'] );
            if ( $local ) {
                $has_calendar_date = true;
                $update['post_date']     = $local;
                $update['post_date_gmt'] = get_gmt_from_date( $local );
                $update['edit_date']     = true;
                // Keep status coherent with the new date: a published post moved into the
                // future becomes scheduled, and a scheduled post moved into the past publishes.
                $existing = get_post( $id );
                $current_status = $status ?: ( $existing ? $existing->post_status : '' );
                $is_future = strtotime( $update['post_date_gmt'] . ' UTC' ) > time();
                if ( $is_future && 'publish' === $current_status ) {
                    $update['post_status'] = 'future';
                } elseif ( ! $is_future && 'future' === $current_status ) {
                    $update['post_status'] = 'publish';
                }
            }
        }

        // Before the post columns, so that a change of status transitions with the
        // finished SEO and field data rather than the previous state.
        $this->apply_studio_post_extras( $id, $params );

        if ( count( $update ) > 1 ) {
            $updated_id = wp_update_post( $update, true );
            if ( is_wp_error( $updated_id ) ) {
                return new \WP_REST_Response( [ 'code' => 'update_failed', 'message' => $updated_id->get_error_message() ], 500 );
            }
        }
        if ( $has_calendar_date ) {
            update_post_meta( $id, '_ve_content_calendar_scheduled', '1' );
        }
        $post = get_post( $id );
        $payload = $this->studio_post_payload( $post );

        /* What was asked for, against what landed.
           `wp_update_post()` does not return an error when a status is
           refused - WordPress writes what it is willing to write and hands
           back the post id either way. "I just published this but it's still
           showing draft" is what that silence looks like from the outside, so
           the panel is told rather than left to assume. */
        if ( $status && $post && $post->post_status !== $status ) {
            $payload['status_asked']   = $status;
            $payload['status_refused'] = true;
            $payload['status_reason']  = $this->studio_status_refusal_reason( $post, $status );
        }

        return new \WP_REST_Response( $payload, 200 );
    }

    /**
     * Why a post is not in the state it was asked to be in.
     *
     * WordPress refuses a status in two ways of its own, and both are worth
     * naming because both are fixable by the person reading. Anything else is
     * another plugin on the site, which MV cannot name but can point at.
     */
    private function studio_status_refusal_reason( \WP_Post $post, string $asked ): string {
        if ( 'future' === $post->post_status && 'publish' === $asked ) {
            return 'Its date is in the future, so WordPress scheduled it instead of publishing it. '
                 . 'Set the date to now to publish it today.';
        }

        $type = get_post_type_object( $post->post_type );
        $cap  = $type && isset( $type->cap->publish_posts ) ? (string) $type->cap->publish_posts : 'publish_posts';
        if ( 'pending' === $post->post_status && 'publish' === $asked && ! current_user_can( $cap ) ) {
            return 'Your account cannot publish this post type, so WordPress saved it for review instead.';
        }

        return sprintf(
            'WordPress kept it as "%s". Something else on this site - a plugin that filters saves, '
            . 'or an editorial workflow - changed it back.',
            $post->post_status
        );
    }

    /**
     * Is this post's own address actually its own?
     *
     * R19, 2026-09-09. The owner asked why one article was not using the single
     * post template. It was never a template question: the article's permalink
     * answered **404**, so what rendered was the 404 template. The post itself
     * was fine - published, same category as its neighbours, and `/?p=<id>`
     * found it and canonically redirected to the address that then refused it.
     *
     * With `/%postname%/` permalinks WordPress consults the PAGE namespace
     * first (`use_verbose_page_rules`), and `get_page_by_path()` matches every
     * page and attachment row **whatever its status** - a draft counts. When one
     * of those holds the article's slug the request is answered as
     * `pagename=<slug>`, the query is then restricted to published pages,
     * nothing matches, and the article 404s while `?p=` keeps working. Core will
     * not correct it either: `wp_unique_post_slug()` scopes its uniqueness check
     * to the post's OWN type, so a page and a post can hold one slug forever.
     *
     * Nothing said so. The panel said Published, the sitemap listed it, REST
     * returned it, and the address was a 404. Deleting the row that holds the
     * slug is not MV's call - but looking, and naming it, is.
     *
     * Deliberately NOT part of `studio_post_payload()`: that payload is built
     * once per row of the content list and `url_to_postid()` is a query. This is
     * one request, for one post, at the moment somebody publishes it.
     */
    public function studio_post_address( \WP_REST_Request $request ): \WP_REST_Response {
        $id   = absint( $request->get_param( 'id' ) );
        $post = $id ? get_post( $id ) : null;
        if ( ! $post ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'Post not found.' ], 404 );
        }

        $status_object = get_post_status_object( $post->post_status );
        $is_public     = $status_object && ! empty( $status_object->public );
        $permalink     = (string) get_permalink( $post );

        /* A draft has no public address, so it cannot have a broken one. Saying
           "unreachable" about a draft would be noise on every single save. */
        if ( ! $is_public || '' === $permalink ) {
            return new \WP_REST_Response( [
                'id'          => (int) $post->ID,
                'slug'        => (string) $post->post_name,
                'permalink'   => $permalink,
                'checked'     => false,
                'resolves'    => true,
                'resolved_id' => 0,
                'holder'      => null,
                'message'     => '',
            ], 200 );
        }

        $resolved = (int) url_to_postid( $permalink );
        $resolves = $resolved === (int) $post->ID;

        $holder  = null;
        $message = '';
        if ( ! $resolves ) {
            /* The same call WordPress itself makes when it decides a request is
               a page. Whatever comes back is what is answering to the address. */
            $shadow = ( $post->post_name && function_exists( 'get_page_by_path' ) )
                ? get_page_by_path( $post->post_name )
                : null;
            if ( $shadow && (int) $shadow->ID !== (int) $post->ID ) {
                $holder = [
                    'id'     => (int) $shadow->ID,
                    'type'   => (string) $shadow->post_type,
                    'status' => (string) $shadow->post_status,
                    'title'  => (string) $shadow->post_title,
                ];
            }
            $message = $holder
                ? sprintf(
                    'Published, but the address returns 404. The slug "%1$s" is held by %2$s #%3$d (%4$s), "%5$s" - WordPress answers this address with that row and finds nothing to show.',
                    $post->post_name,
                    $holder['type'],
                    $holder['id'],
                    $holder['status'],
                    '' !== $holder['title'] ? $holder['title'] : 'untitled'
                )
                : sprintf(
                    'Published, but the address does not resolve to this post%s. Nothing in the page namespace claims the slug "%s", so the cause is elsewhere - rewrite rules are the next place to look.',
                    $resolved ? sprintf( ' - it resolves to #%d', $resolved ) : '',
                    $post->post_name
                );
        }

        return new \WP_REST_Response( [
            'id'          => (int) $post->ID,
            'slug'        => (string) $post->post_name,
            'permalink'   => $permalink,
            'checked'     => true,
            'resolves'    => $resolves,
            'resolved_id' => $resolved,
            'holder'      => $holder,
            'message'     => $message,
        ], 200 );
    }

    public function duplicate_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $id = absint( $request->get_param( 'id' ) );
        $params = $request->get_json_params() ?: [];
        $status = sanitize_key( $params['status'] ?? 'draft' );
        if ( ! in_array( $status, [ 'draft', 'pending', 'private' ], true ) ) {
            $status = 'draft';
        }

        $source = get_post( $id );
        if ( ! $source ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'Post not found.' ], 404 );
        }

        if ( ! current_user_can( 'edit_post', $id ) ) {
            return new \WP_REST_Response( [ 'code' => 'forbidden', 'message' => 'You cannot duplicate this content item.' ], 403 );
        }

        $new_id = wp_insert_post( [
            'post_type'      => $source->post_type,
            'post_title'     => sprintf( '%s Copy', $source->post_title ?: 'Untitled' ),
            'post_content'   => $source->post_content,
            'post_excerpt'   => $source->post_excerpt,
            'post_status'    => $status,
            'post_author'    => get_current_user_id() ?: $source->post_author,
            'post_parent'    => (int) $source->post_parent,
            'menu_order'     => (int) $source->menu_order,
            'comment_status' => $source->comment_status,
            'ping_status'    => $source->ping_status,
        ], true );

        if ( is_wp_error( $new_id ) ) {
            return new \WP_REST_Response( [ 'code' => 'duplicate_failed', 'message' => $new_id->get_error_message() ], 500 );
        }

        $meta = get_post_meta( $id );
        foreach ( $meta as $key => $values ) {
            if ( '_edit_lock' === $key || '_edit_last' === $key ) {
                continue;
            }
            foreach ( (array) $values as $value ) {
                add_post_meta( $new_id, $key, maybe_unserialize( $value ) );
            }
        }

        $taxonomies = get_object_taxonomies( $source->post_type );
        foreach ( $taxonomies as $taxonomy ) {
            $terms = wp_get_object_terms( $id, $taxonomy, [ 'fields' => 'ids' ] );
            if ( ! is_wp_error( $terms ) ) {
                wp_set_object_terms( $new_id, array_map( 'intval', $terms ), $taxonomy, false );
            }
        }

        $thumb_id = get_post_thumbnail_id( $id );
        if ( $thumb_id ) {
            set_post_thumbnail( $new_id, $thumb_id );
        }

        $post = get_post( $new_id );
        return new \WP_REST_Response( $this->studio_post_payload( $post ), 200 );
    }

    public function delete_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $id = absint( $request->get_param( 'id' ) );
        $force = rest_sanitize_boolean( $request->get_param( 'force' ) );

        if ( ! $id || ! get_post( $id ) ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'Post not found.' ], 404 );
        }

        $res = wp_delete_post( $id, $force );
        if ( $res ) {
            return new \WP_REST_Response( [ 'id' => $id ], 200 );
        }

        return new \WP_REST_Response( [ 'code' => 'delete_failed', 'message' => 'Could not delete post.' ], 500 );
    }

    /**
     * Editable registration settings for a post type, read from the live
     * WP_Post_Type object. Feeds Content Studio's Post Types editor (#20) so
     * the full ACF-equivalent settings can be shown without a second request.
     */
    private function studio_cpt_object_settings( \WP_Post_Type $pt ): array {
        $labels  = (array) $pt->labels;
        $rewrite = is_array( $pt->rewrite ) ? $pt->rewrite : [];
        return [
            'description'           => (string) $pt->description,
            'public'                => (bool) $pt->public,
            'hierarchical'          => (bool) $pt->hierarchical,
            'has_archive'           => ! empty( $pt->has_archive ),
            'show_ui'               => (bool) $pt->show_ui,
            'show_in_menu'          => (bool) $pt->show_in_menu,
            'show_in_nav_menus'     => (bool) $pt->show_in_nav_menus,
            'show_in_admin_bar'     => (bool) $pt->show_in_admin_bar,
            'exclude_from_search'   => (bool) $pt->exclude_from_search,
            'publicly_queryable'    => (bool) $pt->publicly_queryable,
            'can_export'            => (bool) $pt->can_export,
            'delete_with_user'      => (bool) $pt->delete_with_user,
            'menu_position'         => null !== $pt->menu_position ? (string) $pt->menu_position : '',
            'menu_icon'             => is_string( $pt->menu_icon ) ? $pt->menu_icon : '',
            'capability_type'       => is_array( $pt->capability_type ) ? (string) ( $pt->capability_type[0] ?? 'post' ) : (string) $pt->capability_type,
            'query_var'             => is_string( $pt->query_var ) ? $pt->query_var : ( $pt->query_var ? $pt->name : '' ),
            'rewrite_slug'          => (string) ( $rewrite['slug'] ?? '' ),
            'rewrite_front'         => ! isset( $rewrite['with_front'] ) || (bool) $rewrite['with_front'],
            'rewrite_feeds'         => ! empty( $rewrite['feeds'] ),
            'rewrite_pages'         => ! isset( $rewrite['pages'] ) || (bool) $rewrite['pages'],
            'show_in_rest'          => (bool) $pt->show_in_rest,
            'rest_base'             => is_string( $pt->rest_base ) ? $pt->rest_base : '',
            'rest_namespace'        => is_string( $pt->rest_namespace ) ? $pt->rest_namespace : 'wp/v2',
            'rest_controller_class' => is_string( $pt->rest_controller_class ) ? $pt->rest_controller_class : '',
            'supports'              => array_values( array_keys( get_all_post_type_supports( $pt->name ) ) ),
            'taxonomies'            => array_values( get_object_taxonomies( $pt->name ) ),
            'labels'                => [
                'menu_name'    => (string) ( $labels['menu_name'] ?? '' ),
                'all_items'    => (string) ( $labels['all_items'] ?? '' ),
                'edit_item'    => (string) ( $labels['edit_item'] ?? '' ),
                'view_item'    => (string) ( $labels['view_item'] ?? '' ),
                'add_new_item' => (string) ( $labels['add_new_item'] ?? '' ),
                'new_item'     => (string) ( $labels['new_item'] ?? '' ),
                'search_items' => (string) ( $labels['search_items'] ?? '' ),
                'not_found'    => (string) ( $labels['not_found'] ?? '' ),
            ],
        ];
    }

    /** Editable registration settings for a taxonomy, read from the live object (#8). */
    private function studio_taxonomy_object_settings( \WP_Taxonomy $tax ): array {
        $labels  = (array) $tax->labels;
        $rewrite = is_array( $tax->rewrite ) ? $tax->rewrite : [];
        return [
            'description'         => (string) $tax->description,
            'public'              => (bool) $tax->public,
            'hierarchical'        => (bool) $tax->hierarchical,
            'show_ui'             => (bool) $tax->show_ui,
            'show_in_menu'        => (bool) $tax->show_in_menu,
            'show_in_nav_menus'   => (bool) $tax->show_in_nav_menus,
            'show_admin_column'   => (bool) $tax->show_admin_column,
            'publicly_queryable'  => (bool) ( $tax->publicly_queryable ?? $tax->public ),
            'query_var'           => is_string( $tax->query_var ) ? $tax->query_var : ( $tax->query_var ? $tax->name : '' ),
            'rewrite_slug'        => (string) ( $rewrite['slug'] ?? '' ),
            'rewrite_front'       => ! isset( $rewrite['with_front'] ) || (bool) $rewrite['with_front'],
            'show_in_rest'        => (bool) $tax->show_in_rest,
            'rest_base'           => is_string( $tax->rest_base ) ? $tax->rest_base : '',
            'rest_namespace'      => is_string( $tax->rest_namespace ) ? $tax->rest_namespace : 'wp/v2',
            'object_type'         => array_values( (array) $tax->object_type ),
            'labels'              => [
                'menu_name'     => (string) ( $labels['menu_name'] ?? '' ),
                'all_items'     => (string) ( $labels['all_items'] ?? '' ),
                'edit_item'     => (string) ( $labels['edit_item'] ?? '' ),
                'view_item'     => (string) ( $labels['view_item'] ?? '' ),
                'add_new_item'  => (string) ( $labels['add_new_item'] ?? '' ),
                'new_item_name' => (string) ( $labels['new_item_name'] ?? '' ),
                'search_items'  => (string) ( $labels['search_items'] ?? '' ),
                'not_found'     => (string) ( $labels['not_found'] ?? '' ),
            ],
        ];
    }

    /** POST — create/update an ACF taxonomy, merging into the existing record (#8). */
    public function create_or_update_studio_taxonomy( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! function_exists( 'acf_update_taxonomy' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'This ACF version cannot register taxonomies from here.' ], 200 );
        }
        $params = $request->get_json_params() ?: [];
        $name = sanitize_key( $params['name'] ?? '' );
        $singular = sanitize_text_field( $params['singular'] ?? '' );
        $plural = sanitize_text_field( $params['plural'] ?? '' );
        $settings = isset( $params['settings'] ) && is_array( $params['settings'] ) ? $params['settings'] : null;
        if ( empty( $name ) || empty( $singular ) || empty( $plural ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_params', 'message' => 'Name, singular label, and plural label are required.' ], 400 );
        }

        $existing = [];
        if ( function_exists( 'acf_get_acf_taxonomies' ) ) {
            foreach ( (array) acf_get_acf_taxonomies() as $at ) {
                if ( ( $at['taxonomy'] ?? '' ) === $name ) {
                    $existing = (array) $at;
                    break;
                }
            }
        }
        $def = $existing;
        $def['taxonomy'] = $name;
        $def['title']    = $plural;
        $def['active']   = 1;
        $labels = isset( $def['labels'] ) && is_array( $def['labels'] ) ? $def['labels'] : [];
        $labels['name']          = $plural;
        $labels['singular_name'] = $singular;

        if ( null !== $settings ) {
            foreach ( [ 'public', 'hierarchical', 'show_ui', 'show_in_menu', 'show_in_nav_menus', 'show_admin_column', 'publicly_queryable', 'show_in_rest' ] as $k ) {
                if ( isset( $settings[ $k ] ) ) {
                    $def[ $k ] = (bool) $settings[ $k ] ? 1 : 0;
                }
            }
            if ( isset( $settings['description'] ) ) {
                $def['description'] = sanitize_textarea_field( (string) $settings['description'] );
            }
            foreach ( [ 'query_var', 'rest_base', 'rest_namespace' ] as $k ) {
                if ( isset( $settings[ $k ] ) ) {
                    $def[ $k ] = sanitize_text_field( (string) $settings[ $k ] );
                }
            }
            if ( isset( $settings['object_type'] ) && is_array( $settings['object_type'] ) ) {
                $def['object_type'] = array_values( array_map( 'sanitize_key', $settings['object_type'] ) );
            }
            $slug  = isset( $settings['rewrite_slug'] ) ? sanitize_title( (string) $settings['rewrite_slug'] ) : '';
            $front = ! isset( $settings['rewrite_front'] ) || (bool) $settings['rewrite_front'];
            $def['permalink_rewrite'] = $slug ? 'custom_slug' : 'taxonomy_key';
            $def['rewrite_slug']      = $slug;
            $def['rewrite_withfront'] = $front ? 1 : 0;
            $def['rewrite'] = [ 'slug' => $slug ?: $name, 'with_front' => $front ];
            if ( isset( $settings['labels'] ) && is_array( $settings['labels'] ) ) {
                foreach ( [ 'menu_name', 'all_items', 'edit_item', 'view_item', 'add_new_item', 'new_item_name', 'search_items', 'not_found' ] as $lk ) {
                    if ( isset( $settings['labels'][ $lk ] ) && '' !== $settings['labels'][ $lk ] ) {
                        $labels[ $lk ] = sanitize_text_field( (string) $settings['labels'][ $lk ] );
                    }
                }
            }
        } else {
            $def['show_in_rest'] = 1;
        }
        $def['labels'] = $labels;
        acf_update_taxonomy( $def );
        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    /** DELETE — remove an ACF taxonomy definition (#8). */
    public function delete_studio_taxonomy( \WP_REST_Request $request ): \WP_REST_Response {
        $name = sanitize_key( (string) $request->get_param( 'name' ) );
        if ( function_exists( 'acf_get_acf_taxonomies' ) && function_exists( 'acf_delete_taxonomy' ) ) {
            foreach ( (array) acf_get_acf_taxonomies() as $at ) {
                if ( ( $at['taxonomy'] ?? '' ) === $name && isset( $at['ID'] ) ) {
                    acf_delete_taxonomy( (int) $at['ID'] );
                    return new \WP_REST_Response( [ 'success' => true ], 200 );
                }
            }
        }
        return new \WP_REST_Response( [ 'success' => false, 'message' => 'Taxonomy not found or not editable here.' ], 200 );
    }

    /** POST — create/update an ACF options page, merging into the existing record (#13). */
    public function create_or_update_studio_options_page( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! function_exists( 'acf_update_ui_options_page' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'This ACF version cannot register options pages from here.' ], 200 );
        }
        $params = $request->get_json_params() ?: [];
        $slug = sanitize_key( $params['slug'] ?? '' );
        $settings = isset( $params['settings'] ) && is_array( $params['settings'] ) ? $params['settings'] : [];
        $page_title = sanitize_text_field( (string) ( $settings['page_title'] ?? $params['page_title'] ?? '' ) );
        if ( empty( $slug ) || empty( $page_title ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_params', 'message' => 'Page title and menu slug are required.' ], 400 );
        }

        $existing = [];
        if ( function_exists( 'acf_get_ui_options_pages' ) ) {
            foreach ( (array) acf_get_ui_options_pages() as $up ) {
                if ( ( $up['menu_slug'] ?? '' ) === $slug ) {
                    $existing = (array) $up;
                    break;
                }
            }
        }
        /* An options page a plugin or theme registers in code (Advanced Themer's,
           on test7) is not one ACF stores, so it was not found above - and
           saving would have made a SECOND page with the same slug. Refused, and
           the answer says where it lives. */
        if ( ! $existing && function_exists( 'acf_get_options_pages' ) ) {
            foreach ( (array) acf_get_options_pages() as $registered ) {
                if ( ( $registered['menu_slug'] ?? '' ) === $slug ) {
                    return new \WP_REST_Response( [ 'code' => 'registered_in_code', 'message' => 'This options page is registered in code by a plugin or theme, so its settings are changed there, not here. Its fields can still be edited.' ], 409 );
                }
            }
        }
        $def = $existing;
        /* C13, 2026-09-24, measured on test7 with ACF Pro: a page created here had
           no key, so ACF stored its post ID as the key (key=65, post name 65).
           ACF's export and JSON sync tell pages apart by key; ACF makes one with
           uniqid( 'ui_options_page_' ), and so does this. An existing key stays. */
        if ( empty( $def['key'] ) ) {
            $def['key'] = uniqid( 'ui_options_page_' );
        }
        $def['menu_slug']  = $slug;
        $def['page_title'] = $page_title;
        $def['menu_title'] = sanitize_text_field( (string) ( $settings['menu_title'] ?? $page_title ) );
        $def['active']     = 1;
        foreach ( [ 'parent_slug', 'icon_url', 'capability', 'description' ] as $k ) {
            if ( isset( $settings[ $k ] ) ) {
                $def[ $k ] = sanitize_text_field( (string) $settings[ $k ] );
            }
        }
        if ( isset( $settings['position'] ) ) {
            $def['position'] = '' !== $settings['position'] ? (string) intval( $settings['position'] ) : '';
        }
        foreach ( [ 'redirect', 'autoload' ] as $b ) {
            if ( isset( $settings[ $b ] ) ) {
                $def[ $b ] = (bool) $settings[ $b ] ? 1 : 0;
            }
        }
        acf_update_ui_options_page( $def );
        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    /** DELETE — remove an ACF options page definition (#13). */
    public function delete_studio_options_page( \WP_REST_Request $request ): \WP_REST_Response {
        $slug = sanitize_key( (string) $request->get_param( 'slug' ) );
        if ( function_exists( 'acf_get_ui_options_pages' ) && function_exists( 'acf_delete_ui_options_page' ) ) {
            foreach ( (array) acf_get_ui_options_pages() as $up ) {
                if ( ( $up['menu_slug'] ?? '' ) === $slug && isset( $up['ID'] ) ) {
                    acf_delete_ui_options_page( (int) $up['ID'] );
                    return new \WP_REST_Response( [ 'success' => true ], 200 );
                }
            }
        }
        return new \WP_REST_Response( [ 'success' => false, 'message' => 'Options page not found or not editable here.' ], 200 );
    }

    public function create_or_update_studio_cpt( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $name = sanitize_key( $params['name'] ?? '' );
        $singular = sanitize_text_field( $params['singular'] ?? '' );
        $plural = sanitize_text_field( $params['plural'] ?? '' );
        $source = sanitize_key( $params['source'] ?? 'acf' );
        $settings = isset( $params['settings'] ) && is_array( $params['settings'] ) ? $params['settings'] : null;

        if ( empty( $name ) || empty( $singular ) || empty( $plural ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_params', 'message' => 'Name, singular label, and plural label are required.' ], 400 );
        }

        if ( $source === 'jet' ) {
            $cpts = get_option( 'jet_engine_cpt', [] );
            if ( ! is_array( $cpts ) ) {
                $cpts = [];
            }
            $found = false;
            foreach ( $cpts as &$c ) {
                if ( ( $c['slug'] ?? '' ) === $name ) {
                    $c['labels']['name'] = $plural;
                    $c['labels']['singular_name'] = $singular;
                    $found = true;
                    break;
                }
            }
            if ( ! $found ) {
                $cpts[] = [
                    'slug'   => $name,
                    'labels' => [
                        'name'          => $plural,
                        'singular_name' => $singular,
                    ],
                    'args'   => [
                        'public'       => true,
                        'show_in_rest' => true,
                    ],
                ];
            }
            update_option( 'jet_engine_cpt', $cpts );
        } else {
            if ( function_exists( 'acf_update_post_type' ) ) {
                // Merge into the existing ACF record so its key and any settings the
                // editor does not expose stay attached while supported values change.
                $existing = [];
                if ( function_exists( 'acf_get_acf_post_types' ) ) {
                    foreach ( (array) acf_get_acf_post_types() as $ap ) {
                        if ( ( $ap['post_type'] ?? '' ) === $name ) {
                            $existing = (array) $ap;
                            break;
                        }
                    }
                }
                $def = $existing;
                $def['post_type'] = $name;
                $def['title']     = $plural;
                $def['active']    = 1;
                $labels = isset( $def['labels'] ) && is_array( $def['labels'] ) ? $def['labels'] : [];
                $labels['name']          = $plural;
                $labels['singular_name'] = $singular;

                if ( null !== $settings ) {
                    $bool_keys = [ 'public', 'hierarchical', 'has_archive', 'show_ui', 'show_in_menu',
                        'show_in_nav_menus', 'show_in_admin_bar', 'exclude_from_search', 'publicly_queryable',
                        'can_export', 'delete_with_user', 'show_in_rest' ];
                    foreach ( $bool_keys as $k ) {
                        if ( isset( $settings[ $k ] ) ) {
                            $def[ $k ] = (bool) $settings[ $k ] ? 1 : 0;
                        }
                    }
                    if ( isset( $settings['description'] ) ) {
                        $def['description'] = sanitize_textarea_field( (string) $settings['description'] );
                    }
                    if ( isset( $settings['menu_position'] ) && '' !== $settings['menu_position'] ) {
                        $def['menu_position'] = (int) $settings['menu_position'];
                    }
                    foreach ( [ 'menu_icon', 'capability_type', 'query_var', 'rest_base', 'rest_namespace', 'rest_controller_class' ] as $k ) {
                        if ( isset( $settings[ $k ] ) ) {
                            $def[ $k ] = sanitize_text_field( (string) $settings[ $k ] );
                        }
                    }
                    if ( isset( $settings['supports'] ) && is_array( $settings['supports'] ) ) {
                        $def['supports'] = array_values( array_map( 'sanitize_key', $settings['supports'] ) );
                    }
                    if ( isset( $settings['taxonomies'] ) && is_array( $settings['taxonomies'] ) ) {
                        $def['taxonomies'] = array_values( array_map( 'sanitize_key', $settings['taxonomies'] ) );
                    }
                    // Rewrite: keep both the WP-style array and ACF's own fields so the
                    // registration matches whichever ACF reads on init.
                    $slug  = isset( $settings['rewrite_slug'] ) ? sanitize_title( (string) $settings['rewrite_slug'] ) : '';
                    $front = ! isset( $settings['rewrite_front'] ) || (bool) $settings['rewrite_front'];
                    $def['permalink_rewrite'] = $slug ? 'custom_slug' : 'post_type_key';
                    $def['rewrite_slug']      = $slug;
                    $def['rewrite_withfront'] = $front ? 1 : 0;
                    $def['rewrite'] = [
                        'slug'       => $slug ?: $name,
                        'with_front' => $front,
                        'feeds'      => ! empty( $settings['rewrite_feeds'] ),
                        'pages'      => ! isset( $settings['rewrite_pages'] ) || (bool) $settings['rewrite_pages'],
                    ];
                    if ( isset( $settings['labels'] ) && is_array( $settings['labels'] ) ) {
                        $label_map = [
                            'menu_name' => 'menu_name', 'all_items' => 'all_items', 'edit_item' => 'edit_item',
                            'view_item' => 'view_item', 'add_new_item' => 'add_new_item', 'new_item' => 'new_item',
                            'search_items' => 'search_items', 'not_found' => 'not_found',
                        ];
                        foreach ( $label_map as $in => $out ) {
                            if ( isset( $settings['labels'][ $in ] ) && '' !== $settings['labels'][ $in ] ) {
                                $labels[ $out ] = sanitize_text_field( (string) $settings['labels'][ $in ] );
                            }
                        }
                    }
                } else {
                    // Legacy labels-only path.
                    $def['show_in_rest'] = 1;
                }
                $def['labels'] = $labels;
                acf_update_post_type( $def );
            } else {
                $cpts = get_option( 'jet_engine_cpt', [] );
                if ( ! is_array( $cpts ) ) {
                    $cpts = [];
                }
                $found = false;
                foreach ( $cpts as &$c ) {
                    if ( ( $c['slug'] ?? '' ) === $name ) {
                        $c['labels']['name'] = $plural;
                        $c['labels']['singular_name'] = $singular;
                        $found = true;
                        break;
                    }
                }
                if ( ! $found ) {
                    $cpts[] = [
                        'slug'   => $name,
                        'labels' => [
                            'name'          => $plural,
                            'singular_name' => $singular,
                        ],
                        'args'   => [
                            'public'       => true,
                            'show_in_rest' => true,
                        ],
                    ];
                }
                update_option( 'jet_engine_cpt', $cpts );
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function delete_studio_cpt( \WP_REST_Request $request ): \WP_REST_Response {
        $name = sanitize_key( $request->get_param( 'name' ) );

        $jet_cpts = get_option( 'jet_engine_cpt', [] );
        if ( is_array( $jet_cpts ) ) {
            $filtered = [];
            $found = false;
            foreach ( $jet_cpts as $c ) {
                if ( ( $c['slug'] ?? '' ) === $name ) {
                    $found = true;
                } else {
                    $filtered[] = $c;
                }
            }
            if ( $found ) {
                update_option( 'jet_engine_cpt', $filtered );
            }
        }

        if ( function_exists( 'acf_delete_post_type' ) ) {
            acf_delete_post_type( $name );
        } else {
            $acf_posts = get_posts([
                'post_type'   => 'acf-post-type',
                'name'        => $name,
                'post_status' => 'any',
                'numberposts' => 1,
            ]);
            if ( ! empty( $acf_posts ) ) {
                wp_delete_post( $acf_posts[0]->ID, true );
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function create_or_update_studio_fields( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $title = sanitize_text_field( $params['title'] ?? '' );
        $post_types = is_array( $params['post_types'] ?? null ) ? array_map( 'sanitize_key', $params['post_types'] ) : [ 'post' ];
        $fields = is_array( $params['fields'] ?? null ) ? $params['fields'] : [];
        $source = sanitize_key( $params['source'] ?? 'acf' );

        if ( empty( $title ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_title', 'message' => 'Title is required.' ], 400 );
        }

        $sanitized_fields = [];
        foreach ( $fields as $f ) {
            $f_name = sanitize_key( $f['name'] ?? '' );
            if ( $f_name ) {
                $sanitized_fields[] = [
                    'name'  => $f_name,
                    'label' => sanitize_text_field( $f['label'] ?? $f_name ),
                    'type'  => sanitize_key( $f['type'] ?? 'text' ),
                ];
            }
        }

        if ( $source === 'jet' ) {
            $boxes = get_option( 'jet_engine_meta_boxes', [] );
            if ( ! is_array( $boxes ) ) {
                $boxes = [];
            }
            $key = sanitize_key( $title );
            $meta_fields = [];
            foreach ( $sanitized_fields as $f ) {
                $meta_fields[] = [
                    'name'  => $f['name'],
                    'title' => $f['label'],
                    'type'  => $f['type'],
                ];
            }
            $new_box = [
                'id'           => $key,
                'name'         => $title,
                'args'         => [
                    'allowed_post_types' => $post_types,
                ],
                'meta_fields'  => $meta_fields,
            ];
            $found = false;
            foreach ( $boxes as &$b ) {
                if ( ( $b['id'] ?? '' ) === $key ) {
                    $b = $new_box;
                    $found = true;
                    break;
                }
            }
            if ( ! $found ) {
                $boxes[] = $new_box;
            }
            update_option( 'jet_engine_meta_boxes', $boxes );
        } else {
            if ( function_exists( 'acf_update_field_group' ) ) {
                $key = 'group_cs_' . sanitize_key( $title );
                $field_group = [
                    'key'      => $key,
                    'title'    => $title,
                    'location' => [],
                    'active'   => true,
                ];
                foreach ( $post_types as $pt ) {
                    $field_group['location'][] = [
                        [
                            'param'    => 'post_type',
                            'operator' => '==',
                            'value'    => $pt,
                        ]
                    ];
                }
                $group = acf_update_field_group( $field_group );
                if ( $group && isset( $group['ID'] ) ) {
                    $existing = acf_get_fields( $group['ID'] ) ?: [];
                    foreach ( $existing as $ef ) {
                        acf_delete_field( $ef['ID'] );
                    }
                    foreach ( $sanitized_fields as $f ) {
                        $f_key = 'field_' . sanitize_key( $group['key'] . '_' . $f['name'] );
                        acf_update_field([
                            'key'          => $f_key,
                            'parent'       => $group['ID'],
                            'name'         => $f['name'],
                            'label'        => $f['label'],
                            'type'         => $f['type'],
                        ]);
                    }
                }
            } else {
                $boxes = get_option( 'jet_engine_meta_boxes', [] );
                if ( ! is_array( $boxes ) ) {
                    $boxes = [];
                }
                $key = sanitize_key( $title );
                $meta_fields = [];
                foreach ( $sanitized_fields as $f ) {
                    $meta_fields[] = [
                        'name'  => $f['name'],
                        'title' => $f['label'],
                        'type'  => $f['type'],
                    ];
                }
                $new_box = [
                    'id'           => $key,
                    'name'         => $title,
                    'args'         => [
                        'allowed_post_types' => $post_types,
                    ],
                    'meta_fields'  => $meta_fields,
                ];
                $found = false;
                foreach ( $boxes as &$b ) {
                    if ( ( $b['id'] ?? '' ) === $key ) {
                        $b = $new_box;
                        $found = true;
                        break;
                    }
                }
                if ( ! $found ) {
                    $boxes[] = $new_box;
                }
                update_option( 'jet_engine_meta_boxes', $boxes );
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function delete_studio_fields( \WP_REST_Request $request ): \WP_REST_Response {
        $id = sanitize_key( $request->get_param( 'id' ) );

        if ( 0 === strpos( $id, 'jet-' ) ) {
            $key = substr( $id, 4 );
            $boxes = get_option( 'jet_engine_meta_boxes', [] );
            if ( is_array( $boxes ) ) {
                $filtered = [];
                foreach ( $boxes as $b ) {
                    if ( ( $b['id'] ?? '' ) !== $key ) {
                        $filtered[] = $b;
                    }
                }
                update_option( 'jet_engine_meta_boxes', $filtered );
            }
        } elseif ( 0 === strpos( $id, 'acf-' ) ) {
            $acf_id = (int) substr( $id, 4 );
            if ( function_exists( 'acf_delete_field_group' ) ) {
                acf_delete_field_group( $acf_id );
            } else {
                wp_delete_post( $acf_id, true );
            }
        } else {
            $boxes = get_option( 'jet_engine_meta_boxes', [] );
            if ( is_array( $boxes ) ) {
                $filtered = [];
                $found = false;
                foreach ( $boxes as $b ) {
                    if ( ( $b['id'] ?? '' ) === $id ) {
                        $found = true;
                    } else {
                        $filtered[] = $b;
                    }
                }
                if ( $found ) {
                    update_option( 'jet_engine_meta_boxes', $filtered );
                }
            }

            if ( function_exists( 'acf_delete_field_group' ) ) {
                acf_delete_field_group( $id );
            } else {
                $acf_id = (int) $id;
                if ( $acf_id ) {
                    wp_delete_post( $acf_id, true );
                }
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    private function studio_jet_to_acf_field_type( string $type ): string {
        $type = sanitize_key( $type );
        $map = [
            'text'      => 'text',
            'textarea'  => 'textarea',
            'wysiwyg'   => 'wysiwyg',
            'editor'    => 'wysiwyg',
            'number'    => 'number',
            'date'      => 'date_picker',
            'date_time' => 'date_time_picker',
            'datetime'  => 'date_time_picker',
            'time'      => 'time_picker',
            'media'     => 'image',
            'image'     => 'image',
            'gallery'   => 'gallery',
            'select'    => 'select',
            'radio'     => 'radio',
            'checkbox'  => 'checkbox',
            'switcher'  => 'true_false',
            'toggle'    => 'true_false',
            'colorpicker' => 'color_picker',
            'color'     => 'color_picker',
            'repeater'  => 'repeater',
        ];

        return $map[ $type ] ?? 'text';
    }

    private function studio_collect_jet_cpts(): array {
        $raw = get_option( 'jet_engine_cpt', [] );
        if ( ! is_array( $raw ) ) {
            return [];
        }

        $out = [];
        foreach ( $raw as $key => $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            $slug = sanitize_key( $item['slug'] ?? $item['post_type'] ?? $item['name'] ?? $key );
            if ( '' === $slug ) {
                continue;
            }
            $labels = is_array( $item['labels'] ?? null ) ? $item['labels'] : [];
            $plural = sanitize_text_field( $labels['name'] ?? $item['label'] ?? $item['title'] ?? ucwords( str_replace( [ '-', '_' ], ' ', $slug ) ) );
            $singular = sanitize_text_field( $labels['singular_name'] ?? $item['singular'] ?? $plural );
            $args = is_array( $item['args'] ?? null ) ? $item['args'] : [];
            $out[] = [
                'slug'     => $slug,
                'plural'   => $plural,
                'singular' => $singular,
                'public'   => isset( $args['public'] ) ? (bool) $args['public'] : true,
                'rest'     => isset( $args['show_in_rest'] ) ? (bool) $args['show_in_rest'] : true,
            ];
        }

        return $out;
    }

    private function studio_collect_jet_field_groups(): array {
        $boxes = get_option( 'jet_engine_meta_boxes', [] );
        if ( ! is_array( $boxes ) ) {
            return [];
        }

        $out = [];
        foreach ( $boxes as $index => $box ) {
            if ( ! is_array( $box ) ) {
                continue;
            }
            $id = sanitize_key( $box['id'] ?? $box['slug'] ?? $index );
            $title = sanitize_text_field( $box['name'] ?? $box['title'] ?? $id );
            $args = is_array( $box['args'] ?? null ) ? $box['args'] : [];
            $post_types = [];
            $allowed = $args['allowed_post_types'] ?? $args['post_types'] ?? $box['post_types'] ?? [];
            if ( is_string( $allowed ) ) {
                $allowed = [ $allowed ];
            }
            if ( is_array( $allowed ) ) {
                foreach ( $allowed as $pt ) {
                    $pt = sanitize_key( (string) $pt );
                    if ( $pt ) {
                        $post_types[] = $pt;
                    }
                }
            }
            if ( empty( $post_types ) ) {
                $post_types = [ 'post' ];
            }

            $fields = [];
            $raw_fields = is_array( $box['meta_fields'] ?? null ) ? $box['meta_fields'] : [];
            foreach ( $raw_fields as $field_index => $field ) {
                if ( ! is_array( $field ) ) {
                    continue;
                }
                $name = sanitize_key( $field['name'] ?? $field['id'] ?? $field['key'] ?? 'field_' . $field_index );
                if ( ! $name ) {
                    continue;
                }
                $fields[] = [
                    'name'  => $name,
                    'label' => sanitize_text_field( $field['title'] ?? $field['label'] ?? ucwords( str_replace( [ '-', '_' ], ' ', $name ) ) ),
                    'type'  => $this->studio_jet_to_acf_field_type( (string) ( $field['type'] ?? 'text' ) ),
                ];
            }

            $out[] = [
                'id'         => $id,
                'title'      => $title,
                'post_types' => array_values( array_unique( $post_types ) ),
                'fields'     => $fields,
            ];
        }

        return $out;
    }

    private function studio_jet_to_acf_plan(): array {
        return [
            'has_acf_fields_api' => function_exists( 'acf_update_field_group' ),
            'has_acf_cpt_api'    => function_exists( 'acf_update_post_type' ),
            'cpts'               => $this->studio_collect_jet_cpts(),
            'field_groups'       => $this->studio_collect_jet_field_groups(),
        ];
    }

    public function preview_jet_to_acf_migration(): \WP_REST_Response {
        $plan = $this->studio_jet_to_acf_plan();
        $plan['mode'] = 'preview';
        $plan['note'] = 'Preview only. Applying this creates ACF mirrors and does not delete JetEngine data.';
        return new \WP_REST_Response( $plan, 200 );
    }

    public function run_jet_to_acf_migration(): \WP_REST_Response {
        $plan = $this->studio_jet_to_acf_plan();
        if ( ! $plan['has_acf_fields_api'] ) {
            return new \WP_REST_Response( [
                'code'    => 'acf_unavailable',
                'message' => 'ACF field group APIs are not available. Activate ACF before running the JetEngine migration.',
            ], 400 );
        }

        $results = [
            'cpts'         => [],
            'field_groups' => [],
            'warnings'     => [],
        ];

        if ( ! $plan['has_acf_cpt_api'] ) {
            $results['warnings'][] = 'ACF post type API is unavailable, so CPT definitions were previewed but not mirrored.';
        } else {
            foreach ( $plan['cpts'] as $cpt ) {
                $updated = acf_update_post_type( [
                    'post_type'    => $cpt['slug'],
                    'title'        => $cpt['plural'],
                    'labels'       => [
                        'name'          => $cpt['plural'],
                        'singular_name' => $cpt['singular'],
                    ],
                    'active'       => true,
                    'public'       => $cpt['public'],
                    'show_in_rest' => $cpt['rest'],
                ] );
                $results['cpts'][] = [
                    'slug'    => $cpt['slug'],
                    'success' => ! empty( $updated ),
                ];
            }
        }

        foreach ( $plan['field_groups'] as $group ) {
            $group_key = 'group_mv_jet_' . sanitize_key( $group['id'] );
            $field_group = [
                'key'      => $group_key,
                'title'    => $group['title'],
                'location' => [],
                'active'   => true,
            ];
            foreach ( $group['post_types'] as $post_type ) {
                $field_group['location'][] = [
                    [
                        'param'    => 'post_type',
                        'operator' => '==',
                        'value'    => $post_type,
                    ],
                ];
            }
            $acf_group = acf_update_field_group( $field_group );
            $field_count = 0;
            if ( $acf_group && isset( $acf_group['ID'] ) ) {
                $existing = function_exists( 'acf_get_fields' ) ? acf_get_fields( $acf_group['ID'] ) : [];
                if ( is_array( $existing ) ) {
                    foreach ( $existing as $existing_field ) {
                        if ( isset( $existing_field['ID'] ) && function_exists( 'acf_delete_field' ) ) {
                            acf_delete_field( $existing_field['ID'] );
                        }
                    }
                }
                foreach ( $group['fields'] as $field ) {
                    acf_update_field( [
                        'key'    => 'field_mv_jet_' . sanitize_key( $group['id'] . '_' . $field['name'] ),
                        'parent' => $acf_group['ID'],
                        'name'   => $field['name'],
                        'label'  => $field['label'],
                        'type'   => $field['type'],
                    ] );
                    $field_count++;
                }
            }
            $results['field_groups'][] = [
                'id'          => $group['id'],
                'title'       => $group['title'],
                'field_count' => $field_count,
                'success'     => $field_count === count( $group['fields'] ),
            ];
        }

        return new \WP_REST_Response( [
            'success' => true,
            'results' => $results,
            'note'    => 'JetEngine data was left in place. Review ACF mirrors before disabling JetEngine.',
        ], 200 );
    }

    public function list_studio_plugins(): \WP_REST_Response {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins = get_plugins();
        $active = (array) get_option( 'active_plugins', [] );
        $auto_updates = (array) get_site_option( 'auto_update_plugins', [] );
        $updates = get_site_transient( 'update_plugins' );
        $response = is_object( $updates ) && isset( $updates->response ) && is_array( $updates->response ) ? $updates->response : [];
        $rows = [];

        foreach ( $plugins as $file => $data ) {
            $update = $response[ $file ] ?? null;
            $rows[] = [
                'file'             => $file,
                'slug'             => sanitize_key( dirname( $file ) === '.' ? basename( $file, '.php' ) : dirname( $file ) ),
                'name'             => $data['Name'] ?? $file,
                'description'      => wp_strip_all_tags( $data['Description'] ?? '' ),
                'author'           => wp_strip_all_tags( $data['Author'] ?? '' ),
                'version'          => $data['Version'] ?? '',
                'active'           => in_array( $file, $active, true ),
                'auto_update'      => in_array( $file, $auto_updates, true ),
                'update_available' => ! empty( $update ),
                'new_version'      => is_object( $update ) ? ( $update->new_version ?? '' ) : '',
                'update_url'       => ! empty( $update ) ? wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . urlencode( $file ) ), 'upgrade-plugin_' . $file ) : '',
            ];
        }

        usort( $rows, function( $a, $b ) {
            return strcasecmp( $a['name'], $b['name'] );
        } );

        return new \WP_REST_Response( [ 'plugins' => $rows ], 200 );
    }

    public function run_studio_plugin_action( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! function_exists( 'activate_plugin' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        $params = $request->get_json_params() ?: [];
        $plugin = plugin_basename( sanitize_text_field( $params['plugin'] ?? '' ) );
        $action = sanitize_key( $params['action'] ?? '' );

        if ( ! $this->can_run_plugin_action( $request ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'You are not allowed to perform this plugin action.' ], 403 );
        }

        if ( empty( $plugin ) || ! file_exists( WP_PLUGIN_DIR . '/' . $plugin ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Plugin not found.' ], 404 );
        }

        if ( $action === 'activate' ) {
            $result = activate_plugin( $plugin );
            if ( is_wp_error( $result ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
            }
            return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin activated.' ], 200 );
        }

        if ( $action === 'deactivate' ) {
            deactivate_plugins( [ $plugin ], false, false );
            return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin deactivated.' ], 200 );
        }

        if ( $action === 'auto_update_on' || $action === 'auto_update_off' ) {
            $list = (array) get_site_option( 'auto_update_plugins', [] );
            if ( $action === 'auto_update_on' ) {
                $list[] = $plugin;
                $list = array_values( array_unique( $list ) );
                update_site_option( 'auto_update_plugins', $list );
                return new \WP_REST_Response( [ 'success' => true, 'message' => 'Auto-update enabled.' ], 200 );
            }
            $list = array_values( array_diff( $list, [ $plugin ] ) );
            update_site_option( 'auto_update_plugins', $list );
            return new \WP_REST_Response( [ 'success' => true, 'message' => 'Auto-update disabled.' ], 200 );
        }

        if ( $action === 'delete' ) {
            if ( is_plugin_active( $plugin ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => 'Deactivate the plugin before deleting it.' ], 400 );
            }
            $result = delete_plugins( [ $plugin ] );
            if ( is_wp_error( $result ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
            }
            return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin deleted.' ], 200 );
        }

        return new \WP_REST_Response( [ 'success' => false, 'message' => 'Unknown plugin action.' ], 400 );
    }

    private function load_plugin_installer_dependencies(): void {
        if ( ! function_exists( 'plugins_api' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    }

    public function search_plugin_directory( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! current_user_can( 'install_plugins' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'You do not have permission to install plugins.' ], 403 );
        }

        $search = sanitize_text_field( (string) ( $request->get_param( 'search' ) ?: '' ) );
        $this->load_plugin_installer_dependencies();
        $args = [
            'per_page' => 12,
            'page'     => 1,
            'fields'   => [
                'short_description' => true,
                'description'       => false,
                'sections'          => false,
                'icons'             => true,
                'rating'            => true,
                'ratings'           => false,
                'downloaded'        => false,
                'active_installs'   => true,
                'last_updated'      => true,
                'homepage'          => true,
            ],
        ];
        if ( strlen( $search ) >= 2 ) {
            $args['search'] = $search;
        } else {
            $args['browse'] = 'popular';
        }
        $api = plugins_api( 'query_plugins', $args );

        if ( is_wp_error( $api ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $api->get_error_message(), 'plugins' => [] ], 400 );
        }

        $rows = [];
        foreach ( (array) ( $api->plugins ?? [] ) as $plugin ) {
            $rows[] = [
                'slug'              => sanitize_key( $plugin['slug'] ?? '' ),
                'name'              => wp_strip_all_tags( $plugin['name'] ?? '' ),
                'version'           => sanitize_text_field( $plugin['version'] ?? '' ),
                'author'            => wp_strip_all_tags( $plugin['author'] ?? '' ),
                'short_description' => wp_strip_all_tags( $plugin['short_description'] ?? '' ),
                'rating'            => isset( $plugin['rating'] ) ? (float) $plugin['rating'] : 0,
                'active_installs'   => isset( $plugin['active_installs'] ) ? absint( $plugin['active_installs'] ) : 0,
                'last_updated'      => sanitize_text_field( $plugin['last_updated'] ?? '' ),
                'homepage'          => esc_url_raw( $plugin['homepage'] ?? '' ),
                'icons'             => is_array( $plugin['icons'] ?? null ) ? array_map( 'esc_url_raw', $plugin['icons'] ) : [],
            ];
        }

        return new \WP_REST_Response( [ 'plugins' => $rows ], 200 );
    }

    public function install_directory_plugin( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! current_user_can( 'install_plugins' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'You do not have permission to install plugins.' ], 403 );
        }

        $params = $request->get_json_params() ?: [];
        $slug = sanitize_key( (string) ( $params['slug'] ?? '' ) );
        if ( empty( $slug ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Missing plugin slug.' ], 400 );
        }

        $this->load_plugin_installer_dependencies();
        $api = plugins_api( 'plugin_information', [
            'slug'   => $slug,
            'fields' => [ 'sections' => false ],
        ] );
        if ( is_wp_error( $api ) || empty( $api->download_link ) ) {
            $message = is_wp_error( $api ) ? $api->get_error_message() : 'Could not find plugin download URL.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        $skin = new \Automatic_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader( $skin );
        $result = $upgrader->install( $api->download_link );
        if ( is_wp_error( $result ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
        }
        if ( ! $result ) {
            $errors = $skin->get_errors();
            $message = is_wp_error( $errors ) && $errors->has_errors() ? $errors->get_error_message() : 'Plugin install failed.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin installed.' ], 200 );
    }

    public function upload_plugin_zip( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! current_user_can( 'install_plugins' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'You do not have permission to upload plugins.' ], 403 );
        }

        $files = $request->get_file_params();
        if ( empty( $files['plugin_zip'] ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Choose a plugin ZIP first.' ], 400 );
        }

        $this->load_plugin_installer_dependencies();
        $upload = wp_handle_upload( $files['plugin_zip'], [
            'test_form' => false,
            'mimes'     => [ 'zip' => 'application/zip' ],
        ] );
        if ( isset( $upload['error'] ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $upload['error'] ], 400 );
        }

        $skin = new \Automatic_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader( $skin );
        $result = $upgrader->install( $upload['file'] );
        @unlink( $upload['file'] );

        if ( is_wp_error( $result ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
        }
        if ( ! $result ) {
            $errors = $skin->get_errors();
            $message = is_wp_error( $errors ) && $errors->has_errors() ? $errors->get_error_message() : 'Plugin upload install failed.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin uploaded and installed.' ], 200 );
    }
}
