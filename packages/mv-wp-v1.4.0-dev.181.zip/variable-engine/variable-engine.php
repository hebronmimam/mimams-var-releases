<?php

/**

 * Plugin Name: Mimam's Var - WP

 * Description: A powerful system for managing CSS variables, generating utilities, and streamlining your workflow in WordPress and Bricks Builder.

 * Version: 1.4.0-dev.181
 * Author: Hebronmimam
 * Author URI: https://hebronmimam.com

 * Text Domain: variable-engine

 * Requires PHP: 7.4

 * Requires at least: 6.0

 */



defined( 'ABSPATH' ) || exit;



// ── Constants ──────────────────────────────────────────────────────────

define( 'VE_VERSION', '1.4.0-dev.181' );
define( 'VE_FILE', __FILE__ );

define( 'VE_DIR', plugin_dir_path( __FILE__ ) );

define( 'VE_URL', plugin_dir_url( __FILE__ ) );

define( 'VE_CSS_OUTPUT_DIR', wp_upload_dir()['basedir'] . '/variable-engine/' );

define( 'VE_CSS_OUTPUT_URL', wp_upload_dir()['baseurl'] . '/variable-engine/' );

define( 'VE_API_NAMESPACE', 'variable-engine/v1' );

// Infrastructure endpoints. These are NOT user settings — they exist only so a site can
// point MV at a different feed/licence host from wp-config.php:
//
//   define( 'VE_UPDATE_FEED_URL', 'https://…/manifest.json' );
//
// They default to EMPTY on purpose. Empty means "use the built-in per-channel feed"
// (Updater::CHANNEL_FEEDS), which is what resolves the Stable/Beta/Dev manifests and
// their raw.githubusercontent fallbacks. Hard-coding a bare repo URL here overrode the
// channel selection and broke updates in 1.3.349–1.3.366.
if ( ! defined( 'VE_UPDATE_FEED_URL' ) ) {
    define( 'VE_UPDATE_FEED_URL', '' );
}
if ( ! defined( 'VE_LICENSE_SERVER_URL' ) ) {
    define( 'VE_LICENSE_SERVER_URL', '' );
}

define( 'VE_IS_BRICKS', isset( $_GET['bricks'] ) );



// ── Autoload core classes ──────────────────────────────────────────────

require_once VE_DIR . 'core/Logger.php';
require_once VE_DIR . 'core/CanonicalJson.php';
require_once VE_DIR . 'core/ContentReadiness.php';

\VE\Core\Logger::register_fatal_handler();

require_once VE_DIR . 'database/Schema.php';

require_once VE_DIR . 'database/Migrations.php';

require_once VE_DIR . 'core/FluidValue.php';

require_once VE_DIR . 'core/Generators/GeneratorInterface.php';

require_once VE_DIR . 'core/Generators/ColorGenerator.php';
require_once VE_DIR . 'core/ImportedColorFamily.php';
require_once VE_DIR . 'core/SocialImage.php';

require_once VE_DIR . 'core/Generators/FluidScaleGenerator.php';

require_once VE_DIR . 'core/VariableManager.php';
// ThemeManager first: PaletteManager is now a deprecated alias that extends it.
require_once VE_DIR . 'core/ThemeManager.php';
require_once VE_DIR . 'core/PaletteManager.php';
require_once VE_DIR . 'core/ColorPaletteManager.php';

require_once VE_DIR . 'core/GeneratorEngine.php';

require_once VE_DIR . 'core/DependencyGraph.php';
require_once VE_DIR . 'core/FamilyRelationshipManager.php';

require_once VE_DIR . 'core/RenamePropagationManager.php';
require_once VE_DIR . 'core/VariableUsageManager.php';
require_once VE_DIR . 'core/MediaCollectionManager.php';
require_once VE_DIR . 'core/SiteVisibility.php';

require_once VE_DIR . 'core/CssExporter.php';

require_once VE_DIR . 'core/Updater.php';

require_once VE_DIR . 'core/ReleaseWebhook.php';

require_once VE_DIR . 'core/LicenseManager.php';

require_once VE_DIR . 'core/AdvancedCssManager.php';
// Code Studio's store. Loaded beside CSS Studio's for now: the migration reads
// the old option and the old file is still written, so both work during the
// transition rather than one replacing the other mid-flight.
require_once VE_DIR . 'core/CodeItemManager.php';
require_once VE_DIR . 'core/ClassLensManager.php';
require_once VE_DIR . 'core/RankMathAnalysisBridge.php';

require_once VE_DIR . 'core/MigrationScanner.php';
require_once VE_DIR . 'core/SettingsTransferManager.php';
require_once VE_DIR . 'core/VariableCategoryManager.php';

// ── Load the REST + sync layer only where it can actually run ──────────
// These 14 files are ~600KB of the ~985KB MV used to parse on EVERY request,
// including anonymous front-end page views that can never reach a REST route.
// Nothing in core/, modules/ or adapters/ references \VE\API\ or \VE\Sync\, so a
// plain front-end request can skip them entirely. Admin, AJAX, REST, the Bricks
// builder, cron and WP-CLI still load the full set.
$ve_rest_prefix = function_exists( 'rest_get_url_prefix' ) ? rest_get_url_prefix() : 'wp-json';
$ve_request_uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
$ve_is_rest     = ( defined( 'REST_REQUEST' ) && REST_REQUEST )
    || false !== strpos( $ve_request_uri, '/' . $ve_rest_prefix . '/' )
    || false !== strpos( $ve_request_uri, '/wp-json/' )
    // The OTHER shape of a REST request. With plain permalinks WordPress serves
    // the API at /index.php?rest_route=/... and that URI carries neither the
    // prefix as a path segment nor /wp-json/ - and REST_REQUEST is defined on
    // parse_request, long after plugins_loaded. So on a site with plain permalinks
    // none of the tests above fired, api/Routes.php was never required, and EVERY
    // variable-engine/v1 route 404'd while core's own wp/v2 routes answered on the
    // same page. It is the test WordPress itself uses in rest_api_loaded().
    || ! empty( $_GET['rest_route'] );
define( 'VE_NEEDS_API', is_admin()
    || $ve_is_rest
    || VE_IS_BRICKS
    || ( function_exists( 'wp_doing_ajax' ) ? wp_doing_ajax() : ( defined( 'DOING_AJAX' ) && DOING_AJAX ) )
    || ( defined( 'WP_CLI' ) && WP_CLI )
    || ( defined( 'DOING_CRON' ) && DOING_CRON ) );

if ( VE_NEEDS_API ) {
require_once VE_DIR . 'api/Routes.php';

require_once VE_DIR . 'api/VariableController.php';
require_once VE_DIR . 'api/PaletteController.php';
require_once VE_DIR . 'api/ThemeController.php';
require_once VE_DIR . 'api/ColorPaletteController.php';
require_once VE_DIR . 'api/VariableCategoryController.php';

require_once VE_DIR . 'api/GeneratorController.php';

require_once VE_DIR . 'api/SyncController.php';

require_once VE_DIR . 'sync/DiffEngine.php';

require_once VE_DIR . 'sync/SnapshotManager.php';

require_once VE_DIR . 'sync/SyncEngine.php';

require_once VE_DIR . 'sync/PortableBundleManager.php';

require_once VE_DIR . 'sync/PairingManager.php';
require_once VE_DIR . 'sync/DriftManager.php';
} // end VE_NEEDS_API

require_once VE_DIR . 'modules/builder-tools/MimamsBarModule.php';
// Do not load the bundled Recovery module if the standalone Recovery Studio test
// harness is already active: both declare VE\Modules\Recovery\* and require_once
// only de-duplicates by file path, so PHP fatals on the duplicate class. Mirrors the
// MimamsBarModule / BAQA_VERSION guard.
if ( ! class_exists( '\VE\Modules\Recovery\RecoveryModule', false ) ) {
    require_once VE_DIR . 'modules/recovery/RecoveryModule.php';
}
// Workspaces + Release & Deploy. Slice 1 is the workspace record only: no Bricks
// read or write, no overlay, no publish. See modules/workspaces/WorkspacesModule.php.
require_once VE_DIR . 'modules/workspaces/WorkspacesModule.php';

/* A workspace preview link is an ordinary front-end URL, and the front end does
   NOT load the REST layer - so the module that owns previews is never booted
   there (see VE_NEEDS_API above) and the link simply rendered the home page.
   That is what the owner saw, logged in and logged out alike, after previews
   moved off REST.

   Registered on its own, outside that gate, and only when the argument is
   actually present - so an ordinary page load pays one isset() and nothing more,
   and the file that answers the link is loaded only when a link is being used. */
/* The literal, not the class constant: the class is not loaded yet, and naming
   it here would fatal on every front-end request. WorkspacePreview::QUERY_VAR
   is asserted against this string by check-workspace-preview.php so the two
   cannot drift apart silently. */
if ( isset( $_GET['mv_preview'] ) ) {
    require_once VE_DIR . 'modules/workspaces/app/WorkspacePreview.php';
    if ( ! \VE\Modules\Workspaces\WorkspacesModule::is_disabled() ) {
        add_action(
            'template_redirect',
            [ '\VE\Modules\Workspaces\WorkspacePreview', 'handle_request' ],
            0
        );
    }
}
require_once VE_DIR . 'adapters/bricks/VariablesMirror.php';
// R47: a variable changed in Bricks' own panel flows back into MV.
\VE\Adapters\Bricks\VariablesMirror::register();
// A shared link keeps its picture: Rank Math's og:image under WhatsApp's weight limit.
\VE\Core\SocialImage::register();
require_once VE_DIR . 'adapters/bricks/BricksAdapter.php';
require_once VE_DIR . 'adapters/AdminAdapter.php';



// ── Activation / Deactivation ──────────────────────────────────────────

register_activation_hook( VE_FILE, function () {

    \VE\Core\Logger::info( 'activation_start' );

    try {

        \VE\Database\Migrations::run();

        \VE\Core\Logger::info( 'activation_complete' );

    } catch ( \Throwable $e ) {

        \VE\Core\Logger::error( 'activation_exception', [

            'message' => $e->getMessage(),

            'file'    => $e->getFile(),

            'line'    => $e->getLine(),

        ] );

        throw $e;

    }

} );



// ── Init ───────────────────────────────────────────────────────────────

add_action( 'plugins_loaded', function () {

    \VE\Core\Logger::info( 'plugins_loaded' );

    \VE\Database\Migrations::maybe_run();

    ( new \VE\Core\Updater() )->register();

    ( new \VE\Core\ReleaseWebhook() )->register();

    ( new \VE\Core\MediaCollectionManager() )->register();
    ( new \VE\Core\SiteVisibility() )->register();



    // Boot REST API routes. Skipped on plain front-end requests, where the REST
    // layer is not loaded at all (see VE_NEEDS_API above).

    if ( VE_NEEDS_API && class_exists( '\VE\API\Routes' ) ) {
        $ve_routes = new \VE\API\Routes();
        $ve_routes->register();

        // Workspaces reuses those permission callbacks rather than defining a
        // second capability model. Gated the way the other modules are.
        if ( class_exists( '\VE\Modules\Workspaces\WorkspacesModule' )
            && ! \VE\Modules\Workspaces\WorkspacesModule::is_disabled() ) {
            \VE\Modules\Workspaces\WorkspacesModule::init( $ve_routes );
        }
    }



    // Boot adapters — mutually exclusive.

    if ( VE_IS_BRICKS ) {

        new \VE\Adapters\BricksAdapter();

    } else if ( is_admin() ) {

        new \VE\Adapters\AdminAdapter();

    }

} );



// ── Enqueue generated CSS on frontend ──────────────────────────────────

add_action( 'wp_enqueue_scripts', function () {

    $css_file = VE_CSS_OUTPUT_DIR . 'variables.css';

    if ( file_exists( $css_file ) ) {

        wp_enqueue_style(

            've-variables',

            VE_CSS_OUTPUT_URL . 'variables.css',

            [],

            filemtime( $css_file )

        );

    }

    $advanced_file = VE_CSS_OUTPUT_DIR . 'advanced.css';

    /* C27, 2026-09-24. Once Code Studio has taken over, `advanced.css` is its
       legacy copy of Everywhere AND Site-only items, kept for anything outside
       MV still loading it. Loaded inside Bricks it put Site-only CSS into the
       builder; code-studio-global.css already carries Everywhere there. */
    if ( file_exists( $advanced_file ) && ! ( ve_code_studio_in_builder() && get_option( 've_code_items_migrated_from_css_studio', '' ) ) ) {

        wp_enqueue_style(

            've-advanced-css',

            VE_CSS_OUTPUT_URL . 'advanced.css',

            [],

            filemtime( $advanced_file )

        );

    }

}, 1 ); // Priority 1 — load before everything else.



// ── Code Studio's compiled files ─────────────────────────────────────

/* Written by CodeItemManager::compile(). Until this, Code Studio wrote files
   nobody loaded: everywhere/site-only on the front end, everywhere/builder-only
   inside Bricks, and the page file only on the page it belongs to. */
function ve_code_studio_enqueue( array $destinations ): void {
    foreach ( $destinations as $destination ) {
        $file = VE_CSS_OUTPUT_DIR . 'code-studio-' . $destination . '.css';
        if ( ! file_exists( $file ) ) {
            continue;
        }
        wp_enqueue_style(
            've-code-studio-' . $destination,
            VE_CSS_OUTPUT_URL . 'code-studio-' . $destination . '.css',
            ve_code_studio_after(),
            filemtime( $file )
        );
    }
}

/* 2026-09-24, found checking C18 on test7: `:root { --mv-live-test: blue }` in a
   page's Code Studio sheet did nothing on the site - it resolved to MV's red.
   Bricks prints its global variables, MV's mirrored copies among them, in its
   own inline style at wp_enqueue_scripts 11, AFTER Code Studio's sheets, so
   Bricks' copy won every tie. What the owner writes in Code Studio has the last
   word now: its sheets are enqueued after Bricks' inline style, and depend on
   it when Bricks has registered it (only then, or a site without Bricks would
   lose them). */
function ve_code_studio_after(): array {
    return function_exists( 'wp_style_is' ) && wp_style_is( 'bricks-frontend-inline', 'registered' )
        ? [ 'bricks-frontend-inline' ] : [];
}

/** Inside the Bricks builder (its window or its canvas). */
function ve_code_studio_in_builder(): bool {
    return function_exists( 'bricks_is_builder' ) && bricks_is_builder();
}

add_action( 'wp_enqueue_scripts', function () {
    /* C27, 2026-09-24: "Site only" is the site and not the builder. Measured on
       test7: code-studio-frontend.css was loaded in the builder window and its
       canvas alike. */
    ve_code_studio_enqueue( ve_code_studio_in_builder() ? [ 'global' ] : [ 'global', 'frontend' ] );

    $page_id = get_queried_object_id();
    if ( ! $page_id ) {
        return;
    }
    $page_file = VE_CSS_OUTPUT_DIR . 'code-studio-page-' . (int) $page_id . '.css';
    if ( ! file_exists( $page_file ) ) {
        return;
    }
    wp_enqueue_style(
        've-code-studio-page-' . (int) $page_id,
        VE_CSS_OUTPUT_URL . 'code-studio-page-' . (int) $page_id . '.css',
        ve_code_studio_after(),
        filemtime( $page_file )
    );
}, 12 );

/* Inside Bricks, where builder-only CSS is the point of that destination. */
add_action( 'wp_enqueue_scripts', function () {
    if ( ! function_exists( 'bricks_is_builder' ) || ! bricks_is_builder() ) {
        return;
    }
    ve_code_studio_enqueue( [ 'builder' ] );
}, 12 );

// ── Also load in the editor/builder ────────────────────────────────────

add_action( 'admin_enqueue_scripts', function () {

    if ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'variable-engine' ) {

        return;

    }

    $css_file = VE_CSS_OUTPUT_DIR . 'variables.css';

    if ( file_exists( $css_file ) ) {

        wp_enqueue_style(

            've-variables-admin',

            VE_CSS_OUTPUT_URL . 'variables.css',

            [],

            filemtime( $css_file )

        );

    }

    $advanced_file = VE_CSS_OUTPUT_DIR . 'advanced.css';

    if ( file_exists( $advanced_file ) ) {

        wp_enqueue_style(

            've-advanced-css-admin',

            VE_CSS_OUTPUT_URL . 'advanced.css',

            [],

            filemtime( $advanced_file )

        );

    }

} );



// ── Security plugin compatibility for VE REST API ────────────────────

// Ensures Variable Engine API works regardless of security plugin restrictions.



// 1. Handle CORS preflight BEFORE anything else (must be earliest hook).

add_action( 'plugins_loaded', function () {

    $uri = $_SERVER['REQUEST_URI'] ?? '';

    if ( strpos( $uri, 'variable-engine' ) === false ) return;

    if ( strpos( $uri, '/wp-json/' ) === false && strpos( $uri, 'rest_route' ) === false ) return;



    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';

    // SECURITY: never combine a reflected/wildcard origin with Allow-Credentials — that
    // lets any website make cookie-authenticated requests to a logged-in admin's VE API.
    // Only the first-party origin(s) may send credentials (cookies); everyone else (the
    // Figma plugin authenticates with X-VE-Key, not cookies) gets a credential-less
    // wildcard, and the routes still enforce their own auth.
    $ve_cors_allowed_hosts = array_values( array_filter( array_map( static function ( $url ) {
        return $url ? wp_parse_url( $url, PHP_URL_HOST ) : '';
    }, apply_filters( 've_cors_allowed_origins', [ home_url(), site_url() ] ) ) ) );
    $origin_host = $origin ? wp_parse_url( $origin, PHP_URL_HOST ) : '';

    if ( '' !== $origin && '' !== (string) $origin_host && in_array( $origin_host, $ve_cors_allowed_hosts, true ) ) {
        header( 'Access-Control-Allow-Origin: ' . $origin );
        header( 'Access-Control-Allow-Credentials: true' );
        header( 'Vary: Origin' );
    } else {
        header( 'Access-Control-Allow-Origin: *' );
    }

    header( 'Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS' );

    header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-VE-Key' );

    header( 'Access-Control-Max-Age: 86400' );



    if ( isset( $_SERVER['REQUEST_METHOD'] ) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS' ) {

        status_header( 200 );

        exit;

    }

}, 0 ); // Priority 0 = before security plugins



// 2. Whitelist VE namespace for Solid Security / iThemes Security.

//    This tells Solid Security to allow unauthenticated access to our routes.

add_filter( 'itsec_rest_api_restricted', function ( $is_restricted, $route ) {

    if ( 0 === strpos( (string) $route, '/variable-engine/v1/' ) ) {

        return false; // Not restricted

    }

    return $is_restricted;

}, 10, 2 );



// 3. Allow VE API key authenticated requests through WordPress REST auth.

//    This intercepts BEFORE security plugins reject the request.

add_filter( 'rest_authentication_errors', function ( $result ) {

    // Only handle the exact VE REST namespace. A query-string substring must
    // never turn an unrelated WordPress REST request into an integration call.

    $uri        = isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
    $path       = (string) wp_parse_url( $uri, PHP_URL_PATH );
    $rest_route = isset( $_GET['rest_route'] ) ? wp_unslash( $_GET['rest_route'] ) : '';
    $is_ve_api  = (bool) preg_match( '#/wp-json/variable-engine/v1(?:/|$)#', $path )
        || (bool) preg_match( '#^/variable-engine/v1(?:/|$)#', (string) $rest_route );

    if ( ! $is_ve_api ) return $result;



    // Check for X-VE-Key header.

    $key = '';

    if ( isset( $_SERVER['HTTP_X_VE_KEY'] ) ) {

        $key = $_SERVER['HTTP_X_VE_KEY'];

    }



    if ( $key ) {

        $stored = get_option( 've_sync_api_key' );

        if ( $stored && hash_equals( $stored, $key ) ) {
            // Let the request reach VE's route-level permission callback. The
            // integration key is never mapped to a WordPress user or capability.
            return true;

        }

    }



    return $result;

}, 1 ); // Priority 1 = before security plugins (they typically use 10+)



// 4. Also whitelist for Wordfence (uses a different filter).

add_filter( 'wordfence_ls_require_captcha', function ( $require, $action ) {

    $uri = $_SERVER['REQUEST_URI'] ?? '';

    if ( strpos( $uri, 'variable-engine' ) !== false ) return false;

    return $require;

}, 10, 2 );



// 5. Ensure CORS headers on actual REST responses too.

add_action( 'rest_api_init', function () {

    remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );

    add_filter( 'rest_pre_serve_request', function ( $value ) {

        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';

        // SECURITY: same rule as the preflight handler — a reflected origin may never be
        // paired with Allow-Credentials. Only first-party origins get credentialed access;
        // API-key callers (Figma) get a credential-less wildcard.
        $ve_cors_allowed_hosts = array_values( array_filter( array_map( static function ( $url ) {
            return $url ? wp_parse_url( $url, PHP_URL_HOST ) : '';
        }, apply_filters( 've_cors_allowed_origins', [ home_url(), site_url() ] ) ) ) );
        $origin_host = $origin ? wp_parse_url( $origin, PHP_URL_HOST ) : '';

        if ( '' !== $origin && '' !== (string) $origin_host && in_array( $origin_host, $ve_cors_allowed_hosts, true ) ) {
            header( 'Access-Control-Allow-Origin: ' . $origin );
            header( 'Access-Control-Allow-Credentials: true' );
            header( 'Vary: Origin' );
        } else {
            header( 'Access-Control-Allow-Origin: *' );
        }

        header( 'Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS' );

        header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-VE-Key' );

        return $value;

    });

}, 15 );



// 6. Whitelist for WP Cerber (another common security plugin).

add_filter( 'cerber_exception', function ( $allow, $uri ) {

    if ( strpos( $uri, 'variable-engine' ) !== false ) return true;

    return $allow;

}, 10, 2 );

// Recovery module (backup / restore / migrate). Self-gates on capability and the
// ve_settings deactivated-tools list, so it stays inert until enabled.
add_action( 'plugins_loaded', function () {
    if ( class_exists( '\VE\Modules\Recovery\RecoveryModule' ) ) {
        \VE\Modules\Recovery\RecoveryModule::init( VE_FILE );
    }
}, 20 );

/* R13. The CSS autocomplete index is built here, by cron, and nowhere else.
   It used to be built inside whichever REST request happened to find the cache
   cold - 1,419ms of MV's own time on a screen that was not going to use it. */
add_action( 've_build_css_suggestion_index', function () {
    if ( class_exists( '\VE\Core\AdvancedCssManager' ) ) {
        ( new \VE\Core\AdvancedCssManager() )->build_index();
    }
} );

// 7. Add extra links to plugin row meta
add_filter( 'plugin_row_meta', function ( $plugin_meta, $plugin_file ) {
    if ( strpos( $plugin_file, 'variable-engine.php' ) !== false ) {
        $user_guide_url = 'https://www.notion.so/Mimam-s-Bar-Complete-User-Documentation-3797562bd31a811188d1d81512267a2b';
        $plugin_meta[] = '<a href="' . esc_url( $user_guide_url ) . '" target="_blank">' . __( 'User Guide', 'variable-engine' ) . '</a>';
        $plugin_meta[] = '<a href="https://hebronmimam.com" target="_blank">' . __( 'Support', 'variable-engine' ) . '</a>';
        $plugin_meta[] = '<a href="https://hebronmimam.com" target="_blank">' . __( 'FAQs', 'variable-engine' ) . '</a>';
        $plugin_meta[] = '<a href="https://hebronmimam.com" target="_blank">' . __( 'Cheat Sheet', 'variable-engine' ) . '</a>';
    }
    return $plugin_meta;
}, 10, 2 );
