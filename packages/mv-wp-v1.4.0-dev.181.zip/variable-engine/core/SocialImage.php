<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * A link shared on WhatsApp shows its picture.
 *
 * 2026-09-24, the owner: "open graph images don't show on whatsapp again".
 * Rank Math gives `og:image` the featured image at full size when it fits its
 * 2000px limit, and kryptfo's featured images are 2000px WebP files of 650 KB
 * to 1 MB - every post since 17 September. WhatsApp leaves out a preview image
 * that heavy. WordPress already holds smaller copies of the same image (a
 * 1024px one at 160 KB on the post that was reported), and none of them was
 * being offered.
 *
 * So when the image Rank Math chose is heavier than the limit, the largest copy
 * of the SAME image that is under it is offered instead, with its own width,
 * height and type, so the tags stay true. A copy narrower than 600px is not
 * offered - that is below what Facebook shows as a large card - and if nothing
 * qualifies, Rank Math's choice stands. Only the Open Graph image changes;
 * X/Twitter takes files up to 5 MB and keeps the original.
 */
class SocialImage {

    /** WhatsApp's practical ceiling for a link preview image. */
    public const MAX_BYTES = 300 * 1024;

    /** Narrower than this is not worth offering as a share image. */
    public const MIN_WIDTH = 600;

    public static function register(): void {
        add_filter( 'rank_math/opengraph/facebook/image_array', [ self::class, 'lighter' ], 20 );
    }

    /**
     * @param mixed $image Rank Math's chosen image: id, url, width, height, type, alt.
     * @return mixed
     */
    public static function lighter( $image ) {
        if ( ! is_array( $image ) || empty( $image['id'] ) || empty( $image['url'] ) ) {
            return $image;
        }
        $id   = (int) $image['id'];
        $meta = wp_get_attachment_metadata( $id );
        $file = (string) get_attached_file( $id );
        if ( ! is_array( $meta ) || '' === $file ) {
            return $image;
        }
        $limit = (int) apply_filters( 've_social_image_max_bytes', self::MAX_BYTES );
        $copy  = self::choose( $meta, dirname( $file ), (string) $image['url'], $limit );
        if ( null === $copy ) {
            return $image;
        }
        $src = wp_get_attachment_image_src( $id, $copy['size'] );
        if ( ! is_array( $src ) || empty( $src[0] ) ) {
            return $image;
        }
        $image['url']    = $src[0];
        $image['width']  = (int) $copy['width'];
        $image['height'] = (int) $copy['height'];
        if ( '' !== $copy['type'] ) {
            $image['type'] = $copy['type'];
        }
        return $image;
    }

    /**
     * Which copy to offer instead, or null to keep the one chosen.
     *
     * @param array  $meta   Attachment metadata (file, filesize, sizes).
     * @param string $dir    Directory the files are in.
     * @param string $chosen URL of the image Rank Math chose.
     * @return array{size:string,width:int,height:int,type:string,bytes:int}|null
     */
    public static function choose( array $meta, string $dir, string $chosen, int $limit ): ?array {
        $name  = wp_basename( (string) strtok( $chosen, '?' ) );
        $bytes = null;
        if ( $name === wp_basename( (string) ( $meta['file'] ?? '' ) ) ) {
            $bytes = self::bytes( $meta, $dir . '/' . $name );
        } else {
            foreach ( (array) ( $meta['sizes'] ?? [] ) as $size ) {
                if ( is_array( $size ) && $name === (string) ( $size['file'] ?? '' ) ) {
                    $bytes = self::bytes( $size, $dir . '/' . $name );
                    break;
                }
            }
        }
        if ( null === $bytes || $bytes <= $limit ) {
            return null;
        }

        $best = null;
        foreach ( (array) ( $meta['sizes'] ?? [] ) as $key => $size ) {
            if ( ! is_array( $size ) || empty( $size['file'] ) ) {
                continue;
            }
            $w = (int) ( $size['width'] ?? 0 );
            $h = (int) ( $size['height'] ?? 0 );
            if ( $w < self::MIN_WIDTH || $h <= 0 ) {
                continue;
            }
            $b = self::bytes( $size, $dir . '/' . $size['file'] );
            if ( null === $b || $b > $limit ) {
                continue;
            }
            if ( null === $best || $w > $best['width'] ) {
                $best = [
                    'size'   => (string) $key,
                    'width'  => $w,
                    'height' => $h,
                    'type'   => (string) ( $size['mime-type'] ?? '' ),
                    'bytes'  => $b,
                ];
            }
        }
        return $best;
    }

    /** Recorded file size, else the file on disk, else unknown. */
    private static function bytes( array $entry, string $path ): ?int {
        if ( isset( $entry['filesize'] ) && (int) $entry['filesize'] > 0 ) {
            return (int) $entry['filesize'];
        }
        return is_file( $path ) ? (int) filesize( $path ) : null;
    }
}
