<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

class AdvancedCssManager {

    private const OPTION = 've_advanced_css';

    public function get(): array {
        $data = get_option( self::OPTION, [] );
        if ( ! is_array( $data ) ) {
            $data = [];
        }

        $sheets = $data['stylesheets'] ?? [];
        if ( ! is_array( $sheets ) || empty( $sheets ) ) {
            $sheets = $this->default_sheets();
        }

        return [
            'stylesheets' => array_values( array_map( [ $this, 'normalize_sheet' ], $sheets ) ),
            'file_url'    => $this->file_url(),
            'file_path'   => $this->file_path(),
        ];
    }

    public function save( array $sheets ): array {
        $clean = [];
        foreach ( $sheets as $sheet ) {
            if ( ! is_array( $sheet ) ) {
                continue;
            }
            $clean[] = $this->normalize_sheet( $sheet );
        }

        if ( empty( $clean ) ) {
            $clean = $this->default_sheets();
        }

        update_option( self::OPTION, [ 'stylesheets' => $clean ], false );
        $this->compile();

        return $this->get();
    }

    public function suggestions( bool $refresh = false ): array {
        global $wpdb;

        $classes = [];
        $ids     = [];
        $vars    = [];
        $variable_meta = [];
        $selectors = [];
        $class_map = $this->global_class_map();
        $cached  = get_transient( 've_advanced_css_suggestions_scan_v16' );

        $var_table = Schema::table( 'variables' );
        $rows = $wpdb->get_results( "SELECT name, value, css_value FROM {$var_table} ORDER BY name ASC", ARRAY_A ) ?: [];
        $manager = new VariableManager();
        foreach ( $rows as $row ) {
            $name = (string) ( $row['name'] ?? '' );
            if ( '' !== $name ) {
                $css_name = $manager->to_css_name( $name );
                $vars[] = $css_name;
                $variable_meta[ $css_name ] = [
                    'value'  => (string) ( $row['css_value'] ?: $row['value'] ?: '' ),
                    'source' => "Mimam's Var",
                ];
            }
        }

        if ( $refresh ) {
            delete_transient( 've_advanced_css_suggestions_scan_v12' );
            delete_transient( 've_advanced_css_suggestions_scan_v13' );
            delete_transient( 've_advanced_css_suggestions_scan_v14' );
            delete_transient( 've_advanced_css_suggestions_scan_v15' );
            delete_transient( 've_advanced_css_suggestions_scan_v16' );
            $cached = false;
        }

        if ( is_array( $cached ) ) {
            $variables = $this->sorted_keys( array_merge( $vars, $cached['variables'] ?? [] ) );
            $variable_meta = array_merge( $cached['variable_meta'] ?? [], $variable_meta );
            return [
                'variables'  => $variables,
                'variable_meta' => $variable_meta,
                'classes'    => $cached['classes'] ?? [],
                'ids'        => $cached['ids'] ?? [],
                'selectors'  => $cached['selectors'] ?? [],
                'sources'    => $cached['sources'] ?? [ "Mimam's Var" ],
                'counts'     => [
                    'variables' => count( $variables ),
                    'classes'   => count( $cached['classes'] ?? [] ),
                    'ids'       => count( $cached['ids'] ?? [] ),
                    'selectors' => count( $cached['selectors'] ?? [] ),
                ],
                'cached'     => true,
                'scanned_at' => $cached['scanned_at'] ?? 0,
            ];
        }

        $scan_text = [];
        $posts = $wpdb->get_col(
             "SELECT post_content FROM {$wpdb->posts}
             WHERE post_status NOT IN ('trash','auto-draft')
             ORDER BY post_modified_gmt DESC
             LIMIT 2000"
        ) ?: [];
        $scan_text = array_merge( $scan_text, $posts );

        $meta_rows = $wpdb->get_col(
            "SELECT meta_value FROM {$wpdb->postmeta}
             WHERE meta_key LIKE '_bricks_%'
                OR meta_key LIKE 'bricks_%'
                OR meta_key LIKE '%global%class%'
             ORDER BY meta_id DESC
             LIMIT 5000"
        ) ?: [];
        $scan_text = array_merge( $scan_text, $meta_rows );

        $option_rows = $wpdb->get_col(
            "SELECT option_value FROM {$wpdb->options}
             WHERE option_name IN ('bricks_global_classes','bricks_global_variables','bricks_theme_styles')
                OR option_name LIKE '%global_classes%'
                OR option_name LIKE '%global%classes%'
                OR option_name = 've_advanced_css'
             LIMIT 1500"
        ) ?: [];
        $scan_text = array_merge( $scan_text, $option_rows );
        // Autocomplete indexes authored site data only. Generated CSS, theme
        // and plugin source files, templates and third-party snippet tables
        // contain implementation selectors that are not meaningful choices
        // for the site author.
        $this->collect_scan_class_map( $scan_text, $class_map );
        foreach ( $class_map as $class_name ) {
            $this->add_identifier( $classes, (string) $class_name, '.' );
        }

        foreach ( $scan_text as $text ) {
            $text = maybe_unserialize( $text );
            if ( is_array( $text ) || is_object( $text ) ) {
                $this->extract_identifiers_from_data( $text, $classes, $ids, $vars, $class_map );
                $text = wp_json_encode( $text );
            }
            $text = substr( (string) $text, 0, 250000 );
            if ( '' === $text ) {
                continue;
            }

            $decoded = json_decode( $text, true );
            if ( is_array( $decoded ) ) {
                $this->extract_identifiers_from_data( $decoded, $classes, $ids, $vars, $class_map );
            }

            $this->extract_css_custom_properties( $text, $vars );
            $this->extract_bricks_class_records( $text, $classes );
            $this->extract_css_selectors( $text, $classes, $ids, $selectors );

            if ( preg_match_all( '/class(?:Name)?=["\']([^"\']+)["\']/i', $text, $matches ) ) {
                foreach ( $matches[1] as $match ) {
                    foreach ( preg_split( '/\s+/', $match ) as $class ) {
                        $this->add_identifier( $classes, $class, '.' );
                    }
                }
            }

            if ( preg_match_all( '/"class(?:Name)?"\s*:\s*"([^"]+)"/i', $text, $matches ) ) {
                foreach ( $matches[1] as $match ) {
                    foreach ( preg_split( '/\s+/', $match ) as $class ) {
                        $this->add_identifier( $classes, $class, '.' );
                    }
                }
            }

            if ( preg_match_all( '/id=["\']([A-Za-z][A-Za-z0-9_-]*)["\']/i', $text, $matches ) ) {
                foreach ( $matches[1] as $id ) {
                    $this->add_identifier( $ids, $id, '#' );
                }
            }

            if ( preg_match_all( '/"id"\s*:\s*"([A-Za-z][A-Za-z0-9_-]*)"/i', $text, $matches ) ) {
                foreach ( $matches[1] as $id ) {
                    $this->add_identifier( $ids, $id, '#' );
                }
            }

            if ( preg_match_all( '/\.([A-Za-z_][A-Za-z0-9_-]*)/', $text, $matches ) ) {
                foreach ( $matches[1] as $class ) {
                    $this->add_identifier( $classes, $class, '.' );
                }
            }

            if ( preg_match_all( '/#([A-Za-z_][A-Za-z0-9_-]*)/', $text, $matches ) ) {
                foreach ( $matches[1] as $id ) {
                    $this->add_identifier( $ids, $id, '#' );
                }
            }
        }

        $migration_scanner = new MigrationScanner();
        foreach ( $migration_scanner->scan( 'all' ) as $external_var ) {
            if ( ! empty( $external_var['name'] ) ) {
                $css_name = $manager->to_css_name( (string) $external_var['name'] );
                $vars[] = $css_name;
                $external_value = (string) ( $external_var['value'] ?? '' );
                if ( '' !== $external_value ) {
                    $source = (string) ( $external_var['category_slug'] ?? 'Sheet' );
                    if ( 'advanced-themer' === $source ) {
                        $source = 'Bricks';
                    } elseif ( 'core-framework' === $source ) {
                        $source = 'Core Framework';
                    } elseif ( 'automatic-css' === $source ) {
                        $source = 'Automatic.css';
                    }
                    $variable_meta[ $css_name ] = [
                        'value'  => $external_value,
                        'source' => $source,
                    ];
                }
            }
        }

        $sources = $migration_scanner->sources();
        $source_labels = [ "Mimam's Var" ];
        foreach ( $sources as $source ) {
            if ( ! empty( $source['available'] ) ) {
                if ( 'Bricks / Advanced Themer' === $source['name'] ) {
                    $source_labels[] = 'Bricks';
                    $source_labels[] = 'Advanced Themer';
                } else {
                    $source_labels[] = (string) $source['name'];
                }
            }
        }
        if ( ! empty( $classes ) ) {
            $source_labels[] = 'CSS Classes';
        }
        if ( ! empty( $ids ) ) {
            $source_labels[] = 'Element IDs';
        }
        if ( ! empty( $selectors ) ) {
            $source_labels[] = 'CSS Selectors';
        }

        $scan = [
            'variables' => $this->sorted_keys( $vars ),
            'variable_meta' => $variable_meta,
            'classes' => $this->sorted_keys( array_keys( $classes ) ),
            'ids'     => $this->sorted_keys( array_keys( $ids ) ),
            'selectors' => $this->sorted_keys( array_keys( $selectors ) ),
            'sources' => array_values( array_unique( $source_labels ) ),
            'scanned_at' => time(),
        ];
        set_transient( 've_advanced_css_suggestions_scan_v16', $scan, 5 * MINUTE_IN_SECONDS );

        return [
            'variables'  => $scan['variables'],
            'variable_meta' => $variable_meta,
            'classes'    => $scan['classes'],
            'ids'        => $scan['ids'],
            'selectors'  => $scan['selectors'],
            'sources'    => $scan['sources'],
            'counts'     => [
                'variables' => count( $scan['variables'] ),
                'classes'   => count( $scan['classes'] ),
                'ids'       => count( $scan['ids'] ),
                'selectors' => count( $scan['selectors'] ),
            ],
            'cached'     => false,
            'scanned_at' => $scan['scanned_at'],
        ];
    }

    public function compile(): array {
        $data   = $this->get();
        $sheets = $data['stylesheets'];
        $lines  = [
            '/*',
            " * Mimam's Var - CSS Studio",
            ' * Version: ' . VE_VERSION,
            ' * Compiled: ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC',
            ' */',
            '',
        ];

        foreach ( $sheets as $sheet ) {
            if ( empty( $sheet['enabled'] ) || '' === trim( (string) $sheet['css'] ) ) {
                continue;
            }
            $lines[] = '/* === ' . $sheet['name'] . ' (' . $sheet['scope'] . ') === */';
            $lines[] = rtrim( (string) $sheet['css'] );
            $lines[] = '';
        }

        if ( ! is_dir( VE_CSS_OUTPUT_DIR ) ) {
            wp_mkdir_p( VE_CSS_OUTPUT_DIR );
        }

        $written = file_put_contents( $this->file_path(), implode( "\n", $lines ) );

        return [
            'compiled'  => false !== $written,
            'file_url'  => $this->file_url(),
            'file_path' => $this->file_path(),
        ];
    }

    private function normalize_sheet( array $sheet ): array {
        $id = sanitize_key( (string) ( $sheet['id'] ?? '' ) );
        if ( '' === $id ) {
            $id = 'sheet_' . substr( md5( wp_json_encode( $sheet ) . microtime( true ) ), 0, 8 );
        }

        $scope = sanitize_key( (string) ( $sheet['scope'] ?? 'global' ) );
        if ( ! in_array( $scope, [ 'page', 'global', 'child', 'custom', 'recipe' ], true ) ) {
            $scope = 'custom';
        }

        return [
            'id'      => $id,
            'name'    => sanitize_text_field( (string) ( $sheet['name'] ?? 'custom.css' ) ),
            'scope'   => $scope,
            'enabled' => ! isset( $sheet['enabled'] ) || ! empty( $sheet['enabled'] ),
            'css'     => wp_kses_post( (string) ( $sheet['css'] ?? '' ) ),
        ];
    }

    private function default_sheets(): array {
        return [
            [ 'id' => 'global', 'name' => 'global.css', 'scope' => 'global', 'enabled' => true, 'css' => '' ],
        ];
    }

    private function add_identifier( array &$bucket, string $value, string $prefix ): void {
        $value = trim( html_entity_decode( $value, ENT_QUOTES, 'UTF-8' ) );
        $value = trim( $value, ".# \t\n\r\0\x0B" );
        $value = str_replace( [ '\\:', '\\/', '\\[', '\\]', '\\.' ], [ ':', '/', '[', ']', '.' ], $value );
        if ( '.' === $prefix ) {
            $value = preg_replace( '/[^A-Za-z0-9_:\\/\\[\\].-]/', '', $value );
        } else {
            $value = preg_replace( '/[^A-Za-z0-9_-]/', '', $value );
        }
        if ( ! is_string( $value ) || '' === $value || is_numeric( $value[0] ) ) {
            return;
        }
        if ( 80 < strlen( $value ) ) {
            return;
        }
        if ( '#' === $prefix && preg_match( '/^[A-Fa-f0-9]{3,8}$/', $value ) ) {
            return;
        }
        if ( '.' === $prefix ) {
            $value = str_replace( [ '\\', ':', '/', '[', ']', '.' ], [ '', '\\:', '\\/', '\\[', '\\]', '\\.' ], $value );
        }
        $bucket[ $prefix . $value ] = true;
    }

    private function add_css_variable( array &$vars, string $value ): void {
        $value = trim( html_entity_decode( $value, ENT_QUOTES, 'UTF-8' ) );
        if ( '' === $value ) {
            return;
        }
        if ( 0 !== strpos( $value, '--' ) ) {
            $value = '--' . ltrim( $value, '-' );
        }
        $value = strtolower( preg_replace( '/[^a-zA-Z0-9_-]/', '-', $value ) );
        $value = preg_replace( '/-+/', '-', $value );
        $value = '--' . trim( substr( $value, 2 ), '-' );
        if ( ! preg_match( '/^--[a-z][a-z0-9_-]{1,120}$/', $value ) ) {
            return;
        }
        $vars[] = $value;
    }

    private function extract_css_custom_properties( string $text, array &$vars ): void {
        if ( preg_match_all( '/--([a-zA-Z][a-zA-Z0-9_-]*)\s*:/', $text, $matches ) ) {
            foreach ( $matches[1] as $name ) {
                $this->add_css_variable( $vars, '--' . $name );
            }
        }
    }

    private function add_selector( array &$selectors, string $value ): void {
        $value = trim( html_entity_decode( $value, ENT_QUOTES, 'UTF-8' ) );
        if ( '' === $value || 60 < strlen( $value ) ) {
            return;
        }
        if ( preg_match( '/^@(?:container|font-face|keyframes|layer|media|property|supports)$/i', $value )
            || preg_match( '/^::?[a-z][a-z0-9-]*(?:\(\))?$/i', $value )
            || preg_match( '/^[a-z][a-z0-9-]*$/i', $value )
        ) {
            $selectors[ strtolower( $value ) ] = true;
        }
    }

    private function extract_css_selectors( string $text, array &$classes, array &$ids, ?array &$selectors = null ): void {
        if ( preg_match_all( '/\\.((?:\\\\.|[A-Za-z_][A-Za-z0-9_-]*|[\\/:\\[\\].-]){1,120})/', $text, $matches ) ) {
            foreach ( $matches[1] as $class ) {
                $class = preg_replace( '/(?<!\\\\)::?[A-Za-z-].*$/', '', (string) $class );
                $this->add_identifier( $classes, (string) $class, '.' );
            }
        }
        if ( preg_match_all( '/#([A-Za-z_][A-Za-z0-9_-]{0,119})/', $text, $matches ) ) {
            foreach ( $matches[1] as $id ) {
                $this->add_identifier( $ids, (string) $id, '#' );
            }
        }
        if ( null === $selectors ) {
            return;
        }
        if ( preg_match_all( '/@(?:container|font-face|keyframes|layer|media|property|supports)\b/i', $text, $matches ) ) {
            foreach ( $matches[0] as $at_rule ) {
                $this->add_selector( $selectors, (string) $at_rule );
            }
        }
        if ( preg_match_all( '/(?<!\\\\)::?[a-z][a-z0-9-]*(?:\s*\([^)]{0,80}\))?/i', $text, $matches ) ) {
            foreach ( $matches[0] as $pseudo ) {
                $pseudo = preg_replace( '/\s*\([^)]*\)$/', '()', (string) $pseudo );
                $this->add_selector( $selectors, $pseudo );
            }
        }
        if ( preg_match_all( '/([^{};]{1,700})\{/', $text, $blocks ) ) {
            $skip = [
                'and' => true, 'from' => true, 'media' => true, 'min-width' => true,
                'max-width' => true, 'not' => true, 'only' => true, 'or' => true,
                'screen' => true, 'to' => true, 'var' => true, 'where' => true,
            ];
            foreach ( $blocks[1] as $prelude ) {
                if ( preg_match_all( '/(?<![.#:a-zA-Z0-9_-])([a-z][a-z0-9-]*)(?=[\s.#:\[>~,+{]|$)/i', (string) $prelude, $tags ) ) {
                    foreach ( $tags[1] as $tag ) {
                        $tag = strtolower( (string) $tag );
                        if ( ! isset( $skip[ $tag ] ) ) {
                            $this->add_selector( $selectors, $tag );
                        }
                    }
                }
            }
        }
    }

    private function extract_markup_identifiers( string $text, array &$classes, array &$ids, array &$vars ): void {
        if ( preg_match_all( "/\\bclass(?:Name)?\\s*=\\s*[\"']([^\"']{1,2000})[\"']/i", $text, $matches ) ) {
            foreach ( $matches[1] as $class_list ) {
                $this->extract_class_list( (string) $class_list, $classes );
            }
        }
        if ( preg_match_all( "/\\bclass(?:Name)?\\s*[:=]\\s*\\{?\\s*[`\"']([^`\"']{1,3000})[`\"']/i", $text, $matches ) ) {
            foreach ( $matches[1] as $class_list ) {
                $this->extract_class_list( (string) $class_list, $classes );
            }
        }
        if ( preg_match_all( "/\\b(?:class|className|class_name)\\s*[:=]\\s*\\[([^\\]]{1,4000})\\]/i", $text, $matches ) ) {
            foreach ( $matches[1] as $class_block ) {
                if ( preg_match_all( "/[`\"']([^`\"']{1,400})[`\"']/", (string) $class_block, $parts ) ) {
                    foreach ( $parts[1] as $class_list ) {
                        $this->extract_class_list( (string) $class_list, $classes );
                    }
                }
            }
        }
        if ( preg_match_all( "/classList\\.(?:add|remove|toggle|contains)\\s*\\(([^)]{1,2000})\\)/i", $text, $matches ) ) {
            foreach ( $matches[1] as $class_block ) {
                if ( preg_match_all( "/[`\"']([^`\"']{1,200})[`\"']/", (string) $class_block, $parts ) ) {
                    foreach ( $parts[1] as $class_list ) {
                        $this->extract_class_list( (string) $class_list, $classes );
                    }
                }
            }
        }
        if ( preg_match_all( "/(?:querySelector(?:All)?|closest|matches)\\s*\\(\\s*[`\"']([^`\"']{1,1000})[`\"']/i", $text, $matches ) ) {
            foreach ( $matches[1] as $selector ) {
                $this->extract_css_selectors( (string) $selector, $classes, $ids );
            }
        }
        if ( preg_match_all( "/\\bid\\s*=\\s*[\"']([A-Za-z][A-Za-z0-9_-]{0,119})[\"']/i", $text, $matches ) ) {
            foreach ( $matches[1] as $id ) {
                $this->add_identifier( $ids, (string) $id, '#' );
            }
        }
        if ( preg_match_all( "/\\bid\\s*[:=]\\s*[`\"']([A-Za-z][A-Za-z0-9_-]{0,119})[`\"']/i", $text, $matches ) ) {
            foreach ( $matches[1] as $id ) {
                $this->add_identifier( $ids, (string) $id, '#' );
            }
        }
        $this->extract_css_custom_properties( $text, $vars );
    }

    private function extract_class_list( string $class_list, array &$classes ): void {
        $class_list = preg_replace( '/\\$\\{[^}]*\\}/', ' ', $class_list );
        $class_list = preg_replace( '/[{}()\\[\\],+?:;]/', ' ', (string) $class_list );
        foreach ( preg_split( '/\\s+/', (string) $class_list ) ?: [] as $class ) {
            $this->add_identifier( $classes, $class, '.' );
        }
    }

    private function extract_bricks_class_records( string $text, array &$classes ): void {
        if ( false === stripos( $text, 'globalClassesNamesIds' )
            && false === stripos( $text, 'global_classes' )
            && false === stripos( $text, 'globalClasses' )
        ) {
            return;
        }

        if ( preg_match_all( '/["\']name["\']\s*:\s*["\']([^"\']{1,120})["\']/i', $text, $matches ) ) {
            foreach ( $matches[1] as $name ) {
                $this->add_identifier( $classes, ltrim( (string) $name, '.' ), '.' );
            }
        }

        if ( preg_match_all( '/["\']selector["\']\s*:\s*["\']\.([^"\']{1,120})["\']/i', $text, $matches ) ) {
            foreach ( $matches[1] as $name ) {
                $this->add_identifier( $classes, (string) $name, '.' );
            }
        }
    }

    private function global_class_map(): array {
        $map = [];
        foreach ( [ 'bricks_global_classes', 'bricks_global_classes_names_ids', 'bricks_global_classes_namesIds' ] as $option ) {
            $data = get_option( $option, [] );
            $this->collect_global_class_map( $data, $map );
        }
        return $map;
    }

    private function collect_global_class_map( $data, array &$map ): void {
        if ( is_string( $data ) ) {
            $decoded = json_decode( $data, true );
            if ( is_array( $decoded ) ) {
                $data = $decoded;
            } else {
                return;
            }
        }
        if ( is_object( $data ) ) {
            $data = (array) $data;
        }
        if ( ! is_array( $data ) ) {
            return;
        }

        if ( isset( $data['id'], $data['name'] ) && is_scalar( $data['id'] ) && is_scalar( $data['name'] ) ) {
            $id = trim( (string) $data['id'] );
            $name = trim( (string) $data['name'] );
            if ( '' !== $id && '' !== $name ) {
                $map[ $id ] = $name;
            }
        }

        foreach ( $data as $value ) {
            $this->collect_global_class_map( $value, $map );
        }
    }

    private function collect_scan_class_map( array $scan_text, array &$map ): void {
        foreach ( $scan_text as $text ) {
            $data = maybe_unserialize( $text );
            if ( is_array( $data ) || is_object( $data ) ) {
                $this->collect_contextual_class_map( $data, $map );
                $text = wp_json_encode( $data );
            }

            $text = substr( (string) $text, 0, 250000 );
            if ( '' === $text ) {
                continue;
            }

            if ( false !== stripos( $text, 'globalClasses' )
                || false !== stripos( $text, 'global_classes' )
                || false !== stripos( $text, 'bricks' )
            ) {
                $this->collect_class_map_from_text( $text, $map );
            }

            $decoded = json_decode( $text, true );
            if ( is_array( $decoded ) ) {
                $this->collect_contextual_class_map( $decoded, $map );
            }
        }
    }

    private function collect_contextual_class_map( $data, array &$map, string $context = '', int $depth = 0 ): void {
        if ( 8 < $depth ) {
            return;
        }
        if ( is_object( $data ) ) {
            $data = (array) $data;
        }
        if ( ! is_array( $data ) ) {
            return;
        }

        $context_l = strtolower( $context );
        $class_context = false !== strpos( $context_l, 'class' )
            || false !== strpos( $context_l, 'globalclasses' )
            || false !== strpos( $context_l, 'bricks' );

        if ( $class_context && isset( $data['id'], $data['name'] ) && is_scalar( $data['id'] ) && is_scalar( $data['name'] ) ) {
            $id = trim( (string) $data['id'] );
            $name = trim( (string) $data['name'] );
            if ( '' !== $id && '' !== $name ) {
                $map[ $id ] = $name;
            }
        }

        foreach ( $data as $key => $value ) {
            $next_context = is_string( $key ) && '' !== $key ? $key : $context;
            $this->collect_contextual_class_map( $value, $map, $next_context, $depth + 1 );
        }
    }

    private function collect_class_map_from_text( string $text, array &$map ): void {
        if ( preg_match_all( '/["\']id["\']\s*:\s*["\']([^"\']{1,120})["\'][^{}]{0,240}["\']name["\']\s*:\s*["\']([^"\']{1,120})["\']/i', $text, $matches, PREG_SET_ORDER ) ) {
            foreach ( $matches as $match ) {
                $map[ trim( (string) $match[1] ) ] = trim( (string) $match[2] );
            }
        }
        if ( preg_match_all( '/["\']name["\']\s*:\s*["\']([^"\']{1,120})["\'][^{}]{0,240}["\']id["\']\s*:\s*["\']([^"\']{1,120})["\']/i', $text, $matches, PREG_SET_ORDER ) ) {
            foreach ( $matches as $match ) {
                $map[ trim( (string) $match[2] ) ] = trim( (string) $match[1] );
            }
        }
    }

    private function generated_css_chunks(): array {
        $upload = wp_upload_dir();
        $root   = (string) ( $upload['basedir'] ?? '' );
        if ( '' === $root || ! is_dir( $root ) ) {
            return [];
        }

        $chunks = [];
        $files  = 0;
        $bytes  = 0;

        try {
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS )
            );

            foreach ( $iterator as $file ) {
                if ( 80 <= $files || 3000000 <= $bytes ) {
                    break;
                }
                if ( ! $file->isFile() || 'css' !== strtolower( $file->getExtension() ) ) {
                    continue;
                }

                $path = strtolower( str_replace( '\\', '/', $file->getPathname() ) );
                if ( false === strpos( $path, '/bricks/' )
                    && false === strpos( $path, '/automatic' )
                    && false === strpos( $path, '/acss' )
                    && false === strpos( $path, '/core-framework' )
                    && false === strpos( $path, '/advanced-themer' )
                    && false === strpos( $path, '/variable-engine' )
                ) {
                    continue;
                }

                $size = (int) $file->getSize();
                if ( 0 >= $size || 500000 < $size ) {
                    continue;
                }

                $content = file_get_contents( $file->getPathname() );
                if ( false === $content || '' === $content ) {
                    continue;
                }

                $chunks[] = substr( $content, 0, 250000 );
                $files++;
                $bytes += $size;
            }
        } catch ( \Throwable $e ) {
            return $chunks;
        }

        return $chunks;
    }

    private function custom_table_chunks(): array {
        global $wpdb;

        $chunks = [];
        $tables = $wpdb->get_col( 'SHOW TABLES' ) ?: [];
        $files  = 0;
        $bytes  = 0;

        foreach ( $tables as $table ) {
            if ( 10 <= $files || 3000000 <= $bytes ) {
                break;
            }

            $table = (string) $table;
            if ( ! preg_match( '/^[A-Za-z0-9_]+$/', $table ) ) {
                continue;
            }

            $lower = strtolower( $table );
            if ( ! preg_match( '/(wpcodebox|code_snippets|codesnippets|snippet|bricks|advanced[-_]?themer|automatic[-_]?css|automaticcss|acss|core[-_]?framework|code2bricks|etch|wpcb)/', $lower ) ) {
                continue;
            }

            try {
                $columns = $wpdb->get_results( 'DESCRIBE ' . $this->quote_identifier( $table ), ARRAY_A ) ?: [];
                $text_columns = [];

                foreach ( $columns as $column ) {
                    $field = (string) ( $column['Field'] ?? '' );
                    $type  = strtolower( (string) ( $column['Type'] ?? '' ) );
                    if ( '' === $field || ! preg_match( '/^[A-Za-z0-9_]+$/', $field ) ) {
                        continue;
                    }
                    if ( preg_match( '/(char|text|json)/', $type ) ) {
                        $text_columns[] = $field;
                    }
                    if ( 8 <= count( $text_columns ) ) {
                        break;
                    }
                }

                if ( empty( $text_columns ) ) {
                    continue;
                }

                $quoted_columns = array_map( [ $this, 'quote_identifier' ], $text_columns );
                $rows = $wpdb->get_results(
                    'SELECT ' . implode( ', ', $quoted_columns ) . ' FROM ' . $this->quote_identifier( $table ) . ' LIMIT 80',
                    ARRAY_A
                ) ?: [];

                foreach ( $rows as $row ) {
                    foreach ( $text_columns as $column ) {
                        if ( 3000000 <= $bytes ) {
                            break 3;
                        }
                        $value = $row[ $column ] ?? '';
                        if ( ! is_scalar( $value ) ) {
                            continue;
                        }
                        $value = trim( (string) $value );
                        if ( '' === $value ) {
                            continue;
                        }
                        if ( ! preg_match( '/(--[A-Za-z0-9_-]+|class(?:Name)?|selector|custom[_-]?css|[.#][A-Za-z_][A-Za-z0-9_-]*)/i', $value ) ) {
                            continue;
                        }

                        $size = strlen( $value );
                        if ( 500000 < $size ) {
                            $value = substr( $value, 0, 250000 );
                            $size  = strlen( $value );
                        }

                        $chunks[] = $value;
                        $bytes += $size;
                    }
                }

                $files++;
            } catch ( \Throwable $e ) {
                continue;
            }
        }

        return $chunks;
    }

    private function scan_template_files( array &$classes, array &$ids, array &$vars ): void {
        $roots = [];
        if ( function_exists( 'get_stylesheet_directory' ) ) {
            $roots[] = get_stylesheet_directory();
        }
        if ( function_exists( 'get_template_directory' ) ) {
            $roots[] = get_template_directory();
        }

        $roots = array_values( array_unique( array_filter( $roots ) ) );
        $files = 0;
        $bytes = 0;
        $exts  = [ 'php' => true, 'html' => true, 'htm' => true, 'twig' => true, 'mustache' => true ];

        foreach ( $roots as $root ) {
            if ( 100 <= $files || 3000000 <= $bytes || ! is_string( $root ) || ! is_dir( $root ) ) {
                continue;
            }
            try {
                $iterator = new \RecursiveIteratorIterator(
                    new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS )
                );
                foreach ( $iterator as $file ) {
                    if ( 100 <= $files || 3000000 <= $bytes ) {
                        break 2;
                    }
                    if ( ! $file->isFile() ) {
                        continue;
                    }
                    $ext = strtolower( $file->getExtension() );
                    if ( ! isset( $exts[ $ext ] ) ) {
                        continue;
                    }
                    $path = strtolower( str_replace( '\\', '/', $file->getPathname() ) );
                    if ( false !== strpos( $path, '/vendor/' ) || false !== strpos( $path, '/node_modules/' ) ) {
                        continue;
                    }
                    $size = (int) $file->getSize();
                    if ( 0 >= $size || 350000 < $size ) {
                        continue;
                    }
                    $content = file_get_contents( $file->getPathname() );
                    if ( false === $content || '' === $content ) {
                        continue;
                    }
                    $this->extract_markup_identifiers( substr( $content, 0, 250000 ), $classes, $ids, $vars );
                    $files++;
                    $bytes += $size;
                }
            } catch ( \Throwable $e ) {
                continue;
            }
        }
    }

    private function source_file_chunks(): array {
        $roots = [];
        if ( function_exists( 'get_stylesheet_directory' ) ) {
            $roots[] = get_stylesheet_directory();
        }
        if ( function_exists( 'get_template_directory' ) ) {
            $roots[] = get_template_directory();
        }

        if ( defined( 'WP_PLUGIN_DIR' ) && is_dir( WP_PLUGIN_DIR ) ) {
            try {
                foreach ( new \DirectoryIterator( WP_PLUGIN_DIR ) as $plugin ) {
                    if ( ! $plugin->isDir() || $plugin->isDot() ) {
                        continue;
                    }
                    $name = strtolower( $plugin->getFilename() );
                    if ( preg_match( '/(bricks|automatic|acss|advanced[-_]?themer|core[-_]?framework|wpcodebox|code2bricks|etch)/', $name ) ) {
                        $roots[] = $plugin->getPathname();
                    }
                }
            } catch ( \Throwable $e ) {
                // Keep suggestions available even if a plugin folder cannot be read.
            }
        }

        return $this->read_source_chunks( array_values( array_unique( array_filter( $roots ) ) ) );
    }

    private function source_template_chunks(): array {
        $roots = [];
        if ( function_exists( 'get_stylesheet_directory' ) ) {
            $roots[] = get_stylesheet_directory();
        }
        if ( function_exists( 'get_template_directory' ) ) {
            $roots[] = get_template_directory();
        }

        if ( defined( 'WP_PLUGIN_DIR' ) && is_dir( WP_PLUGIN_DIR ) ) {
            try {
                foreach ( new \DirectoryIterator( WP_PLUGIN_DIR ) as $plugin ) {
                    if ( ! $plugin->isDir() || $plugin->isDot() ) {
                        continue;
                    }
                    $name = strtolower( $plugin->getFilename() );
                    if ( preg_match( '/(bricks|automatic|acss|advanced[-_]?themer|core[-_]?framework|wpcodebox|code2bricks|etch|wpcode)/', $name ) ) {
                        $roots[] = $plugin->getPathname();
                    }
                }
            } catch ( \Throwable $e ) {
                // Keep suggestions available even if optional plugin folders cannot be read.
            }
        }

        return $this->read_template_chunks( array_values( array_unique( array_filter( $roots ) ) ) );
    }

    private function read_source_chunks( array $roots ): array {
        $chunks = [];
        $files  = 0;
        $bytes  = 0;
        $exts   = [ 'css' => true, 'scss' => true, 'less' => true, 'json' => true ];

        foreach ( $roots as $root ) {
            if ( 120 <= $files || 4000000 <= $bytes || ! is_string( $root ) || ! is_dir( $root ) ) {
                continue;
            }

            try {
                $iterator = new \RecursiveIteratorIterator(
                    new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS )
                );

                foreach ( $iterator as $file ) {
                    if ( 120 <= $files || 4000000 <= $bytes ) {
                        break 2;
                    }
                    if ( ! $file->isFile() ) {
                        continue;
                    }

                    $ext = strtolower( $file->getExtension() );
                    if ( ! isset( $exts[ $ext ] ) ) {
                        continue;
                    }

                    $path = strtolower( str_replace( '\\', '/', $file->getPathname() ) );
                    if ( false !== strpos( $path, '/vendor/' )
                        || false !== strpos( $path, '/node_modules/' )
                        || false !== strpos( $path, '/acf-pro/' )
                        || false !== strpos( $path, '/codemirror/' )
                        || false !== strpos( $path, '.min.css' )
                        || false !== strpos( $path, '.min.js' )
                    ) {
                        continue;
                    }

                    $size = (int) $file->getSize();
                    if ( 0 >= $size || 400000 < $size ) {
                        continue;
                    }

                    $content = file_get_contents( $file->getPathname() );
                    if ( false === $content || '' === $content ) {
                        continue;
                    }

                    $chunks[] = substr( $content, 0, 250000 );
                    $files++;
                    $bytes += $size;
                }
            } catch ( \Throwable $e ) {
                continue;
            }
        }

        return $chunks;
    }

    private function read_template_chunks( array $roots ): array {
        $chunks = [];
        $files  = 0;
        $bytes  = 0;
        $exts   = [
            'php' => true,
            'html' => true,
            'htm' => true,
            'twig' => true,
            'mustache' => true,
            'js' => true,
            'jsx' => true,
            'ts' => true,
            'tsx' => true,
            'vue' => true,
            'svelte' => true,
        ];

        foreach ( $roots as $root ) {
            if ( 100 <= $files || 3000000 <= $bytes || ! is_string( $root ) || ! is_dir( $root ) ) {
                continue;
            }

            try {
                $iterator = new \RecursiveIteratorIterator(
                    new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS )
                );

                foreach ( $iterator as $file ) {
                    if ( 100 <= $files || 3000000 <= $bytes ) {
                        break 2;
                    }
                    if ( ! $file->isFile() ) {
                        continue;
                    }

                    $ext = strtolower( $file->getExtension() );
                    if ( ! isset( $exts[ $ext ] ) ) {
                        continue;
                    }

                    $path = strtolower( str_replace( '\\', '/', $file->getPathname() ) );
                    if ( false !== strpos( $path, '/vendor/' )
                        || false !== strpos( $path, '/node_modules/' )
                        || false !== strpos( $path, '/acf-pro/' )
                        || false !== strpos( $path, '/codemirror/' )
                        || false !== strpos( $path, '/dist/' )
                        || false !== strpos( $path, '/build/' )
                        || false !== strpos( $path, '/cache/' )
                        || false !== strpos( $path, '.min.js' )
                    ) {
                        continue;
                    }

                    $size = (int) $file->getSize();
                    if ( 0 >= $size || 300000 < $size ) {
                        continue;
                    }

                    $content = file_get_contents( $file->getPathname() );
                    if ( false === $content || '' === $content ) {
                        continue;
                    }

                    if ( ! preg_match( '/(class(?:Name)?|classList|querySelector|closest|matches|\\bid\\s*[:=]|--[A-Za-z][A-Za-z0-9_-]*|var\\s*\\()/i', $content ) ) {
                        continue;
                    }

                    $chunks[] = substr( $content, 0, 220000 );
                    $files++;
                    $bytes += $size;
                }
            } catch ( \Throwable $e ) {
                continue;
            }
        }

        return $chunks;
    }

    private function quote_identifier( string $identifier ): string {
        return '`' . str_replace( '`', '``', $identifier ) . '`';
    }

    private function extract_identifiers_from_data( $data, array &$classes, array &$ids, array &$vars, array $class_map = [], string $parent_key = '', int $depth = 0 ): void {
        if ( 8 < $depth ) {
            return;
        }

        if ( is_object( $data ) ) {
            $data = (array) $data;
        }

        if ( ! is_array( $data ) ) {
            if ( '' !== $parent_key ) {
                $this->extract_identifier_value( $parent_key, $data, $classes, $ids, $vars, $class_map );
            }
            return;
        }

        foreach ( $data as $key => $value ) {
            $key_string = is_string( $key ) ? $key : $parent_key;
            if ( '' !== $key_string ) {
                $this->extract_identifier_value( $key_string, $value, $classes, $ids, $vars, $class_map, $parent_key );
            }

            if ( is_array( $value ) || is_object( $value ) ) {
                $this->extract_structured_item( $value, $classes, $ids, $vars, $class_map, $key_string );
                $this->extract_identifiers_from_data( $value, $classes, $ids, $vars, $class_map, $key_string, $depth + 1 );
            }
        }
    }

    private function extract_structured_item( $value, array &$classes, array &$ids, array &$vars, array $class_map, string $context ): void {
        if ( is_object( $value ) ) {
            $value = (array) $value;
        }
        if ( ! is_array( $value ) ) {
            return;
        }

        $context = strtolower( $context );
        $class_context = false !== strpos( $context, 'class' ) || false !== strpos( $context, 'globalclasses' );
        $var_context   = false !== strpos( $context, 'variable' ) || false !== strpos( $context, 'token' ) || false !== strpos( $context, 'cssvar' );

        foreach ( [ 'name', 'label', 'title', 'selector', 'class', 'className', 'class_name', 'slug' ] as $field ) {
            if ( isset( $value[ $field ] ) && ( $class_context || in_array( $field, [ 'selector', 'class', 'className', 'class_name' ], true ) ) ) {
                $raw = (string) $value[ $field ];
                foreach ( preg_split( '/[\s,]+/', $raw ) ?: [] as $part ) {
                    $part = ltrim( trim( $part ), '.' );
                    $this->add_identifier( $classes, $class_map[ $part ] ?? $part, '.' );
                }
            }
        }

        foreach ( [ 'id', '_id', 'elementId', 'anchor', 'cssId' ] as $field ) {
            if ( isset( $value[ $field ] ) && false !== strpos( strtolower( $field ), 'id' ) ) {
                $this->add_identifier( $ids, ltrim( (string) $value[ $field ], '#' ), '#' );
            }
        }

        foreach ( [ 'var', 'variable', 'cssVar', 'css_var', 'token', 'name', 'id' ] as $field ) {
            if ( isset( $value[ $field ] ) && $var_context ) {
                $this->add_css_variable( $vars, (string) $value[ $field ] );
            }
        }
    }

    private function extract_identifier_value( string $key, $value, array &$classes, array &$ids, array &$vars, array $class_map = [], string $parent_key = '' ): void {
        $key_l = strtolower( $key );
        $parent_l = strtolower( $parent_key );
        $is_class_key = false !== strpos( $key_l, 'class' ) || false !== strpos( $parent_l, 'class' );
        $is_id_key    = 'id' === $key_l || false !== strpos( $key_l, '_id' ) || false !== strpos( $key_l, '-id' ) || false !== strpos( $key_l, 'id_' );
        $is_var_key   = false !== strpos( $key_l, 'variable' ) || false !== strpos( $key_l, 'cssvar' ) || false !== strpos( $key_l, 'css_var' ) || false !== strpos( $key_l, 'token' ) || false !== strpos( $parent_l, 'variable' ) || false !== strpos( $parent_l, 'token' );

        if ( ! $is_class_key && ! $is_id_key && ! $is_var_key ) {
            return;
        }

        if ( is_array( $value ) || is_object( $value ) ) {
            $value = wp_json_encode( $value );
        }

        $value = trim( (string) $value );
        if ( '' === $value || 2000 < strlen( $value ) ) {
            return;
        }

        $tokens = preg_split( '/[\s,"\':;\[\]\{\}]+/', $value ) ?: [];
        foreach ( $tokens as $token ) {
            $token = trim( $token );
            if ( '' === $token ) {
                continue;
            }
            if ( $is_class_key ) {
                $token = ltrim( $token, '.' );
                $this->add_identifier( $classes, $class_map[ $token ] ?? $token, '.' );
            }
            if ( $is_id_key ) {
                $this->add_identifier( $ids, ltrim( $token, '#' ), '#' );
            }
            if ( $is_var_key || 0 === strpos( $token, '--' ) ) {
                $this->add_css_variable( $vars, $token );
            }
        }
    }

    private function sorted_keys( array $items ): array {
        $items = array_values( array_unique( array_filter( $items ) ) );
        natcasesort( $items );
        return array_values( array_slice( $items, 0, 10000 ) );
    }

    private function file_path(): string {
        return VE_CSS_OUTPUT_DIR . 'advanced.css';
    }

    private function file_url(): string {
        return VE_CSS_OUTPUT_URL . 'advanced.css';
    }
}
