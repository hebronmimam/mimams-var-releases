(function () {
  'use strict';

  var config = window.baqaConfig || {};
  var labels = config.labels || {};
  var DEBUG = !!config.debug;
  var SETTINGS_KEY = 'mimamsBarSettings';
  var MAX_BULK_TARGETS = 40;

  function readStoredSettings() {
    try {
      var raw = window.localStorage ? window.localStorage.getItem(SETTINGS_KEY) : '';
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  }

  function writeStoredSettings(value) {
    try {
      if (window.localStorage) {
        window.localStorage.setItem(SETTINGS_KEY, JSON.stringify(value || {}));
      }
    } catch (e) {}
  }

  function getEffectiveShortcut() {
    var stored = readStoredSettings();
    var shortcutName = stored.shortcut || 'alt-q';
    var shortcuts = {
      'alt-q': { ctrl: false, alt: true, shift: false, meta: false, key: 'q' },
      'ctrl-k': { ctrl: true, alt: false, shift: false, meta: false, key: 'k' },
      'ctrl-alt-a': { ctrl: true, alt: true, shift: false, meta: false, key: 'a' }
    };
    return shortcuts[shortcutName] || config.shortcut || shortcuts['alt-q'];
  }

  function matchesConfiguredShortcut(event) {
    var shortcut = getEffectiveShortcut();
    var key = String(shortcut.key || 'q').toLowerCase();
    return (!!shortcut.ctrl === event.ctrlKey) &&
      (!!shortcut.alt === event.altKey) &&
      (!!shortcut.shift === event.shiftKey) &&
      (!!shortcut.meta === event.metaKey) &&
      String(event.key || '').toLowerCase() === key;
  }

  function log() {
    if (DEBUG && window.console) {
      console.log.apply(console, ["[Mimam's Bar]"].concat(Array.prototype.slice.call(arguments)));
    }
  }

  function makeId() {
    return 'baqa_' + Math.random().toString(36).slice(2, 9);
  }

  var Core = {
    version: config.version || '0.2.4',
    config: config,
    labels: labels,
    debug: DEBUG,
    SETTINGS_KEY: SETTINGS_KEY,
    MAX_BULK_TARGETS: MAX_BULK_TARGETS,
    readStoredSettings: readStoredSettings,
    writeStoredSettings: writeStoredSettings,
    getEffectiveShortcut: getEffectiveShortcut,
    matchesConfiguredShortcut: matchesConfiguredShortcut,
    log: log,
    makeId: makeId
  };

  window.MimamsBarCore = Core;

  // Bricks can load builder assets in the preview/canvas iframe too.
  // The actual floating panel must only live in the top builder document;
  // otherwise the preview document can gain extra scrollbars/white gutters.
  // When the shortcut is pressed from inside the iframe, forward it upward.
  if (window.self !== window.top) {
    window.MimamsBarFrameBridge = true;

    document.addEventListener('keydown', function (event) {
      if (!matchesConfiguredShortcut(event)) return;
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
      try {
        window.top.postMessage({ type: 'baqa:toggle' }, window.location.origin);
      } catch (e) {
        try { window.top.postMessage({ type: 'baqa:toggle' }, '*'); } catch (ignore) {}
      }
    }, true);

    window.BAQA = { frameBridge: true, version: Core.version };
  }
})();
