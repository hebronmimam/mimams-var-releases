<?php
namespace VE\API;

use VE\Sync\SyncEngine;
use VE\Sync\SnapshotManager;
use VE\Sync\PairingManager;
use VE\Sync\PortableBundleManager;
use VE\Core\Logger;
use VE\Core\VariableManager;
use VE\Core\ThemeManager;

defined('ABSPATH') || exit;

class SyncController {

    private SyncEngine $engine;
    private SnapshotManager $snapshots;
    private PairingManager $pairing;

    public function __construct() {
        $this->engine    = new SyncEngine();
        $this->snapshots = new SnapshotManager();
        $this->pairing   = new PairingManager();
    }

    /* ── EXPORT ────────────────────────────────────────────────────── */

    /**
     * GET /sync/export?format=dtcg|flat|figma
     * Returns JSON of all base variables.
     */
    public function export( \WP_REST_Request $request ): \WP_REST_Response {
        $format = $request->get_param('format') ?? 'dtcg';
        $include_gen = (bool) $request->get_param('include_generated');
        $data   = $this->engine->export( $format, $include_gen );

        return new \WP_REST_Response( $data, 200 );
    }

    /**
     * GET /sync/export-css
     * Returns a commented CSS custom property export.
     */
    public function export_css( \WP_REST_Request $request ): \WP_REST_Response {
        $manager = new VariableManager();
        $rows    = ( new ThemeManager() )->apply_to_variables( $manager->get_all() );
        $seen    = [];
        $groups  = [];

        usort( $rows, static function ( $a, $b ) {
            return (int) ( $b['id'] ?? 0 ) <=> (int) ( $a['id'] ?? 0 );
        } );

        foreach ( $rows as $row ) {
            $name = (string) ( $row['name'] ?? '' );
            if ( '' === $name || isset( $seen[ $name ] ) ) {
                continue;
            }
            $seen[ $name ] = true;

            $namespace = (string) ( $row['namespace'] ?? strtok( $name, '.' ) );
            if ( '' === $namespace ) {
                $namespace = 'tokens';
            }
            if ( ! isset( $groups[ $namespace ] ) ) {
                $groups[ $namespace ] = [];
            }

            $groups[ $namespace ][] = [
                'name'      => $name,
                'css_name'  => $manager->to_css_name( $name ),
                'value'     => (string) ( $row['css_value'] ?: $row['value'] ?: '' ),
                'type'      => (string) ( $row['type'] ?? 'base' ),
                'source_id' => (int) ( $row['source_id'] ?? 0 ),
            ];
        }

        ksort( $groups, SORT_NATURAL );
        foreach ( $groups as &$items ) {
            usort( $items, static function ( $a, $b ) {
                return strnatcasecmp( $a['css_name'], $b['css_name'] );
            } );
        }
        unset( $items );

        $css = [
            '/*',
            " * Mimam's Var - WP CSS Export",
            ' * Version: ' . VE_VERSION,
            ' * Exported: ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC',
            ' * Scale rule: 10px = 1rem.',
            ' */',
            '',
            ':root {',
        ];

        foreach ( $groups as $namespace => $items ) {
            $css[] = '';
            $css[] = '  /* ' . ucwords( str_replace( [ '-', '_' ], ' ', $namespace ) ) . ' */';
            foreach ( $items as $item ) {
                $comment = $item['name'];
                if ( 'generated' === $item['type'] && $item['source_id'] > 0 ) {
                    $comment .= ' | generated from #' . $item['source_id'];
                }
                $css[] = '  ' . $item['css_name'] . ': ' . $item['value'] . '; /* ' . $comment . ' */';
            }
        }

        $css[] = '}';
        $css[] = '';

        $site_slug = sanitize_title( get_bloginfo( 'name' ) );
        if ( '' === $site_slug ) {
            $site_slug = 'wordpress';
        }

        return new \WP_REST_Response( [
            'filename' => 'mimams-var-' . $site_slug . '-css-' . gmdate( 'Y-m-d' ) . '.css',
            'css'      => implode( "\n", $css ),
        ], 200 );
    }

    public function export_bundle( \WP_REST_Request $request ): \WP_REST_Response {
        $bundle = ( new PortableBundleManager() )->export();
        $site_slug = sanitize_title( get_bloginfo( 'name' ) );
        if ( '' === $site_slug ) {
            $site_slug = 'wordpress';
        }
        return new \WP_REST_Response( [
            'filename' => 'mimams-var-' . $site_slug . '-system-' . gmdate( 'Y-m-d' ) . '.json',
            'bundle'   => $bundle,
        ], 200 );
    }

    /* ── IMPORT PREVIEW ────────────────────────────────────────────── */

    /**
     * POST /sync/preview
     * Body: JSON of variables to import.
     * Returns diff preview without applying.
     */
    public function preview( \WP_REST_Request $request ): \WP_REST_Response {
        $body = $request->get_json_params();

        if ( empty( $body ) ) {
            return new \WP_REST_Response(
                [ 'code' => 've_empty', 'message' => 'No data provided.' ],
                400
            );
        }

        $normalized = $this->engine->normalize_import( $body );

        if ( empty( $normalized ) ) {
            return new \WP_REST_Response(
                [ 'code' => 've_parse_failed', 'message' => 'Could not parse the provided JSON. Supported formats: DTCG, VE flat, Figma collections.' ],
                400
            );
        }

        $normalized = $this->engine->prepare_import_rows( $normalized );
        $validation_errors = $this->engine->validate_import_rows( $normalized );
        if ( ! empty( $validation_errors ) ) {
            return new \WP_REST_Response(
                [ 'code' => 've_import_invalid', 'message' => implode( ' ', $validation_errors ), 'errors' => $validation_errors ],
                422
            );
        }

        $result = $this->engine->preview_import( $normalized );
        $result['variable_count'] = count( $normalized );

        return new \WP_REST_Response( $result, 200 );
    }

    public function preview_bundle( \WP_REST_Request $request ): \WP_REST_Response {
        $body = $request->get_json_params();
        $result = ( new PortableBundleManager() )->preview( is_array( $body ) ? $body : [] );
        if ( ! empty( $result['errors'] ) ) {
            return new \WP_REST_Response(
                [ 'code' => 've_bundle_invalid', 'message' => implode( ' ', $result['errors'] ), 'errors' => $result['errors'] ],
                422
            );
        }
        return new \WP_REST_Response( $result, 200 );
    }

    /* ── APPLY CHANGES ─────────────────────────────────────────────── */

    /**
     * POST /sync/apply
     * Body: { changes: [...], skip_deletes: bool }
     * Applies diff changes. Creates a snapshot first.
     */
    public function apply( \WP_REST_Request $request ): \WP_REST_Response {
        $body    = $request->get_json_params();
        $changes = $body['changes'] ?? [];

        if ( empty( $changes ) ) {
            return new \WP_REST_Response(
                [ 'code' => 've_empty', 'message' => 'No changes to apply.' ],
                400
            );
        }

        $options = [
            'skip_deletes' => ! empty( $body['skip_deletes'] ),
        ];

        $result = $this->engine->apply_changes( $changes, $options );

        return new \WP_REST_Response( $result, 200 );
    }

    public function apply_bundle( \WP_REST_Request $request ): \WP_REST_Response {
        $body = $request->get_json_params();
        $bundle = isset( $body['bundle'] ) && is_array( $body['bundle'] ) ? $body['bundle'] : [];
        $result = ( new PortableBundleManager() )->apply( $bundle, ! empty( $body['skip_deletes'] ) );
        $status = ! empty( $result['errors'] ) ? 422 : 200;
        return new \WP_REST_Response( $result, $status );
    }

    /* ── SNAPSHOTS ─────────────────────────────────────────────────── */

    /**
     * GET /sync/snapshots
     */
    public function list_snapshots( \WP_REST_Request $request ): \WP_REST_Response {
        $limit = (int) ( $request->get_param('limit') ?? 20 );
        return new \WP_REST_Response( $this->snapshots->list( $limit ), 200 );
    }

    /**
     * POST /sync/rollback/{id}
     */
    public function rollback( \WP_REST_Request $request ): \WP_REST_Response {
        $id     = (int) $request->get_param('snapshot_id');
        $result = $this->snapshots->rollback( $id );

        if ( is_wp_error( $result ) ) {
            $status = (int) ( $result->get_error_data()['status'] ?? 500 );
            return new \WP_REST_Response(
                [
                    'code'    => $result->get_error_code(),
                    'message' => $result->get_error_message(),
                    'data'    => $result->get_error_data(),
                ],
                $status
            );
        }

        return new \WP_REST_Response([
            'restored' => true,
            'variable_count' => count( $result['variables'] ),
            'dependency_count' => count( $result['dependencies'] ),
            'generator_count' => count( $result['generators'] ),
            'safety_snapshot_id' => (int) $result['safety_snapshot_id'],
            'state_version' => (int) $result['state_version'],
        ], 200 );
    }

    /* ── LOGS ──────────────────────────────────────────────────────── */

    /**
     * GET /sync/logs
     */
    public function list_logs( \WP_REST_Request $request ): \WP_REST_Response {
        $limit = (int) ( $request->get_param('limit') ?? 20 );
        return new \WP_REST_Response( $this->engine->get_logs( $limit ), 200 );
    }

    public function diagnostics( \WP_REST_Request $request ): \WP_REST_Response {
        $lines = (int) ( $request->get_param( 'lines' ) ?? 200 );
        return new \WP_REST_Response( Logger::read( $lines ), 200 );
    }

    public function clear_diagnostics( \WP_REST_Request $request ): \WP_REST_Response {
        return new \WP_REST_Response( [
            'cleared' => Logger::clear(),
            'path'    => Logger::path(),
        ], 200 );
    }

    /* ── MANUAL SNAPSHOT ──────────────────────────────────────────── */

    /**
     * POST /sync/snapshot
     */
    public function create_snapshot( \WP_REST_Request $request ): \WP_REST_Response {
        $id = $this->snapshots->create('manual');
        if ( is_wp_error( $id ) ) {
            $status = (int) ( $id->get_error_data()['status'] ?? 500 );
            return new \WP_REST_Response(
                [ 'code' => $id->get_error_code(), 'message' => $id->get_error_message() ],
                $status
            );
        }
        return new \WP_REST_Response([ 'id' => $id ], 201 );
    }

    /**
     * POST /sync/logs
     * Write a sync log entry (used by Figma plugin after push/pull)
     */
    public function write_log( \WP_REST_Request $request ): \WP_REST_Response {
        global $wpdb;
        $body   = $request->get_json_params();
        $source = sanitize_text_field( $body['source'] ?? 'figma' );
        $author = sanitize_text_field( $body['author'] ?? 'Figma Plugin' );
        $payload = [
            'changes' => $body['changes'] ?? [],
            'summary' => $body['summary'] ?? [],
            'client_time' => sanitize_text_field( $body['client_time'] ?? '' ),
            'client_timezone' => sanitize_text_field( $body['client_timezone'] ?? '' ),
        ];
        $diff = wp_json_encode( $payload );

        $inserted = $wpdb->insert(
            \VE\Database\Schema::table('sync_logs'),
            [ 'source' => $source, 'author' => $author, 'diff' => $diff, 'snapshot_id' => 0 ],
            [ '%s', '%s', '%s', '%d' ]
        );
        if ( false === $inserted ) {
            return new \WP_REST_Response(
                [ 'code' => 've_sync_log_failed', 'message' => $wpdb->last_error ?: 'Could not write the sync log.' ],
                500
            );
        }

        return new \WP_REST_Response([ 'logged' => true ], 201 );
    }

    /* ── PAIRING ──────────────────────────────────────────────────── */

    /**
     * POST /sync/pair/generate
     * Generate a pairing code from WordPress side.
     */
    public function generate_pair( \WP_REST_Request $request ): \WP_REST_Response {
        $result = $this->pairing->generate_code_from_wp();
        return new \WP_REST_Response( $result, 200 );
    }

    /**
     * POST /sync/pair/validate
     * Body: { code: "ABC123", figma_file_key?: "..." }
     * Called by Figma plugin to complete pairing.
     */
    public function validate_pair( \WP_REST_Request $request ): \WP_REST_Response {
        $body = $request->get_json_params();
        $code = $body['code'] ?? '';

        // If already paired and this is just a metadata update (file name etc.)
        if ( $this->pairing->is_paired() && ( ! empty( $body['figma_file_name'] ) || ! empty( $body['figma_collection_name'] ) ) ) {
            if ( ! empty( $body['figma_file_name'] ) ) {
                update_option( 've_sync_figma_name', sanitize_text_field( $body['figma_file_name'] ) );
            }
            if ( ! empty( $body['figma_collection_name'] ) ) {
                update_option( 've_sync_figma_collection', sanitize_text_field( $body['figma_collection_name'] ) );
            }
            return new \WP_REST_Response( [ 'updated' => true ], 200 );
        }

        if ( ! $code ) {
            return new \WP_REST_Response(
                [ 'code' => 've_invalid', 'message' => 'Pairing code required.' ],
                400
            );
        }

        $result = $this->pairing->validate_code( $code, 'figma', [
            'figma_file_key'  => $body['figma_file_key'] ?? '',
            'figma_file_name' => $body['figma_file_name'] ?? '',
            'figma_collection_name' => $body['figma_collection_name'] ?? '',
        ] );

        if ( ! $result ) {
            return new \WP_REST_Response(
                [ 'code' => 've_pair_failed', 'message' => 'Invalid or expired pairing code.' ],
                403
            );
        }

        return new \WP_REST_Response( $result, 200 );
    }

    /**
     * POST /sync/pair/register
     * Called by Figma plugin to register its own code on WP.
     * Body: { code: "ABC123", api_key: "ve_..." }
     */
    public function register_figma_pair( \WP_REST_Request $request ): \WP_REST_Response {
        $body    = $request->get_json_params();
        $code    = $body['code'] ?? '';
        $api_key = $body['api_key'] ?? '';

        if ( ! $code || ! $api_key ) {
            return new \WP_REST_Response(
                [ 'code' => 've_invalid', 'message' => 'Code and API key required.' ],
                400
            );
        }

        $this->pairing->register_figma_code( $code, $api_key );

        return new \WP_REST_Response([ 'registered' => true ], 200 );
    }

    /**
     * POST /sync/pair/complete-figma
     * Called by WP admin after entering Figma-generated code.
     * Body: { code: "ABC123" }
     */
    public function complete_figma_pair( \WP_REST_Request $request ): \WP_REST_Response {
        $body = $request->get_json_params();
        $code = $body['code'] ?? '';

        $result = $this->pairing->validate_code( $code, 'wordpress' );

        if ( ! $result ) {
            return new \WP_REST_Response(
                [ 'code' => 've_pair_failed', 'message' => 'Invalid or expired code.' ],
                403
            );
        }

        return new \WP_REST_Response( $result, 200 );
    }

    /**
     * GET /sync/pair/status
     */
    public function pair_status( \WP_REST_Request $request ): \WP_REST_Response {
        return new \WP_REST_Response( $this->pairing->get_status(), 200 );
    }

    /**
     * POST /sync/pair/disconnect
     */
    public function disconnect( \WP_REST_Request $request ): \WP_REST_Response {
        $this->pairing->disconnect();
        return new \WP_REST_Response([ 'disconnected' => true ], 200 );
    }

    /* ── API KEY AUTH HELPER ──────────────────────────────────────── */

    /**
     * Permission callback that checks either WP auth or VE API key.
     */
    public static function can_sync( \WP_REST_Request $request ): bool {
        // Check X-VE-Key header
        $key = $request->get_header('X-VE-Key');
        if ( $key ) {
            $pm = new PairingManager();
            return $pm->validate_key( $key );
        }
        // Fall back to standard WP auth
        return current_user_can( 'manage_options' );
    }
}
