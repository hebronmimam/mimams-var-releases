<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Organizational containers for color variables.
 *
 * Palettes never alter effective values or generated CSS. Generated children
 * inherit their base variable's membership and therefore do not get their own
 * membership rows.
 */
class ColorPaletteManager {

    public static function source_palette_name( string $category_slug, string $fallback = 'External Sources' ): string {
        $names = [
            'advanced-themer' => 'Bricks / Advanced Themer',
            'core-framework'  => 'Core Framework',
            'automatic-css'   => 'Automatic.css',
        ];
        return $names[ sanitize_key( $category_slug ) ] ?? sanitize_text_field( $fallback );
    }

    /**
     * Resolve migration ownership from the selected scanner first, then from
     * the row metadata. Preview payloads may be normalized by the browser, so
     * category_slug alone is not a strong enough source identity.
     */
    public static function source_palette_slug( string $source, array $variable = [] ): string {
        $source = sanitize_key( $source );
        $source_map = [
            'bricks'          => 'advanced-themer',
            'advanced-themer' => 'advanced-themer',
            'core-framework'  => 'core-framework',
            'acss'            => 'automatic-css',
            'automatic-css'   => 'automatic-css',
        ];
        if ( isset( $source_map[ $source ] ) ) {
            return $source_map[ $source ];
        }

        $origin = sanitize_key( (string) ( $variable['origin'] ?? '' ) );
        $origin_map = [
            'at'   => 'advanced-themer',
            'cf'   => 'core-framework',
            'acss' => 'automatic-css',
        ];
        if ( isset( $origin_map[ $origin ] ) ) {
            return $origin_map[ $origin ];
        }

        $category_slug = sanitize_key( (string) ( $variable['category_slug'] ?? '' ) );
        return $category_slug ?: 'external-sources';
    }

    /**
     * Strictly identify stored CSS color values without relying on a token's
     * namespace. External frameworks often use semantic names such as
     * bg-body or border-primary for values that still belong in Color.
     */
    public static function is_css_color_value( string $value ): bool {
        $value = trim( $value );
        if ( '' === $value ) {
            return false;
        }

        if ( preg_match( '/^#[0-9a-f]{3,8}$/i', $value ) ) {
            return true;
        }

        if ( in_array( strtolower( $value ), [ 'transparent', 'currentcolor' ], true ) ) {
            return true;
        }

        return (bool) preg_match(
            '/^(?:rgba?|hsla?|hwb|lab|lch|oklab|oklch|color|color-mix)\(.+\)$/i',
            $value
        );
    }

    public function list(): array {
        global $wpdb;
        $palettes_table = Schema::table( 'color_palettes' );
        $members_table = Schema::table( 'color_palette_members' );
        $variables_table = Schema::table( 'variables' );

        $rows = $wpdb->get_results(
            "SELECT p.*,
                COUNT(m.variable_id) AS color_count
             FROM {$palettes_table} p
             LEFT JOIN {$members_table} m ON m.palette_id = p.id
             LEFT JOIN {$variables_table} v ON v.id = m.variable_id AND v.namespace = 'color' AND v.type <> 'generated'
             GROUP BY p.id
             ORDER BY p.position ASC, p.id ASC",
            ARRAY_A
        ) ?: [];

        foreach ( $rows as &$row ) {
            $row['id'] = (int) $row['id'];
            $row['position'] = (int) $row['position'];
            $row['color_count'] = (int) $row['color_count'];
        }
        unset( $row );

        return [ 'palettes' => $rows ];
    }

    public function create( string $name ) {
        global $wpdb;
        $name = sanitize_text_field( $name );
        if ( '' === $name ) {
            return new \WP_Error( 've_color_palette_name_required', 'Enter a palette name.', [ 'status' => 400 ] );
        }

        $slug = $this->unique_slug( $name );
        $position = (int) $wpdb->get_var( 'SELECT COALESCE(MAX(position), -1) + 1 FROM ' . Schema::table( 'color_palettes' ) );
        $inserted = $wpdb->insert(
            Schema::table( 'color_palettes' ),
            [
                'slug'     => $slug,
                'name'     => $name,
                'position' => $position,
            ],
            [ '%s', '%s', '%d' ]
        );
        if ( false === $inserted ) {
            return new \WP_Error( 've_color_palette_create_failed', $wpdb->last_error ?: 'Could not create the palette.', [ 'status' => 500 ] );
        }

        return [
            'id'          => (int) $wpdb->insert_id,
            'slug'        => $slug,
            'name'        => $name,
            'position'    => $position,
            'color_count' => 0,
        ];
    }

    public function get_by_slug( string $slug ): ?array {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . Schema::table( 'color_palettes' ) . ' WHERE slug = %s',
                sanitize_key( $slug )
            ),
            ARRAY_A
        );
        return $row ?: null;
    }

    public function get_by_name( string $name ): ?array {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . Schema::table( 'color_palettes' ) . ' WHERE LOWER(name) = LOWER(%s) ORDER BY id ASC LIMIT 1',
                sanitize_text_field( $name )
            ),
            ARRAY_A
        );
        return $row ?: null;
    }

    public function get_or_create( string $name ) {
        $existing = $this->get_by_slug( sanitize_title( $name ) );
        return $existing ?: $this->create( $name );
    }

    public function rename( int $palette_id, string $name ) {
        global $wpdb;
        if ( ! $this->get( $palette_id ) ) {
            return new \WP_Error( 've_color_palette_not_found', 'Palette not found.', [ 'status' => 404 ] );
        }
        $name = sanitize_text_field( $name );
        if ( '' === $name ) {
            return new \WP_Error( 've_color_palette_name_required', 'Enter a palette name.', [ 'status' => 400 ] );
        }
        $updated = $wpdb->update(
            Schema::table( 'color_palettes' ),
            [ 'name' => $name, 'updated_at' => current_time( 'mysql' ) ],
            [ 'id' => $palette_id ],
            [ '%s', '%s' ],
            [ '%d' ]
        );
        if ( false === $updated ) {
            return new \WP_Error( 've_color_palette_rename_failed', $wpdb->last_error ?: 'Could not rename the palette.', [ 'status' => 500 ] );
        }
        return [ 'id' => $palette_id, 'name' => $name ];
    }

    public function get( int $palette_id ): ?array {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'color_palettes' ) . ' WHERE id = %d', $palette_id ),
            ARRAY_A
        );
        return $row ?: null;
    }

    public function first_id(): int {
        global $wpdb;
        return (int) $wpdb->get_var( 'SELECT id FROM ' . Schema::table( 'color_palettes' ) . ' ORDER BY position ASC, id ASC LIMIT 1' );
    }

    public function palette_id_for_variable( int $variable_id ): int {
        global $wpdb;
        return (int) $wpdb->get_var(
            $wpdb->prepare(
                'SELECT palette_id FROM ' . Schema::table( 'color_palette_members' ) . ' WHERE variable_id = %d',
                $variable_id
            )
        );
    }

    public function assign( int $variable_id, int $palette_id ) {
        global $wpdb;
        $variable = ( new VariableManager() )->get( $variable_id );
        if ( ! $variable || ! $this->is_color_variable( $variable ) || 'generated' === (string) ( $variable['type'] ?? '' ) ) {
            return new \WP_Error( 've_color_palette_invalid_variable', 'Only base or alias Color variables can belong to a palette.', [ 'status' => 400 ] );
        }
        if ( ! $this->get( $palette_id ) ) {
            return new \WP_Error( 've_color_palette_not_found', 'Destination palette not found.', [ 'status' => 404 ] );
        }

        $position = (int) $wpdb->get_var(
            $wpdb->prepare(
                'SELECT COALESCE(MAX(position), -1) + 1 FROM ' . Schema::table( 'color_palette_members' ) . ' WHERE palette_id = %d',
                $palette_id
            )
        );
        $result = $wpdb->replace(
            Schema::table( 'color_palette_members' ),
            [
                'palette_id' => $palette_id,
                'variable_id' => $variable_id,
                'position' => $position,
            ],
            [ '%d', '%d', '%d' ]
        );
        if ( false === $result ) {
            return new \WP_Error( 've_color_palette_assign_failed', $wpdb->last_error ?: 'Could not assign the color to the palette.', [ 'status' => 500 ] );
        }
        return [ 'variable_id' => $variable_id, 'palette_id' => $palette_id ];
    }

    /**
     * Color aliases may live in semantic namespaces such as design.*.
     * They still belong to color palettes when their source chain resolves to
     * a Color variable. Storage names and namespaces remain unchanged.
     */
    public function is_color_variable( array $variable, array $seen = [] ): bool {
        if ( 'color' === (string) ( $variable['namespace'] ?? '' ) ) {
            return true;
        }

        $type = (string) ( $variable['type'] ?? '' );
        if ( 'alias' !== $type ) {
            $value = (string) ( $variable['value'] ?? $variable['css_value'] ?? '' );
            if ( self::is_css_color_value( $value ) ) {
                return true;
            }
        }

        if ( ! in_array( $type, [ 'alias', 'generated' ], true ) ) {
            return false;
        }

        $source_id = (int) ( $variable['source_id'] ?? 0 );
        if ( $source_id <= 0 || isset( $seen[ $source_id ] ) ) {
            return false;
        }
        $seen[ $source_id ] = true;
        $source = ( new VariableManager() )->get( $source_id );

        return $source ? $this->is_color_variable( $source, $seen ) : false;
    }

    /**
     * Generated imports inherit palette ownership from their first
     * non-generated ancestor. Base colors and color aliases own themselves.
     */
    public function palette_owner_variable( array $variable, array $seen = [] ): ?array {
        if ( 'generated' !== (string) ( $variable['type'] ?? '' ) ) {
            return $this->is_color_variable( $variable ) ? $variable : null;
        }

        $source_id = (int) ( $variable['source_id'] ?? 0 );
        if ( $source_id <= 0 || isset( $seen[ $source_id ] ) ) {
            return null;
        }
        $seen[ $source_id ] = true;
        $source = ( new VariableManager() )->get( $source_id );

        return $source ? $this->palette_owner_variable( $source, $seen ) : null;
    }

    public function annotate_variables( array $variables ): array {
        global $wpdb;
        if ( empty( $variables ) ) {
            return $variables;
        }

        $members = $wpdb->get_results(
            'SELECT m.variable_id, m.palette_id, p.name AS palette_name
             FROM ' . Schema::table( 'color_palette_members' ) . ' m
             INNER JOIN ' . Schema::table( 'color_palettes' ) . ' p ON p.id = m.palette_id',
            ARRAY_A
        ) ?: [];
        $by_variable = [];
        foreach ( $members as $member ) {
            $by_variable[ (int) $member['variable_id'] ] = [
                'palette_id' => (int) $member['palette_id'],
                'palette_name' => (string) $member['palette_name'],
            ];
        }

        foreach ( $variables as &$variable ) {
            $is_color = $this->is_color_variable( $variable );
            $variable['palette_eligible'] = $is_color;
            if ( $is_color ) {
                $variable['display_namespace'] = 'color';
            }
            if ( ! $is_color ) {
                continue;
            }
            $owner_id = 'generated' === (string) ( $variable['type'] ?? '' )
                ? (int) ( $variable['source_id'] ?? 0 )
                : (int) ( $variable['id'] ?? 0 );
            if ( isset( $by_variable[ $owner_id ] ) ) {
                $variable = array_merge( $variable, $by_variable[ $owner_id ] );
            } else {
                $variable['palette_id'] = 0;
                $variable['palette_name'] = '';
            }
        }
        unset( $variable );

        return $variables;
    }

    public function reconcile_variable( int $variable_id ): void {
        $variable = ( new VariableManager() )->get( $variable_id );
        if ( ! $variable || 'generated' === (string) ( $variable['type'] ?? '' ) || ! $this->is_color_variable( $variable ) ) {
            $this->remove_variable( $variable_id );
            return;
        }
        if ( $this->palette_id_for_variable( $variable_id ) > 0 ) {
            return;
        }
        $palette_id = $this->first_id();
        if ( $palette_id <= 0 ) {
            $created = $this->create( 'Palette One' );
            if ( is_wp_error( $created ) ) {
                return;
            }
            $palette_id = (int) $created['id'];
        }
        $this->assign( $variable_id, $palette_id );
    }

    public function duplicate( int $palette_id, string $name = '' ) {
        global $wpdb;
        $source = $this->get( $palette_id );
        if ( ! $source ) {
            return new \WP_Error( 've_color_palette_not_found', 'Palette not found.', [ 'status' => 404 ] );
        }
        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_color_palette_transaction_failed', $wpdb->last_error ?: 'Could not start the palette transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;
        $created = $this->create( $name ?: (string) $source['name'] . ' Copy' );
        if ( is_wp_error( $created ) ) {
            return $this->fail_transaction( $created, $owns_transaction );
        }

        $members = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT variable_id, position FROM ' . Schema::table( 'color_palette_members' ) . ' WHERE palette_id = %d ORDER BY position ASC, id ASC',
                $palette_id
            ),
            ARRAY_A
        ) ?: [];
        foreach ( $members as $member ) {
            $copy = $this->copy_variable( (int) $member['variable_id'], (int) $created['id'], '', true );
            if ( is_wp_error( $copy ) ) {
                return $this->fail_transaction( $copy, $owns_transaction );
            }
        }
        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            return $this->fail_transaction(
                new \WP_Error( 've_color_palette_commit_failed', $wpdb->last_error ?: 'Could not commit the palette duplication.', [ 'status' => 500 ] ),
                $owns_transaction
            );
        }
        return $created;
    }

    public function move_variable( int $variable_id, int $palette_id ) {
        return $this->assign( $variable_id, $palette_id );
    }

    public function copy_variable( int $variable_id, int $palette_id, string $target_name, bool $include_generated = true ) {
        global $wpdb;
        $manager = new VariableManager();
        $source = $manager->get( $variable_id );
        if ( ! $source || ! $this->is_color_variable( $source ) || 'generated' === (string) ( $source['type'] ?? '' ) ) {
            return new \WP_Error( 've_color_palette_invalid_variable', 'Only base or alias Color variables can be copied between palettes.', [ 'status' => 400 ] );
        }
        if ( ! $this->get( $palette_id ) ) {
            return new \WP_Error( 've_color_palette_not_found', 'Destination palette not found.', [ 'status' => 404 ] );
        }
        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_color_palette_transaction_failed', $wpdb->last_error ?: 'Could not start the color-copy transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;

        if ( '' === trim( $target_name ) ) {
            $target_name = (string) $source['name'] . '.copy';
            $index = 2;
            while ( $manager->get_by_name( VariableManager::normalize_name( $target_name ) ) ) {
                $target_name = (string) $source['name'] . '.copy-' . $index;
                $index++;
            }
        }
        $target_name = VariableManager::normalize_name( $target_name );
        if ( false === strpos( $target_name, '.' ) ) {
            $target_name = 'color.' . $target_name;
        }
        $payload = [
            'name' => $target_name,
            'value' => 'alias' === $source['type'] ? (string) $source['css_value'] : (string) $source['value'],
            'type' => (string) $source['type'],
        ];
        if ( 'alias' === $source['type'] ) {
            $payload['source_id'] = (int) $source['source_id'];
        }

        $created = $manager->create( $payload );
        if ( is_wp_error( $created ) ) {
            return $this->fail_transaction( $created, $owns_transaction );
        }
        $assigned = $this->assign( (int) $created['id'], $palette_id );
        if ( is_wp_error( $assigned ) ) {
            return $this->fail_transaction( $assigned, $owns_transaction );
        }

        ( new ThemeManager() )->copy_variable( (string) $source['name'], (string) $created['name'] );

        if ( $include_generated && 'base' === (string) $source['type'] ) {
            $generators = $wpdb->get_results(
                $wpdb->prepare(
                    'SELECT type, config FROM ' . Schema::table( 'generators' ) . ' WHERE variable_id = %d AND active = 1 ORDER BY id ASC',
                    $variable_id
                ),
                ARRAY_A
            ) ?: [];
            foreach ( $generators as $generator ) {
                $config = json_decode( (string) $generator['config'], true );
                $attached = ( new GeneratorEngine() )->attach(
                    (int) $created['id'],
                    (string) $generator['type'],
                    is_array( $config ) ? $config : []
                );
                if ( is_wp_error( $attached ) ) {
                    return $this->fail_transaction( $attached, $owns_transaction );
                }
            }
        }

        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            return $this->fail_transaction(
                new \WP_Error( 've_color_palette_commit_failed', $wpdb->last_error ?: 'Could not commit the color copy.', [ 'status' => 500 ] ),
                $owns_transaction
            );
        }
        return $this->annotate_variables( [ $manager->get( (int) $created['id'] ) ] )[0];
    }

    public function preview_delete( int $palette_id ) {
        global $wpdb;
        $palette = $this->get( $palette_id );
        if ( ! $palette ) {
            return new \WP_Error( 've_color_palette_not_found', 'Palette not found.', [ 'status' => 404 ] );
        }
        $members = $this->member_ids( $palette_id );
        $generated_count = 0;
        $dependent_count = 0;
        if ( $members ) {
            $ids = implode( ',', array_map( 'intval', $members ) );
            $generated_count = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM " . Schema::table( 'variables' ) . " WHERE type = 'generated' AND source_id IN ({$ids})"
            );
            $dependent_count = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM " . Schema::table( 'dependencies' ) . " WHERE parent_id IN ({$ids}) AND relation = 'alias'"
            );
        }
        return [
            'palette' => $palette,
            'color_count' => count( $members ),
            'generated_count' => $generated_count,
            'dependent_alias_count' => $dependent_count,
        ];
    }

    public function delete( int $palette_id, string $strategy = 'empty', int $destination_id = 0 ) {
        global $wpdb;
        $preview = $this->preview_delete( $palette_id );
        if ( is_wp_error( $preview ) ) {
            return $preview;
        }
        $members = $this->member_ids( $palette_id );

        if ( $members && 'move' === $strategy ) {
            if ( $destination_id === $palette_id || ! $this->get( $destination_id ) ) {
                return new \WP_Error( 've_color_palette_destination_required', 'Choose another destination palette.', [ 'status' => 400 ] );
            }
        } elseif ( $members && 'delete_colors' !== $strategy ) {
            return new \WP_Error(
                've_color_palette_not_empty',
                'This palette contains colors. Move or delete them before removing the palette.',
                [ 'status' => 409, 'preview' => $preview ]
            );
        }

        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_color_palette_transaction_failed', $wpdb->last_error ?: 'Could not start the palette deletion transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;

        if ( $members && 'move' === $strategy ) {
            foreach ( $members as $variable_id ) {
                $moved = $this->assign( $variable_id, $destination_id );
                if ( is_wp_error( $moved ) ) {
                    return $this->fail_transaction( $moved, $owns_transaction );
                }
            }
        } elseif ( $members && 'delete_colors' === $strategy ) {
            foreach ( $members as $variable_id ) {
                $affected = $this->dependent_variables( $variable_id );
                $deleted = ( new VariableManager() )->delete( $variable_id, true );
                if ( is_wp_error( $deleted ) ) {
                    return $this->fail_transaction( $deleted, $owns_transaction );
                }
                foreach ( $affected as $variable ) {
                    ( new ThemeManager() )->delete_variable( (string) $variable['name'] );
                    $this->remove_variable( (int) $variable['id'] );
                }
            }
        }

        if (
            false === $wpdb->delete( Schema::table( 'color_palette_members' ), [ 'palette_id' => $palette_id ], [ '%d' ] )
            || false === $wpdb->delete( Schema::table( 'color_palettes' ), [ 'id' => $palette_id ], [ '%d' ] )
        ) {
            return $this->fail_transaction(
                new \WP_Error( 've_color_palette_delete_failed', $wpdb->last_error ?: 'Could not delete the palette.', [ 'status' => 500 ] ),
                $owns_transaction
            );
        }
        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            return $this->fail_transaction(
                new \WP_Error( 've_color_palette_commit_failed', $wpdb->last_error ?: 'Could not commit the palette deletion.', [ 'status' => 500 ] ),
                $owns_transaction
            );
        }
        return true;
    }

    public function remove_variable( int $variable_id ): void {
        global $wpdb;
        $wpdb->delete( Schema::table( 'color_palette_members' ), [ 'variable_id' => $variable_id ], [ '%d' ] );
    }

    public function repair_memberships(): void {
        global $wpdb;
        $variables_table = Schema::table( 'variables' );
        $members_table = Schema::table( 'color_palette_members' );
        $palettes_table = Schema::table( 'color_palettes' );
        $wpdb->query(
            "DELETE m FROM {$members_table} m
             LEFT JOIN {$variables_table} v ON v.id = m.variable_id
             LEFT JOIN {$palettes_table} p ON p.id = m.palette_id
             WHERE v.id IS NULL OR p.id IS NULL OR v.type = 'generated'"
        );
        $rows = $wpdb->get_results(
            "SELECT v.*, m.palette_id, p.id AS valid_palette_id
             FROM {$variables_table} v
             LEFT JOIN {$members_table} m ON m.variable_id = v.id
             LEFT JOIN {$palettes_table} p ON p.id = m.palette_id
             WHERE v.type <> 'generated'
             ORDER BY v.id ASC",
            ARRAY_A
        ) ?: [];
        $unowned = [];
        foreach ( $rows as $row ) {
            $variable_id = (int) $row['id'];
            $eligible = $this->is_color_variable( $row );
            $has_valid_membership = ! empty( $row['palette_id'] ) && ! empty( $row['valid_palette_id'] );
            if ( ! $eligible && ! empty( $row['palette_id'] ) ) {
                $this->remove_variable( $variable_id );
            } elseif ( $eligible && ! $has_valid_membership ) {
                $unowned[] = $variable_id;
            }
        }
        if ( empty( $unowned ) ) {
            return;
        }
        $palette_id = $this->first_id();
        if ( $palette_id <= 0 ) {
            $created = $this->create( 'Palette One' );
            if ( is_wp_error( $created ) ) {
                return;
            }
            $palette_id = (int) $created['id'];
        }
        foreach ( $unowned as $variable_id ) {
            $this->assign( (int) $variable_id, $palette_id );
        }
    }

    public function reorder_palettes( array $ids ) {
        global $wpdb;
        $table = Schema::table( 'color_palettes' );
        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_color_palette_transaction_failed', $wpdb->last_error ?: 'Could not start reorder transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;

        foreach ( $ids as $position => $id ) {
            $updated = $wpdb->update(
                $table,
                [ 'position' => (int) $position ],
                [ 'id' => (int) $id ],
                [ '%d' ],
                [ '%d' ]
            );
            if ( false === $updated ) {
                return $this->fail_transaction(
                    new \WP_Error( 've_color_palette_reorder_failed', $wpdb->last_error ?: 'Could not update palette position.', [ 'status' => 500 ] ),
                    $owns_transaction
                );
            }
        }

        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            return $this->fail_transaction(
                new \WP_Error( 've_color_palette_commit_failed', $wpdb->last_error ?: 'Could not commit palette positions.', [ 'status' => 500 ] ),
                $owns_transaction
            );
        }
        return true;
    }

    public function batch_assign( array $variable_ids, int $palette_id ) {
        global $wpdb;
        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_color_palette_transaction_failed', $wpdb->last_error ?: 'Could not start batch assignment transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;

        foreach ( $variable_ids as $var_id ) {
            $res = $this->assign( (int) $var_id, $palette_id );
            if ( is_wp_error( $res ) ) {
                return $this->fail_transaction( $res, $owns_transaction );
            }
        }

        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            return $this->fail_transaction(
                new \WP_Error( 've_color_palette_commit_failed', $wpdb->last_error ?: 'Could not commit batch assignments.', [ 'status' => 500 ] ),
                $owns_transaction
            );
        }
        return true;
    }

    private function member_ids( int $palette_id ): array {
        global $wpdb;
        return array_map( 'intval', $wpdb->get_col(
            $wpdb->prepare(
                'SELECT variable_id FROM ' . Schema::table( 'color_palette_members' ) . ' WHERE palette_id = %d ORDER BY position ASC, id ASC',
                $palette_id
            )
        ) ?: [] );
    }

    private function dependent_variables( int $variable_id ): array {
        global $wpdb;
        $variables = [];
        $pending = [ $variable_id ];
        $seen = [];
        while ( $pending ) {
            $current = (int) array_shift( $pending );
            if ( $current <= 0 || isset( $seen[ $current ] ) ) {
                continue;
            }
            $seen[ $current ] = true;
            $row = $wpdb->get_row(
                $wpdb->prepare( 'SELECT id, name FROM ' . Schema::table( 'variables' ) . ' WHERE id = %d', $current ),
                ARRAY_A
            );
            if ( $row ) {
                $variables[] = $row;
            }
            $children = $wpdb->get_col(
                $wpdb->prepare( 'SELECT child_id FROM ' . Schema::table( 'dependencies' ) . ' WHERE parent_id = %d', $current )
            ) ?: [];
            foreach ( $children as $child_id ) {
                $pending[] = (int) $child_id;
            }
        }
        return $variables;
    }

    private function unique_slug( string $name ): string {
        global $wpdb;
        $base = sanitize_key( str_replace( ' ', '-', strtolower( $name ) ) );
        $base = trim( preg_replace( '/-+/', '-', $base ), '-' );
        if ( '' === $base ) {
            $base = 'palette';
        }
        $slug = $base;
        $index = 2;
        while ( $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Schema::table( 'color_palettes' ) . ' WHERE slug = %s', $slug ) ) ) {
            $slug = $base . '-' . $index;
            $index++;
        }
        return $slug;
    }

    private function begin_transaction_if_needed(): int {
        global $wpdb;
        $in_transaction = (int) $wpdb->get_var( 'SELECT @@in_transaction' );
        if ( $in_transaction > 0 ) {
            return 0;
        }
        return false === $wpdb->query( 'START TRANSACTION' ) ? -1 : 1;
    }

    private function commit_if_owned( bool $owns_transaction ): bool {
        global $wpdb;
        return ! $owns_transaction || false !== $wpdb->query( 'COMMIT' );
    }

    private function fail_transaction( \WP_Error $error, bool $owns_transaction ) {
        global $wpdb;
        if ( $owns_transaction ) {
            $wpdb->query( 'ROLLBACK' );
            ( new CssExporter() )->export();
        }
        return $error;
    }
}
