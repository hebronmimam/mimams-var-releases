<?php
namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Loads Rank Math's own browser analyzer for Content Studio.
 *
 * Rank Math calculates its editor score in JavaScript. This bridge exposes the
 * same analyzer, configured tests, locale data, and language helpers without
 * mounting or imitating Rank Math's editor UI.
 */
class RankMathAnalysisBridge {
    private const DEFAULT_TESTS = [
        'contentHasTOC',
        'contentHasShortParagraphs',
        'contentHasAssets',
        'keywordInTitle',
        'keywordInMetaDescription',
        'keywordInPermalink',
        'keywordIn10Percent',
        'keywordInContent',
        'keywordInSubheadings',
        'keywordInImageAlt',
        'keywordDensity',
        'keywordNotUsed',
        'lengthContent',
        'lengthPermalink',
        'linksHasInternal',
        'linksHasExternals',
        'linksNotAllExternals',
        'titleStartWithKeyword',
        'titleSentiment',
        'titleHasPowerWords',
        'titleHasNumber',
        'hasContentAI',
    ];

    /**
     * Enqueue Rank Math's analyzer and return the optional VE app dependency.
     *
     * @return array<int,string>
     */
    public static function enqueue(): array {
        if ( ! class_exists( '\RankMath' ) || ! function_exists( 'rank_math' ) ) {
            return [];
        }

        $rank_math = rank_math();
        if ( ! is_object( $rank_math ) || ! method_exists( $rank_math, 'plugin_url' ) ) {
            return [];
        }

        $version = defined( 'RANK_MATH_VERSION' ) ? RANK_MATH_VERSION : ( isset( $rank_math->version ) ? $rank_math->version : null );
        if ( ! wp_script_is( 'rank-math-analyzer', 'registered' ) ) {
            wp_register_script(
                'rank-math-analyzer',
                $rank_math->plugin_url() . 'assets/admin/js/analyzer.js',
                [ 'lodash', 'wp-autop', 'wp-wordcount', 'wp-url', 'wp-hooks', 'wp-i18n' ],
                $version,
                true
            );
        } else {
            global $wp_scripts;
            if ( isset( $wp_scripts->registered['rank-math-analyzer'] ) ) {
                $required = [ 'lodash', 'wp-autop', 'wp-wordcount', 'wp-url', 'wp-hooks', 'wp-i18n' ];
                $wp_scripts->registered['rank-math-analyzer']->deps = array_values(
                    array_unique( array_merge( $wp_scripts->registered['rank-math-analyzer']->deps, $required ) )
                );
            }
        }

        $config = self::configuration( $rank_math );
        $json   = wp_json_encode( $config );
        if ( $json ) {
            wp_add_inline_script(
                'rank-math-analyzer',
                'window.veRankMathAnalysis=' . $json . ';'
                . 'window.rankMath=window.rankMath||{};'
                . 'window.rankMath.localeFull=window.veRankMathAnalysis.localeFull;'
                . 'window.rankMath.assessor=Object.assign({},window.rankMath.assessor||{},window.veRankMathAnalysis.assessor);',
                'before'
            );
        }

        wp_enqueue_script( 'rank-math-analyzer' );
        if ( function_exists( 'wp_set_script_translations' ) && method_exists( $rank_math, 'plugin_dir' ) ) {
            wp_set_script_translations( 'rank-math-analyzer', 'seo-by-rank-math', $rank_math->plugin_dir() . 'languages/' );
        }

        return [ 'rank-math-analyzer' ];
    }

    /**
     * @param object $rank_math Rank Math plugin instance.
     * @return array<string,mixed>
     */
    private static function configuration( $rank_math ): array {
        $locale       = get_locale();
        $short_locale = strtolower( substr( str_replace( '-', '_', $locale ), 0, 2 ) );
        $plugin_dir   = method_exists( $rank_math, 'plugin_dir' ) ? $rank_math->plugin_dir() : '';

        $power_words = self::include_array( $plugin_dir . 'assets/vendor/powerwords/' . $short_locale . '.php' );
        $diacritics_locale = in_array( $short_locale, [ 'en', 'de', 'ru' ], true ) ? $short_locale : 'en';
        $diacritics = self::include_array( $plugin_dir . 'assets/vendor/diacritics/' . $diacritics_locale . '.php' );

        $tests = self::DEFAULT_TESTS;
        if ( class_exists( '\RankMath\Admin\Metabox\Post_Screen' ) ) {
            try {
                $screen     = new \RankMath\Admin\Metabox\Post_Screen();
                $configured = apply_filters( 'rank_math/researches/tests', $screen->get_analysis(), 'post' );
                if ( is_array( $configured ) && $configured ) {
                    $tests = array_values( array_keys( array_filter( $configured ) ) );
                }
            } catch ( \Throwable $error ) {
                // Keep the Rank Math default post test list when its screen helper is unavailable.
            }
        }

        return [
            'available'  => true,
            'localeFull' => $locale ?: 'en_US',
            'tests'      => $tests,
            'assessor'   => [
                'researchesTests' => $tests,
                'powerWords'      => array_values( array_map( 'strtolower', $power_words ) ),
                'diacritics'      => $diacritics,
            ],
        ];
    }

    /**
     * @return array<mixed>
     */
    private static function include_array( string $path ): array {
        if ( ! $path || ! is_readable( $path ) ) {
            return [];
        }

        $value = include $path;
        return is_array( $value ) ? $value : [];
    }
}
