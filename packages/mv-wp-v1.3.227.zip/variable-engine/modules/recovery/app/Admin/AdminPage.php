<?php

namespace VE\Modules\Recovery\Admin;

use VE\Modules\Recovery\Agency\AgencyDashboard;
use VE\Modules\Recovery\Backup\PackageBuilder;
use VE\Modules\Recovery\Backup\PackageValidator;
use VE\Modules\Recovery\Backup\SnapshotJob;
use VE\Modules\Recovery\Backup\SnapshotManager;
use VE\Modules\Recovery\Database\Schema;
use VE\Modules\Recovery\Emergency\EmergencyRecovery;
use VE\Modules\Recovery\Jobs\JobStore;
use VE\Modules\Recovery\Restore\RollbackManager;
use VE\Modules\Recovery\Restore\RollbackExecutor;
use VE\Modules\Recovery\Restore\RestoreDryRun;
use VE\Modules\Recovery\Restore\RestorePreparation;
use VE\Modules\Recovery\Restore\RestorePreview;
use VE\Modules\Recovery\Restore\RestoreReadiness;
use VE\Modules\Recovery\Restore\RestoreVerifier;
use VE\Modules\Recovery\Restore\StagingRestoreExecutor;
use VE\Modules\Recovery\Restore\ProductionRestoreExecutor;
use VE\Modules\Recovery\Restore\RankMathConfigGuard;
use VE\Modules\Recovery\Schedule\ScheduleManager;
use VE\Modules\Recovery\Security\Capability;
use VE\Modules\Recovery\Security\SecurityAudit;
use VE\Modules\Recovery\Security\ProductionReadiness;
use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Storage\RemoteStorageManager;
use VE\Modules\Recovery\Utils\Logger;
use VE\Modules\Recovery\WooCommerce\WooSafety;
use VE\Modules\Recovery\Workflow\MigrationPlanner;
use VE\Modules\Recovery\Workflow\MigrationImporter;
use VE\Modules\Recovery\Workflow\StagingCloneBuilder;
use VE\Modules\Recovery\Workflow\StagingWorkflow;

defined( 'ABSPATH' ) || exit;

final class AdminPage {
    public function register(): void {
        add_action( 'admin_bar_menu', [ $this, 'add_admin_bar_button' ], 999 );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_notices', [ $this, 'render_restore_outcome_notice' ] );
        add_action( 'admin_footer', [ $this, 'render_floating_panel' ] );
        add_action( 'admin_post_restorebase_download_package', [ $this, 'download_package' ] );

        add_action( 'wp_ajax_restorebase_status', [ $this, 'ajax_status' ] );
        add_action( 'wp_ajax_restorebase_snapshots', [ $this, 'ajax_snapshots' ] );
        add_action( 'wp_ajax_restorebase_jobs', [ $this, 'ajax_jobs' ] );
        add_action( 'wp_ajax_restorebase_create_snapshot', [ $this, 'ajax_create_snapshot' ] );
        add_action( 'wp_ajax_restorebase_create_package', [ $this, 'ajax_create_package' ] );
        add_action( 'wp_ajax_restorebase_save_backup_options', [ $this, 'ajax_save_backup_options' ] );
        add_action( 'wp_ajax_restorebase_begin_package', [ $this, 'ajax_begin_package' ] );
        add_action( 'wp_ajax_restorebase_run_package_job', [ $this, 'ajax_run_package_job' ] );
        add_action( 'wp_ajax_restorebase_package_job_status', [ $this, 'ajax_package_job_status' ] );
        add_action( 'wp_ajax_restorebase_validate_package', [ $this, 'ajax_validate_package' ] );
        add_action( 'wp_ajax_restorebase_restore_preview', [ $this, 'ajax_restore_preview' ] );
        add_action( 'wp_ajax_restorebase_restore_dry_run', [ $this, 'ajax_restore_dry_run' ] );
        add_action( 'wp_ajax_restorebase_prepare_restore', [ $this, 'ajax_prepare_restore' ] );
        add_action( 'wp_ajax_restorebase_readiness', [ $this, 'ajax_readiness' ] );
        add_action( 'wp_ajax_restorebase_execute_staging_restore', [ $this, 'ajax_execute_staging_restore' ] );
        add_action( 'wp_ajax_restorebase_execute_production_restore', [ $this, 'ajax_execute_production_restore' ] );
        add_action( 'wp_ajax_restorebase_begin_production_restore', [ $this, 'ajax_begin_production_restore' ] );
        add_action( 'wp_ajax_restorebase_run_production_restore_job', [ $this, 'ajax_run_production_restore_job' ] );
        add_action( 'wp_ajax_nopriv_restorebase_run_production_restore_job', [ $this, 'ajax_run_production_restore_job' ] );
        add_action( 'wp_ajax_restorebase_restore_job_status', [ $this, 'ajax_restore_job_status' ] );
        add_action( 'wp_ajax_restorebase_cancel_job', [ $this, 'ajax_cancel_job' ] );
        add_action( 'wp_ajax_restorebase_ack_restore_result', [ $this, 'ajax_ack_restore_result' ] );
        add_action( 'wp_ajax_nopriv_restorebase_restore_job_status', [ $this, 'ajax_restore_job_status' ] );
        add_action( 'wp_ajax_restorebase_remote_upload', [ $this, 'ajax_remote_upload' ] );
        add_action( 'wp_ajax_restorebase_schedule_enable', [ $this, 'ajax_schedule_enable' ] );
        add_action( 'wp_ajax_restorebase_schedule_run_now', [ $this, 'ajax_schedule_run_now' ] );
        add_action( 'wp_ajax_restorebase_emergency_enable', [ $this, 'ajax_emergency_enable' ] );
        add_action( 'wp_ajax_restorebase_create_staging_clone', [ $this, 'ajax_create_staging_clone' ] );
        add_action( 'wp_ajax_restorebase_migration_bundle', [ $this, 'ajax_migration_bundle' ] );
        add_action( 'wp_ajax_restorebase_import_migration_package', [ $this, 'ajax_import_migration_package' ] );
        add_action( 'wp_ajax_restorebase_import_chunk', [ $this, 'ajax_import_chunk' ] );
        add_action( 'wp_ajax_restorebase_delete_snapshot', [ $this, 'ajax_delete_snapshot' ] );
        add_action( 'wp_ajax_restorebase_verify', [ $this, 'ajax_verify' ] );
        add_action( 'wp_ajax_restorebase_rollback_plan', [ $this, 'ajax_rollback_plan' ] );
        add_action( 'wp_ajax_restorebase_rollback_dry_run', [ $this, 'ajax_rollback_dry_run' ] );
        add_action( 'wp_ajax_restorebase_execute_rollback', [ $this, 'ajax_execute_rollback' ] );
        add_action( 'wp_ajax_restorebase_staging_plan', [ $this, 'ajax_staging_plan' ] );
        add_action( 'wp_ajax_restorebase_migration_plan', [ $this, 'ajax_migration_plan' ] );
        add_action( 'wp_ajax_restorebase_remote_storage', [ $this, 'ajax_remote_storage' ] );
        add_action( 'wp_ajax_restorebase_schedule_plan', [ $this, 'ajax_schedule_plan' ] );
        add_action( 'wp_ajax_restorebase_woo_safety', [ $this, 'ajax_woo_safety' ] );
        add_action( 'wp_ajax_restorebase_emergency_plan', [ $this, 'ajax_emergency_plan' ] );
        add_action( 'wp_ajax_restorebase_agency_report', [ $this, 'ajax_agency_report' ] );
        add_action( 'wp_ajax_restorebase_security_audit', [ $this, 'ajax_security_audit' ] );
        add_action( 'wp_ajax_restorebase_production_readiness', [ $this, 'ajax_production_readiness' ] );
        add_action( 'wp_ajax_restorebase_logs', [ $this, 'ajax_logs' ] );
        add_action( 'wp_ajax_restorebase_rank_math_guard', [ $this, 'ajax_rank_math_guard' ] );
    }

    public function add_admin_bar_button( \WP_Admin_Bar $bar ): void {
        if ( ! Capability::can_manage() || ! is_admin_bar_showing() ) {
            return;
        }

        $bar->add_node( [
            'id'     => 'restorebase-toggle',
            'parent' => 'top-secondary',
            'title'  => '<span class="rb-adminbar-dot" aria-hidden="true"></span><span class="ab-label">RB</span>',
            'href'   => '#restorebase',
            'meta'   => [ 'title' => __( 'RestoreBase Recovery Panel', 'restorebase' ) ],
        ] );
    }

    public function enqueue_assets(): void {
        if ( ! Capability::can_manage() ) {
            return;
        }

        wp_enqueue_style( 'restorebase-admin', VE_RECOVERY_URL . 'assets/admin.css', [], VE_RECOVERY_VERSION );
        wp_enqueue_script( 'restorebase-admin', VE_RECOVERY_URL . 'assets/admin.js', [], VE_RECOVERY_VERSION, true );

        wp_localize_script( 'restorebase-admin', 'restoreBaseAdmin', [
            'version'   => VE_RECOVERY_VERSION,
            'apiRoot'   => esc_url_raw( rest_url( VE_RECOVERY_API_NAMESPACE ) ),
            'nonce'     => wp_create_nonce( 'wp_rest' ),
            'ajaxUrl'   => esc_url_raw( admin_url( 'admin-ajax.php' ) ),
            'ajaxNonce' => wp_create_nonce( 'restorebase_admin' ),
            'maxChunkSize' => $this->max_chunk_size(),
            'lastRestoreJob' => ( new JobStore() )->latest_restore(),
            'labels'    => [
                'creating'   => __( 'Creating manifest snapshot job...', 'restorebase' ),
                'created'    => __( 'Manifest snapshot job completed.', 'restorebase' ),
                'packaging'  => __( 'Creating backup...', 'restorebase' ),
                'packaged'   => __( 'Backup completed.', 'restorebase' ),
                'validating' => __( 'Validating package...', 'restorebase' ),
                'validated'  => __( 'Package validation completed.', 'restorebase' ),
                'previewing' => __( 'Preparing restore preview...', 'restorebase' ),
                'previewed'  => __( 'Restore preview ready.', 'restorebase' ),
                'dryRun'     => __( 'Running restore dry-run...', 'restorebase' ),
                'dryRunDone' => __( 'Restore dry-run completed.', 'restorebase' ),
                'preparing'  => __( 'Preparing guarded restore workspace...', 'restorebase' ),
                'prepared'   => __( 'Guarded restore preparation completed.', 'restorebase' ),
                'readiness'  => __( 'Checking readiness...', 'restorebase' ),
                'readyScore' => __( 'Readiness completed.', 'restorebase' ),
                'executing'  => __( 'Executing staging-only restore...', 'restorebase' ),
                'executed'   => __( 'Staging-only restore execution completed.', 'restorebase' ),
                'production' => __( 'Running guarded production restore...', 'restorebase' ),
                'remote'     => __( 'Uploading package to remote storage...', 'restorebase' ),
                'schedule'   => __( 'Updating backup schedule...', 'restorebase' ),
                'emergency'  => __( 'Enabling emergency recovery...', 'restorebase' ),
                'staging'    => __( 'Creating staging clone...', 'restorebase' ),
                'migration'  => __( 'Creating backup...', 'restorebase' ),
                'importing'  => __( 'Importing backup...', 'restorebase' ),
                'imported'   => __( 'Backup imported.', 'restorebase' ),
                'deleting'   => __( 'Deleting snapshot/package...', 'restorebase' ),
                'deleted'    => __( 'Snapshot/package deleted.', 'restorebase' ),
                'rollback'   => __( 'Preparing rollback dry-run...', 'restorebase' ),
                'rollbacked' => __( 'Rollback action completed.', 'restorebase' ),
                'audit'      => __( 'Running security audit...', 'restorebase' ),
                'failed'     => __( 'Action failed.', 'restorebase' ),
                'ready'      => __( 'Ready', 'restorebase' ),
            ],
        ] );
    }

    public function render_restore_outcome_notice(): void {
        if ( ! Capability::can_manage() ) {
            return;
        }

        $job = ( new JobStore() )->latest_restore();
        if ( ! is_array( $job ) || empty( $job['job_key'] ) ) {
            return;
        }

        $status = (string) ( $job['status'] ?? '' );
        if ( ! in_array( $status, [ 'completed', 'failed', 'cancelled', 'running' ], true ) ) {
            return;
        }

        $job_key = (string) ( $job['job_key'] ?? '' );
        $seen = get_user_meta( get_current_user_id(), 'restorebase_seen_restore_outcomes', true );
        $seen = is_array( $seen ) ? array_map( 'strval', $seen ) : [];
        if ( '' !== $job_key && in_array( $job_key, $seen, true ) ) {
            return;
        }

        $finished_at = (string) ( $job['finished_at'] ?? '' );
        if ( '' !== $finished_at && strtotime( $finished_at ) && ( time() - strtotime( $finished_at ) ) > DAY_IN_SECONDS ) {
            return;
        }

        $summary = $this->restore_outcome_summary( $job );
        $class = 'completed' === $status && ! empty( $summary['verification_ok'] ) ? 'notice-success' : ( 'running' === $status ? 'notice-info' : 'notice-warning' );
        $title = 'running' === $status ? __( 'RestoreBase restore is still running.', 'restorebase' ) : ( 'completed' === $status ? __( 'RestoreBase restore completed.', 'restorebase' ) : __( 'RestoreBase restore needs attention.', 'restorebase' ) );
        $message = (string) ( $summary['message'] ?: ( $job['message'] ?? '' ) );
        ?>
        <div class="notice <?php echo esc_attr( $class ); ?> is-dismissible restorebase-outcome-notice" data-rb-outcome-job="<?php echo esc_attr( (string) $job['job_key'] ); ?>">
            <p>
                <strong><?php echo esc_html( $title ); ?></strong>
                <?php echo esc_html( $message ); ?>
                <?php if ( ! empty( $summary['steps'] ) ) : ?>
                    <span><?php echo esc_html( sprintf( __( 'Steps: %s.', 'restorebase' ), $summary['steps'] ) ); ?></span>
                <?php endif; ?>
                <a href="#restorebase" class="button button-small rb-open-panel-from-notice"><?php echo esc_html__( 'Open RestoreBase result', 'restorebase' ); ?></a>
                <a href="<?php echo esc_url( remove_query_arg( [ '_wpnonce', 'action' ] ) ); ?>" class="button button-small"><?php echo esc_html__( 'Refresh admin', 'restorebase' ); ?></a>
            </p>
        </div>
        <?php
    }

    private function restore_outcome_summary( array $job ): array {
        $tasks = isset( $job['task_state'] ) && is_array( $job['task_state'] ) ? $job['task_state'] : [];
        $total = count( $tasks );
        $done = 0;
        $failed = 0;
        foreach ( $tasks as $task ) {
            if ( ! is_array( $task ) ) {
                continue;
            }
            if ( 'completed' === (string) ( $task['status'] ?? '' ) ) {
                $done++;
            }
            if ( 'failed' === (string) ( $task['status'] ?? '' ) ) {
                $failed++;
            }
        }

        $result = isset( $job['result'] ) && is_array( $job['result'] ) ? $job['result'] : [];
        $verification = [];
        if ( isset( $result['post_restore_verification'] ) && is_array( $result['post_restore_verification'] ) ) {
            $verification = $result['post_restore_verification'];
        } elseif ( isset( $result['finish_execution']['post_restore_verification'] ) && is_array( $result['finish_execution']['post_restore_verification'] ) ) {
            $verification = $result['finish_execution']['post_restore_verification'];
        }

        $verification_ok = isset( $verification['ok'] ) ? (bool) $verification['ok'] : ( 'completed' === (string) ( $job['status'] ?? '' ) && 0 === $failed );
        $message = '';
        if ( ! empty( $verification['message'] ) ) {
            $message = (string) $verification['message'];
        } elseif ( ! empty( $job['message'] ) ) {
            $message = (string) $job['message'];
        }

        return [
            'steps'           => $total ? $done . '/' . $total . ( $failed ? ' · ' . $failed . ' failed' : '' ) : '',
            'verification_ok' => $verification_ok,
            'message'         => $message,
        ];
    }

    public function render_floating_panel(): void {
        if ( ! Capability::can_manage() ) {
            return;
        }
        $rb_encryption_on = '' !== (string) get_option( 'restorebase_package_passphrase', '' );
        $rb_mysqldump_on  = (bool) get_option( 'restorebase_enable_mysqldump', true );
        $rb_cipher_ready  = class_exists( '\VE\Modules\Recovery\Backup\PackageCipher' ) && \VE\Modules\Recovery\Backup\PackageCipher::available();
        ?>
        <div id="restorebase-backdrop" class="rb-backdrop" aria-hidden="true"></div>
        <div id="restorebase-panel" class="rb-panel" aria-hidden="true">
            <div class="rb-hdr">
                <div class="rb-drag-dot" aria-hidden="true">⌘</div>
                <div class="rb-brand">
                    <span class="rb-hdr-t"><?php echo esc_html__( 'RestoreBase', 'restorebase' ); ?></span>
                    <span class="rb-hdr-sub" data-rb-status><?php echo esc_html__( 'Ready', 'restorebase' ); ?></span>
                </div>
                <div class="rb-hdr-a">
                    <button type="button" class="rb-safe-toggle" data-rb-safe-toggle aria-expanded="true" title="<?php echo esc_attr__( 'Hide safe checks', 'restorebase' ); ?>">☑</button>
                    <button type="button" data-rb-refresh title="<?php echo esc_attr__( 'Refresh', 'restorebase' ); ?>">↻</button>
                    <button type="button" class="rb-close" title="<?php echo esc_attr__( 'Close', 'restorebase' ); ?>">×</button>
                </div>
            </div>

            <div class="rb-action-progress" data-rb-action-progress hidden aria-live="polite">
                <div class="rb-action-progress-top">
                    <span data-rb-progress-label><?php echo esc_html__( 'Working...', 'restorebase' ); ?></span>
                    <div class="rb-action-progress-tools">
                        <strong data-rb-progress-percent>0%</strong>
                        <button type="button" class="rb-progress-cancel" data-rb-cancel-action hidden><?php echo esc_html__( 'Cancel', 'restorebase' ); ?></button>
                    </div>
                </div>
                <div class="rb-action-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                    <span data-rb-progress-fill style="width:0%"></span>
                </div>
                <div class="rb-action-progress-meta" data-rb-progress-meta hidden></div>
                <div class="rb-action-progress-subtrack" data-rb-progress-subtrack hidden aria-hidden="true">
                    <span data-rb-subprogress-fill style="width:0%"></span>
                </div>
            </div>

            <div class="rb-body">

                <details class="rb-section rb-guide rb-migration-first rb-unified-workflow" open>
                    <summary class="rb-workflow-summary"><span><?php echo esc_html__( 'Backup / restore workflow', 'restorebase' ); ?></span><b><?php echo esc_html__( 'Main use', 'restorebase' ); ?></b></summary>
                    <div class="rb-migration-columns">
                        <div class="rb-migration-box">
                            <strong><?php echo esc_html__( 'Backup this site', 'restorebase' ); ?></strong>
                            <p><?php echo esc_html__( 'Create one backup file. Keep it safe or restore it on this site or another site.', 'restorebase' ); ?></p>
                            <button type="button" class="rb-btn rb-btn-accent rb-migration-bundle"><?php echo esc_html__( 'Create Backup', 'restorebase' ); ?></button>
                        </div>
                        <div class="rb-migration-box">
                            <strong><?php echo esc_html__( 'Restore a backup', 'restorebase' ); ?></strong>
                            <p><?php echo esc_html__( 'Import a backup file, then validate and preview it before restoring.', 'restorebase' ); ?></p>
                            <div class="rb-import-row" data-rb-dropzone>
                                <label class="rb-file-dropzone rb-file-dropzone-wide" data-rb-file-dropzone>
                                    <input type="file" class="rb-file-input" data-rb-import-file accept=".zip,application/zip" />
                                    <span class="rb-file-name" data-rb-file-name><?php echo esc_html__( 'Drop backup ZIP here or click to upload', 'restorebase' ); ?></span>
                                    <span class="rb-file-hint"><?php echo esc_html__( 'RestoreBase package (.zip)', 'restorebase' ); ?></span>
                                    <span class="rb-file-drop-text"><?php echo esc_html__( 'Drop backup ZIP to upload', 'restorebase' ); ?></span>
                                </label>
                                <button type="button" class="rb-btn rb-import-migration"><?php echo esc_html__( 'Import Backup', 'restorebase' ); ?></button>
                            </div>
                            <div class="rb-restore-passphrase" data-rb-restore-pass-wrap>
                                <label class="rb-field-label" for="rb-restore-passphrase"><?php echo esc_html__( 'Encrypted backup passphrase', 'restorebase' ); ?></label>
                                <span class="rb-pass-wrap"><button type="button" class="rb-pass-toggle" data-rb-pass-toggle aria-label="Show or hide passphrase">Show</button></span><input id="rb-restore-passphrase" type="password" class="rb-input" data-rb-restore-passphrase autocomplete="off" placeholder="<?php echo esc_attr__( 'Enter the passphrase this backup was encrypted with', 'restorebase' ); ?>" />
                                <small class="rb-restore-pass-hint"><?php echo esc_html__( 'Only needed if the backup is encrypted. Enter it before Import Backup, and it is reused for validate, preview and restore.', 'restorebase' ); ?></small>
                            </div>
                        </div>
                    </div>
                    <div class="rb-inline-safety-flow">
                        <div class="rb-inline-safety-head">
                            <strong><?php echo esc_html__( 'Before restore', 'restorebase' ); ?></strong>
                            <span class="rb-pill rb-pill-soft"><?php echo esc_html__( 'Always run', 'restorebase' ); ?></span>
                        </div>
                        <div class="rb-guide-steps rb-guide-steps-compact">
                            <div class="rb-guide-card rb-guide-card-static">
                                <span>1</span>
                                <strong><?php echo esc_html__( 'Have a backup', 'restorebase' ); ?></strong>
                                <small><?php echo esc_html__( 'Create one here or import one from another site.', 'restorebase' ); ?></small>
                            </div>
                            <button type="button" class="rb-guide-card rb-validate-package">
                                <span>2</span>
                                <strong><?php echo esc_html__( 'Validate backup', 'restorebase' ); ?></strong>
                                <small><?php echo esc_html__( 'Check package safety before use.', 'restorebase' ); ?></small>
                            </button>
                            <button type="button" class="rb-guide-card rb-preview-latest">
                                <span>3</span>
                                <strong><?php echo esc_html__( 'Preview restore risk', 'restorebase' ); ?></strong>
                                <small><?php echo esc_html__( 'See what would change first.', 'restorebase' ); ?></small>
                            </button>
                            <button type="button" class="rb-guide-card rb-restore-selected">
                                <span>4</span>
                                <strong><?php echo esc_html__( 'Restore backup', 'restorebase' ); ?></strong>
                                <small><?php echo esc_html__( 'Apply the selected backup after confirmation.', 'restorebase' ); ?></small>
                            </button>
                        </div>
                    </div>
                </details>

                <details class="rb-section rb-backup-options">
                    <summary><?php echo esc_html__( 'Backup options', 'restorebase' ); ?></summary>
                    <div class="rb-options-grid">
                        <label class="rb-option-row">
                            <input type="checkbox" data-rb-encrypt <?php checked( $rb_encryption_on ); ?> <?php disabled( ! $rb_cipher_ready ); ?> />
                            <span>
                                <strong><?php echo esc_html__( 'Encrypt backups (AES-256-GCM)', 'restorebase' ); ?></strong>
                                <small><?php echo $rb_cipher_ready
                                    ? esc_html__( 'A backup holds your full database. Encrypting makes the package useless without the passphrase. Use the same passphrase on the site you restore to.', 'restorebase' )
                                    : esc_html__( 'OpenSSL AES-256-GCM is not available on this server, so encryption is disabled.', 'restorebase' ); ?></small>
                            </span>
                        </label>
                        <div class="rb-option-field" data-rb-passphrase-wrap>
                            <label class="rb-field-label" for="rb-passphrase"><?php echo esc_html__( 'Encryption passphrase', 'restorebase' ); ?></label>
                            <span class="rb-pass-wrap"><button type="button" class="rb-pass-toggle" data-rb-pass-toggle aria-label="Show or hide passphrase">Show</button></span><input id="rb-passphrase" type="password" class="rb-input" data-rb-passphrase autocomplete="new-password" placeholder="<?php echo $rb_encryption_on ? esc_attr__( 'Encryption is on — leave blank to keep, type to change', 'restorebase' ) : esc_attr__( 'Set a passphrase to turn encryption on', 'restorebase' ); ?>" />
                        </div>
                        <label class="rb-option-row">
                            <input type="checkbox" data-rb-mysqldump <?php checked( $rb_mysqldump_on ); ?> />
                            <span>
                                <strong><?php echo esc_html__( 'Fast database export (mysqldump)', 'restorebase' ); ?></strong>
                                <small><?php echo esc_html__( 'Use the native mysqldump binary for faster exports on large databases. Falls back to the standard exporter automatically if it is unavailable.', 'restorebase' ); ?></small>
                            </span>
                        </label>
                        <div class="rb-options-actions">
                            <button type="button" class="rb-btn rb-btn-accent rb-save-backup-options"><?php echo esc_html__( 'Save backup options', 'restorebase' ); ?></button>
                        </div>
                    </div>
                </details>

                <details class="rb-section rb-advanced">
                    <summary><?php echo esc_html__( 'Advanced recovery tools', 'restorebase' ); ?></summary>
                    <div class="rb-action-grid rb-advanced-grid">
                        <button type="button" class="rb-btn rb-create-snapshot"><?php echo esc_html__( 'Manifest Snapshot', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-dry-run"><?php echo esc_html__( 'Dry Run Plan', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-prepare-restore"><?php echo esc_html__( 'Prepare Workspace', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-readiness"><?php echo esc_html__( 'Readiness Score', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-verify"><?php echo esc_html__( 'Verify Site', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-rollback-plan"><?php echo esc_html__( 'Rollback Plan', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-rollback-dry-run"><?php echo esc_html__( 'Rollback Dry Run', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-security-audit"><?php echo esc_html__( 'Security Audit', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-rank-math-guard"><?php echo esc_html__( 'Rank Math Key Guard', 'restorebase' ); ?></button>
                    </div>
                    <div class="rb-execute-gate">
                        <label class="rb-field-label" for="rb-confirm-restore"><?php echo esc_html__( 'Staging execution confirmation', 'restorebase' ); ?></label>
                        <input id="rb-confirm-restore" type="text" class="rb-input" data-rb-confirm placeholder="<?php echo esc_attr__( 'Type RESTORE STAGING', 'restorebase' ); ?>" autocomplete="off" />
                        <button type="button" class="rb-btn rb-btn-danger rb-execute-staging"><?php echo esc_html__( 'Execute Staging Restore', 'restorebase' ); ?></button>
                        <label class="rb-field-label" for="rb-confirm-production"><?php echo esc_html__( 'Production restore confirmation', 'restorebase' ); ?></label>
                        <input id="rb-confirm-production" type="text" class="rb-input" data-rb-production-confirm placeholder="<?php echo esc_attr__( 'Type RESTORE PRODUCTION', 'restorebase' ); ?>" autocomplete="off" />
                        <button type="button" class="rb-btn rb-btn-danger rb-execute-production"><?php echo esc_html__( 'Execute Production Restore', 'restorebase' ); ?></button>
                        <input id="rb-confirm-rollback" type="text" class="rb-input" data-rb-rollback-confirm placeholder="<?php echo esc_attr__( 'Type ROLLBACK STAGING', 'restorebase' ); ?>" autocomplete="off" />
                        <button type="button" class="rb-btn rb-btn-danger rb-execute-rollback"><?php echo esc_html__( 'Execute Staging Rollback', 'restorebase' ); ?></button>
                    </div>
                </details>

                <details class="rb-section rb-foundations">
                    <summary><?php echo esc_html__( 'System reports', 'restorebase' ); ?></summary>
                    <div class="rb-action-grid rb-advanced-grid">
                        <button type="button" class="rb-btn rb-staging-plan"><?php echo esc_html__( 'Staging Plan', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-migration-plan"><?php echo esc_html__( 'Restore Plan', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-create-staging-clone"><?php echo esc_html__( 'Create Staging Clone', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-migration-bundle"><?php echo esc_html__( 'Create Backup', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-remote-storage"><?php echo esc_html__( 'Remote Storage', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-remote-upload"><?php echo esc_html__( 'Upload Remote', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-schedule-plan"><?php echo esc_html__( 'Scheduling', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-schedule-enable"><?php echo esc_html__( 'Enable Schedule', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-schedule-run-now"><?php echo esc_html__( 'Run Scheduled Backup Now', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-woo-safety"><?php echo esc_html__( 'Woo Safety', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-emergency-plan"><?php echo esc_html__( 'Emergency Mode', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-emergency-enable"><?php echo esc_html__( 'Enable Emergency URL', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-agency-report"><?php echo esc_html__( 'Agency Report', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-security-audit"><?php echo esc_html__( 'Security Audit', 'restorebase' ); ?></button>
                        <button type="button" class="rb-btn rb-production-readiness"><?php echo esc_html__( '1.0 Readiness', 'restorebase' ); ?></button>
                    </div>
                </details>

                <details class="rb-section rb-jobs-section">
                    <summary><?php echo esc_html__( 'Recent jobs', 'restorebase' ); ?></summary>
                    <div data-rb-jobs class="rb-job-list"><p class="rb-empty"><?php echo esc_html__( 'Loading jobs...', 'restorebase' ); ?></p></div>
                </details>

                <details class="rb-section">
                    <summary><?php echo esc_html__( 'Recent snapshots & packages', 'restorebase' ); ?></summary>
                    <button type="button" class="rb-link-btn" data-rb-refresh><?php echo esc_html__( 'Refresh', 'restorebase' ); ?></button>
                    <div class="rb-snapshot-list" data-rb-snapshots><p class="rb-empty"><?php echo esc_html__( 'Loading...', 'restorebase' ); ?></p></div>
                </details>

                <details class="rb-section rb-storage-section">
                    <summary><?php echo esc_html__( 'Local storage', 'restorebase' ); ?></summary>
                    <code data-rb-storage><?php echo esc_html__( 'Loading...', 'restorebase' ); ?></code>
                </details>
            </div>
            <section class="rb-section rb-preview-section rb-safe-dock">
                    <div class="rb-section-head">
                        <h3><?php echo esc_html__( 'Selected package', 'restorebase' ); ?></h3>
                        <span class="rb-pill"><?php echo esc_html__( 'Safe checks', 'restorebase' ); ?></span>
                    </div>
                    <select id="rb-package-select" class="rb-select rb-select-hidden" data-rb-package-select aria-hidden="true" tabindex="-1">
                        <option value=""><?php echo esc_html__( 'Latest backup', 'restorebase' ); ?></option>
                    </select>
                    <div class="rb-menu" data-rb-package-menu>
                        <button type="button" class="rb-menu-btn" data-rb-package-menu-button><?php echo esc_html__( 'Latest backup', 'restorebase' ); ?></button>
                        <div class="rb-menu-list" data-rb-package-menu-list hidden></div>
                    </div>
                    <div data-rb-preview class="rb-preview-box">
                        <div class="rb-help-card">
                            <strong><?php echo esc_html__( 'What should I do first?', 'restorebase' ); ?></strong>
                            <p><?php echo esc_html__( 'Click “Create backup”. After it completes, validate it and preview restore risk. Do not run staging execution on a live/client site.', 'restorebase' ); ?></p>
                        </div>
                    </div>
            </section>
            <div class="rb-footer">
                <span><?php echo esc_html__( 'Snapshots:', 'restorebase' ); ?> <b data-rb-total>—</b> · <?php echo esc_html__( 'Packages:', 'restorebase' ); ?> <b data-rb-packages>—</b></span>
                <span><?php echo esc_html( 'v' . VE_RECOVERY_VERSION ); ?></span>
            </div>
        </div>
        <?php
    }

    public function ajax_status(): void { $this->check_ajax_request(); wp_send_json_success( ( new SnapshotManager() )->status() ); }
    public function ajax_snapshots(): void { $this->check_ajax_request(); $limit = isset( $_REQUEST['limit'] ) ? absint( wp_unslash( $_REQUEST['limit'] ) ) : 20; wp_send_json_success( ( new SnapshotManager() )->all( $limit ) ); }
    public function ajax_jobs(): void { $this->check_ajax_request(); $limit = isset( $_REQUEST['limit'] ) ? absint( wp_unslash( $_REQUEST['limit'] ) ) : 10; wp_send_json_success( ( new JobStore() )->all( $limit ) ); }
    public function ajax_create_snapshot(): void { $this->check_ajax_request(); $label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : ''; wp_send_json_success( ( new SnapshotJob() )->create( $label ) ); }
    public function ajax_save_backup_options(): void {
        $this->check_ajax_request();
        $encrypt       = isset( $_POST['encrypt'] ) && '' !== (string) $_POST['encrypt'] && 'false' !== (string) $_POST['encrypt'] && '0' !== (string) $_POST['encrypt'];
        $use_mysqldump = isset( $_POST['use_mysqldump'] ) && '' !== (string) $_POST['use_mysqldump'] && 'false' !== (string) $_POST['use_mysqldump'] && '0' !== (string) $_POST['use_mysqldump'];
        // Passphrase can contain spaces/symbols — do not sanitize_text_field it.
        $passphrase = isset( $_POST['passphrase'] ) ? trim( (string) wp_unslash( $_POST['passphrase'] ) ) : '';

        $cipher_ready = class_exists( '\VE\Modules\Recovery\Backup\PackageCipher' ) && \VE\Modules\Recovery\Backup\PackageCipher::available();

        if ( $encrypt && $cipher_ready ) {
            if ( '' !== $passphrase ) {
                update_option( 'restorebase_package_passphrase', $passphrase, false );
            } elseif ( '' === (string) get_option( 'restorebase_package_passphrase', '' ) ) {
                wp_send_json_error( [ 'message' => __( 'Enter a passphrase to turn on encryption.', 'restorebase' ) ], 400 );
            }
            // else: encryption already on and no new passphrase — keep the existing one.
        } else {
            delete_option( 'restorebase_package_passphrase' );
        }

        update_option( 'restorebase_enable_mysqldump', $use_mysqldump ? 1 : 0, false );

        wp_send_json_success( [
            'ok'                 => true,
            'message'            => __( 'Backup options saved.', 'restorebase' ),
            'encryption_enabled' => '' !== (string) get_option( 'restorebase_package_passphrase', '' ),
            'mysqldump_enabled'  => (bool) get_option( 'restorebase_enable_mysqldump', false ),
            'cipher_available'   => $cipher_ready,
        ] );
    }

    public function ajax_create_package(): void { $this->check_ajax_request(); $label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : ''; wp_send_json_success( ( new PackageBuilder() )->create( $label ) ); }
    public function ajax_begin_package(): void {
        $this->check_ajax_request();
        $this->prepare_backup_ajax_request();
        $label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '';
        wp_send_json_success( ( new PackageBuilder() )->begin( $label ) );
    }

    public function ajax_run_package_job(): void {
        $this->check_ajax_request();
        $this->prepare_backup_ajax_request();
        $job_key = isset( $_REQUEST['job_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['job_key'] ) ) : '';
        $result = ( new PackageBuilder() )->execute_job( $job_key );
        if ( empty( $result['ok'] ) ) {
            wp_send_json_error( $result, 403 );
        }
        wp_send_json_success( $result );
    }

    public function ajax_package_job_status(): void {
        $this->check_ajax_request();
        $this->prepare_backup_ajax_request( false );
        $job_key = isset( $_REQUEST['job_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['job_key'] ) ) : '';
        $result = ( new PackageBuilder() )->status( $job_key );
        if ( empty( $result['ok'] ) ) {
            wp_send_json_error( $result, 404 );
        }
        wp_send_json_success( $result );
    }
    public function ajax_validate_package(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); wp_send_json_success( ( new PackageValidator() )->validate_snapshot( $snapshot_key, $this->request_passphrase() ) ); }
    public function ajax_restore_preview(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); wp_send_json_success( ( new RestorePreview() )->preview_snapshot( $snapshot_key ) ); }
    public function ajax_restore_dry_run(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); wp_send_json_success( ( new RestoreDryRun() )->run( $snapshot_key, $this->request_passphrase() ) ); }
    public function ajax_prepare_restore(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); wp_send_json_success( ( new RestorePreparation() )->prepare( $snapshot_key, $this->request_passphrase() ) ); }
    public function ajax_readiness(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); wp_send_json_success( ( new RestoreReadiness() )->assess( $snapshot_key, [], $this->request_passphrase() ) ); }
    public function ajax_execute_staging_restore(): void { $this->check_ajax_restore_request(); $snapshot_key = $this->request_snapshot_key(); $confirmation = isset( $_REQUEST['confirmation'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['confirmation'] ) ) : ''; wp_send_json_success( ( new StagingRestoreExecutor() )->execute( $snapshot_key, $confirmation, $this->request_passphrase() ) ); }
    public function ajax_execute_production_restore(): void { $this->check_ajax_restore_request(); $snapshot_key = $this->request_snapshot_key(); $confirmation = isset( $_REQUEST['confirmation'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['confirmation'] ) ) : ''; wp_send_json_success( ( new ProductionRestoreExecutor() )->execute( $snapshot_key, $confirmation, $this->request_passphrase() ) ); }
    public function ajax_begin_production_restore(): void { $this->check_ajax_restore_request(); $snapshot_key = $this->request_snapshot_key(); $confirmation = isset( $_REQUEST['confirmation'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['confirmation'] ) ) : ''; wp_send_json_success( ( new ProductionRestoreExecutor() )->begin( $snapshot_key, $confirmation, $this->request_passphrase() ) ); }
    public function ajax_run_production_restore_job(): void { $job_key = isset( $_REQUEST['job_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['job_key'] ) ) : ''; $token = isset( $_REQUEST['status_token'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['status_token'] ) ) : ''; if ( is_user_logged_in() ) { $this->check_ajax_request(); } elseif ( '' === $job_key || '' === $token ) { wp_send_json_error( [ 'message' => __( 'Restore job token is missing.', 'restorebase' ) ], 403 ); } $result = ( new ProductionRestoreExecutor() )->execute_job( $job_key, $token ); if ( empty( $result['ok'] ) ) { wp_send_json_error( $result, 403 ); } wp_send_json_success( $result ); }
    public function ajax_restore_job_status(): void { $job_key = isset( $_REQUEST['job_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['job_key'] ) ) : ''; $token = isset( $_REQUEST['status_token'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['status_token'] ) ) : ''; $result = ( new ProductionRestoreExecutor() )->status( $job_key, $token ); if ( empty( $result['ok'] ) ) { wp_send_json_error( $result, 403 ); } wp_send_json_success( $result ); }
    public function ajax_cancel_job(): void { $this->check_ajax_request(); $job_key = isset( $_REQUEST['job_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['job_key'] ) ) : ''; wp_send_json_success( ( new JobStore() )->cancel( $job_key ) ); }
    public function ajax_ack_restore_result(): void { $this->check_ajax_request(); $job_key = isset( $_REQUEST['job_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['job_key'] ) ) : ''; $seen = get_user_meta( get_current_user_id(), 'restorebase_seen_restore_outcomes', true ); $seen = is_array( $seen ) ? array_map( 'strval', $seen ) : []; if ( '' !== $job_key && ! in_array( $job_key, $seen, true ) ) { $seen[] = $job_key; $seen = array_slice( array_values( array_unique( $seen ) ), -20 ); update_user_meta( get_current_user_id(), 'restorebase_seen_restore_outcomes', $seen ); } wp_send_json_success( [ 'ok' => true, 'job_key' => $job_key, 'seen' => $seen ] ); }
    public function ajax_remote_upload(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); $result = '' !== $snapshot_key ? ( new RemoteStorageManager() )->upload_snapshot( $snapshot_key ) : ( new RemoteStorageManager() )->upload_latest(); wp_send_json_success( $result ); }
    public function ajax_schedule_enable(): void { $this->check_ajax_request(); wp_send_json_success( ( new ScheduleManager() )->enable() ); }
    public function ajax_schedule_run_now(): void { $this->check_ajax_request(); wp_send_json_success( ( new ScheduleManager() )->run_now( 'manual_panel' ) ); }
    public function ajax_emergency_enable(): void { $this->check_ajax_request(); wp_send_json_success( ( new EmergencyRecovery() )->enable() ); }
    public function ajax_create_staging_clone(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); wp_send_json_success( ( new StagingCloneBuilder() )->create( $snapshot_key ) ); }
    public function ajax_migration_bundle(): void { $this->check_ajax_request(); wp_send_json_success( ( new PackageBuilder() )->create( 'Backup ' . current_time( 'mysql' ) ) ); }
    public function ajax_import_migration_package(): void { $this->check_ajax_request(); $label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : ''; $file = isset( $_FILES['package'] ) && is_array( $_FILES['package'] ) ? $_FILES['package'] : []; wp_send_json_success( ( new MigrationImporter() )->import_uploaded( $file, $label, $this->request_passphrase() ) ); }

    /**
     * Receive one chunk of a backup upload and append it to the assembly file.
     *
     * A whole backup cannot be posted in one request — post_max_size,
     * upload_max_filesize and proxy body limits (nginx client_max_body_size
     * defaults to 1MB) silently kill it, which left the destination with 0
     * packages. The browser slices the ZIP and posts it a chunk at a time.
     */
    public function ajax_import_chunk(): void {
        $this->check_ajax_request();
        $this->prepare_backup_ajax_request();

        $key   = isset( $_POST['upload_key'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_POST['upload_key'] ) ) : '';
        $index = isset( $_POST['chunk_index'] ) ? absint( $_POST['chunk_index'] ) : 0;
        $total = isset( $_POST['total_chunks'] ) ? absint( $_POST['total_chunks'] ) : 0;
        $name  = isset( $_POST['filename'] ) ? sanitize_file_name( (string) wp_unslash( $_POST['filename'] ) ) : 'restorebase-import.zip';
        $label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '';

        if ( '' === $key || strlen( $key ) < 8 || $total < 1 || $index >= $total ) {
            wp_send_json_error( [ 'message' => __( 'Invalid upload session.', 'restorebase' ) ], 400 );
        }
        if ( ! isset( $_FILES['chunk']['tmp_name'] ) || ! is_uploaded_file( (string) $_FILES['chunk']['tmp_name'] ) ) {
            wp_send_json_error( [ 'message' => __( 'Upload chunk is missing. The server may have rejected the request size.', 'restorebase' ) ], 400 );
        }
        if ( isset( $_FILES['chunk']['error'] ) && UPLOAD_ERR_OK !== (int) $_FILES['chunk']['error'] ) {
            wp_send_json_error( [ 'message' => __( 'Upload chunk failed. Check the server upload limits.', 'restorebase' ) ], 400 );
        }

        $dir = LocalStorage::base_dir() . 'tmp/';
        if ( ! is_dir( $dir ) ) {
            wp_mkdir_p( $dir );
        }
        LocalStorage::protect_dir( $dir );

        $part = $dir . 'upload-' . $key . '.part';
        if ( 0 === $index && file_exists( $part ) ) {
            @unlink( $part ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
        }

        $in  = @fopen( (string) $_FILES['chunk']['tmp_name'], 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged
        $out = @fopen( $part, 'ab' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! is_resource( $in ) || ! is_resource( $out ) ) {
            if ( is_resource( $in ) ) { fclose( $in ); }
            if ( is_resource( $out ) ) { fclose( $out ); }
            wp_send_json_error( [ 'message' => __( 'RestoreBase could not write the upload chunk to storage.', 'restorebase' ) ], 500 );
        }
        while ( ! feof( $in ) ) {
            $buffer = fread( $in, 1048576 );
            if ( false === $buffer || '' === $buffer ) {
                break;
            }
            fwrite( $out, $buffer );
        }
        fclose( $in );
        fclose( $out );

        if ( $index + 1 < $total ) {
            wp_send_json_success( [
                'ok'        => true,
                'assembling'=> true,
                'received'  => $index + 1,
                'total'     => $total,
                'bytes'     => file_exists( $part ) ? (int) filesize( $part ) : 0,
                'message'   => sprintf( 'Uploaded %d of %d chunks.', $index + 1, $total ),
            ] );
        }

        // Final chunk — confirm the assembly is the size the browser sent before
        // handing it to the importer, so a dropped chunk is caught here.
        $expected_size = isset( $_POST['total_size'] ) ? absint( $_POST['total_size'] ) : 0;
        $actual_size   = file_exists( $part ) ? (int) filesize( $part ) : 0;
        if ( $expected_size > 0 && $actual_size !== $expected_size ) {
            @unlink( $part ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
            wp_send_json_error( [
                'message' => sprintf(
                    /* translators: 1: received bytes, 2: expected bytes */
                    __( 'The upload is incomplete (%1$s of %2$s bytes arrived). Please try importing again.', 'restorebase' ),
                    number_format_i18n( $actual_size ),
                    number_format_i18n( $expected_size )
                ),
            ], 400 );
        }

        $result = ( new MigrationImporter() )->import_local_file( $part, $name, $label, $this->request_passphrase() );
        if ( file_exists( $part ) ) {
            @unlink( $part ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
        }
        if ( empty( $result['ok'] ) ) {
            wp_send_json_error( $result, 400 );
        }
        wp_send_json_success( $result );
    }

    /** Largest chunk this server will actually accept, with headroom for the rest of the POST body. */
    private function max_chunk_size(): int {
        $cap = 5 * 1024 * 1024;
        $limits = [];
        foreach ( [ 'post_max_size', 'upload_max_filesize' ] as $setting ) {
            $value = $this->parse_ini_size( (string) ini_get( $setting ) );
            if ( $value > 0 ) {
                $limits[] = $value;
            }
        }
        $limits[] = $cap;
        // 80% headroom covers multipart overhead, the nonce, and the other fields.
        return (int) max( 262144, min( $cap, (int) floor( min( $limits ) * 0.8 ) ) );
    }

    private function parse_ini_size( string $size ): int {
        $size = trim( $size );
        if ( '' === $size ) {
            return 0;
        }
        $unit = strtolower( substr( $size, -1 ) );
        $value = (float) $size;
        switch ( $unit ) {
            case 'g': $value *= 1024 * 1024 * 1024; break;
            case 'm': $value *= 1024 * 1024; break;
            case 'k': $value *= 1024; break;
        }
        return (int) $value;
    }
    public function ajax_delete_snapshot(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); $delete_files = ! isset( $_REQUEST['delete_files'] ) || '0' !== (string) wp_unslash( $_REQUEST['delete_files'] ); wp_send_json_success( ( new SnapshotManager() )->delete( $snapshot_key, $delete_files ) ); }
    public function ajax_verify(): void { $this->check_ajax_request(); wp_send_json_success( ( new RestoreVerifier() )->verify() ); }
    public function ajax_rollback_plan(): void { $this->check_ajax_request(); wp_send_json_success( ( new RollbackManager() )->plan() ); }
    public function ajax_rollback_dry_run(): void { $this->check_ajax_request(); $confirmation = isset( $_REQUEST['confirmation'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['confirmation'] ) ) : ''; wp_send_json_success( ( new RollbackExecutor() )->dry_run( $confirmation ) ); }
    public function ajax_execute_rollback(): void { $this->check_ajax_restore_request(); $confirmation = isset( $_REQUEST['confirmation'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['confirmation'] ) ) : ''; wp_send_json_success( ( new RollbackExecutor() )->execute( $confirmation ) ); }
    public function ajax_staging_plan(): void { $this->check_ajax_request(); wp_send_json_success( ( new StagingWorkflow() )->plan() ); }
    public function ajax_migration_plan(): void { $this->check_ajax_request(); wp_send_json_success( ( new MigrationPlanner() )->plan() ); }
    public function ajax_remote_storage(): void { $this->check_ajax_request(); wp_send_json_success( ( new RemoteStorageManager() )->plan() ); }
    public function ajax_schedule_plan(): void { $this->check_ajax_request(); wp_send_json_success( ( new ScheduleManager() )->plan() ); }
    public function ajax_woo_safety(): void { $this->check_ajax_request(); wp_send_json_success( ( new WooSafety() )->report() ); }
    public function ajax_emergency_plan(): void { $this->check_ajax_request(); wp_send_json_success( ( new EmergencyRecovery() )->plan() ); }
    public function ajax_agency_report(): void { $this->check_ajax_request(); wp_send_json_success( ( new AgencyDashboard() )->report() ); }
    public function ajax_security_audit(): void { $this->check_ajax_request(); wp_send_json_success( ( new SecurityAudit() )->report() ); }
    public function ajax_production_readiness(): void { $this->check_ajax_request(); wp_send_json_success( ( new ProductionReadiness() )->report() ); }
    public function ajax_logs(): void { $this->check_ajax_request(); $limit = isset( $_REQUEST['limit'] ) ? absint( wp_unslash( $_REQUEST['limit'] ) ) : 20; wp_send_json_success( Logger::latest( $limit ) ); }
    public function ajax_rank_math_guard(): void { $this->check_ajax_request(); wp_send_json_success( ( new RankMathConfigGuard() )->ensure_stable_constants( 'manual_panel' ) ); }

    public function download_package(): void {
        if ( ! Capability::can_manage() ) {
            wp_die( esc_html__( 'You do not have permission to download RestoreBase packages.', 'restorebase' ) );
        }

        $snapshot_key = isset( $_GET['snapshot_key'] ) ? sanitize_text_field( wp_unslash( $_GET['snapshot_key'] ) ) : '';
        if ( '' === $snapshot_key || ! wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'restorebase_download_' . $snapshot_key ) ) {
            wp_die( esc_html__( 'Invalid RestoreBase download request.', 'restorebase' ) );
        }

        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . Schema::table( 'snapshots' ) . " WHERE snapshot_key = %s LIMIT 1", $snapshot_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        if ( ! is_array( $row ) || empty( $row['meta_json'] ) ) {
            wp_die( esc_html__( 'RestoreBase package was not found.', 'restorebase' ) );
        }

        $meta = json_decode( (string) $row['meta_json'], true );
        $path = is_array( $meta ) && ! empty( $meta['package_path'] ) ? (string) $meta['package_path'] : '';
        if ( '' === $path || ! is_readable( $path ) ) {
            wp_die( esc_html__( 'RestoreBase package file is missing.', 'restorebase' ) );
        }

        Logger::info( 'package_downloaded', 'RestoreBase package downloaded.', [ 'snapshot_key' => $snapshot_key ] );

        // Chunked + resumable. readfile() buffered the whole package in memory and
        // was killed at memory_limit, producing a truncated "backup" that only
        // failed later at restore time.
        \VE\Modules\Recovery\Utils\FileStreamer::stream( $path, $this->download_name( $row, $meta ) );
    }


    private function download_name( array $row, array $meta ): string {
        if ( ! empty( $meta['package_filename'] ) && is_string( $meta['package_filename'] ) ) {
            // Whitelist instead of sanitize_file_name(): that function treats each dot
            // as an extension boundary and would rewrite the readable domain in the
            // name (example.com.zip -> example.com_.zip). basename() blocks traversal.
            $filename = basename( (string) $meta['package_filename'] );
            if ( preg_match( '/^[A-Za-z0-9._\-]{1,180}\.zip$/', $filename ) ) {
                return $filename;
            }
        }

        $source = '';
        if ( ! empty( $meta['source_site_url'] ) && is_string( $meta['source_site_url'] ) ) {
            $source = (string) wp_parse_url( $meta['source_site_url'], PHP_URL_HOST );
        }
        if ( '' === $source ) {
            $source = (string) wp_parse_url( home_url(), PHP_URL_HOST );
        }
        if ( '' === $source ) {
            $source = (string) get_bloginfo( 'name' );
        }

        // Same readable shape as PackageBuilder so the download name never drifts from
        // the stored package filename.
        $created = ! empty( $row['created_at'] ) ? strtotime( (string) $row['created_at'] ) : false;
        $stamp = gmdate( 'Y-m-d-Hi', $created ?: time() );

        return PackageBuilder::build_file_name( $source, $stamp, $this->backup_version_slug( $meta ) );
    }

    private function backup_version_slug( array $meta ): string {
        $version = '';
        foreach ( [ 'restorebase_version', 'created_with_version', 'product_version' ] as $key ) {
            if ( ! empty( $meta[ $key ] ) && is_string( $meta[ $key ] ) ) {
                $version = (string) $meta[ $key ];
                break;
            }
        }
        if ( '' === $version ) {
            $version = defined( 'VE_RECOVERY_VERSION' ) ? (string) VE_RECOVERY_VERSION : 'unknown';
        }
        $version = strtolower( (string) preg_replace( '/[^A-Za-z0-9]+/', '-', $version ) );
        $version = trim( $version, '-' );
        $version = preg_replace( '/^v+/', '', $version );
        return $version ?: 'unknown-version';
    }



    private function prepare_backup_ajax_request( bool $long = true ): void {
        if ( function_exists( 'nocache_headers' ) ) {
            nocache_headers();
        }
        if ( $long ) {
            @ignore_user_abort( true );
            if ( function_exists( 'set_time_limit' ) ) {
                @set_time_limit( 0 );
            }
        }
        if ( function_exists( 'wp_suspend_cache_addition' ) ) {
            wp_suspend_cache_addition( true );
        }
    }

    private function request_snapshot_key(): string {
        return isset( $_REQUEST['snapshot_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['snapshot_key'] ) ) : '';
    }

    /** Inline restore passphrase for encrypted packages. Not sanitize_text_field'd so symbols survive. */
    private function request_passphrase(): string {
        return isset( $_REQUEST['passphrase'] ) ? trim( (string) wp_unslash( $_REQUEST['passphrase'] ) ) : '';
    }

    private function check_ajax_request(): void {
        if ( ! Capability::can_manage() ) {
            wp_send_json_error( [ 'message' => __( 'Permission denied.', 'restorebase' ) ], 403 );
        }

        check_ajax_referer( 'restorebase_admin', 'nonce' );
    }

    /** Stricter gate for destructive actions (restore, rollback, staging swap). */
    private function check_ajax_restore_request(): void {
        if ( ! Capability::can_restore() ) {
            wp_send_json_error( [ 'message' => __( 'Restore permission denied.', 'restorebase' ) ], 403 );
        }

        check_ajax_referer( 'restorebase_admin', 'nonce' );
    }
}
