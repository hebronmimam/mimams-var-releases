/* global restoreBaseAdmin */
/* RestoreBase v1.0.0-rc57 — raw bundle backup engine and real-time progress timer */
(function () {
    'use strict';

    const cfg = window.restoreBaseAdmin || {};
    const panel = document.getElementById('restorebase-panel');
    const backdrop = document.getElementById('restorebase-backdrop');
    const toggle = document.getElementById('wp-admin-bar-restorebase-toggle');
    if (!panel || !toggle) return;

    const statusEl = panel.querySelector('[data-rb-status]');
    const totalEl = panel.querySelector('[data-rb-total]');
    const packagesEl = panel.querySelector('[data-rb-packages]');
    const storageEl = panel.querySelector('[data-rb-storage]');
    const snapshotsEl = panel.querySelector('[data-rb-snapshots]');
    const jobsEl = panel.querySelector('[data-rb-jobs]');
    const previewEl = panel.querySelector('[data-rb-preview]');
    const packageSelect = panel.querySelector('[data-rb-package-select]');
    const packageMenu = panel.querySelector('[data-rb-package-menu]');
    const packageMenuButton = panel.querySelector('[data-rb-package-menu-button]');
    const packageMenuList = panel.querySelector('[data-rb-package-menu-list]');
    const confirmInput = panel.querySelector('[data-rb-confirm]');
    const rollbackConfirmInput = panel.querySelector('[data-rb-rollback-confirm]');
    const productionConfirmInput = panel.querySelector('[data-rb-production-confirm]');
    const importFileInput = panel.querySelector('[data-rb-import-file]');
    const importDropzone = panel.querySelector('[data-rb-dropzone]');
    const importDropLabel = panel.querySelector('[data-rb-file-dropzone]');
    const importFileName = panel.querySelector('[data-rb-file-name]');
    const progressBox = panel.querySelector('[data-rb-action-progress]');
    const progressLabel = panel.querySelector('[data-rb-progress-label]');
    const progressPercent = panel.querySelector('[data-rb-progress-percent]');
    const progressFill = panel.querySelector('[data-rb-progress-fill]');
    const progressMeta = panel.querySelector('[data-rb-progress-meta]');
    const progressSubtrack = panel.querySelector('[data-rb-progress-subtrack]');
    const progressSubfill = panel.querySelector('[data-rb-subprogress-fill]');
    const progressTrack = progressBox ? progressBox.querySelector('[role="progressbar"]') : null;
    const safeToggle = panel.querySelector('[data-rb-safe-toggle]');
    const progressCancel = panel.querySelector('[data-rb-cancel-action]');
    const labels = cfg.labels || {};

    let snapshots = [];
    let droppedImportFile = null;
    let dragDepth = 0;
    let statusTimer = null;
    let progressTimer = null;
    let currentProgress = 0;
    let progressStartedAt = 0;
    let lastProgressJob = null;
    const progressSamples = {};
    const jobStartedAtClient = {};
    let backgroundScrollLocked = false;
    let previousBodyOverflow = '';
    let previousHtmlOverflow = '';
    let previousBodyPaddingRight = '';
    let retryCounter = 0;
    const retryCallbacks = {};
    let activeDialogCleanup = null;
    let activeRequestController = null;
    let activeJobKey = '';
    let activeJobToken = '';
    let activeActionName = '';
    let restoreSessionGuardActive = false;
    let restoreSessionGuardTimer = null;
    let restoreOutcomeRenderedKey = '';
    let restoreResumeAttempted = false;
    let autoRefreshTimer = null;

    const savedSafeChecks = window.localStorage ? window.localStorage.getItem('restorebaseSafeChecksHidden') : null;
    setSafeChecksHidden(savedSafeChecks === '1', false);

    toggle.addEventListener('click', function (event) {
        event.preventDefault();
        togglePanel();
    });

    safeToggle?.addEventListener('click', function (event) {
        event.preventDefault();
        setSafeChecksHidden(!panel.classList.contains('rb-safe-hidden'), true);
    });

    progressCancel?.addEventListener('click', function (event) {
        event.preventDefault();
        cancelActiveAction();
    });

    panel.querySelector('.rb-close')?.addEventListener('click', closePanel);
    backdrop?.addEventListener('click', function (event) {
        event.preventDefault();
        if (activeDialogCleanup) {
            activeDialogCleanup(false);
            return;
        }
        closePanel();
    });
    panel.querySelectorAll('[data-rb-refresh]').forEach(function (button) {
        button.addEventListener('click', refreshAll);
    });
    panel.querySelector('.rb-create-snapshot')?.addEventListener('click', createSnapshot);
    panel.querySelector('.rb-create-package')?.addEventListener('click', createPackage);
    panel.querySelector('.rb-validate-package')?.addEventListener('click', validatePackage);
    panel.querySelector('.rb-preview-latest')?.addEventListener('click', restorePreview);
    panel.querySelector('.rb-dry-run')?.addEventListener('click', restoreDryRun);
    panel.querySelector('.rb-prepare-restore')?.addEventListener('click', prepareRestore);
    panel.querySelector('.rb-readiness')?.addEventListener('click', restoreReadiness);
    panel.querySelector('.rb-execute-staging')?.addEventListener('click', executeStagingRestore);
    panel.querySelector('.rb-execute-production')?.addEventListener('click', executeProductionRestore);
    panel.querySelector('.rb-restore-selected')?.addEventListener('click', function (event) { restoreBackup(selectedPackageKey(), event.currentTarget); });
    panel.querySelector('.rb-verify')?.addEventListener('click', function () { simpleAction('restorebase_verify', 'Running verification...', renderVerification); });
    panel.querySelector('.rb-rollback-plan')?.addEventListener('click', function () { simpleAction('restorebase_rollback_plan', 'Building rollback plan...', renderGenericReport); });
    panel.querySelectorAll('.rb-rollback-dry-run').forEach(function (button) { button.addEventListener('click', rollbackDryRun); });
    panel.querySelector('.rb-execute-rollback')?.addEventListener('click', executeRollback);
    panel.querySelector('.rb-staging-plan')?.addEventListener('click', function () { simpleAction('restorebase_staging_plan', 'Building staging plan...', renderGenericReport); });
    panel.querySelector('.rb-migration-plan')?.addEventListener('click', function () { simpleAction('restorebase_migration_plan', 'Building restore plan...', renderGenericReport); });
    panel.querySelector('.rb-create-staging-clone')?.addEventListener('click', function () { simpleAction('restorebase_create_staging_clone', labels.staging || 'Creating staging clone...', renderGenericReport); });
    panel.querySelectorAll('.rb-migration-bundle').forEach(function (button) { button.addEventListener('click', createBackupAction); });
    panel.querySelector('.rb-save-backup-options')?.addEventListener('click', saveBackupOptions);
    panel.querySelectorAll('[data-rb-pass-toggle]').forEach(function (button) {
        button.addEventListener('click', function () {
            const field = button.closest('.rb-option-field, .rb-restore-passphrase')?.querySelector('input[data-rb-passphrase], input[data-rb-restore-passphrase]');
            if (!field) return;
            const hidden = field.type === 'password';
            field.type = hidden ? 'text' : 'password';
            button.textContent = hidden ? 'Hide' : 'Show';
            field.focus();
        });
    });
    panel.querySelector('.rb-import-migration')?.addEventListener('click', importMigrationPackage);
    setupImportDropzone();
    decorateStaticIcons();
    panel.querySelector('.rb-remote-storage')?.addEventListener('click', function () { simpleAction('restorebase_remote_storage', 'Loading remote storage...', renderGenericReport); });
    panel.querySelector('.rb-remote-upload')?.addEventListener('click', function () { simpleAction('restorebase_remote_upload', labels.remote || 'Uploading package to remote storage...', renderGenericReport); });
    panel.querySelector('.rb-schedule-plan')?.addEventListener('click', function () { simpleAction('restorebase_schedule_plan', 'Loading schedule...', renderGenericReport); });
    panel.querySelector('.rb-schedule-enable')?.addEventListener('click', function () { simpleAction('restorebase_schedule_enable', labels.schedule || 'Enabling schedule...', renderGenericReport); });
    panel.querySelector('.rb-schedule-run-now')?.addEventListener('click', function () { simpleAction('restorebase_schedule_run_now', 'Running scheduled backup now...', renderGenericReport); });
    panel.querySelector('.rb-woo-safety')?.addEventListener('click', function () { simpleAction('restorebase_woo_safety', 'Checking WooCommerce safety...', renderGenericReport); });
    panel.querySelector('.rb-emergency-plan')?.addEventListener('click', function () { simpleAction('restorebase_emergency_plan', 'Loading emergency recovery...', renderGenericReport); });
    panel.querySelector('.rb-emergency-enable')?.addEventListener('click', function () { simpleAction('restorebase_emergency_enable', labels.emergency || 'Enabling emergency recovery...', renderGenericReport); });
    panel.querySelector('.rb-agency-report')?.addEventListener('click', function () { simpleAction('restorebase_agency_report', 'Building agency report...', renderGenericReport); });
    panel.querySelectorAll('.rb-security-audit').forEach(function (button) { button.addEventListener('click', function () { simpleAction('restorebase_security_audit', labels.audit || 'Running security audit...', renderSecurityAudit); }); });
    panel.querySelector('.rb-production-readiness')?.addEventListener('click', function () { simpleAction('restorebase_production_readiness', 'Checking 1.0 readiness...', renderProductionReadiness); });
    panel.querySelectorAll('.rb-rank-math-guard').forEach(function (button) { button.addEventListener('click', function () { simpleAction('restorebase_rank_math_guard', 'Stabilizing Rank Math keys...', renderGenericReport); }); });

    panel.addEventListener('click', function (event) {
        const passToggle = event.target && event.target.closest ? event.target.closest('[data-rb-prompt-toggle]') : null;
        if (passToggle) {
            event.preventDefault();
            const promptField = panel.querySelector('[data-rb-prompt-pass]');
            if (promptField) {
                const hidden = promptField.type === 'password';
                promptField.type = hidden ? 'text' : 'password';
                passToggle.textContent = hidden ? 'Hide' : 'Show';
            }
            return;
        }

        const retryButton = event.target && event.target.closest ? event.target.closest('[data-rb-retry]') : null;
        if (retryButton) {
            event.preventDefault();
            const retryId = retryButton.getAttribute('data-rb-retry') || '';
            if (retryButton.hasAttribute('data-rb-pass-submit')) {
                const typed = panel.querySelector('[data-rb-prompt-pass]');
                const shared = panel.querySelector('[data-rb-restore-passphrase]');
                if (typed && shared) shared.value = typed.value;
                if (typed && !typed.value.trim()) {
                    setStatus('Enter the passphrase this backup was encrypted with.');
                    try { typed.focus(); } catch (e) {}
                    return;
                }
            }
            if (retryCallbacks[retryId]) retryCallbacks[retryId](retryButton);
            return;
        }

        const previewButton = event.target && event.target.closest ? event.target.closest('[data-rb-preview-key]') : null;
        if (previewButton && previewEl && previewEl.contains(previewButton)) {
            event.preventDefault();
            restorePreview(previewButton.getAttribute('data-rb-preview-key') || '');
            return;
        }

        const validateButton = event.target && event.target.closest ? event.target.closest('[data-rb-validate-key]') : null;
        if (validateButton && previewEl && previewEl.contains(validateButton)) {
            event.preventDefault();
            setPackageValue(validateButton.getAttribute('data-rb-validate-key') || '');
            validatePackage();
            return;
        }

        const restoreButton = event.target && event.target.closest ? event.target.closest('[data-rb-restore-key]') : null;
        if (restoreButton && previewEl && previewEl.contains(restoreButton)) {
            event.preventDefault();
            restoreBackup(restoreButton.getAttribute('data-rb-restore-key') || '', restoreButton);
            return;
        }

        const ackButton = event.target && event.target.closest ? event.target.closest('[data-rb-ack-restore-result]') : null;
        if (ackButton && previewEl && previewEl.contains(ackButton)) {
            event.preventDefault();
            markRestoreOutcomeSeen(ackButton.getAttribute('data-rb-ack-restore-result') || '');
            previewEl.innerHTML = '<div class="rb-help-card"><strong>Restore result dismissed</strong><p>You can still reopen it from Recent Jobs.</p></div>';
            return;
        }

        const verifyButton = event.target && event.target.closest ? event.target.closest('[data-rb-run-verify]') : null;
        if (verifyButton && previewEl && previewEl.contains(verifyButton)) {
            event.preventDefault();
            simpleAction('restorebase_verify', 'Running verification...', renderVerification);
            return;
        }

        const refreshButton = event.target && event.target.closest ? event.target.closest('[data-rb-refresh-admin]') : null;
        if (refreshButton) {
            event.preventDefault();
            performAdminRefresh(refreshButton.getAttribute('data-rb-refresh-admin') || activeJobKey || '');
            return;
        }

        const deleteButton = event.target && event.target.closest ? event.target.closest('[data-rb-delete-key]') : null;
        if (deleteButton && previewEl && previewEl.contains(deleteButton)) {
            event.preventDefault();
            deleteSnapshot(deleteButton.getAttribute('data-rb-delete-key') || '', deleteButton.getAttribute('data-rb-delete-label') || 'this backup', deleteButton);
            return;
        }

        const download = event.target && event.target.closest ? event.target.closest('.rb-inline-download') : null;
        if (download && panel.contains(download)) {
            downloadProgress('Download started.');
        }
    });

    if (packageMenuButton && packageMenuList) {
        packageMenuButton.addEventListener('click', function (event) {
            event.preventDefault();
            togglePackageMenu();
        });
    }

    document.addEventListener('click', function (event) {
        if (!packageMenu || !packageMenu.contains(event.target)) {
            closePackageMenu();
        }
    });

    document.addEventListener('click', function (event) {
        const noticeButton = event.target && event.target.closest ? event.target.closest('.rb-open-panel-from-notice') : null;
        if (!noticeButton) return;
        event.preventDefault();
        openPanel();
        const latest = cfg.lastRestoreJob || latestRestoreJobFromCache();
        if (latest) renderRestoreOutcome(latest, {force: true});
    });

    document.addEventListener('click', function (event) {
        const dismiss = event.target && event.target.closest ? event.target.closest('.restorebase-outcome-notice .notice-dismiss') : null;
        if (!dismiss) return;
        const notice = dismiss.closest('.restorebase-outcome-notice');
        if (!notice) return;
        const jobKey = notice.getAttribute('data-rb-outcome-job') || '';
        if (jobKey) markRestoreOutcomeSeen(jobKey);
    });

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape' && packageMenu && packageMenu.classList.contains('open')) {
            closePackageMenu();
            return;
        }
        if (event.key === 'Escape' && activeDialogCleanup) {
            activeDialogCleanup(false);
            return;
        }
        if (event.key === 'Escape' && panel.classList.contains('rb-open')) closePanel();
    });


    if (window.jQuery) {
        window.jQuery(document).on('heartbeat-tick.restorebase-session-guard heartbeat-error.restorebase-session-guard', function (event, data) {
            if (!restoreSessionGuardActive) return;
            if (data && Object.prototype.hasOwnProperty.call(data, 'wp-auth-check')) {
                delete data['wp-auth-check'];
            }
            hideWordPressAuthCheck();
        });
        window.jQuery(document).on('heartbeat-send.restorebase-session-guard', function (event, data) {
            if (!restoreSessionGuardActive || !data) return;
            data['restorebase_restore_running'] = 1;
            if (Object.prototype.hasOwnProperty.call(data, 'wp-auth-check')) {
                delete data['wp-auth-check'];
            }
        });
    }

    document.addEventListener('wheel', preventBackgroundScroll, {passive: false});
    document.addEventListener('touchmove', preventBackgroundScroll, {passive: false});
    window.setTimeout(function () {
        if (!handlePostRestoreAutoRefreshReturn()) resumeRestoreAfterReload();
    }, 600);

    function setSafeChecksHidden(hidden, persist) {
        panel.classList.toggle('rb-safe-hidden', !!hidden);
        if (safeToggle) {
            safeToggle.classList.toggle('rb-safe-toggle-off', !!hidden);
            safeToggle.setAttribute('aria-expanded', hidden ? 'false' : 'true');
            safeToggle.setAttribute('title', hidden ? 'Show safe checks' : 'Hide safe checks');
        }
        if (persist && window.localStorage) {
            window.localStorage.setItem('restorebaseSafeChecksHidden', hidden ? '1' : '0');
        }
    }

    function togglePanel() {
        if (panel.classList.contains('rb-open')) {
            closePanel();
        } else {
            openPanel();
        }
    }

    function openPanel() {
        panel.classList.add('rb-open');
        panel.setAttribute('aria-hidden', 'false');
        if (backdrop) { backdrop.classList.add('show'); backdrop.setAttribute('aria-hidden', 'false'); }
        toggle.classList.add('rb-open');
        lockBackgroundScroll();
        hydrateCachedStatus();
        hydrateCachedSnapshots();
        hydrateCachedJobs();
        refreshAll();
    }

    function closePanel() {
        if (activeDialogCleanup) {
            activeDialogCleanup(false);
        } else {
            document.querySelectorAll('.rb-dialog-wrap').forEach(function (dialog) { dialog.remove(); });
        }
        panel.classList.remove('rb-open');
        panel.setAttribute('aria-hidden', 'true');
        if (backdrop) { backdrop.classList.remove('show'); backdrop.setAttribute('aria-hidden', 'true'); }
        toggle.classList.remove('rb-open');
        unlockBackgroundScroll();
        stopPolling();
    }

    function lockBackgroundScroll() {
        if (backgroundScrollLocked) return;
        backgroundScrollLocked = true;
        previousBodyOverflow = document.body.style.overflow || '';
        previousHtmlOverflow = document.documentElement.style.overflow || '';
        previousBodyPaddingRight = document.body.style.paddingRight || '';
        const scrollbarWidth = Math.max(0, window.innerWidth - document.documentElement.clientWidth);
        document.documentElement.classList.add('restorebase-scroll-locked');
        document.body.classList.add('restorebase-scroll-locked');
        document.documentElement.style.overflow = 'hidden';
        document.body.style.overflow = 'hidden';
        if (scrollbarWidth) {
            const currentPadding = parseFloat(window.getComputedStyle(document.body).paddingRight) || 0;
            document.body.style.paddingRight = (currentPadding + scrollbarWidth) + 'px';
        }
    }

    function unlockBackgroundScroll() {
        if (!backgroundScrollLocked) return;
        backgroundScrollLocked = false;
        document.documentElement.classList.remove('restorebase-scroll-locked');
        document.body.classList.remove('restorebase-scroll-locked');
        document.documentElement.style.overflow = previousHtmlOverflow;
        document.body.style.overflow = previousBodyOverflow;
        document.body.style.paddingRight = previousBodyPaddingRight;
    }

    function preventBackgroundScroll(event) {
        if (!panel.classList.contains('rb-open')) return;
        if (panel.contains(event.target)) return;
        event.preventDefault();
    }


    function rbIcon(name) {
        return '';
    }

    function statusIcon(status) {
        return '';
    }

    function enableRestoreSessionGuard() {
        restoreSessionGuardActive = true;
        document.documentElement.classList.add('restorebase-restore-in-progress');
        document.body.classList.add('restorebase-restore-in-progress');
        hideWordPressAuthCheck();
        if (restoreSessionGuardTimer) window.clearInterval(restoreSessionGuardTimer);
        restoreSessionGuardTimer = window.setInterval(hideWordPressAuthCheck, 500);
        if (window.jQuery) {
            // Stop the core auth-check heartbeat listener while the database is being swapped.
            // The current restore uses its own signed status token, so it can keep reporting progress.
            window.jQuery(document).off('heartbeat-tick.wp-auth-check');
        }
        try {
            if (window.wp && window.wp.heartbeat && typeof window.wp.heartbeat.interval === 'function') {
                window.wp.heartbeat.interval('slow');
            }
        } catch (error) {}
    }

    function disableRestoreSessionGuard() {
        restoreSessionGuardActive = false;
        document.documentElement.classList.remove('restorebase-restore-in-progress');
        document.body.classList.remove('restorebase-restore-in-progress');
        if (restoreSessionGuardTimer) window.clearInterval(restoreSessionGuardTimer);
        restoreSessionGuardTimer = null;
    }

    function hideWordPressAuthCheck() {
        const wrap = document.getElementById('wp-auth-check-wrap');
        if (wrap) {
            wrap.style.display = 'none';
            wrap.style.visibility = 'hidden';
            wrap.setAttribute('aria-hidden', 'true');
        }
        const backdrop = document.querySelector('.wp-auth-check-backdrop');
        if (backdrop) {
            backdrop.style.display = 'none';
            backdrop.style.visibility = 'hidden';
        }
        document.body.classList.remove('modal-open');
    }

    function refreshAll() {
        setStatus(labels.ready || 'Refreshing...');
        const requests = [loadStatus(), loadSnapshots(), loadJobs()];
        return Promise.allSettled(requests).then(function (results) {
            const failed = results.filter(function (item) { return item.status === 'rejected'; }).length;
            setStatus(failed ? 'Some panel data could not load. Use Retry.' : 'Ready');
            return results;
        });
    }

    function startProgress(message, startAt, cancellable) {
        if (!progressBox || !progressFill || !progressLabel || !progressPercent) return;
        window.clearTimeout(progressBox._hideTimer || 0);
        if (progressTimer) window.clearInterval(progressTimer);
        progressTimer = null;
        progressStartedAt = Date.now();
        lastProgressJob = null;
        progressTimer = window.setInterval(function () {
            if (!progressBox || progressBox.hidden || !lastProgressJob) return;
            const status = String((lastProgressJob && lastProgressJob.status) || '');
            if (status === 'running' || status === 'queued') {
                updateJobProgressDetails(lastProgressJob, currentProgress, true);
            }
        }, 1000);
        currentProgress = Math.max(3, Math.min(35, Number(startAt) || 8));
        progressBox.hidden = false;
        progressBox.classList.remove('rb-progress-done', 'rb-progress-error');
        progressBox.classList.toggle('rb-progress-cancellable', !!cancellable);
        if (progressCancel) progressCancel.hidden = !cancellable;
        clearProgressMeta();
        setStatus(cancellable ? 'Working…' : 'Ready');
        updateProgress(currentProgress, message || 'Working...');
    }

    function updateProgress(percent, message) {
        if (!progressBox || !progressFill || !progressLabel || !progressPercent) return;
        currentProgress = Math.max(0, Math.min(100, Math.round(Number(percent) || 0)));
        progressFill.style.width = currentProgress + '%';
        progressPercent.textContent = currentProgress + '%';
        if (message) progressLabel.textContent = message;
        if (progressTrack) progressTrack.setAttribute('aria-valuenow', String(currentProgress));
    }

    function clearProgressMeta() {
        if (progressMeta) { progressMeta.hidden = true; progressMeta.innerHTML = ''; }
        if (progressSubtrack) progressSubtrack.hidden = true;
        if (progressSubfill) progressSubfill.style.width = '0%';
    }

    function finishProgress(message) {
        if (!progressBox) return;
        if (progressTimer) window.clearInterval(progressTimer);
        progressTimer = null;
        lastProgressJob = null;
        activeJobKey = ''; activeJobToken = ''; activeActionName = ''; activeRequestController = null;
        if (progressCancel) progressCancel.hidden = true;
        setPanelActionLock(false);
        progressBox.classList.remove('rb-progress-error');
        progressBox.classList.add('rb-progress-done');
        updateProgress(100, message || 'Completed.');
        if (progressSubtrack) progressSubtrack.hidden = true;
        progressBox._hideTimer = window.setTimeout(function () {
            progressBox.hidden = true;
            progressBox.classList.remove('rb-progress-done');
            updateProgress(0, 'Working...');
            clearProgressMeta();
        }, 1800);
    }

    function failProgress(message) {
        if (!progressBox) return;
        if (progressTimer) window.clearInterval(progressTimer);
        progressTimer = null;
        lastProgressJob = null;
        activeJobKey = ''; activeJobToken = ''; activeActionName = ''; activeRequestController = null;
        if (progressCancel) progressCancel.hidden = true;
        setPanelActionLock(false);
        progressBox.hidden = false;
        progressBox.classList.remove('rb-progress-done');
        progressBox.classList.add('rb-progress-error');
        updateProgress(Math.max(currentProgress, 8), message || 'Failed.');
    }

    function downloadProgress(message) {
        startProgress(message || 'Starting download...', 18);
        updateProgress(100, message || 'Download started.');
        finishProgress(message || 'Download started.');
    }

    function api(action, data, options) {
        options = options || {};
        const body = new URLSearchParams();
        body.append('action', action);
        body.append('nonce', cfg.ajaxNonce || '');
        Object.keys(data || {}).forEach(function (key) {
            body.append(key, data[key]);
        });

        return fetch(cfg.ajaxUrl, {
            method: 'POST',
            credentials: 'same-origin',
            headers: {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'},
            body: body.toString(),
            signal: options.signal || undefined
        }).catch(function (networkError) {
            throw buildAjaxError({action: action, networkError: networkError});
        }).then(function (response) {
            return response.text().then(function (text) {
                let json = null;
                try {
                    json = JSON.parse(text || '{}');
                } catch (parseError) {
                    throw buildAjaxError({action: action, response: response, text: text, parseError: parseError});
                }

                if (!response.ok || !json || json.success === false) {
                    throw buildAjaxError({action: action, response: response, text: text, json: json});
                }

                return json.data;
            });
        });
    }


    function apiUpload(action, formData, options) {
        options = options || {};
        formData.append('action', action);
        formData.append('nonce', cfg.ajaxNonce || '');

        return new Promise(function (resolve, reject) {
            const xhr = new XMLHttpRequest();
            xhr.open('POST', cfg.ajaxUrl, true);
            xhr.withCredentials = true;
            if (options.signal) {
                if (options.signal.aborted) { xhr.abort(); }
                options.signal.addEventListener('abort', function () { xhr.abort(); });
            }

            xhr.upload.onprogress = function (event) {
                if (!event.lengthComputable || options.quiet) return;
                const percent = Math.min(72, Math.max(8, Math.round((event.loaded / event.total) * 72)));
                updateProgress(percent, 'Uploading backup...');
            };

            xhr.onload = function () {
                let json = null;
                try {
                    json = JSON.parse(xhr.responseText || '{}');
                } catch (parseError) {
                    reject(buildAjaxError({action: action, status: xhr.status, text: xhr.responseText, parseError: parseError, upload: true}));
                    return;
                }
                if (xhr.status < 200 || xhr.status >= 300 || !json || json.success === false) {
                    reject(buildAjaxError({action: action, status: xhr.status, text: xhr.responseText, json: json, upload: true}));
                    return;
                }
                resolve(json.data);
            };

            xhr.onerror = function () {
                reject(buildAjaxError({action: action, networkError: new Error('NetworkError when attempting to fetch resource.'), upload: true}));
            };
            xhr.onabort = function () {
                reject(buildAjaxError({action: action, networkError: new Error('Request cancelled.'), upload: true, cancelled: true}));
            };

            xhr.send(formData);
        });
    }

    function loadStatus() {
        return api('restorebase_status').then(function (data) {
            writeCache('status', data || {});
            applyStatusData(data || {});
            if (data && data.last_restore_job) maybeRenderLatestRestoreOutcome([data.last_restore_job], {fromStatus: true});
            if (Array.isArray(data.active_jobs) && data.active_jobs.length) {
                startPolling();
            }
            return data;
        }).catch(function (error) {
            const info = getErrorInfo(error);
            if (totalEl) totalEl.textContent = '—';
            if (packagesEl) packagesEl.textContent = '—';
            if (storageEl) storageEl.textContent = info.title + ' — refresh to retry';
            throw error;
        });
    }

    function applyStatusData(data) {
        if (totalEl) totalEl.textContent = data.total_snapshots || 0;
        if (packagesEl) packagesEl.textContent = data.package_snapshots || 0;
        if (storageEl) storageEl.textContent = data.storage_path || '—';
    }

    function loadSnapshots() {
        return api('restorebase_snapshots', {limit: 20}).then(function (data) {
            snapshots = Array.isArray(data) ? data : [];
            writeCache('snapshots', snapshots);
            renderSnapshots(snapshots);
            renderPackageSelect(snapshots);
            if (snapshotsEl) snapshotsEl.setAttribute('data-rb-has-cache', snapshots.length ? '1' : '0');
            return snapshots;
        }).catch(function (error) {
            renderSectionError(snapshotsEl, 'Recent backups could not load', error, loadSnapshots);
            throw error;
        });
    }

    function loadJobs() {
        const hasCachedJobs = jobsEl && jobsEl.getAttribute('data-rb-has-cache') === '1';
        if (jobsEl && !hasCachedJobs) {
            jobsEl.innerHTML = '<p class="rb-empty">Loading latest jobs...</p>';
        }
        return api('restorebase_jobs', {limit: 10}).then(function (data) {
            const items = Array.isArray(data) ? data : [];
            writeCache('jobs', items);
            renderJobs(items);
            maybeRenderLatestRestoreOutcome(items);
            return data;
        }).catch(function (error) {
            renderSectionError(jobsEl, 'Recent jobs could not load', error, loadJobs);
            throw error;
        });
    }

    function hydrateCachedStatus() {
        const cached = readCache('status');
        if (!cached || typeof cached !== 'object') return;
        applyStatusData(cached);
    }

    function hydrateCachedSnapshots() {
        const cached = readCache('snapshots');
        if (!cached || !Array.isArray(cached) || !cached.length || !snapshotsEl) return;
        snapshots = cached;
        renderSnapshots(cached);
        renderPackageSelect(cached);
        snapshotsEl.setAttribute('data-rb-has-cache', '1');
    }

    function hydrateCachedJobs() {
        const cached = readCache('jobs');
        if (!cached || !Array.isArray(cached) || !cached.length || !jobsEl) return;
        renderJobs(cached);
        maybeRenderLatestRestoreOutcome(cached, {cached: true});
        jobsEl.setAttribute('data-rb-has-cache', '1');
    }

    function readCache(key) {
        if (!window.localStorage) return null;
        try {
            const raw = window.localStorage.getItem('restorebaseCache.' + key);
            if (!raw) return null;
            const parsed = JSON.parse(raw);
            if (!parsed || !parsed.value) return null;
            const maxAge = key === 'jobs' ? 10 * 60 * 1000 : (key === 'status' ? 5 * 60 * 1000 : 3 * 60 * 1000);
            if (parsed.time && Date.now() - parsed.time > maxAge) return null;
            return parsed.value;
        } catch (error) {
            return null;
        }
    }

    function writeCache(key, value) {
        if (!window.localStorage) return;
        try {
            window.localStorage.setItem('restorebaseCache.' + key, JSON.stringify({time: Date.now(), value: value}));
        } catch (error) {}
    }

    function buildAjaxError(context) {
        const info = classifyAjaxError(context || {});
        const error = new Error(info.message || info.title || 'Request failed.');
        error.rbInfo = info;
        return error;
    }

    function classifyAjaxError(context) {
        context = context || {};
        const response = context.response || null;
        const status = response ? response.status : (Number(context.status) || 0);
        const text = String(context.text || '');
        const trimmed = text.trim();
        const json = context.json || null;
        const action = context.action || 'unknown request';
        const isNetwork = !!context.networkError;
        const jsonMessage = json && json.data && json.data.message ? String(json.data.message) : '';
        const needsPassphrase = !!(json && json.data && json.data.needs_passphrase);
        const snippet = trimmed ? trimmed.replace(/\s+/g, ' ').slice(0, 220) : '';
        const info = {
            code: 'request_failed',
            title: 'Request failed',
            message: jsonMessage || 'RestoreBase could not complete this WordPress request.',
            needsPassphrase: needsPassphrase,
            advice: 'Refresh the WordPress admin page, then try again.',
            action: action,
            status: status,
            details: snippet
        };

        if (isNetwork) {
            const networkMessage = context.networkError && context.networkError.message ? String(context.networkError.message) : '';
            info.code = 'network';
            info.title = 'WordPress request was blocked';
            info.message = 'RestoreBase could not reach WordPress admin-ajax.php.';
            info.advice = 'Check your connection, maintenance/security plugins, then retry. If this happened after updating RestoreBase, hard-refresh the admin page.';
            info.details = networkMessage;
            if (/restorebase_run_package_job|restorebase_package_job_status|restorebase_backup/i.test(action + ' ' + activeActionName)) {
                info.title = 'Backup connection paused';
                info.message = 'WordPress temporarily stopped answering while RestoreBase was archiving files.';
                info.advice = 'RestoreBase will keep retrying during active backups. If it fully stops for several minutes, cancel the job, refresh wp-admin, and try again.';
            }
            if (/restorebase_run_production_restore_job|restorebase_restore_job_status|restorebase_restore/i.test(action + ' ' + activeActionName)) {
                info.title = 'Restore connection changed';
                info.message = 'WordPress stopped answering while RestoreBase was restoring. The restore may have changed files, database state, or admin access before the panel could receive the final report.';
                info.advice = 'Refresh the site once. If wp-admin opens, check Recent Jobs and verify the restored site. If it is blocked, fix .htaccess/server rules first, then retry with a fresh RC48 backup.';
            }
            return info;
        }

        if (status === 403 || trimmed === '-1' || /nonce|permission|forbidden|not allowed|security check/i.test(jsonMessage + ' ' + trimmed)) {
            info.code = 'session_or_permission';
            info.title = 'Session expired or permission blocked';
            info.message = jsonMessage || 'WordPress rejected the request for security or permission reasons.';
            info.advice = 'Hard-refresh the admin page, make sure you are still logged in as an admin, then try again.';
            return info;
        }

        if (trimmed === '0') {
            info.code = 'endpoint_missing';
            info.title = 'RestoreBase endpoint did not load';
            info.message = 'WordPress returned 0, which usually means the AJAX action was not registered or the admin page is using old plugin JavaScript.';
            info.advice = 'Refresh the page after updating the plugin. If it continues, deactivate and reactivate RestoreBase.';
            return info;
        }

        if (status >= 500) {
            info.code = 'server_error';
            info.title = 'Server or PHP error';
            info.message = jsonMessage || 'The server failed while running this RestoreBase request.';
            info.advice = 'Retry once. If it repeats, check the WordPress/PHP error log for the RestoreBase request.';
            return info;
        }

        if (context.parseError) {
            info.code = 'invalid_json';
            info.title = 'WordPress returned a non-JSON response';
            info.message = 'RestoreBase expected clean JSON, but WordPress returned something else.';
            info.advice = 'Hard-refresh the admin page. If it repeats, check for PHP warnings, security plugin blocks, login redirects, or cached old JavaScript.';
            if (/^</.test(trimmed) || /<html|<!doctype|wp-login|login/i.test(trimmed)) {
                info.title = 'WordPress returned an HTML page';
                info.message = 'The request was probably redirected, blocked, or interrupted by a PHP/WordPress screen.';
            }
            return info;
        }

        if (jsonMessage) {
            info.code = 'restorebase_error';
            info.title = 'RestoreBase request failed';
            info.message = jsonMessage;
            info.advice = 'Fix the message above, then retry the action.';
            return info;
        }

        return info;
    }

    function getErrorInfo(error) {
        if (error && error.rbInfo) return error.rbInfo;
        const message = error && error.message ? String(error.message) : 'Unknown error';
        if (/NetworkError|Failed to fetch|Load failed|cancel|abort/i.test(message)) {
            return classifyAjaxError({networkError: error || new Error('Unknown error')});
        }
        return classifyAjaxError({json: {data: {message: message}}, action: activeActionName || 'restorebase_action'});
    }

    function registerRetry(callback) {
        retryCounter += 1;
        const retryId = 'retry-' + retryCounter;
        retryCallbacks[retryId] = function (button) {
            if (!callback) return;
            busy(button, true);
            setStatus('Retrying request...');
            startProgress('Retrying request...', 12);
            return Promise.resolve()
                .then(callback)
                .then(function (result) {
                    if (result === false) return;
                    setStatus('Retry completed.');
                    finishProgress('Retry completed.');
                })
                .catch(function (error) {
                    const info = getErrorInfo(error);
                    setStatus('Retry failed: ' + (info.title || 'Request failed'));
                    failProgress(info.title || info.message || 'Retry failed.');
                })
                .finally(function () {
                    busy(button, false);
                });
        };
        return retryId;
    }

    function renderPassphrasePrompt(retryCallback) {
        const retryId = retryCallback ? registerRetry(retryCallback) : '';
        const existing = panel.querySelector('[data-rb-restore-passphrase]');
        const prefill = existing && existing.value ? existing.value : '';
        return [
            '<div class="rb-error-card rb-pass-prompt">',
                '<div class="rb-error-head">',
                    '<span class="rb-error-badge rb-badge-lock">Encrypted</span>',
                    '<strong>This backup needs its passphrase</strong>',
                '</div>',
                '<p>This package was encrypted when it was created. Enter the passphrase it was encrypted with to import it.</p>',
                '<div class="rb-prompt-row">',
                    '<input type="password" class="rb-input" data-rb-prompt-pass value="' + escapeAttr(prefill) + '" placeholder="Passphrase used when the backup was created" autocomplete="off" />',
                    '<button type="button" class="rb-btn rb-btn-g rb-btn-s" data-rb-prompt-toggle>Show</button>',
                '</div>',
                retryId ? '<button type="button" class="rb-btn rb-btn-accent" data-rb-retry="' + escapeAttr(retryId) + '" data-rb-pass-submit>Unlock and import</button>' : '',
                '<small>The passphrase is set on the site that created the backup, under Backup options.</small>',
            '</div>'
        ].join('');
    }

    function renderErrorCard(error, title, retryCallback) {
        const info = getErrorInfo(error);
        const retryId = retryCallback ? registerRetry(retryCallback) : '';
        const meta = [];
        if (info.status) meta.push('HTTP ' + info.status);
        if (info.action) meta.push(info.action);
        if (info.code) meta.push(info.code.replace(/_/g, ' '));
        return [
            '<div class="rb-error-card">',
                '<div class="rb-error-head">',
                    '<span class="rb-error-badge">Error</span>',
                    '<strong>' + escapeHtml(title || info.title || 'Request failed') + '</strong>',
                '</div>',
                '<p>' + escapeHtml(info.message || 'RestoreBase could not complete the request.') + '</p>',
                info.advice ? '<p class="rb-error-advice">' + escapeHtml(info.advice) + '</p>' : '',
                meta.length ? '<small>' + escapeHtml(meta.join(' · ')) + '</small>' : '',
                info.details ? '<code>' + escapeHtml(info.details) + '</code>' : '',
                retryId ? '<button type="button" class="rb-btn rb-error-retry" data-rb-retry="' + escapeAttr(retryId) + '">Retry</button>' : '',
            '</div>'
        ].join('');
    }

    function renderSectionError(container, title, error, retryCallback) {
        if (!container) return;
        container.innerHTML = renderErrorCard(error, title, retryCallback);
        container.setAttribute('data-rb-has-cache', '0');
    }

    function createSnapshot() {
        busy(panel.querySelector('.rb-create-snapshot'), true);
        setStatus(labels.creating || 'Creating snapshot...');
        startProgress(labels.creating || 'Creating snapshot...');
        api('restorebase_create_snapshot', {label: 'Manifest snapshot ' + new Date().toLocaleString()})
            .then(function (data) {
                setStatus(labels.created || 'Snapshot created.');
                finishProgress(labels.created || 'Snapshot created.');
                renderJobResult(data.job || null);
                startPolling();
                return refreshAll();
            })
            .catch(showError)
            .finally(function () { busy(panel.querySelector('.rb-create-snapshot'), false); });
    }

    function createBackupAction() {
        const activeButton = document.activeElement && panel.contains(document.activeElement) && document.activeElement.matches('button, .rb-btn') ? document.activeElement : panel.querySelector('.rb-migration-bundle');
        const controller = beginCancellableAction('restorebase_backup', labels.migration || 'Creating backup...', activeButton);
        const label = 'Backup ' + new Date().toLocaleString();
        let latestJob = null;

        return api('restorebase_begin_package', {label: label}, {signal: controller.signal})
            .then(function (begin) {
                if (!begin || begin.ok === false || !begin.job_key) {
                    throw new Error((begin && begin.message) || 'Backup job could not start.');
                }
                activeJobKey = begin.job_key;
                jobStartedAtClient[begin.job_key] = Date.now();
                updateProgress(3, 'Backup job created. Scanning site...');
                setStatus('Backup running — see progress below.');

                // RC54: use one resilient job driver instead of running a separate status poll beside it.
                // Some security/maintenance plugins block overlapping admin-ajax calls during large archive work,
                // so package status failures must not kill a backup that is still running.
                return runPackageUntilDone(begin.job_key, controller.signal, function (data) {
                    if (data && data.job) latestJob = data.job;
                });
            })
            .then(function (data) {
                const job = data && data.job ? data.job : latestJob;
                setStatus('Backup completed.');
                finishProgress('Backup completed.');
                previewEl.innerHTML = renderMigrationBundle(data || (job ? {job: job} : {}));
                return refreshAll().then(function () {
                    const key = (data && data.snapshot_key) || (data && data.meta && data.meta.snapshot_key) || (job && job.result && job.result.backup_job_meta && job.result.backup_job_meta.snapshot_key) || '';
                    if (key) setPackageValue(key, {renderDetails: false});
                    return data;
                });
            })
            .catch(function (error) {
                if (isCancelError(error)) {
                    setStatus('Cancelled.');
                    failProgress('Backup cancelled.');
                    return false;
                }
                const failedJob = error && error.job ? error.job : null;
                if (failedJob) renderJobResult(failedJob);
                showError(error, createBackupAction);
                return false;
            })
            .finally(function () { endCancellableAction(activeButton); });
    }

    function createPackage() {
        return createBackupAction();
    }

    function saveBackupOptions(event) {
        const button = event && event.currentTarget ? event.currentTarget : panel.querySelector('.rb-save-backup-options');
        const encryptEl = panel.querySelector('[data-rb-encrypt]');
        const passEl = panel.querySelector('[data-rb-passphrase]');
        const mysqldumpEl = panel.querySelector('[data-rb-mysqldump]');
        const payload = {
            encrypt: encryptEl && encryptEl.checked ? '1' : '',
            passphrase: passEl ? passEl.value : '',
            use_mysqldump: mysqldumpEl && mysqldumpEl.checked ? '1' : ''
        };
        if (button) button.disabled = true;
        setStatus('Saving backup options...');
        return api('restorebase_save_backup_options', payload)
            .then(function (res) {
                setStatus((res && res.message) || 'Backup options saved.');
                if (passEl) passEl.value = ''; // never keep the passphrase in the field
                if (encryptEl && res) encryptEl.checked = !!res.encryption_enabled;
                if (mysqldumpEl && res) mysqldumpEl.checked = !!res.mysqldump_enabled;
            })
            .catch(function (error) { showError(error); })
            .finally(function () { if (button) button.disabled = false; });
    }


    function setupImportDropzone() {
        if (!importDropzone || !importFileInput) return;

        importFileInput.addEventListener('change', function () {
            droppedImportFile = null;
            const file = importFileInput.files && importFileInput.files[0] ? importFileInput.files[0] : null;
            updateImportFileName(file);
        });

        ['dragenter', 'dragover'].forEach(function (eventName) {
            importDropzone.addEventListener(eventName, function (event) {
                if (!event.dataTransfer || !hasImportableFiles(event.dataTransfer)) return;
                event.preventDefault();
                if (eventName === 'dragenter') dragDepth += 1;
                importDropzone.classList.add('rb-drag-over');
                if (importDropLabel) importDropLabel.setAttribute('aria-label', 'Drop to upload');
            });
        });

        ['dragleave', 'dragend'].forEach(function (eventName) {
            importDropzone.addEventListener(eventName, function () {
                if (eventName === 'dragleave') dragDepth = Math.max(0, dragDepth - 1);
                if (dragDepth === 0 || eventName === 'dragend') importDropzone.classList.remove('rb-drag-over');
            });
        });

        importDropzone.addEventListener('drop', function (event) {
            if (!event.dataTransfer || !hasImportableFiles(event.dataTransfer)) return;
            event.preventDefault();
            dragDepth = 0;
            importDropzone.classList.remove('rb-drag-over');

            const file = event.dataTransfer.files && event.dataTransfer.files[0] ? event.dataTransfer.files[0] : null;
            if (!file) return;
            droppedImportFile = file;
            try {
                importFileInput.files = event.dataTransfer.files;
            } catch (error) {
                // Some browsers keep input.files read-only; droppedImportFile is still used on import.
            }
            updateImportFileName(file);
            setStatus('Backup ready to import.');
        });
    }

    function hasImportableFiles(dataTransfer) {
        if (dataTransfer.files && dataTransfer.files.length) return true;
        if (!dataTransfer.types) return false;
        return Array.prototype.indexOf.call(dataTransfer.types, 'Files') !== -1;
    }

    function updateImportFileName(file) {
        if (!importFileName) return;
        importFileName.textContent = file && file.name ? file.name : 'Drop backup ZIP here or click to upload';
        importFileName.classList.toggle('has-file', !!file);
    }

    function importMigrationPackage() {
        const button = panel.querySelector('.rb-import-migration');
        const file = droppedImportFile || (importFileInput && importFileInput.files ? importFileInput.files[0] : null);
        if (!file) {
            showError(new Error('Choose or drop the backup ZIP from the old site first.'));
            return;
        }
        const label = 'Imported backup ' + new Date().toLocaleString();
        // Upload in chunks sized to what this server actually accepts. A single POST
        // of a full backup is silently rejected by post_max_size / upload_max_filesize
        // / proxy body limits, which is why the destination ended up with 0 packages.
        const chunkSize = Math.max(262144, parseInt(cfg.maxChunkSize, 10) || 2097152);
        const totalChunks = Math.max(1, Math.ceil(file.size / chunkSize));
        let uploadKey = '';
        for (let i = 0; i < 4; i++) { uploadKey += Math.random().toString(36).slice(2, 10); }
        uploadKey = uploadKey.replace(/[^A-Za-z0-9]/g, '').slice(0, 32);

        const controller = beginCancellableAction('restorebase_import_migration_package', labels.importing || 'Importing backup...', button);

        function sendChunk(index) {
            const start = index * chunkSize;
            const blob = file.slice(start, Math.min(file.size, start + chunkSize));
            const formData = new FormData();
            formData.append('chunk', blob, file.name);
            formData.append('upload_key', uploadKey);
            formData.append('chunk_index', String(index));
            formData.append('total_chunks', String(totalChunks));
            formData.append('filename', file.name);
            formData.append('total_size', String(file.size));
            formData.append('passphrase', restorePassphrase());
            formData.append('label', label);
            return apiUpload('restorebase_import_chunk', formData, {signal: controller.signal, quiet: true})
                .then(function (data) {
                    const done = index + 1;
                    updateProgress(
                        Math.min(72, Math.max(4, Math.round((done / totalChunks) * 72))),
                        totalChunks > 1 ? 'Uploading backup — chunk ' + done + ' of ' + totalChunks + '...' : 'Uploading backup...'
                    );
                    if (done < totalChunks) return sendChunk(done);
                    return data; // final chunk returns the import result
                });
        }

        sendChunk(0)
            .then(function (data) {
                setStatus(labels.imported || 'Backup imported.');
                finishProgress(labels.imported || 'Backup imported.');
                previewEl.innerHTML = renderMigrationImport(data);
                droppedImportFile = null;
                if (importFileInput) importFileInput.value = '';
                updateImportFileName(null);
                return refreshAll().then(function () {
                    if (data && data.snapshot_key) setPackageValue(data.snapshot_key, {renderDetails: false});
                });
            })
            .catch(function (error) {
                if (isCancelError(error)) { setStatus('Cancelled.'); failProgress('Import cancelled.'); return; }
                if (error && error.rbInfo && error.rbInfo.needsPassphrase) {
                    // Ask for it here, where the failure happened, instead of pointing
                    // at a field elsewhere in the panel.
                    setStatus('This backup is encrypted — enter its passphrase to continue.');
                    failProgress('Passphrase required.');
                    if (previewEl) previewEl.innerHTML = renderPassphrasePrompt(importMigrationPackage);
                    const field = panel.querySelector('[data-rb-prompt-pass]');
                    if (field) { try { field.focus(); } catch (e) {} }
                    return;
                }
                showError(error, importMigrationPackage);
            })
            .finally(function () { endCancellableAction(button); });
    }

    function restorePassphrase() {
        const el = panel.querySelector('[data-rb-restore-passphrase]');
        return el ? el.value : '';
    }

    function revealRestorePassphrase(message) {
        const wrap = panel.querySelector('[data-rb-restore-pass-wrap]');
        if (wrap) wrap.hidden = false;
        const el = panel.querySelector('[data-rb-restore-passphrase]');
        if (el) { try { el.focus(); } catch (e) {} }
        if (message) setStatus(message);
    }

    function validatePackage() {
        const key = selectedPackageKey();
        busy(panel.querySelector('.rb-validate-package'), true);
        setStatus(labels.validating || 'Validating package...');
        startProgress(labels.validating || 'Validating package...');
        api('restorebase_validate_package', {snapshot_key: key, passphrase: restorePassphrase()})
            .then(function (data) {
                if (data && data.needs_passphrase) {
                    revealRestorePassphrase('This backup is encrypted — enter its passphrase, then validate again.');
                } else {
                    setStatus(labels.validated || 'Package validation completed.');
                }
                finishProgress(labels.validated || 'Package validation completed.');
                previewEl.innerHTML = renderValidation(data);
                return refreshAll();
            })
            .catch(showError)
            .finally(function () { busy(panel.querySelector('.rb-validate-package'), false); });
    }

    function restorePreview(snapshotKey) {
        const key = typeof snapshotKey === 'string' ? snapshotKey : selectedPackageKey();
        busy(panel.querySelector('.rb-preview-latest'), true);
        setStatus(labels.previewing || 'Preparing restore preview...');
        startProgress(labels.previewing || 'Preparing restore preview...');
        api('restorebase_restore_preview', {snapshot_key: key})
            .then(function (data) {
                setStatus(labels.previewed || 'Restore preview ready.');
                finishProgress(labels.previewed || 'Restore preview ready.');
                previewEl.innerHTML = renderPreview(data);
            })
            .catch(showError)
            .finally(function () { busy(panel.querySelector('.rb-preview-latest'), false); });
    }

    function restoreDryRun() {
        const key = selectedPackageKey();
        busy(panel.querySelector('.rb-dry-run'), true);
        setStatus(labels.dryRun || 'Running dry-run...');
        startProgress(labels.dryRun || 'Running dry-run...');
        api('restorebase_restore_dry_run', {snapshot_key: key})
            .then(function (data) {
                setStatus(labels.dryRunDone || 'Dry-run completed.');
                finishProgress(labels.dryRunDone || 'Dry-run completed.');
                previewEl.innerHTML = renderDryRun(data);
            })
            .catch(showError)
            .finally(function () { busy(panel.querySelector('.rb-dry-run'), false); });
    }

    function prepareRestore() {
        const key = selectedPackageKey();
        busy(panel.querySelector('.rb-prepare-restore'), true);
        setStatus(labels.preparing || 'Preparing guarded restore...');
        startProgress(labels.preparing || 'Preparing guarded restore...');
        api('restorebase_prepare_restore', {snapshot_key: key, passphrase: restorePassphrase()})
            .then(function (data) {
                setStatus(labels.prepared || 'Guarded restore preparation completed.');
                finishProgress(labels.prepared || 'Guarded restore preparation completed.');
                previewEl.innerHTML = renderPreparation(data);
                if (data && data.job) renderJobResult(data.job);
                return refreshAll();
            })
            .catch(showError)
            .finally(function () { busy(panel.querySelector('.rb-prepare-restore'), false); });
    }

    function restoreReadiness() {
        const key = selectedPackageKey();
        busy(panel.querySelector('.rb-readiness'), true);
        setStatus(labels.readiness || 'Checking restore readiness...');
        startProgress(labels.readiness || 'Checking restore readiness...');
        api('restorebase_readiness', {snapshot_key: key})
            .then(function (data) {
                setStatus(labels.readyScore || 'Restore readiness completed.');
                finishProgress(labels.readyScore || 'Restore readiness completed.');
                previewEl.innerHTML = renderReadiness(data);
            })
            .catch(showError)
            .finally(function () { busy(panel.querySelector('.rb-readiness'), false); });
    }

    function executeStagingRestore() {
        const key = selectedPackageKey();
        const confirmation = confirmInput ? confirmInput.value : '';
        if (confirmation !== 'RESTORE STAGING') {
            previewEl.innerHTML = '<div class="rb-check rb-check-danger"><span class="rb-check-level">block</span><div><strong class="rb-check-title">Typed confirmation required</strong><p class="rb-check-message">Type RESTORE STAGING before running staging-only restore execution.</p></div></div>';
            return;
        }
        busy(panel.querySelector('.rb-execute-staging'), true);
        setStatus(labels.executing || 'Executing staging-only restore...');
        startProgress(labels.executing || 'Executing staging-only restore...');
        api('restorebase_execute_staging_restore', {snapshot_key: key, confirmation: confirmation, passphrase: restorePassphrase()})
            .then(function (data) {
                setStatus(labels.executed || 'Staging restore execution completed.');
                finishProgress(labels.executed || 'Staging restore execution completed.');
                previewEl.innerHTML = renderExecution(data);
                if (data && data.job) renderJobResult(data.job);
                return refreshAll();
            })
            .catch(showError)
            .finally(function () { busy(panel.querySelector('.rb-execute-staging'), false); });
    }


    function executeProductionRestore() {
        const key = selectedPackageKey();
        const confirmation = productionConfirmInput ? productionConfirmInput.value : '';
        if (confirmation !== 'RESTORE PRODUCTION') {
            previewEl.innerHTML = '<div class="rb-check rb-check-danger"><span class="rb-check-level">block</span><div><strong class="rb-check-title">Production confirmation required</strong><p class="rb-check-message">Type RESTORE PRODUCTION before running guarded production restore. A safety package is created first.</p></div></div>';
            return;
        }
        busy(panel.querySelector('.rb-execute-production'), true);
        setStatus(labels.production || 'Running guarded production restore...');
        startProgress(labels.production || 'Running guarded production restore...');
        enableRestoreSessionGuard();
        api('restorebase_execute_production_restore', {snapshot_key: key, confirmation: confirmation, passphrase: restorePassphrase()})
            .then(function (data) {
                setStatus('Production restore finished. Verify immediately.');
                finishProgress('Production restore finished. Verify immediately.');
                previewEl.innerHTML = renderExecution(data);
                if (data && data.job) renderJobResult(data.job);
                window.setTimeout(disableRestoreSessionGuard, 3000);
                return Promise.resolve(data);
            })
            .catch(function (error) { showError(error); window.setTimeout(disableRestoreSessionGuard, 10000); })
            .finally(function () { busy(panel.querySelector('.rb-execute-production'), false); });
    }


    function storeActiveRestoreSession(jobKey, statusToken) {
        if (!window.localStorage || !jobKey || !statusToken) return;
        try {
            window.localStorage.setItem('restorebase.activeRestore', JSON.stringify({job_key: jobKey, status_token: statusToken, time: Date.now()}));
        } catch (error) {}
    }

    function readActiveRestoreSession() {
        if (!window.localStorage) return null;
        try {
            const raw = window.localStorage.getItem('restorebase.activeRestore');
            if (!raw) return null;
            const data = JSON.parse(raw);
            if (!data || !data.job_key || !data.status_token) return null;
            if (data.time && Date.now() - Number(data.time) > 8 * 60 * 60 * 1000) {
                window.localStorage.removeItem('restorebase.activeRestore');
                return null;
            }
            return data;
        } catch (error) {
            return null;
        }
    }

    function clearActiveRestoreSession() {
        if (!window.localStorage) return;
        try { window.localStorage.removeItem('restorebase.activeRestore'); } catch (error) {}
    }


    function performAdminRefresh(jobKey) {
        if (window.sessionStorage) {
            try {
                window.sessionStorage.setItem('restorebase.afterAdminRefresh', JSON.stringify({
                    job_key: jobKey || activeJobKey || '',
                    time: Date.now()
                }));
            } catch (error) {}
        }
        window.location.reload();
    }

    function schedulePostRestoreAdminRefresh(job) {
        if (!job || String(job.status || '') !== 'completed') return;
        if (autoRefreshTimer) window.clearTimeout(autoRefreshTimer);
        setStatus('Restore completed. Refreshing admin automatically...');
        autoRefreshTimer = window.setTimeout(function () {
            performAdminRefresh(job.job_key || activeJobKey || '');
        }, 2200);
    }

    function autoRefreshNotice(job, options) {
        if (!job || String(job.status || '') !== 'completed') return '';
        if (options && options.skipAutoRefresh) {
            return '<div class="rb-auto-refresh-note rb-auto-refresh-done"><strong>Admin refreshed.</strong><span>Restored plugin screens, builders, media panels, and REST nonces should now load fresh data.</span></div>';
        }
        return '<div class="rb-auto-refresh-note"><strong>Admin will refresh automatically.</strong><span>This reloads restored plugin screens, builders, media panels, and REST nonces after the database swap.</span></div>';
    }

    function handlePostRestoreAutoRefreshReturn() {
        if (!window.sessionStorage) return false;
        let data = null;
        try {
            const raw = window.sessionStorage.getItem('restorebase.afterAdminRefresh');
            if (!raw) return false;
            window.sessionStorage.removeItem('restorebase.afterAdminRefresh');
            data = JSON.parse(raw);
        } catch (error) {
            return false;
        }
        if (!data || (data.time && Date.now() - Number(data.time) > 10 * 60 * 1000)) return false;
        openPanel();
        setStatus('Admin refreshed after restore.');
        const latest = cfg.lastRestoreJob || latestRestoreJobFromCache();
        if (latest && (!data.job_key || latest.job_key === data.job_key)) {
            renderRestoreOutcome(latest, {force: true, skipAutoRefresh: true});
        }
        return true;
    }

    function resumeRestoreAfterReload() {
        if (restoreResumeAttempted) return;
        restoreResumeAttempted = true;

        const session = readActiveRestoreSession();
        if (session) {
            openPanel();
            enableRestoreSessionGuard();
            activeJobKey = session.job_key;
            activeJobToken = session.status_token;
            activeActionName = 'restorebase_restore_resume';
            setPanelActionLock(true);
            startProgress('Reconnecting to active restore...', 12, true);
            pollRestoreJob(session.job_key, session.status_token, function (status) {
                const job = status && status.job ? status.job : null;
                if (job) writeCache('jobs', [job].concat(readCache('jobs') || []));
            }).then(function (status) {
                const job = status && status.job ? status.job : null;
                clearActiveRestoreSession();
                finishProgress('Restore finished. Final result loaded.');
                if (job) {
                    renderRestoreOutcome(job, {force: true});
                    schedulePostRestoreAdminRefresh(job);
                }
                window.setTimeout(disableRestoreSessionGuard, 2500);
                refreshAll();
            }).catch(function (error) {
                const job = error && error.job ? error.job : null;
                if (job && ['completed','failed','cancelled'].includes(String(job.status || ''))) {
                    clearActiveRestoreSession();
                    failProgress(job.status === 'completed' ? 'Restore completed.' : 'Restore finished with issues.');
                    renderRestoreOutcome(job, {force: true});
                    schedulePostRestoreAdminRefresh(job);
                } else {
                    setStatus('Restore status needs refresh.');
                    failProgress('Restore status needs refresh.');
                    showError(error, refreshAll);
                }
                window.setTimeout(disableRestoreSessionGuard, 5000);
            });
            return;
        }

        const latest = cfg.lastRestoreJob || latestRestoreJobFromCache();
        if (latest) maybeRenderLatestRestoreOutcome([latest], {initial: true});
    }

    function isRestoreJob(job) {
        const type = String((job && job.type) || '');
        return type === 'production_restore' || type === 'staging_restore';
    }

    function isTerminalRestoreJob(job) {
        return ['completed','failed','cancelled'].includes(String((job && job.status) || ''));
    }

    function latestRestoreJobFromCache() {
        const cached = readCache('jobs');
        if (!Array.isArray(cached)) return null;
        return cached.find(isRestoreJob) || null;
    }

    function markRestoreOutcomeSeen(jobKey) {
        if (!jobKey) return;
        if (window.localStorage) {
            try { window.localStorage.setItem('restorebaseLastRestoreOutcomeSeen', jobKey); } catch (error) {}
        }
        api('restorebase_ack_restore_result', {job_key: jobKey}).catch(function () {});
    }

    function restoreOutcomeHasBeenSeen(jobKey) {
        if (!jobKey || !window.localStorage) return false;
        try { return window.localStorage.getItem('restorebaseLastRestoreOutcomeSeen') === jobKey; } catch (error) { return false; }
    }

    function maybeRenderLatestRestoreOutcome(items, options) {
        if (!Array.isArray(items) || !items.length || !previewEl) return;
        const job = items.find(isRestoreJob);
        if (!job || !job.job_key) return;
        if (!isTerminalRestoreJob(job) && String(job.status || '') !== 'running') return;
        if (restoreOutcomeRenderedKey === job.job_key && !(options && options.force)) return;
        if (isTerminalRestoreJob(job) && restoreOutcomeHasBeenSeen(job.job_key) && !(options && options.force)) return;

        restoreOutcomeRenderedKey = job.job_key;
        renderRestoreOutcome(job, options || {});
        if (String(job.status || '') === 'running') {
            setStatus('Restore job still running. Reopen progress if needed.');
        } else if (String(job.status || '') === 'completed') {
            setStatus('Last restore completed. Result is ready.');
        } else {
            setStatus('Last restore needs attention.');
        }
    }

    function renderRestoreOutcome(job, options) {
        if (!previewEl || !job) return;
        const tasks = Object.keys(job.task_state || {}).map(function (key) { return job.task_state[key]; });
        const done = tasks.filter(function (task) { return task.status === 'completed'; }).length;
        const failed = tasks.filter(function (task) { return task.status === 'failed'; });
        const total = tasks.length;
        const status = String(job.status || 'unknown');
        const result = job.result || {};
        const verification = result.post_restore_verification || (result.finish_execution && result.finish_execution.post_restore_verification) || null;
        const verificationOk = verification && Object.prototype.hasOwnProperty.call(verification, 'ok') ? !!verification.ok : (status === 'completed' && failed.length === 0);
        const title = status === 'running' ? 'Restore still running' : (status === 'completed' && verificationOk ? 'Restore completed successfully' : (status === 'completed' ? 'Restore completed with warnings' : 'Restore needs attention'));
        const level = status === 'completed' && verificationOk ? 'completed' : (status === 'running' ? 'running' : 'failed');
        const finished = job.finished_at || job.updated_at || '';
        const message = (verification && verification.message) || job.message || (status === 'completed' ? 'Restore finished.' : 'Open the job steps below for details.');
        const failedHtml = failed.length ? '<div class="rb-check-list">' + failed.map(function (task) {
            return '<div class="rb-check rb-check-danger"><span class="rb-check-level">fix</span><div><strong class="rb-check-title">' + escapeHtml(task.label || task.id || 'Failed step') + '</strong><p class="rb-check-message">' + escapeHtml(task.message || 'This step failed.') + '</p></div></div>';
        }).join('') + '</div>' : '';
        const verificationHtml = verification ? renderPostRestoreVerification(verification) : '';
        const taskHtml = tasks.length ? '<details class="rb-job-steps rb-restore-outcome-steps"><summary>View restore steps</summary><div class="rb-task-list">' + tasks.map(function (task) {
            return '<span class="rb-task rb-task-' + escapeAttr(task.status || 'pending') + '"><i></i>' + escapeHtml(task.label || task.id || 'Step') + '</span>';
        }).join('') + '</div></details>' : '';

        previewEl.innerHTML = [
            '<div class="rb-restore-outcome rb-restore-outcome-' + escapeAttr(level) + '">',
                '<div class="rb-restore-outcome-head"><span class="rb-restore-badge">' + escapeHtml(status) + '</span><strong>' + escapeHtml(title) + '</strong></div>',
                '<p>' + escapeHtml(message) + '</p>',
                '<div class="rb-site-compare">',
                    '<div class="rb-site-mini"><strong>Restore status</strong><span>' + escapeHtml(status) + '</span><span>' + escapeHtml(finished || 'time not recorded') + '</span></div>',
                    '<div class="rb-site-mini"><strong>Steps</strong><span>' + escapeHtml(total ? (done + '/' + total + ' completed') : 'No step data') + '</span><span>' + escapeHtml(failed.length ? failed.length + ' failed' : 'No failed steps') + '</span></div>',
                    '<div class="rb-site-mini"><strong>Verification</strong><span>' + escapeHtml(verification ? (verificationOk ? 'Passed' : 'Needs attention') : 'Not recorded') + '</span><span>' + escapeHtml(job.job_key || '') + '</span></div>',
                '</div>',
                failedHtml,
                verificationHtml,
                taskHtml,
                autoRefreshNotice(job, options),
                '<div class="rb-outcome-actions"><button type="button" class="rb-btn rb-btn-accent" data-rb-refresh-admin="' + escapeAttr(job.job_key || '') + '">Refresh Now</button><button type="button" class="rb-btn" data-rb-run-verify>Run Verify Again</button><button type="button" class="rb-btn" data-rb-ack-restore-result="' + escapeAttr(job.job_key || '') + '">Dismiss Result</button></div>',
            '</div>'
        ].join('');

        if (options && options.force) restoreOutcomeRenderedKey = job.job_key || restoreOutcomeRenderedKey;
    }

    function renderPostRestoreVerification(verification) {
        const checks = Array.isArray(verification.checks) ? verification.checks : [];
        const failed = Array.isArray(verification.failed) ? verification.failed : [];
        if (!checks.length && !failed.length) return '';
        const normalized = checks.map(function (check) {
            return {
                level: check.ok ? 'ok' : 'warn',
                title: check.message || check.key || 'Verification check',
                message: Array.isArray(check.missing) && check.missing.length ? ('Missing: ' + check.missing.join(', ')) : (check.error || check.key || '')
            };
        });
        return '<div class="rb-restore-verification"><strong>Post-restore verification</strong>' + renderChecks(normalized) + '</div>';
    }

    function restoreBackup(snapshotKey, button) {
        const key = snapshotKey || selectedPackageKey();
        if (!key) {
            showError(new Error('Select or import a backup before restoring.'));
            return;
        }
        confirmDialog({
            title: 'Restore this backup?',
            message: 'This applies the selected backup to this site. RestoreBase keeps the current wp-config.php credentials, current site URL, and destination admin access, then restores files, database, and plugin activation state.',
            confirmText: 'Restore Backup',
            cancelText: 'Cancel',
            warning: true,
            requireText: 'RESTORE',
            inputLabel: 'Type RESTORE to confirm',
            trigger: button || panel
        }).then(function (ok) {
            if (!ok) return;
            const activeButton = button || panel.querySelector('.rb-restore-selected');
            const controller = beginCancellableAction('restorebase_restore', 'Starting guarded restore...', activeButton);
            enableRestoreSessionGuard();
            setStatus('Working…');
            if (progressTimer) window.clearInterval(progressTimer);
            progressTimer = null;

            let latestStatus = null;
            let runError = null;
            api('restorebase_begin_production_restore', {snapshot_key: key, confirmation: 'RESTORE PRODUCTION', passphrase: restorePassphrase()}, {signal: controller.signal})
                .then(function (begin) {
                    if (!begin || begin.ok === false || !begin.job_key || !begin.status_token) {
                        throw new Error((begin && begin.message) || 'Restore job could not start.');
                    }

                    activeJobKey = begin.job_key;
                    activeJobToken = begin.status_token;
                    storeActiveRestoreSession(begin.job_key, begin.status_token);
                    updateProgress(3, 'Restore job created. Starting checks...');
                    setStatus('Restore running — see progress below.');

                    const runPromise = api('restorebase_run_production_restore_job', {job_key: begin.job_key, status_token: begin.status_token}, {signal: controller.signal})
                        .catch(function (error) {
                            runError = error;
                            return null;
                        });

                    return pollRestoreJob(begin.job_key, begin.status_token, function (status) {
                        latestStatus = status;
                    }).then(function (status) {
                        latestStatus = status || latestStatus;
                        return runPromise.then(function (runData) {
                            return runData || latestStatus;
                        });
                    }).catch(function (error) {
                        return runPromise.then(function (runData) {
                            if (runData && runData.job && runData.job.status === 'completed') return runData;
                            throw error || runError || new Error('Restore progress could not be confirmed.');
                        });
                    });
                })
                .then(function (data) {
                    const job = data && data.job ? data.job : (latestStatus && latestStatus.job ? latestStatus.job : null);
                    setStatus('Restore finished. Verify the site now.');
                    finishProgress('Restore finished. Verify the site now.');
                    clearActiveRestoreSession();
                    if (job) {
                        renderRestoreOutcome(job, {force: true});
                        schedulePostRestoreAdminRefresh(job);
                    } else {
                        previewEl.innerHTML = renderExecution(data || {ok: true, message: 'Restore finished.', job: job});
                    }
                    window.setTimeout(disableRestoreSessionGuard, 3000);
                    return Promise.resolve(data);
                })
                .catch(function (error) {
                    const failedJob = error && error.job ? error.job : null;
                    if (isCancelError(error)) { clearActiveRestoreSession(); setStatus('Cancelled.'); failProgress('Restore cancelled.'); window.setTimeout(disableRestoreSessionGuard, 1500); return; }
                    if (failedJob && ['failed','cancelled','completed'].includes(String(failedJob.status || ''))) {
                        clearActiveRestoreSession();
                        renderRestoreOutcome(failedJob, {force: true});
                    } else {
                        showError(error, function () { return restoreBackup(key, button); });
                    }
                    window.setTimeout(disableRestoreSessionGuard, 10000);
                })
                .finally(function () { endCancellableAction(activeButton); });
        });
    }

    function runPackageUntilDone(jobKey, signal, onUpdate) {
        let attempts = 0;
        let connectionFailures = 0;
        let lastProgress = -1;
        let lastProgressAt = Date.now();
        let lastKnownData = null;

        const remember = function (data) {
            if (data && data.job) {
                lastKnownData = data;
                const progress = Number(data.job.progress) || 0;
                if (progress !== lastProgress) {
                    lastProgress = progress;
                    lastProgressAt = Date.now();
                }
                updateJobProgress(data.job);
                if (typeof onUpdate === 'function') onUpdate(data);
            }
            return data;
        };

        const statusOnce = function () {
            return api('restorebase_package_job_status', {job_key: jobKey}, {signal: signal})
                .then(function (data) {
                    connectionFailures = 0;
                    remember(data);
                    return data;
                });
        };

        const pump = function () {
            attempts += 1;
            return api('restorebase_run_package_job', {job_key: jobKey}, {signal: signal})
                .then(function (data) {
                    connectionFailures = 0;
                    const remembered = remember(data);
                    const job = remembered && remembered.job ? remembered.job : null;
                    if (job && job.status === 'completed') return remembered;
                    if (job && (job.status === 'failed' || job.status === 'cancelled')) {
                        const err = new Error(job.message || 'Backup job failed.');
                        err.job = job;
                        throw err;
                    }
                    if (remembered && remembered.deferred === false && job && job.status !== 'running') return remembered;
                    return wait(650).then(pump);
                })
                .catch(function (error) {
                    if (isCancelError(error)) throw error;
                    connectionFailures += 1;
                    const reconnectMessage = connectionFailures < 2 ? 'Backup request paused. Reconnecting...' : 'Backup still running. Reconnecting to WordPress...';
                    setStatus(reconnectMessage);
                    if (currentProgress > 0 && currentProgress < 100) updateProgress(currentProgress, reconnectMessage);

                    return statusOnce()
                        .then(function (statusData) {
                            const job = statusData && statusData.job ? statusData.job : null;
                            if (job && job.status === 'completed') return statusData;
                            if (job && (job.status === 'failed' || job.status === 'cancelled')) {
                                const err = new Error(job.message || 'Backup job failed.');
                                err.job = job;
                                throw err;
                            }
                            return wait(Math.min(12000, 1200 + (connectionFailures * 1200))).then(pump);
                        })
                        .catch(function (statusError) {
                            if (isCancelError(statusError)) throw statusError;
                            // During heavy ZIP writes, admin-ajax status requests can be temporarily blocked by
                            // maintenance/security plugins. Keep the job alive instead of showing a fatal panel error.
                            if (Date.now() - lastProgressAt < 10 * 60 * 1000 || connectionFailures < 18) {
                                const fallbackMessage = 'Backup is still active. Waiting for WordPress to answer...';
                                setStatus(fallbackMessage);
                                if (lastKnownData && lastKnownData.job) updateJobProgress(lastKnownData.job);
                                else if (currentProgress > 0 && currentProgress < 100) updateProgress(currentProgress, fallbackMessage);
                                return wait(Math.min(15000, 2500 + (connectionFailures * 1000))).then(pump);
                            }
                            throw statusError || error;
                        });
                });
        };
        return pump();
    }

    function wait(ms) {
        return new Promise(function (resolve) { window.setTimeout(resolve, ms); });
    }

    function pollPackageJob(jobKey, onUpdate) {
        let failedPolls = 0;
        let lastProgressAt = Date.now();
        return new Promise(function (resolve, reject) {
            const tick = function () {
                api('restorebase_package_job_status', {job_key: jobKey})
                    .then(function (data) {
                        failedPolls = 0;
                        const job = data && data.job ? data.job : null;
                        if (!job) throw new Error('Backup job status is unavailable.');
                        lastProgressAt = Date.now();
                        updateJobProgress(job);
                        if (typeof onUpdate === 'function') onUpdate(data);
                        if (job.status === 'completed') { resolve(data); return; }
                        if (job.status === 'failed' || job.status === 'cancelled') {
                            const err = new Error(job.message || 'Backup job failed.');
                            err.job = job;
                            reject(err);
                            return;
                        }
                        window.setTimeout(tick, 1500);
                    })
                    .catch(function (error) {
                        failedPolls += 1;
                        if (failedPolls < 20 || Date.now() - lastProgressAt < 10 * 60 * 1000) {
                            setStatus('Backup still running. Waiting for WordPress response...');
                            window.setTimeout(tick, Math.min(15000, 2000 + failedPolls * 1000));
                            return;
                        }
                        reject(error);
                    });
            };
            tick();
        });
    }

    function pollRestoreJob(jobKey, statusToken, onUpdate) {
        let failedPolls = 0;
        return new Promise(function (resolve, reject) {
            const tick = function () {
                api('restorebase_restore_job_status', {job_key: jobKey, status_token: statusToken})
                    .then(function (data) {
                        failedPolls = 0;
                        const job = data && data.job ? data.job : null;
                        if (!job) {
                            throw new Error('Restore job status is unavailable.');
                        }

                        updateJobProgress(job);
                        if (typeof onUpdate === 'function') onUpdate(data);

                        if (job.status === 'completed') {
                            resolve(data);
                            return;
                        }
                        if (job.status === 'failed' || job.status === 'cancelled') {
                            const err = new Error(job.message || 'Restore job failed.');
                            err.job = job;
                            reject(err);
                            return;
                        }
                        window.setTimeout(tick, 1100);
                    })
                    .catch(function (error) {
                        failedPolls += 1;
                        if (failedPolls < 4) {
                            setStatus('Still restoring. Waiting for WordPress response...');
                            window.setTimeout(tick, 1500);
                            return;
                        }
                        reject(error);
                    });
            };
            tick();
        });
    }

    function updateJobProgress(job) {
        const rawProgress = Math.max(0, Math.min(100, Number(job.progress) || 0));
        const progress = ['queued','running'].includes(String((job && job.status) || '')) ? Math.max(3, rawProgress) : rawProgress;
        const key = String((job && job.job_key) || activeJobKey || 'active');
        if (key && !jobStartedAtClient[key]) jobStartedAtClient[key] = progressStartedAt || Date.now();
        lastProgressJob = job;
        const message = restoreJobMessage(job);
        updateProgress(progress, message);
        updateJobProgressDetails(job, progress);
        const noun = isRestoreJob(job) ? 'Restore' : (String((job && job.type) || '').indexOf('backup') !== -1 ? 'Backup' : 'Action');
        setStatus(noun + ' running — see progress below.');
    }

    function restoreJobMessage(job) {
        if (!job) return 'Restoring...';
        const state = job.task_state || {};
        const current = job.current_task && state[job.current_task] ? state[job.current_task] : null;
        if (current) {
            if (current.message) return current.message;
            if (current.label) return current.label + (current.status === 'running' ? '...' : '');
        }
        return job.message || 'Restoring...';
    }

    function updateJobProgressDetails(job, progress, timerTick) {
        if (!progressMeta || !job) return;
        const tasks = Object.keys(job.task_state || {}).map(function (key) { return job.task_state[key]; });
        const total = tasks.length || Number(job.total_tasks) || 0;
        const index = Math.max(0, Number(job.task_index) || 0);
        const state = job.task_state || {};
        const current = job.current_task && state[job.current_task] ? state[job.current_task] : null;
        const data = current && current.data && typeof current.data === 'object' ? current.data : {};
        const stepNumber = total ? Math.min(total, index + 1) : (index + 1);
        const elapsed = getJobElapsedMs(job);
        const eta = estimateJobEta(job, progress, elapsed);
        const itemBits = [];
        if (Number(data.total) > 0 && Number(data.copied) >= 0) {
            itemBits.push('Files ' + numberFormat(data.copied) + '/' + numberFormat(data.total));
        } else if (Number(data.seen) > 0) {
            itemBits.push('Seen ' + numberFormat(data.seen));
        }
        if (data.method) itemBits.push(String(data.method).replace(/_/g, ' '));
        if (Number(data.batch) > 0 && Number(data.batches) > 0) {
            itemBits.push('File batch ' + numberFormat(data.batch) + '/' + numberFormat(data.batches));
        }
        const detail = [
            total ? ('Checkpoint ' + stepNumber + '/' + total) : 'Running step',
            current && current.label ? current.label : (job.current_task || 'Restore'),
            'Elapsed ' + formatDuration(elapsed),
            eta ? ('ETA ' + formatDuration(eta)) : (timerTick ? 'ETA waiting for movement…' : 'ETA calculating…')
        ].concat(itemBits).filter(Boolean);
        progressMeta.hidden = false;
        progressMeta.innerHTML = detail.map(function (item) { return '<span>' + escapeHtml(item) + '</span>'; }).join('');

        // RC51 keeps only one visual progress bar. Per-task progress remains visible in the detail pills.
        if (progressSubtrack) {
            progressSubtrack.hidden = true;
            if (progressSubfill) progressSubfill.style.width = '0%';
        }
    }

    function getJobElapsedMs(job) {
        const key = String((job && job.job_key) || activeJobKey || 'active');
        if (key && !jobStartedAtClient[key]) jobStartedAtClient[key] = progressStartedAt || Date.now();
        const clientStart = key ? Number(jobStartedAtClient[key] || 0) : 0;
        if (clientStart && String((job && job.status) || '') === 'running') {
            return Math.max(0, Date.now() - clientStart);
        }
        const start = parseWpDate((job && job.started_at) || '') || clientStart || progressStartedAt || Date.now();
        const finish = parseWpDate((job && job.finished_at) || '') || Date.now();
        return Math.max(0, finish - start);
    }

    function estimateJobEta(job, progress, elapsed) {
        const key = String((job && job.job_key) || activeJobKey || 'active');
        const now = Date.now();
        if (!progressSamples[key]) progressSamples[key] = [];
        const previous = progressSamples[key][progressSamples[key].length - 1];
        if (!previous || previous.progress !== progress || now - previous.time > 800) {
            progressSamples[key].push({time: now, progress: progress});
        }
        progressSamples[key] = progressSamples[key].filter(function (sample) { return now - sample.time < 120000; }).slice(-16);
        const samples = progressSamples[key];
        if (progress <= 1 || progress >= 98 || samples.length < 2) return 0;
        const first = samples[0];
        const last = samples[samples.length - 1];
        const deltaProgress = last.progress - first.progress;
        const deltaTime = last.time - first.time;
        if (deltaTime < 3000 || deltaProgress < 1) return 0;
        const rate = deltaProgress / deltaTime;
        if (!rate) return 0;
        const eta = Math.max(0, (100 - progress) / rate);
        if (!isFinite(eta) || eta > 2 * 60 * 60 * 1000) return 0;
        return eta;
    }

    function parseWpDate(value) {
        if (!value) return 0;
        const text = String(value).trim();
        const parsed = Date.parse(text.replace(' ', 'T'));
        return isNaN(parsed) ? 0 : parsed;
    }

    function formatDuration(ms) {
        ms = Math.max(0, Math.round(Number(ms) || 0));
        let total = Math.floor(ms / 1000);
        const hours = Math.floor(total / 3600);
        total -= hours * 3600;
        const minutes = Math.floor(total / 60);
        const seconds = total - minutes * 60;
        const pad = function (n) { return String(n).padStart(2, '0'); };
        if (hours) return hours + 'h ' + pad(minutes) + 'm';
        if (minutes) return minutes + 'm ' + pad(seconds) + 's';
        return seconds + 's';
    }

    function numberFormat(value) {
        const number = Number(value) || 0;
        try { return number.toLocaleString(); } catch (error) { return String(number); }
    }


    function rollbackDryRun() {
        const confirmation = rollbackConfirmInput ? rollbackConfirmInput.value : '';
        setStatus(labels.rollback || 'Preparing rollback dry-run...');
        startProgress(labels.rollback || 'Preparing rollback dry-run...');
        api('restorebase_rollback_dry_run', {confirmation: confirmation})
            .then(function (data) {
                setStatus('Ready');
                finishProgress('Rollback dry-run ready.');
                previewEl.innerHTML = renderRollback(data);
                return refreshAll();
            })
            .catch(showError);
    }

    function executeRollback() {
        const confirmation = rollbackConfirmInput ? rollbackConfirmInput.value : '';
        if (confirmation !== 'ROLLBACK STAGING') {
            previewEl.innerHTML = '<div class="rb-check rb-check-danger"><span class="rb-check-level">block</span><div><strong class="rb-check-title">Rollback confirmation required</strong><p class="rb-check-message">Type ROLLBACK STAGING before running staging rollback.</p></div></div>';
            return;
        }
        busy(panel.querySelector('.rb-execute-rollback'), true);
        setStatus(labels.rollback || 'Executing staging rollback...');
        startProgress(labels.rollback || 'Executing staging rollback...');
        api('restorebase_execute_rollback', {confirmation: confirmation})
            .then(function (data) {
                setStatus(labels.rollbacked || 'Rollback action completed.');
                finishProgress(labels.rollbacked || 'Rollback action completed.');
                previewEl.innerHTML = renderRollback(data);
                if (data && data.job) renderJobResult(data.job);
                return refreshAll();
            })
            .catch(showError)
            .finally(function () { busy(panel.querySelector('.rb-execute-rollback'), false); });
    }

    function simpleAction(action, message, renderer) {
        const activeButton = document.activeElement && panel.contains(document.activeElement) && document.activeElement.matches('button, .rb-btn') ? document.activeElement : null;
        const controller = beginCancellableAction(action, message || 'Working...', activeButton);
        return api(action, {snapshot_key: selectedPackageKey()}, {signal: controller.signal})
            .then(function (data) {
                setStatus('Ready');
                finishProgress('Action completed.');
                previewEl.innerHTML = renderer ? renderer(data) : renderGenericReport(data);
                return refreshAll().then(function () {
                    if (action === 'restorebase_migration_bundle' && data && data.snapshot_key) {
                        setPackageValue(data.snapshot_key, {renderDetails: false});
                    }
                    return data;
                });
            })
            .catch(function (error) {
                if (isCancelError(error)) {
                    setStatus('Cancelled.');
                    failProgress('Action cancelled.');
                    return false;
                }
                showError(error, function () { return simpleAction(action, message, renderer); });
                return false;
            })
            .finally(function () { endCancellableAction(activeButton); });
    }

    function selectedPackageKey() {
        return packageSelect ? (packageSelect.value || '') : '';
    }

    function startPolling() {
        if (statusTimer) return;
        statusTimer = window.setInterval(function () {
            if (!panel.classList.contains('rb-open')) return;
            Promise.all([loadStatus(), loadJobs(), loadSnapshots()]).catch(function () {});
        }, 5000);
    }

    function stopPolling() {
        if (statusTimer) window.clearInterval(statusTimer);
        statusTimer = null;
    }

    function renderSnapshots(items) {
        if (!items.length) {
            snapshotsEl.innerHTML = '<p class="rb-empty">No snapshots yet.</p>';
            return;
        }

        snapshotsEl.innerHTML = items.map(function (item) {
            const isPackage = item.trigger_type === 'backup_package' || item.trigger_type === 'migration_bundle' || item.trigger_type === 'migration_import';
            const packageInfo = item.package || null;
            const actions = [
                isPackage ? '<button type="button" class="rb-mini-action" data-rb-preview-key="' + escapeAttr(item.snapshot_key) + '">Preview</button>' : '',
                isPackage ? '<button type="button" class="rb-mini-action" data-rb-validate-key="' + escapeAttr(item.snapshot_key) + '">Validate</button>' : '',
                packageInfo && packageInfo.download_url ? '<a class="rb-mini-action rb-mini-download" href="' + escapeAttr(packageInfo.download_url) + '" download="' + escapeAttr(packageInfo.download_name || 'restorebase-backup.zip') + '">Download</a>' : '',
                '<button type="button" class="rb-mini-action rb-mini-danger" data-rb-delete-key="' + escapeAttr(item.snapshot_key) + '" data-rb-delete-label="' + escapeAttr(item.label || item.snapshot_key) + '">Delete</button>',
                isPackage ? '<button type="button" class="rb-mini-action rb-mini-restore" data-rb-restore-key="' + escapeAttr(item.snapshot_key) + '">Restore</button>' : '',
            ].filter(Boolean).join('');
            const cardId = 'rb-card-actions-' + escapeAttr(String(item.snapshot_key || '').replace(/[^A-Za-z0-9_-]/g, ''));

            return [
                '<div class="rb-snapshot-item rb-snapshot-collapsible">',
                    '<div class="rb-snapshot-main">',
                        '<strong>' + escapeHtml(item.label || item.snapshot_key) + '</strong>',
                        '<div class="rb-snapshot-meta">',
                            '<span class="rb-pill ' + (item.status === 'completed' ? 'rb-pill-ok' : '') + '">' + escapeHtml(item.status) + '</span>',
                            '<span class="rb-pill">' + escapeHtml(packageTypeLabel(item.trigger_type, item.meta || {})) + '</span>',
                            '<span class="rb-pill">Download ' + formatBytes(packageDownloadSize(item)) + '</span>',
                        '</div>',
                        '<div class="rb-snapshot-id"><span>Backup ID</span><code>' + escapeHtml(item.snapshot_key) + '</code></div>',
                        actions ? '<button type="button" class="rb-card-actions-toggle" data-rb-card-actions-toggle aria-expanded="false" aria-controls="' + cardId + '"><span>Actions</span><i aria-hidden="true">⌄</i></button>' : '',
                        actions ? '<div id="' + cardId + '" class="rb-snapshot-actions rb-snapshot-actions-collapsed" hidden>' + actions + '</div>' : '',
                    '</div>',
                '</div>'
            ].join('');
        }).join('');

        snapshotsEl.querySelectorAll('[data-rb-card-actions-toggle]').forEach(function (button) {
            button.addEventListener('click', function () {
                const targetId = button.getAttribute('aria-controls') || '';
                const target = targetId ? document.getElementById(targetId) : null;
                if (!target) return;
                const isOpen = button.getAttribute('aria-expanded') === 'true';
                button.setAttribute('aria-expanded', isOpen ? 'false' : 'true');
                button.classList.toggle('open', !isOpen);
                target.hidden = isOpen;
            });
        });
        snapshotsEl.querySelectorAll('[data-rb-preview-key]').forEach(function (button) {
            button.addEventListener('click', function () { restorePreview(button.getAttribute('data-rb-preview-key') || ''); });
        });
        snapshotsEl.querySelectorAll('[data-rb-validate-key]').forEach(function (button) {
            button.addEventListener('click', function () {
                setPackageValue(button.getAttribute('data-rb-validate-key') || '');
                validatePackage();
            });
        });
        snapshotsEl.querySelectorAll('.rb-mini-download').forEach(function (link) {
            link.addEventListener('click', function () {
                downloadProgress('Download started.');
            });
        });
        snapshotsEl.querySelectorAll('[data-rb-restore-key]').forEach(function (button) {
            button.addEventListener('click', function () {
                restoreBackup(button.getAttribute('data-rb-restore-key') || '', button);
            });
        });
        snapshotsEl.querySelectorAll('[data-rb-delete-key]').forEach(function (button) {
            button.addEventListener('click', function () {
                deleteSnapshot(button.getAttribute('data-rb-delete-key') || '', button.getAttribute('data-rb-delete-label') || 'this item', button);
            });
        });
    }

    function deleteSnapshot(snapshotKey, label, button) {
        if (!snapshotKey) {
            showError(new Error('Snapshot key is missing.'));
            return;
        }

        confirmDialog({
            title: 'Delete backup?',
            message: 'Delete "' + label + '"? This removes the RestoreBase record and local stored files for this backup.',
            confirmText: 'Delete',
            cancelText: 'Cancel',
            danger: true,
            trigger: button
        }).then(function (ok) {
            if (!ok) return;

            busy(button, true);
            setStatus(labels.deleting || 'Deleting snapshot/package...');
            startProgress(labels.deleting || 'Deleting snapshot/package...', 12);
            api('restorebase_delete_snapshot', {snapshot_key: snapshotKey, delete_files: '1'})
                .then(function (data) {
                    if (data && data.ok === false) throw new Error(data.message || 'Delete failed.');
                    setStatus(labels.deleted || 'Snapshot/package deleted.');
                    finishProgress(labels.deleted || 'Snapshot/package deleted.');
                    previewEl.innerHTML = renderDeleteResult(data);
                    if (selectedPackageKey() === snapshotKey) setPackageValue('');
                    return refreshAll();
                })
                .catch(showError)
                .finally(function () { busy(button, false); });
        });
    }

    function confirmDialog(options) {
        options = options || {};
        return new Promise(function (resolve) {
            const existing = document.querySelector('.rb-dialog-wrap');
            if (existing) existing.remove();

            const dialogHost = dialogHostFor(options.trigger || null);
            const rect = dialogHost.getBoundingClientRect();
            const wrap = document.createElement('div');
            wrap.className = 'rb-dialog-wrap rb-dialog-wrap-local';
            wrap.setAttribute('role', 'presentation');
            wrap.style.inset = 'auto';
            wrap.style.top = Math.max(0, rect.top) + 'px';
            wrap.style.left = Math.max(0, rect.left) + 'px';
            wrap.style.width = Math.max(260, rect.width) + 'px';
            wrap.style.height = Math.max(180, rect.height) + 'px';
            wrap.dataset.rbDialogHost = dialogHost.classList.contains('rb-safe-dock') ? 'safe-checks' : 'main-panel';
            wrap.innerHTML = [
                '<div class="rb-dialog" role="dialog" aria-modal="true" aria-labelledby="rb-dialog-title">',
                    '<div class="rb-dialog-header">',
                        '<div class="rb-dialog-icon" aria-hidden="true">!</div>',
                        '<strong id="rb-dialog-title">' + escapeHtml(options.title || 'Confirm action') + '</strong>',
                    '</div>',
                    '<div class="rb-dialog-message">' + escapeHtml(options.message || 'Are you sure?') + '</div>',
                    options.requireText ? '<label class="rb-dialog-label"><span>' + escapeHtml(options.inputLabel || ('Type ' + options.requireText + ' to confirm')) + '</span><input class="rb-dialog-input" type="text" autocomplete="off" spellcheck="false" /></label>' : '',
                    '<div class="rb-dialog-actions">',
                        '<button type="button" class="rb-dialog-btn rb-dialog-cancel">' + escapeHtml(options.cancelText || 'Cancel') + '</button>',
                        '<button type="button" class="rb-dialog-btn rb-dialog-confirm ' + (options.danger ? 'rb-dialog-danger' : (options.warning ? 'rb-dialog-warning' : 'rb-dialog-primary')) + '">' + escapeHtml(options.confirmText || 'Confirm') + '</button>',
                    '</div>',
                '</div>'
            ].join('');

            const confirmBtn = wrap.querySelector('.rb-dialog-confirm');
            const typedInput = wrap.querySelector('.rb-dialog-input');
            const requiredText = options.requireText ? String(options.requireText).trim().toUpperCase() : '';
            const updateConfirmState = function () {
                if (!confirmBtn || !requiredText) return;
                const typed = typedInput ? String(typedInput.value || '').trim().toUpperCase() : '';
                const ready = typed === requiredText;
                confirmBtn.disabled = !ready;
                confirmBtn.classList.toggle('rb-dialog-confirm-ready', ready);
                confirmBtn.setAttribute('aria-disabled', ready ? 'false' : 'true');
            };
            if (options.requireText && confirmBtn) {
                confirmBtn.disabled = true;
                confirmBtn.setAttribute('aria-disabled', 'true');
            }
            if (typedInput && confirmBtn) {
                ['input', 'keyup', 'change'].forEach(function (eventName) {
                    typedInput.addEventListener(eventName, updateConfirmState);
                });
                typedInput.addEventListener('paste', function () { setTimeout(updateConfirmState, 0); });
            }

            let didClean = false;
            const cleanup = function (value) {
                if (didClean) return;
                didClean = true;
                if (activeDialogCleanup === cleanup) activeDialogCleanup = null;
                document.removeEventListener('keydown', onKeydown);
                wrap.classList.remove('show');
                setTimeout(function () { wrap.remove(); }, 120);
                resolve(value);
            };
            activeDialogCleanup = cleanup;
            const onKeydown = function (event) {
                if (event.key === 'Escape') cleanup(false);
                if (event.key === 'Enter' && (!confirmBtn || !confirmBtn.disabled)) cleanup(true);
            };

            wrap.addEventListener('click', function (event) {
                if (event.target === wrap) cleanup(false);
            });
            wrap.querySelector('.rb-dialog-cancel').addEventListener('click', function () { cleanup(false); });
            confirmBtn.addEventListener('click', function () { if (!confirmBtn.disabled) cleanup(true); });
            document.addEventListener('keydown', onKeydown);
            document.body.appendChild(wrap);
            requestAnimationFrame(function () {
                wrap.classList.add('show');
                updateConfirmState();
                (typedInput || confirmBtn).focus();
            });
        });
    }



    function dialogHostFor(trigger) {
        if (trigger && trigger.closest) {
            const safeDock = trigger.closest('.rb-safe-dock');
            if (safeDock) return safeDock;
        }
        return panel;
    }

    function isPackageItem(item) {
        return item && (item.trigger_type === 'backup_package' || item.trigger_type === 'migration_bundle' || item.trigger_type === 'migration_import');
    }

    function getPackageByKey(value) {
        const packages = snapshots.filter(isPackageItem);
        if (!value) return packages[0] || null;
        return packages.filter(function (item) { return item.snapshot_key === value; })[0] || null;
    }

    function normalizePackageDetails(data) {
        data = data || {};
        const packageData = data.package || {};
        return {
            snapshot_key: data.snapshot_key || '',
            label: data.label || 'Backup',
            status: data.status || 'completed',
            trigger_type: data.trigger_type || 'backup_package',
            size_bytes: data.size_bytes || packageData.size || 0,
            created_at: data.created_at || '',
            meta: data.meta || {},
            package: packageData
        };
    }

    function packageDownloadSize(item) {
        item = item || {};
        const packageData = item.package || {};
        return Number(packageData.actual_size || packageData.size || item.size_bytes || packageData.recorded_size || 0) || 0;
    }

    function packageSourceSize(item) {
        item = item || {};
        const meta = item.meta || {};
        const breakdown = meta.size_breakdown || (meta.contents && meta.contents.size_breakdown) || null;
        if (!breakdown || typeof breakdown !== 'object') return 0;
        const source = breakdown.archived_file_bytes || breakdown.source_file_bytes || {};
        const files = Object.keys(source || {}).reduce(function (total, key) { return total + (Number(source[key]) || 0); }, 0);
        return (Number(breakdown.database) || 0) + files;
    }

    function renderPackageSummary(item, options) {
        options = options || {};
        item = normalizePackageDetails(item);
        const packageInfo = item.package || {};
        const title = item.label || item.snapshot_key || 'Backup';
        const hideDownloadAction = !!options.hideDownloadAction;
        const actionItems = [
            item.snapshot_key ? '<button type="button" class="rb-mini-action" data-rb-preview-key="' + escapeAttr(item.snapshot_key) + '">Preview</button>' : '',
            item.snapshot_key ? '<button type="button" class="rb-mini-action" data-rb-validate-key="' + escapeAttr(item.snapshot_key) + '">Validate</button>' : '',
            (!hideDownloadAction && packageInfo.download_url) ? '<a class="rb-mini-action rb-mini-download rb-inline-download" href="' + escapeAttr(packageInfo.download_url) + '" download="' + escapeAttr(packageInfo.download_name || 'restorebase-backup.zip') + '">Download</a>' : '',
            item.snapshot_key ? '<button type="button" class="rb-mini-action rb-mini-danger" data-rb-delete-key="' + escapeAttr(item.snapshot_key) + '" data-rb-delete-label="' + escapeAttr(title) + '">Delete</button>' : ''
        ].filter(Boolean);
        const actions = options.actions === false ? '' : actionItems.join('');
        const actionClass = hideDownloadAction ? ' rb-actions-no-small-download' : '';

        return [
            '<div class="rb-snapshot-item rb-selected-package-card">',
                '<div class="rb-snapshot-main">',
                    '<strong>' + escapeHtml(title) + '</strong>',
                    '<div class="rb-snapshot-meta">',
                        '<span class="rb-pill ' + (item.status === 'completed' ? 'rb-pill-ok' : '') + '">' + escapeHtml(item.status || '—') + '</span>',
                        '<span class="rb-pill">' + escapeHtml(packageTypeLabel(item.trigger_type, item.meta || {})) + '</span>',
                        '<span class="rb-pill">Download ' + formatBytes(packageDownloadSize(item)) + '</span>',
                    '</div>',
                    item.snapshot_key ? '<div class="rb-snapshot-id"><span>Backup ID</span><code>' + escapeHtml(item.snapshot_key) + '</code></div>' : '',
                    actions ? '<div class="rb-snapshot-actions rb-selected-package-actions' + actionClass + '">' + actions + '</div>' : '',
                '</div>',
            '</div>'
        ].join('');
    }

    function renderSelectedPackageDetails(item) {
        item = normalizePackageDetails(item);
        const downloadUrl = item.package && item.package.download_url ? item.package.download_url : '';
        const downloadName = item.package && item.package.download_name ? item.package.download_name : 'restorebase-backup.zip';
        const download = downloadUrl ? '<a class="rb-btn rb-btn-accent rb-inline-download" href="' + escapeAttr(downloadUrl) + '" download="' + escapeAttr(downloadName) + '">Download Backup</a>' : '';
        return [
            renderPackageSummary(item, {hideDownloadAction: true}),
            '<div class="rb-risk"><strong>Backup:</strong> This one ZIP is your backup and can be restored on this site or another site.<br>Backup ID: <code>' + escapeHtml(item.snapshot_key || '—') + '</code></div>',
            renderSizeBreakdown(item),
            download ? '<div class="rb-download-callout">' + download + '<p>Keep this file safe or import it on another site to restore.</p></div>' : '',
            item.snapshot_key ? '<div class="rb-restore-callout"><button type="button" class="rb-btn rb-btn-warning rb-restore-backup" data-rb-restore-key="' + escapeAttr(item.snapshot_key) + '">Restore Backup</button><p>This applies the selected backup to this site after typed confirmation.</p></div>' : '',
            '<div class="rb-plan-list">',
                '<div class="rb-plan-step"><span>1</span><div><strong>Download this backup file.</strong><p>Keep it as a backup or move it to another site.</p></div></div>',
                '<div class="rb-plan-step"><span>2</span><div><strong>Install RestoreBase on the new site.</strong><p>Use the same backup file there.</p></div></div>',
                '<div class="rb-plan-step"><span>3</span><div><strong>Import, validate, preview, then restore.</strong><p>Check the package before applying it.</p></div></div>',
            '</div>'
        ].join('');
    }


    function renderSizeBreakdown(item) {
        item = normalizePackageDetails(item);
        const meta = item.meta || {};
        const breakdown = meta.size_breakdown || (meta.contents && meta.contents.size_breakdown) || null;
        if (!breakdown || typeof breakdown !== 'object') return '';
        const source = breakdown.archived_file_bytes || breakdown.source_file_bytes || {};
        const rows = [];
        const add = function (label, value) {
            value = Number(value) || 0;
            if (value > 0) rows.push('<div class="rb-size-row"><span>' + escapeHtml(label) + '</span><strong>' + formatBytes(value) + '</strong></div>');
        };
        const downloadSize = packageDownloadSize(item);
        const sourceTotal = packageSourceSize(item);
        add('Download ZIP size', downloadSize);
        add('Original content size', sourceTotal);
        // Surface which database exporter actually ran: "Fast database export" falls
        // back to the PHP exporter silently, so without this there is no way to tell.
        const dbMethod = (meta.database_export && meta.database_export.method)
            || (meta.contents && meta.contents.database_dump && meta.contents.database_dump.method) || '';
        if (dbMethod) {
            const label = dbMethod === 'mysqldump' ? 'mysqldump (fast)' : 'PHP exporter';
            rows.push('<div class="rb-size-row"><span>Database export</span><strong>' + escapeHtml(label) + '</strong></div>');
        }
        const enc = meta.encrypted ? 'AES-256-GCM' : '';
        if (enc) rows.push('<div class="rb-size-row"><span>Encryption</span><strong>' + escapeHtml(enc) + '</strong></div>');
        add('Database', breakdown.database || 0);
        add('Uploads', source.uploads || 0);
        add('Plugins', source.plugins || 0);
        add('Themes', source.themes || 0);
        add('MU plugins', source['mu-plugins'] || 0);
        add('Other files', (source.other || 0) + (source['wp-content'] || 0));
        if (!rows.length && breakdown.files_archive) add('Files archive', breakdown.files_archive);
        if (!rows.length) return '';
        const saved = sourceTotal > 0 && downloadSize > 0 && sourceTotal > downloadSize ? ' · compressed by ' + formatBytes(sourceTotal - downloadSize) : '';
        const metaLine = [
            breakdown.file_count ? formatCount(breakdown.file_count) + ' scanned' : '',
            breakdown.archived_files ? formatCount(breakdown.archived_files) + ' archived' : '',
            breakdown.skipped_files ? formatCount(breakdown.skipped_files) + ' skipped' : ''
        ].filter(Boolean).join(' · ') + saved;
        return '<details class="rb-size-breakdown" open><summary>Backup contents and download size</summary><div>' + rows.join('') + '</div>' + (metaLine ? '<small>' + escapeHtml(metaLine) + '</small>' : '') + '</details>';
    }

    function formatCount(value) {
        value = Number(value) || 0;
        return value.toLocaleString ? value.toLocaleString() : String(value);
    }

    function packageTypeLabel(type, meta) {
        if (type === 'migration_import') return 'imported backup';
        if (type === 'migration_bundle') return 'legacy backup';
        if (type === 'backup_package') return (meta && meta.migration_ready) ? 'backup' : 'backup';
        return type || 'snapshot';
    }

    function renderPackageSelect(items) {
        if (!packageSelect) return;
        const selected = packageSelect.value;
        const packages = items.filter(function (item) { return item.trigger_type === 'backup_package' || item.trigger_type === 'migration_bundle' || item.trigger_type === 'migration_import'; });
        const options = [{value: '', label: 'Latest backup', meta: packages.length ? 'Use the newest completed backup' : 'Create a backup first'}].concat(packages.map(function (item) {
            return {
                value: item.snapshot_key,
                label: item.label || item.snapshot_key,
                meta: (item.created_at || '') + ' · Download ' + formatBytes(packageDownloadSize(item))
            };
        }));

        packageSelect.innerHTML = options.map(function (item) {
            return '<option value="' + escapeAttr(item.value) + '">' + escapeHtml(item.label + (item.meta ? ' · ' + item.meta : '')) + '</option>';
        }).join('');

        setPackageValue(selected && options.some(function (item) { return item.value === selected; }) ? selected : '');
        renderPackageMenu(options);
    }

    function renderPackageMenu(options) {
        if (!packageMenuButton || !packageMenuList) return;
        packageMenuList.innerHTML = options.map(function (item) {
            const isOn = item.value === selectedPackageKey();
            return '<button type="button" class="rb-menu-item ' + (isOn ? 'on' : '') + '" data-rb-package-value="' + escapeAttr(item.value) + '">' + escapeHtml(item.label) + (item.meta ? '<small>' + escapeHtml(item.meta) + '</small>' : '') + '</button>';
        }).join('');

        packageMenuList.querySelectorAll('[data-rb-package-value]').forEach(function (button) {
            button.addEventListener('click', function () {
                setPackageValue(button.getAttribute('data-rb-package-value') || '', {renderDetails: true});
                closePackageMenu();
            });
        });
    }

    function togglePackageMenu() {
        if (!packageMenu || !packageMenuList) return;
        const isOpen = packageMenu.classList.contains('open');
        if (isOpen) {
            closePackageMenu();
        } else {
            packageMenu.classList.add('open');
            packageMenuList.hidden = false;
        }
    }

    function closePackageMenu() {
        if (!packageMenu || !packageMenuList) return;
        packageMenu.classList.remove('open');
        packageMenuList.hidden = true;
    }

    function setPackageValue(value, options) {
        options = options || {};
        if (packageSelect) packageSelect.value = value || '';
        const selected = getPackageByKey(value || '');
        if (packageMenuButton) {
            packageMenuButton.textContent = selected ? (selected.label || selected.snapshot_key) : 'Latest backup';
        }
        if (packageMenuList) {
            packageMenuList.querySelectorAll('.rb-menu-item').forEach(function (button) {
                button.classList.toggle('on', (button.getAttribute('data-rb-package-value') || '') === (value || ''));
            });
        }
        if (options.renderDetails && selected && previewEl) {
            previewEl.innerHTML = renderSelectedPackageDetails(selected);
        }
    }

    function renderJobs(items) {
        if (!jobsEl) return;
        jobsEl.setAttribute('data-rb-has-cache', Array.isArray(items) && items.length ? '1' : '0');
        if (!items.length) {
            jobsEl.innerHTML = '<p class="rb-empty">No jobs yet.</p>';
            return;
        }

        jobsEl.innerHTML = items.map(function (job) {
            const tasks = Object.keys(job.task_state || {}).map(function (key) { return job.task_state[key]; });
            const done = tasks.filter(function (task) { return task.status === 'completed'; }).length;
            const failed = tasks.filter(function (task) { return task.status === 'failed'; }).length;
            const total = tasks.length;
            const progress = Math.max(0, Math.min(100, Number(job.progress) || 0));
            const status = String(job.status || 'pending');
            const statusLabel = status.charAt(0).toUpperCase() + status.slice(1).replace(/_/g, ' ');
            const stepsText = total ? (done + '/' + total + ' steps') : 'No step data';
            const detailsOpen = status === 'running' || status === 'failed' ? ' open' : '';
            const rawLabel = String(job.label || job.type || 'RestoreBase job');
            const cleanLabel = rawLabel.replace(/^Migration bundle source/i, 'Backup').replace(/^Site package/i, 'Backup');
            const cleanType = String(job.type || 'job').replace(/migration_bundle/g, 'backup_package').replace(/site_package/g, 'backup_package');
            const restoreResultAction = isRestoreJob(job) ? '<button type="button" class="rb-mini-action rb-view-restore-result" data-rb-view-restore-result="' + escapeAttr(job.job_key || '') + '">View result</button>' : '';

            return [
                '<div class="rb-job rb-job-clean rb-job-' + escapeAttr(status) + '">',
                    '<div class="rb-job-head">',
                        '<div class="rb-job-title">',
                            '<strong>' + escapeHtml(cleanLabel) + '</strong>',
                            '<span>' + escapeHtml(cleanType) + (job.message ? ' · ' + escapeHtml(job.message) : '') + '</span>',
                        '</div>',
                        '<span class="rb-job-status rb-job-status-' + escapeAttr(status) + '">' + escapeHtml(statusLabel) + '</span>',
                    '</div>',
                    '<div class="rb-job-progress-row">',
                        '<span>' + escapeHtml(progress) + '%</span>',
                        '<span>' + escapeHtml(stepsText) + (failed ? ' · ' + escapeHtml(failed) + ' failed' : '') + '</span>',
                    '</div>',
                    '<div class="rb-progress"><span style="width:' + progress + '%"></span></div>',
                    restoreResultAction ? '<div class="rb-job-actions">' + restoreResultAction + '</div>' : '',
                    total ? '<details class="rb-job-steps"' + detailsOpen + '><summary>View job steps</summary><div class="rb-task-list">' + tasks.map(function (task) {
                        return '<span class="rb-task rb-task-' + escapeAttr(task.status || 'pending') + '"><i></i>' + escapeHtml(task.label || task.id) + '</span>';
                    }).join('') + '</div></details>' : '',
                '</div>'
            ].join('');
        }).join('');

        jobsEl.querySelectorAll('[data-rb-view-restore-result]').forEach(function (button) {
            button.addEventListener('click', function () {
                const key = button.getAttribute('data-rb-view-restore-result') || '';
                const job = items.find(function (item) { return String(item.job_key || '') === key; });
                if (job) {
                    openPanel();
                    renderRestoreOutcome(job, {force: true});
                }
            });
        });
    }

    function renderJobResult(job) {
        if (!job) return;
        const state = job.task_state || {};
        const failed = Object.keys(state).map(function (key) { return state[key]; }).filter(function (task) { return task.status === 'failed'; });
        const failedHtml = failed.length ? '<div class="rb-check-list">' + failed.map(function (task) {
            return '<div class="rb-check rb-check-danger"><span class="rb-check-level">fix</span><div><strong class="rb-check-title">' + escapeHtml(task.label || task.id || 'Failed step') + '</strong><p class="rb-check-message">' + escapeHtml(task.message || 'This step failed.') + '</p></div></div>';
        }).join('') + '</div>' : '';
        previewEl.innerHTML = [
            '<div class="rb-risk rb-risk-' + escapeAttr(job.status || 'unknown') + '"><strong>Job:</strong> ' + escapeHtml(job.label || job.job_key) + '<br>Status: ' + escapeHtml(job.status) + ' · Progress: ' + escapeHtml(job.progress) + '%</div>',
            failedHtml
        ].join('');
    }

    function renderValidation(data) {
        const checks = Array.isArray(data.checks) ? data.checks : [];
        const summary = data.summary || {};
        return [
            '<div class="rb-risk"><strong>Package validation:</strong> ' + escapeHtml(data.message || 'Done') + '<br>Status: ' + escapeHtml(summary.status || '—') + ' · Blockers: ' + escapeHtml(summary.danger || 0) + ' · Warnings: ' + escapeHtml(summary.warnings || 0) + '</div>',
            renderChecks(checks)
        ].join('');
    }

    function renderPreview(data) {
        if (!data || data.available === false) {
            return '<p class="rb-empty">' + escapeHtml((data && data.message) || 'Preview is unavailable.') + '</p>';
        }
        const checks = Array.isArray(data.checks) ? data.checks : [];
        const risk = data.risk || {};
        const backup = data.backup_site || {};
        const current = data.current_site || {};
        return [
            '<div class="rb-risk"><strong>Restore preview:</strong> ' + escapeHtml(risk.summary || data.message || 'Ready') + '</div>',
            '<div class="rb-site-compare">',
                '<div class="rb-site-mini"><strong>Backup</strong><span>' + escapeHtml(backup.url || '—') + '</span><span>WP ' + escapeHtml(backup.wp_version || '—') + ' · Prefix ' + escapeHtml(backup.table_prefix || '—') + '</span></div>',
                '<div class="rb-site-mini"><strong>Current</strong><span>' + escapeHtml(current.url || '—') + '</span><span>WP ' + escapeHtml(current.wp_version || '—') + ' · Prefix ' + escapeHtml(current.table_prefix || '—') + '</span></div>',
            '</div>',
            renderChecks(checks)
        ].join('');
    }

    function renderDryRun(data) {
        const blockers = Array.isArray(data.blockers) ? data.blockers : [];
        const plan = Array.isArray(data.plan) ? data.plan : [];
        return [
            '<div class="rb-risk"><strong>Dry-run:</strong> ' + escapeHtml(data.message || 'Dry-run completed.') + '<br>Production restore enabled: <strong>No</strong></div>',
            blockers.length ? '<div class="rb-check-list">' + blockers.map(function (blocker) { return '<div class="rb-check rb-check-danger"><span class="rb-check-level">block</span><div><strong class="rb-check-title">Restore blocker</strong><p class="rb-check-message">' + escapeHtml(blocker) + '</p></div></div>'; }).join('') + '</div>' : '<div class="rb-check rb-check-ok"><span class="rb-check-level">ok</span><div><strong class="rb-check-title">No dry-run blockers</strong><p class="rb-check-message">The dry-run plan passed, but production restore stays locked. Staging-only execution still needs confirmation and readiness checks.</p></div></div>',
            '<div class="rb-plan-list">',
                plan.map(function (step, index) {
                    return '<div class="rb-plan-step"><span>' + (index + 1) + '</span><div><strong>' + escapeHtml(step.title || '') + '</strong><p>' + escapeHtml(step.message || '') + '</p></div></div>';
                }).join(''),
            '</div>'
        ].join('');
    }

    function renderReadiness(data) {
        const checks = Array.isArray(data.checks) ? data.checks : [];
        const disk = data.disk || {};
        return [
            '<div class="rb-risk"><strong>Readiness score:</strong> ' + escapeHtml(data.score || 0) + '/100<br>Status: ' + escapeHtml(data.status || '—') + ' · Environment: ' + escapeHtml(data.environment || '—') + '</div>',
            '<div class="rb-site-compare">',
                '<div class="rb-site-mini"><strong>Execution gate</strong><span>' + escapeHtml(data.staging_like ? 'Staging/local allowed' : 'Production locked') + '</span><span>Production restore: blocked</span></div>',
                '<div class="rb-site-mini"><strong>Disk</strong><span>' + formatBytes(disk.free_bytes || 0) + ' free</span><span>' + escapeHtml(disk.message || '—') + '</span></div>',
            '</div>',
            renderChecks(checks)
        ].join('');
    }

    function renderExecution(data) {
        const job = data && data.job ? data.job : {};
        const ok = !!(data && data.ok);
        const verify = data && data.verify_now && Array.isArray(data.verify_now) ? data.verify_now : [];
        const post = data && data.post_restore_verification ? data.post_restore_verification : (data && data.context && data.context.post_restore_verification ? data.context.post_restore_verification : null);
        const next = post && Array.isArray(post.next) ? post.next : (ok ? ['Refresh wp-admin.', 'Open the homepage.', 'Check Plugins and Themes.', 'Save Permalinks if needed.'] : ['Check the failed step below before retrying.']);
        const failed = post && Array.isArray(post.failed) ? post.failed : [];
        return [
            '<div class="rb-risk rb-risk-' + (ok ? 'completed' : 'failed') + '"><strong>Restore result:</strong> ' + escapeHtml((data && data.message) || (ok ? 'Restore completed.' : 'Restore did not complete cleanly.')) + '<br>Status: ' + escapeHtml(ok ? 'completed and verified' : 'blocked/failed') + '</div>',
            failed.length ? '<div class="rb-check-list">' + failed.map(function (item) { return '<div class="rb-check rb-check-danger"><span class="rb-check-level">fix</span><div><strong class="rb-check-title">' + escapeHtml(item.key || 'Verification issue') + '</strong><p class="rb-check-message">' + escapeHtml(item.message || 'Verification failed.') + '</p></div></div>'; }).join('') + '</div>' : '',
            next.length ? '<div class="rb-plan-list rb-next-steps">' + next.map(function (step, index) { return '<div class="rb-plan-step"><span>' + (index + 1) + '</span><div><strong>' + escapeHtml(step) + '</strong><p>Do this after the restore action finishes.</p></div></div>'; }).join('') + '</div>' : '',
            verify.length ? '<div class="rb-check-list">' + verify.map(function (item) { return '<div class="rb-check rb-check-info"><span class="rb-check-level">check</span><div><strong class="rb-check-title">Verify ' + escapeHtml(item) + '</strong><p class="rb-check-message">Check this immediately after restore.</p></div></div>'; }).join('') + '</div>' : '',
            job && job.job_key ? '<div class="rb-risk"><strong>Job:</strong> ' + escapeHtml(job.label || job.job_key) + '<br>Status: ' + escapeHtml(job.status || '—') + ' · Progress: ' + escapeHtml(job.progress || 0) + '%</div>' : ''
        ].join('');
    }

    function renderPreparation(data) {
        const plan = data || {};
        const workspace = plan.workspace || {};
        const sql = plan.sql_import_plan || {};
        const url = plan.url_rewrite_plan || {};
        const config = plan.config_guard || {};
        const confirmation = plan.confirmation || {};
        const planFile = plan.plan_file || {};

        return [
            '<div class="rb-risk"><strong>Guarded restore preparation:</strong> ' + escapeHtml(plan.message || 'Preparation completed. No restore action was performed.') + '<br>Production restore enabled: <strong>No</strong></div>',
            '<div class="rb-site-compare">',
                '<div class="rb-site-mini"><strong>Workspace</strong><span>' + escapeHtml(workspace.workspace_key || '—') + '</span><span>' + escapeHtml(workspace.path || '—') + '</span></div>',
                '<div class="rb-site-mini"><strong>SQL Plan</strong><span>Tables: ' + escapeHtml(sql.table_count || 0) + ' · Strategy: ' + escapeHtml((sql.mapping && sql.mapping.strategy) || '—') + '</span><span>' + escapeHtml(sql.backup_prefix || '—') + ' → ' + escapeHtml(sql.current_prefix || '—') + '</span></div>',
                '<div class="rb-site-mini"><strong>URL Plan</strong><span>' + escapeHtml(url.needs_rewrite ? 'Rewrite needed' : 'No rewrite needed') + '</span><span>' + escapeHtml(url.backup_url || '—') + ' → ' + escapeHtml(url.current_url || '—') + '</span></div>',
                '<div class="rb-site-mini"><strong>Config Guard</strong><span>' + escapeHtml(config.message || '—') + '</span><span>wp-config overwrite: blocked</span></div>',
            '</div>',
            '<div class="rb-plan-list">',
                '<div class="rb-plan-step"><span>1</span><div><strong>Temporary workspace</strong><p>' + escapeHtml(workspace.path || 'Workspace path unavailable.') + '</p></div></div>',
                '<div class="rb-plan-step"><span>2</span><div><strong>Temporary table strategy</strong><p>' + escapeHtml((sql.mapping && sql.mapping.note) || 'Import planning completed.') + '</p></div></div>',
                '<div class="rb-plan-step"><span>3</span><div><strong>wp-config preservation</strong><p>Destination credentials stay protected. RestoreBase never overwrites wp-config.php blindly.</p></div></div>',
                '<div class="rb-plan-step"><span>4</span><div><strong>Confirmation gate</strong><p>' + escapeHtml(confirmation.message || 'Restore execution remains locked.') + '</p></div></div>',
                '<div class="rb-plan-step"><span>5</span><div><strong>Plan file</strong><p>' + escapeHtml(planFile.path || 'Plan file not available.') + '</p></div></div>',
            '</div>'
        ].join('');
    }

    function renderMigrationImport(data) {
        const checks = Array.isArray(data && data.checks) ? data.checks : [];
        const steps = Array.isArray(data && data.next_steps) ? data.next_steps : [];
        return [
            '<div class="rb-risk"><strong>Backup import:</strong> ' + escapeHtml((data && data.message) || 'Import completed.') + '<br>Imported key: <code>' + escapeHtml((data && data.snapshot_key) || '—') + '</code></div>',
            data && data.source_url ? '<div class="rb-site-mini"><strong>Source site</strong><span>' + escapeHtml(data.source_url) + '</span><span>' + formatBytes(data.size || 0) + '</span></div>' : '',
            renderChecks(checks),
            steps.length ? '<div class="rb-plan-list">' + steps.map(function (step, index) { return '<div class="rb-plan-step"><span>' + (index + 1) + '</span><div><strong>' + escapeHtml(step) + '</strong><p>Run this step on the imported backup before restoring the new site.</p></div></div>'; }).join('') + '</div>' : ''
        ].join('');
    }

    function renderMigrationBundle(data) {
        const item = normalizePackageDetails(data || {});
        const descriptor = data && data.descriptor ? data.descriptor : {};
        const steps = Array.isArray(descriptor.destination_steps) ? descriptor.destination_steps : [
            'Download this backup file.',
            'Install RestoreBase on the new site.',
            'Import, validate, preview, then restore.'
        ];
        const downloadUrl = item.package && item.package.download_url ? item.package.download_url : '';
        const downloadName = item.package && item.package.download_name ? item.package.download_name : 'restorebase-backup.zip';
        const download = downloadUrl ? '<a class="rb-btn rb-btn-accent rb-inline-download" href="' + escapeAttr(downloadUrl) + '" download="' + escapeAttr(downloadName) + '">Download Backup</a>' : '';
        return [
            renderPackageSummary(item, {hideDownloadAction: true}),
            '<div class="rb-risk"><strong>Backup:</strong> This one ZIP is your backup and can be restored on this site or another site.<br>Backup ID: <code>' + escapeHtml(item.snapshot_key || '—') + '</code></div>',
            renderSizeBreakdown(item),
            download ? '<div class="rb-download-callout">' + download + '<p>Keep this file safe or import it on another site to restore.</p></div>' : '<div class="rb-site-mini"><strong>Next</strong><span>Download the backup from Recent snapshots.</span><span>Then import the backup on the new site.</span></div>',
            steps.length ? '<div class="rb-plan-list rb-plan-list-v2">' + steps.map(function (step, index) { return '<div class="rb-plan-step"><span>' + (index + 1) + '</span><div><strong>' + escapeHtml(step) + '</strong><p>Backup/restore step.</p></div></div>'; }).join('') + '</div>' : ''
        ].join('');
    }


    function renderVerification(data) {
        const checks = Array.isArray(data.checks) ? data.checks.map(function (item) {
            return { level: item.level || (item.ok ? 'ok' : 'warn'), title: item.title || item.id || 'Check', message: item.message || '' };
        }) : [];
        return [
            '<div class="rb-risk"><strong>Verification:</strong> ' + escapeHtml(data.message || 'Verification completed.') + '<br>Score: ' + escapeHtml(data.score || 0) + '/100</div>',
            renderChecks(checks)
        ].join('');
    }

    function renderRollback(data) {
        const checks = Array.isArray(data && data.checks) ? data.checks : [];
        const source = data && data.source ? data.source : null;
        return [
            '<div class="rb-risk"><strong>Rollback:</strong> ' + escapeHtml((data && data.message) || 'Rollback report ready.') + '<br>Execution enabled: <strong>' + escapeHtml(data && data.execution_enabled ? 'Yes' : 'Guarded') + '</strong></div>',
            source ? '<div class="rb-site-mini"><strong>Rollback source</strong><span>' + escapeHtml(source.label || source.snapshot_key || 'Pre-restore package') + '</span><span>' + escapeHtml(source.created_at || '') + '</span></div>' : '',
            renderChecks(checks),
            data && data.job ? '<div class="rb-risk"><strong>Job:</strong> ' + escapeHtml(data.job.label || data.job.job_key || '') + '<br>Status: ' + escapeHtml(data.job.status || '—') + ' · Progress: ' + escapeHtml(data.job.progress || 0) + '%</div>' : ''
        ].join('');
    }


    function renderProductionReadiness(data) {
        const checks = Array.isArray(data && data.checks) ? data.checks : [];
        return [
            '<div class="rb-risk"><strong>1.0 readiness:</strong> ' + escapeHtml((data && data.message) || 'Readiness report generated.') + '<br>Score: ' + escapeHtml(data && data.score != null ? data.score : 0) + '/100 · Production ready: <strong>' + escapeHtml(data && data.production_ready ? 'Yes' : 'No') + '</strong></div>',
            renderChecks(checks),
            data && data.locked_actions ? '<div class="rb-site-mini"><strong>Locked actions</strong><span>' + escapeHtml(data.locked_actions.join(' • ')) + '</span></div>' : '',
            data && data.next_gate ? '<div class="rb-site-mini"><strong>Next gate</strong><span>' + escapeHtml(data.next_gate) + '</span></div>' : ''
        ].join('');
    }

    function renderSecurityAudit(data) {
        const checks = Array.isArray(data && data.checks) ? data.checks : [];
        return [
            '<div class="rb-risk"><strong>Security audit:</strong> ' + escapeHtml((data && data.message) || 'Audit completed.') + '<br>Score: ' + escapeHtml(data && data.score != null ? data.score : 0) + '/100</div>',
            renderChecks(checks),
            data && data.locked_actions ? '<div class="rb-site-mini"><strong>Locked actions</strong><span>' + escapeHtml(data.locked_actions.join(' • ')) + '</span></div>' : ''
        ].join('');
    }


    function renderDeleteResult(data) {
        const deleted = Array.isArray(data && data.deleted_files) ? data.deleted_files.length : 0;
        const kept = Array.isArray(data && data.kept_files) ? data.kept_files.length : 0;
        const errors = Array.isArray(data && data.file_errors) ? data.file_errors.length : 0;
        return [
            '<div class="rb-risk"><strong>Deleted:</strong> ' + escapeHtml((data && data.label) || (data && data.snapshot_key) || 'Snapshot/package') + '<br>' + escapeHtml((data && data.message) || 'Item deleted.') + '</div>',
            '<div class="rb-site-compare">',
                '<div class="rb-site-mini"><strong>Deleted files</strong><span>' + escapeHtml(deleted) + '</span></div>',
                '<div class="rb-site-mini"><strong>Kept for safety</strong><span>' + escapeHtml(kept) + '</span></div>',
                '<div class="rb-site-mini"><strong>File errors</strong><span>' + escapeHtml(errors) + '</span></div>',
            '</div>'
        ].join('');
    }

    function renderGenericReport(data) {
        if (!data || typeof data !== 'object') return '<p class="rb-empty">No report returned.</p>';
        const title = data.message || 'Report ready.';
        const rows = [];
        Object.keys(data).forEach(function (key) {
            if (['ok','message'].includes(key)) return;
            const value = data[key];
            if (Array.isArray(value)) {
                rows.push('<div class="rb-site-mini"><strong>' + escapeHtml(key.replace(/_/g, ' ')) + '</strong><span>' + escapeHtml(value.map(function (item) { return typeof item === 'string' ? item : (item.label || item.id || JSON.stringify(item)); }).join(' • ')) + '</span></div>');
            } else if (value && typeof value === 'object') {
                rows.push('<div class="rb-site-mini"><strong>' + escapeHtml(key.replace(/_/g, ' ')) + '</strong><span>' + escapeHtml(JSON.stringify(value).slice(0, 420)) + '</span></div>');
            } else {
                rows.push('<div class="rb-site-mini"><strong>' + escapeHtml(key.replace(/_/g, ' ')) + '</strong><span>' + escapeHtml(value == null ? '—' : value) + '</span></div>');
            }
        });
        return '<div class="rb-risk"><strong>Report:</strong> ' + escapeHtml(title) + '</div><div class="rb-site-compare">' + rows.join('') + '</div>';
    }

    function renderChecks(checks) {
        if (!checks.length) return '<p class="rb-empty">No checks returned.</p>';
        return '<div class="rb-check-list">' + checks.map(function (check) {
            const level = check.level || 'info';
            return '<div class="rb-check rb-check-' + escapeAttr(level) + '"><span class="rb-check-level">' + escapeHtml(level) + '</span><div><strong class="rb-check-title">' + escapeHtml(check.title || '') + '</strong><p class="rb-check-message">' + escapeHtml(check.message || '') + '</p></div></div>';
        }).join('') + '</div>';
    }

    function beginCancellableAction(action, message, button) {
        const controller = new AbortController();
        activeRequestController = controller;
        activeActionName = action || '';
        activeJobKey = '';
        activeJobToken = '';
        setPanelActionLock(true);
        busy(button, true);
        startProgress(message || 'Working...', 8, true);
        return controller;
    }

    function endCancellableAction(button) {
        busy(button, false);
        // finishProgress/failProgress clears the panel lock. If a caller ends without either, unlock here.
        if (progressBox && progressBox.hidden) setPanelActionLock(false);
    }

    function cancelActiveAction() {
        const jobKey = activeJobKey;
        const controller = activeRequestController;
        setStatus('Cancelling…');
        updateProgress(Math.max(currentProgress, 8), 'Cancelling current action...');
        if (progressCancel) progressCancel.disabled = true;
        if (jobKey) {
            api('restorebase_cancel_job', {job_key: jobKey}).finally(function () {
                if (controller) controller.abort();
                if (progressCancel) progressCancel.disabled = false;
                setStatus('Cancelled.');
                failProgress('Action cancelled.');
                startPolling();
            });
            return;
        }
        if (controller) controller.abort();
        if (progressCancel) progressCancel.disabled = false;
        setStatus('Cancelled.');
        failProgress('Action cancelled.');
    }

    function isCancelError(error) {
        const msg = error && error.rbInfo ? (error.rbInfo.details || error.rbInfo.message || '') : (error && error.message ? error.message : '');
        return /cancel|abort/i.test(String(msg));
    }

    function setPanelActionLock(lock) {
        panel.classList.toggle('rb-action-lock', !!lock);
        const controls = panel.querySelectorAll('button, input, select, textarea, a.rb-mini-action, a.rb-inline-download');
        controls.forEach(function (control) {
            if (control.matches('[data-rb-cancel-action]')) return;
            const keepEnabled = control.classList.contains('rb-progress-cancel');
            if (keepEnabled) return;
            if (lock) {
                if (typeof control.disabled !== 'undefined') {
                    control.dataset.rbWasDisabled = control.disabled ? '1' : '0';
                    control.disabled = true;
                }
                control.classList.add('rb-locked-control');
                control.setAttribute('aria-disabled', 'true');
            } else {
                if (typeof control.disabled !== 'undefined' && control.dataset.rbWasDisabled !== '1') {
                    control.disabled = false;
                }
                delete control.dataset.rbWasDisabled;
                control.classList.remove('rb-locked-control');
                control.removeAttribute('aria-disabled');
            }
        });
    }

    function decorateStaticIcons() {
        return;
    }

    function busy(button, isBusy) {
        if (!button) return;
        button.disabled = !!isBusy;
        button.classList.toggle('rb-is-busy', !!isBusy);
    }

    function setStatus(message) {
        if (statusEl) statusEl.textContent = message || 'Ready';
    }

    function retryCallbackForError(error) {
        const info = getErrorInfo(error);
        const action = info.action || '';
        const map = {
            restorebase_status: refreshAll,
            restorebase_snapshots: loadSnapshots,
            restorebase_jobs: loadJobs,
            restorebase_migration_bundle: createBackupAction,
            restorebase_import_migration_package: importMigrationPackage,
            restorebase_validate_package: validatePackage,
            restorebase_restore_preview: restorePreview,
            restorebase_restore_dry_run: restoreDryRun,
            restorebase_prepare_restore: prepareRestore,
            restorebase_readiness: restoreReadiness,
            restorebase_delete_snapshot: function () { return loadSnapshots().then(refreshAll); },
            restorebase_rank_math_guard: function () { return simpleAction('restorebase_rank_math_guard', 'Stabilizing Rank Math keys...', renderGenericReport); },
            restorebase_remote_upload: function () { return simpleAction('restorebase_remote_upload', labels.remote || 'Uploading package to remote storage...', renderGenericReport); }
        };
        return map[action] || refreshAll;
    }

    function showError(error, retryCallback) {
        const info = getErrorInfo(error);
        const retry = retryCallback || retryCallbackForError(error);
        setStatus('Error: ' + info.title);
        failProgress(info.title || info.message || 'Request failed.');
        if (previewEl) {
            previewEl.innerHTML = renderErrorCard(error, info.title || 'Request failed', retry);
        }
    }

    function formatBytes(bytes) {
        bytes = Number(bytes) || 0;
        if (bytes < 1024) return bytes + ' B';
        if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
        if (bytes < 1024 * 1024 * 1024) return (bytes / 1024 / 1024).toFixed(1) + ' MB';
        return (bytes / 1024 / 1024 / 1024).toFixed(2) + ' GB';
    }

    function escapeHtml(value) {
        return String(value == null ? '' : value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function escapeAttr(value) {
        return escapeHtml(value).replace(/`/g, '&#096;');
    }
})();
