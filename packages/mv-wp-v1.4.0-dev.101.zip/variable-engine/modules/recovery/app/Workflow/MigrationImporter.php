<?php

namespace VE\Modules\Recovery\Workflow;

use VE\Modules\Recovery\Database\Schema;
use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Utils\Logger;

// phpcs:disable WordPress.Security.ValidatedSanitizedInput.InputNotSanitized

defined( 'ABSPATH' ) || exit;

final class MigrationImporter {
    public function import_uploaded( array $file, string $label = '', string $passphrase = '' ): array {
        if ( empty( $file ) || ! isset( $file['tmp_name'] ) ) {
            return $this->fail( 'No backup was uploaded.' );
        }

        $error = isset( $file['error'] ) ? (int) $file['error'] : UPLOAD_ERR_NO_FILE;
        if ( UPLOAD_ERR_OK !== $error ) {
            return $this->fail( $this->upload_error_message( $error ) );
        }

        $name = isset( $file['name'] ) ? sanitize_file_name( (string) $file['name'] ) : 'restorebase-migration.zip';
        $tmp = (string) $file['tmp_name'];
        $size = isset( $file['size'] ) ? (int) $file['size'] : 0;

        if ( $size <= 0 || ! is_uploaded_file( $tmp ) ) {
            return $this->fail( 'The uploaded backup is empty or invalid.' );
        }

        return $this->register_from_path( $tmp, $name, $label, true, $passphrase );
    }

    /**
     * Register a package that is already assembled on disk.
     *
     * Large backups cannot be posted in a single request (post_max_size /
     * upload_max_filesize / proxy body limits), so the UI uploads the ZIP in
     * chunks and appends them to one file. That file is not a PHP upload, so it
     * cannot go through is_uploaded_file()/move_uploaded_file().
     */
    public function import_local_file( string $path, string $original_name = '', string $label = '', string $passphrase = '' ): array {
        if ( '' === $path || ! is_readable( $path ) || (int) filesize( $path ) <= 0 ) {
            return $this->fail( 'The assembled backup upload is empty or missing.' );
        }
        $name = '' !== $original_name ? sanitize_file_name( $original_name ) : 'restorebase-migration.zip';
        return $this->register_from_path( $path, $name, $label, false, $passphrase );
    }

    private function register_from_path( string $tmp, string $name, string $label, bool $is_upload, string $passphrase = '' ): array {
        $ext = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
        if ( 'zip' !== $ext ) {
            return $this->fail( 'RestoreBase backup imports must be ZIP files.' );
        }

        if ( ! class_exists( '\ZipArchive' ) ) {
            return $this->fail( 'ZipArchive is required to inspect backups.' );
        }

        // An encrypted package is NOT a ZIP — it is an AES-256-GCM container, so
        // ZipArchive::open() fails with the useless "could not open the uploaded ZIP
        // package". Decrypt to a temp copy for inspection and keep the encrypted
        // original as the stored package so it stays encrypted at rest; validate and
        // restore decrypt it again on demand.
        $encrypted     = \VE\Modules\Recovery\Backup\PackageCipher::is_encrypted( $tmp );
        $inspect       = $tmp;
        $inspect_temp  = '';
        if ( $encrypted ) {
            $resolved = \VE\Modules\Recovery\Backup\PackageCipher::resolve_readable( $tmp, dirname( $tmp ), $passphrase );
            if ( empty( $resolved['ok'] ) ) {
                return $this->fail( (string) $resolved['message'], [], ! empty( $resolved['needs_passphrase'] ) );
            }
            $inspect      = (string) $resolved['path'];
            $inspect_temp = ! empty( $resolved['temp'] ) ? $inspect : '';
        }

        $zip = new \ZipArchive();
        if ( true !== $zip->open( $inspect ) ) {
            $this->cleanup_temp( $inspect_temp );
            return $this->fail(
                $encrypted
                    ? 'The package decrypted, but the contents are not a readable ZIP. The backup may be corrupted.'
                    : 'RestoreBase could not open the uploaded ZIP package. If this backup was encrypted, enter its key or passphrase and import again.'
            );
        }

        $required = [ 'manifest.json', 'database.sql', 'file-inventory.json', 'checksums.json' ];
        $checks = [];
        $blocked = false;
        foreach ( $required as $entry ) {
            $exists = false !== $zip->locateName( $entry );
            $checks[] = [
                'level'   => $exists ? 'ok' : 'danger',
                'title'   => $entry,
                'message' => $exists ? $entry . ' found.' : $entry . ' is missing from the package.',
            ];
            if ( ! $exists ) {
                $blocked = true;
            }
        }

        $manifest = $this->read_json_entry( $zip, 'manifest.json' );
        if ( ! is_array( $manifest ) ) {
            $zip->close();
            $this->cleanup_temp( $inspect_temp );
            return $this->fail( 'manifest.json could not be read from the backup.', $checks );
        }

        $checksums = $this->read_json_entry( $zip, 'checksums.json' );
        if ( ! is_array( $checksums ) ) {
            $checks[] = [ 'level' => 'danger', 'title' => 'checksums.json', 'message' => 'checksums.json could not be read.' ];
            $blocked = true;
        } else {
            $checks[] = [ 'level' => 'ok', 'title' => 'checksums.json', 'message' => 'checksums.json is readable.' ];

            // Verify every component against the checksums recorded when the backup
            // was built. This is what catches an incomplete/corrupted download at
            // import time instead of part-way through a restore. The package hash we
            // store below is computed from this same file, so it can only ever match
            // itself and cannot detect a truncated source download.
            if ( ! \VE\Modules\Recovery\Backup\PackageChecksums::fingerprint_matches( $checksums ) ) {
                $checks[] = [ 'level' => 'warn', 'title' => 'Package fingerprint', 'message' => 'The recorded fingerprint does not match the component list. The backup may have been modified after it was created.' ];
            }

            $verify = \VE\Modules\Recovery\Backup\PackageChecksums::verify_zip( $zip, $checksums );
            $checks = array_merge( $checks, $verify['checks'] );
            if ( empty( $verify['ok'] ) ) {
                $zip->close();
            $this->cleanup_temp( $inspect_temp );
                $bad = array_slice( array_merge( $verify['failures'], $verify['missing'] ), 0, 3 );
                // Surface the specific danger detail (size N vs M, or checksum) in the
                // headline. The generic "download did not finish" text hid whether a
                // component was truncated (size) or altered (hash), which is exactly what
                // is needed to tell a bad transfer apart from a build-side defect.
                $detail = '';
                foreach ( $verify['checks'] as $check ) {
                    if ( isset( $check['level'] ) && 'danger' === $check['level'] && ! empty( $check['message'] ) ) {
                        $detail = ' ' . (string) $check['message'];
                        break;
                    }
                }
                return $this->fail(
                    'This backup is incomplete or corrupted (' . implode( ', ', $bad ) . ').' . $detail . ' If the file was downloaded from another site, download it again and re-import it.',
                    $checks
                );
            }
            $checks[] = [ 'level' => 'ok', 'title' => 'Package integrity', 'message' => sprintf( 'All %d recorded components verified against the source checksums.', (int) $verify['verified'] ) ];
        }

        $has_files = false !== $zip->locateName( 'files.restorebase' ) || false !== $zip->locateName( 'files.zip' );
        $archive_label = false !== $zip->locateName( 'files.restorebase' ) ? 'files.restorebase' : 'files.zip';
        $checks[] = [
            'level'   => $has_files ? 'ok' : 'warn',
            'title'   => $archive_label,
            'message' => $has_files ? $archive_label . ' found.' : 'Files archive is missing. Restore can only use database and inventory context.',
        ];

        // Completeness gate: checksums only prove the bundle matches ITSELF, so a bundle
        // that was truncated at creation (an inventory re-read failure ended bundling at
        // the first ~20,000-file batch) sailed through as "Verified" and restored half a
        // site. Count the entries actually present and compare against the count the
        // manifest recorded when the backup was built.
        if ( false !== $zip->locateName( 'files.restorebase' ) ) {
            $recorded_files = (int) ( $manifest['contents']['files_archive']['summary']['included_files'] ?? 0 );
            if ( $recorded_files > 0 ) {
                $actual_files = $this->count_bundle_entries( $zip );
                if ( null !== $actual_files && $actual_files < $recorded_files ) {
                    $zip->close();
                    $this->cleanup_temp( $inspect_temp );
                    $checks[] = [ 'level' => 'danger', 'title' => 'Bundle completeness', 'message' => sprintf( 'files.restorebase holds %s of the %s files recorded at backup time.', number_format_i18n( $actual_files ), number_format_i18n( $recorded_files ) ) ];
                    return $this->fail(
                        sprintf( 'This backup is truncated: its file bundle holds %s of the %s files recorded when it was created. Re-create the backup on the source site (v1.3.262 or newer) and import that instead.', number_format_i18n( $actual_files ), number_format_i18n( $recorded_files ) ),
                        $checks
                    );
                }
                if ( null !== $actual_files ) {
                    $checks[] = [ 'level' => 'ok', 'title' => 'Bundle completeness', 'message' => sprintf( 'All %s recorded files are present in the bundle.', number_format_i18n( $actual_files ) ) ];
                }
            }
        }

        if ( $blocked ) {
            $zip->close();
            $this->cleanup_temp( $inspect_temp );
            return $this->fail( 'The backup is missing required RestoreBase files.', $checks );
        }

        $snapshot_key = $this->generate_key();
        $label = $label ? sanitize_text_field( $label ) : 'Imported backup ' . current_time( 'mysql' );
        $dir = LocalStorage::package_work_dir( $snapshot_key );
        LocalStorage::protect_dir( $dir );

        $target_filename = $this->imported_file_name( $name );
        $target = $dir . $target_filename;
        $moved = $is_upload
            ? @move_uploaded_file( $tmp, $target ) // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
            : @rename( $tmp, $target ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! $moved ) {
            $zip->close();
            $this->cleanup_temp( $inspect_temp );
            return $this->fail( 'RestoreBase could not move the uploaded package into storage.', $checks );
        }

        $manifest_path = LocalStorage::manifest_dir() . sanitize_file_name( $snapshot_key ) . '.json';
        LocalStorage::protect_dir( LocalStorage::manifest_dir() );
        file_put_contents( $manifest_path, wp_json_encode( $manifest, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES ) ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        $zip->close();
            $this->cleanup_temp( $inspect_temp );

        $hash = is_readable( $target ) ? (string) hash_file( 'sha256', $target ) : '';
        $manifest_hash = is_readable( $manifest_path ) ? (string) hash_file( 'sha256', $manifest_path ) : '';
        $source_snapshot_key = isset( $manifest['snapshot']['snapshot_key'] ) ? (string) $manifest['snapshot']['snapshot_key'] : '';
        $source_site = isset( $manifest['site_scan']['site']['url'] ) ? (string) $manifest['site_scan']['site']['url'] : '';

        $meta = [
            'package_path'        => $target,
            'encrypted'           => $encrypted,
            'package_filename'    => $target_filename,
            'package_hash'        => $hash,
            'package_size'        => file_exists( $target ) ? (int) filesize( $target ) : 0,
            'imported'            => true,
            'imported_at'         => current_time( 'mysql' ),
            'original_filename'   => $name,
            'source_snapshot_key' => $source_snapshot_key,
            'source_site_url'     => $source_site,
            'contents'            => isset( $manifest['contents'] ) && is_array( $manifest['contents'] ) ? $manifest['contents'] : [],
            'size_breakdown'      => isset( $manifest['contents']['size_breakdown'] ) && is_array( $manifest['contents']['size_breakdown'] ) ? $manifest['contents']['size_breakdown'] : ( isset( $manifest['contents']['files_archive']['summary'] ) ? [ 'files_archive_summary' => $manifest['contents']['files_archive']['summary'] ] : [] ),
            'migration_checks'    => $checks,
        ];

        global $wpdb;
        $wpdb->insert(
            Schema::table( 'snapshots' ),
            [
                'snapshot_key'  => $snapshot_key,
                'label'         => $label,
                'trigger_type'  => 'migration_import',
                'status'        => 'completed',
                'manifest_path' => $manifest_path,
                'manifest_hash' => $manifest_hash,
                'size_bytes'    => (int) $meta['package_size'],
                'meta_json'     => wp_json_encode( $meta ),
                'created_by'    => get_current_user_id(),
                'created_at'    => current_time( 'mysql' ),
                'updated_at'    => current_time( 'mysql' ),
            ],
            [ '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s' ]
        );

        $id = (int) $wpdb->insert_id;
        Logger::info( 'migration_package_imported', 'RestoreBase backup imported.', [
            'snapshot_key' => $snapshot_key,
            'source'       => $source_site,
            'size'         => (int) $meta['package_size'],
        ] );

        return [
            'ok'           => true,
            'message'      => 'Backup imported. Now validate it, preview restore risk, then run dry-run before restore.',
            'id'           => $id,
            'snapshot_key' => $snapshot_key,
            'label'        => $label,
            'source_url'   => $source_site,
            'size'         => (int) $meta['package_size'],
            'hash'         => $hash,
            'checks'       => $checks,
            'next_steps'   => [ 'Validate imported package', 'Preview restore risk', 'Run dry-run plan', 'Prepare guarded restore', 'Restore only after checks pass' ],
        ];
    }

    /**
     * Count the file entries actually present in the files.restorebase bundle by
     * streaming it once (zip streams cannot seek, so entry data is read and discarded).
     * Mirrors FileRestoreStager's reader: an entry is RBEN + 20-byte header + path +
     * data; the end marker's 'RBEN' prefix falls out as a short header read. Returns
     * null when the bundle cannot be inspected — callers must not fail on null.
     */
    private function count_bundle_entries( \ZipArchive $zip ): ?int {
        $stream = $zip->getStream( 'files.restorebase' );
        if ( ! is_resource( $stream ) ) {
            return null;
        }
        $read_exact = static function ( int $bytes ) use ( $stream ): string {
            $buffer = '';
            while ( strlen( $buffer ) < $bytes && ! feof( $stream ) ) {
                $chunk = fread( $stream, min( 4194304, $bytes - strlen( $buffer ) ) );
                if ( false === $chunk || '' === $chunk ) {
                    break;
                }
                $buffer .= $chunk;
            }
            return $buffer;
        };

        $magic = "RESTOREBASE-BUNDLE-1\n";
        if ( $read_exact( strlen( $magic ) ) !== $magic ) {
            fclose( $stream );
            return null;
        }

        $count = 0;
        while ( true ) {
            $sig = $read_exact( 4 );
            if ( strlen( $sig ) < 4 || 'RBEN' !== $sig ) {
                break;
            }
            $header = $read_exact( 20 );
            if ( strlen( $header ) < 20 ) {
                break; // end marker ('RBEN' + 'D') or a short tail.
            }
            $path_len = (int) unpack( 'V', substr( $header, 0, 4 ) )[1];
            $size = (int) unpack( 'P', substr( $header, 4, 8 ) )[1];
            if ( $path_len <= 0 || $path_len > 1048576 || $size < 0 ) {
                break;
            }
            if ( strlen( $read_exact( $path_len ) ) < $path_len ) {
                break;
            }
            $remaining = $size;
            while ( $remaining > 0 ) {
                $skip = $read_exact( (int) min( 4194304, $remaining ) );
                if ( '' === $skip ) {
                    break 2; // entry data cut short — do not count it.
                }
                $remaining -= strlen( $skip );
            }
            $count++;
        }
        fclose( $stream );
        return $count;
    }

    private function read_json_entry( \ZipArchive $zip, string $entry ): ?array {
        $contents = $zip->getFromName( $entry );
        if ( false === $contents ) {
            return null;
        }
        $decoded = json_decode( $contents, true );
        return is_array( $decoded ) ? $decoded : null;
    }

    /** Remove the temporary decrypted copy used only for inspection. */
    private function cleanup_temp( string $path ): void {
        if ( '' !== $path && file_exists( $path ) ) {
            @unlink( $path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
        }
    }

    private function fail( string $message, array $checks = [], bool $needs_passphrase = false ): array {
        Logger::warning( 'migration_package_import_failed', $message, [ 'checks' => $checks ] );
        $result = [ 'ok' => false, 'message' => $message, 'checks' => $checks ];
        if ( $needs_passphrase ) {
            $result['needs_passphrase'] = true;
        }
        return $result;
    }

    private function upload_error_message( int $error ): string {
        $messages = [
            UPLOAD_ERR_INI_SIZE   => 'The uploaded package is larger than the server upload limit.',
            UPLOAD_ERR_FORM_SIZE  => 'The uploaded package is larger than the form limit.',
            UPLOAD_ERR_PARTIAL    => 'The backup uploaded only partially.',
            UPLOAD_ERR_NO_FILE    => 'No backup was selected.',
            UPLOAD_ERR_NO_TMP_DIR => 'The server is missing a temporary upload folder.',
            UPLOAD_ERR_CANT_WRITE => 'The server could not write the uploaded package.',
            UPLOAD_ERR_EXTENSION  => 'A PHP extension blocked the upload.',
        ];
        return $messages[ $error ] ?? 'The backup upload failed.';
    }


    private function imported_file_name( string $original_name ): string {
        $host = wp_parse_url( home_url(), PHP_URL_HOST );
        $site = $host ? sanitize_title( (string) $host ) : sanitize_title( get_bloginfo( 'name' ) ?: 'wordpress-site' );
        $site = $site ?: 'wordpress-site';
        $stamp = gmdate( 'Ymd-His' );
        return sanitize_file_name( 'restorebase-imported-backup-' . $site . '-' . $stamp . '.zip' );
    }

    private function generate_key(): string {
        return 'rb-import-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 8, false, false );
    }
}
