(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarAppShell) return;

  function create(labels) {
    labels = labels || {};
    var panel = document.createElement('div');
    panel.className = 'baqa-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', labels.title || "Mimam's Bar");
    panel.innerHTML = '' +
      '<div class="baqa-head">' +
        '<span class="baqa-mark">M</span>' +
        '<div class="baqa-title">' + (labels.title || "Mimam's Bar") + '</div>' +
        '<button type="button" class="baqa-close" aria-label="Close">×</button>' +
      '</div>' +
      '<div class="baqa-update-slot"></div>' +
      '<div class="baqa-body">' +
        '<div class="baqa-target"><span>Target</span><strong class="baqa-target-name">No element selected</strong></div>' +
        '<div class="baqa-existing is-collapsed" aria-live="polite"><button type="button" class="baqa-existing-toggle"><span>Attributes</span><strong class="baqa-existing-count">0</strong><em>Show</em></button><div class="baqa-existing-meta">Click rows to edit · Shift-click to rename</div><div class="baqa-existing-list"><div class="baqa-existing-empty">No custom attributes on this element yet.</div></div></div>' +
        '<div class="baqa-mode-line"><span class="baqa-mode-label">Direct mode</span><em></em></div>' +
        '<input class="baqa-field" type="text" autocomplete="off" spellcheck="false" placeholder="' + (labels.placeholder || 'data-anim=&quot;fade-up&quot; data-delay=&quot;200&quot;') + '">' +
        '<div class="baqa-command-suggestions" hidden></div>' +
        '<div class="baqa-element-results" hidden></div>' +
        '<div class="baqa-helper"><span>Examples:</span> <code>data-anim="fade-up"</code> <code>.hero</code> <code>#hero</code> <code>-.hero</code> <code>delete data-anim</code> <code>all h2 =&gt; data-anim="text-lines"</code> <code>all li.card-item =&gt; data-anim="fade-up"</code> <code>.card,.panel =&gt; .is-animated</code></div><div class="baqa-tab-hint" aria-live="polite"></div>' +
        '<div class="baqa-error"></div>' +
      '</div>' +
      '<div class="baqa-actions">' +
        '<button type="button" class="baqa-btn baqa-cancel">Close</button>' +
        '<button type="button" class="baqa-btn baqa-btn-primary baqa-apply">Apply</button>' +
      '</div>';

    document.body.appendChild(panel);
    return panel;
  }

  function refs(panel) {
    return {
      input: panel.querySelector('.baqa-field'),
      error: panel.querySelector('.baqa-error'),
      tabHint: panel.querySelector('.baqa-tab-hint'),
      target: panel.querySelector('.baqa-target-name'),
      attrList: panel.querySelector('.baqa-existing-list'),
      existingBox: panel.querySelector('.baqa-existing'),
      attrCount: panel.querySelector('.baqa-existing-count'),
      attrToggleLabel: panel.querySelector('.baqa-existing-toggle em'),
      identityList: panel.querySelector('.baqa-identity-list'),
      elementResults: panel.querySelector('.baqa-element-results'),
      commandSuggestions: panel.querySelector('.baqa-command-suggestions'),
      elementModeLabel: panel.querySelector('.baqa-mode-label'),
      head: panel.querySelector('.baqa-head'),
      closeButton: panel.querySelector('.baqa-close'),
      cancelButton: panel.querySelector('.baqa-cancel'),
      applyButton: panel.querySelector('.baqa-apply'),
      attrsToggle: panel.querySelector('.baqa-existing-toggle')
    };
  }

  window.MimamsBarAppShell = {
    create: create,
    refs: refs
  };
})();
