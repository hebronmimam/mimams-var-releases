<?php
/**
 * Naming guard: themes vs colour palettes.
 *
 * Two systems in this plugin have confusably similar names:
 *
 *   Themes           options `ve_color_palettes`, `ve_active_color_palette`
 *                    route `/themes`   class ThemeManager
 *
 *   Colour palettes  tables `color_palettes`, `color_palette_members`
 *                    route `/color-palettes`   class ColorPaletteManager
 *
 * `ve_color_palettes` stores THEMES. The name is historical (v1.3.05) and was
 * never migrated. This has already caused one real defect: an approved design note
 * instructed implementers to mirror `ve_color_palettes` into Bricks' colour
 * palettes — i.e. themes into palettes, wrong data into the wrong home.
 *
 * Docblocks decay; a failing check does not. This asserts:
 *   1. Only the theme layer touches the theme options.
 *   2. New code does not use the deprecated PaletteManager.
 *
 * Run: php tests/check-naming.php
 */

declare( strict_types = 1 );

$root = dirname( __DIR__ );

/** Files allowed to reference the historically-named theme options. */
$option_owners = [
	'core/ThemeManager.php',       // the implementation
	'core/PaletteManager.php',     // deprecated alias
	'core/VariableUsageManager.php',
	'database/Schema.php',
	'uninstall.php',
	'tests/check-naming.php',
];

/** Files allowed to name the deprecated class. */
$alias_owners = [
	'core/PaletteManager.php',
	'core/ThemeManager.php',
	'variable-engine.php', // must require_once the file by name
	'tests/check-naming.php',
];

$failures = [];

$rii = new RecursiveIteratorIterator( new RecursiveDirectoryIterator( $root, RecursiveDirectoryIterator::SKIP_DOTS ) );
foreach ( $rii as $file ) {
	if ( $file->isDir() || 'php' !== $file->getExtension() ) {
		continue;
	}

	$rel = str_replace( '\\', '/', substr( $file->getPathname(), strlen( $root ) + 1 ) );

	// The bundled Recovery module is a separate concern.
	if ( 0 === strpos( $rel, 'modules/recovery/' ) || 0 === strpos( $rel, 'vendor/' ) ) {
		continue;
	}

	$src = (string) file_get_contents( $file->getPathname() );

	// Only look at real code — a mention inside a comment is documentation, which
	// is exactly what we want people writing.
	$code = '';
	foreach ( token_get_all( $src ) as $token ) {
		if ( is_array( $token ) ) {
			if ( in_array( $token[0], [ T_COMMENT, T_DOC_COMMENT ], true ) ) {
				continue;
			}
			$code .= $token[1];
		} else {
			$code .= $token;
		}
	}

	if ( ! in_array( $rel, $option_owners, true )
		&& ( false !== strpos( $code, 've_color_palettes' ) || false !== strpos( $code, 've_active_color_palette' ) ) ) {
		$failures[] = sprintf(
			"%s references the theme options directly.\n    They store THEMES, not colour palettes. Go through ThemeManager.\n    If you meant colour palettes, you want ColorPaletteManager and the color_palettes tables.",
			$rel
		);
	}

	// Match PaletteManager only when it is NOT part of ColorPaletteManager.
	if ( ! in_array( $rel, $alias_owners, true ) && preg_match( '/(?<!Color)\bPaletteManager\b/', $code ) ) {
		$failures[] = sprintf(
			"%s uses PaletteManager, which is deprecated.\n    It manages THEMES despite the name — use ThemeManager.\n    For colour palettes use ColorPaletteManager.",
			$rel
		);
	}
}

if ( $failures ) {
	echo "FAILED — themes/colour-palette naming:\n\n";
	foreach ( $failures as $f ) {
		echo '  - ' . $f . "\n\n";
	}
	exit( 1 );
}

echo "OK: theme options are reached only through the theme layer; no new use of the deprecated PaletteManager.\n";
exit( 0 );
