(function () {
  'use strict';

  if (window.MimamsBarFrameBridge || window.MimamsBarEverythingManager) return;

  function matches(value, query) {
    return !query || String(value || '').toLowerCase().indexOf(query) !== -1;
  }

  function commandItems(query) {
    return [
      { type: 'action', group: 'Commands', title: 'Direct mode', meta: 'Edit the selected element', icon: 'sliders-horizontal', mode: 'default', keywords: 'attributes classes id' },
      { type: 'action', group: 'Commands', title: 'Search page', meta: 'Find and select an element', icon: 'magnifying-glass', mode: 'elements', keywords: 'navigate select element' },
      { type: 'action', group: 'Commands', title: 'Add element', meta: 'Search Bricks or use Emmet', icon: 'plus', mode: 'add-elements', keywords: 'insert bricks emmet' },
      { type: 'action', group: 'Commands', title: "Open Mimam's Var settings", meta: 'Settings', icon: 'gear-six', action: 'settings', keywords: 'preferences configure' },
      { type: 'action', group: 'Commands', title: "Open Mimam's Bar help", meta: 'Help', icon: 'question', action: 'help', keywords: 'shortcuts commands guide' }
    ].filter(function (item) {
      return matches([item.title, item.meta, item.keywords].join(' '), query);
    });
  }

  function getMatches(app) {
    var query = app && app.input ? String(app.input.value || '').trim().toLowerCase() : '';
    var results = commandItems(query);
    if (!query || !app || !app.adapter || !app.elementSearch) return results;

    if (!app.pageElementsCache) app.pageElementsCache = app.adapter.getAllElements();
    app.elementSearch.getPageMatches(app.adapter, query, 5, app.pageElementsCache).forEach(function (item) {
      results.push({
        type: 'page', group: 'On this page', title: app.adapter.getElementLabel(item.element),
        meta: [item.element.name || item.element.tag || item.element.type || '', item.element.id ? '#' + item.element.id : ''].filter(Boolean).join(' · '),
        icon: 'cursor-click', element: item.element
      });
    });
    app.elementSearch.getLibraryMatches(app.adapter, query, 5).forEach(function (item) {
      var config = item.config || {};
      results.push({
        type: 'add', group: 'Add elements', title: config.label || config.name || 'Element',
        meta: [config.name || '', config.emmet ? 'emmet' : 'element'].filter(Boolean).join(' · '),
        icon: 'plus', config: config
      });
    });
    return results;
  }

  function execute(app, item) {
    if (!app || !item) return;
    if (item.type === 'page' && item.element) return app.selectElementResult(item.element);
    if (item.type === 'add' && item.config) {
      app.enterAddElementMode();
      return app.requestAddElementResult(item.config);
    }
    if (item.mode === 'default') return app.enterDefaultMode();
    if (item.mode === 'elements') return app.enterElementMode();
    if (item.mode === 'add-elements') return app.enterAddElementMode();
    if (item.action === 'settings') return app.toggleSettingsPanel();
    if (item.action === 'help') return app.toggleHelpPanel();
  }

  function render(container, items, callbacks) {
    if (!container) return;
    callbacks = callbacks || {};
    container.innerHTML = '';
    if (!items || !items.length) {
      var empty = document.createElement('div');
      empty.className = 'baqa-element-empty';
      empty.textContent = 'No matching elements or commands found.';
      container.appendChild(empty);
      return;
    }
    var active = Math.max(0, Math.min(items.length - 1, Number(callbacks.activeIndex) || 0));
    var group = '';
    items.forEach(function (item, index) {
      if (item.group !== group) {
        var heading = document.createElement('div');
        heading.className = 'baqa-everything-group';
        heading.textContent = item.group;
        container.appendChild(heading);
        group = item.group;
      }
      var row = document.createElement('button');
      row.type = 'button';
      row.className = 'baqa-element-row' + (index === active ? ' is-active' : '');
      row.setAttribute('data-baqa-result-index', String(index));
      row.innerHTML = '<span class="baqa-element-main"><span class="baqa-element-icon" aria-hidden="true"><i class="ph-duotone ph-' + item.icon + '"></i></span><span class="baqa-element-title"></span></span><em class="baqa-element-meta"></em>';
      row.querySelector('.baqa-element-title').textContent = item.title || '';
      row.querySelector('.baqa-element-meta').textContent = item.meta || '';
      row.addEventListener('mouseenter', function () { if (callbacks.activate) callbacks.activate(index); });
      row.addEventListener('click', function () { if (callbacks.activate) callbacks.activate(index); if (callbacks.execute) callbacks.execute(item); });
      container.appendChild(row);
    });
  }

  window.MimamsBarEverythingManager = { getMatches: getMatches, execute: execute, render: render };
})();
