<?php

namespace VE\Modules\Recovery\Agency;

use VE\Modules\Recovery\Backup\SnapshotManager;
use VE\Modules\Recovery\Jobs\JobStore;
use VE\Modules\Recovery\Restore\RestoreVerifier;
use VE\Modules\Recovery\Security\SecurityAudit;
use VE\Modules\Recovery\WooCommerce\WooSafety;

defined( 'ABSPATH' ) || exit;

final class AgencyDashboard {
    public function report(): array {
        $status = ( new SnapshotManager() )->status();
        $jobs = ( new JobStore() )->all( 5 );
        $woo = ( new WooSafety() )->report();
        $verify = ( new RestoreVerifier() )->verify();
        $security = ( new SecurityAudit() )->report();

        $score = 20;
        if ( ! empty( $status['package_snapshots'] ) ) { $score += 20; }
        if ( ! empty( $status['total_snapshots'] ) ) { $score += 10; }
        if ( ! empty( $jobs ) ) { $score += 10; }
        $score += min( 20, (int) floor( ( (int) ( $verify['score'] ?? 0 ) ) * 0.2 ) );
        $score += min( 20, (int) floor( ( (int) ( $security['score'] ?? 0 ) ) * 0.2 ) );
        if ( ! empty( $woo['woocommerce_active'] ) ) { $score -= 5; }
        $score = max( 0, min( 100, $score ) );

        return [
            'ok' => true,
            'message' => 'Agency dashboard foundation report generated.',
            'health_score' => $score,
            'status' => $status,
            'recent_jobs' => $jobs,
            'verification_score' => (int) ( $verify['score'] ?? 0 ),
            'security_score' => (int) ( $security['score'] ?? 0 ),
            'woocommerce' => $woo,
            'client_report' => [
                'ready' => false,
                'summary' => 'Client report layout is ready conceptually; scheduled/offsite backups need to be connected before reporting is production-ready.',
            ],
            'white_label_ready' => false,
        ];
    }
}
