<?php

namespace VE\Modules\Recovery\WooCommerce;

defined( 'ABSPATH' ) || exit;

final class WooSafety {
    public function report(): array {
        $active = class_exists( '\WooCommerce' ) || function_exists( 'WC' );
        $tables = $this->detect_tables();

        return [
            'ok' => true,
            'woocommerce_active' => $active,
            'message' => $active ? 'WooCommerce detected. Full database overwrite should remain blocked until merge strategy exists.' : 'WooCommerce was not detected on this site.',
            'dynamic_tables_detected' => $tables,
            'safety_rules' => [
                'block_full_db_overwrite_on_stores' => true,
                'detect_new_orders_since_backup' => true,
                'detect_new_customers_since_backup' => true,
                'protect_subscriptions_and_payment_tokens' => true,
                'prefer_files_only_or_selected_tables' => true,
            ],
        ];
    }

    private function detect_tables(): array {
        global $wpdb;
        $patterns = [ 'wc_orders', 'woocommerce_order', 'woocommerce_sessions', 'actionscheduler' ];
        $found = [];
        foreach ( $patterns as $pattern ) {
            $like = '%' . $wpdb->esc_like( $pattern ) . '%';
            $rows = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );
            foreach ( $rows as $row ) {
                $found[] = (string) $row;
            }
        }
        return array_values( array_unique( $found ) );
    }
}
