<?php

namespace VE\Modules\Recovery\Security;

defined( 'ABSPATH' ) || exit;

final class Capability {
    public static function manage_capability(): string {
        return (string) apply_filters( 'restorebase_manage_capability', 'manage_options' );
    }

    /**
     * Capability required for destructive actions (restore, rollback, staging swap).
     * Defaults to the manage capability so existing admins are never locked out,
     * but can be tightened independently, e.g. to a dedicated 'restorebase_restore'
     * capability for agency setups.
     */
    public static function restore_capability(): string {
        return (string) apply_filters( 'restorebase_restore_capability', self::manage_capability() );
    }

    public static function can_manage(): bool {
        return current_user_can( self::manage_capability() );
    }

    public static function can_restore(): bool {
        return current_user_can( self::restore_capability() );
    }
}
