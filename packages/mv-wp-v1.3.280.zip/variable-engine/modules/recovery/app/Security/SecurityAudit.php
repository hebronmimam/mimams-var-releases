<?php

namespace VE\Modules\Recovery\Security;

use VE\Modules\Recovery\Backup\SnapshotManager;
use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class SecurityAudit {
    public function report(): array {
        $base = LocalStorage::base_dir();
        $packages = LocalStorage::packages_dir();
        $snapshots = ( new SnapshotManager() )->all( 5 );
        $checks = [];

        $checks[] = $this->check( Capability::can_manage(), 'Admin capability gate', 'RestoreBase UI and actions are limited to users who can manage options.' );
        $checks[] = $this->check( file_exists( $base . '.htaccess' ), 'Storage access guard', 'Storage root has an .htaccess deny rule when the server supports it.' );
        $checks[] = $this->check( file_exists( $base . 'index.php' ), 'Directory index guard', 'Storage root includes an index.php silence file.' );
        $checks[] = $this->check( is_dir( $packages ) && is_writable( $packages ), 'Package directory writable', 'RestoreBase can write package files to its protected uploads folder.' );
        $checks[] = $this->check( ! empty( $snapshots ), 'Backup history', empty( $snapshots ) ? 'No backup package or snapshot exists yet.' : 'At least one snapshot/package record exists.' );
        $checks[] = $this->check( class_exists( '\\ZipArchive' ), 'ZipArchive available', 'ZipArchive is required for full package, validation, and workspace handling.' );
        $checks[] = $this->check( function_exists( 'hash_file' ), 'Checksum support', 'hash_file is required for package integrity checks.' );
        $checks[] = $this->check( defined( 'DISALLOW_FILE_EDIT' ) && DISALLOW_FILE_EDIT, 'WP file editor disabled', 'Recommended for production. RestoreBase can still function without the WP file editor.' , 'warn' );

        $danger = 0;
        $warn = 0;
        foreach ( $checks as $check ) {
            if ( 'danger' === $check['level'] ) { $danger++; }
            if ( 'warn' === $check['level'] ) { $warn++; }
        }

        $score = max( 0, 100 - ( $danger * 30 ) - ( $warn * 8 ) );
        Logger::info( 'security_audit_created', 'RestoreBase security audit created.', [ 'score' => $score ] );

        return [
            'ok' => 0 === $danger,
            'message' => 'Security and hardening audit completed.',
            'score' => $score,
            'checks' => $checks,
            'production_note' => 'Guarded production restore is available behind typed confirmation, validation, safety package, and wp-config protection. Test before public release.',
            'guarded_actions' => [ 'production_restore', 'external_recovery_with_key', 'zip_extract_in_workspace', 'wp_config_overwrite_blocked' ],
        ];
    }

    private function check( bool $ok, string $title, string $message, string $soft_level = '' ): array {
        $level = $ok ? 'ok' : ( $soft_level ?: 'danger' );
        return [
            'ok' => $ok,
            'level' => $level,
            'title' => sanitize_text_field( $title ),
            'message' => sanitize_text_field( $message ),
        ];
    }
}
