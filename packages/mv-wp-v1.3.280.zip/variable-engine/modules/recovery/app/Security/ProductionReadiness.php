<?php

namespace VE\Modules\Recovery\Security;

use VE\Modules\Recovery\Agency\AgencyDashboard;
use VE\Modules\Recovery\Backup\SnapshotManager;
use VE\Modules\Recovery\Emergency\EmergencyRecovery;
use VE\Modules\Recovery\Restore\RestoreVerifier;
use VE\Modules\Recovery\Schedule\ScheduleManager;
use VE\Modules\Recovery\Storage\RemoteStorageManager;
use VE\Modules\Recovery\WooCommerce\WooSafety;
use VE\Modules\Recovery\Workflow\MigrationPlanner;
use VE\Modules\Recovery\Workflow\StagingWorkflow;

defined( 'ABSPATH' ) || exit;

final class ProductionReadiness {
    public function report(): array {
        $snapshots = ( new SnapshotManager() )->all( 30 );
        $packages = array_values( array_filter( $snapshots, static function ( array $item ): bool {
            return in_array( (string) ( $item['trigger_type'] ?? '' ), [ 'backup_package', 'migration_bundle', 'migration_import' ], true ) && ( $item['status'] ?? '' ) === 'completed';
        } ) );

        $verification = ( new RestoreVerifier() )->verify();
        $security     = ( new SecurityAudit() )->report();
        $woo          = ( new WooSafety() )->report();
        $remote       = ( new RemoteStorageManager() )->plan();
        $schedule     = ( new ScheduleManager() )->plan();
        $staging      = ( new StagingWorkflow() )->plan();
        $migration    = ( new MigrationPlanner() )->plan();
        $emergency    = ( new EmergencyRecovery() )->plan();
        $agency       = ( new AgencyDashboard() )->report();

        $checks = [
            $this->check( ! empty( $packages ), 'Backup package base', 'At least one completed local package exists.' ),
            $this->check( (int) ( $security['score'] ?? 0 ) >= 70, 'Security baseline', 'Capability, nonce, path, download, and dangerous-action controls are present.' ),
            $this->check( (int) ( $verification['score'] ?? 0 ) >= 55, 'Verification baseline', 'Frontend/admin/media/theme/plugin checks are available.' ),
            $this->check( in_array( 'create_staging_clone', $staging['enabled_actions'] ?? [], true ), 'Staging workflow active', 'Staging clone action is available from the panel.' ),
            $this->check( in_array( 'create_migration_bundle', $migration['enabled_actions'] ?? [], true ), 'Backup restore workflow active', 'Backup import/restore action is available from the panel.' ),
            $this->check( ! empty( $remote['offsite_write_enabled'] ), 'Remote upload active', 'Local mirror upload is active and SFTP can run when configured.' ),
            $this->check( ! empty( $schedule['retention_preview']['pruning_enabled'] ), 'Scheduling and retention active', 'WP-Cron scheduling and retention rules are available.' ),
            $this->check( ! empty( $woo['checks'] ?? [] ) || ! empty( $woo['tables'] ?? [] ), 'WooCommerce safety layer', 'Store-sensitive tables and blockers are represented.' ),
            $this->check( ! empty( $emergency['available_outside_wp_admin'] ) || ! empty( $emergency['entry_url'] ), 'Emergency recovery active', 'Outside-wp-admin recovery entry is available once enabled.' ),
            $this->check( ! empty( $agency['score'] ?? null ) || ! empty( $agency['checks'] ?? [] ), 'Agency reporting foundation', 'Client-facing backup health reporting is available.' ),
        ];

        $passed = count( array_filter( $checks, static fn ( array $item ): bool => ( $item['level'] ?? '' ) === 'ok' ) );
        $score  = (int) round( ( $passed / max( 1, count( $checks ) ) ) * 100 );

        return [
            'ok'               => true,
            'message'          => 'Production readiness report generated. v1.0 RC features are active behind confirmations and admin/security gates.',
            'production_ready' => $score >= 80,
            'score'            => $score,
            'active_actions'   => [ 'guarded_production_restore', 'remote_upload', 'scheduling', 'emergency_loader', 'staging_clone', 'migration_bundle' ],
            'still_guarded'    => [ 'typed restore confirmation', 'safety package first', 'package validation', 'wp-config overwrite block', 'WooCommerce warnings' ],
            'checks'           => $checks,
            'next_gate'        => 'Run repeated disposable-site, staging-site, WooCommerce, and large-media restore tests before public production launch.',
        ];
    }

    private function check( bool $ok, string $title, string $message ): array {
        return [ 'level' => $ok ? 'ok' : 'warn', 'title' => $title, 'message' => $message ];
    }
}
