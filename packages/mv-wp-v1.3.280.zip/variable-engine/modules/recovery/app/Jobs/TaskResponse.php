<?php

namespace VE\Modules\Recovery\Jobs;

defined( 'ABSPATH' ) || exit;

final class TaskResponse {
    public static function ok( string $message = '', array $data = [] ): array {
        return [
            'ok'      => true,
            'message' => sanitize_text_field( $message ),
            'data'    => $data,
        ];
    }

    public static function fail( string $message = '', array $data = [] ): array {
        return [
            'ok'      => false,
            'message' => sanitize_text_field( $message ),
            'data'    => $data,
        ];
    }

    public static function defer( string $message = '', array $data = [] ): array {
        return [
            'ok'       => true,
            'deferred' => true,
            'message'  => sanitize_text_field( $message ),
            'data'     => $data,
        ];
    }
}
