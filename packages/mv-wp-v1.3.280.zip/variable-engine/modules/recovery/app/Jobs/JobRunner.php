<?php

namespace VE\Modules\Recovery\Jobs;

use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class JobRunner {
    private JobStore $store;

    public function __construct( ?JobStore $store = null ) {
        $this->store = $store ?: new JobStore();
    }

    /**
     * Serialize execution of a single job across concurrent requests.
     *
     * The browser re-issues the run request when a slow step (hashing/zipping a multi-GB
     * package) outlasts its timeout, so two runs of the same job can overlap and corrupt
     * append-style artifacts — e.g. the file bundle's end marker written twice, leaving the
     * package a few bytes larger than its recorded checksum and failing import. A prior
     * flock guard is silently a no-op on hosts whose storage ignores file locks, so this
     * uses a MySQL advisory lock (connection-scoped, auto-released if the worker dies),
     * which does not depend on the filesystem. A second concurrent request cannot acquire
     * the lock and reports the job as still running, so the client simply polls again.
     */
    public function run( string $job_key, array $tasks, array $context = [] ): array {
        global $wpdb;
        $lock_name = 'rb_job_' . md5( (string) ( defined( 'DB_NAME' ) ? DB_NAME : '' ) . '|' . $job_key );
        $acquired  = null;
        if ( isset( $wpdb ) && is_object( $wpdb ) ) {
            $acquired = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, %d)', $lock_name, 0 ) );
            if ( '0' === (string) $acquired ) {
                // Another request already holds this job. Report it as still running so the
                // poller waits instead of executing a second, racing copy.
                return [
                    'ok'       => true,
                    'deferred' => true,
                    'message'  => 'Job is already running.',
                    'context'  => $context,
                    'job'      => $this->store->get( $job_key ),
                ];
            }
        }
        try {
            return $this->run_locked( $job_key, $tasks, $context );
        } finally {
            if ( '1' === (string) $acquired && isset( $wpdb ) && is_object( $wpdb ) ) {
                $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) );
            }
        }
    }

    private function run_locked( string $job_key, array $tasks, array $context = [] ): array {
        $job = $this->store->get( $job_key );
        if ( ! $job ) {
            return [ 'ok' => false, 'message' => 'Job not found.' ];
        }

        $stored_context = isset( $job['result'] ) && is_array( $job['result'] ) ? $job['result'] : [];
        $context = array_merge( $stored_context, $context );

        $this->store->mark_running( $job_key );
        $context['job_key'] = $job_key;

        $task_state = isset( $job['task_state'] ) && is_array( $job['task_state'] ) ? $job['task_state'] : [];

        foreach ( array_values( $tasks ) as $index => $task ) {
            $current_job = $this->store->get( $job_key );
            if ( $current_job && 'cancelled' === (string) ( $current_job['status'] ?? '' ) ) {
                return [ 'ok' => false, 'message' => 'Job cancelled by user.', 'context' => $context, 'job' => $current_job ];
            }

            $task_id = isset( $task['id'] ) ? sanitize_key( (string) $task['id'] ) : 'task_' . $index;
            $label = isset( $task['label'] ) ? sanitize_text_field( (string) $task['label'] ) : $task_id;
            $callback = $task['callback'] ?? null;
            $latest_job = $this->store->get( $job_key );
            $latest_state = $latest_job && isset( $latest_job['task_state'] ) && is_array( $latest_job['task_state'] ) ? $latest_job['task_state'] : $task_state;
            $existing_task = isset( $latest_state[ $task_id ] ) && is_array( $latest_state[ $task_id ] ) ? $latest_state[ $task_id ] : [];

            if ( 'completed' === (string) ( $existing_task['status'] ?? '' ) && array_key_exists( $task_id, $context ) ) {
                continue;
            }

            if ( ! is_callable( $callback ) ) {
                $message = 'Task callback missing: ' . $label;
                $this->store->update_task( $job_key, $index, $task_id, 'failed', $message );
                $this->store->fail( $job_key, $message, $context );
                return [ 'ok' => false, 'message' => $message, 'context' => $context ];
            }

            $running_data = isset( $existing_task['data'] ) && is_array( $existing_task['data'] ) ? $existing_task['data'] : [];
            $this->store->update_task( $job_key, $index, $task_id, 'running', $label . ' running.', $running_data );
            $context['_current_task_index'] = $index;
            $context['_current_task_id'] = $task_id;
            $context['_total_tasks'] = count( $tasks );

            try {
                $response = call_user_func( $callback, $context );
            } catch ( \Throwable $throwable ) {
                $response = TaskResponse::fail( $throwable->getMessage(), [
                    'exception' => get_class( $throwable ),
                    'file'      => $throwable->getFile(),
                    'line'      => $throwable->getLine(),
                ] );
            }

            $response = is_array( $response ) ? $response : TaskResponse::ok( $label . ' completed.' );
            $current_job = $this->store->get( $job_key );
            if ( $current_job && 'cancelled' === (string) ( $current_job['status'] ?? '' ) ) {
                return [ 'ok' => false, 'message' => 'Job cancelled by user.', 'context' => $context, 'job' => $current_job ];
            }
            $message = isset( $response['message'] ) ? sanitize_text_field( (string) $response['message'] ) : '';
            $data = isset( $response['data'] ) && is_array( $response['data'] ) ? $response['data'] : [];

            if ( empty( $response['ok'] ) ) {
                $this->store->update_task( $job_key, $index, $task_id, 'failed', $message, $data );
                $context[ $task_id ] = $data;
                $this->store->fail( $job_key, $message ?: $label . ' failed.', $context );
                Logger::error( 'job_failed', 'RestoreBase job failed.', [ 'job_key' => $job_key, 'task' => $task_id, 'message' => $message ] );
                return [ 'ok' => false, 'message' => $message, 'context' => $context, 'job' => $this->store->get( $job_key ) ];
            }

            $context[ $task_id ] = $data;

            if ( ! empty( $response['deferred'] ) ) {
                $this->store->update_task( $job_key, $index, $task_id, 'running', $message ?: $label . ' running.', $data );
                $this->store->merge_result( $job_key, $context );
                return [
                    'ok'       => true,
                    'deferred' => true,
                    'message'  => $message ?: $label . ' still running.',
                    'context'  => $context,
                    'job'      => $this->store->get( $job_key ),
                ];
            }

            $this->store->update_task( $job_key, $index, $task_id, 'completed', $message ?: $label . ' completed.', $data );
            $this->store->merge_result( $job_key, $context );
        }

        $this->store->complete( $job_key, $context, 'Job completed.' );
        Logger::info( 'job_completed', 'RestoreBase job completed.', [ 'job_key' => $job_key ] );

        return [
            'ok'      => true,
            'message' => 'Job completed.',
            'context' => $context,
            'job'     => $this->store->get( $job_key ),
        ];
    }
}
