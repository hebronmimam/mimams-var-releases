<?php

namespace VE\Modules\Recovery\Jobs;

use VE\Modules\Recovery\Database\Schema;

defined( 'ABSPATH' ) || exit;

final class JobStore {
    public function create( string $type, string $label, array $tasks = [] ): array {
        global $wpdb;

        $job_key = $this->generate_key();
        $now = current_time( 'mysql' );
        $task_state = $this->initial_task_state( $tasks );

        $wpdb->insert(
            Schema::table( 'jobs' ),
            [
                'job_key'         => $job_key,
                'type'            => sanitize_key( $type ),
                'label'           => sanitize_text_field( $label ),
                'status'          => 'queued',
                'progress'        => 0,
                'current_task'    => '',
                'total_tasks'     => count( $tasks ),
                'task_index'      => 0,
                'task_state_json' => wp_json_encode( $task_state ),
                'result_json'     => wp_json_encode( [] ),
                'message'         => 'Queued.',
                'created_by'      => get_current_user_id(),
                'created_at'      => $now,
                'updated_at'      => $now,
                'started_at'      => null,
                'finished_at'     => null,
            ],
            [ '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%d', '%s', '%s', '%s', '%d', '%s', '%s', '%s', '%s' ]
        );

        return $this->get( $job_key ) ?: [ 'job_key' => $job_key ];
    }

    public function mark_running( string $job_key ): void {
        $job = $this->get( $job_key );
        if ( ! $job ) {
            return;
        }

        $data = [
            'status'  => 'running',
            'message' => 'Running.',
        ];

        if ( empty( $job['started_at'] ) || 'queued' === (string) ( $job['status'] ?? '' ) ) {
            $data['started_at'] = current_time( 'mysql' );
        }

        $this->update( $job_key, $data );
    }

    public function update_task( string $job_key, int $index, string $task_id, string $status, string $message = '', array $task_data = [] ): void {
        $job = $this->get( $job_key );
        if ( ! $job ) {
            return;
        }

        $task_state = isset( $job['task_state'] ) && is_array( $job['task_state'] ) ? $job['task_state'] : [];
        if ( isset( $task_state[ $task_id ] ) ) {
            $task_state[ $task_id ]['status'] = sanitize_key( $status );
            $task_state[ $task_id ]['message'] = sanitize_text_field( $message );
            $task_state[ $task_id ]['updated_at'] = current_time( 'mysql' );
            $task_state[ $task_id ]['data'] = $task_data;
        }

        $total = max( 1, (int) ( $job['total_tasks'] ?? 1 ) );
        $within = null;
        if ( isset( $task_data['_task_progress'] ) ) {
            $within = max( 0, min( 1, (float) $task_data['_task_progress'] ) );
        }
        $step_progress = 'completed' === $status ? 1 : ( 'running' === $status && null !== $within ? $within : 0 );
        $progress = (int) floor( min( 100, max( 0, ( ( $index + $step_progress ) / $total ) * 100 ) ) );

        $this->update( $job_key, [
            'progress'        => $progress,
            'current_task'    => $task_id,
            'task_index'      => $index,
            'task_state_json' => wp_json_encode( $task_state ),
            'message'         => $message,
        ] );
    }

    public function complete( string $job_key, array $result = [], string $message = 'Completed.' ): void {
        $this->update( $job_key, [
            'status'      => 'completed',
            'progress'    => 100,
            'message'     => $message,
            'result_json' => wp_json_encode( $result ),
            'finished_at' => current_time( 'mysql' ),
        ] );
    }


    public function merge_result( string $job_key, array $data ): array {
        $job = $this->get( $job_key );
        if ( ! $job ) {
            return [ 'ok' => false, 'message' => 'Job not found.' ];
        }

        $result = isset( $job['result'] ) && is_array( $job['result'] ) ? $job['result'] : [];
        $result = array_merge( $result, $data );
        $this->update( $job_key, [
            'result_json' => wp_json_encode( $result ),
        ] );

        return [ 'ok' => true, 'message' => 'Job result metadata updated.', 'result' => $result ];
    }

    public function fail( string $job_key, string $message = 'Failed.', array $result = [] ): void {
        $this->update( $job_key, [
            'status'      => 'failed',
            'message'     => $message,
            'result_json' => wp_json_encode( $result ),
            'finished_at' => current_time( 'mysql' ),
        ] );
    }

    public function cancel( string $job_key ): array {
        $job = $this->get( $job_key );
        if ( ! $job ) {
            return [ 'ok' => false, 'message' => 'Job not found.' ];
        }

        if ( in_array( $job['status'], [ 'completed', 'failed', 'cancelled' ], true ) ) {
            return [ 'ok' => false, 'message' => 'Job has already finished.', 'job' => $job ];
        }

        $this->update( $job_key, [
            'status'      => 'cancelled',
            'message'     => 'Cancelled by user.',
            'finished_at' => current_time( 'mysql' ),
        ] );

        return [ 'ok' => true, 'message' => 'Job cancelled.', 'job' => $this->get( $job_key ) ];
    }

    public function get( string $job_key ): ?array {
        global $wpdb;

        $table = Schema::table( 'jobs' );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE job_key = %s LIMIT 1", $job_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return is_array( $row ) ? $this->format_row( $row ) : null;
    }

    /**
     * Cheap status lookup.
     *
     * get() selects every column and json_decodes the task/result blobs, which is
     * far too expensive to call inside a per-file loop (cancel checks). This reads
     * one scalar column instead.
     */
    public function status( string $job_key ): string {
        global $wpdb;

        if ( '' === $job_key ) {
            return '';
        }
        $table = Schema::table( 'jobs' );
        return (string) $wpdb->get_var( $wpdb->prepare( "SELECT status FROM {$table} WHERE job_key = %s LIMIT 1", $job_key ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    public function all( int $limit = 20 ): array {
        global $wpdb;

        $this->prune_finished( 7 );

        $limit = max( 1, min( 100, absint( $limit ) ) );
        $table = Schema::table( 'jobs' );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! is_array( $rows ) ) {
            return [];
        }

        return array_map( [ $this, 'format_row' ], $rows );
    }



    public function latest_restore(): ?array {
        global $wpdb;

        $table = Schema::table( 'jobs' );
        $rows = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE type IN ('production_restore','staging_restore') ORDER BY id DESC LIMIT 1",
            ARRAY_A
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        if ( ! is_array( $rows ) || empty( $rows[0] ) || ! is_array( $rows[0] ) ) {
            return null;
        }

        return $this->format_row( $rows[0] );
    }

    public function latest_of_types( array $types, int $limit = 1 ): array {
        global $wpdb;

        $types = array_values( array_filter( array_map( 'sanitize_key', $types ) ) );
        if ( empty( $types ) ) {
            return [];
        }

        $limit = max( 1, min( 20, absint( $limit ) ) );
        $placeholders = implode( ',', array_fill( 0, count( $types ), '%s' ) );
        $table = Schema::table( 'jobs' );
        $sql = $wpdb->prepare( "SELECT * FROM {$table} WHERE type IN ({$placeholders}) ORDER BY id DESC LIMIT %d", array_merge( $types, [ $limit ] ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $rows = $wpdb->get_results( $sql, ARRAY_A );
        if ( ! is_array( $rows ) ) {
            return [];
        }

        return array_map( [ $this, 'format_row' ], $rows );
    }

    public function prune_finished( int $days = 7 ): void {
        global $wpdb;

        $days = max( 1, min( 365, absint( $days ) ) );
        $cutoff = date( 'Y-m-d H:i:s', current_time( 'timestamp' ) - ( $days * DAY_IN_SECONDS ) ); // phpcs:ignore WordPress.DateTime.RestrictedFunctions.date_date
        $table = Schema::table( 'jobs' );

        $wpdb->query(
            $wpdb->prepare(
                "DELETE FROM {$table} WHERE status IN ('completed','failed','cancelled') AND finished_at IS NOT NULL AND finished_at <> '' AND finished_at < %s",
                $cutoff
            )
        ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
    }

    public function active( int $limit = 5 ): array {
        global $wpdb;

        $limit = max( 1, min( 20, absint( $limit ) ) );
        $table = Schema::table( 'jobs' );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE status IN ('queued','running') ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! is_array( $rows ) ) {
            return [];
        }

        return array_map( [ $this, 'format_row' ], $rows );
    }

    private function update( string $job_key, array $data ): void {
        global $wpdb;

        $data['updated_at'] = current_time( 'mysql' );
        $format = [];
        foreach ( $data as $key => $value ) {
            $format[] = in_array( $key, [ 'progress', 'total_tasks', 'task_index', 'created_by' ], true ) ? '%d' : '%s';
        }

        $wpdb->update(
            Schema::table( 'jobs' ),
            $data,
            [ 'job_key' => $job_key ],
            $format,
            [ '%s' ]
        );
    }

    private function initial_task_state( array $tasks ): array {
        $state = [];
        foreach ( $tasks as $task ) {
            $id = isset( $task['id'] ) ? sanitize_key( (string) $task['id'] ) : '';
            if ( '' === $id ) {
                continue;
            }
            $state[ $id ] = [
                'id'         => $id,
                'label'      => isset( $task['label'] ) ? sanitize_text_field( (string) $task['label'] ) : $id,
                'status'     => 'pending',
                'message'    => '',
                'updated_at' => '',
                'data'       => [],
            ];
        }
        return $state;
    }

    private function format_row( array $row ): array {
        $task_state = json_decode( (string) ( $row['task_state_json'] ?? '' ), true );
        $result = json_decode( (string) ( $row['result_json'] ?? '' ), true );

        return [
            'id'           => (int) $row['id'],
            'job_key'      => (string) $row['job_key'],
            'type'         => (string) $row['type'],
            'label'        => (string) $row['label'],
            'status'       => (string) $row['status'],
            'progress'     => (int) $row['progress'],
            'current_task' => (string) $row['current_task'],
            'total_tasks'  => (int) $row['total_tasks'],
            'task_index'   => (int) $row['task_index'],
            'task_state'   => is_array( $task_state ) ? $task_state : [],
            'result'       => is_array( $result ) ? $result : [],
            'message'      => (string) $row['message'],
            'created_by'   => (int) $row['created_by'],
            'created_at'   => (string) $row['created_at'],
            'updated_at'   => (string) $row['updated_at'],
            'started_at'   => (string) $row['started_at'],
            'finished_at'  => (string) $row['finished_at'],
        ];
    }

    private function generate_key(): string {
        return 'job-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 8, false, false );
    }
}
