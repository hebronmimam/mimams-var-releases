<?php

namespace VE\Modules\Recovery\Utils;

use VE\Modules\Recovery\Database\Schema;

defined( 'ABSPATH' ) || exit;

final class Logger {
    public static function register_fatal_handler(): void {
        register_shutdown_function( function () {
            $error = error_get_last();
            if ( ! is_array( $error ) ) {
                return;
            }

            $fatal_types = [ E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR ];
            if ( ! in_array( (int) $error['type'], $fatal_types, true ) ) {
                return;
            }

            self::error( 'fatal_error', 'A fatal error occurred.', [
                'message' => $error['message'] ?? '',
                'file'    => $error['file'] ?? '',
                'line'    => $error['line'] ?? '',
            ] );
        } );
    }

    public static function info( string $event, string $message = '', array $context = [] ): void {
        self::write( 'info', $event, $message, $context );
    }

    public static function warning( string $event, string $message = '', array $context = [] ): void {
        self::write( 'warning', $event, $message, $context );
    }

    public static function error( string $event, string $message = '', array $context = [] ): void {
        self::write( 'error', $event, $message, $context );
    }

    public static function latest( int $limit = 20 ): array {
        global $wpdb;

        $table = Schema::table( 'logs' );
        $limit = max( 1, min( 100, absint( $limit ) ) );

        if ( self::table_missing( $table ) ) {
            return [];
        }

        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return is_array( $rows ) ? $rows : [];
    }

    private static function write( string $level, string $event, string $message = '', array $context = [] ): void {
        global $wpdb;

        $event = sanitize_key( $event );
        $level = sanitize_key( $level );
        $table = Schema::table( 'logs' );

        if ( self::table_missing( $table ) ) {
            error_log( '[RestoreBase][' . $level . '][' . $event . '] ' . $message ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
            return;
        }

        $wpdb->insert(
            $table,
            [
                'level'        => $level,
                'event'        => $event,
                'message'      => sanitize_textarea_field( $message ),
                'context_json' => wp_json_encode( $context ),
                'created_at'   => current_time( 'mysql' ),
            ],
            [ '%s', '%s', '%s', '%s', '%s' ]
        );
    }

    private static function table_missing( string $table ): bool {
        global $wpdb;
        $found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
        return $found !== $table;
    }
}
