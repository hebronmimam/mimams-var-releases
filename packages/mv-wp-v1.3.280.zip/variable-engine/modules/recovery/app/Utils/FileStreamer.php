<?php

namespace VE\Modules\Recovery\Utils;

// phpcs:disable WordPress.WP.AlternativeFunctions

defined( 'ABSPATH' ) || exit;

/**
 * Streams large package files to the browser.
 *
 * readfile() writes into whatever output buffers WordPress (or another plugin)
 * has open, so PHP ends up holding the entire package in memory. On a multi-GB
 * backup that blows memory_limit and the process is killed mid-transfer — the
 * browser reports a "cancelled" download at a consistent percentage, and the
 * half-written file looks like a valid backup until a restore fails.
 *
 * This streams in chunks with every buffer dropped, and supports HTTP Range so a
 * dropped download can resume instead of starting over.
 */
final class FileStreamer {
    private const CHUNK = 8388608; // 8 MiB — fewer write syscalls per package, still flat memory

    /**
     * Delegate the transfer to the web server when explicitly configured.
     * Returns true when the offload header was sent and PHP should stop.
     */
    private static function offload( string $path, string $download_name, string $content_type ): bool {
        $mode = (string) apply_filters( 'restorebase_download_offload', '' );
        if ( '' === $mode ) {
            return false;
        }

        while ( ob_get_level() > 0 ) {
            @ob_end_clean(); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        }
        nocache_headers();
        header( 'Content-Type: ' . $content_type );
        header( 'Content-Disposition: attachment; filename="' . $download_name . '"; filename*=UTF-8\'\'' . rawurlencode( $download_name ) );

        if ( 'xsendfile' === $mode ) {
            header( 'X-Sendfile: ' . $path ); // Apache mod_xsendfile
            return true;
        }
        if ( 0 === strpos( $mode, 'litespeed:' ) ) {
            // LiteSpeed (Hostinger et al) uses an internal redirect to a URI it can
            // serve itself. The target must be reachable by the server internally, so
            // the storage .htaccess has to permit it.
            $prefix = rtrim( substr( $mode, strlen( 'litespeed:' ) ), '/' );
            header( 'X-LiteSpeed-Location: ' . $prefix . '/' . rawurlencode( basename( $path ) ) );
            return true;
        }
        if ( 0 === strpos( $mode, 'x-accel:' ) ) {
            $prefix = rtrim( substr( $mode, strlen( 'x-accel:' ) ), '/' );
            header( 'X-Accel-Redirect: ' . $prefix . '/' . rawurlencode( basename( $path ) ) ); // nginx
            return true;
        }

        return false;
    }

    public static function stream( string $path, string $download_name, string $content_type = 'application/zip' ): void {
        if ( '' === $path || ! is_readable( $path ) ) {
            status_header( 404 );
            exit;
        }

        $size = (int) filesize( $path );

        // Optional: hand the transfer to the web server so no PHP process is involved.
        // This removes PHP/FastCGI request-duration limits (the usual reason a long
        // download is cut mid-transfer) and serves at native speed.
        //
        // Off by default: mod_xsendfile needs an XSendFilePath covering the storage dir,
        // and nginx needs an `internal` location, so enabling it blindly breaks downloads.
        //   add_filter( 'restorebase_download_offload', function () { return 'xsendfile'; } );
        //   add_filter( 'restorebase_download_offload', function () { return 'x-accel:/rb-internal/'; } );
        if ( self::offload( $path, $download_name, $content_type ) ) {
            exit;
        }

        // Drop every output buffer and any transparent compression, otherwise the
        // file is buffered in memory and Content-Length will not match the body.
        while ( ob_get_level() > 0 ) {
            @ob_end_clean(); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        }
        @ini_set( 'zlib.output_compression', 'Off' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        @ini_set( 'output_buffering', 'Off' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        @ini_set( 'implicit_flush', '1' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        }
        @ignore_user_abort( true ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

        $start  = 0;
        $end    = $size > 0 ? $size - 1 : 0;
        $partial = false;

        $range = isset( $_SERVER['HTTP_RANGE'] ) ? (string) wp_unslash( $_SERVER['HTTP_RANGE'] ) : '';
        if ( '' !== $range && preg_match( '/bytes=(\d*)-(\d*)/i', $range, $matches ) ) {
            $req_start = '' !== $matches[1] ? (int) $matches[1] : 0;
            $req_end   = '' !== $matches[2] ? (int) $matches[2] : $size - 1;
            if ( $req_start > $req_end || $req_start >= $size ) {
                status_header( 416 );
                header( 'Content-Range: bytes */' . $size );
                exit;
            }
            $start   = $req_start;
            $end     = min( $req_end, $size - 1 );
            $partial = true;
        }

        $length = ( $end - $start ) + 1;

        nocache_headers();
        if ( $partial ) {
            status_header( 206 );
            header( 'Content-Range: bytes ' . $start . '-' . $end . '/' . $size );
        }
        header( 'Content-Type: ' . $content_type );
        header( 'Content-Disposition: attachment; filename="' . $download_name . '"; filename*=UTF-8\'\'' . rawurlencode( $download_name ) );
        header( 'Content-Length: ' . $length );
        header( 'Accept-Ranges: bytes' );
        header( 'Content-Transfer-Encoding: binary' );

        // NOTE: deliberately NOT sending "X-Accel-Buffering: no".
        //
        // It was sent up to rc64 to force streaming, but it is the wrong tool here and
        // actively harmful for a large download: it stops nginx buffering the response,
        // so PHP has to stay alive for the whole client-speed transfer (~20 min for a
        // 268MB package on a slow line) with every write blocking on the client. The
        // FPM worker is pinned the entire time and request_terminate_timeout /
        // fastcgi_read_timeout eventually kills it — at a point that varies with
        // connection speed, which is why downloads cancelled at 86%, then 40%, then 74%.
        //
        // The buffering that actually had to be prevented is PHP's own output buffer
        // (the memory blowup), and ob_end_clean() above handles that. Letting the web
        // server buffer means PHP finishes quickly and the server feeds the client.
        // Opt back in only if a proxy genuinely needs unbuffered streaming.
        if ( apply_filters( 'restorebase_download_unbuffered', false ) ) {
            header( 'X-Accel-Buffering: no' );
        }

        $handle = @fopen( $path, 'rb' ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! is_resource( $handle ) ) {
            status_header( 500 );
            exit;
        }
        if ( $start > 0 ) {
            fseek( $handle, $start );
        }

        $remaining = $length;
        while ( $remaining > 0 && ! feof( $handle ) ) {
            if ( connection_aborted() ) {
                break;
            }
            $buffer = fread( $handle, (int) min( self::CHUNK, $remaining ) );
            if ( false === $buffer || '' === $buffer ) {
                break;
            }
            echo $buffer; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
            flush();
            $remaining -= strlen( $buffer );
        }

        fclose( $handle );
        exit;
    }
}
