<?php

namespace VE\Modules\Recovery\Emergency;

use VE\Modules\Recovery\Backup\SnapshotManager;
use VE\Modules\Recovery\Database\Schema;
use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Emergency recovery loader available outside wp-admin.
 *
 * Security model (hardened):
 * - The one-time token is NEVER placed in a URL query string. It is entered in a
 *   POST form and exchanged for a short-lived, httponly session cookie (PRG).
 * - Package list and downloads authenticate via that session cookie, so the token
 *   never appears in access logs, browser history, or Referer headers.
 * - Sessions expire after 30 minutes and are stored server-side as transients.
 */
final class EmergencyRecovery {
    private const SESS_COOKIE = 'restorebase_er_sess';
    private const SESS_TTL    = 1800; // 30 minutes

    public static function register_public_endpoint(): void {
        add_action( 'init', [ self::class, 'maybe_render_loader' ], 1 );
    }

    public function enable(): array {
        $token = wp_generate_password( 32, false, false );
        update_option( 'restorebase_emergency_token_hash', wp_hash_password( $token ), false );
        update_option( 'restorebase_emergency_enabled', true, false );
        // Entry URL carries NO token — the operator pastes the token into the form.
        $url = add_query_arg( [ 'restorebase_recovery' => '1' ], home_url( '/' ) );
        Logger::warning( 'emergency_recovery_enabled', 'RestoreBase emergency recovery endpoint enabled.' );
        return [
            'ok'       => true,
            'message'  => 'Emergency recovery enabled. Copy this token now; it is only shown once. Open the entry URL and paste the token into the form.',
            'url'      => $url,
            'token'    => $token,
            'enabled'  => true,
        ];
    }

    public function disable(): array {
        delete_option( 'restorebase_emergency_token_hash' );
        update_option( 'restorebase_emergency_enabled', false, false );
        Logger::info( 'emergency_recovery_disabled', 'RestoreBase emergency recovery endpoint disabled.' );
        return [ 'ok' => true, 'message' => 'Emergency recovery disabled.', 'enabled' => false ];
    }

    public function plan(): array {
        $token_exists = (bool) get_option( 'restorebase_emergency_token_hash', '' );
        $enabled = (bool) get_option( 'restorebase_emergency_enabled', false );
        $status = ( new SnapshotManager() )->status();
        $descriptor_path = LocalStorage::logs_dir() . 'emergency-descriptor.json';
        $descriptor = [
            'created_at' => current_time( 'mysql' ),
            'site_url' => site_url(),
            'home_url' => home_url(),
            'storage_path' => LocalStorage::base_dir(),
            'package_count' => (int) ( $status['package_snapshots'] ?? 0 ),
            'public_loader_enabled' => $enabled && $token_exists,
            'token_configured' => $token_exists,
            'entry' => home_url( '/?restorebase_recovery=1' ),
        ];
        LocalStorage::write_json_file( $descriptor_path, $descriptor, 'Emergency descriptor' );

        return [
            'ok' => true,
            'message' => $enabled ? 'Emergency recovery outside wp-admin is active.' : 'Emergency recovery is ready but disabled until you generate a recovery token.',
            'enabled' => $enabled && $token_exists,
            'token_configured' => $token_exists,
            'descriptor_path' => $descriptor_path,
            'package_count' => (int) ( $status['package_snapshots'] ?? 0 ),
            'entry_url' => home_url( '/?restorebase_recovery=1' ),
            'available_outside_wp_admin' => $enabled && $token_exists,
            'features' => [ 'package list', 'package download', 'safe status view' ],
            'locked_in_loader' => [ 'destructive restore from public loader requires a separate future confirmation screen' ],
        ];
    }

    public static function maybe_render_loader(): void {
        if ( empty( $_GET['restorebase_recovery'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            return;
        }

        $enabled = (bool) get_option( 'restorebase_emergency_enabled', false );
        $hash = (string) get_option( 'restorebase_emergency_token_hash', '' );
        if ( ! $enabled || '' === $hash ) {
            status_header( 403 );
            self::render_page( 'RestoreBase Emergency Recovery', '<p>Emergency recovery is disabled.</p>' );
            exit;
        }

        // 1) Token submitted via POST form -> verify, mint session cookie, redirect (PRG).
        if ( 'POST' === ( $_SERVER['REQUEST_METHOD'] ?? '' ) && isset( $_POST['restorebase_token'] ) ) {
            $token = sanitize_text_field( wp_unslash( $_POST['restorebase_token'] ) );
            if ( '' !== $token && wp_check_password( $token, $hash ) ) {
                self::start_session();
                Logger::warning( 'emergency_session_started', 'Emergency recovery session started from public loader.' );
                wp_safe_redirect( home_url( '/?restorebase_recovery=1' ) );
                exit;
            }
            status_header( 403 );
            self::render_page( 'RestoreBase Emergency Recovery', '<p>Invalid token.</p>' . self::form_html() );
            exit;
        }

        // 2) Authenticated session cookie -> allow list / download.
        if ( self::has_session() ) {
            if ( isset( $_GET['download'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
                self::download_emergency_package( sanitize_text_field( wp_unslash( $_GET['download'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
            }
            $html  = '<p class="rb-er-ok">Emergency recovery session active.</p>';
            $html .= '<p>This screen can list and download completed RestoreBase backup packages when wp-admin is unavailable.</p>';
            $html .= self::package_list_html();
            self::render_page( 'RestoreBase Emergency Recovery', $html );
            exit;
        }

        // 3) No session -> show the token entry form.
        self::render_page( 'RestoreBase Emergency Recovery', '<p>Enter your one-time recovery token to continue.</p>' . self::form_html() );
        exit;
    }

    private static function start_session(): void {
        $id = wp_generate_password( 40, false, false );
        set_transient( 'restorebase_er_sess_' . $id, 1, self::SESS_TTL );
        setcookie( self::SESS_COOKIE, $id, [
            'expires'  => time() + self::SESS_TTL,
            'path'     => '/',
            'secure'   => is_ssl(),
            'httponly' => true,
            'samesite' => 'Strict',
        ] );
        $_COOKIE[ self::SESS_COOKIE ] = $id;
    }

    private static function has_session(): bool {
        $id = isset( $_COOKIE[ self::SESS_COOKIE ] ) ? sanitize_text_field( wp_unslash( $_COOKIE[ self::SESS_COOKIE ] ) ) : '';
        if ( '' === $id || ! preg_match( '/^[A-Za-z0-9]{20,64}$/', $id ) ) {
            return false;
        }
        return (bool) get_transient( 'restorebase_er_sess_' . $id );
    }

    private static function form_html(): string {
        return '<form method="post" action="' . esc_url( home_url( '/?restorebase_recovery=1' ) ) . '" class="rb-er-form" autocomplete="off">'
            . '<input type="password" name="restorebase_token" placeholder="One-time recovery token" autocomplete="off" spellcheck="false" />'
            . '<button type="submit">Unlock recovery</button>'
            . '</form>';
    }

    private static function package_list_html(): string {
        global $wpdb;
        $rows = $wpdb->get_results( "SELECT snapshot_key,label,size_bytes,created_at FROM " . Schema::table( 'snapshots' ) . " WHERE trigger_type IN ('backup_package','migration_bundle','migration_import') AND status = 'completed' ORDER BY id DESC LIMIT 20", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        if ( empty( $rows ) ) {
            return '<p>No completed backup packages found.</p>';
        }
        $out = '<ul class="rb-er-list">';
        foreach ( $rows as $row ) {
            // Download link carries only the snapshot key; auth comes from the session cookie.
            $url = add_query_arg( [ 'restorebase_recovery' => '1', 'download' => rawurlencode( (string) $row['snapshot_key'] ) ], home_url( '/' ) );
            $out .= '<li><strong>' . esc_html( (string) $row['label'] ) . '</strong><br><small>' . esc_html( (string) $row['snapshot_key'] ) . ' · ' . esc_html( (string) $row['created_at'] ) . '</small><br><a href="' . esc_url( $url ) . '">Download package</a></li>';
        }
        $out .= '</ul>';
        return $out;
    }

    private static function download_emergency_package( string $snapshot_key ): void {
        if ( ! self::has_session() ) {
            status_header( 403 );
            self::render_page( 'RestoreBase Emergency Recovery', '<p>Session expired.</p>' . self::form_html() );
            exit;
        }
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . Schema::table( 'snapshots' ) . " WHERE snapshot_key = %s LIMIT 1", $snapshot_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        $meta = is_array( $row ) ? json_decode( (string) $row['meta_json'], true ) : [];
        $path = is_array( $meta ) && ! empty( $meta['package_path'] ) ? (string) $meta['package_path'] : '';
        if ( '' === $path || ! is_readable( $path ) ) {
            status_header( 404 );
            self::render_page( 'RestoreBase Emergency Recovery', '<p>Package file is missing.</p>' );
            exit;
        }
        Logger::warning( 'emergency_package_downloaded', 'Package downloaded from emergency loader.', [ 'snapshot_key' => $snapshot_key ] );
        // Same chunked + resumable streamer as the admin download; readfile() would
        // buffer the whole package into memory and truncate on large backups.
        \VE\Modules\Recovery\Utils\FileStreamer::stream( $path, basename( $path ) );
    }

    private static function render_page( string $title, string $body ): void {
        echo '<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex,nofollow"><title>' . esc_html( $title ) . '</title><style>body{margin:0;background:#111;color:#f1f1f1;font-family:system-ui,-apple-system,Segoe UI,sans-serif}.wrap{max-width:760px;margin:40px auto;padding:24px;background:#1b1b1b;border:1px solid #333;border-radius:16px}.brand{color:#baff00;text-transform:uppercase;font-weight:800;letter-spacing:.08em}.rb-er-list{list-style:none;padding:0;display:grid;gap:12px}.rb-er-list li{background:#242424;border:1px solid #3a3a3a;border-radius:12px;padding:14px}.rb-er-list a{display:inline-block;margin-top:10px;color:#111;background:#baff00;padding:8px 12px;border-radius:8px;text-decoration:none;font-weight:700}.rb-er-ok{color:#baff00}.rb-er-form{display:flex;gap:10px;margin-top:14px;flex-wrap:wrap}.rb-er-form input{flex:1;min-width:220px;padding:11px 13px;border-radius:9px;border:1px solid #3a3a3a;background:#141414;color:#f1f1f1;font-family:ui-monospace,Menlo,monospace}.rb-er-form button{padding:11px 18px;border:0;border-radius:9px;background:#baff00;color:#111;font-weight:700;cursor:pointer}</style></head><body><main class="wrap"><div class="brand">RestoreBase</div><h1>' . esc_html( $title ) . '</h1>' . wp_kses_post( $body ) . '</main></body></html>';
    }
}
