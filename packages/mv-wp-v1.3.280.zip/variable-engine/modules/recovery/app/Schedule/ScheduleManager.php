<?php

namespace VE\Modules\Recovery\Schedule;

use VE\Modules\Recovery\Backup\PackageBuilder;
use VE\Modules\Recovery\Backup\SnapshotManager;
use VE\Modules\Recovery\Storage\RemoteStorageManager;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class ScheduleManager {
    public static function register_hooks(): void {
        add_filter( 'cron_schedules', [ self::class, 'cron_schedules' ] );
        add_action( 'restorebase_daily_backup', [ self::class, 'run_daily' ] );
        add_action( 'restorebase_weekly_backup', [ self::class, 'run_weekly' ] );
        add_action( 'restorebase_monthly_backup', [ self::class, 'run_monthly' ] );
        add_action( 'upgrader_process_complete', [ self::class, 'run_pre_update_backup' ], 1, 2 );
    }

    public static function cron_schedules( array $schedules ): array {
        $schedules['weekly'] = [ 'interval' => WEEK_IN_SECONDS, 'display' => 'Once weekly' ];
        $schedules['monthly'] = [ 'interval' => 30 * DAY_IN_SECONDS, 'display' => 'Once monthly' ];
        return $schedules;
    }

    public function enable( array $settings = [] ): array {
        $policy = $this->policy( $settings );
        $policy['enabled'] = true;
        update_option( 'restorebase_schedule_settings', $policy, false );
        $this->sync_cron( $policy );
        return [ 'ok' => true, 'message' => 'Scheduling enabled.', 'policy' => $policy, 'cron' => $this->cron_status() ];
    }

    public function disable(): array {
        $policy = $this->policy();
        $policy['enabled'] = false;
        update_option( 'restorebase_schedule_settings', $policy, false );
        $this->clear_cron();
        return [ 'ok' => true, 'message' => 'Scheduling disabled.', 'policy' => $policy, 'cron' => $this->cron_status() ];
    }

    public function run_now( string $reason = 'manual' ): array {
        $result = ( new PackageBuilder() )->create( 'Scheduled backup package ' . current_time( 'mysql' ) . ' (' . sanitize_key( $reason ) . ')' );
        $remote = [];
        if ( ! empty( $result['snapshot_key'] ) ) {
            $remote = ( new RemoteStorageManager() )->upload_snapshot( (string) $result['snapshot_key'] );
        }
        Logger::info( 'scheduled_backup_run', 'RestoreBase scheduled backup run completed.', [ 'reason' => $reason, 'ok' => ! empty( $result['id'] ) ] );
        return [ 'ok' => ! empty( $result['id'] ), 'message' => 'Scheduled backup run completed.', 'backup' => $result, 'remote_upload' => $remote ];
    }

    public function plan(): array {
        $policy = $this->policy();
        return [
            'ok' => true,
            'message' => ! empty( $policy['enabled'] ) ? 'Scheduling is active.' : 'Scheduling is ready but currently disabled. Use Enable Schedule to turn it on.',
            'enabled' => ! empty( $policy['enabled'] ),
            'policy' => $policy,
            'current_history' => ( new SnapshotManager() )->status(),
            'retention_preview' => [
                'daily_keep' => absint( $policy['keep_daily'] ),
                'weekly_keep' => absint( $policy['keep_weekly'] ),
                'monthly_keep' => absint( $policy['keep_monthly'] ),
                'pruning_enabled' => true,
            ],
            'cron_hooks' => $this->cron_status(),
            'remote_handoff' => 'Scheduled packages attempt remote upload after successful local package creation.',
        ];
    }

    public static function run_daily(): void { ( new self() )->run_now( 'daily' ); }
    public static function run_weekly(): void { ( new self() )->run_now( 'weekly' ); }
    public static function run_monthly(): void { ( new self() )->run_now( 'monthly' ); }

    public static function run_pre_update_backup( $upgrader = null, $hook_extra = [] ): void {
        $policy = ( new self() )->policy();
        if ( empty( $policy['enabled'] ) || empty( $policy['pre_update'] ) ) {
            return;
        }
        ( new self() )->run_now( 'pre_update' );
    }

    private function policy( array $overrides = [] ): array {
        $saved = get_option( 'restorebase_schedule_settings', [] );
        $policy = array_merge( [
            'enabled' => false,
            'daily' => true,
            'weekly' => false,
            'monthly' => false,
            'pre_update' => true,
            'keep_daily' => 7,
            'keep_weekly' => 4,
            'keep_monthly' => 3,
            'notify_on_failure' => true,
            'remote_after_backup' => true,
        ], is_array( $saved ) ? $saved : [], $overrides );
        $policy['keep_daily'] = absint( $policy['keep_daily'] );
        $policy['keep_weekly'] = absint( $policy['keep_weekly'] );
        $policy['keep_monthly'] = absint( $policy['keep_monthly'] );
        return $policy;
    }

    private function sync_cron( array $policy ): void {
        $this->clear_cron();
        if ( empty( $policy['enabled'] ) ) {
            return;
        }
        if ( ! empty( $policy['daily'] ) && ! wp_next_scheduled( 'restorebase_daily_backup' ) ) {
            wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'restorebase_daily_backup' );
        }
        if ( ! empty( $policy['weekly'] ) && ! wp_next_scheduled( 'restorebase_weekly_backup' ) ) {
            wp_schedule_event( time() + 2 * HOUR_IN_SECONDS, 'weekly', 'restorebase_weekly_backup' );
        }
        if ( ! empty( $policy['monthly'] ) && ! wp_next_scheduled( 'restorebase_monthly_backup' ) ) {
            wp_schedule_event( time() + 3 * HOUR_IN_SECONDS, 'monthly', 'restorebase_monthly_backup' );
        }
    }

    private function clear_cron(): void {
        foreach ( [ 'restorebase_daily_backup', 'restorebase_weekly_backup', 'restorebase_monthly_backup' ] as $hook ) {
            $timestamp = wp_next_scheduled( $hook );
            while ( $timestamp ) {
                wp_unschedule_event( $timestamp, $hook );
                $timestamp = wp_next_scheduled( $hook );
            }
        }
    }

    private function cron_status(): array {
        $out = [];
        foreach ( [ 'restorebase_daily_backup', 'restorebase_weekly_backup', 'restorebase_monthly_backup' ] as $hook ) {
            $ts = wp_next_scheduled( $hook );
            $out[ $hook ] = $ts ? gmdate( 'c', (int) $ts ) : 'not scheduled';
        }
        return $out;
    }
}
