<?php

namespace VE\Modules\Recovery\Database;

defined( 'ABSPATH' ) || exit;

final class Schema {
    public static function table( string $name ): string {
        global $wpdb;
        return $wpdb->prefix . 'rb_' . sanitize_key( $name );
    }

    public static function get_sql(): string {
        global $wpdb;

        $charset = $wpdb->get_charset_collate();
        $snapshots = self::table( 'snapshots' );
        $logs = self::table( 'logs' );
        $storage = self::table( 'storage_locations' );
        $jobs = self::table( 'jobs' );

        return "
CREATE TABLE {$snapshots} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    snapshot_key VARCHAR(80) NOT NULL,
    label VARCHAR(255) NOT NULL DEFAULT '',
    trigger_type VARCHAR(40) NOT NULL DEFAULT 'manual',
    status VARCHAR(40) NOT NULL DEFAULT 'pending',
    manifest_path TEXT NULL,
    manifest_hash VARCHAR(128) NOT NULL DEFAULT '',
    size_bytes BIGINT UNSIGNED NOT NULL DEFAULT 0,
    meta_json LONGTEXT NULL,
    created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY  (id),
    UNIQUE KEY snapshot_key (snapshot_key),
    KEY status (status),
    KEY trigger_type (trigger_type),
    KEY created_at (created_at)
) {$charset};

CREATE TABLE {$logs} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    level VARCHAR(20) NOT NULL DEFAULT 'info',
    event VARCHAR(120) NOT NULL DEFAULT '',
    message TEXT NULL,
    context_json LONGTEXT NULL,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY  (id),
    KEY level (level),
    KEY event (event),
    KEY created_at (created_at)
) {$charset};


CREATE TABLE {$jobs} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    job_key VARCHAR(80) NOT NULL,
    type VARCHAR(80) NOT NULL DEFAULT '',
    label VARCHAR(255) NOT NULL DEFAULT '',
    status VARCHAR(40) NOT NULL DEFAULT 'queued',
    progress TINYINT UNSIGNED NOT NULL DEFAULT 0,
    current_task VARCHAR(120) NOT NULL DEFAULT '',
    total_tasks SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    task_index SMALLINT UNSIGNED NOT NULL DEFAULT 0,
    task_state_json LONGTEXT NULL,
    result_json LONGTEXT NULL,
    message TEXT NULL,
    created_by BIGINT UNSIGNED NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    started_at DATETIME NULL,
    finished_at DATETIME NULL,
    PRIMARY KEY  (id),
    UNIQUE KEY job_key (job_key),
    KEY type (type),
    KEY status (status),
    KEY created_at (created_at)
) {$charset};

CREATE TABLE {$storage} (
    id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    type VARCHAR(60) NOT NULL DEFAULT 'local',
    label VARCHAR(255) NOT NULL DEFAULT '',
    config_json LONGTEXT NULL,
    is_active TINYINT(1) NOT NULL DEFAULT 0,
    created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY  (id),
    KEY type (type),
    KEY is_active (is_active)
) {$charset};
        ";
    }
}
