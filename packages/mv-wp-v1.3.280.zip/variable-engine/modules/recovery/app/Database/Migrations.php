<?php

namespace VE\Modules\Recovery\Database;

defined( 'ABSPATH' ) || exit;

final class Migrations {
    public static function run(): void {
        global $wpdb;

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( Schema::get_sql() );

        add_option( 'restorebase_version', VE_RECOVERY_VERSION );
        add_option( 'restorebase_delete_on_uninstall', false );
        add_option( 'restorebase_settings', [
            'local_storage_enabled' => true,
            'delete_on_uninstall'   => false,
            'last_migration'        => current_time( 'mysql' ),
            'job_engine_enabled'   => true,
            'real_restore_locked'  => true,
        ] );

        // Seed a local storage location only once.
        $table = Schema::table( 'storage_locations' );
        $count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE type = 'local'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( 0 === $count ) {
            $wpdb->insert(
                $table,
                [
                    'type'        => 'local',
                    'label'       => 'Local RestoreBase Storage',
                    'config_json' => wp_json_encode( [ 'path' => 'uploads/restorebase' ] ),
                    'is_active'   => 1,
                    'created_at'  => current_time( 'mysql' ),
                    'updated_at'  => current_time( 'mysql' ),
                ],
                [ '%s', '%s', '%s', '%d', '%s', '%s' ]
            );
        }

        update_option( 'restorebase_version', VE_RECOVERY_VERSION );
    }
}
