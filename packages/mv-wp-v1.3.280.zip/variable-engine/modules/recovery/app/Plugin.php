<?php

namespace VE\Modules\Recovery;

use VE\Modules\Recovery\Admin\AdminPage;
use VE\Modules\Recovery\API\Routes;
use VE\Modules\Recovery\Database\Migrations;
use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Schedule\ScheduleManager;
use VE\Modules\Recovery\Emergency\EmergencyRecovery;
use VE\Modules\Recovery\Restore\PostRestoreHardener;

use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class Plugin {
    private static ?Plugin $instance = null;

    public static function instance(): Plugin {
        if ( null === self::$instance ) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function boot(): void {
        $stored_version = (string) get_option( 'restorebase_version', '' );
        if ( VE_RECOVERY_VERSION !== $stored_version ) {
            Migrations::run();
            LocalStorage::ensure_directories();
            Logger::info( 'migration_checked', 'RestoreBase migration check completed.', [ 'from' => $stored_version, 'to' => VE_RECOVERY_VERSION ] );
        }

        ScheduleManager::register_hooks();
        EmergencyRecovery::register_public_endpoint();

        add_action( 'rest_api_init', function () {
            ( new Routes() )->register();
        } );

        if ( is_admin() ) {
            add_action( 'admin_init', [ PostRestoreHardener::class, 'maybe_run_deferred_builder_recovery' ], 20 );
            ( new AdminPage() )->register();
        }
    }
}
