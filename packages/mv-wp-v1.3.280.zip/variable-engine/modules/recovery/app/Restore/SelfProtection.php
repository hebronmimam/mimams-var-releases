<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Database\Schema;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Keeps RestoreBase alive while RestoreBase is restoring the rest of the site.
 *
 * RestoreBase is the recovery controller, so its own tables, options, storage, and plugin
 * file must not be overwritten by the package that is being restored. This class provides
 * the shared rules used by backup, restore preview, database import, file copy, and plugin
 * state restoration.
 */
final class SelfProtection {
    public static function protected_options(): array {
        return [
            'restorebase_version',
            'restorebase_delete_on_uninstall',
            'restorebase_settings',
            'restorebase_remote_storage',
            'restorebase_schedule_settings',
            'restorebase_emergency_token_hash',
            'restorebase_emergency_enabled',
        ];
    }

    public static function protected_tables(): array {
        return [
            Schema::table( 'snapshots' ),
            Schema::table( 'logs' ),
            Schema::table( 'storage_locations' ),
            Schema::table( 'jobs' ),
        ];
    }

    public static function is_restorebase_table( string $table ): bool {
        global $wpdb;
        $table = sanitize_text_field( $table );
        $prefix = isset( $wpdb->prefix ) ? (string) $wpdb->prefix : '';
        if ( '' === $table || '' === $prefix ) {
            return false;
        }

        if ( in_array( $table, self::protected_tables(), true ) ) {
            return true;
        }

        // Forward-compatible: protect future RestoreBase tables that follow the rb_ prefix.
        return 0 === strpos( $table, $prefix . 'rb_' );
    }

    public static function is_restorebase_file( string $relative ): bool {
        $relative = trim( wp_normalize_path( $relative ), '/' );
        if ( '' === $relative ) {
            return false;
        }

        $protected = [
            'wp-content/plugins/restorebase/',
            'wp-content/mu-plugins/restorebase/',
            'wp-content/uploads/restorebase/',
        ];

        foreach ( $protected as $prefix ) {
            if ( 0 === strpos( $relative . '/', $prefix ) ) {
                return true;
            }
        }

        $basename = function_exists( 'plugin_basename' ) && defined( 'VE_RECOVERY_FILE' ) ? plugin_basename( VE_RECOVERY_FILE ) : 'restorebase/restorebase.php';
        return $relative === 'wp-content/plugins/' . $basename;
    }

    public static function plugin_basename(): string {
        return function_exists( 'plugin_basename' ) && defined( 'VE_RECOVERY_FILE' ) ? plugin_basename( VE_RECOVERY_FILE ) : 'restorebase/restorebase.php';
    }

    public static function is_restorebase_plugin_basename( string $plugin_file ): bool {
        $plugin_file = trim( wp_normalize_path( $plugin_file ), '/\\' );
        if ( '' === $plugin_file ) {
            return false;
        }

        $current = trim( wp_normalize_path( self::plugin_basename() ), '/\\' );
        $known = array_values( array_unique( array_filter( [
            $current,
            'restorebase/restorebase.php',
        ] ) ) );

        foreach ( $known as $basename ) {
            if ( $plugin_file === $basename ) {
                return true;
            }
        }

        $parts = explode( '/', $plugin_file );
        $main_file = end( $parts );
        $plugin_dir = count( $parts ) > 1 ? $parts[0] : '';

        return 'restorebase.php' === $main_file && 0 === strpos( $plugin_dir, 'restorebase' );
    }

    public function capture(): array {
        $options = [];
        foreach ( self::protected_options() as $option ) {
            $value = get_option( $option, null );
            if ( null !== $value ) {
                $options[ $option ] = $value;
            }
        }

        return [
            'ok'                => true,
            'message'           => 'RestoreBase self state captured.',
            'options'           => $options,
            'plugin_basename'   => self::plugin_basename(),
            'protected_tables'  => self::protected_tables(),
            'protected_options' => self::protected_options(),
        ];
    }

    public function reapply( array $state ): array {
        $options = isset( $state['options'] ) && is_array( $state['options'] ) ? $state['options'] : [];
        foreach ( $options as $name => $value ) {
            update_option( sanitize_key( (string) $name ), $value, false );
        }

        $this->keep_restorebase_active();

        Logger::info( 'self_protection_reapplied', 'RestoreBase self-protection data was reapplied after restore table swap.', [
            'options' => count( $options ),
            'plugin'  => self::plugin_basename(),
        ] );

        return [
            'ok'              => true,
            'message'         => 'RestoreBase memory and activation were preserved.',
            'options_restored'=> array_keys( $options ),
            'plugin_kept'     => self::plugin_basename(),
        ];
    }

    public function keep_restorebase_active(): array {
        $plugin = self::plugin_basename();
        $active = get_option( 'active_plugins', [] );
        $active = is_array( $active ) ? $active : [];

        if ( '' !== $plugin && ! in_array( $plugin, $active, true ) ) {
            $active[] = $plugin;
            update_option( 'active_plugins', array_values( array_unique( $active ) ) );
        }

        if ( is_multisite() ) {
            $network = get_site_option( 'active_sitewide_plugins', [] );
            if ( is_array( $network ) && isset( $network[ $plugin ] ) ) {
                $network[ $plugin ] = is_numeric( $network[ $plugin ] ) ? (int) $network[ $plugin ] : time();
                update_site_option( 'active_sitewide_plugins', $network );
            }
        }

        return [ 'ok' => true, 'plugin' => $plugin, 'active' => in_array( $plugin, get_option( 'active_plugins', [] ), true ) ];
    }
}
