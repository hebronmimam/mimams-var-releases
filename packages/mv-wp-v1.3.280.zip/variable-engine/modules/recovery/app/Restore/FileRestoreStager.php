<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Utils\Logger;

// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_copy

defined( 'ABSPATH' ) || exit;

final class FileRestoreStager {
    public function stage( string $files_zip_path, array $workspace ): array {
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        }

        if ( '' === $files_zip_path || ! is_readable( $files_zip_path ) ) {
            return [ 'ok' => false, 'message' => 'Files archive is unavailable.', 'groups' => [], 'files' => [] ];
        }

        if ( $this->is_restorebase_bundle( $files_zip_path ) ) {
            return $this->stage_bundle( $files_zip_path, $workspace );
        }

        if ( ! class_exists( '\ZipArchive' ) ) {
            return [ 'ok' => false, 'message' => 'ZipArchive is required to inspect ZIP backup files.', 'groups' => [], 'files' => [] ];
        }

        $zip = new \ZipArchive();
        if ( true !== $zip->open( $files_zip_path ) ) {
            return [ 'ok' => false, 'message' => 'files.zip could not be opened.', 'groups' => [], 'files' => [] ];
        }

        $files = [];
        $groups = [];
        $blocked = [];
        $restorable = 0;
        $total_size = 0;
        $max_preview = 1200;

        for ( $i = 0; $i < $zip->numFiles; $i++ ) {
            $name = (string) $zip->getNameIndex( $i );
            if ( '' === $name || '/' === substr( $name, -1 ) || $this->unsafe_path( $name ) || $this->is_protected_path( $name ) ) {
                if ( '' !== $name ) {
                    $blocked[] = $name;
                }
                continue;
            }

            $stat = $zip->statIndex( $i );
            $size = is_array( $stat ) ? (int) ( $stat['size'] ?? 0 ) : 0;
            $group = $this->group( $name );
            $groups[ $group ] = ( $groups[ $group ] ?? 0 ) + 1;
            $restorable++;
            $total_size += $size;

            if ( count( $files ) < $max_preview ) {
                $files[] = [ 'path' => $name, 'group' => $group, 'size' => $size ];
            }
        }

        $zip->close();

        Logger::info( 'files_staged', 'RestoreBase inspected files for direct restore extraction.', [ 'files' => $restorable, 'blocked' => count( $blocked ) ] );

        return [
            'ok'           => $restorable > 0,
            'message'      => $restorable > 0 ? 'Files are ready for direct restore extraction.' : 'No restorable files were found in files.zip.',
            'archive_path' => $files_zip_path,
            'path'         => isset( $workspace['files'] ) ? (string) $workspace['files'] : '',
            'files'        => $files,
            'groups'       => $groups,
            'blocked'      => array_slice( $blocked, 0, 250 ),
            'total_files'  => $restorable,
            'total_size'   => $total_size,
            'direct_copy'  => true,
            'fast_extract' => true,
            'truncated'    => $restorable > $max_preview,
        ];
    }

    public function apply_to_site( array $staging, ?callable $progress = null, ?callable $should_cancel = null ): array {
        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        }

        $archive = isset( $staging['archive_path'] ) ? (string) $staging['archive_path'] : '';
        if ( '' !== $archive && is_readable( $archive ) && ( ! empty( $staging['bundle_restore'] ) || $this->is_restorebase_bundle( $archive ) ) ) {
            return $this->apply_bundle_to_site( $archive, $progress, $should_cancel, (int) ( $staging['expected_files'] ?? 0 ) );
        }
        if ( '' !== $archive && is_readable( $archive ) && class_exists( '\ZipArchive' ) ) {
            return $this->apply_zip_to_site( $archive, $progress, $should_cancel );
        }

        $source = isset( $staging['path'] ) ? (string) $staging['path'] : '';
        if ( '' === $source || ! is_dir( $source ) ) {
            return [ 'ok' => false, 'message' => 'File staging area is unavailable.', 'copied' => 0, 'blocked' => [] ];
        }

        $copied = 0;
        $seen = 0;
        $blocked = [];
        $errors = [];
        $max = 100000;
        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator( $source, \FilesystemIterator::SKIP_DOTS ),
            \RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ( $iterator as $file ) {
            if ( is_callable( $should_cancel ) && $should_cancel() ) {
                return [ 'ok' => false, 'cancelled' => true, 'message' => 'File restore cancelled by user.', 'copied' => $copied, 'blocked' => $blocked, 'errors' => $errors ];
            }
            if ( $copied >= $max ) {
                break;
            }
            if ( ! $file instanceof \SplFileInfo || ! $file->isFile() ) {
                continue;
            }
            $relative = ltrim( str_replace( wp_normalize_path( trailingslashit( $source ) ), '', wp_normalize_path( $file->getPathname() ) ), '/' );
            if ( $this->unsafe_path( $relative ) || $this->is_protected_path( $relative ) ) {
                $blocked[] = $relative;
                continue;
            }
            $seen++;
            $destination = LocalStorage::absolute_from_relative( $relative );
            $dir = dirname( $destination );
            if ( ! is_dir( $dir ) ) {
                wp_mkdir_p( $dir );
            }
            if ( @copy( $file->getPathname(), $destination ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
                $copied++;
            } else {
                $errors[] = $relative;
            }
            if ( is_callable( $progress ) && ( 0 === $seen % 250 || $seen < 5 ) ) {
                $progress( 'Restoring files: ' . $copied . ' copied.', min( 0.98, $seen / max( 1, $seen + 250 ) ), [ 'copied' => $copied, 'seen' => $seen ] );
            }
        }

        return [
            'ok'      => empty( $errors ),
            'message' => empty( $errors ) ? 'Files restored to the site.' : 'Some files could not be restored.',
            'copied'  => $copied,
            'blocked' => $blocked,
            'errors'  => array_slice( $errors, 0, 20 ),
        ];
    }

    private function apply_zip_to_site( string $archive, ?callable $progress = null, ?callable $should_cancel = null ): array {
        $zip = new \ZipArchive();
        if ( true !== $zip->open( $archive ) ) {
            return [ 'ok' => false, 'message' => 'Files archive could not be opened for restore extraction.', 'copied' => 0, 'blocked' => [] ];
        }

        $entries = [];
        $blocked = [];
        $wp_content_entries = 0;
        for ( $i = 0; $i < $zip->numFiles; $i++ ) {
            $name = (string) $zip->getNameIndex( $i );
            if ( '' === $name || '/' === substr( $name, -1 ) || $this->unsafe_path( $name ) || $this->is_protected_path( $name ) ) {
                if ( '' !== $name ) {
                    $blocked[] = $name;
                }
                continue;
            }
            if ( 0 === strpos( trim( wp_normalize_path( $name ), '/' ), 'wp-content/' ) ) {
                $wp_content_entries++;
            }
            $entries[] = $name;
        }

        $total = max( 1, count( $entries ) );
        $target = trailingslashit( ABSPATH );

        if ( is_callable( $should_cancel ) && $should_cancel() ) {
            $zip->close();
            return [ 'ok' => false, 'cancelled' => true, 'message' => 'File restore cancelled by user.', 'copied' => 0, 'blocked' => array_slice( $blocked, 0, 250 ), 'errors' => [] ];
        }

        // Fastest path: let the server unzip wp-content in one operation when available.
        // This mirrors how mature migration plugins avoid slow PHP file-by-file copying.
        if ( $total <= 1000 && function_exists( 'apply_filters' ) && apply_filters( 'restorebase_enable_cli_unzip', false ) && $wp_content_entries > 0 && $wp_content_entries === count( $entries ) ) {
            if ( is_callable( $progress ) ) {
                $progress( 'Turbo restoring files with server unzip…', 0.05, [ 'total' => $total, 'method' => 'cli_unzip' ] );
            }
            $cli = $this->try_cli_unzip_wp_content( $archive, $target );
            if ( ! empty( $cli['ok'] ) ) {
                $zip->close();
                if ( is_callable( $progress ) ) {
                    $progress( 'Restoring files: ' . $total . ' of ' . $total . '.', 1, [ 'copied' => $total, 'total' => $total, 'method' => 'cli_unzip' ] );
                }
                return [
                    'ok'             => true,
                    'message'        => 'Files restored with server unzip.',
                    'copied'         => count( $entries ),
                    'total'          => $total,
                    'blocked'        => array_slice( $blocked, 0, 250 ),
                    'errors'         => [],
                    'direct_copy'    => true,
                    'fast_extract'   => true,
                    'turbo_extract'  => true,
                    'extract_method' => 'cli_unzip',
                ];
            }
        }

        // Fast ZipArchive path: one extraction call instead of dozens of small batches.
        if ( ! empty( $entries ) && $total <= 1000 ) {
            if ( is_callable( $progress ) ) {
                $progress( 'Restoring files from files.zip…', 0.08, [ 'copied' => 0, 'total' => $total, 'method' => 'ziparchive_one_pass' ] );
            }
            $one_pass = @$zip->extractTo( $target, $entries ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
            if ( true === $one_pass ) {
                $zip->close();
                if ( is_callable( $progress ) ) {
                    $progress( 'Restoring files: ' . $total . ' of ' . $total . '.', 1, [ 'copied' => $total, 'total' => $total, 'method' => 'ziparchive_one_pass' ] );
                }
                return [
                    'ok'             => true,
                    'message'        => 'Files restored directly from files.zip.',
                    'copied'         => count( $entries ),
                    'total'          => $total,
                    'blocked'        => array_slice( $blocked, 0, 250 ),
                    'errors'         => [],
                    'direct_copy'    => true,
                    'fast_extract'   => true,
                    'turbo_extract'  => true,
                    'extract_method' => 'ziparchive_one_pass',
                ];
            }
        }

        // Safe fallback: if the server refuses one-pass extraction, continue in batches.
        $copied = 0;
        $errors = [];
        $fallback_batches = 0;
        $batch_size = 3500;
        if ( function_exists( 'apply_filters' ) ) {
            $batch_size = absint( apply_filters( 'restorebase_restore_extract_batch_size', $batch_size ) );
        }
        $batch_size = max( 500, min( 8000, $batch_size ) );

        $batches = array_chunk( $entries, $batch_size );
        $batch_count = max( 1, count( $batches ) );
        $batch_index = 0;
        if ( is_callable( $progress ) ) {
            $progress( 'Preparing progressive file restore: 0 of ' . $total . '.', 0.01, [ 'copied' => 0, 'total' => $total, 'batch' => 0, 'batches' => $batch_count, 'batch_size' => $batch_size, 'method' => 'progressive_zip_batches' ] );
        }

        foreach ( $batches as $batch ) {
            $batch_index++;
            if ( is_callable( $should_cancel ) && $should_cancel() ) {
                $zip->close();
                return [ 'ok' => false, 'cancelled' => true, 'message' => 'File restore cancelled by user.', 'copied' => $copied, 'blocked' => array_slice( $blocked, 0, 250 ), 'errors' => $errors ];
            }

            $result = $this->extract_batch( $zip, $batch, $target );
            $copied += (int) $result['copied'];
            if ( ! empty( $result['fallback'] ) ) {
                $fallback_batches++;
            }
            if ( ! empty( $result['errors'] ) ) {
                $errors = array_merge( $errors, $result['errors'] );
            }

            if ( is_callable( $progress ) ) {
                $progress( 'Restoring files: ' . min( $copied, $total ) . ' of ' . $total . ' (batch ' . $batch_index . '/' . $batch_count . ').', min( 1, $copied / $total ), [ 'copied' => $copied, 'total' => $total, 'batch' => $batch_index, 'batches' => $batch_count, 'batch_size' => $batch_size, 'fallback_batches' => $fallback_batches, 'method' => 'progressive_zip_batches' ] );
            }
        }

        $zip->close();
        $ok = empty( $errors ) && $copied >= count( $entries );
        return [
            'ok'               => $ok,
            'message'          => $ok ? 'Files restored directly to the site.' : 'Some files could not be restored.',
            'copied'           => $copied,
            'total'            => $total,
            'blocked'          => array_slice( $blocked, 0, 250 ),
            'errors'           => array_slice( $errors, 0, 20 ),
            'direct_copy'      => true,
            'fast_extract'     => true,
            'turbo_extract'    => false,
            'extract_method'   => 'progressive_zip_batches',
            'fallback_batches' => $fallback_batches,
        ];
    }

    private function try_cli_unzip_wp_content( string $archive, string $target ): array {
        if ( ! $this->function_available( 'exec' ) || 0 === stripos( PHP_OS, 'WIN' ) ) {
            return [ 'ok' => false, 'message' => 'CLI unzip is unavailable.' ];
        }

        $which_output = [];
        $which_code = 1;
        @exec( 'command -v unzip 2>/dev/null', $which_output, $which_code ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec
        if ( 0 !== (int) $which_code || empty( $which_output[0] ) ) {
            return [ 'ok' => false, 'message' => 'unzip command was not found.' ];
        }

        $command = 'unzip -oq ' . escapeshellarg( $archive ) . ' ' . escapeshellarg( 'wp-content/*' ) . ' -d ' . escapeshellarg( $target ) . ' 2>&1';
        $output = [];
        $code = 1;
        @exec( $command, $output, $code ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.PHP.DiscouragedPHPFunctions.system_calls_exec

        return [
            'ok'      => 0 === (int) $code,
            'message' => 0 === (int) $code ? 'CLI unzip completed.' : 'CLI unzip failed.',
            'code'    => (int) $code,
            'output'  => array_slice( array_map( 'strval', $output ), 0, 8 ),
        ];
    }

    private function function_available( string $function ): bool {
        if ( ! function_exists( $function ) ) {
            return false;
        }
        $disabled = array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) );
        return ! in_array( $function, $disabled, true );
    }


    private function is_restorebase_bundle( string $path ): bool {
        if ( '' === $path || ! is_readable( $path ) ) {
            return false;
        }
        if ( 'restorebase' === strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) ) {
            return true;
        }
        $handle = @fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! is_resource( $handle ) ) {
            return false;
        }
        $magic = fread( $handle, strlen( "RESTOREBASE-BUNDLE-1\n" ) );
        fclose( $handle );
        return "RESTOREBASE-BUNDLE-1\n" === $magic;
    }

    private function stage_bundle( string $bundle_path, array $workspace ): array {
        $handle = @fopen( $bundle_path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! is_resource( $handle ) ) {
            return [ 'ok' => false, 'message' => 'RestoreBase file bundle could not be opened.', 'groups' => [], 'files' => [] ];
        }

        $magic = fread( $handle, strlen( "RESTOREBASE-BUNDLE-1\n" ) );
        if ( "RESTOREBASE-BUNDLE-1\n" !== $magic ) {
            fclose( $handle );
            return [ 'ok' => false, 'message' => 'RestoreBase file bundle header is invalid.', 'groups' => [], 'files' => [] ];
        }

        $files = [];
        $groups = [];
        $blocked = [];
        $restorable = 0;
        $total_size = 0;
        $max_preview = 1200;

        while ( ! feof( $handle ) ) {
            $sig = fread( $handle, 4 );
            if ( '' === $sig || false === $sig ) {
                break;
            }
            if ( 'RBEND' === $sig ) {
                break;
            }
            if ( 'RBEN' !== $sig ) {
                $blocked[] = 'bundle-read-stopped-invalid-entry';
                break;
            }

            $header = fread( $handle, 20 );
            if ( false === $header || strlen( $header ) < 20 ) {
                break;
            }
            $path_len = (int) unpack( 'V', substr( $header, 0, 4 ) )[1];
            $size = $this->unpack_uint64_le( substr( $header, 4, 8 ) );
            $mtime = $this->unpack_uint64_le( substr( $header, 12, 8 ) );
            if ( $path_len <= 0 || $path_len > 1048576 ) {
                $blocked[] = 'bundle-read-stopped-invalid-path-length';
                break;
            }
            $name = (string) fread( $handle, $path_len );
            if ( strlen( $name ) < $path_len ) {
                break;
            }

            if ( '' === $name || $this->unsafe_path( $name ) || $this->is_protected_path( $name ) ) {
                $blocked[] = $name;
            } else {
                $group = $this->group( $name );
                $groups[ $group ] = ( $groups[ $group ] ?? 0 ) + 1;
                $restorable++;
                $total_size += $size;
                if ( count( $files ) < $max_preview ) {
                    $files[] = [ 'path' => $name, 'group' => $group, 'size' => $size, 'modified' => $mtime ];
                }
            }

            if ( 0 !== @fseek( $handle, $size, SEEK_CUR ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
                break;
            }
        }

        fclose( $handle );

        Logger::info( 'files_staged_bundle', 'RestoreBase inspected raw bundle for direct restore extraction.', [ 'files' => $restorable, 'blocked' => count( $blocked ) ] );

        return [
            'ok'             => $restorable > 0,
            'message'        => $restorable > 0 ? 'Files are ready for raw bundle restore extraction.' : 'No restorable files were found in the RestoreBase bundle.',
            'archive_path'   => $bundle_path,
            'path'           => isset( $workspace['files'] ) ? (string) $workspace['files'] : '',
            'files'          => $files,
            'groups'         => $groups,
            'blocked'        => array_slice( $blocked, 0, 250 ),
            'total_files'    => $restorable,
            'total_size'     => $total_size,
            'direct_copy'    => true,
            'fast_extract'   => true,
            'bundle_restore' => true,
            'archive_format' => 'restorebase_bundle',
            'truncated'      => $restorable > $max_preview,
        ];
    }

    private function apply_bundle_to_site( string $bundle_path, ?callable $progress = null, ?callable $should_cancel = null, int $expected_files = 0 ): array {
        $handle = @fopen( $bundle_path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! is_resource( $handle ) ) {
            return [ 'ok' => false, 'message' => 'RestoreBase file bundle could not be opened for restore.', 'copied' => 0, 'blocked' => [] ];
        }

        $magic = fread( $handle, strlen( "RESTOREBASE-BUNDLE-1\n" ) );
        if ( "RESTOREBASE-BUNDLE-1\n" !== $magic ) {
            fclose( $handle );
            return [ 'ok' => false, 'message' => 'RestoreBase file bundle header is invalid.', 'copied' => 0, 'blocked' => [] ];
        }

        $copied = 0;
        $seen = 0;
        $blocked = [];
        $errors = [];
        $started = microtime( true );
        $last_progress_at = $started;

        while ( ! feof( $handle ) ) {
            if ( is_callable( $should_cancel ) && $should_cancel() ) {
                fclose( $handle );
                return [ 'ok' => false, 'cancelled' => true, 'message' => 'File restore cancelled by user.', 'copied' => $copied, 'blocked' => $blocked, 'errors' => $errors ];
            }

            $sig = fread( $handle, 4 );
            if ( '' === $sig || false === $sig ) {
                break;
            }
            if ( 'RBEND' === $sig ) {
                break;
            }
            if ( 'RBEN' !== $sig ) {
                $errors[] = 'bundle-read-stopped-invalid-entry';
                break;
            }

            $header = fread( $handle, 20 );
            if ( false === $header || strlen( $header ) < 20 ) {
                break;
            }
            $path_len = (int) unpack( 'V', substr( $header, 0, 4 ) )[1];
            $size = $this->unpack_uint64_le( substr( $header, 4, 8 ) );
            $mtime = $this->unpack_uint64_le( substr( $header, 12, 8 ) );
            $relative = (string) fread( $handle, $path_len );
            $seen++;

            if ( '' === $relative || strlen( $relative ) < $path_len || $this->unsafe_path( $relative ) || $this->is_protected_path( $relative ) ) {
                $blocked[] = $relative ?: 'invalid-bundle-path';
                @fseek( $handle, $size, SEEK_CUR ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
                continue;
            }

            $destination = LocalStorage::absolute_from_relative( $relative );
            $dir = dirname( $destination );
            if ( ! is_dir( $dir ) ) {
                wp_mkdir_p( $dir );
            }

            $out = @fopen( $destination, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged
            if ( ! is_resource( $out ) ) {
                $errors[] = $relative;
                @fseek( $handle, $size, SEEK_CUR ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
                continue;
            }

            $remaining = $size;
            $ok = true;
            while ( $remaining > 0 ) {
                $read = (int) min( 4194304, $remaining );
                $chunk = fread( $handle, $read );
                if ( false === $chunk || '' === $chunk ) {
                    $ok = false;
                    break;
                }
                $length = strlen( $chunk );
                $written = fwrite( $out, $chunk );
                if ( false === $written || $written < $length ) {
                    $ok = false;
                    break;
                }
                $remaining -= $length;
            }
            fclose( $out );

            if ( $ok ) {
                $copied++;
                if ( $mtime > 0 ) {
                    @touch( $destination, $mtime ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
                }
            } else {
                $errors[] = $relative;
                if ( $remaining > 0 ) {
                    @fseek( $handle, $remaining, SEEK_CUR ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
                }
            }

            if ( is_callable( $progress ) && ( 0 === $seen % 500 || microtime( true ) - $last_progress_at >= 0.75 || $seen < 5 ) ) {
                $progress( 'Restoring files from raw bundle: ' . number_format_i18n( $copied ) . ' copied.', min( 0.98, $seen / max( 1, $seen + 1000 ) ), [ 'copied' => $copied, 'seen' => $seen, 'method' => 'raw bundle' ] );
                $last_progress_at = microtime( true );
            }
        }

        fclose( $handle );

        // The reader treats early EOF as a clean end, so a short bundle used to restore
        // "green" while silently missing its tail files. When the caller knows how many
        // entries the manifest recorded, hold the extraction to that number.
        $complete = $expected_files <= 0 || $seen >= $expected_files;
        if ( ! $complete ) {
            $errors[] = sprintf( 'bundle-ended-early:%d-of-%d', $seen, $expected_files );
        }

        return [
            'ok'             => empty( $errors ) && $complete,
            'message'        => ! $complete
                ? sprintf( 'The file restore ended early: %s of %s recorded files were read from the bundle. The workspace copy of files.restorebase is incomplete — run Prepare workspace again before restoring.', number_format_i18n( $seen ), number_format_i18n( $expected_files ) )
                : ( empty( $errors ) ? 'Files restored from raw bundle.' : 'Some files could not be restored from the raw bundle.' ),
            'copied'         => $copied,
            'seen'           => $seen,
            'expected_files' => $expected_files,
            'blocked'        => array_slice( $blocked, 0, 250 ),
            'errors'         => array_slice( $errors, 0, 20 ),
            'direct_copy'    => true,
            'fast_extract'   => true,
            'bundle_restore' => true,
            'extract_method' => 'restorebase_bundle',
        ];
    }

    private function unpack_uint64_le( string $bytes ): int {
        $parts = unpack( 'Vlow/Vhigh', $bytes );
        if ( ! is_array( $parts ) ) {
            return 0;
        }
        return (int) $parts['low'] + ( (int) $parts['high'] * 4294967296 );
    }

    private function extract_batch( \ZipArchive $zip, array $batch, string $target ): array {
        if ( empty( $batch ) ) {
            return [ 'copied' => 0, 'errors' => [], 'fallback' => false ];
        }

        $ok = @$zip->extractTo( $target, $batch ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        if ( true === $ok ) {
            return [ 'copied' => count( $batch ), 'errors' => [], 'fallback' => false ];
        }

        return $this->manual_extract_batch( $zip, $batch );
    }

    private function manual_extract_batch( \ZipArchive $zip, array $batch ): array {
        $copied = 0;
        $errors = [];

        foreach ( $batch as $relative ) {
            $relative = (string) $relative;
            $destination = LocalStorage::absolute_from_relative( $relative );
            $dir = dirname( $destination );
            if ( ! is_dir( $dir ) ) {
                wp_mkdir_p( $dir );
            }

            $ok = false;
            $stream = $zip->getStream( $relative );
            if ( is_resource( $stream ) ) {
                $out = @fopen( $destination, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged
                if ( is_resource( $out ) ) {
                    while ( ! feof( $stream ) ) {
                        $chunk = fread( $stream, 1024 * 1024 );
                        if ( false === $chunk ) {
                            break;
                        }
                        fwrite( $out, $chunk );
                    }
                    fclose( $out );
                    $ok = true;
                }
                fclose( $stream );
            } else {
                $contents = $zip->getFromName( $relative );
                if ( false !== $contents ) {
                    $ok = false !== file_put_contents( $destination, $contents );
                }
            }

            if ( $ok ) {
                $copied++;
            } else {
                $errors[] = $relative;
            }
        }

        return [ 'copied' => $copied, 'errors' => $errors, 'fallback' => true ];
    }

    private function is_protected_path( string $path ): bool {
        return $this->is_config_path( $path ) || $this->is_wordpress_core_path( $path ) || SelfProtection::is_restorebase_file( $path );
    }

    private function is_wordpress_core_path( string $path ): bool {
        $path = strtolower( trim( wp_normalize_path( $path ), '/' ) );
        if ( 0 === strpos( $path, 'wp-admin/' ) || 0 === strpos( $path, 'wp-includes/' ) ) {
            return true;
        }

        // Core files only count at the WordPress ROOT. Matching on basename alone
        // treated EVERY index.php in the site as core and skipped it during restore —
        // including wp-content/themes/<theme>/index.php, which is a theme's main
        // template. The theme then restored without it, WordPress reported "the active
        // theme is broken. Reverting to the default theme", and every Bricks-dependent
        // plugin failed. The backup side (FileInventory) already scopes this to the
        // root correctly; only the restore side was over-matching.
        if ( false !== strpos( $path, '/' ) ) {
            return false;
        }

        $core_files = [ 'index.php', 'license.txt', 'readme.html', 'wp-activate.php', 'wp-blog-header.php', 'wp-comments-post.php', 'wp-cron.php', 'wp-links-opml.php', 'wp-load.php', 'wp-mail.php', 'wp-settings.php', 'wp-signup.php', 'wp-trackback.php', 'xmlrpc.php', 'wp-login.php' ];
        return in_array( $path, $core_files, true );
    }

    private function unsafe_path( string $path ): bool {
        $path = wp_normalize_path( $path );
        return '' === $path || false !== strpos( $path, '../' ) || 0 === strpos( $path, '/' ) || preg_match( '/^[A-Za-z]:/', $path );
    }

    private function is_config_path( string $path ): bool {
        $path = strtolower( trim( wp_normalize_path( $path ), '/' ) );
        $basename = basename( $path );
        $protected = [ 'wp-config.php', '.htaccess', 'web.config', '.user.ini', 'php.ini', 'php5.ini' ];
        return in_array( $basename, $protected, true ) || false !== strpos( $path, '/wp-config.php' );
    }

    private function group( string $path ): string {
        $path = trim( wp_normalize_path( $path ), '/' );
        if ( 0 === strpos( $path, 'wp-content/uploads/' ) ) {
            return 'uploads';
        }
        if ( 0 === strpos( $path, 'wp-content/plugins/' ) ) {
            return 'plugins';
        }
        if ( 0 === strpos( $path, 'wp-content/themes/' ) ) {
            return 'themes';
        }
        if ( 0 === strpos( $path, 'wp-content/mu-plugins/' ) ) {
            return 'mu-plugins';
        }
        if ( 0 === strpos( $path, 'wp-content/' ) ) {
            return 'wp-content';
        }
        if ( 0 === strpos( $path, 'wp-admin/' ) || 0 === strpos( $path, 'wp-includes/' ) || in_array( basename( $path ), [ 'wp-load.php', 'wp-settings.php', 'wp-login.php', 'index.php' ], true ) ) {
            return 'core';
        }
        return 'other';
    }
}
