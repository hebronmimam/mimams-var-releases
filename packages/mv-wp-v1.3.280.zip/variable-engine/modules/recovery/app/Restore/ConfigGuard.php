<?php

namespace VE\Modules\Recovery\Restore;

defined( 'ABSPATH' ) || exit;

final class ConfigGuard {
    public function plan(): array {
        $path = trailingslashit( ABSPATH ) . 'wp-config.php';
        $exists = is_readable( $path );
        $contents = $exists ? file_get_contents( $path ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents

        $constants = [];
        foreach ( [ 'DB_NAME', 'DB_USER', 'DB_PASSWORD', 'DB_HOST' ] as $constant ) {
            $constants[ $constant ] = is_string( $contents ) && false !== strpos( $contents, $constant );
        }

        global $wpdb;

        return [
            'ok'                 => $exists,
            'message'            => $exists ? 'wp-config.php guard plan created. The file was not modified.' : 'wp-config.php was not readable from the expected location.',
            'path'               => $path,
            'detected_constants' => $constants,
            'current_prefix'     => isset( $wpdb->prefix ) ? (string) $wpdb->prefix : '',
            'rules'              => [
                'never_overwrite_wp_config'       => true,
                'preserve_destination_credentials' => true,
                'only_prefix_and_url_plan_allowed' => true,
                'backup_copy_required_before_touch' => true,
            ],
        ];
    }
}
