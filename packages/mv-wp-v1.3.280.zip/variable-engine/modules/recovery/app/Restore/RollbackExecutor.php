<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Backup\SnapshotManager;
use VE\Modules\Recovery\Jobs\JobRunner;
use VE\Modules\Recovery\Jobs\JobStore;
use VE\Modules\Recovery\Jobs\TaskResponse;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class RollbackExecutor {
    private JobStore $jobs;

    public function __construct( ?JobStore $jobs = null ) {
        $this->jobs = $jobs ?: new JobStore();
    }

    public function dry_run( string $confirmation = '' ): array {
        $source = $this->latest_safety_package();
        $confirmed = 'ROLLBACK STAGING' === trim( sanitize_text_field( $confirmation ) );

        $checks = [];
        $checks[] = [ 'level' => $source ? 'ok' : 'danger', 'title' => 'Rollback source', 'message' => $source ? 'Latest pre-restore safety package found.' : 'No pre-restore safety package exists yet.' ];
        $checks[] = [ 'level' => $confirmed ? 'ok' : 'warn', 'title' => 'Typed confirmation', 'message' => $confirmed ? 'Rollback confirmation accepted.' : 'Type ROLLBACK STAGING before execution.' ];
        $checks[] = [ 'level' => 'info', 'title' => 'Scope', 'message' => 'Rollback execution uses the pre-restore package and remains staging/local only.' ];

        return [
            'ok' => (bool) $source,
            'message' => $source ? 'Rollback dry-run ready. Execution remains gated.' : 'Rollback dry-run blocked because no safety package exists.',
            'source' => $source,
            'confirmed' => $confirmed,
            'checks' => $checks,
            'execution_enabled' => false,
        ];
    }

    public function execute( string $confirmation = '' ): array {
        $confirmation = trim( sanitize_text_field( $confirmation ) );
        $source = $this->latest_safety_package();
        $tasks = [
            [
                'id' => 'rollback_confirmation',
                'label' => 'Rollback Confirmation',
                'callback' => function () use ( $confirmation ) {
                    return 'ROLLBACK STAGING' === $confirmation
                        ? TaskResponse::ok( 'Rollback typed confirmation accepted.' )
                        : TaskResponse::fail( 'Type ROLLBACK STAGING to unlock staging rollback.' );
                },
            ],
            [
                'id' => 'rollback_source',
                'label' => 'Rollback Source',
                'callback' => function () use ( $source ) {
                    return $source
                        ? TaskResponse::ok( 'Rollback source package found.', $source )
                        : TaskResponse::fail( 'No pre-restore safety package was found.' );
                },
            ],
            [
                'id' => 'rollback_execute',
                'label' => 'Staging Rollback Execute',
                'callback' => function ( array $context ) {
                    $source = isset( $context['rollback_source'] ) && is_array( $context['rollback_source'] ) ? $context['rollback_source'] : [];
                    $snapshot_key = (string) ( $source['snapshot_key'] ?? '' );
                    if ( '' === $snapshot_key ) {
                        return TaskResponse::fail( 'Rollback source snapshot key is missing.' );
                    }
                    $run = ( new StagingRestoreExecutor() )->execute( $snapshot_key, 'RESTORE STAGING' );
                    return ! empty( $run['ok'] )
                        ? TaskResponse::ok( 'Rollback staging execution completed. Verify immediately.', $run )
                        : TaskResponse::fail( (string) ( $run['message'] ?? 'Rollback execution failed.' ), $run );
                },
            ],
        ];

        $job = $this->jobs->create( 'rollback_staging', 'Staging rollback ' . current_time( 'mysql' ), $tasks );
        $run = ( new JobRunner( $this->jobs ) )->run( (string) $job['job_key'], $tasks, [] );
        Logger::warning( 'rollback_execution_attempted', 'RestoreBase rollback execution attempted.', [ 'ok' => ! empty( $run['ok'] ) ] );
        return [
            'ok' => ! empty( $run['ok'] ),
            'message' => (string) ( $run['message'] ?? ( ! empty( $run['ok'] ) ? 'Rollback completed.' : 'Rollback blocked.' ) ),
            'job' => $this->jobs->get( (string) $job['job_key'] ),
            'context' => $run['context'] ?? [],
        ];
    }

    private function latest_safety_package(): ?array {
        $snapshots = ( new SnapshotManager() )->all( 100 );
        foreach ( $snapshots as $item ) {
            $label = strtolower( (string) ( $item['label'] ?? '' ) );
            if ( 'backup_package' === ( $item['trigger_type'] ?? '' ) && false !== strpos( $label, 'pre-restore' ) ) {
                return $item;
            }
        }
        return null;
    }
}
