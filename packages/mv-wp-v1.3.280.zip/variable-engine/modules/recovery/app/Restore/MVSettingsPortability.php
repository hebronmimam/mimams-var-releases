<?php

namespace VE\Modules\Recovery\Restore;

use VE\Core\SettingsTransferManager;

defined( 'ABSPATH' ) || exit;

/**
 * Carries secret-safe MV settings independently of WordPress user IDs.
 */
final class MVSettingsPortability {
    private const GROUPS = [ 'mv_core', 'mv_modules', 'mv_bar', 'mv_studio' ];

    public function capture( int $source_user_id = 0 ): array {
        $source_user_id = $source_user_id > 0 ? $source_user_id : $this->source_user_id();
        $this->clear_settings_caches( $source_user_id );
        $bundle = ( new SettingsTransferManager() )->export_bundle( self::GROUPS, $source_user_id );

        return [
            'ok'             => true,
            'source_user_id' => $source_user_id,
            'groups'         => self::GROUPS,
            'bundle'         => $bundle,
        ];
    }

    public function apply_from_manifest( array $manifest, int $target_user_id = 0 ): array {
        $transfer = $manifest['restore_safety']['config_transfer']['mv_settings'] ?? [];
        $bundle = is_array( $transfer ) && isset( $transfer['bundle'] ) && is_array( $transfer['bundle'] )
            ? $transfer['bundle']
            : [];

        if ( [] === $bundle ) {
            return [
                'ok'      => true,
                'applied' => false,
                'legacy'  => true,
                'message' => 'This package predates portable MV settings; database-restored MV data was left unchanged.',
            ];
        }

        $groups = isset( $transfer['groups'] ) && is_array( $transfer['groups'] )
            ? array_values( array_intersect( self::GROUPS, $transfer['groups'] ) )
            : self::GROUPS;
        $target_user_id = $target_user_id > 0 ? $target_user_id : get_current_user_id();
        if ( $target_user_id <= 0 && array_intersect( $groups, [ 'mv_bar', 'mv_studio' ] ) ) {
            return [
                'ok'      => false,
                'applied' => false,
                'message' => 'MV settings could not be restored because the destination administrator was not resolved.',
            ];
        }

        $this->clear_settings_caches( $target_user_id );
        $manager = new SettingsTransferManager();
        $preview = $manager->preview_bundle( $bundle, $groups );
        if ( is_wp_error( $preview ) ) {
            return [ 'ok' => false, 'applied' => false, 'message' => $preview->get_error_message() ];
        }

        $result = $manager->apply_bundle( $bundle, $groups, (string) $preview['fingerprint'], $target_user_id );
        if ( is_wp_error( $result ) ) {
            return [ 'ok' => false, 'applied' => false, 'message' => $result->get_error_message() ];
        }

        $this->clear_settings_caches( $target_user_id );
        $restored_bundle = $manager->export_bundle( $groups, $target_user_id );
        $mismatched = [];
        foreach ( $groups as $group ) {
            $expected = $bundle['groups'][ $group ] ?? null;
            $actual = $restored_bundle['groups'][ $group ] ?? null;
            if ( ! $this->group_transferred( $expected, $actual ) ) {
                $mismatched[] = $group;
            }
        }
        if ( [] !== $mismatched ) {
            return [
                'ok'                => false,
                'applied'           => true,
                'verified'          => false,
                'target_user_id'    => $target_user_id,
                'mismatched_groups' => $mismatched,
                'message'           => 'MV settings did not verify after restore: ' . implode( ', ', $mismatched ) . '.',
            ];
        }

        return [
            'ok'             => true,
            'applied'        => true,
            'verified'       => true,
            'target_user_id' => $target_user_id,
            'groups'         => $groups,
            'result'         => $result,
            'message'        => 'MV core, module, Bar, and Studio settings were restored.',
        ];
    }

    public function destination_user_id_from_context( array $context ): int {
        $paths = [
            [ 'reapply_destination_access', 'current_user_id' ],
            [ 'swap_database_tables', 'immediate_destination_access', 'current_user_id' ],
        ];
        foreach ( $paths as $path ) {
            $value = $this->context_value( $context, $path );
            if ( (int) $value > 0 ) {
                return (int) $value;
            }
        }

        $preferred_login = (string) $this->context_value( $context, [ 'capture_destination_access', 'current_user_login' ] );
        $kept_paths = [
            [ 'reapply_destination_access', 'kept' ],
            [ 'swap_database_tables', 'immediate_destination_access', 'kept' ],
        ];
        foreach ( $kept_paths as $path ) {
            $kept = $this->context_value( $context, $path );
            if ( ! is_array( $kept ) ) {
                continue;
            }
            if ( '' !== $preferred_login ) {
                foreach ( $kept as $user ) {
                    if ( is_array( $user ) && $preferred_login === (string) ( $user['user_login'] ?? '' ) && absint( $user['user_id'] ?? 0 ) > 0 ) {
                        return absint( $user['user_id'] );
                    }
                }
            }
            foreach ( $kept as $user ) {
                if ( is_array( $user ) && absint( $user['user_id'] ?? 0 ) > 0 ) {
                    return absint( $user['user_id'] );
                }
            }
        }

        $current = get_current_user_id();
        return $current > 0 ? $current : $this->first_administrator_id();
    }

    /**
     * Did every setting the package carries reach the destination?
     *
     * This mirrors SettingsTransferManager::write_group, which merges the incoming payload
     * onto the destination's existing row rather than replacing it. Comparing the two
     * bundles outright therefore reported false failures twice over: array_merge keeps the
     * destination's key order while the package carries the source's, and the destination
     * legitimately keeps keys the source never set. Both read as a mismatch under a strict
     * !==, failing the step even though every value transferred - which is what stopped
     * mv_bar and mv_studio, whose user meta survives the database swap.
     *
     * So: each exported setting must be present with an equal value, destination-only
     * extras are allowed, and individual values still compare exactly (order-insensitively
     * for maps, but preserving list order for things like ve_fab_order).
     */
    private function group_transferred( $expected, $actual ): bool {
        if ( ! is_array( $expected ) ) {
            return $this->canonical( $expected ) == $this->canonical( $actual );
        }
        if ( ! is_array( $actual ) ) {
            return false;
        }
        // $section is the payload wrapper: settings, preferences, or options.
        foreach ( $expected as $section => $values ) {
            if ( ! array_key_exists( $section, $actual ) ) {
                return false;
            }
            if ( ! is_array( $values ) || ! is_array( $actual[ $section ] ) ) {
                if ( $this->canonical( $values ) != $this->canonical( $actual[ $section ] ) ) {
                    return false;
                }
                continue;
            }
            foreach ( $values as $key => $value ) {
                if ( ! array_key_exists( $key, $actual[ $section ] ) ) {
                    return false;
                }
                if ( $this->canonical( $value ) != $this->canonical( $actual[ $section ][ $key ] ) ) {
                    return false;
                }
            }
        }
        return true;
    }

    /** Recursively key-sort so two payloads differing only in ordering compare equal. */
    private function canonical( $value ) {
        if ( ! is_array( $value ) ) {
            return $value;
        }
        $sorted = [];
        foreach ( $value as $key => $item ) {
            $sorted[ $key ] = $this->canonical( $item );
        }
        ksort( $sorted );
        return $sorted;
    }

    private function source_user_id(): int {
        $current = get_current_user_id();
        if ( $current > 0 ) {
            return $current;
        }
        return $this->first_administrator_id();
    }

    private function context_value( array $context, array $path ) {
        $value = $context;
        foreach ( $path as $key ) {
            if ( ! is_array( $value ) || ! array_key_exists( $key, $value ) ) {
                return null;
            }
            $value = $value[ $key ];
        }
        return $value;
    }

    private function first_administrator_id(): int {
        if ( ! function_exists( 'get_users' ) ) {
            return 0;
        }

        $admins = get_users( [
            'role'    => 'administrator',
            'fields'  => 'ID',
            'number'  => 1,
            'orderby' => 'ID',
            'order'   => 'ASC',
        ] );
        return is_array( $admins ) && isset( $admins[0] ) ? absint( $admins[0] ) : 0;
    }

    private function clear_settings_caches( int $user_id ): void {
        if ( function_exists( 'wp_cache_delete' ) ) {
            wp_cache_delete( 've_settings', 'options' );
            wp_cache_delete( 'alloptions', 'options' );
            wp_cache_delete( 'notoptions', 'options' );
            if ( $user_id > 0 ) {
                wp_cache_delete( $user_id, 'user_meta' );
            }
        }
        if ( $user_id > 0 && function_exists( 'clean_user_cache' ) ) {
            clean_user_cache( $user_id );
        }
    }
}
