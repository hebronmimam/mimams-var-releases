<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Database\Schema;

defined( 'ABSPATH' ) || exit;

final class PackageLocator {
    public function locate( string $snapshot_key = '' ): array {
        $row = $snapshot_key ? $this->find_snapshot( $snapshot_key ) : $this->latest_package_snapshot();

        if ( ! is_array( $row ) ) {
            return [
                'ok'      => false,
                'message' => 'No RestoreBase local backup package was found.',
                'row'     => null,
                'meta'    => [],
                'path'    => '',
            ];
        }

        $meta = $this->decode_json( (string) ( $row['meta_json'] ?? '' ) );
        $path = isset( $meta['package_path'] ) ? (string) $meta['package_path'] : '';

        if ( '' === $path || ! is_readable( $path ) ) {
            return [
                'ok'      => false,
                'message' => 'The selected RestoreBase package file is missing or unreadable.',
                'row'     => $row,
                'meta'    => $meta,
                'path'    => $path,
            ];
        }

        return [
            'ok'      => true,
            'message' => 'RestoreBase package located.',
            'row'     => $row,
            'meta'    => $meta,
            'path'    => $path,
        ];
    }

    private function latest_package_snapshot(): ?array {
        global $wpdb;
        $table = Schema::table( 'snapshots' );
        $row = $wpdb->get_row( "SELECT * FROM {$table} WHERE trigger_type IN ('backup_package','migration_bundle','migration_import') ORDER BY id DESC LIMIT 1", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return is_array( $row ) ? $row : null;
    }

    private function find_snapshot( string $snapshot_key ): ?array {
        global $wpdb;
        $table = Schema::table( 'snapshots' );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE snapshot_key = %s LIMIT 1", $snapshot_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return is_array( $row ) ? $row : null;
    }

    private function decode_json( string $json ): array {
        $decoded = json_decode( $json, true );
        return is_array( $decoded ) ? $decoded : [];
    }
}
