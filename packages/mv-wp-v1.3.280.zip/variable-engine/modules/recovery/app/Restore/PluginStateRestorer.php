<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

/**
 * Restores the source site's plugin activation state after files and database are restored.
 *
 * WordPress stores active plugin state in the database, but during migration the destination
 * can still end up with a mismatched active_plugins option if the destination had a different
 * plugin set, the table swap changes prefixes, or restore steps finish in a different order.
 * This class makes the rule explicit: active plugins from the backup stay active; plugins not
 * active in the backup stay inactive, while missing plugin files are skipped safely.
 */
final class PluginStateRestorer {
    public function apply_from_context( array $context ): array {
        $prep = isset( $context['prepare_workspace'] ) && is_array( $context['prepare_workspace'] ) ? $context['prepare_workspace'] : [];
        return $this->apply_from_preparation( $prep );
    }

    public function apply_from_preparation( array $prep ): array {
        $manifest = $this->manifest_from_preparation( $prep );
        return $this->apply_from_manifest( $manifest );
    }

    public function apply_from_manifest( array $manifest ): array {
        if ( empty( $manifest ) ) {
            return [
                'ok'      => false,
                'message' => 'Plugin activation state could not be restored because the backup manifest was not available.',
                'active_plugins' => [],
                'skipped_missing' => [],
            ];
        }

        $scan = isset( $manifest['site_scan'] ) && is_array( $manifest['site_scan'] ) ? $manifest['site_scan'] : [];
        $plugins = isset( $scan['plugins'] ) && is_array( $scan['plugins'] ) ? $scan['plugins'] : [];
        $source_active = isset( $plugins['active'] ) && is_array( $plugins['active'] ) ? $plugins['active'] : [];

        $wanted = [];
        $controller_plugins_skipped = [];
        foreach ( $source_active as $plugin ) {
            $file = is_array( $plugin ) && isset( $plugin['file'] ) ? (string) $plugin['file'] : '';
            $file = $this->normalize_plugin_file( $file );
            if ( '' === $file ) {
                continue;
            }

            // Use the destination RestoreBase controller, not the source package copy.
            // The source RestoreBase files are excluded from backups by self-protection.
            if ( SelfProtection::is_restorebase_plugin_basename( $file ) ) {
                $controller_plugins_skipped[] = $file;
                continue;
            }

            $wanted[] = $file;
        }

        $wanted = array_values( array_unique( $wanted ) );
        $available = [];
        $missing = [];

        foreach ( $wanted as $file ) {
            if ( $this->plugin_file_exists( $file ) ) {
                $available[] = $file;
            } else {
                $missing[] = $file;
            }
        }

        // Restore source activation state, but never deactivate RestoreBase while it is running the restore.
        $restorebase_plugin = SelfProtection::plugin_basename();
        if ( '' !== $restorebase_plugin && $this->plugin_file_exists( $restorebase_plugin ) && ! in_array( $restorebase_plugin, $available, true ) ) {
            $available[] = $restorebase_plugin;
        }
        update_option( 'active_plugins', array_values( array_unique( $available ) ) );

        $network_result = $this->apply_network_active_plugins( $plugins );

        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
            wp_clean_plugins_cache( true );
        }

        Logger::info( 'plugin_activation_state_restored', 'RestoreBase restored plugin activation state from backup manifest.', [
            'active_count' => count( $available ),
            'missing_count' => count( $missing ),
        ] );

        $ok = empty( $missing );
        return [
            'ok'              => $ok,
            'message'         => $ok ? 'Plugin activation state restored from backup.' : 'Plugin activation state could not be fully restored because active plugin files are missing.',
            'strategy'        => 'source_active_plugins_are_restored_restorebase_is_kept_active',
            'active_plugins'  => $available,
            'active_count'    => count( $available ),
            'skipped_missing' => $missing,
            'missing_count'   => count( $missing ),
            'network_plugins' => $network_result,
            'controller_plugins_skipped' => $controller_plugins_skipped,
        ];
    }

    private function manifest_from_preparation( array $prep ): array {
        $extract = isset( $prep['package_extract'] ) && is_array( $prep['package_extract'] ) ? $prep['package_extract'] : [];
        $entries = isset( $extract['entries'] ) && is_array( $extract['entries'] ) ? $extract['entries'] : [];
        $manifest_path = isset( $entries['manifest.json']['path'] ) ? (string) $entries['manifest.json']['path'] : '';

        if ( '' === $manifest_path && isset( $prep['workspace']['extracted'] ) ) {
            $manifest_path = trailingslashit( (string) $prep['workspace']['extracted'] ) . 'manifest.json';
        }

        if ( '' === $manifest_path || ! is_readable( $manifest_path ) ) {
            return [];
        }

        $json = file_get_contents( $manifest_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        $decoded = json_decode( (string) $json, true );
        return is_array( $decoded ) ? $decoded : [];
    }

    private function apply_network_active_plugins( array $plugins ): array {
        if ( ! is_multisite() ) {
            return [ 'applied' => false, 'reason' => 'single_site' ];
        }

        $source_network_active = isset( $plugins['network_active'] ) && is_array( $plugins['network_active'] ) ? $plugins['network_active'] : [];
        if ( empty( $source_network_active ) ) {
            update_site_option( 'active_sitewide_plugins', [] );
            return [ 'applied' => true, 'active' => [], 'skipped_missing' => [] ];
        }

        $active = [];
        $missing = [];
        foreach ( $source_network_active as $file => $time ) {
            $file = $this->normalize_plugin_file( (string) $file );
            if ( '' === $file ) {
                continue;
            }
            if ( SelfProtection::is_restorebase_plugin_basename( $file ) ) {
                $controller = SelfProtection::plugin_basename();
                if ( '' !== $controller && $this->plugin_file_exists( $controller ) ) {
                    $active[ $controller ] = is_numeric( $time ) ? (int) $time : time();
                }
                continue;
            }
            if ( $this->plugin_file_exists( $file ) ) {
                $active[ $file ] = is_numeric( $time ) ? (int) $time : time();
            } else {
                $missing[] = $file;
            }
        }

        update_site_option( 'active_sitewide_plugins', $active );
        return [ 'applied' => true, 'active' => array_keys( $active ), 'skipped_missing' => $missing ];
    }

    private function normalize_plugin_file( string $file ): string {
        $file = trim( wp_normalize_path( $file ) );
        $file = ltrim( $file, '/\\' );
        if ( false !== strpos( $file, '..' ) ) {
            return '';
        }
        return sanitize_text_field( $file );
    }

    private function plugin_file_exists( string $file ): bool {
        if ( '' === $file ) {
            return false;
        }
        $path = trailingslashit( WP_PLUGIN_DIR ) . $file;
        return is_readable( $path );
    }
}
