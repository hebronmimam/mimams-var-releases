<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Storage\LocalStorage;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared

defined( 'ABSPATH' ) || exit;

final class SerializedRewritePlanner {
    public function plan( string $sql_path, array $manifest = [] ): array {
        $base = ( new URLRewritePlanner() )->plan( $sql_path, $manifest );
        $backup_url = isset( $base['backup_url'] ) ? (string) $base['backup_url'] : '';
        $backup_home = isset( $base['backup_home'] ) ? (string) $base['backup_home'] : $backup_url;
        $current_url = site_url();
        $current_home = home_url();
        $backup_uploads = isset( $manifest['site_scan']['uploads']['baseurl'] ) ? (string) $manifest['site_scan']['uploads']['baseurl'] : '';
        $uploads = wp_upload_dir( null, false );
        $current_uploads = isset( $uploads['baseurl'] ) ? (string) $uploads['baseurl'] : '';

        return [
            'ok'                => true,
            'message'           => 'Destination URL lock prepared. RestoreBase keeps the current site URL and rewrites supported backup URLs to the destination URL during restore.',
            'site_url'          => [ 'from' => $backup_url, 'to' => $current_url, 'needs_rewrite' => $backup_url && $backup_url !== $current_url ],
            'home_url'          => [ 'from' => $backup_home, 'to' => $current_home, 'needs_rewrite' => $backup_home && $backup_home !== $current_home ],
            'uploads_url'       => [ 'from' => $backup_uploads, 'to' => $current_uploads, 'needs_rewrite' => $backup_uploads && $backup_uploads !== $current_uploads ],
            'sql_mentions'      => $base['sql_mentions'] ?? [],
            'strategy'          => 'destination_url_lock_with_serialized_safe_rewrite',
            'automatic_apply'   => true,
            'preserve_current_site_url' => true,
            'allowed_tables'    => [ 'options', 'posts', 'postmeta', 'termmeta', 'usermeta' ],
            'blocked_tables'    => [ 'woocommerce_order', 'wc_orders', 'actionscheduler' ],
            'woocommerce_note'  => 'WooCommerce transactional tables require a dedicated merge strategy before production restore.',
        ];
    }

    public function apply_site_options( string $table_prefix ): array {
        global $wpdb;
        $options_table = $table_prefix . 'options';
        $updated = [];
        foreach ( [ 'siteurl' => site_url(), 'home' => home_url() ] as $option => $value ) {
            $result = $wpdb->update( $options_table, [ 'option_value' => $value ], [ 'option_name' => $option ], [ '%s' ], [ '%s' ] );
            $updated[ $option ] = false !== $result;
        }
        return [ 'ok' => ! in_array( false, $updated, true ), 'table' => $options_table, 'updated' => $updated, 'kept' => [ 'siteurl' => site_url(), 'home' => home_url() ] ];
    }

    public function apply_destination_url_lock( string $table_prefix, array $rewrite_plan = [] ): array {
        $options = $this->apply_site_options( $table_prefix );
        $replacements = $this->replacements_from_plan( $rewrite_plan );
        $content = empty( $replacements ) ? [ 'ok' => true, 'message' => 'No URL content rewrite was needed.', 'tables' => [], 'rows_checked' => 0, 'rows_updated' => 0 ] : $this->apply_content_replacements( $table_prefix, $replacements );

        return [
            'ok'              => ! empty( $options['ok'] ) && ! empty( $content['ok'] ),
            'message'         => 'Destination URL lock applied. Current siteurl/home were kept and supported content URLs were rewritten.',
            'site_options'    => $options,
            'content_rewrite' => $content,
            'replacements'    => array_map(
                static function ( array $pair ): array {
                    return [ 'from' => $pair['from'], 'to' => $pair['to'] ];
                },
                $replacements
            ),
        ];
    }

    private function replacements_from_plan( array $plan ): array {
        $pairs = [];
        foreach ( [ 'site_url', 'home_url', 'uploads_url' ] as $key ) {
            $from = isset( $plan[ $key ]['from'] ) ? (string) $plan[ $key ]['from'] : '';
            $to = isset( $plan[ $key ]['to'] ) ? (string) $plan[ $key ]['to'] : '';
            if ( '' !== $from && '' !== $to && $from !== $to ) {
                $pairs[ $from . '=>' . $to ] = [ 'from' => $from, 'to' => $to ];
                $pairs[ untrailingslashit( $from ) . '=>' . untrailingslashit( $to ) ] = [ 'from' => untrailingslashit( $from ), 'to' => untrailingslashit( $to ) ];
                $pairs[ trailingslashit( $from ) . '=>' . trailingslashit( $to ) ] = [ 'from' => trailingslashit( $from ), 'to' => trailingslashit( $to ) ];
            }
        }
        return array_values( array_filter( $pairs, static fn( $pair ) => $pair['from'] !== $pair['to'] && '' !== $pair['from'] ) );
    }

    private function apply_content_replacements( string $prefix, array $pairs ): array {
        $tables = [
            'options'  => [ 'table' => $prefix . 'options', 'id' => 'option_id', 'columns' => [ 'option_value' ] ],
            'posts'    => [ 'table' => $prefix . 'posts', 'id' => 'ID', 'columns' => [ 'post_content', 'post_excerpt', 'guid' ] ],
            'postmeta' => [ 'table' => $prefix . 'postmeta', 'id' => 'meta_id', 'columns' => [ 'meta_value' ] ],
            'termmeta' => [ 'table' => $prefix . 'termmeta', 'id' => 'meta_id', 'columns' => [ 'meta_value' ] ],
            'usermeta' => [ 'table' => $prefix . 'usermeta', 'id' => 'umeta_id', 'columns' => [ 'meta_value' ] ],
        ];

        $summary = [];
        $rows_checked = 0;
        $rows_updated = 0;
        $errors = [];

        foreach ( $tables as $key => $def ) {
            $result = $this->rewrite_table( $def['table'], $def['id'], $def['columns'], $pairs );
            $summary[ $key ] = $result;
            $rows_checked += (int) ( $result['checked'] ?? 0 );
            $rows_updated += (int) ( $result['updated'] ?? 0 );
            if ( ! empty( $result['errors'] ) ) {
                $errors = array_merge( $errors, (array) $result['errors'] );
            }
        }

        return [
            'ok'           => empty( $errors ),
            'message'      => empty( $errors ) ? 'Supported content URLs rewritten to destination URL.' : 'Some content URL rewrites had errors.',
            'tables'       => $summary,
            'rows_checked' => $rows_checked,
            'rows_updated' => $rows_updated,
            'errors'       => array_slice( $errors, 0, 20 ),
        ];
    }

    private function rewrite_table( string $table, string $id_column, array $columns, array $pairs ): array {
        global $wpdb;

        if ( ! $this->table_exists( $table ) ) {
            return [ 'checked' => 0, 'updated' => 0, 'skipped' => true, 'errors' => [] ];
        }

        $select_columns = array_merge( [ $id_column ], $columns );
        $rows = $wpdb->get_results( 'SELECT `' . implode( '`, `', array_map( [ $this, 'escape_identifier' ], $select_columns ) ) . '` FROM `' . $this->escape_identifier( $table ) . '` LIMIT 50000', ARRAY_A );
        if ( ! is_array( $rows ) ) {
            return [ 'checked' => 0, 'updated' => 0, 'errors' => [ (string) $wpdb->last_error ] ];
        }

        $checked = 0;
        $updated = 0;
        $errors = [];

        foreach ( $rows as $row ) {
            $checked++;
            $id = isset( $row[ $id_column ] ) ? (int) $row[ $id_column ] : 0;
            if ( $id <= 0 ) {
                continue;
            }

            $data = [];
            $formats = [];
            foreach ( $columns as $column ) {
                $old = isset( $row[ $column ] ) ? (string) $row[ $column ] : '';
                if ( '' === $old || ! $this->contains_any( $old, $pairs ) ) {
                    continue;
                }
                $new = $this->replace_value( $old, $pairs );
                if ( $new !== $old ) {
                    $data[ $column ] = $new;
                    $formats[] = '%s';
                }
            }

            if ( empty( $data ) ) {
                continue;
            }

            $result = $wpdb->update( $table, $data, [ $id_column => $id ], $formats, [ '%d' ] );
            if ( false === $result ) {
                $errors[] = (string) $wpdb->last_error;
            } else {
                $updated++;
            }
        }

        return [ 'checked' => $checked, 'updated' => $updated, 'errors' => $errors ];
    }

    private function replace_value( string $value, array $pairs ): string {
        if ( is_serialized( $value ) ) {
            $unserialized = @unserialize( $value ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
            if ( false !== $unserialized || 'b:0;' === $value ) {
                return serialize( $this->replace_deep( $unserialized, $pairs ) );
            }
        }

        return $this->replace_string( $value, $pairs );
    }

    private function replace_deep( $value, array $pairs ) {
        if ( is_string( $value ) ) {
            return $this->replace_string( $value, $pairs );
        }
        if ( is_array( $value ) ) {
            foreach ( $value as $key => $item ) {
                $value[ $key ] = $this->replace_deep( $item, $pairs );
            }
            return $value;
        }
        if ( is_object( $value ) ) {
            foreach ( get_object_vars( $value ) as $key => $item ) {
                $value->{$key} = $this->replace_deep( $item, $pairs );
            }
            return $value;
        }
        return $value;
    }

    private function replace_string( string $value, array $pairs ): string {
        foreach ( $pairs as $pair ) {
            $value = str_replace( (string) $pair['from'], (string) $pair['to'], $value );
        }
        return $value;
    }

    private function contains_any( string $value, array $pairs ): bool {
        foreach ( $pairs as $pair ) {
            if ( '' !== (string) $pair['from'] && false !== strpos( $value, (string) $pair['from'] ) ) {
                return true;
            }
        }
        return false;
    }

    private function table_exists( string $table ): bool {
        global $wpdb;
        return (string) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;
    }

    private function escape_identifier( string $identifier ): string {
        return str_replace( '`', '``', $identifier );
    }
}
