<?php

namespace VE\Modules\Recovery\Restore;

defined( 'ABSPATH' ) || exit;

/**
 * Checks whether the backup's critical files are actually inside files.zip before any live table swap.
 * This prevents the restore from saying completed while WordPress later deactivates plugins or breaks the theme.
 */
final class PackageContentGuard {
    public function check( string $files_zip_path, array $prep = [] ): array {
        if ( '' === $files_zip_path || ! is_readable( $files_zip_path ) ) {
            return [ 'ok' => false, 'message' => 'The backup files archive is missing, so the restore cannot safely continue.', 'missing' => [] ];
        }

        $manifest = $this->manifest_from_preparation( $prep );
        if ( empty( $manifest ) ) {
            return [ 'ok' => false, 'message' => 'The backup manifest is missing, so RestoreBase cannot confirm plugin/theme files before restore.', 'missing' => [] ];
        }

        $entries = [];
        $prefixes = [];
        if ( $this->is_restorebase_bundle( $files_zip_path ) ) {
            [ $entries, $prefixes ] = $this->entries_from_inventory( $prep );
            if ( empty( $entries ) ) {
                return [ 'ok' => false, 'message' => 'The RestoreBase bundle is present, but file-inventory.json could not be used for restore safety checks.', 'missing' => [] ];
            }
        } else {
            if ( ! class_exists( '\ZipArchive' ) ) {
                return [ 'ok' => false, 'message' => 'ZipArchive is required to confirm ZIP package files before restore.', 'missing' => [] ];
            }

            $zip = new \ZipArchive();
            if ( true !== $zip->open( $files_zip_path ) ) {
                return [ 'ok' => false, 'message' => 'files.zip could not be opened for restore safety checks.', 'missing' => [] ];
            }

            for ( $i = 0; $i < $zip->numFiles; $i++ ) {
                $name = trim( wp_normalize_path( (string) $zip->getNameIndex( $i ) ), '/' );
                if ( '' === $name ) {
                    continue;
                }
                $lower = strtolower( $name );
                $entries[ $lower ] = true;
                $parts = explode( '/', $lower );
                $path = '';
                foreach ( $parts as $part ) {
                    $path = '' === $path ? $part : $path . '/' . $part;
                    $prefixes[ $path . '/' ] = true;
                }
            }
            $zip->close();
        }

        $scan = isset( $manifest['site_scan'] ) && is_array( $manifest['site_scan'] ) ? $manifest['site_scan'] : [];
        $plugins = isset( $scan['plugins'] ) && is_array( $scan['plugins'] ) ? $scan['plugins'] : [];
        $active_plugins = isset( $plugins['active'] ) && is_array( $plugins['active'] ) ? $plugins['active'] : [];
        $theme = isset( $scan['theme'] ) && is_array( $scan['theme'] ) ? $scan['theme'] : [];
        $contents = isset( $manifest['contents'] ) && is_array( $manifest['contents'] ) ? $manifest['contents'] : [];
        $archive_summary = isset( $contents['files_archive']['summary'] ) && is_array( $contents['files_archive']['summary'] ) ? $contents['files_archive']['summary'] : [];

        $missing_plugins = [];
        $controller_plugins_skipped = [];
        foreach ( $active_plugins as $plugin ) {
            $file = is_array( $plugin ) && isset( $plugin['file'] ) ? trim( wp_normalize_path( (string) $plugin['file'] ), '/' ) : '';
            if ( '' === $file ) {
                continue;
            }

            // RestoreBase is intentionally not stored inside files.zip because it is the running
            // restore controller. A fresh backup therefore can validly list RestoreBase as active
            // in the manifest while omitting its own protected plugin directory from the archive.
            if ( SelfProtection::is_restorebase_plugin_basename( $file ) ) {
                $controller_plugins_skipped[] = $file;
                continue;
            }

            $expected = strtolower( 'wp-content/plugins/' . $file );
            if ( empty( $entries[ $expected ] ) ) {
                $missing_plugins[] = $file;
            }
        }

        $missing_themes = [];
        foreach ( array_unique( array_filter( [ (string) ( $theme['template'] ?? '' ), (string) ( $theme['stylesheet'] ?? '' ) ] ) ) as $slug ) {
            $slug = trim( sanitize_file_name( $slug ) );
            if ( '' === $slug ) {
                continue;
            }
            $expected_file = strtolower( 'wp-content/themes/' . $slug . '/style.css' );
            $expected_dir = strtolower( 'wp-content/themes/' . $slug . '/' );
            if ( empty( $entries[ $expected_file ] ) && empty( $prefixes[ $expected_dir ] ) ) {
                $missing_themes[] = $slug;
            }
        }

        $truncated = ! empty( $archive_summary['truncated'] );
        $ok = empty( $missing_plugins ) && empty( $missing_themes ) && ! $truncated;
        $missing = [
            'active_plugins' => $missing_plugins,
            'themes'         => $missing_themes,
            'archive_truncated' => $truncated,
            'controller_plugins_skipped' => $controller_plugins_skipped,
        ];

        $message = 'Critical plugin and theme files are present in the backup.';
        if ( $truncated ) {
            $message = 'The backup file archive was truncated, so the restore cannot safely continue.';
        } elseif ( ! empty( $missing_plugins ) || ! empty( $missing_themes ) ) {
            $details = [];
            if ( ! empty( $missing_plugins ) ) {
                $details[] = 'missing active plugin files: ' . implode( ', ', array_slice( $missing_plugins, 0, 5 ) );
            }
            if ( ! empty( $missing_themes ) ) {
                $details[] = 'missing active themes: ' . implode( ', ', array_slice( $missing_themes, 0, 5 ) );
            }
            $message = 'This backup is missing files needed by the active plugins or active theme (' . implode( '; ', $details ) . '). Create a fresh backup after confirming those plugins/themes are present, then restore that new file.';
        }

        return [
            'ok'       => $ok,
            'message'  => $message,
            'missing'  => $missing,
            'checked'  => [
                'active_plugins' => count( $active_plugins ),
                'controller_plugins_skipped' => count( $controller_plugins_skipped ),
                'themes'         => count( array_unique( array_filter( [ (string) ( $theme['template'] ?? '' ), (string) ( $theme['stylesheet'] ?? '' ) ] ) ) ),
                'archive_entries'=> count( $entries ),
            ],
        ];
    }


    private function is_restorebase_bundle( string $path ): bool {
        if ( 'restorebase' === strtolower( pathinfo( $path, PATHINFO_EXTENSION ) ) ) {
            return true;
        }
        $handle = @fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! is_resource( $handle ) ) {
            return false;
        }
        $magic = fread( $handle, strlen( "RESTOREBASE-BUNDLE-1\n" ) );
        fclose( $handle );
        return "RESTOREBASE-BUNDLE-1\n" === $magic;
    }

    private function entries_from_inventory( array $prep ): array {
        $extract = isset( $prep['package_extract'] ) && is_array( $prep['package_extract'] ) ? $prep['package_extract'] : [];
        $entries = isset( $extract['entries'] ) && is_array( $extract['entries'] ) ? $extract['entries'] : [];
        $inventory_path = isset( $entries['file-inventory.json']['path'] ) ? (string) $entries['file-inventory.json']['path'] : '';
        if ( '' === $inventory_path && isset( $prep['workspace']['extracted'] ) ) {
            $inventory_path = trailingslashit( (string) $prep['workspace']['extracted'] ) . 'file-inventory.json';
        }
        if ( '' === $inventory_path || ! is_readable( $inventory_path ) ) {
            return [ [], [] ];
        }

        $json = file_get_contents( $inventory_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        $decoded = json_decode( (string) $json, true );
        $files = isset( $decoded['files'] ) && is_array( $decoded['files'] ) ? $decoded['files'] : [];
        $found = [];
        $prefixes = [];
        foreach ( $files as $file ) {
            $name = is_array( $file ) && isset( $file['path'] ) ? trim( wp_normalize_path( (string) $file['path'] ), '/' ) : '';
            if ( '' === $name ) {
                continue;
            }
            $lower = strtolower( $name );
            $found[ $lower ] = true;
            $parts = explode( '/', $lower );
            $path = '';
            foreach ( $parts as $part ) {
                $path = '' === $path ? $part : $path . '/' . $part;
                $prefixes[ $path . '/' ] = true;
            }
        }
        return [ $found, $prefixes ];
    }

    private function manifest_from_preparation( array $prep ): array {
        $extract = isset( $prep['package_extract'] ) && is_array( $prep['package_extract'] ) ? $prep['package_extract'] : [];
        $entries = isset( $extract['entries'] ) && is_array( $extract['entries'] ) ? $extract['entries'] : [];
        $manifest_path = isset( $entries['manifest.json']['path'] ) ? (string) $entries['manifest.json']['path'] : '';

        if ( '' === $manifest_path && isset( $prep['workspace']['extracted'] ) ) {
            $manifest_path = trailingslashit( (string) $prep['workspace']['extracted'] ) . 'manifest.json';
        }

        if ( '' === $manifest_path || ! is_readable( $manifest_path ) ) {
            return [];
        }

        $json = file_get_contents( $manifest_path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        $decoded = json_decode( (string) $json, true );
        return is_array( $decoded ) ? $decoded : [];
    }
}
