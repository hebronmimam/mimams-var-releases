<?php

namespace VE\Modules\Recovery\Restore;

defined( 'ABSPATH' ) || exit;

final class SQLImportPlanner {
    public function plan( string $sql_path, array $manifest = [] ): array {
        if ( '' === $sql_path || ! is_readable( $sql_path ) ) {
            return [
                'ok'      => false,
                'message' => 'database.sql is missing or unreadable.',
                'tables'  => [],
                'prefix'  => '',
            ];
        }

        $detected_tables = $this->scan_tables( $sql_path );
        $skipped_restorebase_tables = array_values( array_filter( $detected_tables, static function ( $table ) {
            return SelfProtection::is_restorebase_table( (string) $table );
        } ) );
        $tables = array_values( array_filter( $detected_tables, static function ( $table ) {
            return ! SelfProtection::is_restorebase_table( (string) $table );
        } ) );
        $manifest_prefix = isset( $manifest['site_scan']['database']['prefix'] ) ? (string) $manifest['site_scan']['database']['prefix'] : '';
        $prefix = $manifest_prefix ?: $this->guess_prefix( $tables );

        global $wpdb;
        $current_prefix = isset( $wpdb->prefix ) ? (string) $wpdb->prefix : '';

        return [
            'ok'             => ! empty( $tables ),
            'message'        => ! empty( $tables ) ? 'SQL import plan created. No database tables were imported.' : 'No table names were detected in database.sql.',
            'tables'         => array_values( $tables ),
            'table_count'    => count( $tables ),
            'skipped_restorebase_tables' => $skipped_restorebase_tables,
            'backup_prefix'  => $prefix,
            'current_prefix' => $current_prefix,
            'mapping'        => [
                'strategy' => $prefix && $current_prefix && $prefix !== $current_prefix ? 'temporary_import_then_prefix_map' : 'temporary_import_same_prefix_guarded',
                'from'     => $prefix,
                'to'       => $current_prefix,
                'note'     => 'Future restore must import into temporary tables first. v0.5 only prepares the plan.',
            ],
        ];
    }

    private function scan_tables( string $sql_path ): array {
        $tables = [];
        $handle = fopen( $sql_path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        if ( ! $handle ) {
            return [];
        }

        while ( ! feof( $handle ) && count( $tables ) < 5000 ) {
            $line = fgets( $handle );
            if ( ! is_string( $line ) ) {
                continue;
            }
            if ( preg_match( '/^(?:CREATE TABLE|CREATE TABLE IF NOT EXISTS|INSERT INTO|LOCK TABLES)\s+`?([^`\s(]+)`?/i', $line, $m ) ) {
                $tables[ sanitize_text_field( $m[1] ) ] = sanitize_text_field( $m[1] );
            }
        }

        fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        ksort( $tables );
        return $tables;
    }

    private function guess_prefix( array $tables ): string {
        if ( empty( $tables ) ) {
            return '';
        }

        $first = (string) reset( $tables );
        $pos = strpos( $first, '_' );
        if ( false === $pos ) {
            return '';
        }

        return substr( $first, 0, $pos + 1 );
    }
}
