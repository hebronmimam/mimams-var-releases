<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Backup\PackageValidator;
use VE\Modules\Recovery\Jobs\JobRunner;
use VE\Modules\Recovery\Jobs\JobStore;
use VE\Modules\Recovery\Jobs\TaskResponse;
use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class RestorePreparation {
    private JobStore $jobs;

    public function __construct( ?JobStore $jobs = null ) {
        $this->jobs = $jobs ?: new JobStore();
    }

    public function prepare( string $snapshot_key = '', string $passphrase = '' ): array {
        $snapshot_key = sanitize_text_field( $snapshot_key );
        $label = 'Guarded restore preparation ' . current_time( 'mysql' );
        $job = $this->jobs->create( 'restore_prepare', $label, $this->tasks( $snapshot_key, $passphrase ) );

        $run = ( new JobRunner( $this->jobs ) )->run( (string) $job['job_key'], $this->tasks( $snapshot_key, $passphrase ), [
            'snapshot_key' => $snapshot_key,
        ] );

        $result = isset( $run['context']['finish_plan'] ) && is_array( $run['context']['finish_plan'] ) ? $run['context']['finish_plan'] : [];
        $result['job'] = $this->jobs->get( (string) $job['job_key'] );
        return $result;
    }

    private function tasks( string $snapshot_key, string $passphrase = '' ): array {
        return [
            [
                'id'       => 'locate_package',
                'label'    => 'Locate Package',
                'callback' => function ( array $context ) use ( $snapshot_key ) {
                    $located = ( new PackageLocator() )->locate( $snapshot_key );
                    return ! empty( $located['ok'] ) ? TaskResponse::ok( 'Package located.', $located ) : TaskResponse::fail( (string) $located['message'], $located );
                },
            ],
            [
                'id'       => 'validate_package',
                'label'    => 'Validate Package',
                'callback' => function ( array $context ) use ( $snapshot_key, $passphrase ) {
                    $validation = ( new PackageValidator() )->validate_snapshot( $snapshot_key, $passphrase );
                    return ! empty( $validation['ok'] ) ? TaskResponse::ok( 'Package validation passed.', $validation ) : TaskResponse::fail( 'Package validation has blockers.', $validation );
                },
            ],
            [
                'id'       => 'create_workspace',
                'label'    => 'Create Workspace',
                'callback' => function ( array $context ) {
                    $located = isset( $context['locate_package'] ) && is_array( $context['locate_package'] ) ? $context['locate_package'] : [];
                    $row = isset( $located['row'] ) && is_array( $located['row'] ) ? $located['row'] : [];
                    $snapshot_key = isset( $row['snapshot_key'] ) ? (string) $row['snapshot_key'] : 'latest';
                    $workspace = ( new RestoreWorkspace() )->create( $snapshot_key );
                    return ! empty( $workspace['ok'] ) ? TaskResponse::ok( 'Restore workspace created.', $workspace ) : TaskResponse::fail( (string) $workspace['message'], $workspace );
                },
            ],
            [
                'id'       => 'extract_metadata',
                'label'    => 'Extract Metadata',
                'callback' => function ( array $context ) use ( $passphrase ) {
                    $located = isset( $context['locate_package'] ) && is_array( $context['locate_package'] ) ? $context['locate_package'] : [];
                    $workspace = isset( $context['create_workspace'] ) && is_array( $context['create_workspace'] ) ? $context['create_workspace'] : [];
                    $extract = ( new RestoreWorkspace() )->extract_package( (string) ( $located['path'] ?? '' ), $workspace, $passphrase );
                    return ! empty( $extract['ok'] ) ? TaskResponse::ok( 'Package metadata extracted.', $extract ) : TaskResponse::fail( (string) $extract['message'], $extract );
                },
            ],
            [
                'id'       => 'build_restore_plan',
                'label'    => 'Build Restore Plan',
                'callback' => function ( array $context ) {
                    $workspace = isset( $context['create_workspace'] ) && is_array( $context['create_workspace'] ) ? $context['create_workspace'] : [];
                    $extract = isset( $context['extract_metadata'] ) && is_array( $context['extract_metadata'] ) ? $context['extract_metadata'] : [];
                    $entries = isset( $extract['entries'] ) && is_array( $extract['entries'] ) ? $extract['entries'] : [];
                    $manifest_path = isset( $entries['manifest.json']['path'] ) ? (string) $entries['manifest.json']['path'] : '';
                    $sql_path = isset( $entries['database.sql']['path'] ) ? (string) $entries['database.sql']['path'] : '';
                    $manifest = $this->read_json( $manifest_path );

                    $plan = [
                        'created_at'       => current_time( 'mysql' ),
                        'workspace'        => $workspace,
                        'package'          => isset( $context['locate_package'] ) ? $context['locate_package'] : [],
                        'validation'       => isset( $context['validate_package'] ) ? $context['validate_package'] : [],
                        'sql_import_plan'  => ( new SQLImportPlanner() )->plan( $sql_path, $manifest ),
                        'config_guard'     => ( new ConfigGuard() )->plan(),
                        'rank_math_config_guard' => ( new RankMathConfigGuard() )->plan_from_manifest( $manifest ),
                        'url_rewrite_plan' => ( new URLRewritePlanner() )->plan( $sql_path, $manifest ),
                        'serialized_rewrite_plan' => ( new SerializedRewritePlanner() )->plan( $sql_path, $manifest ),
                        'package_extract'   => $extract,
                        'package_manifest'  => $manifest,
                        'confirmation'     => [
                            'required' => true,
                            'enabled'  => false,
                            'message'  => 'v0.8 prepares a guarded restore plan. Production restore remains locked; staging execution needs separate confirmation.',
                        ],
                        'rollback'         => [
                            'required_before_restore' => true,
                            'strategy'                 => 'create_pre_restore_restorebase_package_before_execution',
                                'mandatory'                => true,
                        ],
                    ];

                    $plan_path = trailingslashit( (string) ( $workspace['plans'] ?? '' ) ) . 'restore-plan.json';
                    $write = LocalStorage::write_json_file( $plan_path, $plan, 'Restore plan' );
                    $plan['plan_file'] = $write;

                    return ! empty( $write['ok'] ) ? TaskResponse::ok( 'Guarded restore plan prepared.', $plan ) : TaskResponse::fail( 'Guarded restore plan could not be written.', $plan );
                },
            ],
            [
                'id'       => 'finish_plan',
                'label'    => 'Finish Plan',
                'callback' => function ( array $context ) {
                    $plan = isset( $context['build_restore_plan'] ) && is_array( $context['build_restore_plan'] ) ? $context['build_restore_plan'] : [];
                    Logger::info( 'guarded_restore_plan_created', 'Guarded restore preparation completed.', [
                        'workspace_key' => (string) ( $plan['workspace']['workspace_key'] ?? '' ),
                    ] );
                    return TaskResponse::ok( 'Guarded restore preparation completed. No restore action was performed.', $plan );
                },
            ],
        ];
    }

    private function read_json( string $path ): array {
        if ( '' === $path || ! is_readable( $path ) ) {
            return [];
        }

        $json = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        $decoded = json_decode( (string) $json, true );
        return is_array( $decoded ) ? $decoded : [];
    }
}
