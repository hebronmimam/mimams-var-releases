<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Utils\Logger;

// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents
// phpcs:disable WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
// phpcs:disable WordPress.PHP.NoSilencedErrors.Discouraged

defined( 'ABSPATH' ) || exit;

/**
 * Keeps Rank Math's encrypted registration data portable across restores.
 *
 * Rank Math can encrypt account data with wp-config.php secret keys. When a
 * site is restored onto a destination with different WordPress salts, the
 * restored Rank Math data can no longer decrypt. This guard supports a safer
 * path:
 * - run the guard once on the source so stable Rank Math-specific constants
 *   exist in wp-config.php;
 * - reconnect Rank Math once so it re-encrypts with those stable constants;
 * - every later RestoreBase backup carries those constants and restores them
 *   to the destination wp-config.php before the restored database is used.
 */
final class RankMathConfigGuard {
    private const KEY  = 'RANK_MATH_ENCRYPTION_KEY';
    private const SALT = 'RANK_MATH_ENCRYPTION_SALT';

    /**
     * Manual/admin action: create the stable constants on the current site.
     */
    public function ensure_stable_constants( string $trigger = 'manual' ): array {
        $detected = $this->rank_math_detected();
        $path = $this->wp_config_path();
        $current = $this->current_constants();

        if ( ! $detected ) {
            return $this->redact( [
                'ok'       => true,
                'message'  => 'Rank Math is not active or detected on this site. No config change was needed.',
                'detected' => false,
                'changed'  => false,
                'portable' => $this->has_pair( $current ),
                'path'     => $path,
                'trigger'  => $trigger,
            ] );
        }

        if ( $this->has_pair( $current ) ) {
            return $this->redact( [
                'ok'       => true,
                'message'  => 'Rank Math stable encryption constants already exist.',
                'detected' => true,
                'changed'  => false,
                'portable' => true,
                'path'     => $path,
                'trigger'  => $trigger,
                'constants'=> $current,
            ] );
        }

        $generated = [
            self::KEY  => $this->generate_secret(),
            self::SALT => $this->generate_secret(),
        ];

        $write = $this->upsert_constants( $generated, 'rank_math_guard_' . $trigger );
        $ok = ! empty( $write['ok'] );

        Logger::info( 'rank_math_config_guard', 'RestoreBase checked Rank Math portable encryption constants.', [
            'trigger'  => $trigger,
            'detected' => $detected,
            'changed'  => ! empty( $write['changed'] ),
            'ok'       => $ok,
        ] );

        return $this->redact( array_merge( $write, [
            'ok'                  => $ok,
            'message'             => $ok ? 'Rank Math stable encryption constants were added. Reconnect Rank Math once, then create a fresh backup for portable restores.' : (string) ( $write['message'] ?? 'Rank Math key guard could not update wp-config.php.' ),
            'detected'            => true,
            'portable'            => $ok,
            'trigger'             => $trigger,
            'needs_rank_math_reconnect' => $ok,
            'constants'           => $generated,
        ] ) );
    }

    /**
     * Capture source constants for a backup manifest. Values are intentionally
     * returned for the package only; public reports should use redact().
     */
    public function capture_for_manifest(): array {
        $detected = $this->rank_math_detected();
        $constants = $this->current_constants();
        $portable = $this->has_pair( $constants );

        return [
            'detected'  => $detected,
            'portable'  => $portable,
            'strategy'  => 'copy_rank_math_specific_wp_config_constants_to_destination',
            'constants' => $portable ? $constants : [],
            'hashes'    => $portable ? $this->hashes( $constants ) : [],
            'message'   => $portable
                ? 'Rank Math portable encryption constants captured for restore.'
                : ( $detected ? 'Rank Math detected, but stable constants are not configured yet. Run Rank Math Key Guard once, reconnect Rank Math, then create a fresh backup.' : 'Rank Math was not detected on the source site.' ),
        ];
    }



    /**
     * Dry plan for restore preparation. This never writes wp-config.php.
     */
    public function plan_from_manifest( array $manifest ): array {
        $rank_math = [];
        if ( isset( $manifest['restore_safety']['config_transfer']['rank_math'] ) && is_array( $manifest['restore_safety']['config_transfer']['rank_math'] ) ) {
            $rank_math = $manifest['restore_safety']['config_transfer']['rank_math'];
        } elseif ( isset( $manifest['config_transfer']['rank_math'] ) && is_array( $manifest['config_transfer']['rank_math'] ) ) {
            $rank_math = $manifest['config_transfer']['rank_math'];
        }

        $constants = isset( $rank_math['constants'] ) && is_array( $rank_math['constants'] ) ? $this->sanitize_constant_pair( $rank_math['constants'] ) : [];
        $detected_in_backup = ! empty( $rank_math['detected'] ) || $this->manifest_has_rank_math_plugin( $manifest );
        $path = $this->wp_config_path();

        return [
            'ok'                 => true,
            'message'            => $this->has_pair( $constants ) ? 'Rank Math portable constants are available and will be synced during restore.' : ( $detected_in_backup ? 'Rank Math is in the backup, but portable constants are not included yet.' : 'No Rank Math portable config is needed for this backup.' ),
            'detected_in_backup' => $detected_in_backup,
            'portable'           => $this->has_pair( $constants ),
            'will_apply_on_restore' => $this->has_pair( $constants ),
            'wp_config_path'     => $path,
            'wp_config_writable' => '' !== $path && is_writable( $path ),
            'hashes'             => $this->has_pair( $constants ) ? $this->hashes( $constants ) : [],
        ];
    }


    /**
     * Restore destination constants from the backup manifest.
     */
    public function apply_from_manifest( array $manifest ): array {
        $rank_math = [];
        if ( isset( $manifest['restore_safety']['config_transfer']['rank_math'] ) && is_array( $manifest['restore_safety']['config_transfer']['rank_math'] ) ) {
            $rank_math = $manifest['restore_safety']['config_transfer']['rank_math'];
        } elseif ( isset( $manifest['config_transfer']['rank_math'] ) && is_array( $manifest['config_transfer']['rank_math'] ) ) {
            $rank_math = $manifest['config_transfer']['rank_math'];
        }

        $constants = isset( $rank_math['constants'] ) && is_array( $rank_math['constants'] ) ? $rank_math['constants'] : [];
        $constants = $this->sanitize_constant_pair( $constants );

        if ( $this->has_pair( $constants ) ) {
            $write = $this->upsert_constants( $constants, 'rank_math_restore_transfer' );
            $ok = ! empty( $write['ok'] );

            Logger::info( 'rank_math_config_restored', 'RestoreBase applied Rank Math config constants from the backup package.', [
                'ok'      => $ok,
                'changed' => ! empty( $write['changed'] ),
            ] );

            return $this->redact( array_merge( $write, [
                'ok'       => $ok,
                'message'  => $ok ? 'Rank Math portable encryption constants were synced from the backup.' : (string) ( $write['message'] ?? 'Rank Math constants could not be synced from the backup.' ),
                'portable' => $ok,
                'source'   => 'backup_manifest',
                'constants'=> $constants,
                'hashes'   => $this->hashes( $constants ),
            ] ) );
        }

        $detected_in_backup = ! empty( $rank_math['detected'] ) || $this->manifest_has_rank_math_plugin( $manifest );
        if ( $detected_in_backup ) {
            $ensure = $this->ensure_stable_constants( 'restore_fallback' );
            $ensure['message'] = ! empty( $ensure['changed'] )
                ? 'The backup did not include Rank Math portable constants, so RestoreBase created local constants. Reconnect Rank Math once on this restored site, then create a new backup.'
                : (string) ( $ensure['message'] ?? 'Rank Math constants checked.' );
            $ensure['source'] = 'local_fallback';
            return $ensure;
        }

        return [
            'ok'       => true,
            'message'  => 'No Rank Math portable config was needed for this backup.',
            'portable' => false,
            'changed'  => false,
            'source'   => 'none',
        ];
    }

    /**
     * Post-restore repair for Rank Math connection data.
     *
     * If a restored backup did not already use portable constants, the old
     * encrypted connect data can be unreadable on the destination. In that case
     * the safest automatic fix is to remove the broken connection payload so
     * Rank Math shows its normal reconnect state instead of a decrypt error.
     */
    public function repair_after_restore( array $restore_context = [] ): array {
        $detected = $this->rank_math_detected();
        if ( ! $detected ) {
            return [
                'ok'       => true,
                'message'  => 'Rank Math is not active or detected, so no Rank Math repair was needed.',
                'detected' => false,
                'changed'  => false,
            ];
        }

        $ensure = $this->ensure_stable_constants( 'post_restore_repair' );
        $sentinel = '__restorebase_missing_rank_math_connect_data__';
        $connect = get_option( 'rank_math_connect_data', $sentinel );
        $exists = $connect !== $sentinel;
        $valid_connection = is_array( $connect ) && ( ! empty( $connect['connected'] ) || ! empty( $connect['api_key'] ) || ! empty( $connect['username'] ) || ! empty( $connect['email'] ) );
        $portable_config = isset( $restore_context['apply_portable_config'] ) && is_array( $restore_context['apply_portable_config'] ) ? $restore_context['apply_portable_config'] : [];
        $portable_from_backup = 'backup_manifest' === (string) ( $portable_config['source'] ?? '' ) && ! empty( $portable_config['portable'] );
        $registration_reset = false;

        if ( $exists && ! $valid_connection && ! $portable_from_backup ) {
            delete_option( 'rank_math_connect_data' );
            delete_option( 'rank_math_registration_skip' );
            delete_option( 'rank_math_registration_failed' );
            $registration_reset = true;
        }

        $cleared = $this->clear_rank_math_runtime_transients();
        $ok = ! empty( $ensure['ok'] );
        if ( $registration_reset ) {
            $message = 'Broken Rank Math registration data was cleared. Reconnect Rank Math once, then create a fresh backup so future restores stay connected.';
        } elseif ( $portable_from_backup && $exists && ! $valid_connection ) {
            $message = 'Rank Math portable constants were applied. The encrypted connection payload was kept for the next refreshed request.';
        } elseif ( $valid_connection ) {
            $message = 'Rank Math registration data looks readable; runtime caches were cleared.';
        } else {
            $message = 'Rank Math connection data was not present; portable constants and runtime caches were checked.';
        }

        Logger::info( 'rank_math_post_restore_repair', 'RestoreBase ran Rank Math post-restore repair.', [
            'detected'            => $detected,
            'ensure_ok'           => $ok,
            'registration_exists' => $exists,
            'valid_connection'    => $valid_connection,
            'registration_reset'  => $registration_reset,
            'portable_from_backup' => $portable_from_backup,
            'transients_cleared'  => $cleared,
        ] );

        return $this->redact( [
            'ok'                  => $ok,
            'message'             => $message,
            'detected'            => true,
            'changed'             => ! empty( $ensure['changed'] ) || $registration_reset || $cleared > 0,
            'portable'            => ! empty( $ensure['portable'] ),
            'registration_exists' => $exists,
            'valid_connection'    => $valid_connection,
            'registration_reset'  => $registration_reset,
            'portable_from_backup' => $portable_from_backup,
            'transients_cleared'  => $cleared,
            'needs_rank_math_reconnect' => $registration_reset || ( ! $valid_connection && ! $portable_from_backup ),
            'ensure'              => $ensure,
        ] );
    }

    private function clear_rank_math_runtime_transients(): int {
        global $wpdb;
        if ( ! $wpdb ) {
            return 0;
        }

        $patterns = [
            '_transient_rank_math_%',
            '_transient_timeout_rank_math_%',
            '_site_transient_rank_math_%',
            '_site_transient_timeout_rank_math_%',
        ];
        $deleted = 0;
        foreach ( $patterns as $pattern ) {
            $deleted += (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $pattern ) ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        }
        return $deleted;
    }

    /**
     * Public-safe version of a result. Raw constant values are never returned.
     */
    public function redact( array $result ): array {
        if ( isset( $result['constants'] ) && is_array( $result['constants'] ) ) {
            $result['hashes'] = $this->hashes( $this->sanitize_constant_pair( $result['constants'] ) );
            $result['constants'] = array_fill_keys( array_keys( $this->sanitize_constant_pair( $result['constants'] ) ), '[stored privately]' );
        }
        return $result;
    }

    private function rank_math_detected(): bool {
        if ( defined( 'RANK_MATH_VERSION' ) || defined( 'RANK_MATH_PRO_VERSION' ) || class_exists( '\RankMath' ) || class_exists( '\RankMath\\Helper' ) ) {
            return true;
        }

        if ( ! function_exists( 'get_plugins' ) && defined( 'ABSPATH' ) && is_readable( ABSPATH . 'wp-admin/includes/plugin.php' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $active = (array) get_option( 'active_plugins', [] );
        $network = is_multisite() ? array_keys( (array) get_site_option( 'active_sitewide_plugins', [] ) ) : [];
        $plugins = array_merge( $active, $network );
        foreach ( $plugins as $plugin ) {
            $plugin = strtolower( (string) $plugin );
            if ( false !== strpos( $plugin, 'seo-by-rank-math' ) || false !== strpos( $plugin, 'rank-math' ) ) {
                return true;
            }
        }

        return false;
    }

    private function manifest_has_rank_math_plugin( array $manifest ): bool {
        $plugins = isset( $manifest['site_scan']['plugins']['active'] ) && is_array( $manifest['site_scan']['plugins']['active'] ) ? $manifest['site_scan']['plugins']['active'] : [];
        foreach ( $plugins as $plugin ) {
            if ( ! is_array( $plugin ) ) {
                continue;
            }
            $haystack = strtolower( (string) ( $plugin['file'] ?? '' ) . ' ' . (string) ( $plugin['name'] ?? '' ) );
            if ( false !== strpos( $haystack, 'rank math' ) || false !== strpos( $haystack, 'rank-math' ) || false !== strpos( $haystack, 'seo-by-rank-math' ) ) {
                return true;
            }
        }
        return false;
    }

    private function current_constants(): array {
        $values = [];
        foreach ( [ self::KEY, self::SALT ] as $constant ) {
            if ( defined( $constant ) ) {
                $value = (string) constant( $constant );
                if ( '' !== $value ) {
                    $values[ $constant ] = $value;
                }
            }
        }

        $path = $this->wp_config_path();
        if ( '' !== $path && is_readable( $path ) ) {
            $contents = (string) file_get_contents( $path );
            foreach ( [ self::KEY, self::SALT ] as $constant ) {
                $from_file = $this->constant_from_config( $contents, $constant );
                if ( null !== $from_file && '' !== $from_file ) {
                    $values[ $constant ] = $from_file;
                }
            }
        }

        return $this->sanitize_constant_pair( $values );
    }

    private function sanitize_constant_pair( array $values ): array {
        $clean = [];
        foreach ( [ self::KEY, self::SALT ] as $constant ) {
            if ( ! isset( $values[ $constant ] ) ) {
                continue;
            }
            $value = (string) $values[ $constant ];
            $value = str_replace( [ "\0", "\r" ], '', $value );
            $value = trim( $value );
            if ( '' !== $value && strlen( $value ) >= 16 ) {
                $clean[ $constant ] = $value;
            }
        }
        return $clean;
    }

    private function has_pair( array $constants ): bool {
        return ! empty( $constants[ self::KEY ] ) && ! empty( $constants[ self::SALT ] );
    }

    private function hashes( array $constants ): array {
        $hashes = [];
        foreach ( [ self::KEY, self::SALT ] as $constant ) {
            if ( ! empty( $constants[ $constant ] ) ) {
                $hashes[ $constant ] = substr( hash( 'sha256', (string) $constants[ $constant ] ), 0, 16 );
            }
        }
        return $hashes;
    }

    private function constant_from_config( string $contents, string $constant ): ?string {
        $pattern = '/define\s*\(\s*[\'\"]' . preg_quote( $constant, '/' ) . '[\'\"]\s*,\s*([\'\"])(.*?)\\1\s*\)\s*;/s';
        if ( preg_match( $pattern, $contents, $matches ) ) {
            return stripcslashes( (string) $matches[2] );
        }
        return null;
    }

    private function upsert_constants( array $constants, string $reason ): array {
        $constants = $this->sanitize_constant_pair( $constants );
        if ( ! $this->has_pair( $constants ) ) {
            return [ 'ok' => false, 'message' => 'Rank Math encryption key and salt are incomplete.', 'changed' => false ];
        }

        $path = $this->wp_config_path();
        if ( '' === $path || ! is_readable( $path ) ) {
            return [ 'ok' => false, 'message' => 'wp-config.php could not be found or read.', 'changed' => false, 'path' => $path ];
        }

        $contents = (string) file_get_contents( $path );
        $new = $contents;
        $changed = false;
        foreach ( [ self::KEY, self::SALT ] as $constant ) {
            $line = "define( '" . $constant . "', " . var_export( (string) $constants[ $constant ], true ) . " );";
            $pattern = '/define\s*\(\s*[\'\"]' . preg_quote( $constant, '/' ) . '[\'\"]\s*,\s*([\'\"])(.*?)\\1\s*\)\s*;/s';
            if ( preg_match( $pattern, $new ) ) {
                $replaced = preg_replace( $pattern, $line, $new, 1 );
                if ( is_string( $replaced ) && $replaced !== $new ) {
                    $new = $replaced;
                    $changed = true;
                }
            } else {
                $new = $this->insert_config_block( $new, "// RestoreBase: Rank Math portable encryption.\n" . $line );
                $changed = true;
            }
        }

        if ( ! $changed || $new === $contents ) {
            return [ 'ok' => true, 'message' => 'Rank Math stable encryption constants are already in wp-config.php.', 'changed' => false, 'path' => $path ];
        }

        if ( ! is_writable( $path ) ) {
            return [ 'ok' => false, 'message' => 'wp-config.php is not writable. Add the Rank Math constants manually or temporarily make the file writable.', 'changed' => false, 'path' => $path ];
        }

        $backup = $path . '.restorebase-' . sanitize_key( $reason ) . '-' . gmdate( 'Ymd-His' ) . '.bak';
        @copy( $path, $backup );
        $written = file_put_contents( $path, $new, LOCK_EX );
        if ( false === $written ) {
            return [ 'ok' => false, 'message' => 'RestoreBase could not write the Rank Math constants into wp-config.php.', 'changed' => false, 'path' => $path, 'backup_path' => is_readable( $backup ) ? $backup : '' ];
        }

        return [
            'ok'          => true,
            'message'     => 'Rank Math stable encryption constants were written to wp-config.php.',
            'changed'     => true,
            'path'        => $path,
            'backup_path' => is_readable( $backup ) ? $backup : '',
        ];
    }

    private function insert_config_block( string $contents, string $block ): string {
        $block = "\n" . trim( $block ) . "\n";
        $patterns = [
            '/\n\s*\/\*\s*That\'s all, stop editing!.*?\*\//i',
            '/\n\s*require_once\s+ABSPATH\s*\.\s*[\'\"]wp-settings\.php[\'\"]\s*;/i',
        ];

        foreach ( $patterns as $pattern ) {
            if ( preg_match( $pattern, $contents, $matches, PREG_OFFSET_CAPTURE ) ) {
                $pos = (int) $matches[0][1];
                return substr( $contents, 0, $pos ) . $block . substr( $contents, $pos );
            }
        }

        $closing = strrpos( $contents, '?>' );
        if ( false !== $closing ) {
            return substr( $contents, 0, $closing ) . $block . substr( $contents, $closing );
        }

        return rtrim( $contents ) . $block . "\n";
    }

    private function wp_config_path(): string {
        $candidates = [];
        if ( defined( 'ABSPATH' ) ) {
            $candidates[] = trailingslashit( ABSPATH ) . 'wp-config.php';
            $candidates[] = trailingslashit( dirname( untrailingslashit( ABSPATH ) ) ) . 'wp-config.php';
        }

        foreach ( array_unique( $candidates ) as $path ) {
            if ( is_readable( $path ) ) {
                return $path;
            }
        }

        return $candidates[0] ?? '';
    }

    private function generate_secret(): string {
        if ( function_exists( 'wp_generate_password' ) ) {
            return wp_generate_password( 64, true, true );
        }
        return bin2hex( random_bytes( 32 ) );
    }
}
