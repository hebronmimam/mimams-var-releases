<?php

namespace VE\Modules\Recovery\Restore;

defined( 'ABSPATH' ) || exit;

final class URLRewritePlanner {
    public function plan( string $sql_path, array $manifest = [] ): array {
        $backup_url = isset( $manifest['site_scan']['site']['url'] ) ? (string) $manifest['site_scan']['site']['url'] : '';
        $backup_home = isset( $manifest['site_scan']['site']['home'] ) ? (string) $manifest['site_scan']['site']['home'] : $backup_url;
        $current_url = site_url();
        $current_home = home_url();

        $needs_rewrite = ( $backup_url && $backup_url !== $current_url ) || ( $backup_home && $backup_home !== $current_home );

        return [
            'ok'            => true,
            'message'       => $needs_rewrite ? 'URL rewrite plan prepared. No URLs were changed.' : 'Backup and current URLs appear aligned. No URL rewrite is planned.',
            'backup_url'    => $backup_url,
            'backup_home'   => $backup_home,
            'current_url'   => $current_url,
            'current_home'  => $current_home,
            'needs_rewrite' => $needs_rewrite,
            'sql_mentions'  => $this->count_mentions( $sql_path, array_filter( [ $backup_url, $backup_home ] ) ),
            'strategy'      => $needs_rewrite ? 'serialized_safe_search_replace_after_temp_import' : 'no_url_rewrite_needed',
        ];
    }

    private function count_mentions( string $path, array $needles ): array {
        $counts = [];
        foreach ( $needles as $needle ) {
            $counts[ $needle ] = 0;
        }

        if ( '' === $path || ! is_readable( $path ) || empty( $needles ) ) {
            return $counts;
        }

        $handle = fopen( $path, 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        if ( ! $handle ) {
            return $counts;
        }

        while ( ! feof( $handle ) ) {
            $line = fgets( $handle );
            if ( ! is_string( $line ) ) {
                continue;
            }
            foreach ( $needles as $needle ) {
                $counts[ $needle ] += substr_count( $line, (string) $needle );
            }
        }

        fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose
        return $counts;
    }
}
