<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Backup\SiteScanner;
use VE\Modules\Recovery\Database\Schema;

use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class RestorePreview {
    public function unavailable_notice(): array {
        return [
            'available' => true,
            'message'   => 'Restore preview is available. Real restore remains locked.',
        ];
    }

    public function preview_snapshot( string $snapshot_key = '' ): array {
        $row = $snapshot_key ? $this->find_snapshot( $snapshot_key ) : $this->latest_package_snapshot();

        if ( ! is_array( $row ) ) {
            return [
                'available' => false,
                'message'   => 'No local backup package was found. Create a Local Backup Package first.',
                'checks'    => [
                    $this->check( 'info', 'No package available', 'Restore preview needs at least one local backup package.' ),
                ],
            ];
        }

        $meta = $this->decode_json( $row['meta_json'] ?? '' );
        $manifest = $this->read_manifest( (string) ( $row['manifest_path'] ?? '' ) );
        $current = ( new SiteScanner() )->scan();
        $backup_scan = is_array( $manifest ) && isset( $manifest['site_scan'] ) && is_array( $manifest['site_scan'] ) ? $manifest['site_scan'] : [];
        $contents = is_array( $manifest ) && isset( $manifest['contents'] ) && is_array( $manifest['contents'] ) ? $manifest['contents'] : [];

        $checks = $this->build_checks( $row, $meta, $manifest, $backup_scan, $current, $contents );
        $risk = $this->risk_summary( $checks );

        Logger::info( 'restore_preview_generated', 'Restore preview generated.', [
            'snapshot_key' => (string) $row['snapshot_key'],
            'risk_level'   => $risk['level'],
        ] );

        return [
            'available'    => true,
            'message'      => 'Restore preview generated. No restore action was performed.',
            'snapshot'     => [
                'id'           => (int) $row['id'],
                'snapshot_key' => (string) $row['snapshot_key'],
                'label'        => (string) $row['label'],
                'status'       => (string) $row['status'],
                'created_at'   => (string) $row['created_at'],
            ],
            'risk'         => $risk,
            'checks'       => $checks,
            'package'      => [
                'has_package' => ! empty( $meta['package_path'] ),
                'size'        => isset( $meta['package_size'] ) ? (int) $meta['package_size'] : (int) ( $row['size_bytes'] ?? 0 ),
                'hash'        => isset( $meta['package_hash'] ) ? (string) $meta['package_hash'] : '',
                'contents'    => $contents,
            ],
            'backup_site'  => $this->summarize_site( $backup_scan ),
            'current_site' => $this->summarize_site( $current ),
        ];
    }

    private function build_checks( array $row, array $meta, ?array $manifest, array $backup, array $current, array $contents ): array {
        $checks = [];

        if ( ! is_array( $manifest ) ) {
            $checks[] = $this->check( 'danger', 'Manifest missing or unreadable', 'RestoreBase could not read the manifest for this backup package.' );
            return $checks;
        }

        $checks[] = $this->check( 'ok', 'No restore executed', 'This preview did not modify files, database tables, wp-config.php, or site options.' );
        $checks[] = $this->check( 'ok', 'Destination server credentials stay', "RestoreBase keeps this site's wp-config.php and database connection credentials. Backup database credentials are not restored over the destination site." );
        $checks[] = $this->check( 'ok', 'Destination admin access stays', 'RestoreBase captures the current destination administrator login before restore and reapplies it after the backup database is live, so you can still log in with the destination admin account.' );

        $has_db = ! empty( $contents['contains_database_dump'] );
        $checks[] = $this->check(
            $has_db ? 'ok' : 'warn',
            $has_db ? 'Database dump found' : 'Database dump not found',
            $has_db ? 'The package manifest says database.sql is included.' : 'This package does not claim to include a database dump.'
        );

        $has_inventory = ! empty( $contents['contains_file_inventory'] );
        $checks[] = $this->check(
            $has_inventory ? 'ok' : 'warn',
            $has_inventory ? 'File inventory found' : 'File inventory missing',
            $has_inventory ? 'The package has file-inventory.json for future comparison.' : 'Restore preview has less file context without inventory data.'
        );

        $has_files_archive = ! empty( $contents['contains_files_archive'] );
        $archive_summary = isset( $meta['files_archive']['summary'] ) && is_array( $meta['files_archive']['summary'] ) ? $meta['files_archive']['summary'] : [];
        $archive_truncated = ! empty( $archive_summary['truncated'] );
        $checks[] = $this->check(
            $has_files_archive && ! $archive_truncated ? 'ok' : 'warn',
            $has_files_archive ? 'Plugins, themes and media are in the backup' : 'Files archive missing',
            $has_files_archive
                ? ( $archive_truncated ? 'The package has a files archive, but it was truncated. Some plugins/themes/uploads may be missing.' : 'The backup includes the site files archive, including wp-content plugins, themes, uploads, and other restorable files. wp-config.php remains protected. Plugin activation state is also stored in the manifest.' )
                : 'This package does not claim to include files archive, so plugins/themes/media cannot be restored from it.'
        );

        $backup_prefix = (string) ( $backup['database']['prefix'] ?? '' );
        $current_prefix = (string) ( $current['database']['prefix'] ?? '' );
        if ( $backup_prefix && $current_prefix ) {
            $checks[] = $this->check(
                $backup_prefix === $current_prefix ? 'ok' : 'warn',
                'Table prefix check',
                $backup_prefix === $current_prefix
                    ? 'Backup and current site use the same table prefix: ' . $current_prefix
                    : 'Backup prefix is ' . $backup_prefix . ', current prefix is ' . $current_prefix . '. Future restore must handle this deliberately.'
            );
        }

        $backup_url = (string) ( $backup['site']['url'] ?? '' );
        $current_url = (string) ( $current['site']['url'] ?? '' );
        if ( $backup_url && $current_url ) {
            $checks[] = $this->check(
                'ok',
                $backup_url === $current_url ? 'Site URL check' : 'Current site URL will be kept',
                $backup_url === $current_url
                    ? 'Backup site URL matches the current site URL.'
                    : 'Backup site URL is ' . $backup_url . ', current site URL is ' . $current_url . '. Destination URL lock will keep this current site URL and rewrite supported backup URLs to it during restore.'
            );
        }

        $backup_home = (string) ( $backup['site']['home_url'] ?? '' );
        $current_home = (string) ( $current['site']['home_url'] ?? '' );
        if ( $backup_home && $current_home && $backup_home !== $current_home ) {
            $checks[] = $this->check( 'ok', 'Current home URL will be kept', 'Backup home URL is ' . $backup_home . ', current home URL is ' . $current_home . '. RestoreBase will keep the destination home URL after restore.' );
        }

        $backup_wp = (string) ( $backup['environment']['wp_version'] ?? '' );
        $current_wp = (string) ( $current['environment']['wp_version'] ?? '' );
        if ( $backup_wp && $current_wp ) {
            $checks[] = $this->check(
                $backup_wp === $current_wp ? 'ok' : 'info',
                'WordPress version check',
                $backup_wp === $current_wp ? 'WordPress version matches: ' . $current_wp : 'Backup WP version is ' . $backup_wp . ', current is ' . $current_wp . '.'
            );
        }

        $backup_theme = (string) ( $backup['theme']['stylesheet'] ?? '' );
        $current_theme = (string) ( $current['theme']['stylesheet'] ?? '' );
        if ( $backup_theme && $current_theme ) {
            $checks[] = $this->check(
                $backup_theme === $current_theme ? 'ok' : 'info',
                'Theme check',
                $backup_theme === $current_theme ? 'Active theme matches: ' . $current_theme : 'Backup theme is ' . $backup_theme . ', current theme is ' . $current_theme . '.'
            );
        }

        $plugin_check = $this->plugin_check( $backup, $current );
        if ( $plugin_check ) {
            $checks[] = $plugin_check;
        }

        $backup_wc = ! empty( $backup['detected']['woocommerce'] );
        $current_wc = ! empty( $current['detected']['woocommerce'] );
        if ( $backup_wc || $current_wc ) {
            $checks[] = $this->check( 'warn', 'WooCommerce-safe restore required', 'WooCommerce data needs special handling so orders, customers, subscriptions, and checkout data are not overwritten accidentally.' );
        }

        $checks[] = $this->check( 'ok', 'Plugin activation state will be restored', 'After restore, plugins active in the backup stay active. Plugins not active in the backup stay inactive. Missing plugin files are skipped safely.' );
        $checks[] = $this->check( 'ok', 'Restore safety defaults', 'RestoreBase restore keeps destination wp-config credentials, keeps the current site URL, preserves destination admin access, preserves RestoreBase memory/data, restores packaged files, restores plugin activation state, and creates a safety package before guarded restore.' );

        return $checks;
    }

    private function plugin_check( array $backup, array $current ): ?array {
        $backup_plugins = isset( $backup['plugins']['active'] ) && is_array( $backup['plugins']['active'] ) ? $backup['plugins']['active'] : [];
        $current_plugins = isset( $current['plugins']['active'] ) && is_array( $current['plugins']['active'] ) ? $current['plugins']['active'] : [];

        if ( empty( $backup_plugins ) ) {
            return null;
        }

        $current_files = [];
        foreach ( $current_plugins as $plugin ) {
            if ( isset( $plugin['file'] ) ) {
                $current_files[] = (string) $plugin['file'];
            }
        }

        $missing = [];
        foreach ( $backup_plugins as $plugin ) {
            $file = isset( $plugin['file'] ) ? (string) $plugin['file'] : '';
            if ( $file && ! in_array( $file, $current_files, true ) ) {
                $missing[] = isset( $plugin['name'] ) ? (string) $plugin['name'] : $file;
            }
        }

        if ( empty( $missing ) ) {
            return $this->check( 'ok', 'Active plugins check', 'Current site has all plugins that were active when the backup package was created.' );
        }

        $preview = array_slice( $missing, 0, 5 );
        $extra = count( $missing ) > 5 ? ' +' . ( count( $missing ) - 5 ) . ' more' : '';
        return $this->check( 'info', 'Plugins will come from the backup package', 'These active plugins are not on the current site yet: ' . implode( ', ', $preview ) . $extra . '. RestoreBase includes plugin files in files archive when the package is complete and will restore the backup activation state automatically after files are copied.' );
    }

    private function risk_summary( array $checks ): array {
        $danger = 0;
        $warn = 0;
        foreach ( $checks as $check ) {
            if ( 'danger' === ( $check['level'] ?? '' ) ) {
                $danger++;
            }
            if ( 'warn' === ( $check['level'] ?? '' ) ) {
                $warn++;
            }
        }

        if ( $danger > 0 ) {
            $level = 'high';
        } elseif ( $warn > 2 ) {
            $level = 'medium';
        } elseif ( $warn > 0 ) {
            $level = 'guarded';
        } else {
            $level = 'low';
        }

        return [
            'level'   => $level,
            'danger'  => $danger,
            'warnings'=> $warn,
            'summary' => ucfirst( $level ) . ' preview risk. Destination server credentials, admin access, and current URL are protected by default.',
        ];
    }

    private function summarize_site( array $scan ): array {
        return [
            'url'          => (string) ( $scan['site']['url'] ?? '' ),
            'home_url'     => (string) ( $scan['site']['home_url'] ?? '' ),
            'wp_version'   => (string) ( $scan['environment']['wp_version'] ?? '' ),
            'php_version'  => (string) ( $scan['environment']['php_version'] ?? '' ),
            'table_prefix' => (string) ( $scan['database']['prefix'] ?? '' ),
            'theme'        => (string) ( $scan['theme']['stylesheet'] ?? '' ),
            'plugins'      => (int) ( $scan['plugins']['active_count'] ?? 0 ),
            'woocommerce'  => ! empty( $scan['detected']['woocommerce'] ),
            'bricks'       => ! empty( $scan['detected']['bricks'] ),
            'acf'          => ! empty( $scan['detected']['acf'] ),
        ];
    }

    private function latest_package_snapshot(): ?array {
        global $wpdb;
        $table = Schema::table( 'snapshots' );
        $row = $wpdb->get_row( "SELECT * FROM {$table} WHERE trigger_type IN ('backup_package','migration_bundle','migration_import') ORDER BY id DESC LIMIT 1", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return is_array( $row ) ? $row : null;
    }

    private function find_snapshot( string $snapshot_key ): ?array {
        global $wpdb;
        $table = Schema::table( 'snapshots' );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE snapshot_key = %s LIMIT 1", $snapshot_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return is_array( $row ) ? $row : null;
    }

    private function read_manifest( string $path ): ?array {
        if ( '' === $path || ! is_readable( $path ) ) {
            return null;
        }

        $contents = file_get_contents( $path ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        if ( false === $contents ) {
            return null;
        }

        $decoded = json_decode( $contents, true );
        return is_array( $decoded ) ? $decoded : null;
    }

    private function decode_json( string $json ): array {
        if ( '' === $json ) {
            return [];
        }
        $decoded = json_decode( $json, true );
        return is_array( $decoded ) ? $decoded : [];
    }

    private function check( string $level, string $title, string $message ): array {
        return [
            'level'   => sanitize_key( $level ),
            'title'   => sanitize_text_field( $title ),
            'message' => sanitize_text_field( $message ),
        ];
    }
}
