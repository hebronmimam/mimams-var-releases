<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Backup\PackageCipher;

defined( 'ABSPATH' ) || exit;

final class RestoreWorkspace {
    public function create( string $snapshot_key ): array {
        $workspace_key = 'workspace-' . sanitize_file_name( $snapshot_key ) . '-' . gmdate( 'Ymd-His' );
        $path = LocalStorage::ensure_workspace_dir( $workspace_key );

        return [
            'ok'            => is_dir( $path ) && is_writable( $path ),
            'workspace_key' => $workspace_key,
            'path'          => $path,
            'extracted'     => trailingslashit( $path ) . 'extracted/',
            'database'      => trailingslashit( $path ) . 'database/',
            'files'         => trailingslashit( $path ) . 'files/',
            'plans'         => trailingslashit( $path ) . 'plans/',
            'message'       => is_dir( $path ) && is_writable( $path ) ? 'Temporary restore workspace created.' : 'Temporary restore workspace could not be created.',
        ];
    }

    public function extract_package( string $package_path, array $workspace, string $passphrase = '' ): array {
        if ( ! class_exists( '\ZipArchive' ) ) {
            return [ 'ok' => false, 'message' => 'ZipArchive is required to inspect RestoreBase packages.', 'entries' => [] ];
        }

        $target = isset( $workspace['extracted'] ) ? (string) $workspace['extracted'] : '';
        if ( '' === $target ) {
            return [ 'ok' => false, 'message' => 'Restore workspace extraction folder is missing.', 'entries' => [] ];
        }
        if ( ! is_dir( $target ) ) {
            wp_mkdir_p( $target );
        }
        if ( ! is_dir( $target ) || ! is_writable( $target ) ) {
            return [ 'ok' => false, 'message' => 'Restore workspace extraction folder is not writable.', 'entries' => [] ];
        }

        // Transparently decrypt an encrypted package to a temp file before extraction.
        $resolved = PackageCipher::resolve_readable( $package_path, isset( $workspace['path'] ) ? (string) $workspace['path'] : $target, $passphrase );
        if ( empty( $resolved['ok'] ) ) {
            return [ 'ok' => false, 'message' => (string) $resolved['message'], 'entries' => [], 'encrypted' => true, 'needs_passphrase' => ! empty( $resolved['needs_passphrase'] ) ];
        }
        $package_path = (string) $resolved['path'];
        $decrypted_temp = ! empty( $resolved['temp'] ) ? $package_path : '';

        $zip = new \ZipArchive();
        if ( true !== $zip->open( $package_path ) ) {
            if ( '' !== $decrypted_temp ) {
                @unlink( $decrypted_temp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
            }
            return [ 'ok' => false, 'message' => 'RestoreBase package could not be opened.', 'entries' => [] ];
        }

        $allowed = [ 'manifest.json', 'database.sql', 'file-inventory.json', 'files.restorebase', 'files.zip', 'checksums.json' ];
        $existing = [];
        foreach ( $allowed as $entry ) {
            if ( false !== $zip->locateName( $entry ) ) {
                $existing[] = $entry;
            }
        }

        // Extract package members to disk with ZipArchive instead of loading files.zip into PHP memory.
        // This is much faster and avoids memory pressure on big backups.
        $extracted = empty( $existing ) ? false : @$zip->extractTo( trailingslashit( $target ), $existing ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

        // If the host refuses multi-entry extraction, fall back to streaming one entry at a time.
        if ( true !== $extracted ) {
            foreach ( $existing as $entry ) {
                $this->stream_entry_to_disk( $zip, $entry, trailingslashit( $target ) . $entry );
            }
        }

        $entries = [];
        foreach ( $existing as $entry ) {
            $destination = trailingslashit( $target ) . $entry;
            if ( ! file_exists( $destination ) ) {
                continue;
            }
            $entries[ $entry ] = [
                'path' => $destination,
                'size' => (int) filesize( $destination ),
                'hash' => is_readable( $destination ) ? (string) hash_file( 'sha256', $destination ) : '',
            ];
        }

        // The workspace copies are what the restore actually reads — the package zip is
        // never consulted again. A partial extractTo or a failed stream write left a
        // silently short files.restorebase on disk; the bundle reader treats early EOF as
        // a clean end, so a restore completed green while the site was missing its tail
        // files. The recorded checksums are sitting right here — verify every extracted
        // copy against them, re-stream any bad copy once, and refuse the workspace if it
        // still does not match. This runs at Prepare Workspace, BEFORE anything destructive.
        $failure = '';
        $bad = $this->copies_not_matching_checksums( $entries );
        if ( [] !== $bad ) {
            foreach ( array_keys( $bad ) as $entry ) {
                $destination = trailingslashit( $target ) . $entry;
                $this->stream_entry_to_disk( $zip, $entry, $destination );
                clearstatcache( true, $destination );
                if ( file_exists( $destination ) ) {
                    $entries[ $entry ] = [
                        'path' => $destination,
                        'size' => (int) filesize( $destination ),
                        'hash' => is_readable( $destination ) ? (string) hash_file( 'sha256', $destination ) : '',
                    ];
                }
            }
            $bad = $this->copies_not_matching_checksums( $entries );
            if ( [] !== $bad ) {
                $entry = (string) array_key_first( $bad );
                $failure = sprintf(
                    'The restore workspace copy of %s is incomplete (%s of %s bytes) and re-extracting it did not help. Check free disk space on this site, then run Prepare workspace again.',
                    $entry,
                    number_format_i18n( (int) ( $entries[ $entry ]['size'] ?? 0 ) ),
                    number_format_i18n( (int) $bad[ $entry ] )
                );
            }
        }

        $zip->close();

        if ( '' !== $decrypted_temp ) {
            @unlink( $decrypted_temp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
        }

        if ( '' !== $failure ) {
            return [ 'ok' => false, 'message' => $failure, 'entries' => [], 'method' => true === $extracted ? 'ziparchive_extract_to' : 'stream_fallback' ];
        }

        return [
            'ok'      => isset( $entries['manifest.json'] ),
            'message' => isset( $entries['manifest.json'] ) ? 'Package metadata extracted to restore workspace.' : 'Package manifest was not found during workspace extraction.',
            'entries' => $entries,
            'fast_extract' => true,
            'method'  => true === $extracted ? 'ziparchive_extract_to' : 'stream_fallback',
        ];
    }

    /** Stream one zip entry to disk with every write checked. Returns true on a complete copy. */
    private function stream_entry_to_disk( \ZipArchive $zip, string $entry, string $destination ): bool {
        $stream = $zip->getStream( $entry );
        if ( ! is_resource( $stream ) ) {
            return false;
        }
        $out = @fopen( $destination, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! is_resource( $out ) ) {
            fclose( $stream );
            return false;
        }
        $complete = true;
        while ( ! feof( $stream ) ) {
            $chunk = fread( $stream, 1024 * 1024 );
            if ( false === $chunk ) {
                $complete = false;
                break;
            }
            if ( '' === $chunk ) {
                continue;
            }
            $written = fwrite( $out, $chunk );
            if ( false === $written || $written < strlen( $chunk ) ) {
                $complete = false; // disk full or quota — do not pretend the copy landed.
                break;
            }
        }
        fflush( $out );
        fclose( $out );
        fclose( $stream );
        return $complete;
    }

    /**
     * Compare extracted workspace copies against the package's recorded checksums.
     * Returns entry => expected size for every copy that is short or altered.
     */
    private function copies_not_matching_checksums( array $entries ): array {
        if ( ! isset( $entries['checksums.json'] ) ) {
            return [];
        }
        $checksums = json_decode( (string) file_get_contents( $entries['checksums.json']['path'] ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
        $components = isset( $checksums['components'] ) && is_array( $checksums['components'] ) ? $checksums['components'] : [];
        $bad = [];
        foreach ( $components as $component ) {
            $relative = isset( $component['relative_path'] ) ? (string) $component['relative_path'] : '';
            if ( '' === $relative || ! isset( $entries[ $relative ] ) ) {
                continue;
            }
            $expected_size = (int) ( $component['size'] ?? 0 );
            $expected_hash = (string) ( $component['hash'] ?? '' );
            $actual_size = (int) $entries[ $relative ]['size'];
            $actual_hash = (string) $entries[ $relative ]['hash'];
            if ( ( $expected_size > 0 && $actual_size !== $expected_size ) || ( '' !== $expected_hash && '' !== $actual_hash && ! hash_equals( $expected_hash, $actual_hash ) ) ) {
                $bad[ $relative ] = $expected_size;
            }
        }
        return $bad;
    }
}