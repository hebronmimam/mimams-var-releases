<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Backup\SnapshotManager;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class RollbackManager {
    public function plan(): array {
        $snapshots = ( new SnapshotManager() )->all( 30 );
        $safety = array_values( array_filter( $snapshots, function ( $item ) {
            $label = strtolower( (string) ( $item['label'] ?? '' ) );
            return 'backup_package' === ( $item['trigger_type'] ?? '' ) && false !== strpos( $label, 'pre-restore' );
        } ) );

        $latest = $safety[0] ?? null;
        $plan = [
            'ok'      => ! empty( $latest ),
            'message' => ! empty( $latest ) ? 'Rollback source package found. Execution remains guarded.' : 'No pre-restore safety package was found yet.',
            'source'  => $latest,
            'steps'   => [
                'Validate pre-restore package.',
                'Prepare rollback workspace.',
                'Run rollback dry-run.',
                'Require typed confirmation.',
                'Restore only after verification gates pass.',
            ],
            'execution_enabled' => false,
        ];

        Logger::info( 'rollback_plan_created', 'RestoreBase rollback plan created.', [ 'has_source' => ! empty( $latest ) ] );
        return $plan;
    }
}
