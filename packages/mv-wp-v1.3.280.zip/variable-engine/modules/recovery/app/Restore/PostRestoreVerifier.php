<?php

namespace VE\Modules\Recovery\Restore;

defined( 'ABSPATH' ) || exit;

/**
 * Verifies the restored site before RestoreBase marks the job as a real success.
 */
final class PostRestoreVerifier {
    public function verify(): array {
        $checks = [];
        $missing_plugins = [];
        $active_plugins = (array) get_option( 'active_plugins', [] );
        foreach ( $active_plugins as $plugin ) {
            $plugin = trim( wp_normalize_path( (string) $plugin ), '/' );
            if ( '' === $plugin ) {
                continue;
            }
            if ( ! is_readable( trailingslashit( WP_PLUGIN_DIR ) . $plugin ) ) {
                $missing_plugins[] = $plugin;
            }
        }
        $checks[] = [
            'key'     => 'active_plugins',
            'ok'      => empty( $missing_plugins ),
            'message' => empty( $missing_plugins ) ? 'Active plugin files exist.' : 'Some active plugin files are missing.',
            'missing' => $missing_plugins,
        ];

        // A theme needs more than style.css. WordPress reverts to a default theme
        // ("the active theme is broken") when the template theme has no index.php or
        // templates/index.html — checking style.css alone reported a broken theme as
        // healthy, which is exactly how a restore with a missing theme template passed
        // verification.
        $template   = (string) get_option( 'template' );
        $stylesheet = (string) get_option( 'stylesheet' );
        $root       = trailingslashit( get_theme_root() );
        $missing_themes = [];

        if ( '' !== $stylesheet && ! is_readable( $root . $stylesheet . '/style.css' ) ) {
            $missing_themes[] = $stylesheet . ' (style.css missing)';
        }
        if ( '' !== $template ) {
            if ( ! is_readable( $root . $template . '/style.css' ) ) {
                $missing_themes[] = $template . ' (style.css missing)';
            } elseif ( ! is_readable( $root . $template . '/index.php' ) && ! is_readable( $root . $template . '/templates/index.html' ) ) {
                $missing_themes[] = $template . ' (no index.php or templates/index.html - theme template missing)';
            }
        }

        $checks[] = [
            'key'     => 'active_theme',
            'ok'      => empty( $missing_themes ),
            'message' => empty( $missing_themes )
                ? 'Active theme files exist.'
                : 'The active theme is incomplete: ' . implode( ', ', $missing_themes ) . '. WordPress will fall back to a default theme.',
            'missing' => $missing_themes,
        ];

        global $wpdb;
        $db_ok = $wpdb && '' === (string) $wpdb->last_error;
        $checks[] = [
            'key'     => 'database',
            'ok'      => $db_ok,
            'message' => $db_ok ? 'Database connection is available.' : 'Database reported an error.',
            'error'   => $db_ok ? '' : (string) $wpdb->last_error,
        ];

        $permalink = (string) get_option( 'permalink_structure', '' );
        $checks[] = [
            'key'     => 'permalinks',
            'ok'      => '/%postname%/' === $permalink,
            'message' => '/%postname%/' === $permalink
                ? 'Permalinks are set to Post name.'
                : 'Permalinks are ' . ( $permalink ? '"' . $permalink . '"' : 'plain' ) . ' rather than Post name. Save Settings → Permalinks to correct this. The restore itself is unaffected.',
            'value'   => $permalink,
        ];

        // The permalink OPTION being right says nothing about the web server honoring
        // pretty URLs: a destination whose .htaccess lacks WordPress rules 404s every
        // /wp-json request at the server itself while the option check shows green.
        // Probe the REST index so the report states plainly whether a manual
        // Permalinks save is still needed.
        $rest_ok  = false;
        $response = wp_remote_get( rest_url(), [ 'timeout' => 8, 'sslverify' => false, 'redirection' => 2 ] );
        if ( ! is_wp_error( $response ) && 404 !== (int) wp_remote_retrieve_response_code( $response ) ) {
            $rest_ok = null !== json_decode( (string) wp_remote_retrieve_body( $response ), true );
        }
        $checks[] = [
            'key'     => 'rest_reachable',
            'ok'      => $rest_ok,
            'message' => $rest_ok
                ? 'Pretty URLs answer on this server (/wp-json responds).'
                : 'Pretty URLs could not be confirmed by a server self-request (common on local sites where the server cannot reach its own domain). Your browser re-checks this automatically — a manual Permalinks save is only needed if that re-check warns too.',
        ];

        // Only things that mean the site is genuinely not restored may fail the job.
        // A permalink setting is cosmetic and fixed by saving Settings → Permalinks;
        // failing the whole restore on it reads as data loss and pushes people into a
        // needless second restore, which is far more dangerous than a wrong setting.
        $blocker_keys = [ 'active_plugins', 'active_theme', 'database' ];
        foreach ( $checks as $index => $check ) {
            $is_blocker = in_array( (string) $check['key'], $blocker_keys, true );
            $checks[ $index ]['severity'] = $is_blocker ? 'blocker' : 'warning';
            $checks[ $index ]['level']    = ! empty( $check['ok'] ) ? 'ok' : ( $is_blocker ? 'danger' : 'warn' );
        }

        $blockers = array_values( array_filter( $checks, function ( $check ) {
            return empty( $check['ok'] ) && 'blocker' === $check['severity'];
        } ) );
        $warnings = array_values( array_filter( $checks, function ( $check ) {
            // rest_reachable is advisory: the server-side probe false-negatives on hosts
            // that cannot reach their own domain, and the browser re-checks it with the
            // authoritative answer. It must not turn a clean restore into "with notes".
            return empty( $check['ok'] ) && 'warning' === $check['severity'] && 'rest_reachable' !== (string) ( $check['key'] ?? '' );
        } ) );

        if ( $blockers ) {
            $message = 'Restore verification found blockers. The site was changed, but it should not be treated as successfully restored yet.';
        } elseif ( $warnings ) {
            $message = 'Restore completed. Verification passed with notes — the site is restored; the items below are settings you can adjust.';
        } else {
            $message = 'Restore verification passed.';
        }

        return [
            'ok'           => empty( $blockers ),
            'has_warnings' => ! empty( $warnings ),
            'message'      => $message,
            'checks'       => $checks,
            'failed'       => $blockers, // retained for the existing panel rendering
            'blockers'     => $blockers,
            'warnings'     => $warnings,
            'next'         => $blockers
                ? [
                    'Do not run another restore on this same test site yet.',
                    'Create a fresh backup with the latest RestoreBase if files were missing.',
                    'Use the RestoreBase job details to see which plugins or theme files were missing.',
                ]
                : [
                    'Refresh wp-admin.',
                    'Open the homepage.',
                    'Check Plugins and Themes.',
                    'Save Settings → Permalinks if the note above mentions them.',
                ],
        ];
    }
}
