<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Backup\SiteScanner;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class RestoreVerifier {
    public function verify(): array {
        global $wpdb;

        $site = ( new SiteScanner() )->scan();
        $checks = [];

        $checks[] = $this->check( 'frontend', 'Frontend URL', $this->probe_url( home_url( '/' ) ) );
        $checks[] = $this->check( 'admin', 'WP admin URL', $this->probe_url( admin_url( '/' ) ) );
        $checks[] = $this->check( 'database', 'Database connection', ! empty( $wpdb->dbh ) && '' === (string) $wpdb->last_error, (string) $wpdb->last_error );
        $checks[] = $this->check( 'theme', 'Active theme', ! empty( $site['theme']['stylesheet'] ?? '' ), (string) ( $site['theme']['stylesheet'] ?? '' ) );
        $checks[] = $this->check( 'plugins', 'Plugin scan', isset( $site['plugins']['active_count'] ), (string) ( $site['plugins']['active_count'] ?? 0 ) . ' active plugins' );
        $checks[] = $this->check( 'uploads', 'Uploads folder', is_dir( wp_upload_dir( null, false )['basedir'] ?? '' ), wp_upload_dir( null, false )['basedir'] ?? '' );
        $permalink = (string) get_option( 'permalink_structure', '' );
        $checks[] = $this->check( 'permalinks', 'Permalink structure', '/%postname%/' === $permalink, '/%postname%/' === $permalink ? 'Post name permalinks active.' : 'Permalink structure is ' . ( $permalink ?: 'plain' ) . '.' );

        $ok_count = count( array_filter( $checks, fn( $item ) => ! empty( $item['ok'] ) ) );
        $score = count( $checks ) ? (int) floor( ( $ok_count / count( $checks ) ) * 100 ) : 0;

        $report = [
            'ok'      => $score >= 70,
            'score'   => $score,
            'message' => $score >= 70 ? 'Verification checks completed.' : 'Verification found blockers or warnings.',
            'checks'  => $checks,
        ];

        Logger::info( 'verification_report_created', 'RestoreBase verification report created.', [ 'score' => $score ] );
        return $report;
    }

    private function probe_url( string $url ): array {
        $response = wp_remote_get( $url, [ 'timeout' => 5, 'redirection' => 2, 'sslverify' => false ] );
        if ( is_wp_error( $response ) ) {
            return [ 'ok' => false, 'message' => $response->get_error_message(), 'code' => 0 ];
        }
        $code = (int) wp_remote_retrieve_response_code( $response );
        return [ 'ok' => $code >= 200 && $code < 500, 'message' => 'HTTP ' . $code, 'code' => $code ];
    }

    private function check( string $id, string $title, $result, string $message = '' ): array {
        if ( is_array( $result ) ) {
            return [
                'id'      => $id,
                'title'   => $title,
                'ok'      => ! empty( $result['ok'] ),
                'level'   => ! empty( $result['ok'] ) ? 'ok' : 'warn',
                'message' => (string) ( $result['message'] ?? $message ),
            ];
        }

        return [
            'id'      => $id,
            'title'   => $title,
            'ok'      => (bool) $result,
            'level'   => (bool) $result ? 'ok' : 'warn',
            'message' => $message ?: ( (bool) $result ? 'Passed.' : 'Needs attention.' ),
        ];
    }
}
