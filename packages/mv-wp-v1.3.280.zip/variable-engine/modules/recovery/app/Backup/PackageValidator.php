<?php

namespace VE\Modules\Recovery\Backup;

use VE\Modules\Recovery\Database\Schema;

use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class PackageValidator {
    public function validate_snapshot( string $snapshot_key = '', string $passphrase = '' ): array {
        $row = $snapshot_key ? $this->find_snapshot( $snapshot_key ) : $this->latest_package_snapshot();
        if ( ! is_array( $row ) ) {
            return [
                'ok'      => false,
                'message' => 'No local backup package found.',
                'checks'  => [ $this->check( 'danger', 'No package', 'Create a local backup package before validating.' ) ],
            ];
        }

        $meta = $this->decode_json( (string) ( $row['meta_json'] ?? '' ) );
        $package_path = isset( $meta['package_path'] ) ? (string) $meta['package_path'] : '';
        $checks = [];

        if ( '' === $package_path || ! is_readable( $package_path ) ) {
            $checks[] = $this->check( 'danger', 'Package missing', 'The package ZIP does not exist or is not readable.' );
            return $this->result( $row, false, $checks );
        }

        $expected_hash = isset( $meta['package_hash'] ) ? (string) $meta['package_hash'] : '';
        $actual_hash = (string) hash_file( 'sha256', $package_path );
        $checks[] = $this->check(
            ( $expected_hash && hash_equals( $expected_hash, $actual_hash ) ) ? 'ok' : 'warn',
            'Package hash',
            ( $expected_hash && hash_equals( $expected_hash, $actual_hash ) ) ? 'Package ZIP hash matches the recorded hash.' : 'Package hash could not be confirmed against the snapshot record.'
        );

        if ( ! class_exists( '\ZipArchive' ) ) {
            $checks[] = $this->check( 'danger', 'ZipArchive unavailable', 'This server cannot inspect package ZIP files without ZipArchive.' );
            return $this->result( $row, false, $checks );
        }

        // Encrypted packages: verify integrity on the raw file above, then decrypt
        // to a temp copy for structural inspection.
        $decrypted_temp = '';
        if ( PackageCipher::is_encrypted( $package_path ) ) {
            $resolved = PackageCipher::resolve_readable( $package_path, '', $passphrase );
            if ( empty( $resolved['ok'] ) ) {
                $checks[] = $this->check( 'danger', 'Encrypted package', (string) $resolved['message'] );
                $result = $this->result( $row, false, $checks );
                if ( ! empty( $resolved['needs_passphrase'] ) ) {
                    $result['needs_passphrase'] = true;
                }
                return $result;
            }
            $checks[] = $this->check( 'ok', 'Encrypted package', 'Package is AES-256-GCM encrypted and the passphrase decrypts it.' );
            $package_path = (string) $resolved['path'];
            $decrypted_temp = ! empty( $resolved['temp'] ) ? $package_path : '';
        }

        $zip = new \ZipArchive();
        if ( true !== $zip->open( $package_path ) ) {
            if ( '' !== $decrypted_temp ) {
                @unlink( $decrypted_temp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
            }
            $checks[] = $this->check( 'danger', 'Package open failed', 'RestoreBase could not open the package ZIP.' );
            return $this->result( $row, false, $checks );
        }

        $required = [ 'manifest.json', 'database.sql', 'file-inventory.json', 'checksums.json' ];
        foreach ( $required as $entry ) {
            $checks[] = $this->check(
                false !== $zip->locateName( $entry ) ? 'ok' : 'danger',
                $entry,
                false !== $zip->locateName( $entry ) ? $entry . ' exists in the package.' : $entry . ' is missing from the package.'
            );
        }

        $has_files_archive = false !== $zip->locateName( 'files.restorebase' ) || false !== $zip->locateName( 'files.zip' );
        $archive_label = false !== $zip->locateName( 'files.restorebase' ) ? 'files.restorebase' : 'files.zip';
        $checks[] = $this->check(
            $has_files_archive ? 'ok' : 'warn',
            $archive_label,
            $has_files_archive ? 'Files archive exists in the package.' : 'Files archive is missing. RestoreBase can only preview files from inventory.'
        );

        $checksums = $this->read_json_entry( $zip, 'checksums.json' );
        if ( is_array( $checksums ) ) {
            $checks[] = $this->check( 'ok', 'Checksum manifest', 'checksums.json is readable.' );
            $checks = array_merge( $checks, $this->component_checks( $zip, $checksums ) );
            $same_site = ( new PackageSigner() )->verify_same_site_signature( $checksums );
            $checks[] = $this->check(
                $same_site ? 'ok' : 'info',
                'Same-site signature',
                $same_site ? 'Same-site signature verified.' : 'Same-site signature could not be verified on this install. Portable fingerprint can still be used.'
            );
        } else {
            $checks[] = $this->check( 'danger', 'Checksum manifest unreadable', 'checksums.json could not be read.' );
        }

        $zip->close();
        if ( '' !== $decrypted_temp ) {
            @unlink( $decrypted_temp ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
        }
        $ok = 0 === count( array_filter( $checks, function ( $check ) { return 'danger' === ( $check['level'] ?? '' ); } ) );

        Logger::info( 'package_validated', 'RestoreBase package validation completed.', [
            'snapshot_key' => (string) $row['snapshot_key'],
            'ok'           => $ok,
        ] );

        return $this->result( $row, $ok, $checks );
    }

    /**
     * Verify every recorded component, including the multi-GB files archive.
     *
     * This used to read each entry with getFromName() (whole entry into memory) and
     * therefore skipped anything over 8MB — so the largest, most truncation-prone
     * components were never checked and an incomplete download could pass. Hashing
     * is now streamed, so there is no size cap.
     */
    private function component_checks( \ZipArchive $zip, array $checksums ): array {
        $verify = PackageChecksums::verify_zip( $zip, $checksums );
        $checks = $verify['checks'];
        if ( ! PackageChecksums::fingerprint_matches( $checksums ) ) {
            $checks[] = $this->check( 'warn', 'Package fingerprint', 'The recorded fingerprint does not match the component list. The backup may have been modified after it was created.' );
        }
        return $checks;
    }

    private function result( array $row, bool $ok, array $checks ): array {
        $danger = 0;
        $warn = 0;
        foreach ( $checks as $check ) {
            if ( 'danger' === ( $check['level'] ?? '' ) ) {
                $danger++;
            }
            if ( 'warn' === ( $check['level'] ?? '' ) ) {
                $warn++;
            }
        }

        return [
            'ok'       => $ok,
            'message'  => $ok ? 'Package validation passed.' : 'Package validation found blockers.',
            'snapshot' => [
                'snapshot_key' => (string) ( $row['snapshot_key'] ?? '' ),
                'label'        => (string) ( $row['label'] ?? '' ),
                'created_at'   => (string) ( $row['created_at'] ?? '' ),
            ],
            'summary'  => [
                'danger'   => $danger,
                'warnings' => $warn,
                'status'   => $ok ? 'valid' : 'blocked',
            ],
            'checks'   => $checks,
        ];
    }

    private function latest_package_snapshot(): ?array {
        global $wpdb;
        $table = Schema::table( 'snapshots' );
        $row = $wpdb->get_row( "SELECT * FROM {$table} WHERE trigger_type IN ('backup_package','migration_bundle','migration_import') ORDER BY id DESC LIMIT 1", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return is_array( $row ) ? $row : null;
    }

    private function find_snapshot( string $snapshot_key ): ?array {
        global $wpdb;
        $table = Schema::table( 'snapshots' );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE snapshot_key = %s LIMIT 1", $snapshot_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        return is_array( $row ) ? $row : null;
    }

    private function read_json_entry( \ZipArchive $zip, string $entry ): ?array {
        $contents = $zip->getFromName( $entry );
        if ( false === $contents ) {
            return null;
        }
        $decoded = json_decode( $contents, true );
        return is_array( $decoded ) ? $decoded : null;
    }

    private function decode_json( string $json ): array {
        $decoded = json_decode( $json, true );
        return is_array( $decoded ) ? $decoded : [];
    }

    private function check( string $level, string $title, string $message ): array {
        return [
            'level'   => sanitize_key( $level ),
            'title'   => sanitize_text_field( $title ),
            'message' => sanitize_text_field( $message ),
        ];
    }
}
