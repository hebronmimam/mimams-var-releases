<?php

namespace VE\Modules\Recovery\Backup;

defined( 'ABSPATH' ) || exit;

/**
 * Verifies package components against the checksums.json recorded at build time.
 *
 * Every entry is hashed by streaming, so a multi-GB files archive costs constant
 * memory. The previous approach used ZipArchive::getFromName() (whole entry into
 * memory) and therefore had to skip anything over 8MB — which meant the largest,
 * most truncation-prone components were never actually verified, and an
 * incomplete download could pass validation and only fail later during restore.
 */
final class PackageChecksums {
    private const READ_CHUNK = 4194304; // 4 MiB

    /** sha256 of a zip entry, streamed. Returns '' if the entry cannot be read. */
    public static function hash_entry( \ZipArchive $zip, string $entry ): string {
        $stream = $zip->getStream( $entry );
        if ( ! is_resource( $stream ) ) {
            return '';
        }
        $context = hash_init( 'sha256' );
        while ( ! feof( $stream ) ) {
            $buffer = fread( $stream, self::READ_CHUNK );
            if ( false === $buffer || '' === $buffer ) {
                break;
            }
            hash_update( $context, $buffer );
        }
        fclose( $stream );
        return hash_final( $context );
    }

    /**
     * Verify each recorded component against the real zip entry.
     *
     * @return array{ok:bool,verified:int,failures:array<int,string>,missing:array<int,string>,checks:array}
     */
    public static function verify_zip( \ZipArchive $zip, array $checksums ): array {
        $components = isset( $checksums['components'] ) && is_array( $checksums['components'] ) ? $checksums['components'] : [];
        $checks   = [];
        $failures = [];
        $missing  = [];
        $verified = 0;

        foreach ( $components as $name => $component ) {
            $name     = (string) $name;
            $relative = isset( $component['relative_path'] ) ? (string) $component['relative_path'] : '';
            $expected = isset( $component['hash'] ) ? (string) $component['hash'] : '';
            $exp_size = isset( $component['size'] ) ? (int) $component['size'] : 0;

            if ( '' === $relative || '' === $expected ) {
                continue; // nothing recorded to verify against
            }
            if ( false === $zip->locateName( $relative ) ) {
                $missing[] = $relative;
                $checks[]  = self::check( 'danger', $name . ' checksum', $relative . ' is missing from the package.' );
                continue;
            }

            $stat = $zip->statName( $relative );
            $actual_size = is_array( $stat ) && isset( $stat['size'] ) ? (int) $stat['size'] : -1;
            if ( $exp_size > 0 && $actual_size >= 0 && $actual_size !== $exp_size ) {
                $failures[] = $relative;
                $checks[]   = self::check( 'danger', $name . ' size', sprintf( '%s is %s bytes but the backup recorded %s bytes — the package is incomplete.', $relative, number_format_i18n( $actual_size ), number_format_i18n( $exp_size ) ) );
                continue;
            }

            $actual = self::hash_entry( $zip, $relative );
            if ( '' === $actual ) {
                $failures[] = $relative;
                $checks[]   = self::check( 'danger', $name . ' checksum', $relative . ' could not be read for verification.' );
                continue;
            }
            if ( ! hash_equals( $expected, $actual ) ) {
                $failures[] = $relative;
                $checks[]   = self::check( 'danger', $name . ' checksum', $relative . ' failed its checksum — the package is corrupted or incomplete.' );
                continue;
            }

            $verified++;
            $checks[] = self::check( 'ok', $name . ' checksum', $relative . ' checksum matches.' );
        }

        return [
            'ok'       => empty( $failures ) && empty( $missing ),
            'verified' => $verified,
            'failures' => $failures,
            'missing'  => $missing,
            'checks'   => $checks,
        ];
    }

    /**
     * Recompute the portable fingerprint from the recorded components.
     * Detects a checksums.json that was itself altered or truncated.
     */
    public static function fingerprint_matches( array $checksums ): bool {
        $recorded = isset( $checksums['portable_fingerprint'] ) ? (string) $checksums['portable_fingerprint'] : '';
        if ( '' === $recorded ) {
            return false;
        }
        $components = isset( $checksums['components'] ) && is_array( $checksums['components'] ) ? $checksums['components'] : [];
        $clean = [];
        foreach ( $components as $name => $component ) {
            if ( ! is_array( $component ) ) {
                continue;
            }
            $clean[ sanitize_key( (string) $name ) ] = [
                'relative_path' => isset( $component['relative_path'] ) ? (string) $component['relative_path'] : '',
                'hash'          => isset( $component['hash'] ) ? (string) $component['hash'] : '',
                'size'          => isset( $component['size'] ) ? (int) $component['size'] : 0,
            ];
        }
        ksort( $clean );
        return hash_equals( $recorded, hash( 'sha256', wp_json_encode( $clean ) ?: '' ) );
    }

    private static function check( string $level, string $title, string $message ): array {
        return [ 'level' => $level, 'title' => $title, 'message' => $message ];
    }
}
