<?php

namespace VE\Modules\Recovery\Backup;

use VE\Modules\Recovery\Restore\SelfProtection;
use VE\Modules\Recovery\Storage\LocalStorage;

defined( 'ABSPATH' ) || exit;

final class FileInventory {
    private int $max_files;

    public function __construct( int $max_files = 100000 ) {
        $this->max_files = max( 100, min( 250000, absint( $max_files ) ) );
    }

    public function scan(): array {
        $root = wp_normalize_path( ABSPATH );
        $files = [];
        $total_size = 0;
        $count = 0;
        $skipped = 0;
        $category_bytes = [];
        $category_counts = [];
        $truncated = false;

        if ( ! is_dir( $root ) || ! is_readable( $root ) ) {
            return [
                'root'      => $root,
                'files'     => [],
                'summary'   => [
                    'file_count'  => 0,
                    'total_bytes' => 0,
                    'skipped'     => 0,
                    'truncated'   => false,
                ],
                'exclusions' => $this->exclusion_labels(),
            ];
        }

        $iterator = new \RecursiveIteratorIterator(
            new \RecursiveCallbackFilterIterator(
                new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS ),
                function ( \SplFileInfo $current ) use ( &$skipped ) {
                    if ( $this->should_skip( $current ) ) {
                        $skipped++;
                        return false;
                    }
                    return true;
                }
            ),
            \RecursiveIteratorIterator::LEAVES_ONLY
        );

        foreach ( $iterator as $file ) {
            if ( ! $file instanceof \SplFileInfo || ! $file->isFile() || $file->isLink() ) {
                continue;
            }

            $path = wp_normalize_path( $file->getPathname() );
            if ( $this->path_is_excluded( $path ) ) {
                $skipped++;
                continue;
            }

            $size = (int) $file->getSize();
            $total_size += $size;
            $count++;
            $category = $this->category_for_path( LocalStorage::relative_path( $path ) );
            $category_bytes[ $category ] = ( $category_bytes[ $category ] ?? 0 ) + $size;
            $category_counts[ $category ] = ( $category_counts[ $category ] ?? 0 ) + 1;

            if ( count( $files ) < $this->max_files ) {
                $files[] = [
                    'path'     => LocalStorage::relative_path( $path ),
                    'size'     => $size,
                    'modified' => gmdate( 'c', (int) $file->getMTime() ),
                ];
            } else {
                $truncated = true;
            }
        }

        return [
            'root'      => $root,
            'files'     => $files,
            'summary'   => [
                'file_count'      => $count,
                'listed_files'    => count( $files ),
                'total_bytes'     => $total_size,
                'skipped_entries' => $skipped,
                'truncated'       => $truncated,
                'max_files'       => $this->max_files,
                'category_bytes'  => $category_bytes,
                'category_counts' => $category_counts,
            ],
            'exclusions' => $this->exclusion_labels(),
        ];
    }

    private function should_skip( \SplFileInfo $file ): bool {
        $path = wp_normalize_path( $file->getPathname() );
        return $this->path_is_excluded( $path );
    }

    private function path_is_excluded( string $path ): bool {
        $path = wp_normalize_path( $path );
        $restorebase = wp_normalize_path( LocalStorage::base_dir() );
        $content = wp_normalize_path( WP_CONTENT_DIR );

        $restorebase_plugin = trailingslashit( $content ) . 'plugins/restorebase/';
        $restorebase_mu_plugin = trailingslashit( $content ) . 'mu-plugins/restorebase/';
        $root = trailingslashit( wp_normalize_path( ABSPATH ) );

        // RestoreBase restores into an existing WordPress install, so core is intentionally
        // not packaged. That keeps packages smaller and lets restore use a much faster
        // one-pass wp-content extraction path.
        $core_prefixes = [ $root . 'wp-admin/', $root . 'wp-includes/' ];
        foreach ( $core_prefixes as $core_prefix ) {
            if ( 0 === strpos( $path, $core_prefix ) ) {
                return true;
            }
        }

        $core_files = [ 'index.php', 'license.txt', 'readme.html', 'wp-activate.php', 'wp-blog-header.php', 'wp-comments-post.php', 'wp-cron.php', 'wp-links-opml.php', 'wp-load.php', 'wp-login.php', 'wp-mail.php', 'wp-settings.php', 'wp-signup.php', 'wp-trackback.php', 'xmlrpc.php' ];
        if ( in_array( basename( $path ), $core_files, true ) && dirname( $path ) === untrailingslashit( $root ) ) {
            return true;
        }

        $excluded_prefixes = [
            $restorebase,
            $restorebase_plugin,
            $restorebase_mu_plugin,
            trailingslashit( $content ) . 'cache/',
            trailingslashit( $content ) . 'upgrade/',
            trailingslashit( $content ) . 'debug.log',
            trailingslashit( $content ) . 'ai1wm-backups/',
            trailingslashit( $content ) . 'updraft/',
            trailingslashit( $content ) . 'wpvividbackups/',
            trailingslashit( $content ) . 'backups/',
            trailingslashit( $content ) . 'backup/',
            trailingslashit( $content ) . 'backup-db/',
            trailingslashit( $content ) . 'backupwordpress/',
            trailingslashit( $content ) . 'backupbuddy_backups/',
            trailingslashit( $content ) . 'wflogs/',
            trailingslashit( $content ) . 'litespeed/',
            trailingslashit( $content ) . 'et-cache/',
            trailingslashit( wp_normalize_path( ABSPATH ) ) . '.git/',
            trailingslashit( wp_normalize_path( ABSPATH ) ) . 'node_modules/',
        ];

        foreach ( $excluded_prefixes as $prefix ) {
            if ( 0 === strpos( $path, $prefix ) ) {
                return true;
            }
        }

        return SelfProtection::is_restorebase_file( LocalStorage::relative_path( $path ) );
    }

    private function category_for_path( string $relative ): string {
        $relative = trim( wp_normalize_path( $relative ), '/' );
        if ( 0 === strpos( $relative, 'wp-content/uploads/' ) ) {
            return 'uploads';
        }
        if ( 0 === strpos( $relative, 'wp-content/plugins/' ) ) {
            return 'plugins';
        }
        if ( 0 === strpos( $relative, 'wp-content/themes/' ) ) {
            return 'themes';
        }
        if ( 0 === strpos( $relative, 'wp-content/mu-plugins/' ) ) {
            return 'mu-plugins';
        }
        if ( 0 === strpos( $relative, 'wp-content/' ) ) {
            return 'wp-content';
        }
        if ( 0 === strpos( $relative, 'wp-admin/' ) || 0 === strpos( $relative, 'wp-includes/' ) || in_array( basename( $relative ), [ 'index.php', 'wp-load.php', 'wp-settings.php', 'wp-login.php' ], true ) ) {
            return 'core';
        }
        return 'other';
    }

    private function exclusion_labels(): array {
        return [
            'WordPress core files and folders',
            'RestoreBase storage folder',
            'RestoreBase plugin folder',
            'wp-content/cache',
            'wp-content/upgrade',
            'wp-content/debug.log',
            'Common backup folders: ai1wm-backups, updraft, wpvividbackups, backups, backup, backup-db, backupwordpress, backupbuddy_backups',
            'Common generated/cache folders: wflogs, litespeed, et-cache',
            '.git',
            'node_modules',
        ];
    }
}
