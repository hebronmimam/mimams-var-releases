<?php

namespace VE\Modules\Recovery\Backup;

defined( 'ABSPATH' ) || exit;

final class PackageSigner {
    public function build_checksums( array $components ): array {
        $clean = [];
        foreach ( $components as $name => $component ) {
            if ( ! is_array( $component ) ) {
                continue;
            }
            $clean[ sanitize_key( (string) $name ) ] = [
                'relative_path' => isset( $component['relative_path'] ) ? sanitize_text_field( (string) $component['relative_path'] ) : '',
                'hash'          => isset( $component['hash'] ) ? sanitize_text_field( (string) $component['hash'] ) : '',
                'size'          => isset( $component['size'] ) ? (int) $component['size'] : 0,
            ];
        }

        ksort( $clean );
        $portable_fingerprint = hash( 'sha256', wp_json_encode( $clean ) ?: '' );

        return [
            'algorithm'            => 'sha256',
            'created_at'           => current_time( 'mysql' ),
            'components'           => $clean,
            'portable_fingerprint' => $portable_fingerprint,
            'same_site_signature'  => hash_hmac( 'sha256', $portable_fingerprint, $this->secret() ),
            'signature_note'       => 'The same-site signature is for integrity on this WordPress install. The portable fingerprint can be checked across sites.',
        ];
    }

    public function verify_same_site_signature( array $checksums ): bool {
        $fingerprint = isset( $checksums['portable_fingerprint'] ) ? (string) $checksums['portable_fingerprint'] : '';
        $signature = isset( $checksums['same_site_signature'] ) ? (string) $checksums['same_site_signature'] : '';
        if ( '' === $fingerprint || '' === $signature ) {
            return false;
        }
        return hash_equals( hash_hmac( 'sha256', $fingerprint, $this->secret() ), $signature );
    }

    private function secret(): string {
        if ( function_exists( 'wp_salt' ) ) {
            return wp_salt( 'restorebase' );
        }
        return defined( 'AUTH_KEY' ) ? (string) AUTH_KEY : 'restorebase-local-secret';
    }
}
