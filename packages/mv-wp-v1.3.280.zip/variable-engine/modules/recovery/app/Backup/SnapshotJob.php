<?php

namespace VE\Modules\Recovery\Backup;

use VE\Modules\Recovery\Jobs\JobRunner;
use VE\Modules\Recovery\Jobs\JobStore;
use VE\Modules\Recovery\Jobs\TaskResponse;

defined( 'ABSPATH' ) || exit;

final class SnapshotJob {
    private JobStore $jobs;

    public function __construct( ?JobStore $jobs = null ) {
        $this->jobs = $jobs ?: new JobStore();
    }

    public function create( string $label = '' ): array {
        $label = $label ? sanitize_text_field( $label ) : 'Manifest snapshot ' . current_time( 'mysql' );
        $tasks = [
            [
                'id'       => 'site_scan',
                'label'    => 'Site Scan',
                'callback' => function ( array $context ) {
                    return TaskResponse::ok( 'Site scan ready.', ( new SiteScanner() )->scan() );
                },
            ],
            [
                'id'       => 'manifest_snapshot',
                'label'    => 'Manifest Snapshot',
                'callback' => function ( array $context ) use ( $label ) {
                    $snapshot = ( new SnapshotManager() )->create( $label, 'manual_job' );
                    return TaskResponse::ok( 'Manifest snapshot created.', [ 'snapshot' => $snapshot ] );
                },
            ],
        ];

        $job = $this->jobs->create( 'manifest_snapshot', $label, $tasks );
        $run = ( new JobRunner( $this->jobs ) )->run( (string) $job['job_key'], $tasks );
        $snapshot = isset( $run['context']['manifest_snapshot']['snapshot'] ) ? $run['context']['manifest_snapshot']['snapshot'] : null;

        return [
            'job'      => $this->jobs->get( (string) $job['job_key'] ),
            'snapshot' => $snapshot,
            'ok'       => ! empty( $run['ok'] ),
            'message'  => (string) ( $run['message'] ?? '' ),
        ];
    }
}
