<?php

namespace VE\Modules\Recovery\Backup;

use VE\Modules\Recovery\Restore\MVSettingsPortability;
use VE\Modules\Recovery\Restore\RankMathConfigGuard;

defined( 'ABSPATH' ) || exit;

final class ManifestBuilder {
    public function build( array $snapshot, array $contents = [] ): array {
        $scanner = new SiteScanner();
        $default_contents = [
            'contains_database_dump' => false,
            'contains_files_archive' => false,
            'contains_file_inventory'=> false,
            'contains_uploads'       => false,
            'note'                   => 'Manifest snapshot only. Backup package contents are recorded when package mode is used.',
        ];

        return [
            'manifest_version' => '0.3',
            'product'          => 'RestoreBase',
            'product_version'  => VE_RECOVERY_VERSION,
            'snapshot'         => [
                'key'          => $snapshot['snapshot_key'] ?? '',
                'label'        => $snapshot['label'] ?? '',
                'trigger_type' => $snapshot['trigger_type'] ?? 'manual',
                'created_by'   => $snapshot['created_by'] ?? 0,
                'created_at'   => current_time( 'mysql' ),
            ],
            'site_scan'        => $scanner->scan(),
            'contents'         => array_merge( $default_contents, $contents ),
            'restore_safety'   => [
                'wp_config_preservation_required' => true,
                'table_prefix_check_required'     => true,
                'siteurl_home_check_required'     => true,
                'destructive_restore_supported'   => false,
                'restore_preview_required'        => true,
                'plugin_activation_state_required'=> true,
                'config_transfer'                  => [
                    'rank_math' => ( new RankMathConfigGuard() )->capture_for_manifest(),
                    'mv_settings' => ( new MVSettingsPortability() )->capture( absint( $snapshot['created_by'] ?? 0 ) ),
                ],
            ],
        ];
    }
}
