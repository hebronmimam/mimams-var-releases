<?php

namespace VE\Modules\Recovery\Backup;

use VE\Modules\Recovery\Restore\SelfProtection;

defined( 'ABSPATH' ) || exit;

final class DatabaseExporter {
    private int $rows_per_batch;

    public function __construct( int $rows_per_batch = 100 ) {
        $this->rows_per_batch = max( 25, min( 500, absint( $rows_per_batch ) ) );
    }

    public function export( string $path ): array {
        global $wpdb;

        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        }

        $dir = dirname( $path );
        if ( ! is_dir( $dir ) ) {
            wp_mkdir_p( $dir );
        }

        // Fast path: native mysqldump. Toggled from the Backup options UI (stored
        // option), still overridable by filter; silently falls back to the PHP
        // exporter below on any failure.
        if ( apply_filters( 'restorebase_enable_mysqldump', (bool) get_option( 'restorebase_enable_mysqldump', true ) ) ) {
            $fast = $this->try_mysqldump( $path );
            if ( ! empty( $fast['ok'] ) ) {
                return $fast;
            }
        }

        $handle = fopen( $path, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        if ( false === $handle ) {
            return [
                'ok'      => false,
                'message' => 'Database export file could not be opened.',
                'path'    => '',
                'hash'    => '',
                'size'    => 0,
                'tables'  => 0,
                'rows'    => 0,
            ];
        }

        $tables = $this->tables();
        $row_total = 0;

        $this->write( $handle, "-- RestoreBase database export\n" );
        $this->write( $handle, "-- Generated: " . gmdate( 'c' ) . "\n" );
        $this->write( $handle, "-- Site: " . site_url() . "\n\n" );
        $this->write( $handle, "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n" );
        $this->write( $handle, "SET time_zone = \"+00:00\";\n\n" );

        foreach ( $tables as $table ) {
            $table = (string) $table;
            $quoted = $this->quote_identifier( $table );
            $create = $wpdb->get_row( 'SHOW CREATE TABLE ' . $quoted, ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

            if ( ! is_array( $create ) || empty( $create[1] ) ) {
                continue;
            }

            $this->write( $handle, "\n-- Table: {$table}\n" );
            $this->write( $handle, "DROP TABLE IF EXISTS {$quoted};\n" );
            $this->write( $handle, $create[1] . ";\n\n" );

            $count = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $quoted ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
            $row_total += $count;

            for ( $offset = 0; $offset < $count; $offset += $this->rows_per_batch ) {
                $rows = $wpdb->get_results(
                    $wpdb->prepare( 'SELECT * FROM ' . $quoted . ' LIMIT %d OFFSET %d', $this->rows_per_batch, $offset ), // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                    ARRAY_A
                );

                if ( ! is_array( $rows ) || [] === $rows ) {
                    continue;
                }

                foreach ( $rows as $row ) {
                    $columns = array_map( [ $this, 'quote_identifier' ], array_keys( $row ) );
                    $values = array_map( [ $this, 'sql_value' ], array_values( $row ) );
                    $this->write( $handle, 'INSERT INTO ' . $quoted . ' (' . implode( ',', $columns ) . ') VALUES (' . implode( ',', $values ) . ");\n" );
                }
            }
        }

        fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

        return [
            'ok'      => true,
            'message' => 'Database exported.',
            'method'  => 'php',
            'path'    => $path,
            'hash'    => is_readable( $path ) ? (string) hash_file( 'sha256', $path ) : '',
            'size'    => file_exists( $path ) ? (int) filesize( $path ) : 0,
            'tables'  => count( $tables ),
            'rows'    => $row_total,
        ];
    }

    /**
     * Native mysqldump fast path. Returns ['ok'=>false] on any problem so the
     * caller transparently falls back to the PHP exporter.
     *
     * Safety: credentials go in a 0600 --defaults-extra-file, never on argv; the
     * command is passed to proc_open as an array (no shell), and only prefixed,
     * non-RestoreBase tables are dumped. --skip-extended-insert keeps the output
     * shape compatible with the SQL importer.
     */
    private function try_mysqldump( string $path ): array {
        global $wpdb;

        if ( ! function_exists( 'proc_open' ) ) {
            return [ 'ok' => false ];
        }
        $disabled = array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) );
        if ( in_array( 'proc_open', $disabled, true ) ) {
            return [ 'ok' => false ];
        }
        if ( ! defined( 'DB_NAME' ) || ! defined( 'DB_USER' ) || ! defined( 'DB_HOST' ) ) {
            return [ 'ok' => false ];
        }

        $tables = $this->tables();
        if ( [] === $tables ) {
            return [ 'ok' => false ];
        }

        $binary = (string) apply_filters( 'restorebase_mysqldump_binary', 'mysqldump' );
        [ $host, $port, $socket ] = $this->parse_db_host( (string) DB_HOST );

        // Credentials via a temporary 0600 defaults file (not argv / not env).
        $cnf = dirname( $path ) . '/.rb-mysqldump-' . wp_generate_password( 8, false, false ) . '.cnf';
        $cnf_body = "[client]\n"
            . 'user=' . (string) DB_USER . "\n"
            . 'password=' . ( defined( 'DB_PASSWORD' ) ? (string) DB_PASSWORD : '' ) . "\n"
            . 'host=' . $host . "\n"
            . ( $port ? 'port=' . $port . "\n" : '' )
            . ( $socket ? 'socket=' . $socket . "\n" : '' );
        if ( false === file_put_contents( $cnf, $cnf_body ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
            return [ 'ok' => false ];
        }
        @chmod( $cnf, 0600 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

        $charset = $wpdb->charset ? (string) $wpdb->charset : 'utf8mb4';
        $cmd = array_merge(
            [
                $binary,
                '--defaults-extra-file=' . $cnf,
                '--single-transaction',
                '--quick',
                '--skip-extended-insert',
                '--skip-comments',
                '--skip-lock-tables',
                '--no-tablespaces',
                '--add-drop-table',
                '--hex-blob',
                '--default-character-set=' . $charset,
                (string) DB_NAME,
            ],
            array_map( 'strval', $tables )
        );

        $descriptors = [ 0 => [ 'pipe', 'r' ], 1 => [ 'file', $path, 'w' ], 2 => [ 'pipe', 'w' ] ];
        $pipes = [];
        $proc = @proc_open( $cmd, $descriptors, $pipes ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! is_resource( $proc ) ) {
            @unlink( $cnf ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
            return [ 'ok' => false ];
        }
        $stderr = is_resource( $pipes[2] ) ? (string) stream_get_contents( $pipes[2] ) : '';
        if ( is_resource( $pipes[2] ) ) { fclose( $pipes[2] ); }
        $exit = proc_close( $proc );
        @unlink( $cnf ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink

        // Validate: clean exit, non-trivial file, and it actually contains DDL.
        $size = file_exists( $path ) ? (int) filesize( $path ) : 0;
        if ( 0 !== $exit || $size < 128 ) {
            \VE\Modules\Recovery\Utils\Logger::warning( 'mysqldump_fallback', 'mysqldump failed; using PHP exporter.', [ 'exit' => $exit, 'stderr' => substr( $stderr, 0, 300 ) ] );
            return [ 'ok' => false ];
        }
        $head = (string) file_get_contents( $path, false, null, 0, 65536 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents
        if ( false === stripos( $head, 'CREATE TABLE' ) ) {
            return [ 'ok' => false ];
        }

        $row_total = 0;
        foreach ( $tables as $table ) {
            $row_total += (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $this->quote_identifier( (string) $table ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        }

        return [
            'ok'      => true,
            'message' => 'Database exported (mysqldump).',
            'method'  => 'mysqldump',
            'path'    => $path,
            'hash'    => is_readable( $path ) ? (string) hash_file( 'sha256', $path ) : '',
            'size'    => $size,
            'tables'  => count( $tables ),
            'rows'    => $row_total,
        ];
    }

    /** @return array{0:string,1:string,2:string} [host, port, socket] */
    private function parse_db_host( string $db_host ): array {
        $host = $db_host;
        $port = '';
        $socket = '';
        if ( false !== strpos( $db_host, ':' ) ) {
            [ $host, $tail ] = explode( ':', $db_host, 2 );
            if ( ctype_digit( $tail ) ) {
                $port = $tail;
            } else {
                $socket = $tail;
            }
        }
        return [ $host !== '' ? $host : 'localhost', $port, $socket ];
    }

    private function tables(): array {
        global $wpdb;

        $like = $wpdb->esc_like( $wpdb->prefix ) . '%';
        $tables = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );
        if ( ! is_array( $tables ) ) {
            return [];
        }

        return array_values( array_filter( $tables, static function ( $table ) {
            return ! SelfProtection::is_restorebase_table( (string) $table );
        } ) );
    }

    private function quote_identifier( string $identifier ): string {
        return '`' . str_replace( '`', '``', $identifier ) . '`';
    }

    private function sql_value( $value ): string {
        if ( null === $value ) {
            return 'NULL';
        }

        return "'" . esc_sql( (string) $value ) . "'";
    }

    private function write( $handle, string $contents ): void {
        fwrite( $handle, $contents ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
    }
}
