<?php

namespace VE\Modules\Recovery\Backup;

use VE\Modules\Recovery\Database\Schema;
use VE\Modules\Recovery\Jobs\JobStore;
use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class SnapshotManager {
    public function create( string $label = '', string $trigger_type = 'manual' ): array {
        global $wpdb;

        $snapshot_key = $this->generate_key();
        $label = $label ? sanitize_text_field( $label ) : 'Manual snapshot ' . current_time( 'mysql' );
        $trigger_type = sanitize_key( $trigger_type ?: 'manual' );
        $created_by = get_current_user_id();

        $snapshot = [
            'snapshot_key' => $snapshot_key,
            'label'        => $label,
            'trigger_type' => $trigger_type,
            'created_by'   => $created_by,
        ];

        $manifest = ( new ManifestBuilder() )->build( $snapshot );
        $write = LocalStorage::write_manifest( $snapshot_key, $manifest );

        $status = $write['ok'] ? 'completed' : 'failed';
        $meta = [
            'manifest_message' => $write['message'],
            'manifest_version' => $manifest['manifest_version'],
            'contents'         => $manifest['contents'],
        ];

        $table = Schema::table( 'snapshots' );
        $wpdb->insert(
            $table,
            [
                'snapshot_key'  => $snapshot_key,
                'label'         => $label,
                'trigger_type'  => $trigger_type,
                'status'        => $status,
                'manifest_path' => $write['path'],
                'manifest_hash' => $write['hash'],
                'size_bytes'    => absint( $write['size'] ),
                'meta_json'     => wp_json_encode( $meta ),
                'created_by'    => absint( $created_by ),
                'created_at'    => current_time( 'mysql' ),
                'updated_at'    => current_time( 'mysql' ),
            ],
            [ '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s' ]
        );

        $id = (int) $wpdb->insert_id;

        Logger::info( 'snapshot_created', 'Snapshot manifest created.', [
            'snapshot_key' => $snapshot_key,
            'status'       => $status,
            'id'           => $id,
        ] );

        return [
            'id'            => $id,
            'snapshot_key'  => $snapshot_key,
            'label'         => $label,
            'trigger_type'  => $trigger_type,
            'status'        => $status,
            'manifest_path' => $write['path'],
            'manifest_hash' => $write['hash'],
            'size_bytes'    => absint( $write['size'] ),
            'created_at'    => current_time( 'mysql' ),
            'meta'          => $meta,
        ];
    }

    public function all( int $limit = 20 ): array {
        global $wpdb;

        $limit = max( 1, min( 100, absint( $limit ) ) );
        $table = Schema::table( 'snapshots' );
        $rows = $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared

        if ( ! is_array( $rows ) ) {
            return [];
        }

        return array_map( [ $this, 'format_row' ], $rows );
    }

    public function status(): array {
        global $wpdb;

        $table = Schema::table( 'snapshots' );
        $total = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $completed = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status = 'completed'" ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        $last = $wpdb->get_row( "SELECT * FROM {$table} ORDER BY id DESC LIMIT 1", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

        return [
            'version'           => VE_RECOVERY_VERSION,
            'storage_path'      => LocalStorage::base_dir(),
            'total_snapshots'   => $total,
            'completed_snapshots' => $completed,
            'last_snapshot'     => is_array( $last ) ? $this->format_row( $last ) : null,
            'destructive_restore_enabled' => 'guarded',
            'staging_restore_execution' => 'guarded',
            'package_snapshots' => (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE trigger_type IN ('backup_package','migration_bundle','migration_import')" ), // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
            'active_jobs'       => ( new JobStore() )->active( 5 ),
            'recent_jobs'       => ( new JobStore() )->all( 5 ),
            'last_restore_job'  => ( new JobStore() )->latest_restore(),
            'message'           => 'RestoreBase uses one backup file for backup and restore. Create a backup, download it, import it on another site, then validate, preview, dry-run, and restore.',
        ];
    }

    private function format_row( array $row ): array {
        $meta = [];
        if ( ! empty( $row['meta_json'] ) ) {
            $decoded = json_decode( (string) $row['meta_json'], true );
            $meta = is_array( $decoded ) ? $decoded : [];
        }

        $package = $this->package_from_meta( (string) $row['snapshot_key'], $meta, $row );
        $size_bytes = (int) $row['size_bytes'];
        if ( is_array( $package ) && isset( $package['size'] ) && (int) $package['size'] > 0 ) {
            $size_bytes = (int) $package['size'];
        }

        return [
            'id'            => (int) $row['id'],
            'snapshot_key'  => (string) $row['snapshot_key'],
            'label'         => (string) $row['label'],
            'trigger_type'  => (string) $row['trigger_type'],
            'status'        => (string) $row['status'],
            'manifest_path' => (string) $row['manifest_path'],
            'manifest_hash' => (string) $row['manifest_hash'],
            'size_bytes'    => $size_bytes,
            'created_by'    => (int) $row['created_by'],
            'created_at'    => (string) $row['created_at'],
            'updated_at'    => (string) $row['updated_at'],
            'meta'          => $meta,
            'package'       => $package,
        ];
    }

    private function package_from_meta( string $snapshot_key, array $meta, array $row = [] ): ?array {
        if ( empty( $meta['package_path'] ) || ! is_string( $meta['package_path'] ) || ! file_exists( $meta['package_path'] ) ) {
            return null;
        }

        $path = (string) $meta['package_path'];
        $actual_size = is_readable( $path ) ? (int) filesize( $path ) : 0;
        $recorded_size = isset( $meta['package_size'] ) ? (int) $meta['package_size'] : 0;
        $size = $actual_size > 0 ? $actual_size : $recorded_size;

        $url = add_query_arg(
            [
                'action'       => 'restorebase_download_package',
                'snapshot_key' => $snapshot_key,
                '_wpnonce'     => wp_create_nonce( 'restorebase_download_' . $snapshot_key ),
            ],
            admin_url( 'admin-post.php' )
        );

        return [
            'hash'          => isset( $meta['package_hash'] ) ? (string) $meta['package_hash'] : '',
            'size'          => $size,
            'recorded_size' => $recorded_size,
            'actual_size'   => $actual_size,
            'download_url'  => $url,
            'download_name' => $this->download_name( $snapshot_key, $meta, $row ),
        ];
    }


    private function download_name( string $snapshot_key, array $meta, array $row = [] ): string {
        if ( ! empty( $meta['package_filename'] ) && is_string( $meta['package_filename'] ) ) {
            $filename = sanitize_file_name( $meta['package_filename'] );
            if ( '' !== $filename && 'zip' === strtolower( pathinfo( $filename, PATHINFO_EXTENSION ) ) ) {
                return $filename;
            }
        }

        $source = '';
        if ( ! empty( $meta['source_site_url'] ) && is_string( $meta['source_site_url'] ) ) {
            $source = (string) wp_parse_url( $meta['source_site_url'], PHP_URL_HOST );
        }
        if ( '' === $source ) {
            $source = (string) wp_parse_url( home_url(), PHP_URL_HOST );
        }
        $site = sanitize_title( $source ?: get_bloginfo( 'name' ) ?: 'wordpress-site' );
        $site = $site ?: 'wordpress-site';

        $created = ! empty( $row['created_at'] ) ? strtotime( (string) $row['created_at'] ) : false;
        $stamp = $created ? gmdate( 'Ymd-His', $created ) : gmdate( 'Ymd-His' );
        $tail = substr( preg_replace( '/[^A-Za-z0-9]/', '', $snapshot_key ), -8 );
        $tail = $tail ?: 'backup';
        $version = $this->backup_version_slug( $meta );

        return sanitize_file_name( 'restorebase-v' . $version . '-backup-' . $site . '-' . $stamp . '-' . $tail . '.zip' );
    }

    private function backup_version_slug( array $meta ): string {
        $version = '';
        foreach ( [ 'restorebase_version', 'created_with_version', 'product_version' ] as $key ) {
            if ( ! empty( $meta[ $key ] ) && is_string( $meta[ $key ] ) ) {
                $version = (string) $meta[ $key ];
                break;
            }
        }
        if ( '' === $version ) {
            $version = defined( 'VE_RECOVERY_VERSION' ) ? (string) VE_RECOVERY_VERSION : 'unknown';
        }
        $version = strtolower( (string) preg_replace( '/[^A-Za-z0-9]+/', '-', $version ) );
        $version = trim( $version, '-' );
        $version = preg_replace( '/^v+/', '', $version );
        return $version ?: 'unknown-version';
    }


    public function delete( string $snapshot_key, bool $delete_files = true ): array {
        global $wpdb;

        $snapshot_key = sanitize_text_field( $snapshot_key );
        if ( '' === $snapshot_key ) {
            return [ 'ok' => false, 'message' => 'Snapshot key is required.' ];
        }

        $table = Schema::table( 'snapshots' );
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE snapshot_key = %s LIMIT 1", $snapshot_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.InterpolatedNotPrepared
        if ( ! is_array( $row ) ) {
            return [ 'ok' => false, 'message' => 'Snapshot or package was not found.' ];
        }

        $meta = [];
        if ( ! empty( $row['meta_json'] ) ) {
            $decoded = json_decode( (string) $row['meta_json'], true );
            $meta = is_array( $decoded ) ? $decoded : [];
        }

        $deleted_files = [];
        $kept_files = [];
        $file_errors = [];

        if ( $delete_files ) {
            foreach ( $this->delete_targets( $snapshot_key, $row, $meta ) as $target ) {
                if ( '' === $target || ! file_exists( $target ) ) {
                    continue;
                }

                $result = $this->delete_path_inside_storage( $target );
                if ( ! empty( $result['deleted'] ) ) {
                    $deleted_files[] = $target;
                } elseif ( ! empty( $result['kept'] ) ) {
                    $kept_files[] = $target;
                } else {
                    $file_errors[] = [
                        'path'    => $target,
                        'message' => (string) ( $result['message'] ?? 'Could not delete file.' ),
                    ];
                }
            }
        }

        $wpdb->delete( $table, [ 'snapshot_key' => $snapshot_key ], [ '%s' ] );

        Logger::info( 'snapshot_deleted', 'RestoreBase snapshot/package deleted.', [
            'snapshot_key'  => $snapshot_key,
            'label'         => (string) $row['label'],
            'trigger_type'  => (string) $row['trigger_type'],
            'delete_files'  => $delete_files,
            'deleted_files' => count( $deleted_files ),
            'kept_files'    => count( $kept_files ),
            'file_errors'   => count( $file_errors ),
        ] );

        return [
            'ok'            => true,
            'message'       => $delete_files ? 'Snapshot/package deleted with local files where safe.' : 'Snapshot/package record deleted. Local files were kept.',
            'snapshot_key'  => $snapshot_key,
            'label'         => (string) $row['label'],
            'trigger_type'  => (string) $row['trigger_type'],
            'deleted_files' => $deleted_files,
            'kept_files'    => $kept_files,
            'file_errors'   => $file_errors,
        ];
    }

    private function delete_targets( string $snapshot_key, array $row, array $meta ): array {
        $targets = [];
        if ( ! empty( $row['manifest_path'] ) ) {
            $targets[] = (string) $row['manifest_path'];
        }
        if ( ! empty( $meta['package_path'] ) ) {
            $targets[] = (string) $meta['package_path'];
        }

        $safe_key = sanitize_file_name( $snapshot_key );
        $targets[] = LocalStorage::package_work_dir( $snapshot_key );
        $targets[] = LocalStorage::manifest_dir() . $safe_key . '.json';
        $targets[] = LocalStorage::base_dir() . 'migration-bundles/migration-' . $safe_key . '.zip';
        $targets[] = LocalStorage::base_dir() . 'migration-bundles/migration-' . $safe_key . '.json';

        return array_values( array_unique( array_filter( $targets ) ) );
    }

    private function delete_path_inside_storage( string $path ): array {
        $path = wp_normalize_path( $path );
        $base = trailingslashit( wp_normalize_path( LocalStorage::base_dir() ) );

        if ( 0 !== strpos( $path, $base ) || $path === untrailingslashit( $base ) ) {
            return [ 'kept' => true, 'message' => 'Path is outside RestoreBase local storage.' ];
        }

        if ( is_dir( $path ) && ! is_link( $path ) ) {
            return $this->delete_directory( $path );
        }

        if ( @unlink( $path ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
            return [ 'deleted' => true ];
        }

        return [ 'deleted' => false, 'message' => 'File could not be deleted.' ];
    }

    private function delete_directory( string $dir ): array {
        $dir = trailingslashit( wp_normalize_path( $dir ) );
        $base = trailingslashit( wp_normalize_path( LocalStorage::base_dir() ) );
        if ( 0 !== strpos( $dir, $base ) || $dir === $base ) {
            return [ 'kept' => true, 'message' => 'Directory is outside RestoreBase local storage or is the storage root.' ];
        }

        $items = @scandir( $dir ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_scandir
        if ( ! is_array( $items ) ) {
            return [ 'deleted' => false, 'message' => 'Directory could not be scanned.' ];
        }

        foreach ( $items as $item ) {
            if ( '.' === $item || '..' === $item ) {
                continue;
            }
            $child = $dir . $item;
            if ( is_dir( $child ) && ! is_link( $child ) ) {
                $result = $this->delete_directory( $child );
                if ( empty( $result['deleted'] ) && empty( $result['kept'] ) ) {
                    return $result;
                }
            } elseif ( file_exists( $child ) && ! @unlink( $child ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
                return [ 'deleted' => false, 'message' => 'A file inside the directory could not be deleted.' ];
            }
        }

        if ( @rmdir( $dir ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.file_system_operations_rmdir
            return [ 'deleted' => true ];
        }

        return [ 'deleted' => false, 'message' => 'Directory could not be removed.' ];
    }

    private function generate_key(): string {
        return 'rb-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 8, false, false );
    }
}
