<?php

namespace VE\Modules\Recovery\Backup;

defined( 'ABSPATH' ) || exit;

final class SiteScanner {
    public function scan(): array {
        global $wpdb, $wp_version;

        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $active_plugins = (array) get_option( 'active_plugins', [] );
        $network_active_plugins = is_multisite() ? (array) get_site_option( 'active_sitewide_plugins', [] ) : [];
        $plugins = function_exists( 'get_plugins' ) ? get_plugins() : [];
        $theme = wp_get_theme();
        $uploads = wp_upload_dir( null, false );

        return [
            'generated_at' => current_time( 'mysql' ),
            'site'         => [
                'name'     => get_bloginfo( 'name' ),
                'url'      => site_url(),
                'home_url' => home_url(),
                'is_multisite' => is_multisite(),
            ],
            'environment'  => [
                'wp_version'        => $wp_version,
                'php_version'       => PHP_VERSION,
                'mysql_version'     => $wpdb->db_version(),
                'server_software'   => isset( $_SERVER['SERVER_SOFTWARE'] ) ? sanitize_text_field( wp_unslash( $_SERVER['SERVER_SOFTWARE'] ) ) : '',
                'memory_limit'      => ini_get( 'memory_limit' ),
                'max_execution_time'=> ini_get( 'max_execution_time' ),
            ],
            'database'     => [
                'prefix'      => $wpdb->prefix,
                'base_prefix' => $wpdb->base_prefix,
                'table_count' => $this->table_count(),
            ],
            'theme'        => [
                'name'    => $theme->get( 'Name' ),
                'version' => $theme->get( 'Version' ),
                'template'=> get_template(),
                'stylesheet' => get_stylesheet(),
            ],
            'plugins'      => [
                'active_count'   => count( $active_plugins ),
                'total_count'    => count( $plugins ),
                'active'         => $this->active_plugin_details( $active_plugins, $plugins ),
                'network_active' => $network_active_plugins,
                'inactive_files' => array_values( array_diff( array_keys( $plugins ), $active_plugins ) ),
                'activation_rule'=> 'active_plugins_option_is_restored_from_backup_manifest',
            ],
            'uploads'      => [
                'basedir' => $uploads['basedir'] ?? '',
                'baseurl' => $uploads['baseurl'] ?? '',
            ],
            'detected'     => [
                'woocommerce'      => class_exists( '\\WooCommerce' ) || in_array( 'woocommerce/woocommerce.php', $active_plugins, true ),
                'bricks'           => defined( 'BRICKS_VERSION' ) || in_array( 'bricks/bricks.php', $active_plugins, true ),
                'acf'              => class_exists( 'ACF' ) || in_array( 'advanced-custom-fields-pro/acf.php', $active_plugins, true ),
                'mimams_var'       => defined( 'VE_VERSION' ),
                'wpcodebox'        => defined( 'WPCB_VERSION' ) || in_array( 'wpcodebox2/wpcodebox2.php', $active_plugins, true ),
                'rank_math'       => defined( 'RANK_MATH_VERSION' ) || in_array( 'seo-by-rank-math/rank-math.php', $active_plugins, true ) || in_array( 'seo-by-rank-math-pro/rank-math-pro.php', $active_plugins, true ),
            ],
        ];
    }

    private function table_count(): int {
        global $wpdb;

        $like = $wpdb->esc_like( $wpdb->prefix ) . '%';
        $tables = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );
        return is_array( $tables ) ? count( $tables ) : 0;
    }

    private function active_plugin_details( array $active_plugins, array $plugins ): array {
        $details = [];

        foreach ( $active_plugins as $plugin_file ) {
            $plugin_file = sanitize_text_field( (string) $plugin_file );
            $plugin_data = $plugins[ $plugin_file ] ?? [];
            $details[] = [
                'file'    => $plugin_file,
                'name'    => isset( $plugin_data['Name'] ) ? $plugin_data['Name'] : $plugin_file,
                'version' => isset( $plugin_data['Version'] ) ? $plugin_data['Version'] : '',
            ];
        }

        return $details;
    }
}
