<?php

namespace VE\Modules\Recovery\Storage;

defined( 'ABSPATH' ) || exit;

final class LocalStorage {
    public static function base_dir(): string {
        $uploads = wp_upload_dir( null, false );
        return trailingslashit( $uploads['basedir'] ) . 'restorebase/';
    }

    public static function base_url(): string {
        $uploads = wp_upload_dir( null, false );
        return trailingslashit( $uploads['baseurl'] ) . 'restorebase/';
    }

    public static function manifest_dir(): string {
        return self::base_dir() . 'manifests/';
    }

    public static function packages_dir(): string {
        return self::base_dir() . 'packages/';
    }

    public static function logs_dir(): string {
        return self::base_dir() . 'logs/';
    }

    public static function workspaces_dir(): string {
        return self::base_dir() . 'workspaces/';
    }

    public static function package_work_dir( string $snapshot_key ): string {
        return self::packages_dir() . sanitize_file_name( $snapshot_key ) . '/';
    }

    public static function ensure_directories(): void {
        foreach ( [ self::base_dir(), self::manifest_dir(), self::packages_dir(), self::logs_dir(), self::workspaces_dir() ] as $dir ) {
            if ( ! wp_mkdir_p( $dir ) ) {
                continue;
            }

            self::write_if_missing( $dir . 'index.php', "<?php\n// Silence is golden.\n" );
            self::write_if_missing( $dir . '.htaccess', "Options -Indexes\nDeny from all\n" );
        }
    }

    public static function ensure_package_dir( string $snapshot_key ): string {
        self::ensure_directories();
        $dir = self::package_work_dir( $snapshot_key );
        self::protect_dir( $dir );
        return $dir;
    }

    public static function ensure_workspace_dir( string $workspace_key ): string {
        self::ensure_directories();
        $safe_key = sanitize_file_name( $workspace_key );
        $dir = self::workspaces_dir() . $safe_key . '/';
        self::protect_dir( $dir );
        foreach ( [ 'extracted', 'database', 'files', 'plans' ] as $subdir ) {
            self::protect_dir( trailingslashit( $dir ) . $subdir . '/' );
        }
        return $dir;
    }

    public static function write_manifest( string $snapshot_key, array $manifest ): array {
        self::ensure_directories();

        $safe_key = sanitize_file_name( $snapshot_key );
        $path = self::manifest_dir() . $safe_key . '.json';
        return self::write_json_file( $path, $manifest, 'Manifest' );
    }

    public static function write_json_file( string $path, array $data, string $label = 'JSON' ): array {
        $json = wp_json_encode( $data, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );

        if ( false === $json ) {
            return [
                'ok'      => false,
                'message' => $label . ' encoding failed.',
                'path'    => '',
                'hash'    => '',
                'size'    => 0,
            ];
        }

        $written = file_put_contents( $path, $json ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        if ( false === $written ) {
            return [
                'ok'      => false,
                'message' => $label . ' file could not be written.',
                'path'    => '',
                'hash'    => '',
                'size'    => 0,
            ];
        }

        return [
            'ok'      => true,
            'message' => $label . ' written.',
            'path'    => $path,
            'hash'    => is_readable( $path ) ? (string) hash_file( 'sha256', $path ) : '',
            'size'    => file_exists( $path ) ? (int) filesize( $path ) : 0,
        ];
    }

    public static function relative_path( string $path ): string {
        $base = wp_normalize_path( ABSPATH );
        $path = wp_normalize_path( $path );
        if ( 0 === strpos( $path, $base ) ) {
            return ltrim( substr( $path, strlen( $base ) ), '/' );
        }

        return basename( $path );
    }

    public static function absolute_from_relative( string $relative ): string {
        $relative = ltrim( wp_normalize_path( $relative ), '/' );
        $base = trailingslashit( wp_normalize_path( ABSPATH ) );
        $absolute = self::collapse_dot_segments( wp_normalize_path( $base . $relative ) );

        // Independently traversal-proof: after collapsing ./.. the path must
        // still live under ABSPATH. Do not rely on unsafe_path() being called first.
        if ( 0 !== strpos( $absolute, $base ) ) {
            return $base;
        }

        return $absolute;
    }

    /** Resolve "." and ".." path segments without touching the filesystem. */
    private static function collapse_dot_segments( string $path ): string {
        $leading = ( '' !== $path && '/' === $path[0] ) ? '/' : '';
        $stack = [];
        foreach ( explode( '/', $path ) as $segment ) {
            if ( '' === $segment || '.' === $segment ) {
                continue;
            }
            if ( '..' === $segment ) {
                array_pop( $stack );
                continue;
            }
            $stack[] = $segment;
        }
        return $leading . implode( '/', $stack );
    }

    public static function protect_dir( string $dir ): void {
        wp_mkdir_p( $dir );
        self::write_if_missing( trailingslashit( $dir ) . 'index.php', "<?php\n// Silence is golden.\n" );
        self::write_if_missing( trailingslashit( $dir ) . '.htaccess', "Options -Indexes\nDeny from all\n" );
    }

    private static function write_if_missing( string $path, string $contents ): void {
        if ( file_exists( $path ) ) {
            return;
        }

        file_put_contents( $path, $contents ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
    }
}
