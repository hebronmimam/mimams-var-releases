<?php

namespace VE\Modules\Recovery\Storage;

use VE\Modules\Recovery\Backup\SnapshotManager;
use VE\Modules\Recovery\Database\Schema;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class RemoteStorageManager {
    public function adapters(): array {
        $settings = $this->settings();
        return [
            [ 'id' => 'local', 'label' => 'Local protected storage', 'status' => 'available', 'configured' => true, 'enabled' => true, 'functional' => true, 'priority' => 0 ],
            [ 'id' => 'local_mirror', 'label' => 'Offsite/local mirror folder', 'status' => is_dir( (string) ( $settings['local_mirror_path'] ?? '' ) ) ? 'ready' : 'auto_created_on_upload', 'configured' => true, 'enabled' => ! empty( $settings['local_mirror_enabled'] ), 'functional' => true, 'priority' => 1 ],
            [ 'id' => 'sftp', 'label' => 'SFTP', 'status' => function_exists( 'ssh2_connect' ) ? 'ready_if_configured' : 'php_ssh2_missing', 'configured' => $this->has_sftp_config( $settings ), 'enabled' => ! empty( $settings['sftp_enabled'] ), 'functional' => function_exists( 'ssh2_connect' ), 'priority' => 2 ],
            [ 'id' => 's3', 'label' => 'S3-compatible', 'status' => 'connector_registered', 'configured' => false, 'enabled' => false, 'functional' => false, 'planned' => true, 'priority' => 3 ],
            [ 'id' => 'cloudflare_r2', 'label' => 'Cloudflare R2', 'status' => 's3_compatible_registered', 'configured' => false, 'enabled' => false, 'functional' => false, 'planned' => true, 'priority' => 4 ],
            [ 'id' => 'backblaze_b2', 'label' => 'Backblaze B2', 'status' => 'registered', 'configured' => false, 'enabled' => false, 'functional' => false, 'planned' => true, 'priority' => 5 ],
            [ 'id' => 'wasabi', 'label' => 'Wasabi', 'status' => 's3_compatible_registered', 'configured' => false, 'enabled' => false, 'functional' => false, 'planned' => true, 'priority' => 6 ],
            [ 'id' => 'google_drive', 'label' => 'Google Drive', 'status' => 'oauth_connector_registered', 'configured' => false, 'enabled' => false, 'functional' => false, 'planned' => true, 'priority' => 7 ],
            [ 'id' => 'dropbox', 'label' => 'Dropbox', 'status' => 'oauth_connector_registered', 'configured' => false, 'enabled' => false, 'functional' => false, 'planned' => true, 'priority' => 8 ],
        ];
    }

    public function settings(): array {
        $defaults = [
            'local_mirror_enabled' => true,
            'local_mirror_path'    => LocalStorage::base_dir() . 'remote-mirror/',
            'sftp_enabled'         => defined( 'RESTOREBASE_SFTP_HOST' ),
            'sftp_host'            => defined( 'RESTOREBASE_SFTP_HOST' ) ? RESTOREBASE_SFTP_HOST : '',
            'sftp_port'            => defined( 'RESTOREBASE_SFTP_PORT' ) ? (int) RESTOREBASE_SFTP_PORT : 22,
            'sftp_user'            => defined( 'RESTOREBASE_SFTP_USER' ) ? RESTOREBASE_SFTP_USER : '',
            'sftp_pass'            => defined( 'RESTOREBASE_SFTP_PASS' ) ? RESTOREBASE_SFTP_PASS : '',
            'sftp_path'            => defined( 'RESTOREBASE_SFTP_PATH' ) ? RESTOREBASE_SFTP_PATH : '',
        ];
        $saved = get_option( 'restorebase_remote_storage', [] );
        return array_merge( $defaults, is_array( $saved ) ? $saved : [] );
    }

    public function save_settings( array $settings ): array {
        $current = $this->settings();
        $clean = [
            'local_mirror_enabled' => ! empty( $settings['local_mirror_enabled'] ),
            'local_mirror_path'    => isset( $settings['local_mirror_path'] ) ? sanitize_text_field( wp_unslash( $settings['local_mirror_path'] ) ) : $current['local_mirror_path'],
            'sftp_enabled'         => ! empty( $settings['sftp_enabled'] ),
            'sftp_host'            => isset( $settings['sftp_host'] ) ? sanitize_text_field( wp_unslash( $settings['sftp_host'] ) ) : $current['sftp_host'],
            'sftp_port'            => isset( $settings['sftp_port'] ) ? absint( $settings['sftp_port'] ) : (int) $current['sftp_port'],
            'sftp_user'            => isset( $settings['sftp_user'] ) ? sanitize_text_field( wp_unslash( $settings['sftp_user'] ) ) : $current['sftp_user'],
            'sftp_pass'            => isset( $settings['sftp_pass'] ) ? (string) wp_unslash( $settings['sftp_pass'] ) : $current['sftp_pass'],
            'sftp_path'            => isset( $settings['sftp_path'] ) ? sanitize_text_field( wp_unslash( $settings['sftp_path'] ) ) : $current['sftp_path'],
        ];
        update_option( 'restorebase_remote_storage', $clean, false );
        return [ 'ok' => true, 'message' => 'Remote storage settings saved.', 'settings' => $this->redact( $clean ), 'adapters' => $this->adapters() ];
    }

    public function plan(): array {
        $status = ( new SnapshotManager() )->status();
        return [
            'ok' => true,
            'message' => 'Remote storage upload is active. Local mirror works immediately; SFTP works when credentials/constants are configured.',
            'adapters' => $this->adapters(),
            'current_storage' => [
                'local_path' => $status['storage_path'] ?? LocalStorage::base_dir(),
                'package_count' => (int) ( $status['package_snapshots'] ?? 0 ),
            ],
            'settings' => $this->redact( $this->settings() ),
            'write_enabled' => array_values( array_filter( array_map( fn( $a ) => ! empty( $a['enabled'] ) ? $a['id'] : null, $this->adapters() ) ) ),
            'offsite_write_enabled' => true,
            'next_required' => [ 'live cloud credential UI for S3/R2/B2', 'retry queue', 'upload pruning after successful remote handoff' ],
        ];
    }

    public function upload_latest(): array {
        $snapshot = $this->latest_package_snapshot();
        if ( ! $snapshot ) {
            return [ 'ok' => false, 'message' => 'No completed local package is available for remote upload.' ];
        }
        return $this->upload_snapshot( (string) $snapshot['snapshot_key'] );
    }

    public function upload_snapshot( string $snapshot_key ): array {
        $row = $this->snapshot_row( $snapshot_key );
        if ( ! $row ) {
            return [ 'ok' => false, 'message' => 'Package snapshot not found.' ];
        }
        $meta = json_decode( (string) $row['meta_json'], true );
        $package_path = is_array( $meta ) && ! empty( $meta['package_path'] ) ? (string) $meta['package_path'] : '';
        if ( '' === $package_path || ! is_readable( $package_path ) ) {
            return [ 'ok' => false, 'message' => 'Package file is missing or unreadable.' ];
        }

        $settings = $this->settings();
        $results = [];
        if ( ! empty( $settings['local_mirror_enabled'] ) ) {
            $results['local_mirror'] = $this->upload_local_mirror( $package_path, (string) $settings['local_mirror_path'] );
        }
        if ( ! empty( $settings['sftp_enabled'] ) ) {
            $results['sftp'] = $this->upload_sftp( $package_path, $settings );
        }

        $ok = ! empty( array_filter( $results, fn( $r ) => is_array( $r ) && ! empty( $r['ok'] ) ) );
        Logger::info( 'remote_upload_finished', 'RestoreBase remote upload attempted.', [ 'snapshot_key' => $snapshot_key, 'ok' => $ok, 'targets' => array_keys( $results ) ] );
        return [
            'ok' => $ok,
            'message' => $ok ? 'Remote upload completed for at least one target.' : 'Remote upload did not complete for any target.',
            'snapshot_key' => $snapshot_key,
            'package' => basename( $package_path ),
            'results' => $results,
        ];
    }

    private function upload_local_mirror( string $package_path, string $target_dir ): array {
        $target_dir = trailingslashit( wp_normalize_path( $target_dir ) );
        if ( ! wp_mkdir_p( $target_dir ) ) {
            return [ 'ok' => false, 'message' => 'Mirror directory could not be created.', 'target' => $target_dir ];
        }
        LocalStorage::protect_dir( $target_dir );
        $target = $target_dir . basename( $package_path );
        $copied = @copy( $package_path, $target ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        return [ 'ok' => (bool) $copied, 'message' => $copied ? 'Copied to mirror folder.' : 'Mirror copy failed.', 'target' => $target ];
    }

    private function upload_sftp( string $package_path, array $settings ): array {
        if ( ! function_exists( 'ssh2_connect' ) || ! function_exists( 'ssh2_scp_send' ) ) {
            return [ 'ok' => false, 'message' => 'PHP ssh2 extension is not available.' ];
        }
        if ( ! $this->has_sftp_config( $settings ) ) {
            return [ 'ok' => false, 'message' => 'SFTP credentials are incomplete.' ];
        }
        $connection = @ssh2_connect( (string) $settings['sftp_host'], (int) $settings['sftp_port'] ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! $connection ) {
            return [ 'ok' => false, 'message' => 'Could not connect to SFTP host.' ];
        }
        if ( ! @ssh2_auth_password( $connection, (string) $settings['sftp_user'], (string) $settings['sftp_pass'] ) ) { // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
            return [ 'ok' => false, 'message' => 'SFTP authentication failed.' ];
        }
        $remote = trailingslashit( (string) $settings['sftp_path'] ) . basename( $package_path );
        $sent = @ssh2_scp_send( $connection, $package_path, $remote, 0640 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        return [ 'ok' => (bool) $sent, 'message' => $sent ? 'Uploaded to SFTP.' : 'SFTP upload failed.', 'remote' => $remote ];
    }

    private function latest_package_snapshot(): ?array {
        global $wpdb;
        $row = $wpdb->get_row( "SELECT * FROM " . Schema::table( 'snapshots' ) . " WHERE trigger_type IN ('backup_package','migration_bundle','migration_import') AND status = 'completed' ORDER BY id DESC LIMIT 1", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        return is_array( $row ) ? $row : null;
    }

    private function snapshot_row( string $snapshot_key ): ?array {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . Schema::table( 'snapshots' ) . " WHERE snapshot_key = %s LIMIT 1", $snapshot_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        return is_array( $row ) ? $row : null;
    }

    private function has_sftp_config( array $settings ): bool {
        return ! empty( $settings['sftp_host'] ) && ! empty( $settings['sftp_user'] ) && ! empty( $settings['sftp_pass'] ) && ! empty( $settings['sftp_path'] );
    }

    private function redact( array $settings ): array {
        if ( ! empty( $settings['sftp_pass'] ) ) {
            $settings['sftp_pass'] = '********';
        }
        return $settings;
    }
}
