<?php

namespace VE\Modules\Recovery\Workflow;

use VE\Modules\Recovery\Backup\PackageBuilder;
use VE\Modules\Recovery\Backup\PackageValidator;
use VE\Modules\Recovery\Restore\FileRestoreStager;
use VE\Modules\Recovery\Restore\PackageLocator;
use VE\Modules\Recovery\Restore\RestorePreparation;
use VE\Modules\Recovery\Restore\SQLTemporaryImporter;
use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class StagingCloneBuilder {
    public function create( string $snapshot_key = '', string $passphrase = '' ): array {
        if ( '' === $snapshot_key ) {
            $package = ( new PackageBuilder() )->create( 'Staging source package ' . current_time( 'mysql' ) );
            $snapshot_key = (string) ( $package['snapshot_key'] ?? '' );
        }
        if ( '' === $snapshot_key ) {
            return [ 'ok' => false, 'message' => 'No source package is available for staging clone.' ];
        }

        $validation = ( new PackageValidator() )->validate_snapshot( $snapshot_key, $passphrase );
        if ( empty( $validation['ok'] ) ) {
            return [ 'ok' => false, 'message' => 'Staging clone blocked because package validation failed.', 'validation' => $validation ];
        }

        $prep = ( new RestorePreparation() )->prepare( $snapshot_key );
        $workspace = $prep['workspace'] ?? [];
        $token = strtolower( wp_generate_password( 6, false, false ) );
        $staging_slug = 'restorebase-staging-' . $token;
        $staging_dir = trailingslashit( ABSPATH ) . $staging_slug . '/';
        $staging_url = trailingslashit( home_url( '/' . $staging_slug ) );

        if ( ! wp_mkdir_p( $staging_dir ) ) {
            return [ 'ok' => false, 'message' => 'Could not create staging folder.', 'path' => $staging_dir ];
        }

        $files_zip = $this->restore_files_archive_path( $workspace );
        $stage = ( new FileRestoreStager() )->stage( $files_zip, [ 'files' => $staging_dir ] );
        $sql_path = trailingslashit( (string) ( $workspace['extracted'] ?? '' ) ) . 'database.sql';
        $plan = $prep['sql_import_plan'] ?? [];
        $import = ( new SQLTemporaryImporter() )->import( $sql_path, $plan, 'stage' . $token );
        $prefix = $this->infer_stage_prefix( $import );
        $config = $this->write_wp_config( $staging_dir, $prefix, $staging_url );
        $this->write_staging_htaccess( $staging_dir );
        $descriptor = [
            'created_at' => current_time( 'mysql' ),
            'snapshot_key' => $snapshot_key,
            'staging_slug' => $staging_slug,
            'staging_url' => $staging_url,
            'staging_dir' => $staging_dir,
            'table_prefix' => $prefix,
            'package_validation' => $validation,
            'files' => $stage,
            'database_import' => $import,
            'wp_config' => $config,
            'indexing_blocked' => true,
        ];
        LocalStorage::write_json_file( LocalStorage::logs_dir() . 'staging-' . $token . '.json', $descriptor, 'Staging descriptor' );
        Logger::warning( 'staging_clone_created', 'RestoreBase staging clone created.', [ 'url' => $staging_url, 'snapshot_key' => $snapshot_key ] );
        return [ 'ok' => ! empty( $stage['ok'] ) && ! empty( $import['ok'] ) && ! empty( $config['ok'] ), 'message' => 'Staging clone created.', 'staging_url' => $staging_url, 'staging_dir' => $staging_dir, 'table_prefix' => $prefix, 'descriptor' => $descriptor ];
    }

    private function infer_stage_prefix( array $import ): string {
        $map = isset( $import['map'] ) && is_array( $import['map'] ) ? $import['map'] : [];
        foreach ( $map as $entry ) {
            $temp = (string) ( $entry['temp'] ?? '' );
            if ( false !== strpos( $temp, 'options' ) ) {
                return substr( $temp, 0, -7 );
            }
        }
        global $wpdb;
        return $wpdb->prefix . 'rbtmp_stage_';
    }

    private function write_wp_config( string $dir, string $prefix, string $url ): array {
        $constants = [ 'DB_NAME', 'DB_USER', 'DB_PASSWORD', 'DB_HOST', 'DB_CHARSET', 'DB_COLLATE' ];
        $lines = [ "<?php", "define('WP_CACHE', false);" ];
        foreach ( $constants as $constant ) {
            if ( defined( $constant ) ) {
                $lines[] = "define('" . $constant . "', " . var_export( constant( $constant ), true ) . ");";
            }
        }
        $lines[] = "\$table_prefix = " . var_export( $prefix, true ) . ";";
        $lines[] = "define('WP_HOME', " . var_export( untrailingslashit( $url ), true ) . ");";
        $lines[] = "define('WP_SITEURL', " . var_export( untrailingslashit( $url ), true ) . ");";
        $lines[] = "define('DISALLOW_FILE_EDIT', true);";
        $lines[] = "if ( ! defined('ABSPATH') ) { define('ABSPATH', __DIR__ . '/'); }";
        $lines[] = "require_once ABSPATH . 'wp-settings.php';";
        $path = trailingslashit( $dir ) . 'wp-config.php';
        $ok = false !== file_put_contents( $path, implode( "\n", $lines ) . "\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
        return [ 'ok' => $ok, 'path' => $path ];
    }

    private function write_staging_htaccess( string $dir ): void {
        file_put_contents( trailingslashit( $dir ) . '.htaccess', "Options -Indexes\n<IfModule mod_headers.c>\nHeader set X-Robots-Tag \"noindex,nofollow\"\n</IfModule>\n" ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
    }

    private function restore_files_archive_path( array $workspace ): string {
        $base = trailingslashit( (string) ( $workspace['extracted'] ?? '' ) );
        $bundle = $base . 'files.restorebase';
        if ( is_readable( $bundle ) ) {
            return $bundle;
        }
        return $base . 'files.zip';
    }
}
