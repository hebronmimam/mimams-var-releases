<?php

namespace VE\Modules\Recovery\Workflow;

use VE\Modules\Recovery\Backup\SiteScanner;

defined( 'ABSPATH' ) || exit;

final class MigrationPlanner {
    public function plan(): array {
        $site = ( new SiteScanner() )->scan();
        return [
            'ok' => true,
            'message' => 'Restore workflow is active. Use Backup to create a portable file, then import it on another site.',
            'source' => [
                'url' => $site['site']['url'] ?? site_url(),
                'home' => $site['site']['home'] ?? home_url(),
                'table_prefix' => $site['database']['table_prefix'] ?? '',
            ],
            'enabled_actions' => [ 'create_migration_bundle', 'destination_preflight_by_path', 'domain_rewrite_plan', 'post_migration_verification' ],
            'destination_steps' => [ 'Install RestoreBase on the new site', 'Upload backup into RestoreBase', 'Run validate and preview', 'Verify the restored site' ],
        ];
    }
}
