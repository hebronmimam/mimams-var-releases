<?php

namespace VE\Modules\Recovery\Workflow;

use VE\Modules\Recovery\Backup\SiteScanner;

defined( 'ABSPATH' ) || exit;

final class StagingWorkflow {
    public function plan(): array {
        $site = ( new SiteScanner() )->scan();
        $env = function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'production';
        return [
            'ok' => true,
            'message' => 'Staging workflow is active. Use Create Staging Clone to build a staging copy from the selected package.',
            'environment' => $env,
            'site' => [
                'url' => $site['site']['url'] ?? site_url(),
                'home' => $site['site']['home'] ?? home_url(),
            ],
            'enabled_actions' => [ 'create_staging_clone', 'block_indexing', 'staging_database_prefix', 'staging_files_copy' ],
            'limits' => [ 'file-only push is safest first', 'database push requires WooCommerce safety checks' ],
        ];
    }
}
