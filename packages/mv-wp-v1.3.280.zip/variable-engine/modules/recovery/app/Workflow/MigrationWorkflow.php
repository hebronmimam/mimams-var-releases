<?php

namespace VE\Modules\Recovery\Workflow;

use VE\Modules\Recovery\Backup\PackageBuilder;
use VE\Modules\Recovery\Database\Schema;
use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class MigrationWorkflow {
    public function create_bundle( string $source_snapshot_key = '' ): array {
        if ( '' === $source_snapshot_key ) {
            $package = ( new PackageBuilder() )->create( 'Backup source ' . current_time( 'mysql' ) );
            $source_snapshot_key = (string) ( $package['snapshot_key'] ?? '' );
        }

        $source_row = $this->snapshot_row( $source_snapshot_key );
        if ( ! $source_row ) {
            return [ 'ok' => false, 'message' => 'No source backup package was available for migration export.' ];
        }

        $source_meta = $this->decode_json( (string) ( $source_row['meta_json'] ?? '' ) );
        $source_package_path = ! empty( $source_meta['package_path'] ) ? (string) $source_meta['package_path'] : '';
        if ( '' === $source_package_path || ! is_readable( $source_package_path ) ) {
            return [ 'ok' => false, 'message' => 'Source backup file is missing. Create a backup first.' ];
        }

        $migration_key = $this->generate_key();
        $safe_key = sanitize_file_name( $migration_key );
        $dir = LocalStorage::base_dir() . 'migration-bundles/';
        LocalStorage::protect_dir( $dir );

        $target = $dir . 'restorebase-migration-' . $safe_key . '.zip';
        $copied = @copy( $source_package_path, $target ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

        $manifest_path = LocalStorage::manifest_dir() . $safe_key . '.json';
        LocalStorage::protect_dir( LocalStorage::manifest_dir() );
        $source_manifest = (string) ( $source_row['manifest_path'] ?? '' );
        if ( is_readable( $source_manifest ) ) {
            @copy( $source_manifest, $manifest_path ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        }

        $descriptor = [
            'created_at'          => current_time( 'mysql' ),
            'source_url'          => site_url(),
            'source_home'         => home_url(),
            'source_snapshot_key' => $source_snapshot_key,
            'migration_key'       => $migration_key,
            'bundle_path'         => $target,
            'bundle_hash'         => is_readable( $target ) ? hash_file( 'sha256', $target ) : '',
            'bundle_size'         => is_readable( $target ) ? filesize( $target ) : 0,
            'destination_steps'   => [ 'Install RestoreBase on the new site.', 'Import the backup.', 'Validate the imported backup.', 'Preview restore changes.', 'Run dry-run, then restore after checks pass.' ],
        ];
        $descriptor_path = $dir . 'restorebase-migration-' . $safe_key . '.json';
        LocalStorage::write_json_file( $descriptor_path, $descriptor, 'Backup restore descriptor' );

        $meta = [
            'package_version'      => 'migration-1.0',
            'package_message'      => $copied ? 'Backup file prepared for restore on another site.' : 'Backup file copy failed.',
            'package_path'         => $target,
            'package_hash'         => is_readable( $target ) ? (string) hash_file( 'sha256', $target ) : '',
            'package_size'         => is_readable( $target ) ? (int) filesize( $target ) : 0,
            'migration_bundle'     => true,
            'source_snapshot_key'  => $source_snapshot_key,
            'source_package_path'  => $source_package_path,
            'source_site_url'      => site_url(),
            'source_home_url'      => home_url(),
            'descriptor_path'      => $descriptor_path,
            'descriptor'           => $descriptor,
            'contents'             => isset( $source_meta['contents'] ) && is_array( $source_meta['contents'] ) ? $source_meta['contents'] : [],
        ];

        global $wpdb;
        $wpdb->insert(
            Schema::table( 'snapshots' ),
            [
                'snapshot_key'  => $migration_key,
                'label'         => 'Backup ' . current_time( 'mysql' ),
                'trigger_type'  => 'migration_bundle',
                'status'        => $copied ? 'completed' : 'failed',
                'manifest_path' => $manifest_path,
                'manifest_hash' => is_readable( $manifest_path ) ? (string) hash_file( 'sha256', $manifest_path ) : '',
                'size_bytes'    => (int) $meta['package_size'],
                'meta_json'     => wp_json_encode( $meta ),
                'created_by'    => get_current_user_id(),
                'created_at'    => current_time( 'mysql' ),
                'updated_at'    => current_time( 'mysql' ),
            ],
            [ '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%d', '%s', '%s' ]
        );

        Logger::info( 'migration_bundle_created', 'RestoreBase backup prepared for restore.', [
            'snapshot_key'        => $migration_key,
            'source_snapshot_key' => $source_snapshot_key,
            'ok'                  => $copied,
        ] );

        return [
            'ok'                  => (bool) $copied,
            'message'             => $copied ? 'Backup created. Download this file and import it on the new site to restore.' : 'Backup file copy failed.',
            'snapshot_key'        => $migration_key,
            'source_snapshot_key' => $source_snapshot_key,
            'bundle_path'         => $target,
            'size'                => is_readable( $target ) ? filesize( $target ) : 0,
            'download_url'        => $this->download_url( $migration_key ),
            'descriptor'          => $descriptor,
        ];
    }

    public function plan_import_from_path( string $path ): array {
        $path = wp_normalize_path( $path );
        $base = wp_normalize_path( LocalStorage::base_dir() );
        if ( 0 !== strpos( $path, $base ) || ! is_readable( $path ) ) {
            return [ 'ok' => false, 'message' => 'Backup import path must point to a readable file inside RestoreBase storage.' ];
        }
        return [ 'ok' => true, 'message' => 'Backup is readable. Restore preflight can continue.', 'path' => $path, 'hash' => hash_file( 'sha256', $path ), 'size' => filesize( $path ) ];
    }

    private function download_url( string $snapshot_key ): string {
        return add_query_arg(
            [
                'action'       => 'restorebase_download_package',
                'snapshot_key' => $snapshot_key,
                '_wpnonce'     => wp_create_nonce( 'restorebase_download_' . $snapshot_key ),
            ],
            admin_url( 'admin-post.php' )
        );
    }

    private function snapshot_row( string $snapshot_key ): ?array {
        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . Schema::table( 'snapshots' ) . " WHERE snapshot_key = %s LIMIT 1", $snapshot_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        return is_array( $row ) ? $row : null;
    }

    private function decode_json( string $json ): array {
        $decoded = json_decode( $json, true );
        return is_array( $decoded ) ? $decoded : [];
    }

    private function generate_key(): string {
        return 'rbm-' . gmdate( 'Ymd-His' ) . '-' . wp_generate_password( 8, false, false );
    }
}
