<?php

namespace VE\API;

use VE\Core\ThemeManager;

defined( 'ABSPATH' ) || exit;

/**
 * @deprecated Serves the legacy `/palettes` REST route, which returns THEMES.
 *
 * Nothing in the product calls it: MV's own UI uses `/themes` (and `/color-palettes`
 * for the unrelated colour palette system), and the Figma plugin never requests it.
 * It is kept only in case an external consumer exists. Every hit is logged; if the
 * log stays empty across a release or two, delete the route, this controller and
 * {@see \VE\Core\PaletteManager}.
 *
 * `/palettes` returning themes while `/color-palettes` returns colour palettes is
 * the single most confusable pair of names in the API. Do not build on it.
 */
class PaletteController {

    private ThemeManager $manager;

    public function __construct() {
        $this->manager = new ThemeManager();
        // Deprecated surface: record that something still calls it, so the decision
        // to delete it later rests on evidence rather than assumption.
        if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
            error_log( 'Mimams Var: deprecated /palettes route called; it returns themes, not colour palettes. Use /themes.' );
        }
    }

    public function list_palettes(): \WP_REST_Response {
        return new \WP_REST_Response( $this->manager->list(), 200 );
    }

    public function create_palette( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $result = $this->manager->create( (string) ( $data['name'] ?? '' ), isset( $data['source_slug'] ) ? (string) $data['source_slug'] : null );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 201 );
    }

    public function update_palette( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $result = $this->manager->rename( sanitize_key( (string) $request->get_param( 'slug' ) ), (string) ( $data['name'] ?? '' ) );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 200 );
    }

    public function delete_palette( \WP_REST_Request $request ) {
        $result = $this->manager->delete( sanitize_key( (string) $request->get_param( 'slug' ) ) );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( [ 'deleted' => true ], 200 );
    }

    public function activate_palette( \WP_REST_Request $request ) {
        $result = $this->manager->activate( sanitize_key( (string) $request->get_param( 'slug' ) ) );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 200 );
    }

    public function duplicate_palette( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $result = $this->manager->duplicate(
            sanitize_key( (string) $request->get_param( 'slug' ) ),
            (string) ( $data['name'] ?? '' )
        );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 201 );
    }
}
