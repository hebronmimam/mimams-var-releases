<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * @deprecated Use {@see ThemeManager}.
 *
 * This class manages THEMES (alternate value layers), not colour palettes — the
 * name is historical, from v1.3.05. It survives only for the deprecated
 * `/palettes` route; every other caller already uses ThemeManager. Do not use it
 * in new code, and do not confuse it with {@see ColorPaletteManager}, which is
 * the real colour palette system.
 */
class PaletteManager extends ThemeManager {
}
