<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

class VariableUsageManager {

    public function inspect( array $variable ): array {
        $id       = (int) ( $variable['id'] ?? 0 );
        $name     = (string) ( $variable['name'] ?? '' );
        $css_name = ( new VariableManager() )->to_css_name( $name );
        $groups   = [
            'aliases'    => [],
            'themes'     => [],
            'css_studio' => [],
            'bricks_saved' => [],
            'wordpress'  => [],
        ];

        foreach ( ( new DependencyGraph() )->get_dependents( $id ) as $dependent ) {
            if ( 'alias' !== (string) ( $dependent['type'] ?? '' ) && 'alias' !== (string) ( $dependent['relation'] ?? '' ) ) {
                continue;
            }
            $groups['aliases'][] = [
                'type'    => 'variable',
                'id'      => (int) ( $dependent['id'] ?? 0 ),
                'name'    => (string) ( $dependent['name'] ?? '' ),
                'label'   => (string) ( $dependent['name'] ?? '' ),
                'matches' => 1,
            ];
        }

        // `ve_color_palettes` stores THEMES (value layers), not colour palettes. The name is
        // historical (v1.3.05) and was never migrated. Colour palettes live in the
        // `color_palettes` tables, owned by ColorPaletteManager. See core/ThemeManager.php.
        $themes = get_option( 've_color_palettes', [] );
        if ( is_array( $themes ) ) {
            foreach ( $themes as $slug => $theme ) {
                $values = isset( $theme['values'] ) && is_array( $theme['values'] ) ? $theme['values'] : [];
                if ( ! array_key_exists( $name, $values ) ) {
                    continue;
                }
                $groups['themes'][] = [
                    'type'    => 'theme',
                    'id'      => sanitize_key( (string) $slug ),
                    'name'    => (string) ( $theme['name'] ?? $slug ),
                    'label'   => (string) ( $theme['name'] ?? $slug ),
                    'matches' => 1,
                ];
            }
        }

        $advanced_css = ( new AdvancedCssManager() )->get();
        foreach ( (array) ( $advanced_css['stylesheets'] ?? [] ) as $sheet ) {
            $css = (string) ( $sheet['css'] ?? '' );
            $matches = $this->count_token( $css, $css_name );
            if ( $matches < 1 ) {
                continue;
            }
            $groups['css_studio'][] = [
                'type'    => 'css_studio',
                'id'      => (string) ( $sheet['id'] ?? '' ),
                'name'    => (string) ( $sheet['name'] ?? $sheet['id'] ?? 'Stylesheet' ),
                'label'   => (string) ( $sheet['name'] ?? $sheet['id'] ?? 'Stylesheet' ),
                'matches' => $matches,
            ];
        }

        if ( $css_name ) {
            $sentinel = '--ve-usage-preview-' . $id;
            $storage  = ( new RenamePropagationManager( [
                [ 'old' => $css_name, 'new' => $sentinel ],
            ] ) )->preview();
            foreach ( (array) ( $storage['locations'] ?? [] ) as $location ) {
                if ( $this->is_definition_registry( $location ) ) {
                    continue;
                }
                $group = $this->is_bricks_storage( $location ) ? 'bricks_saved' : 'wordpress';
                $label = $this->storage_label( $location, $group );
                $groups[ $group ][] = [
                    'type'    => (string) ( $location['type'] ?? 'wordpress' ),
                    'id'      => (int) ( $location['id'] ?? 0 ),
                    'name'    => $label,
                    'label'   => $label,
                    'matches' => max( 1, (int) ( $location['matches'] ?? 1 ) ),
                    'note'    => (string) ( $location['note'] ?? '' ),
                ];
            }
        }

        $total = 0;
        foreach ( $groups as $items ) {
            foreach ( $items as $item ) {
                $total += max( 1, (int) ( $item['matches'] ?? 1 ) );
            }
        }

        return [
            'variable' => [
                'id'       => $id,
                'name'     => $name,
                'css_name' => $css_name,
                'type'     => (string) ( $variable['type'] ?? 'base' ),
            ],
            'groups'   => $groups,
            'total'    => $total,
            'unused'   => 0 === $total,
        ];
    }

    private function count_token( string $content, string $css_name ): int {
        if ( '' === $content || '' === $css_name ) {
            return 0;
        }
        preg_match_all(
            '/(?<![A-Za-z0-9_-])' . preg_quote( $css_name, '/' ) . '(?![A-Za-z0-9_-])/',
            $content,
            $matches
        );
        return count( $matches[0] ?? [] );
    }

    private function is_definition_registry( array $location ): bool {
        $option = strtolower( (string) ( $location['option_name'] ?? '' ) );
        return in_array( $option, [ 'bricks_global_variables', '_bricks_global_variables' ], true );
    }

    private function is_bricks_storage( array $location ): bool {
        $meta_key = strtolower( (string) ( $location['meta_key'] ?? '' ) );
        $option   = strtolower( (string) ( $location['option_name'] ?? '' ) );
        return false !== strpos( $meta_key, 'bricks' ) || false !== strpos( $option, 'bricks' );
    }

    private function storage_label( array $location, string $group ): string {
        $post_id = (int) ( $location['post_id'] ?? 0 );
        if ( $post_id > 0 ) {
            $title = trim( wp_strip_all_tags( (string) get_the_title( $post_id ) ) );
            return ( $title ?: 'Untitled' ) . ' · Post #' . $post_id;
        }

        $option = (string) ( $location['option_name'] ?? '' );
        if ( $option ) {
            return 'bricks_saved' === $group
                ? 'Bricks site settings'
                : ucwords( str_replace( [ '_', '-' ], ' ', trim( $option, '_' ) ) );
        }

        return (string) ( $location['label'] ?? ( 'bricks_saved' === $group ? 'Saved Bricks content' : 'WordPress storage' ) );
    }
}
