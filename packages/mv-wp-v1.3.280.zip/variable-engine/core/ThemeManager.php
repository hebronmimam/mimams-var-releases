<?php

namespace VE\Core;

use VE\Core\Generators\ColorGenerator;
use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Theme value layers — alternate values for the same token names.
 *
 * STORAGE NAMING, READ THIS BEFORE TOUCHING IT:
 * this class stores themes in the options `ve_color_palettes` and
 * `ve_active_color_palette`. Those names are historical — the option shipped in
 * v1.3.05 when the feature was called "color palettes" and was never migrated.
 * `ve_color_palettes` does NOT hold colour palettes.
 *
 * Colour palettes are a different system entirely: tables `color_palettes` and
 * `color_palette_members`, owned by {@see ColorPaletteManager}, served by the
 * `/color-palettes` route. This class is served by `/themes`.
 *
 * The two were conflated once already, in an approved design note that told
 * implementers to mirror `ve_color_palettes` into Bricks' colour palettes — i.e.
 * themes into palettes. `tests/check-naming.php` now fails on that mistake.
 *
 * @see ColorPaletteManager for colour palettes.
 */
class ThemeManager {

    private const OPTION = 've_color_palettes';
    private const ACTIVE_OPTION = 've_active_color_palette';
    public const DEFAULT_SLUG = 'default';

    public function active_slug(): string {
        $slug = sanitize_key( (string) get_option( self::ACTIVE_OPTION, self::DEFAULT_SLUG ) );
        return self::DEFAULT_SLUG === $slug || isset( $this->stored()[ $slug ] ) ? $slug : self::DEFAULT_SLUG;
    }

    public function is_custom_active(): bool {
        return self::DEFAULT_SLUG !== $this->active_slug();
    }

    public function list(): array {
        $active = $this->active_slug();
        $palettes = [
            [
                'slug'       => self::DEFAULT_SLUG,
                'name'       => 'Default',
                'active'     => self::DEFAULT_SLUG === $active,
                'protected'  => true,
                'value_count'=> 0,
            ],
        ];

        foreach ( $this->stored() as $slug => $palette ) {
            $palettes[] = [
                'slug'        => $slug,
                'name'        => (string) ( $palette['name'] ?? $this->humanize( $slug ) ),
                'active'      => $slug === $active,
                'protected'   => false,
                'value_count' => count( $palette['values'] ?? [] ),
                'created_at'  => (string) ( $palette['created_at'] ?? '' ),
                'updated_at'  => (string) ( $palette['updated_at'] ?? '' ),
            ];
        }

        return [ 'active' => $active, 'palettes' => $palettes ];
    }

    public function create( string $name, ?string $source_slug = null ) {
        $name = sanitize_text_field( $name );
        if ( '' === $name ) {
            return new \WP_Error( 've_palette_name_required', 'Enter a theme name.', [ 'status' => 400 ] );
        }

        $palettes = $this->stored();
        $slug = $this->unique_slug( $name, $palettes );
        $values = $this->values_for_source( $source_slug ?: $this->active_slug() );
        $now = current_time( 'mysql' );
        $palettes[ $slug ] = [
            'name'       => $name,
            'values'     => $values,
            'created_at' => $now,
            'updated_at' => $now,
        ];

        if ( ! update_option( self::OPTION, $palettes, false ) ) {
            return new \WP_Error( 've_palette_create_failed', 'Could not create the theme.', [ 'status' => 500 ] );
        }

        return [ 'slug' => $slug, 'name' => $name, 'value_count' => count( $values ) ];
    }

    public function duplicate( string $slug, string $name = '' ) {
        $source = $this->get( $slug );
        if ( ! $source ) {
            return new \WP_Error( 've_palette_not_found', 'Theme not found.', [ 'status' => 404 ] );
        }

        $source_name = self::DEFAULT_SLUG === $slug ? 'Default' : (string) ( $source['name'] ?? $this->humanize( $slug ) );
        return $this->create( $name ?: $source_name . ' Copy', $slug );
    }

    public function rename( string $slug, string $name ) {
        if ( self::DEFAULT_SLUG === $slug ) {
            return new \WP_Error( 've_palette_protected', 'The Default theme cannot be renamed.', [ 'status' => 400 ] );
        }

        $palettes = $this->stored();
        if ( ! isset( $palettes[ $slug ] ) ) {
            return new \WP_Error( 've_palette_not_found', 'Theme not found.', [ 'status' => 404 ] );
        }
        $name = sanitize_text_field( $name );
        if ( '' === $name ) {
            return new \WP_Error( 've_palette_name_required', 'Enter a theme name.', [ 'status' => 400 ] );
        }

        $palettes[ $slug ]['name'] = $name;
        $palettes[ $slug ]['updated_at'] = current_time( 'mysql' );
        if ( ! update_option( self::OPTION, $palettes, false ) ) {
            return new \WP_Error( 've_palette_rename_failed', 'Could not rename the theme.', [ 'status' => 500 ] );
        }

        return [ 'slug' => $slug, 'name' => $name ];
    }

    public function delete( string $slug ) {
        if ( self::DEFAULT_SLUG === $slug ) {
            return new \WP_Error( 've_palette_protected', 'The Default theme cannot be deleted.', [ 'status' => 400 ] );
        }
        $palettes = $this->stored();
        if ( ! isset( $palettes[ $slug ] ) ) {
            return new \WP_Error( 've_palette_not_found', 'Theme not found.', [ 'status' => 404 ] );
        }

        $was_active = $this->active_slug() === $slug;
        unset( $palettes[ $slug ] );
        if ( ! update_option( self::OPTION, $palettes, false ) ) {
            return new \WP_Error( 've_palette_delete_failed', 'Could not delete the theme.', [ 'status' => 500 ] );
        }
        if ( $was_active ) {
            update_option( self::ACTIVE_OPTION, self::DEFAULT_SLUG, false );
            if ( ! ( new CssExporter() )->export() ) {
                return new \WP_Error( 've_palette_css_failed', 'Theme deleted, but generated CSS could not be refreshed.', [ 'status' => 500 ] );
            }
        }

        return true;
    }

    public function activate( string $slug ) {
        if ( self::DEFAULT_SLUG !== $slug && ! $this->get( $slug ) ) {
            return new \WP_Error( 've_palette_not_found', 'Theme not found.', [ 'status' => 404 ] );
        }
        if ( ! update_option( self::ACTIVE_OPTION, $slug, false ) && $this->active_slug() !== $slug ) {
            return new \WP_Error( 've_palette_activate_failed', 'Could not activate the theme.', [ 'status' => 500 ] );
        }
        if ( ! ( new CssExporter() )->export() ) {
            return new \WP_Error( 've_palette_css_failed', 'Theme changed, but generated CSS could not be refreshed.', [ 'status' => 500 ] );
        }

        return [ 'active' => $slug ];
    }

    public function set_color_value( array $variable, string $value ) {
        $slug = $this->active_slug();
        if ( self::DEFAULT_SLUG === $slug ) {
            return new \WP_Error( 've_palette_default_active', 'The Default theme stores values in the main variable database.', [ 'status' => 409 ] );
        }
        if ( 'color' !== (string) ( $variable['namespace'] ?? '' ) || 'alias' === (string) ( $variable['type'] ?? '' ) ) {
            return new \WP_Error( 've_palette_color_only', 'Only non-alias color values can be overridden by a theme.', [ 'status' => 400 ] );
        }

        $palettes = $this->stored();
        if ( ! isset( $palettes[ $slug ] ) ) {
            return new \WP_Error( 've_palette_not_found', 'Active theme not found.', [ 'status' => 404 ] );
        }
        $value = sanitize_text_field( $value );
        $palettes[ $slug ]['values'][ (string) $variable['name'] ] = $value;

        if ( 'base' === (string) ( $variable['type'] ?? '' ) ) {
            foreach ( $this->generated_colors( $variable, $value ) as $generated ) {
                $palettes[ $slug ]['values'][ $generated['name'] ] = $generated['value'];
            }
        }

        $palettes[ $slug ]['updated_at'] = current_time( 'mysql' );
        if ( ! update_option( self::OPTION, $palettes, false ) ) {
            return new \WP_Error( 've_palette_update_failed', 'Could not update the active theme.', [ 'status' => 500 ] );
        }
        if ( ! ( new CssExporter() )->export() ) {
            return new \WP_Error( 've_palette_css_failed', 'Theme value changed, but generated CSS could not be refreshed.', [ 'status' => 500 ] );
        }

        $effective = $this->apply_to_variables( [ $variable ] );
        return $effective[0] ?? $variable;
    }

    public function apply_to_variables( array $variables, ?string $slug = null ): array {
        $slug = null === $slug ? $this->active_slug() : sanitize_key( $slug );
        if ( self::DEFAULT_SLUG === $slug ) {
            return $variables;
        }

        $palette = $this->get( $slug );
        $values = is_array( $palette['values'] ?? null ) ? $palette['values'] : [];
        foreach ( $variables as &$variable ) {
            $name = (string) ( $variable['name'] ?? '' );
            if ( 'color' !== (string) ( $variable['namespace'] ?? '' ) || 'alias' === (string) ( $variable['type'] ?? '' ) || ! array_key_exists( $name, $values ) ) {
                continue;
            }
            $variable['value'] = (string) $values[ $name ];
            $variable['css_value'] = (string) $values[ $name ];
            $variable['palette_override'] = true;
            $variable['palette_slug'] = $slug;
        }
        unset( $variable );

        return $variables;
    }

    public function rename_variable( string $old_name, string $new_name ): void {
        $palettes = $this->stored();
        $changed = false;
        foreach ( $palettes as &$palette ) {
            $values = is_array( $palette['values'] ?? null ) ? $palette['values'] : [];
            foreach ( array_keys( $values ) as $name ) {
                if ( $name !== $old_name && 0 !== strpos( $name, $old_name . '.' ) ) {
                    continue;
                }
                $renamed = $new_name . substr( $name, strlen( $old_name ) );
                $palette['values'][ $renamed ] = $palette['values'][ $name ];
                unset( $palette['values'][ $name ] );
                $changed = true;
            }
        }
        unset( $palette );
        if ( $changed ) {
            update_option( self::OPTION, $palettes, false );
        }
    }

    public function delete_variable( string $name ): void {
        $palettes = $this->stored();
        $changed = false;
        foreach ( $palettes as &$palette ) {
            $values = is_array( $palette['values'] ?? null ) ? $palette['values'] : [];
            foreach ( array_keys( $values ) as $stored_name ) {
                if ( $stored_name === $name || 0 === strpos( $stored_name, $name . '.' ) ) {
                    unset( $palette['values'][ $stored_name ] );
                    $changed = true;
                }
            }
        }
        unset( $palette );
        if ( $changed ) {
            update_option( self::OPTION, $palettes, false );
        }
    }

    private function get( string $slug ): ?array {
        if ( self::DEFAULT_SLUG === $slug ) {
            return [ 'name' => 'Default', 'values' => $this->capture_values( ( new VariableManager() )->get_all() ) ];
        }
        $palettes = $this->stored();
        return isset( $palettes[ $slug ] ) && is_array( $palettes[ $slug ] ) ? $palettes[ $slug ] : null;
    }

    private function values_for_source( string $slug ): array {
        if ( self::DEFAULT_SLUG === $slug ) {
            return $this->capture_values( ( new VariableManager() )->get_all() );
        }
        $palette = $this->get( $slug );
        return is_array( $palette['values'] ?? null ) ? $palette['values'] : [];
    }

    private function capture_values( array $variables ): array {
        $values = [];
        foreach ( $variables as $variable ) {
            if ( 'color' !== (string) ( $variable['namespace'] ?? '' ) || 'alias' === (string) ( $variable['type'] ?? '' ) ) {
                continue;
            }
            $values[ (string) $variable['name'] ] = (string) ( $variable['css_value'] ?: $variable['value'] );
        }
        ksort( $values, SORT_NATURAL );
        return $values;
    }

    private function generated_colors( array $variable, string $value ): array {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT config FROM ' . Schema::table( 'generators' ) . ' WHERE variable_id = %d AND type = %s AND active = 1 ORDER BY id DESC LIMIT 1',
                (int) ( $variable['id'] ?? 0 ),
                'color'
            ),
            ARRAY_A
        );
        if ( ! $row ) {
            return [];
        }
        $config = json_decode( (string) ( $row['config'] ?? '{}' ), true );
        $base = $variable;
        $base['value'] = $value;
        return ( new ColorGenerator() )->generate( $base, is_array( $config ) ? $config : [] );
    }

    private function stored(): array {
        $palettes = get_option( self::OPTION, [] );
        return is_array( $palettes ) ? $palettes : [];
    }

    private function unique_slug( string $name, array $palettes ): string {
        $base = sanitize_key( str_replace( ' ', '-', strtolower( $name ) ) );
        $base = trim( preg_replace( '/-+/', '-', $base ), '-' );
        if ( '' === $base || self::DEFAULT_SLUG === $base ) {
            $base = 'palette';
        }
        $slug = $base;
        $index = 2;
        while ( isset( $palettes[ $slug ] ) ) {
            $slug = $base . '-' . $index;
            $index++;
        }
        return $slug;
    }

    private function humanize( string $slug ): string {
        return ucwords( trim( str_replace( [ '-', '_' ], ' ', $slug ) ) );
    }


    /**
     * Copy a variable's custom-theme values to a newly duplicated variable.
     */
    public function copy_variable( string $source_name, string $target_name ): void {
        $themes = get_option( 've_color_palettes', [] );
        if ( ! is_array( $themes ) ) {
            return;
        }

        $changed = false;
        foreach ( $themes as &$theme ) {
            $theme_changed = false;
            $values = isset( $theme['values'] ) && is_array( $theme['values'] ) ? $theme['values'] : [];
            foreach ( $values as $stored_name => $stored_value ) {
                if ( $stored_name !== $source_name && 0 !== strpos( $stored_name, $source_name . '.' ) ) {
                    continue;
                }
                $copied_name = $target_name . substr( $stored_name, strlen( $source_name ) );
                $theme['values'][ $copied_name ] = $stored_value;
                $theme_changed = true;
                $changed = true;
            }
            if ( $theme_changed ) {
                $theme['updated_at'] = current_time( 'mysql' );
            }
        }
        unset( $theme );

        if ( $changed ) {
            update_option( 've_color_palettes', $themes, false );
        }
    }

    public function snapshot_state(): array {
        $themes = get_option( 've_color_palettes', [] );
        return [
            'items'  => is_array( $themes ) ? $themes : [],
            'active' => $this->active_slug(),
        ];
    }

    public function restore_snapshot_state( array $state ): bool {
        $items = isset( $state['items'] ) && is_array( $state['items'] ) ? $state['items'] : [];
        $active = sanitize_key( (string) ( $state['active'] ?? self::DEFAULT_SLUG ) );
        update_option( 've_color_palettes', $items, false );
        update_option( 've_active_color_palette', $active ?: self::DEFAULT_SLUG, false );
        return true;
    }
}
