<?php
namespace VE\Adapters;
defined('ABSPATH') || exit;

class AdminAdapter {
    public function __construct() {
        if (defined('VE_IS_BRICKS') && VE_IS_BRICKS) return;
        if (!is_admin()) return;
        global $pagenow;
        if (in_array($pagenow, ['update.php', 'update-core.php'])) return;
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
    }
    public function enqueue(): void {
        if (!current_user_can('manage_options')) return;
        // All runtime vendor assets are bundled with the plugin, not loaded from a CDN, so
        // the builder works offline, under strict CSP, and on privacy-strict hosts. GSAP was
        // enqueued but never referenced by the panel; it has been removed.
        $ver = VE_VERSION;
        wp_enqueue_style('ve-ph', VE_URL.'assets/phosphor/style.css', [], $ver.'.'.filemtime(VE_DIR.'assets/phosphor/style.css'));
        wp_enqueue_style('ve-components', VE_URL.'assets/components.css', [], $ver.'.'.filemtime(VE_DIR.'assets/components.css'));
        wp_enqueue_style('ve-codemirror', VE_URL.'assets/vendor/codemirror/codemirror.css', [], '5.65.16');
        wp_enqueue_style('ve-codemirror-hint', VE_URL.'assets/vendor/codemirror/show-hint.css', ['ve-codemirror'], '5.65.16');
        // Neutralize CodeMirror 5's unscoped light defaults so MV's globally loaded editor CSS
        // does not bleed a white background into other plugins' editors. MV's own editors
        // override this via the more specific `.ve-cm-host` rules.
        wp_add_inline_style('ve-codemirror', '.CodeMirror{background:transparent;color:inherit}.CodeMirror-gutters{background:transparent}');
        wp_enqueue_script('ve-p', VE_URL.'assets/vendor/preact.umd.js', [], '10', true);
        wp_enqueue_script('ve-ph', VE_URL.'assets/vendor/preact-hooks.umd.js', ['ve-p'], '10', true);
        wp_enqueue_script('ve-codemirror', VE_URL.'assets/vendor/codemirror/codemirror.js', [], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-css', VE_URL.'assets/vendor/codemirror/mode-css.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-closebrackets', VE_URL.'assets/vendor/codemirror/closebrackets.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-hint', VE_URL.'assets/vendor/codemirror/show-hint.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-app', VE_URL.'assets/js/builder-panel.js', ['ve-p','ve-ph','ve-codemirror-css','ve-codemirror-closebrackets','ve-codemirror-hint'], $ver.'.'.filemtime(VE_DIR.'assets/js/builder-panel.js'), true);
        $preferences = get_user_meta( get_current_user_id(), 've_user_preferences', true );
        wp_localize_script('ve-app', 'vePanel', ['apiRoot'=>esc_url_raw(rest_url()),'ajaxUrl'=>esc_url_raw(admin_url('admin-ajax.php')),'nonce'=>wp_create_nonce('wp_rest'),'version'=>VE_VERSION,'mode'=>'admin','siteTitle'=>sanitize_text_field(get_bloginfo('name')),'logoUrl'=>esc_url_raw(VE_URL.'assets/hebronmimam-logo-icon.png'),'assetUrl'=>esc_url_raw(VE_URL.'assets/'),'userPreferences'=>is_array($preferences)?$preferences:[]]);
        if (class_exists('\VE\Modules\BuilderTools\MimamsBarModule')) {
            (new \VE\Modules\BuilderTools\MimamsBarModule())->enqueue('admin');
        }
    }
}
