<?php
namespace VE\Sync;

defined('ABSPATH') || exit;

/**
 * PairingManager — handles pairing between WordPress and Figma.
 *
 * Flow:
 *  1. Either side generates a 6-char pairing code + a permanent API key
 *  2. Code is entered on the other side within 10 minutes
 *  3. The other side calls POST /sync/pair with the code
 *  4. If valid, returns the API key. Both sides store it.
 *  5. All subsequent sync calls use X-VE-Key header instead of WP auth
 *
 * Source of truth:
 *  - If code generated on WordPress → WordPress is source
 *  - If code generated on Figma → Figma is source
 */
class PairingManager {

    private const OPTION_KEY      = 've_sync_api_key';
    private const OPTION_SOURCE   = 've_sync_source';
    private const OPTION_PENDING  = 've_sync_pending_pair';
    private const OPTION_PAIRED   = 've_sync_paired';
    private const OPTION_FIGMA_ID = 've_sync_figma_file';
    private const OPTION_FIGMA_NAME = 've_sync_figma_name';
    private const OPTION_FIGMA_COLLECTION = 've_sync_figma_collection';

    /** Brute-force guards for the public /sync/pair/validate endpoint. */
    private const MAX_CODE_ATTEMPTS = 8;    // wrong guesses that burn a pending code
    private const MAX_IP_ATTEMPTS   = 12;   // validation attempts per IP per window
    private const ATTEMPT_WINDOW    = 600;  // seconds (matches the code's 10-min life)

    /**
     * Generate a pairing code from WordPress side.
     * WordPress becomes the source of truth.
     *
     * @return array { code: string, expires: int }
     */
    public function generate_code_from_wp(): array {
        $code = strtoupper( substr( bin2hex( random_bytes(3) ), 0, 6 ) );
        $api_key = 've_' . bin2hex( random_bytes(24) );

        $pending = [
            'code'       => $code,
            'api_key'    => $api_key,
            'source'     => 'wordpress',
            'expires_at' => time() + 600,
        ];
        update_option( self::OPTION_PENDING, $pending );
        // Also pre-store the key so it's ready when pairing completes.
        update_option( self::OPTION_KEY, $api_key );

        return [
            'code'    => $code,
            'api_key' => $api_key,
            'expires' => 600,
        ];
    }

    /**
     * Validate a pairing code and complete the pairing.
     * Called by the Figma plugin with a code generated on WP,
     * OR by WP with a code generated on Figma.
     *
     * @param string $code The 6-char pairing code
     * @param string $origin 'figma' or 'wordpress' — who is calling this
     * @param array  $meta   Optional metadata (figma_file_key, etc.)
     * @return array|false { api_key, source } or false
     */
    public function validate_code( string $code, string $origin = 'figma', array $meta = [] ) {
        // Brute-force guard. /sync/pair/validate is intentionally public (the code is the
        // auth), so an unthrottled 6-char code could be ground out within its 10-minute
        // life. Throttle attempts per IP as defense-in-depth, and — the real cap — burn
        // the pending code after a handful of wrong guesses regardless of source IP, which
        // turns a 16.7M-guess search into an 8-guess one.
        $ip_key = 've_pair_try_' . md5( (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) );
        $ip_tries = (int) get_transient( $ip_key );
        if ( $ip_tries >= self::MAX_IP_ATTEMPTS ) {
            return false;
        }

        $pending = get_option( self::OPTION_PENDING );

        if ( ! $pending || ! is_array( $pending ) ) {
            set_transient( $ip_key, $ip_tries + 1, self::ATTEMPT_WINDOW );
            return false;
        }

        // Check expiry
        if ( time() > ( $pending['expires_at'] ?? 0 ) ) {
            delete_option( self::OPTION_PENDING );
            return false;
        }

        // Timing-safe code comparison; a wrong guess costs the code an attempt.
        $expected = strtoupper( (string) ( $pending['code'] ?? '' ) );
        if ( '' === $expected || ! hash_equals( $expected, strtoupper( $code ) ) ) {
            set_transient( $ip_key, $ip_tries + 1, self::ATTEMPT_WINDOW );
            $failed = (int) ( $pending['attempts'] ?? 0 ) + 1;
            if ( $failed >= self::MAX_CODE_ATTEMPTS ) {
                delete_option( self::OPTION_PENDING ); // burn it — a fresh code must be generated.
            } else {
                $pending['attempts'] = $failed;
                update_option( self::OPTION_PENDING, $pending );
            }
            return false;
        }

        // Correct code — clear the IP throttle before completing the pairing.
        delete_transient( $ip_key );

        $api_key = $pending['api_key'];
        $source  = $pending['source'] ?? 'wordpress';

        // Store the permanent pairing
        update_option( self::OPTION_KEY, $api_key );
        update_option( self::OPTION_SOURCE, $source );
        update_option( self::OPTION_PAIRED, true );

        if ( ! empty( $meta['figma_file_key'] ) ) {
            update_option( self::OPTION_FIGMA_ID, sanitize_text_field( $meta['figma_file_key'] ) );
        }
        if ( ! empty( $meta['figma_file_name'] ) ) {
            update_option( self::OPTION_FIGMA_NAME, sanitize_text_field( $meta['figma_file_name'] ) );
        }
        if ( ! empty( $meta['figma_collection_name'] ) ) {
            update_option( self::OPTION_FIGMA_COLLECTION, sanitize_text_field( $meta['figma_collection_name'] ) );
        }

        // Clear pending
        delete_option( self::OPTION_PENDING );

        return [
            'api_key' => $api_key,
            'source'  => $source,
        ];
    }

    /**
     * Register a pairing code generated by Figma.
     * Called by WP admin when the user enters a Figma-generated code.
     * Figma becomes the source of truth.
     *
     * The Figma plugin generates its own code + key, stores them locally,
     * and also POSTs them to WP so WP can store the pending pair.
     *
     * @param string $code
     * @param string $api_key
     * @return bool
     */
    public function register_figma_code( string $code, string $api_key ): bool {
        update_option( self::OPTION_PENDING, [
            'code'       => strtoupper( $code ),
            'api_key'    => $api_key,
            'source'     => 'figma',
            'expires_at' => time() + 600,
        ] );

        return true;
    }

    /**
     * Validate an API key from a request.
     *
     * @param string $key
     * @return bool
     */
    public function validate_key( string $key ): bool {
        $stored = get_option( self::OPTION_KEY );
        return $stored && hash_equals( $stored, $key );
    }

    /**
     * Check if currently paired.
     */
    public function is_paired(): bool {
        return (bool) get_option( self::OPTION_PAIRED, false );
    }

    /**
     * Get current pairing status.
     */
    public function get_status(): array {
        return [
            'paired'       => $this->is_paired(),
            'source'       => get_option( self::OPTION_SOURCE, '' ),
            'figma_file'   => get_option( self::OPTION_FIGMA_ID, '' ),
            'figma_name'   => get_option( self::OPTION_FIGMA_NAME, '' ),
            'collection_name' => get_option( self::OPTION_FIGMA_COLLECTION, '' ),
            'has_pending'  => (bool) get_option( self::OPTION_PENDING ),
        ];
    }

    /**
     * Disconnect / unpair.
     */
    public function disconnect(): void {
        delete_option( self::OPTION_KEY );
        delete_option( self::OPTION_SOURCE );
        delete_option( self::OPTION_PAIRED );
        delete_option( self::OPTION_PENDING );
        delete_option( self::OPTION_FIGMA_ID );
        delete_option( self::OPTION_FIGMA_NAME );
        delete_option( self::OPTION_FIGMA_COLLECTION );
    }
}
