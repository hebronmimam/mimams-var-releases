(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarGlobalEvents) return;

  function bind(app) {
    if (!app || app._globalEventsBound) return;
    app._globalEventsBound = true;

    window.addEventListener('keydown', function (event) { onKeydown(app, event); }, true);
    document.addEventListener('pointerdown', function (event) { onPointerDown(app, event); }, true);
    window.addEventListener('message', function (event) { onMessage(app, event); });
    window.addEventListener('ve-mimams-bar-toggle-request', function () {
      if (isMimamsBarDisabled()) return;
      app.toggle();
    });

    function handleToggleBtnEvent(event) {
      var btn = event.target && event.target.closest && event.target.closest('.mimams-bar-toggle-button');
      if (btn) {
        event.preventDefault();
        event.stopPropagation();
        if (event.stopImmediatePropagation) event.stopImmediatePropagation();
        if (event.type === 'click') {
          if (isMimamsBarDisabled()) return;
          app.toggle();
        }
      }
    }
    document.addEventListener('pointerdown', handleToggleBtnEvent, true);
    document.addEventListener('mousedown', handleToggleBtnEvent, true);
    document.addEventListener('click', handleToggleBtnEvent, true);

    var recover = makeRecoveryHandler(app);
    document.addEventListener('visibilitychange', recover, true);
    window.addEventListener('pageshow', recover, true);
    window.addEventListener('focus', recover, true);

    var closeIfDisabled = function () {
      if (isMimamsBarDisabled() && app.isOpen && app.isOpen()) {
        app.close();
      }
    };
    window.addEventListener('ve-deactivated-tools-changed', closeIfDisabled);
    window.addEventListener('storage', closeIfDisabled);
  }

  function makeRecoveryHandler(app) {
    var timer = null;
    return function () {
      if (!app) return;
      if (document.visibilityState && document.visibilityState !== 'visible') return;
      if (timer) window.clearTimeout(timer);
      timer = window.setTimeout(function () {
        timer = null;
        try {
          if (app.settings && typeof app.settings.applyUiState === 'function') app.settings.applyUiState();
          if (app.isOpen && app.isOpen() && app.targetManager) app.targetManager.scheduleRefresh(app);
        } catch (e) {}
      }, 180);
    };
  }

  function onMessage(app, event) {
    if (!event || !event.data || event.data.type !== 'baqa:toggle') return;
    if (event.origin && event.origin !== window.location.origin) return;
    if (isMimamsBarDisabled()) return;
    app.toggle();
  }

  function isMimamsBarDisabled() {
    try {
      var raw = window.localStorage ? window.localStorage.getItem('ve_deactivated_tools') : '';
      var surfaceRaw = window.localStorage ? window.localStorage.getItem('ve_deactivated_tool_surfaces') : '';
      var list = raw ? JSON.parse(raw) : [];
      var surfaces = surfaceRaw ? JSON.parse(surfaceRaw) : {};
      var builderList = surfaces && Array.isArray(surfaces.builder) ? surfaces.builder : [];
      var adminList = surfaces && Array.isArray(surfaces.admin) ? surfaces.admin : [];
      var config = window.MimamsBarCore && window.MimamsBarCore.config ? window.MimamsBarCore.config : (window.baqaConfig || {});
      var surface = config.surface === 'builder' ? 'builder' : 'admin';
      var activeList = surface === 'builder' ? builderList : adminList;
      var legacy = Array.isArray(list) ? list : [];
      var legacyWithoutSurfaceChoice = legacy.filter(function (id) {
        return adminList.indexOf(id) === -1 && builderList.indexOf(id) === -1;
      });
      return activeList.indexOf('mimams_bar') !== -1 || legacyWithoutSurfaceChoice.indexOf('mimams_bar') !== -1;
    } catch (e) {
      return false;
    }
  }

  function bindCanvasFrames(app) {
    // v1.2.49: intentionally disabled. Binding pointer listeners inside the
    // Bricks canvas iframe can be expensive on complex builder pages and was
    // one likely source of freeze while the bar remained open.
    return;
  }

  function onCanvasPointerDown(app, event) {
    if (!app || !app.isOpen()) return;
    app.targetManager.scheduleRefresh(app);
  }

  function clickedInside(node, event, path) {
    if (!node || !event) return false;
    return path ? path.indexOf(node) !== -1 : node.contains(event.target);
  }

  function shouldRefreshFromTopDocumentClick(app, target) {
    if (!target || !target.closest) return false;
    // Structure/tree clicks are cheap enough to use for target refresh. Canvas
    // iframe clicks are deliberately ignored in this release for freeze safety.
    return !!target.closest('#bricks-structure, #bricks-structure-resizable, .bricks-structure, .brx-structure, #brx-structure, [data-panel="structure"], [data-control="structure"], [data-id], .bricks-draggable-item');
  }

  function onPointerDown(app, event) {
    if (!app || !app.isOpen()) return;

    var path = typeof event.composedPath === 'function' ? event.composedPath() : null;
    if (app.dialogs.clickInside(app.confirmOverlay, event, path) || app.dialogs.clickInside(app.bulkOverlay, event, path)) return;
    if (clickedInside(app.panel, event, path)) return;
    if (event.target && event.target.closest && event.target.closest('.mimams-bar-toggle-button')) return;

    if (shouldRefreshFromTopDocumentClick(app, event.target)) {
      app.targetManager.scheduleRefresh(app);
    }

    app.close();
  }

  function isDeselectShortcut(event, app) {
    // The registry owns this key now. The stored deselectShortcut below is the
    // pre-registry setting, kept as a fallback so an install that has not yet
    // written registry data keeps the binding it already had.
    if (window.MVShortcuts && typeof window.MVShortcuts.matches === 'function'
      && window.MVShortcuts.get('element.deselect')
      && window.MVShortcuts.get('element.deselect').customised) {
      return window.MVShortcuts.matches('element.deselect', event);
    }
    if (!app || !app.Core || !app.Core.readStoredSettings) return false;
    var conf = app.Core.readStoredSettings().deselectShortcut || 'escape';
    if (conf === 'none') return false;
    if (conf === 'escape' && event.key === 'Escape') return true;
    if (conf === 'shift-d' && event.key.toLowerCase() === 'd' && event.shiftKey && !event.ctrlKey && !event.metaKey && !event.altKey) return true;
    if (conf === 'alt-d' && event.key.toLowerCase() === 'd' && event.altKey && !event.ctrlKey && !event.metaKey && !event.shiftKey) return true;
    return false;
  }


  /* Where a fired chord goes. Everything the registry can fire is listed once,
     so a new chord is a registry entry plus a case here. */
  function runChord(app, id) {
    if (id === 'element.rename') {
      if (window.MimamsBarRenameManager) window.MimamsBarRenameManager.tryOpen(app);
      return;
    }
    if (id === 'component.unlink') {
      var adapter = app.adapter || (app.Core && app.Core.adapter);
      if (!adapter || typeof adapter.unlinkComponent !== 'function') return;
      var res = adapter.unlinkComponent();
      if (res && res.ok) {
        if (app.toast && app.toast.show) app.toast.show('Component unlinked', 'success');
        try {
          if (app.targetManager && app.targetManager.scheduleRefresh) {
            app.targetManager.scheduleRefresh(app);
          }
        } catch (e) {}
      } else if (app.toast && app.toast.show) {
        app.toast.show((res && res.message) || 'Could not unlink this component',
          (res && res.reason === 'not-a-component') ? 'warning' : 'error');
      }
      return;
    }
    if (id === 'help.cheatsheet') {
      window.dispatchEvent(new CustomEvent('mv-shortcuts-cheatsheet'));
      return;
    }
    if (id.indexOf('goto.') === 0) {
      window.dispatchEvent(new CustomEvent('mv-shortcuts-goto',
        { detail: { target: id.slice(5) } }));
    }
  }

  /* A dead letter after the leader is shown, not silently dropped: once the
     leader is down you are unambiguously mid-chord. A lone letter that leads
     nowhere is simply forgotten, which is why only 'rejected' reaches here. */
  function announceChord(app, kind, key) {
    window.dispatchEvent(new CustomEvent('mv-shortcuts-armed',
      { detail: { state: kind, key: key } }));
  }

  function onKeydown(app, event) {
    if (event.__mimamsBarHandledKeydown) return;

    var confirmOpen = app.confirmOverlay && app.confirmOverlay.classList.contains('is-open');

    if (event.key === 'Escape' && confirmOpen) {
      event.__mimamsBarHandledKeydown = true;
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
      app.closeConfirmDialog();
      return;
    }

    if (event.key === 'Escape' && app.isOpen()) {
      event.__mimamsBarHandledKeydown = true;
      event.preventDefault();
      app.close();
      return;
    }

    // Typing "//" closes the Bar — pressing "/" while the field already holds "/".
    if (event.key === '/' && app.isOpen() && app.input && event.target === app.input && String(app.input.value) === '/') {
      event.__mimamsBarHandledKeydown = true;
      event.preventDefault();
      app.input.value = '';
      app.close();
      return;
    }

    var inInput = (event.target && (event.target.isContentEditable || (event.target.closest && event.target.closest('input, textarea, select, [contenteditable="true"]'))));

    // Chords, decided by assets/js/shortcut-registry.js rather than here.
    // R R and U U used to be inline, each with its own timestamp field and its
    // own copy of the 400 ms window; the registry now runs one state machine
    // for every chord, so adding or rebinding one touches no handler.
    //
    // A claimed letter is swallowed on the lone press. That is what lets a
    // chord sit on a letter Bricks already uses without MV having to hold the
    // key and replay it, which would put latency on every keystroke.
    if (!inInput && window.MVShortcuts) {
      var chord = window.MVShortcuts.handleKey(event);
      if (chord) {
        if (chord.armed || chord.rejected) {
          event.__mimamsBarHandledKeydown = true;
          event.preventDefault();
          event.stopPropagation();
          if (chord.rejected) announceChord(app, 'rejected', chord.rejected);
          return;
        }
        if (chord.fired) {
          event.__mimamsBarHandledKeydown = true;
          event.preventDefault();
          event.stopPropagation();
          runChord(app, chord.fired);
          return;
        }
      }
    }

    if (app.isOpen() && !inInput) {
      if (app.handleModeKeys(event)) {
        event.__mimamsBarHandledKeydown = true;
        return;
      }
    }

    if (!inInput && isDeselectShortcut(event, app)) {
      if (app.Core && app.Core.adapter && app.Core.adapter.deselectElement) {
        app.Core.adapter.deselectElement();
        event.__mimamsBarHandledKeydown = true;
        event.preventDefault();
        return;
      }
    }

    if (app.matchesShortcut(event)) {
      // The open shortcut is a global command trigger, so it must work even when focus
      // is in a code editor / input (e.g. the Code2Bricks textarea) — as long as it uses
      // a modifier (Ctrl/Cmd/Alt) so it can't hijack plain typing in a field.
      var hasModifier = event.ctrlKey || event.metaKey || event.altKey;
      if (inInput && !hasModifier) return;
      event.__mimamsBarHandledKeydown = true;
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
      if (isMimamsBarDisabled()) return;
      // Opened from a code editor / input: some editors (Code2Bricks) refocus their own
      // field the instant it blurs, so plain focus() just ping-pongs back (confirmed: focus
      // lands on the Bar input, then jumps straight to the editor TEXTAREA). Briefly disable
      // the editor field so it CANNOT be refocused, move focus into the Bar, then restore it.
      var reclaimer = null;
      if (inInput && event.target && (event.target.tagName === 'TEXTAREA' || event.target.tagName === 'INPUT') && !event.target.disabled) {
        reclaimer = event.target;
        try { reclaimer.blur(); reclaimer.disabled = true; } catch (e) { reclaimer = null; }
      }
      app.toggle();
      window.setTimeout(function () {
        try { if (app.isOpen && app.isOpen() && app.input && typeof app.input.focus === 'function') app.input.focus(); } catch (e) {}
        if (reclaimer) {
          // Restore the editor once focus is safely in the Bar; re-enabling fires no blur,
          // so the editor won't spontaneously grab focus back.
          window.setTimeout(function () { try { reclaimer.disabled = false; } catch (e) {} }, 350);
        }
      }, 30);
    }
  }

  function bindCanvasIframeEvents(app) {
    try {
      var iframes = document.querySelectorAll('iframe, #bricks-builder-iframe, .bricks-builder-iframe, .brx-iframe, #brx-iframe');
      iframes.forEach(function (iframe) {
        if (!iframe || !iframe.contentDocument) return;
        if (iframe._mimamsBarPointerdownBound) {
          try {
            iframe.contentDocument.removeEventListener('pointerdown', iframe._mimamsBarPointerdownBound, true);
          } catch (e) {}
        }
        var listener = function (event) {
          if (app && typeof app.close === 'function') {
            app.close();
          }
        };
        iframe.contentDocument.addEventListener('pointerdown', listener, true);
        iframe._mimamsBarPointerdownBound = listener;
      });
    } catch (e) {}
  }

  function unbindCanvasIframeEvents() {
    try {
      var iframes = document.querySelectorAll('iframe, #bricks-builder-iframe, .bricks-builder-iframe, .brx-iframe, #brx-iframe');
      iframes.forEach(function (iframe) {
        if (iframe && iframe.contentDocument && iframe._mimamsBarPointerdownBound) {
          try {
            iframe.contentDocument.removeEventListener('pointerdown', iframe._mimamsBarPointerdownBound, true);
          } catch (e) {}
          delete iframe._mimamsBarPointerdownBound;
        }
      });
    } catch (e) {}
  }

  window.MimamsBarGlobalEvents = {
    bind: bind,
    bindCanvasFrames: bindCanvasFrames,
    bindCanvasIframeEvents: bindCanvasIframeEvents,
    unbindCanvasIframeEvents: unbindCanvasIframeEvents,
    onMessage: onMessage,
    onCanvasPointerDown: onCanvasPointerDown,
    onPointerDown: onPointerDown,
    onKeydown: onKeydown
  };
})();
