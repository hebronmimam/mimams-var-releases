(function(){
'use strict';
if(window.self!==window.top&&document.querySelector('.brx-body'))return;
// #35/#36: install one wheel broker before the Preact panel mounts. Bricks and
// Firefox can register window-level wheel handling before an individual
// CodeMirror effect runs, so editor-local listeners are too late.
const veCodeEditorScrollRegistry=new Set();
let veLastCodeEditorWheel={time:-Infinity,type:'',direction:0,record:null};
function veCodeEditorRows(){
  return Array.from(veCodeEditorScrollRegistry).filter(item=>item.wrapper&&item.wrapper.isConnected).map((item,index)=>{
    const info=item.cm.getScrollInfo();
    const scroller=item.cm.getScrollerElement();
    return {
      editor:index+1,
      surface:item.wrapper.closest('.ve-bricks-cm-full')?'pop-out':'inline',
      top:Math.round(scroller.scrollTop),
      maxTop:Math.max(0,Math.round(scroller.scrollHeight-scroller.clientHeight)),
      codeMirrorTop:Math.round(info.top),
      codeMirrorMaxTop:Math.max(0,Math.round(info.height-info.clientHeight)),
      nativeClientHeight:Math.round(scroller.clientHeight),
      nativeScrollHeight:Math.round(scroller.scrollHeight),
      overflowY:getComputedStyle(scroller).overflowY,
      lastWheel:item.lastWheel||'none'
    };
  });
}
function veInspectCodeEditors(){
  const rows=veCodeEditorRows();
  if(typeof console!=='undefined'&&console.table)console.table(rows);
  return rows;
}
function veExposeCodeEditorDiagnostics(target){
  if(!target)return;
  try{
    Object.defineProperty(target,'mimamVarInspectCodeEditors',{configurable:true,writable:true,value:veInspectCodeEditors});
  }catch(e){
    try{target.mimamVarInspectCodeEditors=veInspectCodeEditors;}catch(ignore){}
  }
}
veExposeCodeEditorDiagnostics(window);
try{if(window.top!==window)veExposeCodeEditorDiagnostics(window.top);}catch(e){}
function veCodeEditorDelta(event,record){
  const line=Math.max(1,record.cm.defaultTextHeight());
  if(event.type==='wheel'&&Number.isFinite(event.deltaY)){
    if(Number.isFinite(event.deltaX)&&Math.abs(event.deltaX)>Math.abs(event.deltaY))return 0;
    return event.deltaY*(event.deltaMode===1?line:(event.deltaMode===2?record.cm.getScrollInfo().clientHeight:1));
  }
  if(event.type==='DOMMouseScroll'){
    if(event.axis!=null&&event.HORIZONTAL_AXIS!=null&&event.axis===event.HORIZONTAL_AXIS)return 0;
    return Number(event.detail||0)*line;
  }
  const wheel=Number(event.wheelDeltaY!=null?event.wheelDeltaY:event.wheelDelta);
  return Number.isFinite(wheel)&&wheel?-(wheel/120)*line*3:0;
}
function veScrollCodeEditorOuter(record,delta){
  if(record.wrapper.closest('.ve-bricks-cm-full'))return false;
  let node=record.wrapper.parentElement;
  while(node&&node!==document.body){
    const style=getComputedStyle(node);
    if((style.overflowY==='auto'||style.overflowY==='scroll')&&node.scrollHeight>node.clientHeight+1){
      const before=node.scrollTop;
      const max=Math.max(0,node.scrollHeight-node.clientHeight);
      const next=Math.max(0,Math.min(max,before+delta));
      if(Math.abs(next-before)>=.5){
        node.scrollTop=next;
        return true;
      }
    }
    node=node.parentElement;
  }
  return false;
}
function veHandleCodeEditorWheel(event){
  const path=typeof event.composedPath==='function'?event.composedPath():[];
  let record=null;
  veCodeEditorScrollRegistry.forEach(item=>{
    if(!record&&(path.includes(item.wrapper)||(event.target&&item.wrapper.contains(event.target))))record=item;
  });
  if(!record)return;
  const delta=veCodeEditorDelta(event,record);
  if(!delta)return;
  const now=Number(event.timeStamp)||performance.now();
  const direction=Math.sign(delta);
  const duplicate=veLastCodeEditorWheel.record===record&&veLastCodeEditorWheel.type!==event.type&&veLastCodeEditorWheel.direction===direction&&Math.abs(now-veLastCodeEditorWheel.time)<50;
  if(duplicate){
    if(event.cancelable)event.preventDefault();
    event.stopImmediatePropagation();
    return;
  }
  veLastCodeEditorWheel={time:now,type:event.type,direction,record};
  const cm=record.cm;
  const info=cm.getScrollInfo();
  const scroller=cm.getScrollerElement();
  const before=scroller.scrollTop;
  const maxTop=Math.max(0,scroller.scrollHeight-scroller.clientHeight,info.height-info.clientHeight);
  const nextTop=Math.max(0,Math.min(maxTop,before+delta));
  record.lastWheel={
    eventType:event.type,
    delta:Math.round(delta),
    defaultPreventedAtBroker:event.defaultPrevented,
    before:Math.round(before),
    requested:Math.round(nextTop),
    maxTop:Math.round(maxTop),
    consumed:Math.abs(nextTop-before)>=.5
  };
  if(!record.lastWheel.consumed){
    record.lastWheel.outerPanelMoved=veScrollCodeEditorOuter(record,delta);
    if(!record.lastWheel.outerPanelMoved)return;
    if(event.cancelable)event.preventDefault();
    event.stopImmediatePropagation();
    return;
  }
  if(event.cancelable)event.preventDefault();
  event.stopImmediatePropagation();
  scroller.scrollTop=nextTop;
  cm.scrollTo(info.left,nextTop);
  record.lastWheel.after=Math.round(scroller.scrollTop);
}
window.addEventListener('wheel',veHandleCodeEditorWheel,{capture:true,passive:false});
window.addEventListener('DOMMouseScroll',veHandleCodeEditorWheel,{capture:true,passive:false});
window.addEventListener('mousewheel',veHandleCodeEditorWheel,{capture:true,passive:false});
if(!window.preact||!window.preactHooks){
  const showMissingRuntime=()=>{try{
    if(document.getElementById('ve-boot-fallback'))return;
    const b=document.createElement('button');
    b.id='ve-boot-fallback';
    b.type='button';
    b.textContent='MV';
    b.title='Mimam’s Var runtime did not load. Click to reload.';
    b.style.cssText='position:fixed;right:16px;bottom:16px;z-index:120050;width:38px;height:38px;border-radius:10px;border:1px solid #baf400;background:#1f1f1f;color:#baf400;font:700 11px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;cursor:pointer;box-shadow:0 8px 22px rgba(0,0,0,.35)';
    b.addEventListener('click',()=>window.location.reload());
    document.body.appendChild(b);
    console.error('Mimam’s Var runtime dependency missing', {preact:!!window.preact, hooks:!!window.preactHooks});
  }catch(e){}};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',showMissingRuntime,{once:true});else showMissingRuntime();
  return;
}
const{h,render,Fragment}=window.preact;const{useState,useEffect,useRef,useMemo,useCallback,useLayoutEffect}=window.preactHooks;
const CFG=window.vePanel||{};const MODE=CFG.mode||'admin';

// ── #11 Minimum canvas viewport ────────────────────────────────────────────
// Bricks implements this itself: `previewWidthLocked` in its Vue store locks the
// desktop preview width and Bricks computes the zoom (previewWrapperWidth /
// previewWidth). It is seeded at boot from the `bricks_builder_width_locked` user
// meta, which MV writes on save — but mutating window.bricksData afterwards does
// nothing, because the store already copied the value. So for a live change we set
// the store property Bricks actually reads, via its exposed $_state.
(function(){
  if ((CFG.mode||'admin') !== 'builder') return;

  // Vue 3 marks only the mount root with __vue_app__, and Bricks does not mount on a
  // predictable id — the earlier guess list found nothing (stateFound:false). Scan for
  // either marker and cache the hit. __vueParentComponent is present on every element
  // Vue rendered, so this finds the app even if the root is anonymous.
  var stateCache=null;
  function bricksState(){
    if(stateCache&&('previewWidthLocked' in stateCache))return stateCache;
    var all;
    try{ all=document.querySelectorAll('*'); }catch(e){ return null; }
    for(var i=0;i<all.length;i++){
      var n=all[i],gp=null;
      try{
        if(n.__vue_app__&&n.__vue_app__.config)gp=n.__vue_app__.config.globalProperties;
        else if(n.__vueParentComponent&&n.__vueParentComponent.appContext)gp=n.__vueParentComponent.appContext.config.globalProperties;
      }catch(e){}
      if(gp&&gp.$_state&&('previewWidthLocked' in gp.$_state)){ stateCache=gp.$_state; return stateCache; }
    }
    return null;
  }

  /* ── Live theme styles ──────────────────────────────────────────────────
   * Writing bricks_theme_styles to the database changes nothing on screen:
   * the builder generated its canvas CSS at boot and never re-reads the option.
   * Bricks' own panel is live because it edits the store, so MV does the same.
   *
   * The canvas CSS is generated inside the IFRAME, from
   *   gp.themeStyles[ each of themeStyleActiveIds ].settings
   * and regenerated by a watcher on gp.themeStyleSettings (iframe.min.js:
   * `"$_state.themeStyleSettings":{handler(){this.css.themeStyles=this.$_generateCss("themeStyles")}}`).
   * Both watchers compare by reference, so every value below is a fresh clone —
   * mutating in place would update the data and repaint nothing.
   *
   * The main window mirrors each store key to the iframe automatically, but it
   * skips the forward when the last change arrived FROM the iframe
   * (`if (yp.messageOrigin !== 'iframe')`), so the message is also posted
   * directly with ignoreOrigin, which the iframe always honours.
   */
  function iframeWindow(){
    try{
      var frame=document.getElementById('bricks-builder-iframe');
      return frame&&frame.contentWindow?frame.contentWindow:null;
    }catch(e){ return null; }
  }
  function postToCanvas(key,value){
    var target=iframeWindow();
    if(!target)return false;
    try{
      target.postMessage(JSON.stringify({key:key,value:value,ignoreOrigin:true}),window.bricksData?window.bricksData.siteUrl:'*');
      return true;
    }catch(e){ return false; }
  }
  function clone(value){ try{ return JSON.parse(JSON.stringify(value)); }catch(e){ return value; } }

  var lastPayload='';
  window.veThemeStylesApply=function(stylesById,activeIds,options){
    var opts=options||{};
    var st=bricksState();
    var next=clone(stylesById||{});

    // Regenerating identical CSS still swaps the <style> node, which is a
    // visible flash. Skip when nothing actually changed.
    var signature='';
    try{ signature=JSON.stringify(next); }catch(e){ signature=String(Date.now()); }
    if(signature===lastPayload&&!opts.force)return !!st;
    lastPayload=signature;

    var activeId=st?st.themeStyleActiveId:(Array.isArray(activeIds)&&activeIds.length?activeIds[activeIds.length-1]:'');
    var activeSettings=(activeId&&next[activeId]&&next[activeId].settings)?clone(next[activeId].settings):null;

    if(st){
      // Bricks mirrors every store key to the iframe by itself, but skips the
      // forward when the last change arrived FROM the iframe. Claiming 'main'
      // guarantees it forwards, so MV does not have to post the payload as
      // well — doing both regenerated the canvas CSS twice per keystroke,
      // which is what the flicker was.
      st.messageOrigin='main';
      st.themeStyles=next;
      if(Array.isArray(activeIds)&&activeIds.length){
        st.themeStyleActiveIds=activeIds.slice();
        if(!st.themeStyleActiveId||activeIds.indexOf(st.themeStyleActiveId)===-1)st.themeStyleActiveId=activeIds[activeIds.length-1];
      }
      // Order matters: the map has to land before the trigger, or the
      // regeneration reads the previous settings.
      if(activeSettings)st.themeStyleSettings=activeSettings;
      // Re-rendering Bricks' entire control panel is expensive and visible, so
      // it waits until the value settles rather than firing on every keystroke.
      if(!opts.quiet)st.rerenderControls=Date.now();
      return true;
    }

    // No store found (Bricks not mounted yet): talk to the canvas directly.
    postToCanvas('themeStyles',next);
    if(Array.isArray(activeIds)&&activeIds.length)postToCanvas('themeStyleActiveIds',activeIds.slice());
    if(activeSettings)postToCanvas('themeStyleSettings',clone(activeSettings));
    return false;
  };

  window.mimamVarInspectThemeStyles=function(){
    var st=bricksState();
    var out={
      stateFound:!!st,
      iframeFound:!!iframeWindow(),
      themeStyleActiveId: st?st.themeStyleActiveId:null,
      themeStyleActiveIds: st?st.themeStyleActiveIds:null,
      themeStyleIds: (st&&st.themeStyles)?Object.keys(st.themeStyles):null,
      activeSettingGroups: (st&&st.themeStyleSettings)?Object.keys(st.themeStyleSettings):null,
      hasStylesheet: !!(st&&st.themeStyleSettings&&st.themeStyleSettings.css&&st.themeStyleSettings.css.stylesheet)
    };
    console.log('[MV] Bricks theme styles state');
    console.log(JSON.stringify(out,null,1));
    return out;
  };
})();

const NATIVE_MEDIA_REPLACEMENT_ENABLED=false;
const MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED=true;
const apiActivity={count:0,label:'Working…',progress:0,panelId:'variables',failed:false,listeners:new Set(),nextId:1,active:new Map(),timer:null};
const UPDATE_INSTALL_STEPS=[
  'Checking the selected channel',
  'Resolving the release package',
  'Preserving the current build',
  'Downloading the package',
  'Verifying and unpacking',
  'Installing plugin files',
  'Restoring activation',
  'Finishing up'
];
const updateInstallActivity={
  visible:false,open:false,status:'idle',progress:0,step:0,version:'',message:'',
  notes:[],refreshRequired:false,errorCode:'',listeners:new Set(),timer:null
};
function updateInstallSnapshot(){
  return{
    visible:updateInstallActivity.visible,open:updateInstallActivity.open,status:updateInstallActivity.status,
    progress:updateInstallActivity.progress,step:updateInstallActivity.step,version:updateInstallActivity.version,
    message:updateInstallActivity.message,notes:updateInstallActivity.notes.slice(),
    refreshRequired:updateInstallActivity.refreshRequired,errorCode:updateInstallActivity.errorCode
  };
}
function notifyUpdateInstall(){
  const state=updateInstallSnapshot();
  updateInstallActivity.listeners.forEach(listener=>{try{listener(state);}catch(error){}});
}
function stopUpdateInstallTimer(){
  if(updateInstallActivity.timer)clearInterval(updateInstallActivity.timer);
  updateInstallActivity.timer=null;
}
function beginUpdateInstall(version){
  stopUpdateInstallTimer();
  Object.assign(updateInstallActivity,{
    visible:true,open:false,status:'running',progress:6,step:0,version:String(version||''),
    message:'The update is running in the background.',notes:[],refreshRequired:false,errorCode:''
  });
  updateInstallActivity.timer=setInterval(()=>{
    if(updateInstallActivity.status!=='running')return;
    updateInstallActivity.progress=Math.min(92,updateInstallActivity.progress+(updateInstallActivity.progress<48?6:updateInstallActivity.progress<78?3:1));
    updateInstallActivity.step=Math.min(6,Math.floor(updateInstallActivity.progress/14));
    notifyUpdateInstall();
  },620);
  notifyUpdateInstall();
}
function completeUpdateInstall(result){
  stopUpdateInstallTimer();
  const notes=Array.isArray(result?.release_notes)?result.release_notes.filter(Boolean).slice(0,5):[];
  Object.assign(updateInstallActivity,{
    visible:true,open:true,status:'success',progress:100,step:UPDATE_INSTALL_STEPS.length,
    version:String(result?.version||updateInstallActivity.version||''),
    message:String(result?.message||"Mimam's Var was installed successfully."),notes,
    refreshRequired:result?.refresh_required!==false,errorCode:''
  });
  notifyUpdateInstall();
}
function failUpdateInstall(result){
  stopUpdateInstallTimer();
  const supplied=Number(result?.data?.update_step);
  const step=Number.isFinite(supplied)?Math.max(0,Math.min(UPDATE_INSTALL_STEPS.length-1,supplied)):Math.max(0,Math.min(UPDATE_INSTALL_STEPS.length-1,updateInstallActivity.step));
  Object.assign(updateInstallActivity,{
    visible:true,open:true,status:'failure',step,progress:Math.max(6,Math.round(step/UPDATE_INSTALL_STEPS.length*100)),
    message:String(result?.message||'WordPress could not finish the update.'),notes:[],refreshRequired:false,
    errorCode:String(result?.code||'ve_update_failed')
  });
  notifyUpdateInstall();
}
function setUpdateInstallOpen(open){updateInstallActivity.open=!!open;notifyUpdateInstall();}
function apiActivityLabel(path,method){
  const clean=String(path||'').replace(/^variable-engine\/v1\//,'').split('?')[0];
  if(clean==='migration/preview')return'Scanning external variables…';
  if(clean==='migration/apply')return'Importing external variables…';
  if(clean==='sync/preview')return'Preparing import preview…';
  if(clean==='sync/apply')return'Applying imported variables…';
  if(clean==='sync/preview-bundle')return'Preparing System Bundle preview…';
  if(clean==='sync/apply-bundle')return'Restoring System Bundle…';
  if(/^sync\/rollback\//.test(clean))return'Restoring snapshot…';
  if(clean==='sync/snapshot')return'Creating snapshot…';
  if(/^generators(?:\/|$)/.test(clean)&&String(method||'GET').toUpperCase()!=='GET')return'Generating variables…';
  if(/^color-palettes\/.+\/(?:duplicate|delete-preview)$/.test(clean))return'Updating Color Palettes…';
  if(/^themes\/.+\/duplicate$/.test(clean))return'Updating Themes…';
  /* Updates own the approved B79 corner pill and decision ledger. */
  if(clean==='update/install')return'';
  return'';
}
function notifyApiActivity(){
  const state={count:apiActivity.count,label:apiActivity.label,progress:apiActivity.progress,panelId:apiActivity.panelId,failed:apiActivity.failed};
  apiActivity.listeners.forEach(listener=>{try{listener(state);}catch(e){}});
}
function apiActivityPanelId(){
  try{
    const panel=document.activeElement?.closest?.('[data-panel]');
    return panel?.dataset?.panel||'variables';
  }catch(e){return'variables';}
}
function startApiActivityTimer(){
  if(apiActivity.timer)clearInterval(apiActivity.timer);
  apiActivity.timer=setInterval(()=>{
    if(!apiActivity.count)return;
    if(apiActivity.progress<45)apiActivity.progress+=5;
    else if(apiActivity.progress<75)apiActivity.progress+=3;
    else if(apiActivity.progress<92)apiActivity.progress+=1;
    apiActivity.progress=Math.min(apiActivity.progress,92);
    notifyApiActivity();
  },500);
}
function beginApiActivity(path,method){
  const label=apiActivityLabel(path,method);
  if(!label)return 0;
  const id=apiActivity.nextId++;
  apiActivity.active.set(id,label);
  apiActivity.count=apiActivity.active.size;
  if(apiActivity.count===1){
    apiActivity.label=label;
    apiActivity.progress=8;
    apiActivity.failed=false;
    apiActivity.panelId=apiActivityPanelId();
    startApiActivityTimer();
  }
  notifyApiActivity();
  return id;
}
function endApiActivity(id,failed=false){
  if(!id)return;
  if(failed)apiActivity.failed=true;
  apiActivity.active.delete(id);
  apiActivity.count=apiActivity.active.size;
  if(!apiActivity.count){
    if(apiActivity.timer)clearInterval(apiActivity.timer);
    apiActivity.timer=null;
    apiActivity.progress=100;
  }
  notifyApiActivity();
}

let restNonceRefreshPromise=null;
function isRestNonceError(data,status){
  return data?.code==='rest_cookie_invalid_nonce'||(status===403&&/nonce/i.test(String(data?.message||'')));
}
async function refreshRestNonce(){
  if(restNonceRefreshPromise)return restNonceRefreshPromise;
  restNonceRefreshPromise=(async()=>{
    const body=new URLSearchParams({action:'ve_refresh_rest_nonce'});
    const r=await fetch(CFG.ajaxUrl||'/wp-admin/admin-ajax.php',{
      method:'POST',credentials:'same-origin',
      headers:{'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8'},
      body:body.toString()
    });
    const data=await r.json();
    const nonce=String(data?.data?.nonce||'');
    if(!r.ok||!data?.success||!nonce)throw new Error(data?.data?.message||'Your WordPress session must be refreshed.');
    CFG.nonce=nonce;
    return nonce;
  })().finally(()=>{restNonceRefreshPromise=null;});
  return restNonceRefreshPromise;
}
let restRouteFallback=false;
try{restRouteFallback=localStorage.getItem('ve_rest_route_fallback')==='1';}catch(e){}
// The pretty /wp-json route needs server rewrite rules. A site restored onto a host
// whose .htaccess has no WordPress rules 404s at the web server before WordPress runs
// (Apache's own 404 page), which surfaced as "WordPress returned an error while loading
// data" on every Studio. The ?rest_route= form needs no rewrite rules at all.
function restEndpoint(path){
  const root=CFG.apiRoot||'/wp-json/';
  const q=path.indexOf('?');
  const route=q===-1?path:path.slice(0,q);
  const extra=q===-1?'':path.slice(q+1);
  if(/[?&]rest_route=/i.test(root)){
    const joined=/(?:\/|%2f)$/i.test(root)?root:(root+'/');
    return joined+route+(extra?'&'+extra:'');
  }
  if(!restRouteFallback)return root+path;
  const base=root.replace(/wp-json\/?$/,'');
  return base+'?rest_route=/'+route+(extra?'&'+extra:'');
}
async function apiRequest(path,options,retried=false,routeRetried=false){
  const r=await fetch(restEndpoint(path),{credentials:'same-origin',...options,headers:{'X-WP-Nonce':CFG.nonce||'',...(options.headers||{})}});
  const ct=(r.headers.get('content-type')||'').toLowerCase();
  const txt=await r.text();
  let data=null;
  if(ct.includes('application/json')){
    try{data=txt?JSON.parse(txt):{};}catch(e){data={code:'ve_bad_json',message:'WordPress returned invalid JSON.'};}
  }else{
    data={code:'ve_non_json',message:r.ok?'Unexpected non-JSON response from WordPress.':'WordPress returned an error while loading data.',raw:txt};
  }
  if(data.code==='ve_non_json'&&404===r.status&&!restRouteFallback&&!routeRetried){
    restRouteFallback=true;
    const second=await apiRequest(path,options,retried,true);
    if(second&&second.code==='ve_non_json'&&404===second.httpStatus){
      restRouteFallback=false; // 404 either way — the problem is not the route form.
    }else{
      try{localStorage.setItem('ve_rest_route_fallback','1');}catch(e){}
    }
    return second;
  }
  if(isRestNonceError(data,r.status)&&!retried){
    await refreshRestNonce();
    return apiRequest(path,options,true,routeRetried);
  }
  if(!r.ok&&!data.code)data.code='ve_http_'+r.status;
  if(data&&typeof data==='object')data.httpStatus=r.status;
  return data;
}
const api={
 f:async(p,o={})=>{
  const activityId=beginApiActivity(p,o.method||'GET');
  let failed=false;
  try{
    const data=await apiRequest(p,o);
    failed=!!data?.code;
    return data;
  }catch(error){
    failed=true;
    return{code:'ve_network_error',message:'WordPress did not finish the request. Check the server error log, then try again.',detail:String(error?.message||error||'Network request failed')};
  }finally{
    endApiActivity(activityId,failed);
  }
},
g:p=>api.f('variable-engine/v1/'+p),
p:async(p,b)=>{
  const d=await api.f('variable-engine/v1/'+p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
  if(!d?.code){
    if(isVariableMutationPath(p))refreshVariableStylesheets();
    if(p.split('?')[0]==='settings')refreshSettings(d);
  }
  return d;
},
u:async(p,b)=>{
  const d=await api.f('variable-engine/v1/'+p,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
  if(!d?.code){
    if(isVariableMutationPath(p))refreshVariableStylesheets();
    if(p.split('?')[0]==='settings')refreshSettings(d);
  }
  return d;
},
d:async(p,b)=>{
  const opts={method:'DELETE'};
  if(b!==undefined){opts.headers={'Content-Type':'application/json'};opts.body=JSON.stringify(b);}
  const d=await api.f('variable-engine/v1/'+p,opts);
  if(!d?.code&&isVariableMutationPath(p))refreshVariableStylesheets();
  return d;
},
};

let fontToolsRuntimePromise=null;
function ensureFontToolsRuntime(){
  if(window.VEFontTools?.createFont&&window.VEFontTools?.woff2)return Promise.resolve(window.VEFontTools);
  if(fontToolsRuntimePromise)return fontToolsRuntimePromise;
  fontToolsRuntimePromise=new Promise((resolve,reject)=>{
    const existing=document.getElementById('ve-font-tools-runtime');
    const ready=()=>{
      if(window.VEFontTools?.createFont&&window.VEFontTools?.woff2)resolve(window.VEFontTools);
      else reject(new Error('The font conversion runtime did not initialise.'));
    };
    if(existing){existing.addEventListener('load',ready,{once:true});existing.addEventListener('error',()=>reject(new Error('The font conversion runtime could not load.')),{once:true});return;}
    const script=document.createElement('script');
    script.id='ve-font-tools-runtime';
    script.src=CFG.fontToolsScript||'';
    script.async=true;
    script.onload=ready;
    script.onerror=()=>reject(new Error('The font conversion runtime could not load.'));
    document.head.appendChild(script);
  }).catch(error=>{fontToolsRuntimePromise=null;throw error;});
  return fontToolsRuntimePromise;
}
function fontNameText(value){
  if(typeof value==='string')return value;
  if(value&&typeof value==='object')return value.en||value['en-US']||Object.values(value).find(item=>typeof item==='string')||'';
  return'';
}
function fontWeightLabel(weight){
  const names={100:'Thin',200:'Extra Light',300:'Light',400:'Regular',500:'Medium',600:'Semi Bold',700:'Bold',800:'Extra Bold',900:'Black'};
  return(names[weight]||'Weight')+' · '+weight;
}

let recoveryRuntimePromise=null;
function setRecoveryRuntimeOpen(open,source){
  const runtime=window.__veRecoveryAdmin;
  if(runtime&&typeof runtime.open==='function'&&typeof runtime.close==='function'){
    if(open)runtime.open();
    else runtime.close();
    return typeof runtime.isOpen==='function'?runtime.isOpen()===!!open:true;
  }
  window.dispatchEvent(new CustomEvent('ve-recovery-toggle',{detail:{open:!!open,source:source||'studio-owner'}}));
  return !!document.querySelector('[data-panel="recovery"]')?.classList.contains('rb-open')===!!open;
}
function loadRecoveryRuntimeAsset(kind,id,url){
  if(!url)return Promise.reject(new Error('Recovery runtime asset is missing.'));
  const existing=document.getElementById(id);
  if(existing)return Promise.resolve(existing);
  return new Promise((resolve,reject)=>{
    const asset=document.createElement(kind==='style'?'link':'script');
    asset.id=id;
    if(kind==='style'){
      asset.rel='stylesheet';
      asset.href=url;
    }else{
      asset.src=url;
      asset.async=false;
    }
    asset.addEventListener('load',()=>resolve(asset),{once:true});
    asset.addEventListener('error',()=>reject(new Error('Recovery runtime asset could not be loaded.')),{once:true});
    (kind==='style'?document.head:document.body).appendChild(asset);
  });
}
function installRecoveryRuntime(payload){
  const mounted=document.querySelector('[data-panel="recovery"]');
  if(mounted&&window.__veRecoveryAdminInitialized&&window.__veRecoveryAdmin)return Promise.resolve(mounted);
  if(!payload?.html||!payload?.assets?.style||!payload?.assets?.script){
    return Promise.reject(new Error('WordPress did not return the Recovery runtime.'));
  }
  const template=document.createElement('template');
  template.innerHTML=String(payload.html).trim();
  document.body.appendChild(template.content);
  window.restoreBaseAdmin=payload.config||{};
  return Promise.all([
    loadRecoveryRuntimeAsset('style','restorebase-admin-runtime-css',payload.assets.style),
    loadRecoveryRuntimeAsset('script','restorebase-admin-runtime-js',payload.assets.script)
  ]).then(()=>{
    const panel=document.querySelector('[data-panel="recovery"]');
    if(!panel||!window.__veRecoveryAdminInitialized||!window.__veRecoveryAdmin){
      throw new Error('Recovery did not finish initializing.');
    }
    return panel;
  });
}

function isVariableMutationPath(path){
  const clean=String(path||'').split('?')[0];
  if(/rename-preview$/.test(clean))return false;
  return /^(variables(?:\/|$)|generators(?:\/|$)|palettes(?:\/|$)|themes(?:\/|$)|color-palettes(?:\/|$)|migration\/apply$|sync\/apply(?:-bundle)?$|sync\/import(?:\/|$)|sync\/rollback\/|snapshots\/[^/]+\/rollback$)/.test(clean);
}
const variablePreviewValues=new Map();
function builderRuntimeWindows(){
  const found=[],queue=[];
  const add=runtime=>{
    try{
      if(runtime&&runtime.document&&!found.includes(runtime)){
        found.push(runtime);
        queue.push(runtime);
      }
    }catch(e){}
  };
  add(window);
  try{add(window.parent);}catch(e){}
  try{add(window.top);}catch(e){}
  while(queue.length){
    const runtime=queue.shift();
    try{runtime.document.querySelectorAll('iframe').forEach(frame=>add(frame.contentWindow));}catch(e){}
  }
  return found;
}
function builderRuntimeDocuments(){
  const found=[];
  builderRuntimeWindows().forEach(runtime=>{
    try{if(runtime.document&&!found.includes(runtime.document))found.push(runtime.document);}catch(e){}
  });
  return found;
}
function renderVariablePreviewStyles(){
  const cssText=variablePreviewValues.size
    ? ':root {\n'+Array.from(variablePreviewValues.entries()).map(([name,value])=>`  ${name}: ${value} !important;`).join('\n')+'\n}'
    : '';
  builderRuntimeDocuments().forEach(doc=>{
    try{
      let styleEl=doc.getElementById('ve-variable-preview-runtime');
      if(!cssText){
        styleEl?.remove();
        return;
      }
      if(!styleEl){
        styleEl=doc.createElement('style');
        styleEl.id='ve-variable-preview-runtime';
        (doc.head||doc.documentElement).appendChild(styleEl);
      }
      styleEl.textContent=cssText;
    }catch(e){}
  });
}
function applyVariablePreview(name,value){
  const cssName=cssTokenName(name);
  if(!cssName||!value)return;
  variablePreviewValues.set(cssName,value);
  renderVariablePreviewStyles();
}
function clearVariablePreview(name){
  variablePreviewValues.delete(cssTokenName(name));
  renderVariablePreviewStyles();
}
function refreshVariableStylesheets(){
  const docs=builderRuntimeDocuments();
  let pending=0;
  const announce=()=>{
    syncBricksVariableConsumers();
    builderRuntimeWindows().forEach(win => {
      try {
        win.dispatchEvent(new win.CustomEvent('ve-variables-updated',{detail:{at:Date.now()}}));
        win.document.dispatchEvent(new win.CustomEvent('ve:variables-updated',{detail:{at:Date.now()}}));
      } catch (e) {
        try { win.dispatchEvent(new CustomEvent('ve-variables-updated',{detail:{at:Date.now()}})); } catch (err) {}
      }
    });
  };
  docs.forEach(doc=>{
    Array.from(doc.querySelectorAll('link[rel="stylesheet"]')).filter(link=>{
      const href=link.getAttribute('href')||'';
      return /\/variable-engine\/variables\.css(?:[?#]|$)/.test(href)||/^ve-variables(?:-admin)?-css$/.test(link.id||'');
    }).forEach(link=>{
      let nextUrl;
      try{nextUrl=new URL(link.href,doc.baseURI);nextUrl.searchParams.set('ve-refresh',Date.now().toString());}catch(e){return;}
      const next=link.cloneNode(true);
      next.href=nextUrl.toString();
      next.id=link.id;
      pending++;
      next.addEventListener('load',()=>{link.remove();pending--;if(pending===0)announce();},{once:true});
      next.addEventListener('error',()=>{next.remove();pending--;if(pending===0)announce();},{once:true});
      link.parentNode?.insertBefore(next,link.nextSibling);
    });
  });
  if(pending===0)announce();
}
function refreshSettings(settings){
  builderRuntimeWindows().forEach(win => {
    try {
      win.dispatchEvent(new win.CustomEvent('ve-settings-updated',{detail:settings||{at:Date.now()}}));
    } catch (e) {
      try { win.dispatchEvent(new CustomEvent('ve-settings-updated',{detail:settings||{at:Date.now()}})); } catch (err) {}
    }
  });
}
let bricksVariableSyncPromise=null;
async function syncBricksVariableConsumers(){
  if(MODE!=='builder')return false;
  if(bricksVariableSyncPromise)return bricksVariableSyncPromise;
  bricksVariableSyncPromise=(async()=>{
  let variables;
  try{variables=await api.g('variables?dedupe=true&_nc='+Date.now());}catch(e){return false;}
  if(!Array.isArray(variables))return false;
  const mirrored=variables.map(v=>({
    id:'mv-'+v.id,
    name:cssTokenName(v.name).replace(/^--/,''),
    value:v.css_value||v.value||'',
    category:'mimams-var'
  })).filter(v=>v.name);
  const signature=mirrored.map(v=>v.name+'\u0000'+v.value).join('\u0001');
  const apply=()=>{
    let providerFound=false;
    builderRuntimeWindows().forEach(runtime=>{
      try{
        const current=Array.isArray(runtime.bricksData?.loadData?.globalVariables)?runtime.bricksData.loadData.globalVariables:[];
        const external=current.filter(v=>v&&v.category!=='mimams-var'&&!String(v.id||'').startsWith('mv-'));
        const externalNames=new Set(external.map(v=>String(v?.name||'').replace(/^--/,'')).filter(Boolean));
        const localMirrored=mirrored.filter(v=>!externalNames.has(v.name));
        const runtimeCssText=':root {\n'+localMirrored.map(v=>`  --${v.name}: ${v.value} !important;`).join('\n')+'\n}';
        const changed=runtime.__veVariableSignature!==signature;
        if(changed&&runtime.bricksData?.loadData)runtime.bricksData.loadData.globalVariables=[...external,...localMirrored];
        const provider=runtime.Code2Bricks?.css?.CssVariableProvider;
        if(provider){
          providerFound=true;
          if(changed){
            if(provider.refresh)provider.refresh();
            const mvNames=localMirrored.map(v=>'--'+v.name);
            const existing=Array.isArray(provider._variables)?provider._variables:[];
            provider._variables=Array.from(new Set([...existing,...mvNames])).sort();
            provider._variablesFormatted=provider._variables.map(name=>`var(${name})`);
            provider._lastRefresh=Date.now();
          }
        }
        if(changed&&runtime.document){
          let styleEl=runtime.document.getElementById('ve-dynamic-variables-runtime');
          if(!styleEl){
            styleEl=runtime.document.createElement('style');
            styleEl.id='ve-dynamic-variables-runtime';
            (runtime.document.head||runtime.document.documentElement).appendChild(styleEl);
          }
          styleEl.textContent=runtimeCssText;
          runtime.document.querySelectorAll('iframe').forEach(frame=>{
            if(frame.__veVariableRuntimeLoadBound)return;
            frame.__veVariableRuntimeLoadBound=true;
            frame.addEventListener('load',()=>setTimeout(apply,0));
          });
        }
        runtime.__veVariableSignature=signature;
      }catch(e){}
    });
    renderVariablePreviewStyles();
    return providerFound;
  };
  const providerFound=apply();
  if(!providerFound)setTimeout(apply,600);
  return providerFound;
  })();
  try{return await bricksVariableSyncPromise;}finally{bricksVariableSyncPromise=null;}
}

const USER_PREF_KEYS=[
  'mimamsBarSettings','ve_skip_update_version','ve_panel_mode','ve_panel_pos','ve_allow_multi_panels',
  've_deactivated_tools','ve_deactivated_tool_surfaces',
  've_css_scss','ve_css_source_order','ve_css_disabled_sources',
  've_content_visible_groups','ve_content_visible_groups_v2','ve_content_status_filter','ve_content_table_columns','ve_content_editor_theme','ve_content_studio_default_theme','ve_content_studio_default_view','ve_media_studio_default_view','ve_content_media_picker_view',
  've_media_layout','ve_media_filter','ve_media_sort','ve_media_collection_sort','ve_media_collections','ve_media_list_meta','ve_media_list_meta_fields','ve_media_last_collection','ve_media_as_bricks_picker',
  've_media_quality_filter','ve_media_quality_filters','ve_media_saved_filters','ve_media_detail_preview_mode','ve_media_detail_preview_zoom',
  've_media_dynamic_collapsed','ve_media_sidebar_width','ve_media_hide_folders','ve_media_collapsed_paths','ve_media_replace_wp_library','ve_media_auto_sync_external_folders',
  've_plugin_directory_view','ve_fab_order','ve_tooltips_off','ve_backdrop_intensity','ve_backdrop_off',
  've_pos_ve_settings_pos','ve_pos_ve_help_pos','ve_pos_ve_css_studio_pos','ve_pos_ve_css_recipes_pos',
  've_pos_ve_content_pos','ve_pos_ve_media_pos','ve_pos_ve_plugin_pos','ve_pos_ve_bricks_settings_pos','ve_pos_ve_theme_styles_pos'
];
const USER_PREF_RAW_STRING_KEYS=['ve_media_collections'];
let userPreferenceTimer=null;
function preferenceStorageValue(value){
  return value&&typeof value==='object'?JSON.stringify(value):String(value??'');
}
function hydrateUserPreferences(){
  const remote=CFG.userPreferences&&typeof CFG.userPreferences==='object'?CFG.userPreferences:{};
  Object.keys(remote).forEach(key=>{
    if(!USER_PREF_KEYS.includes(key))return;
    try{
      localStorage.setItem(key,preferenceStorageValue(remote[key]));
    }catch(e){}
  });
  return Object.keys(remote).length>0;
}
function collectUserPreferences(){
  const preferences={};
  USER_PREF_KEYS.forEach(key=>{
    let raw='';
    try{raw=localStorage.getItem(key);}catch(e){raw=null;}
    if(raw===null)return;
    if(USER_PREF_RAW_STRING_KEYS.includes(key)){preferences[key]=raw;return;}
    if(/^[\[{]/.test(raw)){
      try{preferences[key]=JSON.parse(raw);return;}catch(e){}
    }
    preferences[key]=raw;
  });
  return preferences;
}
function syncUserPreferences(strict=false){
  const request=api.p('user-preferences',{preferences:collectUserPreferences()});
  return strict?request.then(result=>{
    if(result?.code)throw new Error(result.message||'Mimam’s Var preferences could not be saved before backup.');
    return result;
  }):request.catch(()=>{});
}
function persistUserPreference(key,value){
  try{localStorage.setItem(key,preferenceStorageValue(value));}catch(e){}
  if(!USER_PREF_KEYS.includes(key))return;
  if(userPreferenceTimer)clearTimeout(userPreferenceTimer);
  userPreferenceTimer=setTimeout(syncUserPreferences,280);
}
window.vePersistUserPreference=persistUserPreference;
window.veSyncUserPreferences=syncUserPreferences;

// After a variable mutation the server regenerates uploads/variable-engine/{variables,advanced}.css,
// but the already-loaded <link> in the admin page and the Bricks canvas iframe still points at the
// stale file — so edits/deletes only show after a manual refresh. Cache-bust those links (in every
// reachable document) so the change reflects live without a reload.
function refreshVariableStylesheets(){
  try{
    const stamp=Date.now();
    const docs=[];
    const add=doc=>{if(doc&&!docs.includes(doc))docs.push(doc);};
    add(document);
    try{Array.from(window.frames||[]).forEach(f=>{try{add(f.document);}catch(e){}});}catch(e){}
    try{document.querySelectorAll('iframe').forEach(f=>{try{add(f.contentDocument||f.contentWindow&&f.contentWindow.document);}catch(e){}});}catch(e){}
    docs.slice(0,10).forEach(doc=>{
      try{
        doc.querySelectorAll('link[rel="stylesheet"][href]').forEach(link=>{
          const href=link.getAttribute('href')||'';
          if(!/variable-engine\/(?:variables|advanced)\.css/i.test(href))return;
          link.setAttribute('href', href.split('?')[0]+'?ve_live='+stamp);
        });
      }catch(e){}
    });
  }catch(e){}
}
window.veRefreshVariableStylesheets=refreshVariableStylesheets;
const hadRemoteUserPreferences=hydrateUserPreferences();
if(!hadRemoteUserPreferences)setTimeout(syncUserPreferences,1200);
else{try{if(localStorage.getItem('ve_media_collections'))setTimeout(syncUserPreferences,1600);}catch(e){}}

function fuzzy(q,tLower){if(tLower.includes(q))return{m:1,s:tLower.indexOf(q)===0?100:80};let i=0,s=0;for(let j=0;j<tLower.length&&i<q.length;j++)if(tLower[j]===q[i]){i++;s+=10;}return{m:i===q.length,s};}
function tokenParts(n){return String(n||'').split('.').filter(Boolean);}
function stripStorageWrapper(n){const p=tokenParts(n);const wrappers=['size','font','typography'];return p.length>1&&wrappers.includes(p[0])?p.slice(1).join('.'):p.join('.');}
function cssTokenName(n){return '--'+stripStorageWrapper(n).replace(/\./g,'-');}
function sn(n){const clean=stripStorageWrapper(n);const p=clean.split('.');return p.length>1?p.slice(1).join('.'):clean;}
function normalizeNameInput(v){return String(v||'').toLowerCase().replace(/[\s._]+/g,'-').replace(/[^a-z0-9-]/g,'').replace(/-+/g,'-').replace(/^-+/,'');}
function publicTokenLabel(n){return cssTokenName(n).replace(/^--/,'');}
function safeFilePart(value,fallback='site'){
  const clean=String(value||'').toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
  return clean||fallback;
}
function detectAliasSource(value, vars){
  if (!value || typeof value !== 'string') return null;
  const clean = value.trim();
  let cssName = '';
  const m1 = clean.match(/^var\(\s*(--[a-z0-9.-]+)\s*\)$/i);
  const m2 = clean.match(/^(--[a-z0-9.-]+)$/i);
  if (m1) cssName = m1[1];
  else if (m2) cssName = m2[1];
  if (cssName) {
    const found = (vars || []).find(v => cssTokenName(v.name).toLowerCase() === cssName.toLowerCase());
    return found ? found.id : null;
  }
  return null;
}
function resolvedVariableValue(v, vars, visited = new Set()) {
  const id=String(v?.id??'');
  if (!v || visited.has(id)) return '';
  visited.add(id);
  if (v.type === 'alias' && v.source_id) {
    const parent = (vars || []).find(x => String(x.id) === String(v.source_id));
    return parent ? resolvedVariableValue(parent, vars, visited) : '';
  }
  return v.value || '';
}
function isClr(v){return/^(#|rgb|hsl|oklch)/i.test(v||'');}
function clrToHex(v){if(!v)return'#000000';if(v.charAt(0)==='#'){let h=v.slice(1);if(h.length===3||h.length===4)h=h[0]+h[0]+h[1]+h[1]+h[2]+h[2]+(h.length===4?h[3]+h[3]:'');return'#'+h.slice(0,6);}
const rm=v.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);if(rm)return'#'+[rm[1],rm[2],rm[3]].map(x=>('0'+(+x).toString(16)).slice(-2)).join('');
const om=v.match(/oklch\(\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)/);if(om){const L=+om[1],C=+om[2],H=+om[3],hr=H*Math.PI/180,a=C*Math.cos(hr),b=C*Math.sin(hr),l_=L+.3963377774*a+.2158037573*b,m_=L-.1055613458*a-.0638541728*b,s_=L-.0894841775*a-1.291485548*b,l=l_*l_*l_,m=m_*m_*m_,s=s_*s_*s_,rl=4.0767416621*l-3.3077115913*m+.2309699292*s,gl=-1.2684380046*l+2.6097574011*m-.3413193965*s,bl=-.0041960863*l-.7034186147*m+1.707614701*s,gm=x=>x<=.0031308?12.92*x:1.055*Math.pow(Math.max(0,x),1/2.4)-.055,r=Math.round(Math.max(0,Math.min(1,gm(rl)))*255),g=Math.round(Math.max(0,Math.min(1,gm(gl)))*255),bv=Math.round(Math.max(0,Math.min(1,gm(bl)))*255);return'#'+('0'+r.toString(16)).slice(-2)+('0'+g.toString(16)).slice(-2)+('0'+bv.toString(16)).slice(-2);}
const hm=v.match(/hsla?\(\s*([\d.]+)\s*,?\s*([\d.]+)%?\s*,?\s*([\d.]+)%?/);if(hm){const hu=+hm[1]/360,sa=+hm[2]/100,li=+hm[3]/100,q=li<.5?li*(1+sa):li+sa-li*sa,p=2*li-q,h2r=(pp,qq,t)=>{if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return pp+(qq-pp)*6*t;if(t<.5)return qq;if(t<2/3)return pp+(qq-pp)*(2/3-t)*6;return pp;},r=Math.round((sa===0?li:h2r(p,q,hu+1/3))*255),g=Math.round((sa===0?li:h2r(p,q,hu))*255),bv=Math.round((sa===0?li:h2r(p,q,hu-1/3))*255);return'#'+('0'+r.toString(16)).slice(-2)+('0'+g.toString(16)).slice(-2)+('0'+bv.toString(16)).slice(-2);}
return'#000000';}
function clrAlpha(v){
  const raw=String(v||'').trim();
  if(raw.charAt(0)==='#'){
    const hex=raw.slice(1);
    if(hex.length===4)return parseInt(hex.charAt(3)+hex.charAt(3),16)/255;
    if(hex.length===8)return parseInt(hex.slice(6,8),16)/255;
  }
  const slash=raw.match(/\/\s*([\d.]+)(%)?\s*\)$/);
  if(slash)return Math.max(0,Math.min(1,+slash[1]/(slash[2]?100:1)));
  const legacy=raw.match(/(?:rgba|hsla)\([^)]*,\s*([\d.]+)(%)?\s*\)$/i);
  if(legacy)return Math.max(0,Math.min(1,+legacy[1]/(legacy[2]?100:1)));
  return 1;
}
function normAlpha(value){const alpha=Number(value);return Number.isFinite(alpha)?Math.max(0,Math.min(1,alpha)):1;}
function alphaText(value){return String(Math.round(normAlpha(value)*1000)/1000).replace(/^0\./,'.');}
function hexWithAlpha(hex,alpha){
  const base=clrToHex(hex);
  const clean=normAlpha(alpha);
  return clean>=.999?base:base+Math.round(clean*255).toString(16).padStart(2,'0');
}
function pxV(v){const str=(v||'').toString();const cm=str.match(/clamp\([^,]+,[^,]+,\s*([\d.]+)(rem|px)?/i);if(cm){return (cm[2]||'')==='rem'?parseFloat(cm[1])*10:parseFloat(cm[1]);}const m=str.match(/([\d.]+)(rem|px)?/i);if(!m)return 0;return (m[2]||'')==='rem'?parseFloat(m[1])*10:parseFloat(m[1]);}
function pxToRemValue(v){const n=parseFloat((v||'').toString().replace(/[^0-9.]/g,''));if(!isFinite(n))return'';return (Math.round((n/10)*10000)/10000).toString().replace(/\.?0+$/,'')+'rem';}
/* ── Fluid value helpers (mirror core/FluidValue.php) ── */
const FLUID_PREFIX='fluid:';
let _veViewport={vw_min:320,vw_max:1440};
function isFluidVal(v){return (v||'').toString().trim().toLowerCase().indexOf(FLUID_PREFIX)===0;}
function fluidMarker(min,max){const a=parseFloat(min),b=parseFloat(max);if(!isFinite(a)||!isFinite(b))return'';return FLUID_PREFIX+trimNum(a)+','+trimNum(b);}
function parseFluid(v){if(!isFluidVal(v))return null;const body=(v||'').toString().trim().slice(FLUID_PREFIX.length);const p=body.split(',').map(s=>s.trim());if(p.length!==2||!isFinite(parseFloat(p[0]))||!isFinite(parseFloat(p[1])))return null;return[parseFloat(p[0]),parseFloat(p[1])];}
function trimNum(n){let s=(Math.round(n*10000)/10000).toString();return s;}
function fluidClamp(minPx,maxPx,vwMin,vwMax,unit){let a=Math.round(minPx*1000)/1000,b=Math.round(maxPx*1000)/1000;if(a>b){const t=a;a=b;b=t;}let span=vwMax-vwMin;if(span<=0)span=1;const slope=(b-a)/span;const intercept=a-slope*vwMin;const slopeVw=Math.round(slope*100*10000)/10000;if(unit==='px'){return`clamp(${trimNum(a)}px, ${trimNum(Math.round(intercept*1000)/1000)}px + ${slopeVw}vw, ${trimNum(b)}px)`;}return`clamp(${trimNum(Math.round(a/10*10000)/10000)}rem, ${trimNum(Math.round(intercept/10*10000)/10000)}rem + ${slopeVw}vw, ${trimNum(Math.round(b/10*10000)/10000)}rem)`;}
function fluidPreview(min,max){const a=parseFloat(min),b=parseFloat(max);if(!isFinite(a)||!isFinite(b))return'';return fluidClamp(a,b,_veViewport.vw_min,_veViewport.vw_max,'rem');}
function hexOklch(hex){hex=hex.replace('#','');if(hex.length===3)hex=hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];const r=parseInt(hex.substr(0,2),16)/255,g=parseInt(hex.substr(2,2),16)/255,b=parseInt(hex.substr(4,2),16)/255;const f=v=>v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);const rl=f(r),gl=f(g),bl=f(b);const l_=.4122214708*rl+.5363325363*gl+.0514459929*bl,m_=.2119034982*rl+.6806995451*gl+.1073969566*bl,s_=.0883024619*rl+.2817188376*gl+.6299787005*bl;const lc=Math.cbrt(Math.max(0,l_)),mc=Math.cbrt(Math.max(0,m_)),sc=Math.cbrt(Math.max(0,s_));const L=.2104542553*lc+.793617785*mc-.0040720468*sc,a=1.9779984951*lc-2.428592205*mc+.4505937099*sc,bv=.0259040371*lc+.7827717662*mc-.808675766*sc;const cc=Math.sqrt(a*a+bv*bv);let H=Math.atan2(bv,a)*180/Math.PI;if(H<0)H+=360;return`oklch(${Math.max(0,Math.min(1,L)).toFixed(4)} ${cc.toFixed(4)} ${H.toFixed(2)})`;}
function colorOklch(hex,alpha){const value=hexOklch(hex);const clean=normAlpha(alpha);return clean>=.999?value:value.replace(/\)$/,' / '+alphaText(clean)+')');}
function fmtD(hex,fmt,alpha=1){const clean=normAlpha(alpha),suffix=clean>=.999?'':' / '+alphaText(clean);if(fmt==='oklch')return colorOklch(hex,clean);const rr=parseInt(hex.replace('#','').substr(0,2),16),gg=parseInt(hex.replace('#','').substr(2,2),16),bb=parseInt(hex.replace('#','').substr(4,2),16);if(fmt==='hex')return hexWithAlpha(hex,clean);if(fmt==='rgb')return`rgb(${rr} ${gg} ${bb}${suffix})`;const rn=rr/255,gn=gg/255,bn=bb/255,mx=Math.max(rn,gn,bn),mn=Math.min(rn,gn,bn),l=(mx+mn)/2;let hu=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);if(mx===rn)hu=((gn-bn)/d+(gn<bn?6:0))/6;else if(mx===gn)hu=((bn-rn)/d+2)/6;else hu=((rn-gn)/d+4)/6;}return`hsl(${Math.round(hu*360)} ${Math.round(s*100)}% ${Math.round(l*100)}%${suffix})`;}
const ph=(n,props={})=>h('i',{...(props||{}),class:`ph-duotone ph-${n} `+(props.class||''),style:props.style||'font-size:13px;line-height:1'});
const IX_PATHS={
  filter:[['M4 6h16',.9],['M7 12h10',.9],['M10 18h4',.9],['M8 4v4M16 10v4M12 16v4',.35]],
  x:[['M7 7l10 10M17 7L7 17',.9]],
  plus:[['M12 5v14M5 12h14',.9]],
  trash:[['M7 8h10M10 11v6M14 11v6M9 8l1-2h4l1 2M8 8l1 12h6l1-12',.9]],
  'pencil-simple':[['M5 16l-1 4 4-1 10-10-3-3L5 16z',.9],['M13 6l3 3',.35]],
  'tree-structure':[['M7 5h5v5H7zM12 7h5v10M7 17h5',.75],['M5 15h4v4H5zM15 15h4v4h-4z',.9]],
  'folder-open':[['M3 8h7l2 2h9l-2 9H4z',.9],['M3 8v10',.35]],
  folder:[['M3 7h7l2 2h9v10H3z',.9]],
  'folder-dashed':[['M3 8h6l2 2h10v9H3z',.45],['M5 8h2M12 10h3M17 10h2',.9]],
  'download-simple':[['M12 4v11M8 11l4 4 4-4',.9],['M5 20h14',.35]],
  'upload-simple':[['M12 20V9M8 13l4-4 4 4',.9],['M5 20h14',.35]],
  'arrows-merge':[['M7 4v4c0 4 10 4 10 8v4',.75],['M17 4v6M14 7l3 3 3-3M14 17l3 3 3-3',.9]],
  'arrows-clockwise':[['M7 7a7 7 0 0110-1l2 2M17 17a7 7 0 01-10 1l-2-2',.9]],
  'arrows-out-line-vertical':[['M12 4v16M8 8l4-4 4 4M8 16l4 4 4-4',.9]],
  command:[['M8 8h8v8H8z',.35],['M7 4a3 3 0 013 3v10a3 3 0 11-3-3h10a3 3 0 11-3 3V7a3 3 0 113-3',.85]],
  'magic-wand':[['M5 19L19 5',.9],['M14 4l1 2 2 1-2 1-1 2-1-2-2-1 2-1zM6 6l1 1M4 11h2M11 4v2',.65]],
  images:[['M4 6h13v10H4z',.65],['M7 9l3 3 2-2 3 4',.9],['M8 18h12V9',.35]],
  tray:[['M5 5h14v9l-3 5H8l-3-5z',.65],['M8 14h2l1 2h2l1-2h2',.9]],
  'lock-simple':[['M7 10h10v10H7z',.75],['M9 10V8a3 3 0 016 0v2',.9]],
  'lock-open':[['M7 10h10v10H7z',.75],['M9 10V8a3 3 0 015.2-2',.9]],
  'dots-six-vertical':[['M8 5h.1M8 12h.1M8 19h.1M16 5h.1M16 12h.1M16 19h.1',.9]],
  copy:[['M8 8h10v10H8z',.85],['M5 5h10',.35],['M5 5v10',.35]],
  'file-arrow-down':[['M7 4h7l4 4v12H7z',.55],['M14 4v5h4M12 11v6M9 14l3 3 3-3',.9]],
  eye:[['M3 12s3-6 9-6 9 6 9 6-3 6-9 6-9-6-9-6z',.55],['M12 9a3 3 0 100 6 3 3 0 000-6z',.9]],
  'eye-slash':[['M4 4l16 16',.9],['M3 12s3-6 9-6c2 0 3.8.6 5.2 1.4M21 12s-3 6-9 6c-2 0-3.8-.6-5.2-1.4',.45]],
  columns:[['M4 5h16v14H4z',.35],['M10 5v14M15 5v14',.9]],
  table:[['M4 5h16v14H4z',.45],['M4 10h16M4 15h16M10 5v14',.9]],
  'squares-four':[['M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z',.85]],
  'grid-four':[['M4 5h7v5H4zM13 5h7v8h-7zM4 12h7v7H4zM13 15h7v4h-7z',.85]],
  masonry:[['M4 4h4v7H4zM4 13h4v7H4zM10 4h4v4h-4zM10 10h4v10h-4zM16 4h4v9h-4zM16 15h4v5h-4z',.9]],
  list:[['M8 6h12M8 12h12M8 18h12',.9],['M4 6h1M4 12h1M4 18h1',.9]],
  'text-aa':[['M4 18l4-12 4 12M6 14h4',.9],['M14 18l2-6 2 6M15 16h2',.65]],
  'hard-drive':[['M5 6h14l2 8v4H3v-4z',.65],['M6 15h12M17 16h1',.9]],
  'bounding-box':[['M5 5h5M14 5h5M5 19h5M14 19h5M5 5v5M19 5v5M5 14v5M19 14v5',.9]],
  'image-square':[['M4 5h16v14H4z',.55],['M7 15l3-3 2 2 3-4 3 5',.9]],
  'device-mobile':[['M8 3h8v18H8z',.65],['M11 18h2',.9]],
  square:[['M5 5h14v14H5z',.85]],
  'caret-down':[['M8 10l4 4 4-4',.9]],
  'caret-right':[['M10 8l4 4-4 4',.9]]
};
const ix=(name,props={})=>{
  const paths=IX_PATHS[name]||IX_PATHS.square;
  return h('svg',{...(props||{}),class:'ve-ix ve-ix-'+name+' '+(props.class||''),viewBox:'0 0 24 24','aria-hidden':'true',focusable:'false',style:props.style||{}},
    paths.map((p,i)=>h('path',{key:i,d:p[0],opacity:p[1]||1,fill:'none',stroke:'currentColor','stroke-width':'1.8','stroke-linecap':'round','stroke-linejoin':'round'}))
  );
};
const TOOL_DEFINITIONS=[
  {id:'variables',label:'Variable Panel',icon:'sliders-horizontal',module:'variables',speedDial:true,studioRail:true,studioRailOrder:10},
  {id:'help',label:'Docs',icon:'book-open',module:'help',speedDial:true,studioRail:true,studioRailOrder:80},
  {id:'css_studio',label:'CSS Studio',icon:'code',module:'css_studio',speedDial:true,studioRail:true,studioRailOrder:20},
  {id:'css_recipes',label:'CSS Recipes',icon:'brackets-curly',module:'css_recipes',speedDial:true,studioRail:true,studioRailOrder:25},
  {id:'content_studio',label:'Content Studio',icon:'file-text',module:'content_studio',speedDial:true,studioRail:true,studioRailOrder:40},
  {id:'media_studio',label:'Media Studio',icon:'image',module:'media_studio',speedDial:true,studioRail:true,studioRailOrder:30},
  {id:'font_manager',label:'Font Manager',icon:'text-aa',module:'font_manager',speedDial:true,studioRail:true,studioRailOrder:35},
  {id:'plugin_studio',label:'Plugin Studio',icon:'plugs',module:'plugin_studio',speedDial:true,studioRail:true,studioRailOrder:50},
  {id:'bricks_settings',label:'Bricks Settings',icon:'squares-four',module:'bricks_settings',speedDial:true,studioRail:true,studioRailOrder:55},
  {id:'theme_styles',label:'Theme Styles',icon:'paint-brush',module:'theme_styles',speedDial:true,studioRail:true,studioRailOrder:57},
  {id:'recovery',label:'Recovery (Backup & Restore)',icon:'arrow-counter-clockwise',module:'recovery',speedDial:true,studioRail:true,studioRailOrder:60,adminOnly:true},
  {id:'mimams_bar',label:"Mimam's Bar (Alt+Q)",icon:'terminal',module:'mimams_bar',speedDial:true},
  {id:'settings',label:'Settings',icon:'gear',studioRail:true,studioRailOrder:90}
];
const TOOL_BY_ID=Object.fromEntries(TOOL_DEFINITIONS.map(tool=>[tool.id,tool]));
const SPEED_DIAL_TOOLS=TOOL_DEFINITIONS.filter(tool=>tool.speedDial&&!(tool.adminOnly&&MODE==='builder'));
const STUDIO_RAIL_TOOLS=TOOL_DEFINITIONS.filter(tool=>tool.studioRail&&!(tool.adminOnly&&MODE==='builder')).sort((a,b)=>(a.studioRailOrder||999)-(b.studioRailOrder||999));
function toolLabel(id){return TOOL_BY_ID[id]?.label||'This module';}
function toolModuleId(id){return TOOL_BY_ID[id]?.module||id;}
function normalizeFabOrder(order){
  const ids=SPEED_DIAL_TOOLS.map(tool=>tool.id);
  const seen=new Set();
  const clean=(Array.isArray(order)?order:[]).filter(id=>ids.includes(id)&&!seen.has(id)&&(seen.add(id),true));
  return [...clean,...ids.filter(id=>!seen.has(id))];
}
function readStoredJson(key,fallback){
  try{
    const raw=localStorage.getItem(key);
    return raw===null?fallback:JSON.parse(raw);
  }catch(e){return fallback;}
}
function readFabOrder(){return normalizeFabOrder(readStoredJson('ve_fab_order',[]));}
function normalizeToolSurfaces(value){
  return{
    admin:Array.isArray(value?.admin)?value.admin:[],
    builder:Array.isArray(value?.builder)?value.builder:[]
  };
}
function hasToolSurfaceChoice(id,surfaces){
  return surfaces.admin.includes(id)||surfaces.builder.includes(id);
}
function disabledToolsForSurface(settings,surface){
  const legacy=Array.isArray(settings?.deactivated_tools)?settings.deactivated_tools:[];
  const surfaces=normalizeToolSurfaces(settings?.deactivated_tool_surfaces);
  const unresolvedLegacy=legacy.filter(id=>!hasToolSurfaceChoice(id,surfaces));
  return[...new Set([...unresolvedLegacy,...surfaces[surface]])];
}
function useOpenedOnce(open){
  const[hasOpened,setHasOpened]=useState(false);
  useEffect(()=>{if(open)setHasOpened(true);},[open]);
  return hasOpened;
}
function useExclusivePanel(open,id,allowMultiple,closeOthers){
  useEffect(()=>{if(!allowMultiple&&open)closeOthers(id);},[open,id,allowMultiple,closeOthers]);
}
const TSHIRT_UP=['s','m','l','xl','2xl','3xl','4xl','5xl','6xl','7xl','8xl'];
const TSHIRT_DN=['xs','2xs','3xs','4xs','5xs','6xs','7xs','8xs'];
const SCALES=['minor-second','major-second','minor-third','major-third','perfect-fourth','augmented-fourth','perfect-fifth','golden'];
const CSS_PROPS=['align-content','align-items','align-self','animation','animation-delay','animation-duration','animation-name','appearance','aspect-ratio','backdrop-filter','background','background-attachment','background-blend-mode','background-clip','background-color','background-image','background-position','background-repeat','background-size','block-size','border','border-block','border-block-color','border-block-end','border-block-start','border-bottom','border-bottom-color','border-bottom-left-radius','border-bottom-right-radius','border-bottom-width','border-color','border-inline','border-inline-color','border-inline-end','border-inline-start','border-left','border-left-color','border-left-width','border-radius','border-right','border-right-color','border-right-width','border-style','border-top','border-top-color','border-top-left-radius','border-top-right-radius','border-top-width','border-width','bottom','box-shadow','box-sizing','clear','clip-path','color','column-gap','container','container-name','container-type','content','cursor','display','filter','flex','flex-basis','flex-direction','flex-flow','flex-grow','flex-shrink','flex-wrap','font','font-family','font-size','font-style','font-weight','gap','grid','grid-area','grid-auto-columns','grid-auto-flow','grid-auto-rows','grid-column','grid-template','grid-template-areas','grid-template-columns','grid-template-rows','height','inline-size','inset','inset-block','inset-block-end','inset-block-start','inset-inline','inset-inline-end','inset-inline-start','isolation','justify-content','justify-items','justify-self','left','letter-spacing','line-height','list-style','margin','margin-block','margin-block-end','margin-block-start','margin-bottom','margin-inline','margin-inline-end','margin-inline-start','margin-left','margin-right','margin-top','max-block-size','max-height','max-inline-size','max-width','min-block-size','min-height','min-inline-size','min-width','mix-blend-mode','object-fit','object-position','opacity','order','outline','overflow','overflow-block','overflow-inline','overflow-x','overflow-y','padding','padding-block','padding-block-end','padding-block-start','padding-bottom','padding-inline','padding-inline-end','padding-inline-start','padding-left','padding-right','padding-top','place-content','place-items','pointer-events','position','right','row-gap','scroll-margin','scroll-margin-block','scroll-margin-inline','scroll-padding','scroll-padding-block','scroll-padding-inline','text-align','text-decoration','text-transform','top','transform','transform-origin','transition','transition-delay','transition-duration','transition-property','translate','user-select','vertical-align','visibility','white-space','width','will-change','z-index'];
const CSS_VALUES=['auto','block','inline-block','flex','grid','none','relative','absolute','fixed','sticky','hidden','visible','center','space-between','space-around','space-evenly','start','end','stretch','cover','contain','pointer','default','transparent','currentColor','inherit','initial','unset'];
const CSS_LOGICAL_PROPS=['block-size','inline-size','min-block-size','max-block-size','min-inline-size','max-inline-size','margin-block','margin-block-start','margin-block-end','margin-inline-start','margin-inline-end','padding-block','padding-block-start','padding-block-end','padding-inline-start','padding-inline-end','border-block','border-block-color','border-block-start','border-block-start-color','border-block-start-style','border-block-start-width','border-block-end','border-block-end-color','border-block-end-style','border-block-end-width','border-inline','border-inline-color','border-inline-start','border-inline-start-color','border-inline-start-style','border-inline-start-width','border-inline-end','border-inline-end-color','border-inline-end-style','border-inline-end-width','inset-block','inset-block-start','inset-block-end','inset-inline','inset-inline-start','inset-inline-end'];
CSS_PROPS.push(...CSS_LOGICAL_PROPS.filter(x=>!CSS_PROPS.includes(x)));
const CSS_SELECTOR_HINTS=['a','article','aside','body','button','canvas','code','dialog','div','fieldset','figure','footer','form','h1','h2','h3','h4','h5','h6','header','html','iframe','img','input','label','li','main','nav','ol','option','p','picture','section','select','span','svg','table','textarea','ul',':active',':checked',':disabled',':empty',':enabled',':first-child',':first-of-type',':focus',':focus-visible',':hover',':is()',':last-child',':last-of-type',':not()',':nth-child()',':nth-of-type()',':root',':where()','::after','::before','::marker','::placeholder','@container','@font-face','@keyframes','@layer','@media','@supports'];
const CSS_SOURCE_DEFAULTS=["Mimam's Var",'Advanced Themer','Bricks','Core Framework','Automatic.css','CSS Classes','Element IDs'];
const CSS_RECIPES=[
  {name:'Section rhythm',code:'@rhythm',css:'.section {\n  padding-block: var(--space-xl);\n  gap:var(--space-m);\n}'},
  {name:'Fluid card grid',code:'@grid',css:'.card-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(min(100%, 280px), 1fr));\n  gap:var(--space-m);\n}'},
  {name:'Focus ring',code:'@focus',css:':where(a, button, input, textarea, select):focus-visible {\n  outline: 2px solid var(--color-primary);\n  outline-offset: 3px;\n}'}
];
function loadUserCssRecipes(){try{const r=JSON.parse(localStorage.getItem('ve_css_recipes')||'[]');return Array.isArray(r)?r.filter(x=>x&&x.code&&x.css):[];}catch(e){return[];}}
function saveUserCssRecipes(list){localStorage.setItem('ve_css_recipes',JSON.stringify(list||[]));window.dispatchEvent(new CustomEvent('ve-css-recipes-changed'));}
function getCssRecipes(){const seen={};return [...CSS_RECIPES,...loadUserCssRecipes()].filter(r=>{const k=String(r.code||'').trim();if(!k||seen[k])return false;seen[k]=1;return true;});}
const CSS_HINT_LIMIT=72;
const DEFAULT_CSS_SHEETS=[
  {id:'global',name:'global.css',scope:'global',enabled:true,css:''}
];
const VE_MEDIA_CACHE_KEY='ve_media_library_cache_v2';
const readMediaCacheSnapshot=()=>{
  try{
    const cached=JSON.parse(sessionStorage.getItem(VE_MEDIA_CACHE_KEY)||'null');
    if(!cached||!Array.isArray(cached.items)||!cached.items.length)return null;
    if(Date.now()-Number(cached.at||0)>15*60*1000)return null;
    return cached;
  }catch(e){return null;}
};
const initialMediaCache=readMediaCacheSnapshot();
const VE_MEDIA_CACHE={items:initialMediaCache?.items||null,folders:null,at:Number(initialMediaCache?.at||0),listeners:new Set()};
let VE_MEDIA_PREFETCH_PROMISE=null;
function publishMediaCache(items,complete=false){
  if(!Array.isArray(items))return items;
  VE_MEDIA_CACHE.items=items;
  VE_MEDIA_CACHE.at=Date.now();
  try{sessionStorage.setItem(VE_MEDIA_CACHE_KEY,JSON.stringify({items,at:VE_MEDIA_CACHE.at}));}catch(e){}
  VE_MEDIA_CACHE.listeners.forEach(listener=>{try{listener(items,{complete});}catch(e){}});
  return items;
}
function subscribeMediaCache(listener){
  VE_MEDIA_CACHE.listeners.add(listener);
  return()=>VE_MEDIA_CACHE.listeners.delete(listener);
}
async function fetchMediaLibraryPages(query='',publishProgress=false){
  const all=[];
  for(let page=1;page<=100;page++){
    let endpoint='wp/v2/media?per_page=100&page='+page;
    if(query)endpoint+='&search='+encodeURIComponent(query);
    const res=await api.f(endpoint);
    if(res?.code==='rest_post_invalid_page_number')break;
    if(res?.code)throw new Error(res.message||'Media Studio could not read the media library.');
    if(!Array.isArray(res)||!res.length)break;
    all.push(...res);
    if(publishProgress)publishMediaCache(all.slice(),res.length<100);
    if(res.length<100)break;
  }
  return all;
}
function prefetchMediaLibrary(force=false){
  const cacheFresh=Array.isArray(VE_MEDIA_CACHE.items)&&Date.now()-Number(VE_MEDIA_CACHE.at||0)<60*1000;
  if(cacheFresh&&!force)return Promise.resolve(VE_MEDIA_CACHE.items);
  if(VE_MEDIA_PREFETCH_PROMISE)return VE_MEDIA_PREFETCH_PROMISE;
  VE_MEDIA_PREFETCH_PROMISE=fetchMediaLibraryPages('',true)
    .then(items=>publishMediaCache(items,true))
    .finally(()=>{VE_MEDIA_PREFETCH_PROMISE=null;});
  return VE_MEDIA_PREFETCH_PROMISE;
}
const NS_CLR={color:'#ef4444',space:'#3b82f6',spacing:'#3b82f6',font:'#a855f7',typography:'#a855f7',heading:'#c084fc',text:'#8b5cf6',weight:'#d946ef',radius:'#f59e0b',size:'#22c55e',scale:'#84cc16',stroke:'#14b8a6','stroke-width':'#14b8a6',shadow:'#6b7280',opacity:'#06b6d4',motion:'#ec4899',grid:'#22c55e',design:'#baf400'};
function variableNamespace(v){
  if(v?.palette_eligible)return'color';
  return v?.category_slug||'uncategorized';
}
function variableOriginKey(v){return String(v?.origin||'mv').toLowerCase();}
function variableOriginLabel(v){return({mv:'MV',wordpress:'MV',at:'AT',cf:'CF',acss:'ACSS',figma:'Figma',file:'FILE',json:'FILE',css:'FILE',dtcg:'FILE',import:'FILE'})[variableOriginKey(v)]||'MV';}
function variableOriginTitle(v){return({mv:"Created in Mimam's Var",wordpress:"Created in Mimam's Var",at:'Imported from Advanced Themer',cf:'Imported from Core Framework',acss:'Imported from Automatic.css',figma:'Imported from Figma',file:'Imported from a file',json:'Imported from a JSON file',css:'Imported from a CSS file',dtcg:'Imported from a DTCG file',import:'Imported from a file'})[variableOriginKey(v)]||"Created in Mimam's Var";}
const VARIABLE_ORIGINS=['mv','file','figma','at','cf','acss'];
function normalizedVariableOrigin(v){
  const key=variableOriginKey(v);
  if(['file','json','css','dtcg','import'].includes(key))return'file';
  if(key==='wordpress')return'mv';
  return VARIABLE_ORIGINS.includes(key)?key:'mv';
}
function OriginPill({variable,onFilter,active=false}){
  const key=normalizedVariableOrigin(variable);
  return h('button',{
    type:'button',
    class:'ve-origin-pill'+(active?' active':''),
    title:variableOriginTitle(variable)+' · Click to filter this source',
    onClick:e=>{e.stopPropagation();onFilter&&onFilter(key);}
  },variableOriginLabel(variable));
}
function stripeColor(v){const p=tokenParts(v?.name);for(const k of [variableNamespace(v),p[0],p[1],p[2],v?.namespace]){if(k&&NS_CLR[k])return NS_CLR[k];}return'#8b949e';}

const SLIDE_MS=200;



function wireGsapHover(root){
  if(!root)return;
}

function Sw({v}){return h('div',{class:'ve-sw',style:isClr(v)?`background:${v}`:'background:repeating-conic-gradient(#333 0% 25%,#2a2a2a 0% 50%) 50%/8px 8px'});}

/* ── Sub-panel wrapper with slide-out animation ── */
function Sub({title,onClose,onBack,children,exiting,sidecar,bodyClass}){
  const[closing,sC]=useState(false);
  const isOut=closing||exiting;
  const doClose=useCallback(()=>{sC(true);setTimeout(onClose,SLIDE_MS);},[onClose]);
  const handleBack=onBack||doClose;
  const icon=sidecar&&!onBack?'x':'arrow-left';
  return h('div',{class:'ve-sub'+(sidecar?' ve-sidecar':'')+(isOut?' closing':'')},
    h('div',{class:'ve-sub-hdr'},h('button',{class:'ve-exp',onClick:handleBack,title:onBack?'Back':'Close'},ph(icon)),h('span',null,title)),
    h('div',{class:'ve-sub-body'+(bodyClass?' '+bodyClass:'')},typeof children==='function'?children(doClose):children));
}

function searchableOptionScore(option,query,index){
  const label=String(option?.label||'').toLowerCase();
  const value=String(option?.value||'').toLowerCase();
  const q=String(query||'').trim().toLowerCase();
  if(!q)return[index,label];
  const tokens=label.split(/[\s._-]+/).filter(Boolean);
  let score=1000;
  if(label===q||value===q)score=0;
  else if(label.startsWith(q)||value.startsWith(q))score=10;
  else if(tokens.some(token=>token===q))score=20;
  else if(tokens.some(token=>token.startsWith(q)))score=30;
  else{
    const labelAt=label.indexOf(q);
    const valueAt=value.indexOf(q);
    const at=Math.min(labelAt<0?999:valueAt<0?999:valueAt,labelAt<0?999:labelAt);
    if(at<999)score=40+at;
  }
  return[score,label.length,index,label];
}
// Keep spaces in an uploaded filename for the Content-Disposition header. Encoding
// them to %20 makes WordPress' sanitizer strip the "%" and leave "20"
// ("campaign monitoring" → "campaign20monitoring"). Preserve printable ASCII
// (spaces included), drop header-breaking characters, and replace non-ASCII.
function headerSafeFilename(name){
  return String(name || 'upload').replace(/[\r\n"\\]/g, '').replace(/[^\x20-\x7E]/g, '_') || 'upload';
}
function ownedOverlayBounds(trigger,padding=8){
  const owner=trigger?.closest?.('.ve-standalone-panel,.ve-o[data-panel],.ve-content-studio,.ve-media-studio,.ve-plugin-studio,.ve-modal-box,.rb-panel');
  const rect=owner?.getBoundingClientRect?.();
  return{
    owner,
    left:Math.max(padding,rect?rect.left+padding:padding),
    top:Math.max(padding,rect?rect.top+padding:padding),
    right:Math.min(window.innerWidth-padding,rect?rect.right-padding:window.innerWidth-padding),
    bottom:Math.min(window.innerHeight-padding,rect?rect.bottom-padding:window.innerHeight-padding)
  };
}
function SelectMenu({value,onChange,options,className,disabled,searchable,searchPlaceholder}){
  const[open,sOpen]=useState(false);
  const[query,sQuery]=useState('');
  const[activeIndex,sActiveIndex]=useState(0);
  const ref=useRef();
  const buttonRef=useRef();
  const portalRef=useRef();
  const keyNavRef=useRef(false);
  const opts=(options||[]).map(o=>typeof o==='string'?{value:o,label:o}:o);
  const normalizedQuery=String(query||'').trim().toLowerCase();
  const filteredOpts=searchable&&normalizedQuery
    ?opts.map((o,index)=>({o,rank:searchableOptionScore(o,normalizedQuery,index)}))
      .filter(item=>item.rank[0]<1000)
      .sort((a,b)=>{for(let i=0;i<Math.max(a.rank.length,b.rank.length);i++){if(a.rank[i]<b.rank[i])return-1;if(a.rank[i]>b.rank[i])return 1;}return 0;})
      .map(item=>item.o)
    :opts;
  const isContentTermMenu=String(className||'').split(/\s+/).includes('ve-content-term-add');
  const filteredCount=filteredOpts.length;
  const menuOpts=isContentTermMenu?filteredOpts.filter(o=>String(o.value)!==''):filteredOpts;
  const optionGroup=o=>String(o?.group||(isContentTermMenu?'Choose term':'Options')).trim();
  const groupCount=new Set(menuOpts.map(optionGroup)).size;
  const cur=opts.find(o=>String(o.value)===String(value))||opts[0]||{value:'',label:''};
  const choose=o=>{if(!o)return;onChange&&onChange(o.value);sOpen(false);sQuery('');sActiveIndex(0);};
  const onMenuKey=e=>{
    if(e.key==='Escape'){e.preventDefault();e.stopPropagation();sOpen(false);return;}
    if(e.key==='ArrowDown'||e.key==='ArrowUp'){
      e.preventDefault();e.stopPropagation();
      if(!menuOpts.length)return;
      keyNavRef.current=true;
      sActiveIndex(current=>(current+(e.key==='ArrowDown'?1:-1)+menuOpts.length)%menuOpts.length);
      return;
    }
    if(e.key==='Home'||e.key==='End'){
      e.preventDefault();e.stopPropagation();keyNavRef.current=true;sActiveIndex(e.key==='Home'?0:Math.max(0,menuOpts.length-1));return;
    }
    if(e.key==='Enter'){
      e.preventDefault();e.stopPropagation();choose(menuOpts[Math.min(activeIndex,Math.max(0,menuOpts.length-1))]);}
  };
  useEffect(()=>{
    const selectedIndex=menuOpts.findIndex(o=>String(o.value)===String(value));
    sActiveIndex(Math.max(0,selectedIndex));
  },[query,open,value]);
  useEffect(()=>{
    if(!open)return;
    const close=e=>{if(ref.current&&!ref.current.contains(e.target)&&(!portalRef.current||!portalRef.current.contains(e.target)))sOpen(false);};
    document.addEventListener('pointerdown',close,true);
    return()=>document.removeEventListener('pointerdown',close,true);
  },[open]);
  useEffect(()=>{
    if(!open)return;
    const portal=document.createElement('div');
    const themeClass=(buttonRef.current?.closest?.('.ve-cs-light')?' ve-menu-light':'')
      +(buttonRef.current?.closest?.('.ve-fg-root')?' ve-menu-round':'');
    portal.className='ve-menu-portal'+themeClass+(isContentTermMenu?' ve-content-term-portal':'');
    document.body.appendChild(portal);
    portalRef.current=portal;
    return()=>{
      render(null,portal);
      portal.remove();
      if(portalRef.current===portal)portalRef.current=null;
    };
  },[open]);
  useEffect(()=>{
    if(!open||!buttonRef.current||!portalRef.current)return;
    const portal=portalRef.current;
    const place=()=>{
      if(!buttonRef.current)return;
      const rect=buttonRef.current.getBoundingClientRect();
      const bounds=ownedOverlayBounds(buttonRef.current,8);
      const requestedWidth=isContentTermMenu?190:0;
      const portalWidth=Math.min(Math.max(44,bounds.right-bounds.left),Math.max(rect.width,requestedWidth));
      const wanted=Math.min(340,Math.max(44,menuOpts.length*32+14+(searchable?40:0)+groupCount*25));
      const roomBelow=Math.max(0,bounds.bottom-rect.bottom-6);
      const roomAbove=Math.max(0,rect.top-bounds.top-6);
      const openUp=roomBelow<wanted&&roomAbove>roomBelow;
      const available=Math.max(44,Math.min(340,openUp?roomAbove:roomBelow));
      const themeClass=(buttonRef.current.closest?.('.ve-cs-light')?' ve-menu-light':'')
        +(buttonRef.current.closest?.('.ve-fg-root')?' ve-menu-round':'');
      portal.className='ve-menu-portal'+(openUp?' up':'')+themeClass+(isContentTermMenu?' ve-content-term-portal':'');
      portal.style.left=Math.max(bounds.left,Math.min(rect.left,bounds.right-portalWidth))+'px';
      portal.style.width=portalWidth+'px';
      const rows=[];
      let previousGroup='';
      menuOpts.forEach((o,index)=>{
        const group=optionGroup(o);
        if(group!==previousGroup){
          rows.push(h('span',{class:'ve-menu-section-label',key:'group-'+group+'-'+index},group));
          previousGroup=group;
        }
        const icon=o.icon||(isContentTermMenu?'tag':'');
        rows.push(h('button',{type:'button',class:'ve-menu-item'+(icon?' has-icon':'')+(String(o.value)===String(value)?' on':'')+(index===activeIndex?' active':''),key:'option-'+o.value,role:'option','aria-selected':index===activeIndex,onMouseEnter:()=>{keyNavRef.current=false;sActiveIndex(index);},onMouseDown:e=>{e.preventDefault();choose(o);}},icon&&ph(icon),h('span',{class:'ve-menu-item-label'},o.label)));
      });
      render(h('div',{class:'ve-menu-list'},
        searchable&&h('input',{class:'ve-menu-search',value:query,placeholder:searchPlaceholder||'Search variables…',autoComplete:'off',role:'combobox','aria-expanded':'true','aria-controls':'ve-menu-options',onInput:e=>sQuery(e.target.value),onKeyDown:onMenuKey}),
        menuOpts.length
          ?rows
          :h('div',{class:'ve-menu-empty'},'No matching variables')
      ),portal);
      const list=portal.querySelector('.ve-menu-list');
      if(list){
        list.style.maxHeight=Math.floor(available)+'px';
        const actualHeight=Math.min(list.scrollHeight,available);
        const wantedTop=openUp?rect.top-actualHeight-6:rect.bottom+6;
        portal.style.top=Math.max(bounds.top,Math.min(wantedTop,bounds.bottom-actualHeight))+'px';
      }
      if(searchable){
        const input=portal.querySelector('.ve-menu-search');
        if(input&&document.activeElement!==input){
          input.focus();
          input.setSelectionRange(input.value.length,input.value.length);
        }
      }
      // Only follow the highlight when the keyboard moved it. Following it on
      // hover cancels the user's own wheel scrolling.
      if(keyNavRef.current){
        const activeItem=portal.querySelector('.ve-menu-item.active');
        if(activeItem)activeItem.scrollIntoView({block:'nearest'});
      }
    };
    place();
    const reposition=e=>{if(e?.target&&portal.contains(e.target))return;place();};
    window.addEventListener('resize',place);
    window.addEventListener('scroll',reposition,true);
    return()=>{
      window.removeEventListener('resize',place);
      window.removeEventListener('scroll',reposition,true);
    };
  },[open,value,options,query,searchable,searchPlaceholder,activeIndex,className,groupCount]);
  return h('div',{ref,class:'ve-menu '+(open?'open ':'')+(disabled?'disabled ':'')+(className||'')},
    h('button',{ref:buttonRef,type:'button',class:'ve-menu-btn',disabled:!!disabled,onClick:()=>{if(!disabled){sQuery('');keyNavRef.current=true;sOpen(v=>!v);}},onKeyDown:e=>{
      if(disabled)return;
      if(e.key==='Escape')sOpen(false);
      if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();sQuery('');sActiveIndex(0);sOpen(true);}
      if(e.key==='Enter'||e.key===' '){e.preventDefault();sQuery('');sActiveIndex(0);sOpen(v=>!v);}
    }},h('span',{class:'ve-menu-label'},cur.label)));
}

function ConfirmModal({title,body,confirmText,cancelText,onCancel,onConfirm,danger,global=false}){
  return h('div',{class:'ve-modal'+(global?' ve-modal-global':'')},
    h('div',{class:'ve-modal-box'},
      h('div',{class:'ve-modal-title'},title||'Confirm action'),
      h('div',{class:'ve-modal-body'},body||'Are you sure?'),
      h('div',{class:'ve-modal-actions'},
        h('button',{class:'ve-btn ve-btn-g ve-btn-s',type:'button',onClick:onCancel},cancelText||'Cancel'),
        h('button',{class:'ve-btn '+(danger?'ve-btn-d':'')+' ve-btn-s',type:'button',onClick:onConfirm},confirmText||'Confirm'))));
}

function CheckControl({checked,onChange,label,title,className,disabled,onShiftClick}){
  const shiftRef=useRef(false);
  const rememberShift=e=>{
    const held=!!(e?.shiftKey||e?.nativeEvent?.shiftKey||shiftRef.current||((typeof window!=='undefined')&&window.__veLastShiftCheckUntil>Date.now()));
    shiftRef.current=held;
    if(held&&typeof window!=='undefined')window.__veLastShiftCheckUntil=Date.now()+700;
    if(e?.currentTarget){
      const input=e.currentTarget.querySelector&&e.currentTarget.querySelector('input');
      const currentHeld=!!(e.shiftKey||e.nativeEvent?.shiftKey||e.currentTarget.__veShiftKey||input?.__veShiftKey||shiftRef.current||((typeof window!=='undefined')&&window.__veLastShiftCheckUntil>Date.now()));
      e.currentTarget.__veShiftKey=currentHeld;
      if(input)input.__veShiftKey=currentHeld;
    }
  };
  const interceptShiftClick=e=>{
    const held=!!(e.shiftKey||e.nativeEvent?.shiftKey||e.target?.__veShiftKey||e.target?.parentNode?.__veShiftKey||e.currentTarget?.__veShiftKey||e.currentTarget?.parentNode?.__veShiftKey||shiftRef.current||((typeof window!=='undefined')&&window.__veLastShiftCheckUntil>Date.now()));
    if(held&&onShiftClick){
      e.preventDefault();
      e.stopPropagation();
      onShiftClick(e, held);
      shiftRef.current=false;
      if(e.target)e.target.__veShiftKey=false;
      if(e.target?.parentNode)e.target.parentNode.__veShiftKey=false;
      if(e.currentTarget)e.currentTarget.__veShiftKey=false;
      if(e.currentTarget?.parentNode)e.currentTarget.parentNode.__veShiftKey=false;
      if(typeof window!=='undefined')window.__veLastShiftCheckUntil=0;
      return true;
    }
    rememberShift(e);
    return false;
  };
  const consumeShift=e=>{
    const held=!!(e.shiftKey||e.nativeEvent?.shiftKey||e.target?.__veShiftKey||e.target?.parentNode?.__veShiftKey||e.currentTarget.__veShiftKey||e.currentTarget.parentNode?.__veShiftKey||shiftRef.current||((typeof window!=='undefined')&&window.__veLastShiftCheckUntil>Date.now()));
    e.__veShiftKey=held;
    if(e.nativeEvent)e.nativeEvent.__veShiftKey=held;
    onChange&&onChange(e.target.checked,e,held);
    shiftRef.current=false;
    if(e.target)e.target.__veShiftKey=false;
    if(e.target?.parentNode)e.target.parentNode.__veShiftKey=false;
    e.currentTarget.__veShiftKey=false;
    if(e.currentTarget.parentNode)e.currentTarget.parentNode.__veShiftKey=false;
  };
  return h('label',{class:'ve-check-row '+(className||'')+(disabled?' disabled':''),'aria-label':title||label||'',onPointerDown:rememberShift,onPointerDownCapture:rememberShift,onMouseDown:rememberShift,onMouseDownCapture:rememberShift,onClick:interceptShiftClick,onClickCapture:interceptShiftClick},
    h('input',{type:'checkbox',checked:!!checked,disabled:!!disabled,onPointerDown:rememberShift,onPointerDownCapture:rememberShift,onMouseDown:rememberShift,onMouseDownCapture:rememberShift,onClick:interceptShiftClick,onClickCapture:interceptShiftClick,onChange:consumeShift}),
    h('span',{class:'ve-check-box'},ph('check')),
    label!==undefined&&h('span',{class:'ve-check-label'},label));
}

function ToggleControl({checked,onChange,label,title,disabled,className}){
  return h('button',{
    type:'button',
    class:'ve-toggle '+(checked?'on':'off')+' '+(className||''),
    'aria-label':title||label||'',
    disabled:!!disabled,
    'aria-pressed':!!checked,
    onClick:()=>!disabled&&onChange&&onChange(!checked)
  },
    h('span',{class:'ve-toggle-label'},checked?'On':'Off'),
    h('span',{class:'ve-toggle-knob'})
  );
}

function ActivityProgress({panelId='variables'}){
  const[state,setState]=useState({count:apiActivity.count,label:apiActivity.label,progress:apiActivity.progress,panelId:apiActivity.panelId,failed:apiActivity.failed});
  const[visible,setVisible]=useState(false);
  const[done,setDone]=useState(false);
  const visibleRef=useRef(false);
  const showTimer=useRef(null);
  const hideTimer=useRef(null);
  useEffect(()=>{
    const listener=next=>setState(next);
    apiActivity.listeners.add(listener);
    return()=>apiActivity.listeners.delete(listener);
  },[]);
  useEffect(()=>{
    if(showTimer.current)clearTimeout(showTimer.current);
    if(hideTimer.current)clearTimeout(hideTimer.current);
    if(state.count>0){
      setDone(false);
      if(!visibleRef.current){
        showTimer.current=setTimeout(()=>{visibleRef.current=true;setVisible(true);},220);
      }
      return;
    }
    if(visibleRef.current){
      setDone(true);
      hideTimer.current=setTimeout(()=>{visibleRef.current=false;setVisible(false);setDone(false);},220);
    }
  },[state.count]);
  useEffect(()=>()=>{if(showTimer.current)clearTimeout(showTimer.current);if(hideTimer.current)clearTimeout(hideTimer.current);},[]);
  if(!visible||state.panelId!==panelId)return null;
  const percent=done?100:Math.max(8,Math.min(92,state.progress||8));
  const finalLabel=state.failed?'Failed':'Complete';
  return h('div',{class:'ve-header-progress'+(done?' done':'')+(done&&state.failed?' failed':''),role:'progressbar','aria-label':state.label,'aria-valuemin':'0','aria-valuemax':'100','aria-valuenow':String(percent),'aria-valuetext':done?finalLabel:state.label},
    h('div',{class:'ve-header-progress-top'},
      h('span',{class:'ve-header-progress-label'},done?finalLabel:state.label),
      h('strong',{class:'ve-header-progress-percent'},percent+'%')),
    h('div',{class:'ve-header-progress-track'},h('div',{class:'ve-header-progress-bar',style:{width:percent+'%'}})));
}

function hexToRgb(hex){
  hex=clrToHex(hex).replace('#','');
  return{r:parseInt(hex.slice(0,2),16),g:parseInt(hex.slice(2,4),16),b:parseInt(hex.slice(4,6),16)};
}
function rgbToHex(r,g,b){return'#'+[r,g,b].map(v=>('0'+Math.max(0,Math.min(255,Math.round(v))).toString(16)).slice(-2)).join('');}
function hexToHsv(hex){
  const{r,g,b}=hexToRgb(hex);const rn=r/255,gn=g/255,bn=b/255,mx=Math.max(rn,gn,bn),mn=Math.min(rn,gn,bn),d=mx-mn;
  let h=0;if(d){if(mx===rn)h=((gn-bn)/d+(gn<bn?6:0))*60;else if(mx===gn)h=((bn-rn)/d+2)*60;else h=((rn-gn)/d+4)*60;}
  return{h:Math.round(h),s:mx?d/mx:0,v:mx};
}
function hsvToHex(h,s,v){
  const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c;let r=0,g=0,b=0;
  if(h<60){r=c;g=x;}else if(h<120){r=x;g=c;}else if(h<180){g=c;b=x;}else if(h<240){g=x;b=c;}else if(h<300){r=x;b=c;}else{r=c;b=x;}
  return rgbToHex((r+m)*255,(g+m)*255,(b+m)*255);
}
function hexToHslObj(hex){
  const{r,g,b}=hexToRgb(hex);const rn=r/255,gn=g/255,bn=b/255,mx=Math.max(rn,gn,bn),mn=Math.min(rn,gn,bn),l=(mx+mn)/2;let h=0,s=0;
  if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);if(mx===rn)h=((gn-bn)/d+(gn<bn?6:0))/6;else if(mx===gn)h=((bn-rn)/d+2)/6;else h=((rn-gn)/d+4)/6;}
  return{h:Math.round(h*360),s:Math.round(s*100),l:Math.round(l*100)};
}
function hslToHexObj(h,s,l){
  h=((+h||0)%360+360)%360/360;s=Math.max(0,Math.min(100,+s||0))/100;l=Math.max(0,Math.min(100,+l||0))/100;
  const q=l<.5?l*(1+s):l+s-l*s,p=2*l-q,h2r=(pp,qq,t)=>{if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return pp+(qq-pp)*6*t;if(t<.5)return qq;if(t<2/3)return pp+(qq-pp)*(2/3-t)*6;return pp;};
  const r=s===0?l:h2r(p,q,h+1/3),g=s===0?l:h2r(p,q,h),b=s===0?l:h2r(p,q,h-1/3);return rgbToHex(r*255,g*255,b*255);
}
function hexToOklchObj(hex){
  const m=hexOklch(hex).match(/oklch\(([\d.]+)\s+([\d.]+)\s+([\d.]+)\)/);return{l:m?+m[1]:0,c:m?+m[2]:0,h:m?+m[3]:0};
}
function hexToOklabObj(hex){
  const{l,c,h}=hexToOklchObj(hex);const rad=(h||0)*Math.PI/180;
  return{l,a:c*Math.cos(rad),b:c*Math.sin(rad)};
}
function oklabToHex(l,a,b){
  const c=Math.sqrt((a||0)*(a||0)+(b||0)*(b||0));
  let hue=Math.atan2(b||0,a||0)*180/Math.PI;
  if(hue<0)hue+=360;
  return clrToHex('oklch('+(l||0)+' '+c+' '+hue+')');
}
// One preset row for every picker, so the same seven colours are one click away
// wherever colour is edited.
// Recently used colours, shared by every picker rather than a fixed palette.
// Nothing is rendered until you have actually used a colour, so the row is
// never a line of empty boxes.
const MV_RECENT_COLORS_KEY='ve_recent_colors';
const MV_RECENT_COLORS_MAX=8;
const mvRecentColors={list:null,listeners:new Set()};
function readRecentColors(){
  if(mvRecentColors.list)return mvRecentColors.list;
  let parsed=[];
  try{ parsed=JSON.parse(localStorage.getItem(MV_RECENT_COLORS_KEY)||'[]'); }catch(e){ parsed=[]; }
  mvRecentColors.list=Array.isArray(parsed)?parsed.filter(v=>typeof v==='string'&&v).slice(0,MV_RECENT_COLORS_MAX):[];
  return mvRecentColors.list;
}
function rememberColor(value){
  const clean=String(value||'').trim();
  if(!clean)return;
  const current=readRecentColors();
  const next=[clean].concat(current.filter(v=>v.toLowerCase()!==clean.toLowerCase())).slice(0,MV_RECENT_COLORS_MAX);
  mvRecentColors.list=next;
  try{ localStorage.setItem(MV_RECENT_COLORS_KEY,JSON.stringify(next)); }catch(e){}
  mvRecentColors.listeners.forEach(fn=>{ try{ fn(next); }catch(e){} });
}
function useRecentColors(){
  const[list,setList]=useState(readRecentColors);
  useEffect(()=>{
    const listener=next=>setList(next.slice());
    mvRecentColors.listeners.add(listener);
    return ()=>mvRecentColors.listeners.delete(listener);
  },[]);
  return list;
}
function colorChannelFormat(fmt){return['rgb','hsl','oklch','oklab','var'].includes(fmt)?fmt:'oklch';}
function MVColorDraftInput({value,onCommit,label}){
  const[draft,setDraft]=useState(String(value??''));
  const focused=useRef(false);
  const cancelOnBlur=useRef(false);
  useEffect(()=>{if(!focused.current)setDraft(String(value??''));},[value]);
  const commit=()=>{const accepted=onCommit(draft)!==false;if(!accepted)setDraft(String(value??''));};
  return h('input',{value:draft,title:label,'aria-label':label,onFocus:()=>{focused.current=true;cancelOnBlur.current=false;setDraft(String(value??''));},onInput:event=>setDraft(event.target.value),onBlur:()=>{focused.current=false;if(cancelOnBlur.current){cancelOnBlur.current=false;setDraft(String(value??''));return;}commit();},onKeyDown:event=>{if(event.key==='Enter'){event.preventDefault();event.currentTarget.blur();}else if(event.key==='Escape'){event.preventDefault();cancelOnBlur.current=true;setDraft(String(value??''));event.currentTarget.blur();}}});
}
// Clamp a floating element inside its container and re-clamp whenever it
// resizes. A one-shot measure is not enough: the colour popover grows when you
// switch to VAR or a recent row appears, and it would then hang off the edge.
function keepInsideBounds(el,getBounds){
  if(!el)return ()=>{};
  let lastMax='';
  const apply=()=>{
    // Measure unshifted, then re-apply the offset as a transform: the host
    // re-renders left/top from state and would wipe anything written there.
    el.style.transform='';
    const edge=getBounds()||{top:0,left:0,bottom:window.innerHeight,right:window.innerWidth};
    const pad=12;
    const room=Math.round(edge.bottom-edge.top-pad*2);
    const box=el.getBoundingClientRect();
    const nextMax=box.height>room?room+'px':'';
    if(nextMax!==lastMax){
      lastMax=nextMax;
      el.style.maxHeight=nextMax;
      el.style.overflowY=nextMax?'auto':'';
      return;               // the resize observer will re-run against the new size
    }
    let top=box.top,left=box.left;
    if(box.bottom>edge.bottom-pad)top=edge.bottom-box.height-pad;
    if(top<edge.top+pad)top=edge.top+pad;
    if(box.right>edge.right-pad)left=Math.max(edge.left+pad,edge.right-box.width-pad);
    if(left<edge.left+pad)left=edge.left+pad;
    const dx=Math.round(left-box.left),dy=Math.round(top-box.top);
    el.style.transform=(dx||dy)?'translate('+dx+'px,'+dy+'px)':'';
  };
  const frame=requestAnimationFrame(apply);
  let observer=null;
  try{ observer=new ResizeObserver(()=>apply()); observer.observe(el); }catch(e){}
  return ()=>{ cancelAnimationFrame(frame); if(observer)observer.disconnect(); };
}

const mvVariableCache={list:[],loading:null};
function loadMvVariables(){
  if(mvVariableCache.list.length)return Promise.resolve(mvVariableCache.list);
  if(mvVariableCache.loading)return mvVariableCache.loading;
  mvVariableCache.loading=api.g('variables?dedupe=true')
    .then(res=>{ mvVariableCache.list=Array.isArray(res?.variables)?res.variables:(Array.isArray(res)?res:[]); return mvVariableCache.list; })
    .catch(()=>[]);
  return mvVariableCache.loading;
}

function MVColorVarField({vars,boundVar,hex,alpha,onBindVariable,onClearVariable}){
  const[query,setQuery]=useState('');
  const[cached,setCached]=useState(mvVariableCache.list);
  useEffect(()=>{ if(!(vars&&vars.length))loadMvVariables().then(setCached); },[vars]);
  vars=(vars&&vars.length)?vars:cached;
  const list=useMemo(()=>{
    const all=Array.isArray(vars)?vars:[];
    const needle=String(query||'').trim().toLowerCase();
    if(!needle)return all.slice(0,60);
    return all.filter(v=>((v.name||'').toLowerCase().includes(needle)||cssTokenName(v.name).toLowerCase().includes(needle))).slice(0,60);
  },[query,vars]);
  const current=String(boundVar||'');
  return h('div',{class:'ve-shared-color-var'},
    current
      ? h('div',{class:'ve-shared-color-var-bound'},
          h('span',{class:'ve-shared-color-var-sw',style:'background:'+hexWithAlpha(hex,alpha)}),
          h('code',null,current),
          h('button',{type:'button',title:'Unbind and go back to a literal colour',onClick:onClearVariable},ph('x')))
      : null,
    h('input',{class:'ve-shared-color-var-search',value:query,placeholder:'Search variables…',
      onInput:e=>setQuery(e.target.value),
      onKeyDown:e=>{ if(e.key==='Enter'&&list.length){e.preventDefault();onBindVariable('var('+cssTokenName(list[0].name)+')');} }}),
    h('div',{class:'ve-shared-color-var-list'},
      list.length?list.map(variable=>{
        const resolved=resolvedVariableValue(variable,vars);
        const token='var('+cssTokenName(variable.name)+')';
        return h('button',{type:'button',key:variable.id,class:'ve-shared-color-var-item'+(token===current?' on':''),
          onClick:()=>onBindVariable(token)},
          h('span',{class:'ve-shared-color-var-sw',style:isClr(resolved)?('background:'+resolved+';border-color:transparent'):''}),
          h('span',{class:'ve-shared-color-var-name'},cssTokenName(variable.name)),
          h('span',{class:'ve-shared-color-var-val'},variable.type==='alias'?variable.css_value:variable.value));
      }):h('div',{class:'ve-shared-color-var-empty'},(vars&&vars.length)?'No variable matches that.':'No MV variables yet.')));
}

function MVColorPickerCore({hex,onChange,alpha=1,onAlphaChange,fmt,setFmt,variant='full',closing=false,label='Color value',actions,vars,boundVar,onBindVariable}){
  hex=clrToHex(hex||'#baf400');
  const activeFmt=colorChannelFormat(fmt);
  const cleanAlpha=normAlpha(alpha);
  const hsv=hexToHsv(hex);
  const mapRef=useRef();
  const setFromEvent=e=>{
    const r=mapRef.current?.getBoundingClientRect();if(!r)return;
    const sat=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width));
    const val=1-Math.max(0,Math.min(1,(e.clientY-r.top)/r.height));
    onChange(hsvToHex(hsv.h,sat,val));
  };
  const down=e=>{
    if(e.pointerType==='mouse'&&e.button!==0)return;
    e.preventDefault();
    setFromEvent(e);
    const move=ev=>setFromEvent(ev);
    const up=()=>{window.removeEventListener('pointermove',move);window.removeEventListener('pointerup',up);window.removeEventListener('pointercancel',up);};
    window.addEventListener('pointermove',move);window.addEventListener('pointerup',up);window.addEventListener('pointercancel',up);
  };
  const rgb=hexToRgb(hex);
  const setRgb=(k,v)=>{const next={...rgb,[k]:Math.max(0,Math.min(255,parseInt(v||0,10)||0))};onChange(rgbToHex(next.r,next.g,next.b));return true;};
  const hsl=hexToHslObj(hex);
  const ok=hexToOklchObj(hex);
  const setHsl=(k,v)=>{const next={...hsl,[k]:parseFloat(v||0)||0};onChange(hslToHexObj(next.h,next.s,next.l));return true;};
  const setOk=(k,v)=>{const next={...ok,[k]:parseFloat(v||0)||0};onChange(clrToHex(`oklch(${next.l} ${next.c} ${next.h})`));return true;};
  const lab=hexToOklabObj(hex);
  const setLab=(k,v)=>{const next={...lab,[k]:parseFloat(v||0)||0};onChange(oklabToHex(next.l,next.a,next.b));return true;};
  const setHex=value=>{
    const raw=String(value||'').trim().replace(/^#/,'');
    if(!/^[0-9a-f]{6}([0-9a-f]{2})?$/i.test(raw))return false;
    onChange('#'+raw.slice(0,6));
    if(raw.length===8&&onAlphaChange)onAlphaChange(parseInt(raw.slice(6,8),16)/255);
    return true;
  };
  const controls=activeFmt==='hsl'
    ?[{v:hsl.h,set:v=>setHsl('h',v),label:'H'},{v:hsl.s,set:v=>setHsl('s',v),label:'S'},{v:hsl.l,set:v=>setHsl('l',v),label:'L'}]
    :activeFmt==='oklch'
      ?[{v:ok.l.toFixed(4),set:v=>setOk('l',v),label:'L'},{v:ok.c.toFixed(4),set:v=>setOk('c',v),label:'C'},{v:ok.h.toFixed(2),set:v=>setOk('h',v),label:'H'}]
      :activeFmt==='oklab'
        ?[{v:lab.l.toFixed(4),set:v=>setLab('l',v),label:'L'},{v:lab.a.toFixed(4),set:v=>setLab('a',v),label:'a'},{v:lab.b.toFixed(4),set:v=>setLab('b',v),label:'b'}]
        :[{v:rgb.r,set:v=>setRgb('r',v),label:'R'},{v:rgb.g,set:v=>setRgb('g',v),label:'G'},{v:rgb.b,set:v=>setRgb('b',v),label:'B'}];
  // VAR is only offered where the host can actually store a variable reference.
  // One entry per session: remembered on close, only if it changed.
  const openedWith=useRef(null);
  const latestValue=useRef('');
  const sessionValue=hexWithAlpha(clrToHex(hex),cleanAlpha).toLowerCase();
  if(openedWith.current===null)openedWith.current=sessionValue;
  latestValue.current=sessionValue;
  useEffect(()=>()=>{
    const final=latestValue.current;
    if(final&&final!==openedWith.current)rememberColor(final);
  },[]);
  const canBindVar=typeof onBindVariable==='function';
  const recents=useRecentColors();
  const pickerRgb=hexToRgb(hex);
  const pickerStyle={
    '--ve-picker-color':hex,
    '--ve-picker-alpha-color':`rgba(${pickerRgb.r},${pickerRgb.g},${pickerRgb.b},${cleanAlpha})`,
    '--ve-picker-rgb':`${pickerRgb.r},${pickerRgb.g},${pickerRgb.b}`
  };
  return h('div',{class:'ve-shared-color-core ve-shared-color-core-'+variant+(closing?' closing':''),style:pickerStyle},
    h('div',{class:'ve-shared-color-context'},label),
    h('div',{ref:mapRef,class:'ve-shared-color-map',style:'background:hsl('+hsv.h+',100%,50%)',onPointerDown:down},
      h('span',{class:'ve-shared-color-dot',style:{left:'clamp(7px,'+(hsv.s*100)+'%,calc(100% - 7px))',top:'clamp(7px,'+((1-hsv.v)*100)+'%,calc(100% - 7px))'}})),
    h('input',{class:'ve-shared-color-range ve-shared-color-hue',type:'range',min:0,max:359,value:hsv.h,'aria-label':'Hue',onInput:e=>onChange(hsvToHex(+e.target.value,hsv.s,hsv.v))}),
    h('div',{class:'ve-shared-color-alpha-row'},
      h('input',{class:'ve-shared-color-range ve-shared-color-alpha',type:'range',min:0,max:100,value:Math.round(cleanAlpha*100),'aria-label':'Alpha',onInput:e=>onAlphaChange&&onAlphaChange(+e.target.value/100)}),
      h('output',{class:'ve-shared-color-alpha-value'},Math.round(cleanAlpha*100)+'%')),
    activeFmt==='var'
      ? h(MVColorVarField,{vars,boundVar,hex,alpha:cleanAlpha,onBindVariable,onClearVariable:()=>{if(onBindVariable)onBindVariable('');setFmt('oklch');}})
      : h('div',{class:'ve-shared-color-fields'},
          h(MVColorDraftInput,{value:hexWithAlpha(hex,cleanAlpha),label:'Hex color',onCommit:setHex}),
          controls.map(c=>h(MVColorDraftInput,{key:c.label,value:c.v,label:c.label,onCommit:c.set}))),
    h('div',{class:'ve-shared-color-formats'+(canBindVar?' has-var':'')},
      ['rgb','hsl','oklch','oklab'].concat(canBindVar?['var']:[]).map(f=>
        h('button',{key:f,class:activeFmt===f?'on':'',type:'button',
          title:f==='var'?'Point this colour at an MV variable instead of a literal':'',
          onClick:()=>setFmt(f)},f.toUpperCase()))),
    // The Component Library has always specified a preset row; the shipped
    // picker never had one. Brand first, then neutrals, then the semantics.
    recents.length>0&&h('div',{class:'ve-shared-color-swatches'},recents.map(recent=>h('button',{
      key:recent,type:'button',class:clrToHex(hex).toLowerCase()===clrToHex(recent).toLowerCase()?'on':'',
      style:'background:'+recent+' !important',title:recent,'aria-label':'Reuse '+recent,onClick:()=>setHex(clrToHex(recent))}))),
    // Footers used to be built by each host, which is why the three pickers
    // looked like three components. They are declared here now.
    Array.isArray(actions)&&actions.length&&h('div',{class:'ve-shared-color-actions'},
      actions.filter(Boolean).map(action=>h('button',{key:action.label,type:'button',
        class:'ve-btn ve-btn-s'+(action.primary?'':' ve-btn-g'),disabled:!!action.disabled,
        title:action.title||'',onClick:action.onClick},action.icon?ph(action.icon):null,action.label))));
}

function MVColorPicker({hex,onChange,alpha=1,onAlphaChange,fmt,setFmt}){
  const[shown,sShown]=useState(false);
  const[closing,sClosing]=useState(false);
  const cleanHex=clrToHex(hex||'#baf400');
  const cleanAlpha=normAlpha(alpha);
  const activeFmt=colorChannelFormat(fmt);
  const rgb=hexToRgb(cleanHex);
  const pickerStyle={
    '--ve-picker-alpha-color':`rgba(${rgb.r},${rgb.g},${rgb.b},${cleanAlpha})`,
    '--ve-picker-rgb':`${rgb.r},${rgb.g},${rgb.b}`
  };
  const toggleOpen=()=>{
    if(shown&&!closing){sClosing(true);setTimeout(()=>{sShown(false);sClosing(false);},140);return;}
    sShown(true);sClosing(false);
  };
  const wrapRef=useRef();
  useEffect(()=>{
    if(!shown||closing)return undefined;
    const away=event=>{ if(wrapRef.current&&!wrapRef.current.contains(event.target))toggleOpen(); };
    const key=event=>{ if(event.key==='Escape')toggleOpen(); };
    document.addEventListener('pointerdown',away,true);
    document.addEventListener('keydown',key,true);
    return ()=>{ document.removeEventListener('pointerdown',away,true); document.removeEventListener('keydown',key,true); };
  },[shown,closing]);
  return h('div',{class:'ve-cp',ref:wrapRef,style:{flex:1,...pickerStyle}},
    h('button',{type:'button',class:'ve-shared-color-swatch','aria-label':shown?'Close color picker':'Open color picker','aria-expanded':shown?'true':'false',onClick:toggleOpen}),
    h('div',{class:'ve-cp-v'},fmtD(cleanHex,activeFmt,cleanAlpha)),
    shown&&h(MVColorPickerCore,{hex:cleanHex,onChange,alpha:cleanAlpha,onAlphaChange,fmt:activeFmt,setFmt,variant:'full',closing,label:'Color value'}));
}

function MVInlineColorPicker({hex,onChange,alpha=1,onAlphaChange,fmt,setFmt,variant='inline',label='Color value',actions,vars,boundVar,onBindVariable}){
  return h(MVColorPickerCore,{hex,onChange,alpha,onAlphaChange,fmt:colorChannelFormat(fmt),setFmt,variant,label,actions,vars,boundVar,onBindVariable});
}
function VariableColorField({hex,onChange,alpha,onAlphaChange,fmt,setFmt}){
  return h('div',{class:'ve-row ve-color-picker-row'},
    h(MVColorPicker,{hex,onChange,alpha,onAlphaChange,fmt,setFmt}));
}

/* ── Settings sub-panel ───────────────── */
/* ── Standalone draggable panel wrapper ── */
/* Listens to the registry via the events global-event-manager dispatches, so
   the panel needs no key handling of its own. */
/* One row per shortcut, arrangement A from the approved mock: keys, name,
   scope and the switch on a single 50px line, so a third more shortcuts fit
   before the list scrolls. Scope is a button showing its current value rather
   than three visible choices, which is the cost A accepts for the height. */
/* Renders the media context menu. Kept outside the studio component so the
   studio only owns state; everything positional lives here.

   The menu is fixed and flips rather than clips: a menu that runs off the
   viewport hides the row you were reaching for. It also caps its height and
   scrolls, because the full list is taller than a short builder viewport. */
function MediaCtxMenu({ at, rows, onClose, host }){
  const ref=useRef(null);
  const subRef=useRef(null);
  const [open,setOpen]=useState(-1);
  const [pos,setPos]=useState({left:-9999,top:-9999});
  const [subPos,setSubPos]=useState(null);
  /* Every measurement below is in the studio's frame, because that is the frame
     the menu is positioned in. Mixing the two — client rects flipped against
     window.innerWidth, then written to an element whose containing block is the
     panel — is what put the menu off screen. */
  const box=()=>{
    const el=host&&host.current;
    const r=el&&el.getBoundingClientRect?el.getBoundingClientRect():null;
    return r||{left:0,top:0,width:window.innerWidth||900,height:window.innerHeight||620};
  };
  useLayoutEffect(()=>{
    const el=ref.current; if(!el)return;
    const w=el.offsetWidth,h=el.offsetHeight,b=box();
    // Flip when it would overrun, then clamp: on a short panel a flipped menu
    // can still overrun the other edge, and 8px in is better than half of it cut.
    setPos({
      left:Math.max(8,Math.min(at.x+w>b.width-8?at.x-w:at.x,Math.max(8,b.width-w-8))),
      top:Math.max(8,Math.min(at.y+h>b.height-8?at.y-h:at.y,Math.max(8,b.height-h-8)))
    });
  },[at]);
  useLayoutEffect(()=>{
    if(open<0||!subRef.current||!ref.current){setSubPos(p=>p&&null);return;}
    const parent=ref.current.querySelectorAll('.ve-ctx-row')[open];
    if(!parent)return;
    const b=box(),r=parent.getBoundingClientRect();
    const w=subRef.current.offsetWidth,h=subRef.current.offsetHeight;
    const left=r.left-b.left,right=r.right-b.left,top=r.top-b.top;
    setSubPos({
      left:Math.max(8,right-2+w>b.width-8?left-w+2:right-2),
      top:Math.max(8,Math.min(top-5,Math.max(8,b.height-h-8)))
    });
  },[open,at]);
  return h(Fragment,null,
    h('div',{class:'ve-ctx',ref,style:{left:pos.left+'px',top:pos.top+'px'}},
      rows.map((r,i)=>r.sep
        ? h('div',{class:'ve-ctx-sep',key:'s'+i})
        : h('button',{
            key:r.label,type:'button',
            class:'ve-ctx-row'+(r.bad?' bad':'')+(open===i?' open':''),
            disabled:!!r.off,
            onMouseEnter:()=>setOpen(r.sub&&!r.off?i:-1),
            onClick:e=>{
              if(r.off)return;
              if(r.sub){e.stopPropagation();setOpen(open===i?-1:i);return;}
              r.run();onClose();
            }},
            h('span',null,r.label),
            r.sub?h('span',{class:'ve-ctx-car'},'\u203a')
                 :r.hint?h('span',{class:'ve-ctx-key'},r.hint):null)
      )),
    open>=0&&rows[open]&&rows[open].sub&&h('div',{
      class:'ve-ctx ve-ctx-sub',ref:subRef,
      style:subPos?{left:subPos.left+'px',top:subPos.top+'px'}:{left:'-9999px',top:'-9999px'}},
      rows[open].sub.map(x=>h('button',{key:x.label,type:'button',class:'ve-ctx-row',
        onClick:()=>{x.run();onClose();}},h('span',null,x.label)))));
}

function ShortcutRow({item,onEdit,capturing,onCapture,onChange}){
  const reg=window.MVShortcuts;
  const conflict=reg.conflict(item);
  const scopes=['builder','admin','both'];
  const scopeLabel={builder:'Builder',admin:'Admin',both:'Both'};
  return h('div',{class:'mv-sc-row'+(item.enabled?'':' off')+(conflict&&item.enabled?' warn':'')},
    h('button',{type:'button',class:'mv-sc-keys'+(capturing?' capturing':''),
      onClick:onCapture,
      title:capturing?'Press the keys you want':'Click, then press the keys you want'},
      capturing
        ? h('em',null,item.type==='chord'?'Press a letter':'Hold the keys')
        : reg.describe(item).split(' ').filter(p=>p!=='+').map((p,i)=>h('kbd',{key:i},p))),
    h('span',{class:'mv-sc-name'},item.label,
      conflict&&item.enabled&&h('em',null,conflict)),
    h('button',{type:'button',class:'mv-sc-scope',
      onClick:()=>onChange({scope:scopes[(scopes.indexOf(item.scope)+1)%3]}),
      title:'Where this shortcut may fire'},scopeLabel[item.scope]),
    h(ToggleControl,{checked:item.enabled,label:item.label,
      onChange:v=>onChange({enabled:!!v})}));
}

function ShortcutsSettings(){
  const reg=window.MVShortcuts;
  const [tick,setTick]=useState(0);
  const [capturing,setCapturing]=useState('');
  const bump=()=>setTick(t=>t+1);
  useEffect(()=>{
    if(!capturing)return undefined;
    const item=reg.get(capturing);
    const onKey=e=>{
      e.preventDefault();e.stopPropagation();
      if(e.key==='Escape'){setCapturing('');return;}
      if(['Control','Alt','Shift','Meta'].indexOf(e.key)!==-1)return;
      if(item.type==='chord'){
        const k=String(e.key);
        if(k.length!==1)return;
        reg.set(capturing,{keys:{key:k.toLowerCase()}});
      }else{
        reg.set(capturing,{keys:{ctrl:e.ctrlKey,alt:e.altKey,shift:e.shiftKey,
          meta:e.metaKey,key:e.key}});
      }
      setCapturing('');bump();
    };
    window.addEventListener('keydown',onKey,true);
    return()=>window.removeEventListener('keydown',onKey,true);
  },[capturing,tick]);

  if(!reg)return h('p',{class:'ve-settings-empty'},
    'The shortcut registry did not load, so shortcuts cannot be edited here.');

  const prefs=reg.prefs();
  const groups=[];const seen={};
  reg.all().forEach(item=>{
    if(!seen[item.group]){seen[item.group]=[];groups.push([item.group,seen[item.group]]);}
    seen[item.group].push(item);
  });
  return h(Fragment,null,
    groups.map(([name,items])=>h('div',{class:'mv-sc-group',key:name},
      h('h4',null,name),
      items.map(item=>h(ShortcutRow,{key:item.id,item,
        capturing:capturing===item.id,
        onCapture:()=>setCapturing(capturing===item.id?'':item.id),
        onChange:patch=>{reg.set(item.id,patch);bump();}})))),
    h('div',{class:'mv-sc-foot'},
      h('label',null,'Leader key',
        h('input',{class:'mv-sc-leader',maxLength:1,value:prefs.leader.toUpperCase(),
          onInput:e=>{const v=String(e.target.value||'').trim().toLowerCase();
            if(v)reg.setPrefs({leader:v});bump();}})),
      h('label',null,'Chord window',
        h('input',{type:'range',min:'200',max:'800',step:'50',value:String(prefs.window),
          onInput:e=>{reg.setPrefs({window:Number(e.target.value)});bump();}}),
        h('span',{class:'mv-sc-ms'},prefs.window+' ms')),
      h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',
        onClick:()=>{reg.resetAll();bump();}},'Restore defaults')));
}

function ShortcutSurface(){
  const [armed,setArmed]=useState(null);
  const [sheet,setSheet]=useState(false);
  useEffect(()=>{
    let clear=null;
    const onArmed=e=>{
      const d=e?.detail||{};
      setArmed(d.state==='rejected'?{key:d.key,bad:true}:{key:d.key});
      if(clear)clearTimeout(clear);
      clear=setTimeout(()=>setArmed(null),d.state==='rejected'?900:520);
    };
    const onSheet=()=>setSheet(v=>!v);
    const onGoto=e=>{
      const map={variables:'ve-toggle-panel',settings:'ve-toggle-settings',
        cssStudio:'ve-toggle-css',contentStudio:'ve-toggle-content',
        mediaStudio:'ve-toggle-media'};
      const name=map[e?.detail?.target];
      if(name)window.dispatchEvent(new CustomEvent(name));
    };
    window.addEventListener('mv-shortcuts-armed',onArmed);
    window.addEventListener('mv-shortcuts-cheatsheet',onSheet);
    window.addEventListener('mv-shortcuts-goto',onGoto);
    return()=>{
      if(clear)clearTimeout(clear);
      window.removeEventListener('mv-shortcuts-armed',onArmed);
      window.removeEventListener('mv-shortcuts-cheatsheet',onSheet);
      window.removeEventListener('mv-shortcuts-goto',onGoto);
    };
  },[]);
  useEffect(()=>{
    if(!sheet)return undefined;
    const esc=e=>{if(e.key==='Escape'){e.preventDefault();setSheet(false);}};
    window.addEventListener('keydown',esc,true);
    return()=>window.removeEventListener('keydown',esc,true);
  },[sheet]);

  const reg=window.MVShortcuts;
  const groups=[];
  if(sheet&&reg){
    const seen={};
    reg.all().forEach(item=>{
      if(!seen[item.group]){seen[item.group]=[];groups.push([item.group,seen[item.group]]);}
      seen[item.group].push(item);
    });
  }
  return h(Fragment,null,
    armed&&h('div',{class:'mv-chord-chip'+(armed.bad?' rejected':'')},
      h('kbd',null,armed.key),
      h('span',null,armed.bad?'nothing bound to that':'waiting for the second key')),
    sheet&&h('div',{class:'mv-cheat-back',onClick:()=>setSheet(false)},
      h('div',{class:'mv-cheat',onClick:e=>e.stopPropagation()},
        h('h2',null,'Shortcuts'),
        h('p',{class:'mv-cheat-sub'},'Press Esc to close. Rebind any of these in Settings \u2192 Shortcuts.'),
        groups.map(([name,items])=>h(Fragment,{key:name},
          h('h3',null,name),
          items.map(item=>h('div',{class:'mv-cheat-row'+(item.enabled?'':' off'),key:item.id},
            h('span',{class:'mv-cheat-keys'},
              reg.describe(item).split(' ').filter(p=>p!=='+').map((p,i)=>h('kbd',{key:i},p))),
            h('span',null,item.label),
            h('span',{class:'mv-cheat-scope'},
              item.enabled?(item.scope==='both'?'Builder and admin'
                :item.scope==='builder'?'Builder':'Admin'):'Off'))))))));
}

function UpdateInstallDock(){
  const[state,setState]=useState(updateInstallSnapshot());
  useEffect(()=>{
    const listener=next=>setState(next);
    updateInstallActivity.listeners.add(listener);
    return()=>updateInstallActivity.listeners.delete(listener);
  },[]);
  if(!state.visible)return null;
  const running=state.status==='running';
  const failed=state.status==='failure';
  const success=state.status==='success';
  const percent=Math.max(0,Math.min(100,Number(state.progress)||0));
  const circumference=2*Math.PI*13;
  const currentStep=UPDATE_INSTALL_STEPS[Math.min(state.step,UPDATE_INSTALL_STEPS.length-1)]||'Finishing up';
  const versionLabel=state.version?'v'+state.version:'Selected release';
  const retry=async()=>{try{await installPanelUpdate(state.version||'');}catch(error){}};
  const close=()=>setUpdateInstallOpen(false);
  const stepRows=UPDATE_INSTALL_STEPS.map((label,index)=>{
    let cls='';
    if(success||index<state.step)cls='done';
    else if(index===state.step)cls=failed?'failed':running?'now':'';
    return h('div',{class:'ve-update-step '+cls,key:label},
      h('span',{class:'ve-update-step-dot'},ph('check')),
      h('span',null,label));
  });
  // The scrim is a sibling of the dock, under it, so the dock stays crisp.
  const settled=(success||failed)&&state.open;
  return h(Fragment,null,
    settled&&h('div',{class:'ve-update-scrim',onClick:close}),
    h('div',{class:'ve-update-dock','aria-live':'polite'},
    state.open&&h('div',{class:'ve-update-ledger'},
      h('div',{class:'ve-update-ledger-head'},
        h('b',null,failed?'Update failed':success?'Update installed':'Installing Mimam’s Var'),
        h('span',{class:'ve-update-ledger-ver'},versionLabel),
        h('button',{type:'button',class:'ve-update-ledger-fold','aria-label':'Collapse update details',onClick:close},ph('minus'))),
      failed&&h('p',{class:'ve-update-ledger-why failure'},'Stopped at step '+(state.step+1)+'. The completed steps above remain intact, the current build stays available as WordPress’s rollback point, and '+(MODE==='builder'?'the builder was not reloaded.':'nothing was reloaded.')),
      running&&h('p',{class:'ve-update-ledger-why'},'The install is continuing without blocking this page. You may collapse this ledger and keep working.'),
      h('div',{class:'ve-update-steps'},stepRows),
      h('div',{class:'ve-update-ledger-foot'},
        h('span',null,failed?state.message:success?(state.refreshRequired?(MODE==='builder'?'Installed; the builder is still running the previous files.':'Installed; this page is still running the previous files.'):state.message):'Safe to keep working while WordPress finishes.'),
        h('strong',null,percent+'%')),
      success&&state.notes.length>0&&h('div',{class:'ve-update-notes'},
        h('b',null,'What changed in '+versionLabel),
        h('ul',null,state.notes.map((note,index)=>h('li',{key:index},note)))),
      success&&state.refreshRequired&&h('p',{class:'ve-update-ledger-hold'},(MODE==='builder'?'Nothing reloads automatically. Finish what you are doing in the builder, then reload when you are ready to use the new files.':'Nothing reloads automatically. Finish what you are doing, then reload this page when you are ready to use the new files.')),
      (failed||success)&&h('div',{class:'ve-update-ledger-actions'},
        failed&&h('button',{type:'button',class:'ve-btn ve-btn-s',onClick:retry},'Retry'),
        failed&&h('button',{type:'button',class:'ve-btn ve-btn-g',onClick:close},'Dismiss'),
        success&&state.refreshRequired&&h('button',{type:'button',class:'ve-btn ve-btn-s',onClick:()=>window.location.reload()},MODE==='builder'?'Reload the builder':'Reload the page'),
        success&&state.refreshRequired&&h('button',{type:'button',class:'ve-btn ve-btn-g',onClick:close},'Later'),
        success&&!state.refreshRequired&&h('button',{type:'button',class:'ve-btn ve-btn-s',onClick:close},'Close'))),
    h('button',{type:'button',class:'ve-update-puck '+state.status,onClick:()=>setUpdateInstallOpen(!state.open),
      role:'progressbar','aria-valuemin':'0','aria-valuemax':'100','aria-valuenow':String(percent),'aria-expanded':state.open?'true':'false'},
      h('span',{class:'ve-update-ring'},
        h('svg',{width:'30',height:'30','aria-hidden':'true'},
          h('circle',{class:'ve-update-ring-bg',cx:'15',cy:'15',r:'13'}),
          h('circle',{class:'ve-update-ring-fg',cx:'15',cy:'15',r:'13','stroke-dasharray':String(circumference),'stroke-dashoffset':String(circumference*(1-percent/100))})),
        h('span',{class:'ve-update-ring-num'},failed?'!':String(percent))),
      h('span',{class:'ve-update-puck-copy'},
        h('b',null,failed?'Update failed':success?(state.refreshRequired?'Reload when ready':'Updated'):'Updating MV'),
        h('span',null,failed?'While '+currentStep.toLowerCase():success?versionLabel+(state.refreshRequired?' is installed':' is current'):currentStep)))));
}

async function installPanelUpdate(version){
  const payload=version?{version}:{};
  beginUpdateInstall(version);
  try{
    const result=await api.p('update/install',payload);
    if(result?.code){
      failUpdateInstall(result);
      const error=new Error(result.message||'Update failed.');
      error.updateResult=result;
      throw error;
    }
    completeUpdateInstall(result||{});
    window.dispatchEvent(new CustomEvent('ve-update-installed',{detail:result||{}}));
    return result;
  }catch(error){
    if(updateInstallActivity.status!=='failure')failUpdateInstall(error?.updateResult||{message:error?.message||'Update failed.'});
    throw error;
  }
}

function UpdateNotice({info,skipped,onSkip}){
  const[updating,setUpdating]=useState(false);
  const[error,setError]=useState('');
  const[installed,setInstalled]=useState(false);
  if(!info?.update_available||info.latest_version===skipped)return null;
  const run=async()=>{
    setUpdating(true);setError('');
    try{await installPanelUpdate(info.latest_version);setInstalled(true);}
    catch(e){setError(e?.message||'Update failed.');}
    finally{setUpdating(false);}
  };
  return h('div',{class:'ve-update'},
    ph('arrow-circle-up'),
    h('span',null,
      h('b',null,installed?'Update installed: ':'Update available: '),'v'+info.latest_version,
      error&&h('small',{style:'display:block;color:#ff7777;margin-top:2px'},error)),
    h('button',{class:'ve-btn ve-btn-s',disabled:updating||installed,onClick:run},updating?'Updating…':installed?'Installed':'Update'),
    !installed&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',disabled:updating,onClick:()=>onSkip(info.latest_version)},'Skip'));
}

function syncMimamsBarUpdateNotice(info,skipped,onSkip){
  const slot=document.querySelector('.baqa-panel .baqa-update-slot');
  if(!slot)return false;
  slot.innerHTML='';
  if(!info?.update_available||info.latest_version===skipped)return true;
  const notice=document.createElement('div');
  notice.className='ve-update ve-update-shared';
  notice.innerHTML='<i class="ph-duotone ph-arrow-circle-up" aria-hidden="true"></i><span><b>Update available: </b>v'+String(info.latest_version)+'</span>';
  if(info.update_admin_url){
    const update=document.createElement('button');
    update.type='button';
    update.className='ve-btn ve-btn-s';
    update.textContent='Update';
    update.addEventListener('click',async()=>{
      update.disabled=true;
      update.textContent='Updating…';
      try{
        await installPanelUpdate(info.latest_version);
        update.textContent='Installed';
      }catch(error){
        update.disabled=false;
        update.textContent='Try Again';
        notice.title=error?.message||'Update failed.';
      }
    });
    notice.appendChild(update);
  }
  const skip=document.createElement('button');
  skip.type='button';
  skip.className='ve-btn ve-btn-g ve-btn-s';
  skip.textContent='Skip';
  skip.addEventListener('click',()=>onSkip(info.latest_version));
  notice.appendChild(skip);
  slot.appendChild(notice);
  return true;
}

function StudioToolRail({activeTool,disabledTools,onSelect}){
  const[layout,setLayout]=useState(null);
  const railRef=useRef(null);
  const disabledKey=(Array.isArray(disabledTools)?disabledTools:[]).slice().sort().join('|');
  const tools=STUDIO_RAIL_TOOLS.filter(tool=>{
const mod=tool.module||tool.id;
return !disabledTools?.includes(mod) && !disabledTools?.includes(tool.id);
});
  useEffect(()=>{
    if(!activeTool){setLayout(null);return;}
    let frame=0;
    let timer=0;
    let observer=null;
    let mutationObserver=null;
    let retries=0;
    const update=()=>{
      const anchor=document.querySelector('[data-panel="'+activeTool+'"]');
      if(!anchor||!anchor.getBoundingClientRect){
        // The panel may not have mounted yet; keep looking instead of giving up
        // forever. Retry on a timer, not rAF: rAF never fires while the document is
        // hidden, which left the rail permanently unpositioned.
        if(retries++<120){timer=setTimeout(update,25);}
        else{setLayout(null);}
        return;
      }
      const rect=anchor.getBoundingClientRect();
      if(!rect.width||!rect.height){
        if(retries++<120){timer=setTimeout(update,25);}
        else{setLayout(null);}
        return;
      }
      retries=0;
      const gap=12;
      const railWidth=48;
      const useSide=rect.left>=railWidth+gap+8;
      const next=useSide
        ?{orientation:'vertical',right:Math.max(8,Math.round(window.innerWidth-rect.left+gap)),top:Math.round(rect.top+(rect.height/2))}
        :{orientation:'horizontal',left:Math.round(rect.left+(rect.width/2)),top:Math.max(8,Math.round(rect.top-railWidth-gap))};
      setLayout(prev=>{
        if(prev&&prev.orientation===next.orientation&&prev.top===next.top&&prev.left===next.left&&prev.right===next.right)return prev;
        return next;
      });
    };
    // Debounce on a timer rather than rAF: rAF never fires while the document is
    // hidden, and this must stay correct in a backgrounded tab.
    const queue=()=>{if(timer)clearTimeout(timer);timer=setTimeout(update,16);};
    update(); // resolve synchronously; do not depend on a frame that may never come
    // The panel animates into place after it opens. Nothing observable fires for a
    // pure transition, so re-measure across the animation window and on transitionend.
    const settle=[60,140,240,360,520,760].map(ms=>setTimeout(update,ms));
    window.addEventListener('resize',queue);
    document.addEventListener('scroll',queue,true);
    const anchor=document.querySelector('[data-panel="'+activeTool+'"]');
    if(anchor)anchor.addEventListener('transitionend',queue);
    if(anchor&&window.ResizeObserver){observer=new ResizeObserver(queue);observer.observe(anchor);}
    if(anchor&&window.MutationObserver){mutationObserver=new MutationObserver(queue);mutationObserver.observe(anchor,{attributes:true,attributeFilter:['style','class']});}
    return()=>{if(frame)cancelAnimationFrame(frame);if(timer)clearTimeout(timer);settle.forEach(clearTimeout);if(anchor)anchor.removeEventListener('transitionend',queue);window.removeEventListener('resize',queue);document.removeEventListener('scroll',queue,true);if(observer)observer.disconnect();if(mutationObserver)mutationObserver.disconnect();};
  },[activeTool,disabledKey]);
  if(!activeTool||!tools.length||!layout)return null; // unpositioned fixed element would land inside the panel
  const horizontal=layout?.orientation==='horizontal';
  const style=layout?{
    ...(typeof layout.right==='number'?{right:layout.right+'px'}:{left:layout.left+'px'}),
    top:layout.top+'px',
    transform:horizontal?'translateX(-50%)':'translateY(-50%)'
  }:{};
  // Slide the active chip between icons. Measured from the live button because the
  // rail has dividers, so button offsets are not evenly spaced. First paint parks the
  // indicator without travelling - otherwise it flies in from the corner on open.
  const[ind,setInd]=useState(null);
  const indSeenRef=useRef(false);
  useLayoutEffect(()=>{
    const rail=railRef.current;
    if(!rail||!activeTool||!layout){indSeenRef.current=false;setInd(null);return;}
    const btn=rail.querySelector('.ve-studio-tool-rail-button.is-active');
    if(!btn){setInd(null);return;}
    const next={x:btn.offsetLeft,y:btn.offsetTop,w:btn.offsetWidth,h:btn.offsetHeight,first:!indSeenRef.current};
    indSeenRef.current=true;
    setInd(prev=>(prev&&prev.x===next.x&&prev.y===next.y&&prev.w===next.w&&prev.h===next.h&&prev.first===next.first)?prev:next);
  },[activeTool,layout,horizontal,tools.length,disabledKey]);

  const moveFocus=(event)=>{
    if(!['ArrowDown','ArrowUp','ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
    const buttons=Array.from(railRef.current?.querySelectorAll('.ve-studio-tool-rail-button')||[]);
    if(!buttons.length)return;
    event.preventDefault();
    let index=buttons.indexOf(document.activeElement);
    if(index<0)index=0;
    if(event.key==='Home')index=0;
    else if(event.key==='End')index=buttons.length-1;
    else if(event.key==='ArrowDown'||event.key==='ArrowRight')index=(index+1)%buttons.length;
    else index=(index-1+buttons.length)%buttons.length;
    buttons[index].focus();
  };
  return h('nav',{
    ref:railRef,
    class:'ve-studio-tool-rail'+(horizontal?' is-horizontal':'')+(layout?'':' is-pending'),
    style,
    'aria-label':'Mimam’s Var tools',
    onKeyDown:moveFocus
  },[
  ind&&h('span',{
    key:'ve-rail-ind',
    class:'ve-studio-tool-rail-ind is-on'+(ind.first?' is-first':''),
    'aria-hidden':'true',
    style:{transform:'translate('+ind.x+'px,'+ind.y+'px)',width:ind.w+'px',height:ind.h+'px'}
  }),
  ...tools.map((tool,index)=>h(Fragment,{key:tool.id},
    tool.id==='settings'&&index>0&&h('span',{class:'ve-studio-tool-rail-divider','aria-hidden':'true'}),
    h('button',{
      type:'button',
      class:'ve-studio-tool-rail-button '+(horizontal?'ve-tip-bottom':'ve-tip-right')+(activeTool===tool.id?' is-active':''),
      'aria-label':tool.label,
      'aria-current':activeTool===tool.id?'true':'false',
      'data-ve-tip':tool.label,
      onClick:()=>onSelect&&onSelect(tool.id)
    },ph(tool.icon))
  ))]);
}

function StandalonePanel({ title, onClose, onActivate, active, withStudioRail, children, width = 340, height = 'min(760px, calc(100vh - 32px))', defaultLeft, defaultTop, persistKey, panelId, open, panelMode, updateNotice, hasUpdate, backdrop = 'none' }) {
  const isWideStudio = panelId === 'content_studio' || panelId === 'media_studio' || panelId === 'plugin_studio' || panelId === 'css_recipes';
  const isStudio = isWideStudio || panelId === 'css_studio';
  const isRecipeStudio = panelId === 'css_recipes';
  const isCssStudio = panelId === 'css_studio';
  const supportsFullscreen = panelId === 'content_studio' || panelId === 'media_studio';
  const defaultViewKey = panelId === 'content_studio' ? 've_content_studio_default_view' : (panelId === 'media_studio' ? 've_media_studio_default_view' : '');
  const readDefaultFullscreen = () => {
    if (!supportsFullscreen || !defaultViewKey) return false;
    try { return localStorage.getItem(defaultViewKey) === 'fullscreen'; } catch (e) { return false; }
  };
  const compactRailLayout = !!withStudioRail && window.innerWidth <= 720;
  
  const [pos, setPos] = useState(() => {
    if (persistKey && !isCssStudio) {
      try {
        const saved = localStorage.getItem('ve_pos_' + persistKey);
        if (saved) return JSON.parse(saved);
      } catch (e) {}
    }
    return {
      left:defaultLeft !== undefined ? defaultLeft : Math.max(16, window.innerWidth - width - 16),
      top:defaultTop !== undefined ? defaultTop : 100
    };
  });
  
  const [dragging, setDragging] = useState(false);
  const [fullscreen, setFullscreen] = useState(readDefaultFullscreen);
  const panelRef = useRef();
  const dragRef = useRef(null);
  const wasOpenRef = useRef(false);

  useLayoutEffect(() => {
    if (!open) {
      setFullscreen(readDefaultFullscreen());
      wasOpenRef.current = false;
      return;
    }
    if (!wasOpenRef.current) setFullscreen(readDefaultFullscreen());
    wasOpenRef.current = true;
  }, [open, defaultViewKey]);

  useEffect(() => {
    const shouldLockBackgroundScroll = isWideStudio || panelId === 'settings';
    if (!open || !shouldLockBackgroundScroll || MODE === 'builder') return;
    const body = document.body;
    const html = document.documentElement;
    const prevBodyOverflow = body.style.overflow;
    const prevHtmlOverflow = html.style.overflow;
    body.style.overflow = 'hidden';
    html.style.overflow = 'hidden';
    return () => {
      body.style.overflow = prevBodyOverflow;
      html.style.overflow = prevHtmlOverflow;
    };
  }, [open, isWideStudio, panelId]);

  const startDrag = e => {
    if (isStudio) return;
    // Disable dragging for now
    return;
  };

  useEffect(() => {
    if (isStudio || !dragging) return;
    const move = e => {
      const d = dragRef.current;
      if (!d) return;
      const el = panelRef.current;
      const w = el ? el.offsetWidth : width;
      const hgt = el ? el.offsetHeight : (typeof height === 'number' ? height : 760);
      const maxLeft = Math.max(8, window.innerWidth - w - 8);
      const maxTop = Math.max(8, window.innerHeight - hgt - 8);
      const next = {
        left:Math.max(8, Math.min(maxLeft, d.left + (e.clientX - d.x))),
        top:Math.max(8, Math.min(maxTop, d.top + (e.clientY - d.y)))
      };
      setPos(next);
      if (persistKey) {
        persistUserPreference('ve_pos_' + persistKey, next);
      }
    };
    const up = () => {
      setDragging(false);
      dragRef.current = null;
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    return () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
  }, [dragging, pos, persistKey, width, height, isStudio]);

  const isDocked = !isStudio && (panelMode === 'left' || panelMode === 'right');
  const toolWidth = isCssStudio ? 430 : width;
  const displayTop = compactRailLayout ? '64px' : (isWideStudio ? '50%' : (isCssStudio ? '16px' : (isDocked ? '8px' : pos.top + 'px')));
  const displayLeft = isWideStudio ? '50%' : (isCssStudio ? Math.max(16, window.innerWidth - toolWidth - 16) + 'px' : (isDocked 
    ? (panelMode === 'left' ? '16px' : Math.max(16, window.innerWidth - width - 16) + 'px')
    : pos.left + 'px'));
  const displayHeight = compactRailLayout ? 'calc(100vh - 80px)' : (isWideStudio ? '88dvh' : (isCssStudio ? 'calc(100vh - 32px)' : (isDocked ? 'calc(100vh - 16px)' : (typeof height === 'number' ? height + 'px' : height))));
  const displayTransform = isWideStudio ? (compactRailLayout?'translateX(-50%)':'translate(-50%, -50%)') : 'none';
  const displayWidth = compactRailLayout ? 'calc(100vw - 32px)' : (isWideStudio ? (isRecipeStudio ? (withStudioRail?'min(calc(100vw - 176px), 1120px)':'min(calc(100vw - 96px), 1120px)') : (withStudioRail?'calc(100vw - 176px)':'calc(100vw - 96px)')) : (isCssStudio ? 'min(430px, calc(100vw - 32px))' : width + 'px'));

  const style = {
    position: 'fixed',
    left:displayLeft,
    top:displayTop,
    transform: displayTransform,
    width: displayWidth,
    maxWidth: isWideStudio ? (isRecipeStudio ? '1120px' : '1920px') : (isCssStudio ? '430px' : 'none'),
    height: displayHeight,
    maxHeight: compactRailLayout ? 'calc(100vh - 80px)' : (isWideStudio ? '88dvh' : (isCssStudio ? 'calc(100vh - 32px)' : (isDocked ? 'calc(100vh - 16px)' : (typeof height === 'string' && height.indexOf('16px') !== -1 ? 'calc(100vh - 16px)' : 'calc(100vh - 32px)')))),
    background: isStudio || isCssStudio ? '#151515' : '#1f1f1f',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    borderRadius: isStudio || isCssStudio ? '12px' : '10px',
    boxShadow: isStudio || isCssStudio ? '0 24px 70px rgba(0, 0, 0, 0.55)' : '0 18px 46px rgba(0, 0, 0, 0.40)',
    zIndex: active ? 120010 : 120000,
    display: 'flex',
    flexDirection: 'column',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    fontSize: '13px',
    color: '#f1f1f1',
    userSelect: 'none',
    overflow: 'hidden'
  };

  if (supportsFullscreen && fullscreen) {
    Object.assign(style, {
      left: '0',
      top: '0',
      transform: 'none',
      width: '100vw',
      maxWidth: 'none',
      height: '100dvh',
      maxHeight: 'none',
      borderRadius: '0',
      resize: 'none'
    });
  }

  if (!open) return null;

  return h(Fragment, null,
    backdrop !== 'none' && h('button', { type: 'button', class: 've-studio-backdrop' + (backdrop !== 'blur' ? ' ve-bd-' + backdrop : ''), 'aria-label': 'Close ' + title, onClick: () => (isWideStudio && onClose) ? onClose() : (onClose && onClose()) }),
    h('div', { ref: panelRef, tabIndex:-1, 'data-panel': panelId, class: 've-o ve-standalone-panel' + (open ? ' open' : '') + (dragging ? ' ve-dragging' : '') + (hasUpdate ? ' has-update' : '') + (withStudioRail ? ' ve-has-studio-rail' : '') + (fullscreen ? ' ve-panel-fullscreen' : ''), style, onPointerDown:()=>onActivate&&onActivate(panelId) },
      h('div', { class: 've-hdr', style: { cursor: isStudio ? 'default' : 'grab', background: '#171717', borderBottom: '1px solid rgba(255,255,255,0.06)' }, onMouseDown: isStudio ? undefined : startDrag },
        !isStudio && h('span', { class: 've-drag-handle', style: { marginRight: '8px' } }, ph('dots-six-vertical')),
        h('span', { class: 've-hdr-t', style: isStudio ? 'font-size:12px;color:#fff' : '' }, title),
        h('div', { style: 'display:flex;gap:4px;margin-left:auto' },
          supportsFullscreen&&h('button', { type: 'button', class: 've-a', style: 'width:26px;height:26px;display:flex;align-items:center;justify-content:center', onClick: e => { e.preventDefault(); e.stopPropagation(); setFullscreen(value => !value); }, title: fullscreen ? 'Exit full screen' : 'Full screen', 'aria-label': fullscreen ? 'Exit full screen' : 'Open full screen', 'aria-pressed': fullscreen ? 'true' : 'false' }, ph(fullscreen ? 'corners-in' : 'corners-out')),
          h('button', { type: 'button', class: 've-a', style: 'width:26px;height:26px;display:flex;align-items:center;justify-content:center', onClick: e => { e.preventDefault(); e.stopPropagation(); onClose && onClose(); }, title: 'Close' }, ph('x'))
        ),
        h(ActivityProgress,{panelId})
      ),
      updateNotice,
      children
    )
  );
}

/* ── Help panel component ── */
// Documentation content (#14). Bodies are block arrays: p / h2 / callout / steps / code / kbd / list.
const DOCS_MODULES = [
  { id: 'variables', label: 'Variables', icon: 'sliders-horizontal', color: 'rgba(186,244,0,.16)', tint: '#baf400', blurb: 'Tokens, fluid scales, families, and export.' },
  { id: 'media', label: 'Media Studio', icon: 'image', color: 'rgba(158,201,255,.16)', tint: '#9ec9ff', blurb: 'Collections, imports, conversion, and the picker bridge.' },
  { id: 'content', label: 'Content Studio', icon: 'article', color: 'rgba(155,140,255,.16)', tint: '#9b8cff', blurb: 'ACF content models, the SEO panel, and content import.' },
  { id: 'builder', label: 'Builder Tools', icon: 'magic-wand', color: 'rgba(127,224,192,.16)', tint: '#7fe0c0', blurb: 'Mimam’s Bar — Direct, Bulk, Everything, and Rename.' },
  { id: 'recovery', label: 'Recovery', icon: 'clock-counter-clockwise', color: 'rgba(255,207,138,.16)', tint: '#ffcf8a', blurb: 'Backups, restore ladders, and production safeguards.' }
];
const DOCS_ARTICLES = [
  { id: 'fluid-scales', module: 'variables', title: 'Fluid scales', read: '3 min', updated: 'v1.3.300', summary: 'Author a min/max pair and let MV interpolate across the viewport.', body: [
    { p: 'A fluid value moves smoothly between a minimum and maximum across a viewport range instead of snapping at breakpoints. MV stores the raw min/max and generates the clamp() at output time.' },
    { h2: 'Set one up', id: 's1' },
    { steps: ['Pick a variable and switch its value control to Fluid.', 'Enter the minimum and maximum values.', 'MV interpolates between your viewport min and max (set in Settings).'] },
    { callout: 'tip', text: 'Unitless families — font weight, line-height, z-index, opacity — are excluded from the dimension converter so they never become 1rem.' }
  ] },
  { id: 'export-tokens', module: 'variables', title: 'Export tokens', read: '2 min', updated: 'v1.3.288', summary: 'Values are authored raw; the unit is chosen at export/output.', body: [
    { p: 'MV authors values raw and applies the unit at output/export, so the same token can drive live CSS and every export target consistently.' }
  ] },
  { id: 'media-collections', module: 'media', title: 'Collections & folders', read: '3 min', updated: 'v1.3.375', summary: 'Group media into nested collections stored as an attachment taxonomy.', body: [
    { p: 'Collections live as a dedicated attachment taxonomy, so grouping never moves or duplicates files. Sub-collections nest with a “Parent / Child” name.' },
    { callout: 'tip', text: 'Creating a collection selects and opens it immediately, expanding its parent branch if collapsed.' }
  ] },
  { id: 'media-import', module: 'media', title: 'Import from URL or ZIP', read: '3 min', updated: 'v1.3.373', summary: 'Bring external media in without leaving Media Studio.', body: [
    { p: 'Paste a URL or drop a ZIP to import into a collection. Filenames keep their spaces — a source name with %20 is decoded before sanitising.' }
  ] },
  { id: 'acf-models', module: 'content', title: 'ACF content models', read: '5 min', updated: 'v1.3.383', summary: 'Create Post Types, Taxonomies, and Options Pages without leaving Content Studio.', body: [
    { p: 'Content Studio edits ACF’s own records. Each section — Custom Post Types, Taxonomies, Options Pages — has a tabbed editor that saves through ACF’s API, merging into the existing definition so nothing you don’t touch is lost.' },
    { h2: 'The category list', id: 's1' },
    { p: 'Click a section header to list its items in a table with inline toggles (Public, Hierarchical, Archive, Front prefix) that save through ACF. The caret alone collapses the section.' }
  ] },
  { id: 'seo-panel', module: 'content', title: 'The SEO panel & Rank Math', read: '3 min', updated: 'v1.3.380', summary: 'Live on-page analysis, focus keywords, and a Google/social preview.', body: [
    { p: 'The SEO panel scores the page live from on-page checks as you type. When Rank Math isn’t active a notice makes clear the analysis is Content Studio’s own.' },
    { callout: 'warn', text: 'Rank Math free allows up to 5 focus keywords; Content Studio respects that limit.' }
  ] },
  { id: 'bar-commands', module: 'builder', title: 'Mimam’s Bar commands', read: '5 min', updated: 'v1.3.381', summary: 'Direct edits, bulk targets, combined selectors, and mode switching.', body: [
    { h2: 'Direct mode', id: 's1' },
    { list: [['data-anim="fade-up"', 'Set or update an attribute on the selected element.'], ['.hero-card', 'Add a class to the selected element.'], ['#hero-title', 'Set the CSS ID.'], ['-.hero-card', 'Remove a class.'], ['delete data-anim', 'Remove an attribute.']] },
    { callout: 'tip', text: 'With a class/attribute token focused, Enter applies the command — the same as the Apply button.' },
    { h2: 'Bulk targets', id: 's2' },
    { list: [['all li => data-anim="fade-up"', 'Every matching <li> on the page/template.'], ['.service-card => data-anim="fade-up"', 'Every element with that class.'], ['#hero-title => data-anim="text-lines"', 'One element by CSS ID.']] },
    { h2: 'Modes & helpers', id: 's3' },
    { kbd: [['1', 'Direct'], ['2', 'Search elements'], ['3', 'Add elements'], ['//', 'Close the Bar'], ['--', 'Variable autocomplete']] }
  ] },
  { id: 'font-relink', module: 'builder', title: 'Recover a missing font file', read: '4 min', updated: 'v1.3.343', summary: 'Repoint a Bricks font family whose media attachment stopped resolving.', body: [
    { p: 'Bricks stores a font family and its variant records separately from the WordPress media attachment holding the file. If that attachment stops resolving — after a migration, re-upload, or deleted file — the family record survives while pointing at nothing.' },
    { callout: 'warn', text: 'The file itself cannot be reconstructed. MV can only restore the link to a real file — one already in your library, or one you re-upload.' },
    { h2: 'Spot it', id: 's1' },
    { p: 'A broken variant no longer previews in its own typeface; the row is marked and the family shows a warning.' },
    { h2: 'Fix it', id: 's2' },
    { steps: ['Open Font Manager → Library and find the family with the warning banner.', 'On the broken variant press Relink. MV scans the media library and ranks candidates — exact filename first, then weight/style.', 'Pick the file and press Relink selected. The row heals and the preview returns.', 'If nothing matches, drop the font file onto the panel to re-upload and repoint the variant.', 'If the variant is no longer used, just Remove it.'] },
    { callout: 'tip', text: 'Fix all relinks every variant with an exact-name match in one pass — the usual case after a migration.' }
  ] },
  { id: 'rename-fast', module: 'builder', title: 'Rename an element fast', read: '1 min', updated: 'v1.3.326', summary: 'Double-tap R to rename the selected element.', body: [
    { p: 'Select an element and double-tap R. The rename bar opens with the label pre-selected; Enter applies, Esc cancels. Works on component roots too.' }
  ] },
  { id: 'recovery-restore', module: 'recovery', title: 'Backups & restore', read: '4 min', updated: 'v1.3.292', summary: 'Two restore paths: the staging ladder and a typed production restore.', body: [
    { p: 'Recovery keeps snapshots you can restore. Production restore is guarded behind a readiness check and a typed confirmation so it can’t fire by accident.' },
    { callout: 'warn', text: 'Production restore requires typing RESTORE PRODUCTION — it stays self-blocked until the readiness checks pass.' }
  ] }
];
const DOCS_FAQ = [
  { q: 'A font shows as “attachment missing” — what now?', a: 'Bricks keeps the font family record separately from the media attachment. When the attachment stops resolving the record survives, pointing at nothing. Open Font Manager → Relink — MV finds a filename match and repoints it in one click.', article: 'font-relink' },
  { q: 'Why did my font-weight become 1rem?', a: 'Older builds swept every font.* token through the dimension converter. Unitless families (weight, line-height, z-index, opacity) are now excluded — update to 1.3.306+.' },
  { q: 'How do I rename an element fast?', a: 'Select it and double-tap R. The rename bar opens with the label pre-selected; Enter applies, Esc cancels.', article: 'rename-fast' }
];
const DOCS_NEWS = [
  ['v1.3.383', 'Options Pages editor', 'Create and edit ACF options pages in Content Studio.'],
  ['v1.3.377', 'ACF content-model list', 'Section headers open a table with inline toggles.'],
  ['v1.3.371', 'Snappier Bar', 'Suggestions respond in ~0.12s, and typing // closes the Bar.']
];

function HelpPanel({ onClose }) {
  const [view, setView] = useState('home');
  const [module, setModule] = useState('home');
  const [articleId, setArticleId] = useState('');
  const [query, setQuery] = useState('');
  const [openFaq, setOpenFaq] = useState(0);
  const searchRef = useRef(null);
  const article = DOCS_ARTICLES.find(a => a.id === articleId);
  const moduleOf = id => DOCS_MODULES.find(m => m.id === id) || {};
  const count = id => DOCS_ARTICLES.filter(a => a.module === id).length;
  const q = query.trim().toLowerCase();
  const searchHits = q ? DOCS_ARTICLES.filter(a => (a.title + ' ' + a.summary).toLowerCase().indexOf(q) !== -1) : [];
  const openArticle = id => { setArticleId(id); setView('article'); };
  const openModule = id => { setModule(id); setView('module'); setQuery(''); };
  const goHome = () => { setModule('home'); setView('home'); setQuery(''); };
  const renderBlock = (b, i) => {
    if (b.p) return h('p', { key: i }, b.p);
    if (b.h2) return h('h2', { key: i, id: b.id }, b.h2);
    if (b.callout) return h('div', { class: 've-doc-callout ' + b.callout, key: i }, ph(b.callout === 'warn' ? 'warning' : 'lightbulb'), h('div', null, b.text));
    if (b.steps) return h('ol', { class: 've-doc-steps', key: i }, b.steps.map((s, j) => h('li', { key: j }, s)));
    if (b.list) return h('div', { class: 've-doc-cmdlist', key: i }, b.list.map((r, j) => h('div', { class: 've-doc-cmd', key: j }, h('code', null, r[0]), h('span', null, r[1]))));
    if (b.kbd) return h('div', { class: 've-doc-kbds', key: i }, b.kbd.map((r, j) => h('span', { class: 've-doc-kbd', key: j }, h('kbd', null, r[0]), r[1])));
    return null;
  };
  return h('div', { class: 've-body ve-docs' },
    h('div', { class: 've-docs-body' },
      h('div', { class: 've-docs-rail' },
        h('div', { class: 've-docs-rl' }, 'Browse'),
        h('button', { class: 've-docs-rnav' + (view === 'home' ? ' on' : ''), onClick: goHome }, ph('house'), h('span', { class: 'n' }, 'Home')),
        h('div', { class: 've-docs-rl' }, 'Modules'),
        DOCS_MODULES.map(m => h('button', { key: m.id, class: 've-docs-rnav' + (module === m.id && view !== 'home' ? ' on' : ''), onClick: () => openModule(m.id) }, ph(m.icon), h('span', { class: 'n' }, m.label), h('span', { class: 'c' }, count(m.id)))),
        h('div', { class: 've-docs-rl' }, 'Help'),
        h('button', { class: 've-docs-rnav', onClick: () => { goHome(); setTimeout(() => searchRef.current && searchRef.current.focus(), 30); } }, ph('question'), h('span', { class: 'n' }, 'Quick answers'))
      ),
      h('div', { class: 've-docs-main' },
        view === 'article' && article ? h('div', { class: 've-doc-art' },
          h('div', { class: 've-doc-crumbs' }, h('button', { onClick: () => openModule(article.module) }, ph('arrow-left'), moduleOf(article.module).label), h('span', null, ' / '), h('span', { style: 'color:#b9b9b9' }, article.title)),
          h('h1', null, article.title),
          h('div', { class: 've-doc-artmeta' }, h('span', { class: 've-doc-pillm' }, moduleOf(article.module).label), h('span', { class: 've-doc-pillm' }, article.read + ' read'), h('span', null, 'Updated for ' + article.updated)),
          article.body.map(renderBlock)
        ) : view === 'module' ? h('div', { class: 've-docs-sect' },
          h('h3', null, moduleOf(module).label),
          h('p', { class: 've-docs-modblurb' }, moduleOf(module).blurb),
          h('div', { class: 've-docs-list' }, DOCS_ARTICLES.filter(a => a.module === module).map(a => h('button', { key: a.id, class: 've-docs-listitem', onClick: () => openArticle(a.id) },
            h('div', null, h('strong', null, a.title), h('span', null, a.summary)),
            h('span', { class: 've-docs-listmeta' }, a.read, ph('arrow-right'))
          )))
        ) : h('div', null,
          h('div', { class: 've-docs-hero' },
            h('h2', null, 'What do you want to ', h('em', null, 'build'), '?'),
            h('p', null, 'Search the docs or pick a module. Type to filter across every article.'),
            h('div', { class: 've-docs-search' }, ph('magnifying-glass'), h('input', { ref: searchRef, placeholder: 'Search the docs — try “relink font” or “fluid scale”…', value: query, onInput: e => setQuery(e.target.value) })),
            !q && h('div', { class: 've-docs-pops' }, ['relink font', 'fluid scale', 'direct mode', 'export tokens', 'options page'].map(p => h('button', { key: p, class: 've-docs-pop', onClick: () => setQuery(p) }, p)))
          ),
          q ? h('div', { class: 've-docs-sect' },
            h('h3', null, searchHits.length + ' result' + (searchHits.length === 1 ? '' : 's')),
            searchHits.length ? h('div', { class: 've-docs-list' }, searchHits.map(a => h('button', { key: a.id, class: 've-docs-listitem', onClick: () => openArticle(a.id) },
              h('div', null, h('strong', null, a.title), h('span', null, a.summary)),
              h('span', { class: 've-docs-listmeta' }, moduleOf(a.module).label, ph('arrow-right'))
            ))) : h('div', { class: 've-docs-empty' }, 'No articles match. Try a different term.')
          ) : [
            h('div', { class: 've-docs-sect', key: 'mods' },
              h('h3', null, 'Browse by module'),
              h('div', { class: 've-docs-cards' }, DOCS_MODULES.map(m => h('button', { key: m.id, class: 've-docs-card', style: '--gl:' + m.color, onClick: () => openModule(m.id) },
                h('span', { class: 've-docs-ci', style: 'color:' + m.tint }, ph(m.icon)),
                h('h4', null, m.label), h('p', null, m.blurb),
                h('span', { class: 've-docs-cmeta' }, count(m.id) + ' articles', h('span', { class: 'go' }, 'Open', ph('arrow-right')))
              )))
            ),
            h('div', { class: 've-docs-sect', key: 'faq', style: 'padding-top:0' },
              h('h3', null, 'Quick answers'),
              h('div', { class: 've-docs-qa' }, DOCS_FAQ.map((f, i) => h('div', { key: i, class: 've-docs-qi' + (openFaq === i ? ' open' : '') },
                h('button', { class: 've-docs-qq', onClick: () => setOpenFaq(openFaq === i ? -1 : i) }, h('span', { class: 've-docs-qc' }, ph('question')), h('span', { style: 'flex:1' }, f.q), ph('caret-down')),
                openFaq === i && h('div', { class: 've-docs-qbody' }, f.a, f.article && h('button', { class: 've-docs-pop', style: 'margin-top:8px', onClick: () => openArticle(f.article) }, 'Read the full guide'))
              )))
            ),
            h('div', { class: 've-docs-sect', key: 'news', style: 'padding-top:0' },
              h('h3', null, 'What’s new'),
              h('div', { class: 've-docs-news' }, DOCS_NEWS.map((n, i) => h('div', { key: i, class: 've-docs-nw' }, h('span', { class: 'v' }, n[0]), h('h5', null, n[1]), h('p', null, n[2]))))
            )
          ]
        )
      )
    )
  );
}

function RichContentEditor({ value, onChange, onChooseImage, workspace, beforeSurface, readOnly, onNotice, onBlockSelect, theme, onTheme }) {
  const ref = useRef(null);
  const aiWrapRef = useRef(null);
  const formatWrapRef = useRef(null);
  const colorWrapRef = useRef(null);
  const contextMenuRef = useRef(null);
  const savedRangeRef = useRef(null);
  const lastAltTapRef = useRef(0);
  const lastHtml = useRef('');
  const [dialog, setDialog] = useState(null);
  const [ownTheme, setOwnTheme] = useState(() => localStorage.getItem('ve_content_editor_theme') || 'dark');
  const editorTheme = theme || ownTheme;
  const [aiOpen, setAiOpen] = useState(false);
  const [formatOpen, setFormatOpen] = useState(false);
  const [highlightOpen, setHighlightOpen] = useState(false);
  const [highlightColor, setHighlightColor] = useState('#baf400');
  const [highlightAlpha, setHighlightAlpha] = useState(1);
  const [highlightFormat, setHighlightFormat] = useState('hex');
  const [activeFormat, setActiveFormat] = useState('p');
  const [contextMenu, setContextMenu] = useState(null);

  useEffect(() => {
    if (!aiOpen) return;
    const close = event => { if (aiWrapRef.current && !aiWrapRef.current.contains(event.target)) setAiOpen(false); };
    document.addEventListener('pointerdown', close);
    return () => document.removeEventListener('pointerdown', close);
  }, [aiOpen]);

  useEffect(() => {
    if (!formatOpen && !highlightOpen) return;
    const close = event => {
      if (formatOpen && formatWrapRef.current && !formatWrapRef.current.contains(event.target)) setFormatOpen(false);
      if (highlightOpen && colorWrapRef.current && !colorWrapRef.current.contains(event.target)) setHighlightOpen(false);
    };
    document.addEventListener('pointerdown', close, true);
    return () => document.removeEventListener('pointerdown', close, true);
  }, [formatOpen, highlightOpen]);

  useEffect(() => {
    if (!contextMenu) return;
    const close = event => {
      if (contextMenuRef.current && contextMenuRef.current.contains(event.target)) return;
      setContextMenu(null);
    };
    const closeOnKey = event => { if (event.key === 'Escape') setContextMenu(null); };
    document.addEventListener('pointerdown', close, true);
    document.addEventListener('keydown', closeOnKey, true);
    window.addEventListener('resize', close);
    return () => {
      document.removeEventListener('pointerdown', close, true);
      document.removeEventListener('keydown', closeOnKey, true);
      window.removeEventListener('resize', close);
    };
  }, [contextMenu]);

  useEffect(() => {
    const html = value || '';
    if (ref.current && document.activeElement === ref.current) return;
    if (ref.current && html !== lastHtml.current && ref.current.innerHTML !== html) {
      ref.current.innerHTML = html;
      lastHtml.current = html;
    }
  }, [value]);

  const commit = () => {
    if (!ref.current) return;
    const clone = ref.current.cloneNode(true);
    clone.querySelectorAll('.ve-rich-selected-block').forEach(node => {
      node.classList.remove('ve-rich-selected-block');
      node.removeAttribute('data-ve-block-label');
      if (!node.getAttribute('class')) node.removeAttribute('class');
    });
    const html = clone.innerHTML || '';
    lastHtml.current = html;
    onChange(html);
  };

  const blockLabel = node => {
    const tag = String(node?.tagName || '').toLowerCase();
    if (/^h[1-6]$/.test(tag)) return 'Heading ' + tag.slice(1);
    if (tag === 'img' || tag === 'figure') return 'Image block';
    if (tag === 'blockquote') return 'Quote block';
    if (tag === 'ul') return 'Bulleted list';
    if (tag === 'ol') return 'Numbered list';
    if (tag === 'pre') return 'Code block';
    if (tag === 'hr') return 'Divider';
    if (tag === 'p') return 'Paragraph';
    return 'Content block';
  };
  const clearEditableBlockSelection = () => {
    if (!ref.current) return;
    ref.current.querySelectorAll('.ve-rich-selected-block').forEach(node => {
      node.classList.remove('ve-rich-selected-block');
      node.removeAttribute('data-ve-block-label');
      if (!node.getAttribute('class')) node.removeAttribute('class');
    });
  };
  const editableBlockForTarget = target => {
    if (!ref.current || !target) return;
    const clickedImage = target.closest && target.closest('img');
    let block = target.closest && target.closest('img,figure,h1,h2,h3,h4,h5,h6,blockquote,pre,ul,ol,hr,p,div');
    if (!block || block === ref.current || !ref.current.contains(block)) return null;
    if (clickedImage) block = clickedImage.closest('figure') || clickedImage.closest('p') || clickedImage;
    while (block.parentElement && block.parentElement !== ref.current) block = block.parentElement;
    return { block, clickedImage };
  };
  const selectEditableBlock = target => {
    const match = editableBlockForTarget(target);
    if (!match) {
      ref.current.querySelectorAll('.ve-rich-selected-block').forEach(node => {
        node.classList.remove('ve-rich-selected-block');
        node.removeAttribute('data-ve-block-label');
      });
      if (typeof onBlockSelect === 'function') onBlockSelect(null);
      return;
    }
    const { block, clickedImage } = match;
    const formatNode = target?.closest?.('p,h1,h2,h3,h4,h5,h6,blockquote,pre');
    const formatTag = String(formatNode?.tagName || block?.tagName || 'p').toLowerCase();
    setActiveFormat(['p','h1','h2','h3','h4','h5','h6','blockquote','pre'].includes(formatTag)?formatTag:'p');
    ref.current.querySelectorAll('.ve-rich-selected-block').forEach(node => {
      node.classList.remove('ve-rich-selected-block');
      node.removeAttribute('data-ve-block-label');
    });
    const label = clickedImage ? 'Image block' : blockLabel(block);
    block.classList.add('ve-rich-selected-block');
    block.setAttribute('data-ve-block-label', label);
    const siblings = Array.from(ref.current.children);
    const image = clickedImage || (String(block.tagName||'').toLowerCase()==='img'?block:block.querySelector?.('img')) || null;
    if (typeof onBlockSelect === 'function') onBlockSelect({ id: 'block-' + Math.max(0, siblings.indexOf(block)), label, type: label, tag: String(image?.tagName || block.tagName || '').toLowerCase(), text: image ? String(image.getAttribute('alt') || '').trim() : String(block.textContent || '').replace(/\s+/g,' ').trim(), image: image?{src:String(image.getAttribute('src')||''),alt:String(image.getAttribute('alt')||'')}:null });
  };

  const openBlockContextMenu = event => {
    if (readOnly) return;
    const match = editableBlockForTarget(event.target);
    if (!match) return;
    const textTarget=event.target?.closest?.('p,h1,h2,h3,h4,h5,h6,li,blockquote,pre');
    if(event.isTrusted&&textTarget&&!match.clickedImage&&String(textTarget.textContent||'').trim())return;
    event.preventDefault();
    selectEditableBlock(event.target);
    const width = 236;
    const height = 380;
    const editor=ref.current?.closest?.('.ve-rich-editor');
    const editorRect=editor?.getBoundingClientRect?.()||{left:0,top:0,right:window.innerWidth,bottom:window.innerHeight};
    const bounds=ownedOverlayBounds(editor||ref.current,8);
    const clientLeft=Math.max(Math.max(bounds.left,editorRect.left+8),Math.min(event.clientX,Math.min(bounds.right,editorRect.right)-width-8));
    const clientTop=Math.max(Math.max(bounds.top,editorRect.top+8),Math.min(event.clientY,Math.min(bounds.bottom,editorRect.bottom)-Math.min(height,Math.max(120,editorRect.height-16))));
    const contextImage=match.clickedImage || match.block.querySelector?.('img') || null;
    const contextLabel=contextImage?'Image block':blockLabel(match.block);
    const contextText=String(contextImage?.getAttribute?.('alt')||match.block.textContent||'').replace(/\s+/g,' ').trim();
    setContextMenu({
      block: match.block,
      image: contextImage,
      label:contextLabel,
      summary:contextText?(contextText.length>44?contextText.slice(0,43)+'…':contextText):'',
      insertOpen:false,
      left: clientLeft-editorRect.left,
      top: clientTop-editorRect.top
    });
  };
  const contextInsertMarkup={paragraph:'<p><br></p>',heading:'<h2>New heading</h2>',quote:'<blockquote>Write a quote…</blockquote>',code:'<pre><code>// Write code here</code></pre>',bullets:'<ul><li>List item</li></ul>',numbers:'<ol><li>List item</li></ol>',divider:'<hr>'};
  const runBlockContextAction = (action,insertType='paragraph') => {
    const block = contextMenu?.block;
    if (!block || !ref.current || !ref.current.contains(block)) { setContextMenu(null); return; }
    let nextSelection = block;
    if (action === 'duplicate') {
      const clone = block.cloneNode(true);
      clone.classList.remove('ve-rich-selected-block');
      clone.removeAttribute('data-ve-block-label');
      block.after(clone);
      nextSelection = clone;
    } else if (action === 'insert') {
      if(insertType==='image'){
        setContextMenu(null);
        if(typeof onChooseImage==='function')onChooseImage((url,item)=>{
          if(!url)return;
          const figure=document.createElement('figure');
          const image=document.createElement('img');
          image.src=String(url);
          image.alt=String(item?.alt||item?.name||'');
          figure.appendChild(image);
          block.after(figure);
          commit();
          setTimeout(()=>selectEditableBlock(image),0);
        });
        return;
      }
      const holder=document.createElement('div');
      holder.innerHTML=contextInsertMarkup[insertType]||contextInsertMarkup.paragraph;
      const inserted=holder.firstElementChild;
      if(inserted){block.after(inserted);nextSelection=inserted;}
    } else if (action === 'up' && block.previousElementSibling) {
      block.previousElementSibling.before(block);
    } else if (action === 'down' && block.nextElementSibling) {
      block.nextElementSibling.after(block);
    } else if (action === 'delete') {
      nextSelection = block.nextElementSibling || block.previousElementSibling;
      block.remove();
    }
    setContextMenu(null);
    commit();
    setTimeout(() => {
      if (!nextSelection || !ref.current?.contains(nextSelection)) {
        clearEditableBlockSelection();
        if (typeof onBlockSelect === 'function') onBlockSelect(null);
        return;
      }
      nextSelection.focus?.();
      selectEditableBlock(nextSelection);
      nextSelection.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
    }, 0);
  };
  const replaceContextImage=()=>{
    const image=contextMenu?.image;
    if(!image||typeof onChooseImage!=='function')return;
    setContextMenu(null);
    onChooseImage((url,item)=>{
      const target=ref.current?.querySelector?.('.ve-rich-selected-block img,.ve-rich-selected-block')||image;
      const nextImage=String(target?.tagName||'').toLowerCase()==='img'?target:target?.querySelector?.('img')||image;
      if(!url||!ref.current?.contains(nextImage))return;
      nextImage.src=String(url);
      if(!nextImage.getAttribute('alt')&&item)nextImage.alt=String(item.alt||item.name||item.title?.rendered||'');
      commit();
      selectEditableBlock(nextImage);
    });
  };
  const editContextImageAlt=()=>{
    const image=contextMenu?.image;
    if(!image)return;
    setDialog({type:'alt',value:String(image.getAttribute('alt')||''),image});
    setContextMenu(null);
  };

  const saveSelection = () => {
    try {
      const sel = window.getSelection && window.getSelection();
      if (!sel || !sel.rangeCount || !ref.current) return;
      const node = sel.anchorNode;
      if (node && (node === ref.current || ref.current.contains(node))) {
        savedRangeRef.current = sel.getRangeAt(0).cloneRange();
      }
    } catch (e) {}
  };

  const handleSurfaceKeyDown = event => {
    saveSelection();
    if (!readOnly && event.key === 'Alt' && !event.repeat && !event.ctrlKey && !event.metaKey && !event.shiftKey && ref.current) {
      event.preventDefault();
      event.stopPropagation();
      const now = Date.now();
      const isDoubleTap = now - lastAltTapRef.current <= 520;
      lastAltTapRef.current = isDoubleTap ? 0 : now;
      if (!isDoubleTap) return;

      const selection = window.getSelection && window.getSelection();
      const anchor = selection && selection.anchorNode;
      const target = anchor && anchor.nodeType === 1 ? anchor : anchor && anchor.parentElement;
      let match = editableBlockForTarget(target);
      if (!match) {
        const selected = ref.current.querySelector('.ve-rich-selected-block') || ref.current.lastElementChild;
        match = editableBlockForTarget(selected);
      }
      if (!match) {
        const paragraph = document.createElement('p');
        paragraph.innerHTML = '<br>';
        ref.current.appendChild(paragraph);
        commit();
        match = { block: paragraph, clickedImage: null };
      }

      selectEditableBlock(match.clickedImage || match.block);
      const editor = ref.current.closest('.ve-rich-editor');
      const editorRect = editor?.getBoundingClientRect?.() || { left: 0, top: 0, right: window.innerWidth, bottom: window.innerHeight, height: window.innerHeight };
      const bounds = ownedOverlayBounds(editor || ref.current, 8);
      let caretRect = null;
      try {
        if (selection && selection.rangeCount) caretRect = selection.getRangeAt(0).getBoundingClientRect();
      } catch (error) {}
      const blockRect = match.block.getBoundingClientRect();
      const clientX = caretRect && (caretRect.width || caretRect.height) ? caretRect.left : blockRect.left + Math.min(36, blockRect.width / 2);
      const clientY = caretRect && (caretRect.width || caretRect.height) ? caretRect.bottom : blockRect.top + Math.min(28, blockRect.height / 2);
      const width = 236;
      const height = 300;
      const left = Math.max(Math.max(bounds.left, editorRect.left + 8), Math.min(clientX, Math.min(bounds.right, editorRect.right) - width - 8));
      const top = Math.max(Math.max(bounds.top, editorRect.top + 8), Math.min(clientY + 8, Math.min(bounds.bottom, editorRect.bottom) - Math.min(height, Math.max(120, editorRect.height - 16))));
      setContextMenu({
        block: match.block,
        image: null,
        label: 'Add block below',
        summary: 'Choose the block to insert after the current block.',
        insertOpen: true,
        insertOnly: true,
        left: left - editorRect.left,
        top: top - editorRect.top
      });
      return;
    }
    if (readOnly || event.key !== 'Enter' || event.shiftKey || !ref.current) return;
    clearEditableBlockSelection();
    setTimeout(() => {
      if (!ref.current) return;
      const selection = window.getSelection && window.getSelection();
      const anchor = selection && selection.anchorNode;
      const target = anchor && anchor.nodeType === 1 ? anchor : anchor && anchor.parentElement;
      if (target && ref.current.contains(target)) selectEditableBlock(target);
    }, 0);
  };

  const restoreSelection = () => {
    if (!ref.current) return;
    ref.current.focus();
    try {
      const range = savedRangeRef.current;
      const sel = window.getSelection && window.getSelection();
      if (range && sel) {
        sel.removeAllRanges();
        sel.addRange(range);
      }
    } catch (e) {}
  };

  const exec = (cmd, arg) => {
    if (!ref.current) return;
    restoreSelection();
    try { document.execCommand(cmd, false, arg); } catch (e) {}
    commit();
    setTimeout(()=>{
      const selection=window.getSelection&&window.getSelection();
      const anchor=selection?.anchorNode;
      const target=anchor?.nodeType===1?anchor:anchor?.parentElement;
      if(target&&ref.current?.contains(target))selectEditableBlock(target);
    },0);
  };

  const openInlineDialog = type => {
    saveSelection();
    setDialog({ type, value: '' });
  };

  const applyInlineDialog = () => {
    const next = String(dialog?.value || '').trim();
    if(dialog?.type==='alt'){
      if(dialog.image&&ref.current?.contains(dialog.image)){
        dialog.image.setAttribute('alt',next);
        commit();
        selectEditableBlock(dialog.image);
      }
      setDialog(null);
      return;
    }
    if (!next) { setDialog(null); return; }
    if (dialog.type === 'link') exec('createLink', next);
    if (dialog.type === 'image') exec('insertImage', next);
    setDialog(null);
  };

  const promptLink = () => openInlineDialog('link');
  const promptImage = () => {
    saveSelection();
    if (typeof onChooseImage === 'function') {
      onChooseImage(url => {
        const next = String(url || '').trim();
        if (!next) return;
        exec('insertImage', next);
      });
      return;
    }
    openInlineDialog('image');
  };
  const insertHr = () => exec('insertHorizontalRule');
  const setTheme = mode => {
    const next = mode === 'light' ? 'light' : 'dark';
    if (onTheme) { onTheme(next); return; }
    setOwnTheme(next);
    persistUserPreference('ve_content_editor_theme', next);
  };

  const tool = (label, cmd, arg, title, className) => h('button', {
    type: 'button',
    title: title || label,
    class: className || '',
    onMouseDown: e => { e.preventDefault(); saveSelection(); },
    onClick: () => exec(cmd, arg)
  }, label);
  const actionTool = (label, fn, title, className) => h('button', {
    type: 'button',
    title: title || label,
    'data-ve-tip': title || label,
    class: className || '',
    onMouseDown: e => { e.preventDefault(); saveSelection(); },
    onClick: fn
  }, label);
  const sep = key => h('span', { class: 've-rich-sep', key });
  const chooseAiAction = label => {
    setAiOpen(false);
    if (typeof onNotice === 'function') onNotice(label + ' is ready for an AI provider connection.');
  };
  const formatGroups = [
    { label: 'Text', items: [
      { value: 'p', label: 'Paragraph', icon: 'text-t' },
      { value: 'h1', label: 'Heading 1', icon: 'text-h-one' },
      { value: 'h2', label: 'Heading 2', icon: 'text-h-two' },
      { value: 'h3', label: 'Heading 3', icon: 'text-h-three' },
      { value: 'h4', label: 'Heading 4', icon: 'text-h-four' }
    ] },
    { label: 'Blocks', items: [
      { value: 'blockquote', label: 'Quote', icon: 'quotes' },
      { value: 'pre', label: 'Code', icon: 'code' }
    ] }
  ];
  const chooseFormat = item => {
    setFormatOpen(false);
    setActiveFormat(item.value);
    exec('formatBlock', item.value);
  };
  const applyHighlight = color => {
    const next = hexWithAlpha(clrToHex(color || highlightColor),highlightAlpha);
    setHighlightColor(next);
    exec('hiliteColor', next);
  };
  const applyHighlightAlpha = alpha => {
    const clean = normAlpha(alpha);
    const next = hexWithAlpha(clrToHex(highlightColor),clean);
    setHighlightAlpha(clean);
    setHighlightColor(next);
    exec('hiliteColor', next);
  };

  return h('div', { class: 've-rich-editor ve-rich-editor-' + editorTheme + (workspace ? ' ve-rich-editor-workspace' : '') },
    h('div', { class: 've-rich-toolbar' },
      h('div', { class: 've-rich-tool-group ve-rich-tool-group-left' },
        h('div',{class:'ve-rich-format-wrap',ref:formatWrapRef},
          h('button',{type:'button',class:'ve-rich-format-trigger','aria-expanded':formatOpen?'true':'false',onMouseDown:event=>{event.preventDefault();saveSelection();},onClick:()=>setFormatOpen(open=>!open)},({p:'Paragraph',h1:'Heading 1',h2:'Heading 2',h3:'Heading 3',h4:'Heading 4',h5:'Heading 5',h6:'Heading 6',blockquote:'Quote',pre:'Code'})[activeFormat]||'Paragraph',ph(formatOpen?'caret-up':'caret-down')),
          formatOpen&&h('div',{class:'ve-rich-popover ve-rich-format-menu'},formatGroups.map(group=>h('div',{class:'ve-rich-menu-group',key:group.label},h('span',{class:'ve-rich-menu-label'},group.label),group.items.map(item=>h('button',{type:'button',key:item.value,onClick:()=>chooseFormat(item)},ph(item.icon),item.label)))))
        ),
        sep('format-sep'),
        h('span',{class:'ve-rich-inline-tools'},
          tool('B', 'bold', null, 'Bold'),
          tool('I', 'italic', null, 'Italic'),
          tool('U', 'underline', null, 'Underline')
        ),
        h('div',{class:'ve-rich-highlight-wrap',ref:colorWrapRef},
          h('button',{type:'button',class:'ve-rich-highlight-trigger',title:'Highlight color','aria-expanded':highlightOpen?'true':'false',onMouseDown:event=>{event.preventDefault();saveSelection();},onClick:()=>setHighlightOpen(open=>!open)},h('span',{class:'ve-rich-color-swatch',style:'background:'+highlightColor})),
          highlightOpen&&h('div',{class:'ve-rich-popover ve-rich-highlight-menu'},h(MVInlineColorPicker,{hex:clrToHex(highlightColor),onChange:applyHighlight,alpha:highlightAlpha,onAlphaChange:applyHighlightAlpha,fmt:highlightFormat,setFmt:setHighlightFormat,variant:'compact',label:'Highlight color',boundVar:/^var\(/.test(String(highlightColor||''))?String(highlightColor):'',onBindVariable:token=>applyHighlight(token||'#baf400')}))
        )
      ),
      h('div', { class: 've-rich-tool-group ve-rich-tool-group-center' },
        actionTool(ph('text-align-left'), () => exec('justifyLeft'), 'Align left'),
        actionTool(ph('text-align-center'), () => exec('justifyCenter'), 'Align center'),
        actionTool(ph('list-bullets'), () => exec('insertUnorderedList'), 'Bullet list'),
        actionTool(ph('list-numbers'), () => exec('insertOrderedList'), 'Numbered list'),
        actionTool(ph('link'), promptLink, 'Add link')
      ),
      h('div', { class: 've-rich-tool-group ve-rich-tool-group-right' },
        actionTool(ph('image'), promptImage, 'Choose image from Media Studio'),
        h('div', { class: 've-rich-ai-wrap', ref: aiWrapRef },
          h('button', { type: 'button', class: 've-rich-ai', onMouseDown: e => e.preventDefault(), onClick: () => setAiOpen(value => !value) }, ph('sparkle'), 'Ask AI'),
          aiOpen && h('div', { class: 've-rich-ai-menu' },
            ['Rewrite', 'Check grammar', 'Continue writing', 'Make shorter', 'Add detail', 'Professional tone'].map(label => h('button', { type: 'button', key: label, onClick: () => chooseAiAction(label) }, label))
          )
        )
      )
    ),
    beforeSurface || null,
    h('div', {
      ref,
      class: 've-rich-surface ve-scroll-custom',
      contentEditable: !readOnly,
      spellCheck: true,
      role: 'textbox',
      'aria-label': 'Post content',
      'data-placeholder': 'Write content here...',
      onFocus: saveSelection,
      onKeyDown: handleSurfaceKeyDown,
      onKeyUp: saveSelection,
      onMouseUp: saveSelection,
      onClick: readOnly ? undefined : event => selectEditableBlock(event.target),
      onContextMenu: readOnly ? undefined : openBlockContextMenu,
      onInput: readOnly ? undefined : commit,
      onBlur: readOnly ? undefined : commit,
      onPaste: () => setTimeout(commit, 0)
    }),
    contextMenu && h('div', {
      ref: contextMenuRef,
      class: 've-context-menu ve-rich-context-menu',
      role: 'menu',
      style: 'left:' + contextMenu.left + 'px;top:' + contextMenu.top + 'px',
      onPointerDown: event => event.stopPropagation()
    },
      h('div',{class:'ve-rich-context-head'},h('span',null,contextMenu.label||'Selected block'),contextMenu.summary&&h('small',null,contextMenu.summary)),
      !contextMenu.insertOnly&&h('button', { type: 'button', onClick: () => runBlockContextAction('duplicate') }, ph('copy'), 'Duplicate block'),
      !contextMenu.insertOnly&&contextMenu.image&&h('button',{type:'button',onClick:replaceContextImage},ph('image-square'),'Replace image'),
      !contextMenu.insertOnly&&contextMenu.image&&h('button',{type:'button',onClick:editContextImageAlt},ph('text-aa'),'Edit alt text'),
      !contextMenu.insertOnly&&h('button', { type: 'button', class:contextMenu.insertOpen?'on':'', onClick: () => setContextMenu(current=>current?({...current,insertOpen:!current.insertOpen}):current) }, ph('plus'), h('span',null,'Insert'), ph(contextMenu.insertOpen?'caret-up':'caret-down')),
      contextMenu.insertOpen&&h('div',{class:'ve-rich-context-insert'},
        h('span',{class:'ve-menu-section-label'},contextMenu.insertOnly?'Add below':'Insert after'),
        [['paragraph','paragraph','Paragraph'],['heading','text-h-two','Heading'],['quote','quotes','Quote'],['code','code','Code'],['bullets','list-bullets','Bulleted list'],['numbers','list-numbers','Numbered list'],['image','image','Image'],['divider','minus','Divider']].map(item=>h('button',{type:'button',key:item[0],onClick:()=>runBlockContextAction('insert',item[0])},ph(item[1]),item[2]))
      ),
      !contextMenu.insertOnly&&h('button', { type: 'button', disabled: !contextMenu.block?.previousElementSibling, onClick: () => runBlockContextAction('up') }, ph('arrow-up'), 'Move up'),
      !contextMenu.insertOnly&&h('button', { type: 'button', disabled: !contextMenu.block?.nextElementSibling, onClick: () => runBlockContextAction('down') }, ph('arrow-down'), 'Move down'),
      !contextMenu.insertOnly&&h('button', { type: 'button', class: 'danger', onClick: () => runBlockContextAction('delete') }, ph('trash'), 'Delete block')
    ),
    dialog && h('div', { class: 've-rich-inline-dialog', onMouseDown: e => e.stopPropagation() },
      h('div', { class: 've-rich-inline-dialog-card' },
        h('strong', null, dialog.type === 'alt' ? 'Edit image alt text' : dialog.type === 'image' ? 'Insert image by URL' : 'Add link'),
        h('input', { class: 've-studio-input', autoFocus: true, placeholder: dialog.type === 'alt' ? 'Describe this image' : dialog.type === 'image' ? 'https://image-url...' : 'https://link-url...', value: dialog.value || '', onInput: e => setDialog(d => ({ ...(d || {}), value: e.target.value })), onKeyDown: e => { if (e.key === 'Enter') { e.preventDefault(); applyInlineDialog(); } if (e.key === 'Escape') setDialog(null); } }),
        h('div', { class: 've-rich-inline-dialog-actions' },
          h('button', { type: 'button', class: 've-btn ve-btn-primary', onClick: applyInlineDialog }, 'Apply'),
          h('button', { type: 'button', class: 've-btn ve-btn-g', onClick: () => setDialog(null) }, 'Cancel')
        )
      )
    )
  );
}

function ContentMediaPicker({ title, onSelect, onClose, flash }) {
  const insertMedia = item => {
    const sizes = item?.media_details?.sizes || {};
    const url = item?.source_url || item?.url || item?.guid?.rendered ||
      sizes.medium_large?.source_url || sizes.medium?.source_url || sizes.thumbnail?.source_url || '';
    if (!url || typeof onSelect !== 'function') return false;
    onSelect(url, item);
    return true;
  };

  return h('div', { class: 've-content-media-picker', onMouseDown: e => e.stopPropagation(), onClick: e => e.stopPropagation() },
    h('div', { class: 've-content-media-picker-card ve-content-media-picker-card-studio ve-content-media-picker-shared' },
      h('div', { class: 've-content-media-picker-head' },
        h('div', null, h('strong', null, title || 'Choose image'), h('span', null, 'Media Studio')),
        h('button', { type: 'button', class: 've-a', onClick: onClose, title: 'Close picker' }, ph('x'))
      ),
      h('div', { class: 've-content-media-picker-native' },
        h(LazyStudio,{name:'MediaStudioSub',
          onClose,
          flash: typeof flash === 'function' ? flash : () => {},
          picking: true,
          onInsertMedia: insertMedia,
          initialFilter: 'image'
        })
      )
    )
  );
}

function parseContentImportText(source, fileName) {
  let text=String(source||'').replace(/^\uFEFF/,'');
  if(!text.trim())throw new Error('The selected file is empty.');
  const firstLine=(text.split(/\r?\n/,1)[0]||'');
  const countOutsideQuotes=char=>{let count=0,quoted=false;for(let i=0;i<firstLine.length;i++){if(firstLine[i]==='"'){if(quoted&&firstLine[i+1]==='"'){i++;continue;}quoted=!quoted;}else if(!quoted&&firstLine[i]===char)count++;}return count;};
  const delimiter=countOutsideQuotes('\t')>countOutsideQuotes(',')?'\t':',';
  const matrix=[];let row=[],cell='',quoted=false;
  for(let i=0;i<text.length;i++){
    const char=text[i];
    if(char==='"'){
      if(quoted&&text[i+1]==='"'){cell+='"';i++;}else quoted=!quoted;
      continue;
    }
    if(!quoted&&char===delimiter){row.push(cell);cell='';continue;}
    if(!quoted&&(char==='\n'||char==='\r')){
      if(char==='\r'&&text[i+1]==='\n')i++;
      row.push(cell);cell='';matrix.push(row);row=[];continue;
    }
    cell+=char;
  }
  row.push(cell);matrix.push(row);
  const nonEmpty=matrix.filter(values=>values.some(value=>String(value||'').trim()!==''));
  if(nonEmpty.length<2)throw new Error('The file needs a header row and at least one content row.');
  if(nonEmpty[0].length>100)throw new Error('Content imports support up to 100 columns.');
  if(nonEmpty.length-1>5000)throw new Error('Content imports support up to 5,000 rows per file.');
  const used={};
  const headers=nonEmpty[0].map((value,index)=>{
    const base=String(value||'').trim()||('Column '+(index+1));
    used[base]=(used[base]||0)+1;
    return used[base]===1?base:(base+' ('+used[base]+')');
  });
  const rows=nonEmpty.slice(1).map(values=>{
    const item={};headers.forEach((header,index)=>{item[header]=String(values[index]??'');});return item;
  });
  return {name:String(fileName||'content-import.'+(delimiter==='\t'?'tsv':'csv')),headers,rows,delimiter:delimiter==='\t'?'TSV':'CSV'};
}

function defaultContentImportMapping(headers){
  const aliases={
    title:['title','post_title','name','headline'],content:['content','post_content','body','body_html','html'],excerpt:['excerpt','post_excerpt','summary','description'],
    slug:['slug','post_name','permalink'],status:['status','post_status'],date:['date','post_date','published_at','publish_date'],author:['author','post_author','author_email'],
    categories:['categories','category','topics'],tags:['tags','post_tags'],featured_image_url:['featured_image','featured_image_url','hero_image','image','image_url','thumbnail']
  };
  const mapping={};
  (headers||[]).forEach(header=>{
    const normalized=String(header||'').toLowerCase().trim().replace(/[^a-z0-9]+/g,'_').replace(/^_|_$/g,'');
    let match='ignore';
    Object.keys(aliases).some(field=>{if(aliases[field].includes(normalized)){match=field;return true;}return false;});
    mapping[header]=match;
  });
  return mapping;
}

/* ── Content Studio sub-panel ────────────────── */
function contentTitleSlug(value) {
  return String(value || '')
    .normalize('NFKD')
    .replace(/[\u0300-\u036f]/g, '')
    .toLowerCase()
    .trim()
    .replace(/['’]/g, '')
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/^-+|-+$/g, '');
}

/* ContentStudioSub -> assets/js/studios.js (v1.3.519) */

/* ── Media Studio sub-panel ──────────────────── */
const COLL_ICONS = ['folder','folders','images','image','file','file-image','file-video','file-audio','file-text','file-pdf','text-aa','star','heart','bookmark','tag','bookmarks','flag','lightning','globe','camera','music-notes','video','paint-brush','palette','code','brackets-curly','book','books','trophy','gift','diamond','rocket','puzzle-piece','shield-check','house','buildings','tree','sun','moon','fire','drop','leaf','smiley','archive','box-arrow-down','calendar','users','user','briefcase','browser','app-window','database','cloud','download','upload','link','paperclip','paint-bucket','swatches','sparkle','magic-wand','target','tray','stack','squares-four','grid-four'];
const VE_MEDIA_COLLAPSED_PATHS_KEY = 've_media_collapsed_paths';
function loadMediaCollapsedPaths(){
  try {
    const parsed = JSON.parse(localStorage.getItem(VE_MEDIA_COLLAPSED_PATHS_KEY) || '{}');
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch(e) {
    return {};
  }
}
function persistMediaCollapsedPaths(next){
  try { localStorage.setItem(VE_MEDIA_COLLAPSED_PATHS_KEY, JSON.stringify(next || {})); } catch(e) {}
}
function collectFolderDescendantIds(folders, folderId){
  const ids = new Set([String(folderId)]);
  let changed = true;
  let guard = 0;
  while (changed && guard < 1000) {
    changed = false;
    guard++;
    (folders || []).forEach(folder => {
      const id = String(folder.id);
      const parent = String(folder.parent || '0');
      if (!ids.has(id) && ids.has(parent)) {
        ids.add(id);
        changed = true;
      }
    });
  }
  return Array.from(ids);
}
function collectFolderMediaIds(folderData, folderId){
  const wantedFolders = new Set(collectFolderDescendantIds(folderData?.folders || [], folderId));
  const map = folderData?.map || {};
  return Object.keys(map)
    .filter(id => (map[id] || []).map(String).some(fid => wantedFolders.has(fid)))
    .map(id => parseInt(id, 10));
}
function MediaVideoThumbnail({src,label,onDimensions}){
  const wrapRef=useRef(null);
  const videoRef=useRef(null);
  const[visible,setVisible]=useState(false);
  const[ready,setReady]=useState(false);
  const[failed,setFailed]=useState(false);
  useEffect(()=>{
    const node=wrapRef.current;
    if(!node)return;
    if(typeof IntersectionObserver==='undefined'){setVisible(true);return;}
    const observer=new IntersectionObserver(entries=>{
      if(entries.some(entry=>entry.isIntersecting)){
        setVisible(true);
        observer.disconnect();
      }
    },{rootMargin:'220px'});
    observer.observe(node);
    return()=>observer.disconnect();
  },[]);
  useEffect(()=>{setReady(false);setFailed(false);},[src]);
  const captureFrame=event=>{
    const video=event.currentTarget;
    const width=Number(video.videoWidth||0);
    const height=Number(video.videoHeight||0);
    const card=wrapRef.current?.closest?.('.ve-media-thumb');
    if(card&&width>0&&height>0)card.style.setProperty('--ve-media-aspect',width+' / '+height);
    if(width>0&&height>0&&typeof onDimensions==='function')onDimensions(width,height);
    const duration=Number(video.duration||0);
    try{video.currentTime=duration>1?Math.min(1,duration*.08):0.01;}catch(e){setReady(true);}
  };
  return h('div',{ref:wrapRef,class:'ve-video-thumb'+(ready?' ready':'')+(failed?' failed':'')},
    visible&&!failed&&h('video',{ref:videoRef,src,muted:true,playsInline:true,preload:'metadata','aria-label':label||'Video thumbnail',onLoadedMetadata:captureFrame,onLoadedData:()=>setReady(true),onSeeked:()=>setReady(true),onError:()=>setFailed(true)}),
    h('span',{class:'ve-video-thumb-fallback'},failed?'Preview unavailable':'Loading video frame…'),
    !failed&&h('span',{class:'ve-video-thumb-play','aria-hidden':'true'},'▶')
  );
}
function MediaVideoPlayer({src,label}){
  const videoRef=useRef(null);
  const[playing,setPlaying]=useState(false);
  const[muted,setMuted]=useState(true);
  const[volume,setVolume]=useState(.75);
  const[failed,setFailed]=useState(false);
  const[dimensions,setDimensions]=useState({width:0,height:0});
  const[duration,setDuration]=useState(0);
  const[currentTime,setCurrentTime]=useState(0);
  useEffect(()=>{
    setPlaying(false);
    setFailed(false);
    setDimensions({width:0,height:0});
    setDuration(0);
    setCurrentTime(0);
    const video=videoRef.current;
    if(video){video.pause();video.currentTime=0;video.muted=true;video.volume=.75;}
  },[src]);
  const togglePlay=()=>{
    const video=videoRef.current;
    if(!video)return;
    if(video.paused){
      const promise=video.play();
      if(promise?.catch)promise.catch(()=>setFailed(true));
    }else video.pause();
  };
  const toggleSound=()=>{
    const video=videoRef.current;
    if(!video)return;
    const next=!muted;
    video.muted=next;
    setMuted(next);
  };
  const changeVolume=event=>{
    const next=Math.max(0,Math.min(1,Number(event.currentTarget.value||0)));
    const video=videoRef.current;
    if(video){video.volume=next;if(next>0&&video.muted){video.muted=false;setMuted(false);}}
    setVolume(next);
  };
  const changeTime=event=>{
    const next=Math.max(0,Math.min(duration||0,Number(event.currentTarget.value||0)));
    const video=videoRef.current;
    if(video)video.currentTime=next;
    setCurrentTime(next);
  };
  const stop=event=>event.stopPropagation();
  const portrait=dimensions.height>dimensions.width&&dimensions.width>0;
  const aspect=dimensions.width&&dimensions.height?dimensions.width+'/'+dimensions.height:'16/9';
  return h('div',{class:'ve-video-player'+(portrait?' is-portrait':'')+(failed?' is-failed':''),style:'--ve-video-aspect:'+aspect,onMouseDown:stop,onClick:stop},
    h('div',{class:'ve-video-player-stage'},
      failed
        ?h('div',{class:'ve-video-player-error'},'This video could not be previewed in your browser.')
        :h('video',{ref:videoRef,src,muted,volume,playsInline:true,preload:'metadata','aria-label':label||'Video preview',onLoadedMetadata:event=>{setDimensions({width:event.currentTarget.videoWidth||0,height:event.currentTarget.videoHeight||0});setDuration(Number(event.currentTarget.duration||0));},onDurationChange:event=>setDuration(Number(event.currentTarget.duration||0)),onTimeUpdate:event=>setCurrentTime(Number(event.currentTarget.currentTime||0)),onPlay:()=>setPlaying(true),onPause:()=>setPlaying(false),onEnded:()=>{setPlaying(false);setCurrentTime(Number(videoRef.current?.duration||0));},onError:()=>setFailed(true),onClick:togglePlay}),
      !failed&&!playing&&h('button',{type:'button',class:'ve-video-player-overlay',onClick:togglePlay,'aria-label':'Play video',title:'Play'},h('i',{class:'ph-duotone ph-play','aria-hidden':'true'}))
    ),
    !failed&&duration>0&&h('label',{class:'ve-video-player-seek'},h('input',{type:'range',min:'0',max:String(duration),step:'0.01',value:Math.min(currentTime,duration),onInput:changeTime,'aria-label':'Seek video'})),
    !failed&&h('div',{class:'ve-video-player-controls'},
      h('button',{type:'button',onClick:togglePlay,'aria-label':playing?'Pause video':'Play video',title:playing?'Pause':'Play'},h('i',{class:'ph-duotone '+(playing?'ph-pause':'ph-play'),'aria-hidden':'true'})),
      h('button',{type:'button',onClick:toggleSound,'aria-label':muted?'Turn sound on':'Turn sound off',title:muted?'Turn sound on':'Turn sound off'},h('i',{class:'ph-duotone '+(muted?'ph-speaker-slash':'ph-speaker-high'),'aria-hidden':'true'})),
      h('label',null,h('span',null,'Volume'),h('input',{type:'range',min:'0',max:'1',step:'0.05',value:volume,onInput:changeVolume,'aria-label':'Video volume'}))
    )
  );
}
/* MediaStudioSub -> assets/js/studios.js (v1.3.519) */

/* ── Plugin Studio sub-panel ─────────────────── */
/* FontManagerStudio -> assets/js/studios.js (v1.3.519) */

// #29 Bricks Theme Styles — a complete editor for Bricks' native theme styles.
// The spec below is generated from Bricks' own includes/theme-styles/controls/*.php,
// so group ids, control keys, types, labels, placeholders, option tokens, `exclude`
// lists and `required` gating are Bricks', not MV inventions.
const BRICKS_TS_OPTIONS={"fontWeight": [["100", "100"], ["200", "200"], ["300", "300"], ["400", "400"], ["500", "500"], ["600", "600"], ["700", "700"], ["800", "800"], ["900", "900"]], "fontStyle": [["normal", "Normal"], ["italic", "Italic"], ["oblique", "Oblique"]], "borderStyle": [["none", "None"], ["hidden", "Hidden"], ["solid", "Solid"], ["dotted", "Dotted"], ["dashed", "Dashed"], ["double", "Double"], ["groove", "Groove"], ["ridge", "Ridge"], ["inset", "Inset"], ["outset", "Outset"]], "textWrap": [["wrap", "wrap"], ["nowrap", "nowrap"], ["balance", "balance"], ["pretty", "pretty"], ["stable", "stable"]], "whiteSpace": [["normal", "normal"], ["nowrap", "nowrap"], ["pre", "pre"], ["pre-wrap", "pre-wrap"], ["pre-line", "pre-line"], ["break-spaces", "break-spaces"]]};
const BRICKS_TS_GROUPS=[
  {id:"conditions",label:"Conditions",kind:"conditions"},
  {id:"css",label:"Stylesheet",kind:"css"},
  {id:"general",label:"General",fields:[
    {"k": "siteLayout", "t": "select", "l": "Site layout", "p": "Wide", "o": [["boxed", "Boxed"], ["wide", "Wide"]]},
    {"k": "siteLayoutBoxedMaxWidth", "t": "number", "l": "Boxed max. width", "u": 1, "req": ["siteLayout", "=", "boxed"]},
    {"k": "contentBoxShadow", "t": "box-shadow", "l": "Content box shadow", "req": ["siteLayout", "=", "boxed"]},
    {"k": "contentBackground", "t": "background", "l": "Content background", "req": ["siteLayout", "=", "boxed"], "x": "video"},
    {"k": "siteBackground", "t": "background", "l": "Site background", "x": "video"},
    {"k": "siteBorder", "t": "border", "l": "Site border", "req": ["siteLayout", "=", "boxed"]},
    {"k": "elementMargin", "t": "spacing", "l": "Element margin"},
    {"k": "containerSeparator", "t": "separator", "l": "Container"},
    {"k": "sectionMargin", "t": "spacing", "l": "Root container margin"},
    {"k": "sectionPadding", "t": "spacing", "l": "Root container padding"},
    {"k": "containerMaxWidth", "t": "number", "l": "Root container width", "p": "1100px", "u": 1},
    {"k": "lightboxSeparator", "t": "separator", "l": "Lightbox", "d": "Set only width generates 16:9 ratio videos."},
    {"k": "lightboxBackground", "t": "background", "l": "Background", "x": "video"},
    {"k": "lightboxCloseColor", "t": "color", "l": "Close color"},
    {"k": "lightboxCloseSize", "t": "number", "l": "Close size", "u": 1},
    {"k": "lightboxWidth", "t": "number", "l": "Width (Video)", "p": "1280"},
    {"k": "lightboxHeight", "t": "number", "l": "Height (Video)", "p": "720"},
  ]},
  {id:"colors",label:"Colors",fields:[
    {"k": "colorsInfo", "t": "info", "d": "Applicable to heading or button \"Style\" setting only. Create & use global colors through your own custom \"Color palette\"."},
    {"k": "colorPrimary", "t": "color", "l": "Primary color"},
    {"k": "colorSecondary", "t": "color", "l": "Secondary color"},
    {"k": "colorLight", "t": "color", "l": "Light color"},
    {"k": "colorDark", "t": "color", "l": "Dark color"},
    {"k": "colorMuted", "t": "color", "l": "Muted color"},
    {"k": "colorBorder", "t": "color", "l": "Border color"},
    {"k": "colorInfo", "t": "color", "l": "Info color"},
    {"k": "colorSuccess", "t": "color", "l": "Success color"},
    {"k": "colorWarning", "t": "color", "l": "Warning color"},
    {"k": "colorDanger", "t": "color", "l": "Danger color"},
  ]},
  {id:"links",label:"Links",fields:[
    {"k": "cssSelectorInfo", "t": "info", "d": "Link styles apply only to specific elements. Overwrite them via the [[bricks/link_css_selectors|https://academy.bricksbuilder.io/article/filter-bricks-link_css_selectors]] filter or extend them via the CSS selectors setting below."},
    {"k": "cssSelectors", "t": "textarea", "l": "Link: CSS selectors", "p": ":where(.brxe-accordion .accordion-content-wrapper) a, :where(.brxe-icon-box .content) a, :where(.brxe-list) a, :where(.brxe-post-content):not([data-source=\"bricks\"]) a, :where(.brxe-posts .dynamic p) a, :where(.brxe-shortcode) a, :where(.brxe-tabs .tab-content) a, :where(.brxe-team-members) .description a, :where(.brxe-testimonials) .testimonial-content-wrapper a, :where(.brxe-text) a, :where(a.brxe-text), :where(.brxe-text-basic) a, :where(a.brxe-text-basic), :where(.brxe-post-comments) .comment-content a"},
    {"k": "cssSelectorsApply", "t": "apply", "l": "Apply (CSS selectors)"},
    {"k": "typography", "t": "typography", "l": "Typography", "x": "text-alignline-height"},
    {"k": "background", "t": "background", "l": "Background", "x": "video"},
    {"k": "border", "t": "border", "l": "Border"},
    {"k": "padding", "t": "spacing", "l": "Padding"},
    {"k": "textDecoration", "t": "text-decoration", "l": "Text decoration"},
    {"k": "transition", "t": "text", "l": "Transition", "d": "[[Learn more about CSS transitions|https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Transitions/Using_CSS_transitions]]"},
  ]},
  {id:"contextualSpacing",label:"Contextual spacing",fields:[
    {"k": "contextualSpacingRemoveDefaultMargins", "t": "select", "l": "Remove default margins", "d": "Select the elements for which you want to remove the default margins.", "p": "Select HTML tags", "m": 1, "add": 1, "s": "Custom tag", "o": [["h1,h2,h3,h4,h5,h6", "Headings (h1 - h6)"], ["p", "Paragraph (p)"], ["ul", "Unordered list (ul)"], ["ol", "Ordered list (ol)"], ["li", "List item (li)"], ["figure", "Figure (figure)"], ["blockquote", "Blockquote (blockquote)"]]},
    {"k": "contextualSpacingSep", "t": "separator", "l": "Contextual spacing", "d": "Contextual spacing applies a top margin to elements with a preceding sibling within embedded content. [[Learn more|https://academy.bricksbuilder.io/article/contextual-spacing]]"},
    {"k": "contextualSpacingHeading", "t": "number", "l": "Heading", "i": "margin-block-start", "u": 1},
    {"k": "contextualSpacingParagraph", "t": "number", "l": "Paragraph", "i": "margin-block-start", "u": 1},
    {"k": "contextualSpacingFallback", "t": "number", "l": "Fallback spacing", "d": "Fallback applies to elements in embedded content without a specific spacing rule.", "i": "margin-block-start", "u": 1},
    {"k": "contextualSpacingCustomSeparator", "t": "separator", "l": "Additional target elements", "d": "Extend contextual spacing to other elements within embedded content."},
    {"k": "contextualSpacingCustomTarget", "t": "repeater", "p": "Target", "f": [{"k": "selector", "t": "select", "l": "Selector", "p": "HTML tag", "add": 1, "s": "Custom tag / Selector", "o": [["ul", "Unordered list (ul)"], ["ol", "Ordered list (ol)"], ["li", "List item (li)"], ["figure", "Figure (figure)"], ["blockquote", "Blockquote (blockquote)"]]}, {"k": "marginStart", "t": "text", "l": "Margin: Top", "i": "margin-block-start", "req": {"0": "selector", "!=": ""}}, {"k": "marginEnd", "t": "text", "l": "Margin: Bottom", "i": "margin-block-end", "req": {"0": "selector", "!=": ""}}, {"k": "paddingStart", "t": "text", "l": "Padding: Start", "i": "padding-inline-start", "req": {"0": "selector", "!=": ""}}, {"k": "paddingEnd", "t": "text", "l": "Padding: End", "i": "padding-inline-end", "req": {"0": "selector", "!=": ""}}], "tp": "selector"},
    {"k": "contextualSpacingApplyToSep", "t": "separator", "l": "Apply spacing inside"},
    {"k": "contextualSpacingApplyTo", "t": "text", "d": "Contextual spacing targets embedded content (Rich Text, Post Content, WooCommerce). Use this field to apply contextual spacing to additional selectors, separated by commas.", "p": ".contextual-spacing, .brxe-shortcode"},
  ]},
  {id:"content",label:"Content (Margin)",fields:[
    {"k": "contentMargin", "t": "spacing", "l": "Margin", "d": "Space between header and footer."},
    {"k": "contentBlockquoteSeparator", "t": "separator", "l": "Blockquote"},
    {"k": "contentBlockquoteMargin", "t": "spacing", "l": "Margin"},
    {"k": "contentBlockquotePadding", "t": "spacing", "l": "Padding"},
    {"k": "contentBlockquoteBorder", "t": "border", "l": "Border"},
    {"k": "contentBlockquoteTypography", "t": "typography", "l": "Typography"},
  ]},
  {id:"typography",label:"Typography",fields:[
    {"k": "typographyFluidPopup", "t": "popup", "l": "Fluid typography"},
    {"k": "typographyHtml", "t": "number", "l": "HTML: font-size", "p": "62.5%", "i": "62.5% html font-size: 1rem = 10px\n100% html font-size: 1rem = 16px", "u": 1},
    {"k": "typographyBody", "t": "typography", "l": "Body"},
    {"k": "typographyHeadings", "t": "typography", "l": "All headings"},
    {"k": "headingH1Separator", "t": "separator", "l": "Heading H1"},
    {"k": "typographyHeadingH1", "t": "typography", "l": "Typography"},
    {"k": "h1Margin", "t": "spacing", "l": "Margin"},
    {"k": "headingH2Separator", "t": "separator", "l": "Heading H2"},
    {"k": "typographyHeadingH2", "t": "typography", "l": "Typography"},
    {"k": "h2Margin", "t": "spacing", "l": "Margin"},
    {"k": "headingH3Separator", "t": "separator", "l": "Heading H3"},
    {"k": "typographyHeadingH3", "t": "typography", "l": "Typography"},
    {"k": "h3Margin", "t": "spacing", "l": "Margin"},
    {"k": "headingH4Separator", "t": "separator", "l": "Heading H4"},
    {"k": "typographyHeadingH4", "t": "typography", "l": "Typography"},
    {"k": "h4Margin", "t": "spacing", "l": "Margin"},
    {"k": "headingH5Separator", "t": "separator", "l": "Heading H5"},
    {"k": "typographyHeadingH5", "t": "typography", "l": "Typography"},
    {"k": "h5Margin", "t": "spacing", "l": "Margin"},
    {"k": "headingH6Separator", "t": "separator", "l": "Heading H6"},
    {"k": "typographyHeadingH6", "t": "typography", "l": "Typography"},
    {"k": "h6Margin", "t": "spacing", "l": "Margin"},
    {"k": "miscSeparator", "t": "separator", "l": "Miscellaneous"},
    {"k": "typographyHero", "t": "typography", "l": "Hero"},
    {"k": "typographyLead", "t": "typography", "l": "Lead"},
    {"k": "focusOutline", "t": "text", "l": "Focus outline", "p": "auto", "i": ":focus-visible"},
    {"k": "blockquoteSeparator", "t": "separator", "l": "Blockquote"},
    {"k": "blockquoteMargin", "t": "spacing", "l": "Blockquote margin"},
    {"k": "blockquotePadding", "t": "spacing", "l": "Blockquote padding"},
    {"k": "blockquoteBorder", "t": "border", "l": "Blockquote border"},
    {"k": "blockquoteTypography", "t": "typography", "l": "Blockquote typography"},
  ]},
  {id:"popup",label:"Popup",fields:[
    {"k": "popupPadding", "t": "spacing", "l": "Padding", "req": ["popupIsInfoBox", "!=", true]},
    {"k": "popupJustifyConent", "t": "justify-content", "l": "Align main axis", "req": ["popupIsInfoBox", "!=", true], "x": "space"},
    {"k": "popupAlignItems", "t": "align-items", "l": "Align cross axis", "req": ["popupIsInfoBox", "!=", true], "x": "stretch"},
    {"k": "popupZindex", "t": "number", "l": "Z-index", "p": "10000", "req": ["popupIsInfoBox", "!=", true]},
    {"k": "popupAjaxLoaderSep", "t": "separator", "l": "AJAX loader", "d": "Shows when popup content is fetched via AJAX.", "req": ["popupAjax", "=", true]},
    {"k": "popupBreakpointSep", "t": "separator", "l": "Breakpoints", "d": "Choose at which breakpoint do you want to start showing this popup or on which specific breakpoints.", "req": ["popupIsInfoBox", "!=", true]},
    {"k": "popupBreakpointMode", "t": "select", "p": "Start display at breakpoint", "req": ["popupIsInfoBox", "!=", true], "o": [["at", "Start display at breakpoint"], ["on", "Display on breakpoints"]]},
    {"k": "popupShowAt", "t": "select", "p": "Any breakpoint", "req": [["popupBreakpointMode", "!=", "on"], ["popupIsInfoBox", "!=", true]]},
    {"k": "popupShowOn", "t": "select", "p": "Any breakpoint", "m": 1, "req": [["popupBreakpointMode", "=", "on"], ["popupIsInfoBox", "!=", true]]},
    {"k": "popupBackdropSep", "t": "separator", "l": "Backdrop", "req": ["popupIsInfoBox", "!=", true]},
    {"k": "popupDisableBackdrop", "t": "checkbox", "l": "Disable backdrop", "req": ["popupIsInfoBox", "!=", true]},
    {"k": "popupBackground", "t": "background", "l": "Background", "req": [["popupDisableBackdrop", "!=", true], ["popupIsInfoBox", "!=", true]], "x": "video"},
    {"k": "popupBackdropTransition", "t": "text", "l": "Transition", "req": [["popupDisableBackdrop", "!=", true], ["popupIsInfoBox", "!=", true]]},
    {"k": "popupContentSep", "t": "separator", "l": "Content"},
    {"k": "popupContentPadding", "t": "spacing", "l": "Padding"},
    {"k": "popupContentWidth", "t": "number", "l": "Width", "u": 1},
    {"k": "popupContentMinWidth", "t": "number", "l": "Min. width", "u": 1},
    {"k": "popupContentMaxWidth", "t": "number", "l": "Max. width", "u": 1},
    {"k": "popupContentHeight", "t": "number", "l": "Height", "u": 1},
    {"k": "popupContentMinHeight", "t": "number", "l": "Min. height", "u": 1},
    {"k": "popupContentMaxHeight", "t": "number", "l": "Max. height", "u": 1},
    {"k": "popupContentBackground", "t": "background", "l": "Background"},
    {"k": "popupContentBorder", "t": "border", "l": "Border"},
    {"k": "popupContentBoxShadow", "t": "box-shadow", "l": "Box shadow"},
  ]},
  {id:"elements",label:"Elements",kind:"paused"},
];

// #29 Bricks Theme Styles — a full editor for Bricks' native bricks_theme_styles.
//
// Every value here is stored the way Bricks stores it, because Bricks is the only
// reader: Theme_Styles::get_setting_by_key() looks up settings[group][key], and
// Assets::generate_inline_css_theme_style() interprets each control type's shape.
// So the controls below read and write Bricks' shapes exactly:
//   color        {id?, raw?, rgb?, hex?}   — resolved in that precedence order
//   background   {color:{…}}
//   spacing      {top,right,bottom,left, unit:{top,…}}
//   border       {width:{top,…,unit:{…}}, style, color:{…}}
//   box-shadow   {values:{offsetX,offsetY,blur,spread}, color:{…}, inset?}
//   typography   {color:{…}, 'font-family', 'font-size', …, 'text-shadow':{values,color}}
// Unrecognised keys inside a value are preserved untouched, so nothing Bricks
// (or a future Bricks release) writes is destroyed by a round-trip through MV.

const BRICKS_TS_SIDES=[['top','TOP'],['right','RIGHT'],['bottom','BOTTOM'],['left','LEFT']];
const BRICKS_TS_UNITS=['px','em','rem','%','vw','vh',''];
const BRICKS_TS_ALIGN=[['left','align-left'],['center','align-center-horizontal'],['right','align-right'],['justify','text-align-justify']];
const BRICKS_TS_TRANSFORM=[['capitalize','Aa'],['uppercase','AA'],['lowercase','aa'],['none','—']];
const BRICKS_TS_DECORATION=[['line-through','text-strikethrough'],['underline','text-underline'],['overline','text-t'],['none','x']];
const BRICKS_TS_JUSTIFY=[['flex-start','align-top'],['center','align-center-vertical'],['flex-end','align-bottom'],['space-between','arrows-out-line-vertical'],['space-around','dots-three-vertical'],['space-evenly','equals']];
const BRICKS_TS_ITEMS=[['flex-start','align-left'],['center','align-center-horizontal'],['flex-end','align-right'],['stretch','arrows-out-line-horizontal'],['baseline','text-aa'],['auto','dot']];
// Bricks' typography popup, in Bricks' order. Keys are literal CSS properties
// because that is what Assets.php emits them as.
const BRICKS_TS_TYPO=[
  {k:'color',t:'color',l:'Color'},
  {k:'font-family',t:'font',l:'Font family'},
  {k:'font-weight',t:'opt',l:'Font weight',o:'fontWeight'},
  {k:'font-style',t:'opt',l:'Font style',o:'fontStyle'},
  {k:'font-size',t:'unit',l:'Font size'},
  {k:'line-height',t:'unit',l:'Line height'},
  {k:'letter-spacing',t:'unit',l:'Letter spacing'},
  {k:'text-align',t:'seg',l:'Text align',o:BRICKS_TS_ALIGN},
  {k:'text-transform',t:'seg',l:'Text transform',o:BRICKS_TS_TRANSFORM},
  {k:'text-decoration',t:'seg',l:'Text decoration',o:BRICKS_TS_DECORATION},
  {k:'white-space',t:'opt',l:'White space',o:'whiteSpace'},
  {k:'text-wrap',t:'opt',l:'Text wrap',o:'textWrap'},
  {k:'font-variation-settings',t:'text',l:'Font variation settings'},
  {k:'fallback',t:'text',l:'Fallback fonts'},
  {k:'text-shadow',t:'shadow3',l:'Text shadow'}
];

function tsIsEmpty(value){
  if(value==null||value==='')return true;
  if(Array.isArray(value))return value.length===0;
  if(typeof value==='object')return Object.keys(value).every(k=>tsIsEmpty(value[k]));
  return false;
}
function tsPrune(obj){
  const out={};
  Object.keys(obj||{}).forEach(k=>{ if(!tsIsEmpty(obj[k]))out[k]=obj[k]; });
  return Object.keys(out).length?out:'';
}
// Bricks resolves a colour as id → raw → rgb → hex, so read it back in that order
// or the field would show a hex that the page never actually renders.
function tsColorText(value){
  if(value==null||value==='')return '';
  if(typeof value==='string')return value;
  if(typeof value!=='object')return '';
  return value.raw||value.rgb||value.hex||'';
}
function tsColorWrite(previous,text){
  const prev=(previous&&typeof previous==='object')?previous:{};
  const out={...prev};
  delete out.raw;delete out.rgb;delete out.hex;
  const value=String(text||'').trim();
  if(!value)return Object.keys(out).length?out:'';
  // rgb()/hsl() are tested first: they are also function calls, and Bricks' own
  // picker stores them in `rgb`, so matching the generic function test first
  // would file every rgba() under `raw`.
  if(/^(rgba?|hsla?)\(/i.test(value))out.rgb=value;
  else if(/^var\(|^--|^calc\(|^[a-z-]+\(/i.test(value))out.raw=value;
  else out.hex=value;
  return out;
}
// Renders "text [[label|url]] text" — Bricks' own help copy carries the academy
// deep link for that exact setting, so it is kept rather than re-worded.
function tsDesc(text){
  if(!text)return null;
  const parts=String(text).split(/\[\[([^|\]]+)\|([^\]]+)\]\]/);
  const nodes=[];
  for(let i=0;i<parts.length;i+=3){
    if(parts[i])nodes.push(parts[i]);
    if(parts[i+1])nodes.push(h('a',{class:'ve-ts-lm',href:parts[i+2],target:'_blank',rel:'noopener'},parts[i+1]));
  }
  return nodes;
}
function tsMeetsRequired(req,values){
  if(!req)return true;
  const list=Array.isArray(req[0])?req:[req];
  return list.every(rule=>{
    if(!Array.isArray(rule))return true;
    const current=values?.[rule[0]];
    const op=rule.length>2?rule[1]:'!=';
    const want=rule.length>2?rule[2]:'';
    const text=current==null?'':String(current);
    if(op==='=')return text===String(want);
    if(op==='!=')return text!==String(want);
    if(op==='includes')return Array.isArray(current)&&current.includes(want);
    return true;
  });
}

function TsSwatch({value,onPick,onClear,onBind,vars}){
  const[open,setOpen]=useState(false);
  const[swatchFmt,setSwatchFmt]=useState('oklch');
  const wrapRef=useRef();
  const text=tsColorText(value);
  const literal=/^#|^rgb|^hsl/i.test(text.trim());
  const hex=literal?text.trim():'';
  const alphaNow=literal?clrAlpha(hex):1;
  // Clicking anywhere outside closes it, and so does Escape. Without this the
  // only way out was the Done button.
  useEffect(()=>{
    if(!open)return undefined;
    const away=event=>{ if(wrapRef.current&&!wrapRef.current.contains(event.target))setOpen(false); };
    const key=event=>{ if(event.key==='Escape')setOpen(false); };
    document.addEventListener('pointerdown',away,true);
    document.addEventListener('keydown',key,true);
    return ()=>{ document.removeEventListener('pointerdown',away,true); document.removeEventListener('keydown',key,true); };
  },[open]);
  const cpRef=useRef();
  useEffect(()=>{
    if(!open)return undefined;
    const el=cpRef.current;if(!el)return undefined;
    // Re-evaluated on resize: switching to VAR makes the popover taller after
    // it has already decided which way to open.
    const decide=()=>{
      el.classList.remove('flip-up');
      const box=el.getBoundingClientRect();
      el.classList.toggle('flip-up',box.bottom>window.innerHeight-12&&box.height<window.innerHeight-24);
    };
    const frame=requestAnimationFrame(decide);
    let observer=null;
    try{ observer=new ResizeObserver(()=>decide()); observer.observe(el); }catch(e){}
    return ()=>{ cancelAnimationFrame(frame); if(observer)observer.disconnect(); };
  },[open]);
  return h('span',{class:'ve-ts-sw-wrap',ref:wrapRef},
    h('button',{type:'button',class:'ve-ts-swatch'+(text?'':' empty'),style:literal?('background:linear-gradient('+hex+','+hex+'),repeating-conic-gradient(#2a2a2a 0% 25%,#1e1e1e 0% 50%) 50%/10px 10px'):'',
      title:text||'No colour set — click to pick',onClick:()=>setOpen(v=>!v)}),
    open&&h('div',{class:'ve-ts-cp',ref:cpRef},
      h(MVColorPickerCore,{hex:clrToHex(hex||'#000000'),onChange:next=>onPick(hexWithAlpha(clrToHex(next),alphaNow)),alpha:alphaNow,onAlphaChange:next=>onPick(hexWithAlpha(clrToHex(hex||'#000000'),next)),fmt:swatchFmt,setFmt:setSwatchFmt,variant:'inline',label:'Colour value',
        vars,boundVar:/^var\(/.test(text.trim())?text.trim():'',
        onBindVariable:token=>{ onBind(token); if(!token)setSwatchFmt('oklch'); },
        actions:[
          {label:'Clear',icon:'x',disabled:!text,title:'Remove the colour so the Bricks default applies again',onClick:()=>{onClear();setOpen(false);}},
          {label:'Done',primary:true,onClick:()=>setOpen(false)}
        ]}))
  );
}
function TsColor({value,onChange,vars,placeholder}){
  const text=tsColorText(value);
  const bound=/^var\(|^--/.test(text.trim());
  return h('div',{class:'ve-ts-val'},
    h(TsSwatch,{value,vars,onPick:next=>onChange(tsColorWrite(value,next)),onClear:()=>onChange(''),onBind:token=>onChange(tsColorWrite(value,token))}),
    h(VarRefInput,{value:text,vars:vars||[],bind:true,placeholder:placeholder||'Color value',
      onInput:e=>onChange(tsColorWrite(value,typeof e==='object'&&e?.target?e.target.value:e))}),
  );
}
function TsBackground({value,onChange,vars}){
  const obj=(value&&typeof value==='object')?value:{};
  return h(TsColor,{value:obj.color,vars,onChange:next=>onChange(tsPrune({...obj,color:next}))});
}
// Bricks stores a side's unit separately (value.unit.top), so a bare number means
// px while "2rem" carries its own unit. Splitting on input keeps both shapes valid.
function tsSplitUnit(raw){
  const text=String(raw==null?'':raw).trim();
  const m=text.match(/^(-?[\d.]+)(px|em|rem|%|vw|vh|ch|ex)$/i);
  return m?[m[1],m[2].toLowerCase()]:[text,''];
}
const TS_BOX_UNITS=['px','rem','em','%','vw','vh'];
const TS_BOX_STEPS={
  px:{per:2,decimals:0,max:400},
  rem:{per:8,decimals:2,max:40},
  em:{per:8,decimals:2,max:40},
  '%':{per:4,decimals:0,max:100},
  vw:{per:4,decimals:0,max:100},
  vh:{per:4,decimals:0,max:100},
};
function tsBoxNumber(value,step){
  const clamped=Math.max(0,Math.min(step.max,Number(value)||0));
  return step.decimals?String(+clamped.toFixed(step.decimals)):String(Math.round(clamped));
}
function TsBoxEdgeInput({side,label,value,band,onChange}){
  const[number,parsedUnit]=tsSplitUnit(value);
  const unit=TS_BOX_UNITS.includes(parsedUnit)?parsedUnit:'px';
  const[menu,setMenu]=useState(false);
  const[editing,setEditing]=useState(false);
  const[draft,setDraft]=useState(number);
  const wrapRef=useRef(null);
  const inputRef=useRef(null);
  const dragRef=useRef(null);
  const step=TS_BOX_STEPS[unit]||TS_BOX_STEPS.px;
  const numeric=Number(number);
  const fill=Number.isFinite(numeric)?Math.max(0,Math.min(100,numeric/step.max*100)):0;
  useEffect(()=>{if(!editing)setDraft(number);},[number,unit,editing]);
  useEffect(()=>{
    if(!menu)return;
    const close=e=>{if(!wrapRef.current||!wrapRef.current.contains(e.target))setMenu(false);};
    document.addEventListener('pointerdown',close,true);
    return()=>document.removeEventListener('pointerdown',close,true);
  },[menu]);
  const beginEdit=()=>{
    if(editing)return;
    setDraft(number===''?'':number+unit);
    setEditing(true);
    requestAnimationFrame(()=>{const input=inputRef.current;if(input){input.focus();try{input.select();}catch(error){}}});
  };
  const finishEdit=()=>{
    const text=String(draft==null?'':draft).trim();
    if(text===''){onChange('');setEditing(false);return;}
    const match=text.match(/^(-?[\d.]+)\s*(px|rem|em|%|vw|vh)?$/i);
    if(match){
      const nextUnit=(match[2]||unit).toLowerCase();
      onChange(match[1]+nextUnit);
    }else{
      const fallback=parseFloat(text);
      onChange(Number.isFinite(fallback)?String(fallback)+unit:'');
    }
    setEditing(false);
  };
  const beginScrub=e=>{
    if(e.button!==0||e.target.closest('.ve-ts-edge-unit'))return;
    const start=Number(number);
    if(!Number.isFinite(start))return;
    dragRef.current={x:e.clientX,start,moved:false,unit};
    const move=ev=>{
      const state=dragRef.current;if(!state)return;
      const dx=ev.clientX-state.x;
      if(Math.abs(dx)<3&&!state.moved)return;
      if(!state.moved){
        state.moved=true;
        setEditing(false);
        if(inputRef.current)inputRef.current.blur();
        document.body.style.userSelect='none';
      }
      ev.preventDefault();
      const scrubStep=TS_BOX_STEPS[state.unit]||TS_BOX_STEPS.px;
      onChange(tsBoxNumber(state.start+dx/scrubStep.per,scrubStep)+state.unit);
    };
    const end=()=>{
      dragRef.current=null;
      document.body.style.userSelect='';
      document.removeEventListener('pointermove',move);
      document.removeEventListener('pointerup',end);
    };
    document.addEventListener('pointermove',move,{passive:false});
    document.addEventListener('pointerup',end,{once:true});
  };
  const chooseUnit=next=>{
    const nextStep=TS_BOX_STEPS[next]||TS_BOX_STEPS.px;
    onChange((number===''?'':tsBoxNumber(number,nextStep)+next));
    setMenu(false);
  };
  return h('span',{class:'ve-ts-bf '+side,'data-side':label.slice(0,1),key:side},
    h('span',{class:'ve-ts-edge'+(editing?' editing':''),ref:wrapRef,onPointerDown:beginScrub},
      h('span',{class:'ve-ts-edge-fill','aria-hidden':'true',style:{width:fill+'%'}}),
      h('input',{ref:inputRef,value:editing?draft:number,placeholder:'0',inputMode:'decimal','aria-label':label+' '+(band||'spacing'),
        title:label+' '+(band||'spacing')+' — drag to scrub or click to type',
        onFocus:beginEdit,onInput:e=>{setDraft(e.target.value);onChange(e.target.value);},onBlur:finishEdit,
        onKeyDown:e=>{if(e.key==='Enter'||e.key==='Escape'){e.preventDefault();e.currentTarget.blur();}}}),
      h('button',{type:'button',class:'ve-ts-edge-unit'+(menu?' on':''),'aria-label':'Choose '+label.toLowerCase()+' unit','aria-expanded':menu?'true':'false',onClick:e=>{e.stopPropagation();setMenu(v=>!v);}},unit),
      menu&&h('span',{class:'ve-ts-edge-menu',role:'menu'},TS_BOX_UNITS.map(option=>
        h('button',{type:'button',role:'menuitem',class:option===unit?'on':'',onClick:e=>{e.stopPropagation();chooseUnit(option);},key:option},option)
      ))));
}
function TsSpacing({value,onChange,core,band}){
  const obj=(value&&typeof value==='object'&&!Array.isArray(value))?value:{};
  const units=(obj.unit&&typeof obj.unit==='object')?obj.unit:{};
  const shown=side=>{
    const number=obj[side];
    if(number==null||number==='')return '';
    return units[side]?String(number)+String(units[side]):String(number);
  };
  const values=BRICKS_TS_SIDES.map(s=>shown(s[0]));
  const[linked,setLinked]=useState(()=>values.every(v=>v===values[0]));
  const put=(side,raw)=>{
    const next={...obj},nextUnits={...units};
    const apply=target=>{
      const[number,unit]=tsSplitUnit(raw);
      if(number===''){delete next[target];delete nextUnits[target];return;}
      next[target]=number;
      if(unit)nextUnits[target]=unit; else delete nextUnits[target];
    };
    if(linked)BRICKS_TS_SIDES.forEach(s=>apply(s[0])); else apply(side);
    if(Object.keys(nextUnits).length)next.unit=nextUnits; else delete next.unit;
    onChange(tsPrune(next));
  };
  // Approved C44 Variant A — Quiet cross. The centre is intentionally silent:
  // the property heading and T/R/B/L edge labels already provide the context.
  // Each edge supports direct typing, horizontal scrubbing, and an explicit unit.
  const cell=(side,label)=>h(TsBoxEdgeInput,{side,label,value:shown(side),band,onChange:raw=>put(side,raw),key:side});
  return h('div',{class:'ve-ts-box'},
    h('div',{class:'ve-ts-box-top'},
      h('span',null,band||'spacing'),
      h('button',{type:'button',class:'ve-ts-lk'+(linked?' on':''),
        title:linked?'All four sides move together — click to set each side separately':'Each side is independent — click to move all four together',
        'aria-pressed':linked?'true':'false',onClick:()=>setLinked(v=>!v)},ph('link'))),
    h('div',{class:'ve-ts-frame'},
      h('div',{class:'ve-ts-el','aria-label':(core||'Element')+' content box'}),
      cell('top','Top'),cell('left','Left'),cell('right','Right'),cell('bottom','Bottom')));
}
function TsBorder({value,onChange,vars}){
  const obj=(value&&typeof value==='object')?value:{};
  return h('div',{class:'ve-ts-sub'},
    h('div',{class:'ve-ts-sub-l'},'Width'),
    h(TsSpacing,{value:obj.width,core:'border',band:'border width',onChange:next=>onChange(tsPrune({...obj,width:next}))}),
    h('div',{class:'ve-ts-row'},h('label',null,'Style'),
      h(TsSeg,{value:obj.style,options:BRICKS_TS_OPTIONS.borderStyle.filter(o=>['none','solid','dashed','dotted','double'].includes(o[0])),
        onChange:next=>onChange(tsPrune({...obj,style:next}))})),
    h('div',{class:'ve-ts-row'},h('label',null,'Color'),
      h(TsColor,{value:obj.color,vars,onChange:next=>onChange(tsPrune({...obj,color:next}))})));
}
function TsBoxShadow({value,onChange,vars,three}){
  const obj=(value&&typeof value==='object')?value:{};
  const values=(obj.values&&typeof obj.values==='object')?obj.values:{};
  const put=(key,next)=>{
    const merged={...values};
    if(String(next).trim()==='')delete merged[key]; else merged[key]=next;
    onChange(tsPrune({...obj,values:Object.keys(merged).length?merged:''}));
  };
  const num=(key,label)=>h('div',{class:'ve-ts-f',key},h('span',null,label),
    h('input',{class:'ve-studio-input',value:values[key]==null?'':String(values[key]),placeholder:'0',onInput:e=>put(key,e.target.value)}));
  return h('div',{class:'ve-ts-sub'},
    h('div',{class:'ve-ts-g2'},num('offsetX','X'),num('offsetY','Y')),
    h('div',{class:'ve-ts-g2'},num('blur','Blur'),three?null:num('spread','Spread')),
    h('div',{class:'ve-ts-row'},h('label',null,'Color'),
      h(TsColor,{value:obj.color,vars,onChange:next=>onChange(tsPrune({...obj,color:next}))})),
    three?null:h('div',{class:'ve-ts-inline'},h('span',null,'Inset'),
      h(ToggleControl,{checked:!!obj.inset,onChange:next=>{const merged={...obj};if(next)merged.inset=true;else delete merged.inset;onChange(tsPrune(merged));}})));
}
function tsExclude(options,exclude){
  if(!exclude)return options;
  const needle=String(exclude);
  return options.filter(option=>String(option[0]).indexOf(needle)===-1);
}
function TsSeg({value,options,onChange,icons,exclude}){
  const current=value==null?'':String(value);
  return h('div',{class:'ve-ts-seg'+(icons?' icons':'')},tsExclude(options,exclude).map(option=>{
    const token=option[0],label=option[1];
    const on=current===String(token);
    // Bricks clears the value when you click the active button — match that.
    return h('button',{type:'button',key:token,class:on?'on':'',title:String(token),
      onClick:()=>onChange(on?'':token)}, icons?ph(label):label);
  }));
}
function TsUnitInput({value,onChange,placeholder,units}){
  const text=value==null?'':String(value);
  return h('div',{class:'ve-ts-unit'},
    h('input',{class:'ve-studio-input',value:text,placeholder:placeholder||'',onInput:e=>onChange(e.target.value)}),
    units&&h(SelectMenu,{className:'ve-ts-unit-sel',value:tsSplitUnit(text)[1]||'',
      options:BRICKS_TS_UNITS.map(u=>({value:u,label:u||'—'})),
      onChange:unit=>{const[number]=tsSplitUnit(text);onChange(number===''?'':number+unit);}}));
}
function TsMultiSelect({value,onChange,options,placeholder,search,allowAdd}){
  const list=Array.isArray(value)?value:(value?[value]:[]);
  const[draft,setDraft]=useState('');
  const toggle=token=>onChange(list.includes(token)?list.filter(v=>v!==token):list.concat([token]));
  return h('div',{class:'ve-ts-multi'},
    h('div',{class:'ve-ts-chips'},
      list.length?list.map(token=>{
        const known=(options||[]).find(o=>o[0]===token);
        return h('span',{class:'ve-ts-chip',key:token},known?known[1]:token,
          h('button',{type:'button',title:'Remove',onClick:()=>toggle(token)},'×'));
      }):h('span',{class:'ve-ts-ph'},placeholder||'Nothing selected')),
    h('div',{class:'ve-ts-multi-opts'},(options||[]).map(option=>
      h('button',{type:'button',key:option[0],class:list.includes(option[0])?'on':'',onClick:()=>toggle(option[0])},option[1]))),
    allowAdd&&h('div',{class:'ve-ts-multi-add'},
      h('input',{class:'ve-studio-input',value:draft,placeholder:search||'Custom tag',
        onInput:e=>setDraft(e.target.value),
        onKeyDown:e=>{if(e.key==='Enter'){e.preventDefault();const token=draft.trim();if(token&&!list.includes(token))onChange(list.concat([token]));setDraft('');}}}),
      h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>{const token=draft.trim();if(token&&!list.includes(token))onChange(list.concat([token]));setDraft('');}},ph('plus')))
  );
}
function TsTypography({value,onChange,vars,fonts,exclude}){
  const obj=(value&&typeof value==='object')?value:{};
  const put=(key,next)=>{
    const merged={...obj};
    if(tsIsEmpty(next))delete merged[key]; else merged[key]=next;
    onChange(tsPrune(merged));
  };
  const omit=String(exclude||'');
  return h('div',{class:'ve-ts-sub'},BRICKS_TS_TYPO.filter(f=>!omit||omit.indexOf(f.k)===-1).map(field=>{
    const current=obj[field.k];
    let control=null;
    if(field.t==='color')control=h(TsColor,{value:current,vars,onChange:next=>put(field.k,next)});
    else if(field.t==='seg')control=h(TsSeg,{value:current,options:field.o,icons:field.k!=='text-transform',onChange:next=>put(field.k,next)});
    else if(field.t==='opt')control=h(SelectMenu,{value:current==null?'':String(current),
      options:[{value:'',label:'—'}].concat(BRICKS_TS_OPTIONS[field.o].map(o=>({value:o[0],label:o[1]}))),
      onChange:next=>put(field.k,next)});
    else if(field.t==='font')control=h(SelectMenu,{value:current==null?'':String(current),searchable:true,searchPlaceholder:'Search fonts',
      options:[{value:'',label:'Font family'}].concat((fonts||[]).map(f=>({value:f,label:f}))),
      onChange:next=>put(field.k,next)});
    else if(field.t==='unit')control=h(TsUnitInput,{value:current,units:true,placeholder:'—',onChange:next=>put(field.k,next)});
    else if(field.t==='shadow3')return h('details',{class:'ve-ts-exp',key:field.k},
      h('summary',null,h('span',null,field.l),!tsIsEmpty(current)&&h('i',{class:'ve-ts-dot'}),ph('caret-down')),
      h('div',{class:'ve-ts-exp-b'},h(TsBoxShadow,{value:current,vars,three:true,onChange:next=>put(field.k,next)})));
    else control=h('input',{class:'ve-studio-input',value:current==null?'':String(current),placeholder:field.l,onInput:e=>put(field.k,e.target.value)});
    return h('div',{class:'ve-ts-row',key:field.k},
      h('label',null,field.l,!tsIsEmpty(current)&&h('i',{class:'ve-ts-dot'})),control);
  }));
}
function TsRepeater({value,onChange,field,vars}){
  const rows=Array.isArray(value)?value:[];
  const title=field.tp||'selector';
  const put=(index,key,next)=>{
    const copy=rows.slice();
    const row={...copy[index]};
    if(tsIsEmpty(next))delete row[key]; else row[key]=next;
    copy[index]=row;onChange(copy);
  };
  return h('div',{class:'ve-ts-rep'},
    rows.map((row,index)=>h('div',{class:'ve-ts-rep-row',key:'row-'+index},
      h('div',{class:'ve-ts-rep-h'},
        h('b',null,row[title]||field.p||('Target ('+(index+1)+')')),
        h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',title:'Duplicate',
          onClick:()=>{const copy=rows.slice();copy.splice(index+1,0,{...row});onChange(copy);}},ph('copy')),
        h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',title:'Remove',
          onClick:()=>onChange(rows.filter((_,i)=>i!==index))},ph('trash'))),
      (field.f||[]).map(sub=>{
        if(!tsMeetsRequired(sub.req,row))return null;
        const current=row[sub.k];
        const control=sub.o
          ?h(SelectMenu,{value:current==null?'':String(current),searchable:!!sub.add,searchPlaceholder:sub.s||'Search',
            options:[{value:'',label:sub.p||'—'}].concat(sub.o.map(o=>({value:o[0],label:o[1]}))),
            onChange:next=>put(index,sub.k,next)})
          :h(VarRefInput,{value:current==null?'':String(current),vars:vars||[],bind:true,placeholder:sub.p||sub.l||'',
            onInput:e=>put(index,sub.k,typeof e==='object'&&e?.target?e.target.value:e)});
        return h('div',{class:'ve-ts-row',key:sub.k},h('label',null,sub.l),control);
      }))),
    h('button',{type:'button',class:'ve-btn ve-btn-g ve-ts-add',onClick:()=>onChange(rows.concat([{}]))},ph('plus'),' Add target'));
}

// The post the canvas is previewing, so the server can work out which theme
// styles' conditions currently match it.
function tsPostId(){ try{ return (window.bricksData&&window.bricksData.postId)||0; }catch(e){ return 0; } }
// id14 — the ten groups never fitted across 410px, so six were always scrolled
// out of sight. The rail shows all of them at once: 52px of icons, labels
// overlaid on hover so the fields never reflow, and a pin that reserves the
// width for anyone who would rather always read the names.
const BRICKS_TS_ICONS={
  conditions:'funnel', css:'brackets-curly', general:'browser', colors:'palette',
  links:'link', contextualSpacing:'arrows-out-line-horizontal', content:'selection',
  typography:'text-aa', popup:'browsers', elements:'squares-four'
};
// Bricks separates its own panel here too: matching / styling / per-element.
const BRICKS_TS_RAIL_BREAKS=['general','elements'];
const BRICKS_TS_CONDITIONS=[
  ['any','Entire website'],['frontpage','Front page'],['postType','Post type'],
  ['archiveType','Archive'],['terms','Terms'],['ids','Specific IDs'],
  ['search','Search results'],['error','Error page']
];
/* ── Per-control history (id41) ──────────────────────────────────────────────
   Undo, redo and clear on every theme style control. History is per setting,
   not panel-wide: undoing a colour must not also undo a font size changed after
   it. Depth is 25 steps and the stacks live in memory only — persisting them
   means storing them, which is a different and much larger feature.

   Text controls fire a change per keystroke. Rather than one history step per
   character, edits to the same control inside TS_HISTORY_COALESCE_MS collapse
   into one, keeping the value from *before* the burst — which is what an undo
   is expected to restore. */
const TS_HISTORY_DEPTH=25;
const TS_HISTORY_COALESCE_MS=600;
function tsHistoryKey(styleId,groupId,key){return String(styleId||'')+'|'+String(groupId||'')+'|'+String(key==null?'*':key);}
function tsHistoryEntry(store,id){
  let entry=store.get(id);
  if(!entry){entry={past:[],future:[],at:0};store.set(id,entry);}
  return entry;
}
function tsHistoryRecord(store,id,previousValue,now){
  const entry=tsHistoryEntry(store,id);
  const stamp=now==null?Date.now():now;
  entry.future.length=0;
  if(entry.past.length&&stamp-entry.at<TS_HISTORY_COALESCE_MS){entry.at=stamp;return entry;}
  entry.past.push(previousValue);
  if(entry.past.length>TS_HISTORY_DEPTH)entry.past.shift();
  entry.at=stamp;
  return entry;
}
function tsHistoryUndo(store,id,currentValue){
  const entry=store.get(id);
  if(!entry||!entry.past.length)return null;
  const value=entry.past.pop();
  entry.future.push(currentValue);
  if(entry.future.length>TS_HISTORY_DEPTH)entry.future.shift();
  /* Reset the coalescing clock or the next edit would be folded into the step
     we just undid, silently eating it. */
  entry.at=0;
  return{value};
}
function tsHistoryRedo(store,id,currentValue){
  const entry=store.get(id);
  if(!entry||!entry.future.length)return null;
  const value=entry.future.pop();
  entry.past.push(currentValue);
  if(entry.past.length>TS_HISTORY_DEPTH)entry.past.shift();
  entry.at=0;
  return{value};
}
function tsHistoryState(store,id){
  const entry=store.get(id);
  return{canUndo:!!(entry&&entry.past.length),canRedo:!!(entry&&entry.future.length)};
}
/* A style's stacks are dropped when you switch to a different style, so undo
   can never write a value from one style into another. */
function tsHistoryDropOthers(store,styleId){
  const prefix=String(styleId||'')+'|';
  Array.from(store.keys()).forEach(id=>{if(id.indexOf(prefix)!==0)store.delete(id);});
}
/* Buttons disable when there is nothing to do, so the row reports its own state
   without needing a click to find out. */
function TsHistory({history,label}){
  if(!history)return null;
  const what=label?' '+label:'';
  return h('span',{class:'ve-ts-hist'},
    h('button',{type:'button',class:'ve-ts-hb',disabled:!history.canUndo,'aria-label':'Undo'+what,
      title:history.canUndo?'Undo'+what:'Nothing to undo',
      onClick:e=>{e.preventDefault();e.stopPropagation();history.undo();}},ph('arrow-counter-clockwise')),
    h('button',{type:'button',class:'ve-ts-hb',disabled:!history.canRedo,'aria-label':'Redo'+what,
      title:history.canRedo?'Redo'+what:'Nothing to redo',
      onClick:e=>{e.preventDefault();e.stopPropagation();history.redo();}},ph('arrow-clockwise')),
    h('button',{type:'button',class:'ve-ts-hb clear',disabled:!history.canClear,'aria-label':'Clear'+what,
      title:history.canClear?'Clear'+what+' — remove the value so the Bricks default applies again':'Nothing set to clear',
      onClick:e=>{e.preventDefault();e.stopPropagation();history.clear();}},ph('x')));
}
function BricksThemeStylesSub({flash,open}){
  const[styles,setStyles]=useState([]);
  const[ctx,setCtx]=useState({post_types:[],fonts:[]});
  const[vars,setVars]=useState([]);
  const[selectedId,setSelectedId]=useState('');
  const[draft,setDraft]=useState(null);
  const[loading,setLoading]=useState(true);
  const[busy,setBusy]=useState(false);
  const[dirty,setDirty]=useState(false);
  const[group,setGroup]=useState(()=>{ try{ return localStorage.getItem('ve_theme_styles_group')||'general'; }catch(e){ return 'general'; } });
  const[railPinned,setRailPinned]=useState(()=>{ try{ return localStorage.getItem('ve_theme_styles_rail_pinned')==='1'; }catch(e){ return false; } });
  const pickGroup=next=>{ setGroup(next); try{ localStorage.setItem('ve_theme_styles_group',next); }catch(e){} };
  const[renaming,setRenaming]=useState(false);
  const[pendingDelete,setPendingDelete]=useState(null);
  const[headingLevel,setHeadingLevel]=useState('1');
  // Same suggestion pool as every other CodeMirror in MV.
  const{sourceOrder,disabledSources}=useCssStudioPreferences();

  const load=useCallback(async()=>{
    setLoading(true);
    try{
      const res=await api.g('bricks-theme-styles?post_id='+encodeURIComponent(tsPostId()));
      const next=Array.isArray(res?.styles)?res.styles:[];
      setStyles(next);setCtx(res?.context||{post_types:[],fonts:[]});
      if(Array.isArray(res?.context?.active_ids))activeIdsRef.current=res.context.active_ids;
      const chosen=next.find(style=>style.id===selectedId)||next[0]||null;
      if(chosen){setSelectedId(chosen.id);setDraft(tsDraft(chosen));}
      else{setSelectedId('');setDraft(null);}
      setDirty(false);
    }catch(e){setStyles([]);flash('Could not read Bricks theme styles.');}
    setLoading(false);
  },[flash]);
  useEffect(()=>{if(open)load();},[open]);
  useEffect(()=>{
    if(!open)return;
    // The ⚡ bind fields offer MV's own variables, so a theme style can follow the
    // token system instead of hard-coding a literal.
    api.g('variables?dedupe=true').then(res=>setVars(Array.isArray(res?.variables)?res.variables:(Array.isArray(res)?res:[]))).catch(()=>{});
  },[open]);

  const tsDraft=style=>({id:style.id,label:style.label,settings:JSON.parse(JSON.stringify(style.settings||{}))});
  const activeIdsRef=useRef([]);
  // Push the current picture to the builder canvas. Called on every edit, not
  // only on save, because "I don't want to refresh to see" is the whole point.
  const pushTimer=useRef(null);
  const pushNow=(list,override,options)=>{
    const map={};
    (list||[]).forEach(style=>{ map[style.id]={label:style.label,settings:style.settings||{}}; });
    if(override&&override.id)map[override.id]={label:override.label,settings:override.settings||{}};
    try{ if(typeof window.veThemeStylesApply==='function')window.veThemeStylesApply(map,activeIdsRef.current,options); }catch(e){}
  };
  // Each push replaces the whole styles map and re-renders Bricks' panel, so
  // firing one per keystroke made the canvas flicker. Coalesce to the pause
  // between keystrokes; it still reads as live.
  // Two-stage: repaint the canvas quickly while typing, then once the value has
  // settled do the heavier pass that also re-renders Bricks' control panel.
  const settleTimer=useRef(null);
  const pushLive=(list,override)=>{
    if(pushTimer.current)clearTimeout(pushTimer.current);
    if(settleTimer.current)clearTimeout(settleTimer.current);
    pushTimer.current=setTimeout(()=>pushNow(list,override,{quiet:true}),200);
    settleTimer.current=setTimeout(()=>pushNow(list,override,{force:true}),650);
  };
  // Leaving with unsaved edits used to leave them applied in Bricks: the canvas
  // and Bricks' own panel kept showing values MV had already discarded. Put the
  // saved state back on the way out.
  const revertLive=useCallback(()=>{
    if(pushTimer.current)clearTimeout(pushTimer.current);
    if(settleTimer.current)clearTimeout(settleTimer.current);
    pushNow(stylesRef.current,null,{force:true});
  },[]);
  const stylesRef=useRef([]);
  useEffect(()=>{ stylesRef.current=styles; },[styles]);
  const dirtyRef=useRef(false);
  useEffect(()=>{ dirtyRef.current=dirty; },[dirty]);
  useEffect(()=>()=>{ if(dirtyRef.current)revertLive(); },[revertLive]);
  useEffect(()=>{ if(!open&&dirtyRef.current)revertLive(); },[open,revertLive]);
  const selectStyle=id=>{
    if(dirty){flash('Save or reset this theme style before switching.');return;}
    const style=styles.find(s=>s.id===id);
    if(!style)return;
    setSelectedId(id);setDraft(tsDraft(style));setDirty(false);
    pushLive(styles);
  };
  // settings[group][key] — the exact shape Theme_Styles::get_setting_by_key reads.
  const groupValues=groupId=>(draft?.settings?.[groupId]&&typeof draft.settings[groupId]==='object')?draft.settings[groupId]:{};
  const historyRef=useRef(new Map());
  const[historyTick,setHistoryTick]=useState(0);
  const bumpHistory=()=>setHistoryTick(n=>n+1);
  const settingValue=(groupId,key)=>{
    const bucket=draft?.settings?.[groupId];
    return bucket&&typeof bucket==='object'?bucket[key]:undefined;
  };
  // Writes the value and nothing else. Undo and redo go through here, so
  // stepping back through history never records itself as new history.
  const applySetting=(groupId,key,value)=>{
    setDraft(prev=>{
      const settings={...(prev?.settings||{})};
      const bucket={...(settings[groupId]&&typeof settings[groupId]==='object'?settings[groupId]:{})};
      if(tsIsEmpty(value))delete bucket[key]; else bucket[key]=value;
      if(Object.keys(bucket).length)settings[groupId]=bucket; else delete settings[groupId];
      const next={...prev,settings};
      pushLive(styles,next);
      return next;
    });
    setDirty(true);
  };
  const applyGroup=(groupId,bucket)=>{
    setDraft(prev=>{
      const settings={...(prev?.settings||{})};
      if(bucket&&Object.keys(bucket).length)settings[groupId]={...bucket}; else delete settings[groupId];
      const next={...prev,settings};
      pushLive(styles,next);
      return next;
    });
    setDirty(true);
  };
  const setSetting=(groupId,key,value)=>{
    const id=tsHistoryKey(draft?.id,groupId,key);
    tsHistoryRecord(historyRef.current,id,settingValue(groupId,key));
    // The group stack records the whole bucket, so a group-level undo returns
    // every control at once rather than replaying them one by one.
    tsHistoryRecord(historyRef.current,tsHistoryKey(draft?.id,groupId,null),{...(draft?.settings?.[groupId]||{})});
    applySetting(groupId,key,value);
    bumpHistory();
  };
  const controlHistory=(groupId,key)=>{
    const id=tsHistoryKey(draft?.id,groupId,key);
    const store=historyRef.current;
    const state=tsHistoryState(store,id);
    return{
      canUndo:state.canUndo,
      canRedo:state.canRedo,
      // "Clear" is not "set to zero" — it removes the key so Bricks' own
      // default applies again, which is the only route back to "never set".
      canClear:!tsIsEmpty(settingValue(groupId,key)),
      undo:()=>{const step=tsHistoryUndo(store,id,settingValue(groupId,key));if(step){applySetting(groupId,key,step.value);bumpHistory();}},
      redo:()=>{const step=tsHistoryRedo(store,id,settingValue(groupId,key));if(step){applySetting(groupId,key,step.value);bumpHistory();}},
      clear:()=>{
        tsHistoryRecord(store,id,settingValue(groupId,key),0);
        tsHistoryRecord(store,tsHistoryKey(draft?.id,groupId,null),{...(draft?.settings?.[groupId]||{})},0);
        applySetting(groupId,key,undefined);
        bumpHistory();
      }
    };
  };
  const groupHistory=groupId=>{
    const id=tsHistoryKey(draft?.id,groupId,null);
    const store=historyRef.current;
    const state=tsHistoryState(store,id);
    const current=()=>({...(draft?.settings?.[groupId]||{})});
    return{
      canUndo:state.canUndo,
      canRedo:state.canRedo,
      canClear:!tsIsEmpty(draft?.settings?.[groupId]),
      undo:()=>{const step=tsHistoryUndo(store,id,current());if(step){applyGroup(groupId,step.value);bumpHistory();}},
      redo:()=>{const step=tsHistoryRedo(store,id,current());if(step){applyGroup(groupId,step.value);bumpHistory();}},
      clear:()=>{tsHistoryRecord(store,id,current(),0);applyGroup(groupId,null);bumpHistory();}
    };
  };
  useEffect(()=>{tsHistoryDropOthers(historyRef.current,draft?.id);bumpHistory();},[draft?.id]);
  const syncFromResponse=(res,preferredId)=>{
    const next=Array.isArray(res?.styles)?res.styles:[];
    setStyles(next);setCtx(res?.context||ctx);
    // Conditions may have changed which styles apply to this page, so the
    // server recomputes the active ids on every write.
    if(Array.isArray(res?.context?.active_ids))activeIdsRef.current=res.context.active_ids;
    pushLive(next);
    const chosen=next.find(style=>style.id===preferredId)||next[next.length-1]||null;
    if(chosen){setSelectedId(chosen.id);setDraft(tsDraft(chosen));}
    else{setSelectedId('');setDraft(null);}
    setDirty(false);
  };
  const create=async()=>{
    setBusy(true);
    try{const res=await api.p('bricks-theme-styles',{action:'create',label:'New theme style',post_id:tsPostId()});syncFromResponse(res,'');flash('Theme style created in Bricks.');}
    catch(e){flash('Create failed: '+(e?.message||'error'));}
    setBusy(false);
  };
  const save=async()=>{
    if(!draft||!draft.label.trim())return;
    setBusy(true);
    try{
      const res=await api.p('bricks-theme-styles',{action:'save',id:draft.id,label:draft.label.trim(),settings:draft.settings||{},post_id:tsPostId()});
      syncFromResponse(res,draft.id);flash('Theme style saved to Bricks.');
    }catch(e){flash('Save failed: '+(e?.message||'error'));}
    setBusy(false);
  };
  const duplicate=async()=>{
    if(!draft)return;
    setBusy(true);
    try{const res=await api.p('bricks-theme-styles',{action:'duplicate',id:draft.id,post_id:tsPostId()});syncFromResponse(res,'');flash('Theme style duplicated.');}
    catch(e){flash('Duplicate failed: '+(e?.message||'error'));}
    setBusy(false);
  };
  const remove=async()=>{
    if(!pendingDelete)return;
    setBusy(true);
    try{
      const res=await api.p('bricks-theme-styles',{action:'delete',id:pendingDelete.id,confirm:pendingDelete.id,post_id:tsPostId()});
      syncFromResponse(res,'');setPendingDelete(null);flash('Theme style deleted from Bricks.');
    }catch(e){flash('Delete failed: '+(e?.message||'error'));}
    setBusy(false);
  };

  /* ── Conditions ─────────────────────────────────────────────── */
  const conditions=Array.isArray(draft?.settings?.conditions?.conditions)?draft.settings.conditions.conditions:[];
  const setConditions=next=>setSetting('conditions','conditions',next.length?next:[{main:'any'}]);
  const conditionSummary=()=>{
    if(!conditions.length)return 'No conditions — never applied';
    return conditions.map(condition=>{
      const label=(BRICKS_TS_CONDITIONS.find(c=>c[0]===(condition.main||'any'))||['','Entire website'])[1];
      const detail=condition[condition.main];
      const suffix=Array.isArray(detail)&&detail.length?': '+detail.join(', '):'';
      return (condition.exclude?'Not ':'')+label+suffix;
    }).join(' · ');
  };
  const conditionEditor=()=>h('div',{class:'ve-ts-cond-list'},
    h('p',{class:'ve-ts-note'},'Where this theme style applies. Groups are OR\'d — a page matching any group gets the style. Bricks scores the matches and, unless you switch it in Bricks Settings, applies only the most specific one.'),
    conditions.map((condition,index)=>h(Fragment,{key:'cond-'+index},
      index>0&&h('div',{class:'ve-ts-or'},'OR'),
      h('div',{class:'ve-ts-cond'},
        h('div',{class:'ve-ts-g2'},
          h(SelectMenu,{value:String(condition.main||'any'),
            options:BRICKS_TS_CONDITIONS.map(c=>({value:c[0],label:c[1]})),
            onChange:value=>{const next=conditions.slice();next[index]={main:value};setConditions(next);}}),
          ['postType','archiveType','terms','ids'].includes(condition.main||'')
            ?h('input',{class:'ve-studio-input',
                value:(Array.isArray(condition[condition.main])?condition[condition.main]:condition[condition.main]?[condition[condition.main]]:[]).join(', '),
                placeholder:condition.main==='postType'
                  ?((ctx.post_types||[]).map(t=>t.slug).join(', ')||'Post type slugs')
                  :(condition.main==='archiveType'?'any, author, date, or term':'Numeric IDs, comma separated'),
                onInput:e=>{const next=conditions.slice();next[index]={...condition,[condition.main]:e.target.value.split(',').map(v=>v.trim()).filter(Boolean)};setConditions(next);}})
            :h('span',{class:'ve-ts-na'},'Not applicable')),
        h('div',{class:'ve-ts-cond-f'},
          h('div',{class:'ve-ts-inline'},h('span',null,'Exclude'),
            h(ToggleControl,{checked:!!condition.exclude,onChange:value=>{const next=conditions.slice();next[index]={...condition,exclude:value};setConditions(next);}})),
          h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',disabled:conditions.length===1,
            onClick:()=>setConditions(conditions.filter((_,i)=>i!==index))},ph('trash'),' Remove'))))),
    h('button',{type:'button',class:'ve-btn ve-btn-g ve-ts-add',onClick:()=>setConditions(conditions.concat([{main:'any'}]))},ph('plus'),' Add condition group')
  );

  /* ── Field rendering ────────────────────────────────────────── */
  const fontOptions=Array.isArray(ctx.fonts)?ctx.fonts:[];
  const renderField=(groupId,field)=>{
    const values=groupValues(groupId);
    if(!tsMeetsRequired(field.req,values))return null;
    const value=values[field.k];
    const set=next=>setSetting(groupId,field.k,next);
    const type=field.t;

    if(type==='separator')return h('div',{class:'ve-ts-sep',key:field.k},
      field.l&&h('div',{class:'ve-ts-sep-h'},field.l),
      field.d&&h('p',{class:'ve-ts-note'},tsDesc(field.d)));
    if(type==='info')return h('div',{class:'ve-ts-banner',key:field.k},ph('info'),h('div',null,tsDesc(field.d)));
    // Bricks' 'apply' control saves and reloads, because the selector list is baked
    // into the generated CSS at save time rather than applied live.
    if(type==='apply')return h('button',{type:'button',key:field.k,class:'ve-btn ve-btn-g ve-ts-add',disabled:busy,
      title:'Save now and reload the builder so the new selector list is used',
      onClick:async()=>{await save();flash('Saved. Reload the builder to see the new link selectors applied.');}},field.l);

    const set_=!tsIsEmpty(value);
    let control=null,wide=false;
    if(type==='color')control=h(TsColor,{value,vars,onChange:set});
    else if(type==='background')control=h(TsBackground,{value,vars,onChange:set});
    else if(type==='spacing'){wide=true;control=h(TsSpacing,{value,core:tsCore(field.k),band:tsBand(field.k),onChange:set});}
    else if(type==='border'){wide=true;control=h(TsBorder,{value,vars,onChange:set});}
    else if(type==='box-shadow'){wide=true;control=h(TsBoxShadow,{value,vars,onChange:set});}
    else if(type==='typography'){wide=true;control=h(TsTypography,{value,vars,fonts:fontOptions,exclude:field.x,onChange:set});}
    else if(type==='repeater'){wide=true;control=h(TsRepeater,{value,field,vars,onChange:set});}
    else if(type==='text-decoration')control=h(TsSeg,{value,options:BRICKS_TS_DECORATION,icons:true,exclude:field.x,onChange:set});
    else if(type==='justify-content')control=h(TsSeg,{value,options:BRICKS_TS_JUSTIFY,icons:true,exclude:field.x,onChange:set});
    else if(type==='align-items')control=h(TsSeg,{value,options:BRICKS_TS_ITEMS,icons:true,exclude:field.x,onChange:set});
    else if(type==='checkbox')control=h(ToggleControl,{checked:!!value,onChange:set});
    else if(type==='select'){
      // popupShowAt / popupShowOn have no static options — Bricks fills them with the
      // site's own breakpoints, so MV reads those from the REST context.
      const options=(field.o&&field.o.length)?field.o:(/^popupShow/.test(field.k)?(ctx.breakpoints||[]).map(b=>[b.key,b.label]):[]);
      control=field.m
        ?h(TsMultiSelect,{value,options,placeholder:field.p,search:field.s,allowAdd:!!field.add,onChange:set})
        :h(SelectMenu,{value:value==null?'':String(value),searchable:options.length>8,
          options:[{value:'',label:field.p||'—'}].concat(options.map(o=>({value:o[0],label:o[1]}))),onChange:set});
    }
    else if(type==='number')control=h(TsUnitInput,{value,units:!!field.u,placeholder:field.p||'—',onChange:set});
    else if(type==='textarea'){wide=true;control=h('textarea',{class:'ve-studio-input ve-ts-ta',value:value==null?'':String(value),
      placeholder:field.def||field.p||'',spellcheck:false,onInput:e=>set(e.target.value)});}
    else control=h(VarRefInput,{value:value==null?'':String(value),vars,bind:true,placeholder:field.p||'—',
      onInput:e=>set(typeof e==='object'&&e?.target?e.target.value:e)});

    // Composite controls need the full width, so they collapse into their own
    // disclosure instead of sitting in the label / control row.
    const history=controlHistory(groupId,field.k);
    if(wide)return h('details',{class:'ve-ts-exp',key:field.k,open:set_||type==='spacing'||type==='repeater'},
      h('summary',null,h('span',null,field.l||field.k),set_&&h('i',{class:'ve-ts-dot'}),
        field.i&&h('span',{class:'ve-ts-info','data-ve-tip':field.i},'i'),
        h(TsHistory,{history,label:field.l||field.k}),ph('caret-down')),
      h('div',{class:'ve-ts-exp-b'},control,field.d&&h('div',{class:'ve-ts-hint'},tsDesc(field.d))));
    return h('div',{class:'ve-ts-row',key:field.k},
      h('label',null,field.l||field.k,set_&&h('i',{class:'ve-ts-dot'}),
        field.i&&h('span',{class:'ve-ts-info','data-ve-tip':field.i},'i'),
        h(TsHistory,{history,label:field.l||field.k})),
      control,
      field.d&&h('div',{class:'ve-ts-hint'},tsDesc(field.d)));
  };
  // The band is the property being edited; the core is the element it wraps.
  const tsBand=key=>{
    const k=String(key||'');
    if(/padding/i.test(k))return 'padding';
    if(/margin/i.test(k))return 'margin';
    if(/gap/i.test(k))return 'gap';
    if(/border/i.test(k))return 'border width';
    return 'spacing';
  };
  const tsCore=key=>{
    // Names the rectangle in the box control, so it has to read as a thing on
    // the page. 'all' is an internal grouping token and means nothing there.
    if(/blockquote/i.test(key))return 'quote';
    if(/^h[1-6]Margin$/.test(key))return key.slice(0,2).toUpperCase();
    if(/popupContent/i.test(key))return 'content';
    if(/popup/i.test(key))return 'popup';
    if(/content/i.test(key))return 'content';
    if(/section/i.test(key))return 'root container';
    if(/^root/i.test(key))return 'root container';
    return 'element';
  };

  // Typography carries six near-identical H1–H6 blocks. Bricks stacks them all;
  // MV shows one level at a time so the panel stays readable in a 410px studio.
  const typographyFields=fields=>{
    const out=[];
    let skipping=false;
    fields.forEach(field=>{
      const headingSep=/^headingH([1-6])Separator$/.exec(field.k);
      if(headingSep){
        skipping=headingSep[1]!==headingLevel;
        if(headingSep[1]==='1'){
          out.push(h('div',{class:'ve-ts-sep',key:'heading-picker'},
            h('div',{class:'ve-ts-sep-h'},'Heading H1 – H6'),
            h('p',{class:'ve-ts-note'},'Each level has its own typography and margin. Pick a level, edit it, move on.'),
            h(TsSeg,{value:headingLevel,options:['1','2','3','4','5','6'].map(n=>[n,'H'+n]),
              onChange:next=>setHeadingLevel(next||headingLevel)})));
        }
        return;
      }
      if(skipping&&/^(typographyHeadingH[1-6]|h[1-6]Margin)$/.test(field.k))return;
      if(skipping&&!/^(typographyHeadingH[1-6]|h[1-6]Margin)$/.test(field.k))skipping=false;
      const relabelled=/^typographyHeadingH[1-6]$/.test(field.k)?{...field,l:'Typography — H'+headingLevel}
        :(/^h[1-6]Margin$/.test(field.k)?{...field,l:'Margin — H'+headingLevel}:field);
      out.push(renderField('typography',relabelled));
    });
    return out;
  };

  const groupBody=definition=>{
    if(definition.kind==='conditions')return conditionEditor();
    if(definition.kind==='css')return h('div',{class:'ve-ts-css'},
      h('p',{class:'ve-ts-note'},'Applies wherever this theme style’s conditions match. Custom CSS is not breakpoint-aware — add media queries yourself.'),
      h(CssEditor,{value:groupValues('css').stylesheet||'',onChange:value=>setSetting('css','stylesheet',value),
        vars,sourceOrder,disabledSources,
        // Bricks writes this stylesheet out verbatim, so SCSS would ship to the
        // site uncompiled. Suggestions are shared; the compile mode is not.
        scss:false}));
    if(definition.kind==='paused'){
      const carried=(styles.find(style=>style.id===draft.id)||{}).other_groups||[];
      return h('div',{class:'ve-ts-banner paused'},ph('pause'),
        h('div',null,h('b',null,'Per-element defaults are paused.'),
          ' Bricks exposes about forty element groups (Section, Button, Heading…). Edit them in Bricks for now — MV never touches them when you save from here.',
          carried.length
            ?h('div',{style:'margin-top:8px'},'This style already carries ',h('b',null,String(carried.length)),
                ' element group'+(carried.length===1?'':'s')+' set in Bricks: ',h('code',null,carried.join(', ')),'. They are preserved on every save.')
            :h('div',{style:'margin-top:8px'},'This style has no element groups set.')));
    }
    if(definition.id==='typography')return h('div',{class:'ve-ts-fields'},typographyFields(definition.fields||[]));
    return h('div',{class:'ve-ts-fields'},(definition.fields||[]).map(field=>renderField(definition.id,field)));
  };

  const groupIsSet=definition=>{
    if(definition.kind==='conditions')return conditions.length>0;
    if(definition.kind==='paused')return false;
    return !tsIsEmpty(draft?.settings?.[definition.id]);
  };
  const setCount=BRICKS_TS_GROUPS.filter(groupIsSet).length;
  const active=BRICKS_TS_GROUPS.find(definition=>definition.id===group)||BRICKS_TS_GROUPS[0];

  if(loading)return h('div',{class:'ve-ts'},h('div',{class:'ve-ts-empty'},'Loading Bricks theme styles…'));
  if(!draft)return h('div',{class:'ve-ts'},
    h('div',{class:'ve-ts-empty'},'No Bricks theme styles yet.'),
    h('button',{type:'button',class:'ve-btn ve-ts-add',disabled:busy,onClick:create},ph('plus'),' Create the first theme style'));

  return h(Fragment,null,
    h('div',{class:'ve-ts'},
      h('div',{class:'ve-ts-switch'},
        h('div',{class:'ve-ts-switch-r'},
          renaming
            ?h('input',{class:'ve-studio-input',value:draft.label,autofocus:true,'aria-label':'Theme style name',
                onInput:e=>{setDraft({...draft,label:e.target.value});setDirty(true);},
                onBlur:()=>setRenaming(false),onKeyDown:e=>{if(e.key==='Enter')setRenaming(false);}})
            :h(SelectMenu,{className:'ve-ts-switch-sel',value:selectedId,
                options:styles.map(style=>({value:style.id,label:style.label})),onChange:selectStyle}),
          h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s','data-ve-tip':'Rename',onClick:()=>setRenaming(v=>!v)},ph('pencil-simple')),
          h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s','data-ve-tip':'New theme style',disabled:busy,onClick:create},ph('plus')),
          h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s','data-ve-tip':'Duplicate',disabled:busy,onClick:duplicate},ph('copy')),
          h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s ve-ih-del','data-ve-tip':'Delete',disabled:busy,onClick:()=>setPendingDelete(draft)},ph('trash'))),
        h('div',{class:'ve-ts-meta'},
          conditions.some(c=>(c.main||'any')==='any'&&!c.exclude)&&h('span',{class:'ve-ts-pill'},'Site-wide'),
          h('span',{class:'ve-ts-meta-c'},conditionSummary()),
          h('span',{class:'ve-ts-meta-n'},setCount+' group'+(setCount===1?'':'s')+' set'))),
      h('div',{class:'ve-ts-split'},
        h('nav',{class:'ve-ts-rail'+(railPinned?' pinned':''),'aria-label':'Theme style groups'},
          h('div',{class:'ve-ts-rail-inner'},
            BRICKS_TS_GROUPS.map(definition=>h(Fragment,{key:definition.id},
              BRICKS_TS_RAIL_BREAKS.includes(definition.id)&&h('div',{class:'ve-ts-rail-sep'}),
              h('button',{type:'button',
                class:(definition.id===group?'on':'')+(definition.kind==='paused'?' paused':''),
                'aria-current':definition.id===group?'true':undefined,
                onClick:()=>pickGroup(definition.id)},
                ph(BRICKS_TS_ICONS[definition.id]||'circle'),
                h('span',{class:'ve-ts-rail-lbl'},definition.label),
                groupIsSet(definition)&&h('i',{class:'ve-ts-dot'})))),
            h('button',{type:'button',class:'ve-ts-rail-pin'+(railPinned?' on':''),
              title:railPinned?'Collapse the rail back to icons':'Keep the group names showing',
              onClick:()=>{const next=!railPinned;setRailPinned(next);try{localStorage.setItem('ve_theme_styles_rail_pinned',next?'1':'0');}catch(e){}}},
              ph(railPinned?'push-pin-slash':'push-pin'),
              h('span',{class:'ve-ts-rail-lbl'},railPinned?'Collapse':'Keep open')))),
        h('div',{class:'ve-ts-body'},
          active&&active.kind!=='paused'&&h('div',{class:'ve-ts-group-h'},
            h('b',null,active.label),
            h(TsHistory,{history:groupHistory(active.id),label:'everything in '+active.label})),
          groupBody(active))),
      h('div',{class:'ve-ts-foot'},
        h('span',{class:'ve-ts-status'},h('i',{class:'ve-ts-live'+(dirty?' off':'')}),
          dirty?'Unsaved changes':'Saved to Bricks · no separate MV copy'),
        h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',disabled:busy||!dirty,
          title:'Discard every unsaved change in this style',
          onClick:()=>{const live=styles.find(style=>style.id===draft.id);if(live){setDraft(tsDraft(live));setDirty(false);revertLive();historyRef.current.clear();bumpHistory();}}},'Reset'),
        h('button',{type:'button',class:'ve-btn ve-btn-s',disabled:busy||!dirty||!draft.label.trim(),onClick:save},busy?'Saving…':'Save style'))
    ),
    pendingDelete&&h(ConfirmModal,{title:'Delete theme style',
      body:'Delete “'+pendingDelete.label+'” from Bricks? This removes the native theme-style record and its generated CSS file. It cannot be undone.',
      confirmText:'Delete theme style',danger:true,onCancel:()=>setPendingDelete(null),onConfirm:remove})
  );
}

// #23 Bricks Settings — read/write Bricks' own bricks_global_settings from MV.
// Live-editable control types: toggle, select (exact Bricks enum tokens), text,
// password, number, code. Complex/destructive items (converters, delete-data,
// multiselects, access matrix) are surfaced read-only with a "manage in Bricks"
// note for v1. Maintenance reuses MV's Site Visibility.
const BRICKS_SETTINGS_GROUPS = [
  ['general','General',[
    {n:'Bricks components in block editor',k:'bricksComponentsInBlockEditor',t:'select',o:[['','Disabled (default)'],['manual','Enable individually'],['all','Enable all automatically']]},
    {n:'Disable global class manager',k:'disableClassManager',t:'toggle'},
    {n:'Disable CSS variables manager',k:'disableVariablesManager',t:'toggle'},
    {n:'Disable Bricks Open Graph tags',k:'disableOpenGraph',t:'toggle'},
    {n:'Disable Bricks SEO meta tags',k:'disableSeo',t:'toggle'},
    {n:'Generate custom image sizes',k:'customImageSizes',t:'toggle'},
    {n:'Add element ID as needed',k:'elementAttsAsNeeded',t:'toggle'},
    {n:'Disable "Skip links"',k:'disableSkipLinks',t:'toggle'},
    {n:'Smooth scroll (CSS)',k:'smoothScroll',t:'toggle'},
    {n:'Query Bricks data in search results',k:'searchResultsQueryBricksData',t:'toggle'},
    {n:'Theme styles loading method',k:'themeStylesLoadingMethod',t:'select',o:[['','Most specific (default)'],['all','Load all matching']]},
    {n:'Duplicate content',k:'duplicateContent',t:'select',o:[['','Enable'],['disable_all','Disable globally'],['disable_wp','Disable for WP data']]},
    {n:'Save form submissions in database',k:'saveFormSubmissions',t:'toggle'},
    {n:'Enable query filters',k:'enableQueryFilters',h:'Index-based filtering for query loops.',t:'toggle'},
    {n:'Custom breakpoints',k:'customBreakpoints',h:'Add/edit your own responsive breakpoints.',t:'toggle'},
    {n:'Password protection',k:'passwordProtectionEnabled',t:'toggle'},
    {n:'Check for corrupt data',k:'builderCheckForCorruptData',t:'toggle'},
    {n:'Post types',k:'postTypes',h:'Which post types Bricks can edit.',t:'multiselect',src:'post_types'},
    {n:'SVG upload roles',k:'uploadSvgCapabilities',h:'Roles allowed to upload SVG (grants the capability).',t:'multiselect',src:'roles'},
    {n:'Load Block editor data into Bricks',k:'wp_to_bricks',h:'Convert Block editor data into Bricks when editing.',t:'toggle'},
    {n:'Save Bricks data as Block editor data',k:'bricks_to_wp',t:'toggle'},
    {n:'Delete all Bricks data on uninstall',k:'deleteBricksData',h:'Irreversible on uninstall.',t:'toggle',danger:true},
  ]],
  ['builder-access','Builder access',[
    {n:'Builder capabilities by role',k:'customCapabilities',h:'Full / limited builder access per role (roles × permissions matrix).',t:'inbricks'},
  ]],
  ['templates','Templates',[
    {n:'Generate template screenshots',k:'generateTemplateScreenshots',t:'toggle'},
    {n:'Template thumbnail height',k:'templateManagerThumbnailHeight',t:'number',u:'px'},
    {n:'Screenshots in admin column',k:'templateScreenshotsAdminColumn',t:'toggle'},
    {n:'Disable default templates',k:'defaultTemplatesDisabled',t:'toggle'},
    {n:'Public templates',k:'publicTemplates',h:'Expose templates to the Bricks community library.',t:'toggle'},
    {n:'Excluded templates',k:'excludedTemplates',h:'Templates hidden from the remote template library.',t:'multiselect',src:'templates'},
  ]],
  ['builder','Builder',[
    {n:'Disable autosave',k:'builderAutosaveDisabled',t:'toggle'},
    {n:'Autosave interval',k:'builderAutosaveInterval',h:'Default 60s. Minimum 15s.',t:'number',u:'sec'},
    {n:'Builder mode',k:'builderMode',t:'select',o:[['dark','Dark'],['light','Light'],['custom','Custom']]},
    {n:'Disable panel auto-expand',k:'builderDisablePanelAutoExpand',t:'toggle'},
    {n:'Disable global classes interface',k:'builderDisableGlobalClassesInterface',t:'toggle'},
    {n:'Hide variable values in picker',k:'builderVariablePickerHideValue',t:'toggle'},
    {n:'Vim mode in code editors',k:'builderCodeVim',t:'toggle'},
    {n:'Element breadcrumbs',k:'builderElementBreadcrumbs',t:'toggle'},
    {n:'Structure: auto-sync',k:'structureAutoSync',t:'toggle'},
    {n:'Import image on paste',k:'importImageOnPaste',t:'toggle'},
    {n:'Query dropdown behavior',k:'builderQueryObjectType',t:'select',o:[['conflicts','On conflicts'],['new','New'],['always','Always'],['never','Never']]},
    {n:'Query max results',k:'builderQueryMaxResults',t:'number',u:'rows'},
    {n:'Enable dynamic data preview',k:'enableDynamicDataPreview',t:'toggle'},
    {n:'Global classes: auto-sync',k:'builderGlobalClassesSync',t:'toggle'},
    {n:'Disable builder REST API',k:'builderDisableRestApi',t:'toggle'},
  ]],
  ['performance','Performance',[
    {n:'Disable emojis',k:'disableEmojis',t:'toggle'},
    {n:'Disable embeds',k:'disableEmbed',t:'toggle'},
    {n:'Disable Google Fonts',k:'disableGoogleFonts',t:'toggle'},
    {n:'Disable lazy load',k:'disableLazyLoad',t:'toggle'},
    {n:'Lazy load offset',k:'offsetLazyLoad',t:'number',u:'px'},
    {n:'Disable jQuery Migrate',k:'disableJqueryMigrate',t:'toggle'},
    {n:'Cache query loops',k:'cacheQueryLoops',t:'toggle'},
    {n:'Disable class chaining',k:'disableClassChaining',t:'toggle'},
    {n:'CSS loading method',k:'cssLoading',t:'select',o:[['','Inline styles (default)'],['file','External files']]},
    {n:'Regenerate CSS files',k:'__regen',h:'Rebuild Bricks external CSS files (external-files mode).',t:'regen'},
    {n:'Webfont loading method',k:'webfontLoading',t:'select',o:[['','Stylesheets (default)'],['webfontloader','Webfont Loader (JS)']]},
    {n:'Preload custom fonts',k:'customFontsPreload',t:'toggle'},
    {n:'Disable Bricks cascade layer',k:'disableBricksCascadeLayer',h:'Discouraged — leave OFF for compatibility.',t:'toggle',danger:true},
  ]],
  ['maintenance','Maintenance mode',[
    {n:'Managed by MV Site Visibility',k:'maintenanceMode',t:'sitevis'},
  ]],
  ['api-keys','API keys',[
    {n:'Adobe Fonts project ID',k:'adobeFontsProjectId',t:'text'},
    {n:'Unsplash API key',k:'apiKeyUnsplash',t:'password'},
    {n:'Google Maps API key',k:'apiKeyGoogleMaps',t:'password'},
    {n:'Google reCAPTCHA site key',k:'apiKeyGoogleRecaptcha',t:'password'},
    {n:'Google reCAPTCHA secret key',k:'apiSecretKeyGoogleRecaptcha',t:'password'},
    {n:'hCaptcha site key',k:'apiKeyHCaptcha',t:'password'},
    {n:'Cloudflare Turnstile site key',k:'apiKeyTurnstile',t:'password'},
    {n:'Mailchimp API key',k:'apiKeyMailchimp',t:'password'},
    {n:'SendGrid API key',k:'apiKeySendgrid',t:'password'},
    {n:'Facebook App ID',k:'facebookAppId',t:'text'},
    {n:'Instagram access token',k:'instagramAccessToken',t:'password'},
  ]],
  ['custom-code','Custom code',[
    {n:'Enable code execution',k:'executeCodeEnabled',h:'Allow PHP/JS in Code elements. Powerful — admin only.',t:'toggle',danger:true},
    {n:'Code execution roles',k:'executeCodeCapabilities',h:'Roles allowed to run code (needs the toggle above).',t:'multiselect',src:'roles'},
    {n:'Custom CSS',k:'customCss',t:'code',ph:'/* Global custom CSS */'},
    {n:'Header scripts',k:'customScriptsHeader',t:'code',ph:'<!-- before </head> -->'},
    {n:'Body scripts (header)',k:'customScriptsBodyHeader',t:'code',ph:'<!-- after <body> -->'},
    {n:'Body scripts (footer)',k:'customScriptsBodyFooter',t:'code',ph:'<!-- before </body> -->'},
  ]],
  ['woocommerce','WooCommerce',[
    {n:'Disable Bricks Woo builder',k:'woocommerceDisableBuilder',t:'toggle'},
    {n:'Use Bricks Woo notices',k:'woocommerceUseBricksWooNotice',t:'toggle'},
    {n:'Quantity input in loop',k:'woocommerceUseQtyInLoop',t:'toggle'},
    {n:'Variation swatches',k:'woocommerceUseVariationSwatches',t:'toggle'},
    {n:'AJAX add to cart',k:'woocommerceEnableAjaxAddToCart',t:'toggle'},
    {n:'"Adding…" text',k:'woocommerceAjaxAddingText',t:'text'},
    {n:'"Added" text',k:'woocommerceAjaxAddedText',t:'text'},
  ]],
];
const BRICKS_LIVE_TYPES = ['toggle','select','text','password','number','code','multiselect'];
const BRICKS_SETTINGS_SECTIONS={
  general:[
    ['Editing & data',['bricksComponentsInBlockEditor','duplicateContent','saveFormSubmissions','enableQueryFilters','searchResultsQueryBricksData','postTypes','wp_to_bricks','bricks_to_wp']],
    ['Managers & SEO',['disableClassManager','disableVariablesManager','disableOpenGraph','disableSeo','themeStylesLoadingMethod']],
    ['Media & access',['customImageSizes','uploadSvgCapabilities','elementAttsAsNeeded','disableSkipLinks','smoothScroll']],
    ['Advanced & safety',['customBreakpoints','passwordProtectionEnabled','builderCheckForCorruptData','deleteBricksData']]
  ],
  templates:[['Template library',['generateTemplateScreenshots','templateManagerThumbnailHeight','templateScreenshotsAdminColumn','defaultTemplatesDisabled','publicTemplates','excludedTemplates']]],
  builder:[
    ['Editing experience',['builderAutosaveDisabled','builderAutosaveInterval','builderMode','builderDisablePanelAutoExpand','builderElementBreadcrumbs','importImageOnPaste','enableDynamicDataPreview']],
    ['Managers & structure',['builderDisableGlobalClassesInterface','builderVariablePickerHideValue','structureAutoSync','builderGlobalClassesSync']],
    ['Code & query',['builderCodeVim','builderQueryObjectType','builderQueryMaxResults','builderDisableRestApi']]
  ],
  performance:[
    ['WordPress cleanup',['disableEmojis','disableEmbed','disableJqueryMigrate']],
    ['Assets & fonts',['disableGoogleFonts','disableLazyLoad','offsetLazyLoad','webfontLoading','customFontsPreload']],
    ['CSS & queries',['cacheQueryLoops','disableClassChaining','cssLoading','__regen','disableBricksCascadeLayer']]
  ],
  'api-keys':[['External services',['adobeFontsProjectId','apiKeyUnsplash','apiKeyGoogleMaps','apiKeyGoogleRecaptcha','apiSecretKeyGoogleRecaptcha','apiKeyHCaptcha','apiKeyTurnstile','apiKeyMailchimp','apiKeySendgrid','facebookAppId','instagramAccessToken']]],
  'custom-code':[
    ['Execution',['executeCodeEnabled','executeCodeCapabilities']],
    ['Styles',['customCss']],
    ['Scripts',['customScriptsHeader','customScriptsBodyHeader','customScriptsBodyFooter']]
  ],
  woocommerce:[['WooCommerce builder',['woocommerceDisableBuilder','woocommerceUseBricksWooNotice','woocommerceUseQtyInLoop','woocommerceUseVariationSwatches','woocommerceEnableAjaxAddToCart','woocommerceAjaxAddingText','woocommerceAjaxAddedText']]]
};
function bricksSettingsSections(group){
  const config=BRICKS_SETTINGS_SECTIONS[group[0]];
  if(!config)return[[group[1],group[2]]];
  const byKey=Object.fromEntries(group[2].map(field=>[field.k,field]));
  const used=new Set();
  const sections=config.map(([label,keys])=>[label,keys.map(key=>byKey[key]).filter(field=>{if(!field)return false;used.add(field.k);return true;})]).filter(section=>section[1].length);
  const remaining=group[2].filter(field=>!used.has(field.k));
  if(remaining.length)sections.push(['Other',remaining]);
  return sections;
}

function BricksSettingsSub({ flash }) {
  const [values, setValues] = useState({});
  const [ctx, setCtx] = useState({ post_types: [], templates: [], roles: [] });
  const [wooActive, setWooActive] = useState(false);
  const [loading, setLoading] = useState(true);
  const [group, setGroup] = useState(() => { try { return localStorage.getItem('ve_bricks_settings_group') || 'general'; } catch (e) { return 'general'; } });
  const [q, setQ] = useState('');
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [regenBusy, setRegenBusy] = useState(false);
  const [showDescriptions, setShowDescriptions] = useState(false);
  const [openSettingsSection, setOpenSettingsSection] = useState('');
  const [popoutKey, setPopoutKey] = useState(null); // #36: code field popped into a side panel
  const saveRef = useRef(null); // latest save(), so ⌘/Ctrl+S never fires a stale closure
  const [popLeft, setPopLeft] = useState(14); // pop-out sits just left of the Settings panel
  // #56: owner-defined custom HTML tags merged into Bricks' allow-list.
  const [customTags, setCustomTags] = useState([]);
  // #11 — Minimum canvas viewport (Bricks builder / Code2Bricks).
  const [tagDraft, setTagDraft] = useState('');
  const [tagsDirty, setTagsDirty] = useState(false);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.g('bricks-settings');
      setValues(res && res.values ? res.values : {});
      setCtx((res && res.context) ? { post_types: res.context.post_types || [], templates: res.context.templates || [], roles: res.context.roles || [] } : { post_types: [], templates: [], roles: [] });
      setWooActive(!!(res && res.context && res.context.woo_active));
      try { const tg = await api.g('bricks-settings/custom-tags'); setCustomTags(Array.isArray(tg && tg.tags) ? tg.tags : []); } catch (e) { setCustomTags([]); }
    } catch (e) {
      setValues({}); flash('Could not read Bricks settings.');
    }
    try {
    } catch (e) { /* leave defaults; the group still renders */ }
    setLoading(false); setDirty(false); setTagsDirty(false);
  }, [flash]);
  useEffect(() => { load(); }, [load]);
  // A remembered group can become invalid (e.g. WooCommerce after Woo is deactivated);
  // fall back to General so the dropdown never shows a blank selection.
  useEffect(() => {
    if (loading) return;
    const valid = group === 'custom-tags' || groups.some(g => g[0] === group);
    if (!valid) { setGroup('general'); try { localStorage.setItem('ve_bricks_settings_group', 'general'); } catch (e) {} }
  }, [loading, wooActive]);

  // Normalize each option source to {value,label} with string values (backend coerces).
  const optionsFor = (src) => {
    if (src === 'post_types') return (ctx.post_types || []).map(p => ({ value: String(p.slug), label: p.label }));
    if (src === 'templates') return (ctx.templates || []).map(t => ({ value: String(t.id), label: t.title }));
    if (src === 'roles') return (ctx.roles || []).map(r => ({ value: String(r.slug), label: r.label }));
    return [];
  };

  const groups = BRICKS_SETTINGS_GROUPS.filter(g => g[0] !== 'woocommerce' || wooActive);
  const setVal = (k, v) => { setValues(prev => ({ ...prev, [k]: v })); setDirty(true); };

  const save = async () => {
    setSaving(true);
    const payload = {};
    BRICKS_SETTINGS_GROUPS.forEach(g => g[2].forEach(f => {
      if (BRICKS_LIVE_TYPES.indexOf(f.t) === -1) return;
      let v = values[f.k];
      if (f.t === 'toggle') v = !!v;
      else if (f.t === 'multiselect') v = Array.isArray(v) ? v : [];
      else if (f.t === 'number') v = (v === '' || v == null) ? '' : v;
      else v = v == null ? '' : v;
      payload[f.k] = v;
    }));
    try {
      const res = await api.p('bricks-settings', { values: payload });
      flash('Saved ' + ((res && res.saved != null) ? res.saved : '') + ' Bricks settings.');
      setDirty(false);
    } catch (e) {
      flash('Save failed: ' + ((e && e.message) || 'error'));
    }
    setSaving(false);
  };

  const doRegen = async () => {
    setRegenBusy(true);
    try { await api.p('bricks-settings/regenerate-css', {}); flash('Bricks CSS files regenerated.'); }
    catch (e) { flash('Regenerate failed: ' + ((e && e.message) || 'external-files mode may be off')); }
    setRegenBusy(false);
  };

  const normTag = t => String(t || '').toLowerCase().trim().replace(/[^a-z0-9-]/g, '');
  const addTags = raw => {
    const parts = String(raw || '').split(/[\s,]+/).map(normTag).filter(Boolean);
    if (!parts.length) return;
    setCustomTags(prev => { const next = prev.slice(); parts.forEach(p => { if (next.indexOf(p) === -1) next.push(p); }); return next; });
    setTagDraft(''); setTagsDirty(true);
  };
  const removeTag = t => { setCustomTags(prev => prev.filter(x => x !== t)); setTagsDirty(true); };
  const saveTags = async () => {
    setSaving(true);
    try {
      const res = await api.p('bricks-settings/custom-tags', { tags: customTags });
      setCustomTags(Array.isArray(res && res.tags) ? res.tags : customTags);
      flash('Saved custom HTML tags.'); setTagsDirty(false);
    } catch (e) { flash('Save failed: ' + ((e && e.message) || 'error')); }
    setSaving(false);
  };

  const inbricks = (label) => h('span', { style: 'font-size:12px;color:#8a8a8a;font-style:italic' }, label || 'Manage in Bricks');
  const dangerBadge = h('span', { style: 'font-size:9px;font-weight:800;text-transform:uppercase;letter-spacing:.04em;color:#ff8f8f;border:1px solid rgba(255,107,107,.35);border-radius:5px;padding:1px 6px;margin-left:7px;vertical-align:middle' }, 'caution');
  const titleEl = (f) => h('div', { style: 'font-size:13px;color:#e8e8e8;font-weight:600' }, f.n, f.danger ? dangerBadge : null);
  const descEl = (f) => showDescriptions&&f.h ? h('div', { style: 'font-size:12px;color:#9a9a9a;line-height:1.55;margin-top:5px' }, f.h) : null;
  const rowWrap = 'padding:13px 2px;border-top:1px solid rgba(255,255,255,.06)';
  const ctlFor = (f) => {
    if (f.t === 'toggle') return h(ToggleControl, { checked: !!values[f.k], onChange: v => setVal(f.k, v) });
    if (f.t === 'select') return h(SelectMenu, { value: values[f.k] != null ? String(values[f.k]) : (f.o[0] ? f.o[0][0] : ''), onChange: v => setVal(f.k, v), options: f.o.map(o => ({ value: o[0], label: o[1] })) });
    if (f.t === 'text' || f.t === 'password') return h('input', { type: f.t === 'password' ? 'password' : 'text', value: values[f.k] != null ? values[f.k] : '', placeholder: f.ph || (f.t === 'password' ? '••••••••' : ''), onInput: e => setVal(f.k, e.target.value), style: 'height:32px;background:rgba(0,0,0,.28);border:1px solid rgba(255,255,255,.1);border-radius:8px;color:#f0f0f0;font:inherit;font-size:12px;padding:0 11px;width:180px;max-width:180px' });
    if (f.t === 'number') return h('div', { style: 'display:flex;align-items:stretch;background:rgba(0,0,0,.28);border:1px solid rgba(255,255,255,.1);border-radius:8px;overflow:hidden;width:118px' },
      h('input', { type: 'number', value: values[f.k] != null ? values[f.k] : '', onInput: e => setVal(f.k, e.target.value), style: 'border:0;background:transparent;color:#f0f0f0;font:inherit;font-size:12px;padding:0 9px;height:32px;width:100%;text-align:right' }),
      f.u ? h('span', { style: 'display:grid;place-items:center;padding:0 10px;font-size:11px;color:#8a8a8a;background:rgba(255,255,255,.03);border-left:1px solid rgba(255,255,255,.1)' }, f.u) : null);
    return inbricks();
  };

  // #35/#45: CSS fields mount the shared editor with suggestions; script
  // fields reuse it with the vendored HTML/XML/JavaScript mixed mode.
  const isCssField = k => k === 'customCss';
  const codeEditor = (f, full) => h('div', { class: full ? 've-bricks-cm-full' : 've-bricks-cm-inline' },
    h(CssEditor, isCssField(f.k)
      ? { value: values[f.k] != null ? values[f.k] : '', onChange: v => setVal(f.k, v), vars: [], scss: false }
      : { value: values[f.k] != null ? values[f.k] : '', onChange: v => setVal(f.k, v), vars: [], scss: false, mode: 'htmlmixed', noHints: true }));

  const rowFor = (f) => {
    if (f.t === 'sitevis') return h('div', { key: f.k, style: 'background:rgba(186,244,0,.06);border:1px solid rgba(186,244,0,.2);border-radius:10px;padding:14px 15px;font-size:12.5px;color:#cfe89a;line-height:1.55;margin-top:12px' },
      'Maintenance mode lives in MV as ', h('b', null, 'Site Visibility'), ' — Live / Coming soon / Maintenance, bypass roles, excluded posts, and a preview URL.',
      h('div', { style: 'margin-top:10px' }, h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: () => { try { window.dispatchEvent(new CustomEvent('ve-open-site-visibility')); } catch (e) {} } }, 'Open Site Visibility →')));

    if (f.t === 'code') {
      const popped = popoutKey === f.k;
      return h('div', { key: f.k, style: rowWrap },
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:10px' },
          titleEl(f),
          h('span', { title: 'Pop out into a side panel', onClick: () => setPopoutKey(f.k),
            style: 'width:26px;height:26px;border-radius:7px;display:grid;place-items:center;color:#baf400;background:rgba(186,244,0,.08);border:1px solid rgba(186,244,0,.35);cursor:pointer;flex:0 0 auto;font-size:14px' }, '⤢')),
        descEl(f),
        popped
          ? h('div', { style: 'margin-top:9px;padding:16px;border:1px dashed rgba(186,244,0,.3);border-radius:9px;color:#9a9a9a;font-size:11.5px;text-align:center' }, 'Open in the side panel — edit it there')
          : codeEditor(f, false));
    }

    if (f.t === 'multiselect') {
      const opts = optionsFor(f.src);
      const sel = Array.isArray(values[f.k]) ? values[f.k].map(String) : [];
      const labelFor = v => { const o = opts.find(o => o.value === String(v)); return o ? o.label : String(v); };
      const remaining = opts.filter(o => sel.indexOf(o.value) === -1);
      return h('div', { key: f.k, style: rowWrap },
        titleEl(f), descEl(f),
        h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px;align-items:center;margin-top:10px' },
          sel.length ? sel.map(v => h('span', { key: v, style: 'font-size:11.5px;font-weight:600;color:#cfe89a;background:rgba(186,244,0,.1);border:1px solid rgba(186,244,0,.3);border-radius:999px;padding:5px 11px;display:inline-flex;align-items:center;gap:7px' }, labelFor(v), h('span', { style: 'cursor:pointer;opacity:.6;font-size:12px', onClick: () => setVal(f.k, sel.filter(x => x !== String(v))) }, '✕'))) : h('span', { style: 'font-size:12px;color:#7a7a7a' }, 'None selected'),
          remaining.length ? h('div', { style: 'min-width:150px' }, h(SelectMenu, { value: '', onChange: v => { if (v) setVal(f.k, sel.concat([String(v)])); }, options: [{ value: '', label: '+ add…' }].concat(remaining) })) : null));
    }

    if (f.t === 'regen') return h('div', { key: f.k, style: rowWrap },
      h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:12px' }, titleEl(f),
        h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', disabled: regenBusy, onClick: doRegen }, regenBusy ? 'Working…' : 'Regenerate')),
      descEl(f));

    // Compact controls: title + control on one line, full description beneath.
    const live = BRICKS_LIVE_TYPES.indexOf(f.t) !== -1;
    const control = live ? ctlFor(f) : inbricks(f.t === 'inbricks' ? 'In Bricks →' : '');
    return h('div', { key: f.k, style: rowWrap },
      h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:12px' },
        h('div', { style: 'min-width:0;flex:1' }, titleEl(f)),
        h('div', { style: 'flex:0 0 auto;display:flex;align-items:center' }, control)),
      descEl(f));
  };

  const term = q.trim().toLowerCase();
  let visibleRows;
  if (term) {
    visibleRows = [];
    groups.forEach(g => {
      const matches = g[2].filter(f => (f.n + ' ' + (f.h || '') + ' ' + f.k).toLowerCase().includes(term));
      if (matches.length) { visibleRows.push(h('div', { key: 'h-' + g[0], style: 'font-size:10px;font-weight:800;letter-spacing:.07em;text-transform:uppercase;color:#6f6f6f;margin:12px 0 2px' }, g[1])); matches.forEach(f => visibleRows.push(rowFor(f))); }
    });
    if (!visibleRows.length) visibleRows = [h('div', { key: 'none', style: 'color:#6f6f6f;text-align:center;padding:32px 8px' }, 'No settings match "' + q + '"')];
  } else {
    const g = groups.find(x => x[0] === group) || groups[0];
    const sections=bricksSettingsSections(g);
    const activeSection=openSettingsSection||sections[0]?.[0]||'';
    if(g[0]==='custom-code'){
      // #35: Custom Code is an editing workspace, not a settings accordion.
      // Keep Execution, Styles and Scripts visible so every editor and action is
      // reachable by the panel's normal scrollbar.
      visibleRows=sections.map(([label,fields])=>h('section',{class:'ve-bricks-settings-section open static',key:g[0]+'-'+label},
        h('div',{class:'ve-bricks-settings-section-head'},h('span',null,label)),
        h('div',{class:'ve-bricks-settings-section-body'},fields.map(rowFor))
      ));
    }else{
      visibleRows=sections.map(([label,fields])=>h('section',{class:'ve-bricks-settings-section'+(activeSection===label?' open':''),key:g[0]+'-'+label},
        h('button',{type:'button',class:'ve-bricks-settings-section-head',onClick:()=>setOpenSettingsSection(activeSection===label?'':label)},
          h('span',null,label),
          h('span',{class:'ve-bricks-settings-section-count'},fields.length),
          ph(activeSection===label?'caret-down':'caret-right')),
        activeSection===label&&h('div',{class:'ve-bricks-settings-section-body'},fields.map(rowFor))
      ));
    }
  }

  const onCustom = group === 'custom-tags';
  const curDirty = onCustom ? tagsDirty : dirty;
  const onSave = onCustom ? saveTags : save;
  saveRef.current = onSave;
  const suggestedTags = ['picture', 'source', 'dialog', 'details', 'summary', 'audio', 'video', 'track', 'figure', 'figcaption', 'time', 'mark', 'abbr', 'template'];
  const tagsUI = h('div', { style: 'padding:6px 2px' },
    h('div', { style: 'font-size:13px;color:#e8e8e8;font-weight:600;margin:6px 0 4px' }, 'Custom allowed HTML tags'),
    h('div', { style: 'font-size:12px;color:#9a9a9a;line-height:1.55;margin-bottom:13px' }, 'Tags added here are merged into Bricks through the ', h('code', { style: 'color:#cbe89a;font-size:11px' }, 'bricks/allowed_html_tags'), ' filter, so they are no longer stripped from code elements and raw HTML. Use lowercase names; hyphens are allowed for custom elements.'),
    h('div', { style: 'display:flex;gap:7px;margin-bottom:12px' },
      h('input', { type: 'text', value: tagDraft, placeholder: 'e.g. picture, source, dialog', onInput: e => setTagDraft(e.target.value), onKeyDown: e => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); addTags(tagDraft); } }, style: 'flex:1;height:34px;background:rgba(0,0,0,.24);border:1px solid rgba(255,255,255,.08);border-radius:6px;color:#f0f0f0;font:inherit;font-size:12px;padding:0 12px' }),
      h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: () => addTags(tagDraft) }, 'Add')),
    customTags.length
      ? h('div', { style: 'display:flex;flex-wrap:wrap;gap:7px;margin-bottom:16px' },
          customTags.map(t => h('span', { key: t, style: 'display:inline-flex;align-items:center;gap:5px;font-size:12px;font-weight:600;color:#dfffa0;background:rgba(186,244,0,.1);border:1px solid rgba(186,244,0,.3);border-radius:999px;padding:4px 5px 4px 11px' }, '<' + t + '>', h('button', { type: 'button', title: 'Remove', onClick: () => removeTag(t), style: 'border:0;background:transparent;color:#baf400;cursor:pointer;font-size:15px;line-height:1;padding:0 3px' }, '×'))))
      : h('div', { style: 'color:#6f6f6f;font-size:12px;margin-bottom:16px' }, 'No custom tags yet — Bricks defaults still apply.'),
    h('div', { style: 'font-size:10px;font-weight:800;letter-spacing:.06em;text-transform:uppercase;color:#6f6f6f;margin:2px 0 8px' }, 'Common additions'),
    h('div', { style: 'display:flex;flex-wrap:wrap;gap:6px' },
      suggestedTags.filter(t => customTags.indexOf(t) === -1).map(t => h('button', { key: t, class: 've-tag-suggest', type: 'button', title: 'Add <' + t + '>', onClick: () => addTags(t) }, h('span', { class: 'p' }, '+'), t))));
  const popField = popoutKey ? BRICKS_SETTINGS_GROUPS.reduce((a, g) => a.concat(g[2]), []).find(f => f.k === popoutKey) : null;
  useEffect(() => {
    if (!popoutKey) return;
    const onKey = e => { if ((e.metaKey || e.ctrlKey) && (e.key === 's' || e.key === 'S')) { e.preventDefault(); if (saveRef.current) saveRef.current(); } };
    window.addEventListener('keydown', onKey, true);
    return () => window.removeEventListener('keydown', onKey, true);
  }, [popoutKey]);
  useLayoutEffect(() => {
    if (!popoutKey) return;
    const position = () => {
      const el = document.querySelector('.ve-standalone-panel[data-panel="bricks_settings"]');
      if (el && el.getBoundingClientRect) {
        const r = el.getBoundingClientRect();
        setPopLeft(Math.max(66, Math.round(r.left - 410 - 12)));
      }
    };
    position();
    window.addEventListener('resize', position);
    window.addEventListener('pointerup', position, true);
    return () => {
      window.removeEventListener('resize', position);
      window.removeEventListener('pointerup', position, true);
    };
  }, [popoutKey]);
  useEffect(() => {
    document.body.classList.toggle('ve-code-popout-open', !!popoutKey);
    if (popoutKey) document.body.style.setProperty('--ve-code-popout-left', popLeft + 'px');
    else document.body.style.removeProperty('--ve-code-popout-left');
    return () => {
      document.body.classList.remove('ve-code-popout-open');
      document.body.style.removeProperty('--ve-code-popout-left');
    };
  }, [popoutKey, popLeft]);

  return h('div', { style: 'display:flex;flex-direction:column;height:100%' },
    h('div', { style: 'padding:10px 13px 9px;border-bottom:1px solid rgba(255,255,255,.05);display:flex;flex-direction:column;gap:8px;flex:0 0 auto' },
      h(SelectMenu, { value: group, onChange: v => { setGroup(v); try { localStorage.setItem('ve_bricks_settings_group', v); } catch (e) {} setQ(''); setOpenSettingsSection(''); }, options: groups.map(g => ({ value: g[0], label: g[1] + '  (' + g[2].length + ')' })).concat([{ value: 'custom-tags', label: 'Custom HTML tags' }]) }),
      h('input', { type: 'text', value: q, placeholder: 'Search all Bricks settings…', onInput: e => setQ(e.target.value), style: 'width:100%;height:32px;background:rgba(0,0,0,.24);border:1px solid rgba(255,255,255,.08);border-radius:9px;color:#f0f0f0;font:inherit;font-size:12px;padding:0 12px' }),
      !onCustom && h('label',{class:'ve-bricks-settings-descriptions'},h(ToggleControl,{checked:showDescriptions,onChange:setShowDescriptions}),'Show descriptions')),
    h('div', { style: 'flex:1;overflow-y:auto;padding:4px 13px 16px' }, loading ? h('div', { style: 'color:#6f6f6f;text-align:center;padding:40px 8px' }, 'Loading Bricks settings…') : (onCustom ? tagsUI : visibleRows)),
    h('div', { style: 'flex:0 0 auto;border-top:1px solid rgba(255,255,255,.08);background:#171717;padding:10px 13px;display:flex;align-items:center;gap:9px' },
      h('span', { style: 'flex:1;font-size:11px;color:#8a8a8a;display:flex;align-items:center;gap:6px;visibility:' + (curDirty ? 'visible' : 'hidden') }, h('span', { style: 'width:7px;height:7px;border-radius:50%;background:#f0b429;box-shadow:0 0 0 3px rgba(240,180,41,.15)' }), 'Unsaved changes'),
      h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', disabled: saving, onClick: load }, 'Reset'),
      h('button', { class: 've-btn ve-btn-s', type: 'button', disabled: saving || !curDirty, onClick: onSave }, saving ? 'Saving…' : 'Save changes')),
    popField && h('div', { class: 've-code-popout', style: 'left:' + popLeft + 'px' },
      h('div', { class: 'cph' },
        h('span', { class: 't' }, popField.n),
        h('span', { class: 'ico', title: 'Dock back into Settings', onClick: () => setPopoutKey(null) }, '⧉')),
      h('div', { class: 'cpb' }, codeEditor(popField, true)),
      h('div', { class: 'cpf' },
        h('span', { style: 'width:7px;height:7px;border-radius:50%;flex:0 0 auto;background:' + (dirty ? '#f0b429' : '#4a4a4a') }),
        dirty ? 'Unsaved' : 'Saved', ' — press ', h('kbd', null, '⌘/Ctrl'), '+', h('kbd', null, 'S'), ' to save')));
}

/* PluginStudioSub -> assets/js/studios.js (v1.3.519) */

/* ── Unified Settings sub-panel ───────────────── */
const SETTINGS_TRANSFER_GROUPS=[
  {id:'mv_core',product:'mv',label:'Core settings'},
  {id:'mv_modules',product:'mv',label:'Modules & surfaces'},
  {id:'mv_bar',product:'mv',label:"Mimam's Bar"},
  {id:'mv_studio',product:'mv',label:'Studio preferences'},
  {id:'bricks_site',product:'bricks',label:'Site settings'},
  {id:'bricks_classes',product:'bricks',label:'Global classes'},
  {id:'bricks_variables',product:'bricks',label:'Global variables'},
  {id:'bricks_theme_styles',product:'bricks',label:'Theme styles'},
  {id:'bricks_global_elements',product:'bricks',label:'Global elements'}
];

const SETTINGS_PANEL_TABS=['general','visibility','updates','bar','shortcuts','transfer','studio','modules','media'];
// Modules whose hover tooltips are suppressed. Shared between the Settings switches and
// the global tooltip engine, which live in different components.
function readTooltipsOff(){
  try{return String(localStorage.getItem('ve_tooltips_off')||'').split(',').filter(Boolean);}catch(e){return[];}
}
const SETTINGS_PANEL_SESSION_KEY='ve_settings_active_tab';
function loadSettingsPanelTab(){
  try{
    const stored=sessionStorage.getItem(SETTINGS_PANEL_SESSION_KEY);
    return SETTINGS_PANEL_TABS.includes(stored)?stored:'general';
  }catch(e){return'general';}
}
function loadPanelBarSettings(){
  if(window.MimamsBarSettings){
    const loaded=window.MimamsBarSettings.load();
    if(loaded&&typeof loaded==='object')return{...loaded};
  }
  try{
    const raw=localStorage.getItem('mimamsBarSettings')||localStorage.getItem('mimamsBarSettingsBackup');
    if(raw){
      const parsed=JSON.parse(raw);
      if(parsed&&typeof parsed==='object'&&!Array.isArray(parsed))return parsed;
    }
  }catch(e){}
  const remote=CFG.userPreferences?.mimamsBarSettings;
  return remote&&typeof remote==='object'&&!Array.isArray(remote)?{...remote}:{};
}

function UnifiedSettingsPanel({ onClose, panelMode, setPanelMode, onModuleStateChange }) {
  const [activeTab, setActiveTab] = useState(loadSettingsPanelTab);
  const [tooltipsOff, setTooltipsOff] = useState(readTooltipsOff);
  const toggleModuleTooltips = id => {
    setTooltipsOff(prev => {
      const next = prev.includes(id) ? prev.filter(x => x !== id) : prev.concat(id);
      persistUserPreference('ve_tooltips_off', next.join(','));
      try { window.dispatchEvent(new CustomEvent('ve-tooltips-off-changed', { detail: next })); } catch (e) {}
      return next;
    });
  };
  const [s, sS] = useState({ vw_min: 320, vw_max: 1440, delete_on_uninstall: false, update_url: '', update_channel: 'stable', auto_update: false, license_server_url: '', license: {}, deactivated_tools: [], deactivated_tool_surfaces: { admin: [], builder: [] }, allow_multi_panels: false, show_all_tab: true, media_replace_wp_library: false, media_auto_sync_external_folders: false, output_unit: 'rem10' });
  const moduleSettingsRef = useRef(s);
  const moduleSettingsRevisionRef = useRef(0);
  useEffect(() => { moduleSettingsRef.current = s; }, [s]);
  const [lk, sLk] = useState('');
  // Backdrop-behind-panels controls (#18). Writes localStorage + user meta and fires
  // ve-backdrop-changed so the live panels re-apply immediately.
  const [backdropInt, setBackdropInt] = useState(() => { const v = localStorage.getItem('ve_backdrop_intensity'); return ['blur', 'soft', 'dim', 'none'].indexOf(v) !== -1 ? v : 'blur'; });
  const [backdropOffList, setBackdropOffList] = useState(() => { try { const a = JSON.parse(localStorage.getItem('ve_backdrop_off') || '["variables","settings"]'); return Array.isArray(a) ? a : ['variables', 'settings']; } catch (e) { return ['variables', 'settings']; } });
  const applyBackdropInt = v => { setBackdropInt(v); persistUserPreference('ve_backdrop_intensity', v); window.dispatchEvent(new CustomEvent('ve-backdrop-changed')); };
  const toggleBackdropMod = id => setBackdropOffList(prev => { const next = prev.indexOf(id) !== -1 ? prev.filter(x => x !== id) : [...prev, id]; persistUserPreference('ve_backdrop_off', JSON.stringify(next)); window.dispatchEvent(new CustomEvent('ve-backdrop-changed')); return next; });
  const [upd, sUpd] = useState(null);
  const [ck, sCk] = useState(false);
  const [updateBusy, setUpdateBusy] = useState(false);
  const [updateBusyVersion, setUpdateBusyVersion] = useState('');
  const [rollbackConfirm, setRollbackConfirm] = useState('');
  const [updateError, setUpdateError] = useState('');
  const [licBusy, sLicBusy] = useState('');
  const [ld, sLd] = useState(true);
  const [barContext,setBarContext]=useState(MODE==='builder'?'builder':'admin');
  const [versionCopied,setVersionCopied]=useState(false);
  const [transferMode,setTransferMode]=useState('export');
  const [transferSelection,setTransferSelection]=useState(()=>Object.fromEntries(SETTINGS_TRANSFER_GROUPS.map(group=>[group.id,true])));
  const [transferBundle,setTransferBundle]=useState(null);
  const [transferFileName,setTransferFileName]=useState('');
  const [transferPreview,setTransferPreview]=useState(null);
  const [transferBusy,setTransferBusy]=useState(false);
  const [transferError,setTransferError]=useState('');
  const [transferSuccess,setTransferSuccess]=useState('');
  const [transferConfirm,setTransferConfirm]=useState(false);
  const [transferDropActive,setTransferDropActive]=useState(false);
  const [transferInspected,setTransferInspected]=useState(false);
  const transferFileRef=useRef(null);
  const transferDropDepth=useRef(0);

  const surfaceKey = MODE === 'builder' ? 'builder' : 'admin';
  const normalizeModuleSettings = value => {
    const next = { ...(value || {}) };
    const surfaces = normalizeToolSurfaces(next.deactivated_tool_surfaces);
    const legacy = Array.isArray(next.deactivated_tools) ? next.deactivated_tools : [];
    const legacyWithoutSurfaceChoice = legacy.filter(id => !hasToolSurfaceChoice(id, surfaces));
    next.deactivated_tool_surfaces = {
      admin: [...new Set([...surfaces.admin, ...legacyWithoutSurfaceChoice])],
      builder: [...new Set([...surfaces.builder, ...legacyWithoutSurfaceChoice])]
    };
    next.deactivated_tools = [];
    return next;
  };
  // #19 Output units: how bare-number / px dimension tokens are expressed in variables.css
  // and exports. Values are authored in px-equivalent terms; the unit is chosen here.
  const OUTPUT_UNITS = [['rem10', 'rem', '1rem = 10px'], ['rem16', 'rem', '1rem = 16px'], ['px', 'px', 'as authored'], ['raw', 'raw', 'no unit']];
  const OUTPUT_UNIT_DETAILS = {
    rem10: ['rem · 10px base', '16px becomes 1.6rem'],
    rem16: ['rem · 16px base', '16px becomes 1rem'],
    px: ['Pixels', '16 stays 16px'],
    raw: ['Unitless', '16 stays 16']
  };
  const fmtOutputUnit = (px, unit) => {
    const t = n => String(+(+n).toFixed(4));
    switch (unit) {
      case 'rem16': return t(px / 16) + 'rem';
      case 'px': return t(px) + 'px';
      case 'raw': return t(px);
      default: return t(px / 10) + 'rem';
    }
  };
  // Bulk "convert existing tokens" — its own unit picker; rewrites every stored
  // dimension value and adopts that unit as the default.
  const [reconvertUnit, setReconvertUnit] = useState('');
  const [reconvertBusy, setReconvertBusy] = useState(false);
  const [reconvertMsg, setReconvertMsg] = useState('');
  const [reconvertReview, setReconvertReview] = useState(false);
  const doReconvert = async () => {
    const u = reconvertUnit || s.output_unit || 'rem10';
    setReconvertBusy(true); setReconvertMsg('');
    try {
      const r = await api.p('variables/reconvert-units', { unit: u });
      sS(v => ({ ...v, output_unit: u }));
      setReconvertMsg('Converted ' + (r && r.converted != null ? r.converted : 0) + ' token' + ((r && r.converted) === 1 ? '' : 's') + '.');
      setReconvertReview(false);
      try { builderRuntimeWindows().forEach(win => { try { win.dispatchEvent(new win.CustomEvent('ve-variables-changed')); } catch (e) {} }); } catch (e) {}
    } catch (e) {
      setReconvertMsg('Error: ' + ((e && e.message) || 'conversion failed'));
    }
    setReconvertBusy(false);
  };
  const legacyDeactivated = id => Array.isArray(s.deactivated_tools) && s.deactivated_tools.includes(id);
  const isDeactivatedOn = (id, side = surfaceKey) => {
    const surfaces = normalizeToolSurfaces(s.deactivated_tool_surfaces);
    return (!hasToolSurfaceChoice(id, surfaces) && legacyDeactivated(id)) || surfaces[side]?.includes(id);
  };
  const isDeactivated = id => isDeactivatedOn(id, surfaceKey);
  const activeDisabledListForSide = (side, settings = s) => disabledToolsForSurface(settings,side);

  const persistModuleRuntimeState = updated => {
    const surfaces=normalizeToolSurfaces(updated.deactivated_tool_surfaces);
    try{
      localStorage.setItem('ve_deactivated_tools','[]');
      localStorage.setItem('ve_deactivated_tool_surfaces',JSON.stringify(surfaces));
    }catch(e){}
    // Send the complete snapshot instead of guessing whether every discovered frame
    // is Admin or Builder. Each MV runtime knows its own MODE and derives its own list.
    // This keeps a Builder toggle from leaking into Admin and still updates both
    // surfaces immediately when they are open at the same time.
    const detail={deactivated_tools:[],deactivated_tool_surfaces:surfaces,source_surface:surfaceKey};
    // The Settings panel and Studio rail are separate Preact state owners. Update
    // the owning runtime directly before broadcasting to sibling frames so the
    // rail cannot wait for an event/storage round trip or a later server response.
    if(typeof onModuleStateChange==='function')onModuleStateChange(detail);
    let dispatchedToSelf = false;
    builderRuntimeWindows().forEach(win=>{
      if(win===window)dispatchedToSelf=true;
      try{win.dispatchEvent(new win.CustomEvent('ve-deactivated-tools-changed',{detail}));}catch(e){}
    });
    if(!dispatchedToSelf){
      try{window.dispatchEvent(new CustomEvent('ve-deactivated-tools-changed',{detail}));}catch(e){}
    }
  };

  const toggleDeactivated = (id, side = surfaceKey, enabled) => {
    const normalized=normalizeModuleSettings(moduleSettingsRef.current);
    const surfaces = normalizeToolSurfaces(normalized.deactivated_tool_surfaces);
    const currentlyOff = surfaces[side].includes(id);
    const shouldBeOff=typeof enabled==='boolean'?!enabled:!currentlyOff;
    if(shouldBeOff===currentlyOff)return;
    const nextSurfaces = {
      admin: [...surfaces.admin],
      builder: [...surfaces.builder]
    };
    if (shouldBeOff) {
      nextSurfaces[side] = [...new Set([...nextSurfaces[side], id])];
    } else {
      nextSurfaces[side] = nextSurfaces[side].filter(x => x !== id);
    }
    const updated={...normalized,deactivated_tools:[],deactivated_tool_surfaces:nextSurfaces};
    const toggleRevision=++moduleSettingsRevisionRef.current;
    moduleSettingsRef.current=updated;
    sS(updated);
    persistModuleRuntimeState(updated);
    // Save only the changed surface/module pair. The server applies this patch
    // against its latest option so an Admin window can never overwrite a newer
    // Builder rail choice (or vice versa) with a stale full settings snapshot.
    api.p('settings',{deactivated_tool_surface_patch:{surface:side,module:id,disabled:shouldBeOff}}).then(result=>{
      if(result?.code){
        api.g('settings').then(server=>{
          if(!server||server.code||toggleRevision!==moduleSettingsRevisionRef.current)return;
          const restored=normalizeModuleSettings(server);
          moduleSettingsRef.current=restored;
          sS(restored);persistModuleRuntimeState(restored);
        });
        try{window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:result.message||'The module setting could not be saved.'}));}catch(e){}
        return;
      }
      if(result&&toggleRevision===moduleSettingsRevisionRef.current){
        const reconciled=normalizeModuleSettings(result);
        moduleSettingsRef.current=reconciled;
        sS(reconciled);
        persistModuleRuntimeState(reconciled);
      }
      if(id==='recovery'&&side==='admin'&&!shouldBeOff){
        const installPromise=installRecoveryRuntime(result?.recovery_runtime);
        recoveryRuntimePromise=installPromise;
        installPromise.then(panel=>{
          try{window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:'Recovery is ready.'}));}catch(e){}
          return panel;
        }).catch(error=>{
          if(recoveryRuntimePromise===installPromise)recoveryRuntimePromise=null;
          try{window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:error?.message||'Recovery could not be loaded.'}));}catch(e){}
        });
      }
    });
  };

  const updateSetting = (key, value, eventName) => {
    sS(prev => {
      const next = { ...prev, [key]: value };
      api.p('settings', { [key]: value });
      if (eventName) {
        try { window.dispatchEvent(new CustomEvent(eventName, { detail: value })); } catch(e) {}
        builderRuntimeWindows().forEach(win => {
          try { win.dispatchEvent(new win.CustomEvent(eventName, { detail: value })); } catch(e) {}
        });
      }
      return next;
    });
  };

  // CSS Studio settings states
  const{
    scss:cssScss,
    setScss:setCssScss,
    sourceOrder:cssSourceOrder,
    setSourceOrder:setCssSourceOrder,
    disabledSources:cssDisabledSources,
    setDisabledSources:setCssDisabledSources
  }=useCssStudioPreferences();
  const [cssSourceMeta, setCssSourceMeta] = useState({});
  const [cssDragSource, setCssDragSource] = useState('');
  const [cssDropHint, setCssDropHint] = useState(null);
  const [cssRemoteSuggestions, setCssRemoteSuggestions] = useState({ variables: [], classes: [], ids: [], sources: [] });
  const [cssIndexMsg, setCssIndexMsg] = useState('');
  const [cssIndexBusy, setCssIndexBusy] = useState(false);

  // Mimam's Bar settings state (mirrored from its runtime or persisted user preference).
  const [barSettings, setBarSettings] = useState(loadPanelBarSettings);

  const [folderData, setFolderData] = useState({ folders: [], map: {} });
  const [localCollections, setLocalCollections] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('ve_media_collections') || '{}');
    } catch(e) {
      return {};
    }
  });
  const [hideFolders, setHideFoldersState] = useState(() => localStorage.getItem('ve_media_hide_folders') === 'true');
  const [settingsCollapsedPaths, setSettingsCollapsedPaths] = useState(loadMediaCollapsedPaths);
  const [fabOrder, setFabOrder] = useState(readFabOrder);
  const [contentStudioDefaultTheme, setContentStudioDefaultTheme] = useState(() => { try { return localStorage.getItem('ve_content_studio_default_theme') || 'dark'; } catch (e) { return 'dark'; } });
  const [contentStudioDefaultView, setContentStudioDefaultView] = useState(() => { try { return localStorage.getItem('ve_content_studio_default_view') || 'normal'; } catch (e) { return 'normal'; } });
  const [mediaStudioDefaultView, setMediaStudioDefaultView] = useState(() => { try { return localStorage.getItem('ve_media_studio_default_view') || 'normal'; } catch (e) { return 'normal'; } });
  const [mediaAsBricksPicker, setMediaAsBricksPicker] = useState(() => { try { return localStorage.getItem('ve_media_as_bricks_picker') !== '0'; } catch (e) { return true; } });
  const [showMigrateConfirm, setShowMigrateConfirm] = useState(false);
  const [migrationStatus, setMigrationStatus] = useState('');
  const [visibility,setVisibility]=useState({mode:'live',template:0,templates:[],bypass_policy:'logged_in',bypass_roles:[],roles:[],render_header:false,render_footer:false,render_popups:false,excluded:[],site_url:'',preview_key:'bypass',preview_url:'',preview_enabled:false,bricks_available:true});
  const [visibilityLoading,setVisibilityLoading]=useState(true);
  const [visibilityBusy,setVisibilityBusy]=useState(false);
  const [visibilityStatus,setVisibilityStatus]=useState('');
  // Compact dirty flag for the footer — the old long status string clipped the Close button.
  const [visibilityDirty,setVisibilityDirty]=useState(false);
  const [visibilityQuery,setVisibilityQuery]=useState('');
  const [visibilityResults,setVisibilityResults]=useState([]);
  const [visibilitySearching,setVisibilitySearching]=useState(false);
  const [visibilityCopied,setVisibilityCopied]=useState(false);
  const [savedAttrName,setSavedAttrName]=useState('');
  const [savedAttrValue,setSavedAttrValue]=useState('');
  const [savedAttrEditing,setSavedAttrEditing]=useState('');
  const [savedAttrBulk,setSavedAttrBulk]=useState('');
  const [savedAttrBusy,setSavedAttrBusy]=useState(false);
  const [savedAttrStatus,setSavedAttrStatus]=useState('');

  const settingToggleRow = (key, label, checked, onChange) => h('div', { class: 've-opt ve-opt-toggle', key },
    h('span', null, label),
    h(ToggleControl, { checked: !!checked, label, onChange })
  );

  const settingRow=(key,label,description,control)=>h('div',{class:'ve-setting-row',key},
    h('div',{class:'ve-setting-label'},h('strong',null,label),description&&h('span',null,description)),
    h('div',{class:'ve-setting-control'},control)
  );
  const settingToggle=(key,label,description,checked,onChange)=>settingRow(key,label,description,h(ToggleControl,{checked:!!checked,label,onChange}));
  const settingSection=(key,title,description,children,action=null)=>h('section',{class:'ve-settings-section',key,id:'ve-settings-section-'+key,'data-settings-section':key},
    h('div',{class:'ve-settings-section-head'},h('div',null,h('div',{class:'ve-settings-section-title'},title),h('div',{class:'ve-settings-section-desc'},description)),action),
    children
  );
  const settingSegmented=(value,onChange,options)=>h('div',{class:'ve-setting-segmented'},options.map(option=>h('button',{type:'button',key:option.value,class:value===option.value?'on':'',onClick:()=>onChange(option.value)},option.label)));
  const saveStudioDefault=(key,value,setter)=>{setter(value);persistUserPreference(key,value);};
  const selectSettingsTab=id=>{
    setActiveTab(id);
    try{sessionStorage.setItem(SETTINGS_PANEL_SESSION_KEY,id);}catch(e){}
  };
  const focusSettingsSection=(key,attempt=0)=>{
    const section=document.getElementById('ve-settings-section-'+key);
    if(!section){
      if(attempt<12)setTimeout(()=>focusSettingsSection(key,attempt+1),55);
      return;
    }
    try{sessionStorage.removeItem('ve_settings_focus_section');}catch(e){}
    section.scrollIntoView({behavior:'smooth',block:'start'});
    section.classList.add('is-targeted');
    setTimeout(()=>section.classList.remove('is-targeted'),1400);
    const input=section.querySelector('input,textarea,button');
    if(input&&input.focus)setTimeout(()=>input.focus({preventScroll:true}),260);
  };
  useEffect(()=>{
    const selectTab=event=>{
      const id=String(event?.detail||'');
      if(SETTINGS_PANEL_TABS.includes(id))selectSettingsTab(id);
    };
    const syncSaved=event=>{
      if(Array.isArray(event?.detail))sS(prev=>({...prev,saved_attributes:event.detail}));
    };
    const focusSection=event=>{
      const key=String(event?.detail||'');
      if(!key)return;
      try{sessionStorage.setItem('ve_settings_focus_section',key);}catch(e){}
      if(key.indexOf('bar-')===0)selectSettingsTab('bar');
      setTimeout(()=>focusSettingsSection(key),80);
    };
    window.addEventListener('ve-settings-select-tab',selectTab);
    window.addEventListener('ve-settings-focus-section',focusSection);
    window.addEventListener('ve-saved-attributes-changed',syncSaved);
    return()=>{
      window.removeEventListener('ve-settings-select-tab',selectTab);
      window.removeEventListener('ve-settings-focus-section',focusSection);
      window.removeEventListener('ve-saved-attributes-changed',syncSaved);
    };
  },[]);
  useEffect(()=>{
    let key='';
    try{key=sessionStorage.getItem('ve_settings_focus_section')||'';}catch(e){}
    if(!key)return;
    if(key.indexOf('bar-')===0&&activeTab!=='bar'){selectSettingsTab('bar');return;}
    setTimeout(()=>focusSettingsSection(key),40);
  },[activeTab]);

  useEffect(() => {
    const startedAtRevision=moduleSettingsRevisionRef.current;
    api.g('settings').then(d => {
      if (d && !d.code && startedAtRevision===moduleSettingsRevisionRef.current) {
        const loaded={...moduleSettingsRef.current,...normalizeModuleSettings(d)};
        moduleSettingsRef.current=loaded;
        sS(loaded);
      }
      sLd(false);
    }).catch(() => sLd(false));

    api.g('media-studio/folders').then(d => {
      if (d && !d.code) {
        setFolderData({ folders: d.folders || [], map: d.map || {} });
      }
    }).catch(() => {});

    api.g('advanced-css/suggestions').then(d => {
      if (d && !d.code) {
        setCssRemoteSuggestions(d);
        const next = normalizeSourceOrder(cssSourceOrder, d.sources || []);
        setCssSourceOrder(next);
        persistUserPreference('ve_css_source_order', next);
        const m = {};
        (d.sources || []).forEach(x => {
          m[x] = x === "Mimam's Var" ? 'Active' : 'Detected';
        });
        setCssSourceMeta(prev => ({ ...prev, ...m }));
        if (d.counts) {
          setCssIndexMsg('Index: ' + d.counts.variables + ' variables · ' + d.counts.classes + ' classes · ' + d.counts.ids + ' IDs · ' + (d.counts.selectors || 0) + ' selectors' + (d.cached ? ' (cached)' : ''));
        }
      }
    }).catch(() => {});

    api.g('migration/sources').then(d => {
      if (Array.isArray(d)) {
        const m = {};
        d.forEach(x => {
          m[x.name] = x.available ? 'Detected' : 'Not found';
          if (x.name === 'Bricks / Advanced Themer') {
            m.Bricks = x.available ? 'Detected' : 'Not found';
            m['Advanced Themer'] = x.available ? 'Detected' : 'Not found';
          }
        });
        setCssSourceMeta(prev => ({ ...prev, ...m }));
      }
    }).catch(() => {});

    const handleMediaCollectionsMigrated = () => {
      try {
        const saved = localStorage.getItem('ve_media_collections');
        setLocalCollections(saved ? JSON.parse(saved) : {});
      } catch (e) {}
    };
    const handleMediaCollectionsChanged = e => {
      if (e && e.detail && typeof e.detail === 'object') {
        setLocalCollections(e.detail);
        return;
      }
      handleMediaCollectionsMigrated();
    };
    const handleMediaCollapsedPathsChanged = e => {
      if (e && e.detail && typeof e.detail === 'object') {
        setSettingsCollapsedPaths(e.detail);
      } else {
        setSettingsCollapsedPaths(loadMediaCollapsedPaths());
      }
    };
    const handleSettingsUpdated = e => {
      if (e && e.detail && typeof e.detail === 'object') {
        sS(v => {
          const next={...v,...normalizeModuleSettings(e.detail)};
          moduleSettingsRef.current=next;
          return next;
        });
      }
    };
    window.addEventListener('ve-media-collections-migrated', handleMediaCollectionsMigrated);
    window.addEventListener('ve-media-collections-changed', handleMediaCollectionsChanged);
    window.addEventListener('ve-media-collapsed-paths-changed', handleMediaCollapsedPathsChanged);
    window.addEventListener('ve-settings-updated', handleSettingsUpdated);
    return () => {
      window.removeEventListener('ve-media-collections-migrated', handleMediaCollectionsMigrated);
      window.removeEventListener('ve-media-collections-changed', handleMediaCollectionsChanged);
      window.removeEventListener('ve-media-collapsed-paths-changed', handleMediaCollapsedPathsChanged);
      window.removeEventListener('ve-settings-updated', handleSettingsUpdated);
    };
  }, []);

  useEffect(()=>{
    api.g('site-visibility').then(data=>{
      if(data&&!data.code)setVisibility(data);
      else setVisibilityStatus(data?.message||'Site visibility could not be loaded.');
    }).catch(()=>setVisibilityStatus('Site visibility could not be loaded.')).finally(()=>setVisibilityLoading(false));
  },[]);

  useEffect(()=>{
    const query=visibilityQuery.trim();
    if(!query){setVisibilityResults([]);setVisibilitySearching(false);return;}
    setVisibilitySearching(true);
    const timer=setTimeout(()=>{
      api.g('site-visibility/content?q='+encodeURIComponent(query)).then(data=>{
        const selected=new Set((visibility.excluded||[]).map(item=>Number(item.id)));
        setVisibilityResults((data?.items||[]).filter(item=>!selected.has(Number(item.id))));
      }).catch(()=>setVisibilityResults([])).finally(()=>setVisibilitySearching(false));
    },220);
    return()=>clearTimeout(timer);
  },[visibilityQuery,visibility.excluded]);

  const changeVisibility=(key,value)=>{
    setVisibility(prev=>({...prev,[key]:value}));
    setVisibilityDirty(true);
  };
  const generatedVisibilityUrl=()=>{
    const base=String(visibility.site_url||'').replace(/\/+$/,'');
    const key=String(visibility.preview_key||'');
    return base+(base.includes('?')?'&':'?')+'preview_key='+encodeURIComponent(key);
  };
  const saveVisibility=async()=>{
    setVisibilityBusy(true);setVisibilityStatus('');
    try{
      const payload={
        mode:visibility.mode,
        template:Number(visibility.template||0),
        bypass_policy:visibility.bypass_policy,
        bypass_roles:Array.isArray(visibility.bypass_roles)?visibility.bypass_roles:[],
        render_header:!!visibility.render_header,
        render_footer:!!visibility.render_footer,
        render_popups:!!visibility.render_popups,
        excluded:(visibility.excluded||[]).map(item=>Number(item.id)),
        preview_key:String(visibility.preview_key||''),
        preview_enabled:!!visibility.preview_enabled
      };
      const data=await api.p('site-visibility',payload);
      if(data?.code)throw new Error(data.message||'Visibility settings could not be saved.');
      setVisibility(data);
      // Announce the outcome as a toast — the footer strip is too narrow for it and
      // was squeezing the Close button.
      const okMessage=data.mode==='live'?'Site is live.':'Visibility and preview access saved.';
      setVisibilityStatus('');setVisibilityDirty(false);
      try{window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:okMessage}));}catch(e){}
    }catch(error){
      const failMessage=error?.message||'Visibility settings could not be saved.';
      setVisibilityStatus('');
      try{window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:failMessage}));}catch(e){}
    }
    finally{setVisibilityBusy(false);}
  };
  const copyVisibilityUrl=async()=>{
    const value=generatedVisibilityUrl();
    try{await navigator.clipboard.writeText(value);}catch(error){
      const helper=document.createElement('textarea');helper.value=value;helper.style.position='fixed';helper.style.opacity='0';document.body.appendChild(helper);helper.select();document.execCommand('copy');helper.remove();
    }
    setVisibilityCopied(true);setTimeout(()=>setVisibilityCopied(false),1300);
  };

  const normalizeSavedAttributes=list=>{
    const next=[];
    (Array.isArray(list)?list:[]).forEach(item=>{
      const name=String(item?.name||'').trim();
      if(!/^[A-Za-z_:][A-Za-z0-9:._-]*$/.test(name))return;
      const clean={name,value:String(item?.value??'').trim().slice(0,500)};
      const index=next.findIndex(current=>current.name===name);
      if(index>=0)next[index]=clean;
      else if(next.length<100)next.push(clean);
    });
    return next;
  };
  const persistSavedAttributes=async(next,message)=>{
    next=normalizeSavedAttributes(next);
    setSavedAttrBusy(true);setSavedAttrStatus('');
    try{
      const result=await api.p('settings',{saved_attributes:next});
      if(result?.code)throw new Error(result.message||'Saved attributes could not be updated.');
      const saved=normalizeSavedAttributes(result?.saved_attributes||next);
      sS(prev=>({...prev,...result,saved_attributes:saved}));
      builderRuntimeWindows().forEach(win=>{try{win.dispatchEvent(new win.CustomEvent('ve-saved-attributes-changed',{detail:saved}));}catch(e){}});
      setSavedAttrStatus(message||'Saved attributes updated.');
      return true;
    }catch(error){setSavedAttrStatus(error?.message||'Saved attributes could not be updated.');return false;}
    finally{setSavedAttrBusy(false);}
  };
  const saveOneAttribute=async()=>{
    const name=String(savedAttrName||'').trim();
    if(!/^[A-Za-z_:][A-Za-z0-9:._-]*$/.test(name)){setSavedAttrStatus('Enter a valid attribute name.');return;}
    const current=normalizeSavedAttributes(s.saved_attributes);
    const withoutEdited=current.filter(item=>item.name!==savedAttrEditing&&item.name!==name);
    const ok=await persistSavedAttributes([...withoutEdited,{name,value:String(savedAttrValue||'').trim()}],name+' saved for this site.');
    if(ok){setSavedAttrName('');setSavedAttrValue('');setSavedAttrEditing('');}
  };
  const editSavedAttribute=item=>{
    setSavedAttrEditing(item.name);setSavedAttrName(item.name);setSavedAttrValue(item.value||'');setSavedAttrStatus('Editing '+item.name+'.');
    setTimeout(()=>{
      const section=document.getElementById('ve-settings-section-bar-saved-attributes');
      const card=section?.querySelector('.ve-attr-library-card');
      if(!card)return;
      card.scrollIntoView({behavior:'smooth',block:'start'});
      card.classList.add('is-targeted');
      setTimeout(()=>card.classList.remove('is-targeted'),1400);
      const input=card.querySelector('input');
      if(input&&input.focus)setTimeout(()=>{input.focus({preventScroll:true});input.select&&input.select();},240);
    },40);
  };
  const removeSavedAttribute=async name=>{
    const next=normalizeSavedAttributes(s.saved_attributes).filter(item=>item.name!==name);
    const ok=await persistSavedAttributes(next,name+' removed.');
    if(ok&&savedAttrEditing===name){setSavedAttrEditing('');setSavedAttrName('');setSavedAttrValue('');}
  };
  const importSavedAttributes=async()=>{
    let valid=0;
    const imported=[];
    String(savedAttrBulk||'').split(/\r?\n/).forEach(line=>{
      const match=line.trim().match(/^([^\s=]+)(?:\s*=\s*(?:"([^"]*)"|'([^']*)'|(.+)))?$/);
      if(!match)return;
      const name=String(match[1]||'').trim();
      if(!/^[A-Za-z_:][A-Za-z0-9:._-]*$/.test(name))return;
      imported.push({name,value:match[2]!==undefined?match[2]:(match[3]!==undefined?match[3]:(match[4]||''))});
      valid++;
    });
    if(!valid){setSavedAttrStatus('Paste at least one valid attribute line.');return;}
    const ok=await persistSavedAttributes([...normalizeSavedAttributes(s.saved_attributes),...imported],valid+' saved attribute'+(valid===1?'':'s')+' imported.');
    if(ok)setSavedAttrBulk('');
  };

  const setScss = v => {
    setCssScss(v);
    persistUserPreference('ve_css_scss', v ? '1' : '0');
    window.dispatchEvent(new CustomEvent('ve-css-settings-changed'));
  };

  const toggleSource = x => {
    setCssDisabledSources(a => {
      const n = a.includes(x) ? a.filter(y => y !== x) : [...a, x];
      persistUserPreference('ve_css_disabled_sources', n);
      window.dispatchEvent(new CustomEvent('ve-css-settings-changed'));
      return n;
    });
  };

  const persistSources = (a, validSources) => {
    const next = normalizeSourceOrder(a, validSources || cssRemoteSuggestions.sources || []);
    setCssSourceOrder(next);
    persistUserPreference('ve_css_source_order', next);
    window.dispatchEvent(new CustomEvent('ve-css-settings-changed'));
  };

  const refreshIndex = async () => {
    setCssIndexBusy(true);
    setCssIndexMsg('Rebuilding index...');
    const d = await api.g('advanced-css/suggestions?refresh=1');
    setCssIndexBusy(false);
    if (!d || d.code) {
      setCssIndexMsg(d?.message || 'Index refresh failed');
      return;
    }
    setCssRemoteSuggestions(d);
    const next = normalizeSourceOrder(cssSourceOrder, d.sources || []);
    setCssSourceOrder(next);
    persistUserPreference('ve_css_source_order', next);
    const m = {};
    (d.sources || []).forEach(x => {
      m[x] = x === "Mimam's Var" ? 'Active' : 'Detected';
    });
    setCssSourceMeta(prev => ({ ...prev, ...m }));
    setCssIndexMsg('Index refreshed: ' + (d.counts?.variables || 0) + ' variables · ' + (d.counts?.classes || 0) + ' classes · ' + (d.counts?.ids || 0) + ' IDs · ' + (d.counts?.selectors || 0) + ' selectors');
  };

  const dropSource = () => {
    if (!cssDragSource || !cssDropHint) return;
    const drag = cssDragSource;
    setCssDragSource('');
    const a = cssSourceOrder.filter(x => x !== drag);
    let idx = a.indexOf(cssDropHint.target);
    if (idx < 0) idx = a.length;
    if (cssDropHint.pos === 'after') idx++;
    a.splice(idx, 0, drag);
    persistSources(a);
    setCssDropHint(null);
  };

  const updateBarSetting = (key, value) => {
    const next = { ...(barSettings || {}), [key]: value };
    if (window.MimamsBarSettings) {
      window.MimamsBarSettings.set(key, value);
      setBarSettings({ ...window.MimamsBarSettings.data });
      return;
    }
    try {
      if (window.localStorage) {
        window.localStorage.setItem('mimamsBarSettings', JSON.stringify(next));
        window.localStorage.setItem('mimamsBarSettingsBackup', JSON.stringify(next));
      }
    } catch (e) {}
    try {
      if (window.vePersistUserPreference) window.vePersistUserPreference('mimamsBarSettings', next);
    } catch (e) {}
    setBarSettings(next);
  };

  const updateBarSettings = patch => {
    const next={...(barSettings||{}),...patch};
    if(window.MimamsBarSettings){
      if(!window.MimamsBarSettings.data)window.MimamsBarSettings.load();
      Object.assign(window.MimamsBarSettings.data,patch);
      window.MimamsBarSettings.save();
      setBarSettings({...window.MimamsBarSettings.data});
      return;
    }
    try{
      localStorage.setItem('mimamsBarSettings',JSON.stringify(next));
      localStorage.setItem('mimamsBarSettingsBackup',JSON.stringify(next));
    }catch(e){}
    if(window.vePersistUserPreference)window.vePersistUserPreference('mimamsBarSettings',next);
    setBarSettings(next);
  };

  const barPanelPlacement=side=>{
    const cap=side==='elements'?'Elements':'Structure';
    if(barSettings['float'+cap])return'float';
    if(barSettings['hide'+cap])return'hide';
    return'dock';
  };
  const setBarPanelPlacement=(side,value)=>{
    const cap=side==='elements'?'Elements':'Structure';
    updateBarSettings({['float'+cap]:value==='float',['hide'+cap]:value==='hide'});
  };

  const selectedTransferGroups=()=>SETTINGS_TRANSFER_GROUPS.filter(group=>{
    if(!transferSelection[group.id])return false;
    return !transferBundle||!!transferBundle.groups?.[group.id];
  }).map(group=>group.id);
  const setTransferGroup=(id,checked)=>{
    setTransferSelection(prev=>({...prev,[id]:checked}));
    setTransferPreview(null);setTransferConfirm(false);setTransferSuccess('');
  };
  const setTransferProduct=(product,checked)=>{
    setTransferSelection(prev=>{
      const next={...prev};
      SETTINGS_TRANSFER_GROUPS.filter(group=>group.product===product).forEach(group=>{
        if(!transferBundle||transferBundle.groups?.[group.id])next[group.id]=checked;
      });
      return next;
    });
    setTransferPreview(null);setTransferConfirm(false);setTransferSuccess('');
  };
  const transferProductChecked=product=>{
    const available=SETTINGS_TRANSFER_GROUPS.filter(group=>group.product===product&&(!transferBundle||transferBundle.groups?.[group.id]));
    return available.length>0&&available.every(group=>!!transferSelection[group.id]);
  };
  const resetTransferMessages=()=>{setTransferError('');setTransferSuccess('');setTransferConfirm(false);};

  const exportSettings=async()=>{
    const groups=selectedTransferGroups();
    if(!groups.length){setTransferError('Choose at least one settings group to export.');return;}
    resetTransferMessages();setTransferBusy(true);
    await api.p('user-preferences',{preferences:collectUserPreferences()});
    const result=await api.p('settings-transfer/export',{groups});
    setTransferBusy(false);
    if(result?.code||!result?.bundle){setTransferError(result?.message||'The settings package could not be created.');return;}
    const blob=new Blob([JSON.stringify(result.bundle,null,2)],{type:'application/json'});
    const url=URL.createObjectURL(blob);
    const anchor=document.createElement('a');
    const now=new Date();
    const timestamp=now.toISOString().replace(/[-:]/g,'').replace('T','-').slice(0,13);
    const site=safeFilePart(CFG.siteTitle||window.location.hostname,'site');
    anchor.href=url;anchor.download='mimams-settings-'+site+'-'+timestamp+'.json';
    document.body.appendChild(anchor);anchor.click();anchor.remove();URL.revokeObjectURL(url);
    setTransferSuccess(groups.length+' settings group(s) exported. Licenses and secrets were excluded.');
  };

  const loadTransferFile=async file=>{
    if(!file)return;
    resetTransferMessages();setTransferPreview(null);setTransferBundle(null);setTransferInspected(false);setTransferFileName(file.name||'settings.json');
    try{
      const parsed=JSON.parse(await file.text());
      if(!parsed||parsed.product!=='mimams-var-settings'||!parsed.groups||typeof parsed.groups!=='object')throw new Error("This is not a Mimam's Var settings package.");
      const next=Object.fromEntries(SETTINGS_TRANSFER_GROUPS.map(group=>[group.id,!!parsed.groups[group.id]]));
      setTransferSelection(next);setTransferBundle(parsed);
      await reviewSettingsImport(parsed,Object.keys(parsed.groups).filter(id=>SETTINGS_TRANSFER_GROUPS.some(group=>group.id===id)));
    }catch(error){
      setTransferFileName('');setTransferBundle(null);setTransferInspected(false);setTransferError(error?.message||'The selected JSON file could not be read.');
    }
  };
  const chooseTransferFile=async event=>{
    await loadTransferFile(event.target.files?.[0]);
    event.target.value='';
  };
  const transferDragEnter=event=>{event.preventDefault();transferDropDepth.current+=1;setTransferDropActive(true);};
  const transferDragOver=event=>{event.preventDefault();if(event.dataTransfer)event.dataTransfer.dropEffect='copy';setTransferDropActive(true);};
  const transferDragLeave=event=>{event.preventDefault();transferDropDepth.current=Math.max(0,transferDropDepth.current-1);if(!transferDropDepth.current)setTransferDropActive(false);};
  const transferDrop=async event=>{event.preventDefault();transferDropDepth.current=0;setTransferDropActive(false);await loadTransferFile(event.dataTransfer?.files?.[0]);};

  const reviewSettingsImport=async(bundleOverride=null,groupsOverride=null)=>{
    const bundle=bundleOverride||transferBundle;
    if(!bundle){setTransferError('Choose a settings package first.');return;}
    const groups=groupsOverride||selectedTransferGroups();
    if(!groups.length){setTransferError('Choose at least one available settings group.');return;}
    resetTransferMessages();setTransferBusy(true);
    const result=await api.p('settings-transfer/preview',{bundle,groups});
    setTransferBusy(false);
    if(result?.code){setTransferError(result.message||'The settings package could not be reviewed.');return;}
    setTransferPreview(result);setTransferInspected(true);
  };

  const applySettingsImport=async()=>{
    if(!transferBundle||!transferPreview?.fingerprint)return;
    resetTransferMessages();setTransferBusy(true);
    const result=await api.p('settings-transfer/apply',{bundle:transferBundle,groups:selectedTransferGroups(),fingerprint:transferPreview.fingerprint});
    setTransferBusy(false);
    if(result?.code){setTransferError(result.message||'The settings package could not be imported.');return;}
    setTransferSuccess(result.message||'Settings imported. Reload this surface to use them.');
    setTransferConfirm(false);
    if(transferBundle.groups?.mv_bar?.preferences?.mimamsBarSettings){
      const restored=transferBundle.groups.mv_bar.preferences.mimamsBarSettings;
      try{localStorage.setItem('mimamsBarSettings',JSON.stringify(restored));localStorage.setItem('mimamsBarSettingsBackup',JSON.stringify(restored));}catch(e){}
      setBarSettings(restored);
    }
    if(selectedTransferGroups().includes('mv_modules')&&transferBundle.groups?.mv_modules?.settings){
      const restored=normalizeModuleSettings({...s,...transferBundle.groups.mv_modules.settings});
      sS(restored);persistModuleRuntimeState(restored);
    }
  };

  const copySettingsVersion=async()=>{
    try{await navigator.clipboard.writeText(String(CFG.version||''));}catch(e){}
    setVersionCopied(true);setTimeout(()=>setVersionCopied(false),1200);
  };

  const check = async () => {
    sCk(true);
    try {
      const r = await api.p('update/check', {});
      sUpd(r);
    } catch (error) {
      const currentVersion = CFG.version || '';
      sUpd({ configured:false, code:'ve_update_check_failed', message:error?.message||'Update check failed.', update_channel:s.update_channel||'stable', current_version:currentVersion, latest_version:currentVersion, update_available:false });
    } finally {
      sCk(false);
    }
  };
  useEffect(() => {
    let active = true;
    sCk(true);
    api.p('update/check', {}).then(result => {
      if (active) sUpd(result);
    }).catch(error => {
      if (!active) return;
      const currentVersion = CFG.version || '';
      sUpd({ configured:false, code:'ve_update_check_failed', message:error?.message||'Update check failed.', update_channel:s.update_channel||'stable', current_version:currentVersion, latest_version:currentVersion, update_available:false });
    }).finally(() => {
      if (active) sCk(false);
    });
    return () => { active = false; };
  }, []);
  const installUpdate = async (version) => {
    const targetVersion = version || upd?.latest_version || '';
    setUpdateBusy(true);
    setUpdateBusyVersion(targetVersion);
    setUpdateError('');
    try {
      const result = await installPanelUpdate(targetVersion);
      setRollbackConfirm('');
      sUpd(previous => {
        if (!previous) return previous;
        const nextVersion = result.version || previous.current_version || previous.latest_version || CFG.version || '';
        const latestVersion = previous.latest_version || nextVersion;
        const canUpdateAgain = !!result.rollback && !!latestVersion && latestVersion !== nextVersion;
        return { ...previous, update_available: canUpdateAgain, current_version: nextVersion, message: result.message || (result.rollback ? 'Rollback installed. Refresh required.' : 'Update installed. Refresh required.') };
      });
    } catch (error) {
      setUpdateError(error?.message || 'Update failed.');
    } finally {
      setUpdateBusy(false);
      setUpdateBusyVersion('');
    }
  };
  const setLicense = r => sS(v => ({ ...v, license: r || {} }));
  const saveSettingsOnly = async () => {
    const r = await api.p('settings', s);
    sS(v => ({ ...v, ...r }));
    return r;
  };
  const activateLic = async () => {
    sLicBusy('activate');
    await saveSettingsOnly();
    const r = await api.p('license/activate', { license_key: lk });
    setLicense(r);
    sLk('');
    sLicBusy('');
  };
  const checkLic = async () => {
    sLicBusy('check');
    await saveSettingsOnly();
    const r = await api.p('license/check', {});
    setLicense(r);
    sLicBusy('');
  };
  const deactivateLic = async () => {
    sLicBusy('deactivate');
    const r = await api.p('license/deactivate', {});
    setLicense(r);
    sLicBusy('');
  };

  if (ld) return h('div', { class: 've-empty' }, 'Loading...');

  const lic = s.license || {};
  const licLabel = (lic.status || 'inactive').replace(/^\w/, m => m.toUpperCase());
  const releaseHistory = Array.isArray(upd?.release_history) ? upd.release_history : (Array.isArray(upd?.releases) ? upd.releases : []);
  const updateHosts = Array.isArray(upd?.error_details?.hosts) ? upd.error_details.hosts : [];
  const updateBlocked = !!upd?.code && (/feed|http|blocked|unreachable/i).test(String(upd.code || upd.message || ''));
  const compareVersions = (a, b) => {
    const pa = String(a || '0').split('.').map(n => parseInt(n, 10) || 0);
    const pb = String(b || '0').split('.').map(n => parseInt(n, 10) || 0);
    const max = Math.max(pa.length, pb.length);
    for (let i = 0; i < max; i++) {
      const diff = (pa[i] || 0) - (pb[i] || 0);
      if (diff) return diff;
    }
    return 0;
  };
  const renderReleaseManager = () => {
    const current = upd?.current_version || CFG.version || '';
    const latest = upd?.latest_version || (releaseHistory[0] && releaseHistory[0].version) || current;
    let rollbackRows = 0;
    const visibleReleaseHistory = releaseHistory.filter(release => {
      const version = release.version || '';
      const isRollback = version && compareVersions(version, current) < 0;
      if (!isRollback) return true;
      rollbackRows += 1;
      return rollbackRows <= 4;
    });
    return h('div', { class: 've-release-manager', key: 'release-manager' },
      h('div', { class: 've-release-head' },
        h('span', null, 'Release manager'),
        h('span', { class: 've-release-channel' }, upd?.update_channel || s.update_channel || 'stable')
      ),
      !releaseHistory.length && h('div', { class: 've-release-empty' }, ck ? 'Loading releases for the selected channel...' : 'No release history is available for this channel.'),
      releaseHistory.length > 0 && visibleReleaseHistory.map(release => {
        const version = release.version || '';
        const isCurrent = version && !compareVersions(version, current);
        const isLatest = version && !compareVersions(version, latest);
        // The pending latest build is already presented by the Check-update block above,
        // so listing it again here is a duplicate card. Installed/rollback rows still show.
        if (isLatest && !isCurrent) return null;
        const isRollback = version && compareVersions(version, current) < 0;
        const isBusy = updateBusy && updateBusyVersion === version;
        return h('div', { class: 've-release-row', key: 'rel-' + version },
          h('div', { style: 'min-width:0' },
            h('div', { class: 've-release-title' },
              h('span', null, release.label || ('v' + version)),
              isCurrent && h('span', { class: 've-release-pill ve-release-pill-installed' }, 'Installed'),
              !isCurrent && isLatest && h('span', { class: 've-release-pill ve-release-pill-latest' }, 'Latest'),
              isRollback && h('span', { class: 've-release-pill ve-release-pill-rollback' }, 'Rollback')
            ),
            h('div', { class: 've-release-meta' }, version, release.created_at ? ' · ' + release.created_at : '', isRollback ? ' · confirm before installing this older package' : '')
          ),
          h('div', { class: 've-release-actions' },
            release.download_url && h('a', { class: 've-release-link', href: release.download_url, target: '_blank', rel: 'noopener noreferrer', title: 'Download the ZIP package for this release' }, 'Download ZIP'),
            // The "Update to latest" action already lives in the Check-update block above;
            // repeating it on the Latest row read as a duplicate control.
            !isCurrent && !isRollback && !isLatest && h('button', { class: 've-btn ve-btn-s', disabled: updateBusy, onClick: () => installUpdate(version) }, isBusy ? 'Updating…' : 'Update'),
            !isCurrent && isRollback && h('button', { class: 've-btn ve-btn-s', disabled: updateBusy, onClick: () => setRollbackConfirm(version) }, rollbackConfirm === version ? 'Reviewing…' : 'Rollback')
          ),
          rollbackConfirm === version && h('div', { class: 've-release-confirm' },
            h('b', null, 'Rollback to v' + version + '?'),
            h('span', null, 'MV will install this selected-channel package through WordPress, restore activation, and ask you to refresh. Use this only when you intentionally want to return to an older tested release.'),
            h('div', { class: 've-release-confirm-actions' },
              h('button', { class: 've-btn', disabled: updateBusy, onClick: () => setRollbackConfirm('') }, 'Cancel'),
              h('button', { class: 've-btn ve-btn-g', disabled: updateBusy, onClick: () => installUpdate(version) }, isBusy ? 'Rolling back…' : 'Confirm rollback')
            )
          )
        );
      })
    );
  };
  const moduleSurfaceCard = (id, label, description, extra) => h('div', { class: 've-module-card', key: 'mod-' + id },
      h('div', null,
        h('div', { class: 've-module-card-title' }, label),
        h('div', { class: 've-module-card-desc' }, description)
      ),
      h('div', { class: 've-module-surface-controls' },
        ['admin', 'builder'].map(side => h('label', { key: id + '-' + side, class: 've-module-surface-toggle' },
          h(ToggleControl, { checked: !isDeactivatedOn(id, side), onChange: enabled => toggleDeactivated(id, side, enabled), title: (isDeactivatedOn(id, side) ? 'Enable ' : 'Disable ') + label + ' on ' + side }),
          side
        ))
      ),
    extra
  );
  const settingsBuildFolderPath = folder => {
    if (!folder) return '';
    const parts = [folder.name];
    let current = folder;
    while (current && current.parent && current.parent !== '0') {
      const parent = (folderData.folders || []).find(f => String(f.id) === String(current.parent));
      if (!parent) break;
      parts.unshift(parent.name);
      current = parent;
    }
    return parts.join(' / ');
  };
  const settingsFolderCount = folderId => {
    return collectFolderMediaIds(folderData, folderId).length;
  };
  const settingsFolderRows = (folderData.folders || [])
    .map(folder => ({ folder, label: settingsBuildFolderPath(folder) }))
    .sort((a, b) => a.label.localeCompare(b.label));
  const settingsPathHidden = label => {
    const parts = label.split(' / ');
    for (let i = 1; i < parts.length; i++) {
      if (settingsCollapsedPaths[parts.slice(0, i).join(' / ')]) return true;
    }
    return false;
  };
  const toggleSettingsFolderPath = label => {
    const next = { ...settingsCollapsedPaths, [label]: !settingsCollapsedPaths[label] };
    setSettingsCollapsedPaths(next);
    persistMediaCollapsedPaths(next);
    window.dispatchEvent(new CustomEvent('ve-media-collapsed-paths-changed', { detail: next }));
  };
  const moveFabTool = (id, dir) => {
    const order = normalizeFabOrder(fabOrder);
    const idx = order.indexOf(id);
    const nextIdx = idx + dir;
    if (idx < 0 || nextIdx < 0 || nextIdx >= order.length) return;
    const next = order.slice();
    [next[idx], next[nextIdx]] = [next[nextIdx], next[idx]];
    setFabOrder(next);
    persistUserPreference('ve_fab_order', next);
    window.dispatchEvent(new CustomEvent('ve-fab-order-changed', { detail: next }));
  };

  const settingsNav = [
    { id: 'general', label: 'General', icon: 'sliders-horizontal' },
    { id: 'visibility', label: 'Site visibility', icon: 'eye' },
    { id: 'updates', label: 'Updates & License', icon: 'arrows-clockwise' },
    { id: 'bar', label: "Mimam's Bar", icon: 'terminal-window' },
    { id: 'shortcuts', label: 'Shortcuts', icon: 'keyboard' },
    { id: 'transfer', label: 'Import & Export', icon: 'arrows-left-right' },
    { id: 'studio', label: 'CSS Studio', icon: 'brackets-curly' },
    { id: 'modules', label: 'Modules', icon: 'squares-four' },
    { id: 'media', label: 'Media Studio', icon: 'image' }
  ];

  return h('div', { style: 'display:flex;flex-direction:column;flex:1;min-height:0;box-sizing:border-box' },
    h('div', { class: 've-settings-main' },
      // Left icon rail
      h('div', { class: 've-settings-rail' },
        settingsNav.map(t => h('button', {
          type: 'button',
          key: t.id,
          class: 've-settings-rail-item ve-tip-right' + (activeTab === t.id ? ' on' : ''),
          'aria-label': t.label,
          'data-ve-tip': t.label,
          onClick: () => selectSettingsTab(t.id)
        }, ph(t.icon)))
      ),

    h('div', { class: 've-body ve-settings-content', style: 'flex:1;overflow-y:auto' },
      activeTab === 'visibility' ? [
        visibilityLoading
          ? h('div',{class:'ve-settings-empty',key:'loading'},'Loading Site Visibility…')
          : h('div',{class:'ve-visibility',key:'visibility'},
              !visibility.bricks_available&&h('div',{class:'ve-visibility-status'},'Bricks is not active, so maintenance settings cannot be applied.'),
              h('section',{class:'ve-visibility-card'},
                h('div',{class:'ve-visibility-head'},h('span',{class:'ve-visibility-num'},'01'),h('div',null,h('b',null,'Publishing mode'),h('span',null,'Writes to Bricks’ existing maintenance mode setting.'))),
                h('div',{class:'ve-visibility-modes'},
                  [
                    ['live','Live','Normal site · indexable'],
                    ['coming','Coming soon','HTTP 200 · indexable'],
                    ['maintenance','Maintenance','HTTP 503 · temporary']
                  ].map(option=>h('button',{type:'button',key:option[0],class:'ve-visibility-mode'+(visibility.mode===option[0]?' on':''),onClick:()=>changeVisibility('mode',option[0])},h('b',null,option[1]),h('span',null,option[2])))
                )
              ),
              visibility.mode!=='live'&&h('section',{class:'ve-visibility-card'},
                h('div',{class:'ve-visibility-head'},h('span',{class:'ve-visibility-num'},'02'),h('div',null,h('b',null,'Bricks maintenance page'),h('span',null,'Manage the Bricks template, rendering, and public exclusions here.'))),
                h('div',{class:'ve-visibility-grid'},
                  h('div',{class:'ve-visibility-field'},h('label',{class:'ve-visibility-key'},'Template'),h(SelectMenu,{value:String(visibility.template||0),onChange:value=>changeVisibility('template',Number(value)),options:[{value:'0',label:'Default'},...(visibility.templates||[]).map(item=>({value:String(item.id),label:item.title}))]})),
                  h('div',{class:'ve-visibility-field'},h('label',{class:'ve-visibility-key'},'Bricks bypass policy'),h(SelectMenu,{value:visibility.bypass_policy||'logged_in',onChange:value=>changeVisibility('bypass_policy',value),options:[{value:'logged_in',label:'Logged-in users'},{value:'custom',label:'Logged-in users with role'}]}),h('div',{class:'ve-visibility-help'},visibility.bypass_policy==='custom'?'Only the selected roles bypass; administrators always bypass.':'All logged-in users bypass Bricks maintenance.'))
                ),
                visibility.bypass_policy==='custom'&&h('div',{class:'ve-visibility-role-list'},
                  (visibility.roles||[]).map(role=>h('div',{class:'ve-visibility-switch-row',key:role.slug},
                    h('span',null,role.label),
                    h(ToggleControl,{checked:(visibility.bypass_roles||[]).includes(role.slug),label:role.label,onChange:checked=>changeVisibility('bypass_roles',checked?[...(visibility.bypass_roles||[]),role.slug]:(visibility.bypass_roles||[]).filter(slug=>slug!==role.slug))})
                  ))
                ),
                h('div',{class:'ve-visibility-switches'},
                  [['render_header','Render header'],['render_footer','Render footer'],['render_popups','Render popups']].map(item=>h('div',{class:'ve-visibility-switch-row',key:item[0]},h('span',null,item[1]),h(ToggleControl,{checked:!!visibility[item[0]],label:item[1],onChange:value=>changeVisibility(item[0],value)})))
                ),
                h('div',{class:'ve-visibility-exclude'},
                  h('label',{class:'ve-visibility-key'},'Excluded posts/pages'),
                  h('div',{class:'ve-visibility-help',style:'margin:0 0 6px'},'These URLs remain public while Coming soon or Maintenance is active.'),
                  h('div',{class:'ve-visibility-search'},h('input',{class:'ve-studio-input',value:visibilityQuery,placeholder:'Search posts or pages',onInput:event=>setVisibilityQuery(event.target.value)})),
                  visibilityQuery.trim()&&h('div',{class:'ve-visibility-results'},
                    visibilitySearching?h('div',{class:'ve-settings-empty'},'Searching…')
                    :visibilityResults.length?visibilityResults.map(item=>h('button',{type:'button',class:'ve-visibility-result',key:item.id,onClick:()=>{changeVisibility('excluded',[...(visibility.excluded||[]),item]);setVisibilityQuery('');setVisibilityResults([]);}},item.title,h('span',null,item.type)))
                    :h('div',{class:'ve-settings-empty'},'No matching content.')
                  ),
                  h('div',{class:'ve-visibility-chips'},
                    (visibility.excluded||[]).length
                      ?visibility.excluded.map(item=>h('span',{class:'ve-visibility-chip',key:item.id},h('span',null,item.title),h('button',{type:'button','aria-label':'Remove '+item.title,onClick:()=>changeVisibility('excluded',visibility.excluded.filter(current=>Number(current.id)!==Number(item.id)))},'×')))
                      :h('span',{class:'ve-visibility-help'},'No excluded content.')
                  )
                )
              ),
              visibility.mode!=='live'&&h('section',{class:'ve-visibility-card'+(visibility.preview_enabled?'':' is-disabled')},
                h('div',{class:'ve-visibility-head'},h('span',{class:'ve-visibility-num'},'03'),h('div',null,h('b',null,'Visitor preview access'),h('span',null,'Share a temporary bypass URL without installing a separate PHP snippet.')),h(ToggleControl,{checked:!!visibility.preview_enabled,label:'Visitor preview access',onChange:value=>changeVisibility('preview_enabled',value)})),
                h('div',{class:'ve-visibility-grid'},
                  h('div',{class:'ve-visibility-field'},h('label',{class:'ve-visibility-key'},'Site URL'),h('div',{class:'ve-visibility-origin'},visibility.site_url),h('div',{class:'ve-visibility-help'},'Read from WordPress. Change it under Settings → General.')),
                  h('div',{class:'ve-visibility-field'},h('label',{class:'ve-visibility-key'},'Preview key'),h('input',{class:'ve-studio-input',value:visibility.preview_key||'',autocomplete:'off',disabled:!visibility.preview_enabled,onInput:event=>changeVisibility('preview_key',event.target.value)}),h('div',{class:'ve-visibility-help'},'Letters, numbers, dashes, and underscores.')),
                  h('div',{class:'ve-visibility-field full'},h('label',{class:'ve-visibility-key'},'Generated preview link'),h('div',{class:'ve-visibility-preview-row'},h('output',{class:'ve-visibility-url'},generatedVisibilityUrl()),h('button',{type:'button',class:'ve-btn',disabled:!visibility.preview_enabled,onClick:copyVisibilityUrl},visibilityCopied?'Copied':'Copy URL')))
                ),
                h('div',{class:'ve-visibility-status',style:'margin-top:10px'},visibility.preview_enabled?'Managed by Mimam’s Var · visitors receive a one-hour preview cookie.':'Off by default · turn on to activate preview-key access.')
              )
            )
      ] : activeTab === 'general' ? [
        h('div', { class: 've-viewport-group', key: 'viewport' },
          h('div', { class: 've-viewport-head' },
            h('span', null, 'Viewport range'),
            h('small', null, 'Used by fluid values and generator previews')
          ),
          h('div', { class: 've-viewport-grid' },
            h('label', { class: 've-viewport-field' },
              h('span', { class: 've-viewport-affix' }, 'Min'),
              h('input', { type: 'number', value: s.vw_min, onInput: e => { const val = +e.target.value; sS(v => ({ ...v, vw_min: val })); api.p('settings', { ...s, vw_min: val }); } }),
              h('span', { class: 've-viewport-unit' }, 'px')
            ),
            h('label', { class: 've-viewport-field' },
              h('span', { class: 've-viewport-affix' }, 'Max'),
              h('input', { type: 'number', value: s.vw_max, onInput: e => { const val = +e.target.value; sS(v => ({ ...v, vw_max: val })); api.p('settings', { ...s, vw_max: val }); } }),
              h('span', { class: 've-viewport-unit' }, 'px')
            )
          )
        ),
        (() => {
          const outUnit = s.output_unit || 'rem10';
          const convertUnit = reconvertUnit || outUnit;
          const convertLabel = (OUTPUT_UNIT_DETAILS[convertUnit] || [convertUnit])[0];
          return h('div', { class: 've-viewport-group ve-output-unit-settings', key: 'output-unit', style: 'margin-top:12px' },
            h('div', { class: 've-viewport-head' },
              h('span', null, 'Output unit'),
              h('small', null, 'How dimension tokens are written to variables.css and exports')
            ),
            h('section', { class: 've-output-step' },
              h('div', { class: 've-output-step-head' },
                h('strong', null, 'Default for new tokens'),
                h('span', null, 'Choose how new or edited dimension values are stored.')
              ),
              h('div', { class: 've-output-unit-grid' },
                OUTPUT_UNITS.map(o => {
                  const detail = OUTPUT_UNIT_DETAILS[o[0]] || [o[1], o[2]];
                  return h('button', {
                    key: o[0],
                    type: 'button',
                    class: 've-output-unit-card' + (outUnit === o[0] ? ' on' : ''),
                    onClick: () => { const next = { ...s, output_unit: o[0] }; sS(next); api.p('settings', next); }
                  }, h('strong', null, detail[0]), h('span', null, detail[1]));
                })
              ),
              h('div', { class: 've-output-preview' },
                h('span', null, 'Preview for 16px'),
                h('code', null, '16px → ' + fmtOutputUnit(16, outUnit))
              )
            ),
            h('section', { class: 've-output-step' },
              h('div', { class: 've-output-step-head' },
                h('strong', null, 'Convert existing tokens (optional)'),
                h('span', null, 'This is separate from the default above and rewrites stored values.')
              ),
              h('div', { class: 've-output-convert-controls' },
                h(SelectMenu, {
                  value: convertUnit,
                  onChange: v => { setReconvertUnit(v); setReconvertReview(false); setReconvertMsg(''); },
                  options: OUTPUT_UNITS.map(o => ({ value: o[0], label: (OUTPUT_UNIT_DETAILS[o[0]] || [o[1]])[0] }))
                }),
                h('button', { type: 'button', class: 've-btn ve-btn-g ve-btn-s', disabled: reconvertBusy, onClick: () => setReconvertReview(true) }, 'Review conversion')
              ),
              reconvertReview && h('div', { class: 've-output-review' },
                h('strong', null, 'Convert all clean dimension tokens to ' + convertLabel + '?'),
                h('span', null, 'Complex values such as clamp(), fluid values, percentages, viewport units, and variables will stay unchanged. This also becomes the new default.'),
                h('button', { type: 'button', class: 've-btn ve-btn-s', disabled: reconvertBusy, onClick: doReconvert }, reconvertBusy ? 'Converting…' : 'Convert existing tokens')
              ),
              reconvertMsg && h('div', { class: 've-output-result' + (reconvertMsg.indexOf('Error') === 0 ? ' error' : '') }, reconvertMsg)
            ),
          );
        })(),
        h('div', { class: 've-opt', key: 'del', style: 'margin-top:12px' }, h('span', null, 'Delete all data on uninstall'), h(ToggleControl, { checked: s.delete_on_uninstall, onChange: val => { sS(v => ({ ...v, delete_on_uninstall: val })); api.p('settings', { ...s, delete_on_uninstall: val }); } })),
        h('div', { class: 've-opt', key: 'show-all-tab', style: 'margin-top:12px' }, h('span', null, 'Show "All" tab in variables list'), h(ToggleControl, { checked: typeof s.show_all_tab === 'undefined' ? true : !!s.show_all_tab, onChange: val => { const next = { ...s, show_all_tab: val }; sS(next); api.p('settings', next); builderRuntimeWindows().forEach(win => { try { win.dispatchEvent(new win.CustomEvent('ve-show-all-tab-changed', { detail: val })); } catch(e) { try { win.dispatchEvent(new CustomEvent('ve-show-all-tab-changed', { detail: val })); } catch(err) {} } }); } })),
        h('div', { class: 've-opt ve-opt-stack', key: 'layout', style: 'margin-top:12px' },
          h('span', null, 'Panel layout'),
          h('div', { class: 've-layout-grid' },
            ['right', 'left', 'float'].map(m => h('button', { type: 'button', class: 've-btn ' + (panelMode === m ? '' : 've-btn-g') + ' ve-btn-s', onClick: () => setPanelMode(m) }, m === 'right' ? 'Dock Right' : m === 'left' ? 'Dock Left' : 'Float'))
          ),
          h('div', { style: 'font-size:11px;color:#666;line-height:1.55;margin-top:4px' }, 'Floating panels can be dragged from the header. Layout is saved on this browser.')
        ),
        h('div', { class: 've-opt ve-opt-stack', key: 'multi-panels' },
          h('span', null, 'Panel behavior (single/multiple)'),
          h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:10px;width:100%' }, h('span', { style: 'color:#d4d4d4' }, 'Allow more than one MV panel open at once'), h(ToggleControl, { checked: !!s.allow_multi_panels, onChange: val => { const next = { ...s, allow_multi_panels: val }; sS(next); persistUserPreference('ve_allow_multi_panels', val ? '1' : '0'); builderRuntimeWindows().forEach(win => { try { win.dispatchEvent(new win.CustomEvent('ve-panel-concurrency-changed', { detail: val })); } catch(e) { try { win.dispatchEvent(new CustomEvent('ve-panel-concurrency-changed', { detail: val })); } catch(err) {} } }); api.p('settings', next); } })),
          h('div', { style: 'font-size:11px;color:#777;line-height:1.55;margin-top:4px' }, 'Off keeps one major panel open at a time. On lets Studio panels share the viewport.')
        ),
        settingSection('studio-defaults','Studio defaults','Choose the appearance used each time Content or Media Studio opens.',[
          settingRow('content-default-theme','Content Studio theme','Applied when a content editor or Preview opens.',h(SelectMenu,{value:contentStudioDefaultTheme,onChange:value=>saveStudioDefault('ve_content_studio_default_theme',value,setContentStudioDefaultTheme),options:[{value:'dark',label:'Dark'},{value:'light',label:'Light'}]})),
          settingRow('content-default-view','Content Studio view','The panel can still be changed from its header.',h(SelectMenu,{value:contentStudioDefaultView,onChange:value=>saveStudioDefault('ve_content_studio_default_view',value,setContentStudioDefaultView),options:[{value:'normal',label:'Normal'},{value:'fullscreen',label:'Full screen'}]})),
          settingRow('media-default-view','Media Studio view','The panel can still be changed from its header.',h(SelectMenu,{value:mediaStudioDefaultView,onChange:value=>saveStudioDefault('ve_media_studio_default_view',value,setMediaStudioDefaultView),options:[{value:'normal',label:'Normal'},{value:'fullscreen',label:'Full screen'}]})),
          settingRow('media-as-bricks-picker','Media Studio as Bricks media picker','When on, clicking an image/media control in the Bricks builder opens Media Studio instead of the WordPress media library.',h(ToggleControl,{checked:mediaAsBricksPicker,onChange:val=>{setMediaAsBricksPicker(val);persistUserPreference('ve_media_as_bricks_picker',val?'1':'0');}}))
        ]),
        // Backdrop behind panels (#18)
        h('div', { class: 've-media-settings-card', key: 'backdrop-card', style: 'margin-bottom:12px' },
          h('div', { class: 've-media-settings-head' },
            h('div', null,
              h('div', { class: 've-media-settings-title' }, ph('sliders-horizontal'), 'Backdrop behind panels'),
              h('div', { class: 've-media-settings-desc' }, 'Blur or dim the page behind a studio while it is open. Choose the intensity, then which modules use it.')
            )
          ),
          h('div', { class: 've-seg', style: 'margin:10px 0 12px' },
            [['blur', 'Blur + dim'], ['soft', 'Soft'], ['dim', 'Dim only'], ['none', 'None']].map(o => h('button', {
              key: o[0], type: 'button', class: backdropInt === o[0] ? 'on' : '', onClick: () => applyBackdropInt(o[0])
            }, o[1]))
          ),
          backdropInt !== 'none' && [['content_studio', 'Content Studio'], ['media_studio', 'Media Studio'], ['plugin_studio', 'Plugin Studio'], ['bricks_settings', 'Bricks Settings'], ['theme_styles', 'Theme Styles'], ['css_studio', 'CSS Studio'], ['css_recipes', 'CSS Recipes'], ['font_manager', 'Font Manager'], ['help', 'Documentation']].map(m => h('div', { key: m[0], class: 've-media-settings-action-row' },
            h('span', null, m[1]),
            h(ToggleControl, { checked: backdropOffList.indexOf(m[0]) === -1, onChange: () => toggleBackdropMod(m[0]) })
          )),
          backdropInt === 'none' && h('div', { class: 've-media-settings-desc', style: 'margin-top:2px' }, 'Backdrop is off for every module. Pick an intensity above to enable per-module control.')
        ),
        h('div', { class: 've-opt ve-opt-stack', key: 'tooltips-off' },
          h('span', null, 'Tooltips'),
          h('div', { style: 'font-size:11px;color:#777;line-height:1.55' }, 'Turn hover tooltips off for individual modules once you know your way around.'),
          h('div', { class: 've-tip-mod-list' },
            [{ id: 'shell', label: 'Speed dial & studio rail' }].concat(
              SPEED_DIAL_TOOLS.map(tool => ({ id: tool.id, label: tool.label }))
            ).map(mod => h('div', { class: 've-tip-mod-row', key: mod.id },
              h('span', null, mod.label),
              h(ToggleControl, {
                checked: !tooltipsOff.includes(mod.id),
                onChange: () => toggleModuleTooltips(mod.id)
              })
            ))
          )
        ),
        h('div', { class: 've-opt ve-opt-stack', key: 'fab-order' },
          h('span', null, 'Speed dial icon order'),
          h('div', { style: 'font-size:11px;color:#777;line-height:1.55' }, 'Move tools up or down in the bottom floating hover menu. Module visibility is still controlled in Modules.'),
          h('div', { class: 've-fab-order-list' },
            normalizeFabOrder(fabOrder).map((id, index, arr) => {
              const tool = SPEED_DIAL_TOOLS.find(item => item.id === id);
              if (!tool) return null;
              return h('div', { class: 've-fab-order-row', key: id },
                ph(tool.icon),
                h('span', null, tool.label),
                h('span', { class: 've-fab-order-actions' },
                  h('button', { type: 'button', disabled: index === 0, onClick: () => moveFabTool(id, -1), title: 'Move up' }, ph('caret-up')),
                  h('button', { type: 'button', disabled: index === arr.length - 1, onClick: () => moveFabTool(id, 1), title: 'Move down' }, ph('caret-down'))
                )
              );
            })
          )
        )
      ] : activeTab === 'updates' ? [
        /* Update feed + license server are infrastructure, not user settings. They now
           live in code (VE_UPDATE_FEED_URL / VE_LICENSE_SERVER_URL), overridable from
           wp-config.php, so nobody can break updates or licensing by editing a field. */
        h('div', { class: 've-opt ve-opt-stack', key: 'channel' },
          h('span', null, 'Update channel'),
          h(SelectMenu, { value: s.update_channel || 'stable', onChange: async v => { const next = { ...s, update_channel: v, update_url: '' }; sS(next); setRollbackConfirm(''); await api.p('settings', next); await check(); }, options: [{ value: 'stable', label: 'Stable' }, { value: 'beta', label: 'Beta' }, { value: 'dev', label: 'Dev' }] })
        ),
        h('div', { class: 've-opt', key: 'auto' }, h('span', null, 'Auto-update this plugin'), h(ToggleControl, { checked: !!s.auto_update, onChange: val => { sS(v => ({ ...v, auto_update: val })); api.p('settings', { ...s, auto_update: val }); } })),
        h('div', { class: 've-upd', key: 'upd-row' },
          h('button', { class: 've-btn ve-btn-g', onClick: check, disabled: ck }, ck ? 'Checking...' : 'Check update'),
          upd && h('span', { class: upd.update_available ? 'ok' : 'muted' }, upd.message || 'Checked', upd.latest_version ? ' · ' + upd.latest_version : ''),
          upd?.update_available && h('button', { class: 've-btn ve-btn-s', disabled:updateBusy, onClick:()=>installUpdate() }, updateBusy?'Updating…':'Update'),
          updateError&&h('span',{style:'color:#ff7777;font-size:11px'},updateError)
        ),
        updateBlocked && h('div', { class: 've-update-help', key: 'upd-help' },
          h('b', null, 'Update feed blocked. '),
          'Allow ', updateHosts.length ? updateHosts.join(' and ') : 'the selected update feed host',
          ' in your hosting, firewall, or security-plugin HTTP rules, then run Check update again.'
        ),
        renderReleaseManager(),
        h('div', { key: 'lic-box', style: 'margin-top:8px;padding:11px;border:1px solid rgba(255,255,255,.10);border-radius:8px;background:rgba(255,255,255,.035)' },
          h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px' },
            h('span', { style: 'font-size:11px;font-weight:700;color:#ddd' }, 'License'),
            h('span', { class: lic.active ? 'ok' : 'muted', style: 'font-size:11px' }, licLabel)
          ),
          h('div', { style: 'font-size:11px;color:#888;line-height:1.55;margin-bottom:8px' }, lic.message || 'No license key saved.', lic.key_masked ? ' · ' + lic.key_masked : ''),
          h('div', { style: 'display:flex;gap:6px;align-items:center' },
            h('input', { class: 've-studio-input', type: 'text', value: lk, placeholder: 'License key', onInput: e => sLk(e.target.value), style: 'flex:1;min-width:0;font-size:11px;' }),
            h('button', { class: 've-btn', onClick: activateLic, disabled: !!licBusy || !lk.trim() }, licBusy === 'activate' ? 'Saving...' : 'Activate')
          ),
          h('div', { style: 'display:flex;gap:6px;margin-top:8px' },
            h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: checkLic, disabled: !!licBusy }, licBusy === 'check' ? 'Checking...' : 'Check license'),
            lic.configured && h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: deactivateLic, disabled: !!licBusy }, licBusy === 'deactivate' ? 'Removing...' : 'Deactivate')
)
)

] : activeTab === 'shortcuts' ? [
        settingSection('shortcuts-all','Every shortcut','One page for all of them, each rebindable. Click a key to change it, then press what you want. Amber marks a letter Bricks already answers to \u2014 turning it on anyway means MV takes the letter, so the lone press stops reaching Bricks.',[
          h(ShortcutsSettings,{key:'shortcuts-body'})
        ])
      ] : activeTab === 'bar' ? [
        settingSection('bar-context','Surface defaults','Only this section changes when you switch between Admin and Builder.',[
          h('div',{class:'ve-settings-scope-note',key:'scope-note'},
            h('span',{class:'ve-settings-scope-kicker'},barContext==='admin'?'Editing Admin defaults':'Editing Builder defaults'),
            h('span',null,'All sections below are shared unless they are explicitly labelled Builder-only.')
          ),
          barContext==='admin'
            ? settingRow('bar-admin-mode','Admin mode','Everything is the only Admin mode. Direct, Search Page, and Add Element are Builder-only.',h('div',{class:'ve-setting-lock'},h('b',null,'Everything (0)'),ph('lock-simple')))
            : settingRow('bar-builder-default','Builder default','Used when Builder mode memory is off.',h(SelectMenu,{value:barSettings.defaultModeBuilder||'default',onChange:v=>updateBarSetting('defaultModeBuilder',v),options:[
                {value:'everything',label:'Everything (0)'},{value:'default',label:'Direct (1)'},{value:'elements',label:'Search page (2)'},{value:'add-elements',label:'Add element (3)'}
              ]})),
          barContext==='builder'&&settingToggle('bar-builder-memory','Remember Builder mode','Reopen the last Builder mode instead of the default.',barSettings.rememberLastModeBuilder!==false,val=>updateBarSetting('rememberLastModeBuilder',val))
        ],h('div',{class:'ve-settings-context'},
          h('button',{type:'button',class:barContext==='admin'?'on':'',onClick:()=>setBarContext('admin')},'Admin'),
          h('button',{type:'button',class:barContext==='builder'?'on':'',onClick:()=>setBarContext('builder')},'Builder')
        )),
        h('div',{class:'ve-settings-shared-banner',key:'shared-banner'},ph('link'),h('span',null,h('strong',null,'Shared across Admin + Builder'),'These settings apply everywhere.')),
        settingSection('bar-behavior','Behavior','Keyboard and apply behavior shared by Admin and Builder.',[
          settingRow('bar-shortcut','Open shortcut','Ctrl+K is claimed before other command palettes when selected.',h(SelectMenu,{value:barSettings.shortcut||'ctrl-k',onChange:v=>updateBarSetting('shortcut',v),options:[{value:'ctrl-k',label:'Ctrl + K',group:'Shortcut',icon:'command'},{value:'alt-q',label:'Alt + Q',group:'Shortcut',icon:'option'},{value:'ctrl-alt-a',label:'Ctrl + Alt + A',group:'Shortcut',icon:'keyboard'}]})),
          settingRow('bar-deselect','Deselect shortcut','Clear the active Builder element without closing the Bar.',h(SelectMenu,{value:barSettings.deselectShortcut||'escape',onChange:v=>updateBarSetting('deselectShortcut',v),options:[{value:'escape',label:'Escape',group:'Shortcut',icon:'arrow-bend-up-left'},{value:'shift-d',label:'Shift + D',group:'Shortcut',icon:'arrow-up'},{value:'alt-d',label:'Alt + D',group:'Shortcut',icon:'option'},{value:'none',label:'None',group:'Shortcut',icon:'prohibit'}]})),
          settingToggle('bar-auto-close','Auto-close','Close the Bar after a successful action.',!!barSettings.autoClose,val=>updateBarSetting('autoClose',val)),
          settingToggle('bar-bulk-confirm','Bulk confirmation','Keep a preview before multi-element changes.',!barSettings.skipBulkPreview,val=>updateBarSetting('skipBulkPreview',!val)),
          settingToggle('bar-undocked','Undock Bar','Float Mimam\'s Bar and remember its position.',!!barSettings.undocked,val=>updateBarSetting('undocked',val))
        ]),
        settingSection('bar-saved-attributes','Saved attributes','Frequent names and values appear near the top of Direct suggestions. Shared site-wide across Admin and Builder.',[
          h('div',{class:'ve-attr-library-card',key:'attr-add'},
            h('div',{class:'ve-attr-library-title'},savedAttrEditing?'Edit saved attribute':'Add one attribute'),
            h('div',{class:'ve-attr-library-help'},'Selecting a saved suggestion pre-fills both its name and usual value.'),
            h('div',{class:'ve-attr-library-add'},
              h('input',{class:'ve-studio-input',value:savedAttrName,placeholder:'data-aos','aria-label':'Attribute name',onInput:event=>setSavedAttrName(event.target.value)}),
              h('input',{class:'ve-studio-input',value:savedAttrValue,placeholder:'fade-up','aria-label':'Attribute value',onInput:event=>setSavedAttrValue(event.target.value)}),
              h('button',{type:'button',class:'ve-btn ve-btn-s',disabled:savedAttrBusy,onClick:saveOneAttribute},savedAttrEditing?'Save edit':'Add')
            ),
            savedAttrEditing&&h('button',{type:'button',class:'ve-attr-library-cancel',onClick:()=>{setSavedAttrEditing('');setSavedAttrName('');setSavedAttrValue('');setSavedAttrStatus('');}},'Cancel edit')
          ),
          h('div',{class:'ve-attr-library-card',key:'attr-bulk'},
            h('div',{class:'ve-attr-library-title'},'Bulk paste'),
            h('div',{class:'ve-attr-library-help'},'One attribute per line. Quoted and unquoted values are accepted.'),
            h('textarea',{class:'ve-attr-library-paste',value:savedAttrBulk,placeholder:'data-aos="fade-up"\\ndata-theme=dark\\naria-live="polite"',spellcheck:false,onInput:event=>setSavedAttrBulk(event.target.value)}),
            h('div',{class:'ve-attr-library-actions'},
              h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',disabled:savedAttrBusy||!savedAttrBulk,onClick:()=>setSavedAttrBulk('')},'Clear'),
              h('button',{type:'button',class:'ve-btn ve-btn-s',disabled:savedAttrBusy||!savedAttrBulk.trim(),onClick:importSavedAttributes},savedAttrBusy?'Saving…':'Import lines')
            )
          ),
          h('div',{class:'ve-attr-library-card',key:'attr-list'},
            h('div',{class:'ve-attr-library-title'},'Saved · frequent'),
            h('div',{class:'ve-attr-library-list'},
              normalizeSavedAttributes(s.saved_attributes).length
                ?normalizeSavedAttributes(s.saved_attributes).map(item=>h('div',{class:'ve-attr-library-row',key:item.name},
                    h('span',{class:'ve-attr-library-star'},'★'),
                    h('code',null,item.name+'="'+item.value+'"'),
                    h('span',{class:'ve-attr-library-row-actions'},
                      h('button',{type:'button','aria-label':'Edit '+item.name,title:'Edit',onClick:()=>editSavedAttribute(item)},ph('pencil-simple')),
                      h('button',{type:'button',class:'ve-attr-library-unstar','aria-label':'Unstar '+item.name,title:'Unstar',disabled:savedAttrBusy,onClick:()=>removeSavedAttribute(item.name)},ph('star'))
                    )
                  ))
                :h('div',{class:'ve-attr-library-empty'},'No saved attributes yet. Star one in the Bar or add it above.')
            )
          ),
          savedAttrStatus&&h('div',{class:'ve-attr-library-status'+(/could not|valid|at least/i.test(savedAttrStatus)?' is-error':'')},savedAttrStatus)
        ]),
        barContext==='builder'&&settingSection('bar-panels','Builder Panels','Dock, float, or hide related Bricks panels from one place.',[
          settingRow('bar-elements-placement','Elements panel','Choose how the Bricks Elements panel behaves.',settingSegmented(barPanelPlacement('elements'),value=>setBarPanelPlacement('elements',value),[{value:'dock',label:'Dock'},{value:'float',label:'Float'},{value:'hide',label:'Hide'}])),
          settingRow('bar-structure-placement','Structure panel','Choose how the Bricks Structure panel behaves.',settingSegmented(barPanelPlacement('structure'),value=>setBarPanelPlacement('structure',value),[{value:'dock',label:'Dock'},{value:'float',label:'Float'},{value:'hide',label:'Hide'}])),
          settingRow('bar-opacity','Floating opacity','Applies to both floating Bricks panels.',h(SelectMenu,{value:barSettings.floatOpacity||'1',onChange:v=>updateBarSetting('floatOpacity',v),options:[{value:'1',label:'100%'},{value:'0.9',label:'90%'},{value:'0.78',label:'78%'},{value:'0.65',label:'65%'},{value:'0.5',label:'50%'}]}))
        ]),
        settingSection('bar-appearance','Appearance & Access','Keep the command surface quiet and reachable.',[
          settingRow('bar-density','Density','Controls spacing inside Mimam\'s Bar.',h(SelectMenu,{value:barSettings.density||'compact',onChange:v=>updateBarSetting('density',v),options:[{value:'compact',label:'Compact'},{value:'comfortable',label:'Comfortable'}]})),
          settingToggle('bar-toolbar','Mimam\'s Bar toolbar icon','Show the Bar launcher in the top toolbar.',barSettings.showTopBarIcon!==false,val=>updateBarSetting('showTopBarIcon',val)),
          settingToggle('bar-vengine-toolbar','Vengine toolbar icon','Show the main Vengine launcher in the top toolbar.',barSettings.showVengineTopBarIcon!==false,val=>updateBarSetting('showVengineTopBarIcon',val))
        ])
      ] : activeTab === 'transfer' ? [
        h('div',{class:'ve-transfer-toolbar',key:'transfer-toolbar'},
          h('div',{class:'ve-settings-context'},
            h('button',{type:'button',class:transferMode==='export'?'on':'',onClick:()=>{setTransferMode('export');resetTransferMessages();}},'Export'),
            h('button',{type:'button',class:transferMode==='import'?'on':'',onClick:()=>{setTransferMode('import');resetTransferMessages();}},'Import')
          ),
          h('div',{class:'ve-transfer-caption'},transferMode==='export'?'Choose exactly what goes into the settings package.':'Inspect the package first, then choose what should be restored.')
        ),
        transferMode==='import'&&h('label',{class:'ve-transfer-file'+(transferDropActive?' is-dragging':'')+(transferBundle?' is-loaded':''),key:'transfer-file',onDragEnter:transferDragEnter,onDragOver:transferDragOver,onDragLeave:transferDragLeave,onDrop:transferDrop},
          h('div',{class:'ve-transfer-file-main'},
            h('span',{class:'ve-transfer-file-icon'},ph(transferDropActive?'download-simple':transferBundle?'check-circle':'file-arrow-up')),
            h('div',null,
              h('strong',null,transferDropActive?'Drop the settings package':transferFileName||'Choose an MV settings package'),
              h('span',{class:transferDropActive?'ve-transfer-drop-copy':transferBundle?'ve-transfer-file-meta':''},transferDropActive?'Release to inspect it':transferBundle?((transferBundle.site_name||'Unknown site')+' · '+(transferBundle.created_at?new Date(transferBundle.created_at).toLocaleString():'Export time unavailable')):'Drop JSON here or choose a file')
            )
          ),
          h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',onClick:event=>{event.preventDefault();transferFileRef.current?.click();}},ph('file-arrow-up'),'Choose file'),
          h('input',{ref:transferFileRef,type:'file',accept:'application/json,.json',onChange:chooseTransferFile})
        ),
        transferPreview&&h('div',{class:'ve-transfer-preview',key:'transfer-preview'},
          h('div',{class:'ve-transfer-preview-head'},h('strong',null,'Import preview'),h('span',null,'Compatible')),
          h('div',{class:'ve-transfer-preview-meta'},(transferPreview.site_name||transferBundle?.site_name||'Unknown site')+' · '+(transferPreview.created_at||transferBundle?.created_at?new Date(transferPreview.created_at||transferBundle.created_at).toLocaleString():'time unavailable')+' · MV '+(transferPreview.plugin_version||'unknown')+(transferPreview.bricks_version?' · Bricks '+transferPreview.bricks_version:'')+' · schema '+transferPreview.schema_version),
          h('div',{class:'ve-transfer-preview-list'},['mv','bricks'].map(product=>{
            const rows=(transferPreview.groups||[]).filter(group=>group.product===product);
            return rows.length&&h('div',{class:'ve-transfer-preview-group',key:'preview-'+product},
              h('div',{class:'ve-transfer-preview-product'},ph(product==='mv'?'cube':'bricks'),product==='mv'?"Mimam's Var settings":'Bricks settings'),
              rows.map(group=>h('div',{class:'ve-transfer-preview-row',key:group.id},h('b',null,group.label),h('span',{class:group.will_replace?'ve-transfer-replace':''},group.will_replace?'Replaces current settings':'Adds settings')))
            );
          }))
        ),
        transferMode==='import'&&transferInspected&&h('div',{key:'transfer-choose-head'},h('div',{class:'ve-transfer-choose-title'},'Choose what to restore'),h('div',{class:'ve-transfer-choose-copy'},'The package is compatible. Select the MV and Bricks groups that should be applied.')),
        (transferMode==='export'||transferInspected)&&['mv','bricks'].map(product=>h('section',{class:'ve-transfer-scope',key:'transfer-'+product},
          h('div',{class:'ve-transfer-scope-head'},
            h('div',{class:'ve-transfer-scope-title'},ph(product==='mv'?'cube':'bricks'),h('strong',null,product==='mv'?"Mimam's Var":'Bricks'),h('span',null,product==='mv'?'Plugin preferences':'Global builder settings')),
            h(ToggleControl,{checked:transferProductChecked(product),label:'All '+(product==='mv'?'MV':'Bricks'),onChange:value=>setTransferProduct(product,value)})
          ),
          h('div',{class:'ve-transfer-checks'},SETTINGS_TRANSFER_GROUPS.filter(group=>group.product===product).map(group=>{
            const available=!transferBundle||!!transferBundle.groups?.[group.id];
            return h('label',{class:'ve-transfer-check'+(available?'':' is-disabled'),key:group.id},h('input',{type:'checkbox',checked:available&&!!transferSelection[group.id],disabled:!available,onChange:event=>setTransferGroup(group.id,event.target.checked)}),h('span',null,group.label));
          }))
        )),
        transferError&&h('div',{class:'ve-transfer-error',key:'transfer-error'},transferError),
        transferSuccess&&h('div',{class:'ve-transfer-success',key:'transfer-success'},transferSuccess),
        (transferMode==='export'||transferInspected)&&h('div',{class:'ve-transfer-summary',key:'transfer-summary'},
          h('span',null,selectedTransferGroups().length+' groups selected · licenses and secrets excluded'),
          h('button',{type:'button',class:'ve-btn',disabled:transferBusy,onClick:transferMode==='export'?exportSettings:(transferPreview?()=>setTransferConfirm(true):reviewSettingsImport)},transferBusy?'Working…':(transferMode==='export'?[ph('download-simple'),'Export JSON']:(transferPreview?[ph('upload-simple'),'Import selected']:[ph('magnifying-glass'),'Review import'])))
        ),
        transferConfirm&&h('div',{class:'ve-transfer-confirm',key:'transfer-confirm'},
          h('strong',null,'Replace the selected settings?'),
          h('p',null,'This writes the reviewed MV and Bricks groups over their current values. Unselected groups stay unchanged.'),
          h('div',{class:'ve-transfer-confirm-actions'},h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>setTransferConfirm(false)},'Cancel'),h('button',{type:'button',class:'ve-btn ve-btn-s',disabled:transferBusy,onClick:applySettingsImport},transferBusy?'Importing…':'Confirm import'))
        )
      ] : activeTab === 'studio' ? [
        // CSS Studio settings
        h('div', { class: 've-css-note', style: 'margin-bottom:8px' }, 'Live auto-format is off so typing never moves your cursor unexpectedly.'),
        settingToggleRow('studio-scss', 'SCSS mode foundation', cssScss, setScss),
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:8px;margin:' + (cssSourceOrder.length ? '10px 0 6px' : '0'), key: 'studio-sug-hdr' },
          h('div', { style: 'font-size:11px;color:#888;text-transform:uppercase;font-weight:700' }, 'Suggestion Priority'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: refreshIndex, disabled: cssIndexBusy }, cssIndexBusy ? 'Indexing...' : 'Refresh Index')),
        cssIndexMsg && h('div', { class: 've-css-note', style: 'margin-bottom:6px', key: 'studio-idx-msg' }, cssIndexMsg),
        h('div', { class: 've-source-list', key: 'studio-src-list' },
          normalizeSourceOrder(cssSourceOrder, cssRemoteSuggestions.sources || []).map(x => h('div', {
            class: 've-source-pill' + (cssDragSource === x ? ' dragging' : '') + (cssDropHint?.target === x ? ' drop-' + cssDropHint.pos : ''),
            key: x,
            draggable: true,
            onDragStart: e => { setCssDragSource(x); e.dataTransfer.effectAllowed = 'move'; },
            onDragOver: e => { e.preventDefault(); const r = e.currentTarget.getBoundingClientRect(); setCssDropHint({ target: x, pos: e.clientY < r.top + r.height/2 ? 'before' : 'after' }); e.dataTransfer.dropEffect = 'move'; },
            onDrop: e => { e.preventDefault(); dropSource(); },
            onDragEnd: () => { setCssDragSource(''); setCssDropHint(null); }
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px' }, h('span', { class: 've-source-grip' }, ph('dots-six-vertical')), h('span', null, x)),
            h('span', { style: 'display:flex;align-items:center;gap:6px' },
              h('span', { class: 've-source-meta' }, cssDisabledSources.includes(x) ? 'Off' : (cssSourceMeta[x] || 'Source')),
              h('button', { type: 'button', class: 've-source-toggle ' + (!cssDisabledSources.includes(x) ? 'on' : ''), title: cssDisabledSources.includes(x) ? 'Enable source' : 'Disable source', onMouseDown: e => e.preventDefault(), onClick: e => { e.preventDefault(); toggleSource(x); } }, ph(cssDisabledSources.includes(x) ? 'eye-slash' : 'eye')))))
        ),
        h('div', { class: 've-css-note', style: 'margin-top:10px', key: 'studio-src-note' }, 'Suggestions use this order when sources overlap. MV variables, detected builder classes, IDs, and supported plugin sources are scanned from WordPress.')
      ] : activeTab === 'modules' ? [
        // Modules settings tab
        h('div', { style: 'font-size:11px;color:#888;margin-bottom:14px;line-height:1.5', key: 'mod-intro' }, 'Choose where each module is active. Turn a module off in Admin without disabling it in Builder, or vice versa. Older global module settings are still respected.'),
        
        moduleSurfaceCard('variables', 'Variable Panel', 'Core variables grid, color palette manager, fluid scale builder, and Figma sync workspace.'),
        moduleSurfaceCard('css_studio', 'CSS Studio', 'Standalone SCSS/CSS workspace with auto-complete and live page injections.'),
        moduleSurfaceCard('css_recipes', 'CSS Recipes', 'Reusable CSS patterns and variable-aware snippets, controlled independently from CSS Studio.'),
        moduleSurfaceCard('mimams_bar', "Mimam's Bar", 'Power-user command line interface for lightning-fast attribute and design operations.'),
        moduleSurfaceCard('content_studio', 'Content Studio', 'Central hub for managing pages, posts, and CPTs with status toggles.'),
        moduleSurfaceCard('media_studio', 'Media Studio', 'Premium glassmorphic media library replacement with collections and alt-text helpers.'),
        moduleSurfaceCard('font_manager', 'Font Manager', 'Read, import, and edit Bricks Custom Fonts with browser-side WOFF2 conversion.'),
        moduleSurfaceCard('plugin_studio', 'Plugin Studio', 'Manage activation, updates, auto-updates, and inactive plugin cleanup.'),
        moduleSurfaceCard('bricks_settings', 'Bricks Settings', 'Read and write every Bricks global setting from a docked MV panel.'),
        moduleSurfaceCard('theme_styles', 'Theme Styles', 'Create, edit, duplicate, and delete Bricks native theme styles without a separate sync database.'),
        moduleSurfaceCard('help', 'Documentation', 'The in-builder documentation hub: module guides, quick answers, and what’s new.'),
        moduleSurfaceCard('recovery', 'Recovery', 'Backup, restore, and migrate this site. Guarded restore with validation, risk preview, dry-run, and rollback.')
      ] : activeTab === 'media' ? [
        h('div', { class: 've-css-note', style: 'margin-bottom:8px' }, 'Runtime behavior and folder-plugin integration for Media Studio. Enable or disable the module itself from the Modules tab.'),
              h('div', { class: 've-media-settings-card', key: 'media-runtime-options' },
                h('div', { class: 've-media-settings-head' },
                  h('div', null,
                    h('div', { class: 've-media-settings-title' }, ph('sliders-horizontal'), 'Media Studio Runtime'),
                    h('div', { class: 've-media-settings-desc' }, 'Control how Media Studio opens and how it stays in sync with detected folder plugins.')
                  )
                ),
                h('div', { class: 've-media-settings-actions' },
                  h('div', { class: 've-media-settings-action-row ve-media-settings-paused' },
                    h('span', null, 'Replace native WordPress Media Library page'),
                    h('span', { class: 've-badge muted', title: 'Paused until this flow is rebuilt safely' }, 'Paused')
                  ),
                  h('div', { class: 've-media-settings-desc', style: 'margin:-4px 0 2px' }, 'Paused for now. Media → Library stays on the default WordPress Media Library while we rebuild this safely later.'),
                  folderData.folders && folderData.folders.length > 0 && h('div', { class: 've-media-settings-action-row' },
                    h('span', null, 'Auto-sync external folders when Media Studio opens'),
                    h(ToggleControl, {
                      checked: !!s.media_auto_sync_external_folders,
                      label: 'Auto-sync external folders when Media Studio opens',
                      onChange: val => updateSetting('media_auto_sync_external_folders', val, 've-media-auto-sync-external-folders-changed')
                    })
                  )
                )
              ),
              !isDeactivated('media_studio') && folderData.folders && folderData.folders.length > 0 && h('div', { class: 've-media-settings-card' },
                h('div', { class: 've-media-settings-head' },
                  h('div', null,
                    h('div', { class: 've-media-settings-title' }, ph('arrows-merge'), 'Folder-Plugin Integration'),
                    h('div', { class: 've-media-settings-desc' }, `Detected ${folderData.folders.length} folder(s). Tree state is shared with Media Studio.`)
                  )
                ),
                h('div', { class: 've-media-settings-tree ve-scroll-custom' },
                  settingsFolderRows.length === 0 ? h('div', { class: 've-media-settings-empty' }, 'No folder-plugin folders were detected.') :
                  settingsFolderRows.map(({ folder, label }) => {
                    if (settingsPathHidden(label)) return null;
                    const depth = label.split(' / ').length - 1;
                    const leaf = label.split(' / ').pop().trim();
                    const hasChildren = settingsFolderRows.some(row => row.label !== label && row.label.startsWith(label + ' / '));
                    const guides = [];
                    for (let i = 0; i < depth; i++) guides.push(h('div', { class: 've-tree-guide', key: i }));
                    const count = settingsFolderCount(folder.id);
                    return h('div', { class: 've-media-settings-row', key: String(folder.id), title: label },
                      h('div', { class: 've-media-tree-guides' }, guides),
                      h('div', { class: 've-media-settings-name' },
                        hasChildren ? h('button', {
                          type: 'button',
                          class: 've-tree-toggle',
                          title: 'Toggle children',
                          onClick: e => {
                            e.preventDefault();
                            e.stopPropagation();
                            toggleSettingsFolderPath(label);
                          }
                        }, ph(settingsCollapsedPaths[label] ? 'caret-right' : 'caret-down')) : h('span', { class: 've-tree-spacer' }),
                        ph('folder', { style: 'color:#baf400;opacity:.8;flex-shrink:0' }),
                        h('span', null, leaf)
                      ),
                      h('span', { class: 've-studio-badge' }, count)
                    );
                  })
                ),
                h('div', { class: 've-media-settings-actions' },
                  h('div', { class: 've-media-settings-action-row' },
                    h('span', null, 'Hide external folders in Media Studio sidebar'),
                    h(ToggleControl, {
                      checked: hideFolders,
                      label: 'Hide external folders in Media Studio sidebar',
                      onChange: val => {
                        setHideFoldersState(val);
                        localStorage.setItem('ve_media_hide_folders', val ? 'true' : 'false');
                        window.dispatchEvent(new CustomEvent('ve-media-hide-folders-changed', { detail: val }));
                      }
                    })
                  ),
                  h('button', {
                    type: 'button',
                    class: 've-btn ve-btn-s',
                    style: 'background:rgba(186,244,0,0.1);color:#baf400;border:1px solid rgba(186,244,0,0.25);font-size:10px;padding:0 10px;font-weight:700;align-self:flex-start;min-height:30px',
                    onClick: () => setShowMigrateConfirm(true)
                  }, ph('copy-simple'), 'Migrate folders to MV Collections')
                ),
                
                showMigrateConfirm && h('div', { class: 've-modal' },
                  h('div', {
                    class: 've-modal-box ve-migration-modal',
                    style: 'width: 420px; max-width: 90vw; background: #161616; border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); display: flex; flex-direction: column; overflow: hidden;'
                  },
                    h('div', {
                      class: 've-modal-title',
                      style: 'padding: 16px; border-bottom: 1px solid rgba(255,255,255,0.06); margin: 0; font-size: 14px; font-weight: 700; color: #fff; display: flex; align-items: center; gap: 8px'
                    },
                      ph('arrows-merge', { style: 'color: #baf400; font-size: 18px' }),
                      'Migrate Folders'
                    ),
                    h('div', {
                      class: 've-modal-body',
                      style: 'padding: 16px; font-size: 12px; color: #aaa; line-height: 1.55; display: flex; flex-direction: column; gap: 12px;'
                    },
                      h('p', { style: 'margin: 0; color: #ffc86b; font-weight: 600' }, 'Warning: This action will duplicate your folder structures.'),
                      h('p', { style: 'margin: 0' }, 'This will copy all detected external folder structures and their media assignments into Mimam\'s Var local collections. The original folders in your external folder plugin will not be modified or deleted.')
                    ),
                    h('div', {
                      class: 've-modal-actions',
                      style: 'padding: 12px 16px; border-top: 1px solid rgba(255,255,255,0.06); display: flex; justify-content: flex-end; gap: 8px; margin: 0; background: rgba(0,0,0,0.1)'
                    },
                      h('button', {
                        type: 'button',
                        class: 've-btn ve-btn-g ve-btn-s',
                        onClick: () => setShowMigrateConfirm(false)
                      }, 'Cancel'),
                      h('button', {
                        type: 'button',
                        class: 've-btn ve-btn-s',
                        style: 'background: #baf400; color: #111; font-weight: 600',
                        onClick: () => {
                          const nextMap = { ...localCollections };
                          let migratedCount = 0;
                          const buildPath = (folder) => {
                            const parts = [folder.name];
                            let cur = folder;
                            while (cur && cur.parent && cur.parent !== '0') {
                              const parent = (folderData.folders || []).find(f => String(f.id) === String(cur.parent));
                              if (parent) {
                                parts.unshift(parent.name);
                                cur = parent;
                              } else break;
                            }
                            return parts.join(' / ');
                          };
                          const makeKey = label => (label || '').trim().toLowerCase().replace(/\s*\/\s*/g, '/').replace(/[^a-z0-9/]+/g, '_').replace(/^_+|_+$/g, '');
                          const folderMap = folderData.map || {};
                          (folderData.folders || []).forEach(folder => {
                            const pathLabel = buildPath(folder);
                            const key = makeKey(pathLabel);
                            if (!key) return;
                            const newIds = Object.keys(folderMap).filter(id => (folderMap[id] || []).map(String).includes(String(folder.id))).map(id => parseInt(id, 10));
                            const existing = nextMap[key] || { ids: [], icon: 'folder', label: pathLabel };
                            const nextIds = [...new Set([...(existing.ids || []), ...newIds])];
                            nextMap[key] = {
                              ids: nextIds,
                              icon: existing.icon || 'folder',
                              label: pathLabel
                            };
                            migratedCount++;
                          });
                          localStorage.setItem('ve_media_collections', JSON.stringify(nextMap));
                          persistUserPreference('ve_media_collections', JSON.stringify(nextMap));
                          setLocalCollections(nextMap);
                          setShowMigrateConfirm(false);
                          setMigrationStatus(`Successfully migrated ${migratedCount} folder(s)!`);
                          window.dispatchEvent(new CustomEvent('ve-media-collections-migrated'));
                          window.dispatchEvent(new CustomEvent('ve-media-collections-changed', { detail: nextMap }));
                          window.dispatchEvent(new CustomEvent('ve-toast-request', { detail: `Successfully migrated ${migratedCount} folder(s) to MV collections!` }));
                          setTimeout(() => setMigrationStatus(''), 4000);
                        }
                      }, 'Confirm Migration')
                    )
                  )
                ),
                migrationStatus && h('div', { style: 'font-size:10px;color:#baf400;font-weight:600;margin-top:4px' }, migrationStatus)
              )
      ] : []
    )
    ),
    h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 14px', class: 've-settings-footer' },
      h('span', { class: 've-settings-version' }, "Mimam's Var v" + (CFG.version || ''),h('button',{type:'button',class:'ve-settings-copy-version',onClick:copySettingsVersion,'aria-label':'Copy version','data-ve-tip':'Copy version'},ph('copy')),versionCopied&&h('span',{class:'ve-settings-copy-state'},'Copied')),
      h('span',{class:'ve-settings-footer-actions'},
        activeTab==='visibility'&&visibilityDirty&&h('span',{class:'ve-settings-footer-status is-dirty','data-ve-tip':'You have unsaved visibility changes'},h('i',{class:'ve-settings-dirty-dot'}),'Unsaved'),
        activeTab==='visibility'&&h('button',{type:'button',class:'ve-btn',disabled:visibilityBusy||!visibility.bricks_available,onClick:saveVisibility},visibilityBusy?'Saving…':'Save visibility'),
        h('button', { class: 've-btn', onClick: onClose }, 'Close')
      )
    )
  );
}

/* ── External source migration ─────────── */
function MigrationSub({onClose,exiting,onDone}){
  const[sources,sSources]=useState([]);
  const[source,sSource]=useState('all');
  const[previewBusy,setPreviewBusy]=useState(false);
  const[applyBusy,setApplyBusy]=useState(false);
  const[diff,sDiff]=useState([]);
  const[summary,sSummary]=useState(null);
  const[count,sCount]=useState(0);
  const[counts,setCounts]=useState(null);
  const[previewRows,setPreviewRows]=useState([]);
  const[err,sErr]=useState('');
  const[warnings,sWarnings]=useState([]);
  useEffect(()=>{api.g('migration/sources').then(d=>{if(Array.isArray(d))sSources(d);});},[]);
  const chooseSource=value=>{sSource(value);sDiff([]);sSummary(null);setCounts(null);setPreviewRows([]);sWarnings([]);sErr('');};
  const acceptPreview=r=>{
    if(r?.code){sErr(r.message||'Migration preview failed');return false;}
    sDiff(r.changes||[]);sSummary(r.summary||{});sCount(r.variable_count||0);setCounts(r.migration_counts||null);setPreviewRows(r.migration_payload||r.variables||[]);sWarnings(r.warnings||[]);
    return true;
  };
  const preview=async()=>{
    setPreviewBusy(true);sErr('');sWarnings([]);
    try{
      const r=await api.p('migration/preview',{source});
      acceptPreview(r);
    }finally{setPreviewBusy(false);}
  };
  const familyGroups=useMemo(()=>{
    const roots=new Map(),children=new Map();
    previewRows.forEach(row=>{
      const name=String(row?.name||'');
      if(!name)return;
      if(String(row?.type||'')==='generated'&&String(row?.generator_type||'')==='imported'&&row?.source_name){
        const source=String(row.source_name);
        if(!children.has(source))children.set(source,[]);
        children.get(source).push(row);
      }else roots.set(name,row);
    });
    return Array.from(children.entries()).map(([rootName,items])=>{
      const root=roots.get(rootName);
      if(!root||!root.family_synthetic)return null;
      const sorted=items.slice().sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true}));
      const selected=String(root.family_base_source||'')||String((sorted.find(item=>String(item.value||'')===String(root.value||''))||sorted[0]||{}).name||'');
      return{root,children:sorted,selected};
    }).filter(Boolean);
  },[previewRows]);
  const chooseFamilyBase=async(group,childName)=>{
    const child=group.children.find(item=>String(item.name||'')===String(childName||''));
    if(!child)return;
    const next=previewRows.map(row=>String(row?.name||'')===String(group.root.name||'')?{...row,value:child.value,family_base_source:child.name}:row);
    setPreviewBusy(true);sErr('');
    try{
      const r=await api.p('migration/preview',{source,variables:next});
      acceptPreview(r);
    }finally{setPreviewBusy(false);}
  };
  const apply=async()=>{
    if(!(counts?.apply||diff.filter(c=>c.action!=='delete').length))return;
    setApplyBusy(true);sErr('');
    try{
      const r=await api.p('migration/apply',{source,variables:previewRows});
      if(r?.code||r?.errors?.length){
        const details=(r?.verification_issues||r?.errors||[]).slice(0,8);
        sErr((r?.message||'Migration failed')+(details.length?' '+details.join(' '):''));
        return;
      }
      if(!(Number(r?.applied)>0)){sErr('No variables were written. Run Preview Migration again before applying.');return;}
      if(onDone)await onDone(r);
    }catch(error){
      sErr(error?.message||'WordPress did not finish the migration. Nothing has been confirmed as imported.');
    }finally{setApplyBusy(false);}
  };
  const opts=[{value:'all',label:'All available sources'},...sources.map(x=>({value:x.id,label:x.name+(x.available?'':' (not detected)')}))];
  const changedCount = summary ? ((summary.updated||0) + (summary.type_changed||0) + (summary.relationship_changed||0) + (summary.repaired||0)) : 0;
  const migrationCounts=counts||{detected:count,new:summary?.added||0,changed:changedCount,skipped:warnings.length,unchanged:0,apply:diff.filter(c=>c.action!=='delete').length};
  const applicableDiff=diff.filter(c=>c.action!=='delete');
  const actionClass=action=>action==='add'?'add':action==='update'?'update':'other';
  const actionLabel=action=>action==='relationship_change'?'LINK':action==='repair_generated'?'FIX':String(action||'').toUpperCase().slice(0,4);
  return h(Sub,{title:'Migrate Variables',onClose,exiting,bodyClass:'ve-migrate-sub-body'},
    h('div',{class:'ve-migrate-shell'},
      h('div',{class:'ve-migrate-scroll'},
        h('div',{class:'ve-migrate-callout'},
          h('div',{class:'ve-migrate-desc'},"Preview variables from Core Framework, Advanced Themer/Bricks, and ACSS before adding anything to Mimam's Var. Deletions are never applied. Reviewed colors enter the reusable source-named Color Palette, while imported families keep every original child value.")),
        h('div',{class:'ve-migrate-field'},
          h('div',{class:'ve-migrate-field-label'},'Source'),
          h(SelectMenu,{value:source,onChange:chooseSource,options:opts})),
        sources.length>0&&h('div',{class:'ve-migrate-sources'},sources.map(x=>h('div',{key:x.id,class:'ve-migrate-card'},
          h('div',{class:'ve-migrate-card-copy'},
            h('div',{class:'ve-migrate-card-title'},x.name),
            h('div',{class:'ve-migrate-card-desc'},x.description)),
          h('span',{class:'ve-migrate-badge '+(x.available?'ok':'muted')},x.available?'Detected':'Not found')))),
        familyGroups.length>0&&h('div',{class:'ve-migrate-families'},
          h('div',{class:'ve-migrate-families-title'},'Imported family base values'),
          h('div',{class:'ve-migrate-families-help'},'The clean root has no “base” suffix. The 500 step is selected automatically when available; choose another child here if it should supply the root value. Every child token and imported value remains unchanged.'),
          h('div',{class:'ve-migrate-family-list'},familyGroups.map(group=>h('div',{key:group.root.name,class:'ve-migrate-family-row'},
            h('div',{class:'ve-migrate-family-name'},publicTokenLabel(group.root.name),h('span',{class:'ve-migrate-family-meta'},group.children.length+' imported children')),
            h(SelectMenu,{
              value:group.selected,
              onChange:value=>chooseFamilyBase(group,value),
              disabled:previewBusy||applyBusy,
              options:group.children.map(child=>({value:child.name,label:publicTokenLabel(child.name)}))
            }))))),
        warnings.length>0&&h('div',{class:'ve-migrate-result warning'},
          h('div',null,
            h('div',{class:'ve-migrate-warnings-title'},migrationCounts.skipped+' item'+(migrationCounts.skipped===1?'':'s')+' skipped'),
            h('div',{class:'ve-migrate-warning-list'},
              warnings.slice(0,4).map((warning,index)=>h('div',{key:index},warning)),
              warnings.length>4&&h('div',{style:'font-weight:750;color:#f59e0b'},'+'+(warnings.length-4)+' more')))),
        applicableDiff.length>0&&h('div',{class:'ve-migrate-diff-list'},applicableDiff.slice(0,60).map((c,i)=>h('div',{key:i,class:'ve-migrate-diff-row'},
          h('span',{class:'ve-migrate-diff-action '+actionClass(c.action)},actionLabel(c.action)),
          h('span',{style:'flex:1;min-width:0;overflow-wrap:anywhere;font-family:"SF Mono","Fira Code",monospace;color:#ddd'},c.name)))),
        err&&h('div',{class:'ve-migrate-result warning'},
          h('div',null,h('div',{class:'ve-migrate-warnings-title'},'Migration could not continue'),h('div',{class:'ve-migrate-warning-list'},err)))),
      h('div',{class:'ve-migrate-sticky'},
        h('div',{class:'ve-migrate-actions'},
          h('button',{class:'ve-btn',onClick:preview,disabled:previewBusy||applyBusy,title:summary?'Re-scan the sources and refresh the preview':'Scan the detected sources and preview the changes'},previewBusy?'Scanning...':(summary?'Re-preview':'Preview Migration')),
          summary&&h('button',{class:'ve-btn ve-btn-g',onClick:apply,disabled:previewBusy||applyBusy||migrationCounts.apply<1},applyBusy?'Applying...':(migrationCounts.apply>0?'Apply '+migrationCounts.apply:'No changes to apply'))),
        summary&&h('div',{class:'ve-migrate-result success'},
          h('div',null,
            h('div',{class:'ve-migrate-summary-title'},migrationCounts.detected+' variables detected'),
            h('div',{class:'ve-migrate-summary-details'},
              h('span',{class:'ve-migrate-count-ready'},migrationCounts.apply+' changes ready'),
              ' · '+migrationCounts.new+' new · '+migrationCounts.changed+' changed · ',
              h('span',{class:'ve-migrate-count-skipped'},migrationCounts.skipped+' skipped'),
              ' · '+migrationCounts.unchanged+' unchanged'))))));
}

function usageTokenCount(content,token){
  const text=String(content||'');
  if(!text||!token)return 0;
  const escaped=String(token).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const matches=text.match(new RegExp('(^|[^A-Za-z0-9_-])'+escaped+'(?![A-Za-z0-9_-])','g'));
  return matches?matches.length:0;
}
function scanClientVariableUsages(variables){
  const list=(variables||[]).filter(Boolean);
  const result={};
  list.forEach(variable=>{result[String(variable.id)]={css_recipes:[],bricks:[]};});
  const recipes=loadUserCssRecipes();
  const adapter=window.MimamsBarBricksAdapter;
  let elements=[];
  if(adapter&&typeof adapter.getAllElements==='function'){
    try{elements=adapter.getAllElements({fresh:false})||[];}catch(e){elements=[];}
  }
  list.forEach(variable=>{
    const key=String(variable.id);
    const token=cssTokenName(variable.name);
    recipes.forEach(recipe=>{
      const matches=usageTokenCount(recipe.css,token);
      if(matches)result[key].css_recipes.push({type:'css_recipe',id:String(recipe.code||''),label:String(recipe.name||recipe.code||'CSS Recipe'),name:String(recipe.name||recipe.code||'CSS Recipe'),matches});
    });
    elements.forEach(element=>{
      let raw='';
      try{raw=JSON.stringify(element?.settings||{});}catch(e){raw='';}
      const matches=usageTokenCount(raw,token);
      if(!matches)return;
      let label=String(element?.label||element?.name||element?.id||'Bricks element');
      try{if(adapter&&typeof adapter.getElementFullLabel==='function')label=adapter.getElementFullLabel(element)||label;}catch(e){}
      result[key].bricks.push({type:'bricks',id:String(element?.id||''),label,name:label,matches,element});
    });
  });
  return result;
}
function mergeVariableUsage(server,client){
  const groups={...(server?.groups||{})};
  groups.css_recipes=client?.css_recipes||[];
  groups.bricks=client?.bricks||[];
  let total=0;
  Object.values(groups).forEach(items=>(items||[]).forEach(item=>{total+=Math.max(1,Number(item.matches||1));}));
  return{...(server||{}),groups,total,unused:total===0};
}
const USAGE_GROUPS=[
  ['aliases','Aliases','link'],
  ['themes','Themes','palette'],
  ['css_studio','CSS Studio','code'],
  ['css_recipes','CSS Recipes','brackets-curly'],
  ['bricks','Current Bricks document','cube'],
  ['bricks_saved','Saved Bricks content','floppy-disk'],
  ['wordpress','Other WordPress storage','database']
];
function VariableUsagePanel({variable,onNavigate,title='Usage & impact',compact=false,onLoaded}){
  const[report,sReport]=useState(null);
  const[loading,sLoading]=useState(true);
  const[error,sError]=useState('');
  const loadUsage=useCallback(async()=>{
    if(!variable)return;
    sLoading(true);sError('');
    try{
      const server=await api.g('variables/'+variable.id+'/usage');
      if(server?.code)throw new Error(server.message||'Usage scan failed');
      const client=scanClientVariableUsages([variable])[String(variable.id)]||{};
      const merged=mergeVariableUsage(server,client);
      sReport(merged);onLoaded&&onLoaded(merged);
    }catch(e){sError(e.message||'Usage scan failed');}
    finally{sLoading(false);}
  },[variable?.id,variable?.name]);
  useEffect(()=>{sReport(null);loadUsage();},[loadUsage]);
  const groups=report?.groups||{};
  return h('div',{class:'ve-usage'+(compact?' compact':'')},
    h('div',{class:'ve-usage-head'},
      h('div',{class:'ve-usage-title'},ph('git-branch'),title),
      report&&h('span',{class:'ve-usage-status'+(report.unused?' unused':'')},report.unused?'Unused':report.total+' ref'+(report.total===1?'':'s'))),
    loading?h('div',{class:'ve-usage-loading'},'Checking aliases, Themes, CSS Studio and Bricks…')
    :error?h('div',{class:'ve-usage-empty'},error,h('button',{class:'ve-btn ve-btn-s',style:'margin-left:7px',onClick:loadUsage},'Retry'))
    :h('div',{class:'ve-usage-body'},
      report?.unused&&h('div',{class:'ve-usage-empty'},'No consumers were found. This variable is currently safe to review as unused.'),
      USAGE_GROUPS.map(([key,label,icon])=>{
        const items=groups[key]||[];
        if(!items.length)return null;
        return h('div',{class:'ve-usage-group',key},
          h('div',{class:'ve-usage-group-title'},label+' · '+items.length),
          items.map((item,index)=>{
            const clickable=!!onNavigate&&['variable','theme','css_studio','css_recipe','bricks'].includes(item.type);
            return h('button',{type:'button',class:'ve-usage-item'+(clickable?' clickable':''),key:String(item.id)+'-'+index,disabled:!clickable,onClick:()=>clickable&&onNavigate(item,variable)},
              ph(icon),h('span',{class:'ve-usage-item-main'},h('span',{class:'ve-usage-item-label'},item.label||item.name),h('span',{class:'ve-usage-item-meta'},Number(item.matches||1)+' reference'+(Number(item.matches||1)===1?'':'s'))));
          }));
      })
    ));
}
function VariableImpactStack({variables,onNavigate}){
  const list=(variables||[]).filter(Boolean).slice(0,12);
  if(!list.length)return null;
  return h('div',{class:'ve-impact-stack'},
    h('div',{class:'ve-impact-summary'},ph('warning-circle'),'Consumers of the affected variables are shown before Apply. Token names and values remain unchanged.'),
    list.map(variable=>h(VariableUsagePanel,{key:variable.id,variable,onNavigate,title:publicTokenLabel(variable.name),compact:true})),
    (variables||[]).length>list.length&&h('div',{class:'ve-family-note'},'Plus '+((variables||[]).length-list.length)+' more affected variables.'));
}

function cssLineCount(text){const s=String(text||'');return Math.max(1,(s.match(/\n/g)||[]).length+1);}
const DOM_SUGGEST_CACHE={class:{at:0,items:[]},id:{at:0,items:[]},var:{at:0,items:[]}};
const CSSOM_SUGGEST_CACHE={class:{at:0,items:[]},id:{at:0,items:[]},var:{at:0,items:[]}};
function domSuggestionDocuments(){
  const docs=[];const seen=[];
  const add=doc=>{if(!doc||seen.includes(doc))return;seen.push(doc);docs.push(doc);};
  add(document);
  try{
    Array.from(window.frames||[]).forEach(frame=>{try{add(frame.document);}catch(e){}});
  }catch(e){}
  try{
    document.querySelectorAll('iframe').forEach(frame=>{try{add(frame.contentDocument||frame.contentWindow?.document);}catch(e){}});
  }catch(e){}
  return docs.slice(0,8);
}
function domClassName(el){
  const raw=el?.className;
  if(!raw)return'';
  if(typeof raw==='string')return raw;
  if(typeof raw.baseVal==='string')return raw.baseVal;
  return String(raw||'');
}
function collectDomSuggestions(kind){
  const now=Date.now();
  const cached=DOM_SUGGEST_CACHE[kind];
  if(cached&&now-cached.at<5000)return cached.items;
  const found={};
  let count=0;
  domSuggestionDocuments().forEach(doc=>{
    if(count>=3000)return;
    try{
      doc.querySelectorAll(kind==='class'?'[class]':'[id]').forEach(el=>{
        if(count>=3000)return;
        if(kind==='class')domClassName(el).split(/\s+/).forEach(c=>{if(c&&!c.startsWith('ve-')){found['.'+c]=true;count++;}});
        else if(el.id&&!String(el.id).startsWith('ve-')){found['#'+el.id]=true;count++;}
      });
    }catch(e){}
  });
  const items=Object.keys(found).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).slice(0,2000);
  DOM_SUGGEST_CACHE[kind]={at:now,items};
  return items;
}
function cssomExtractSelector(selector,found,kind){
  if(!selector)return 0;
  let count=0;
  const text=String(selector);
  if(kind==='class'){
    const re=/(?<![A-Za-z0-9_-])\.((?:\\.|[A-Za-z_][A-Za-z0-9_-]*|[\\/:\\].-]){1,120})/g;
    let m;while((m=re.exec(text))){const name='.'+m[1].replace(/\\/g,'');if(!name.startsWith('.ve-')){found[name]=true;count++;}}
  }else if(kind==='id'){
    const re=/(?<![A-Za-z0-9_-])#([A-Za-z_][A-Za-z0-9_-]{0,119})/g;
    let m;while((m=re.exec(text))){const name='#'+m[1];if(!name.startsWith('#ve-')){found[name]=true;count++;}}
  }
  return count;
}
function cssomExtractVars(text,found,meta,source){
  let count=0;const s=String(text||'');
  let m;const add=(name,raw)=>{
    name=String(name||'').trim();
    if(!name||name.indexOf('--ve-')===0)return;
    found[name]=true;count++;
    if(meta)cssRecordVarMeta(meta,name,raw,source);
  };
  const decl=/--([A-Za-z][A-Za-z0-9_-]*)\s*:\s*([^;}]*)/g;while((m=decl.exec(s)))add('--'+m[1],m[2]);
  return count;
}
function collectDomVariableSuggestions(){
  const now=Date.now();
  const cached=DOM_SUGGEST_CACHE.var;
  if(cached&&now-cached.at<8000)return cached.items;
  const found={};let count=0;
  const scanText=text=>{if(count>=2200)return;count+=cssomExtractVars(text,found,null,'Sheet');};
  domSuggestionDocuments().forEach(doc=>{
    if(count>=2200)return;
    try{
      scanText(doc.documentElement?.getAttribute?.('style')||'');
      scanText(doc.body?.getAttribute?.('style')||'');
      const els=doc.querySelectorAll('[style]');
      for(let i=0;i<els.length&&i<1600&&count<2200;i++){
        scanText(els[i].getAttribute('style')||'');
      }
    }catch(e){}
  });
  const items=Object.keys(found).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).slice(0,1500);
  DOM_SUGGEST_CACHE.var={at:now,items};
  return items;
}
function cssVarSheetIsProductUi(sheet){
  let id='',href='';
  try{href=String((sheet&&sheet.href)||'').toLowerCase();}catch(e){}
  try{const owner=sheet&&sheet.ownerNode;id=String((owner&&(owner.id||(owner.getAttribute&&owner.getAttribute('id'))))||'').toLowerCase();}catch(e){}
  if(id==='ve-dynamic-variables-runtime'||id==='ve-variable-preview-runtime'||id==='ve-css-studio-runtime')return false;
  return id==='ve-studio-ui-styles'||href.indexOf('/variable-engine/assets/')>=0;
}
function cssomWalkRules(rules,found,kind,state){
  if(!rules||state.count>=2500)return;
  try{
    Array.from(rules).forEach(rule=>{
      if(state.count>=2500)return;
      try{
        if(kind==='var')state.count+=cssomExtractVars(rule.cssText||'',found,state.meta,state.source);
        else if(rule.selectorText)state.count+=cssomExtractSelector(rule.selectorText,found,kind);
        if(rule.cssRules)cssomWalkRules(rule.cssRules,found,kind,state);
      }catch(e){}
    });
  }catch(e){}
}
function collectCssomSuggestions(kind){
  const now=Date.now();
  const cached=CSSOM_SUGGEST_CACHE[kind];
  if(cached&&now-cached.at<8000){if(kind==='var')CSSOM_VAR_META=cached.meta;return cached.items;}
  const found={};const state={count:0,meta:kind==='var'?new Map():null,source:'Sheet'};
  domSuggestionDocuments().forEach(doc=>{
    if(state.count>=2500)return;
    try{
      Array.from(doc.styleSheets||[]).forEach(sheet=>{
        if(state.count>=2500)return;
        if(kind==='var'&&cssVarSheetIsProductUi(sheet))return;
        state.source=kind==='var'?cssVarSourceForSheet(sheet):'Sheet';
        try{cssomWalkRules(sheet.cssRules,found,kind,state);}catch(e){}
      });
    }catch(e){}
  });
  const items=Object.keys(found).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).slice(0,1500);
  CSSOM_SUGGEST_CACHE[kind]={at:now,items,meta:state.meta};
  if(kind==='var')CSSOM_VAR_META=state.meta;
  return items;
}
let CSSOM_VAR_META=null;
/* The CSSOM only sees stylesheets this document can read. Computed style is the
   backstop: it reports what the token actually resolves to right now, including
   anything a cross-origin sheet or an inline style contributed. */
function collectComputedVarValues(names){
  const out=new Map();
  const docs=domSuggestionDocuments();
  for(let d=0;d<docs.length;d++){
    let win=null,els=[];
    try{win=docs[d].defaultView;els=[docs[d].documentElement,docs[d].body,docs[d].querySelector('.brx-body')].filter(Boolean);}catch(e){}
    if(!win||!els.length||!win.getComputedStyle)continue;
    for(let e=0;e<els.length;e++){
      let st=null;
      try{st=win.getComputedStyle(els[e]);}catch(error){}
      if(!st)continue;
      for(let i=0;i<names.length;i++){
        const name=names[i];
        if(out.has(name))continue;
        let v='';
        try{v=String(st.getPropertyValue(name)||'').trim();}catch(error){}
        if(v)out.set(name,v);
      }
    }
  }
  return out;
}
function normalizeSourceOrder(saved,serverSources){
  const valid=[...new Set(serverSources&&serverSources.length?serverSources:["Mimam's Var"])];
  const incoming=Array.isArray(saved)?saved:[];
  const kept=incoming.filter(x=>valid.includes(x));
  return [...new Set([...kept,...valid])];
}
function readCssStudioPreferences(){
  const disabled=readStoredJson('ve_css_disabled_sources',[]);
  return{
    scss:localStorage.getItem('ve_css_scss')==='1',
    sourceOrder:normalizeSourceOrder(readStoredJson('ve_css_source_order',[]),[]),
    disabledSources:Array.isArray(disabled)?disabled:[]
  };
}
function useCssStudioPreferences(){
  const initial=useMemo(readCssStudioPreferences,[]);
  const[scss,setScss]=useState(initial.scss);
  const[sourceOrder,setSourceOrder]=useState(initial.sourceOrder);
  const[disabledSources,setDisabledSources]=useState(initial.disabledSources);
  useEffect(()=>{
    const sync=()=>{
      const next=readCssStudioPreferences();
      setScss(next.scss);
      setSourceOrder(next.sourceOrder);
      setDisabledSources(next.disabledSources);
    };
    window.addEventListener('ve-css-settings-changed',sync);
    return()=>window.removeEventListener('ve-css-settings-changed',sync);
  },[]);
  return{scss,setScss,sourceOrder,setSourceOrder,disabledSources,setDisabledSources};
}
function cssValidation(text){
  const warnings=[];
  const s=String(text||'').slice(0,60000);
  const open=(s.match(/\{/g)||[]).length, close=(s.match(/\}/g)||[]).length;
  if(open!==close)warnings.push('Brace count is off: '+open+' opening, '+close+' closing.');
  const props=[...new Set(CSS_PROPS)];
  s.split('\n').slice(0,900).forEach((line,i)=>{
    const m=line.match(/^\s*([a-z-]+)\s*:/i);
    if(m&&!props.includes(m[1].toLowerCase())&&!m[1].startsWith('--'))warnings.push('Line '+(i+1)+': unknown property "'+m[1]+'".');
  });
  return warnings.slice(0,5);
}
function cssContext(text,pos){
  const before=String(text||'').slice(0,pos);
  const line=before.split('\n').pop()||'';
  const inValue=/:\s*[^;{}]*$/.test(line);
  let depth=0,quote='',comment=false;
  for(let i=0;i<before.length;i++){
    const c=before[i],n=before[i+1]||'';
    if(comment){if(c==='*'&&n==='/'){comment=false;i++;}continue;}
    if(quote){if(c==='\\'){i++;continue;}if(c===quote)quote='';continue;}
    if(c==='/'&&n==='*'){comment=true;i++;continue;}
    if(c==='"'||c==="'"){quote=c;continue;}
    if(c==='{')depth++;
    else if(c==='}')depth=Math.max(0,depth-1);
  }
  return{line,inValue,inBlock:depth>0};
}
function cssSuggestionMatch(before){
  const raw=String(before||'');
  const varMatch=raw.match(/var\(\s*(--[a-z0-9-]*)?$/i);
  if(varMatch)return{token:varMatch[1]||'--',kind:'var',replaceLength:varMatch[1]?varMatch[1].length:0,inVar:true};
  const varWordMatch=raw.match(/\bvar\s*$/i);
  if(varWordMatch)return{token:'--',kind:'var',replaceLength:varWordMatch[0].trim().length,inVar:false,variableTrigger:'var'};
  const pseudoMatch=raw.match(/(::?[a-z0-9_-]*)$/i);
  if(pseudoMatch)return{token:pseudoMatch[1],kind:'selector',replaceLength:pseudoMatch[1].length};
  const tokenMatch=raw.match(/(@[a-z0-9_-]*|--[a-z0-9-]*|\.[a-z0-9_:/[\].-]*|#[a-z0-9_-]*|[a-z-]{1,})$/i);
  if(!tokenMatch)return null;
  const token=tokenMatch[1];
  return{token,replaceLength:token.length,kind:token.startsWith('@')?'atrule':token.startsWith('--')?'var':token.startsWith('.')?'class':token.startsWith('#')?'id':'css',inVar:false};
}
/* ── What a suggestion is actually worth (id34) ──────────────────────────────
   The list used to show names only, so you had to already know what a token
   held before you could pick one. Every variable now carries its resolved
   value, the kind of value it is, and where it is defined. Names still drive
   filtering and ordering — this is presentation hung off the name, and the
   lookup stays a plain string so nothing downstream changes. */
const CSS_VAR_META=new Map();
const CSS_NAMED_COLORS={black:'#000000',white:'#ffffff',red:'#ff0000',green:'#008000',blue:'#0000ff',yellow:'#ffff00',orange:'#ffa500',purple:'#800080',gray:'#808080',grey:'#808080',silver:'#c0c0c0',maroon:'#800000',olive:'#808000',lime:'#00ff00',aqua:'#00ffff',cyan:'#00ffff',teal:'#008080',navy:'#000080',fuchsia:'#ff00ff',magenta:'#ff00ff',pink:'#ffc0cb',brown:'#a52a2a',gold:'#ffd700',beige:'#f5f5dc',ivory:'#fffff0',khaki:'#f0e68c',coral:'#ff7f50',salmon:'#fa8072',crimson:'#dc143c',indigo:'#4b0082',violet:'#ee82ee',turquoise:'#40e0d0',tan:'#d2b48c',plum:'#dda0dd',orchid:'#da70d6',transparent:'transparent'};
function cssVarMeta(label){return CSS_VAR_META.get(String(label||''))||null;}
function cssIsColorValue(v){
  const t=String(v||'').trim().toLowerCase();
  if(!t)return false;
  if(t.charAt(0)==='#')return /^#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/.test(t);
  if(/^(rgba?|hsla?|hwb|lab|lch|oklab|oklch|color)\(/.test(t))return true;
  return Object.prototype.hasOwnProperty.call(CSS_NAMED_COLORS,t);
}
/* Kind is read from the value first and the name only as a tie-break. A shadow
   and a border shorthand look alike to a regex; the token name is the honest
   signal for which one it is. */
function cssValueKind(name,value){
  const v=String(value||'').trim();
  if(!v)return 'miss';
  const lower=v.toLowerCase();
  const n=String(name||'').toLowerCase();
  if(/^(repeating-)?(linear|radial|conic)-gradient\(/.test(lower))return 'grad';
  if(cssIsColorValue(lower))return 'color';
  if(n.indexOf('shadow')>=0&&/\d/.test(lower))return 'shadow';
  if(n.indexOf('radius')>=0&&/^-?[\d.]+(px|rem|em|%)$/.test(lower))return 'radius';
  if(/^-?[\d.]+$/.test(lower))return 'num';
  if(/^-?[\d.]+(px|rem|em|%|vw|vh|vmin|vmax|ch|ex|pt)$/.test(lower))return 'len';
  if(/^(clamp|calc|min|max)\(/.test(lower))return 'len';
  if(n.indexOf('font')>=0&&/[a-z]/i.test(v))return 'font';
  return 'text';
}
function cssLengthPx(value){
  const m=String(value||'').trim().match(/^(-?[\d.]+)(px|rem|em|pt)?$/);
  if(!m)return null;
  const n=parseFloat(m[1]);
  if(!isFinite(n))return null;
  const unit=m[2]||'px';
  if(unit==='rem'||unit==='em')return n*16;
  if(unit==='pt')return n*(4/3);
  return n;
}
/* The pool spans single-digit spacing to full container widths, so a bar drawn
   to absolute length would be a dot next to a full bar. Log scale keeps it to
   the only claim it can honestly make: small, medium or large. */
function cssLengthBar(value){
  const px=cssLengthPx(value);
  if(px===null)return 9;
  const clamped=Math.max(1,Math.min(Math.abs(px),1600));
  return Math.max(2,Math.round((Math.log(clamped)/Math.log(1600))*20));
}
function cssVarAliasTarget(value){
  const m=String(value||'').trim().match(/^var\(\s*(--[A-Za-z][A-Za-z0-9_-]*)/);
  return m?m[1]:null;
}
/* Follow an alias to whatever it finally resolves to, recording the hops so the
   row can show the chain. A cycle stops rather than resolving — a token that
   points back at itself has no value to show and saying so is the answer. */
function cssResolveVarChain(label,meta){
  const chain=[];const seen={};
  let cur=String(label||'');
  let node=meta.get(cur);
  while(node){
    const next=cssVarAliasTarget(node.raw);
    if(!next)break;
    if(seen[next])return{chain,value:'',cycle:true};
    seen[next]=true;chain.push(next);
    if(chain.length>8)break;
    cur=next;node=meta.get(next);
  }
  const last=meta.get(cur);
  return{chain,value:last?last.raw:'',cycle:false};
}
function cssVarSourceForSheet(sheet){
  let id='',href='';
  try{href=String((sheet&&sheet.href)||'');}catch(e){}
  try{const owner=sheet&&sheet.ownerNode;id=String((owner&&(owner.id||(owner.getAttribute&&owner.getAttribute('id'))))||'');}catch(e){}
  const hay=(id+' '+href).toLowerCase();
  if(hay.indexOf('ve-dynamic-variables')>=0||hay.indexOf('ve-variable-preview')>=0||hay.indexOf('variable-engine')>=0)return 'MV';
  if(hay.indexOf('theme-style')>=0)return 'Theme';
  if(hay.indexOf('bricks')>=0)return 'Bricks';
  return 'Sheet';
}
const CSS_VAR_SOURCE_RANK={MV:4,Theme:3,Bricks:2,Sheet:1};
function cssRecordVarMeta(meta,name,raw,source){
  const label=String(name||'').trim();
  if(!label)return;
  const value=String(raw==null?'':raw).trim();
  const prev=meta.get(label);
  /* First writer with a real value wins on value; source keeps the most
     specific owner, so a token both declared by MV and echoed into a page
     stylesheet still reports MV as the place you would go to edit it. */
  if(prev){
    if(!prev.raw&&value)prev.raw=value;
    if((CSS_VAR_SOURCE_RANK[source]||0)>(CSS_VAR_SOURCE_RANK[prev.source]||0))prev.source=source;
    return;
  }
  meta.set(label,{raw:value,source:source||'Sheet'});
}
/* Second pass: everything above collects raw declarations, this turns them into
   what a row needs — alias chain resolved, kind decided, bar width measured. */
function cssFinalizeVarMeta(meta){
  CSS_VAR_META.clear();
  meta.forEach((entry,label)=>{
    const resolved=cssResolveVarChain(label,meta);
    const value=resolved.cycle?'':(resolved.value||entry.raw||'');
    const kind=resolved.cycle?'miss':cssValueKind(label,value);
    CSS_VAR_META.set(label,{
      value,
      raw:entry.raw||'',
      source:entry.source||'Sheet',
      kind,
      chain:resolved.chain,
      cycle:!!resolved.cycle,
      bar:kind==='len'?cssLengthBar(value):0
    });
  });
}
function cssIndex(list){
  const out=[];const seen={};
  (list||[]).forEach(x=>{const label=String(x||'').trim();if(!label||seen[label])return;seen[label]=true;out.push({label,lower:label.toLowerCase()});});
  return out;
}
function cssLookup(index,query,limit){
  const q=String(query||'').toLowerCase();
  const res=[];
  if(!q){
    for(let i=0;i<index.length&&res.length<limit;i++)res.push(index[i].label);
    return res;
  }
  const bare=q.replace(/^(--|[.#])/,'');
  const add=label=>{if(res.length<limit&&!res.includes(label))res.push(label);};
  const itemBare=item=>item.lower.replace(/^(--|[.#])/,'');
  const segmentHit=(hay,needle)=>needle&&hay.split(/[-_.:/\s]+/).some(part=>part.indexOf(needle)===0);
  for(let i=0;i<index.length&&res.length<limit;i++)if(index[i].lower.indexOf(q)===0)add(index[i].label);
  if(bare!==q)for(let i=0;i<index.length&&res.length<limit;i++)if(itemBare(index[i]).indexOf(bare)===0)add(index[i].label);
  for(let i=0;i<index.length&&res.length<limit;i++)if(segmentHit(itemBare(index[i]),bare||q))add(index[i].label);
  for(let i=0;i<index.length&&res.length<limit;i++)if((index[i].lower.indexOf(q)>0||itemBare(index[i]).indexOf(bare)>0))add(index[i].label);
  return res;
}
/* MV's own variables are authoritative: the panel holds the authored value and
   knows the user edits it here, so it outranks anything scraped off the page. */
function buildCssVarMeta(varIndex,vars,remoteMeta){
  const meta=CSSOM_VAR_META?new Map(CSSOM_VAR_META):new Map();
  Object.keys(remoteMeta||{}).forEach(name=>{
    const item=remoteMeta[name]||{};
    cssRecordVarMeta(meta,name,item.value||'',item.source||'Sheet');
  });
  (vars||[]).forEach(v=>{
    const name=cssTokenName(v&&v.name);
    if(!name)return;
    const raw=String((v&&(v.value!=null?v.value:v.val))||'').trim();
    const prev=meta.get(name);
    if(prev){prev.raw=raw||prev.raw;prev.source='MV';}
    else meta.set(name,{raw,source:'MV'});
  });
  const missing=[];
  varIndex.forEach(item=>{
    const entry=meta.get(item.label);
    if(!entry){meta.set(item.label,{raw:'',source:'Sheet'});missing.push(item.label);}
    else if(!entry.raw)missing.push(item.label);
  });
  if(missing.length){
    const computed=collectComputedVarValues(missing);
    computed.forEach((value,name)=>{const entry=meta.get(name);if(entry&&!entry.raw)entry.raw=value;});
  }
  cssFinalizeVarMeta(meta);
}
function cssSuggestionPools(vars,remoteSuggestions){
  const orderVars=a=>{
    const priority=['--color','--space','--spacing','--typography','--font','--text','--heading','--radius','--size','--scale','--stroke','--shadow','--opacity','--motion'];
    const seen={};const arr=[];
    (a||[]).forEach(x=>{const label=String(x||'').trim();if(!label||seen[label])return;seen[label]=true;arr.push(label);});
    arr.sort((x,y)=>{
      const lx=x.toLowerCase(),ly=y.toLowerCase();
      const ix=priority.findIndex(p=>lx.startsWith(p)),iy=priority.findIndex(p=>ly.startsWith(p));
      return (ix<0?99:ix)-(iy<0?99:iy)||lx.length-ly.length||lx.localeCompare(ly,undefined,{numeric:true,sensitivity:'base'});
    });
    return cssIndex(arr);
  };
  // Live styles may override the value of a known authored variable, but they
  // must never expand autocomplete with WordPress, theme, Bricks or MV UI
  // implementation tokens from the current admin document.
  collectCssomSuggestions('var');
  let varIndex=orderVars([...(remoteSuggestions?.variables||[]),...(vars||[]).map(v=>cssTokenName(v.name)).filter(Boolean)]);
  buildCssVarMeta(varIndex,vars,remoteSuggestions?.variable_meta);
  varIndex=varIndex.filter(item=>{
    const meta=cssVarMeta(item.label);
    return !!(meta&&meta.value);
  });
  const originalVarOrder=new Map(varIndex.map((item,index)=>[item.label,index]));
  varIndex.sort((a,b)=>{
    const am=cssVarMeta(a.label),bm=cssVarMeta(b.label);
    const aDefined=!!(am&&am.value),bDefined=!!(bm&&bm.value);
    return Number(bDefined)-Number(aDefined)
      ||(CSS_VAR_SOURCE_RANK[bm?.source]||0)-(CSS_VAR_SOURCE_RANK[am?.source]||0)
      ||(originalVarOrder.get(a.label)||0)-(originalVarOrder.get(b.label)||0);
  });
  return{
    vars:varIndex,
    classes:cssIndex(remoteSuggestions?.classes||[]),
    ids:cssIndex(remoteSuggestions?.ids||[]),
    selectors:cssIndex([...(remoteSuggestions?.selectors||[]),...CSS_SELECTOR_HINTS]),
    props:cssIndex(CSS_PROPS),
    values:cssIndex(CSS_VALUES)
  };
}

/* One suggestion index for every MV editor. Theme Styles used to load the
   endpoint when its panel opened, while CSS Studio and CSS Recipes each made a
   separate one-shot request during their own mount. A request that happened
   before the REST nonce/runtime was ready left that editor with an empty index
   for the rest of the page. Keep a single cache/promise and let CssEditor own
   the subscription so every CodeMirror receives the same payload. */
const EMPTY_CSS_SUGGESTIONS={variables:[],classes:[],ids:[],selectors:[],sources:[],variable_meta:{}};
let sharedCssSuggestions=EMPTY_CSS_SUGGESTIONS;
let sharedCssSuggestionsRequest=null;
function cssSuggestionPayloadHasData(payload){
  return !!(payload&&['variables','classes','ids','selectors'].some(key=>Array.isArray(payload[key])&&payload[key].length));
}
function mergeCssSuggestionPayloads(base,extra){
  const left=base||EMPTY_CSS_SUGGESTIONS;
  const right=extra||EMPTY_CSS_SUGGESTIONS;
  const mergeList=key=>[...new Set([...(left[key]||[]),...(right[key]||[])])];
  return{
    ...left,...right,
    variables:mergeList('variables'),
    classes:mergeList('classes'),
    ids:mergeList('ids'),
    selectors:mergeList('selectors'),
    sources:mergeList('sources'),
    variable_meta:{...(left.variable_meta||{}),...(right.variable_meta||{})}
  };
}
function loadSharedCssSuggestions(force=false){
  if(!force&&cssSuggestionPayloadHasData(sharedCssSuggestions))return Promise.resolve(sharedCssSuggestions);
  if(sharedCssSuggestionsRequest)return sharedCssSuggestionsRequest;
  sharedCssSuggestionsRequest=api.g('advanced-css/suggestions?_nc='+Date.now()).then(payload=>{
    if(payload&&!payload.code){
      sharedCssSuggestions=mergeCssSuggestionPayloads(EMPTY_CSS_SUGGESTIONS,payload);
      try{window.dispatchEvent(new CustomEvent('ve-css-suggestions-updated',{detail:sharedCssSuggestions}));}catch(e){}
    }
    return sharedCssSuggestions;
  }).finally(()=>{sharedCssSuggestionsRequest=null;});
  return sharedCssSuggestionsRequest;
}
function useSharedCssSuggestions(provided){
  const[current,setCurrent]=useState(()=>mergeCssSuggestionPayloads(sharedCssSuggestions,provided));
  useEffect(()=>{
    let alive=true;
    const sync=event=>{
      const payload=event?.detail||sharedCssSuggestions;
      if(alive)setCurrent(mergeCssSuggestionPayloads(payload,provided));
    };
    const refresh=()=>loadSharedCssSuggestions(true).then(payload=>{if(alive)setCurrent(mergeCssSuggestionPayloads(payload,provided));});
    window.addEventListener('ve-css-suggestions-updated',sync);
    window.addEventListener('ve-variables-updated',refresh);
    window.addEventListener('ve:variables-updated',refresh);
    loadSharedCssSuggestions().then(payload=>{if(alive)setCurrent(mergeCssSuggestionPayloads(payload,provided));});
    return()=>{
      alive=false;
      window.removeEventListener('ve-css-suggestions-updated',sync);
      window.removeEventListener('ve-variables-updated',refresh);
      window.removeEventListener('ve:variables-updated',refresh);
    };
  },[]);
  useEffect(()=>{setCurrent(mergeCssSuggestionPayloads(sharedCssSuggestions,provided));},[provided]);
  return current;
}
try{loadSharedCssSuggestions();}catch(e){}
function cssSuggestions(text,pos,pools,disabledSources){
  const before=String(text||'').slice(0,pos);
  const m=cssSuggestionMatch(before);
  if(!m)return[];
  const q=m.token.toLowerCase();
  const ctx=cssContext(text,pos);
  const off=name=>(disabledSources||[]).includes(name);
  const cleanQ=(m.kind==='var'&&q==='--')||(m.kind==='class'&&q==='.')||(m.kind==='id'&&q==='#')||(m.kind==='atrule'&&q==='@')?'':q;
  if(m.kind==='atrule'){
    return cssLookup(pools?.selectors||[],cleanQ,CSS_HINT_LIMIT).filter(x=>String(x).startsWith('@'));
  }
  if(m.kind==='var'){
    if(off("Mimam's Var"))return[];
    return cssLookup(pools?.vars||[],cleanQ,CSS_HINT_LIMIT);
  }
  if(m.kind==='class')return off('CSS Classes')?[]:cssLookup(pools?.classes||[],cleanQ,CSS_HINT_LIMIT);
  if(m.kind==='id')return off('Element IDs')?[]:cssLookup(pools?.ids||[],cleanQ,CSS_HINT_LIMIT);
  if(m.kind==='selector')return cssLookup(pools?.selectors||[],cleanQ,CSS_HINT_LIMIT);
  if(ctx.inValue)return cssLookup(pools?.values||[],q,CSS_HINT_LIMIT);
  if(ctx.inBlock)return cssLookup(pools?.props,q,CSS_HINT_LIMIT);
  return cssLookup(pools?.selectors,q,CSS_HINT_LIMIT);
}
/* One description of a row, rendered twice — Preact for the plain editor and
   raw DOM for CodeMirror's hint list. Keeping the shape in one place is what
   stops the two lists drifting apart the way they did before. */
function cssSuggestRowParts(label){
  const name=String(label||'');
  if(name.indexOf('--')!==0)return null;
  const meta=cssVarMeta(name);
  if(!meta)return null;
  const kind=meta.kind||'miss';
  let valueText=meta.value||'';
  let valueMiss=false;
  if(meta.cycle){valueText='circular reference';valueMiss=true;}
  else if(!valueText){valueText='not defined';valueMiss=true;}
  let chainText='';
  if(meta.chain&&meta.chain.length){
    const hops=meta.chain.length>2?[meta.chain[0],'…',meta.chain[meta.chain.length-1]]:meta.chain;
    chainText=hops.join(' → ')+' = ';
  }
  return{
    name,kind,valueText,valueMiss,chainText,
    source:meta.source||'Sheet',
    sourceClass:meta.source==='MV'?'mv':(meta.source==='Theme'?'ts':''),
    swatch:kind==='color'?meta.value:'',
    gradient:kind==='grad'?meta.value:'',
    font:kind==='font'?meta.value:'',
    bar:meta.bar||0,
    num:kind==='num'?String(meta.value).slice(0,4):''
  };
}
function cssSuggestPreviewVnode(p){
  if(p.kind==='color')return h('span',{class:'ve-sg-pv color'},h('i',{style:{background:p.swatch}}));
  if(p.kind==='grad')return h('span',{class:'ve-sg-pv',style:{background:p.gradient}});
  if(p.kind==='len')return h('span',{class:'ve-sg-pv len'},h('i',{style:{width:p.bar+'px'}}));
  if(p.kind==='font')return h('span',{class:'ve-sg-pv font',style:{fontFamily:p.font}},'Ag');
  if(p.kind==='num')return h('span',{class:'ve-sg-pv num'},p.num);
  if(p.kind==='radius')return h('span',{class:'ve-sg-pv radius'},h('i',null));
  if(p.kind==='shadow')return h('span',{class:'ve-sg-pv shadow'},h('i',null));
  if(p.kind==='miss')return h('span',{class:'ve-sg-pv miss'},'?');
  return h('span',{class:'ve-sg-pv'});
}
function cssSuggestRowVnode(label){
  const p=cssSuggestRowParts(label);
  if(!p)return String(label||'');
  return h('span',{class:'ve-sg-row'},
    cssSuggestPreviewVnode(p),
    h('span',{class:'ve-sg-txt'},
      h('span',{class:'ve-sg-nm'},p.name),
      h('span',{class:'ve-sg-val'+(p.valueMiss?' miss':'')},p.chainText+p.valueText)),
    h('span',{class:'ve-sg-src '+p.sourceClass},p.source));
}
function cssSuggestRowElement(doc,label){
  const p=cssSuggestRowParts(label);
  if(!p)return null;
  const make=(tag,cls)=>{const el=doc.createElement(tag);if(cls)el.className=cls;return el;};
  const row=make('span','ve-sg-row');
  const pv=make('span','ve-sg-pv'+(p.kind?' '+p.kind:''));
  if(p.kind==='color'){const i=make('i');i.style.background=p.swatch;pv.appendChild(i);}
  else if(p.kind==='grad')pv.style.background=p.gradient;
  else if(p.kind==='len'){const i=make('i');i.style.width=p.bar+'px';pv.appendChild(i);}
  else if(p.kind==='font'){pv.style.fontFamily=p.font;pv.textContent='Ag';}
  else if(p.kind==='num')pv.textContent=p.num;
  else if(p.kind==='radius'||p.kind==='shadow')pv.appendChild(make('i'));
  else if(p.kind==='miss')pv.textContent='?';
  row.appendChild(pv);
  const txt=make('span','ve-sg-txt');
  const nm=make('span','ve-sg-nm');nm.textContent=p.name;
  const val=make('span','ve-sg-val'+(p.valueMiss?' miss':''));val.textContent=p.chainText+p.valueText;
  txt.appendChild(nm);txt.appendChild(val);row.appendChild(txt);
  const src=make('span','ve-sg-src '+p.sourceClass);src.textContent=p.source;
  row.appendChild(src);
  return row;
}
function cssCommitSuggestion(item,match){
  const label=typeof item==='string'?item:String(item?.value||item?.label||'');
  if(!label)return{insert:'',cursor:null};
  if(match&&match.kind==='css'&&CSS_PROPS.includes(label))return{insert:label+':  ;',cursor:label.length+3};
  if(label.indexOf('--')===0&&(!match||!match.inVar)){
    const insert='var('+label+')';
    return{insert,cursor:insert.length};
  }
  return{insert:label,cursor:label.length};
}
function cssNextIndent(text,pos){
  const before=String(text||'').slice(0,pos);
  const line=before.split('\n').pop()||'';
  const base=(line.match(/^\s*/)||[''])[0];
  const trimmed=line.trim();
  if(!trimmed)return base;
  if(trimmed.endsWith('{'))return base+'  ';
  return trimmed.endsWith(';')?base:base+'  ';
}
function cssEnterInsert(text,pos){
  const s=String(text||'');
  const before=s.slice(0,pos);
  const after=s.slice(pos);
  const line=before.split('\n').pop()||'';
  const base=(line.match(/^\s*/)||[''])[0];
  const trimmed=line.trim();
  const ind=cssNextIndent(s,pos);
  if(trimmed.endsWith('{')&&after.trimStart().startsWith('}')){
    return{text:'\n'+ind+'\n'+base,cursor:1+ind.length};
  }
  return{text:'\n'+ind,cursor:1+ind.length};
}
function autoFormatCss(text){
  return String(text||'').replace(/;\s*/g,';\n  ').replace(/\{\s*/g,'{\n  ').replace(/\s*\}/g,'\n}\n').replace(/\n\s*\n\s*\n/g,'\n\n');
}
function cssEsc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function cssHighlight(text){
  const s=String(text||'');
  const re=/\/\*[\s\S]*?\*\/|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|#[0-9a-f]{3,8}\b|--[a-z0-9-]+|\b[a-z-]+(?=\s*:)|\b\d+(?:\.\d+)?(?:px|rem|em|%|vw|vh)?\b|[{}:;(),]/gi;
  let out='',last=0,m;
  while((m=re.exec(s))){
    out+=cssEsc(s.slice(last,m.index));
    const t=m[0];let cls='tok-punc';
    if(t.startsWith('/*'))cls='tok-comment';
    else if(t[0]==='"'||t[0]==="'")cls='tok-string';
    else if(t[0]==='#')cls='tok-color';
    else if(t.startsWith('--'))cls='tok-var';
    else if(/^\d/.test(t))cls='tok-num';
    else if(/^[a-z-]+$/i.test(t))cls='tok-prop';
    out+='<span class="'+cls+'">'+cssEsc(t)+'</span>';
    last=re.lastIndex;
  }
  out+=cssEsc(s.slice(last));
  return out||' ';
}
function cssCaretPos(el){
  if(!el)return{left:46,top:34};
  const text=el.value.slice(0,el.selectionStart||0);
  const lines=text.split('\n');
  const line=lines.length-1;
  const col=(lines[lines.length-1]||'').length;
  const left=38+10+Math.min(col*6.7,Math.max(80,el.clientWidth-190));
  const top=10+(line*17.6)-el.scrollTop+24;
  const maxTop=Math.max(32,el.clientHeight-145);
  return{left,top:Math.max(12,Math.min(top,maxTop))};
}
function cmHintFactory(poolsRef,disabledRef,reportRef){
  return function(cm){
    const cur=cm.getCursor();
    const pos=cm.indexFromPos(cur);
    const text=cm.getValue();
    const before=text.slice(0,pos);
    const m=cssSuggestionMatch(before);
    // Record every request. Four things can each produce an empty list, and
    // from the outside they are indistinguishable — which is what made this
    // take so long to pin down.
    const note=info=>{if(reportRef)reportRef.current=info;};
    if(!m){note({token:'',kind:'',count:0,pool:0,reason:'the caret is not somewhere a suggestion applies'});return{list:[],from:cur,to:cur};}
    const pools=poolsRef.current||{};
    const poolSize=['vars','classes','ids','selectors','props','values'].reduce((n,k)=>n+((pools[k]||[]).length),0);
    const hits=cssSuggestions(text,pos,poolsRef.current,disabledRef.current);
    note({token:m.token,kind:m.kind,count:hits.length,pool:poolSize,
      reason:poolSize===0?'nothing has been collected to suggest from'
        :(hits.length===0?'nothing in the collected suggestions matches':'')});
    const list=hits.map(item=>{
      const label=typeof item==='string'?item:item.label;
      return{
        text:label,
        displayText:label,
        className:cssSuggestRowParts(label)?'ve-sg-hint':undefined,
        render:function(el){
          const row=cssSuggestRowElement(el.ownerDocument||document,label);
          if(row)el.appendChild(row);else el.appendChild((el.ownerDocument||document).createTextNode(label));
        },
        hint:function(editor){
          const packed=cssCommitSuggestion(item,m);
          const from=editor.posFromIndex(pos-(m.replaceLength||0));
          const to=editor.posFromIndex(pos);
          editor.replaceRange(packed.insert,from,to,'complete');
          const nextIndex=pos-(m.replaceLength||0)+(packed.cursor==null?packed.insert.length:packed.cursor);
          editor.setCursor(editor.posFromIndex(nextIndex));
        }
      };
    });
    return{list,from:cm.posFromIndex(pos-(m.replaceLength||0)),to:cur};
  };
}
function cmShouldHint(editor,typed){
  const cur=editor.getCursor();
  const pos=editor.indexFromPos(cur);
  const before=editor.getValue().slice(0,pos);
  const m=cssSuggestionMatch(before);
  if(!m)return false;
  if(m.kind==='atrule')return m.token.length>=1;
  if(m.kind==='var')return m.token.length>=2;
  if(m.kind==='class'||m.kind==='id')return m.token.length>=1;
  const ctx=cssContext(editor.getValue(),pos);
  return /^[a-z-]$/i.test(typed||'')&&m.token.length>=(ctx.inValue?1:2);
}
/* Every showHint call used to sit unguarded inside a timer. When it threw there
   was nothing to see — which is how an editor with no suggestions went
   unexplained for so long. Report it instead. */
/* Put the opened hint list next to the caret, in viewport terms, and say so if
   it had drifted. CodeMirror's own positioning depends on the container, the
   page scroll and the body's geometry agreeing; when they do not the list opens
   correctly somewhere off-screen, which looks exactly like nothing happening. */
function veActiveHintNode(editor,container){
  let node=null;
  try{
    const active=editor&&editor.state&&editor.state.completionActive;
    node=active&&active.widget&&active.widget.hints;
    if(node&&node.isConnected)return node;
  }catch(e){}
  let nodes=[];
  try{nodes=Array.from((container||document).querySelectorAll('.CodeMirror-hints'));}catch(e){}
  if(!nodes.length){try{nodes=Array.from(document.querySelectorAll('.CodeMirror-hints'));}catch(e){}}
  return nodes.length?nodes[nodes.length-1]:null;
}
function veAnchorHints(editor,container){
  const node=veActiveHintNode(editor,container);
  if(!node)return{shown:false,moved:false,covered:false,over:''};
  try{
    if(container&&node.parentNode!==container)container.appendChild(node);
    if(container&&container.parentNode===document.body&&document.body.lastElementChild!==container)document.body.appendChild(container);
  }catch(e){}
  const placed=vePlaceHintsAtCaret(node,editor);
  const seen=veCheckHintsVisible(node);
  return{shown:seen.shown,moved:placed,covered:seen.covered,over:seen.over,portal:true};
}
/* Geometry is not visibility. A list can sit exactly where it belongs and still
   be painted under something else, and from the outside that is identical to
   nothing happening — which is where this whole hunt finally landed.

   Raising z-index alone is not enough. A competing overlay can sit at the
   maximum too, and on a tie the element later in the document wins; a z-index
   also cannot climb out of an ancestor stacking context. So lift by both means:
   take the top of the range AND move the container to the end of the body. */
/* The portal must be a direct body child. Theme Styles is translated into view,
   and transformed ancestors become containing blocks for fixed descendants.
   A viewport coordinate placed inside that panel is therefore measured twice
   and can land behind the studio backdrop. A root-level fixed portal has one
   coordinate space and outranks the backdrop's documented z-index. */
function veHintContainerFor(host){
  const parent=document.body;
  let container=document.getElementById('ve-cm-hints-root');
  if(!container){
    container=document.createElement('div');
    container.className='ve-cm-hints-root';
    container.id='ve-cm-hints-root';
    parent.appendChild(container);
  }
  if(parent.lastElementChild!==container)parent.appendChild(container);
  return container;
}
/* Place the root-level list at the caret, but keep it inside the editor that
   owns it. The body portal avoids transformed-panel clipping; the editor's
   visible rectangle remains the interaction boundary the user can reason
   about. */
function vePlaceHintsAtCaret(node,editor){
  let caret=null,editorRect=null;
  try{caret=editor.cursorCoords(null,'window');}catch(e){}
  try{editorRect=editor.getWrapperElement().getBoundingClientRect();}catch(e){}
  if(!caret)return false;
  try{
    if(node.matches&&node.matches(':popover-open')&&typeof node.hidePopover==='function')node.hidePopover();
    node.removeAttribute('popover');
  }catch(e){}
  node.style.setProperty('display','block','important');
  node.style.setProperty('position','fixed','important');
  node.style.setProperty('pointer-events','auto','important');
  const vw=window.innerWidth||0,vh=window.innerHeight||0;
  const editorLeft=Math.max(8,editorRect?editorRect.left+4:8);
  const editorRight=Math.min(vw-8,editorRect?editorRect.right-4:vw-8);
  const editorTop=Math.max(8,editorRect?editorRect.top+4:8);
  const editorBottom=Math.min(vh-8,editorRect?editorRect.bottom-4:vh-8);
  const boundaryWidth=Math.max(40,editorRight-editorLeft);
  const fixedWidth=Math.max(40,Math.min(300,boundaryWidth));
  node.style.setProperty('width',fixedWidth+'px','important');
  node.style.setProperty('max-width',boundaryWidth+'px','important');
  const initialRect=node.getBoundingClientRect();
  const naturalHeight=Math.min(initialRect.height||180,260);
  const roomBelow=Math.max(0,editorBottom-caret.bottom-4);
  const roomAbove=Math.max(0,caret.top-editorTop-4);
  const placeBelow=roomBelow>=Math.min(naturalHeight,140)||roomBelow>=roomAbove;
  const available=Math.max(24,Math.min(260,placeBelow?roomBelow:roomAbove));
  node.style.setProperty('max-height',Math.floor(available)+'px','important');
  node.style.setProperty('overflow-x','hidden','important');
  node.style.setProperty('overflow-y','auto','important');
  const fitted=node.getBoundingClientRect();
  const height=Math.min(fitted.height||naturalHeight,available),width=fitted.width||fixedWidth;
  const desiredTop=placeBelow?caret.bottom+4:caret.top-height-4;
  const top=Math.max(editorTop,Math.min(desiredTop,editorBottom-height));
  node.style.setProperty('top',Math.round(top)+'px','important');
  node.style.setProperty('right','auto','important');
  node.style.setProperty('bottom','auto','important');
  node.style.setProperty('left',Math.round(Math.max(editorLeft,Math.min(caret.left,editorRight-width)))+'px','important');
  return true;
}
function veDescribeElement(el){
  if(!el)return'something on the page';
  let name='';
  try{
    name=String(el.tagName||'').toLowerCase();
    if(el.id)name+='#'+el.id;
    else{
      const cls=String((el.className&&el.className.baseVal)||el.className||'').trim().split(/\s+/)[0];
      if(cls)name+='.'+cls;
    }
  }catch(e){}
  return name||'something on the page';
}
function veLiftHints(node){
  try{
    node.style.setProperty('z-index','2147483647','important');
    node.style.setProperty('position','fixed','important');
    node.style.setProperty('pointer-events','auto','important');
    const root=veHintContainerFor();
    if(node.parentNode!==root)root.appendChild(node);
    if(document.body.lastElementChild!==root)document.body.appendChild(root);
  }catch(e){}
}
function veHintsHitTest(node){
  const rect=node.getBoundingClientRect();
  const x=Math.round(rect.left+Math.min(rect.width,60)/2);
  const y=Math.round(rect.top+Math.min(rect.height,20)/2);
  let hit=null;
  try{hit=document.elementFromPoint(x,y);}catch(e){}
  return{hit,blocked:!!(hit&&hit!==node&&!node.contains(hit))};
}
function veCheckHintsVisible(node){
  let covered=false,over='',hidden=false,reason='';
  try{
    const rect=node.getBoundingClientRect();
    const style=getComputedStyle(node);
    hidden=style.display==='none'||style.visibility==='hidden'||Number(style.opacity)===0||rect.width===0||rect.height===0;
    if(hidden){
      reason=style.display==='none'?'display:none':style.visibility==='hidden'?'visibility:hidden':Number(style.opacity)===0?'opacity:0':'zero-size';
      return{shown:false,covered:false,over:'',hidden:true,reason:reason};
    }
    let probe=veHintsHitTest(node);
    if(probe.blocked){
      veLiftHints(node);
      probe=veHintsHitTest(node);
      covered=probe.blocked;
      // Name it. Guessing at the culprit is what cost the last several rounds.
      if(covered)over=veDescribeElement(probe.hit);
    }
  }catch(e){}
  return{shown:!covered&&!hidden,covered,over,hidden,reason};
}
function veAutocompleteSnapshot(){
  const nodes=Array.from(document.querySelectorAll('.CodeMirror-hints'));
  return{
    userAgent:String(navigator.userAgent||''),
    count:nodes.length,
    nodes:nodes.map(node=>{
      const rect=node.getBoundingClientRect();
      const x=Math.round(rect.left+Math.min(rect.width,60)/2);
      const y=Math.round(rect.top+Math.min(rect.height,20)/2);
      let stack=[];
      try{stack=document.elementsFromPoint(x,y).slice(0,8).map(veDescribeElement);}catch(e){}
      const style=getComputedStyle(node);
      const parent=node.parentElement;
      const parentStyle=parent?getComputedStyle(parent):null;
      return{
        id:node.id||'',connected:node.isConnected,parent:veDescribeElement(parent),popover:node.getAttribute('popover'),
        rect:{left:rect.left,top:rect.top,right:rect.right,bottom:rect.bottom,width:rect.width,height:rect.height},
        inline:node.style.cssText,position:style.position,display:style.display,
        visibility:style.visibility,opacity:style.opacity,pointerEvents:style.pointerEvents,zIndex:style.zIndex,
        parentPosition:parentStyle?parentStyle.position:'',parentPointerEvents:parentStyle?parentStyle.pointerEvents:'',
        parentZIndex:parentStyle?parentStyle.zIndex:'',stack:stack
      };
    })
  };
}
function veInstallAutocompleteInspector(){
  const inspect=()=>{
    const report=veAutocompleteSnapshot();
    try{console.log('[Mimam\'s Var] autocomplete',report);}catch(e){}
    return report;
  };
  try{window.mimamVarInspectAutocomplete=inspect;}catch(e){}
  try{if(window.top&&window.top!==window)window.top.mimamVarInspectAutocomplete=inspect;}catch(e){}
}
veInstallAutocompleteInspector();
function veShowHint(editor,options,onFail){
  try{
    if(typeof editor.showHint!=='function'){
      if(onFail)onFail('the editor build on this page has no autocomplete addon');
      return false;
    }
    editor.showHint(options);
    return true;
  }catch(error){
    if(onFail)onFail((error&&error.message)||'the suggestion list could not open');
    return false;
  }
}
function CssCodeMirrorEditor({value,onChange,vars,remoteSuggestions,scss,disabledSources,mode,noHints,autoHeight}){
  const hostRef=useRef();
  const cmRef=useRef(null);
  const onChangeRef=useRef(onChange);
  const commitTimerRef=useRef(null);
  const poolsRef=useRef(cssSuggestionPools(vars,remoteSuggestions));
  const disabledRef=useRef(disabledSources||[]);
  const[hintFault,setHintFault]=useState('');
  const[hintNote,setHintNote]=useState('');
  const hintReportRef=useRef(null);
  const reportHint=useCallback(reason=>setHintFault(String(reason||'')),[]);
  // Called just after a hint was asked for: compare what the factory produced
  // with whether a list actually reached the page.
  const auditHint=useCallback(editor=>{
    const info=hintReportRef.current;
    if(!info){setHintNote('');return;}
    let state={shown:false,moved:false};
    try{state=veAnchorHints(editor,veHintContainerFor(hostRef.current));}catch(e){}
    if(info.count>0&&!state.shown){
      setHintFault(state.hidden
        ?info.count+' suggestions opened but the list is hidden ('+(state.reason||'unknown hidden state')+')'
        :state.covered
          ?info.count+' suggestions opened but '+(state.over||'something on the page')+' is painted over them'
          :info.count+' suggestions were found but the list could not be shown');
      setHintNote('');
      return;
    }
    setHintFault('');
    setHintNote(info.count>0?'':(info.reason?(info.token?'No suggestions for “'+info.token+'” — '+info.reason:''):''));
  },[]);
  useEffect(()=>{onChangeRef.current=onChange;},[onChange]);
  useEffect(()=>{poolsRef.current=cssSuggestionPools(vars,remoteSuggestions);},[vars,remoteSuggestions]);
  useEffect(()=>{disabledRef.current=disabledSources||[];},[disabledSources]);
  useEffect(()=>{
    const CM=veCodeMirror();
    if(!hostRef.current||!CM)return;
    const hintContainer=veHintContainerFor(hostRef.current);
    const hintFactory=cmHintFactory(poolsRef,disabledRef,hintReportRef);
    const cm=CM(hostRef.current,{
      value:value||'',
      mode:mode||(scss?'text/x-scss':'css'),
      lineNumbers:true,
      lineWrapping:true,
      indentUnit:2,
      tabSize:2,
      viewportMargin:autoHeight?Infinity:10,
      theme:'default',
      autoCloseBrackets:false,
      hintOptions:{hint:hintFactory,completeSingle:false,container:hintContainer,extraKeys:{}},
      extraKeys:{
        'Ctrl-Space':editor=>veShowHint(editor,{hint:hintFactory,completeSingle:false,container:hintContainer},reportHint),
        'Cmd-Space':editor=>veShowHint(editor,{hint:hintFactory,completeSingle:false,container:hintContainer},reportHint),
        'Tab':editor=>{
          if(editor.state.completionActive){editor.state.completionActive.pick();return;}
          const cur=editor.getCursor();
          const before=editor.getRange({line:cur.line,ch:0},cur);
          const m=before.match(/(\d+(?:\.\d+)?(?:px|rem|em|%)?)\s*([-+*/])\s*(\d+(?:\.\d+)?(?:px|rem|em|%)?)$/);
          if(m){
            const from={line:cur.line,ch:cur.ch-m[0].length};
            editor.replaceRange('calc('+m[0]+')',from,cur,'input');
            editor.setCursor({line:cur.line,ch:from.ch+6+m[0].length});
            return;
          }
          veShowHint(editor,{hint:hintFactory,completeSingle:false,container:hintContainer},reportHint);
        },
        'Enter':editor=>{
          const cur=editor.getCursor();
          const pos=editor.indexFromPos(cur);
          const packed=cssEnterInsert(editor.getValue(),pos);
          editor.replaceSelection(packed.text,'end','input');
          editor.setCursor(editor.posFromIndex(pos+packed.cursor));
        }
      }
    });
    cmRef.current=cm;
    const hintObserver=typeof MutationObserver!=='undefined'?new MutationObserver(()=>{
      if(cm.state.completionActive&&veActiveHintNode(cm,hintContainer))auditHint(cm);
    }):null;
    if(hintObserver)hintObserver.observe(hintContainer,{childList:true});
    const wheelHost=cm.getWrapperElement();
    const diagnostic={cm,host:hostRef.current,wrapper:wheelHost,lastWheel:null};
    // Broker disabled: rely on native CodeMirror scroll (reaches the last line, then chains
    // to the panel). Registration left out so the window wheel broker never intercepts. (#35/#36)
    // veCodeEditorScrollRegistry.add(diagnostic);
    const scheduleCommit=editor=>{
      if(commitTimerRef.current)clearTimeout(commitTimerRef.current);
      commitTimerRef.current=setTimeout(()=>{
        commitTimerRef.current=null;
        onChangeRef.current(editor.getValue());
      },140);
    };
    const flushCommit=editor=>{
      if(commitTimerRef.current)clearTimeout(commitTimerRef.current);
      commitTimerRef.current=null;
      onChangeRef.current(editor.getValue());
    };
    cm.on('beforeChange',(editor,change)=>{
      if(change.origin!=='+input'||!change.text||change.text.length!==1||change.text[0]!=='{')return;
      const selected=editor.getRange(change.from,change.to);
      change.update(change.from,change.to,[selected?'{'+selected+'}':'{}']);
      editor.state.veBraceCursor={line:change.from.line,ch:change.from.ch+1};
    });
    cm.on('changes',scheduleCommit);
    cm.on('changes',editor=>{
      if(!editor.state.veBraceCursor)return;
      const cur=editor.state.veBraceCursor;
      editor.state.veBraceCursor=null;
      editor.setCursor(cur);
    });
    cm.on('blur',flushCommit);
    if(!noHints)cm.on('inputRead',(editor,change)=>{
      const t=(change.text||[]).join('');
      if(cmShouldHint(editor,t)){
        clearTimeout(editor.state.veHintTimer);
        if(editor.state.completionActive)return;
        editor.state.veHintTimer=setTimeout(()=>{
          veShowHint(editor,{hint:hintFactory,completeSingle:false,container:hintContainer},reportHint);
          setTimeout(()=>auditHint(editor),0);
        },90);
      }
    });
    let resizeObserver=null;
    let resizeFrame=0;
    let lastWidth=0;
    let lastHeight=0;
    const syncGeometry=()=>{
      if(resizeFrame)cancelAnimationFrame(resizeFrame);
      resizeFrame=requestAnimationFrame(()=>{
        resizeFrame=0;
        const host=hostRef.current;
        if(!host||!cmRef.current)return;
        const rect=host.getBoundingClientRect();
        const nextWidth=Math.max(0,Math.floor(rect.width));
        const nextHeight=Math.max(0,Math.floor(rect.height));
        if(!nextWidth||!nextHeight)return;
        if(nextWidth!==lastWidth||nextHeight!==lastHeight){
          lastWidth=nextWidth;
          lastHeight=nextHeight;
          cm.setSize('100%',nextHeight);
        }
        cm.refresh();
      });
    };
    syncGeometry();
    const refreshTimer=setTimeout(syncGeometry,60);
    if(typeof ResizeObserver!=='undefined'){
      resizeObserver=new ResizeObserver(syncGeometry);
      resizeObserver.observe(hostRef.current);
    }
    window.addEventListener('resize',syncGeometry);
    if(document.fonts&&document.fonts.ready)document.fonts.ready.then(syncGeometry).catch(()=>{});
    return()=>{
      clearTimeout(refreshTimer);
      if(resizeFrame)cancelAnimationFrame(resizeFrame);
      if(resizeObserver)resizeObserver.disconnect();
      if(hintObserver)hintObserver.disconnect();
      window.removeEventListener('resize',syncGeometry);
      veCodeEditorScrollRegistry.delete(diagnostic);
      if(commitTimerRef.current)clearTimeout(commitTimerRef.current);
      if(cm.state.veHintTimer)clearTimeout(cm.state.veHintTimer);
      try { cm.closeHint && cm.closeHint(); } catch(e) {}
      cm.toTextArea?cm.toTextArea():cm.getWrapperElement().remove();
      try { hintContainer && hintContainer.querySelectorAll('.CodeMirror-hints').forEach(el => el.remove()); } catch(e) {}
      cmRef.current=null;
    };
  },[]);
  useEffect(()=>{const cm=cmRef.current;if(cm&&value!==cm.getValue()&&!cm.hasFocus())cm.setValue(value||'');},[value]);
  return h(Fragment,null,
    h('div',{class:'ve-cm-host',ref:hostRef}),
    hintFault&&h('div',{class:'ve-code-basic'},ph('warning'),
      h('span',null,'Suggestions could not be displayed \u2014 '+hintFault+'.')),
    !hintFault&&hintNote&&h('div',{class:'ve-code-hintnote'},hintNote));
}
/* MV ships its own CodeMirror. The old check inferred whether one was usable by
   looking for a <link> tag whose href mentioned codemirror, and silently
   dropped to a plain textarea when the guess came out false — so whether you
   got a real editor depended on what else the host page happened to load. MV
   now loads its own copy when it is missing, and the textarea is only ever
   reached if those bundled files cannot be fetched at all. */
const VE_CM_FILES=['codemirror.js','mode-xml.js','mode-javascript.js','mode-css.js','mode-htmlmixed.js','closebrackets.js','show-hint.js'];
const VE_CM_STYLES=['codemirror.scoped.css','show-hint.css'];
function veCodeMirrorBase(){
  const asset=String((window.vePanel&&window.vePanel.assetUrl)||'');
  return asset?asset.replace(/\/?$/,'/')+'vendor/codemirror/':'';
}
/* window.CodeMirror is shared ground. Other plugins ship their own build — this
   site runs Code2Bricks, which does — and whichever loads last owns the global.
   If that one has no show-hint addon, MV's editor still mounts and looks
   completely normal, then every showHint() call throws inside a timer where
   nobody sees it: a real editor that silently never suggests anything.
   So MV takes a reference to the build it verified and uses that from then on,
   whatever the global becomes afterwards. */
let VE_CM=null;
function veCodeMirrorUsable(CM){
  return !!(CM&&CM.prototype&&typeof CM.prototype.showHint==='function');
}
function veCaptureCodeMirror(){
  if(veCodeMirrorUsable(VE_CM))return VE_CM;
  if(veCodeMirrorUsable(window.CodeMirror)){VE_CM=window.CodeMirror;return VE_CM;}
  return null;
}
function veCodeMirror(){return veCaptureCodeMirror();}
function veCodeMirrorLive(){return !!veCaptureCodeMirror();}
/* Only MV's own scoped sheet counts. Another plugin's CodeMirror CSS is not
   interchangeable — it is unscoped and would style, or fight over, MV's
   editors. Code2Bricks in particular ships one. */
function veCodeMirrorStyled(){
  try{
    return Array.from(document.querySelectorAll('link[rel="stylesheet"]')).some(link=>{
      const href=String(link.href||'').toLowerCase();
      return href.indexOf('/vendor/codemirror/')>=0&&href.indexOf('code2bricks')<0;
    });
  }catch(e){return false;}
}
function veLoadScriptOnce(src){
  return new Promise((resolve,reject)=>{
    const existing=document.querySelector('script[data-ve-cm="'+src+'"]');
    if(existing){
      if(existing.dataset.veLoaded==='1')return resolve();
      existing.addEventListener('load',()=>resolve());
      existing.addEventListener('error',()=>reject(new Error(src)));
      return;
    }
    const el=document.createElement('script');
    el.src=src;el.async=false;el.dataset.veCm=src;
    el.addEventListener('load',()=>{el.dataset.veLoaded='1';resolve();});
    el.addEventListener('error',()=>reject(new Error(src)));
    document.head.appendChild(el);
  });
}
let VE_CM_READY=null;
function ensureCodeMirrorRuntime(){
  if(VE_CM_READY)return VE_CM_READY;
  const base=veCodeMirrorBase();
  if(base&&!veCodeMirrorStyled()){
    VE_CM_STYLES.forEach(file=>{
      const link=document.createElement('link');
      link.rel='stylesheet';link.href=base+file;link.dataset.veCm='1';
      document.head.appendChild(link);
    });
  }
  if(veCodeMirrorLive()){VE_CM_READY=Promise.resolve(true);return VE_CM_READY;}
  if(!base){VE_CM_READY=Promise.resolve(false);return VE_CM_READY;}
  // Sequential, because the modes and addons all extend the core.
  VE_CM_READY=VE_CM_FILES.reduce((chain,file)=>chain.then(()=>veLoadScriptOnce(base+file)),Promise.resolve())
    .then(()=>{VE_CM=null;return veCodeMirrorLive();})
    .catch(()=>false);
  return VE_CM_READY;
}
// Start fetching as soon as the panel script runs, so the first editor opened
// does not have to wait for the round trip.
try{ensureCodeMirrorRuntime();}catch(e){}
function useCodeMirrorRuntime(){
  const[ready,setReady]=useState(veCodeMirrorLive);
  useEffect(()=>{
    if(ready)return undefined;
    let alive=true;
    ensureCodeMirrorRuntime().then(ok=>{if(alive&&ok)setReady(true);});
    return()=>{alive=false;};
  },[ready]);
  return ready;
}
function CssEditor(props){
  const ready=useCodeMirrorRuntime();
  const{value,onChange,vars,remoteSuggestions,scss,disabledSources,mode,noHints,autoHeight}=props;
  const completeSuggestions=useSharedCssSuggestions(remoteSuggestions);
  return ready
    ?h(CssCodeMirrorEditor,{value,onChange,vars,remoteSuggestions:completeSuggestions,scss,disabledSources,mode,noHints,autoHeight})
    :h(CssPlainEditor,{...props,remoteSuggestions:completeSuggestions});
}
/* Reached only when MV's own CodeMirror files cannot be fetched. */
function CssPlainEditor({value,onChange,vars,sourceOrder,remoteSuggestions,scss,disabledSources,mode,noHints,autoHeight}){
  const[draft,sDraft]=useState(value||'');
  const[sel,sSel]=useState([]);
  const[active,sActive]=useState(0);
  const[suggestPos,sSuggestPos]=useState({left:46,top:34});
  const ref=useRef();
  const hiRef=useRef();
  const commitRef=useRef(null);
  const suggestRef=useRef(null);
  const editingRef=useRef(false);
  const pools=useMemo(()=>cssSuggestionPools(vars,remoteSuggestions),[vars,remoteSuggestions]);
  useEffect(()=>{if(!editingRef.current)sDraft(value||'');},[value]);
  useEffect(()=>()=>{if(commitRef.current)clearTimeout(commitRef.current);if(suggestRef.current)cancelAnimationFrame(suggestRef.current);},[]);
  const commit=v=>{if(commitRef.current)clearTimeout(commitRef.current);commitRef.current=setTimeout(()=>onChange(v),120);};
  const commitNow=v=>{if(commitRef.current)clearTimeout(commitRef.current);commitRef.current=null;onChange(v);};
  const updateSuggest=()=>{const el=ref.current;if(!el){sSel([]);return;}sSel(cssSuggestions(el.value,el.selectionStart||0,pools,disabledSources));sSuggestPos(cssCaretPos(el));sActive(0);};
  const queueSuggest=()=>{if(suggestRef.current)cancelAnimationFrame(suggestRef.current);suggestRef.current=requestAnimationFrame(updateSuggest);};
  useEffect(()=>{const el=ref.current;if(el&&document.activeElement===el)queueSuggest();},[pools,disabledSources]);
  const setEditorValue=(next,pos)=>{
    sDraft(next);commit(next);sSel([]);
    setTimeout(()=>{const el=ref.current;if(!el)return;el.focus();if(pos!=null)el.setSelectionRange(pos,pos);},0);
  };
  const applySuggestion=(item)=>{
    const el=ref.current;if(!el)return;
    const start=el.selectionStart||0;const before=el.value.slice(0,start);const after=el.value.slice(el.selectionEnd||start);
    const m=cssSuggestionMatch(before);
    if(!m)return;
    const packed=cssCommitSuggestion(item,m);
    const insert=packed.insert;
    const cut=m.replaceLength||0;
    const next=before.slice(0,before.length-cut)+insert+after;
    const p=before.length-cut+(packed.cursor==null?insert.length:packed.cursor);
    setEditorValue(next,p);
  };
  const onKey=e=>{
    if((e.ctrlKey||e.metaKey)&&e.key===' '){e.preventDefault();updateSuggest();return;}
    if(e.key==='Tab'&&sel.length){e.preventDefault();applySuggestion(sel[active]||sel[0]);return;}
    if(e.key==='ArrowDown'&&sel.length){e.preventDefault();sActive(i=>Math.min(sel.length-1,i+1));return;}
    if(e.key==='ArrowUp'&&sel.length){e.preventDefault();sActive(i=>Math.max(0,i-1));return;}
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='d'){
      e.preventDefault();
      const el=e.currentTarget;const start=el.selectionStart||0;const end=el.selectionEnd||start;
      const lineStart=el.value.lastIndexOf('\n',start-1)+1;
      let lineEnd=el.value.indexOf('\n',end);if(lineEnd<0)lineEnd=el.value.length;
      const line=el.value.slice(lineStart,lineEnd);
      const next=el.value.slice(0,lineEnd)+'\n'+line+el.value.slice(lineEnd);
      setEditorValue(next,lineEnd+1+line.length);return;
    }
    if(e.key==='{'){
      e.preventDefault();
      const el=e.currentTarget;const p=el.selectionStart||0;const end=el.selectionEnd||p;
      const before=el.value.slice(0,p),selected=el.value.slice(p,end),after=el.value.slice(end);
      const insert=selected?'{'+selected+'}':'{\n  \n}';
      const next=before+insert+after;
      setEditorValue(next,before.length+(selected?insert.length:4));return;
    }
    if(e.key==='}'&&e.currentTarget.value[e.currentTarget.selectionStart||0]==='}'){
      e.preventDefault();const p=(e.currentTarget.selectionStart||0)+1;e.currentTarget.setSelectionRange(p,p);return;
    }
    if(e.key==='Tab'){
      const el=e.currentTarget;const p=el.selectionStart||0;const m=el.value.slice(0,p).match(/(\d+(?:\.\d+)?(?:px|rem|em|%)?)\s*([-+*/])\s*(\d+(?:\.\d+)?(?:px|rem|em|%)?)$/);
      if(m){e.preventDefault();const before=el.value.slice(0,p-m[0].length);const after=el.value.slice(el.selectionEnd||p);const next=before+'calc('+m[0]+')'+after;setEditorValue(next,before.length+6+m[0].length);}
    }
    if(e.key==='Enter'){
      e.preventDefault();
      const el=e.currentTarget;const p=el.selectionStart||0;const end=el.selectionEnd||p;
      const packed=cssEnterInsert(el.value,p);
      const next=el.value.slice(0,p)+packed.text+el.value.slice(end);
      setEditorValue(next,p+packed.cursor);return;
    }
  };
  const onInput=e=>{
    const v=e.target.value;
    sDraft(v);
    commit(v);
    queueSuggest();
  };
  const lines=useMemo(()=>Array.from({length:cssLineCount(draft)},(_,i)=>i+1).join('\n'),[draft]);
  const highlighted=useMemo(()=>cssHighlight(draft),[draft]);
  const syncScroll=e=>{if(hiRef.current){hiRef.current.scrollTop=e.currentTarget.scrollTop;hiRef.current.scrollLeft=e.currentTarget.scrollLeft;}queueSuggest();};
  return h('div',{class:'ve-code-wrap'},
    h('div',{class:'ve-code-shell'},
      h('pre',{class:'ve-code-lines'},lines),
      h('div',{class:'ve-code-editor'},
        h('pre',{ref:hiRef,class:'ve-code-highlight',dangerouslySetInnerHTML:{__html:highlighted}}),
        h('textarea',{ref,class:'ve-code-input',value:draft,onInput,onKeyDown:onKey,onClick:queueSuggest,onKeyUp:queueSuggest,onFocus:()=>{editingRef.current=true;queueSuggest();},onBlur:()=>{editingRef.current=false;commitNow(ref.current?ref.current.value:draft);},onSelect:queueSuggest,onScroll:syncScroll,placeholder:'/* Type . for classes, # for IDs, or -- for variables */\n.selector {\n  color: var(--color-primary);\n}'}))),
    sel.length>0&&h('div',{class:'ve-suggest'+(sel.some(x=>cssSuggestRowParts(typeof x==='string'?x:x.label))?' ve-sg-wide':''),style:{left:suggestPos.left+'px',top:suggestPos.top+'px'}},sel.map((x,i)=>{const label=typeof x==='string'?x:x.label;const rich=!!cssSuggestRowParts(label);return h('button',{type:'button',class:(i===active?'on':'')+(rich?' ve-sg-btn':''),onMouseDown:e=>{e.preventDefault();applySuggestion(x);}},rich?cssSuggestRowVnode(label):label);})),
    h('div',{class:'ve-code-basic'},ph('warning'),h('span',null,'Basic editor — MV’s code editor could not load, so syntax help and suggestions are limited. Reload the page; if it persists, check that the plugin’s asset files are reachable.')),
    h('div',{style:'font-size:11px;color:#666;line-height:1.55;margin-top:6px'},'Tab completes suggestions. Ctrl+D duplicates the current line/selection. After a small math expression like 100% - 20px, Tab wraps it in calc().',scss?' SCSS mode keeps nested syntax while compile support remains plain CSS-safe.':''));
}

/* ── CSS Studio sub-panel ─────────────── */
function AdvancedCssSub({onClose,exiting,vars,initialSheetId,onDirtyChange}){
  const[sheets,sSheets]=useState(DEFAULT_CSS_SHEETS);
  const[savedSignature,sSavedSignature]=useState(()=>JSON.stringify(DEFAULT_CSS_SHEETS));
  const[sel,sSel]=useState('global');
  const[ld,sLd]=useState(false);
  const[msg,sMsg]=useState('');
  const{scss,sourceOrder,disabledSources}=useCssStudioPreferences();
  const[pendingDelete,sPendingDelete]=useState(null);

  useEffect(()=>{
    api.g('advanced-css').then(d=>{let a=d?.stylesheets||[];if(a.length){const legacy=a.length===3&&a.every(x=>['page','global','child'].includes(x.id))&&a.every(x=>!String(x.css||'').trim());if(legacy)a=DEFAULT_CSS_SHEETS;sSavedSignature(JSON.stringify(a));sSheets(a);sSel((a.find(x=>String(x.id)===String(initialSheetId))||a.find(x=>x.id==='global')||a[0])?.id||'global');}}).catch(()=>{});
  },[initialSheetId]);

  const currentSignature=useMemo(()=>JSON.stringify(sheets),[sheets]);
  const dirty=currentSignature!==savedSignature;
  useEffect(()=>{if(onDirtyChange)onDirtyChange(dirty);},[dirty,onDirtyChange]);
  useEffect(()=>()=>{if(onDirtyChange)onDirtyChange(false);},[onDirtyChange]);

  const cur=sheets.find(x=>x.id===sel)||sheets[0]||null;
  const upd=(patch)=>sSheets(arr=>arr.map(x=>x.id===(cur?.id)?{...x,...patch}:x));
  const add=()=>{const id='custom_'+Date.now();const next={id,name:'custom.css',scope:'custom',enabled:true,css:''};sSheets(a=>[...a,next]);sSel(id);};
  const delSheet=(sheet,e)=>{e&&e.stopPropagation();if(sheets.length<=1)return;sPendingDelete(sheet);};
  const confirmDelSheet=()=>{const sheet=pendingDelete;if(!sheet)return;const next=sheets.filter(x=>x.id!==sheet.id);sSheets(next);if(sel===sheet.id)sSel((next.find(x=>x.id==='global')||next[0])?.id||'global');sPendingDelete(null);};
  const save=async()=>{sLd(true);sMsg('');const r=await api.p('advanced-css',{stylesheets:sheets});sLd(false);if(r?.code){sMsg(r.message||'Save failed');return;}const next=r.stylesheets||sheets;sSavedSignature(JSON.stringify(next));sSheets(next);sMsg('Saved and compiled.');};
  const scopeHelp={page:'Scope: renders only where page-level targeting is supported. Use for CSS that should stay narrow.',global:'Scope: renders site-wide. Use for CSS that should work everywhere.',child:'Scope: renders as a child-theme-style layer for broad theme overrides.',custom:'Scope: custom named stylesheet. Use when you want a separate editable layer.'};
  const warnings=useMemo(()=>cssValidation(cur?.css||''),[cur?.id,cur?.css]);

  return h('div',{class:'ve-body ve-css-studio-combined'},
      pendingDelete&&h(ConfirmModal,{title:'Delete stylesheet',body:'Delete stylesheet "'+pendingDelete.name+'"? This will be removed when you save and compile.',confirmText:'Delete',danger:true,onCancel:()=>sPendingDelete(null),onConfirm:confirmDelSheet}),
      h('div',{class:'ve-css-studio-combined-grid'},
        h('div',{class:'ve-css-settings-column ve-scroll-custom'},
          h('div',{class:'ve-studio-top'},
            h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:add},'+ New Stylesheet')),
          h('div',{style:'display:grid;grid-template-columns:'+(sheets.length>1?'115px minmax(0,1fr)':'1fr')+';gap:10px;min-height:0'},
            sheets.length>1&&h('div',{class:'ve-css-sheet-list ve-scroll-custom'},sheets.map(x=>h('button',{key:x.id,type:'button',class:'ve-btn '+(x.id===sel?'':'ve-btn-g')+' ve-btn-s ve-sheet-tab',onClick:()=>sSel(x.id)},h('span',null,x.name),sheets.length>1&&h('span',{class:'ve-sheet-del',title:'Delete stylesheet',onClick:e=>delSheet(x,e)},ph('trash'))))),
            cur&&h('div',{class:'ve-studio-main',style:'padding:0;overflow:visible'},
              h('div',{class:'ve-row'},h('input',{class:'ve-studio-input',value:cur.name,onInput:e=>upd({name:e.target.value}),placeholder:'stylesheet name'})),
              h('div',{class:'ve-scope-label'},'Stylesheet Scope'),
              h('div',{class:'ve-row'},
                h(SelectMenu,{value:cur.scope,onChange:v=>upd({scope:v}),options:['page','global','child','custom']}),
                h('label',{style:'display:flex;align-items:center;gap:7px;font-size:11px;color:#bbb;min-height:38px'},h('input',{type:'checkbox',checked:!!cur.enabled,onChange:e=>upd({enabled:e.target.checked})}),'Enabled')),
              h('div',{style:'font-size:11px;color:#777;line-height:1.55;margin:0 0 8px'},(scopeHelp[cur.scope]||scopeHelp.custom)+' This dropdown determines where and how widely this stylesheet renders/works.'),
              warnings.length>0&&h('div',{class:'ve-css-diag'},warnings.map(w=>h('div',null,w))))),
          h('div',{style:'font-size:11px;color:#666;line-height:1.6;margin-top:auto'},"CSS Studio compiles after Mimam's Var variables on the frontend and in admin/builder screens.")),
        cur&&h('div',{class:'ve-css-editor-column'},
          h('div',{class:'ve-editor-only'},
            h(CssEditor,{value:cur.css,onChange:v=>upd({css:v}),vars,sourceOrder,scss,disabledSources}),
            h('div',{class:'ve-editor-actions'},
              h('small',null,msg || "Compile after editing this stylesheet."),
              h('button',{class:'ve-btn ve-btn-s',onClick:save,disabled:ld},ld?'Saving...':'Save & Compile')))))
    );
}

function CssRecipesStudioSub({ flash, vars, initialCode }) {
  const [userRecipes, setUserRecipes] = useState(() => loadUserCssRecipes());
  const [code, setCode] = useState('custom');
  const [name, setName] = useState('');
  const [css, setCss] = useState('');
  const [editingCode, setEditingCode] = useState(null);
  const [editingBuiltin, setEditingBuiltin] = useState(false);
  const {scss,sourceOrder,disabledSources}=useCssStudioPreferences();
  const builtins = CSS_RECIPES;

  const persistUserRecipes = next => {
    setUserRecipes(next);
    saveUserCssRecipes(next);
  };

  const resetRecipeForm = () => {
    setCode('custom');
    setName('');
    setCss('');
    setEditingCode(null);
    setEditingBuiltin(false);
  };

  const saveRecipe = e => {
    e && e.preventDefault();
    const cleanCode = (code || '').trim().replace(/^@+/, '').replace(/[^a-z0-9_-]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').toLowerCase();
    const finalCode = '@' + cleanCode;
    if (!finalCode || finalCode === '@' || !css.trim()) {
      flash('Add a shortcode and CSS first.');
      return;
    }
    const nextRecipe = { code: finalCode, name: (name || finalCode.replace(/^@/, '')).trim(), css: css.trim() };
    const next = [...userRecipes.filter(r => r.code !== finalCode), nextRecipe].sort((a,b)=>a.code.localeCompare(b.code));
    persistUserRecipes(next);
    resetRecipeForm();
    flash('Recipe saved. Type ' + finalCode + ' then press Tab in CSS Studio.');
  };

  const removeRecipe = recipe => {
    persistUserRecipes(userRecipes.filter(r => r.code !== recipe.code));
    flash('Recipe removed.');
  };

  const loadRecipe = (recipe, builtin) => {
    setCode(String(recipe.code || '').replace(/^@/, ''));
    setName(recipe.name || '');
    setCss(recipe.css || '');
    setEditingCode(recipe.code || null);
    setEditingBuiltin(!!builtin);
    flash('Loaded ' + recipe.code + ' into the recipe editor.');
  };
  useEffect(()=>{
    if(!initialCode)return;
    const recipe=[...builtins,...userRecipes].find(item=>String(item.code)===String(initialCode));
    if(recipe)loadRecipe(recipe,builtins.includes(recipe));
  },[initialCode]);

  const recipeTitle = editingCode ? (editingBuiltin ? 'Built-in Recipe Preview' : 'Edit Recipe') : 'New Recipe';

  const recipeCard = (recipe, builtin) => h('div', { class: 've-recipe-card', key: (builtin ? 'b-' : 'u-') + recipe.code, role: 'button', tabIndex: 0, onClick: () => loadRecipe(recipe, builtin), onKeyDown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); loadRecipe(recipe, builtin); } } },
    h('span', { class: 've-recipe-code' }, recipe.code),
    h('div', null,
      h('strong', null, recipe.name || recipe.code),
      h('small', null, 'Click to load this recipe output')
    ),
    builtin ? h('span', { style: 'font-size:11px;color:#777;text-transform:uppercase;font-weight:700' }, 'Built in') :
      h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: e => { e.stopPropagation(); removeRecipe(recipe); }, title: 'Delete recipe' }, ph('trash'))
  );

  return h('div', { class: 've-recipe-studio' },
    h('div', { class: 've-recipe-studio-main' },
      h('div', { class: 've-recipe-list ve-scroll-custom' },
        h('div', { class: 've-studio-nav-title', style: 'margin-bottom:2px' }, 'Recipe Shortcodes'),
        builtins.map(r => recipeCard(r, true)),
        userRecipes.length ? userRecipes.map(r => recipeCard(r, false)) : h('div', { class: 've-empty', style: 'padding:16px;text-align:left' }, 'No custom recipes yet.')
      ),
      h('form', { class: 've-recipe-form', onSubmit: saveRecipe },
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:10px' },
          h('div', { class: 've-studio-nav-title', style: 'margin:0' }, recipeTitle),
          editingCode && h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: resetRecipeForm }, '+ New Recipe')
        ),
        h('label', { class: 've-recipe-field' }, h('span', { class: 've-scope-label' }, 'Shortcode'), h('div', { class: 've-recipe-shortcode' },
          h('span', { class: 've-studio-input' }, '@'),
          h('input', {
            class: 've-studio-input',
            name: 've_recipe_shortcode',
            value: code,
            autoComplete: 'off',
            'data-1p-ignore': 'true',
            'data-lpignore': 'true',
            onInput: e => setCode(String(e.target.value || '').replace(/^@+/, '')),
            placeholder: 'section'
          })
        )),
        h('label', { class: 've-recipe-field' }, h('span', { class: 've-scope-label' }, 'Name'), h('input', {
          class: 've-studio-input',
          name: 've_recipe_title',
          value: name,
          autoComplete: 'off',
          'data-1p-ignore': 'true',
          'data-lpignore': 'true',
          onInput: e => setName(e.target.value),
          placeholder: 'Section rhythm'
        })),
        h('label', { class: 've-recipe-field', style: 'min-height:0;flex:0 0 auto' },
          h('span', { class: 've-scope-label' }, 'CSS'),
          h('div', { class: 've-recipe-editor' },
            h(CssEditor, { value: css, onChange: setCss, vars, sourceOrder, scss, disabledSources })
          )
        ),
        h('div', { class: 've-recipe-form-actions' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: resetRecipeForm }, editingCode ? 'Cancel Edit' : 'Clear'),
          h('button', { class: 've-btn ve-btn-s', type: 'submit' }, editingBuiltin ? 'Save as Custom Recipe' : 'Save Recipe')
        ),
        h('div', { style: 'font-size:11px;color:#777;line-height:1.55' }, 'Click any shortcode to load its output into this editor, then save it as a custom recipe when needed.')
      )
    )
  );
}

/* ── Manual family relationships ──────── */
function FamilyRelationshipSub({initialIds,initialOperation,initialRootId,initialNewRootId,lockRoot,vars,onDone,onClose,onNavigateUsage,exiting}){
  const selected=(initialIds||[]).map(id=>vars.find(v=>Number(v.id)===Number(id))).filter(Boolean);
  const selectedGenerated=selected.filter(v=>v.type==='generated');
  const selectedBases=selected.filter(v=>v.type==='base');
  const familyRoots=vars.filter(v=>v.type==='base'&&vars.some(c=>c.type==='generated'&&Number(c.source_id)===Number(v.id)));
  const selectedGeneratedRootIds=[...new Set(selectedGenerated.map(v=>Number(v.source_id)).filter(id=>id>0))];
  const selectedFamilyRootId=selectedGeneratedRootIds.length===1?selectedGeneratedRootIds[0]:'';
  const selectedFamilyRoot=vars.find(v=>Number(v.id)===Number(selectedFamilyRootId));
  const selectedBaseFamilyRoot=selectedBases.find(v=>familyRoots.some(root=>Number(root.id)===Number(v.id)));
  const inferredOperation=initialOperation||(selected.length>0&&selectedGenerated.length===selected.length?'ungroup':'group');
  const inferredRootId=initialRootId||selectedBaseFamilyRoot?.id||selectedFamilyRoot?.id||selectedBases[0]?.id||familyRoots[0]?.id||'';
  const inferredNewRootId=initialNewRootId||'';
  const[operation,sOperation]=useState(inferredOperation);
  const[rootId,sRootId]=useState(String(inferredRootId));
  const[newRootId,sNewRootId]=useState(String(inferredNewRootId));
  const[preview,sPreview]=useState(null);
  const[loading,sLoading]=useState(false);
  const[error,sError]=useState('');

  const contextRoot=vars.find(v=>Number(v.id)===Number(initialRootId));
  const contextChildren=contextRoot?vars.filter(v=>v.type==='generated'&&Number(v.source_id)===Number(contextRoot.id)):[];
  const currentRoot=vars.find(v=>String(v.id)===String(rootId));
  const rootChildren=currentRoot?vars.filter(v=>v.type==='generated'&&Number(v.source_id)===Number(currentRoot.id)):[];
  const eligibleRoots=operation==='change_root'?familyRoots:vars.filter(v=>v.type==='base');
  const operationOptions=(lockRoot?[
    {value:'change_root',label:'Change this family’s root'},
    {value:'reparent',label:'Move this family’s children to another root'},
    {value:'ungroup',label:'Ungroup this family’s children'}
  ]:[
    {value:'group',label:'Group selected variables'},
    {value:'reparent',label:'Move selected children to another root'},
    {value:'ungroup',label:'Ungroup selected children'},
    {value:'change_root',label:'Change a family root'}
  ]);
  const descriptions={
    group:'Choose one standalone variable as the root. Every other selected variable becomes its child.',
    reparent:'Move the selected imported or manually grouped children beneath another standalone root.',
    ungroup:'Promote the selected imported or manually grouped children back to standalone variables.',
    change_root:'Promote one existing child to root. The old root and its siblings move beneath it.'
  };

  useEffect(()=>{
    sPreview(null);sError('');
    if(operation==='change_root'){
      const preferred=vars.find(v=>Number(v.id)===Number(inferredRootId))||familyRoots[0];
      sRootId(String(preferred?.id||''));
      const preferredChild=vars.find(v=>Number(v.id)===Number(initialNewRootId)&&Number(v.source_id)===Number(preferred?.id));
      const child=preferredChild||vars.find(v=>v.type==='generated'&&Number(v.source_id)===Number(preferred?.id));
      sNewRootId(String(child?.id||''));
    }else if(operation==='group'){
      sRootId(String(selectedBases[0]?.id||''));
      sNewRootId('');
    }else if(operation==='reparent'){
      const selectedRootIds=new Set(selected.map(v=>Number(v.id)));
      const destination=vars.find(v=>v.type==='base'&&!selectedRootIds.has(Number(v.id))&&Number(v.id)!==Number(initialRootId));
      sRootId(String(destination?.id||''));
      sNewRootId('');
    }else{
      sRootId(lockRoot?String(initialRootId||''):'');sNewRootId('');
    }
  },[operation]);

  useEffect(()=>{
    if(operation!=='change_root')return;
    const children=vars.filter(v=>v.type==='generated'&&Number(v.source_id)===Number(rootId));
    if(!children.some(v=>String(v.id)===String(newRootId)))sNewRootId(String(children[0]?.id||''));
    sPreview(null);sError('');
  },[rootId]);

  const operationSelection=lockRoot&&['reparent','ungroup'].includes(operation)?contextChildren:selected;
  const payload=()=>({
    operation,
    variable_ids:operationSelection.map(v=>Number(v.id)),
    root_id:Number(rootId||0),
    new_root_id:Number(newRootId||0)
  });
  const runPreview=async()=>{
    sLoading(true);sError('');sPreview(null);
    const result=await api.p('variable-families/preview',payload());
    sLoading(false);
    if(result?.code){sError(result.message||'Could not preview this family change.');return;}
    sPreview(result);
  };
  const apply=async()=>{
    if(!preview)return;
    sLoading(true);sError('');
    const result=await api.p('variable-families/apply',{...payload(),fingerprint:preview.fingerprint});
    sLoading(false);
    if(result?.code){sError(result.message||'Could not apply this family change.');return;}
    onDone(result);
  };
  const parentLabel=(name,type)=>name?publicTokenLabel(name):(type==='base'?'Standalone':'No parent');

  return h(Sub,{title:'Manage variable family',onClose,exiting},
    h('div',{class:'ve-family-intro'},ph('tree-structure'),h('div',null,'Relationships change how variables are grouped in Mimam’s Var. Token names, exact values, aliases, generated CSS names, and source tags are preserved.')),
    h('label',{class:'ve-family-field'},h('span',null,'Action'),h(SelectMenu,{value:operation,onChange:sOperation,options:operationOptions})),
    h('div',{class:'ve-family-note',style:'margin:-4px 0 12px'},descriptions[operation]),
    operation!=='change_root'&&h('div',{class:'ve-family-field'},
      h('span',null,(lockRoot?'Family children':'Selected variables')+' ('+operationSelection.length+')'),
      h('div',{class:'ve-family-selection'},operationSelection.length?operationSelection.map(v=>h('span',{class:'ve-family-chip',key:v.id},publicTokenLabel(v.name))):h('span',{style:'color:#777;font-size:11px'},'Select variables from the main list first.'))
    ),
    (operation==='group'||operation==='reparent'||operation==='change_root')&&h('label',{class:'ve-family-field'},
      h('span',null,operation==='change_root'?'Current family root':'Destination root'),
      operation==='change_root'&&lockRoot
        ?h('div',{class:'ve-family-selection'},h('span',{class:'ve-family-chip'},currentRoot?publicTokenLabel(currentRoot.name):'Family root unavailable'))
        :h(SelectMenu,{className:'ve-family-root-menu',searchable:true,searchPlaceholder:'Search destination roots…',value:rootId,onChange:value=>{sRootId(value);sPreview(null);},options:[{value:'',label:'Choose root'},...eligibleRoots.map(v=>({value:String(v.id),label:publicTokenLabel(v.name)}))]})
    ),
    operation==='change_root'&&h('label',{class:'ve-family-field'},
      h('span',null,'New root'),
      h(SelectMenu,{className:'ve-family-root-menu',searchable:true,searchPlaceholder:'Search family children…',value:newRootId,onChange:value=>{sNewRootId(value);sPreview(null);sError('');},options:[{value:'',label:'Choose child'},...rootChildren.map(v=>({value:String(v.id),label:publicTokenLabel(v.name)}))]})
    ),
    error&&h('div',{class:'ve-warn',style:'margin-top:10px'},error),
    preview&&h('div',{class:'ve-family-preview'},
      h('div',{class:'ve-family-preview-h'},ph('check-circle'),'Preview · '+preview.count+' relationship change'+(preview.count===1?'':'s')),
      preview.changes.map(change=>h('div',{class:'ve-family-change',key:change.id},
        h('div',{class:'ve-family-change-name'},publicTokenLabel(change.name)),
        h('div',{class:'ve-family-change-path'},
          parentLabel(change.from_parent_name,change.from_type),' → ',h('b',null,parentLabel(change.to_parent_name,change.to_type)),
          change.from_category!==change.to_category&&h('span',null,' · Category ',change.from_category,' → ',change.to_category)
        )
      ))
    ),
    preview&&h('div',{class:'ve-family-note'},'A complete safety snapshot will be created before Apply. Calculated generator families stay protected.'),
    preview&&h(VariableImpactStack,{variables:preview.changes.map(change=>vars.find(variable=>Number(variable.id)===Number(change.id))).filter(Boolean),onNavigate:onNavigateUsage}),
    h('div',{class:'ve-family-actions'},
      h('button',{class:'ve-btn ve-btn-g',onClick:onClose,disabled:loading},'Cancel'),
      h('button',{class:'ve-btn',onClick:runPreview,disabled:loading||(!operationSelection.length&&operation!=='change_root')},loading&&!preview?'Previewing...':'Preview changes'),
      preview&&h('button',{class:'ve-btn',onClick:apply,disabled:loading},loading?'Applying...':'Apply '+preview.count+' changes')
    )
  );
}

/* ── Color generate sub-panel ─────────── */
function GenColorSub({variable,childMap,onDone,onClose,exiting}){
  const has=(childMap[variable.id]||[]).length>0;
  const[ok,sOk]=useState(!has);
  const[tints,sT]=useState(true);const[shades,sS]=useState(true);const[alpha,sA]=useState(true);
  const[tN,sTN]=useState(8);const[sN,sSN]=useState(8);const[aN,sAN]=useState(8);const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const run=async()=>{sLd(true);sErr('');
    const r=await api.p(`variables/${variable.id}/generators`,{type:'color',replace:has,config:{tint_count:tints?tN:0,shade_count:shades?sN:0,include_alpha:alpha,alpha_count:alpha?aN:0}});
    sLd(false);if(r?.code){sErr(r.message||'Could not generate color variants.');return;}onDone();};
  return h(Sub,{title:'Generate: '+publicTokenLabel(variable.name),onClose,exiting},
    has&&!ok?h('div',null,h('div',{class:'ve-warn'},'This color already has variants. Continuing replaces them.'),
      h('div',{style:'display:flex;gap:5px;margin-top:8px'},h('button',{class:'ve-btn',onClick:()=>sOk(true)},'Continue')))
    :h('div',null,
      h('div',{class:'ve-opt'},h('label',null,h('input',{type:'checkbox',checked:tints,onChange:e=>sT(e.target.checked)}),'Tints'),h('input',{type:'number',min:0,max:20,value:tN,onInput:e=>sTN(+e.target.value),disabled:!tints})),
      h('div',{class:'ve-opt'},h('label',null,h('input',{type:'checkbox',checked:shades,onChange:e=>sS(e.target.checked)}),'Shades'),h('input',{type:'number',min:0,max:20,value:sN,onInput:e=>sSN(+e.target.value),disabled:!shades})),
      h('div',{class:'ve-opt'},h('label',null,h('input',{type:'checkbox',checked:alpha,onChange:e=>sA(e.target.checked)}),'Alpha'),h('input',{type:'number',min:0,max:20,value:aN,onInput:e=>sAN(+e.target.value),disabled:!alpha})),
      err&&h('div',{style:'font-size:11px;color:#ef4444;padding:6px 0 0'},err),
      h('div',{style:'display:flex;gap:5px;margin-top:10px;justify-content:flex-end'},h('button',{class:'ve-btn',onClick:run,disabled:ld},ld?'Generating...':'Generate'))));
}

/* ── Scale generate sub-panel (reads viewport from settings) ── */
function GenScaleSub({variable,onDone,onClose,exiting}){
  const bv=pxV(variable.value)||16;
  const[bMin,sBM]=useState(bv);const[bMax,sBX]=useState(Math.round(bv*1.125));
  const[scMin,sSM]=useState('major-third');const[scMax,sSX]=useState('major-third');
  const[up,sUp]=useState(3);const[dn,sDn]=useState(2);const[ld,sLd]=useState(false);
  const[vwMin,sVWM]=useState(320);const[vwMax,sVWX]=useState(1440);
  const[err,sErr]=useState('');

  useEffect(()=>{api.g('settings').then(d=>{if(d&&d.vw_min)sVWM(d.vw_min);if(d&&d.vw_max)sVWX(d.vw_max);});},[]);

  const run=async()=>{sLd(true);sErr('');
    const ns=variable.namespace;const tp=(ns==='font'||ns==='heading'||ns==='text')?'typography':ns==='space'?'spacing':ns==='radius'?'radius':ns==='size'?'size':'spacing';
    const r=await api.p(`variables/${variable.id}/generators`,{type:tp,replace:true,config:{base_min:bMin,base_max:bMax,scale_min:scMin,scale_max:scMax,steps_up:up,steps_down:dn,vw_min:vwMin,vw_max:vwMax,naming:'numeric'}});
    sLd(false);if(r?.code){sErr(r.message||'Could not generate the fluid scale.');return;}onDone();};
  return h(Sub,{title:'Fluid scale: '+publicTokenLabel(variable.name),onClose,exiting},
    h('div',{class:'ve-opt'},h('span',null,'Base min (mobile)'),h('input',{type:'number',value:bMin,onInput:e=>sBM(+e.target.value),step:'0.1'})),
    h('div',{class:'ve-opt'},h('span',null,'Base max (desktop)'),h('input',{type:'number',value:bMax,onInput:e=>sBX(+e.target.value),step:'0.1'})),
    h('div',{class:'ve-opt'},h('span',null,'Scale min'),h(SelectMenu,{className:'ve-opt-menu',value:scMin,onChange:sSM,options:SCALES})),
    h('div',{class:'ve-opt'},h('span',null,'Scale max'),h(SelectMenu,{className:'ve-opt-menu',value:scMax,onChange:sSX,options:SCALES})),
    h('div',{class:'ve-opt'},h('span',null,'Steps up'),h('input',{type:'number',min:0,max:8,value:up,onInput:e=>sUp(+e.target.value)})),
    h('div',{class:'ve-opt'},h('span',null,'Steps down'),h('input',{type:'number',min:0,max:8,value:dn,onInput:e=>sDn(+e.target.value)})),
    h('div',{style:'font-size:11px;color:#444;padding:4px 0;border-top:1px solid #2a2a2a;margin-top:6px'},'Viewport: '+vwMin+'px → '+vwMax+'px (from Settings)'),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:6px 0 0'},err),
    h('div',{style:'display:flex;gap:5px;margin-top:10px;justify-content:flex-end'},h('button',{class:'ve-btn',onClick:run,disabled:ld},ld?'Generating...':'Generate')));
}

function cssVarToTokenName(name){
  let n=String(name||'').trim().toLowerCase().replace(/^--/,'').replace(/[^a-z0-9-]/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'');
  if(!n)return'';
  return n.replace(/-/g,'.');
}
function parseCssVariables(text){
  const clean=String(text||'').replace(/\/\*[\s\S]*?\*\//g,'');
  const re=/--([a-zA-Z0-9_-]+)\s*:\s*([^;]+);/g;
  const out=[];const seen={};let m;
  while((m=re.exec(clean))){
    const publicCssName='--'+String(m[1]||'').toLowerCase();
    const name=cssVarToTokenName('--'+m[1]);
    const value=String(m[2]||'').trim();
    if(!name||!value)continue;
    const aliasMatch=value.match(/^var\(\s*(--[a-zA-Z0-9_-]+)\s*(?:,\s*[^)]+)?\)$/);
    seen[name]={name,value,namespace:name.split('.')[0],type:aliasMatch?'alias':'base',public_css_name:publicCssName,source_css_name:aliasMatch?String(aliasMatch[1]).toLowerCase():''};
  }
  Object.keys(seen).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).forEach(k=>out.push(seen[k]));
  return out;
}

function ThemePanel({onClose,exiting,onChanged}){
  const[data,sData]=useState({active:'default',palettes:[]});
  const[name,sName]=useState('');
  const[editing,sEditing]=useState(null);
  const[editName,sEditName]=useState('');
  const[ld,sLd]=useState(false);
  const[err,sErr]=useState('');
  const[confirmDelete,sConfirmDelete]=useState(null);
  const load=async()=>{const r=await api.g('themes');if(r&&!r.code)sData(r);};
  useEffect(()=>{load();},[]);
  const finish=async message=>{await load();onChanged&&onChanged();if(message)window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:message}));};
  const create=async()=>{if(!name.trim())return;sLd(true);sErr('');const r=await api.p('themes',{name:name.trim(),source_slug:data.active});sLd(false);if(r?.code){sErr(r.message||'Could not create theme.');return;}sName('');await finish('Theme created');};
  const activate=async slug=>{sLd(true);sErr('');const r=await api.p('themes/'+slug+'/activate',{});sLd(false);if(r?.code){sErr(r.message||'Could not switch theme.');return;}await finish('Theme switched');};
  const duplicate=async p=>{sLd(true);sErr('');const r=await api.p('themes/'+p.slug+'/duplicate',{name:p.name+' Copy'});sLd(false);if(r?.code){sErr(r.message||'Could not duplicate theme.');return;}await finish('Theme duplicated');};
  const rename=async()=>{if(!editing||!editName.trim())return;sLd(true);sErr('');const r=await api.u('themes/'+editing,{name:editName.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not rename theme.');return;}sEditing(null);sEditName('');await finish('Theme renamed');};
  const remove=async()=>{if(!confirmDelete)return;const slug=confirmDelete.slug;sConfirmDelete(null);sLd(true);sErr('');const r=await api.d('themes/'+slug);sLd(false);if(r?.code){sErr(r.message||'Could not delete theme.');return;}await finish('Theme deleted');};
  const active=data.palettes.find(p=>p.slug===data.active);
  const rows=data.palettes.map(p=>{
    const info=editing===p.slug
      ? h('div',{style:'display:flex;gap:4px'},h('input',{class:'ve-studio-input',type:'text',value:editName,onInput:e=>sEditName(e.target.value),onKeyDown:e=>{if(e.key==='Enter')rename();if(e.key==='Escape')sEditing(null);},style:'flex:1;min-width:0;font-size:11px;'}),h('button',{class:'ve-btn',onClick:rename,disabled:ld},'Save'))
      : h('div',{class:'ve-palette-row-name'},p.name);
    return h('div',{class:'ve-palette-row',key:p.slug},
      h('button',{class:'ve-a',title:p.active?'Active theme':'Activate '+p.name,onClick:()=>!p.active&&activate(p.slug),disabled:ld},ph(p.active?'check-circle':'circle')),
      h('div',{class:'ve-palette-row-info'},info,h('div',{class:'ve-palette-row-meta'},p.active?'Active · ':'',p.slug==='default'?'Uses base variable values':(p.value_count||0)+' color values')),
      h('div',{class:'ve-palette-actions'},
        h('button',{class:'ve-a',title:'Duplicate theme',onClick:()=>duplicate(p),disabled:ld},ph('copy')),
        !p.protected&&h('button',{class:'ve-a',title:'Rename theme',onClick:()=>{sEditing(p.slug);sEditName(p.name);},disabled:ld},ph('pencil-simple')),
        !p.protected&&h('button',{class:'ve-a',title:'Delete theme',onClick:()=>sConfirmDelete(p),disabled:ld},ph('trash'))));
  });
  return h(Sub,{title:'Color Themes',onClose,exiting},
    confirmDelete&&h(ConfirmModal,{title:'Delete theme',body:'Delete “'+confirmDelete.name+'”? Its alternate color values will be removed. The underlying variables remain safe.',confirmText:'Delete Theme',danger:true,onCancel:()=>sConfirmDelete(null),onConfirm:remove}),
    h('div',{class:'ve-palette-current'},h('i',{class:'ph-duotone ph-palette',style:'font-size:18px;color:#baf400;line-height:1'}),h('div',null,h('div',{style:'font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;font-weight:600'},'Active theme'),h('div',{style:'font-size:13px;color:#e8e8e8;font-weight:700;margin-top:1px'},active?.name||'Default'))),
    h('div',{class:'ve-import-help'},'Themes change color values without changing token names. Create one from the active values, switch it on, then edit Color variables normally.'),
    h('div',{style:'display:flex;gap:5px;margin-bottom:10px'},h('input',{class:'ve-studio-input',type:'text',value:name,onInput:e=>sName(e.target.value),placeholder:'New theme name',onKeyDown:e=>e.key==='Enter'&&create(),style:'flex:1;font-size:11px;'}),h('button',{class:'ve-btn',onClick:create,disabled:ld||!name.trim()},'Create')),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:0 0 8px'},err),
    h('div',{style:'flex:1;min-height:0;overflow-y:auto'},rows));
}

function ColorPalettePanel({onClose,exiting,onChanged,inline=false,selectedPaletteId='all'}){
  const[data,sData]=useState({palettes:[]});
  const [draggingPaletteId, sDraggingPaletteId] = useState(null);
  const [dragOverPaletteId, sDragOverPaletteId] = useState(null);
  const handlePaletteDrop = async (e, targetPalette) => {
    e.preventDefault();
    const sourceId = draggingPaletteId;
    sDraggingPaletteId(null);
    sDragOverPaletteId(null);
    if (!sourceId || sourceId === targetPalette.id) return;

    const currentList = [...data.palettes];
    const sourceIdx = currentList.findIndex(x => x.id === sourceId);
    const targetIdx = currentList.findIndex(x => x.id === targetPalette.id);
    if (sourceIdx === -1 || targetIdx === -1) return;

    const [removed] = currentList.splice(sourceIdx, 1);
    currentList.splice(targetIdx, 0, removed);

    const orderedIds = currentList.map(x => x.id);

    sData(prev => ({
      ...prev,
      palettes: currentList.map((x, idx) => ({ ...x, position: idx }))
    }));

    try {
      const res = await api.p('color-palettes/reorder', { ids: orderedIds });
      if (res && !res.code) {
        window.dispatchEvent(new CustomEvent('ve-toast-request', { detail: 'Palettes reordered' }));
      } else {
        window.dispatchEvent(new CustomEvent('ve-toast-request', { detail: res?.message || 'Failed to reorder' }));
      }
      await load();
    } catch(err) {
      window.dispatchEvent(new CustomEvent('ve-toast-request', { detail: 'Failed to reorder' }));
      await load();
    }
  };
  const[name,sName]=useState('');
  const[editing,sEditing]=useState(null);
  const[editName,sEditName]=useState('');
  const[ld,sLd]=useState(false);
  const[err,sErr]=useState('');
  const[confirmDuplicate,sConfirmDuplicate]=useState(null);
  const[deleteState,sDeleteState]=useState(null);
  const[deleteDestination,sDeleteDestination]=useState('');
  const load=async()=>{const r=await api.g('color-palettes');if(r&&!r.code)sData(r);};
  useEffect(()=>{load();},[]);
  const finish=async message=>{await load();onChanged&&onChanged();if(message)window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:message}));};
  const create=async()=>{if(!name.trim())return;sLd(true);sErr('');const r=await api.p('color-palettes',{name:name.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not create palette.');return;}sName('');await finish('Empty palette created');};
  const duplicate=async()=>{if(!confirmDuplicate)return;const p=confirmDuplicate;sConfirmDuplicate(null);sLd(true);sErr('');const r=await api.p('color-palettes/'+p.id+'/duplicate',{name:p.name+' Copy'});sLd(false);if(r?.code){sErr(r.message||'Could not duplicate palette.');return;}await finish('Palette and its colors duplicated');};
  const rename=async()=>{if(!editing||!editName.trim())return;sLd(true);sErr('');const r=await api.u('color-palettes/'+editing,{name:editName.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not rename palette.');return;}sEditing(null);sEditName('');await finish('Palette renamed');};
  const askDelete=async p=>{sLd(true);sErr('');const preview=await api.g('color-palettes/'+p.id+'/delete-preview');sLd(false);if(preview?.code){sErr(preview.message||'Could not inspect palette.');return;}sDeleteDestination('');sDeleteState({palette:p,preview});};
  const remove=async(strategy='empty')=>{if(!deleteState)return;const p=deleteState.palette;const destinationId=Number(deleteDestination)||0;sDeleteState(null);sLd(true);sErr('');const r=await api.d('color-palettes/'+p.id,{strategy,destination_id:destinationId});sLd(false);if(r?.code){sErr(r.message||'Could not delete palette.');return;}await finish(strategy==='move'?'Palette removed and colors moved':'Palette deleted');};
  const destinationOptions=data.palettes.filter(p=>p.id!==deleteState?.palette?.id).map(p=>({value:String(p.id),label:p.name}));
  const rows=data.palettes.map(p=>{
    const info=editing===p.id
      ? h('div',{style:'display:flex;gap:4px'},h('input',{class:'ve-studio-input',type:'text',value:editName,onInput:e=>sEditName(e.target.value),onKeyDown:e=>{if(e.key==='Enter')rename();if(e.key==='Escape')sEditing(null);},style:'flex:1;min-width:0;font-size:11px;'}),h('button',{class:'ve-btn',onClick:rename,disabled:ld},'Save'))
      : h('div',{class:'ve-palette-row-name'},p.name);
    return h('div',{
      class:'ve-palette-row'+(draggingPaletteId===p.id?' dragging':'')+(dragOverPaletteId===p.id?' drag-over':''),
      key:p.id,
      draggable:true,
      onDragStart:e=>{
        sDraggingPaletteId(p.id);
        e.dataTransfer.effectAllowed='move';
        e.dataTransfer.setData('text/plain',String(p.id));
      },
      onDragOver:e=>{
        e.preventDefault();
        if(p.id!==draggingPaletteId)sDragOverPaletteId(p.id);
      },
      onDragLeave:()=>sDragOverPaletteId(null),
      onDragEnd:()=>{sDraggingPaletteId(null);sDragOverPaletteId(null);},
      onDrop:e=>handlePaletteDrop(e,p)
    },
      h('span',{class:'ve-palette-drag-handle',style:'cursor:grab;margin-right:4px;display:flex;align-items:center;opacity:0.3;'},ph('dots-six-vertical')),
      h('div',{class:'ve-sw-trigger',style:'width:24px;color:#baf400'},ph('palette')),
      h('div',{class:'ve-palette-row-info'},info,h('div',{class:'ve-palette-row-meta'},p.color_count+' color'+(p.color_count===1?'':'s'))),
      h('div',{class:'ve-palette-actions'},
        h('button',{class:'ve-a',title:'Duplicate palette and colors',onClick:()=>sConfirmDuplicate(p),disabled:ld},ph('copy')),
        h('button',{class:'ve-a',title:'Rename palette',onClick:()=>{sEditing(p.id);sEditName(p.name);},disabled:ld},ph('pencil-simple')),
        h('button',{class:'ve-a',title:'Delete palette',onClick:()=>askDelete(p),disabled:ld},ph('trash'))));
  });
  const selected=data.palettes.find(p=>String(p.id)===String(selectedPaletteId));
  const content=[
    confirmDuplicate&&h(ConfirmModal,{title:'Duplicate palette',body:'Duplicate “'+confirmDuplicate.name+'” and create independent copies of its '+confirmDuplicate.color_count+' color'+(confirmDuplicate.color_count===1?'':'s')+'?',confirmText:'Duplicate Palette',onCancel:()=>sConfirmDuplicate(null),onConfirm:duplicate}),
    deleteState&&(deleteState.preview.color_count===0
      ? h(ConfirmModal,{title:'Delete empty palette',body:'Delete “'+deleteState.palette.name+'”?',confirmText:'Delete Palette',danger:true,onCancel:()=>sDeleteState(null),onConfirm:()=>remove('empty')})
      : h('div',{class:'ve-modal'},h('div',{class:'ve-modal-box'},
          h('div',{class:'ve-modal-title'},'Delete populated palette'),
          h('div',{class:'ve-modal-body'},
            h('div',null,'“'+deleteState.palette.name+'” contains '+deleteState.preview.color_count+' color'+(deleteState.preview.color_count===1?'':'s')+' and '+deleteState.preview.generated_count+' generated child'+(deleteState.preview.generated_count===1?'':'ren')+'.'),
            deleteState.preview.dependent_alias_count>0&&h('div',{style:'color:#f6c369;margin-top:6px'},deleteState.preview.dependent_alias_count+' alias relationship'+(deleteState.preview.dependent_alias_count===1?'':'s')+' may also be removed if the colors are deleted.'),
            destinationOptions.length>0&&h('div',{style:'margin-top:10px'},h('div',{style:'font-size:11px;color:#888;margin-bottom:5px'},'Move colors before deleting'),h(SelectMenu,{value:deleteDestination,onChange:sDeleteDestination,options:[{value:'',label:'Choose destination palette'},...destinationOptions]}))),
          h('div',{class:'ve-modal-actions',style:'flex-wrap:wrap'},
            h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sDeleteState(null)},'Cancel'),
            destinationOptions.length>0&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',disabled:!deleteDestination,onClick:()=>remove('move')},'Move & Delete'),
            h('button',{class:'ve-btn ve-btn-d ve-btn-s',onClick:()=>remove('delete_colors')},'Delete Palette & Colors'))))),
    h('div',{class:'ve-palette-current'},h('i',{class:'ph-duotone ph-palette',style:'font-size:18px;color:#baf400;line-height:1'}),h('div',null,h('div',{style:'font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;font-weight:600'},selected?'Selected palette':'Color organization'),h('div',{style:'font-size:13px;color:#e8e8e8;font-weight:700;margin-top:1px'},selected?.name||(data.palettes.length+' palette'+(data.palettes.length===1?'':'s'))))),
    h('div',{class:'ve-import-help'},'Palettes are user-created containers for actual Color variables. They do not change the active theme or website values. New palettes start empty; colors can be moved or copied between them.'),
    h('div',{style:'display:flex;gap:5px;margin-bottom:10px'},h('input',{class:'ve-studio-input',type:'text',value:name,onInput:e=>sName(e.target.value),placeholder:'New palette name',onKeyDown:e=>e.key==='Enter'&&create(),style:'flex:1;font-size:11px;'}),h('button',{class:'ve-btn',onClick:create,disabled:ld||!name.trim()},'Create')),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:0 0 8px'},err),
    h('div',{style:inline?'max-height:190px;overflow-y:auto':'flex:1;min-height:0;overflow-y:auto'},rows.length?rows:h('div',{class:'ve-empty'},'No palettes yet. Create one to begin grouping colors.'))
  ];
  return inline
    ? h('div',{style:'padding:10px 14px 12px;border-top:1px solid #2a2a2a;display:flex;flex-direction:column;gap:8px;background:rgba(0,0,0,.12)'},...content)
    : h(Sub,{title:'Color Palettes',onClose,exiting},...content);
}

/* ── User-managed non-color categories ── */
function VariableCategoryPanel({onClose,exiting,onChanged,categories=[]}){
  const[name,sName]=useState('');
  const[editing,sEditing]=useState(null);
  const[editName,sEditName]=useState('');
  const[confirmDelete,sConfirmDelete]=useState(null);
  const[ld,sLd]=useState(false);
  const[err,sErr]=useState('');
  const finish=async message=>{if(onChanged)await onChanged();sErr('');window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:message}));};
  const create=async()=>{if(!name.trim())return;sLd(true);sErr('');const r=await api.p('variable-categories',{name:name.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not create category.');return;}sName('');await finish('Category created');};
  const rename=async()=>{if(!editing||!editName.trim())return;sLd(true);sErr('');const r=await api.p('variable-categories/'+editing.slug+'/rename',{name:editName.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not rename category.');return;}sEditing(null);await finish('Category renamed');};
  const remove=async()=>{if(!confirmDelete)return;const category=confirmDelete;sConfirmDelete(null);sLd(true);sErr('');const r=await api.p('variable-categories/'+category.slug+'/remove',{});sLd(false);if(r?.code){sErr(r.message||'Could not delete category.');return;}await finish('Category deleted · variables moved to Uncategorized');};
  return h(Sub,{title:'Categories',onClose,exiting},
    h('div',{class:'ve-import-help',style:'margin-bottom:10px'},'Categories organize non-color variables without changing their token names, aliases, CSS, or website output. Imported variables receive a category named after their source.'),
    h('div',{style:'display:flex;gap:5px;margin-bottom:10px'},
      h('input',{class:'ve-studio-input',value:name,onInput:e=>sName(e.target.value),onKeyDown:e=>e.key==='Enter'&&create(),placeholder:'New category name',style:'flex:1'}),
      h('button',{class:'ve-btn',onClick:create,disabled:ld||!name.trim()},'Create')),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:0 0 8px'},err),
    h('div',{style:'display:flex;flex-direction:column'},
      categories.map(category=>h('div',{key:category.slug,style:'display:flex;align-items:center;gap:7px;padding:8px 0;border-bottom:1px solid #2a2a2a'},
        h('div',{style:'flex:1;min-width:0'},
          editing?.slug===category.slug
            ? h('input',{class:'ve-studio-input',value:editName,onInput:e=>sEditName(e.target.value),onKeyDown:e=>{if(e.key==='Enter')rename();if(e.key==='Escape')sEditing(null);}})
            : h('div',{style:'font-size:11px;color:#ddd;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis'},category.name),
          h('div',{style:'font-size:11px;color:#666;margin-top:2px'},Number(category.variable_count||0)+' variables')),
        editing?.slug===category.slug
          ? h('button',{class:'ve-btn ve-btn-s',onClick:rename,disabled:ld||!editName.trim()},'Save')
          : !Number(category.protected)&&[
              h('button',{class:'ve-a',title:'Rename category',onClick:()=>{sEditing(category);sEditName(category.name);}},ph('pencil-simple')),
              h('button',{class:'ve-a',title:'Delete category',onClick:()=>sConfirmDelete(category)},ph('trash'))
            ])),
      categories.length===0&&h('div',{class:'ve-empty'},'No categories available.')),
    confirmDelete&&h(ConfirmModal,{title:'Delete category',body:'Delete “'+confirmDelete.name+'”? Its variables and generated children will move to Uncategorized. Token names and CSS will not change.',confirmText:'Delete Category',danger:true,onCancel:()=>sConfirmDelete(null),onConfirm:remove}));
}

/* ── Sync sub-panel (includes Figma connection + pairing) ── */
function SyncPanel({onClose,exiting,onDone,onReload,initialView='main',snapshotsOnly=false}){
  const[view,sView]=useState(initialView);
  const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const[diff,sDiff]=useState(null);const[summary,sSummary]=useState(null);
  const[snaps,sSnaps]=useState([]);const[skipDel,sSD]=useState(true);
  const[snapshotTitle,sSnapshotTitle]=useState('');
  const[snapshotDescription,sSnapshotDescription]=useState('');
  const[showCreateModal,sShowCreateModal]=useState(false);
  const[snapDeleteId,sSnapDeleteId]=useState(null);
  const[pair,sPair]=useState(null);const[stats,sStats]=useState(null);const[cleaning,sCleaning]=useState(false);
  const[pCode,sPC]=useState('');const[pKey,sPK]=useState('');const[figCode,sFC]=useState('');const[pMsg,sPM]=useState('');
  const[diag,sDiag]=useState(null);
  const[confirmClean,sConfirmClean]=useState(false);
  const[confirmImportDeletes,sConfirmImportDeletes]=useState(false);
  const fileRef=useRef();const cssFileRef=useRef();
  const dropDepthRef=useRef(0);
  const[dropActive,sDropActive]=useState(false);
  const[importFileName,sImportFileName]=useState('');
  const[importFormat,sImportFormat]=useState('json');
  const[importMode,sImportMode]=useState('tokens');
  const[bundlePayload,sBundlePayload]=useState(null);
  const[cssText,sCssText]=useState('');const[cssCount,sCssCount]=useState(0);
  const[driftSource,sDriftSource]=useState('figma');
  const[driftData,sDriftData]=useState(null);
  const[driftKeys,sDriftKeys]=useState([]);
  const[driftPlan,sDriftPlan]=useState(null);
  const[driftMsg,sDriftMsg]=useState('');

  const loadPair=useCallback(()=>api.g('sync/pair/status').then(d=>{if(d)sPair(d);return d;}),[]);
  const loadStats=useCallback(()=>api.g('variables/stats').then(d=>{if(d&&!d.code)sStats(d);return d;}).catch(()=>null),[]);
  useEffect(()=>{loadPair();loadStats();const t=setInterval(()=>{loadPair();loadStats();},2500);return()=>clearInterval(t);},[loadPair,loadStats]);

  const genCode=async()=>{const r=await api.p('sync/pair/generate',{});if(r?.code){sPC(r.code);sPK(r.api_key||'');}};
  const submitFigCode=async()=>{if(figCode.length!==6){sPM('Enter the 6-character code');return;}const r=await api.p('sync/pair/complete-figma',{code:figCode});if(r?.api_key){sPM('Paired!');api.g('sync/pair/status').then(d=>{if(d)sPair(d);});}else sPM(r?.message||'Invalid code');};
  const disc=async()=>{await api.p('sync/pair/disconnect',{});sPair({paired:false,source:'',figma_name:'',collection_name:''});sPC('');sPK('');};
  const cleanDb=async()=>{sConfirmClean(false);sCleaning(true);sErr('');const r=await api.p('variables/cleanup',{});sCleaning(false);if(r?.after){sStats(r.after);onReload&&onReload();}else{sErr(r?.message||'Cleanup failed');}};
  const loadDiagnostics=async()=>{if(diag){sDiag(null);return;}const r=await api.g('diagnostics/logs?lines=12');if(r?.code){sErr(r.message||'Could not load diagnostics');return;}sDiag(r);};
  const cleanableStatIssues=stats?[(stats.stale_generated?stats.stale_generated+' stale':''),(stats.orphan_generated?stats.orphan_generated+' orphan generated':''),(stats.missing_dependencies?stats.missing_dependencies+' missing dependency links':''),(stats.orphan_dependencies?stats.orphan_dependencies+' orphan dependency rows':''),(stats.duplicate_count?stats.duplicate_count+' duplicate names':''),(stats.older_generators?stats.older_generators+' old generators':'')].filter(Boolean):[];
  const manualStatIssues=stats?[(stats.public_name_conflict_count?stats.public_name_conflict_count+' CSS name conflicts require manual rename':''),(stats.broken_aliases?stats.broken_aliases+' aliases have missing sources':''),(stats.blocked_orphan_generated?stats.blocked_orphan_generated+' orphan generated variables still have dependents':'')].filter(Boolean):[];
  const statIssues=[...cleanableStatIssues,...manualStatIssues];
  const exportBaseName=()=>`mimams-var-${safeFilePart(CFG.siteTitle,'wordpress')}`;
  const doExport=async(fmt)=>{sLd(true);sErr('');const d=await api.g('sync/export?format='+fmt);const blob=new Blob([JSON.stringify(d,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=exportBaseName()+'-'+fmt+'-'+(new Date).toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);sLd(false);};
  const doExportBundle=async()=>{sLd(true);sErr('');const d=await api.g('sync/export-bundle');if(d?.code||!d?.bundle){sErr(d?.message||'System Bundle export failed');sLd(false);return;}const blob=new Blob([JSON.stringify(d.bundle,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=d.filename||exportBaseName()+'-system-'+(new Date).toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);sLd(false);};
  const doExportCss=async()=>{sLd(true);sErr('');const d=await api.g('sync/export-css');if(d?.code){sErr(d.message||'CSS export failed');sLd(false);return;}const blob=new Blob([d.css||''],{type:'text/css'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=d.filename||('mimams-var-'+(new Date).toISOString().slice(0,10)+'.css');document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);sLd(false);};
  const importJsonFile=async file=>{sLd(true);sErr('');sImportFileName(file.name||'JSON file');try{const text=await file.text();const json=JSON.parse(text);const isBundle=json?.format==='mimams-var-system';const detectedFormat=isBundle?'system':json?.format==='mimams-var-figma-handoff'?'figma':Array.isArray(json)?'flat':(json?.collections?'figma':'dtcg');sImportFormat(detectedFormat);const res=await api.p(isBundle?'sync/preview-bundle':'sync/preview',json);if(res?.code){sErr(res.message||'Parse error');sLd(false);return;}sImportMode(isBundle?'system':'tokens');sBundlePayload(isBundle?json:null);sDiff(res.changes||[]);sSummary(res.summary||{});sView('preview');}catch(ex){sErr('Invalid JSON: '+ex.message);}sLd(false);};
  const importCssFile=async file=>{sErr('');sImportFileName(file.name||'CSS file');sImportFormat('css');const text=await file.text();sCssText(text);sCssCount(parseCssVariables(text).length);};
  const importDroppedFile=async file=>{
    if(!file)return;
    const name=String(file.name||'').toLowerCase();
    if(name.endsWith('.json')||file.type==='application/json'){await importJsonFile(file);return;}
    if(name.endsWith('.css')||file.type==='text/css'){await importCssFile(file);return;}
    sErr('Unsupported file. Drop an MV System Bundle, JSON token export, or CSS file.');
  };
  const doImport=async e=>{const file=e.target.files?.[0];if(file)await importJsonFile(file);e.target.value='';};
  const readCssFile=async e=>{const file=e.target.files?.[0];if(file)await importCssFile(file);e.target.value='';};
  const dragEnter=e=>{if(!Array.from(e.dataTransfer?.types||[]).includes('Files'))return;e.preventDefault();dropDepthRef.current++;sDropActive(true);};
  const dragOver=e=>{if(!Array.from(e.dataTransfer?.types||[]).includes('Files'))return;e.preventDefault();e.dataTransfer.dropEffect='copy';sDropActive(true);};
  const dragLeave=e=>{e.preventDefault();dropDepthRef.current=Math.max(0,dropDepthRef.current-1);if(dropDepthRef.current===0)sDropActive(false);};
  const dropFile=async e=>{e.preventDefault();dropDepthRef.current=0;sDropActive(false);await importDroppedFile(e.dataTransfer?.files?.[0]);};
  const previewCssImport=async()=>{const vars=parseCssVariables(cssText);sCssCount(vars.length);if(!vars.length){sErr('No CSS custom properties found. Use declarations like --color-primary: #baf400;');return;}sImportFormat('css');sLd(true);sErr('');const res=await api.p('sync/preview',vars);if(res?.code){sErr(res.message||'CSS import preview failed');sLd(false);return;}sImportMode('tokens');sBundlePayload(null);sDiff(res.changes||[]);sSummary(res.summary||{});sView('preview');sLd(false);};
  const isDeleteAction=action=>action==='delete'||String(action||'').endsWith('_delete');
  const isExecutableImportChange=c=>c?.action!=='protected_update'&&(!skipDel||!isDeleteAction(c?.action));
  const executableImportCount=(diff||[]).filter(isExecutableImportChange).length;
  const applyImport=async()=>{if(!diff)return;sConfirmImportDeletes(false);sLd(true);sErr('');let res;if(importMode==='system'){res=await api.p('sync/apply-bundle',{bundle:bundlePayload,skip_deletes:skipDel});}else{const filtered=diff.filter(isExecutableImportChange);res=await api.p('sync/apply',{changes:filtered,skip_deletes:skipDel,file_name:importFileName||'Pasted token import',import_format:importFormat||'json',import_source:'file',snapshot_title:'Before importing '+(importFileName||'pasted variables'),snapshot_description:'Recovery point created before applying '+filtered.length+' reviewed '+String(importFormat||'file').toUpperCase()+' change'+(filtered.length===1?'':'s')+'.'});}sLd(false);if(res?.errors?.length){sErr((res.rolled_back?'No changes were kept. ':'')+res.errors.join('; '));return;}if(res?.applied>0){if(res.snapshot_id)sPM('Imported safely · snapshot #'+res.snapshot_id+' is ready to restore.');onDone();}else sView('main');};
  const doApply=()=>{if(!diff)return;const deleteCount=diff.filter(c=>isDeleteAction(c.action)).length;if(!skipDel&&deleteCount){sConfirmImportDeletes(true);return;}applyImport();};
  const doSnap=async()=>{sLd(true);sErr('');const res=await api.p('sync/snapshot',{title:snapshotTitle.trim()||'Manual backup',description:snapshotDescription.trim()});sLd(false);if(res?.code){sErr(res.message||'Snapshot could not be created');return false;}else{sSnapshotTitle('');sSnapshotDescription('');await loadSnaps();return true;}};
  const loadSnaps=async()=>{const s=await api.g('sync/snapshots');if(Array.isArray(s))sSnaps(s);};
  const doRollback=async(id)=>{sLd(true);sErr('');const res=await api.p('sync/rollback/'+id,{});sLd(false);if(res?.restored)onDone();else sErr(res?.message||'Rollback failed');};
  const doDeleteSnap=async(id)=>{sSnapDeleteId(null);sLd(true);sErr('');const res=await api.d('sync/snapshot/'+id);sLd(false);if(res?.deleted)await loadSnaps();else sErr(res?.message||'Could not delete snapshot');};
  useEffect(()=>{if(view==='snapshots')loadSnaps();},[view]);
  const loadDrift=async source=>{
    const next=source||driftSource;
    sLd(true);sErr('');sDriftMsg('');sDriftPlan(null);
    const data=await api.g('sync/drift?source='+encodeURIComponent(next));
    sLd(false);
    if(data?.code){sErr(data.message||'Could not inspect Sync Drift');return;}
    sDriftData(data);
    sDriftKeys((data.rows||[]).filter(row=>row.status!=='in_sync').map(row=>String(row.key)));
  };
  const chooseDriftSource=source=>{sDriftSource(source);loadDrift(source);};
  const toggleDriftKey=key=>sDriftKeys(previous=>previous.includes(String(key))?previous.filter(item=>item!==String(key)):[...previous,String(key)]);
  const previewDrift=async direction=>{
    sLd(true);sErr('');sDriftMsg('');
    const plan=await api.p('sync/drift/preview',{source:driftSource,direction,keys:driftKeys});
    sLd(false);
    if(plan?.code){sErr(plan.message||'Could not prepare Sync Drift');return;}
    sDriftPlan(plan);
  };
  const applyDrift=async()=>{
    if(!driftPlan)return;
    sLd(true);sErr('');
    const result=await api.p('sync/drift/apply',{source:driftSource,direction:driftPlan.direction,keys:driftKeys});
    sLd(false);
    if(result?.errors?.length){sErr(result.errors.join('; '));return;}
    const message=result?.queued?(result.message||'Push queued. Open the paired Figma plugin to finish it.'):(result?.applied||0)+' drift change'+(Number(result?.applied||0)===1?'':'s')+' applied.';
    sDriftPlan(null);
    await loadDrift(driftSource);
    sDriftMsg(message);
    onReload&&onReload();
  };
  useEffect(()=>{if(view==='drift')loadDrift(driftSource);},[view]);

  const AC={add:'#22c55e',update:'#3b82f6',protected_update:'#d6a34a',delete:'#ef4444',type_change:'#f59e0b',relationship_change:'#f59e0b',repair_generated:'#a78bfa',generator_add:'#22c55e',generator_update:'#3b82f6',generator_delete:'#ef4444',themes_update:'#a78bfa',palette_add:'#22c55e',palette_update:'#3b82f6',palette_delete:'#ef4444',category_add:'#22c55e',category_update:'#3b82f6',category_delete:'#ef4444'};
  const AL={add:'ADD',update:'UPD',protected_update:'LOCK',delete:'DEL',type_change:'TYPE',relationship_change:'LINK',repair_generated:'FIX',generator_add:'GEN+',generator_update:'GEN',generator_delete:'GEN-',themes_update:'THEME',palette_add:'PAL+',palette_update:'PAL',palette_delete:'PAL-',category_add:'CAT+',category_update:'CAT',category_delete:'CAT-'};
  const blockedImportCount=(diff||[]).filter(c=>c.action==='type_change').length;
  const changeDetail=c=>{
    if(c.action==='update')return 'value: '+String(c.old_value??'')+' → '+String(c.new_value??'');
    if(c.action==='protected_update')return 'calculated family: edit its base variable or generator settings';
    if(c.action==='relationship_change')return String(c.old_source_name||'none')+' → '+String(c.source_name||'none');
    if(c.action==='type_change')return String(c.old_type||'base')+' → '+String(c.new_type||'base');
    if(c.action==='repair_generated')return 'source: '+String(c.source_name||c.base_name||'generated base');
    if(c.action.indexOf('generator_')===0)return 'generator configuration';
    if(c.action.indexOf('palette_')===0)return 'Color Palette definition or membership';
    if(c.action.indexOf('category_')===0)return 'Variable category definition or membership';
    if(c.action==='themes_update')return 'Theme values or active Theme';
    return '';
  };

  if(view==='preview')return h(Sub,{title:importMode==='system'?'System Bundle Preview':'Import Preview',onClose,exiting},
    importMode==='system'&&h('div',{class:'ve-warn',style:'margin-bottom:8px;color:#baf400'},'Portable system update: variables, generated children, aliases, Themes, Color Palettes, memberships, ordering, and CSS are recovered together if any phase fails.'),
    summary&&h('div',{style:'display:flex;gap:8px;margin-bottom:8px;flex-wrap:wrap'},summary.added>0&&h('span',{style:'font-size:11px;color:#22c55e'},'+'+summary.added+' new'),summary.updated>0&&h('span',{style:'font-size:11px;color:#3b82f6'},'~'+summary.updated+' changed'),summary.protected>0&&h('span',{style:'font-size:11px;color:#d6a34a'},summary.protected+' calculated values protected'),summary.deleted>0&&h('span',{style:'font-size:11px;color:#ef4444'},'-'+summary.deleted+' removed'),summary.repaired>0&&h('span',{style:'font-size:11px;color:#a78bfa'},summary.repaired+' relationship repairs'),summary.type_changed>0&&h('span',{style:'font-size:11px;color:#f59e0b'},summary.type_changed+' type reviews'),summary.relationship_changed>0&&h('span',{style:'font-size:11px;color:#f59e0b'},summary.relationship_changed+' source reviews'),summary.system_changed>0&&h('span',{style:'font-size:11px;color:#a78bfa'},summary.system_changed+' system changes')),
    h('div',{style:'max-height:260px;overflow-y:auto;margin-bottom:8px;padding-right:4px'},(diff||[]).map((c,i)=>h('div',{key:i,class:'ve-import-change'},h('span',{class:'ve-import-change-tag',style:`color:${AC[c.action]||'#888'}`},AL[c.action]||c.action),h('span',{class:'ve-import-change-name'},c.name),changeDetail(c)&&h('span',{class:'ve-import-change-detail',style:c.action==='relationship_change'?'color:#d6a34a':''},changeDetail(c))))),
    (diff||[]).some(c=>c.action==='relationship_change')&&h('div',{class:'ve-warn',style:'margin-bottom:8px;color:#d6a34a'},'Alias and generated source changes are shown as LINK and will be applied transactionally with the rest of the import.'),
    (diff||[]).some(c=>c.action==='protected_update')&&h('div',{class:'ve-warn',style:'margin-bottom:8px;color:#d6a34a'},'LOCK rows belong to calculated MV generator families. They are shown for transparency and safely skipped; change their base variable or generator settings instead.'),
    blockedImportCount>0&&h('div',{class:'ve-warn',style:'margin-bottom:8px'},blockedImportCount+' variable type change'+(blockedImportCount===1?' requires':'s require')+' manual review before this import can be applied.'),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:4px 0'},err),
    h('div',{class:'ve-opt',style:'margin-top:4px'},h('label',null,h('input',{type:'checkbox',checked:skipDel,onChange:e=>sSD(e.target.checked)}),'Skip deletions')),
    h('div',{style:'display:flex;gap:5px;margin-top:8px;justify-content:flex-end'},h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sView('main')},'Back'),h('button',{class:'ve-btn ve-btn-s',onClick:doApply,disabled:ld||executableImportCount<1||blockedImportCount>0},ld?'Applying...':(executableImportCount>0?'Apply '+executableImportCount+' changes':'No changes to apply'))),
    confirmImportDeletes&&h(ConfirmModal,{title:'Apply destructive import',body:'This import will remove '+(diff||[]).filter(c=>isDeleteAction(c.action)).length+' destination items. A complete safety snapshot will be created first. Continue?',confirmText:'Apply & Delete',danger:true,onCancel:()=>sConfirmImportDeletes(false),onConfirm:applyImport}));

  if(view==='snapshots')return h(Sub,{title:'Snapshots',onClose,onBack:snapshotsOnly?onClose:()=>sView('main'),exiting},
    h('div',{style:'display:flex;flex-direction:column;min-height:100%;gap:12px'},
      h('button',{class:'ve-btn ve-btn-s',style:'margin-bottom:4px;width:100%',onClick:()=>sShowCreateModal(true)},'+ New Snapshot'),
      snaps.length===0?h('div',{class:'ve-empty',style:'flex:1'},'No snapshots yet'):h('div',{style:'flex:1;min-height:0;overflow-y:auto;padding-right:4px'},snaps.map(s=>h('div',{key:s.id,class:'ve-snapshot-card'},
        h('div',{style:'min-width:0'},
          h('div',{class:'ve-snapshot-title'},s.title||s.trigger_label||s.trigger_type||'Snapshot'),
          h('div',{class:'ve-snapshot-description'},s.description||'Complete variable-system recovery point.'),
          h('div',{class:'ve-snapshot-meta'},
            h('span',null,'Snapshot #'+s.id),
            h('span',null,s.created_at),
            s.file_name&&h('span',{class:'ve-snapshot-file',title:s.file_name},s.file_name),
            s.change_count>0&&h('span',null,s.change_count+' reviewed changes')),
          s.restorable===false&&h('div',{style:'color:#d6a34a;font-size:11px;line-height:1.45;margin-top:4px'},s.restore_warning||'Legacy snapshot cannot be restored safely.')),
        h('div',{class:'ve-snap-actions'},
          h('button',{class:'ve-snap-icon-btn',title:s.restorable===false?(s.restore_warning||'Legacy snapshot cannot be restored safely.'):'Restore this snapshot',onClick:()=>doRollback(s.id),disabled:ld||s.restorable===false},ph(s.restorable===false?'prohibit':'arrow-counter-clockwise',{style:'font-size:15px;line-height:1'})),
          h('button',{class:'ve-snap-icon-btn is-danger',title:'Delete this snapshot permanently',onClick:()=>sSnapDeleteId(s.id),disabled:ld},ph('trash',{style:'font-size:15px;line-height:1'})))))),
      err&&h('div',{style:'font-size:11px;color:#ef4444;padding:4px 0'},err),
      h('div',{style:'display:flex;gap:5px;margin-top:auto'},h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:snapshotsOnly?onClose:()=>sView('main')},'Back'))),
    showCreateModal&&h('div',{class:'ve-modal'},
      h('div',{class:'ve-modal-box'},
        h('div',{class:'ve-modal-title',style:'display:flex;align-items:center;gap:7px'},ph('clock-counter-clockwise'),'Create recovery point'),
        h('div',{class:'ve-modal-body',style:'margin:12px 0 0 0'},
          h('input',{class:'ve-studio-input',value:snapshotTitle,onInput:e=>sSnapshotTitle(e.target.value),placeholder:'Snapshot title, e.g. Before homepage redesign',style:'width:100%;margin-bottom:8px'}),
          h('textarea',{class:'ve-studio-input',value:snapshotDescription,onInput:e=>sSnapshotDescription(e.target.value),placeholder:'Optional note about what this snapshot protects',style:'width:100%;margin-bottom:8px;min-height:58px;resize:vertical'})
        ),
        h('div',{class:'ve-modal-actions'},
          h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>{sShowCreateModal(false);sSnapshotTitle('');sSnapshotDescription('');},disabled:ld},'Cancel'),
          h('button',{class:'ve-btn ve-btn-s',onClick:async()=>{const ok=await doSnap();if(ok)sShowCreateModal(false);},disabled:ld},ld?'Creating...':'Create')
        )
      )
    ),
    snapDeleteId&&h(ConfirmModal,{title:'Delete snapshot',body:'Permanently delete snapshot #'+snapDeleteId+'? This recovery point cannot be restored afterward.',confirmText:'Delete',danger:true,onCancel:()=>sSnapDeleteId(null),onConfirm:()=>doDeleteSnap(snapDeleteId)})
  );



  if(view==='drift')return h(Sub,{title:'Sync Drift',onClose,onBack:()=>sView('main'),exiting},
    h('div',{class:'ve-drift-head'},
      h('div',{style:'display:flex;align-items:center;gap:8px'},h('span',{style:'color:#baf400'},ph('arrows-left-right')),h('div',null,
        h('div',{style:'font-size:11px;color:#ddd;font-weight:650'},'Compare MV with a connected consumer'),
        h('div',{style:'font-size:11px;color:#777;line-height:1.45;margin-top:2px'},'Pull uses Import Preview and a safety snapshot. Push uses the paired Figma companion or the Bricks adapter.'))),
      h('div',{style:'display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:10px'},
        h('button',{class:'ve-btn '+(driftSource==='figma'?'':'ve-btn-g'),onClick:()=>chooseDriftSource('figma')},'Figma'),
        h('button',{class:'ve-btn '+(driftSource==='bricks'?'':'ve-btn-g'),onClick:()=>chooseDriftSource('bricks')},'Bricks')),
      driftData&&h('div',{class:'ve-drift-summary'},
        h('div',{class:'ve-drift-stat'},h('b',null,driftData.summary?.in_sync||0),h('span',null,'In sync')),
        h('div',{class:'ve-drift-stat'},h('b',null,(driftData.summary?.changed||0)+(driftData.summary?.missing_mv||0)+(driftData.summary?.missing_source||0)),h('span',null,'Different')),
        h('div',{class:'ve-drift-stat'},h('b',null,driftData.summary?.conflict||0),h('span',null,'Conflicts'))),
      driftData?.reported_at&&h('div',{style:'font-size:11px;color:#5f5f5f;margin-top:7px'},driftSource==='figma'?'Last Figma report: '+driftData.reported_at:'Live Bricks registry comparison'),
      driftSource==='figma'&&Number(driftData?.age_seconds||0)>60&&h('div',{style:'font-size:11px;color:#d6a34a;line-height:1.45;margin-top:4px'},'This Figma report is older than one minute. Open the paired companion or Check again before resolving conflicts.')),
    !ld&&driftData&&!driftData.available&&h('div',{class:'ve-warn',style:'margin-bottom:9px'},driftSource==='figma'?'Open the paired Figma plugin and select a collection so it can publish a current variable report.':'Bricks global variables are not available on this site.'),
    driftData&&h('div',{style:'display:flex;align-items:center;justify-content:space-between;margin-bottom:7px'},
      h('label',{style:'display:flex;align-items:center;gap:6px;font-size:11px;color:#888'},h('input',{class:'ve-var-check',type:'checkbox',checked:(driftData.rows||[]).filter(row=>row.status!=='in_sync').length>0&&(driftData.rows||[]).filter(row=>row.status!=='in_sync').every(row=>driftKeys.includes(String(row.key))),onChange:e=>sDriftKeys(e.target.checked?(driftData.rows||[]).filter(row=>row.status!=='in_sync').map(row=>String(row.key)):[])}),'Select all differences'),
      h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>loadDrift(driftSource),disabled:ld},ld?'Checking...':'Check again')),
    driftData&&h('div',{class:'ve-drift-list'},(driftData.rows||[]).filter(row=>row.status!=='in_sync').length===0
      ?h('div',{class:'ve-empty'},'No drift detected.')
      :(driftData.rows||[]).filter(row=>row.status!=='in_sync').map(row=>h('div',{class:'ve-drift-row',key:row.key},
        h('input',{class:'ve-var-check',type:'checkbox',checked:driftKeys.includes(String(row.key)),onChange:()=>toggleDriftKey(row.key)}),
        h('div',null,h('div',{class:'ve-drift-name'},'--'+row.public_name),h('div',{class:'ve-drift-values'},'MV: '+(row.mv?.value??'Missing'),h('br'),(driftData.source_label||'Source')+': '+(row.source?.value??'Missing'))),
        h('span',{class:'ve-drift-status '+row.status},String(row.status||'changed').replace(/_/g,' '))))),
    driftPlan&&h('div',{class:'ve-warn',style:'margin-top:9px;color:#ddd'},
      h('div',{style:'font-weight:650;color:#baf400;margin-bottom:4px'},(driftPlan.direction==='pull'?'Pull into MV':'Push to '+(driftData?.source_label||driftSource))+' · '+(driftPlan.count||0)+' change'+(Number(driftPlan.count||0)===1?'':'s')),
      h('div',{style:'line-height:1.5;color:#888'},driftPlan.direction==='pull'?'Values from the selected source will enter the normal import transaction. A named snapshot is created before Apply.':(driftSource==='figma'?'The push is queued for the paired Figma companion and applies when that plugin is open.':'The Bricks adapter will refresh its MV-owned variable mirror.'))),
    driftMsg&&h('div',{class:'ve-warn',style:'margin-top:9px;color:#baf400'},driftMsg),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:8px 0'},err),
    h('div',{class:'ve-drift-actions'},
      h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sView('main')},'Back'),
      !driftPlan&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',disabled:ld||driftKeys.length<1,onClick:()=>previewDrift('pull')},'Preview Pull'),
      !driftPlan&&h('button',{class:'ve-btn ve-btn-s',disabled:ld||driftKeys.length<1,onClick:()=>previewDrift('push')},'Preview Push'),
      driftPlan&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sDriftPlan(null),disabled:ld},'Change plan'),
      driftPlan&&h('button',{class:'ve-btn ve-btn-s',onClick:applyDrift,disabled:ld||driftPlan.count<1},ld?'Applying...':'Apply resolution')));

  return h(Sub,{title:'Sync',onClose,exiting},
    /* Figma Connection */
    h('div',{style:'margin-bottom:12px'},
      h('div',{style:'font-size:11px;color:#888;margin-bottom:8px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Figma Connection'),
      h('div',{class:'ve-fig-status'},h('span',{class:'ve-fig-dot'+(pair?.paired?' on':'')}),pair?.paired?'Connected':'Not connected',h('span',{class:'ve-fig-hint'},pair?.paired?(pair.figma_name||'Figma file'):'Pair once — MV remembers this Figma file')),
      pair?.paired?h('div',null,
        h('div',{style:'display:flex;align-items:flex-start;gap:6px;font-size:11px;color:#ddd;margin-bottom:4px;font-family:monospace'},ph('file'),h('span',null,pair.figma_name||'Figma file not captured yet — open the Figma plugin once to update this.')),
        pair.collection_name&&h('div',{style:'display:flex;align-items:flex-start;gap:6px;font-size:11px;color:#888;margin-bottom:4px;font-family:monospace'},ph('stack'),h('span',null,'Collection: '+pair.collection_name)),
        h('div',{style:'font-size:11px;color:#555;margin-bottom:8px'},'Source: '+(pair.source==='figma'?'Figma':'WordPress')),
        h('button',{class:'ve-btn ve-btn-d ve-btn-s',onClick:disc},'Disconnect'))
      :h('div',null,
        h('div',{class:'ve-fig-step'},h('span',{class:'ve-fig-snum'},'1'),h('div',{class:'ve-fig-sbody'},
          h('div',{class:'ve-fig-slab'},'Generate credentials for the Figma plugin'),
          h('button',{class:'ve-btn ve-btn-s',onClick:genCode,style:'width:100%'},'Generate pairing credentials'),
          pCode&&h('div',null,
            h('div',{class:'ve-fig-cred'},h('div',{class:'ve-fig-cbody'},h('span',{class:'ve-fig-k'},'Pairing code'),h('span',{class:'ve-fig-code'},pCode)),h('span',{class:'ve-fig-copy',title:'Copy code',onClick:()=>{navigator.clipboard?.writeText(pCode);sPM('Copied code');}},ph('copy'))),
            pKey&&h('div',{class:'ve-fig-cred'},h('div',{class:'ve-fig-cbody'},h('span',{class:'ve-fig-k'},'API key'),h('span',{class:'ve-fig-val'},pKey)),h('span',{class:'ve-fig-copy',title:'Copy key',onClick:()=>{navigator.clipboard?.writeText(pKey);sPM('Copied key');}},ph('copy'))),
            h('div',{style:'font-size:10.5px;color:#6f6f6f;margin-top:7px'},'Paste both into the Figma plugin settings.')))),
        h('div',{class:'ve-fig-divider'},'or'),
        h('div',{class:'ve-fig-step'},h('span',{class:'ve-fig-snum'},'2'),h('div',{class:'ve-fig-sbody'},
          h('div',{class:'ve-fig-slab'},'Enter a code shown in the Figma plugin'),
          h('div',{class:'ve-fig-pairrow'},
            h('input',{class:'ve-studio-input',style:'flex:1;font-family:monospace;text-align:center;letter-spacing:2px;text-transform:uppercase',maxLength:6,value:figCode,onInput:e=>sFC(e.target.value.toUpperCase()),placeholder:'ABC123'}),
            h('button',{class:'ve-btn ve-btn-s',onClick:submitFigCode},'Pair')))),
        pMsg&&h('div',{style:'font-size:11px;color:'+(pMsg.includes('Paired')||pMsg.includes('Copied')?'#baf400':'#ef4444')+';padding:6px 0 0'},pMsg))),
    /* Database Cleanup */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'display:flex;align-items:center;justify-content:space-between;gap:8px'},
        h('div',null,h('div',{style:'font-size:11px;color:#ddd;font-weight:650'},'Sync Drift'),h('div',{style:'font-size:11px;color:#666;line-height:1.45;margin-top:2px'},'Compare MV with Figma or Bricks, then preview Pull or Push before resolving differences.')),
        h('button',{class:'ve-btn ve-btn-s',onClick:()=>sView('drift')},ph('arrows-left-right'),'Open'))),
    /* Database Cleanup & Languages */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:11px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'WordPress Database'),
      stats?h('div',null,
        h('div',{style:'font-size:11px;color:#ddd;margin-bottom:4px'},(stats.base||0)+' base · '+(stats.generated||0)+' generated · '+(stats.total||0)+' raw'),
        statIssues.length?h('div',{style:'font-size:11px;color:#f59e0b;margin-bottom:6px'},statIssues.join(', ')):h('div',{style:'font-size:11px;color:#555;margin-bottom:6px'},'No cleanup issues detected'),
        h('div',{style:'display:flex;gap:4px;flex-wrap:wrap'},h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sConfirmClean(true),disabled:cleaning},cleaning?'Cleaning...':'Clean WP DB'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:loadDiagnostics},diag?'Hide Diagnostics':'View Diagnostic Logs')),
        diag&&h('div',{style:'margin-top:8px;padding:8px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.08);border-radius:8px;font-size:11px;color:#aaa;line-height:1.5;max-height:120px;overflow:auto;font-family:"SF Mono","Fira Code",monospace;white-space:pre-wrap'},(diag.entries||[]).length?(diag.entries||[]).map(x=>(x.time||'')+' '+(x.level||'')+' '+(x.event||x.raw||'')).join('\n'):'No diagnostic entries yet',h('div',{style:'color:#555;margin-top:4px;word-break:break-all'},diag.path||'')))
      :h('div',{style:'font-size:11px;color:#555'},'Loading stats...'),
      ),
    /* Export */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:11px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Export'),
      h('div',{class:'ve-export-list'},
        [['bundle','package','System Bundle','Complete portable backup / site-to-site update',true,doExportBundle],
         ['dtcg','brackets-curly','DTCG','Design Tokens Community Group JSON',false,()=>doExport('dtcg')],
         ['flat','list-dashes','Flat','Flat key/value token JSON',false,()=>doExport('flat')],
         ['figma','figma-logo','Figma','Handoff for the MV Figma plugin',false,()=>doExport('figma')],
         ['css','brackets-angle','CSS',':root custom properties stylesheet',false,doExportCss]
        ].map(row=>h('button',{key:row[0],type:'button',class:'ve-export-row'+(row[4]?' primary':''),disabled:ld,onClick:row[5]},
          h('span',{class:'ve-export-ic'},ph(row[1])),
          h('span',{class:'ve-export-txt'},h('b',null,row[2]),h('span',null,row[3])),
          h('span',{class:'ve-export-dl'},ph('download-simple'),'Download')))),
      h('div',{style:'font-size:11px;color:#555;padding:6px 2px 0;line-height:1.5'},'System Bundle is the complete portable backup/update format. DTCG, Flat, Figma, and CSS remain interoperability exports.')),
    /* Import */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:11px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Import'),
      h('input',{ref:fileRef,type:'file',accept:'.json',style:'display:none',onChange:doImport}),
      h('input',{ref:cssFileRef,type:'file',accept:'.css,text/css',style:'display:none',onChange:readCssFile}),
      h('div',{class:'ve-import-help'},'Upload an MV System Bundle for a complete site-to-site update, or import DTCG, Flat, Figma, and CSS token files. Every import opens a preview before anything changes.'),
      h('div',{class:'ve-import-drop'+(dropActive?' active':''),onDragEnter:dragEnter,onDragOver:dragOver,onDragLeave:dragLeave,onDrop:dropFile},
        h('div',{class:'ve-import-drop-overlay'},ph('upload-simple'),h('span',null,'Drop file here'),h('small',null,'MV System Bundle, token JSON, or CSS variables')),
        h('div',{class:'ve-import-drop-content'},
          h('div',{style:'display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px'},h('button',{class:'ve-btn ve-btn-s',onClick:()=>fileRef.current?.click(),disabled:ld},ld?'Reading...':'Upload JSON'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>cssFileRef.current?.click(),disabled:ld},'Upload CSS')),
          h('textarea',{value:cssText,onInput:e=>{sCssText(e.target.value);sCssCount(parseCssVariables(e.target.value).length);sImportFileName('');},placeholder:'Or paste CSS variables here, e.g. :root { --color-primary: #baf400; --space-20: 20px; }',style:'width:100%;min-height:96px;padding:9px 11px;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.10);border-radius:8px;color:#f1f1f1;font-size:11px;font-family:"SF Mono","Fira Code",monospace;outline:none;resize:vertical;line-height:1.55;margin-bottom:6px'}),
          h('div',{style:'display:flex;align-items:center;justify-content:space-between;gap:8px'},h('span',{style:'font-size:11px;color:#777;overflow:hidden;text-overflow:ellipsis;white-space:nowrap'},importFileName?(importFileName+(cssCount?' · '+cssCount+' variables':'')):(cssCount?cssCount+' CSS variables detected':'Drag a compatible file here')),h('button',{class:'ve-btn ve-btn-s',onClick:previewCssImport,disabled:ld||!cssText.trim()},'Preview CSS Import'))))),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:8px 0'},err),
    confirmClean&&h(ConfirmModal,{title:'Clean WordPress DB',body:'Clean duplicate, stale, and orphan generated variables from WordPress? This keeps base variables and rebuilds recoverable generated variants.',confirmText:'Clean',onCancel:()=>sConfirmClean(false),onConfirm:cleanDb}));
}

/* ── Variable reference autocomplete ──── */
function VarRefInput({value,onInput,vars,placeholder,onKeyDown,bind}){
  const[show,sShow]=useState(false);
  const[q,sQ]=useState('');
  const[idx,sIdx]=useState(0);
  const ref=useRef();

  const matches=useMemo(()=>{
    if(show){
      if(!q)return vars.slice(0,10);
      const qLower=q.toLowerCase();
      return vars.filter(v=>{
        const dotName=(v.name||'').toLowerCase();
        const cssName=cssTokenName(v.name).toLowerCase();
        return dotName.includes(qLower)||cssName.includes(qLower);
      }).slice(0,10);
    }
    return [];
  },[show,q,vars]);

  const handleInput=e=>{
    const val=e.target.value;
    onInput(e);
    const cur=val.slice(0,e.target.selectionStart||val.length);
    const m=cur.match(/(?:var\(--|var\(|--)([a-z0-9.-]*)$/i);
    if(m){
      sQ(m[1].replace(/-/g,'.'));
      sShow(true);
      sIdx(0);
    }
    else{sShow(false);sQ('');}
  };

  // Typing "--" opens the inline type-ahead, which is fine once you know it.
  // The bind button is the discoverable route: its own searchable list.
  const[pickerOpen,sPickerOpen]=useState(false);
  const[pickerQuery,sPickerQuery]=useState('');
  const bindRef=useRef();
  useEffect(()=>{
    if(!pickerOpen)return undefined;
    const away=event=>{ if(bindRef.current&&!bindRef.current.contains(event.target))sPickerOpen(false); };
    const key=event=>{ if(event.key==='Escape')sPickerOpen(false); };
    document.addEventListener('pointerdown',away,true);
    document.addEventListener('keydown',key,true);
    return ()=>{ document.removeEventListener('pointerdown',away,true); document.removeEventListener('keydown',key,true); };
  },[pickerOpen]);
  const pickerMatches=useMemo(()=>{
    const needle=String(pickerQuery||'').trim().toLowerCase();
    const all=vars||[];
    if(!needle)return all.slice(0,60);
    return all.filter(v=>((v.name||'').toLowerCase().includes(needle)||cssTokenName(v.name).toLowerCase().includes(needle))).slice(0,60);
  },[pickerQuery,vars]);
  const chooseVariable=variable=>{
    const token='var('+cssTokenName(variable.name)+')';
    const el=ref.current;
    if(el){ el.value=token; onInput({target:el}); }
    else onInput(token);
    sPickerOpen(false);sPickerQuery('');sShow(false);
  };

  const insert=(v)=>{
    const el=ref.current;if(!el)return;
    const val=el.value;
    const pos=el.selectionStart||val.length;
    const before=val.slice(0,pos);
    const after=val.slice(pos);
    const m=before.match(/(?:var\(--|var\(|--)[a-z0-9.-]*$/i);
    if(m){
      const cssName=cssTokenName(v.name);
      const newBefore=before.slice(0,before.length-m[0].length)+'var('+cssName+')';
      const nv=newBefore+after;
      onInput({target:{value:nv}});
      sShow(false);sQ('');
      setTimeout(()=>{el.focus();el.selectionStart=el.selectionEnd=newBefore.length;},10);
    }
  };

  const handleKey=e=>{
    if(show&&matches.length){
      if(e.key==='ArrowDown'){e.preventDefault();sIdx(i=>(i+1)%matches.length);}
      else if(e.key==='ArrowUp'){e.preventDefault();sIdx(i=>(i-1+matches.length)%matches.length);}
      else if(e.key==='Enter'&&matches[idx]){e.preventDefault();insert(matches[idx]);}
      else if(e.key==='Tab'&&matches[idx]){e.preventDefault();insert(matches[idx]);}
      else if(e.key==='Escape'){sShow(false);}
    }
    if(onKeyDown)onKeyDown(e);
  };

  const bound=/^var\(--|^--/.test(String(value==null?'':value).trim());
  return h('div',{class:'ve-ac-wrap'+(bind?' has-bind':'')},
    bind&&h('span',{class:'ve-ac-bind-wrap'+(pickerOpen?' is-open':''),ref:bindRef},
      h('button',{type:'button',class:'ve-ac-bind'+(bound?' on':''),tabIndex:-1,
        'data-ve-tip':bound?'Bound to a variable':'Use an MV variable',
        onClick:()=>{sPickerOpen(v=>!v);sPickerQuery('');}},ph('lightning')),
      pickerOpen&&h('div',{class:'ve-var-menu'},
        h('input',{class:'ve-var-menu-search',value:pickerQuery,placeholder:'Search variables…',autoFocus:true,
          onInput:e=>sPickerQuery(e.target.value),
          onKeyDown:e=>{ if(e.key==='Enter'&&pickerMatches.length){e.preventDefault();chooseVariable(pickerMatches[0]);} }}),
        h('div',{class:'ve-var-menu-list'},
          pickerMatches.length?pickerMatches.map(variable=>{
            const resolved=resolvedVariableValue(variable,vars);
            return h('button',{type:'button',key:variable.id,class:'ve-var-menu-item',onClick:()=>chooseVariable(variable)},
              h('span',{class:'ve-var-menu-sw',style:isClr(resolved)?('background:'+resolved+';border-color:transparent'):''}),
              h('span',{class:'ve-var-menu-name'},cssTokenName(variable.name)),
              h('span',{class:'ve-var-menu-val'},variable.type==='alias'?variable.css_value:variable.value));
          }):h('div',{class:'ve-var-menu-empty'},vars&&vars.length?'No variable matches that.':'No MV variables yet.')),
        bound&&h('button',{type:'button',class:'ve-var-menu-unbind',onClick:()=>{
          const el=ref.current; if(el){el.value='';onInput({target:el});} else onInput('');
          sPickerOpen(false);
        }},ph('x'),' Unbind')),
    ),
    h('input',{ref,placeholder,value,onInput:handleInput,onKeyDown:handleKey,onBlur:()=>setTimeout(()=>sShow(false),150),style:'width:100%;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:11px;outline:none;font-family:monospace'}),
    show&&matches.length>0&&h('div',{class:'ve-ac'},
      matches.map((v,i)=>{
        const resVal = resolvedVariableValue(v, vars);
        return h('div',{class:'ve-ac-i'+(i===idx?' sel':''),onMouseDown:e=>{e.preventDefault();insert(v);},key:v.id},
          h('div',{class:'ve-ac-sw',style:isClr(resVal)?`background:${resVal};border-color:transparent`:''}),
          h('span',null,cssTokenName(v.name)),
          h('span',{style:'color:#444;margin-left:auto;font-size:11px'},v.type==='alias'?v.css_value:v.value));
      })));
}

/* ── Create sub-panel ─────────────────── */
function CreateSub({onCreated,onClose,categories,vars,exiting,palettes,paletteId,initialCategory}){
  const[mode,sMode]=useState('color');
  const[cat,sCat]=useState(initialCategory&&initialCategory!=='color'&&initialCategory!=='all'?initialCategory:'uncategorized');
  const[nm,sNm]=useState('');const[val,sVal]=useState('');
  const[fMin,sFMin]=useState('');const[fMax,sFMax]=useState('');
  const[hex,sHex]=useState('#baf400');const[alpha,sAlpha]=useState(1);const[fmt,sFmt]=useState('oklch');
  const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const[selectedPalette,sSelectedPalette]=useState(paletteId&&paletteId!=='all'?String(paletteId):((palettes||[]).length===1?String(palettes[0].id):''));
  const fullNm=nm;

  const create=async()=>{
    if(!nm)return;sLd(true);sErr('');
    let fv;
    if(mode==='color')fv=colorOklch(hex,alpha);
    else if(mode==='fluid')fv=fluidMarker(fMin,fMax);
    else if(mode==='clamp')fv=val?(val.match(/\d/)?pxToRemValue(val):val):'10px';
    else fv=val;
    if(!fv){sLd(false);sErr(mode==='fluid'?'Enter both a min and max value.':'');return;}
    const payload={name:fullNm,value:fv,category_slug:mode==='color'?'uncategorized':cat};
    if(mode==='color'){
      if(!selectedPalette){sLd(false);sErr('Choose a palette for this color.');return;}
      payload.palette_id=Number(selectedPalette);
    }
    if(mode==='static'){
      const sourceId = detectAliasSource(fv, vars);
      if(sourceId){
        payload.type='alias';
        payload.source_id=Number(sourceId);
      }
    }
    const r=await api.p('variables',payload);
    sLd(false);
    if(r?.code==='ve_duplicate'){sErr(r.message||'A variable with this name already exists.');return;}
    if(r?.code){sErr(r.message||'Failed to create variable.');return;}
    if(r?.id)onCreated(r);
  };

  const catOpts=(categories||[]).map(c=>({value:c.slug,label:c.name}));

  return h(Sub,{title:'New Variable',onClose,exiting},
    h('div',{class:'ve-ef-types',style:'margin-bottom:12px'},
      h('button',{type:'button',class:'ve-ef-type'+(mode==='color'?' on':''),onClick:()=>sMode('color')},'Color'),
      h('button',{type:'button',class:'ve-ef-type'+(mode==='clamp'?' on':''),onClick:()=>sMode('clamp')},'Fixed'),
      h('button',{type:'button',class:'ve-ef-type'+(mode==='fluid'?' on':''),onClick:()=>sMode('fluid')},'Fluid'),
      h('button',{type:'button',class:'ve-ef-type'+(mode==='static'?' on':''),onClick:()=>sMode('static')},'Static')),
    mode==='color'&&h('div',{class:'ve-opt ve-opt-stack',style:'padding-top:0'},
      h('span',null,'Palette'),
      (palettes||[]).length
        ? h(SelectMenu,{value:selectedPalette,onChange:sSelectedPalette,options:[{value:'',label:'Choose palette'},...(palettes||[]).map(p=>({value:String(p.id),label:p.name}))]})
        : h('div',{class:'ve-warn',style:'margin:0;font-size:11px'},'Create a palette before creating Color variables.')),
    mode!=='color'&&h('div',{class:'ve-opt ve-opt-stack',style:'padding-top:0'},
      h('span',null,'Category'),
      h(SelectMenu,{value:cat,onChange:sCat,options:catOpts})),
    h('div',{class:'ve-row'},h('input',{placeholder:mode==='color'?'e.g. accent, free-test':'e.g. 20, heading-58, gap-20',value:nm,onInput:e=>{sNm(normalizeNameInput(e.target.value));if(err)sErr('');},onKeyDown:e=>e.key==='Enter'&&create(),style:'flex:1'})),
    nm&&h('div',{style:'font-size:11px;color:#444;padding:0 0 6px;font-family:monospace'},publicTokenLabel(fullNm)),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:2px 0 6px'},err),
    mode==='color'&&h(VariableColorField,{hex,onChange:sHex,alpha,onAlphaChange:sAlpha,fmt,setFmt:sFmt}),
    mode==='clamp'&&h('div',null,
      h('div',{class:'ve-row'},h('input',{placeholder:'Base value (number, stored as rem)',value:val,onInput:e=>{const v=e.target.value.replace(/[^0-9.]/g,'');sVal(v);},style:'flex:1'})),
      h('div',{style:'font-size:11px;color:#555;padding:0 0 6px'},'Numbers are px references — stored as rem using 10px = 10px. Example: 20 → 20px.')),
    mode==='fluid'&&h('div',null,
      h('div',{class:'ve-row',style:'gap:6px'},
        h('input',{placeholder:'Min px',value:fMin,onInput:e=>{sFMin(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'}),
        h('input',{placeholder:'Max px',value:fMax,onInput:e=>{sFMax(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'})),
      fMin&&fMax&&h('div',{style:'font-size:11px;color:#baf400;padding:0 0 4px;font-family:monospace;word-break:break-all'},fluidPreview(fMin,fMax)),
      h('div',{style:'font-size:11px;color:#555;padding:0 0 6px'},'Scales smoothly between the page min and max viewport widths (set in Settings). Min/max are px values.')),
    mode==='static'&&h('div',{class:'ve-row'},
      h(VarRefInput,{placeholder:'e.g. 0 4px 12px rgba(0,0,0,.1) or var(--...',value:val,onInput:e=>sVal(typeof e.target==='object'?e.target.value:e),vars:vars||[],onKeyDown:e=>e.key==='Enter'&&create()})),
    h('div',{style:'display:flex;gap:5px;justify-content:flex-end;margin-top:4px'},
      h('button',{class:'ve-btn',onClick:create,disabled:ld||!nm||(mode==='color'&&!selectedPalette)||(mode==='clamp'&&!val)||(mode==='static'&&!val)||(mode==='fluid'&&(!fMin||!fMax))},ld?'...':'Create')));
}

/* ── Edit sub-panel (same as create, pre-filled) ── */
function EditSub({variable,onDone,onClose,categories,vars,onNavigateUsage,exiting}){
  const resolvedVal=resolvedVariableValue(variable, vars);
  const isClrV=isClr(resolvedVal);
  const isFluidV=isFluidVal(variable.value);
  const initMode=variable.type==='alias'?'static':(isClrV?'color':(isFluidV?'fluid':((variable.value||'').includes('clamp')?'clamp':'static')));
  const initCat=variable.category_slug||'uncategorized';
  const initNm=normalizeNameInput(variable.name);
  const initFluid=isFluidV?parseFluid(variable.value):null;

  const[mode,sMode]=useState(initMode);
  const[cat,sCat]=useState(initCat);
  const[nm,sNm]=useState(initNm);const[val,sVal]=useState(variable.type==='alias'?variable.css_value:(variable.value||''));
  const[fMin,sFMin]=useState(initFluid?String(initFluid[0]):'');const[fMax,sFMax]=useState(initFluid?String(initFluid[1]):'');
  const[hex,sHex]=useState(isClrV?clrToHex(resolvedVal):'#baf400');const[alpha,sAlpha]=useState(isClrV?clrAlpha(resolvedVal):1);const[fmt,sFmt]=useState('oklch');
  const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const[prop,sProp]=useState(false);const[impact,sImpact]=useState(null);const[checking,sChecking]=useState(false);

  useEffect(()=>{
    if(mode!=='color'||!hex)return;
    applyVariablePreview(variable.name,colorOklch(hex,alpha));
    return()=>clearVariablePreview(variable.name);
  },[mode,hex,alpha,variable.name]);
  const fullNm=nm;
  const nameChanged=fullNm&&cssTokenName(fullNm)!==cssTokenName(variable.name);
  const proposedSourceId=mode==='static'?detectAliasSource(val,vars):null;
  const proposedType=mode==='static'&&proposedSourceId?'alias':'base';
  const typeChanged=proposedType!==String(variable.type||'base');
  const previewRename=async()=>{if(!nameChanged)return;sChecking(true);sErr('');try{const r=await api.p('variables/'+variable.id+'/rename-preview',{new_name:fullNm});if(r?.code){sErr(r.message||'Preview failed');return;}sImpact(r.impact||null);}catch(e){sErr('Preview failed. Check WordPress error logs for details.');}finally{sChecking(false);}};

  const save=async()=>{
    if(!nm)return;sLd(true);sErr('');
    let fv;
    if(mode==='color')fv=colorOklch(hex,alpha);
    else if(mode==='fluid')fv=fluidMarker(fMin,fMax);
    else if(mode==='clamp')fv=val?(val.match(/\d/)?pxToRemValue(val):val):'10px';
    else fv=val;
    if(!fv){sLd(false);sErr(mode==='fluid'?'Enter both a min and max value.':'');return;}
    const updates={};
    if(nameChanged){updates.name=fullNm;if(prop)updates.propagate_usages=true;}
    if(cat!==(variable.category_slug||'uncategorized'))updates.category_slug=cat;
    // For colors, compare hex values to detect change (avoids oklch rounding issues)
    if(mode==='color'){
      if(hex!==clrToHex(variable.value)||Math.abs(alpha-clrAlpha(variable.value))>.001){updates.value=fv;updates.palette_value=true;}
    } else {
      if(fv!==variable.value)updates.value=fv;
    }
    if(mode==='static'){
      const sourceId = detectAliasSource(fv, vars);
      if(sourceId){
        if(variable.type!=='alias'||Number(variable.source_id)!==Number(sourceId)){
          updates.type='alias';
          updates.source_id=Number(sourceId);
          updates.value=''; // database stores empty value for alias type
        }
      } else {
        if(variable.type!=='base'){
          updates.type='base';
          updates.source_id=null;
          updates.value=fv;
        }
      }
    } else {
      if(variable.type!=='base'){
        updates.type='base';
        updates.source_id=null;
      }
    }
    if(Object.keys(updates).length===0){sLd(false);onDone();return;}
    const r=await api.u('variables/'+variable.id,updates);
    sLd(false);
    if(r?.code==='ve_duplicate'){sErr(r.message||'Name already exists.');return;}
    if(r?.code){sErr(r.message||'Failed to update.');return;}
    onDone(r);
  };

  const catOpts=(categories||[]).map(c=>({value:c.slug,label:c.name}));

  const impactSafe=impact&&(impact.total_matches||0)===0;
  return h(Sub,{title:'Edit variable',onClose,exiting},
    h('div',{class:'ve-ef'},
      h('div',null,
        h('div',{class:'ve-ef-label'},'Type'),
        h('div',{class:'ve-ef-types'},
          h('button',{type:'button',class:'ve-ef-type'+(mode==='color'?' on':''),onClick:()=>sMode('color')},'Color'),
          h('button',{type:'button',class:'ve-ef-type'+(mode==='clamp'?' on':''),onClick:()=>sMode('clamp')},'Fixed'),
          h('button',{type:'button',class:'ve-ef-type'+(mode==='fluid'?' on':''),onClick:()=>sMode('fluid')},'Fluid'),
          h('button',{type:'button',class:'ve-ef-type'+(mode==='static'?' on':''),onClick:()=>sMode('static')},'Static'))),
      h('div',{class:'ve-ef-card'},
        h('div',{class:'ve-ef-label'},'Identity'),
        h('div',{class:'ve-ef-field'},
          h('label',null,'Name'),
          h('input',{class:'ve-studio-input',value:nm,placeholder:'name',onInput:e=>{sNm(normalizeNameInput(e.target.value));sImpact(null);if(err)sErr('');},onKeyDown:e=>e.key==='Enter'&&save()}),
          nm&&h('div',{class:'ve-ef-cssname'},h('span',{class:'ve-ef-cssname-lab'},'CSS'),publicTokenLabel(fullNm))),
        !isClrV&&h('div',{class:'ve-ef-field'},
          h('label',null,'Category'),
          h(SelectMenu,{value:cat,onChange:sCat,options:catOpts}))),
      h('div',{class:'ve-ef-card'},
        h('div',{class:'ve-ef-label'},'Value'),
        mode==='color'&&h(VariableColorField,{hex,onChange:sHex,alpha,onAlphaChange:sAlpha,fmt,setFmt:sFmt}),
        mode==='clamp'&&h('div',null,
          h('input',{class:'ve-studio-input',placeholder:'Base value (number, stored as rem)',value:val,onInput:e=>sVal(e.target.value),onKeyDown:e=>e.key==='Enter'&&save()}),
          h('div',{class:'ve-ef-hint'},'Current: '+variable.value)),
        mode==='fluid'&&h('div',null,
          h('div',{class:'ve-ef-fluidrow'},
            h('input',{class:'ve-studio-input',placeholder:'Min px',value:fMin,onInput:e=>{sFMin(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');}}),
            h('input',{class:'ve-studio-input',placeholder:'Max px',value:fMax,onInput:e=>{sFMax(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');}})),
          fMin&&fMax&&h('div',{class:'ve-ef-fluidpreview'},fluidPreview(fMin,fMax)),
          h('div',{class:'ve-ef-hint'},'Scales between the page min/max viewport widths. Min/max are px values.')),
        mode==='static'&&h(VarRefInput,{placeholder:'value',value:val,onInput:e=>sVal(typeof e.target==='object'?e.target.value:e),vars:vars||[],onKeyDown:e=>e.key==='Enter'&&save()})),
      nameChanged&&h('div',{class:'ve-ef-impact'+(impactSafe?' safe':'')},
        h('div',{class:'ve-ef-impact-head'},
          h('span',{class:'ve-ef-impact-icon'},ph(impactSafe?'check':'warning')),
          h('div',null,
            h('div',{class:'ve-ef-impact-title'},impactSafe?'Rename is safe':'Rename detected'),
            h('div',{class:'ve-ef-impact-sub'},impactSafe?'No consumers use this variable yet.':'You can update existing var() references in WordPress / Bricks storage too.'))),
        h('label',{class:'ve-ef-toggle-row'},h('input',{type:'checkbox',checked:prop,onChange:e=>sProp(e.target.checked)}),h('span',null,'Update usages in WordPress storage')),
        h('button',{type:'button',class:'ve-ef-preview-btn',onClick:previewRename,disabled:checking},ph('eye'),checking?'Checking...':'Preview impact'),
        impact&&h('div',{class:'ve-ef-impact-result'},(impact.total_matches||0)+' matches in '+((impact.locations||[]).length)+' records')),
      (nameChanged||typeChanged)&&h(VariableUsagePanel,{variable,onNavigate:onNavigateUsage,title:(nameChanged?'Rename':'Type change')+' impact'}),
      err&&h('div',{class:'ve-ef-err'},err),
      h('div',{class:'ve-ef-footer'},
        h('button',{type:'button',class:'ve-btn ve-btn-g',onClick:onClose},'Cancel'),
        h('button',{type:'button',class:'ve-btn',onClick:save,disabled:ld||!nm||(mode==='fluid'&&(!fMin||!fMax))},ld?'…':'Save changes'))));
}

/* ── Detail (with inline value editing) ── */
function Detail({variable,vars,onNav,onNavigateUsage,onClose,onUpdate,onEditFull}){
  const[d,sD]=useState(null);
  const[editing,sEditing]=useState(false);
  const[editVal,sEV]=useState('');
  const[saving,sSaving]=useState(false);
  useEffect(()=>{sD(null);if(variable){api.g('variables/'+variable.id).then(sD);sEditing(false);}},[variable?.id]);
  if(!variable)return null;
  const css=cssTokenName(variable.name);
  const isGen=variable.type==='generated';
  const isFluidV=isFluidVal(variable.value);
  const fluidPair=isFluidV?parseFluid(variable.value):null;
  const fluidLabel=fluidPair?(trimNum(fluidPair[0])+' → '+trimNum(fluidPair[1])+'px fluid'):'';
  const resolvedVal=resolvedVariableValue(variable, vars);
  const displayVal=variable.type==='alias'
    ? (variable.css_value ? `${variable.css_value}${resolvedVal ? ` (${resolvedVal})` : ''}` : resolvedVal)
    : (isFluidV ? fluidLabel : variable.value);
  // Fluid variables can't be edited with the single-field inline editor — send to full edit panel.
  const startEdit=()=>{if(isGen)return;if(isFluidV){onEditFull&&onEditFull(variable);return;}sEV(variable.type==='alias'?variable.css_value:variable.value);sEditing(true);};
  const saveVal=async()=>{
    const currentVal=variable.type==='alias'?variable.css_value:variable.value;
    if(!editVal||editVal===currentVal){sEditing(false);return;}
    sSaving(true);
    const updates={value:editVal};
    if(isClr(resolvedVal))updates.palette_value=true;
    const sourceId = detectAliasSource(editVal, vars);
    if(sourceId){
      updates.type='alias';
      updates.source_id=Number(sourceId);
      updates.value='';
    } else {
      updates.type='base';
      updates.source_id=null;
    }
    const r=await api.u('variables/'+variable.id,updates);
    sSaving(false);sEditing(false);
    if(r&&!r.code&&onUpdate)onUpdate();
  };
  return h('div',{class:'ve-det'},
    h('div',{class:'ve-det-t'},h('span',null,publicTokenLabel(variable.name)),h('button',{class:'ve-exp',onClick:onClose},ph('x'))),
    h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'Value'),
      editing?h('div',{style:'display:flex;gap:3px;flex:1'},
        h('input',{style:'flex:1;padding:2px 4px;background:#2a2a2a;border:1px solid #baf400;border-radius:3px;color:#f1f1f1;font-size:11px;font-family:monospace;outline:none',value:editVal,onInput:e=>sEV(e.target.value),onKeyDown:e=>{if(e.key==='Enter')saveVal();if(e.key==='Escape')sEditing(false);}}),
        h('button',{class:'ve-btn ve-btn-s',style:'padding:1px 6px;font-size:11px',onClick:saveVal,disabled:saving},saving?'...':'✓'))
      :h('span',{class:'ve-det-v',style:isGen?'':'cursor:pointer',onClick:startEdit,title:isGen?'Generated — edit base variable':(isFluidV?'Fluid — click to edit min/max':'Click to edit')},displayVal)),
    isFluidV&&h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'Fluid'),h('span',{class:'ve-det-v',style:'font-size:11px;color:#baf400;word-break:break-all'},variable.css_value||d?.css_value||'')),
    h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'CSS'),h('span',{class:'ve-det-v'},'var('+css+')')),
    h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'Type'),h('span',{class:'ve-det-v'},variable.type||'base')),
    d?.dependents?.length>0&&h('div',{class:'ve-dep-s'},h('div',{class:'ve-dep-t'},'Dependents ('+d.dependents.length+')'),
      d.dependents.slice(0,6).map(x=>h('div',{class:'ve-dep',onClick:()=>onNav(x)},x.name))),
    d?.depends_on?.length>0&&h('div',{class:'ve-dep-s'},h('div',{class:'ve-dep-t'},'Source'),
      d.depends_on.map(x=>h('div',{class:'ve-dep',onClick:()=>onNav(x)},x.name))),
    h(VariableUsagePanel,{variable,onNavigate:onNavigateUsage}));
}

/* ── Main ──────────────────────────────── */
function Panel(){
  const[open,sO]=useState(false);const[vars,sV]=useState([]);const[stats,sStats]=useState(null);const[sr,sSr]=useState('');
  const[sel,sSel]=useState(null);const[nsTab,sNT]=useState('all');
  const[sourceFilter,sSourceFilter]=useState('all');
  const[palettesData,sPalettesData]=useState({active:'default',palettes:[]});
  const[colorPalettesData,sColorPalettesData]=useState({palettes:[]});
  const[variableCategoriesData,sVariableCategoriesData]=useState({categories:[]});
  const[selectedColorPalette,sSelectedColorPalette]=useState('all');
  const[colorControlMode,sColorControlMode]=useState(()=>localStorage.getItem('ve_color_control_mode')||'theme');
  const[colorPaletteManagerOpen,sColorPaletteManagerOpen]=useState(()=>localStorage.getItem('ve_color_palette_mgr_open')==='1');
  const[showAllTab,sShowAllTab]=useState(true);
  const[exp,sExp]=useState({});const[toast,sToast]=useState('');const[toastTick,sToastTick]=useState(0);const[cfm,sCfm]=useState(null);
  const[mvTip,sMvTip]=useState(null);
  const mvTipTargetRef=useRef(null);
  const toastTimerRef=useRef(null);
  // Short confirmations auto-dismiss with the countdown ring. Longer messages are
  // things you need time to read, so they stay until dismissed with the × instead.
  const[toastSticky,sToastSticky]=useState(false);
  const flash=useCallback(m=>{
    if(toastTimerRef.current)clearTimeout(toastTimerRef.current);
    const sticky=String(m||'').length>72;
    sToastTick(v=>v+1);
    sToastSticky(sticky);
    sToast(m);
    if(!sticky)toastTimerRef.current=setTimeout(()=>{sToast('');toastTimerRef.current=null;},5000);
  },[]);
  const[rowActions,sRowActions]=useState(null);
  const rowActionsTimerRef=useRef(null);
  const[sub,sSub]=useState(null);const[autoGen,sAG]=useState(null);
  const [editingCategory, sEditingCategory] = useState(null);
  const [categoryEditName, sCategoryEditName] = useState('');
  const [confirmCategoryDelete, sConfirmCategoryDelete] = useState(null);
  const [categoryMenu, sCategoryMenu] = useState(null);

  const renameCategory = async () => {
    if (!editingCategory || !categoryEditName.trim()) return;
    const r = await api.p('variable-categories/' + editingCategory.slug + '/rename', { name: categoryEditName.trim() });
    if (r?.code) {
      flash(r.message || 'Could not rename category');
      return;
    }
    sEditingCategory(null);
    await load();
    flash('Category renamed');
  };

  const deleteCategory = async () => {
    if (!confirmCategoryDelete) return;
    const category = confirmCategoryDelete;
    sConfirmCategoryDelete(null);
    const r = await api.p('variable-categories/' + category.slug + '/remove', {});
    if (r?.code) {
      flash(r.message || 'Could not delete category');
      return;
    }
    if (nsTab === category.slug) {
      sNT('all');
    }
    await load();
    flash('Category deleted · variables moved to Uncategorized');
  };
  const hSel = v => sSel(current => current?.id === v.id ? null : v);
  const [draggingVarId, sDraggingVarId] = useState(null);
  const [dragOverVarId, sDragOverVarId] = useState(null);
  const [checkedVars, sCheckedVars] = useState([]);
  const checkedVarSet = useMemo(()=>new Set(checkedVars.map(Number)),[checkedVars]);
  const [selectionReviewOpen, sSelectionReviewOpen] = useState(false);
  const lastAutoOpenedHiddenSelectionRef = useRef('');
  const lastCheckedVarRef = useRef(null);
  const [confirmBatchDelete, sConfirmBatchDelete] = useState(false);
  const [batchTargetPaletteId, sBatchTargetPaletteId] = useState('');
  const [batchTargetCategorySlug, sBatchTargetCategorySlug] = useState('');

  const handleVarDragStart = (e, v) => {
    sDraggingVarId(v.id);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', String(v.id));
  };
  const handleVarDragOver = (e, v) => {
    e.preventDefault();
    if (v.id !== draggingVarId) {
      sDragOverVarId(v.id);
    }
  };
  const handleVarDragEnd = () => {
    sDraggingVarId(null);
    sDragOverVarId(null);
  };
  const handleVarDrop = async (e, targetVar) => {
    e.preventDefault();
    const sourceId = draggingVarId;
    sDraggingVarId(null);
    sDragOverVarId(null);
    if (!sourceId || sourceId === targetVar.id) return;

    const currentList = [...filtered];
    const sourceIdx = currentList.findIndex(x => x.id === sourceId);
    const targetIdx = currentList.findIndex(x => x.id === targetVar.id);
    if (sourceIdx === -1 || targetIdx === -1) return;

    const [removed] = currentList.splice(sourceIdx, 1);
    currentList.splice(targetIdx, 0, removed);

    const allVars = [...vars];
    const idsToReorder = currentList.map(x => x.id);
    const reorderedIds = [];
    reorderedIds.push(...idsToReorder);
    const otherIds = allVars.filter(x => !idsToReorder.includes(x.id)).map(x => x.id);
    reorderedIds.push(...otherIds);

    sV(allVars.map(x => {
      if (idsToReorder.includes(x.id)) {
        const idx = idsToReorder.indexOf(x.id);
        return { ...x, position: idx };
      }
      return x;
    }));

    try {
      const res = await api.p('variables/reorder', { ids: reorderedIds });
      if (res && !res.code) {
        flash('Order saved');
      } else {
        flash(res?.message || 'Failed to save order');
      }
      load();
    } catch(err) {
      flash('Failed to save order');
      load();
    }
  };

  const toggleVarChecked = (id, event) => {
    id=Number(id);
    const shiftHeld=!!(event?.shiftKey||event?.nativeEvent?.shiftKey||event?.currentTarget?.__veShiftKey);
    const shouldCheck=!checkedVarSet.has(id);
    const anchor=Number(lastCheckedVarRef.current||0);
    if(shiftHeld&&anchor&&visibleSelectionIds.includes(anchor)&&visibleSelectionIds.includes(id)){
      const start=visibleSelectionIds.indexOf(anchor);
      const end=visibleSelectionIds.indexOf(id);
      const range=visibleSelectionIds.slice(Math.min(start,end),Math.max(start,end)+1);
      sCheckedVars(prev=>{
        const normalized=prev.map(Number);
        return shouldCheck?[...new Set([...normalized,...range])]:normalized.filter(value=>!range.includes(value));
      });
    }else{
      sCheckedVars(prev=>{
        const normalized=prev.map(Number);
        return normalized.includes(id)?normalized.filter(value=>value!==id):[...normalized,id];
      });
    }
    lastCheckedVarRef.current=id;
  };
  const toggleAllVarsChecked = () => {
    const visibleIds = visibleSelectionIds;
    const allChecked = visibleIds.every(id => checkedVarSet.has(Number(id)));
    if (allChecked) {
      sCheckedVars(prev => prev.map(Number).filter(id => !visibleIds.includes(id)));
    } else {
      sCheckedVars(prev => [...new Set([...prev.map(Number), ...visibleIds])]);
    }
  };
  const removeCheckedVar = id => {
    id=Number(id);
    if(Number(lastCheckedVarRef.current||0)===id)lastCheckedVarRef.current=null;
    sCheckedVars(prev=>prev.filter(value=>Number(value)!==id));
  };
  const clearCheckedVars = () => {
    lastCheckedVarRef.current=null;
    sSelectionReviewOpen(false);
    sCheckedVars([]);
  };
  const deleteCheckedVars = async () => {
    if (checkedVars.length === 0) return;
    try {
      const res = await api.p('variables/batch-delete', { ids: checkedVars, force: true });
      if (res && !res.code) {
        flash(checkedVars.length + ' variables deleted');
        clearCheckedVars();
        load();
      } else {
        flash(res?.message || 'Failed to delete variables');
      }
    } catch(e) {
      flash('Failed to delete variables');
    }
  };
  const moveCheckedVarsToPalette = async (paletteId) => {
    if (checkedVars.length === 0 || !paletteId) return;
    try {
      const res = await api.p('color-palettes/variables/batch-move', { ids: checkedVars, palette_id: Number(paletteId) });
      if (res && !res.code) {
        flash(checkedVars.length + ' colors assigned to palette');
        clearCheckedVars();
        load();
      } else {
        flash(res?.message || 'Failed to assign colors');
      }
    } catch(e) {
      flash('Failed to assign colors');
    }
  };
  const moveCheckedVarsToCategory = async (categorySlug) => {
    if (checkedVars.length === 0 || !categorySlug) return;
    try {
      const res = await api.p('variable-categories/variables/move', { variable_ids: checkedVars, category_slug: categorySlug });
      if (res && !res.code) {
        flash((res.moved || checkedVars.length) + ' variables moved');
        clearCheckedVars();
        sBatchTargetCategorySlug('');
        load();
      } else {
        flash(res?.message || 'Failed to move variables');
      }
    } catch(e) {
      flash('Failed to move variables');
    }
  };
  const activatePalette = async (slug) => {
    try {
      const res = await api.p('themes/' + slug + '/activate', {});
      if (res && !res.code) {
        sPalettesData(prev => ({ ...prev, active: slug }));
        load();
        flash('Theme activated');
      } else {
        flash(res?.message || 'Activation failed');
      }
    } catch (e) {
      flash('Activation failed');
    }
  };
  const[updateInfo,sUpdateInfo]=useState(null);const[skipUpdate,sSkipUpdate]=useState(()=>localStorage.getItem('ve_skip_update_version')||'');
  const[panelMode,sPanelMode]=useState(()=>localStorage.getItem('ve_panel_mode')||'right');
  const[panelPos,sPanelPos]=useState(()=>{try{return JSON.parse(localStorage.getItem('ve_panel_pos')||'{}')}catch(e){return{}}});
  const[allowMultiPanels,sAllowMultiPanels]=useState(()=>localStorage.getItem('ve_allow_multi_panels')==='1');
  const[snapSide,sSnapSide]=useState('');
  const[confirmCleanFooter,sConfirmCleanFooter]=useState(false);
  
  // Standalone panel states
  const [settingsOpen, sSettingsOpen] = useState(false);
  const [helpOpen, sHelpOpen] = useState(false);
  const [cssStudioOpen, sCssStudioOpen] = useState(false);
  const [usageCssSheet, sUsageCssSheet] = useState('');
  const [usageRecipeCode, sUsageRecipeCode] = useState('');
  const [contentStudioOpen, sContentStudioOpen] = useState(false);
  const [mediaStudioOpen, sMediaStudioOpen] = useState(false);
  const [mediaStudioInitialFilter, setMediaStudioInitialFilter] = useState('');
  const [fontManagerOpen, sFontManagerOpen] = useState(false);
  const [pluginStudioOpen, sPluginStudioOpen] = useState(false);
  const [bricksSettingsOpen, sBricksSettingsOpen] = useState(false);
  const [themeStylesOpen, sThemeStylesOpen] = useState(false);
  const [recoveryOpen, sRecoveryOpen] = useState(()=>!!document.querySelector('[data-panel="recovery"].rb-open'));
  const [cssRecipesOpen, sCssRecipesOpen] = useState(false);
  // Per-module tooltip suppression. The switches live in the Settings component, so this
  // side only mirrors the stored list into a ref the tooltip engine can read.
  const tooltipsOffRef = useRef(readTooltipsOff());
  useEffect(() => {
    const sync = () => { tooltipsOffRef.current = readTooltipsOff(); };
    window.addEventListener('ve-tooltips-off-changed', sync);
    window.addEventListener('storage', sync);
    return () => {
      window.removeEventListener('ve-tooltips-off-changed', sync);
      window.removeEventListener('storage', sync);
    };
  }, []);
  useEffect(() => {
    // Warm the lightweight Media Studio cache after the admin surface settles. Opening
    // the studio can then paint from memory instead of starting with an empty library.
    const timer = setTimeout(() => { prefetchMediaLibrary().catch(() => {}); }, 180);
    return () => clearTimeout(timer);
  }, []);

  const [fabToolsOpen, setFabToolsOpen] = useState(false);
  // Hover-intent for the speed dial: closing the instant the pointer leaves made it
  // almost impossible to travel diagonally from the trigger to an icon. Keep it open
  // for a grace period and cancel that timer whenever the pointer comes back.
  const fabCloseTimerRef = useRef(null);
  const cancelFabClose = useCallback(() => {
    if (fabCloseTimerRef.current) { clearTimeout(fabCloseTimerRef.current); fabCloseTimerRef.current = null; }
  }, []);
  const openFabTools = useCallback(() => { cancelFabClose(); setFabToolsOpen(true); }, [cancelFabClose]);
  const scheduleFabClose = useCallback(() => {
    cancelFabClose();
    fabCloseTimerRef.current = setTimeout(() => { setFabToolsOpen(false); fabCloseTimerRef.current = null; }, 320);
  }, [cancelFabClose]);
  useEffect(() => () => { if (fabCloseTimerRef.current) clearTimeout(fabCloseTimerRef.current); }, []);
  const [fabOrder, setFabOrder] = useState(readFabOrder);
  const [activeStudioTool, sActiveStudioTool] = useState('');
  const [studioLaunchContext, sStudioLaunchContext] = useState(null);
  const [cssStudioDirty, sCssStudioDirty] = useState(false);
  const [cssStudioResetToken, sCssStudioResetToken] = useState(0);
  const [studioLeaveRequest, sStudioLeaveRequest] = useState(null);

  // Lazy-mount states for exit animations
  const settingsHasOpened=useOpenedOnce(settingsOpen);
  const helpHasOpened=useOpenedOnce(helpOpen);
  const cssStudioHasOpened=useOpenedOnce(cssStudioOpen);
  const contentStudioHasOpened=useOpenedOnce(contentStudioOpen);
  const mediaStudioHasOpened=useOpenedOnce(mediaStudioOpen);
  const fontManagerHasOpened=useOpenedOnce(fontManagerOpen);
  const pluginStudioHasOpened=useOpenedOnce(pluginStudioOpen);
  const bricksSettingsHasOpened=useOpenedOnce(bricksSettingsOpen);
  const themeStylesHasOpened=useOpenedOnce(themeStylesOpen);
  const cssRecipesHasOpened=useOpenedOnce(cssRecipesOpen);

  const disabledToolsForCurrentSurface = settings => disabledToolsForSurface(settings,MODE==='builder'?'builder':'admin');
  const readDisabledToolsForSurface = surface => {
    try {
      const side = surface || (MODE === 'builder' ? 'builder' : 'admin');
      return disabledToolsForSurface({
        deactivated_tools:readStoredJson('ve_deactivated_tools',[]),
        deactivated_tool_surfaces:readStoredJson('ve_deactivated_tool_surfaces',{})
      },side);
    } catch (e) {
      return [];
    }
  };
  const [deactivatedTools, setDeactivatedTools] = useState(() => readDisabledToolsForSurface());
  // Module state can change while the page's initial settings request is still
  // in flight. Track every accepted runtime change so an older response cannot
  // restore the pre-toggle rail a second or two later.
  const moduleRuntimeRevisionRef=useRef(0);

  const applyModuleStateImmediately = settings => {
    moduleRuntimeRevisionRef.current+=1;
    const fresh=disabledToolsForCurrentSurface(settings||{});
    deactivatedToolsRef.current=fresh;
    setDeactivatedTools(current=>{
      const same=current.length===fresh.length&&current.every(id=>fresh.includes(id));
      return same?current:fresh;
    });
    return fresh;
  };

  const broadcastDisabledTools = (settings, resolved) => {
    const list = Array.isArray(resolved) ? resolved : disabledToolsForCurrentSurface(settings || {});
    let detail=list;
    if (settings) {
      const surfaces=normalizeToolSurfaces(settings.deactivated_tool_surfaces);
      const legacy=Array.isArray(settings.deactivated_tools)?settings.deactivated_tools:[];
      detail={deactivated_tools:legacy,deactivated_tool_surfaces:surfaces};
      try{
        localStorage.setItem('ve_deactivated_tool_surfaces',JSON.stringify(surfaces));
        localStorage.setItem('ve_deactivated_tools',JSON.stringify(legacy));
      }catch(e){}
    }
    try {
      const event = new CustomEvent('ve-deactivated-tools-changed', { detail });
      window.dispatchEvent(event);
      if (window.top && window.top !== window) window.top.dispatchEvent(new CustomEvent('ve-deactivated-tools-changed', { detail }));
    } catch (e) {}
    return list;
  };
  const deactivatedToolsRef = useRef(deactivatedTools);
  useEffect(() => { deactivatedToolsRef.current = deactivatedTools; }, [deactivatedTools]);
  useEffect(() => {
    const inspect=()=>({
      surface:MODE==='builder'?'builder':'admin',
      runtime_revision:moduleRuntimeRevisionRef.current,
      disabled:[...deactivatedToolsRef.current],
      stored_legacy:readStoredJson('ve_deactivated_tools',[]),
      stored_surfaces:normalizeToolSurfaces(readStoredJson('ve_deactivated_tool_surfaces',{}))
    });
    window.mimamVarInspectModuleState=inspect;
    try{if(window.top&&window.top!==window)window.top.mimamVarInspectModuleState=inspect;}catch(e){}
    return()=>{
      try{if(window.mimamVarInspectModuleState===inspect)delete window.mimamVarInspectModuleState;}catch(e){}
      try{if(window.top&&window.top!==window&&window.top.mimamVarInspectModuleState===inspect)delete window.top.mimamVarInspectModuleState;}catch(e){}
    };
  },[]);
  const isToolDisabledNow = useCallback(id => {
    const key=toolModuleId(id);
    return deactivatedTools.includes(key) || deactivatedTools.includes(id);
  }, [deactivatedTools]);
  const openModuleIfEnabled = useCallback((id, opener) => {
    if (isToolDisabledNow(id)) {
      flash(toolLabel(id) + ' is disabled for this surface in Settings → Modules.');
      return false;
    }
    opener && opener();
    return true;
  }, [flash, isToolDisabledNow]);
  const closeDisabledModulesNow = useCallback(() => {
    if (isToolDisabledNow('variables') && open) sO(false);
    if (isToolDisabledNow('help') && helpOpen) sHelpOpen(false);
    if (isToolDisabledNow('css_studio') && cssStudioOpen) sCssStudioOpen(false);
    if (isToolDisabledNow('css_recipes') && cssRecipesOpen) sCssRecipesOpen(false);
    if (isToolDisabledNow('content_studio') && contentStudioOpen) sContentStudioOpen(false);
    if (isToolDisabledNow('media_studio')) {
      if (mediaStudioOpen) sMediaStudioOpen(false);
      if (mediaTargetRef.current) mediaTargetRef.current = null;
      if (pendingMediaFrameRef.current) pendingMediaFrameRef.current = null;
    }
    if (isToolDisabledNow('font_manager') && fontManagerOpen) sFontManagerOpen(false);
    if (isToolDisabledNow('plugin_studio') && pluginStudioOpen) sPluginStudioOpen(false);
    if (isToolDisabledNow('bricks_settings') && bricksSettingsOpen) sBricksSettingsOpen(false);
    if (isToolDisabledNow('theme_styles') && themeStylesOpen) sThemeStylesOpen(false);
    if(isToolDisabledNow('recovery')&&recoveryOpen){
      sRecoveryOpen(false);
      window.dispatchEvent(new CustomEvent('ve-recovery-toggle',{detail:{open:false,source:'module-state'}}));
    }
    if(activeStudioTool&&isToolDisabledNow(activeStudioTool))sActiveStudioTool('');
    if(studioLaunchContext?.toolId&&isToolDisabledNow(studioLaunchContext.toolId))sStudioLaunchContext(null);
  }, [open, helpOpen, cssStudioOpen, cssRecipesOpen, contentStudioOpen, mediaStudioOpen, fontManagerOpen, pluginStudioOpen, bricksSettingsOpen, themeStylesOpen, recoveryOpen, activeStudioTool, studioLaunchContext, isToolDisabledNow]);
  const [mediaReplaceLibrary, setMediaReplaceLibrary] = useState(false);
  const [mediaAutoSyncExternalFolders, setMediaAutoSyncExternalFolders] = useState(() => localStorage.getItem('ve_media_auto_sync_external_folders') === '1');
  // Backdrop behind studio panels (#18): global intensity + per-module opt-out.
  // The Settings tab (separate component) writes these and fires ve-backdrop-changed.
  const readBackdropIntensity = () => { const v = localStorage.getItem('ve_backdrop_intensity'); return ['blur', 'soft', 'dim', 'none'].indexOf(v) !== -1 ? v : 'blur'; };
  const readBackdropOff = () => { try { const a = JSON.parse(localStorage.getItem('ve_backdrop_off') || '["variables","settings"]'); return Array.isArray(a) ? a : ['variables', 'settings']; } catch (e) { return ['variables', 'settings']; } };
  const [backdropIntensity, setBackdropIntensity] = useState(readBackdropIntensity);
  const [backdropOff, setBackdropOff] = useState(readBackdropOff);
  useEffect(() => {
    const sync = () => { setBackdropIntensity(readBackdropIntensity()); setBackdropOff(readBackdropOff()); };
    window.addEventListener('ve-backdrop-changed', sync);
    return () => window.removeEventListener('ve-backdrop-changed', sync);
  }, []);
  const backdropFor = moduleId => (backdropIntensity === 'none' || backdropOff.indexOf(moduleId) !== -1) ? 'none' : backdropIntensity;
  const isNativeMediaLibraryPage = MODE === 'admin' && /\/wp-admin\/upload\.php$/i.test(window.location.pathname || '');
  const nativeMediaPageActive = NATIVE_MEDIA_REPLACEMENT_ENABLED && isNativeMediaLibraryPage && mediaReplaceLibrary && !isToolDisabledNow('media_studio');
  const mediaStudioStandaloneOpen = mediaStudioOpen && !nativeMediaPageActive && !isToolDisabledNow('media_studio');
  const closeNativeMediaReplacement = useCallback(() => {
    setMediaReplaceLibrary(false);
    persistUserPreference('ve_media_replace_wp_library', '0');
    try { document.body.classList.remove('ve-native-media-page-active'); } catch(e) {}
    api.g('settings').then(curr => api.p('settings', { ...(curr || {}), media_replace_wp_library: false })).catch(() => {});
    try { window.dispatchEvent(new CustomEvent('ve-media-replace-library-changed', { detail: false })); } catch(e) {}
    // On the native upload.php screen, reloading is safer than leaving WordPress'
    // original Media Library in a hidden/blank intermediate state after replacement.
    if (isNativeMediaLibraryPage) {
      setTimeout(() => { try { window.location.reload(); } catch(e) {} }, 80);
    }
  }, [isNativeMediaLibraryPage]);

  useEffect(() => {
    closeDisabledModulesNow();
  }, [deactivatedTools, closeDisabledModulesNow]);
  useEffect(() => {
    if (nativeMediaPageActive && mediaStudioOpen) {
      sMediaStudioOpen(false);
    }
  }, [nativeMediaPageActive, mediaStudioOpen]);

  useEffect(() => {
    const changed = e => setFabOrder(normalizeFabOrder(e?.detail));
    window.addEventListener('ve-fab-order-changed', changed);
    return () => window.removeEventListener('ve-fab-order-changed', changed);
  }, []);

  useEffect(() => {
    const openMedia = e => {
      if(cssStudioOpen&&cssStudioDirty){sStudioLeaveRequest({target:'media_studio'});return;}
      openModuleIfEnabled('media_studio', () => {
        sStudioLaunchContext(null);
        sActiveStudioTool('media_studio');
        setMediaStudioInitialFilter(e?.detail?.filter || '');
        sMediaStudioOpen(true);
      });
    };
    window.addEventListener('ve-open-media-studio', openMedia);
    return () => window.removeEventListener('ve-open-media-studio', openMedia);
  }, [openModuleIfEnabled,cssStudioOpen,cssStudioDirty]);
  useEffect(()=>{const fn=e=>flash(String(e.detail||''));window.addEventListener('ve-toast-request',fn);return()=>window.removeEventListener('ve-toast-request',fn);},[]);
  useEffect(()=>{
    const installed=event=>{
      const detail=event?.detail||{};
      sUpdateInfo(previous=>previous?{...previous,update_available:false,current_version:detail.version||previous.latest_version}:previous);
    };
    window.addEventListener('ve-update-installed',installed);
    return()=>window.removeEventListener('ve-update-installed',installed);
  },[]);

  useEffect(() => {
    // The wp.media hooking below is builder-only, but MV's own panels (Font Manager and
    // friends) need the Media Studio picker in wp-admin too — this effect used to return
    // before defining it, so veOpenMediaPicker only existed inside Bricks.
    // Hook wp.media in the builder, and across wp-admin whenever Media Studio is enabled,
    // so image pickers (Site Icon, featured image, ACF fields…) route to Media Studio.
    // The wrapper falls back to native wp.media when Media Studio can't handle a request.
    const bridgeWpMedia = MODE === 'builder' || (MODE === 'admin' && !isToolDisabledNow('media_studio'));
    const listeners=[];
    const wrappers=[];
    const normalizeAttachment=item=>{
      const url=item?.source_url||item?.url||'';
      const mime=item?.mime_type||item?.mime||'image/jpeg';
      const filename=decodeURIComponent(String(url).split('/').pop()||item?.slug||'media');
      const sizes={};
      const rawSizes=item?.media_details?.sizes||{};
      Object.keys(rawSizes).forEach(key=>{
        const size=rawSizes[key]||{};
        sizes[key]={...size,url:size.source_url||size.url||url};
      });
      if(!sizes.full)sizes.full={url,width:item?.media_details?.width||0,height:item?.media_details?.height||0};
      return {
        id:Number(item?.id||0),url,filename,mime,
        type:String(mime).split('/')[0]||'image',
        subtype:String(mime).split('/')[1]||'',
        title:item?.title?.rendered||item?.title||filename,
        caption:item?.caption?.rendered||item?.caption||'',
        description:item?.description?.rendered||item?.description||'',
        alt:item?.alt_text||item?.alt||'',
        sizes
      };
    };
    const createFrame=(runtime,options,intent)=>{
      const callbacks={};
      let selected=[];
      let contextGuard=null;
      const releaseContextGuard=()=>{
        if(contextGuard?.parentNode)contextGuard.parentNode.removeChild(contextGuard);
        contextGuard=null;
      };
      const installContextGuard=()=>{
        releaseContextGuard();
        contextGuard=document.createElement('div');
        contextGuard.className='media-modal ve-media-context-guard';
        contextGuard.hidden=true;
        contextGuard.setAttribute('aria-hidden','true');
        document.body.appendChild(contextGuard);
      };
      const collection={
        toJSON:()=>selected.slice(),
        first:()=>selected.length?{toJSON:()=>selected[0]}:null,
        add:attachment=>{try{selected.push(attachment?.toJSON?attachment.toJSON():attachment);}catch(e){}},
        reset:()=>{selected=[];}
      };
      const emit=event=>(callbacks[event]||[]).slice().forEach(callback=>{try{callback.call(frame, frame);}catch(e){}});
      const frame={
        options:options||{},
        on(events,callback){String(events||'').split(/\s+/).filter(Boolean).forEach(event=>{(callbacks[event]||(callbacks[event]=[])).push(callback);});return frame;},
        off(events,callback){String(events||'').split(/\s+/).filter(Boolean).forEach(event=>{if(!callbacks[event])return;callbacks[event]=callback?callbacks[event].filter(cb=>cb!==callback):[];});return frame;},
        open(){
          if(isToolDisabledNow('media_studio')){
            flash('Media Studio is disabled for this surface in Settings → Modules.');
            return frame;
          }
          const frameFilter = inferMediaFilterFromFrameOptions(options);
          mediaTargetRef.current=intent?.scope||intent?.target||null;
          // Bricks' transient component-property editor treats the native
          // `.media-modal` marker as an active picker context. Install the same
          // non-visual marker before Preact opens Media Studio so its direct
          // image-property flow is not dismissed as an outside interaction.
          installContextGuard();
          setMediaStudioInitialFilter(intent?.filter || frameFilter || inferMediaFilterFromScope(intent?.scope||intent?.target) || 'image');
          pendingMediaFrameRef.current=frame;
          sStudioLaunchContext({toolId:'media_studio',sourceId:'',sourceElement:intent?.target||null});
          sActiveStudioTool('media_studio');
          sMediaStudioOpen(true);
          emit('open');
          return frame;
        },
        close(){emit('close');releaseContextGuard();return frame;},
        state:()=>({get:key=>key==='selection'?collection:null}),
        content:{get:()=>null},
        __select(item){
          const attachment=normalizeAttachment(item);
          if(!attachment.url)return false;
          selected=[attachment];
          emit('select');
          releaseContextGuard();
          return true;
        },
        __releaseContextGuard:releaseContextGuard
      };
      return frame;
    };
    // Open Media Studio as a picker from MV's own UI. The wp.media bridge below only
    // engages when a recent Bricks control intent exists, so panels such as Font Manager
    // need a direct entry point or they fall through to the WordPress library.
    window.veOpenMediaPicker=(options,filter)=>createFrame(window,options||{},{
      target:document.body,
      filter:filter||'all'
    });

    const install=runtime=>{
      try{
        if(!runtime||runtime.__veWpHooked)return;
        runtime.__veWpHooked=true;
        const wrapMedia=media=>{
          if(typeof media!=='function'||media.__veMediaStudioBridge)return media;
          const original=media;
          const wrapped=function(...args){
            const intent=mediaIntentRef.current;
            if(intent&&Date.now()-intent.at<1800){
              mediaIntentRef.current=null;
              if(isToolDisabledNow('media_studio'))return original.apply(this,args);
              // Setting: let Media Studio act as the Bricks media picker (default on).
              // When off, fall through to Bricks' native WordPress media frame.
              let mvPicker=true; try{mvPicker=localStorage.getItem('ve_media_as_bricks_picker')!=='0';}catch(e){}
              if(!mvPicker)return original.apply(this,args);
              return createFrame(runtime,args[0],intent);
            }
            return original.apply(this,args);
          };
          Object.getOwnPropertyNames(original).forEach(key=>{
            try{if(!['length','name','prototype'].includes(key))Object.defineProperty(wrapped,key,Object.getOwnPropertyDescriptor(original,key));}catch(e){}
          });
          wrapped.__veMediaStudioBridge=true;
          wrapped.__veOriginal=original;
          return wrapped;
        };
        let currentWp=runtime.wp;
        let originalWpDesc=Object.getOwnPropertyDescriptor(runtime,'wp');
        let originalMediaDesc=null;
        let wpObjForCleanup=null;
        const hookMediaOnWp=wpObj=>{
          if(!wpObj||wpObj.__veMediaHooked)return;
          wpObj.__veMediaHooked=true;
          wpObjForCleanup=wpObj;
          let currentMedia=wpObj.media;
          originalMediaDesc=Object.getOwnPropertyDescriptor(wpObj,'media');
          if(currentMedia){currentMedia=wrapMedia(currentMedia);}
          try{
            Object.defineProperty(wpObj,'media',{
              get(){return currentMedia;},
              set(newMedia){currentMedia=wrapMedia(newMedia);},
              configurable:true,
              enumerable:true
            });
          }catch(e){
            wpObj.media=wrapMedia(currentMedia);
          }
        };
        if(currentWp){hookMediaOnWp(currentWp);}
        try{
          Object.defineProperty(runtime,'wp',{
            get(){return currentWp;},
            set(newWp){
              currentWp=newWp;
              if(newWp){hookMediaOnWp(newWp);}
            },
            configurable:true,
            enumerable:true
          });
        }catch(e){
          if(runtime.wp){hookMediaOnWp(runtime.wp);}
        }
        wrappers.push({
          runtime,
          restore:()=>{
            try{
              delete runtime.__veWpHooked;
              if(originalWpDesc){Object.defineProperty(runtime,'wp',originalWpDesc);}
              else{delete runtime.wp;runtime.wp=currentWp;}
            }catch(e){try{runtime.wp=currentWp;}catch(_){}}
            try{
              if(wpObjForCleanup){
                delete wpObjForCleanup.__veMediaHooked;
                if(originalMediaDesc){Object.defineProperty(wpObjForCleanup,'media',originalMediaDesc);}
                else{
                  const orig=wpObjForCleanup.media?.__veOriginal;
                  delete wpObjForCleanup.media;
                  wpObjForCleanup.media=orig||wpObjForCleanup.media;
                }
              }
            }catch(e){}
          }
        });
      }catch(e){}
    };
    const track=e=>{
      const target=e.target;
      if(!target||!target.closest||isToolDisabledNow('media_studio')||target.closest('#ve-panel-root,.media-modal,.media-frame'))return;
      const scope=findMediaWriteScope(target);
      mediaIntentRef.current={at:Date.now(),target,scope,filter:inferMediaFilterFromScope(scope||target)};
    };
    const installAll=()=>{
      builderRuntimeWindows().forEach(runtime=>{
        install(runtime);
        try{
          const doc=runtime.document;
          if(listeners.some(entry=>entry.doc===doc))return;
          doc.addEventListener('pointerdown',track,true);
          listeners.push({doc});
        }catch(e){}
      });
    };
    if (!bridgeWpMedia) {
      // wp-admin: no wp.media hooking, but veOpenMediaPicker above stays available.
      return () => { try { delete window.veOpenMediaPicker; } catch (e) {} };
    }
    installAll();
    const retry=setInterval(installAll,300);
    return () => {
      clearInterval(retry);
      listeners.forEach(({doc})=>{try{doc.removeEventListener('pointerdown',track,true);}catch(e){}});
      wrappers.forEach(w=>{try{w.restore();}catch(e){}});
      try { delete window.veOpenMediaPicker; } catch (e) {}
    };
  }, [deactivatedTools]);

  // Mutual exclusion: by default, one major MV panel is open at a time.
  // Hold every panel still and cross-fade while switching tools. Panels stay mounted,
  // so without this one slides out while the next slides in - two shells travelling,
  // which is the jump. The class is removed once the swap window has passed.
  const swapTimerRef=useRef(0);
  // Flagged on <body>, not #ve-panel-root: module surfaces rendered outside the
  // Preact root (the Recovery panel) must cross-fade too, and body is an ancestor
  // of both.
  const beginPanelSwap=useCallback(()=>{
    const host=document.body;
    if(!host)return;
    host.classList.add('ve-swapping');
    clearTimeout(swapTimerRef.current);
    swapTimerRef.current=setTimeout(()=>host.classList.remove('ve-swapping'),260);
  },[]);

  const closePanelsExcept=useCallback(activeId=>{
    // Clear the hover tooltip before unmounting panels. It is rendered from global
    // mouseover handlers and may be anchored to a node inside a panel about to be
    // removed; Preact then diffs against a detached node and throws
    // "DOMException: insertBefore", which aborted the entire click - so the rail
    // appeared to do nothing and switching looked frozen.
    sMvTip(null);
    mvTipTargetRef.current=null;
    if(activeId!=='variables')sO(false);
    if(activeId!=='settings')sSettingsOpen(false);
    if(activeId!=='help')sHelpOpen(false);
    if(activeId!=='css_studio')sCssStudioOpen(false);
    if(activeId!=='content_studio')sContentStudioOpen(false);
    if(activeId!=='media_studio')sMediaStudioOpen(false);
    if(activeId!=='font_manager')sFontManagerOpen(false);
    if(activeId!=='plugin_studio')sPluginStudioOpen(false);
    if(activeId!=='bricks_settings')sBricksSettingsOpen(false);
    if(activeId!=='theme_styles')sThemeStylesOpen(false);
    if(activeId!=='help')sHelpOpen(false);
    if(activeId!=='recovery'){
      sRecoveryOpen(false);
      setRecoveryRuntimeOpen(false,'studio-owner');
    }
    if(activeId!=='css_recipes')sCssRecipesOpen(false);
  },[]);
  useExclusivePanel(open,'variables',allowMultiPanels,closePanelsExcept);
  useExclusivePanel(settingsOpen,'settings',allowMultiPanels,closePanelsExcept);
  useExclusivePanel(helpOpen,'help',allowMultiPanels,closePanelsExcept);
  useExclusivePanel(cssStudioOpen,'css_studio',allowMultiPanels,closePanelsExcept);
  useExclusivePanel(contentStudioOpen,'content_studio',allowMultiPanels,closePanelsExcept);
  useExclusivePanel(mediaStudioOpen,'media_studio',allowMultiPanels,closePanelsExcept);
  useExclusivePanel(fontManagerOpen,'font_manager',allowMultiPanels,closePanelsExcept);
  useExclusivePanel(pluginStudioOpen,'plugin_studio',allowMultiPanels,closePanelsExcept);
  useExclusivePanel(bricksSettingsOpen,'bricks_settings',allowMultiPanels,closePanelsExcept);
  useExclusivePanel(themeStylesOpen,'theme_styles',allowMultiPanels,closePanelsExcept);
  useExclusivePanel(recoveryOpen,'recovery',allowMultiPanels,closePanelsExcept);
  useExclusivePanel(cssRecipesOpen,'css_recipes',allowMultiPanels,closePanelsExcept);

  useEffect(()=>{
    const syncRecoveryState=event=>{
      const isOpen=!!event?.detail?.open;
      sRecoveryOpen(isOpen);
      if(isOpen){
        if(!allowMultiPanels)closePanelsExcept('recovery');
        sStudioLaunchContext(null);
        sActiveStudioTool('recovery');
      }else{
        sActiveStudioTool(current=>current==='recovery'?'':current);
      }
    };
    window.addEventListener('ve-recovery-state',syncRecoveryState);
    const recoveryPanel=document.querySelector('[data-panel="recovery"]');
    if(recoveryPanel?.classList.contains('rb-open'))syncRecoveryState({detail:{open:true}});
    return()=>window.removeEventListener('ve-recovery-state',syncRecoveryState);
  },[allowMultiPanels,closePanelsExcept]);

  const sRef=useRef();
  const panelRef=useRef();
  const fabRef=useRef();
  const mediaTargetRef=useRef(null);
  const mediaIntentRef=useRef(null);
  const pendingMediaFrameRef=useRef(null);

  const openStudioToolIds=useMemo(()=>[
    open&&'variables',
    helpOpen&&'help',
    settingsOpen&&'settings',
    cssStudioOpen&&'css_studio',
    cssRecipesOpen&&'css_recipes',
    contentStudioOpen&&'content_studio',
    mediaStudioStandaloneOpen&&'media_studio',
    fontManagerOpen&&'font_manager',
    pluginStudioOpen&&'plugin_studio',
    bricksSettingsOpen&&'bricks_settings',
    themeStylesOpen&&'theme_styles',
    recoveryOpen&&'recovery'
  ].filter(Boolean),[open,helpOpen,settingsOpen,cssStudioOpen,cssRecipesOpen,contentStudioOpen,mediaStudioStandaloneOpen,fontManagerOpen,pluginStudioOpen,bricksSettingsOpen,themeStylesOpen,recoveryOpen]);
  const resolvedActiveStudioTool=openStudioToolIds.includes(activeStudioTool)
    ?activeStudioTool
    :(openStudioToolIds[openStudioToolIds.length-1]||'');
  const studioRailActiveTool=studioLaunchContext?.toolId===resolvedActiveStudioTool?'':resolvedActiveStudioTool;
  const focusStudioPanel=id=>setTimeout(()=>{
    const panel=document.querySelector('[data-panel="'+id+'"]');
    if(panel&&panel.focus)panel.focus({preventScroll:true});
  },30);
  const setStudioToolOpen=(id,value)=>{
    if(id==='variables')sO(value);
    else if(id==='help')sHelpOpen(value);
    else if(id==='settings')sSettingsOpen(value);
    else if(id==='css_studio')sCssStudioOpen(value);
    else if(id==='css_recipes')sCssRecipesOpen(value);
    else if(id==='content_studio')sContentStudioOpen(value);
    else if(id==='media_studio')sMediaStudioOpen(value);
    else if(id==='font_manager')sFontManagerOpen(value);
    else if(id==='plugin_studio')sPluginStudioOpen(value);
    else if(id==='bricks_settings')sBricksSettingsOpen(value);
    else if(id==='theme_styles')sThemeStylesOpen(value);
    // Recovery owns PHP-rendered markup, but its open state is mirrored here so it
    // participates in the same rail and single-panel ownership as Preact Studios.
    else if(id==='recovery'){
      const changed=setRecoveryRuntimeOpen(!!value,'studio-owner');
      sRecoveryOpen(changed?!!value:false);
      if(!changed&&value)flash('Recovery could not open. Try disabling and enabling it again.');
    }
  };
  const openStudioToolDirect=(id,skipGuard=false)=>{
    const tool=TOOL_BY_ID[id];
    if(!tool)return false;
    if(!skipGuard&&id!==resolvedActiveStudioTool&&resolvedActiveStudioTool==='css_studio'&&cssStudioOpen&&cssStudioDirty){
      sStudioLeaveRequest({target:id});
      return false;
    }
    return openModuleIfEnabled(id,()=>{
      if(id==='recovery'&&!document.querySelector('[data-panel="recovery"]')){
        if(recoveryRuntimePromise){
          recoveryRuntimePromise.then(()=>openStudioToolDirect('recovery',skipGuard)).catch(()=>{});
          return true;
        }
        flash('Recovery is still loading. Try again in a moment.');
        return false;
      }
      // Moving between tools (something is already open) should cross-fade in place;
      // opening from nothing keeps the normal travel-in.
      if(!allowMultiPanels&&resolvedActiveStudioTool&&id!==resolvedActiveStudioTool)beginPanelSwap();
      // Single-panel switching must close and open in one batched state change.
      // Deferring closure to effects can briefly overlap panels and lets stale
      // exclusivity effects close the newly selected Studio.
      if(!allowMultiPanels)closePanelsExcept(id);
      sStudioLaunchContext(null);
      sActiveStudioTool(id);
      setStudioToolOpen(id,true);
      focusStudioPanel(id);
    });
  };
  const restoreStudioSource=context=>{
    if(!context)return;
    if(context.sourceId&&TOOL_BY_ID[context.sourceId]){
      sActiveStudioTool(context.sourceId);
      setStudioToolOpen(context.sourceId,true);
    }
    setTimeout(()=>{
      const source=context.sourceElement;
      if(source&&source.isConnected&&source.focus)source.focus({preventScroll:true});
      else if(context.sourceId)focusStudioPanel(context.sourceId);
    },70);
  };
  const closeStudioTool=(id,restoreContext=true)=>{
    const context=studioLaunchContext?.toolId===id?studioLaunchContext:null;
    if(id==='media_studio'){
      const pendingFrame=pendingMediaFrameRef.current;
      if(pendingFrame&&typeof pendingFrame.close==='function')pendingFrame.close();
      else if(pendingFrame&&typeof pendingFrame.__releaseContextGuard==='function')pendingFrame.__releaseContextGuard();
      pendingMediaFrameRef.current=null;
      mediaTargetRef.current=null;
    }
    setStudioToolOpen(id,false);
    if(activeStudioTool===id)sActiveStudioTool('');
    if(context){
      sStudioLaunchContext(null);
      if(restoreContext)restoreStudioSource(context);
    }
  };
  const requestStudioTool=id=>{
    if(!id)return;
    if(id===resolvedActiveStudioTool){focusStudioPanel(id);return;}
    if(resolvedActiveStudioTool==='css_studio'&&cssStudioOpen&&cssStudioDirty){
      sStudioLeaveRequest({target:id});
      return;
    }
    openStudioToolDirect(id);
  };
  const requestStudioClose=id=>{
    if(id==='css_studio'&&cssStudioDirty){sStudioLeaveRequest({target:''});return;}
    closeStudioTool(id,true);
  };
  const confirmStudioLeave=()=>{
    const request=studioLeaveRequest;
    sStudioLeaveRequest(null);
    sCssStudioDirty(false);
    sCssStudioResetToken(value=>value+1);
    closeStudioTool('css_studio',!request?.target);
    if(request?.target)setTimeout(()=>openStudioToolDirect(request.target,true),40);
  };

  const findMediaWriteScope = target => {
    if (!target || !target.closest) return null;
    return target.closest('.bricks-control-image, .bricks-control-media, .bricks-control-background, .brx-control, .bricks-control, .control, .control-inner, [data-control], [data-control-key], [data-setting]') || target;
  };

  const inferMediaFilterFromFrameOptions = options => {
    const library = options && options.library;
    const type = Array.isArray(library?.type) ? library.type.join(' ') : (library?.type || options?.type || '');
    const text = String(type || '').toLowerCase();
    if (/svg/.test(text)) return 'svg';
    if (/video/.test(text)) return 'video';
    if (/audio/.test(text)) return 'audio';
    if (/font|woff|ttf|otf/.test(text)) return 'font';
    if (/application|pdf|document/.test(text)) return 'application';
    if (/image/.test(text)) return 'image';
    return '';
  };

  const inferMediaFilterFromScope = scope => {
    if (!scope) return '';
    const text = [
      scope.getAttribute && scope.getAttribute('data-control'),
      scope.getAttribute && scope.getAttribute('data-control-key'),
      scope.getAttribute && scope.getAttribute('data-setting'),
      scope.getAttribute && scope.getAttribute('aria-label'),
      scope.className,
      scope.textContent
    ].map(x => String(x || '').toLowerCase()).join(' ');
    if (/svg|icon|vector/.test(text)) return 'svg';
    if (/video|mp4|webm/.test(text)) return 'video';
    if (/audio|mp3|wav/.test(text)) return 'audio';
    if (/image|img|picture|photo|logo|media|background|bg/.test(text)) return 'image';
    return '';
  };

  const setNativeValue = (el, value) => {
    if (!el) return false;
    try {
      const proto = Object.getPrototypeOf(el);
      const desc = proto && Object.getOwnPropertyDescriptor(proto, 'value');
      if (desc && desc.set) desc.set.call(el, value);
      else el.value = value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      return true;
    } catch (e) {
      try {
        el.value = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (e2) {
        return false;
      }
    }
  };

  const insertMediaIntoRememberedControl = item => {
    const url = item?.source_url || '';
    if (!url) return false;
    const pendingFrame=pendingMediaFrameRef.current;
    if(pendingFrame?.__select&&pendingFrame.__select(item)){
      closeStudioTool('media_studio',true);
      return true;
    }
    const target = mediaTargetRef.current;
    const scope = findMediaWriteScope(target);
    let inserted = false;
    if (scope) {
      const writable = Array.from(scope.querySelectorAll('input:not([type="hidden"]), textarea, [contenteditable="true"]')).filter(el => {
        const t = ((el.getAttribute('type') || '') + ' ' + (el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('data-setting') || '') + ' ' + String(el.className || '')).toLowerCase();
        return !el.disabled && !el.readOnly && (el.tagName === 'TEXTAREA' || el.isContentEditable || /url|image|media|svg|background|source|custom/.test(t) || el.value);
      });
      const field = writable.find(el => /url|source|custom/i.test((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + String(el.className || ''))) || writable[0];
      if (field) {
        if (field.isContentEditable) {
          field.textContent = url;
          field.dispatchEvent(new Event('input', { bubbles: true }));
          field.dispatchEvent(new Event('change', { bubbles: true }));
          inserted = true;
        } else {
          inserted = setNativeValue(field, url);
        }
      }
      scope.querySelectorAll('img').forEach(img => {
        try { img.src = url; inserted = true; } catch (e) {}
      });
      scope.dispatchEvent(new CustomEvent('ve-media-selected', { bubbles: true, detail: { id: item.id, url, item } }));
    }
    if (inserted) {
      closeStudioTool('media_studio',true);
      return true;
    }
    navigator.clipboard?.writeText(url);
    flash('Copied media URL. Bricks did not expose a writable field here.');
    return false;
  };

  // Toggle FAB visibility and reset position when panels open/close
  useEffect(() => {
    const fab = fabRef.current;
    if (!fab) return;

    const hasOpenPanel = open || settingsOpen || helpOpen || cssStudioOpen || contentStudioOpen || mediaStudioStandaloneOpen || pluginStudioOpen || bricksSettingsOpen || themeStylesOpen || cssRecipesOpen;
    if (hasOpenPanel) {
      fab.classList.add('ve-fab-hidden');
    } else {
      fab.classList.remove('ve-fab-hidden');
      fab.style.left = '';
      fab.style.right = '';
      fab.classList.remove('ve-fab-left-side');
    }
  }, [open, settingsOpen, helpOpen, cssStudioOpen, contentStudioOpen, mediaStudioStandaloneOpen, pluginStudioOpen, cssRecipesOpen]);

  const dragRef=useRef(null);
  const snapRef=useRef('');

  const loadSeqRef=useRef(0);
  const cssSigRef=useRef(null);
  const load=useCallback(async()=>{
    const seq=++loadSeqRef.current;
    const stamp=Date.now();
    const [v,statsData,themesData,colorPalettes,variableCategories]=await Promise.all([
      api.g('variables?dedupe=true&_nc='+stamp).catch(()=>null),
      api.g('variables/stats?_nc='+stamp).catch(()=>null),
      api.g('themes?_nc='+stamp).catch(()=>null),
      api.g('color-palettes?_nc='+stamp).catch(()=>null),
      api.g('variable-categories?_nc='+stamp).catch(()=>null)
    ]);
    if(seq!==loadSeqRef.current)return null;
    if(Array.isArray(v)){
      // Reflect variable mutations (especially deletes) live: when the set actually changed,
      // re-fetch the generated CSS in the admin doc + Bricks canvas instead of waiting for a
      // manual page refresh. Signature-gated so the 30s/focus polling doesn't re-fetch needlessly.
      const sig=v.map(x=>x.id+':'+(x.name||'')+':'+(x.value==null?'':x.value)).join('|');
      if(cssSigRef.current!==null&&cssSigRef.current!==sig)refreshVariableStylesheets();
      cssSigRef.current=sig;
      sV(v);
      sSel(current=>current?(v.find(item=>item.id===current.id)||null):current);
    }
    if(statsData&&!statsData.code)sStats(statsData);
    if(themesData&&!themesData.code)sPalettesData(themesData);
    if(colorPalettes&&!colorPalettes.code)sColorPalettesData(colorPalettes);
    if(variableCategories&&!variableCategories.code)sVariableCategoriesData(variableCategories);
    return Array.isArray(v)?v:null;
  },[]);
  useEffect(()=>{load();},[]);
  useEffect(()=>{
    const startedAtModuleRevision=moduleRuntimeRevisionRef.current;
    api.g('settings').then(d=>{
      if(d) {
        if(d.vw_min)_veViewport={vw_min:+d.vw_min||320,vw_max:+d.vw_max||1440};
        if(typeof d.allow_multi_panels !== 'undefined') {
          sAllowMultiPanels(!!d.allow_multi_panels);
          persistUserPreference('ve_allow_multi_panels', d.allow_multi_panels ? '1' : '0');
        }
        if(typeof d.show_all_tab !== 'undefined') {
          sShowAllTab(!!d.show_all_tab);
        }
        if(typeof d.media_replace_wp_library !== 'undefined') {
          setMediaReplaceLibrary(false);
          persistUserPreference('ve_media_replace_wp_library', '0');
        }
        if(typeof d.media_auto_sync_external_folders !== 'undefined') {
          setMediaAutoSyncExternalFolders(!!d.media_auto_sync_external_folders);
          persistUserPreference('ve_media_auto_sync_external_folders', d.media_auto_sync_external_folders ? '1' : '0');
        }
        // This request starts during App mount. If a module toggle or a newer
        // settings event landed while it was pending, keep that newer rail state.
        if(startedAtModuleRevision===moduleRuntimeRevisionRef.current){
          const disabled=applyModuleStateImmediately(d);
          broadcastDisabledTools(d,disabled);
        }
      }
    }).catch(()=>{});
  },[]);
  useEffect(() => {
    const handleShowAllTabChanged = (e) => {
      if (typeof e.detail !== 'undefined') {
        sShowAllTab(!!e.detail);
      }
    };
    window.addEventListener('ve-show-all-tab-changed', handleShowAllTabChanged);
    return () => window.removeEventListener('ve-show-all-tab-changed', handleShowAllTabChanged);
  }, []);
  useEffect(() => {
    const sameList = (a, b) => Array.isArray(a) && Array.isArray(b) && a.length === b.length && a.every(x => b.includes(x));
    const apply = (fresh) => {
      // Even a no-op event is newer than an outstanding settings GET and must
      // invalidate that request before it can repaint the rail.
      moduleRuntimeRevisionRef.current+=1;
      // Skip no-op updates: re-setting an identical list still re-rendered the rail and
      // ran another close pass, which read as a flicker when toggling repeatedly.
      if (sameList(fresh, deactivatedToolsRef.current)) return;
      setDeactivatedTools(fresh);
      deactivatedToolsRef.current = fresh;
      requestAnimationFrame(closeDisabledModulesNow);
    };
    const handleChanged = (e) => {
      const detail=e?.detail;
      if(Array.isArray(detail)){apply(detail);return;}
      if(detail&&detail.deactivated_tool_surfaces){apply(disabledToolsForCurrentSurface(detail));return;}
      apply(readDisabledToolsForSurface());
    };
    // Only react to the two keys that actually describe module state. Previously ANY
    // localStorage write from another tab (view mode, theme, last-nav…) triggered a
    // full re-read plus closeDisabledModulesNow, closing panels out of nowhere.
    const handleStorage = (e) => {
      if (e && e.key && e.key !== 've_deactivated_tools' && e.key !== 've_deactivated_tool_surfaces') return;
      apply(readDisabledToolsForSurface());
    };
    window.addEventListener('ve-deactivated-tools-changed', handleChanged);
    window.addEventListener('storage', handleStorage);
    return () => {
      window.removeEventListener('ve-deactivated-tools-changed', handleChanged);
      window.removeEventListener('storage', handleStorage);
    };
  }, [closeDisabledModulesNow]);
  useEffect(()=>{if(!open)return;const t=setInterval(load,30000);const f=()=>{if(!document.hidden)load();};window.addEventListener('focus',f);document.addEventListener('visibilitychange',f);return()=>{clearInterval(t);window.removeEventListener('focus',f);document.removeEventListener('visibilitychange',f);};},[open,load]);
  useEffect(()=>{let alive=true;const check=()=>api.p('update/check',{}).then(r=>{if(alive&&r&&!r.code)sUpdateInfo(r);}).catch(()=>{});check();const t=setInterval(check,10*60*1000);return()=>{alive=false;clearInterval(t);};},[]);
  const skipUpdateVersion=useCallback(version=>{persistUserPreference('ve_skip_update_version',version);sSkipUpdate(version);},[]);
  useEffect(()=>{
    const sync=()=>syncMimamsBarUpdateNotice(updateInfo,skipUpdate,skipUpdateVersion);
    sync();
    const timers=[setTimeout(sync,250),setTimeout(sync,1000)];
    return()=>timers.forEach(clearTimeout);
  },[updateInfo,skipUpdate,skipUpdateVersion]);
  useEffect(()=>{const fn=e=>sAllowMultiPanels(!!e.detail);window.addEventListener('ve-panel-concurrency-changed',fn);return()=>window.removeEventListener('ve-panel-concurrency-changed',fn);},[]);
  useEffect(() => {
    let timer=null;
    const handleVarsUpdated = () => {
      if(timer)clearTimeout(timer);
      timer=setTimeout(load,80);
    };
    window.addEventListener('ve-variables-updated', handleVarsUpdated);
    window.addEventListener('ve:variables-updated', handleVarsUpdated);
    return () => {
      if(timer)clearTimeout(timer);
      window.removeEventListener('ve-variables-updated', handleVarsUpdated);
      window.removeEventListener('ve:variables-updated', handleVarsUpdated);
    };
  }, [load]);
  useEffect(() => {
    const applySettingsResponse=(d,startedAtModuleRevision)=>{
        if(d) {
          if(d.vw_min)_veViewport={vw_min:+d.vw_min||320,vw_max:+d.vw_max||1440};
          if(typeof d.allow_multi_panels !== 'undefined') sAllowMultiPanels(!!d.allow_multi_panels);
          if(typeof d.show_all_tab !== 'undefined') sShowAllTab(!!d.show_all_tab);
          if(typeof d.media_replace_wp_library !== 'undefined') {
            setMediaReplaceLibrary(!!d.media_replace_wp_library);
            persistUserPreference('ve_media_replace_wp_library', d.media_replace_wp_library ? '1' : '0');
          }
          if(typeof d.media_auto_sync_external_folders !== 'undefined') {
            setMediaAutoSyncExternalFolders(!!d.media_auto_sync_external_folders);
            persistUserPreference('ve_media_auto_sync_external_folders', d.media_auto_sync_external_folders ? '1' : '0');
          }
          if(typeof startedAtModuleRevision==='undefined'||startedAtModuleRevision===moduleRuntimeRevisionRef.current){
            const freshDisabled=applyModuleStateImmediately(d);
            broadcastDisabledTools(d,freshDisabled);
            requestAnimationFrame(closeDisabledModulesNow);
          }
        }
    };
    const handleSettingsUpdated = e => {
      const detail=e?.detail;
      // Successful settings mutations already carry the authoritative saved
      // payload. Consuming it directly avoids creating another response race.
      if(detail&&detail.deactivated_tool_surfaces){
        applySettingsResponse(detail);
        return;
      }
      const startedAtModuleRevision=moduleRuntimeRevisionRef.current;
      api.g('settings').then(d=>applySettingsResponse(d,startedAtModuleRevision)).catch(()=>{});
    };
    window.addEventListener('ve-settings-updated', handleSettingsUpdated);
    return () => window.removeEventListener('ve-settings-updated', handleSettingsUpdated);
  }, [closeDisabledModulesNow]);
  useEffect(()=>{if(autoGen){const v=vars.find(x=>x.id===autoGen.id||x.name===autoGen.name);if(v){sSub({type:'genScale',v});sAG(null);}};},[vars,autoGen]);
  
  // Shortcuts and custom toggle triggers
  const toggleVariablePanel = useCallback(() => {
    if (isToolDisabledNow('variables')) {
      flash(toolLabel('variables') + ' is disabled for this surface in Settings → Modules.');
      return;
    }
    if(!open&&resolvedActiveStudioTool==='css_studio'&&cssStudioOpen&&cssStudioDirty){
      sStudioLeaveRequest({target:'variables'});
      return;
    }
    sO(p=>{
      const next=!p;
      if(next){sStudioLaunchContext(null);sActiveStudioTool('variables');}
      return next;
    });
    setTimeout(()=>sRef.current?.focus(),80);
  }, [isToolDisabledNow, flash,open,resolvedActiveStudioTool,cssStudioOpen,cssStudioDirty]);
  useEffect(() => {
    window.veToggleVariables = toggleVariablePanel;
    window.veOpenSettings = () => openStudioToolDirect('settings');
    window.veCloseAllPanels = () => {
      sO(false); sSettingsOpen(false); sHelpOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sFontManagerOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false);
    };
    return () => {
      if (window.veToggleVariables === toggleVariablePanel) delete window.veToggleVariables;
      delete window.veOpenSettings;
      delete window.veCloseAllPanels;
    };
  }, [toggleVariablePanel,openStudioToolDirect]);
  useEffect(()=>{
    const openSiteVisibility=()=>{
      // Set the tab before opening so a first-time Settings mount starts on Site
      // Visibility; dispatch again after mount for an already-opened instance.
      try{sessionStorage.setItem(SETTINGS_PANEL_SESSION_KEY,'visibility');}catch(e){}
      openStudioToolDirect('settings');
      setTimeout(()=>{
        try{window.dispatchEvent(new CustomEvent('ve-settings-select-tab',{detail:'visibility'}));}catch(e){}
      },40);
    };
    window.addEventListener('ve-open-site-visibility',openSiteVisibility);
    return()=>window.removeEventListener('ve-open-site-visibility',openSiteVisibility);
  },[openStudioToolDirect]);
  useEffect(()=>{const fn=e=>{const active=document.activeElement;if(active&&(active.tagName==='INPUT'||active.tagName==='TEXTAREA'||active.isContentEditable||active.closest('input,textarea,select,[contenteditable="true"]')))return;if(e.altKey&&(e.key==='z'||e.key==='Z')){e.preventDefault();toggleVariablePanel();}};document.addEventListener('keydown',fn);return()=>document.removeEventListener('keydown',fn);},[toggleVariablePanel]);
  useEffect(()=>{window.addEventListener('ve-toggle-panel',toggleVariablePanel);return()=>window.removeEventListener('ve-toggle-panel',toggleVariablePanel);},[toggleVariablePanel]);
  
  // Standalone panel toggle events (for Alt+Q / Speed Dial / Global messaging delegation)
  useEffect(() => {
    const toggleSettings = () => settingsOpen ? requestStudioClose('settings') : openStudioToolDirect('settings');
    const toggleHelp = () => helpOpen ? requestStudioClose('help') : openStudioToolDirect('help');
    const toggleCss = () => cssStudioOpen ? requestStudioClose('css_studio') : openStudioToolDirect('css_studio');
    const toggleRecipes = () => cssRecipesOpen ? requestStudioClose('css_recipes') : openStudioToolDirect('css_recipes');
    const toggleContent = () => contentStudioOpen ? requestStudioClose('content_studio') : openStudioToolDirect('content_studio');
    const toggleMedia = () => mediaStudioOpen ? requestStudioClose('media_studio') : openStudioToolDirect('media_studio');
    const toggleFonts = () => fontManagerOpen ? requestStudioClose('font_manager') : openStudioToolDirect('font_manager');
    const togglePlugin = () => pluginStudioOpen ? requestStudioClose('plugin_studio') : openStudioToolDirect('plugin_studio');
    const requestMimamsBar = () => {
      window.dispatchEvent(new CustomEvent('ve-mimams-bar-toggle-request'));
    };
    const toggleMimamsBar = () => openModuleIfEnabled('mimams_bar', requestMimamsBar);
    window.addEventListener('ve-toggle-settings', toggleSettings);
    window.addEventListener('ve-toggle-help', toggleHelp);
    window.addEventListener('ve-toggle-css', toggleCss);
    window.addEventListener('ve-toggle-css-recipes', toggleRecipes);
    window.addEventListener('ve-toggle-content', toggleContent);
    window.addEventListener('ve-toggle-media', toggleMedia);
    window.addEventListener('ve-toggle-font-manager', toggleFonts);
    window.addEventListener('ve-toggle-plugin', togglePlugin);
    window.addEventListener('ve-toggle-plugin-studio', togglePlugin);
    window.addEventListener('ve-toggle-mimams-bar', toggleMimamsBar);
    return () => {
      window.removeEventListener('ve-toggle-settings', toggleSettings);
      window.removeEventListener('ve-toggle-help', toggleHelp);
      window.removeEventListener('ve-toggle-css', toggleCss);
      window.removeEventListener('ve-toggle-css-recipes', toggleRecipes);
      window.removeEventListener('ve-toggle-content', toggleContent);
      window.removeEventListener('ve-toggle-media', toggleMedia);
      window.removeEventListener('ve-toggle-font-manager', toggleFonts);
      window.removeEventListener('ve-toggle-plugin', togglePlugin);
      window.removeEventListener('ve-toggle-plugin-studio', togglePlugin);
      window.removeEventListener('ve-toggle-mimams-bar', toggleMimamsBar);
    };
  }, [openModuleIfEnabled,settingsOpen,helpOpen,cssStudioOpen,cssRecipesOpen,contentStudioOpen,mediaStudioOpen,fontManagerOpen,pluginStudioOpen,openStudioToolDirect,requestStudioClose]);
  useEffect(() => {
    const onReplace = e => {
      const value = !!e.detail;
      setMediaReplaceLibrary(value);
      persistUserPreference('ve_media_replace_wp_library', value ? '1' : '0');
      if (isNativeMediaLibraryPage) {
        setTimeout(() => { try { window.location.reload(); } catch(err) {} }, 100);
      }

    };
    const onAutoSync = e => {
      const value = !!e.detail;
      setMediaAutoSyncExternalFolders(value);
      persistUserPreference('ve_media_auto_sync_external_folders', value ? '1' : '0');
    };
    window.addEventListener('ve-media-replace-library-changed', onReplace);
    window.addEventListener('ve-media-auto-sync-external-folders-changed', onAutoSync);
    return () => {
      window.removeEventListener('ve-media-replace-library-changed', onReplace);
      window.removeEventListener('ve-media-auto-sync-external-folders-changed', onAutoSync);
    };
  }, []);
  useEffect(() => {
    if (MODE !== 'admin') return;
    document.body.classList.toggle('ve-native-media-page-active', !!nativeMediaPageActive);
    return () => document.body.classList.remove('ve-native-media-page-active');
  }, [nativeMediaPageActive]);
  useEffect(() => {
    if (MODE !== 'admin') return;
    if (!nativeMediaPageActive) return;
    const root = document.getElementById('ve-panel-root');
    const host = document.getElementById('wpbody-content');
    if (!root || !host) return;
    const originalParent = root.parentNode || document.body;
    const originalNext = root.nextSibling;
    if (root.parentNode !== host || root !== host.firstChild) {
      host.insertBefore(root, host.firstChild);
    }
    // Remember what wp-admin had before we overwrite it. Without this the
    // cleanup below put #ve-panel-root back but left #wpbody-content pinned at
    // padding-top:0 / margin-top:0, so the admin page it was borrowed from kept
    // MV's layout after MV had let go of it.
    const hostPadTop = host.style.paddingTop;
    const hostMarTop = host.style.marginTop;
    try { host.style.paddingTop = '0'; host.style.marginTop = '0'; window.scrollTo({ top: 0, left: 0, behavior: 'auto' }); } catch(e) {}
    const scrollTimer = setTimeout(() => { try { window.scrollTo(0, 0); } catch(e) {} }, 60);
    return () => {
      clearTimeout(scrollTimer);
      try { host.style.paddingTop = hostPadTop; host.style.marginTop = hostMarTop; } catch(e) {}
      if (!root || !root.parentNode) return;
      if (originalParent && originalParent.isConnected) {
        if (originalNext && originalNext.parentNode === originalParent) originalParent.insertBefore(root, originalNext);
        else originalParent.appendChild(root);
      } else {
        document.body.appendChild(root);
      }
    };
  }, [nativeMediaPageActive]);
  useEffect(() => {
    if ((!mediaStudioOpen && !nativeMediaPageActive) || !mediaAutoSyncExternalFolders || isToolDisabledNow('media_studio')) return;
    try { window.dispatchEvent(new CustomEvent('ve-media-sync-external-folders')); } catch(e) {}
  }, [mediaStudioOpen, nativeMediaPageActive, mediaAutoSyncExternalFolders, deactivatedTools]);

  // Global PointerDown outside click checks
  useEffect(() => {
    const handleOutsideClick = e => {
      const target = e.target;
      if (!target) return;

      // This runs in the CAPTURE phase, so it fires before anything the element itself
      // does — stopPropagation on the target cannot save these. Surfaces that legitimately
      // sit outside a panel (toasts, the WP media frame) must be excluded here or
      // interacting with them silently closes whatever studio is open.
      if (target.closest && target.closest('.ve-toast, .media-modal, .media-modal-backdrop, .media-frame, .ui-autocomplete')) {
        return;
      }

      if (target.closest('.ve-category-context')) {
        return;
      }
      if (categoryMenu) {
        sCategoryMenu(null);
      }

      if (target.closest('.CodeMirror-hints') || target.closest('.ve-suggest') || target.closest('.ve-ac') || target.closest('.ve-menu-list')) {
        return;
      }
      
      if (target.closest('.ve-fab-wrap') || target.closest('.ve-fab-menu') || target.closest('.ve-fab') || target.closest('.ve-studio-tool-rail') || target.closest('#wp-admin-bar-ve-toggle')) {
        return;
      }

      const clickedAnyPanel = target.closest('.ve-o') || target.closest('.ve-o.ve-sidecar') || target.closest('.ve-standalone-panel') || target.closest('.ve-studio-tool-rail');

      if (nativeMediaPageActive && !target.closest('.ve-native-media-page-shell') && !target.closest('.ve-modal') && !target.closest('.ve-menu-list') && !target.closest('.ve-fab-wrap') && !target.closest('#wpadminbar')) {
        closeNativeMediaReplacement();
        return;
      }

      if (!clickedAnyPanel) {
        if (open) {
          const panelEl = panelRef.current;
          if (panelEl && !panelEl.contains(target) && !target.closest('.ve-cf-b') && !target.closest('.ve-modal')) {
            sO(false);
          }
        }

        if (settingsOpen) {
          const settingsEl = document.querySelector('.ve-standalone-panel[data-panel="settings"]');
          if (settingsEl && !settingsEl.contains(target)) {
            requestStudioClose('settings');
          }
        }

        if (helpOpen) {
          const helpEl = document.querySelector('.ve-standalone-panel[data-panel="help"]');
          if (helpEl && !helpEl.contains(target)) {
            sHelpOpen(false);
          }
        }

        if (cssStudioOpen) {
          const cssEl = document.querySelector('.ve-standalone-panel[data-panel="css_studio"]');
          if (cssEl && !cssEl.contains(target) && !target.closest('.CodeMirror-dialog') && !target.closest('.ve-o.ve-sidecar') && !target.closest('.ve-modal')) {
            requestStudioClose('css_studio');
          }
        }

        if (contentStudioOpen) {
          const contentEl = document.querySelector('.ve-standalone-panel[data-panel="content_studio"]');
          if (contentEl && !contentEl.contains(target) && !target.closest('.ve-modal')) {
            requestStudioClose('content_studio');
          }
        }

        if (mediaStudioOpen) {
          const mediaEl = document.querySelector('.ve-standalone-panel[data-panel="media_studio"]');
          if (mediaEl && !mediaEl.contains(target) && !target.closest('.ve-modal')) {
            requestStudioClose('media_studio');
          }
        }

        if (fontManagerOpen) {
          const fontEl = document.querySelector('.ve-standalone-panel[data-panel="font_manager"]');
          if (fontEl && !fontEl.contains(target) && !target.closest('.ve-modal')) {
            requestStudioClose('font_manager');
          }
        }

        if (pluginStudioOpen) {
          const pluginEl = document.querySelector('.ve-standalone-panel[data-panel="plugin_studio"]');
          if (pluginEl && !pluginEl.contains(target) && !target.closest('.ve-modal')) {
            requestStudioClose('plugin_studio');
          }
        }

        if (cssRecipesOpen) {
          const recipesEl = document.querySelector('.ve-standalone-panel[data-panel="css_recipes"]');
          if (recipesEl && !recipesEl.contains(target) && !target.closest('.ve-modal')) {
            sCssRecipesOpen(false);
          }
        }
      }
    };

    document.addEventListener('pointerdown', handleOutsideClick, true);
    return () => {
      document.removeEventListener('pointerdown', handleOutsideClick, true);
    };
  }, [open, settingsOpen, helpOpen, cssStudioOpen, contentStudioOpen, mediaStudioOpen, fontManagerOpen, pluginStudioOpen, cssRecipesOpen, categoryMenu, nativeMediaPageActive, closeNativeMediaReplacement,requestStudioClose]);

  const genSort=useCallback((a,b)=>{
    if(String(a?.generator_type||'')==='imported'&&String(b?.generator_type||'')==='imported'){
      const tshirtRank=name=>{
        const match=String(name||'').toLowerCase().match(/(?:-|\.)(8xs|7xs|6xs|5xs|4xs|3xs|2xs|xs|s|m|l|xl|2xl|3xl|4xl|5xl|6xl|7xl|8xl)$/);
        if(!match)return null;
        return ['8xs','7xs','6xs','5xs','4xs','3xs','2xs','xs','s','m','l','xl','2xl','3xl','4xl','5xl','6xl','7xl','8xl'].indexOf(match[1]);
      };
      const ar=tshirtRank(a.name),br=tshirtRank(b.name);
      if(ar!==null&&br!==null&&ar!==br)return ar-br;
      // Color shade variants (…-l-1, …-d-2, …-t-3) group by type then step:
      // lights (l-1..8), then darks (d-1..8), then transparents (t-1..8) —
      // matching the source Color Manager, instead of interleaving by step
      // number (d-1, l-1, t-1, d-2, …).
      const shadeInfo=name=>{const m=String(name||'').toLowerCase().match(/(?:-|\.)([ldt])(?:-|\.)(\d+)$/);return m?{t:{l:0,d:1,t:2}[m[1]],n:Number(m[2])}:null;};
      const as=shadeInfo(a.name),bs=shadeInfo(b.name);
      if(as&&bs){if(as.t!==bs.t)return as.t-bs.t;if(as.n!==bs.n)return as.n-bs.n;}
      const an=String(a.name||'').match(/(?:-|\.)(\d+)$/),bn=String(b.name||'').match(/(?:-|\.)(\d+)$/);
      if(an&&bn&&Number(an[1])!==Number(bn[1]))return Number(an[1])-Number(bn[1]);
      if((ar!==null)!==(br!==null)){
        const av=pxV(a.value),bv=pxV(b.value);
        if(av!==bv)return av-bv;
      }
      return String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true,sensitivity:'base'});
    }
    const av=pxV(a.value), bv=pxV(b.value);
    if(av!==bv)return av-bv;
    return String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true,sensitivity:'base'});
  },[]);

  const{bases,childMap,namespaces}=useMemo(()=>{
    const cm={};const bs=[];
    vars.forEach(v=>{if(v.type==='generated'&&v.source_id){if(!cm[v.source_id])cm[v.source_id]=[];cm[v.source_id].push(v);}});
    Object.keys(cm).forEach(k=>cm[k].sort(genSort));
    vars.forEach(v=>{if(v.type!=='generated')bs.push(v);});
    bs.sort((a,b)=>{const ap=a.position!==undefined?a.position:0;const bp=b.position!==undefined?b.position:0;if(ap!==bp)return ap-bp;return String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true,sensitivity:'base'});});
    const list=['color',...(variableCategoriesData.categories||[]).map(category=>category.slug)];
    return{bases:bs,childMap:cm,namespaces:showAllTab?['all',...list]:list};
  },[vars,genSort,showAllTab,variableCategoriesData]);

  const allCats=useMemo(()=>variableCategoriesData.categories||[],[variableCategoriesData]);
  const categoryNames=useMemo(()=>{
    const map={all:'All',color:'Color'};
    allCats.forEach(category=>{map[category.slug]=category.name;});
    return map;
  },[allCats]);

  useEffect(() => {
    if (!showAllTab && nsTab === 'all') {
      const list = namespaces.filter(n => n !== 'all');
      if (list.length) sNT(list[0]);
    }
  }, [showAllTab, nsTab, namespaces]);
  useEffect(()=>{
    if(selectedColorPalette!=='all'&&!(colorPalettesData.palettes||[]).some(p=>String(p.id)===String(selectedColorPalette))){
      sSelectedColorPalette('all');
    }
  },[colorPalettesData,selectedColorPalette]);

  const maxSp=useMemo(()=>{let mx=0;vars.forEach(v=>{if(v.namespace==='space'){const n=pxV(v.value);if(n>mx)mx=n;}});return mx||1;},[vars]);
  const scopedBases=useMemo(()=>{
    let list=nsTab==='all'?bases:bases.filter(v=>variableNamespace(v)===nsTab);
    if(nsTab==='color'&&selectedColorPalette!=='all'){
      list=list.filter(v=>String(v.palette_id||0)===String(selectedColorPalette));
    }
    return list;
  },[bases,nsTab,selectedColorPalette]);
  const sourceCounts=useMemo(()=>{
    const counts={all:0,mv:0,file:0,figma:0,at:0,cf:0,acss:0};
    scopedBases.forEach(root=>{
      [root,...(childMap[root.id]||[])].forEach(variable=>{
        const key=normalizedVariableOrigin(variable);
        counts.all++;
        counts[key]=(counts[key]||0)+1;
      });
    });
    return counts;
  },[scopedBases,childMap]);
  const filteredChildMap=useMemo(()=>{
    if(sourceFilter==='all')return childMap;
    const map={};
    scopedBases.forEach(root=>{
      map[root.id]=(childMap[root.id]||[]).filter(child=>normalizedVariableOrigin(child)===sourceFilter);
    });
    return map;
  },[childMap,scopedBases,sourceFilter]);
  const filtered=useMemo(()=>{
    let list=scopedBases;
    if(sourceFilter!=='all'){
      list=list.filter(v=>normalizedVariableOrigin(v)===sourceFilter||(filteredChildMap[v.id]||[]).length>0);
    }
    if(sr){
      const q=sr.toLowerCase();
      const mp=new Set();
      vars.forEach(v=>{
        if(v.type==='generated'&&v.source_id&&(sourceFilter==='all'||normalizedVariableOrigin(v)===sourceFilter)&&fuzzy(q,v.nameLower||(v.nameLower=v.name.toLowerCase())).m)mp.add(String(v.source_id));
      });
      list=list.map(v=>({
        ...v,
        ...fuzzy(q,v.nameLower||(v.nameLower=v.name.toLowerCase())),
        cm:mp.has(String(v.id))
      })).filter(v=>v.m||v.cm).sort((a,b)=>(b.s||0)-(a.s||0));
    }
    return list;
  },[scopedBases,filteredChildMap,vars,sr,sourceFilter]);
  const[visibleVariableLimit,sVisibleVariableLimit]=useState(100);
  useEffect(()=>{sVisibleVariableLimit(100);},[nsTab,sr,selectedColorPalette,sourceFilter]);
  const visibleFiltered=useMemo(
    ()=>filtered.slice(0,visibleVariableLimit),
    [filtered,visibleVariableLimit]
  );
  const visibleSelectionIds=useMemo(()=>{
    const ids=[];
    visibleFiltered.forEach(variable=>{
      ids.push(Number(variable.id));
      const expKey=String(variable.id);
      const expanded=sr?true:(Object.prototype.hasOwnProperty.call(exp,expKey)?!!exp[expKey]:(sourceFilter!=='all'));
      if(expanded)(filteredChildMap[variable.id]||[]).forEach(child=>ids.push(Number(child.id)));
    });
    return ids;
  },[visibleFiltered,filteredChildMap,exp,sr]);
  const sourceSelectionIds=useMemo(()=>{
    const ids=[];
    filtered.forEach(root=>{
      if(sourceFilter==='all'||normalizedVariableOrigin(root)===sourceFilter)ids.push(Number(root.id));
      (filteredChildMap[root.id]||[]).forEach(child=>{
        if(sourceFilter==='all'||normalizedVariableOrigin(child)===sourceFilter)ids.push(Number(child.id));
      });
    });
    return [...new Set(ids)];
  },[filtered,filteredChildMap,sourceFilter]);
  const selectCurrentSource=()=>{
    if(!sourceSelectionIds.length)return;
    sCheckedVars(previous=>[...new Set([...previous.map(Number),...sourceSelectionIds])]);
  };
  const selectedVariables=useMemo(
    ()=>checkedVars.map(id=>vars.find(variable=>Number(variable.id)===Number(id))).filter(Boolean),
    [checkedVars,vars]
  );
  const visibleSelectionSet=useMemo(()=>new Set(visibleSelectionIds.map(Number)),[visibleSelectionIds]);
  const hiddenSelectedCount=useMemo(
    ()=>selectedVariables.filter(variable=>!visibleSelectionSet.has(Number(variable.id))).length,
    [selectedVariables,visibleSelectionSet]
  );
  const hiddenSelectionKey=useMemo(
    ()=>selectedVariables.filter(variable=>!visibleSelectionSet.has(Number(variable.id))).map(variable=>Number(variable.id)).sort((a,b)=>a-b).join(','),
    [selectedVariables,visibleSelectionSet]
  );
  useEffect(()=>{
    if(!vars.length)return;
    const validIds=new Set(vars.map(variable=>Number(variable.id)));
    sCheckedVars(previous=>{
      const next=previous.filter(id=>validIds.has(Number(id)));
      return next.length===previous.length?previous:next;
    });
  },[vars]);
  useEffect(()=>{
    if(!checkedVars.length)sSelectionReviewOpen(false);
  },[checkedVars.length]);
  useEffect(()=>{
    if(!hiddenSelectionKey){
      lastAutoOpenedHiddenSelectionRef.current='';
      return;
    }
    if(hiddenSelectionKey!==lastAutoOpenedHiddenSelectionRef.current){
      lastAutoOpenedHiddenSelectionRef.current=hiddenSelectionKey;
      sSelectionReviewOpen(true);
    }
  },[hiddenSelectionKey]);
  const cleanupIssues=useMemo(()=>stats?[(stats.stale_generated?stats.stale_generated+' stale generated':''),(stats.orphan_generated?stats.orphan_generated+' orphan generated':''),(stats.missing_dependencies?stats.missing_dependencies+' missing dependency links':''),(stats.orphan_dependencies?stats.orphan_dependencies+' orphan dependency rows':''),(stats.duplicate_count?stats.duplicate_count+' duplicate names':''),(stats.older_generators?stats.older_generators+' older generators':'')].filter(Boolean):[],[stats]);
  const manualIntegrityNotices=useMemo(()=>stats?[(stats.public_name_conflict_count?stats.public_name_conflict_count+' CSS name conflicts require manual rename':''),(stats.broken_aliases?stats.broken_aliases+' aliases have missing sources and require manual relinking':''),(stats.blocked_orphan_generated?stats.blocked_orphan_generated+' orphan generated variables still have dependents and require review':'')].filter(Boolean):[],[stats]);
  const hasAvailableUpdate=!!(updateInfo?.update_available&&updateInfo.latest_version!==skipUpdate);

  const setPanelMode=m=>{sPanelMode(m);persistUserPreference('ve_panel_mode',m);};
  const startPanelDrag=e=>{
    if(e.button!==0)return;
    const currentLeft=panelMode==='left'?0:(panelMode==='right'?Math.max(16,window.innerWidth-430):(panelPos.left||Math.max(16,window.innerWidth-430)));
    const currentTop=panelMode==='float'?(panelPos.top||16):16;
    const startLeft=Math.max(8,Math.min(window.innerWidth-120,currentLeft));
    const startTop=Math.max(8,Math.min(window.innerHeight-90,currentTop));
    dragRef.current={x:e.clientX,y:e.clientY,left:startLeft,top:startTop};
    sPanelMode('float');
    persistUserPreference('ve_panel_mode','float');
    sPanelPos({left:startLeft,top:startTop});
    const el=panelRef.current;
    if(el){el.classList.add('ve-dragging');el.style.left=startLeft+'px';el.style.top=startTop+'px';el.style.right='auto';}
    document.querySelector('#ve-panel-root .ve-hdr')?.classList.add('dragging');
    e.preventDefault();
  };
  useEffect(()=>{
    const move=e=>{
      const d=dragRef.current;if(!d)return;
      const el=panelRef.current;
      const w=el?el.offsetWidth:410;
      const hgt=el?el.offsetHeight:760;
      const maxLeft=Math.max(8,window.innerWidth-w-8);
      const maxTop=Math.max(8,window.innerHeight-hgt-8);
      const next={left:Math.max(8,Math.min(maxLeft,d.left+(e.clientX-d.x))),top:Math.max(8,Math.min(maxTop,d.top+(e.clientY-d.y)))};
      d.last=next;
      if(el){el.style.left=next.left+'px';el.style.top=next.top+'px';el.style.right='auto';}
      const cur=snapRef.current;
      let side='';
      if(cur==='left')side=next.left<190?'left':'';
      else if(cur==='right')side=next.left>maxLeft-190?'right':'';
      else side=next.left<72?'left':(next.left>maxLeft-72?'right':'');
      if(side!==snapRef.current){snapRef.current=side;sSnapSide(side);}
    };
    const up=()=>{
      if(!dragRef.current)return;
      const side=snapRef.current;
      const last=dragRef.current.last||panelPos;
      if(side==='left'||side==='right'){
        sPanelMode(side);
        persistUserPreference('ve_panel_mode',side);
      }else{
        sPanelPos(last);
        persistUserPreference('ve_panel_pos',last);
      }
      panelRef.current?.classList.remove('ve-dragging');
      dragRef.current=null;
      snapRef.current='';
      sSnapSide('');
      document.querySelector('#ve-panel-root .ve-hdr')?.classList.remove('dragging');
    };
    window.addEventListener('mousemove',move);window.addEventListener('mouseup',up);
    return()=>{window.removeEventListener('mousemove',move);window.removeEventListener('mouseup',up);};
  },[panelPos]);
  const cpVar=n=>{navigator.clipboard?.writeText('var('+cssTokenName(n)+')');flash('Copied!');};
  const openRowActions=id=>{if(rowActionsTimerRef.current)clearTimeout(rowActionsTimerRef.current);rowActionsTimerRef.current=null;sRowActions(String(id));};
  const scheduleRowActionsClose=id=>{
    if(rowActionsTimerRef.current)clearTimeout(rowActionsTimerRef.current);
    rowActionsTimerRef.current=setTimeout(()=>{
      const row=document.querySelector('[data-ve-variable-row="'+String(id)+'"]');
      if(!row?.matches(':hover')&&!row?.matches(':focus-within'))sRowActions(current=>current===String(id)?null:current);
    },220);
  };

  const tgExp=(id,defaultOpen=false)=>sExp(p=>{const k=String(id);const has=Object.prototype.hasOwnProperty.call(p,k);return {...p,[k]:has?!p[k]:!defaultOpen};});
  const cleanDbFooter=async()=>{
    sConfirmCleanFooter(false);
    try{flash('Cleaning...');const r=await api.p('variables/cleanup',{});await load();flash(r?.message||'Cleaned');}
    catch(e){flash('Cleanup failed');}
  };
  const [confirmDuplicate, sConfirmDuplicate] = useState(null);
  const [paletteTransfer, sPaletteTransfer] = useState(null);
  const hDup = v => {
    sConfirmDuplicate(v);
  };
  const cfmDup = async () => {
    if (!confirmDuplicate) return;
    const v = confirmDuplicate;
    sConfirmDuplicate(null);
    try {
      const res = v.palette_eligible&&v.palette_id
        ? await api.p('color-palettes/variables/'+v.id+'/copy',{palette_id:Number(v.palette_id),name:sn(v.name)+'-copy',include_generated:true})
        : await api.p('variables', { name: v.name + '.copy', value: v.value });
      if (res && res.code) {
        flash(res.message || 'Duplication failed');
      } else {
        load();
        flash('Duplicated');
      }
    } catch(e) {
      flash('Duplication failed');
    }
  };
  const openPaletteTransfer=(mode,v)=>{
    const destinations=(colorPalettesData.palettes||[]).filter(p=>mode==='copy'||String(p.id)!==String(v.palette_id||0));
    sPaletteTransfer({
      mode,
      variable:v,
      paletteId:destinations[0]?String(destinations[0].id):'',
      name:mode==='copy'?sn(v.name)+'-copy':sn(v.name),
      includeGenerated:true
    });
  };
  const runPaletteTransfer=async()=>{
    if(!paletteTransfer||!paletteTransfer.paletteId)return;
    const t=paletteTransfer;
    sPaletteTransfer(null);
    try{
      const path='color-palettes/variables/'+t.variable.id+'/'+t.mode;
      const body={palette_id:Number(t.paletteId)};
      if(t.mode==='copy'){body.name=t.name;body.include_generated=!!t.includeGenerated;}
      const res=await api.p(path,body);
      if(res?.code){flash(res.message||('Could not '+t.mode+' color'));return;}
      await load();
      flash(t.mode==='copy'?'Color copied to palette':'Color moved to palette');
    }catch(e){flash('Palette operation failed');}
  };
  const hDel = v => {
    sCfm(v);
  };
  const cfmDel = async () => {
    if (!cfm) return;
    try {
      const res = await api.d('variables/' + cfm.id + '?force=true');
      if (res && res.code) {
        flash(res.message || 'Delete failed');
      } else {
        load();
        flash('Deleted');
        sSel(null);
        sCfm(null);
      }
    } catch(e) {
      flash('Delete failed');
    }
  };
  const hCreated=(nv,isClamp)=>{load();sSub(null);flash('Created');if(isClamp)sAG(nv);};

  // Theme value-layer management states
  const [paletteManagerOpen, sPaletteManagerOpen] = useState(() => localStorage.getItem('ve_palette_mgr_open') === '1');
  const [paletteName, sPaletteName] = useState('');
  const [editingPalette, sEditingPalette] = useState(null);
  const [editPaletteName, sEditPaletteName] = useState('');
  const [paletteLd, sPaletteLd] = useState(false);
  const [paletteErr, sPaletteErr] = useState('');
  const [confirmDeletePalette, sConfirmDeletePalette] = useState(null);

  const togglePaletteManager = (val) => {
    sPaletteManagerOpen(val);
    localStorage.setItem('ve_palette_mgr_open', val ? '1' : '0');
  };
  const toggleColorPaletteManager = val => {
    sColorPaletteManagerOpen(val);
    localStorage.setItem('ve_color_palette_mgr_open',val?'1':'0');
  };
  const chooseColorControlMode = mode => {
    const next=mode==='palette'?'palette':'theme';
    sColorControlMode(next);
    localStorage.setItem('ve_color_control_mode',next);
    if(next==='theme')toggleColorPaletteManager(false);
    else togglePaletteManager(false);
  };
  const navigateVariableUsage=(item)=>{
    if(!item)return;
    sCfm(null);
    sConfirmBatchDelete(false);
    if(item.type==='variable'){
      const target=vars.find(variable=>Number(variable.id)===Number(item.id)||String(variable.name)===String(item.name));
      if(target){sSub(null);sSel(target);}
      return;
    }
    if(item.type==='theme'){
      sSub(null);sNT('color');chooseColorControlMode('theme');togglePaletteManager(true);return;
    }
    if(item.type==='css_studio'){
      openModuleIfEnabled('css_studio', () => {
        sStudioLaunchContext({toolId:'css_studio',sourceId:'variables',sourceElement:document.activeElement});
        sActiveStudioTool('css_studio');
        sUsageCssSheet(String(item.id||''));
        sCssStudioOpen(true);
      });
      return;
    }
    if(item.type==='css_recipe'){
      openModuleIfEnabled('css_recipes', () => {
        sUsageRecipeCode(String(item.id||''));
        sCssRecipesOpen(true);
      });
      return;
    }
    if(item.type==='bricks'&&item.element&&window.MimamsBarBricksAdapter){
      try{window.MimamsBarBricksAdapter.selectElement(item.element,{focusStructure:true});}catch(e){flash('Could not open that Bricks element');}
    }
  };

  // Theme actions
  const createPalette = async () => {
    if (!paletteName.trim()) return;
    sPaletteLd(true);
    sPaletteErr('');
    try {
      const res = await api.p('themes', { name: paletteName.trim(), source_slug: palettesData.active });
      sPaletteLd(false);
      if (res?.code) {
        sPaletteErr(res.message || 'Could not create theme.');
      } else {
        sPaletteName('');
        await load();
        flash('Theme created');
      }
    } catch(e) {
      sPaletteLd(false);
      sPaletteErr('Could not create theme.');
    }
  };

  const duplicatePalette = async (p) => {
    sPaletteLd(true);
    sPaletteErr('');
    try {
      const res = await api.p('themes/' + p.slug + '/duplicate', { name: p.name + ' Copy' });
      sPaletteLd(false);
      if (res?.code) {
        sPaletteErr(res.message || 'Could not duplicate theme.');
      } else {
        await load();
        flash('Theme duplicated');
      }
    } catch(e) {
      sPaletteLd(false);
      sPaletteErr('Could not duplicate theme.');
    }
  };

  const renamePalette = async () => {
    if (!editingPalette || !editPaletteName.trim()) return;
    sPaletteLd(true);
    sPaletteErr('');
    try {
      const res = await api.u('themes/' + editingPalette, { name: editPaletteName.trim() });
      sPaletteLd(false);
      if (res?.code) {
        sPaletteErr(res.message || 'Could not rename theme.');
      } else {
        sEditingPalette(null);
        sEditPaletteName('');
        await load();
        flash('Theme renamed');
      }
    } catch(e) {
      sPaletteLd(false);
      sPaletteErr('Could not rename theme.');
    }
  };

  const deletePalette = async () => {
    if (!confirmDeletePalette) return;
    const slug = confirmDeletePalette.slug;
    sConfirmDeletePalette(null);
    sPaletteLd(true);
    sPaletteErr('');
    try {
      const res = await api.d('themes/' + slug);
      sPaletteLd(false);
      if (res?.code) {
        sPaletteErr(res.message || 'Could not delete theme.');
      } else {
        await load();
        flash('Theme deleted');
      }
    } catch(e) {
      sPaletteLd(false);
      sPaletteErr('Could not delete theme.');
    }
  };

  const[subExit,sSE]=useState(false);
  const closeSub=useCallback(()=>{sSE(true);setTimeout(()=>{sSub(null);sSE(false);},SLIDE_MS);},[]);

  useEffect(()=>{
    const root=document.getElementById('ve-panel-root');
    const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
    const showFor=el=>{
      if(!el)return;
      // Respect the per-module tooltip switch. Panels carry data-panel="<module id>";
      // the speed dial and studio rail count as the shell.
      try{
        const off=tooltipsOffRef.current||[];
        if(off.length){
          const host=el.closest('[data-panel]');
          const moduleId=host?host.getAttribute('data-panel')
            :(el.closest('.ve-fab-wrap,.ve-studio-tool-rail')?'shell':'');
          if(moduleId&&off.indexOf(moduleId)!==-1)return;
        }
      }catch(e){}
      // Only intercept titles on MV surfaces. Previously this required el to be inside
      // the #ve-panel-root element; in the Bricks builder that lookup does not resolve to
      // the hovered node's root, so the styled tooltip never fired and the raw browser
      // title showed as a wide, unstyleable box. Match any MV surface via closest() so it
      // works regardless of how the builder mounts the panel.
      if(!(root&&root.contains(el))&&!el.closest('#ve-panel-root,.ve-o,.ve-standalone-panel,.ve-fab-wrap,.ve-studio-tool-rail,.ve-menu-list,.ve-modal,.ve-context-menu,.ve-rich-popover'))return;
      // Re-render puts a changed title back on the node, so adopt it BEFORE reading the
      // cached copy. Reading data-ve-title first left dynamic tips (canvas theme) showing
      // the previous label until the element was hovered a second time.
      const live=el.getAttribute('title');
      if(live){
        el.setAttribute('data-ve-title',live);
        el.removeAttribute('title');
      }
      const text=el.getAttribute('data-ve-tip')||el.getAttribute('data-ve-title')||'';
      if(!text)return;
      const compact=text.length<50&&!el.classList.contains('ve-rich-tip');
      mvTipTargetRef.current=el;
      const rect=el.getBoundingClientRect();
      let owner=el.closest('.ve-standalone-panel,.ve-o[data-panel],.ve-modal-box,.ve-rich-popover,.ve-context-menu');
      if(el.closest('.ve-studio-tool-rail')&&studioRailActiveTool)owner=document.querySelector('[data-panel="'+studioRailActiveTool+'"]')||owner;
      const ownerRect=owner?.getBoundingClientRect?.();
      const bounds={
        left:Math.max(8,ownerRect?ownerRect.left+8:8),
        top:Math.max(8,ownerRect?ownerRect.top+8:8),
        right:Math.min(window.innerWidth-8,ownerRect?ownerRect.right-8:window.innerWidth-8),
        bottom:Math.min(window.innerHeight-8,ownerRect?ownerRect.bottom-8:window.innerHeight-8)
      };
      const maxWidth=Math.max(36,bounds.right-bounds.left);
      const w=Math.min(maxWidth,compact?Math.min(230,Math.max(36,text.length*5.5+18)):Math.min(260,Math.max(120,text.length*6+28)));
      const estimatedLines=compact?1:Math.max(1,Math.ceil(text.length/38));
      const height=compact?27:Math.min(170,Math.max(34,20+(estimatedLines*16)));
      const gap=12;
      const candidates={
        above:{left:rect.left+(rect.width/2)-(w/2),top:rect.top-height-gap},
        below:{left:rect.left+(rect.width/2)-(w/2),top:rect.bottom+gap},
        right:{left:rect.right+gap,top:rect.top+(rect.height/2)-(height/2)},
        left:{left:rect.left-w-gap,top:rect.top+(rect.height/2)-(height/2)}
      };
      const preferred=el.classList.contains('ve-tip-right')?'right':el.classList.contains('ve-tip-left')?'left':el.classList.contains('ve-tip-bottom')?'below':'above';
      const order=[preferred,...['above','below','right','left'].filter(value=>value!==preferred)];
      const fits=point=>point.left>=bounds.left&&point.top>=bounds.top&&point.left+w<=bounds.right&&point.top+height<=bounds.bottom;
      const placement=order.find(value=>fits(candidates[value]))||preferred;
      const point=candidates[placement];
      const left=clamp(point.left,bounds.left,Math.max(bounds.left,bounds.right-w));
      const top=clamp(point.top,bounds.top,Math.max(bounds.top,bounds.bottom-height));
      const caret=placement==='above'||placement==='below'
        ?clamp(rect.left+(rect.width/2)-left,8,w-8)
        :clamp(rect.top+(rect.height/2)-top,8,height-8);
      sMvTip({text,left,top,width:w,placement,compact,caret});
    };
    const show=e=>showFor(e.target?.closest&&e.target.closest('[data-ve-tip],[title],[data-ve-title]'));
    const hide=e=>{
      const target=mvTipTargetRef.current;
      if(target&&e?.relatedTarget&&target.contains(e.relatedTarget))return;
      mvTipTargetRef.current=null;
      sMvTip(null);
    };
    // A tip whose label changes while the pointer sits still (toggle buttons) must
    // repaint in place; without this the tip only refreshes on the next hover.
    const retitle=new MutationObserver(records=>{
      const target=mvTipTargetRef.current;
      if(target&&records.some(record=>record.target===target))showFor(target);
    });
    if(root)retitle.observe(root,{subtree:true,attributes:true,attributeFilter:['title','data-ve-tip']});
    // Native-title killer. In the Bricks builder the styled mouseover handler does not
    // reliably fire before the browser renders its own wide `title` box, so hovering a
    // control flashed the unstyleable native tooltip. Instead of racing the browser on
    // hover, strip `title` off every MV surface the moment it is painted and mirror it
    // into data-ve-tip, which the browser cannot show natively and showFor() reads. The
    // browser then has nothing to render on its own; worst case is no tip, never a wide
    // native one. Runs in whatever frame the panel mounts in, so it is frame-independent.
    const MV_SURFACE_SEL='#ve-panel-root,.ve-o,.ve-standalone-panel,.ve-fab-wrap,.ve-studio-tool-rail,.ve-menu-list,.ve-modal,.ve-context-menu,.ve-rich-popover';
    const stripNativeTitle=el=>{
      if(!el||el.nodeType!==1||!el.getAttribute)return;
      const t=el.getAttribute('title');
      if(t&&el.closest&&el.closest(MV_SURFACE_SEL)){el.setAttribute('data-ve-tip',t);el.removeAttribute('title');}
    };
    const stripNativeTree=node=>{
      if(!node||node.nodeType!==1)return;
      stripNativeTitle(node);
      if(node.querySelectorAll)node.querySelectorAll('[title]').forEach(stripNativeTitle);
    };
    const denative=new MutationObserver(records=>{
      for(const r of records){
        if(r.type==='attributes')stripNativeTitle(r.target);
        else if(r.type==='childList')r.addedNodes.forEach(stripNativeTree);
      }
    });
    denative.observe(document.body,{subtree:true,childList:true,attributes:true,attributeFilter:['title']});
    stripNativeTree(document.body);
    document.addEventListener('mouseover',show,true);
    document.addEventListener('mouseout',hide,true);
    document.addEventListener('focusin',show,true);
    document.addEventListener('focusout',hide,true);
    return()=>{
      retitle.disconnect();
      denative.disconnect();
      document.removeEventListener('mouseover',show,true);
      document.removeEventListener('mouseout',hide,true);
      document.removeEventListener('focusin',show,true);
      document.removeEventListener('focusout',hide,true);
    };
  },[studioRailActiveTool]);
  const fabActions={
    variables:()=>openStudioToolDirect('variables'),
    help:()=>openStudioToolDirect('help'),
    css_studio:()=>openStudioToolDirect('css_studio'),
    css_recipes:()=>openStudioToolDirect('css_recipes'),
    content_studio:()=>openStudioToolDirect('content_studio'),
    media_studio:()=>openStudioToolDirect('media_studio'),
    font_manager:()=>openStudioToolDirect('font_manager'),
    plugin_studio:()=>openStudioToolDirect('plugin_studio'),
    bricks_settings:()=>openStudioToolDirect('bricks_settings'),
    theme_styles:()=>openStudioToolDirect('theme_styles'),
    recovery:()=>openStudioToolDirect('recovery'),
    mimams_bar:()=>openModuleIfEnabled('mimams_bar',()=>{
      window.dispatchEvent(new CustomEvent('ve-mimams-bar-toggle-request'));
    })
  };
  const closeMediaStudio=()=>requestStudioClose('media_studio');
  const renderStandaloneTool=({visible=true,open:toolOpen,hasOpened,title,panelId,width,persistKey,onClose,children})=>
    visible&&(toolOpen||hasOpened)&&h(StandalonePanel,{
      title,
      panelId,
      open:toolOpen,
      panelMode,
      active:resolvedActiveStudioTool===panelId,
      withStudioRail:studioRailActiveTool===panelId,
      onActivate:id=>sActiveStudioTool(id),
      width,
      persistKey,
      height:panelMode==='float'?'min(760px, calc(100vh - 32px))':'calc(100vh - 16px)',
      onClose,
      backdrop:backdropFor(panelId),
      updateNotice:h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
      hasUpdate:hasAvailableUpdate
    },children);

  return h('div',null,
    h(UpdateInstallDock),
    h(ShortcutSurface),
    studioLeaveRequest&&h(ConfirmModal,{
      global:true,
      title:studioLeaveRequest.target?'Leave CSS Studio?':'Close CSS Studio?',
      body:'Your CSS changes have not been saved. Keep editing, or discard the changes'+(studioLeaveRequest.target?' and open '+toolLabel(studioLeaveRequest.target)+'.':'.'),
      confirmText:studioLeaveRequest.target?'Discard and switch':'Discard and close',
      cancelText:'Keep editing',
      onCancel:()=>{sStudioLeaveRequest(null);focusStudioPanel('css_studio');},
      onConfirm:confirmStudioLeave
    }),
    // The toast sits outside every panel, so any pointer event that reaches document
    // reads as "clicked outside" and closes whichever studio is open. Swallow them.
    h('div',{class:'ve-toast'+(toast?' show':'')+(toastSticky?' is-sticky':''),
      onPointerDown:e=>{e.stopPropagation();},
      onMouseDown:e=>{e.stopPropagation();},
      onClick:e=>{e.stopPropagation();}},
      toast&&!toastSticky&&h('span',{class:'ve-toast-ring',key:toastTick}),
      toast&&h('span',{class:'ve-toast-text'},toast),
      toast&&toastSticky&&h('button',{type:'button',class:'ve-toast-close','aria-label':'Dismiss',
        onPointerDown:e=>{e.stopPropagation();e.preventDefault();},
        onClick:e=>{e.stopPropagation();e.preventDefault();if(toastTimerRef.current)clearTimeout(toastTimerRef.current);sToast('');}},'×')),
    // Compact tips size to their text (CSS width:auto, capped at 230px); the JS width
    // estimate is for POSITIONING only. Forcing it as inline width made every short
    // label render as a too-wide bubble whenever the estimate ran high.
    mvTip&&h('div',{role:'tooltip',class:'ve-tooltip-card ve-global-tip'+(mvTip.compact?' ve-global-tip-compact':'')+' ve-rich-tip-'+(mvTip.placement||'above'),style:{left:mvTip.left+'px',top:mvTip.top+'px',...(mvTip.compact?{}:{width:mvTip.width+'px'}),'--ve-tip-caret':mvTip.caret+'px'}},h('span',{class:'ve-tip-text'},mvTip.text)),
    nativeMediaPageActive && h('div',{class:'ve-native-media-page'},
      h('div',{class:'ve-native-media-page-shell'},
        h('div',{class:'ve-native-media-page-head'},
          h('span',null,ph('images'),' Media Studio'),
          h('div',{style:'display:flex;align-items:center;gap:8px'},
            h('span',{style:'font-size:11px;color:#888;font-weight:600'},'Native Media Library replacement'),
            h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',onClick:closeNativeMediaReplacement},'Use legacy library'),
            h('button',{type:'button',class:'ve-native-media-page-close',onClick:closeNativeMediaReplacement,title:'Close Media Studio'},ph('x'))
          )
        ),
        h(LazyStudio,{name:'MediaStudioSub',
          onClose: closeNativeMediaReplacement,
          flash,
          picking:false,
          initialFilter:'',
          pageMode:true
        })
      )
    ),
    categoryMenu&&h('div',{
      class:'ve-menu-list ve-category-context',
      style:{left:categoryMenu.x+'px',top:categoryMenu.y+'px'}
    },
      h('button',{
        type:'button',
        class:'ve-menu-item',
        disabled:categoryMenu.protected,
        title:categoryMenu.protected?'System categories cannot be renamed':'Rename category',
        onClick:()=>{if(categoryMenu.protected)return;sEditingCategory(categoryMenu.category);sCategoryEditName(categoryMenu.category.name);sCategoryMenu(null);}
      },ph('pencil-simple'),' Rename'),
      h('button',{
        type:'button',
        class:'ve-menu-item danger',
        disabled:categoryMenu.protected,
        title:categoryMenu.protected?'System categories cannot be removed':'Remove category',
        style:categoryMenu.protected?'':'color:#ef4444',
        onClick:()=>{if(categoryMenu.protected)return;sConfirmCategoryDelete(categoryMenu.category);sCategoryMenu(null);}
      },ph('trash'),' Remove')
    ),
    studioRailActiveTool&&h(StudioToolRail,{activeTool:studioRailActiveTool,disabledTools:deactivatedTools,onSelect:requestStudioTool}),
      /* Opening is triggered only by the gear (below); the wrap merely cancels a
         pending close so moving up into the tools keeps them open. Hovering the
         wrap's empty area no longer reveals the speed dial. */
      h('div',{ref:fabRef,class:'ve-fab-wrap' + (fabToolsOpen ? ' ve-fab-tools-open' : '') + (open || settingsOpen || helpOpen || cssStudioOpen || contentStudioOpen || mediaStudioStandaloneOpen || fontManagerOpen || pluginStudioOpen || bricksSettingsOpen || themeStylesOpen || cssRecipesOpen ? ' ve-fab-hidden' : ''),onMouseEnter:function(){cancelFabClose();prefetchStudios();},onMouseLeave:scheduleFabClose},
      h('div',{class:'ve-fab-menu'},
        normalizeFabOrder(fabOrder).map(id=>{
          const tool=SPEED_DIAL_TOOLS.find(item=>item.id===id);
          if(!tool)return null;
          if(tool.module&&isToolDisabledNow(tool.module))return null;
          return h('div',{class:'ve-fab-item',key:id,onClick:fabActions[id]},ph(tool.icon),h('div',{class:'ve-fab-tooltip'},tool.label));
        })
      ),
      h('div',{class:'ve-fab',onMouseEnter:openFabTools,onFocus:openFabTools,onClick:()=>openStudioToolDirect('settings'),'aria-label':"Mimam's Var settings"},ph('gear'))
    ),
    open&&snapSide&&h('div',{class:'ve-snap-zone '+snapSide+' show'}),
    open&&panelMode!=='float'&&h('div',{class:'ve-bd show',onClick:()=>sO(false)}),
    h('div',{ref:panelRef,tabIndex:-1,'data-panel':'variables',class:'ve-o '+(panelMode==='float'?'ve-float':'ve-dock-'+panelMode)+(open?' open':'')+(hasAvailableUpdate?' has-update':'')+(studioRailActiveTool==='variables'?' ve-has-studio-rail':''),style:panelMode==='float'?{left:(panelPos.left||Math.max(16,window.innerWidth-430))+'px',top:(panelPos.top||16)+'px',right:'auto'}:null,onPointerDown:()=>open&&sActiveStudioTool('variables')},
      cfm&&h('div',{class:'ve-modal ve-delete-impact-modal',onClick:()=>sCfm(null)},h('div',{class:'ve-modal-box ve-delete-impact-box',onClick:e=>e.stopPropagation()},
        h('div',{class:'ve-delete-impact-head'},
          h('div',{class:'ve-delete-impact-icon'},ph('warning')),
          h('div',{class:'ve-delete-impact-copy'},
            h('div',{class:'ve-delete-impact-title'},'Delete variable?'),
            h('div',{class:'ve-delete-impact-name'},publicTokenLabel(cfm.name)),
            h('div',{class:'ve-delete-impact-text'},'This permanently removes the variable and its generated variants. Review every detected consumer first.'))),
        h('div',{class:'ve-delete-impact-content'},h(VariableUsagePanel,{variable:cfm,onNavigate:navigateVariableUsage,title:'Affected consumers'})),
        h('div',{class:'ve-delete-impact-actions'},h('button',{class:'ve-btn ve-btn-g',onClick:()=>sCfm(null)},'Keep Variable'),h('button',{class:'ve-btn ve-btn-d',onClick:cfmDel},ph('trash'),'Delete Variable')))),
      confirmCategoryDelete&&h(ConfirmModal,{
        title:'Delete Category',
        body:'Delete “'+confirmCategoryDelete.name+'”? Its variables and generated children will move to Uncategorized. Token names and CSS will not change.',
        confirmText:'Delete Category',
        danger:true,
        onCancel:()=>sConfirmCategoryDelete(null),
        onConfirm:deleteCategory
      }),
      editingCategory&&h('div',{class:'ve-modal'},h('div',{class:'ve-modal-box'},
        h('div',{class:'ve-modal-title'},'Rename Category'),
        h('div',{class:'ve-modal-body'},
          h('input',{
            class:'ve-studio-input',
            value:categoryEditName,
            onInput:e=>sCategoryEditName(e.target.value),
            onKeyDown:e=>{if(e.key==='Enter')renameCategory();if(e.key==='Escape')sEditingCategory(null);},
            style:'width:100%'
          })
        ),
        h('div',{class:'ve-modal-actions'},
          h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sEditingCategory(null)},'Cancel'),
          h('button',{class:'ve-btn ve-btn-s',disabled:!categoryEditName.trim()||categoryEditName.trim()===editingCategory.name,onClick:renameCategory},'Save')
        )
      )),
      confirmCleanFooter&&h(ConfirmModal,{title:'Clean WordPress DB',body:'Clean duplicate, stale, and orphan generated variables from WordPress? This keeps base variables and rebuilds recoverable generated variants.',confirmText:'Clean',onCancel:()=>sConfirmCleanFooter(false),onConfirm:cleanDbFooter}),
      confirmDeletePalette&&h(ConfirmModal,{title:'Delete theme',body:'Delete \''+confirmDeletePalette.name+'\'? Its alternate color values will be removed. The underlying variables remain safe.',confirmText:'Delete Theme',danger:true,onCancel:()=>sConfirmDeletePalette(null),onConfirm:deletePalette}),
      confirmDuplicate&&h(ConfirmModal,{title:'Duplicate variable',body:'Are you sure you want to duplicate variable \''+confirmDuplicate.name+'\'?',confirmText:'Duplicate',onCancel:()=>sConfirmDuplicate(null),onConfirm:cfmDup}),
      confirmBatchDelete&&h('div',{class:'ve-modal ve-delete-impact-modal'},h('div',{class:'ve-modal-box ve-delete-impact-box'},
        h('div',{class:'ve-delete-impact-head'},
          h('div',{class:'ve-delete-impact-icon'},ph('warning')),
          h('div',{class:'ve-delete-impact-copy'},
            h('div',{class:'ve-delete-impact-title'},'Delete '+checkedVars.length+' variables?'),
            h('div',{class:'ve-delete-impact-text'},'This permanently removes the selected variables and their generated variants. Review every detected consumer first.'))),
        h('div',{class:'ve-delete-impact-content'},h(VariableImpactStack,{variables:selectedVariables,onNavigate:navigateVariableUsage})),
        h('div',{class:'ve-delete-impact-actions'},h('button',{class:'ve-btn ve-btn-g',onClick:()=>sConfirmBatchDelete(false)},'Keep Variables'),h('button',{class:'ve-btn ve-btn-d',onClick:()=>{sConfirmBatchDelete(false);deleteCheckedVars();}},ph('trash'),'Delete Selected')))),
      paletteTransfer&&h('div',{class:'ve-modal'},h('div',{class:'ve-modal-box'},
        h('div',{class:'ve-modal-title'},paletteTransfer.mode==='copy'?'Copy color to palette':'Move color to palette'),
        h('div',{class:'ve-modal-body'},
          h('div',{style:'margin-bottom:8px'},paletteTransfer.mode==='copy'?'Create an independent copy of “'+paletteTransfer.variable.name+'”.':'Move “'+paletteTransfer.variable.name+'” without changing its token, value, aliases, or website output.'),
          h('div',{style:'font-size:11px;color:#888;margin-bottom:5px'},'Destination palette'),
          h(SelectMenu,{
            value:paletteTransfer.paletteId,
            onChange:value=>sPaletteTransfer(prev=>({...prev,paletteId:value})),
            options:[{value:'',label:'Choose palette'},...(colorPalettesData.palettes||[]).filter(p=>paletteTransfer.mode==='copy'||String(p.id)!==String(paletteTransfer.variable.palette_id||0)).map(p=>({value:String(p.id),label:p.name}))]
          }),
          paletteTransfer.mode==='copy'&&h('div',{style:'margin-top:10px'},
            h('div',{style:'font-size:11px;color:#888;margin-bottom:5px'},'New variable name'),
            h('input',{class:'ve-studio-input',value:paletteTransfer.name,onInput:e=>sPaletteTransfer(prev=>({...prev,name:normalizeNameInput(e.target.value)})),style:'width:100%'}),
            paletteTransfer.variable.type==='base'&&h(CheckControl,{checked:paletteTransfer.includeGenerated,onChange:value=>sPaletteTransfer(prev=>({...prev,includeGenerated:value})),label:'Copy generated children'}))),
        h('div',{class:'ve-modal-actions'},
          h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sPaletteTransfer(null)},'Cancel'),
          h('button',{class:'ve-btn ve-btn-s',disabled:!paletteTransfer.paletteId||(paletteTransfer.mode==='copy'&&!paletteTransfer.name),onClick:runPaletteTransfer},paletteTransfer.mode==='copy'?'Copy Color':'Move Color')))),

      h('div',{class:'ve-hdr'},h('span',{class:'ve-drag-handle',title:'Drag panel',onMouseDown:startPanelDrag},ph('dots-six-vertical')),
        h('div',{class:'ve-brand'},h('span',{class:'ve-hdr-t'},"Mimam's Var - WP"),CFG.logoUrl?h('img',{class:'ve-hdr-i',src:CFG.logoUrl,alt:''}):h('div',{class:'ve-hdr-i'})),
        h('div',{class:'ve-hdr-a'},

          h('button',{onClick:()=>{if(sub==='sync')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('sync'),sub?SLIDE_MS+10:0);}},title:'Sync'},ph('cloud-arrow-up')),
          h('button',{onClick:()=>{if(sub==='snapshots')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('snapshots'),sub?SLIDE_MS+10:0);}},title:'Snapshots'},ph('clock-counter-clockwise')),
          h('button',{onClick:()=>{if(sub==='migration')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('migration'),sub?SLIDE_MS+10:0);}},title:'Migrate variables'},ph('database')),
          h('button',{onClick:()=>{if(sub==='create')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('create'),sub?SLIDE_MS+10:0);}},title:sub==='create'?'Close new variable':'New variable'},ph(sub==='create'?'x':'plus')),
          h('button',{onClick:load,title:'Refresh'},ph('arrows-clockwise')),
          h('button',{onClick:()=>sO(false),title:'Close'},ph('x'))),
        h(ActivityProgress,{panelId:'variables'})),

      h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
      sub==='sync'&&h(SyncPanel,{onClose:closeSub,exiting:subExit,onReload:load,onDone:()=>{sSub(null);load();flash('Sync complete');}}),
      sub==='snapshots'&&h(SyncPanel,{onClose:closeSub,exiting:subExit,onReload:load,initialView:'snapshots',snapshotsOnly:true,onDone:()=>{sSub(null);load();flash('Snapshot restored');}}),
      sub==='migration'&&h(MigrationSub,{onClose:closeSub,exiting:subExit,onDone:async result=>{sSub(null);const fresh=await load();const affected=new Set((result?.affected_names||[]).map(String));const firstAffected=Array.isArray(fresh)?fresh.find(v=>affected.has(String(v.name))):null;if(firstAffected)sNT(variableNamespace(firstAffected));const applied=Number(result?.applied||0);const skipped=Number(result?.skipped_aliases||0);flash('Migration complete · '+applied+' change'+(applied===1?'':'s')+' applied'+(skipped?' · '+skipped+' skipped':''));}}),
      sub==='categories'&&h(VariableCategoryPanel,{onClose:closeSub,exiting:subExit,categories:allCats,onChanged:load}),
      sub==='create'&&h(CreateSub,{onCreated:hCreated,onClose:closeSub,categories:allCats,vars,exiting:subExit,palettes:colorPalettesData.palettes,paletteId:selectedColorPalette,initialCategory:nsTab}),
      sub?.type==='edit'&&h(EditSub,{variable:sub.v,categories:allCats,vars,onNavigateUsage:navigateVariableUsage,onDone:r=>{sSub(null);load();const warnings=r?.rename_impact?.warnings||[];flash(warnings.length?'Updated with '+warnings.length+' propagation warning'+(warnings.length===1?'':'s'):'Updated');},onClose:closeSub,exiting:subExit}),
      sub?.type==='genColor'&&h(GenColorSub,{variable:sub.v,childMap,onDone:()=>{sSub(null);load();flash('Generated');},onClose:closeSub,exiting:subExit}),
      sub?.type==='genScale'&&h(GenScaleSub,{variable:sub.v,onDone:()=>{sSub(null);load();flash('Generated');},onClose:closeSub,exiting:subExit}),
      sub?.type==='family'&&h(FamilyRelationshipSub,{initialIds:sub.ids||[],initialOperation:sub.operation,initialRootId:sub.rootId,initialNewRootId:sub.newRootId,lockRoot:!!sub.lockRoot,vars,onNavigateUsage:navigateVariableUsage,onDone:result=>{sSub(null);clearCheckedVars();load();flash((result?.applied||0)+' family relationship'+(Number(result?.applied)===1?'':'s')+' updated');},onClose:closeSub,exiting:subExit}),

      !sub&&h('div',{style:'display:flex;flex-direction:column;flex:1;min-height:0'},
        h('div',{class:'ve-sr'},h('input',{ref:sRef,placeholder:'Search... (Alt+Z)',value:sr,onInput:e=>sSr(e.target.value)})),
        h('div',{class:'ve-tabs'},
          h('div',{class:'ve-tabs-scroll'},namespaces.map(ns=>{
            const catObj = allCats.find(c => c.slug === ns);
            const menuCategory = ns==='color'
              ? {slug:'color',name:'Color',protected:1}
              : catObj;
            return h('div',{
              class:'ve-t'+(nsTab===ns?' on':''),
              title:ns==='all'?'Show every variable':ns==='color'?'Color variables':'Category: '+(categoryNames[ns]||ns),
              onClick:()=>sNT(ns),
              onContextMenu: e => {
                if (menuCategory) {
                  e.preventDefault();
                  const menuWidth=142;
                  const menuHeight=82;
                  sCategoryMenu({
                    x:Math.max(8,Math.min(e.clientX,window.innerWidth-menuWidth-8)),
                    y:Math.max(8,Math.min(e.clientY,window.innerHeight-menuHeight-8)),
                    category:menuCategory,
                    protected:!!Number(menuCategory.protected)
                  });
                }
              }
            },categoryNames[ns]||ns);
          })),
          h('div',{class:'ve-category-manage-wrap'},
            h('button',{class:'ve-a ve-category-manage',title:'Create and manage categories',onClick:()=>sSub('categories')},ph('folder-simple-plus')))),
        nsTab==='color'&&h('div',{class:'ve-color-control'},
          h('div',{class:'ve-color-kind-switch'},
            h('button',{class:colorControlMode==='theme'?'on':'',onClick:()=>chooseColorControlMode('theme')},'Theme'),
            h('button',{class:colorControlMode==='palette'?'on':'',onClick:()=>chooseColorControlMode('palette')},'Palette')
          ),
          colorControlMode==='theme'&&h('div',{class:'ve-color-control-row'},
            
            h(SelectMenu,{
              value:palettesData?.active,
              onChange:activatePalette,
              options:(palettesData?.palettes||[]).map(p=>({value:p.slug,label:p.name}))
            }),
            h('button',{
              class:'ve-a' + (paletteManagerOpen ? ' on' : ''),
              title: paletteManagerOpen ? 'Close Theme Manager' : 'Manage Themes',
              onClick:()=>togglePaletteManager(!paletteManagerOpen)
            }, ph(paletteManagerOpen ? 'caret-up' : 'sliders-horizontal'))
          ),
          colorControlMode==='theme'&&paletteManagerOpen && h('div',{style:'padding:0 14px 12px;border-top:1px solid #2a2a2a;display:flex;flex-direction:column;gap:8px;background:rgba(0,0,0,.12)'},
            h('div',{class:'ve-palette-current',style:'margin-top:10px;margin-bottom:6px;padding:4px 0;display:flex;align-items:center;gap:10px'},
              h('i',{class:'ph-duotone ph-palette',style:'font-size:18px;color:#baf400;line-height:1'}),
              h('div',null,
                h('div',{style:'font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;font-weight:600'},'Active Theme'),
                h('div',{style:'font-size:13px;color:#e8e8e8;font-weight:700;margin-top:1px'},(palettesData.palettes.find(p=>p.slug===palettesData.active)?.name)||'Default')
              )
            ),
            h('div',{style:'font-size:11px;color:#888;line-height:1.4;margin-bottom:2px'},'Themes change color values without changing token names. Create one from the currently active colors, switch it on, then edit Color variables normally to customize that theme. Generated color children follow their base color.'),
            h('div',{style:'display:flex;gap:5px'},
              h('input',{
                class:'ve-studio-input',
                type:'text',
                value:paletteName,
                onInput:e=>sPaletteName(e.target.value),
                placeholder:'New theme name',
                onKeyDown:e=>e.key==='Enter'&&createPalette(),
                style:'flex:1;font-size:11px;'
              }),
              h('button',{class:'ve-btn',onClick:createPalette,disabled:paletteLd||!paletteName.trim()},'Create')
            ),
            paletteErr&&h('div',{style:'font-size:11px;color:#ef4444'},paletteErr),
            h('div',{style:'max-height:160px;overflow-y:auto;margin-top:4px'},
              palettesData.palettes.map(p=>{
                const info=editingPalette===p.slug
                  ? h('div',{style:'display:flex;gap:4px'},
                      h('input',{
                        class:'ve-studio-input',
                        type:'text',
                        value:editPaletteName,
                        onInput:e=>sEditPaletteName(e.target.value),
                        onKeyDown:e=>{if(e.key==='Enter')renamePalette();if(e.key==='Escape')sEditingPalette(null);},
                        style:'flex:1;min-width:0;font-size:11px;'
                      }),
                      h('button',{class:'ve-btn',onClick:renamePalette,disabled:paletteLd},'Save')
                    )
                  : h('div',{class:'ve-palette-row-name',style:'font-size:11px;color:#ddd;font-weight:600'},p.name);
                return h('div',{class:'ve-palette-row',key:p.slug,style:'display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #222'},
                  h('button',{
                    class:'ve-a',
                    style:'opacity:'+(p.active?'1':'.4')+';padding:2px',
                    title:p.active?'Active theme':'Activate '+p.name,
                    onClick:()=>!p.active&&activatePalette(p.slug),
                    disabled:paletteLd
                  }, ph(p.active?'check-circle':'circle')),
                  h('div',{class:'ve-palette-row-info',style:'flex:1;min-width:0'},
                    info,
                    h('div',{class:'ve-palette-row-meta',style:'font-size:11px;color:#666;margin-top:2px'},
                      p.active?'Active · ':'',
                      p.slug==='default'?'Uses base variable values':(p.value_count||0)+' color values'
                    )
                  ),
                  h('div',{class:'ve-palette-actions',style:'display:flex;gap:4px;align-items:center'},
                    h('button',{class:'ve-a',style:'padding:2px',title:'Duplicate theme',onClick:()=>duplicatePalette(p),disabled:paletteLd}, ph('copy')),
                    !p.protected&&h('button',{class:'ve-a',style:'padding:2px',title:'Rename theme',onClick:()=>{sEditingPalette(p.slug);sEditPaletteName(p.name);},disabled:paletteLd}, ph('pencil-simple')),
                    !p.protected&&h('button',{class:'ve-a',style:'padding:2px',title:'Delete theme',onClick:()=>sConfirmDeletePalette(p),disabled:paletteLd}, ph('trash'))
                  )
                );
              })
            )
          ),
          colorControlMode==='palette'&&h('div',{class:'ve-color-control-row'},
            
            h(SelectMenu,{
              value:selectedColorPalette,
              onChange:sSelectedColorPalette,
              options:[{value:'all',label:'All Colors'},...(colorPalettesData.palettes||[]).map(p=>({value:String(p.id),label:p.name+' ('+p.color_count+')'}))]
            }),
            h('button',{class:'ve-a'+(colorPaletteManagerOpen?' on':''),title:colorPaletteManagerOpen?'Close Color Palette Manager':'Manage Color Palettes',onClick:()=>toggleColorPaletteManager(!colorPaletteManagerOpen)},ph(colorPaletteManagerOpen?'caret-up':'sliders-horizontal'))),
          colorControlMode==='palette'&&colorPaletteManagerOpen&&h(ColorPalettePanel,{inline:true,onChanged:load,selectedPaletteId:selectedColorPalette})
        ),
        h('div',{class:'ve-source-filter'},
          h('button',{
            type:'button',
            class:'ve-source-chip'+(sourceFilter==='all'?' on':''),
            onClick:()=>sSourceFilter('all')
          },'All sources',h('span',{class:'ve-source-count'},sourceCounts.all||0)),
          VARIABLE_ORIGINS.filter(key=>(sourceCounts[key]||0)>0).map(key=>h('button',{
            type:'button',
            class:'ve-source-chip'+(sourceFilter===key?' on':''),
            onClick:()=>sSourceFilter(sourceFilter===key?'all':key),
            title:'Filter '+({mv:"Mimam's Var",file:'file imports',figma:'Figma',at:'Advanced Themer',cf:'Core Framework',acss:'Automatic.css'}[key]||key)
          },({mv:'MV',file:'FILE',figma:'Figma',at:'AT',cf:'CF',acss:'ACSS'}[key]||key),h('span',{class:'ve-source-count'},sourceCounts[key]||0))),
          sourceFilter!=='all'&&h('button',{class:'ve-btn ve-btn-g ve-btn-s ve-source-select',onClick:selectCurrentSource,disabled:sourceSelectionIds.length<1},'Select source')
        ),
        cleanupIssues.length>0&&h('div',{class:'ve-clean'},
          h('span',null,'WP cleanup available: '+cleanupIssues.join(', ')),
          h('button',{class:'ve-btn ve-btn-g',onClick:()=>sConfirmCleanFooter(true)},'Clean')),
        manualIntegrityNotices.length>0&&h('div',{class:'ve-warn',style:'margin:0 10px 8px;font-size:11px;line-height:1.5'},manualIntegrityNotices.join('. ')+'. Cleanup will not guess the intended source or public token.'),
        h('div',{style:'display:flex;justify-content:space-between;align-items:center;padding:6px 14px;border-bottom:1px solid #2a2a2a;background:#1a1a1a;flex-shrink:0'},
          h('label',{style:'display:flex;align-items:center;gap:6px;font-size:11px;color:#888;cursor:pointer;'},
            h('input',{class:'ve-var-check',type:'checkbox',checked:visibleSelectionIds.length>0&&visibleSelectionIds.every(id=>checkedVarSet.has(Number(id))),onChange:toggleAllVarsChecked}),
            'Select All'
          ),
          h('span',{style:'font-size:11px;color:#555;'},'Shift-click selects a range'),
          h('span',{style:'font-size:11px;color:#666;'},filtered.length+' variables')
        ),
        h('div',{class:'ve-body'},
          filtered.length===0?h('div',{class:'ve-empty'},sr?'No matches':'No variables'):
          [
          visibleFiltered.map(v=>{
            // Expansion: while searching, always expand so matches show. Otherwise an
            // explicit toggle (hasExp) always wins — previously a selected source forced
            // iE=true unconditionally, so families could not be collapsed under a source
            // filter. When untouched, default to expanded in a source view, collapsed in All.
            const kids=filteredChildMap[v.id]||[];const allKids=childMap[v.id]||[];const expKey=String(v.id);const hasExp=Object.prototype.hasOwnProperty.call(exp,expKey);const iE=sr?true:(hasExp?!!exp[expKey]:(sourceFilter!=='all'));
            const resolvedVal=resolvedVariableValue(v, vars);
            const displayNs=variableNamespace(v);const isSp=displayNs==='space';const spW=isSp?Math.max(4,pxV(resolvedVal)/maxSp*100):0;
            const bc=stripeColor(v);
            const row=h('div',{
              class:'ve-v'+(sel?.id===v.id?' sel':'')+(checkedVarSet.has(Number(v.id))?' checked':'')+(draggingVarId===v.id?' dragging':'')+(dragOverVarId===v.id?' drag-over':''),
              style:`--ve-ns:${bc};padding-left:4px`,
              title:(categoryNames[displayNs]||displayNs)+' · '+variableOriginTitle(v),
              'data-ve-variable-row':String(v.id),
              draggable:true,
              onDragStart:e=>handleVarDragStart(e,v),
              onDragOver:e=>handleVarDragOver(e,v),
              onDragLeave:()=>sDragOverVarId(null),
              onDragEnd:handleVarDragEnd,
              onDrop:e=>handleVarDrop(e,v),
              onMouseEnter:()=>openRowActions(v.id),
              onMouseLeave:()=>scheduleRowActionsClose(v.id),
              onFocus:()=>openRowActions(v.id),
              onBlur:()=>scheduleRowActionsClose(v.id),
              onClick:()=>hSel(v)
            },
              h('span',{class:'ve-var-drag-handle',style:'cursor:grab;margin-right:2px;display:flex;align-items:center;opacity:0.3;'},ph('dots-six-vertical')),
              h('input',{class:'ve-var-check',type:'checkbox',checked:checkedVarSet.has(Number(v.id)),onChange:e=>{e.stopPropagation();toggleVarChecked(v.id,e);},onClick:e=>{e.stopPropagation();e.currentTarget.__veShiftKey=!!e.shiftKey;},title:'Shift-click to select a visible range'}),
              allKids.length>0?h('button',{class:'ve-exp',onClick:e=>{e.stopPropagation();tgExp(v.id,sourceFilter!=='all');}},ph(iE?'minus':'plus')):h('div',{style:'width:18px'}),
              h('div',{class:'ve-sw-trigger'},h(Sw,{v:resolvedVal})),
              h('div',{class:'ve-inf'},h('div',{class:'ve-nm'},h('span',{class:'ve-nm-label'},publicTokenLabel(v.name)),h(OriginPill,{variable:v,active:sourceFilter===normalizedVariableOrigin(v),onFilter:key=>sSourceFilter(sourceFilter===key?'all':key)})),h('div',{class:'ve-vl'},v.type==='alias'?(v.css_value||''):v.value,isSp&&h('div',{class:'ve-sb',style:`width:${spW}%`}))),
              h('div',{class:'ve-as'+(rowActions===String(v.id)?' open':'')},
                h('button',{class:'ve-a',title:'Edit',onClick:e=>{e.stopPropagation();sSub({type:'edit',v});}},ph('pencil-simple')),
                h('button',{class:'ve-a',title:'Generate',onClick:e=>{e.stopPropagation();sSub(isClr(resolvedVal)?{type:'genColor',v}:{type:'genScale',v});}},ph('sun')),
                h('button',{class:'ve-a',title:'Duplicate',onClick:e=>{e.stopPropagation();hDup(v);}},ph('copy')),
                allKids.length>0&&h('button',{class:'ve-a',title:'Manage this family',onClick:e=>{e.stopPropagation();const rootId=Number(v.id);const ids=[rootId,...allKids.map(child=>Number(child.id))];sSub({type:'family',ids,operation:'change_root',rootId,lockRoot:true});}},ph('tree-structure')),
                v.palette_eligible&&h('button',{class:'ve-a',title:'Copy to palette',onClick:e=>{e.stopPropagation();openPaletteTransfer('copy',v);}},ph('copy-simple')),
                v.palette_eligible&&h('button',{class:'ve-a',title:'Move to palette',onClick:e=>{e.stopPropagation();openPaletteTransfer('move',v);}},ph('arrows-left-right')),
                h('button',{class:'ve-a',title:'Copy var()',onClick:e=>{e.stopPropagation();cpVar(v.name);}},ph('clipboard-text')),
                h('button',{class:'ve-a',title:'Delete',onClick:e=>{e.stopPropagation();hDel(v);}},ph('trash'))));
            const children=kids.length>0&&iE&&h('div',{class:'ve-ch'},kids.map(c=>{
              const resolvedCVal=resolvedVariableValue(c, vars);
              return h('div',{class:'ve-c'+(checkedVarSet.has(Number(c.id))?' checked':''),key:c.id,onClick:()=>hSel(c)},
                h('input',{class:'ve-var-check',type:'checkbox',checked:checkedVarSet.has(Number(c.id)),onChange:e=>{e.stopPropagation();toggleVarChecked(c.id,e);},onClick:e=>{e.stopPropagation();e.currentTarget.__veShiftKey=!!e.shiftKey;},title:'Shift-click to select a visible range'}),
                h(Sw,{v:resolvedCVal}),
                h('div',{class:'ve-inf'},h('div',{class:'ve-nm'},h('span',{class:'ve-nm-label'},publicTokenLabel(c.name)),h(OriginPill,{variable:c,active:sourceFilter===normalizedVariableOrigin(c),onFilter:key=>sSourceFilter(sourceFilter===key?'all':key)})),h('div',{class:'ve-vl'},c.type==='alias'?c.css_value:c.value)),
                h('button',{class:'ve-a',style:'opacity:.6',title:'Manage this family',onClick:e=>{e.stopPropagation();const rootId=Number(c.source_id);const familyChildren=childMap[rootId]||[];sSub({type:'family',ids:[rootId,...familyChildren.map(child=>Number(child.id))],operation:'change_root',rootId,newRootId:Number(c.id),lockRoot:true});}},ph('tree-structure')),
                h('button',{class:'ve-a',style:'opacity:.6',title:'Copy var()',onClick:e=>{e.stopPropagation();cpVar(c.name);}},ph('clipboard-text')));
            }));
            return h('div',{class:'ve-tree-item',key:v.id},row,children);
          }),
          filtered.length>visibleFiltered.length&&h('div',{style:'padding:12px 14px;text-align:center'},
            h('button',{
              class:'ve-btn ve-btn-g',
              onClick:()=>sVisibleVariableLimit(limit=>limit+100)
            },ph('plus-circle'),'Load '+Math.min(100,filtered.length-visibleFiltered.length)+' more')
          )
          ]),
        sel&&h(Detail,{variable:sel,vars,onNav:d=>{const f=vars.find(v=>v.id===d.id||v.name===d.name);if(f)sSel(f);},onNavigateUsage:navigateVariableUsage,onClose:()=>sSel(null),onUpdate:()=>{load();flash('Updated');},onEditFull:v=>sSub({type:'edit',v})}),
      ),
      h('div',{class:'ve-st'},
        h('div',{class:'ve-st-left'},
          h('span',null,(stats?(stats.base||0)+' base · '+(stats.generated||0)+' generated':vars.length+' variables')),
          cleanupIssues.length>0&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',title:'Clean WordPress variable database',onClick:()=>sConfirmCleanFooter(true)},'Clean WP DB')
        ),
        h('span',null,'v'+(CFG.version||'1.1.16'))),
      !sub && checkedVars.length > 0 && h('div', { class: 've-studio-batch-overlay', style: 'left:14px;right:14px;bottom:56px;transform:none!important;box-sizing:border-box;display:flex;justify-content:space-between;align-items:center;padding:8px 12px;gap:8px;' },
        selectionReviewOpen&&h('div',{class:'ve-selection-review'},
          h('div',{class:'ve-selection-review-head'},
            h('div',{class:'ve-selection-review-title'},
              h('strong',null,'Selected variables'),
              h('span',null,hiddenSelectedCount?`${selectedVariables.length-hiddenSelectedCount} visible · ${hiddenSelectedCount} outside this view`:`${selectedVariables.length} visible in this view`)
            ),
            h('button',{class:'ve-selection-review-clear',onClick:clearCheckedVars},'Clear all')
          ),
          h('div',{class:'ve-selection-review-list'},
            selectedVariables.map(variable=>{
              const isVisible=visibleSelectionSet.has(Number(variable.id));
              return h('div',{class:'ve-selection-review-item',key:variable.id},
                h('span',{class:'ve-selection-review-item-name',title:publicTokenLabel(variable.name)},publicTokenLabel(variable.name)),
                h(OriginPill,{variable,active:sourceFilter===normalizedVariableOrigin(variable),onFilter:key=>sSourceFilter(sourceFilter===key?'all':key)}),
                !isVisible&&h('span',{class:'ve-selection-review-item-badge hidden'},'Off-screen'),
                h('button',{class:'ve-selection-review-remove',title:'Remove from selection',onClick:()=>removeCheckedVar(variable.id)},ph('x'))
              );
            })
          )
        ),
        h('button',{
          type:'button',
          class:'ve-batch-count'+(selectionReviewOpen?' open':''),
          title:'Review selected variables',
          'aria-expanded':selectionReviewOpen?'true':'false',
          onClick:()=>sSelectionReviewOpen(open=>!open)
        },h('b',null,selectedVariables.length),h('span',null,'selected'),hiddenSelectedCount>0&&h('em',{class:'ve-batch-count-hidden'},`${hiddenSelectedCount} off-screen`),ph(selectionReviewOpen?'caret-down':'caret-up')),
        h('div', { class:'ve-batch-actions' },
          nsTab === 'color' && h('div', { style: 'display:flex;align-items:center;gap:4px;flex-shrink:1;min-width:0;' },
            h(SelectMenu, {
              value: batchTargetPaletteId,
              onChange: sBatchTargetPaletteId,
              className: 've-batch-select',
              options: [{ value: '', label: 'Move to...' }, ...(colorPalettesData.palettes || []).map(p => ({ value: String(p.id), label: p.name }))]
            }),
            h('button', {
              class: 've-btn ve-btn-g ve-btn-s',
              disabled: !batchTargetPaletteId,
              onClick: () => moveCheckedVarsToPalette(batchTargetPaletteId)
            }, 'Move')
          ),
          nsTab !== 'color' && h('div', { style: 'display:flex;align-items:center;gap:4px;flex-shrink:1;min-width:0;' },
            h(SelectMenu, {
              value: batchTargetCategorySlug,
              onChange: sBatchTargetCategorySlug,
              className: 've-batch-select',
              options: [{ value: '', label: 'Move to...' }, ...allCats.map(category => ({ value: category.slug, label: category.name }))]
            }),
            h('button', {
              class: 've-btn ve-btn-g ve-btn-s',
              disabled: !batchTargetCategorySlug,
              onClick: () => moveCheckedVarsToCategory(batchTargetCategorySlug)
            }, 'Move')
          ),
          h('button', { type:'button', class: 've-batch-icon-btn', title:'Family — group, ungroup, reparent, or change a family root', onClick: () => sSub({type:'family',ids:[...checkedVars]}) }, ph('tree-structure')),
          h('span', { class: 've-batch-div' }),
          h('button', { type:'button', class: 've-batch-icon-btn', title:'Cancel selection', onClick: clearCheckedVars }, ph('x')),
          h('button', { type:'button', class: 've-batch-icon-btn danger', title:'Delete selected', onClick: () => sConfirmBatchDelete(true) }, ph('trash'))
        )
      )
    ),
        
      renderStandaloneTool({open:settingsOpen,hasOpened:settingsHasOpened,title:'Settings',panelId:'settings',width:468,persistKey:'ve_settings_pos',onClose:()=>requestStudioClose('settings'),children:h(UnifiedSettingsPanel, {
        onClose: () => requestStudioClose('settings'),
        panelMode,
        setPanelMode,
        onModuleStateChange: applyModuleStateImmediately
      })}),

      renderStandaloneTool({visible:!isToolDisabledNow('help'),open:helpOpen,hasOpened:helpHasOpened,title:'Documentation',panelId:'help',width:900,persistKey:'ve_help_pos',onClose:()=>requestStudioClose('help'),children:h(HelpPanel, {
        onClose: () => sHelpOpen(false)
      })}),

      renderStandaloneTool({visible:!isToolDisabledNow('css_studio'),open:cssStudioOpen,hasOpened:cssStudioHasOpened,title:'CSS Studio',panelId:'css_studio',width:430,persistKey:'ve_css_studio_pos',onClose:()=>requestStudioClose('css_studio'),children:h(AdvancedCssSub, {
        key:'css-studio-'+cssStudioResetToken,
        onClose: () => requestStudioClose('css_studio'),
        exiting: false,
        vars,
        initialSheetId: usageCssSheet,
        onDirtyChange:sCssStudioDirty
      })}),

      renderStandaloneTool({visible:!isToolDisabledNow('css_recipes'),open:cssRecipesOpen,hasOpened:cssRecipesHasOpened,title:'CSS Recipes',panelId:'css_recipes',width:420,persistKey:'ve_css_recipes_pos',onClose:()=>sCssRecipesOpen(false),children:h(CssRecipesStudioSub, {
        flash,
        vars,
        initialCode: usageRecipeCode
      })}),

      renderStandaloneTool({visible:!isToolDisabledNow('content_studio'),open:contentStudioOpen,hasOpened:contentStudioHasOpened,title:'Content Studio',panelId:'content_studio',width:380,persistKey:'ve_content_pos',onClose:()=>requestStudioClose('content_studio'),children:h(LazyStudio,{name:'ContentStudioSub',
        onClose: () => requestStudioClose('content_studio'),
        flash
      })}),

      renderStandaloneTool({visible:!nativeMediaPageActive && !isToolDisabledNow('media_studio'),open:mediaStudioOpen,hasOpened:mediaStudioHasOpened,title:'Media Studio',panelId:'media_studio',width:420,persistKey:'ve_media_pos',onClose:closeMediaStudio,children:h('div',{class:'ve-bricks-media-bridge'+(mediaTargetRef.current?' media-modal':'')},
        h(LazyStudio,{name:'MediaStudioSub',
          onClose: closeMediaStudio,
          flash,
          picking: !!mediaTargetRef.current,
          onInsertMedia: insertMediaIntoRememberedControl,
          initialFilter: mediaStudioInitialFilter
        })
      )}),

      renderStandaloneTool({visible:!isToolDisabledNow('font_manager'),open:fontManagerOpen,hasOpened:fontManagerHasOpened,title:'Font Manager',panelId:'font_manager',width:468,persistKey:'ve_font_manager_pos',onClose:()=>requestStudioClose('font_manager'),children:h(LazyStudio,{name:'FontManagerStudio',flash})}),

      renderStandaloneTool({visible:!isToolDisabledNow('plugin_studio'),open:pluginStudioOpen,hasOpened:pluginStudioHasOpened,title:'Plugin Studio',panelId:'plugin_studio',width:420,persistKey:'ve_plugin_pos',onClose:()=>requestStudioClose('plugin_studio'),children:h(LazyStudio,{name:'PluginStudioSub',
        flash
      })}),
      renderStandaloneTool({visible:!isToolDisabledNow('bricks_settings'),open:bricksSettingsOpen,hasOpened:bricksSettingsHasOpened,title:'Bricks Settings',panelId:'bricks_settings',width:468,persistKey:'ve_bricks_settings_pos',onClose:()=>requestStudioClose('bricks_settings'),children:h(BricksSettingsSub, {
        flash
      })}),
      renderStandaloneTool({visible:!isToolDisabledNow('theme_styles'),open:themeStylesOpen,hasOpened:themeStylesHasOpened,title:'Theme Styles',panelId:'theme_styles',width:468,persistKey:'ve_theme_styles_pos',onClose:()=>requestStudioClose('theme_styles'),children:h(BricksThemeStylesSub,{flash,open:themeStylesOpen})})
  );
}

function showBootFallback(err){
  try{
    if(document.getElementById('ve-boot-fallback'))return;
    const b=document.createElement('button');
    b.id='ve-boot-fallback';
    b.type='button';
    b.textContent='MV';
    b.title=err?'Mimam’s Var could not fully load. Click to retry/open.':'Open Mimam’s Var';
    b.style.cssText='position:fixed;right:16px;bottom:16px;z-index:120050;width:38px;height:38px;border-radius:10px;border:1px solid #baf400;background:#1f1f1f;color:#baf400;font:700 11px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;cursor:pointer;box-shadow:0 8px 22px rgba(0,0,0,.35)';
    b.addEventListener('click',()=>{if(window.veToggleVariables)window.veToggleVariables();else window.location.reload();});
    document.body.appendChild(b);
    if(err)console.error('Mimam’s Var failed to boot',err);
  }catch(e){}
}

/* -- The studios are fetched on first open ------------------------------
   538 KB of Content Studio, Media Studio, Font Manager and Plugin Studio,
   none of which is needed to draw the tool rail that most wp-admin pages
   ever show. They live in assets/js/studios.js now.

   They can no longer see this closure, so what they use is handed over
   explicitly. check-v1-3-519-lazy-studios.js fails if studios.js reaches for
   anything not on this list, because a missing helper does not break the
   build - it breaks the studio, in front of the owner. */
window.__VE=window.__VE||{};
window.__VE.shared={h,render,Fragment,useState,useEffect,useRef,useMemo,useCallback,useLayoutEffect,CFG,api,ph,restEndpoint,COLL_ICONS,CheckControl,ConfirmModal,ContentMediaPicker,MVInlineColorPicker,MediaCtxMenu,MediaVideoPlayer,MediaVideoThumbnail,RichContentEditor,SelectMenu,ToggleControl,VE_MEDIA_CACHE,VE_MEDIA_CACHE_KEY,clrAlpha,clrToHex,collectFolderMediaIds,contentTitleSlug,defaultContentImportMapping,ensureFontToolsRuntime,fontNameText,fontWeightLabel,headerSafeFilename,hexWithAlpha,keepInsideBounds,loadMediaCollapsedPaths,parseContentImportText,persistMediaCollapsedPaths,persistUserPreference,prefetchMediaLibrary,publishMediaCache,subscribeMediaCache,MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED};
let veStudiosPromise=null;
function loadStudios(){
  if(window.__VE.studios)return Promise.resolve(window.__VE.studios);
  if(veStudiosPromise)return veStudiosPromise;
  veStudiosPromise=new Promise(function(resolve,reject){
    const base=(CFG&&CFG.assetUrl)||'';
    if(!base){reject(new Error('assetUrl missing, cannot locate studios.js'));return;}
    const el=document.createElement('script');
    el.src=base+'js/studios.js?ver='+encodeURIComponent((CFG&&CFG.version)||'');
    el.async=true;
    el.onload=function(){
      if(window.__VE.studios)resolve(window.__VE.studios);
      else{veStudiosPromise=null;reject(new Error('studios.js loaded but registered nothing'));}
    };
    el.onerror=function(){veStudiosPromise=null;reject(new Error('studios.js could not be fetched'));};
    (document.head||document.documentElement).appendChild(el);
  });
  return veStudiosPromise;
}
/* Opening the rail is a fair bet a studio is next, so the fetch starts then.
   It is only ever a head start: nothing waits on it and a failure is retried
   by LazyStudio, which is the thing that actually needs the code. */
function prefetchStudios(){try{loadStudios().catch(function(){});}catch(e){}}
function LazyStudio(props){
  const name=props.name;
  const loaded=window.__VE.studios&&window.__VE.studios[name];
  const [,bump]=useState(0);
  const [err,setErr]=useState('');
  useEffect(function(){
    if(loaded)return undefined;
    let alive=true;
    loadStudios().then(function(){if(alive)bump(function(n){return n+1;});})
      .catch(function(e){if(alive)setErr((e&&e.message)||'Could not load');});
    return function(){alive=false;};
  },[name,loaded]);
  if(err)return h('div',{class:'ve-studio-lazy ve-studio-lazy-error'},
    h('strong',null,'This studio could not load'),
    h('span',null,err),
    h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',onClick:function(){
      veStudiosPromise=null;setErr('');bump(function(n){return n+1;});}},'Try again'));
  if(!loaded)return h('div',{class:'ve-studio-lazy'},
    h('span',{class:'ve-media-progress-spinner'}),h('span',null,'Opening'+String.fromCharCode(8230)));
  const rest={};
  Object.keys(props).forEach(function(k){if(k!=='name')rest[k]=props[k];});
  return h(loaded,rest);
}

function mt(){
  try{
    // The panel stylesheet is enqueued as assets/css/panel.css since v1.3.517
    // rather than injected from a string here. cssVarSheetIsProductUi still
    // recognises it — it matches on an href containing /variable-engine/assets/
    // as well as on the old element id, so MV's own tokens stay out of the
    // variable suggestions either way.
    if(!document.getElementById('ve-studio-ui-styles')&&!document.querySelector('link[href*="/variable-engine/assets/css/panel.css"]')){
      console.warn('Mimam’s Var: panel.css did not load; the panel will render unstyled.');
    }
    const r=document.createElement('div');r.id='ve-panel-root';document.body.appendChild(r);render(h(Panel),r);wireGsapHover(r);if(MODE==='builder')setTimeout(syncBricksVariableConsumers,0);
    setTimeout(()=>{if(!document.querySelector('#ve-panel-root .ve-fab-wrap')&&!window.veToggleVariables)showBootFallback();},1200);
    // Fetch the studios once the page has gone quiet, rather than waiting for a
    // click. The point of splitting them out was never "never download this" —
    // it was "do not make every admin page parse 1.8 MB before it can paint".
    // Idle time is after the paint, so the page stays fast and the studio is
    // already there when it is opened. Without this, first open waits on a
    // 541 KB fetch and shows a spinner, which is a worse trade than the one we
    // were making before.
    if(typeof requestIdleCallback==='function')requestIdleCallback(prefetchStudios,{timeout:4000});
    else setTimeout(prefetchStudios,2000);
  }catch(e){showBootFallback(e);}
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mt);else mt();
})();
