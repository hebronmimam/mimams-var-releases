/**
 * MV shortcut registry — the one place a key is decided.
 *
 * Approved mock: docs/mocks/tools/2026-08-10-double-letter-shortcuts.html
 * Checklist 29 / backlog 49, ref B32.
 *
 * Before this, every shortcut tested event.altKey and friends inline at the
 * point it fired, so a key could not be rebound without editing the handler.
 * Three files held rebindable keys (the mock counted six, but the other three
 * were guard clauses inside the Bar's own input — "if any modifier is held,
 * this is not plain typing" — which are not shortcuts and stay where they are).
 *
 * Two kinds of shortcut live here:
 *
 *   modifier — Ctrl/Alt/Shift/Meta plus a key, matched in one shot.
 *   chord    — two plain keys in sequence: the same letter twice (R R) or a
 *              leader followed by a letter (G V).
 *
 * Claiming a letter. Enabling a chord on a letter means MV takes that letter:
 * the lone press is swallowed so Bricks cannot act on it, and only the chord
 * fires. That is what lets a chord start on a letter Bricks already uses
 * without MV having to hold the keypress and replay it, which would put
 * latency on every key in the builder.
 */
(function () {
  'use strict';

  if (window.MVShortcuts) return;

  var STORE_KEY = 'mvShortcuts';

  /* ── what exists ─────────────────────────────────────────────────────────
     scope:   'builder' | 'admin' | 'both' — where the shortcut may fire.
     enabled: the out-of-the-box set is R R, U U and ? ?, matching what MV
              shipped before this page existed plus the cheat sheet. Every
              other chord is present and rebindable but starts off, so a fresh
              install claims no letter the owner did not ask for. */
  var DEFAULTS = [
    { id: 'bar.open', label: 'Open Mimam’s Bar', group: 'Panels',
      type: 'modifier', keys: { ctrl: true, alt: false, shift: false, meta: false, key: 'k' },
      scope: 'both', enabled: true },
    { id: 'element.deselect', label: 'Deselect element', group: 'Selection',
      type: 'modifier', keys: { ctrl: false, alt: false, shift: false, meta: false, key: 'Escape' },
      scope: 'builder', enabled: true },
    { id: 'editor.save', label: 'Save', group: 'Editing',
      type: 'modifier', keys: { ctrl: true, alt: false, shift: false, meta: false, key: 's' },
      scope: 'both', enabled: true },
    { id: 'editor.suggest', label: 'Suggest a variable', group: 'Editing',
      type: 'modifier', keys: { ctrl: true, alt: false, shift: false, meta: false, key: ' ' },
      scope: 'both', enabled: true },
    { id: 'editor.duplicateLine', label: 'Duplicate line', group: 'Editing',
      type: 'modifier', keys: { ctrl: true, alt: false, shift: false, meta: false, key: 'd' },
      scope: 'both', enabled: true },

    { id: 'element.rename', label: 'Rename', group: 'Selection',
      type: 'chord', chord: 'same', keys: { key: 'r' }, scope: 'builder', enabled: true },
    { id: 'component.unlink', label: 'Unlink component', group: 'Selection',
      type: 'chord', chord: 'same', keys: { key: 'u' }, scope: 'builder', enabled: true },
    { id: 'help.cheatsheet', label: 'Shortcut cheat sheet', group: 'Help',
      type: 'chord', chord: 'same', keys: { key: '?' }, scope: 'both', enabled: true },

    { id: 'goto.variables', label: 'Variables', group: 'Go to',
      type: 'chord', chord: 'leader', keys: { key: 'v' }, scope: 'both', enabled: false },
    { id: 'goto.settings', label: 'Settings', group: 'Go to',
      type: 'chord', chord: 'leader', keys: { key: 's' }, scope: 'both', enabled: false },
    { id: 'goto.cssStudio', label: 'CSS Studio', group: 'Go to',
      type: 'chord', chord: 'leader', keys: { key: 'c' }, scope: 'both', enabled: false },
    { id: 'goto.contentStudio', label: 'Content Studio', group: 'Go to',
      type: 'chord', chord: 'leader', keys: { key: 'n' }, scope: 'both', enabled: false },
    { id: 'goto.mediaStudio', label: 'Media Studio', group: 'Go to',
      type: 'chord', chord: 'leader', keys: { key: 'm' }, scope: 'both', enabled: false }
  ];

  var PREFS = { leader: 'g', window: 400 };

  /* Letters Bricks already answers to. Not a gate — the Shortcuts page shows
     the warning while you choose, and enabling anyway takes the letter. A
     vetted "safe list" goes stale the moment Bricks adds a shortcut, and it
     rules out the mnemonic letters worth having. */
  var BRICKS_LETTERS = {
    d: 'Bricks duplicates the element',
    c: 'Bricks copies the element',
    v: 'Bricks pastes',
    x: 'Bricks cuts',
    z: 'Bricks undoes',
    s: 'Bricks saves',
    a: 'Bricks selects all',
    g: 'Bricks groups the selection',
    h: 'Bricks hides the element'
  };

  function clone(value) { return JSON.parse(JSON.stringify(value)); }

  function readStore() {
    try {
      var raw = window.localStorage ? window.localStorage.getItem(STORE_KEY) : '';
      var parsed = raw ? JSON.parse(raw) : {};
      return parsed && typeof parsed === 'object' ? parsed : {};
    } catch (e) { return {}; }
  }

  function writeStore(value) {
    try {
      if (window.localStorage) window.localStorage.setItem(STORE_KEY, JSON.stringify(value));
    } catch (e) {}
    mirrorToProfile(value);
  }

  /* localStorage is the live copy every surface reads without a round trip;
     user meta is what survives a new browser. Best effort on purpose — a
     failed mirror must never stop a shortcut from taking effect. */
  function mirrorToProfile(value) {
    try {
      var cfg = window.vePanel;
      if (!cfg || !cfg.apiRoot || !cfg.nonce || !window.fetch) return;
      window.fetch(cfg.apiRoot + 'variable-engine/v1/user-preferences', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.nonce },
        body: JSON.stringify({ preferences: { mvShortcuts: value } })
      })['catch'](function () {});
    } catch (e) {}
  }

  function currentSurface() {
    try {
      if (window.baqaConfig && window.baqaConfig.surface) {
        return window.baqaConfig.surface === 'builder' ? 'builder' : 'admin';
      }
      if (window.vePanel && window.vePanel.mode) {
        return window.vePanel.mode === 'builder' ? 'builder' : 'admin';
      }
    } catch (e) {}
    return 'admin';
  }

  function resolved() {
    var overrides = readStore();
    var prefs = overrides.__prefs || {};
    return {
      leader: String(prefs.leader || PREFS.leader).toLowerCase(),
      window: Math.max(150, Math.min(1200, Number(prefs.window) || PREFS.window)),
      list: DEFAULTS.map(function (def) {
        var over = overrides[def.id] || {};
        var out = clone(def);
        if (over.keys) out.keys = over.keys;
        if (typeof over.enabled === 'boolean') out.enabled = over.enabled;
        if (over.scope) out.scope = over.scope;
        out.customised = !!(over.keys || over.scope || typeof over.enabled === 'boolean');
        return out;
      })
    };
  }

  function find(id) {
    var list = resolved().list;
    for (var i = 0; i < list.length; i++) if (list[i].id === id) return list[i];
    return null;
  }

  function allowedHere(item, surface) {
    if (!item || !item.enabled) return false;
    var where = surface || currentSurface();
    return item.scope === 'both' || item.scope === where;
  }

  /* ── matching ───────────────────────────────────────────────────────────── */

  function matches(id, event) {
    var item = find(id);
    if (!item || item.type !== 'modifier' || !allowedHere(item)) return false;
    var k = item.keys || {};
    return (!!k.ctrl === !!event.ctrlKey)
      && (!!k.alt === !!event.altKey)
      && (!!k.shift === !!event.shiftKey)
      && (!!k.meta === !!event.metaKey)
      && String(event.key || '').toLowerCase() === String(k.key || '').toLowerCase();
  }

  /* Every letter a chord may begin with, so a lone press can be swallowed. */
  function claimedLetters() {
    var state = resolved();
    var claimed = {};
    var needsLeader = false;
    state.list.forEach(function (item) {
      if (item.type !== 'chord' || !allowedHere(item)) return;
      if (item.chord === 'same') claimed[String(item.keys.key).toLowerCase()] = item.id;
      else needsLeader = true;
    });
    if (needsLeader) claimed[state.leader] = '__leader__';
    return claimed;
  }

  /* ── the chord state machine ─────────────────────────────────────────────
     Returns one of:
       null                       nothing to do, let the key through
       {fired:id}                 a chord completed
       {armed:key}                first key accepted, waiting for the second
       {rejected:key}             after the leader, a letter that means nothing
       {swallow:true}             claimed letter, nothing else to report

     A mistyped chord behaves differently before and after the leader, which is
     the prototype's behaviour: a lone letter is simply forgotten and the next
     key starts fresh, but once the leader is down you are unambiguously
     mid-chord, so a dead letter is rejected visibly. This was the one question
     in the mock left unanswered at approval; flagged rather than assumed. */
  var pending = null;
  var listeners = { arm: [], change: [] };

  function emit(kind, payload) {
    (listeners[kind] || []).forEach(function (fn) {
      try { fn(payload); } catch (e) {}
    });
  }

  function clearPending() {
    if (pending) { pending = null; emit('arm', null); }
  }

  function handleKey(event) {
    if (event.ctrlKey || event.metaKey || event.altKey) { clearPending(); return null; }
    var raw = String(event.key || '');
    if (raw.length !== 1 && raw !== '?') { clearPending(); return null; }

    var state = resolved();
    var key = raw.toLowerCase();
    var now = Date.now();

    if (pending && (now - pending.at) > state.window) pending = null;

    if (pending) {
      var was = pending.key;
      pending = null;
      emit('arm', null);

      if (was === state.leader) {
        var hit = null;
        state.list.forEach(function (item) {
          if (item.type === 'chord' && item.chord === 'leader'
            && allowedHere(item) && String(item.keys.key).toLowerCase() === key) hit = item.id;
        });
        if (hit) return { fired: hit };
        return { rejected: key };
      }

      if (was === key) {
        var same = null;
        state.list.forEach(function (item) {
          if (item.type === 'chord' && item.chord === 'same'
            && allowedHere(item) && String(item.keys.key).toLowerCase() === key) same = item.id;
        });
        if (same) return { fired: same };
      }
      // Not a chord. Fall through so this key can arm on its own account.
    }

    var claimed = claimedLetters();
    if (Object.prototype.hasOwnProperty.call(claimed, key)) {
      pending = { key: key, at: now };
      emit('arm', { key: raw, leader: key === state.leader });
      return { armed: raw };
    }
    return null;
  }

  window.MVShortcuts = {
    DEFAULTS: DEFAULTS,
    BRICKS_LETTERS: BRICKS_LETTERS,

    all: function () { return resolved().list; },
    prefs: function () { var s = resolved(); return { leader: s.leader, window: s.window }; },
    get: find,
    surface: currentSurface,
    allowedHere: function (id) { return allowedHere(find(id)); },
    isEnabled: function (id) { var i = find(id); return !!(i && i.enabled); },

    set: function (id, patch) {
      var store = readStore();
      store[id] = Object.assign({}, store[id] || {}, patch || {});
      writeStore(store);
      emit('change', id);
    },
    setPrefs: function (patch) {
      var store = readStore();
      store.__prefs = Object.assign({}, store.__prefs || {}, patch || {});
      writeStore(store);
      emit('change', '__prefs');
    },
    reset: function (id) {
      var store = readStore();
      delete store[id];
      writeStore(store);
      emit('change', id);
    },
    resetAll: function () { writeStore({}); emit('change', null); },

    matches: matches,
    handleKey: handleKey,
    clearPending: clearPending,
    claimedLetters: claimedLetters,

    /* A chord's own letter must not also reach Bricks. Handlers ask this
       before deciding whether to preventDefault on a lone press. */
    isClaimed: function (key) {
      return Object.prototype.hasOwnProperty.call(
        claimedLetters(), String(key || '').toLowerCase());
    },

    conflict: function (item) {
      if (!item || item.type !== 'chord') return '';
      return BRICKS_LETTERS[String(item.keys.key).toLowerCase()] || '';
    },

    describe: function (item) {
      if (!item) return '';
      if (item.type === 'chord') {
        var letter = String(item.keys.key).toUpperCase();
        if (item.chord === 'same') return letter + ' ' + letter;
        return resolved().leader.toUpperCase() + ' ' + letter;
      }
      var k = item.keys || {};
      var parts = [];
      if (k.ctrl) parts.push('Ctrl');
      if (k.meta) parts.push('Cmd');
      if (k.alt) parts.push('Alt');
      if (k.shift) parts.push('Shift');
      parts.push(k.key === ' ' ? 'Space' : String(k.key).length === 1
        ? String(k.key).toUpperCase() : String(k.key));
      return parts.join(' + ');
    },

    onArm: function (fn) { listeners.arm.push(fn); },
    onChange: function (fn) { listeners.change.push(fn); }
  };
})();
