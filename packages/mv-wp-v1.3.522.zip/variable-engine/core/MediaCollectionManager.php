<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * WordPress-backed Media Studio collections.
 *
 * Collections intentionally live as a dedicated attachment taxonomy instead of
 * browser/localStorage data. This makes them persistent, queryable, exportable,
 * and usable by shortcode/Bricks loops while still behaving like flexible tags.
 */
class MediaCollectionManager {

    public const TAXONOMY = 'mv_media_collection';
    public const META_ICON = '_mv_media_collection_icon';
    public const META_ORDER = '_mv_media_collection_order';
    public const META_PATH_KEY = '_mv_media_collection_path_key';
    public const META_LOCKED = '_mv_media_collection_locked';
    public const META_STARRED = '_mv_media_collection_starred';
    public const META_COLOR = '_mv_media_collection_color';

    public function register(): void {
        add_action( 'init', [ $this, 'register_taxonomy' ], 5 );
        add_shortcode( 'mv_media_collection', [ $this, 'shortcode' ] );
        add_filter( 'bricks/query/run', [ $this, 'run_bricks_query' ], 10, 2 );
        add_filter( 'bricks/query/loop_object_type', [ $this, 'bricks_loop_object_type' ], 10, 3 );

        // Cache clearing hooks
        add_action( 'created_' . self::TAXONOMY, [ $this, 'clear_cache' ] );
        add_action( 'edited_' . self::TAXONOMY, [ $this, 'clear_cache' ] );
        add_action( 'delete_' . self::TAXONOMY, [ $this, 'clear_cache' ] );
        add_action( 'set_object_terms', [ $this, 'on_set_object_terms' ], 10, 4 );
        add_filter( 'upload_mimes', [ $this, 'allow_font_uploads' ] );
        add_filter( 'wp_check_filetype_and_ext', [ $this, 'resolve_font_filetype' ], 10, 4 );
    }

    public function register_taxonomy(): void {
        if ( taxonomy_exists( self::TAXONOMY ) ) {
            return;
        }

        register_taxonomy( self::TAXONOMY, [ 'attachment' ], [
            'labels'       => [
                'name'          => __( 'MV Media Collections', 'variable-engine' ),
                'singular_name' => __( 'MV Media Collection', 'variable-engine' ),
            ],
            'public'              => false,
            'publicly_queryable'  => false,
            'show_ui'             => false,
            'show_in_menu'        => false,
            'show_admin_column'   => false,
            'show_in_nav_menus'   => false,
            'show_tagcloud'       => false,
            'show_in_rest'        => true,
            'hierarchical'        => true,
            'rewrite'             => false,
            'query_var'           => false,
            'capabilities' => [
                'manage_terms' => 'upload_files',
                'edit_terms'   => 'upload_files',
                'delete_terms' => 'upload_files',
                'assign_terms' => 'upload_files',
            ],
        ] );
    }

    /**
     * Fonts in the media library.
     *
     * WordPress does not list any font type in get_allowed_mime_types(): core
     * permits WOFF2 only inside the Font Library's own upload path, so a
     * .woff2/.ttf/.otf dropped on Media Studio is rejected by
     * wp_check_filetype_and_ext() before it ever reaches an attachment. Media
     * Studio ships a Fonts collection, so this is a gap rather than a policy.
     *
     * Scope is deliberately narrow. The types are opened only for a request
     * that carries Media Studio's own header and comes from a user who may
     * already upload files, so nothing changes for the classic media modal,
     * XML-RPC, or any other plugin's upload path. EOT and SVG fonts are left
     * out: SVG is a live XSS vector and neither is worth the exposure.
     */
    public function allow_font_uploads( array $mimes ): array {
        if ( ! $this->is_media_studio_upload() ) {
            return $mimes;
        }
        foreach ( self::font_mime_types() as $ext => $type ) {
            if ( ! isset( $mimes[ $ext ] ) ) {
                $mimes[ $ext ] = $type;
            }
        }
        return $mimes;
    }

    /**
     * Font files have no reliable magic-number check in WordPress, so
     * wp_check_filetype_and_ext() blanks the type it just resolved from the
     * extension. Restore it, but only for the same narrow scope, and only
     * after confirming the file really starts with that format's signature.
     */
    public function resolve_font_filetype( array $checked, $file, $filename, $mimes ) {
        if ( ! empty( $checked['type'] ) || ! $this->is_media_studio_upload() ) {
            return $checked;
        }
        $ext = strtolower( (string) pathinfo( (string) $filename, PATHINFO_EXTENSION ) );
        $fonts = self::font_mime_types();
        if ( ! isset( $fonts[ $ext ] ) || ! $this->has_font_signature( (string) $file, $ext ) ) {
            return $checked;
        }
        $checked['ext']  = $ext;
        $checked['type'] = $fonts[ $ext ];
        return $checked;
    }

    private static function font_mime_types(): array {
        return [
            'woff2' => 'font/woff2',
            'woff'  => 'font/woff',
            'ttf'   => 'font/ttf',
            'otf'   => 'font/otf',
        ];
    }

    private function is_media_studio_upload(): bool {
        if ( empty( $_SERVER['HTTP_X_MV_MEDIA_UPLOAD'] ) ) {
            return false;
        }
        return current_user_can( 'upload_files' );
    }

    /**
     * First four bytes, per the OpenType and WOFF specifications. This is what
     * stops the header alone from turning "payload.php" renamed to ".ttf" into
     * an accepted upload.
     */
    private function has_font_signature( string $file, string $ext ): bool {
        if ( '' === $file || ! is_readable( $file ) ) {
            return false;
        }
        $handle = fopen( $file, 'rb' );
        if ( ! $handle ) {
            return false;
        }
        $head = fread( $handle, 4 );
        fclose( $handle );
        if ( ! is_string( $head ) || 4 !== strlen( $head ) ) {
            return false;
        }
        $signatures = [
            'woff2' => [ 'wOF2' ],
            'woff'  => [ 'wOFF' ],
            'ttf'   => [ "\x00\x01\x00\x00", 'true', 'ttcf' ],
            'otf'   => [ 'OTTO', "\x00\x01\x00\x00" ],
        ];
        return in_array( $head, $signatures[ $ext ] ?? [], true );
    }

    public function sanitize_key_from_label( string $label ): string {
        $label = trim( wp_strip_all_tags( $label ) );
        $parts = preg_split( '#\s*/\s*#', $label );
        $parts = array_values( array_filter( array_map( static function ( $part ) {
            $part = sanitize_title( $part );
            return $part ?: '';
        }, is_array( $parts ) ? $parts : [] ) ) );
        return implode( '/', $parts );
    }

    public function sanitize_key( string $key ): string {
        $key = trim( strtolower( $key ) );
        $key = str_replace( '\\', '/', $key );
        $key = preg_replace( '#\s*/\s*#', '/', $key );
        $key = preg_replace( '#[^a-z0-9/_-]+#', '_', $key );
        $key = preg_replace( '#_+#', '_', $key );
        $key = trim( $key, '_/' );
        return $key;
    }

    public function slug_from_key( string $key ): string {
        $key = $this->sanitize_key( $key );
        $slug = str_replace( '/', '-', $key );
        return sanitize_title( $slug );
    }

    private function leaf_label( string $label ): string {
        $parts = preg_split( '#\s*/\s*#', trim( $label ) );
        $parts = array_values( array_filter( array_map( 'trim', is_array( $parts ) ? $parts : [] ) ) );
        return $parts ? (string) end( $parts ) : $label;
    }

    private function path_parts_from_label( string $label ): array {
        $parts = preg_split( '#\s*/\s*#', trim( wp_strip_all_tags( $label ) ) );
        return array_values( array_filter( array_map( 'trim', is_array( $parts ) ? $parts : [] ) ) );
    }

    public function get_term_by_key( string $key ) {
        $key = $this->sanitize_key( $key );
        if ( '' === $key ) {
            return null;
        }
        $terms = get_terms( [
            'taxonomy'   => self::TAXONOMY,
            'hide_empty' => false,
            'meta_query' => [
                [
                    'key'   => self::META_PATH_KEY,
                    'value' => $key,
                ],
            ],
            'number'     => 1,
        ] );
        if ( ! is_wp_error( $terms ) && ! empty( $terms ) ) {
            return $terms[0];
        }
        $term = get_term_by( 'slug', $this->slug_from_key( $key ), self::TAXONOMY );
        return $term ?: null;
    }

    public function get_term_by_any( $value ) {
        if ( is_numeric( $value ) ) {
            $term = get_term( absint( $value ), self::TAXONOMY );
            return ( $term && ! is_wp_error( $term ) ) ? $term : null;
        }
        $value = trim( (string) $value );
        if ( '' === $value ) {
            return null;
        }
        $term = $this->get_term_by_key( $value );
        if ( $term ) {
            return $term;
        }
        $term = get_term_by( 'slug', sanitize_title( $value ), self::TAXONOMY );
        return $term ?: null;
    }

    public function ensure_collection( string $label, array $entry = [] ) {
        $parts = $this->path_parts_from_label( $label );
        if ( empty( $parts ) ) {
            return new \WP_Error( 'mv_empty_collection_label', __( 'Collection label is required.', 'variable-engine' ) );
        }

        $parent = 0;
        $path_parts = [];
        $term = null;
        foreach ( $parts as $part ) {
            $path_parts[] = $part;
            $path_label = implode( ' / ', $path_parts );
            $path_key = $this->sanitize_key_from_label( $path_label );
            $slug = $this->slug_from_key( $path_key );
            $existing = $this->get_term_by_key( $path_key );

            if ( $existing ) {
                $term = $existing;
                if ( (int) $term->parent !== (int) $parent ) {
                    wp_update_term( (int) $term->term_id, self::TAXONOMY, [ 'parent' => $parent ] );
                }
            } else {
                $created = wp_insert_term( $part, self::TAXONOMY, [
                    'slug'   => $slug,
                    'parent' => $parent,
                ] );
                if ( is_wp_error( $created ) ) {
                    return $created;
                }
                $term = get_term( (int) $created['term_id'], self::TAXONOMY );
            }

            if ( $term && ! is_wp_error( $term ) ) {
                update_term_meta( (int) $term->term_id, self::META_PATH_KEY, $path_key );
                if ( isset( $entry['order'] ) ) {
                    update_term_meta( (int) $term->term_id, self::META_ORDER, absint( $entry['order'] ) );
                }
                $parent = (int) $term->term_id;
            }
        }

        if ( $term && ! is_wp_error( $term ) ) {
            $leaf = $this->leaf_label( $label );
            $args = [ 'name' => $leaf ?: $term->name ];
            if ( ! empty( $entry['slug'] ) ) {
                $args['slug'] = sanitize_title( (string) $entry['slug'] );
            }
            wp_update_term( (int) $term->term_id, self::TAXONOMY, $args );
            $icon = isset( $entry['icon'] ) ? sanitize_key( (string) $entry['icon'] ) : 'folder';
            update_term_meta( (int) $term->term_id, self::META_ICON, $icon ?: 'folder' );
            update_term_meta( (int) $term->term_id, self::META_PATH_KEY, $this->sanitize_key_from_label( $label ) );
            if ( array_key_exists( 'locked', $entry ) ) {
                update_term_meta( (int) $term->term_id, self::META_LOCKED, ! empty( $entry['locked'] ) ? '1' : '0' );
            }
            if ( array_key_exists( 'starred', $entry ) ) {
                update_term_meta( (int) $term->term_id, self::META_STARRED, ! empty( $entry['starred'] ) ? '1' : '0' );
            }
            if ( array_key_exists( 'color', $entry ) ) {
                $raw_color = strtolower( trim( sanitize_text_field( (string) $entry['color'] ) ) );
                // Six- or eight-digit HEX, or a CSS variable reference so a collection
                // colour can follow an MV token instead of a frozen literal.
                $color = preg_match( '/^#[0-9a-f]{6}(?:[0-9a-f]{2})?$/', $raw_color )
                    || preg_match( '/^var\(\s*--[a-z0-9_-]+\s*\)$/i', $raw_color )
                    ? $raw_color : '';
                update_term_meta( (int) $term->term_id, self::META_COLOR, $color ?: '' );
            }
        }

        return $term;
    }

    public function list_collections(): array {
        $cached = get_transient( 've_media_collections_list' );
        if ( is_array( $cached ) && isset( $cached['collections'], $cached['map'] ) ) {
            return $cached;
        }

        $terms = get_terms( [
            'taxonomy'   => self::TAXONOMY,
            'hide_empty' => false,
            'orderby'    => 'meta_value_num',
            'meta_key'   => self::META_ORDER,
            'order'      => 'ASC',
        ] );
        if ( is_wp_error( $terms ) ) {
            return [ 'collections' => [], 'map' => [] ];
        }

        $by_id = [];
        foreach ( $terms as $term ) {
            $by_id[ (int) $term->term_id ] = $term;
        }

        $path_for = function ( $term ) use ( &$path_for, $by_id ) {
            $parts = [ $term->name ];
            $parent = (int) $term->parent;
            $guard = 0;
            while ( $parent && isset( $by_id[ $parent ] ) && $guard < 50 ) {
                array_unshift( $parts, $by_id[ $parent ]->name );
                $parent = (int) $by_id[ $parent ]->parent;
                $guard++;
            }
            return implode( ' / ', $parts );
        };

        $collections = [];
        $map = [];
        foreach ( $terms as $index => $term ) {
            $path_label = $path_for( $term );
            $path_key = (string) get_term_meta( (int) $term->term_id, self::META_PATH_KEY, true );
            if ( '' === $path_key ) {
                $path_key = $this->sanitize_key_from_label( $path_label );
                update_term_meta( (int) $term->term_id, self::META_PATH_KEY, $path_key );
            }
            $ids = $this->collection_attachment_ids( (int) $term->term_id, -1 );
            $collections[ $path_key ] = [
                'id'     => (int) $term->term_id,
                'ids'    => $ids,
                'icon'   => (string) ( get_term_meta( (int) $term->term_id, self::META_ICON, true ) ?: 'folder' ),
                'label'  => $path_label,
                'slug'   => $term->slug,
                'parent' => (int) $term->parent,
                'source'  => 'mv',
                'order'   => (int) ( get_term_meta( (int) $term->term_id, self::META_ORDER, true ) ?: $index ),
                'locked'  => '1' === (string) get_term_meta( (int) $term->term_id, self::META_LOCKED, true ),
                'starred' => '1' === (string) get_term_meta( (int) $term->term_id, self::META_STARRED, true ),
                'color'   => (string) get_term_meta( (int) $term->term_id, self::META_COLOR, true ),
                'count'   => count( $ids ),
            ];
            foreach ( $ids as $id ) {
                $map[ (string) $id ][] = $path_key;
            }
        }

        $result = [ 'collections' => $collections, 'map' => $map ];
        set_transient( 've_media_collections_list', $result, 12 * HOUR_IN_SECONDS );
        return $result;
    }

    public function collection_attachment_ids( int $term_id, int $limit = -1 ): array {
        $args = [
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => $limit,
            'fields'         => 'ids',
            'orderby'        => 'menu_order date',
            'order'          => 'DESC',
            'tax_query'      => [
                [
                    'taxonomy'         => self::TAXONOMY,
                    'field'            => 'term_id',
                    'terms'            => [ $term_id ],
                    'include_children' => false,
                ],
            ],
        ];
        $ids = get_posts( $args );
        return array_values( array_map( 'absint', is_array( $ids ) ? $ids : [] ) );
    }

    public function set_collection_items( int $term_id, array $attachment_ids ): void {
        $attachment_ids = array_values( array_unique( array_filter( array_map( 'absint', $attachment_ids ) ) ) );
        $current = $this->collection_attachment_ids( $term_id, -1 );
        $wanted = array_flip( $attachment_ids );
        $current_lookup = array_flip( $current );

        foreach ( $attachment_ids as $id ) {
            if ( get_post_type( $id ) !== 'attachment' ) {
                continue;
            }
            $terms = wp_get_object_terms( $id, self::TAXONOMY, [ 'fields' => 'ids' ] );
            if ( is_wp_error( $terms ) ) {
                $terms = [];
            }
            $terms[] = $term_id;
            wp_set_object_terms( $id, array_values( array_unique( array_map( 'absint', $terms ) ) ), self::TAXONOMY, false );
        }

        foreach ( $current as $id ) {
            if ( isset( $wanted[ $id ] ) ) {
                continue;
            }
            $terms = wp_get_object_terms( $id, self::TAXONOMY, [ 'fields' => 'ids' ] );
            if ( is_wp_error( $terms ) ) {
                continue;
            }
            $terms = array_values( array_filter( array_map( 'absint', $terms ), static function ( $existing ) use ( $term_id ) {
                return (int) $existing !== (int) $term_id;
            } ) );
            wp_set_object_terms( $id, $terms, self::TAXONOMY, false );
        }
    }

    public function assign_attachment( int $attachment_id, $collection, bool $checked ): bool {
        if ( get_post_type( $attachment_id ) !== 'attachment' ) {
            return false;
        }
        $term = $this->get_term_by_any( $collection );
        if ( ! $term ) {
            return false;
        }
        $terms = wp_get_object_terms( $attachment_id, self::TAXONOMY, [ 'fields' => 'ids' ] );
        if ( is_wp_error( $terms ) ) {
            $terms = [];
        }
        $term_id = (int) $term->term_id;
        if ( $checked ) {
            $terms[] = $term_id;
        } else {
            $terms = array_filter( $terms, static function ( $id ) use ( $term_id ) {
                return (int) $id !== $term_id;
            } );
        }
        wp_set_object_terms( $attachment_id, array_values( array_unique( array_map( 'absint', $terms ) ) ), self::TAXONOMY, false );
        return true;
    }

    public function sync_from_map( array $collection_map, bool $delete_missing = false ): array {
        $incoming = [];
        $order = 0;
        foreach ( $collection_map as $key => $entry ) {
            if ( ! is_array( $entry ) ) {
                $entry = [ 'ids' => is_array( $entry ) ? $entry : [] ];
            }
            $key = $this->sanitize_key( (string) $key );
            if ( '' === $key || 0 === strpos( $key, 'folder:' ) ) {
                continue;
            }
            $label = isset( $entry['label'] ) && '' !== trim( (string) $entry['label'] )
                ? sanitize_text_field( (string) $entry['label'] )
                : str_replace( '/', ' / ', str_replace( '_', ' ', $key ) );
            $entry['order'] = $order++;
            $term = $this->ensure_collection( $label, $entry );
            if ( is_wp_error( $term ) || ! $term ) {
                continue;
            }
            $path_key = (string) get_term_meta( (int) $term->term_id, self::META_PATH_KEY, true );
            if ( '' === $path_key ) {
                $path_key = $this->sanitize_key_from_label( $label );
            }
            $incoming[] = (int) $term->term_id;
            $this->set_collection_items( (int) $term->term_id, isset( $entry['ids'] ) && is_array( $entry['ids'] ) ? $entry['ids'] : [] );
        }

        if ( $delete_missing ) {
            $terms = get_terms( [ 'taxonomy' => self::TAXONOMY, 'hide_empty' => false ] );
            if ( ! is_wp_error( $terms ) ) {
                foreach ( $terms as $term ) {
                    if ( ! in_array( (int) $term->term_id, $incoming, true ) ) {
                        wp_delete_term( (int) $term->term_id, self::TAXONOMY );
                    }
                }
            }
        }

        return $this->list_collections();
    }

    public function query_items( array $args = [] ): array {
        $collection = $args['collection'] ?? ( $args['slug'] ?? ( $args['id'] ?? '' ) );
        $term = $this->get_term_by_any( $collection );
        if ( ! $term ) {
            return [];
        }
        $limit = isset( $args['limit'] ) ? (int) $args['limit'] : -1;
        $mime = isset( $args['mime'] ) ? sanitize_text_field( (string) $args['mime'] ) : '';
        $query_args = [
            'post_type'      => 'attachment',
            'post_status'    => 'inherit',
            'posts_per_page' => $limit,
            'orderby'        => in_array( (string) ( $args['orderby'] ?? 'menu_order date' ), [ 'menu_order date', 'date', 'title', 'menu_order', 'ID', 'rand' ], true ) ? (string) ( $args['orderby'] ?? 'menu_order date' ) : 'menu_order date',
            'order'          => strtoupper( (string) ( $args['order'] ?? 'DESC' ) ) === 'ASC' ? 'ASC' : 'DESC',
            'tax_query'      => [
                [
                    'taxonomy'         => self::TAXONOMY,
                    'field'            => 'term_id',
                    'terms'            => [ (int) $term->term_id ],
                    'include_children' => ! empty( $args['include_children'] ),
                ],
            ],
        ];
        if ( $mime ) {
            $query_args['post_mime_type'] = $mime;
        }
        return get_posts( $query_args );
    }

    public function shortcode( $atts ): string {
        $atts = shortcode_atts( [
            'id'               => '',
            'slug'             => '',
            'collection'       => '',
            'limit'            => 24,
            'layout'           => 'grid',
            'size'             => 'medium_large',
            'include_children' => 'false',
            'show_titles'      => 'false',
        ], is_array( $atts ) ? $atts : [], 'mv_media_collection' );

        $items = $this->query_items( [
            'collection'       => $atts['collection'] ?: ( $atts['slug'] ?: $atts['id'] ),
            'limit'            => (int) $atts['limit'],
            'include_children' => filter_var( $atts['include_children'], FILTER_VALIDATE_BOOLEAN ),
        ] );

        if ( empty( $items ) ) {
            return '<div class="mv-media-collection mv-media-collection--empty">No media found in this collection.</div>';
        }

        $layout = sanitize_html_class( (string) $atts['layout'] ?: 'grid' );
        $show_titles = filter_var( $atts['show_titles'], FILTER_VALIDATE_BOOLEAN );
        $out = '<div class="mv-media-collection mv-media-collection--' . esc_attr( $layout ) . '">';
        foreach ( $items as $post ) {
            $id = (int) $post->ID;
            $url = wp_get_attachment_url( $id );
            $title = get_the_title( $id );
            $alt = get_post_meta( $id, '_wp_attachment_image_alt', true );
            $mime = (string) get_post_mime_type( $id );
            $out .= '<figure class="mv-media-collection__item">';
            if ( 0 === strpos( $mime, 'image/' ) ) {
                $out .= wp_get_attachment_image( $id, sanitize_key( $atts['size'] ), false, [
                    'class' => 'mv-media-collection__image',
                    'alt'   => $alt ?: $title,
                ] );
            } elseif ( $url ) {
                $out .= '<a class="mv-media-collection__file" href="' . esc_url( $url ) . '">' . esc_html( $title ?: basename( $url ) ) . '</a>';
            }
            if ( $show_titles ) {
                $out .= '<figcaption class="mv-media-collection__caption">' . esc_html( $title ) . '</figcaption>';
            }
            $out .= '</figure>';
        }
        $out .= '</div>';
        return $out;
    }

    public function run_bricks_query( $result, $query ) {
        $object_type = method_exists( $query, 'object_type' ) ? $query->object_type : ( $query->object_type ?? '' );
        $settings = $query->settings['query'] ?? [];
        if ( 'mv_media_collection' !== $object_type && 'mv_media_collection' !== ( $settings['objectType'] ?? '' ) ) {
            return $result;
        }
        $collection = $settings['mvCollection'] ?? ( $settings['collection'] ?? ( $settings['collection_slug'] ?? ( $settings['slug'] ?? '' ) ) );
        return $this->query_items( [
            'collection'       => $collection,
            'limit'            => isset( $settings['posts_per_page'] ) ? (int) $settings['posts_per_page'] : -1,
            'include_children' => ! empty( $settings['include_children'] ),
        ] );
    }

    public function bricks_loop_object_type( $object_type, $object, $query_id ) {
        if ( $object instanceof \WP_Post && 'attachment' === $object->post_type ) {
            return 'post';
        }
        return $object_type;
    }

    public function clear_cache(): void {
        delete_transient( 've_media_collections_list' );
    }

    public function on_set_object_terms( $object_id, $terms, $tt_ids, $taxonomy ): void {
        if ( self::TAXONOMY === $taxonomy ) {
            $this->clear_cache();
        }
    }
}
