<?php
/**
 * Release webhook — turns update polling into a push.
 *
 * The manifest is cached for 6 hours (Updater::fetch_manifest), so a site can be
 * six hours behind a Dev release without knowing it. Shortening that TTL only
 * shortens the window; it cannot close it, because WordPress checks on a page
 * load and nothing tells it a release happened. This endpoint is the thing that
 * tells it: GitHub POSTs on push, the site clears its cache and re-reads the
 * manifest within seconds.
 *
 * Security. This route is deliberately public — GitHub has no WordPress cookie —
 * so the signature is the ONLY thing standing in front of it:
 *
 *   - it is inert until a secret exists (no secret, no endpoint)
 *   - it verifies GitHub's X-Hub-Signature-256 HMAC over the raw body
 *   - it compares in constant time with hash_equals
 *   - it never echoes the secret, the signature, or the body back
 *   - it does nothing but refresh a cache, so the worst a valid call can do is
 *     make the site fetch its own manifest
 *
 * The secret is read from the VE_RELEASE_WEBHOOK_SECRET constant first so it can
 * live in wp-config.php and stay out of the database entirely.
 *
 * @package VariableEngine
 */

namespace VE\Core;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class ReleaseWebhook {

	const OPTION = 've_release_webhook_secret';
	const RATE_KEY = 've_release_webhook_seen';

	public function register(): void {
		add_action( 'rest_api_init', [ $this, 'routes' ] );
	}

	/**
	 * The shared secret, or '' when none is configured.
	 */
	public static function secret(): string {
		if ( defined( 'VE_RELEASE_WEBHOOK_SECRET' ) && is_string( VE_RELEASE_WEBHOOK_SECRET ) ) {
			$constant = trim( (string) VE_RELEASE_WEBHOOK_SECRET );
			if ( '' !== $constant ) {
				return $constant;
			}
		}
		$stored = get_option( self::OPTION, '' );
		return is_string( $stored ) ? trim( $stored ) : '';
	}

	public static function is_enabled(): bool {
		return '' !== self::secret();
	}

	public function routes(): void {
		register_rest_route(
			'variable-engine/v1',
			'/release-ping',
			[
				'methods'             => 'POST',
				'callback'            => [ $this, 'handle' ],
				// Public by necessity; authorisation is the HMAC in verify().
				'permission_callback' => '__return_true',
			]
		);
	}

	public function handle( \WP_REST_Request $request ) {
		$secret = self::secret();
		if ( '' === $secret ) {
			// Not configured: behave as if the route does not exist rather than
			// advertising that it is here and unarmed.
			return new \WP_Error( 'rest_no_route', 'Not found.', [ 'status' => 404 ] );
		}

		$body = $request->get_body();
		if ( ! is_string( $body ) || '' === $body ) {
			return new \WP_Error( 've_webhook_empty', 'Empty payload.', [ 'status' => 400 ] );
		}

		// A body large enough to be a denial-of-service is not a release ping.
		if ( strlen( $body ) > 512000 ) {
			return new \WP_Error( 've_webhook_large', 'Payload too large.', [ 'status' => 413 ] );
		}

		if ( ! $this->verify( $request, $body, $secret ) ) {
			return new \WP_Error( 've_webhook_signature', 'Bad signature.', [ 'status' => 403 ] );
		}

		// GitHub's connectivity test fires before any release exists.
		$event = (string) $request->get_header( 'x-github-event' );
		if ( 'ping' === $event ) {
			return rest_ensure_response(
				[
					'ok'      => true,
					'action'  => 'ping',
					'message' => 'Release webhook is armed.',
				]
			);
		}

		// One refresh per 10 seconds. A push can deliver several events at once
		// and each would otherwise cost an outbound manifest fetch.
		$last = (int) get_transient( self::RATE_KEY );
		if ( $last && ( time() - $last ) < 10 ) {
			return rest_ensure_response(
				[
					'ok'      => true,
					'action'  => 'skipped',
					'message' => 'Refreshed moments ago.',
				]
			);
		}
		set_transient( self::RATE_KEY, time(), 60 );

		// check_now() clears every channel transient and force-fetches, bypassing
		// the CDN with a cache-busted URL. It is what the Check update button runs.
		$status = ( new Updater() )->check_now();

		if ( class_exists( '\VE\Core\Logger' ) && method_exists( '\VE\Core\Logger', 'info' ) ) {
			Logger::info(
				'Release webhook refreshed the update channel.',
				[
					'channel' => $status['update_channel'] ?? '',
					'latest'  => $status['latest_version'] ?? '',
				]
			);
		}

		return rest_ensure_response(
			[
				'ok'               => true,
				'action'           => 'refreshed',
				'update_channel'   => $status['update_channel'] ?? '',
				'current_version'  => $status['current_version'] ?? VE_VERSION,
				'latest_version'   => $status['latest_version'] ?? VE_VERSION,
				'update_available' => ! empty( $status['update_available'] ),
			]
		);
	}

	/**
	 * GitHub signs the raw body with HMAC-SHA256 and sends it as
	 * "sha256=<hex>". Compared with hash_equals so the comparison cannot be
	 * timed to recover the expected value one byte at a time.
	 */
	private function verify( \WP_REST_Request $request, string $body, string $secret ): bool {
		$sent = (string) $request->get_header( 'x-hub-signature-256' );
		if ( '' === $sent || 0 !== strpos( $sent, 'sha256=' ) ) {
			return false;
		}
		$expected = 'sha256=' . hash_hmac( 'sha256', $body, $secret );
		return hash_equals( $expected, $sent );
	}
}
