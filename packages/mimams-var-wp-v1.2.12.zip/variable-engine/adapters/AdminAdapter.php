<?php
namespace VE\Adapters;
defined('ABSPATH') || exit;

class AdminAdapter {
    public function __construct() {
        if (defined('VE_IS_BRICKS') && VE_IS_BRICKS) return;
        if (!is_admin()) return;
        add_action('admin_bar_menu', [$this, 'toolbar'], 999);
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
        add_action('admin_footer', [$this, 'footer']);
    }
    public function toolbar(\WP_Admin_Bar $b): void {
        if (!current_user_can('manage_options')) return;
        $icon = esc_url( VE_URL . 'assets/hebronmimam-logo-icon.png' );
        $b->add_node(['id'=>'ve-toggle','parent'=>'top-secondary','title'=>'<img class="ve-admin-logo" alt="" src="' . $icon . '"><span class="ab-label" style="font-size:11px;font-weight:600">MV</span>','href'=>'#','meta'=>['title'=>"Mimam's Var - WP (Alt+Z)"]]);
    }
    public function enqueue(): void {
        if (!current_user_can('manage_options')) return;
        wp_enqueue_style('ve-ph', 'https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2/src/duotone/style.css', [], '2');
        wp_enqueue_script('ve-p', 'https://cdn.jsdelivr.net/npm/preact@10/dist/preact.umd.js', [], '10', true);
        wp_enqueue_script('ve-ph', 'https://cdn.jsdelivr.net/npm/preact@10/hooks/dist/hooks.umd.js', ['ve-p'], '10', true);
        wp_enqueue_script('ve-gsap', 'https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js', [], '3.12.5', true);
        wp_enqueue_script('ve-app', VE_URL.'assets/js/builder-panel.js', ['ve-p','ve-ph','ve-gsap'], VE_VERSION.'.'.filemtime(VE_DIR.'assets/js/builder-panel.js'), true);
        wp_localize_script('ve-app', 'vePanel', ['apiRoot'=>esc_url_raw(rest_url()),'nonce'=>wp_create_nonce('wp_rest'),'version'=>VE_VERSION,'mode'=>'admin','logoUrl'=>esc_url_raw(VE_URL.'assets/hebronmimam-logo-icon.png')]);
    }
    public function footer(): void {
        if (!current_user_can('manage_options')) return;
        echo '<script>document.addEventListener("DOMContentLoaded",function(){var b=document.getElementById("wp-admin-bar-ve-toggle");if(b)b.addEventListener("click",function(e){e.preventDefault();window.dispatchEvent(new Event("ve-toggle-panel"))})});</script>';
        echo '<style>#wp-admin-bar-ve-toggle .ab-item{display:flex!important;align-items:center!important;justify-content:center!important;gap:6px!important;height:32px!important;line-height:32px!important;padding:0 8px!important}#wp-admin-bar-ve-toggle .ve-admin-logo{width:18px!important;height:18px!important;object-fit:contain!important;border-radius:4px!important;display:block!important;margin:0!important;position:relative!important;top:0!important;transform:none!important}#wp-admin-bar-ve-toggle .ab-label{display:block!important;line-height:1!important;padding:0!important;margin:0!important}#wp-admin-bar-ve-toggle:hover .ab-label{color:#baf400!important}</style>';
    }
}
