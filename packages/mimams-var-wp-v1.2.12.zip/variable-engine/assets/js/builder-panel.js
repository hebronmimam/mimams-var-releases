﻿(function(){
'use strict';
if(window.self!==window.top&&document.querySelector('.brx-body'))return;
const{h,render}=window.preact;const{useState,useEffect,useRef,useMemo,useCallback}=window.preactHooks;
const CFG=window.vePanel||{};const MODE=CFG.mode||'admin';

const api={
f:async(p,o={})=>{
  const r=await fetch((CFG.apiRoot||'/wp-json/')+p,{credentials:'same-origin',...o,headers:{'X-WP-Nonce':CFG.nonce||'',...(o.headers||{})}});
  const ct=(r.headers.get('content-type')||'').toLowerCase();
  const txt=await r.text();
  let data=null;
  if(ct.includes('application/json')){
    try{data=txt?JSON.parse(txt):{};}catch(e){data={code:'ve_bad_json',message:'WordPress returned invalid JSON.'};}
  }else{
    data={code:'ve_non_json',message:r.ok?'Unexpected non-JSON response from WordPress.':'WordPress returned an error while previewing impact.',raw:txt};
  }
  if(!r.ok&&!data.code)data.code='ve_http_'+r.status;
  return data;
},
g:p=>api.f('variable-engine/v1/'+p),
p:(p,b)=>api.f('variable-engine/v1/'+p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}),
u:(p,b)=>api.f('variable-engine/v1/'+p,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)}),
d:p=>api.f('variable-engine/v1/'+p,{method:'DELETE'}),
};

function fuzzy(q,t){q=q.toLowerCase();t=t.toLowerCase();if(t.includes(q))return{m:1,s:t.indexOf(q)===0?100:80};let i=0,s=0;for(let j=0;j<t.length&&i<q.length;j++)if(t[j]===q[i]){i++;s+=10;}return{m:i===q.length,s};}
function tokenParts(n){return String(n||'').split('.').filter(Boolean);}
function stripStorageWrapper(n){const p=tokenParts(n);const wrappers=['size','font','typography'];return p.length>1&&wrappers.includes(p[0])?p.slice(1).join('.'):p.join('.');}
function cssTokenName(n){return '--'+stripStorageWrapper(n).replace(/\./g,'-');}
function sn(n){const clean=stripStorageWrapper(n);const p=clean.split('.');return p.length>1?p.slice(1).join('.'):clean;}
function isClr(v){return/^(#|rgb|hsl|oklch)/i.test(v||'');}
function clrToHex(v){if(!v)return'#000000';if(v.charAt(0)==='#'){let h=v.slice(1);if(h.length===3)h=h[0]+h[0]+h[1]+h[1]+h[2]+h[2];return'#'+h.slice(0,6);}
const rm=v.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);if(rm)return'#'+[rm[1],rm[2],rm[3]].map(x=>('0'+(+x).toString(16)).slice(-2)).join('');
const om=v.match(/oklch\(\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)/);if(om){const L=+om[1],C=+om[2],H=+om[3],hr=H*Math.PI/180,a=C*Math.cos(hr),b=C*Math.sin(hr),l_=L+.3963377774*a+.2158037573*b,m_=L-.1055613458*a-.0638541728*b,s_=L-.0894841775*a-1.291485548*b,l=l_*l_*l_,m=m_*m_*m_,s=s_*s_*s_,rl=4.0767416621*l-3.3077115913*m+.2309699292*s,gl=-1.2684380046*l+2.6097574011*m-.3413193965*s,bl=-.0041960863*l-.7034186147*m+1.707614701*s,gm=x=>x<=.0031308?12.92*x:1.055*Math.pow(Math.max(0,x),1/2.4)-.055,r=Math.round(Math.max(0,Math.min(1,gm(rl)))*255),g=Math.round(Math.max(0,Math.min(1,gm(gl)))*255),bv=Math.round(Math.max(0,Math.min(1,gm(bl)))*255);return'#'+('0'+r.toString(16)).slice(-2)+('0'+g.toString(16)).slice(-2)+('0'+bv.toString(16)).slice(-2);}
const hm=v.match(/hsla?\(\s*([\d.]+)\s*,?\s*([\d.]+)%?\s*,?\s*([\d.]+)%?/);if(hm){const hu=+hm[1]/360,sa=+hm[2]/100,li=+hm[3]/100,q=li<.5?li*(1+sa):li+sa-li*sa,p=2*li-q,h2r=(pp,qq,t)=>{if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return pp+(qq-pp)*6*t;if(t<.5)return qq;if(t<2/3)return pp+(qq-pp)*(2/3-t)*6;return pp;},r=Math.round((sa===0?li:h2r(p,q,hu+1/3))*255),g=Math.round((sa===0?li:h2r(p,q,hu))*255),bv=Math.round((sa===0?li:h2r(p,q,hu-1/3))*255);return'#'+('0'+r.toString(16)).slice(-2)+('0'+g.toString(16)).slice(-2)+('0'+bv.toString(16)).slice(-2);}
return'#000000';}
function pxV(v){const str=(v||'').toString();const cm=str.match(/clamp\([^,]+,[^,]+,\s*([\d.]+)(rem|px)?/i);if(cm){return (cm[2]||'')==='rem'?parseFloat(cm[1])*10:parseFloat(cm[1]);}const m=str.match(/([\d.]+)(rem|px)?/i);if(!m)return 0;return (m[2]||'')==='rem'?parseFloat(m[1])*10:parseFloat(m[1]);}
function pxToRemValue(v){const n=parseFloat((v||'').toString().replace(/[^0-9.]/g,''));if(!isFinite(n))return'';return (Math.round((n/10)*10000)/10000).toString().replace(/\.?0+$/,'')+'rem';}
/* ── Fluid value helpers (mirror core/FluidValue.php) ── */
const FLUID_PREFIX='fluid:';
let _veViewport={vw_min:320,vw_max:1440};
function isFluidVal(v){return (v||'').toString().trim().toLowerCase().indexOf(FLUID_PREFIX)===0;}
function fluidMarker(min,max){const a=parseFloat(min),b=parseFloat(max);if(!isFinite(a)||!isFinite(b))return'';return FLUID_PREFIX+trimNum(a)+','+trimNum(b);}
function parseFluid(v){if(!isFluidVal(v))return null;const body=(v||'').toString().trim().slice(FLUID_PREFIX.length);const p=body.split(',').map(s=>s.trim());if(p.length!==2||!isFinite(parseFloat(p[0]))||!isFinite(parseFloat(p[1])))return null;return[parseFloat(p[0]),parseFloat(p[1])];}
function trimNum(n){let s=(Math.round(n*10000)/10000).toString();return s;}
function fluidClamp(minPx,maxPx,vwMin,vwMax,unit){let a=Math.round(minPx*1000)/1000,b=Math.round(maxPx*1000)/1000;if(a>b){const t=a;a=b;b=t;}let span=vwMax-vwMin;if(span<=0)span=1;const slope=(b-a)/span;const intercept=a-slope*vwMin;const slopeVw=Math.round(slope*100*10000)/10000;if(unit==='px'){return`clamp(${trimNum(a)}px, ${trimNum(Math.round(intercept*1000)/1000)}px + ${slopeVw}vw, ${trimNum(b)}px)`;}return`clamp(${trimNum(Math.round(a/10*10000)/10000)}rem, ${trimNum(Math.round(intercept/10*10000)/10000)}rem + ${slopeVw}vw, ${trimNum(Math.round(b/10*10000)/10000)}rem)`;}
function fluidPreview(min,max){const a=parseFloat(min),b=parseFloat(max);if(!isFinite(a)||!isFinite(b))return'';return fluidClamp(a,b,_veViewport.vw_min,_veViewport.vw_max,'rem');}
function hexOklch(hex){hex=hex.replace('#','');if(hex.length===3)hex=hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];const r=parseInt(hex.substr(0,2),16)/255,g=parseInt(hex.substr(2,2),16)/255,b=parseInt(hex.substr(4,2),16)/255;const f=v=>v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);const rl=f(r),gl=f(g),bl=f(b);const l_=.4122214708*rl+.5363325363*gl+.0514459929*bl,m_=.2119034982*rl+.6806995451*gl+.1073969566*bl,s_=.0883024619*rl+.2817188376*gl+.6299787005*bl;const lc=Math.cbrt(Math.max(0,l_)),mc=Math.cbrt(Math.max(0,m_)),sc=Math.cbrt(Math.max(0,s_));const L=.2104542553*lc+.793617785*mc-.0040720468*sc,a=1.9779984951*lc-2.428592205*mc+.4505937099*sc,bv=.0259040371*lc+.7827717662*mc-.808675766*sc;const cc=Math.sqrt(a*a+bv*bv);let H=Math.atan2(bv,a)*180/Math.PI;if(H<0)H+=360;return`oklch(${Math.max(0,Math.min(1,L)).toFixed(4)} ${cc.toFixed(4)} ${H.toFixed(2)})`;}
function fmtD(hex,fmt){if(fmt==='oklch')return hexOklch(hex);const rr=parseInt(hex.replace('#','').substr(0,2),16),gg=parseInt(hex.replace('#','').substr(2,2),16),bb=parseInt(hex.replace('#','').substr(4,2),16);if(fmt==='hex')return hex;if(fmt==='rgb')return`rgb(${rr},${gg},${bb})`;const rn=rr/255,gn=gg/255,bn=bb/255,mx=Math.max(rn,gn,bn),mn=Math.min(rn,gn,bn),l=(mx+mn)/2;let hu=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);if(mx===rn)hu=((gn-bn)/d+(gn<bn?6:0))/6;else if(mx===gn)hu=((bn-rn)/d+2)/6;else hu=((rn-gn)/d+4)/6;}return`hsl(${Math.round(hu*360)},${Math.round(s*100)}%,${Math.round(l*100)}%)`;}
const ph=n=>h('i',{class:`ph-duotone ph-${n}`,style:'font-size:13px;line-height:1'});
const TSHIRT_UP=['s','m','l','xl','2xl','3xl','4xl','5xl','6xl','7xl','8xl'];
const TSHIRT_DN=['xs','2xs','3xs','4xs','5xs','6xs','7xs','8xs'];
const SCALES=['minor-second','major-second','minor-third','major-third','perfect-fourth','augmented-fourth','perfect-fifth','golden'];
const NS_CLR={color:'#ef4444',space:'#3b82f6',spacing:'#3b82f6',font:'#a855f7',typography:'#a855f7',heading:'#c084fc',text:'#8b5cf6',weight:'#d946ef',radius:'#f59e0b',size:'#22c55e',scale:'#84cc16',stroke:'#14b8a6','stroke-width':'#14b8a6',shadow:'#6b7280',opacity:'#06b6d4',motion:'#ec4899',grid:'#22c55e',design:'#baf400'};
function stripeColor(v){const p=tokenParts(v?.name);for(const k of [p[0],p[1],p[2],v?.namespace]){if(k&&NS_CLR[k])return NS_CLR[k];}return'#8b949e';}

const SLIDE_MS=200;

const CSS=`
*{box-sizing:border-box;}
.ve-o{position:fixed;top:0;right:0;width:370px;height:100vh;background:#1f1f1f;border-left:1px solid #2a2a2a;z-index:999999;display:flex;flex-direction:column;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;font-size:13px;color:#f1f1f1;transform:translateX(100%);transition:transform .22s cubic-bezier(.4,0,.2,1);box-shadow:-4px 0 20px rgba(0,0,0,.5);}
.ve-o.open{transform:translateX(0);}
.ve-bd{position:fixed;inset:0;background:rgba(10,10,10,.10);z-index:999998;opacity:0;transition:opacity .2s;pointer-events:none;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px);}
.ve-bd.show{opacity:1;pointer-events:auto;}
.ve-fab{position:fixed;bottom:16px;right:16px;width:36px;height:36px;background:#1f1f1f;border:1.5px solid #baf400;border-radius:8px;cursor:pointer;z-index:999998;display:flex;align-items:center;justify-content:center;transition:transform .12s;}
.ve-fab:hover{transform:scale(1.06);}
.ve-fab i{color:#baf400;font-size:18px;}
.ve-hdr{display:flex;align-items:center;padding:10px 14px;border-bottom:1px solid #2a2a2a;gap:8px;flex-shrink:0;background:#1a1a1a;z-index:5;position:relative;}
.ve-hdr-i{width:18px;height:18px;background:transparent;border-radius:4px;flex-shrink:0;object-fit:contain;}
.ve-hdr-t{font-weight:700;font-size:11px;letter-spacing:.6px;text-transform:uppercase;color:#baf400;flex:1;}
.ve-hdr-a{display:flex;gap:1px;}
.ve-hdr-a button{background:none;border:none;color:#555;cursor:pointer;width:26px;height:26px;display:flex;align-items:center;justify-content:center;border-radius:4px;padding:0;}
.ve-hdr-a button:hover{background:#2a2a2a;color:#f1f1f1;}
.ve-sr{padding:6px 14px;border-bottom:1px solid #2a2a2a;flex-shrink:0;}
.ve-sr input{width:100%;padding:6px 10px;background:#2a2a2a;border:1px solid #333;border-radius:5px;color:#f1f1f1;font-size:11px;outline:none;}
.ve-sr input:focus{border-color:#baf400;}
.ve-sr input::placeholder{color:#444;}
.ve-tabs{display:flex;gap:2px;padding:4px 14px;border-bottom:1px solid #2a2a2a;flex-shrink:0;overflow-x:auto;}
.ve-tabs::-webkit-scrollbar{height:0;}
.ve-t{padding:4px 8px;font-size:9px;font-weight:600;color:#444;cursor:pointer;border-radius:4px;white-space:nowrap;text-transform:uppercase;letter-spacing:.4px;transition:all .1s;}
.ve-t:hover{color:#999;background:#262626;}
.ve-t.on{color:#1f1f1f;background:#baf400;}

/* Sub-panel slide-in/out */
.ve-sub{position:absolute;top:46px;left:0;right:0;bottom:0;background:#1f1f1f;z-index:4;display:flex;flex-direction:column;animation:veSlideIn .2s ease forwards;}
.ve-sub.closing{animation:veSlideOut .2s ease forwards;pointer-events:none;}
@keyframes veSlideIn{from{transform:translateX(100%);opacity:.8}to{transform:translateX(0);opacity:1}}
@keyframes veSlideOut{from{transform:translateX(0);opacity:1}to{transform:translateX(100%);opacity:.8}}
.ve-sub-hdr{display:flex;align-items:center;height:48px;min-height:48px;padding:0 16px;border-bottom:1px solid #2a2a2a;gap:8px;background:#1a1a1a;}
.ve-sub-hdr span{flex:1;font-size:11px;font-weight:700;color:#baf400;text-transform:uppercase;letter-spacing:.4px;line-height:1;display:flex;align-items:center;height:100%;}
.ve-sub-body{flex:1;overflow-y:auto;padding:10px 14px;}

.ve-body{flex:1;overflow-y:auto;overflow-x:hidden;position:relative;}
.ve-body::-webkit-scrollbar{width:3px;}
.ve-body::-webkit-scrollbar-thumb{background:#333;border-radius:2px;}

.ve-v{padding:5px 14px 5px 0;display:flex;align-items:center;gap:6px;cursor:pointer;transition:background .08s;position:relative;min-height:30px;border-left:0;}
.ve-v:before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--ve-ns,#555);border-radius:0;}
.ve-v:hover{background:#262626;}
.ve-v.sel{background:#262626;}
.ve-sw{width:15px;height:15px;border-radius:3px;border:1px solid #333;flex-shrink:0;}
.ve-inf{flex:1;min-width:0;}
.ve-nm{font-size:11px;font-weight:500;color:#ddd;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:'SF Mono','Fira Code',monospace;line-height:1.3;}
.ve-vl{font-size:9px;color:#555;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:'SF Mono','Fira Code',monospace;}
.ve-exp{background:none;border:none;color:#555;cursor:pointer;width:18px;height:18px;display:flex;align-items:center;justify-content:center;border-radius:3px;flex-shrink:0;padding:0;}
.ve-exp:hover{background:#2a2a2a;color:#baf400;}
.ve-as{display:none;position:absolute;right:10px;top:50%;transform:translateY(-50%);gap:3px;background:rgba(24,24,24,.90);border:1px solid rgba(255,255,255,.10);border-radius:8px;padding:4px;z-index:2;box-shadow:0 12px 28px rgba(0,0,0,.34);backdrop-filter:blur(14px);}
.ve-v:hover .ve-as{display:flex;}
.ve-a{background:transparent;border:none;color:#777;cursor:pointer;width:24px;height:24px;display:flex;align-items:center;justify-content:center;border-radius:6px;padding:0;transition:background .15s,color .15s,box-shadow .15s;}
.ve-a:hover{background:rgba(186,244,0,.11);color:#baf400;box-shadow:0 0 0 1px rgba(186,244,0,.18);}
.ve-a i{font-size:12px;}
.ve-ch{margin-left:18px;border-left:1px solid #2a2a2a;padding-left:2px;}
.ve-c{padding:3px 10px;display:flex;align-items:center;gap:6px;cursor:pointer;transition:background .08s;}
.ve-c:hover{background:#262626;}
.ve-c .ve-nm{font-size:10px;color:#888;}.ve-c .ve-vl{font-size:8px;}
.ve-sb{height:3px;background:#baf400;border-radius:2px;opacity:.4;margin-top:1px;}

/* Forms */
.ve-opt{display:flex;align-items:center;justify-content:space-between;padding:4px 0;font-size:11px;}
.ve-opt>span{color:#888;}
.ve-opt label{display:flex;align-items:center;gap:6px;cursor:pointer;color:#bbb;line-height:1.45;}
.ve-opt input[type=checkbox]{accent-color:#baf400;width:13px;height:13px;}
.ve-opt input[type=number],.ve-opt input[type=text]{padding:4px 6px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:10px;outline:none;}
.ve-opt input[type=number]{width:56px;text-align:center;}
.ve-opt input[type=number]::-webkit-outer-spin-button,.ve-opt input[type=number]::-webkit-inner-spin-button{appearance:none;-webkit-appearance:none;margin:0;}
.ve-opt input[type=number]{appearance:textfield;-moz-appearance:textfield;}
.ve-opt input:focus{border-color:#baf400;}

/* Unified select */
.ve-sel{width:100%;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:10px;outline:none;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='5'%3E%3Cpath d='M0 0l4 5 4-5z' fill='%23666'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 6px center;padding-right:20px;cursor:pointer;transition:border-color .1s;}
.ve-sel:focus{border-color:#baf400;}
.ve-sel:hover{border-color:#555;}
.ve-sel option{background:#2a2a2a;color:#f1f1f1;}
.ve-opt .ve-sel{width:auto;min-width:110px;}
.ve-menu{position:relative;width:100%;min-width:0;}
.ve-menu-btn{width:100%;min-height:38px;padding:9px 34px 9px 11px;background:#282828;border:1px solid rgba(255,255,255,.10);border-radius:4px;color:#f1f1f1;font-size:12px;text-align:left;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 1px 0 rgba(0,0,0,.25);transition:border-color .16s,box-shadow .16s,background .16s;}
.ve-menu-btn:after{content:'';position:absolute;right:12px;top:50%;width:7px;height:7px;border-right:1.5px solid #baf400;border-bottom:1.5px solid #baf400;transform:translateY(-65%) rotate(45deg);pointer-events:none;}
.ve-menu.open .ve-menu-btn{border-color:#baf400;box-shadow:0 0 0 3px rgba(186,244,0,.10),inset 0 1px 0 rgba(255,255,255,.04);background:#303030;border-radius:4px 4px 0 0;}
.ve-menu-list{position:absolute;left:0;right:0;top:calc(100% - 1px);z-index:30;background:#242424;border:1px solid #baf400;border-top-color:rgba(255,255,255,.10);border-radius:0 0 4px 4px;box-shadow:0 18px 38px rgba(0,0,0,.42);max-height:210px;overflow-y:auto;padding:4px;}
.ve-menu-list::-webkit-scrollbar{width:3px}.ve-menu-list::-webkit-scrollbar-thumb{background:#3a3a3a;border-radius:2px}
.ve-menu-item{width:100%;display:block;padding:7px 8px;background:transparent;border:0;border-radius:2px;color:#e7e7e7;text-align:left;font-size:12px;line-height:1.35;cursor:pointer;}
.ve-menu-item:hover,.ve-menu-item.on{background:#343434;color:#baf400;}
.ve-opt-menu{width:168px;flex:0 0 168px;}

.ve-row{display:flex;gap:5px;margin-bottom:6px;align-items:center;}
.ve-row input{flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:10px;outline:none;}
.ve-row input:focus{border-color:#baf400;}
.ve-cp{display:grid;grid-template-columns:42px minmax(0,1fr);gap:8px;align-items:stretch;width:100%;}
.ve-cp input[type=color]{width:42px;height:42px;min-height:42px;padding:0;border:1px solid #333;border-radius:4px;background:#2a2a2a;cursor:pointer;aspect-ratio:1/1;}
.ve-cp input[type=color]::-webkit-color-swatch-wrapper{padding:2px;}
.ve-cp input[type=color]::-webkit-color-swatch{border:none;border-radius:2px;}
.ve-cp-v{min-width:0;padding:7px 10px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#ddd;font-size:10px;font-family:monospace;display:flex;align-items:center;overflow:hidden;line-height:1.45;word-break:break-all;}
.ve-format-tabs{grid-column:1 / -1;display:grid;grid-template-columns:repeat(4,1fr);gap:0;border:1px solid #333;background:#202020;border-radius:4px;overflow:hidden;}
.ve-format-tabs button{min-height:30px;border:0;border-right:1px solid #333;background:#252525;color:#888;font-size:9px;font-weight:700;letter-spacing:0;text-transform:uppercase;cursor:pointer;border-radius:0;}
.ve-format-tabs button:last-child{border-right:0;}
.ve-format-tabs button:hover{background:#2f2f2f;color:#ddd;}
.ve-format-tabs button.on{background:#baf400;color:#1f1f1f;}
.ve-mode{display:flex;gap:2px;margin-bottom:8px;}
.ve-mode button{flex:1;padding:5px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#666;font-size:9px;font-weight:600;text-transform:uppercase;cursor:pointer;letter-spacing:.3px;transition:all .1s;}
.ve-mode button.on{background:#baf400;color:#1f1f1f;border-color:#baf400;}
.ve-btn{padding:5px 12px;background:#baf400;color:#1f1f1f;border:none;border-radius:4px;font-size:10px;font-weight:700;cursor:pointer;white-space:nowrap;}
.ve-btn:hover{background:#d4ff33;}.ve-btn:disabled{opacity:.3;cursor:not-allowed;}
.ve-btn-s{padding:3px 8px;font-size:9px;}
.ve-btn-g{background:none;border:1px solid #333;color:#666;font-weight:500;}
.ve-btn-g:hover{border-color:rgba(255,255,255,.22);color:#fff;background:rgba(255,255,255,.075);}
.ve-btn-d{background:#991b1b;color:#fff;}.ve-btn-d:hover{background:#7f1d1d;color:#fff;border-color:#ef4444;}
.ve-det{padding:10px 14px;border-top:1px solid #2a2a2a;background:#1a1a1a;flex-shrink:0;max-height:180px;overflow-y:auto;}
.ve-det-t{font-weight:700;font-size:12px;margin-bottom:6px;font-family:monospace;color:#baf400;display:flex;justify-content:space-between;align-items:center;}
.ve-det-r{display:flex;justify-content:space-between;padding:2px 0;font-size:10px;}
.ve-det-l{color:#555;}.ve-det-v{color:#ddd;font-family:monospace;}
.ve-dep-s{margin-top:6px;}
.ve-dep-t{font-size:9px;color:#555;text-transform:uppercase;letter-spacing:.4px;margin-bottom:2px;}
.ve-dep{font-size:10px;color:#baf400;padding:1px 0;cursor:pointer;font-family:monospace;}
.ve-dep:hover{text-decoration:underline;}
.ve-empty{padding:24px 14px;text-align:center;color:#444;font-size:11px;}
.ve-st{padding:4px 14px;font-size:9px;color:#444;border-top:1px solid #2a2a2a;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-shrink:0;background:#1a1a1a;margin-top:auto;}
.ve-st-left{display:flex;align-items:center;gap:8px;min-width:0;}
.ve-st .ve-btn{padding:2px 6px;font-size:8px;line-height:1.2;white-space:nowrap;}
.ve-toast{position:fixed;bottom:60px;right:16px;background:#baf400;color:#1f1f1f;padding:6px 14px;border-radius:5px;font-size:11px;font-weight:600;z-index:1000000;opacity:0;transition:opacity .2s;pointer-events:none;}
.ve-toast.show{opacity:1;}
.ve-cf{position:absolute;inset:0;background:rgba(0,0,0,.65);z-index:10;display:flex;align-items:center;justify-content:center;}
.ve-cf-b{background:#1f1f1f;border:1px solid #333;border-radius:8px;padding:16px;text-align:center;max-width:240px;}
.ve-cf-b p{margin:0 0 10px;font-size:12px;color:#bbb;}
.ve-warn{font-size:10px;color:#f59e0b;padding:4px 0;}
.ve-ren{display:flex;gap:4px;align-items:center;padding:8px 0;}
.ve-ren input{flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:11px;font-family:monospace;outline:none;}
.ve-ren input:focus{border-color:#baf400;}
.ve-tshirt-ctrl{display:flex;align-items:center;justify-content:center;gap:4px;padding:4px 0;}
.ve-tshirt-ctrl button{width:24px;height:24px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#baf400;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;padding:0;}
.ve-tshirt-ctrl button:hover{background:#333;border-color:#baf400;}
.ve-tshirt-ctrl button:disabled{opacity:.2;cursor:not-allowed;}
.ve-tshirt-ctrl span{font-size:9px;color:#555;min-width:60px;text-align:center;}

/* Variable reference autocomplete */
.ve-ac{position:absolute;left:0;right:0;top:100%;background:#2a2a2a;border:1px solid #333;border-radius:0 0 4px 4px;max-height:120px;overflow-y:auto;z-index:10;box-shadow:0 4px 12px rgba(0,0,0,.4);}
.ve-ac::-webkit-scrollbar{width:3px;}
.ve-ac::-webkit-scrollbar-thumb{background:#444;border-radius:2px;}
.ve-ac-i{padding:4px 8px;font-size:10px;font-family:'SF Mono','Fira Code',monospace;color:#bbb;cursor:pointer;display:flex;align-items:center;gap:6px;transition:background .08s;}
.ve-ac-i:hover,.ve-ac-i.sel{background:#333;color:#baf400;}
.ve-ac-sw{width:10px;height:10px;border-radius:2px;border:1px solid #444;flex-shrink:0;}
.ve-ac-wrap{position:relative;flex:1;}

/* Premium finish */
.ve-o{width:410px;background:linear-gradient(180deg,rgba(255,255,255,.035),rgba(255,255,255,0) 180px),#1f1f1f;border-left:1px solid rgba(255,255,255,.10);box-shadow:-22px 0 54px rgba(0,0,0,.46);}
.ve-hdr,.ve-sub-hdr,.ve-st,.ve-det{background:rgba(26,26,26,.78);backdrop-filter:blur(18px);border-color:rgba(255,255,255,.08);}
.ve-hdr{padding:14px 16px;gap:10px}.ve-hdr-i{width:24px;height:24px;border-radius:6px;background:transparent;object-fit:contain;box-shadow:none}
.ve-hdr-t{font-size:12px;letter-spacing:0;text-transform:none}.ve-hdr-a{gap:4px}.ve-hdr-a button,.ve-exp,.ve-a{border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.035);border-radius:8px;transition:background .15s,border-color .15s,color .15s,box-shadow .15s}.ve-hdr-a button:hover,.ve-exp:hover,.ve-a:hover{background:rgba(186,244,0,.10);border-color:rgba(186,244,0,.40);color:#baf400;box-shadow:0 0 0 3px rgba(186,244,0,.055)}
.ve-sr{padding:12px 16px;border-color:rgba(255,255,255,.08)}.ve-sr input,.ve-row input,.ve-ren input,.ve-opt input[type=number],.ve-opt input[type=text],.ve-sel,.ve-cp-v{min-height:34px;padding:9px 11px;background:#282828;border:1px solid rgba(255,255,255,.10);border-radius:4px;color:#f1f1f1;box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 1px 0 rgba(0,0,0,.25);transition:border-color .16s,box-shadow .16s,background .16s}.ve-sr input:focus,.ve-row input:focus,.ve-ren input:focus,.ve-opt input:focus,.ve-sel:focus{border-color:#baf400;box-shadow:0 0 0 3px rgba(186,244,0,.10),inset 0 1px 0 rgba(255,255,255,.04);background:#303030}
.ve-opt{align-items:center;padding:8px 0;font-size:12px;gap:10px}.ve-opt>span{color:#aaa}.ve-opt label{gap:9px;color:#d4d4d4;line-height:1.5}.ve-opt input[type=checkbox],.ve-opt input[type=radio]{appearance:none;-webkit-appearance:none;width:16px;height:16px;border:1px solid rgba(255,255,255,.18);border-radius:4px;background:#242424;display:inline-grid;place-content:center;flex:0 0 16px;margin:0;cursor:pointer}.ve-opt input[type=checkbox]:checked,.ve-opt input[type=radio]:checked{background:#baf400;border-color:#baf400;box-shadow:0 0 0 3px rgba(186,244,0,.08)}.ve-opt input[type=checkbox]:checked:before{content:'';width:8px;height:5px;border-left:2px solid #1f1f1f;border-bottom:2px solid #1f1f1f;transform:rotate(-45deg);margin-top:-1px}.ve-opt input[type=number]::-webkit-outer-spin-button,.ve-opt input[type=number]::-webkit-inner-spin-button{appearance:none;-webkit-appearance:none;margin:0}.ve-opt input[type=number]{appearance:textfield;-moz-appearance:textfield;text-align:center;padding-right:11px}.ve-opt-stack{align-items:stretch;flex-direction:column}.ve-opt-stack input{width:100%;font-family:'SF Mono','Fira Code',monospace}
.ve-tabs{padding:8px 16px;gap:5px;border-color:rgba(255,255,255,.08)}.ve-t{padding:6px 10px;border-radius:8px;letter-spacing:0}.ve-t.on{box-shadow:0 8px 22px rgba(186,244,0,.12),inset 0 1px 0 rgba(255,255,255,.38)}
.ve-sub{top:51px;background:linear-gradient(180deg,rgba(255,255,255,.028),rgba(255,255,255,0) 170px),#1f1f1f}.ve-sub-body{padding:16px}.ve-row{gap:8px;margin-bottom:10px}.ve-mode{gap:6px;margin-bottom:12px}.ve-mode button{padding:8px;border-radius:8px;background:rgba(255,255,255,.045);border-color:rgba(255,255,255,.10);letter-spacing:0}.ve-mode button.on{box-shadow:0 10px 24px rgba(186,244,0,.12),inset 0 1px 0 rgba(255,255,255,.42)}
.ve-sub-hdr{height:48px;min-height:48px;padding:0 16px;align-items:center}.ve-sub-hdr .ve-exp{width:26px;height:26px;flex:0 0 26px}.ve-sub-hdr span{line-height:1;align-items:center}
.ve-v{margin:3px 10px 3px 0;border-radius:8px;min-height:38px;padding-top:8px!important;padding-bottom:8px!important;overflow:hidden}.ve-v:before{top:0;bottom:0;border-radius:0}.ve-v:hover,.ve-v.sel{background:rgba(255,255,255,.055);box-shadow:inset 0 0 0 1px rgba(255,255,255,.055)}.ve-ch{margin-left:30px;border-color:rgba(255,255,255,.08)}.ve-c{border-radius:7px;margin:2px 8px 2px 0;padding:6px 10px}.ve-sw{width:18px;height:18px;border-radius:6px;border-color:rgba(255,255,255,.14)}.ve-nm{font-size:12px}.ve-vl{font-size:10px;color:#777}
.ve-btn{position:relative;overflow:hidden;min-height:34px;padding:8px 14px;border-radius:8px;background:#baf400;color:#1f1f1f;border:1px solid rgba(186,244,0,.82);box-shadow:0 1px 0 rgba(255,255,255,.12) inset,0 8px 18px rgba(186,244,0,.10);letter-spacing:0;transition:box-shadow .15s,background .15s,border-color .15s,color .15s}.ve-btn:hover{background:#d4ff33;border-color:#d4ff33;color:#1f1f1f;box-shadow:0 0 0 3px rgba(186,244,0,.10),0 10px 24px rgba(186,244,0,.13)}.ve-btn-g{background:rgba(255,255,255,.045);color:#d8d8d8;border-color:rgba(255,255,255,.14);box-shadow:inset 0 1px 0 rgba(255,255,255,.08),0 1px 2px rgba(0,0,0,.25)}.ve-btn-g:hover{background:rgba(255,255,255,.075);border-color:rgba(255,255,255,.22);color:#fff;box-shadow:inset 0 1px 0 rgba(255,255,255,.10),0 8px 20px rgba(0,0,0,.18)}.ve-btn-d{background:#991b1b;color:#fff;border-color:rgba(255,255,255,.14)}.ve-btn-d:hover{background:#7f1d1d;color:#fff;border-color:#ef4444}
.ve-upd{display:flex;align-items:center;gap:8px;margin-top:8px;font-size:10px;color:#777}.ve-upd .ok{color:#baf400}.ve-upd .muted{color:#888}
.ve-update{margin:10px 16px 0;padding:11px 12px;border:1px solid rgba(186,244,0,.26);background:rgba(186,244,0,.075);border-radius:8px;color:#dfffa3;font-size:10px;line-height:1.55;display:flex;align-items:center;gap:10px}.ve-update i{color:#baf400;font-size:16px}.ve-update span{flex:1}.ve-update b{color:#f1f1f1}
.ve-clean{margin:10px 16px 0;padding:10px 11px;border:1px solid rgba(245,158,11,.28);background:rgba(245,158,11,.08);border-radius:6px;color:#f6c369;font-size:10px;line-height:1.55;display:flex;align-items:center;gap:9px}.ve-clean span{flex:1}.ve-clean .ve-btn{min-height:28px;padding:5px 9px;font-size:9px}
.ve-toast{border-radius:9px;box-shadow:0 16px 38px rgba(0,0,0,.35),0 10px 28px rgba(186,244,0,.12)}.ve-cf-b{border-color:rgba(255,255,255,.10);box-shadow:0 24px 62px rgba(0,0,0,.46)}
.ve-o,.ve-opt,.ve-warn,.ve-empty,.ve-cf-b p,.ve-det-r,.ve-st,.ve-upd{line-height:1.55}
.ve-mode button{line-height:1.35}
`;

function wireGsapHover(root){
  if(!window.gsap||!root||root.__veGsapHover)return;
  root.__veGsapHover=true;
  const selector='.ve-btn,.ve-hdr-a button,.ve-exp,.ve-a,.ve-t,.ve-fab';
  root.addEventListener('mouseover',e=>{
    const el=e.target.closest(selector);
    if(!el||!root.contains(el)||el.disabled)return;
    window.gsap.to(el,{scale:1.018,duration:.16,ease:'power2.out'});
  });
  root.addEventListener('mouseout',e=>{
    const el=e.target.closest(selector);
    if(!el||!root.contains(el)||el.disabled)return;
    window.gsap.to(el,{scale:1,duration:.20,ease:'power2.out'});
  });
}

function Sw({v}){return h('div',{class:'ve-sw',style:isClr(v)?`background:${v}`:'background:repeating-conic-gradient(#333 0% 25%,#2a2a2a 0% 50%) 50%/8px 8px'});}

/* ── Sub-panel wrapper with slide-out animation ── */
function Sub({title,onClose,onBack,children,exiting}){
  const[closing,sC]=useState(false);
  const isOut=closing||exiting;
  const doClose=useCallback(()=>{sC(true);setTimeout(onClose,SLIDE_MS);},[onClose]);
  const handleBack=onBack||doClose;
  return h('div',{class:'ve-sub'+(isOut?' closing':'')},
    h('div',{class:'ve-sub-hdr'},h('button',{class:'ve-exp',onClick:handleBack,title:onBack?'Back':'Close'},ph('arrow-left')),h('span',null,title)),
    h('div',{class:'ve-sub-body'},typeof children==='function'?children(doClose):children));
}

function SelectMenu({value,onChange,options,className}){
  const[open,sOpen]=useState(false);
  const ref=useRef();
  useEffect(()=>{
    if(!open)return;
    const close=e=>{if(ref.current&&!ref.current.contains(e.target))sOpen(false);};
    document.addEventListener('mousedown',close);
    return()=>document.removeEventListener('mousedown',close);
  },[open]);
  const opts=(options||[]).map(o=>typeof o==='string'?{value:o,label:o}:o);
  const cur=opts.find(o=>String(o.value)===String(value))||opts[0]||{value:'',label:''};
  return h('div',{ref,class:'ve-menu '+(open?'open ':'')+(className||'')},
    h('button',{type:'button',class:'ve-menu-btn',onClick:()=>sOpen(v=>!v),onKeyDown:e=>{
      if(e.key==='Escape')sOpen(false);
      if(e.key==='Enter'||e.key===' '){e.preventDefault();sOpen(v=>!v);}
    }},cur.label),
    open&&h('div',{class:'ve-menu-list'},
      opts.map(o=>h('button',{type:'button',class:'ve-menu-item'+(String(o.value)===String(value)?' on':''),key:o.value,onMouseDown:e=>{e.preventDefault();onChange&&onChange(o.value);sOpen(false);}},o.label))));
}

/* ── Settings sub-panel ───────────────── */
function SettingsPanel({onClose,exiting}){
  const[s,sS]=useState({vw_min:320,vw_max:1440,delete_on_uninstall:false,update_url:'',auto_update:false});
  const[upd,sUpd]=useState(null);
  const[ck,sCk]=useState(false);
  const[ld,sLd]=useState(true);
  useEffect(()=>{api.g('settings').then(d=>{sS(d);sLd(false);});},[]);
  const save=async(close)=>{await api.p('settings',s);close();};
  const check=async()=>{sCk(true);const r=await api.p('update/check',{});sUpd(r);sCk(false);};
  if(ld)return h(Sub,{title:'Settings',onClose,exiting},()=>h('div',{class:'ve-empty'},'Loading...'));
  return h(Sub,{title:'Settings',onClose,exiting},doClose=>[
    h('div',{class:'ve-opt',key:'vwm'},h('span',null,'Min viewport (px)'),h('input',{type:'number',value:s.vw_min,onInput:e=>sS({...s,vw_min:+e.target.value})})),
    h('div',{class:'ve-opt',key:'vwx'},h('span',null,'Max viewport (px)'),h('input',{type:'number',value:s.vw_max,onInput:e=>sS({...s,vw_max:+e.target.value})})),
    h('div',{class:'ve-opt',key:'del',style:'margin-top:12px'},h('label',null,h('input',{type:'checkbox',checked:s.delete_on_uninstall,onChange:e=>sS({...s,delete_on_uninstall:e.target.checked})}),'Delete all data on uninstall')),
    h('div',{class:'ve-opt ve-opt-stack',key:'url'},h('span',null,'Update feed URL'),h('input',{type:'text',value:s.update_url||'',placeholder:'https://.../manifest.json',onInput:e=>sS({...s,update_url:e.target.value})})),
    h('div',{class:'ve-opt',key:'auto'},h('label',null,h('input',{type:'checkbox',checked:!!s.auto_update,onChange:e=>sS({...s,auto_update:e.target.checked})}),'Auto-update this plugin')),
    h('div',{class:'ve-upd',key:'upd'},
      h('button',{class:'ve-btn ve-btn-g',onClick:check,disabled:ck},ck?'Checking...':'Check update'),
      upd&&h('span',{class:upd.update_available?'ok':'muted'},upd.message||'Checked',upd.latest_version?' · '+upd.latest_version:''),
      upd?.update_available&&upd.update_admin_url&&h('button',{class:'ve-btn ve-btn-s',onClick:()=>{window.location.href=upd.update_admin_url;}},'Update')),
    h('div',{style:'display:flex;justify-content:flex-end;margin-top:14px',key:'sv'},h('button',{class:'ve-btn',onClick:()=>save(doClose)},'Save'))]);
}

/* ── Color generate sub-panel ─────────── */
function GenColorSub({variable,childMap,onDone,onClose,exiting}){
  const has=(childMap[variable.id]||[]).length>0;
  const[ok,sOk]=useState(!has);
  const[tints,sT]=useState(true);const[shades,sS]=useState(true);const[alpha,sA]=useState(true);
  const[tN,sTN]=useState(8);const[sN,sSN]=useState(8);const[aN,sAN]=useState(8);const[ld,sLd]=useState(false);
  const run=async()=>{sLd(true);if(has){const gs=await api.g(`variables/${variable.id}/generators`);if(Array.isArray(gs))for(const g of gs)await api.d(`generators/${g.id}`);}
    await api.p(`variables/${variable.id}/generators`,{type:'color',config:{tint_count:tints?tN:0,shade_count:shades?sN:0,include_alpha:alpha,alpha_count:alpha?aN:0}});sLd(false);onDone();};
  return h(Sub,{title:'Generate: '+sn(variable.name),onClose,exiting},
    has&&!ok?h('div',null,h('div',{class:'ve-warn'},'This color already has variants. Continuing replaces them.'),
      h('div',{style:'display:flex;gap:5px;margin-top:8px'},h('button',{class:'ve-btn',onClick:()=>sOk(true)},'Continue')))
    :h('div',null,
      h('div',{class:'ve-opt'},h('label',null,h('input',{type:'checkbox',checked:tints,onChange:e=>sT(e.target.checked)}),'Tints'),h('input',{type:'number',min:0,max:20,value:tN,onInput:e=>sTN(+e.target.value),disabled:!tints})),
      h('div',{class:'ve-opt'},h('label',null,h('input',{type:'checkbox',checked:shades,onChange:e=>sS(e.target.checked)}),'Shades'),h('input',{type:'number',min:0,max:20,value:sN,onInput:e=>sSN(+e.target.value),disabled:!shades})),
      h('div',{class:'ve-opt'},h('label',null,h('input',{type:'checkbox',checked:alpha,onChange:e=>sA(e.target.checked)}),'Alpha'),h('input',{type:'number',min:0,max:20,value:aN,onInput:e=>sAN(+e.target.value),disabled:!alpha})),
      h('div',{style:'display:flex;gap:5px;margin-top:10px;justify-content:flex-end'},h('button',{class:'ve-btn',onClick:run,disabled:ld},ld?'Generating...':'Generate'))));
}

/* ── Scale generate sub-panel (reads viewport from settings) ── */
function GenScaleSub({variable,onDone,onClose,exiting}){
  const bv=pxV(variable.value)||16;
  const[bMin,sBM]=useState(bv);const[bMax,sBX]=useState(Math.round(bv*1.125));
  const[scMin,sSM]=useState('major-third');const[scMax,sSX]=useState('major-third');
  const[up,sUp]=useState(3);const[dn,sDn]=useState(2);const[ld,sLd]=useState(false);
  const[vwMin,sVWM]=useState(320);const[vwMax,sVWX]=useState(1440);

  useEffect(()=>{api.g('settings').then(d=>{if(d&&d.vw_min)sVWM(d.vw_min);if(d&&d.vw_max)sVWX(d.vw_max);});},[]);

  const run=async()=>{sLd(true);const gs=await api.g(`variables/${variable.id}/generators`);
    if(Array.isArray(gs))for(const g of gs)await api.d(`generators/${g.id}`);
    const ns=variable.namespace;const tp=(ns==='font'||ns==='heading'||ns==='text')?'typography':ns==='space'?'spacing':ns==='radius'?'radius':ns==='size'?'size':'spacing';
    await api.p(`variables/${variable.id}/generators`,{type:tp,config:{base_min:bMin,base_max:bMax,scale_min:scMin,scale_max:scMax,steps_up:up,steps_down:dn,vw_min:vwMin,vw_max:vwMax,naming:'numeric'}});
    sLd(false);onDone();};
  return h(Sub,{title:'Fluid scale: '+sn(variable.name),onClose,exiting},
    h('div',{class:'ve-opt'},h('span',null,'Base min (mobile)'),h('input',{type:'number',value:bMin,onInput:e=>sBM(+e.target.value),step:'0.1'})),
    h('div',{class:'ve-opt'},h('span',null,'Base max (desktop)'),h('input',{type:'number',value:bMax,onInput:e=>sBX(+e.target.value),step:'0.1'})),
    h('div',{class:'ve-opt'},h('span',null,'Scale min'),h(SelectMenu,{className:'ve-opt-menu',value:scMin,onChange:sSM,options:SCALES})),
    h('div',{class:'ve-opt'},h('span',null,'Scale max'),h(SelectMenu,{className:'ve-opt-menu',value:scMax,onChange:sSX,options:SCALES})),
    h('div',{class:'ve-opt'},h('span',null,'Steps up'),h('input',{type:'number',min:0,max:8,value:up,onInput:e=>sUp(+e.target.value)})),
    h('div',{class:'ve-opt'},h('span',null,'Steps down'),h('input',{type:'number',min:0,max:8,value:dn,onInput:e=>sDn(+e.target.value)})),
    h('div',{style:'font-size:9px;color:#444;padding:4px 0;border-top:1px solid #2a2a2a;margin-top:6px'},'Viewport: '+vwMin+'px → '+vwMax+'px (from Settings)'),
    h('div',{style:'display:flex;gap:5px;margin-top:10px;justify-content:flex-end'},h('button',{class:'ve-btn',onClick:run,disabled:ld},ld?'Generating...':'Generate')));
}

function cssVarToTokenName(name){
  let n=String(name||'').trim().toLowerCase().replace(/^--/,'').replace(/[^a-z0-9-]/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'');
  if(!n)return'';
  return n.replace(/-/g,'.');
}
function parseCssVariables(text){
  const clean=String(text||'').replace(/\/\*[\s\S]*?\*\//g,'');
  const re=/--([a-zA-Z0-9_-]+)\s*:\s*([^;]+);/g;
  const out=[];const seen={};let m;
  while((m=re.exec(clean))){
    const name=cssVarToTokenName('--'+m[1]);
    const value=String(m[2]||'').trim();
    if(!name||!value)continue;
    seen[name]={name,value,namespace:name.split('.')[0],type:'base'};
  }
  Object.keys(seen).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).forEach(k=>out.push(seen[k]));
  return out;
}

/* ── Sync sub-panel (includes Figma connection + pairing) ── */
function SyncPanel({onClose,exiting,onDone,onReload}){
  const[view,sView]=useState('main');
  const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const[diff,sDiff]=useState(null);const[summary,sSummary]=useState(null);
  const[snaps,sSnaps]=useState([]);const[skipDel,sSD]=useState(true);
  const[pair,sPair]=useState(null);const[stats,sStats]=useState(null);const[cleaning,sCleaning]=useState(false);
  const[pCode,sPC]=useState('');const[pKey,sPK]=useState('');const[figCode,sFC]=useState('');const[pMsg,sPM]=useState('');
  const[diag,sDiag]=useState(null);
  const fileRef=useRef();const cssFileRef=useRef();
  const[cssText,sCssText]=useState('');const[cssCount,sCssCount]=useState(0);

  const loadPair=useCallback(()=>api.g('sync/pair/status').then(d=>{if(d)sPair(d);return d;}),[]);
  const loadStats=useCallback(()=>api.g('variables/stats').then(d=>{if(d&&!d.code)sStats(d);return d;}).catch(()=>null),[]);
  useEffect(()=>{loadPair();loadStats();const t=setInterval(()=>{loadPair();loadStats();},2500);return()=>clearInterval(t);},[loadPair,loadStats]);

  const genCode=async()=>{const r=await api.p('sync/pair/generate',{});if(r?.code){sPC(r.code);sPK(r.api_key||'');}};
  const submitFigCode=async()=>{if(figCode.length!==6){sPM('Enter the 6-character code');return;}const r=await api.p('sync/pair/complete-figma',{code:figCode});if(r?.api_key){sPM('Paired!');api.g('sync/pair/status').then(d=>{if(d)sPair(d);});}else sPM(r?.message||'Invalid code');};
  const disc=async()=>{await api.p('sync/pair/disconnect',{});sPair({paired:false,source:'',figma_name:'',collection_name:''});sPC('');sPK('');};
  const cleanDb=async()=>{if(!confirm('Clean duplicate, stale, and orphan generated variables from WordPress? This keeps base variables and rebuilds recoverable generated variants.'))return;sCleaning(true);sErr('');const r=await api.p('variables/cleanup',{});sCleaning(false);if(r?.after){sStats(r.after);onReload&&onReload();}else{sErr(r?.message||'Cleanup failed');}};
  const loadDiagnostics=async()=>{if(diag){sDiag(null);return;}const r=await api.g('diagnostics/logs?lines=12');if(r?.code){sErr(r.message||'Could not load diagnostics');return;}sDiag(r);};
  const statIssues=stats?[(stats.stale_generated?stats.stale_generated+' stale':''),(stats.orphan_generated?stats.orphan_generated+' orphan':''),(stats.duplicate_count?stats.duplicate_count+' duplicate names':''),(stats.older_generators?stats.older_generators+' old generators':'')].filter(Boolean):[];
  const doExport=async(fmt)=>{sLd(true);sErr('');const d=await api.g('sync/export?format='+fmt);const blob=new Blob([JSON.stringify(d,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download='variable-engine-export-'+(new Date).toISOString().slice(0,10)+'.'+fmt+'.json';document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);sLd(false);};
  const doExportCss=async()=>{sLd(true);sErr('');const d=await api.g('sync/export-css');if(d?.code){sErr(d.message||'CSS export failed');sLd(false);return;}const blob=new Blob([d.css||''],{type:'text/css'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=d.filename||('mimams-var-'+(new Date).toISOString().slice(0,10)+'.css');document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);sLd(false);};
  const doImport=async(e)=>{const file=e.target.files?.[0];if(!file)return;sLd(true);sErr('');try{const text=await file.text();const json=JSON.parse(text);const res=await api.p('sync/preview',json);if(res?.code){sErr(res.message||'Parse error');sLd(false);return;}sDiff(res.changes||[]);sSummary(res.summary||{});sView('preview');}catch(ex){sErr('Invalid JSON: '+ex.message);}sLd(false);};
  const readCssFile=async(e)=>{const file=e.target.files?.[0];if(!file)return;const text=await file.text();sCssText(text);sCssCount(parseCssVariables(text).length);};
  const previewCssImport=async()=>{const vars=parseCssVariables(cssText);sCssCount(vars.length);if(!vars.length){sErr('No CSS custom properties found. Use declarations like --color-primary: #baf400;');return;}sLd(true);sErr('');const res=await api.p('sync/preview',vars);if(res?.code){sErr(res.message||'CSS import preview failed');sLd(false);return;}sDiff(res.changes||[]);sSummary(res.summary||{});sView('preview');sLd(false);};
  const doApply=async()=>{if(!diff)return;sLd(true);sErr('');const filtered=skipDel?diff.filter(c=>c.action!=='delete'):diff;const res=await api.p('sync/apply',{changes:filtered,skip_deletes:skipDel});sLd(false);if(res?.errors?.length)sErr(res.errors.join('; '));if(res?.applied>0)onDone();else sView('main');};
  const doSnap=async()=>{sLd(true);await api.p('sync/snapshot',{});await loadSnaps();sLd(false);};
  const loadSnaps=async()=>{const s=await api.g('sync/snapshots');if(Array.isArray(s))sSnaps(s);};
  const doRollback=async(id)=>{sLd(true);sErr('');const res=await api.p('sync/rollback/'+id,{});sLd(false);if(res?.restored)onDone();else sErr(res?.message||'Rollback failed');};
  useEffect(()=>{if(view==='snapshots')loadSnaps();},[view]);

  const AC={add:'#22c55e',update:'#3b82f6',delete:'#ef4444',type_change:'#f59e0b'};
  const AL={add:'ADD',update:'UPD',delete:'DEL',type_change:'TYPE'};

  if(view==='preview')return h(Sub,{title:'Import Preview',onClose,exiting},
    summary&&h('div',{style:'display:flex;gap:8px;margin-bottom:8px;flex-wrap:wrap'},summary.added>0&&h('span',{style:'font-size:10px;color:#22c55e'},'+'+summary.added+' new'),summary.updated>0&&h('span',{style:'font-size:10px;color:#3b82f6'},'~'+summary.updated+' changed'),summary.deleted>0&&h('span',{style:'font-size:10px;color:#ef4444'},'-'+summary.deleted+' removed')),
    h('div',{style:'max-height:220px;overflow-y:auto;margin-bottom:8px'},(diff||[]).map((c,i)=>h('div',{key:i,style:'display:flex;align-items:center;gap:6px;padding:3px 0;font-size:10px;border-bottom:1px solid #2a2a2a'},h('span',{style:`color:${AC[c.action]||'#888'};font-weight:700;font-size:8px;width:30px;text-transform:uppercase`},AL[c.action]||c.action),h('span',{style:'color:#ddd;font-family:monospace;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap'},c.name),c.action==='update'&&h('span',{style:'color:#555;font-size:8px;font-family:monospace'},'→ ',c.new_value?.slice(0,20))))),
    err&&h('div',{style:'font-size:10px;color:#ef4444;padding:4px 0'},err),
    h('div',{class:'ve-opt',style:'margin-top:4px'},h('label',null,h('input',{type:'checkbox',checked:skipDel,onChange:e=>sSD(e.target.checked)}),'Skip deletions')),
    h('div',{style:'display:flex;gap:5px;margin-top:8px;justify-content:flex-end'},h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sView('main')},'Back'),h('button',{class:'ve-btn ve-btn-s',onClick:doApply,disabled:ld||!(diff||[]).length},ld?'Applying...':'Apply '+(diff||[]).length+' changes')));

  if(view==='snapshots')return h(Sub,{title:'Snapshots',onClose,onBack:()=>sView('main'),exiting},
    h('div',{style:'display:flex;flex-direction:column;min-height:100%;gap:12px'},
      h('div',null,h('button',{class:'ve-btn ve-btn-s',onClick:doSnap,disabled:ld},'+ New Snapshot')),
      snaps.length===0?h('div',{class:'ve-empty',style:'flex:1'},'No snapshots yet'):h('div',{style:'flex:1;min-height:0;overflow-y:auto;padding-right:4px'},snaps.map(s=>h('div',{key:s.id,style:'display:flex;align-items:center;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:1px solid #2a2a2a;font-size:10px'},h('div',{style:'min-width:0'},h('div',{style:'color:#ddd;white-space:nowrap;overflow:hidden;text-overflow:ellipsis'},'#'+s.id+' — '+s.trigger_type),h('div',{style:'color:#555;font-size:9px'},s.created_at)),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>doRollback(s.id),disabled:ld},'Restore')))),
      err&&h('div',{style:'font-size:10px;color:#ef4444;padding:4px 0'},err),
      h('div',{style:'display:flex;gap:5px;margin-top:auto'},h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sView('main')},'Back'))));

  return h(Sub,{title:'Sync',onClose,exiting},
    /* Figma Connection */
    h('div',{style:'margin-bottom:12px'},
      h('div',{style:'font-size:10px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Figma Connection'),
      pair?.paired?h('div',null,
        h('div',{style:'font-size:11px;color:#baf400;margin-bottom:4px'},'✓ Connected'),
        h('div',{style:'display:flex;align-items:flex-start;gap:6px;font-size:10px;color:#ddd;margin-bottom:4px;font-family:monospace'},ph('file'),h('span',null,pair.figma_name||'Figma file not captured yet — open the Figma plugin once to update this.')),
        pair.collection_name&&h('div',{style:'display:flex;align-items:flex-start;gap:6px;font-size:10px;color:#888;margin-bottom:4px;font-family:monospace'},ph('stack'),h('span',null,'Collection: '+pair.collection_name)),
        h('div',{style:'font-size:10px;color:#555;margin-bottom:6px'},'Source: '+(pair.source==='figma'?'Figma':'WordPress')),
        h('button',{class:'ve-btn ve-btn-d ve-btn-s',onClick:disc},'Disconnect'))
      :h('div',null,
        h('div',{style:'font-size:10px;color:#555;margin-bottom:6px'},'Generate credentials for your Figma plugin:'),
        h('button',{class:'ve-btn ve-btn-s',onClick:genCode,style:'margin-bottom:6px'},'Generate Pairing Credentials'),
        pCode&&h('div',{style:'background:#2a2a2a;border-radius:6px;padding:10px;margin:6px 0'},
          h('div',{style:'font-size:9px;color:#555;text-transform:uppercase;margin-bottom:2px'},'Pairing Code'),
          h('div',{style:'font-size:22px;font-weight:800;letter-spacing:4px;text-align:center;font-family:monospace;color:#baf400'},pCode),
          pKey&&h('div',null,
            h('div',{style:'font-size:9px;color:#555;text-transform:uppercase;margin-top:8px;margin-bottom:2px'},'API Key'),
            h('div',{style:'font-size:9px;font-family:monospace;color:#888;word-break:break-all;cursor:pointer;padding:4px;background:#1f1f1f;border-radius:3px',onClick:()=>{navigator.clipboard?.writeText(pKey);sPM('Copied!');}},pKey),
            h('div',{style:'font-size:9px;color:#555;text-align:center;margin-top:4px'},'Click key to copy. Enter both in Figma plugin.'))),
        h('div',{style:'font-size:10px;color:#555;margin:8px 0 4px'},'Or enter a code from Figma:'),
        h('div',{style:'display:flex;gap:4px'},
          h('input',{style:'flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:13px;font-family:monospace;text-align:center;letter-spacing:2px;text-transform:uppercase;outline:none',maxLength:6,value:figCode,onInput:e=>sFC(e.target.value.toUpperCase()),placeholder:'ABC123'}),
          h('button',{class:'ve-btn ve-btn-s',onClick:submitFigCode},'Pair')),
        pMsg&&h('div',{style:'font-size:10px;color:'+(pMsg.includes('Paired')||pMsg.includes('Copied')?'#baf400':'#ef4444')+';padding:4px 0'},pMsg))),
    /* Database Cleanup */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:10px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'WordPress Database'),
      stats?h('div',null,
        h('div',{style:'font-size:10px;color:#ddd;margin-bottom:4px'},(stats.base||0)+' base · '+(stats.generated||0)+' generated · '+(stats.total||0)+' raw'),
        statIssues.length?h('div',{style:'font-size:9px;color:#f59e0b;margin-bottom:6px'},statIssues.join(', ')):h('div',{style:'font-size:9px;color:#555;margin-bottom:6px'},'No cleanup issues detected'),
        h('div',{style:'display:flex;gap:4px;flex-wrap:wrap'},statIssues.length>0&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:cleanDb,disabled:cleaning},cleaning?'Cleaning...':'Clean WP DB'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:loadDiagnostics},diag?'Hide Diagnostics':'View Diagnostic Logs')),
        diag&&h('div',{style:'margin-top:8px;padding:8px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.08);border-radius:8px;font-size:9px;color:#aaa;line-height:1.5;max-height:120px;overflow:auto;font-family:"SF Mono","Fira Code",monospace;white-space:pre-wrap'},(diag.entries||[]).length?(diag.entries||[]).map(x=>(x.time||'')+' '+(x.level||'')+' '+(x.event||x.raw||'')).join('\n'):'No diagnostic entries yet',h('div',{style:'color:#555;margin-top:4px;word-break:break-all'},diag.path||'')))
      :h('div',{style:'font-size:10px;color:#555'},'Loading stats...')),
    /* Export */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:10px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Export'),
      h('div',{style:'display:flex;gap:4px;flex-wrap:wrap'},h('button',{class:'ve-btn ve-btn-s',onClick:()=>doExport('dtcg'),disabled:ld},'DTCG'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>doExport('flat'),disabled:ld},'Flat'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>doExport('figma'),disabled:ld},'Figma'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:doExportCss,disabled:ld},'CSS')),
      h('div',{style:'font-size:9px;color:#444;padding:4px 0;line-height:1.5'},'CSS exports a commented :root file using current css_value output.')),
    /* Import */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:10px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Import'),
      h('input',{ref:fileRef,type:'file',accept:'.json',style:'display:none',onChange:doImport}),
      h('input',{ref:cssFileRef,type:'file',accept:'.css,text/css',style:'display:none',onChange:readCssFile}),
      h('div',{style:'display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px'},h('button',{class:'ve-btn ve-btn-s',onClick:()=>fileRef.current?.click(),disabled:ld},ld?'Reading...':'Upload JSON'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>cssFileRef.current?.click(),disabled:ld},'Upload CSS')),
      h('textarea',{value:cssText,onInput:e=>{sCssText(e.target.value);sCssCount(parseCssVariables(e.target.value).length);},placeholder:'Paste CSS variables here, e.g. :root { --color-primary: #baf400; --space-20: 2rem; }',style:'width:100%;min-height:96px;padding:9px 11px;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.10);border-radius:8px;color:#f1f1f1;font-size:10px;font-family:"SF Mono","Fira Code",monospace;outline:none;resize:vertical;line-height:1.55;margin-bottom:6px'}),
      h('div',{style:'display:flex;align-items:center;justify-content:space-between;gap:8px'},h('span',{style:'font-size:9px;color:#777'},cssCount?cssCount+' CSS variables detected':'Paste or upload a CSS file'),h('button',{class:'ve-btn ve-btn-s',onClick:previewCssImport,disabled:ld||!cssText.trim()},'Preview CSS Import'))),
    /* Snapshots */
    h('div',{style:'padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:10px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Snapshots & Rollback'),
      h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sView('snapshots')},'View Snapshots')),
    err&&h('div',{style:'font-size:10px;color:#ef4444;padding:8px 0'},err));
}

/* ── Variable reference autocomplete ──── */
function VarRefInput({value,onInput,vars,placeholder,onKeyDown}){
  const[show,sShow]=useState(false);
  const[q,sQ]=useState('');
  const[idx,sIdx]=useState(0);
  const ref=useRef();

  const matches=useMemo(()=>{
    if(!q)return[];
    return vars.filter(v=>v.name.toLowerCase().includes(q.toLowerCase())).slice(0,8);
  },[q,vars]);

  const handleInput=e=>{
    const val=e.target.value;
    onInput(e);
    const cur=val.slice(0,e.target.selectionStart||val.length);
    const m=cur.match(/var\(--([a-z0-9.-]*)$/i);
    if(m){sQ(m[1].replace(/-/g,'.'));sShow(true);sIdx(0);}
    else{sShow(false);sQ('');}
  };

  const insert=(v)=>{
    const el=ref.current;if(!el)return;
    const val=el.value;
    const pos=el.selectionStart||val.length;
    const before=val.slice(0,pos);
    const after=val.slice(pos);
    const m=before.match(/var\(--[a-z0-9.-]*$/i);
    if(m){
      const cssName=cssTokenName(v.name);
      const newBefore=before.slice(0,before.length-m[0].length)+'var('+cssName+')';
      const nv=newBefore+after;
      onInput({target:{value:nv}});
      sShow(false);sQ('');
      setTimeout(()=>{el.focus();el.selectionStart=el.selectionEnd=newBefore.length;},10);
    }
  };

  const handleKey=e=>{
    if(show&&matches.length){
      if(e.key==='ArrowDown'){e.preventDefault();sIdx(i=>(i+1)%matches.length);}
      else if(e.key==='ArrowUp'){e.preventDefault();sIdx(i=>(i-1+matches.length)%matches.length);}
      else if(e.key==='Enter'&&matches[idx]){e.preventDefault();insert(matches[idx]);}
      else if(e.key==='Escape'){sShow(false);}
    }
    if(onKeyDown)onKeyDown(e);
  };

  return h('div',{class:'ve-ac-wrap'},
    h('input',{ref,placeholder,value,onInput:handleInput,onKeyDown:handleKey,onBlur:()=>setTimeout(()=>sShow(false),150),style:'width:100%;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:10px;outline:none;font-family:monospace'}),
    show&&matches.length>0&&h('div',{class:'ve-ac'},
      matches.map((v,i)=>h('div',{class:'ve-ac-i'+(i===idx?' sel':''),onMouseDown:e=>{e.preventDefault();insert(v);},key:v.id},
        h('div',{class:'ve-ac-sw',style:isClr(v.value)?`background:${v.value};border-color:transparent`:''}),
        h('span',null,cssTokenName(v.name)),
        h('span',{style:'color:#444;margin-left:auto;font-size:8px'},v.value)))));
}

/* ── Create sub-panel ─────────────────── */
function CreateSub({onCreated,onClose,categories,vars,exiting}){
  const[mode,sMode]=useState('color');
  const[cat,sCat]=useState('color');const[newCat,sNC]=useState('');const[showNC,sSNC]=useState(false);
  const[nm,sNm]=useState('');const[val,sVal]=useState('');
  const[fMin,sFMin]=useState('');const[fMax,sFMax]=useState('');
  const[hex,sHex]=useState('#baf400');const[fmt,sFmt]=useState('oklch');
  const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  useEffect(()=>{if(mode==='color')sCat('color');else if(cat==='color')sCat(categories.find(c=>c!=='color'&&c!=='all')||'space');},[mode]);
  const prefix=showNC?newCat:cat;
  const fullNm=prefix&&nm?(prefix+'.'+nm):nm;

  const create=async()=>{
    if(!nm)return;sLd(true);sErr('');
    let fv;
    if(mode==='color')fv=hexOklch(hex);
    else if(mode==='fluid')fv=fluidMarker(fMin,fMax);
    else if(mode==='clamp')fv=val?(val.match(/\d/)?pxToRemValue(val):val):'1rem';
    else fv=val;
    if(!fv){sLd(false);sErr(mode==='fluid'?'Enter both a min and max value.':'');return;}
    const r=await api.p('variables',{name:fullNm,value:fv});
    sLd(false);
    if(r?.code==='ve_duplicate'){sErr(r.message||'A variable with this name already exists.');return;}
    if(r?.code){sErr(r.message||'Failed to create variable.');return;}
    if(r?.id)onCreated(r,mode==='clamp');
  };

  const catOpts=mode==='color'?['color']:categories.filter(c=>c!=='all'&&c!=='color');

  return h(Sub,{title:'New Variable',onClose,exiting},
    h('div',{class:'ve-mode'},
      h('button',{class:mode==='color'?'on':'',onClick:()=>sMode('color')},'Color'),
      h('button',{class:mode==='clamp'?'on':'',onClick:()=>sMode('clamp')},'Fixed'),
      h('button',{class:mode==='fluid'?'on':'',onClick:()=>sMode('fluid')},'Fluid'),
      h('button',{class:mode==='static'?'on':'',onClick:()=>sMode('static')},'Static')),
    h('div',{class:'ve-row'},
      !showNC?h(SelectMenu,{value:cat,onChange:v=>{if(v==='__new__')sSNC(true);else sCat(v)},options:[...catOpts.map(c=>({value:c,label:c})),{value:'__new__',label:'+ New category'}]}):
      h('input',{placeholder:'category name',value:newCat,onInput:e=>sNC(e.target.value),style:'flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:10px;outline:none',onBlur:()=>{if(!newCat)sSNC(false);}})),
    h('div',{class:'ve-row'},h('input',{placeholder:mode==='color'?'e.g. accent, brand':'e.g. 20, 8, heading.58, gap.20',value:nm,onInput:e=>{sNm(e.target.value);if(err)sErr('');},onKeyDown:e=>e.key==='Enter'&&create(),style:'flex:1'})),
    prefix&&nm&&h('div',{style:'font-size:9px;color:#444;padding:0 0 6px;font-family:monospace'},fullNm),
    err&&h('div',{style:'font-size:10px;color:#ef4444;padding:2px 0 6px'},err),
    mode==='color'&&h('div',{class:'ve-row'},h('div',{class:'ve-cp',style:'flex:1'},
      h('input',{type:'color',value:hex,onInput:e=>sHex(e.target.value)}),
      h('div',{class:'ve-cp-v'},fmtD(hex,fmt)),
      h('div',{class:'ve-format-tabs'},['hex','rgb','hsl','oklch'].map(f=>h('button',{class:fmt===f?'on':'',type:'button',onClick:()=>sFmt(f)},f.toUpperCase()))))),
    mode==='clamp'&&h('div',null,
      h('div',{class:'ve-row'},h('input',{placeholder:'Base value (number, stored as rem)',value:val,onInput:e=>{const v=e.target.value.replace(/[^0-9.]/g,'');sVal(v);},style:'flex:1'})),
      h('div',{style:'font-size:9px;color:#555;padding:0 0 6px'},'Numbers are px references — stored as rem using 10px = 1rem. Example: 20 → 2rem.')),
    mode==='fluid'&&h('div',null,
      h('div',{class:'ve-row',style:'gap:6px'},
        h('input',{placeholder:'Min px',value:fMin,onInput:e=>{sFMin(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'}),
        h('input',{placeholder:'Max px',value:fMax,onInput:e=>{sFMax(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'})),
      fMin&&fMax&&h('div',{style:'font-size:9px;color:#baf400;padding:0 0 4px;font-family:monospace;word-break:break-all'},fluidPreview(fMin,fMax)),
      h('div',{style:'font-size:9px;color:#555;padding:0 0 6px'},'Scales smoothly between the page min and max viewport widths (set in Settings). Min/max are px values.')),
    mode==='static'&&h('div',{class:'ve-row'},
      h(VarRefInput,{placeholder:'e.g. 0 4px 12px rgba(0,0,0,.1) or var(--...',value:val,onInput:e=>sVal(typeof e.target==='object'?e.target.value:e),vars:vars||[],onKeyDown:e=>e.key==='Enter'&&create()})),
    h('div',{style:'display:flex;gap:5px;justify-content:flex-end;margin-top:4px'},
      h('button',{class:'ve-btn',onClick:create,disabled:ld||!nm||(mode==='clamp'&&!val)||(mode==='static'&&!val)||(mode==='fluid'&&(!fMin||!fMax))},ld?'...':'Create')));
}

/* ── Edit sub-panel (same as create, pre-filled) ── */
function EditSub({variable,onDone,onClose,categories,vars,exiting}){
  const isClrV=isClr(variable.value);
  const isFluidV=isFluidVal(variable.value);
  const initMode=isClrV?'color':isFluidV?'fluid':(variable.value||'').includes('clamp')?'clamp':'static';
  const parts=variable.name.split('.');
  const initCat=parts[0]||'color';
  const initNm=parts.slice(1).join('.')||variable.name;
  const initFluid=isFluidV?parseFluid(variable.value):null;

  const[mode,sMode]=useState(initMode);
  const[cat,sCat]=useState(initCat);const[newCat,sNC]=useState('');const[showNC,sSNC]=useState(false);
  const[nm,sNm]=useState(initNm);const[val,sVal]=useState(variable.value||'');
  const[fMin,sFMin]=useState(initFluid?String(initFluid[0]):'');const[fMax,sFMax]=useState(initFluid?String(initFluid[1]):'');
  const[hex,sHex]=useState(isClrV?clrToHex(variable.value):'#baf400');const[fmt,sFmt]=useState('oklch');
  const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const[prop,sProp]=useState(false);const[impact,sImpact]=useState(null);const[checking,sChecking]=useState(false);

  useEffect(()=>{if(mode==='color')sCat('color');else if(cat==='color')sCat(categories.find(c=>c!=='color'&&c!=='all')||'space');},[mode]);
  const prefix=showNC?newCat:cat;
  const fullNm=prefix&&nm?(prefix+'.'+nm):nm;
  const nameChanged=fullNm&&fullNm!==variable.name;
  const previewRename=async()=>{if(!nameChanged)return;sChecking(true);sErr('');try{const r=await api.p('variables/'+variable.id+'/rename-preview',{new_name:fullNm});if(r?.code){sErr(r.message||'Preview failed');return;}sImpact(r.impact||null);}catch(e){sErr('Preview failed. Check WordPress error logs for details.');}finally{sChecking(false);}};

  const save=async()=>{
    if(!nm)return;sLd(true);sErr('');
    let fv;
    if(mode==='color')fv=hexOklch(hex);
    else if(mode==='fluid')fv=fluidMarker(fMin,fMax);
    else if(mode==='clamp')fv=val?(val.match(/\d/)?pxToRemValue(val):val):'1rem';
    else fv=val;
    if(!fv){sLd(false);sErr(mode==='fluid'?'Enter both a min and max value.':'');return;}
    const updates={};
    if(fullNm!==variable.name){updates.name=fullNm;if(prop)updates.propagate_usages=true;}
    // For colors, compare hex values to detect change (avoids oklch rounding issues)
    if(mode==='color'){
      if(hex!==clrToHex(variable.value))updates.value=fv;
    } else {
      if(fv!==variable.value)updates.value=fv;
    }
    if(Object.keys(updates).length===0){sLd(false);onDone();return;}
    const r=await api.u('variables/'+variable.id,updates);
    sLd(false);
    if(r?.code==='ve_duplicate'){sErr(r.message||'Name already exists.');return;}
    if(r?.code){sErr(r.message||'Failed to update.');return;}
    onDone();
  };

  const catOpts=mode==='color'?['color']:categories.filter(c=>c!=='all'&&c!=='color');

  return h(Sub,{title:'Edit: '+sn(variable.name),onClose,exiting},
    h('div',{class:'ve-mode'},
      h('button',{class:mode==='color'?'on':'',onClick:()=>sMode('color')},'Color'),
      h('button',{class:mode==='clamp'?'on':'',onClick:()=>sMode('clamp')},'Fixed'),
      h('button',{class:mode==='fluid'?'on':'',onClick:()=>sMode('fluid')},'Fluid'),
      h('button',{class:mode==='static'?'on':'',onClick:()=>sMode('static')},'Static')),
    h('div',{class:'ve-row'},
      !showNC?h(SelectMenu,{value:cat,onChange:v=>{if(v==='__new__')sSNC(true);else sCat(v)},options:[...catOpts.map(c=>({value:c,label:c})),{value:'__new__',label:'+ New category'}]}):
      h('input',{placeholder:'category name',value:newCat,onInput:e=>sNC(e.target.value),style:'flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:10px;outline:none',onBlur:()=>{if(!newCat)sSNC(false);}})),
    h('div',{class:'ve-row'},h('input',{placeholder:'name',value:nm,onInput:e=>{sNm(e.target.value);sImpact(null);if(err)sErr('');},onKeyDown:e=>e.key==='Enter'&&save(),style:'flex:1'})),
    prefix&&nm&&h('div',{style:'font-size:9px;color:#444;padding:0 0 6px;font-family:monospace'},fullNm),
    nameChanged&&h('div',{class:'ve-warn',style:'margin:0 0 8px'},
      h('div',{style:'font-size:10px;margin-bottom:5px'},'Rename detected. You can update existing var() references in WordPress/Bricks storage too.'),
      h('label',{style:'display:flex;gap:6px;align-items:center;font-size:10px;color:#ccc;margin-bottom:5px'},h('input',{type:'checkbox',checked:prop,onChange:e=>sProp(e.target.checked)}),'Update usages in WordPress storage'),
      h('button',{class:'ve-btn ve-btn-s',style:'font-size:9px;padding:3px 7px',onClick:previewRename,disabled:checking},checking?'Checking...':'Preview impact'),
      impact&&h('div',{style:'font-size:9px;color:#777;margin-top:4px'},(impact.total_matches||0)+' matches in '+((impact.locations||[]).length)+' records')
    ),
    err&&h('div',{style:'font-size:10px;color:#ef4444;padding:2px 0 6px'},err),
    mode==='color'&&h('div',{class:'ve-row'},h('div',{class:'ve-cp',style:'flex:1'},
      h('input',{type:'color',value:hex,onInput:e=>sHex(e.target.value)}),
      h('div',{class:'ve-cp-v'},fmtD(hex,fmt)),
      h('div',{class:'ve-format-tabs'},['hex','rgb','hsl','oklch'].map(f=>h('button',{class:fmt===f?'on':'',type:'button',onClick:()=>sFmt(f)},f.toUpperCase()))))),
    mode==='clamp'&&h('div',null,
      h('div',{class:'ve-row'},h('input',{placeholder:'Base value (number, stored as rem)',value:val,onInput:e=>sVal(e.target.value),style:'flex:1'})),
      h('div',{style:'font-size:9px;color:#555;padding:0 0 6px'},'Current: '+variable.value)),
    mode==='fluid'&&h('div',null,
      h('div',{class:'ve-row',style:'gap:6px'},
        h('input',{placeholder:'Min px',value:fMin,onInput:e=>{sFMin(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'}),
        h('input',{placeholder:'Max px',value:fMax,onInput:e=>{sFMax(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'})),
      fMin&&fMax&&h('div',{style:'font-size:9px;color:#baf400;padding:0 0 4px;font-family:monospace;word-break:break-all'},fluidPreview(fMin,fMax)),
      h('div',{style:'font-size:9px;color:#555;padding:0 0 6px'},'Scales between the page min/max viewport widths. Min/max are px values.')),
    mode==='static'&&h('div',{class:'ve-row'},
      h(VarRefInput,{placeholder:'value',value:val,onInput:e=>sVal(typeof e.target==='object'?e.target.value:e),vars:vars||[],onKeyDown:e=>e.key==='Enter'&&save()})),
    h('div',{style:'display:flex;gap:5px;justify-content:flex-end;margin-top:4px'},
      h('button',{class:'ve-btn',onClick:save,disabled:ld||!nm||(mode==='fluid'&&(!fMin||!fMax))},ld?'...':'Save Changes')));
}

/* ── Detail (with inline value editing) ── */
function Detail({variable,onNav,onClose,onUpdate,onEditFull}){
  const[d,sD]=useState(null);
  const[editing,sEditing]=useState(false);
  const[editVal,sEV]=useState('');
  const[saving,sSaving]=useState(false);
  useEffect(()=>{if(variable){api.g('variables/'+variable.id).then(sD);sEditing(false);}},[variable?.id]);
  if(!variable||!d)return null;
  const css=cssTokenName(variable.name);
  const isGen=variable.type==='generated';
  const isFluidV=isFluidVal(variable.value);
  const fluidPair=isFluidV?parseFluid(variable.value):null;
  const fluidLabel=fluidPair?(trimNum(fluidPair[0])+' → '+trimNum(fluidPair[1])+'px fluid'):'';
  // Fluid variables can't be edited with the single-field inline editor — send to full edit panel.
  const startEdit=()=>{if(isGen)return;if(isFluidV){onEditFull&&onEditFull(variable);return;}sEV(variable.value);sEditing(true);};
  const saveVal=async()=>{if(!editVal||editVal===variable.value){sEditing(false);return;}
    sSaving(true);
    const r=await api.u('variables/'+variable.id,{value:editVal});
    sSaving(false);sEditing(false);
    if(r&&!r.code&&onUpdate)onUpdate();
  };
  return h('div',{class:'ve-det'},
    h('div',{class:'ve-det-t'},h('span',null,variable.name),h('button',{class:'ve-exp',onClick:onClose},ph('x'))),
    h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'Value'),
      editing?h('div',{style:'display:flex;gap:3px;flex:1'},
        h('input',{style:'flex:1;padding:2px 4px;background:#2a2a2a;border:1px solid #baf400;border-radius:3px;color:#f1f1f1;font-size:10px;font-family:monospace;outline:none',value:editVal,onInput:e=>sEV(e.target.value),onKeyDown:e=>{if(e.key==='Enter')saveVal();if(e.key==='Escape')sEditing(false);}}),
        h('button',{class:'ve-btn ve-btn-s',style:'padding:1px 6px;font-size:8px',onClick:saveVal,disabled:saving},saving?'...':'✓'))
      :h('span',{class:'ve-det-v',style:isGen?'':'cursor:pointer',onClick:startEdit,title:isGen?'Generated — edit base variable':(isFluidV?'Fluid — click to edit min/max':'Click to edit')},isFluidV?fluidLabel:variable.value)),
    isFluidV&&h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'Fluid'),h('span',{class:'ve-det-v',style:'font-size:9px;color:#baf400;word-break:break-all'},variable.css_value||d.css_value||'')),
    h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'CSS'),h('span',{class:'ve-det-v'},'var('+css+')')),
    h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'Type'),h('span',{class:'ve-det-v'},variable.type||'base')),
    d.dependents?.length>0&&h('div',{class:'ve-dep-s'},h('div',{class:'ve-dep-t'},'Dependents ('+d.dependents.length+')'),
      d.dependents.slice(0,6).map(x=>h('div',{class:'ve-dep',onClick:()=>onNav(x)},x.name))),
    d.depends_on?.length>0&&h('div',{class:'ve-dep-s'},h('div',{class:'ve-dep-t'},'Source'),
      d.depends_on.map(x=>h('div',{class:'ve-dep',onClick:()=>onNav(x)},x.name))));
}

/* ── Main ──────────────────────────────── */
function Panel(){
  const[open,sO]=useState(false);const[vars,sV]=useState([]);const[stats,sStats]=useState(null);const[sr,sSr]=useState('');
  const[sel,sSel]=useState(null);const[nsTab,sNT]=useState('all');
  const[exp,sExp]=useState({});const[toast,sToast]=useState('');const[cfm,sCfm]=useState(null);
  const[sub,sSub]=useState(null);const[autoGen,sAG]=useState(null);
  const[updateInfo,sUpdateInfo]=useState(null);const[skipUpdate,sSkipUpdate]=useState(()=>localStorage.getItem('ve_skip_update_version')||'');
  const sRef=useRef();

  const load=useCallback(async()=>{const v=await api.g('variables?dedupe=true');if(Array.isArray(v))sV(v);api.g('variables/stats').then(d=>{if(d&&!d.code)sStats(d);}).catch(()=>{});},[]);
  useEffect(()=>{load();},[]);
  useEffect(()=>{api.g('settings').then(d=>{if(d&&d.vw_min)_veViewport={vw_min:+d.vw_min||320,vw_max:+d.vw_max||1440};}).catch(()=>{});},[]);
  useEffect(()=>{if(!open)return;const t=setInterval(load,3500);const f=()=>load();window.addEventListener('focus',f);document.addEventListener('visibilitychange',f);return()=>{clearInterval(t);window.removeEventListener('focus',f);document.removeEventListener('visibilitychange',f);};},[open,load]);
  useEffect(()=>{if(!open)return;let alive=true;const check=()=>api.p('update/check',{}).then(r=>{if(alive&&r&&!r.code)sUpdateInfo(r);}).catch(()=>{});check();const t=setInterval(check,10*60*1000);return()=>{alive=false;clearInterval(t);};},[open]);
  useEffect(()=>{if(autoGen){const v=vars.find(x=>x.id===autoGen.id||x.name===autoGen.name);if(v){sSub({type:'genScale',v});sAG(null);}};},[vars,autoGen]);
  useEffect(()=>{const fn=e=>{if(e.altKey&&(e.key==='z'||e.key==='Z')){e.preventDefault();sO(p=>!p);setTimeout(()=>sRef.current?.focus(),80);}};document.addEventListener('keydown',fn);return()=>document.removeEventListener('keydown',fn);},[]);
  useEffect(()=>{const fn=()=>{sO(p=>!p);setTimeout(()=>sRef.current?.focus(),80);};window.addEventListener('ve-toggle-panel',fn);return()=>window.removeEventListener('ve-toggle-panel',fn);},[]);

  const genSort=useCallback((a,b)=>{
    const av=pxV(a.value), bv=pxV(b.value);
    if(av!==bv)return av-bv;
    return String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true,sensitivity:'base'});
  },[]);

  const{bases,childMap,namespaces}=useMemo(()=>{
    const cm={};const ns=new Set();const bs=[];
    vars.forEach(v=>{ns.add(v.namespace);if(v.type==='generated'&&v.source_id){if(!cm[v.source_id])cm[v.source_id]=[];cm[v.source_id].push(v);}});
    Object.keys(cm).forEach(k=>cm[k].sort(genSort));
    vars.forEach(v=>{if(v.type!=='generated')bs.push(v);});
    bs.sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true,sensitivity:'base'}));
    return{bases:bs,childMap:cm,namespaces:['all',...[...ns].sort()]};
  },[vars,genSort]);

  const maxSp=useMemo(()=>{let mx=0;vars.forEach(v=>{if(v.namespace==='space'){const n=pxV(v.value);if(n>mx)mx=n;}});return mx||1;},[vars]);
  const filtered=useMemo(()=>{
    let list=nsTab==='all'?bases:bases.filter(v=>v.namespace===nsTab);
    if(sr){const mp=new Set();vars.forEach(v=>{if(v.type==='generated'&&v.source_id&&fuzzy(sr,v.name).m)mp.add(String(v.source_id));});
    list=list.map(v=>({...v,...fuzzy(sr,v.name),cm:mp.has(String(v.id))})).filter(v=>v.m||v.cm).sort((a,b)=>(b.s||0)-(a.s||0));}return list;
  },[bases,vars,sr,nsTab]);
  const cleanupIssues=useMemo(()=>stats?[(stats.stale_generated?stats.stale_generated+' stale generated':''),(stats.orphan_generated?stats.orphan_generated+' orphan generated':''),(stats.duplicate_count?stats.duplicate_count+' duplicate names':''),(stats.older_generators?stats.older_generators+' older generators':'')].filter(Boolean):[],[stats]);

  const flash=m=>{sToast(m);setTimeout(()=>sToast(''),1400);};
  const cpVar=n=>{navigator.clipboard?.writeText('var('+cssTokenName(n)+')');flash('Copied!');};
  const tgExp=(id,defaultOpen=false)=>sExp(p=>{const k=String(id);const has=Object.prototype.hasOwnProperty.call(p,k);return {...p,[k]:has?!p[k]:!defaultOpen};});
  const hSel=v=>sSel(prev=>prev?.id===v.id?null:v);
  const cleanDbFooter=async()=>{
    if(!confirm('Clean duplicate, stale, and orphan generated variables from WordPress? This keeps base variables and rebuilds recoverable generated variants.'))return;
    try{flash('Cleaning...');const r=await api.p('variables/cleanup',{});await load();flash(r?.message||'Cleaned');}
    catch(e){flash('Cleanup failed');}
  };
  const hDup=async v=>{await api.p('variables',{name:v.name+'.copy',value:v.value});load();flash('Duplicated');};
  const hDel=async v=>{if((childMap[v.id]||[]).length){sCfm(v);return;}await api.d('variables/'+v.id+'?force=true');load();flash('Deleted');if(sel?.id===v.id)sSel(null);};
  const cfmDel=async()=>{if(!cfm)return;await api.d('variables/'+cfm.id+'?force=true');load();flash('Deleted');sSel(null);sCfm(null);};
  const hCreated=(nv,isClamp)=>{load();sSub(null);flash('Created');if(isClamp)sAG(nv);};
  const allCats=[...new Set(['color','space','font','radius','size','shadow','opacity','motion',...namespaces.filter(n=>n!=='all')])].sort();
  /* Animated close: set a sentinel, let Sub detect it and animate, then clear */
  const[subExit,sSE]=useState(false);
  const closeSub=useCallback(()=>{sSE(true);setTimeout(()=>{sSub(null);sSE(false);},SLIDE_MS);},[]);

  return h('div',null,
    h('div',{class:'ve-toast'+(toast?' show':'')},toast),
    MODE==='builder'&&!open&&h('div',{class:'ve-fab',onClick:()=>sO(true),title:"Mimam's Var - WP (Alt+Z)"},ph('stack')),
    open&&h('div',{class:'ve-bd show',onClick:()=>sO(false)}),
    h('div',{class:'ve-o'+(open?' open':'')},
      cfm&&h('div',{class:'ve-cf'},h('div',{class:'ve-cf-b'},h('p',null,'Delete "',cfm.name,'" and all variants?'),
        h('div',{style:'display:flex;gap:5px;justify-content:center'},h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sCfm(null)},'Cancel'),h('button',{class:'ve-btn ve-btn-d ve-btn-s',onClick:cfmDel},'Delete')))),

      h('div',{class:'ve-hdr'},CFG.logoUrl?h('img',{class:'ve-hdr-i',src:CFG.logoUrl,alt:''}):h('div',{class:'ve-hdr-i'}),h('span',{class:'ve-hdr-t'},"Mimam's Var - WP"),
        h('div',{class:'ve-hdr-a'},
          h('button',{onClick:()=>{if(sub==='settings')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('settings'),sub?SLIDE_MS+10:0);}},title:'Settings'},ph('gear')),
          h('button',{onClick:()=>{if(sub==='sync')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('sync'),sub?SLIDE_MS+10:0);}},title:'Sync'},ph('cloud-arrow-up')),
          h('button',{onClick:()=>{if(sub==='create')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('create'),sub?SLIDE_MS+10:0);}},title:sub==='create'?'Close new variable':'New variable'},ph(sub==='create'?'x':'plus')),
          h('button',{onClick:load,title:'Refresh'},ph('arrows-clockwise')),
          h('button',{onClick:()=>sO(false),title:'Close'},ph('x')))),

      sub==='settings'&&h(SettingsPanel,{onClose:closeSub,exiting:subExit}),
      sub==='sync'&&h(SyncPanel,{onClose:closeSub,exiting:subExit,onReload:load,onDone:()=>{sSub(null);load();flash('Sync complete');}}),
      sub==='create'&&h(CreateSub,{onCreated:hCreated,onClose:closeSub,categories:allCats,vars,exiting:subExit}),
      sub?.type==='edit'&&h(EditSub,{variable:sub.v,categories:allCats,vars,onDone:()=>{sSub(null);load();flash('Updated');},onClose:closeSub,exiting:subExit}),
      sub?.type==='genColor'&&h(GenColorSub,{variable:sub.v,childMap,onDone:()=>{sSub(null);load();flash('Generated');},onClose:closeSub,exiting:subExit}),
      sub?.type==='genScale'&&h(GenScaleSub,{variable:sub.v,onDone:()=>{sSub(null);load();flash('Generated');},onClose:closeSub,exiting:subExit}),

      !sub&&h('div',{style:'display:flex;flex-direction:column;flex:1;min-height:0'},
        h('div',{class:'ve-sr'},h('input',{ref:sRef,placeholder:'Search... (Alt+Z)',value:sr,onInput:e=>sSr(e.target.value)})),
        h('div',{class:'ve-tabs'},namespaces.map(ns=>h('div',{class:'ve-t'+(nsTab===ns?' on':''),onClick:()=>sNT(ns)},ns))),
        updateInfo?.update_available&&updateInfo.latest_version!==skipUpdate&&h('div',{class:'ve-update'},
          ph('arrow-circle-up'),
          h('span',null,h('b',null,'Update available: '), 'v'+updateInfo.latest_version),
          updateInfo.update_admin_url&&h('button',{class:'ve-btn ve-btn-s',onClick:()=>{window.location.href=updateInfo.update_admin_url;}},'Update'),
          h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>{localStorage.setItem('ve_skip_update_version',updateInfo.latest_version);sSkipUpdate(updateInfo.latest_version);}},'Skip')),
        cleanupIssues.length>0&&h('div',{class:'ve-clean'},
          h('span',null,'WP cleanup available: '+cleanupIssues.join(', ')),
          h('button',{class:'ve-btn ve-btn-g',onClick:cleanDbFooter},'Clean')),
        h('div',{class:'ve-body'},
          filtered.length===0?h('div',{class:'ve-empty'},sr?'No matches':'No variables'):
          filtered.map(v=>{
            const kids=childMap[v.id]||[];const expKey=String(v.id);const hasExp=Object.prototype.hasOwnProperty.call(exp,expKey);const iE=sr?true:(hasExp?!!exp[expKey]:false);
            const isSp=v.namespace==='space';const spW=isSp?Math.max(4,pxV(v.value)/maxSp*100):0;
            const bc=stripeColor(v);
            return h('div',{key:v.id},
              h('div',{class:'ve-v'+(sel?.id===v.id?' sel':''),style:`--ve-ns:${bc};padding-left:14px`,title:v.namespace,onClick:()=>hSel(v)},
                kids.length>0?h('button',{class:'ve-exp',onClick:e=>{e.stopPropagation();tgExp(v.id,false);}},ph(iE?'minus':'plus')):h('div',{style:'width:18px'}),
                h(Sw,{v:v.value}),
                h('div',{class:'ve-inf'},h('div',{class:'ve-nm'},sn(v.name)),h('div',{class:'ve-vl'},v.value),isSp&&h('div',{class:'ve-sb',style:`width:${spW}%`})),
                h('div',{class:'ve-as'},
                  h('button',{class:'ve-a',title:'Edit',onClick:e=>{e.stopPropagation();sSub({type:'edit',v});}},ph('pencil-simple')),
                  h('button',{class:'ve-a',title:'Generate',onClick:e=>{e.stopPropagation();sSub(isClr(v.value)?{type:'genColor',v}:{type:'genScale',v});}},ph('sun')),
                  h('button',{class:'ve-a',title:'Duplicate',onClick:e=>{e.stopPropagation();hDup(v);}},ph('copy')),
                  h('button',{class:'ve-a',title:'Copy var()',onClick:e=>{e.stopPropagation();cpVar(v.name);}},ph('clipboard-text')),
                  h('button',{class:'ve-a',title:'Delete',onClick:e=>{e.stopPropagation();hDel(v);}},ph('trash')))),
              kids.length>0&&iE&&h('div',{class:'ve-ch'},kids.map(c=>h('div',{class:'ve-c',key:c.id,onClick:()=>hSel(c)},
                h(Sw,{v:c.value}),h('div',{class:'ve-inf'},h('div',{class:'ve-nm'},sn(c.name)),h('div',{class:'ve-vl'},c.value)),
                h('button',{class:'ve-a',style:'opacity:.6',title:'Copy var()',onClick:e=>{e.stopPropagation();cpVar(c.name);}},ph('clipboard-text'))))));
          })),
        sel&&h(Detail,{variable:sel,onNav:d=>{const f=vars.find(v=>v.id===d.id||v.name===d.name);if(f)sSel(f);},onClose:()=>sSel(null),onUpdate:()=>{load();flash('Updated');},onEditFull:v=>sSub({type:'edit',v})}),
      ),
      h('div',{class:'ve-st'},
        h('div',{class:'ve-st-left'},
          h('span',null,(stats?(stats.base||0)+' base · '+(stats.generated||0)+' generated':vars.length+' variables')),
          cleanupIssues.length>0&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',title:'Clean WordPress variable database',onClick:cleanDbFooter},'Clean WP DB')
        ),
        h('span',null,'v'+(CFG.version||'1.1.16')))),
  );
}

function mt(){const s=document.createElement('style');s.textContent=CSS;document.head.appendChild(s);
const r=document.createElement('div');r.id='ve-panel-root';document.body.appendChild(r);render(h(Panel),r);wireGsapHover(r);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mt);else mt();
})();
