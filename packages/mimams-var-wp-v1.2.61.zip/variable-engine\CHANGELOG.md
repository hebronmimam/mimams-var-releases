## v1.2.60 - Floating shell cleanup and freeze-reduction pass

**By:** Hebronmimam ft ChatGPT

- Renumbered the active check focus after v1.2.59 feedback: old C03, C04, and C10 are treated as working; old C08 and C09 move to later persistence testing.
- Bumped Mimam's Var package version to 1.2.60 and Mimam's Bar module version to 0.3.17.
- Added cached Bricks Elements/Structure panel detection so floating-state recovery does not keep doing broad DOM scans once the correct panels have been found.
- Throttled the heavier panel-finder fallback scans and reduced retry passes to lower the chance of Bricks freezing while floating panel settings are active.
- Expanded floating host cleanup to nearby side-panel wrapper ancestors, not just the immediate parent, so the old static slot/background is more likely to collapse after a panel floats.
- Added stronger transparent host styling and hidden non-floating siblings inside floating host slots to reduce leftover static panel backgrounds.
- Added a cleaner floated-panel shell with top padding for the move handle, stronger background control, and calmer resize/handle placement without changing the already-working drag logic.

## v1.2.59 - Floating persistence, drag recovery, and freeze hardening

**By:** Hebronmimam ft ChatGPT

- Focused this build on the unresolved v1.2.58 checks: floating panel design cleanup, static background leftovers, Elements/Structure drag stability, typing lag, general freezing, settings/layout persistence, and tab-switch recovery.
- Bumped Mimam's Var package version to 1.2.59 and Mimam's Bar module version to 0.3.16.
- Changed floating panel reapplication so active floated panels are no longer fully cleared and rebuilt on every pass; stale panel classes are cleaned selectively instead.
- Collapsed floating panel host wrappers more strongly, including height/block-size cleanup, so the old static panel slot is less likely to remain visible after floating.
- Persisted and reapplied floating panel positions/heights with a calmer retry flow after builder reloads.
- Improved drag recovery by using pointer capture where available, suppressing duplicate mouse fallback starts, disabling panel transitions during drag, and raising the drag shield/panel stacking above the builder canvas.
- Added tab/page visibility recovery so floating panel state and target refresh are reapplied after switching away from and back to the Bricks tab.
- Cleared pending suggestion/target timers when Mimam's Bar closes to reduce stacked delayed work.
- Added light caching around Bricks Vue globals and element tree scans to reduce repeated DOM/Vue lookups during normal typing and search use.

## v1.2.58 - Performance hardening and floating panel cleanup

**By:** Hebronmimam ft ChatGPT

- Reviewed the uploaded WordPress core ZIP package structures for context. The lag issue is most likely coming from the builder-tool runtime and floating-panel DOM/CSS pressure, not WordPress core files directly.
- Removed confirmed-working checks from the active test focus.
- Reworked floating panel CSS to use a lighter, single consolidated style layer instead of multiple stacked legacy floating-panel override blocks.
- Removed expensive universal scrollbar and dragging selectors that targeted every descendant inside Bricks panels.
- Collapsed floating panel host wrappers so the old static panel background is less likely to remain visible behind floated Elements/Structure panels.
- Rebuilt floating panel dragging to use transform while dragging, then commit top/left after release. This reduces layout pressure during drag.
- Added mouse fallback and blur cleanup for floating panel drag so the drag shield does not remain active after tab switching or focus loss.
- Reapplied critical top/left/position styles inline for floating panels to reduce Bricks CSS override conflicts.
- Reduced floating panel retry scans and slowed suggestion/result rendering to reduce typing pressure.
- Bumped Mimam's Var package version to 1.2.58 and Mimam's Bar module version to 0.3.15.

## v1.2.57 - Floating drag stability, scrollbar polish, under-bar toasts, and freeze hardening

**By:** Hebronmimam ft ChatGPT

- Kept confirmed-working checks out of the active checklist.
- Improved floating panel visual polish so Elements and Structure floats feel closer to Mimam's Var panels.
- Reworked floating panel drag with a drag shield and window-level pointer tracking so Bricks does not steal the drag mid-move.
- Removed visible Move panel text from floating handles and kept icon-only Phosphor duotone-style handles.
- Added safer floating host cleanup to reduce blank/static background leftovers when panels float or reset.
- Styled Mimam's Bar and floating panel scrollbars to match the dark/acid system.
- Moved transient toasts clearly under Mimam's Bar when open, with more spacing and no overlap.
- Auto-closes Settings and Help panels once the user starts typing in the command field.
- Reduced panel retry scans and removed broad full-DOM rail scanning to reduce lag/freezing.
- Increased debounce timing for search/suggestion redraws to reduce typing pressure.
- Bumped Mimam's Var package version to 1.2.57 and Mimam's Bar module version to 0.3.14.

## v1.2.56 - Floating panel polish, persistent float state, and drag/lag hardening
- By: Hebronmimam ft ChatGPT
- Polishes floating Bricks panels to feel more like Mimam's Var panels, with cleaner borders, radius, and shadows.
- Adds Phosphor duotone icon-only floating handles.
- Persists floating panel position and height after dragging/resizing.
- Reapplies floating panel state after Bricks finishes loading so enabled float settings persist across reloads.
- Improves floating Structure behavior by trying to include nearby right-side shortcut rails with the Structure panel.
- Reduces drag lag by using requestAnimationFrame and temporarily reducing pointer work during drag.
- Moves under-bar toast farther below Mimam's Bar with clear spacing.
- Adds another lag-reduction pass for typing and target refresh.

## v1.2.55 - Softer selections, floating panel drag fix, under-bar toasts, and lag pass
**By:** Hebronmimam ft ChatGPT

- Reduced active selection contrast in Search Page and Add Element result lists.
- Fixed floating panel dragging by applying drag positions with priority over Bricks panel CSS.
- Floating panel styles are now cleaned up when float mode is disabled to avoid blank/white panel areas.
- Replaced floating handle mark with a Phosphor duotone handle icon class.
- Reduced heavy/pixelated shadows on Mimam's Bar and floating panels.
- Add Element Safe Add messages now show as toasts instead of inline bar errors.
- Error toasts now use red border treatment.
- Toasts now appear directly under Mimam's Bar when it is open, and bottom-center when it is closed.
- Added another typing-lag pass by slowing expensive suggestion/result redraws.

## v1.2.54 - Structure selection, draggable floating panels, bottom toast, and lag pass
- By Hebronmimam ft ChatGPT.
- Improved Search Page selection so Bricks activeId is updated before Bricks' own setActiveElement helper runs.
- Added stronger Structure panel focus/jump attempts after Search Page selection.
- Added draggable handles for floating Elements and Structure panels.
- Floating panels now start at about 70% of their original height and can be resized vertically.
- Toast/error popups now appear bottom-center instead of top-right.
- Added stale Add Element result reset after blocked/errors so the next error label follows the current highlighted element.
- Further reduced typing lag by debouncing Direct-mode suggestion rendering and reducing unnecessary immediate renders.

## v1.2.53 - Selection reliability, lighter suggestions, floating panel options, and docs
- Fixed Search Page selection fallback so selecting a target can work even when no element was previously selected.
- Added a manual selected-element fallback inside the Bricks adapter for safer direct commands after Search Page selection.
- Search Page now searches custom element labels/settings labels more reliably.
- Add Element mode now resolves the current highlighted result fresh before adding, reducing stale warning labels.
- Command suggestions now support Arrow Up and Arrow Down navigation.
- Mimam's Var token suggestions now use softer color and lighter weight.
- Hide Elements panel is safer and no longer uses broad aria/title selectors that could hide the whole builder view.
- Added optional floating Elements/Structure panel settings with opacity control.
- Added more lag hardening around suggestion rendering and selection refresh.

## v1.2.52 - Search target selection, highlighted completion, and MV token helpers

- Fixed Search Page target selection when no element was previously selected.
- Added best-effort Structure panel jump/scroll when selecting an element from Search Page mode.
- Kept Mimam's Bar in the current mode after adding elements instead of jumping back to Direct mode.
- Improved Add Element Tab completion so it completes from the highlighted suggestion first.
- Fixed stale highlighted-result handling that could show the wrong no-target add error.
- Added first Mimam's Var integration helpers: Direct mode can suggest saved variable tokens when typing `var `, `token `, or `--`.
- Added the token helper to the lightweight Help mode.

## v1.2.50 - Softer bar hierarchy and Emmet Tab completion

- Softened the Mimam's Bar Target label and mode labels so they no longer compete visually with the main input/action flow.
- Added Emmet Tab completion in Add Element mode.
- Typing aliases such as `cont`, `btn`, `img`, `sec`, `blk`, or heading shortcuts can now be completed with Tab before continuing a chain.
- Supports chain-token completion such as `section>cont` → `section>container`, so the user can continue typing `>button`.
- Kept the update focused on current user feedback and moved deferred freeze/bulk checks into the later-checks list.

## v1.2.49 - Freeze hardening, Add Element Emmet basics, and calmer bar hierarchy
- Hardened Mimam's Bar open-state performance by removing duplicate capture listeners and pausing iframe pointer listeners.
- Page Search and Add Element modes no longer scan/render a default result list on empty input.
- Added lightweight caching for page elements and Bricks element library results while a search mode is active.
- Added Emmet-style Add Element shortcuts and simple chained structure support for safe core elements.
- Added a calmer visual hierarchy using Mimam's Var-style contrast: fewer loud accents, softer rows, and clearer primary/secondary emphasis.
- Carried unresolved bulk checks forward without re-adding confirmed-working checks.

## v1.2.48 - Freeze Guard and Lighter Open-State Processing

- Added open-state freeze guards for Mimam's Bar.
- Throttled target refreshes while the bar is open so canvas clicks no longer schedule multiple refresh passes.
- Debounced element result rendering while typing in Search Page and Add Element modes.
- Arrow-key navigation now uses the already-rendered result list instead of rescanning Bricks elements on every arrow press.
- Added duplicate keydown protection so the same shortcut or Enter event cannot be handled twice by both window and document listeners.
- Reduced iframe/canvas listener rebinding while the panel is open.
- Kept unresolved Bulk checks for the next testing round: confirmation, narrow selector apply, and save after bulk.
- Bumped Mimam's Var package version to 1.2.48.
- Bumped bundled Mimam's Bar module version to 0.3.5.

## v1.2.47 - Safe Add Element Flow and Settings Fix
- Changed Mimam's Bar Auto-close default to off and added a one-time migration so the panel stays open after actions unless Auto-close is intentionally enabled again.
- Added Safe Add guards for Add Bricks Element mode: non-section elements now require a selected target first, preventing unsafe no-target insert attempts.
- Paused direct adding of third-party/custom elements from Mimam's Bar until core Bricks elements are confirmed stable.
- Added an add-operation lock to prevent repeated add calls while Bricks is still processing an insertion.
- Improved Add Element failure messages so unclear add-helper failures can be moved forward as exact checks instead of guessing.
- Improved Elements panel hiding with dynamic left-panel detection while keeping Structure separate.

## v1.2.46 - Add Element Diagnostics and Safer Element Search

### Added
- Added safer Add Bricks Element diagnostics for Mimam's Bar.
- Add Element mode now requires a second Enter/click confirmation before calling the Bricks add-element helper.
- The confirmation message shows the exact element label, internal element name, and whether it looks like a core or custom/third-party element.
- Added console info output before an element add attempt so failed tests can identify the exact element being added.
- Added active result highlighting and Arrow Up / Arrow Down navigation for element results.

### Improved
- Add Element search now ranks core Bricks elements such as `image` above custom/dynamic elements when typing short queries like `im`.
- Element result rows now show whether a result is likely `core` or `custom`.

### Notes
- This release does not attempt to force-add every third-party element safely. It is designed to identify which exact element triggers the Bricks out-of-memory behavior before a deeper add-helper fix.

## v1.2.45 - Mimam's Bar Suggestions and No-Target Flow
- Added context-aware command suggestions in Mimam's Bar Direct mode.
- Typing `-` now suggests classes available on the selected element for safe selected-element class removal.
- Typing `delete` now suggests attributes available on the selected element; typing `delete .` suggests classes for guarded global cleanup.
- Tab or Enter accepts the visible suggestion without immediately applying the command.
- Mimam's Bar can now open even when no Bricks element is selected.
- When no element is selected, the bar opens in Search page mode so a target can be chosen, and Direct mode is blocked with a clear message until a target exists.
- Kept the module mode-based and added the command suggestion behavior as its own module.

## v1.2.44 - Builder Tools Mimam's Bar merge
- Added Mimam's Bar as a modular Builder Tools module inside the Bricks builder context.
- Bundled the v0.3.1 architecture-refactored Mimam's Bar assets under modules/builder-tools/mimams-bar.
- Mimam's Bar loads only in Bricks builder and is skipped when the standalone Mimam's Bar plugin is active.
- Fixed Hide Bricks elements so it no longer hides the Structure panel.
- Kept the module type-first and mode-based: Direct, page element search, add Bricks element, Bulk, Settings, and guarded dialogs.

# v1.2.43 - CSS Studio Selector Context Suggestions

- Added selector-context autocomplete so bare selector typing suggests elements, pseudo selectors, and at-rules instead of CSS properties outside declaration blocks.
- Added backend selector indexing for scanned CSS, including element selectors, pseudo selectors, and common at-rules, with a fresh suggestion cache key.
- Fixed selector extraction so normal selectors like `.hero:hover` and `button#cta` are indexed as `.hero` and `#cta`, while escaped class variants like `.focus\:ring` do not leak fake pseudo hints.

# v1.2.42 - CSS Studio Inline Variable Indexing

- Added cached live indexing for inline styles, root/body style attributes, and computed root/body CSS custom properties.
- CSS Studio autocomplete can now learn `--tokens` and `var(--tokens)` that are rendered inline by builders or plugins instead of only stored in database scans or stylesheet rules.
- Replaced CodeMirror's generic bracket auto-closer with a tiny Mimam's Var `{}` handler so brace completion stays simple while preserving custom Enter indentation and Tab property completion.

# v1.2.41 - CSS Studio Live CSSOM Indexing

- Added cached CSSOM scanning for accessible stylesheets in the current document and same-origin frames.
- CSS Studio autocomplete can now learn class selectors, ID selectors, and CSS custom properties from loaded stylesheets in the live page/builder environment.
- Cross-origin stylesheets are skipped silently, and CSSOM traversal is capped so suggestions broaden without slowing the editor.

# v1.2.40 - CSS Studio Live Frame DOM Indexing

- Expanded CSS Studio's browser-side class/ID collector to scan the current document plus accessible same-origin frames and iframes.
- Added SVG-safe class extraction through `className.baseVal`, while still excluding Mimam's Var internal `ve-` UI classes and IDs.
- Kept DOM indexing cached and capped so live builder suggestions improve without making editor typing heavy again.

# v1.2.39 - CSS Studio Segment Autocomplete

- Improved CSS Studio autocomplete lookup so class, ID, and variable suggestions compare both the typed token and the bare segment form.
- Queries like `.primary` can now surface `.btn-primary`, and `--primary` can surface `--color-primary` from the appropriate suggestion pool.
- Verified editor helper behavior for Enter indentation, auto-closed block indentation, Tab property completion, and segment lookup with local Node checks.

# v1.2.38 - CSS Studio Source Template Indexing

- Added capped scanning for PHP, HTML, JS, TS, JSX, TSX, Vue, Svelte, Twig, and Mustache files inside active themes and known builder/source plugins.
- Expanded class and ID extraction for source-code patterns such as `className: '...'`, template strings, class arrays, `classList.add(...)`, and `querySelector(...)`.
- Bumped the CSS Studio suggestion cache key so the broader source-template index rebuilds immediately after update.

# v1.2.37 - CSS Studio Snippet Table Indexing

- Added bounded custom-table scanning for known snippet and builder helper tables, including WPCodeBox, Code Snippets, Bricks, Advanced Themer, ACSS, Core Framework, Code2Bricks, and Etch-style storage.
- Reads only text/json-like columns from matched tables and only keeps rows that look like CSS selectors, classes, IDs, or custom properties, so indexing gets broader without turning into a full database crawl.
- Bumped the CSS Studio suggestion cache key so the new snippet-table index rebuilds immediately after update.

# v1.2.36 - CSS Studio Scanned Class Map Prepass

- Added a scanned-payload prepass that learns class ID-to-name pairs from Bricks/class-like data found in posts, postmeta, options, generated CSS payloads, and source files.
- Uses the expanded class map before structured data extraction so CSS Studio can resolve more stored class IDs into readable class suggestions.
- Bumped the CSS Studio suggestion cache key so the broader class map rebuilds immediately after update.

# v1.2.35 - CSS Studio Builder Class Name Mapping

- Added Bricks global class ID-to-name mapping so CSS Studio autocomplete can show readable class names when builder content stores class IDs.
- Added detected global class names directly into the suggestion index.
- Updated structured builder-data scanning to resolve mapped class IDs while still preserving raw class names from other sources.

# v1.2.34 - CSS Studio Index Refresh

- Added a force-refresh option for the CSS Studio suggestions endpoint so the class, ID, and variable index can be rebuilt immediately instead of waiting for cache expiry.
- Added a Refresh Index button inside CSS Studio settings.
- Added suggestion index counts for variables, classes, and IDs so it is clearer what the editor currently knows about.

# v1.2.33 - CSS Studio Template Class Indexing

- Added targeted active-theme template scanning for PHP, HTML, Twig, and Mustache files so CSS Studio can index static `class`, `className`, `id`, and CSS custom-property usage without broad source-code noise.
- Improved CSS selector extraction for escaped utility-style class selectors, preserving classes such as responsive or state variants more faithfully in autocomplete.
- Bumped the CSS Studio suggestion cache key so the template index rebuilds immediately after update.

# v1.2.32 - CSS Studio Theme and Source Plugin Indexing

- Added capped scanning for active theme CSS, SCSS, LESS, and JSON files so CSS Studio autocomplete can see classes, IDs, and variables defined in theme source files.
- Added capped scanning for known source plugin folders including Bricks, Automatic.css, ACSS, Advanced Themer, Core Framework, WPCodeBox, Code2Bricks, and Etch.
- Skipped vendor, bundled editor, ACF, minified, and oversized files so broader indexing stays lightweight.
- Bumped the CSS Studio suggestion cache key so the new source-file index rebuilds immediately after update.

# v1.2.31 - CSS Studio Generated CSS Indexing

- Added bounded generated-CSS scanning from likely uploads folders for Bricks, Automatic.css, ACSS, Core Framework, Advanced Themer, and Mimam's Var output.
- Extracted classes, IDs, and CSS custom properties from those generated CSS files so autocomplete can see source data that is not stored plainly in WordPress options.
- Bumped the CSS Studio suggestion cache key again so the generated-CSS index rebuilds immediately after update.
- Improved CodeMirror and fallback editor Enter behavior inside auto-closed `{}` blocks while preserving same-indent-after-semicolon and deeper-indent-for-unfinished-lines behavior.

# v1.2.30 - CSS Studio Source-Aware Indexing

- Added external migration-detected tokens from Bricks, Advanced Themer, Core Framework, and Automatic.css into CSS Studio variable autocomplete.
- Expanded option scanning for known global class, global variable, Advanced Themer, ACSS, Core Framework, and custom CSS storage keys.
- Added a targeted Bricks/global-class parser for `globalClassesNamesIds` style payloads that may be embedded in scripts rather than stored as clean JSON.
- Bumped the CSS Studio suggestion cache key so updated sites rebuild the richer index immediately after update.

# v1.2.29 - CSS Studio Smooth Autocomplete

- Debounced CodeMirror editor saves so typing stays local-first and no longer rerenders the full Mimam's Var panel on every keystroke.
- Guarded automatic autocomplete so braces and normal typing do less work while `--`, `.`, `#`, `@`, and CSS property prefixes still open useful suggestions.
- Increased the autocomplete result window while keeping the hint menu scrollable and compact.
- Improved CSS Studio indexing cache to include CSS custom properties found in external builder/plugin data and existing CSS.
- Kept CodeMirror syntax coloring active for comments, strings, colors, variables, properties, numbers, and keywords.

# v1.2.28 - CSS Studio CodeMirror Foundation

- Added CodeMirror 5 as the primary CSS Studio editor in WP admin and Bricks builder, with the previous textarea editor kept as a fallback.
- Wired Mimam's Var variables, classes, IDs, CSS properties, CSS values, and recipes into CodeMirror autocomplete.
- Added Enter indentation behavior: after a semicolon the next line keeps indentation, while unfinished lines indent one level deeper.
- Broadened CSS Studio indexing across more posts, post meta, builder/plugin options, class-like options, and term slugs.
- Increased suggestion bucket limits so larger sites can expose more classes, IDs, and variables to Studio autocomplete.

# v1.2.27 - CSS Studio Highlighting and Faster Suggestions

- Disabled live auto-format in CSS Studio so typing no longer moves the cursor unexpectedly.
- Replaced expensive per-keystroke suggestion scoring with pre-indexed lookup for variables, classes, IDs, properties, and values.
- Reduced post-edit work after auto-closing braces so `{}` pairing no longer immediately asks autocomplete to rescan.
- Added lightweight CSS syntax highlighting for comments, strings, colors, variables, properties, numbers, and punctuation.
- Improved variable suggestion ordering so common Mimam's Var token families surface earlier.

# v1.2.26 - CSS Studio Smooth Editing

- Added CSS editor brace pairing so typing `{` inserts a matching closing brace with the cursor inside the block.
- Improved property autocomplete so Tab inserts `property:  ;` and places the cursor before the semicolon.
- Made CSS Studio typing smoother by keeping editor keystrokes in a local draft instead of rerendering the whole Studio panel on every key.
- Cached DOM/class/ID suggestion pools and backend class/ID scans so autocomplete is lighter and Studio opens with less repeated work.
- Raised the autocomplete menu above the editor surface so suggestions do not appear visually behind the code area.
- Studied Code2Bricks, Advanced Themer, ACSS, and Etch assets for editor/performance patterns and applied the relevant lightweight patterns without copying their code.

# v1.2.25 - CSS Studio Sidecar Visibility

- Fixed the CSS Studio editor sidecar being clipped by the rounded main panel shell.
- Kept internal panel/body scrolling intact while allowing sidecar panels to render beside the main MV panel.

# v1.2.24 - CSS Studio Sidecar Restore

- Changed the CSS Studio editor sidecar header action from a back arrow to a close icon.
- Restored the CSS Studio code editor sidecar layout so the editor fills the sidecar reliably.
- Expanded CSS Studio autocomplete indexing across more WordPress posts, post meta, options, builder-shaped class/id data, and current DOM classes/IDs.
- Improved autocomplete ranking so typed prefixes are prioritized while still searching the fuller known suggestion pool.

# v1.2.23 - Color Picker Hue and CSS Studio Autocomplete

- Fixed the MV color picker hue slider so the hue gradient remains visible despite global input styling.
- Added close animation for the MV color picker panel.
- Rounded and inset the docked main MV panel so it visually matches the sidecar panel instead of touching viewport edges.
- Improved CSS Studio autocomplete detection for `var(`, `--variables`, classes, IDs, recipes, and one-letter CSS property starts.
- Added `Ctrl+Space` / `Cmd+Space` to force CSS Studio suggestions.

# v1.2.22 - CSS Studio Editor Split and Color Picker Polish

- Kept CSS Studio settings, stylesheet controls, scope controls, and recipes in the main MV panel.
- Changed the CSS Studio sidecar to an editor-only surface for the selected stylesheet.
- Replaced remaining browser-native confirmation dialogs with MV-styled modal confirmations.
- Improved checkbox centering and alignment inside MV panel controls.
- Animated the MV color picker reveal instead of popping it in abruptly.
- Improved the hue slider styling so the color range is clearer.
- Updated color picker value inputs so the three numeric boxes change meaning for RGB, HSL, and OKLCH modes.

# v1.2.21 - CSS Studio Sidecar and UI Corrections

- Fixed MV color picker overflow so the map, hue slider, and RGB/HEX inputs stay inside the panel.
- CSS Studio suggestion sources now show only detected sources instead of always listing every possible integration.
- Moved CSS Studio into a same-size sidecar panel beside the main MV panel so the main panel remains available.
- Added stylesheet deletion controls for user-created stylesheets.
- Made recipe shortcodes easier to find with a visible Recipe Shortcodes section inside CSS Studio.
- Reduced snap-zone flicker near dock edges by widening snap hysteresis.
- Extended the header separator line to the panel edges and aligned header actions more deliberately.

# v1.2.20 - CSS Studio Logical Properties and MV Color Picker

- CSS Studio validation now recognizes modern logical properties such as `padding-block`, `margin-inline`, `inset-block`, and logical border properties.
- Capped CSS Studio autocomplete dropdown height and result count so suggestions stay usable instead of overflowing the panel.
- Added source enable/disable controls to the CSS Studio suggestion priority list.
- Reworked recipes into a dedicated reference panel; type `@rhythm`, `@grid`, or `@focus`, then press Tab to insert the recipe.
- Added the first MV custom color picker for color creation/editing, replacing the native operating-system color dialog.
- Added a visible Stylesheet Scope label and clearer scope help beside the stylesheet scope dropdown.
- Smoothed floating panel snap detection and separated the drag handle, brand, logo, and header actions more clearly.
- Updated the license server placeholder to `https://lic.hebronmimam.com`.

# v1.2.19 — CSS Studio Depth and Panel Docking Polish

- CSS Studio now starts with one default global stylesheet instead of page/global/child defaults.
- Added update channels for stable, beta, and dev manifests.
- Removed closed-panel/offscreen shadows that could appear on WordPress update screens.
- Floating panels no longer show the background overlay, drag faster, and snap left/right based on panel edge proximity.
- Panel header actions now sit on their own row under the brand area for a cleaner header.
- CSS Studio now scans WordPress for MV variables, builder classes, IDs, and supported source labels for richer autocomplete.
- Increased autocomplete result depth and added basic CSS validation, starter recipes, and Ctrl+D line duplication.
- Source-priority rows now show a drop-line while dragging.
- Tightened checkbox alignment in CSS Studio and across MV panel controls.

# v1.2.18 — Update Feed Freshness

- Switched the default update manifest from GitHub raw CDN to the GitHub contents API raw response.
- Forced update checks now append a cache-buster so the panel can detect newly published updates sooner.
- Legacy saved raw manifest URLs are normalized back to the fresher default update feed.

# v1.2.17 — Docking Snap and CSS Studio UX

- Added a dedicated drag-handle icon before the panel logo.
- Dragging the handle now turns the panel into a floating panel automatically.
- Dragging near the left or right edge shows snap zones, and dropping there docks the panel.
- CSS Studio now renders immediately from local default sheets instead of showing a loading state.
- Fixed checkbox styling globally inside the MV panel so admin and builder panels match.
- Reworked CSS Studio suggestion priority around source names like Mimam's Var, Advanced Themer, Bricks, Core Framework, and Automatic.css.
- Replaced source-priority Up/Down buttons with drag-handle reordering.
- Moved CSS autocomplete suggestions near the editor caret instead of under the full editor.

# v1.2.16 — Dockable Panel and CSS Studio

- Added dock-right, dock-left, and floating panel modes, saved per browser.
- Floating panels can be dragged from the header.
- Removed GSAP scale hover from panel controls so buttons no longer jump, squeeze, or resize on hover.
- Standardized checkbox styling across sub-panels, including CSS Studio.
- Renamed the user-facing Advanced CSS area to CSS Studio.
- Expanded CSS Studio with editor settings, line numbers, Tab autocomplete foundations for variables/classes/IDs/properties, source-priority controls, and auto-format/SCSS-mode toggles.
- Added explanatory scope help for page, global, child, custom, and recipe stylesheets.

# v1.2.15 — Migration, Advanced CSS, and UI Standards

- Added a migration preview foundation for Bricks/Advanced Themer, Core Framework, and Automatic.css variables.
- Added an Advanced CSS panel and backend manager that compiles enabled stylesheets to `/wp-content/uploads/variable-engine/advanced.css`.
- Added frontend/admin loading for the compiled Advanced CSS file.
- Standardized panel inputs, textareas, checkboxes, and buttons so license and future feature controls inherit the same premium styling.
- Replaced ghost/outlined buttons with a filled neutral secondary button to permanently fix harsh hover text contrast.
- Added the backend route support Figma needs to read WordPress license status.

# v1.2.14 — Licensing Foundation and Hover Cleanup

- Added the first licensing gate foundation: license status, activate, check, and deactivate REST endpoints.
- Added license key, status, and optional license server URL controls to the WordPress settings panel.
- License keys are stored server-side and only a masked key/status is returned to the UI.
- Removed the panel background blur and kept a darker non-blurred overlay.
- Locked ghost/outlined button hover text to the same calm readable color so hover no longer causes bright text glare.

# v1.2.13 — Update Link and Admin Bar Hotfix

- Fixed the panel update button URL so WordPress receives real query parameters instead of an HTML-escaped nonce URL.
- Injected Mimam's Var into WordPress' cached update transient as well as the pre-set transient so the Plugins page/update count can detect available updates sooner.
- Reworked the admin bar toggle to use a fixed logo mark with centered `MV` text.
- Darkened and softened the panel background blur overlay.
- Reduced outlined/ghost button hover glare further while keeping the dark premium feel.

# v1.2.12 — Admin Bar, Overlay, and Sync Stats Polish

- Centered the WordPress admin bar logo and `MV` label so the toggle sits cleanly in the toolbar.
- Replaced the WordPress panel color overlay with a background blur when the panel is open.
- Changed `.base` parent groups to start collapsed by default; the toggle now opens them instead of first needing to close an already-open group.
- Softened outlined/ghost button hover states again so text remains readable without harsh brand-color glare.
- Removed duplicated "active variables on WordPress" text from the Figma stats card; the card now shows supporting record stats only.

# v1.2.11 — Panel Polish and Startup Collection Metadata

- Fixed default-open `.base` group toggling so the first click closes the parent.
- Replaced the WP admin bar placeholder/icon slot with the Hebronmimam logo image.
- Softened ghost-button hover colors to avoid harsh neon text on dark surfaces.
- Let the Snapshots view use the full sub-panel height.
- Improved Figma startup collection metadata sync so WordPress can show the active Figma collection after the Figma plugin opens.

# v1.2.10 — Sync Navigation, Collection Metadata, and Update Notice Polish

- Fixed generated/base parent rows so default-open `.base` groups can still be collapsed manually.
- Renamed and toggled the diagnostics viewer button so it is clear that it opens plugin diagnostic logs and can be hidden again.
- Hid Clean WP DB actions unless stats report stale, orphan, duplicate, or older-generator cleanup work.
- Added selected Figma collection metadata to the pairing status so WordPress can show the active collection under the Figma file name.
- Added a panel update notice with Update and Skip actions when the GitHub manifest reports a newer version.
- Fixed Snapshot back navigation so nested snapshot views return to the Sync panel instead of closing back to the main variable list.
- Added child-variant copy tooltips and switched panel icon rendering to Phosphor duotone classes.
- Improved destructive button hover contrast and replaced the WP admin bar icon with the Hebronmimam logo asset.

# v1.2.9 — Update Feed, UI Polish, and Imported Variant Preservation

- Added the GitHub raw update-feed URL as the default update source so WordPress can show plugin updates without manual feed setup.
- Added the Hebronmimam logo asset to the WordPress panel header instead of the placeholder color box.
- Improved number inputs, checkbox alignment/styling, hover action groups, and type-colored variable stripes across the WordPress panel.
- Protected imported generated children from cleanup when they belong to Figma-pushed synthetic bases, so nested variants remain visible after cleanup.
- Auto-expands safe `.base` groups in the WordPress variable browser so imported scale-like children are visible under their base.

# v1.2.8 — Dropdown, Cleanup, and Variant Base Refinement

- Replaced the WP new-variable category and scale selectors with custom dark menus to remove native select flicker, blue focus styling, and unreadable open states.
- Added a visible WP cleanup notice in the main variable browser when stale generated, orphan generated, duplicate, or older generator records are detected.
- Extended Figma-to-WordPress push nesting beyond colors: scale-like children can now nest under an existing parent, or a safe synthetic `{parent}.base` token when no parent exists.
- Fixed the new-variable header spacing and the create/close toolbar tooltip.

# v1.2.7 — Color Creation Control Refinement

- Updated the color creation/editing control so the color picker is a true 1:1 square.
- The generated color value preview now spans the remaining row width beside the picker.
- Replaced the HEX/RGB/HSL/OKLCH native dropdown with a full-width segmented control below the picker row to avoid white native popup edges.
- Reduced excessive rounding on form controls and tightened the dark dropdown/input styling.
- File-manager workflow now refreshes only the extracted `file-manager-upload/variable-engine` folder; no separate file-manager ZIP is produced.

# v1.2.6 — Figma Push Variant Cleanup + Straight Type Stripe

- Figma-to-WordPress import repair now also recognizes numeric color variants such as `color.background.bg.body.5`, `color.background.bg.body.10`, and `color.background.bg.body.20`.
- Numeric color variants are migrated into generated children of their base color when the base exists or is part of the same push.
- Restored the WordPress panel property/type marker to a straight vertical stripe instead of a rounded left border.
- Reviewed plugin inspiration packages for admin/builder UI direction; kept the current scoped refinement instead of a broad UI rewrite.

# v1.2.5 — Activation Diagnostics and CSS Import/Export

- Fixed an activation fatal caused by a UTF-8 BOM before the namespace declaration in `AdminAdapter.php`.
- Added early diagnostic logging for activation exceptions and plugin-owned fatal shutdown errors.
- Added a diagnostics log viewer endpoint and panel button so install/activation failures have a readable trail.
- Added commented CSS export with all current variables grouped by namespace.
- Added CSS import from uploaded `.css` files or pasted CSS custom properties, using the existing preview/apply workflow.
- Updated WordPress panel button hover behavior to remove jumpy vertical movement and use cleaner GSAP-assisted feedback.

# v1.2.4 — File Manager Hotfix

- Hardened the update-feed integration with more conservative PHP syntax and function guards.
- Bumped the WordPress plugin to `1.2.4` so it can be installed over the problematic `1.2.3` build.
- Kept the Figma → WordPress `repair_generated` nesting fix from v1.2.3.
- Refined button styling and line heights in the WordPress panel.
- Prepared a file-manager-ready extracted plugin folder and ZIP.

# v1.2.3 — Mimam's Var Rename, Update Feed, and Figma Nest Repair

- Renamed the WordPress plugin header/UI to "Mimam's Var - WP".
- Added private update-feed support so test sites can receive WordPress-native plugin update prompts from a JSON manifest URL.
- Added a Settings option to enable automatic updates for this plugin on test installs.
- Added an update check action in the panel settings.
- Fixed Figma → WordPress push previews that previously showed "No changes" when existing color variants only needed to be migrated under their base color.
- Improved the WordPress panel spacing, controls, borders, and button finish while preserving the existing dark/accent color system.

# v1.2.2 — Figma Color Variant Import Nesting

- Figma → WordPress push now imports color variants such as `color.brand.primary.d.4` as generated children of `color.brand.primary`.
- Imported generated color variants now receive `source_id`, `generator_type`, and dependency records so WordPress can display them under their base color instead of as unrelated base tokens.
- Updating an existing imported color variant now preserves/migrates it as a generated child instead of failing on the generated-variable edit lock.

# v1.2.1 — Activation Compatibility Fix

- Fixed activation fatal on PHP 7.4 sites by removing PHP 8-only syntax from loaded plugin files.
- Replaced `match` expressions with PHP 7.4-compatible `switch` logic.
- Removed union return type declarations such as `array|\WP_Error`, `true|\WP_Error`, and `\WP_REST_Response|\WP_Error`.
- No functional changes to fluid variables, sync, generators, cleanup, or pairing.

# v1.2.0 — Fluid Responsive Variables

- Added a new "Fluid" variable mode. Any single variable can now hold a responsive value that scales smoothly between the global min and max viewport widths.
- A fluid variable stores a compact `fluid:min,max` marker (px values); its `css_value` is compiled to a real `clamp()`.
- New shared `FluidValue` helper centralizes all clamp() math. `FluidScaleGenerator` now delegates to it, so single fluid variables and generated fluid scales use identical math.
- The builder panel's variable mode toggle is now Color / Fixed / Fluid / Static. The old "Clamp" mode is relabeled "Fixed" (single rem value — unchanged behaviour).
- Fluid mode shows min/max px inputs with a live clamp() preview using the global viewport settings.
- Changing the viewport range in Settings now automatically recompiles every fluid variable's clamp() output and re-exports CSS.
- The variable detail panel shows fluid variables in a friendly "16 → 24px fluid" form plus the computed clamp(); editing a fluid variable opens the full edit panel.
- Figma sync is unchanged: `extractNumber()` already extracts the max value from clamp(), so fluid variables push their desktop value correctly with no Figma plugin changes.

# v1.1.23
- Fixed fatal error in sync export caused by missing rename-history helper methods.
- Added stable identity key generation for base and generated variables.
- Added previous public token names to sync export for rename-aware Figma syncing.

# v1.1.22

- Added rename history metadata to sync exports so Figma can rename variables even when values changed.
- Added stable identity keys for Figma sync.
- Added client local time metadata support for sync logs.

# v1.1.21

- Sync export now includes stable variable IDs, source IDs, and generator type metadata so the Figma plugin can rename existing variables even when the variable value also changes.
- This supports safer Figma rename matching without requiring destructive delete sync.

# v1.1.21 — Rename Preview Fatal Fix

- Fixed rename impact preview fatal error caused by accessing a private validation constant from the REST controller.
- `VariableManager::NAME_PATTERN` is now public so rename preview can validate proposed names safely.
- This fixes the WordPress critical-error HTML appearing inside the edit panel when Preview impact is clicked.

# 1.1.17
- Added public token names to sync export (`public_name` and `css_name`) so Figma can use clean public names instead of internal storage wrappers.
- This lets `size.space` sync as `space` and generated children sync as `space-20`, while keeping the internal WordPress storage name intact.

# v1.1.16

- Added rename impact preview in the edit panel.
- Added optional WordPress/Bricks storage usage propagation when renaming variables.
- Searches post content, post meta, and targeted builder/theme options for CSS custom property references.
- Creates mappings for base variables and generated children.

# v1.1.15
- Public CSS/token name generation now strips storage-only wrappers such as `size`, `font`, and `typography` from base variable names. Example: `size.space` exports as `--space`.
- Copy var(), detail CSS display, and variable autocomplete now use the same public token-name logic.
- Reverted row-click auto expansion for generated children. Only the explicit plus/minus toggle opens generated children again.

## v1.1.10 — Cleanup Recovery + WordPress Cleanup UI
- Added Clean WP DB directly inside the WordPress Sync panel.
- WordPress panel now auto-refreshes while open and on window focus/visibility changes, so external cleanup/sync changes reflect without manual refresh.
- Cleanup now recovers missing color generator records from existing generated variable names before deleting stale/orphan rows.
- Cleanup now rebuilds recoverable generated variants after repair instead of leaving only base variables.
- Regeneration now repairs source_id, generator_type, type, and dependency links for existing generated rows.

## v1.1.9 — Generated Variable Repair + Live Pair Status

- Added deeper WordPress variable diagnostics: expected generated count, stale generated count, orphan generated count, duplicate name count, and older generator count.
- Clean WP DB now removes duplicate, orphan, and stale generated records, then reruns current active generators.
- WordPress panel footer now shows base/generated breakdown instead of a misleading single raw count.
- Sync panel now polls pairing status while open, so Figma file name updates without leaving and returning to the tab.

# Variable Engine Changelog

## 1.1.8
- WordPress panel now loads the deduped active variable list, so the footer count no longer shows old/raw database records.
- Keeps cleanup endpoints from v1.1.7 for removing stale duplicate/orphan rows when needed.
- Better Figma file name metadata handling via the companion plugin.

## v1.1.6 — Figma UX Stabilization

- Added `dedupe=true` support to the variables REST endpoint.
- Deduped flat sync exports by variable name so Figma shows/syncs the current variable set instead of counting duplicate legacy rows.
- Preserved raw DB records; dedupe is a safe read/export layer, not destructive cleanup.

## v1.1.5 — Stabilization Release

### Fixed
- Allowed paired Figma plugin requests using `X-VE-Key` to access Variable Engine read/write routes, not only sync routes.
- Fixed Figma connection checks that could fail because `/variables` and `/settings` still required browser-based WordPress permissions.
- Fixed Figma-side variable management routes so the companion plugin can list, create, and delete variables after pairing.
- Fixed Figma disconnect flow so API-key authenticated disconnect requests can reach WordPress.
- Improved sync log storage by saving both raw changes and a summary payload.
- Improved sync log output by returning parsed summaries instead of hiding the stored diff data.

### Notes
- This release focuses on stabilizing the existing MVP rather than adding new product surface area.
- Figma collection deletion sync still needs live testing inside Figma because it depends on Figma's plugin runtime behavior.

## 1.1.7
- Added variable database stats endpoint.
- Added cleanup endpoint for duplicate and orphan generated variable records.
- Cleanup regenerates the CSS export after removing stale rows.

## 1.1.13 - 2026-05-10
- Fixed numeric scale child ordering in the WordPress panel so generated scale tokens display from small to large.
- Changed numeric fluid-scale generated names to use the base token family/name instead of the storage category.
  - `size.space` now generates `space.20` / `--space-20`.
  - `size.heading` now generates `heading.58` / `--heading-58`.
  - `size.text` now generates `text.46` / `--text-46`.
  - `size.grid.gap` now generates `grid.gap.20` / `--grid-gap-20`.
- Clicking a base variable with generated children now opens/expands its generated list automatically.
- Existing generated values are still preserved inside `clamp()`; only token naming and panel ordering were improved.

## 1.1.12 - 2026-05-10
- Fixed numeric generator labels so generated tokens use rounded readable px suffixes such as `size.107`, not decimal-safe names like `font.107-29`.
- Fixed generated variable regeneration on base variable rename, not only value changes.
- Regeneration now removes old generated children for the same base/generator when their names no longer match the current base name or naming rule.
- Prevents renamed bases such as `font.space` → `size.space` from leaving old CSS variables like `--font-*` behind.

## 1.1.11 - 2026-05-10
- Added numeric dimension naming support for space, radius, heading, text, grid, font, and size tokens.
- Allows numeric dot segments such as `space.20`, `radius.8`, `heading.58`, `text.46`, and `grid.gap.20`.
- Normalizes numeric dimension values using the 10px rem system: `20` or `20px` becomes `2rem`.
- Fluid scale generation now uses numeric labels based on the desktop/max pixel value.
- Fluid scale rem output now uses `1rem = 10px` instead of browser-default `16px` conversion.

## 1.2.51 - 2026-06-08
- Removed second-confirmation requirement from Add Element mode.
- Removed no-target warning from the bar body when opening with no element selected.
- Removed permanent mode keyboard hints from the tab-hint area.
- Added optional command help mode via the `?` header button or typing `help` / `?` then Enter.
- Improved Emmet Tab completion for aliases and partial tokens such as `cont`, `btn`, `img`, `sec`, `blk`, and chained tokens like `section>cont`.
- Kept TARGET and mode labels quieter so the input remains the main focus.
