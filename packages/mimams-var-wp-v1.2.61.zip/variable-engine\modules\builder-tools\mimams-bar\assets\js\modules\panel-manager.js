(function () {
  'use strict';

  var Core = window.MimamsBarCore || {};

  function syncSettingsControls(settingsPanel, Settings) {
    if (!settingsPanel || !Settings) return;

    Array.prototype.slice.call(settingsPanel.querySelectorAll('[data-setting]')).forEach(function (control) {
      var key = control.getAttribute('data-setting');
      if (!key) return;

      if (control.type === 'checkbox') {
        control.checked = !!Settings.get(key);
      } else {
        control.value = Settings.get(key);
      }
    });
  }

  function bindSettingsControls(settingsPanel, Settings, afterChange) {
    if (!settingsPanel || !Settings) return;

    syncSettingsControls(settingsPanel, Settings);

    settingsPanel.addEventListener('change', function (event) {
      var target = event.target;
      var key = target && target.getAttribute('data-setting');
      if (!key) return;

      if (target.type === 'checkbox') {
        Settings.set(key, !!target.checked);
      } else {
        Settings.set(key, target.value);
      }

      syncSettingsControls(settingsPanel, Settings);
      if (typeof afterChange === 'function') afterChange(key, Settings.get(key));
    });
  }

  function toggleSettingsPanel(settingsPanel, Settings) {
    if (!settingsPanel) return;

    settingsPanel.hidden = !settingsPanel.hidden;
    var panel = settingsPanel.closest ? settingsPanel.closest('.baqa-panel') : null;
    if (panel) panel.classList.toggle('is-settings-open', !settingsPanel.hidden);
    if (!settingsPanel.hidden) syncSettingsControls(settingsPanel, Settings);
  }

  function startDrag(event, panel, Settings) {
    if (!panel || !Settings || !Settings.get('undocked')) return false;
    if (event.target && event.target.closest && event.target.closest('button, input, select, textarea')) return false;

    event.preventDefault();

    var rect = panel.getBoundingClientRect();
    var offsetX = event.clientX - rect.left;
    var offsetY = event.clientY - rect.top;

    var onMove = function (moveEvent) {
      var left = Math.max(8, Math.min(window.innerWidth - rect.width - 8, moveEvent.clientX - offsetX));
      var top = Math.max(8, Math.min(window.innerHeight - 80, moveEvent.clientY - offsetY));

      panel.style.insetInlineStart = left + 'px';
      panel.style.insetInlineEnd = 'auto';
      panel.style.insetBlockStart = top + 'px';
      panel.style.marginInline = '0';

      Settings.data.panelLeft = Math.round(left);
      Settings.data.panelTop = Math.round(top);
    };

    var onUp = function () {
      document.removeEventListener('pointermove', onMove, true);
      document.removeEventListener('pointerup', onUp, true);
      Settings.save();
    };

    document.addEventListener('pointermove', onMove, true);
    document.addEventListener('pointerup', onUp, true);

    return true;
  }

  window.MimamsBarPanelManager = {
    syncSettingsControls: syncSettingsControls,
    bindSettingsControls: bindSettingsControls,
    toggleSettingsPanel: toggleSettingsPanel,
    startDrag: startDrag
  };
})();
