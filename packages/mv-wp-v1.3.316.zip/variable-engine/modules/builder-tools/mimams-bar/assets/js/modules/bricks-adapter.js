(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;

  var Core = window.MimamsBarCore || {};
  var labels = Core.labels || {};
  var MAX_BULK_TARGETS = Core.MAX_BULK_TARGETS || 40;
  var log = Core.log || function () {};
  var makeId = Core.makeId || function () { return 'baqa_' + Math.random().toString(36).slice(2, 9); };
  var DEBUG_BULK = !!(Core.DEBUG_BULK || (window.MimamsBarDebug && window.MimamsBarDebug.bulk));
  function bulkLog() {
    if (!DEBUG_BULK || !window.console || typeof window.console.info !== 'function') return;
    try { window.console.info.apply(window.console, arguments); } catch (e) {}
  }

  var BricksAdapter = {
    _manualSelection: null,
    _globalsCache: null,
    _globalsCacheAt: 0,
    _allElementsCache: null,
    _allElementsCacheAt: 0,
    _defaultElementTags: {
      'list-item': 'li',
      'list': 'ul',
      'link': 'a',
      'text-link': 'a',
      'heading': 'h2',
      'section': 'section',
      'container': 'div',
      'block': 'div',
      'div': 'div',
      'image': 'img',
      'video': 'video',
      'button': 'button',
      'icon': 'i',
      'svg': 'svg',
      'form': 'form',
      'nav': 'nav',
      'nav-nestable': 'nav'
    },
    isDeepEqual: function (a, b) {
      if (a === b) return true;
      var strA = this.safeJsonStringify(a);
      var strB = this.safeJsonStringify(b);
      if (strA && strB) return strA === strB;
      return false;
    },
    safeJsonStringify: function (obj) {
      try {
        return JSON.stringify(this.sortObjectKeys(obj));
      } catch (e) {
        return null;
      }
    },
    sortObjectKeys: function (obj) {
      if (!obj || typeof obj !== 'object') return obj;
      if (Array.isArray(obj)) {
        return obj.map(this.sortObjectKeys.bind(this));
      }
      var sorted = {};
      var keys = Object.keys(obj).sort();
      for (var i = 0; i < keys.length; i++) {
        var key = keys[i];
        if (obj[key] !== undefined) {
          sorted[key] = this.sortObjectKeys(obj[key]);
        }
      }
      return sorted;
    },
    getVueGlobals: function () {
      var now = Date.now ? Date.now() : new Date().getTime();
      if (this._globalsCache && now - this._globalsCacheAt < 650) return this._globalsCache;
      var roots = ['.brx-body', '#bricks-builder', '#brx-builder', '#bricks-panel', 'body'];
      for (var i = 0; i < roots.length; i++) {
        var node = document.querySelector(roots[i]);
        if (node && node.__vue_app__ && node.__vue_app__.config) {
          this._globalsCache = node.__vue_app__.config.globalProperties || null;
          this._globalsCacheAt = now;
          return this._globalsCache;
        }
      }
      this._globalsCache = null;
      this._globalsCacheAt = now;
      return null;
    },

    getState: function () {
      var globals = this.getVueGlobals();
      return globals && globals.$_state ? globals.$_state : null;
    },

    findElementInList: function (id, list, visited) {
      if (!id || !Array.isArray(list)) return null;
      visited = visited || (typeof Set !== 'undefined' ? new Set() : []);

      for (var i = 0; i < list.length; i++) {
        var item = list[i];
        if (!item || typeof item !== 'object') continue;

        var itemId = item.id || item.instanceId;
        if (!itemId) continue;

        var key = String(itemId);
        if (typeof Set !== 'undefined') {
          if (visited.has(key)) continue;
          visited.add(key);
        } else {
          if (visited.indexOf(key) !== -1) continue;
          visited.push(key);
        }

        if (itemId === id) return item;

        var children = item.children;
        if (Array.isArray(children)) {
          var found = this.findElementInList(id, children, visited);
          if (found) return found;
        }
      }
      return null;
    },

    getSelectedElementIdFromDom: function () {
      var selected = document.querySelector('[data-id].selected, [data-id].active, .bricks-draggable-item.selected[data-id], .bricks-draggable-item.active[data-id]');
      return selected ? selected.getAttribute('data-id') : null;
    },

    getManualSelection: function () {
      var manual = this._manualSelection;
      if (!manual || !manual.id) return null;
      // Keep manual search selection long enough for Direct commands, but do
      // not let it override real user selection forever.
      if (Date.now && manual.time && Date.now() - manual.time > 15000) return null;
      var root = this.getMutableElementsRoot ? this.getMutableElementsRoot() : [];
      var found = this.findElementInList(manual.id, root) || manual.element;
      return found && found.id ? found : null;
    },

    getSelectedElement: function () {
      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      var element = null;

      if (state) {
        if (Array.isArray(state.selectedElements) && state.selectedElements.length === 1) {
          element = state.selectedElements[0];
        } else if (state.activeElement && state.activeElement.id) {
          element = state.activeElement;
        }
      }

      if (!element) {
        var id = this.getSelectedElementIdFromDom();
        var dynamicElements = globals && globals.$_dynamicElements && globals.$_dynamicElements.value ? globals.$_dynamicElements.value : null;
        element = this.findElementInList(id, dynamicElements) || this.findElementInList(id, window.bricksData && window.bricksData.elements);
      }

      var manual = this.getManualSelection();
      if (manual && this._manualSelection && this._manualSelection.time && Date.now && Date.now() - this._manualSelection.time < 1800) {
        element = manual;
      }
      if (!element) element = manual;

      return element && element.id ? element : null;
    },

    cssEscape: function (value) {
      value = String(value || '');
      if (window.CSS && typeof window.CSS.escape === 'function') return window.CSS.escape(value);
      return value.replace(/[^a-zA-Z0-9_-]/g, '\\$&');
    },

    findStructureNode: function (id) {
      id = String(id || '').trim();
      if (!id) return null;
      var safe = this.cssEscape(id);
      var selectors = [
        '#bricks-structure [data-id="' + safe + '"]',
        '#bricks-structure-resizable [data-id="' + safe + '"]',
        '.bricks-structure [data-id="' + safe + '"]',
        '.brx-structure [data-id="' + safe + '"]',
        '#brx-structure [data-id="' + safe + '"]',
        '[data-panel="structure"] [data-id="' + safe + '"]',
        '[data-element-id="' + safe + '"]',
        '[data-bricks-id="' + safe + '"]',
        '[data-builder-id="' + safe + '"]',
        '[data-object-id="' + safe + '"]',
        '.bricks-draggable-item[data-id="' + safe + '"]',
        '[data-id="' + safe + '"]'
      ];

      for (var i = 0; i < selectors.length; i++) {
        var node = document.querySelector(selectors[i]);
        if (!node) continue;
        if (node.closest && node.closest('.baqa-panel')) continue;
        return node;
      }
      return null;
    },

    focusElementInStructure: function (element, options) {
      options = options || {};
      if (!element || !element.id) return false;
      var node = this.findStructureNode(element.id);
      if (!node) return false;

      try {
        if (typeof node.scrollIntoView === 'function') node.scrollIntoView({ block: 'center', inline: 'nearest' });
      } catch (e) {
        try { node.scrollIntoView(); } catch (e2) {}
      }

      if (options.click === false) return true;

      try {
        var clickable = node.closest && node.closest('[data-id]') ? node.closest('[data-id]') : node;
        clickable.dispatchEvent(new MouseEvent('click', { bubbles: true, cancelable: true, view: window }));
      } catch (e3) {
        try { node.click(); } catch (e4) {}
      }

      return true;
    },

    selectElement: function (element, options) {
      options = options || {};
      if (!element || !element.id) return false;
      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      var selected = false;
      this._manualSelection = { id: element.id, element: element, time: Date.now ? Date.now() : new Date().getTime() };

      // v1.2.54: Bricks uses activeId + setActiveElement() as the real single
      // selection pipeline. Older builds only changed local/manual state, which
      // made the bar target update without the Structure panel actually selecting.
      try {
        if (state) {
          state.activeId = element.id;
          state.activeElement = element;
          state.selectedElement = element;
          state.selectedElements = [];
          state.selectedElementSettings = this.clone(element.settings || {});
          state.activePanel = 'element';
          selected = true;
        }
      } catch (e) { log('selectElement state update failed', e); }

      try {
        if (globals && typeof globals.$_setActiveElement === 'function') {
          globals.$_setActiveElement();
          selected = true;
        }
      } catch (eSet) { log('selectElement setActiveElement helper failed', eSet); }

      try {
        if (globals && typeof globals.$_selectElement === 'function') {
          var fakeEvent = { ctrlKey: false, metaKey: false, shiftKey: false, stopPropagation: function () {}, preventDefault: function () {} };
          globals.$_selectElement(fakeEvent, element.id);
          selected = true;
        }
      } catch (e2) { log('selectElement selectElements helper failed', e2); }

      if (options.focusStructure !== false) {
        try {
          this.focusElementInStructure(element, { click: false });
          selected = true;
        } catch (e3) { log('focusElementInStructure failed', e3); }
      }

      return selected;
    },

    deselectElement: function () {
      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      var deselected = false;
      this._manualSelection = null;

      try {
        if (state) {
          state.activeId = null;
          state.activeElement = null;
          state.selectedElement = null;
          state.selectedElements = [];
          state.selectedElementSettings = {};
          state.activePanel = 'structure';
          deselected = true;
        }
      } catch (e) { log('deselectElement state update failed', e); }

      try {
        if (globals && typeof globals.$_setActiveElement === 'function') {
          globals.$_setActiveElement(null);
          deselected = true;
        }
      } catch (eSet) { log('deselectElement setActiveElement helper failed', eSet); }
      
      // Cleanup DOM just in case Vue missed it
      try {
        var selectedNodes = document.querySelectorAll('.bricks-structure-item.active, .bricks-structure-item.selected, [data-id].active, [data-id].selected');
        for (var i = 0; i < selectedNodes.length; i++) {
          selectedNodes[i].classList.remove('active', 'selected', 'is-active', 'is-selected');
        }
      } catch (e) {}

      return deselected;
    },

    splitClassString: function (value) {
      if (!value) return [];
      if (Array.isArray(value)) {
        return value.reduce(function (all, item) {
          return all.concat(BricksAdapter.splitClassString(item));
        }, []);
      }
      if (typeof value === 'object') {
        if (value.name) return [String(value.name)];
        if (value.value) return BricksAdapter.splitClassString(value.value);
        return [];
      }
      return String(value).trim().split(/\s+/).filter(Boolean);
    },

    getGlobalClasses: function () {
      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      return state && Array.isArray(state.globalClasses) ? state.globalClasses : [];
    },

    _globalClassNameMapCache: null,
    _globalClassNameMapCacheAt: 0,
    getGlobalClassNameMap: function () {
      var now = Date.now ? Date.now() : new Date().getTime();
      if (this._globalClassNameMapCache && now - this._globalClassNameMapCacheAt < 650) {
        return this._globalClassNameMapCache;
      }

      var classes = this.getGlobalClasses();
      var map = {};

      classes.forEach(function (item) {
        if (item && item.id && item.name) {
          map[item.id] = item.name;
        }
      });

      this._globalClassNameMapCache = map;
      this._globalClassNameMapCacheAt = now;
      return map;
    },

    findGlobalClassByName: function (name) {
      name = String(name || '').replace(/^\./, '').trim();
      if (!name) return null;

      var classes = this.getGlobalClasses();
      for (var i = 0; i < classes.length; i++) {
        if (classes[i] && classes[i].name === name) return classes[i];
      }

      return null;
    },

    findGlobalClassById: function (id) {
      id = String(id || '').trim();
      if (!id) return null;

      var classes = this.getGlobalClasses();
      for (var i = 0; i < classes.length; i++) {
        if (classes[i] && classes[i].id === id) return classes[i];
      }

      return null;
    },

    createGlobalClass: function (name) {
      name = String(name || '').replace(/^\./, '').trim();
      if (!name) return null;

      var existing = this.findGlobalClassByName(name);
      if (existing) return existing;

      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      if (!state) return null;

      if (!Array.isArray(state.globalClasses)) state.globalClasses = [];

      var id = '';
      try {
        if (globals && typeof globals.$_generateId === 'function') {
          id = globals.$_generateId();
        }
      } catch (e) { log('global class id generation failed', e); }

      if (!id) id = makeId();

      var item = { id: id, name: name, settings: {} };
      state.globalClasses.push(item);

      // Bricks uses this post message after creating global classes. Keep it
      // best-effort so the class manager/chips know about the new class.
      try {
        if (globals && typeof globals.$_postMessage === 'function') {
          globals.$_postMessage({ key: 'globalClassesNew', value: JSON.stringify([item]) });
        }
      } catch (e2) { log('globalClassesNew postMessage failed', e2); }

      return item;
    },

    // Clone a global class WITH its styles: a new class whose settings are a deep copy
    // of the source's. Returns the new class name (or null if the source/store is missing).
    duplicateGlobalClass: function (sourceName) {
      var source = this.findGlobalClassByName(sourceName);
      if (!source) return null;

      var base = source.name + '-copy';
      var name = base, n = 2;
      while (this.findGlobalClassByName(name)) { name = base + '-' + n; n++; }

      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      if (!state) return null;
      if (!Array.isArray(state.globalClasses)) state.globalClasses = [];

      var id = '';
      try { if (globals && typeof globals.$_generateId === 'function') id = globals.$_generateId(); } catch (e) { log('dup class id generation failed', e); }
      if (!id) id = makeId();

      var settings = {};
      try { settings = JSON.parse(JSON.stringify(source.settings || {})); } catch (e3) { settings = {}; }

      var item = { id: id, name: name, settings: settings };
      state.globalClasses.push(item);
      try {
        if (globals && typeof globals.$_postMessage === 'function') {
          globals.$_postMessage({ key: 'globalClassesNew', value: JSON.stringify([item]) });
        }
      } catch (e2) { log('globalClassesNew (dup) postMessage failed', e2); }

      return name;
    },

    getElementClasses: function (element) {
      if (!element || !element.settings) return [];

      var settings = element.settings;
      var classNames = [];
      var globalMap = this.getGlobalClassNameMap();

      // Bricks renders global classes first and then the manual CSS classes.
      // Keep that order so the Target row reflects the final class flow.
      if (Array.isArray(settings._cssGlobalClasses)) {
        settings._cssGlobalClasses.forEach(function (classId) {
          var name = globalMap[classId] || classId;
          if (name) classNames.push(String(name));
        });
      }

      classNames = classNames.concat(this.splitClassString(settings._cssClasses));

      return classNames.filter(function (name, index, list) {
        return name && list.indexOf(name) === index;
      });
    },

    getElementCssId: function (element) {
      var settings = element && element.settings ? element.settings : {};
      if (settings._cssId) return String(settings._cssId);
      if (settings.cssId) return String(settings.cssId);
      return '';
    },

    getElementIdentity: function (element) {
      return {
        id: this.getElementCssId(element),
        classes: this.getElementClasses(element)
      };
    },

    getElementCustomLabel: function (element) {
      if (!element) return '';
      var settings = element.settings || {};
      var candidates = [
        element.label, element.title, element.customLabel, element.structureLabel, element.adminLabel, element.nameLabel,
        settings.label, settings._label, settings.customLabel, settings._customLabel, settings.adminLabel, settings._adminLabel,
        settings._cssCustomLabel, settings._structureLabel, settings.structureLabel, settings.elementLabel, settings._elementLabel
      ];
      for (var i = 0; i < candidates.length; i++) {
        var value = String(candidates[i] || '').trim();
        if (value && value !== String(element.name || '').trim()) return value;
      }
      return '';
    },

    getElementDisplayType: function (element) {
      if (!element) return 'Element';
      return String(element.name || element.element || element.tag || element.type || element.label || 'Element');
    },

    getElementFullLabel: function (element) {
      if (!element) return 'No element selected';

      var parts = [];
      var type = this.getElementDisplayType(element);
      var customLabel = this.getElementCustomLabel(element);
      var classes = this.getElementClasses(element);
      var cssId = this.getElementCssId(element);

      parts.push(String(type));
      if (customLabel) parts.push('“' + customLabel + '”');
      if (cssId) parts.push('#' + cssId);
      if (classes.length) {
        parts.push(classes.map(function (className) { return '.' + className; }).join(' '));
      }
      parts.push('· Bricks ID: ' + String(element.id));

      return parts.join(' ');
    },

    getElementLabel: function (element) {
      if (!element) return 'No element selected';

      var parts = [];
      var type = this.getElementDisplayType(element);
      var customLabel = this.getElementCustomLabel(element);
      var classes = this.getElementClasses(element);
      var cssId = this.getElementCssId(element);

      parts.push(String(type));
      if (customLabel) parts.push('“' + customLabel + '”');
      if (cssId) parts.push('#' + cssId);
      if (classes.length) {
        parts.push(classes.length === 1 ? '.' + classes[0] : classes.length + ' classes');
      }
      parts.push('· Bricks ID: ' + String(element.id));

      return parts.join(' ');
    },

    isCanvasEventTarget: function (target) {
      if (!target || target === document) return false;
      if (target.tagName === 'IFRAME') return true;
      if (!target.closest) return false;

      var directCanvas = target.closest('iframe, #bricks-builder-iframe, .bricks-builder-iframe, .brx-iframe, #brx-iframe, #bricks-builder-canvas, #brx-canvas, .bricks-canvas, .brx-canvas, #bricks-preview, #brx-preview, .bricks-preview, .brx-preview, .brx-body, #brx-content');
      if (directCanvas) return true;

      var node = target;
      while (node && node !== document && node.nodeType === 1) {
        var id = String(node.id || '').toLowerCase();
        var className = String(node.className || '').toLowerCase();
        if (id.indexOf('canvas') !== -1 || id.indexOf('iframe') !== -1 || id.indexOf('preview') !== -1) return true;
        if (className.indexOf('canvas') !== -1 || className.indexOf('iframe') !== -1 || className.indexOf('preview') !== -1) return true;
        node = node.parentNode;
      }

      return false;
    },

    isCanvasElementTarget: function (target) {
      if (!target || target.nodeType !== 1) return false;
      if (!target.closest) return false;

      var elementNode = target.closest('[id^="brxe-"], [data-id], [data-brx-id], [data-element-id], [data-builder-element-id], .bricks-draggable-root, .brx-draggable-root');
      if (!elementNode) return false;

      var tag = String(elementNode.tagName || '').toLowerCase();
      if (tag === 'html' || tag === 'body') return false;

      return true;
    },

    normalizeAttributes: function (settings) {
      var list = settings && Array.isArray(settings._attributes) ? settings._attributes.slice() : [];
      return list.filter(function (item) { return item && item.name; }).map(function (item) {
        return {
          id: item.id || makeId(),
          name: String(item.name),
          value: item.value == null ? '' : String(item.value)
        };
      });
    },

    getElementAttributes: function (element) {
      if (!element || !element.settings) return [];
      return this.normalizeAttributes(element.settings);
    },

    walkElements: function (list, callback, visited) {
      if (!list || !Array.isArray(list)) return;
      visited = visited || (typeof Set !== 'undefined' ? new Set() : []);

      for (var i = 0; i < list.length; i++) {
        var item = list[i];
        if (!item || typeof item !== 'object') continue;

        var id = item.id || item.instanceId;
        if (!id) {
          callback(item);
          continue;
        }

        var key = String(id);
        if (typeof Set !== 'undefined') {
          if (visited.has(key)) continue;
          visited.add(key);
        } else {
          if (visited.indexOf(key) !== -1) continue;
          visited.push(key);
        }

        callback(item);

        var children = item.children;
        if (Array.isArray(children)) {
          BricksAdapter.walkElements(children, callback, visited);
        }
      }
    },

    _toRaw: function (value) {
      if (!value) return value;
      if (typeof value === 'object' && value.__v_raw) return value.__v_raw;

      // Check canvas iframe context for Vue first
      try {
        var iframe = document.getElementById('bricks-builder-iframe') || document.getElementById('brx-iframe');
        var win = iframe ? iframe.contentWindow : window;
        if (win && win.Vue && typeof win.Vue.toRaw === 'function') {
          return win.Vue.toRaw(value);
        }
      } catch (e) {}

      if (typeof window.Vue !== 'undefined' && typeof window.Vue.toRaw === 'function') return window.Vue.toRaw(value);
      if (typeof window.toRaw === 'function') return window.toRaw(value);
      
      // Fallback via globals cache app instance
      try {
        var globals = this._globalsCache || this.getVueGlobals();
        if (globals && globals.$_app && globals.$_app.__vue_app__) {
          var vue = globals.$_app.__vue_app__;
          if (vue.config && vue.config.globalProperties && typeof vue.config.globalProperties.$toRaw === 'function') {
            return vue.config.globalProperties.$toRaw(value);
          }
        }
      } catch (e2) {}

      return value;
    },

    getMutableElementsRoot: function () {
      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;

      // For builder data operations, prefer the same root that proved safe in
      // console debugging: globals.$_dynamicElements.value. On this Bricks page
      // it resolves the rendered canvas element IDs without walking heavier
      // active component proxies.
      if (globals && globals.$_dynamicElements && Array.isArray(globals.$_dynamicElements.value)) {
        return globals.$_dynamicElements.value;
      }
      if (state && state.activeComponent && Array.isArray(state.activeComponent.elements)) {
        return state.activeComponent.elements;
      }
      if (window.bricksData && Array.isArray(window.bricksData.elements)) {
        return window.bricksData.elements;
      }
      return [];
    },

    getAllElements: function (options) {
      options = options || {};
      var now = Date.now ? Date.now() : new Date().getTime();
      if (!options.fresh && this._allElementsCache && now - this._allElementsCacheAt < 900) {
        return this._allElementsCache;
      }
      var items = [];
      var root = this.getMutableElementsRoot();
      var self = this;
      this.walkElements(root, function (item) {
        if (item && item.id) items.push(item);
      });
      this._allElementsCache = items;
      this._allElementsCacheAt = now;
      return items;
    },

    getBricksElementConfigs: function () {
      var data = window.bricksData && window.bricksData.elements ? window.bricksData.elements : {};
      return Object.keys(data).map(function (name) {
        var item = data[name] || {};
        return {
          name: name,
          label: item.label || item.title || item.name || name,
          category: item.category || item.group || '',
          icon: item.icon || ''
        };
      }).filter(function (item) {
        return item && item.name;
      });
    },

    addBricksElement: function (name, options) {
      options = options || {};
      name = String(name || '').trim();
      if (!name) return { ok: false, reason: 'missing-element-name' };

      var globals = this.getVueGlobals();
      if (!globals || typeof globals.$_addNewElement !== 'function') {
        return { ok: false, reason: 'add-helper-missing' };
      }

      var elementConfig = options.config || {};
      var payloadElement = { name: name };

      try {
        var fullConfig = window.bricksData && window.bricksData.elements && window.bricksData.elements[name]
          ? window.bricksData.elements[name]
          : null;
        if (fullConfig && typeof fullConfig === 'object' && !Array.isArray(fullConfig)) {
          payloadElement = this.clone(fullConfig);
          payloadElement.name = name;
        }
      } catch (e0) {}

      if (elementConfig && elementConfig.label && (options.keepLabel || !payloadElement.label)) {
        payloadElement.label = elementConfig.label;
      }

      var payload = { element: payloadElement, keepLabel: !!options.keepLabel };
      if (typeof options.parent !== 'undefined') payload.parent = options.parent;
      if (typeof options.index !== 'undefined') payload.index = options.index;

      try {
        var eventLike = options.event || { shiftKey: true, preventDefault: function () {}, stopPropagation: function () {} };
        var added = globals.$_addNewElement(payload, eventLike, true);
        var addedElement = added && added.id ? added : this.getSelectedElement();
        if (added && added.id) {
          try { this.selectElement(added); } catch (eSelect) {}
        }
        if (addedElement && options.settings && typeof options.settings === 'object') {
          var currentSettings = this.clone(addedElement.settings || {});
          var nextSettings = this.clone(currentSettings);
          for (var settingKey in options.settings) {
            if (Object.prototype.hasOwnProperty.call(options.settings, settingKey)) {
              nextSettings[settingKey] = options.settings[settingKey];
            }
          }
          this.commitSettings(addedElement, nextSettings, currentSettings, { silent: true });
        }
        if (added && added.id) {
          this._allElementsCache = null;
          return { ok: true, element: added };
        }
        return { ok: true, element: this.getSelectedElement() };
      } catch (e2) {
        log('addBricksElement failed', e2);
        return { ok: false, reason: 'add-failed', error: e2 };
      }
    },

    getElementTagNameFromSettings: function (element) {
      if (!element) return '';
      var settings = element.settings || {};
      var tag = settings._tag || settings.tag || settings.htmlTag || settings._htmlTag || settings.tagName || element.tag || element.htmlTag || '';
      var customTag = settings._customTag || settings.customTag || '';

      tag = String(tag || '').trim().toLowerCase();
      customTag = String(customTag || '').trim().toLowerCase();

      if (tag === 'custom' && customTag) {
        tag = customTag.split(/\s+/)[0];
      }

      if (tag && /^(section|div|article|main|header|footer|figure|figcaption|picture|source|img|h1|h2|h3|h4|h5|h6|p|span|a|button|ul|ol|li|form|input|textarea|nav|label|blockquote|cite|small|strong|em|b|i)$/.test(tag)) {
        return tag;
      }

      return '';
    },

    getElementTagNameFast: function (element) {
      if (!element) return '';

      // For bulk scans, avoid touching iframe DOM or Bricks/Vue helper APIs.
      // Those calls can allocate heavily and were causing Firefox/Bricks to
      // throw repeated "out of memory" errors on commands like:
      // all li => data-anim="fade-up".
      var tag = this.getElementTagNameFromSettings(element);
      if (tag) return tag;

      var name = String(element.name || '').trim().toLowerCase();
      if (this._defaultElementTags && this._defaultElementTags[name]) {
        return this._defaultElementTags[name];
      }

      return name || String(element.label || '').trim().toLowerCase();
    },

    getElementTagNameFromDom: function (elementId) {
      if (!elementId) return '';
      try {
        var iframe = document.getElementById('bricks-builder-iframe') || 
                     document.querySelector('iframe.bricks-builder-iframe') ||
                     document.getElementById('brx-iframe') ||
                     document.querySelector('.brx-iframe') ||
                     document.querySelector('iframe');
                     
        var doc = iframe ? iframe.contentDocument || iframe.contentWindow.document : document;
        if (!doc) return '';

        // Try brxe- prefix ID first (most standard for Bricks elements on canvas)
        var node = doc.getElementById('brxe-' + elementId) || 
                   doc.querySelector('[data-id="' + elementId + '"]') ||
                   doc.querySelector('[data-element-id="' + elementId + '"]');

        if (node && node.tagName) {
          return node.tagName.toLowerCase();
        }
      } catch (e) {}
      return '';
    },

    getElementTagName: function (element) {
      if (!element) return '';

      // Prefer cheap settings/default checks first. Most Bricks custom tag
      // choices (including Basic Text set to `li`) are already available in
      // element.settings, so we should not call iframe/Vue APIs unless needed.
      var fastTag = this.getElementTagNameFast(element);
      if (fastTag) return fastTag;

      // Fallback only for unusual cases where settings do not expose a tag.
      var globals = this.getVueGlobals();
      if (globals && typeof globals.$_getElementNode === 'function') {
        try {
          var node = globals.$_getElementNode(element, 'iframe');
          if (node && node.tagName) {
            return node.tagName.toLowerCase();
          }
        } catch (eNode) {}
      }

      if (element.id) {
        var domTag = this.getElementTagNameFromDom(element.id);
        if (domTag) return domTag;
      }

      return String(element.name || element.label || '').trim().toLowerCase();
    },

    describeSelectorBulkTarget: function (target) {
      target = target || {};
      var parts = [];
      if (target.tag) parts.push('all <' + target.tag + '> elements');
      else parts.push('elements');

      if (target.id) parts.push('with #' + target.id);
      if (target.classes && target.classes.length) {
        parts.push('with ' + target.classes.map(function (name) { return '.' + name; }).join(' and '));
      }

      return parts.join(' ');
    },

    describeBulkTarget: function (target) {
      if (!target) return 'unknown target';
      if (target.mode === 'tag') return 'all <' + target.value + '> elements';
      if (target.mode === 'class') return 'elements with .' + target.value;
      if (target.mode === 'id') return 'element with #' + target.value;
      if (target.mode === 'type') return 'Bricks element type: ' + target.value;
      if (target.mode === 'selector') return this.describeSelectorBulkTarget(target);
      if (target.mode === 'group') {
        var self = this;
        return (target.targets || []).map(function (item) {
          return self.describeBulkTarget(item);
        }).join(', ');
      }
      return target.mode + ':' + target.value;
    },

    matchesSelectorBulkTarget: function (element, target, fast) {
      if (!element || !target) return false;

      if (target.tag) {
        var wantedTag = String(target.tag || '').toLowerCase();
        var elementTag = fast ? this.getElementTagNameFast(element) : this.getElementTagName(element);
        var elName = String(element.name || '').trim().toLowerCase();
        var elLabel = String(element.label || '').trim().toLowerCase();
        var tagMatched = elementTag === wantedTag || elName === wantedTag || (!fast && elLabel === wantedTag);

        if (!tagMatched) {
          var hasIdentityFilter = !!target.id || !!(target.classes && target.classes.length);
          var knownHtmlTag = /^(section|div|article|main|header|footer|figure|figcaption|picture|source|img|h1|h2|h3|h4|h5|h6|p|span|a|button|ul|ol|li|form|input|textarea|nav|label|blockquote|cite|small|strong|em|b|i)$/;

          // Bricks sometimes exposes Basic Text items as their element type
          // (`text-basic`) while Code2Bricks/rendered output uses a custom tag
          // such as <li>. For combined selectors like `all li.card-item`, keep
          // the tag strict when a real HTML tag is known, but allow class/ID
          // identity to carry the match when the tag is unknown from Bricks data.
          if (!hasIdentityFilter || (elementTag && knownHtmlTag.test(elementTag))) {
            return false;
          }
        }
      }

      if (target.id) {
        if (this.getElementCssId(element) !== String(target.id || '').replace(/^#/, '')) return false;
      }

      if (target.classes && target.classes.length) {
        var classes = this.getElementClasses(element);
        for (var i = 0; i < target.classes.length; i++) {
          var clsClean = String(target.classes[i] || '').replace(/^\./, '');
          if (classes.indexOf(clsClean) === -1) return false;
        }
      }

      return true;
    },

    matchesBulkTargetFast: function (element, target) {
      if (!element || !target) return false;

      if (target.mode === 'group') {
        var groupTargets = target.targets || [];
        for (var groupIndex = 0; groupIndex < groupTargets.length; groupIndex++) {
          if (this.matchesBulkTargetFast(element, groupTargets[groupIndex])) return true;
        }
        return false;
      }

      if (target.mode === 'selector') {
        return this.matchesSelectorBulkTarget(element, target, true);
      }

      var value = String(target.value || '').trim();
      if (!value) return false;

      if (target.mode === 'tag') {
        var tagLower = value.toLowerCase();
        var elementTag = this.getElementTagNameFast(element);
        if (elementTag === tagLower) return true;

        var elName = String(element.name || '').trim().toLowerCase();
        if (elName && elName === tagLower) return true;
        return false;
      }

      if (target.mode === 'class') {
        var clsClean = value.replace(/^\./, '');
        var classes = this.getElementClasses(element);
        return classes.indexOf(clsClean) !== -1;
      }

      if (target.mode === 'id') {
        var idClean = value.replace(/^#/, '');
        return this.getElementCssId(element) === idClean;
      }

      if (target.mode === 'type') {
        var type = String(element.name || element.label || element.element || element.type || '').trim().toLowerCase();
        return type === value.toLowerCase();
      }

      return false;
    },

    matchesBulkTarget: function (element, target) {
      if (!element || !target) return false;

      if (target.mode === 'group') {
        var groupTargets = target.targets || [];
        for (var groupIndex = 0; groupIndex < groupTargets.length; groupIndex++) {
          if (this.matchesBulkTarget(element, groupTargets[groupIndex])) return true;
        }
        return false;
      }

      if (target.mode === 'selector') {
        return this.matchesSelectorBulkTarget(element, target, false);
      }

      var value = String(target.value || '').trim();
      if (!value) return false;

      var matched = false;
      if (target.mode === 'tag') {
        var tagLower = value.toLowerCase();
        var elementTag = this.getElementTagName(element);
        if (elementTag === tagLower) matched = true;
        
        // Also match against the Bricks element type name
        var elName = String(element.name || '').trim().toLowerCase();
        if (elName && elName === tagLower) matched = true;
        
        // Match custom label
        var elLabel = String(element.label || '').trim().toLowerCase();
        if (elLabel && elLabel === tagLower) matched = true;
        
      } else if (target.mode === 'class') {
        var clsClean = value.replace(/^\./, '');
        var classes = this.getElementClasses(element);
        matched = classes.indexOf(clsClean) !== -1;
      } else if (target.mode === 'id') {
        var idClean = value.replace(/^#/, '');
        var cssId = this.getElementCssId(element);
        matched = cssId === idClean;
      } else if (target.mode === 'type') {
        var type = String(element.name || element.label || element.element || element.type || '').trim().toLowerCase();
        matched = type === value.toLowerCase();
      }

      return matched;
    },

    getCanvasDocumentSafe: function () {
      try {
        var iframe = document.getElementById('bricks-builder-iframe') ||
          document.querySelector('iframe.bricks-builder-iframe') ||
          document.getElementById('brx-iframe') ||
          document.querySelector('.brx-iframe') ||
          document.querySelector('iframe');
        if (iframe && iframe.contentDocument) return iframe.contentDocument;
        if (iframe && iframe.contentWindow && iframe.contentWindow.document) return iframe.contentWindow.document;
      } catch (e) {}
      return null;
    },

    getCanvasElementIdsByTag: function (tagName, limit) {
      tagName = String(tagName || '').trim().toLowerCase();
      limit = limit || (MAX_BULK_TARGETS + 1);
      if (!tagName || !/^[a-z][a-z0-9-]*$/.test(tagName)) return [];

      var doc = this.getCanvasDocumentSafe();
      if (!doc) return [];

      var ids = [];
      var seen = {};

      function collectId(node) {
        if (!node || !node.getAttribute) return;
        var rawId = node.getAttribute('data-id') || node.getAttribute('data-element-id') || node.getAttribute('data-bricks-id') || node.id || '';
        rawId = String(rawId || '').replace(/^brxe-/, '').trim();
        if (!rawId || seen[rawId]) return;
        seen[rawId] = true;
        ids.push(rawId);
      }

      try {
        if (doc.createTreeWalker && doc.body) {
          var walker = doc.createTreeWalker(doc.body, 1, {
            acceptNode: function (node) {
              return node && node.tagName && String(node.tagName).toLowerCase() === tagName ? 1 : 3;
            }
          });

          var node;
          while ((node = walker.nextNode()) && ids.length < limit) {
            collectId(node);
          }
          return ids;
        }

        // Last-resort fallback for older browsers only. Keep it bounded after collection.
        if (typeof doc.getElementsByTagName === 'function') {
          var nodes = doc.getElementsByTagName(tagName);
          for (var i = 0; i < nodes.length && ids.length < limit; i++) {
            collectId(nodes[i]);
          }
        }
      } catch (e) {
        return [];
      }
      return ids;
    },

    getBulkElementsRootSafe: function () {
      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;

      if (globals && globals.$_dynamicElements && Array.isArray(globals.$_dynamicElements.value)) {
        return globals.$_dynamicElements.value;
      }
      if (state && state.activeComponent && Array.isArray(state.activeComponent.elements)) {
        return state.activeComponent.elements;
      }
      if (window.bricksData && Array.isArray(window.bricksData.elements)) {
        return window.bricksData.elements;
      }
      return [];
    },

    getCanvasElementIdsByBulkTarget: function (target, limit) {
      limit = limit || (MAX_BULK_TARGETS + 1);
      if (!target) return [];

      var doc = this.getCanvasDocumentSafe();
      if (!doc || !doc.body) return [];

      var ids = [];
      var seen = {};
      var self = this;

      function nodeHasClass(node, className) {
        if (!node || !className) return false;
        className = String(className || '').replace(/^\./, '');
        if (!className) return false;
        if (node.classList && typeof node.classList.contains === 'function') return node.classList.contains(className);
        return (' ' + String(node.className || '') + ' ').indexOf(' ' + className + ' ') !== -1;
      }

      function nodeBricksId(node) {
        if (!node || !node.getAttribute) return '';
        var raw = String(
          node.getAttribute('data-id') ||
          node.getAttribute('data-element-id') ||
          node.getAttribute('data-bricks-id') ||
          ''
        ).trim();
        if (!raw && String(node.id || '').indexOf('brxe-') === 0) raw = String(node.id || '');
        return raw.replace(/^brxe-/, '').trim();
      }

      function nodeMatches(node, item) {
        if (!node || !item || !node.tagName) return false;

        if (item.mode === 'group') {
          var groupTargets = item.targets || [];
          for (var groupIndex = 0; groupIndex < groupTargets.length; groupIndex++) {
            if (nodeMatches(node, groupTargets[groupIndex])) return true;
          }
          return false;
        }

        if (item.mode === 'tag') {
          return String(node.tagName || '').toLowerCase() === String(item.value || '').toLowerCase();
        }

        if (item.mode === 'class') {
          return nodeHasClass(node, item.value);
        }

        if (item.mode === 'id') {
          var wantedId = String(item.value || '').replace(/^#/, '');
          return !!wantedId && String(node.id || '').replace(/^brxe-/, '') === wantedId;
        }

        if (item.mode === 'selector') {
          if (item.tag && String(node.tagName || '').toLowerCase() !== String(item.tag || '').toLowerCase()) return false;
          if (item.id && String(node.id || '').replace(/^#|^brxe-/, '') !== String(item.id || '').replace(/^#/, '')) return false;
          var classes = item.classes || [];
          for (var i = 0; i < classes.length; i++) {
            if (!nodeHasClass(node, classes[i])) return false;
          }
          return true;
        }

        return false;
      }

      function collect(node) {
        var id = nodeBricksId(node);
        if (!id || seen[id]) return;
        seen[id] = true;
        ids.push(id);
      }

      try {
        if (doc.createTreeWalker) {
          var walker = doc.createTreeWalker(doc.body, 1, {
            acceptNode: function (node) {
              return nodeMatches(node, target) ? 1 : 3;
            }
          });
          var node;
          while ((node = walker.nextNode()) && ids.length < limit) collect(node);
          return ids;
        }

        var nodes = doc.body.getElementsByTagName('*');
        for (var i = 0; i < nodes.length && ids.length < limit; i++) {
          if (nodeMatches(nodes[i], target)) collect(nodes[i]);
        }
      } catch (e) {
        log('bulk target DOM fallback failed', e);
      }

      return ids;
    },

    findElementsByIdsSafe: function (ids) {
      ids = Array.isArray(ids) ? ids : [];
      if (!ids.length) return [];

      var needed = {};
      var remaining = 0;
      ids.forEach(function (id) {
        id = String(id || '').trim();
        if (id && !needed[id]) { needed[id] = true; remaining++; }
      });
      if (!remaining) return [];

      // Match the verified console method: no Vue.toRaw calls, no full cache,
      // no iframe helper calls. Just walk the current Bricks element array by ID
      // with a hard guard and stop as soon as all IDs are found.
      var root = this.getBulkElementsRootSafe();
      var stack = Array.isArray(root) ? root.slice() : [];
      var out = [];
      var guard = 0;
      var maxNodes = 3000;

      while (stack.length && remaining > 0 && guard < maxNodes) {
        guard++;
        var item = stack.pop();
        if (!item || typeof item !== 'object') continue;

        var itemId = String(item.id || item.instanceId || '').trim();
        if (itemId && needed[itemId]) {
          out.push(item);
          delete needed[itemId];
          remaining--;
        }

        if (Array.isArray(item.children)) {
          for (var i = 0; i < item.children.length; i++) stack.push(item.children[i]);
        }
      }

      return out;
    },

    findBulkTargetsStreamed: function (target, limit) {
      limit = limit || (MAX_BULK_TARGETS + 1);
      var root = this.getBulkElementsRootSafe();
      var stack = Array.isArray(root) ? root.slice() : [];
      var out = [];
      var seenIds = {};
      var guard = 0;
      var maxNodes = 3000;

      while (stack.length && out.length < limit && guard < maxNodes) {
        guard++;
        var element = stack.pop();
        if (!element || typeof element !== 'object') continue;

        var id = String(element.id || element.instanceId || '').trim();
        if (id && !seenIds[id] && this.matchesBulkTargetFast(element, target)) {
          seenIds[id] = true;
          out.push(element);
          if (out.length >= limit) break;
        }

        if (Array.isArray(element.children)) {
          for (var i = 0; i < element.children.length; i++) stack.push(element.children[i]);
        }
      }

      return out;
    },

    findBulkTargets: function (target, options) {
      options = options || {};
      var limit = options.limit || (MAX_BULK_TARGETS + 1);

      if (target && target.mode === 'group') {
        var out = [];
        var seen = {};
        var groupTargets = target.targets || [];
        for (var groupIndex = 0; groupIndex < groupTargets.length && out.length < limit; groupIndex++) {
          var groupItems = this.findBulkTargets(groupTargets[groupIndex], { limit: limit });
          for (var itemIndex = 0; itemIndex < groupItems.length && out.length < limit; itemIndex++) {
            var item = groupItems[itemIndex];
            var id = String(item && (item.id || item.instanceId) || '').trim();
            if (!id || seen[id]) continue;
            seen[id] = true;
            out.push(item);
          }
        }
        return out;
      }

      // Check both Bricks element data and canvas DOM, merging results to ensure
      // we don't miss elements whose tags/classes are only resolvable in one of them.
      var seenIds = {};
      var out = [];

      var fromData = this.findBulkTargetsStreamed(target, limit);
      fromData.forEach(function (el) {
        if (el && el.id && !seenIds[el.id]) {
          seenIds[el.id] = true;
          out.push(el);
        }
      });

      if (out.length < limit) {
        var domIds = this.getCanvasElementIdsByBulkTarget(target, limit);
        if (domIds.length) {
          var fromDomTarget = this.findElementsByIdsSafe(domIds);
          fromDomTarget.forEach(function (el) {
            if (el && el.id && !seenIds[el.id]) {
              seenIds[el.id] = true;
              out.push(el);
            }
          });
        }
      }

      if (out.length < limit) {
        var fallbackTag = '';
        if (target && target.mode === 'tag') fallbackTag = target.value;
        if (target && target.mode === 'selector' && target.tag) fallbackTag = target.tag;

        if (fallbackTag) {
          var ids = this.getCanvasElementIdsByTag(fallbackTag, limit);
          if (ids.length) {
            var filterTarget = target;
            if (target && target.mode === 'selector' && target.tag) {
              filterTarget = {
                mode: 'selector',
                value: target.value,
                tag: '',
                id: target.id || '',
                classes: target.classes || []
              };
            }

            var fromCanvas = this.findElementsByIdsSafe(ids).filter(function (element) {
              return !filterTarget || filterTarget.mode === 'tag' || this.matchesBulkTargetFast(element, filterTarget);
            }, this);

            fromCanvas.forEach(function (el) {
              if (el && el.id && !seenIds[el.id]) {
                seenIds[el.id] = true;
                out.push(el);
              }
            });
          }
        }
      }

      return out.slice(0, limit);
    },

    applyAttributes: function (operations) {
      var ops = this.normalizeOperations(operations);
      var bulkOps = ops.filter(function (op) { return op && op.type === 'bulk-apply'; });

      if (bulkOps.length) {
        return this.applyBulkOperations(bulkOps);
      }

      var element = this.getSelectedElement();
      if (!element) return { ok: false, reason: 'no-selection' };

      return this.applyOperationsToElement(element, ops);
    },

    normalizeOperations: function (operations) {
      var ops = Array.isArray(operations) ? operations : [];
      return ops.map(function (op) {
        if (op && op.type) return op;
        return { type: 'set', name: op && op.name, value: op && op.value };
      }).filter(function (op) {
        return op && (
          op.type === 'set' ||
          op.type === 'rename' ||
          op.type === 'delete-attribute' ||
          op.type === 'set-id' ||
          op.type === 'add-class' ||
          op.type === 'remove-class' ||
          op.type === 'rename-class' ||
          op.type === 'delete-global-class' ||
          op.type === 'bulk-apply'
        );
      });
    },

    canApplyOperationsLight: function (ops) {
      ops = this.normalizeOperations(ops || []);
      if (!ops.length) return false;
      return ops.every(function (op) {
        return op && (
          op.type === 'set' ||
          op.type === 'delete-attribute' ||
          op.type === 'set-id'
        );
      });
    },

    applyOperationsToElementLight: function (element, operations) {
      if (!element) return { ok: false, reason: 'no-selection' };

      // Match the console method that worked on the user's Bricks page: mutate
      // the element object from $_dynamicElements directly. Avoid Vue.toRaw,
      // JSON clone/stringify, deep comparisons, selected element commits, and
      // any per-element iframe/Vue helper calls.
      if (!element.settings || typeof element.settings !== 'object') {
        element.settings = {};
      }

      var settings = element.settings;
      var attrs = Array.isArray(settings._attributes) ? settings._attributes.slice() : [];
      var ops = this.normalizeOperations(operations || []);

      function findIndexByName(name) {
        for (var i = 0; i < attrs.length; i++) {
          if (attrs[i] && attrs[i].name === name) return i;
        }
        return -1;
      }

      for (var i = 0; i < ops.length; i++) {
        var op = ops[i];

        if (op.type === 'set') {
          var setIndex = findIndexByName(op.name);
          var value = op.value == null ? '' : String(op.value);
          if (setIndex >= 0) {
            attrs[setIndex].value = value;
          } else {
            attrs.push({ id: makeId(), name: op.name, value: value });
          }
          continue;
        }

        if (op.type === 'delete-attribute') {
          var namesToDelete = Array.isArray(op.names) ? op.names : [op.name];
          var normalizedNames = namesToDelete.map(function (name) { return String(name || '').trim(); }).filter(Boolean);
          var beforeLength = attrs.length;
          attrs = attrs.filter(function (attr) {
            return normalizedNames.indexOf(attr.name) === -1;
          });
          if (beforeLength === attrs.length) {
            return { ok: false, reason: 'missing-delete-attribute', name: normalizedNames.join(', ') };
          }
          continue;
        }

        if (op.type === 'set-id') {
          settings._cssId = String(op.value || '').replace(/^#/, '').trim();
          continue;
        }
      }

      settings._attributes = attrs;
      element.settings = settings;
      return { ok: true, element: element };
    },

    markBulkChanged: function (changedIds) {
      changedIds = changedIds || [];
      try {
        var globals = this.getVueGlobals();
        var state = globals && globals.$_state ? globals.$_state : null;

        if (state && Array.isArray(state.rerenderElementIds)) {
          changedIds.forEach(function (id) {
            if (id && state.rerenderElementIds.indexOf(id) === -1) state.rerenderElementIds.push(id);
          });
        }

        // Keep Bricks save-aware without per-element selected settings work.
        if (state && Array.isArray(state.unsavedChanges) && state.unsavedChanges.indexOf('components') === -1) {
          state.unsavedChanges.push('components');
        }
        if (state && Array.isArray(state.unsavedChanges) && state.unsavedChanges.indexOf('content') === -1) {
          state.unsavedChanges.push('content');
        }

        if (globals && typeof globals.$_rerenderControls === 'function') {
          globals.$_rerenderControls();
        } else if (state) {
          state.rerenderControls = (state.rerenderControls || 0) + 1;
        }
      } catch (e) { log('bulk mark changed failed', e); }
    },

    applyBulkOperations: function (bulkOps) {
      var self = this;
      var total = 0;
      var summaries = [];
      var changedIds = [];

      for (var i = 0; i < bulkOps.length; i++) {
        var bulk = bulkOps[i];
        if (!bulk.confirmed) {
          return { ok: false, reason: 'bulk-needs-confirmation', bulk: bulk };
        }

        var targets = this.findBulkTargets(bulk.target);
        if (!targets.length) {
          return { ok: false, reason: 'no-bulk-targets', target: this.describeBulkTarget(bulk.target) };
        }

        if (targets.length > MAX_BULK_TARGETS) {
          return { ok: false, reason: 'too-many-bulk-targets', target: this.describeBulkTarget(bulk.target), count: targets.length, max: MAX_BULK_TARGETS };
        }

        var innerOps = this.normalizeOperations(bulk.ops || []);
        innerOps = innerOps.filter(function (op) { return op.type !== 'bulk-apply' && op.type !== 'delete-global-class'; });
        if (!innerOps.length) {
          return { ok: false, reason: 'empty-bulk-command', target: this.describeBulkTarget(bulk.target) };
        }

        var useLightBulk = this.canApplyOperationsLight(innerOps);

        for (var targetIndex = 0; targetIndex < targets.length; targetIndex++) {
          var targetEl = targets[targetIndex];
          var result = useLightBulk
            ? self.applyOperationsToElementLight(targetEl, innerOps)
            : self.applyOperationsToElement(targetEl, innerOps, {
                silent: true,
                bulk: true,
                deferCacheClear: true
              });
          if (!result.ok) return result;
          if (targetEl && targetEl.id && changedIds.indexOf(targetEl.id) === -1) changedIds.push(targetEl.id);
          total++;
        }

        summaries.push({ target: this.describeBulkTarget(bulk.target), count: targets.length });
      }

      this._allElementsCache = null;
      this._allElementsCacheAt = 0;

      this.markBulkChanged(changedIds);

      return { ok: true, bulkCount: total, bulkSummaries: summaries };
    },

    applyOperationsToElement: function (element, operations, options) {
      options = options || {};
      if (!element) return { ok: false, reason: 'no-selection' };

      if (!element.settings || typeof element.settings !== 'object') {
        element.settings = {};
      }

      var ops = this.normalizeOperations(operations);
      var currentSettings = element.settings && typeof element.settings === 'object' ? element.settings : {};
      // Strip Vue reactivity before cloning so property reads don't trigger getter storms
      if (this._toRaw) currentSettings = this._toRaw(currentSettings) || currentSettings;
      var nextSettings = this.clone(currentSettings);
      var next = this.normalizeAttributes(nextSettings);
      var manualClasses = this.splitClassString(nextSettings._cssClasses);
      var globalClassIds = Array.isArray(nextSettings._cssGlobalClasses) ? nextSettings._cssGlobalClasses.slice() : [];
      var self = this;

      function findIndexByName(name) {
        for (var i = 0; i < next.length; i++) {
          if (next[i] && next[i].name === name) return i;
        }
        return -1;
      }

      function normalizeClassName(value) {
        return String(value || '').replace(/^\./, '').trim();
      }

      function hasManualClass(name) {
        return manualClasses.indexOf(name) !== -1;
      }

      function removeManualClass(name) {
        name = normalizeClassName(name);
        manualClasses = manualClasses.filter(function (item) { return item !== name; });
      }

      function getGlobalClassNameById(id) {
        var item = self.findGlobalClassById(id);
        return item && item.name ? String(item.name) : '';
      }

      function addGlobalClass(name) {
        name = normalizeClassName(name);
        if (!name) return false;

        var item = self.createGlobalClass(name);
        if (!item || !item.id) return false;

        if (globalClassIds.indexOf(item.id) === -1) {
          globalClassIds.push(item.id);
        }

        removeManualClass(name);
        return true;
      }

      function removeGlobalClass(name) {
        name = normalizeClassName(name);
        var found = false;

        globalClassIds = globalClassIds.filter(function (id) {
          var match = getGlobalClassNameById(id) === name || String(id) === name;
          if (match) found = true;
          return !match;
        });

        if (hasManualClass(name)) {
          removeManualClass(name);
          found = true;
        }

        return found;
      }

      function renameGlobalClassOnElement(from, to) {
        from = normalizeClassName(from);
        to = normalizeClassName(to);
        if (!from || !to) return false;

        var removed = removeGlobalClass(from);
        if (!removed) return false;
        addGlobalClass(to);
        return true;
      }

      function removeClassReferencesFromAllElements(classId, className) {
        var roots = self.getMutableElementsRoot();
        self.walkElements(roots, function (item) {
          if (!item.settings || typeof item.settings !== 'object') return;

          if (Array.isArray(item.settings._cssGlobalClasses)) {
            item.settings._cssGlobalClasses = item.settings._cssGlobalClasses.filter(function (id) {
              return id !== classId;
            });
          }

          var itemManual = self.splitClassString(item.settings._cssClasses);
          if (itemManual.length) {
            item.settings._cssClasses = itemManual.filter(function (manualName) {
              return manualName !== className;
            }).join(' ');
          }
        });
      }

      function deleteGlobalClassEverywhere(names, confirmed) {
        names = Array.isArray(names) ? names : [names];
        names = names.map(normalizeClassName).filter(Boolean).filter(function (name, index, list) {
          return list.indexOf(name) === index;
        });

        if (!names.length) return { ok: false, reason: 'missing-global-class', name: '' };
        if (!confirmed) return { ok: false, reason: 'global-delete-needs-confirmation', name: names[0], names: names };

        var state = self.getState();
        if (!state || !Array.isArray(state.globalClasses)) {
          return { ok: false, reason: 'missing-global-class', name: names.join(', '), names: names };
        }

        var missing = [];
        var idsToRemove = [];
        var classItems = [];

        names.forEach(function (name) {
          var item = self.findGlobalClassByName(name);
          if (!item || !item.id) {
            missing.push(name);
            return;
          }
          idsToRemove.push(item.id);
          classItems.push({ id: item.id, name: name });
        });

        if (missing.length) {
          return { ok: false, reason: 'missing-global-class', name: missing.join(', '), names: missing };
        }

        state.globalClasses = state.globalClasses.filter(function (globalClass) {
          return !(globalClass && idsToRemove.indexOf(globalClass.id) !== -1);
        });

        classItems.forEach(function (item) {
          globalClassIds = globalClassIds.filter(function (id) { return id !== item.id; });
          removeManualClass(item.name);
          removeClassReferencesFromAllElements(item.id, item.name);
        });

        try {
          var globals = self.getVueGlobals();
          if (globals && typeof globals.$_postMessage === 'function') {
            globals.$_postMessage({ key: 'globalClasses', value: JSON.stringify(state.globalClasses) });
          }
        } catch (e) { log('global class delete postMessage failed', e); }

        return { ok: true, names: names };
      }

      for (var i = 0; i < ops.length; i++) {
        var op = ops[i];

        if (op.type === 'set') {
          var setIndex = findIndexByName(op.name);
          if (setIndex >= 0) {
            next[setIndex].value = op.value == null ? '' : String(op.value);
          } else {
            next.push({ id: makeId(), name: op.name, value: op.value == null ? '' : String(op.value) });
          }
          continue;
        }

        if (op.type === 'delete-attribute') {
          var namesToDelete = Array.isArray(op.names) ? op.names : [op.name];
          var normalizedNames = namesToDelete.map(function (name) { return String(name || '').trim(); }).filter(Boolean);
          var beforeLength = next.length;
          next = next.filter(function (attr) {
            return normalizedNames.indexOf(attr.name) === -1;
          });
          if (beforeLength === next.length) {
            return { ok: false, reason: 'missing-delete-attribute', name: normalizedNames.join(', ') };
          }
          continue;
        }

        if (op.type === 'set-id') {
          nextSettings._cssId = String(op.value || '').replace(/^#/, '').trim();
          continue;
        }

        if (op.type === 'add-class') {
          addGlobalClass(op.name);
          continue;
        }

        if (op.type === 'remove-class') {
          removeGlobalClass(op.name);
          continue;
        }

        if (op.type === 'rename-class') {
          if (!renameGlobalClassOnElement(op.from, op.to)) {
            return { ok: false, reason: 'missing-class-source', name: op.from };
          }
          continue;
        }

        if (op.type === 'delete-global-class') {
          var deleteResult = deleteGlobalClassEverywhere(op.names || op.name, !!op.confirmed);
          if (!deleteResult.ok) return deleteResult;
          continue;
        }

        if (op.type === 'rename') {
          var fromIndex = findIndexByName(op.from);
          if (fromIndex < 0) {
            return { ok: false, reason: 'missing-rename-source', name: op.from };
          }

          var toIndex = findIndexByName(op.to);
          var source = next[fromIndex];
          var nextValue = op.hasValue ? (op.value == null ? '' : String(op.value)) : source.value;

          if (toIndex >= 0 && toIndex !== fromIndex) {
            next[toIndex].value = nextValue;
            next.splice(fromIndex, 1);
          } else {
            source.name = op.to;
            source.value = nextValue;
          }
        }
      }

      nextSettings._attributes = next;
      nextSettings._cssClasses = manualClasses.join(' ');
      nextSettings._cssGlobalClasses = globalClassIds.filter(function (id, index, list) {
        return id && list.indexOf(id) === index;
      });

      var selected = this.getSelectedElement();
      var isSelected = selected && selected.id === element.id;
      var commitOptions = isSelected ? { silent: true } : options;

      this.commitSettings(element, nextSettings, currentSettings, commitOptions);
      return { ok: true, element: element };
    },

    clone: function (value) {
      if (!value || typeof value !== 'object') return {};
      var copy = {};
      for (var key in value) {
        if (!Object.prototype.hasOwnProperty.call(value, key)) continue;
        var val = value[key];
        if (Array.isArray(val)) {
          copy[key] = val.map(function (item) {
            if (item && typeof item === 'object') {
              var itemCopy = {};
              for (var k in item) {
                if (Object.prototype.hasOwnProperty.call(item, k)) {
                  itemCopy[k] = item[k];
                }
              }
              return itemCopy;
            }
            return item;
          });
        } else if (val && typeof val === 'object') {
          var objCopy = {};
          for (var k in val) {
            if (Object.prototype.hasOwnProperty.call(val, k)) {
              objCopy[k] = val[k];
            }
          }
          copy[key] = objCopy;
        } else {
          copy[key] = val;
        }
      }
      return copy;
    },

    commitSettings: function (element, nextSettings, oldSettings, options) {
      options = options || {};
      var globals = this.getVueGlobals();
      var state = globals && globals.$_state ? globals.$_state : null;
      var committedViaBricks = false;

      if (options.bulk) {
        var cleanSettings;
        try {
          cleanSettings = JSON.parse(JSON.stringify(nextSettings));
        } catch (eJson) {
          cleanSettings = this.clone(nextSettings);
        }

        // Bulk commands should update Bricks' central element data only.
        // Avoid deep equality checks, console logging, and iframe Vue-state crawling per target;
        // those were causing Firefox/Bricks to run out of memory on commands like:
        // all li => data-anim="fade-up".
        element.settings = cleanSettings;

        try {
          if (state && Array.isArray(state.rerenderElementIds) && element.id && state.rerenderElementIds.indexOf(element.id) === -1) {
            state.rerenderElementIds.push(element.id);
          }
        } catch (eRerender) { log('Rerender push failed', eRerender); }

        try {
          if (state && Array.isArray(state.unsavedChanges) && state.unsavedChanges.indexOf('components') === -1) {
            state.unsavedChanges.push('components');
          }
        } catch (eUnsaved) { log('Unsaved push failed', eUnsaved); }

        if (!options.deferCacheClear) {
          this._allElementsCache = null;
          this._allElementsCacheAt = 0;
        }

        return;
      }

      // Important: do not set Bricks' internal unsavedChanges manually. In Bricks
      // 2.x that value is an array, and forcing it to a boolean can break save.
      // Instead, push the change through Bricks' own selectedElementSettings flow,
      // which is what the native controls use to mark/save changes.
      try {
        if (state && Array.isArray(state.selectedElements) && state.selectedElements.length) {
          var isAlreadySelected = state.selectedElements.some(function (selected) {
            return selected && selected.id === element.id;
          });

          if (!isAlreadySelected) {
            state.selectedElements = [element];
          }

          if (!this.isDeepEqual(state.selectedElementSettings, nextSettings)) {
            state.selectedElementSettings = this.clone(nextSettings);
          }
          committedViaBricks = true;
        }
      } catch (e) { log('selectedElementSettings commit failed', e); }

      // Fallback for unusual Bricks states where selectedElementSettings is not
      // available. Avoid dirty-state mutation; only update the central element and
      // rerender. This keeps the builder from saving corrupted runtime state.
      if (!committedViaBricks) {
        try {
          if (!this.isDeepEqual(element.settings, nextSettings)) {
            element.settings = this.clone(nextSettings);
          }
          if (globals && typeof globals.$_selectedElementsSetSettings === 'function') {
            globals.$_selectedElementsSetSettings(this.clone(nextSettings), this.clone(oldSettings || {}));
            committedViaBricks = true;
          }
        } catch (e2) { log('selectedElementsSetSettings fallback failed', e2); }
      }

      try {
        if (globals && typeof globals.$_rerenderControls === 'function') {
          globals.$_rerenderControls();
        } else if (state) {
          state.rerenderControls = (state.rerenderControls || 0) + 1;
        }
      } catch (e3) { log('controls refresh failed', e3); }

      if (!options.silent) {
        try {
          if (globals && typeof globals.$_showMessage === 'function') {
            globals.$_showMessage(labels.applied || 'Attributes applied.');
          }
        } catch (e4) { log('showMessage failed', e4); }
      }

      this._allElementsCache = null;

      try {
        window.dispatchEvent(new CustomEvent('baqa:attributes-applied', { detail: { element: element } }));
      } catch (e5) { /* noop */ }
    }
  };


  window.MimamsBarBricksAdapter = BricksAdapter;
})();
