// Mimam's Var - Figma — Figma Plugin (code.js) v2.17.18
// Clean rebuild with all fixes incorporated

try { figma.showUI(__html__, { width: 400, height: 560, themeColors: true }); }
catch(e) { figma.showUI(__html__, { width: 400, height: 560 }); }

// ── Storage helpers ──
const DOC_KEYS = [
  've_wp_url',
  've_api_key',
  've_source',
  've_paired',
  've_collection_id',
  've_collection_name',
  've_site_title',
  've_file_key',
  've_wp_to_figma_var_map',
  've_wp_public_name_map'
];

function currentFileKey() {
  return (typeof figma.fileKey === 'string' && figma.fileKey) || (figma.root && figma.root.id) || (figma.root && figma.root.name) || 'unknown-file';
}

async function getS(k) {
  if (DOC_KEYS.indexOf(k) !== -1) {
    try {
      return figma.root ? (figma.root.getPluginData(k) || '') : '';
    } catch(e) { return ''; }
  }
  return await figma.clientStorage.getAsync(k) || '';
}

async function setS(k, v) {
  if (DOC_KEYS.indexOf(k) !== -1) {
    try {
      if (figma.root) figma.root.setPluginData(k, String(v || ''));
    } catch(e) {}
    return;
  }
  await figma.clientStorage.setAsync(k, v);
}

async function getJsonS(k) {
  try {
    var raw = await getS(k);
    return raw ? JSON.parse(raw) : {};
  } catch(e) { return {}; }
}

async function setJsonS(k, v) {
  try { await setS(k, JSON.stringify(v || {})); } catch(e) {}
}

// ── Load/Save settings ──
async function loadSettings() {
  var collections = await collectionSummaries();
  var selectedId = await getS('ve_collection_id');
  var selectedName = await getS('ve_collection_name');
  var fileKey = currentFileKey();
  var storedFileKey = await getS('ve_file_key');
  var paired = (await getS('ve_paired')) === 'true';
  var apiKey = await getS('ve_api_key');
  if (paired && apiKey && storedFileKey && storedFileKey !== fileKey) {
    await saveSettings({ wpUrl: '', apiKey: '', source: '', paired: false, collectionId: '', collectionName: '' });
    await setS('ve_site_title', '');
    await setS('ve_file_key', '');
    paired = false;
    apiKey = '';
  } else if (paired && apiKey && !storedFileKey) {
    await setS('ve_file_key', fileKey);
  }
  figma.ui.postMessage({
    type: 'settings',
    wpUrl: await getS('ve_wp_url'),
    apiKey: apiKey,
    source: await getS('ve_source'),
    paired: paired,
    figmaFileName: figma.root ? figma.root.name : 'Unknown',
    siteTitle: await getS('ve_site_title'),
    collectionId: selectedId,
    collectionName: selectedName,
    collections: collections
  });
}

async function saveSettings(data) {
  if (data.wpUrl !== undefined) await setS('ve_wp_url', data.wpUrl);
  if (data.apiKey !== undefined) await setS('ve_api_key', data.apiKey);
  if (data.source !== undefined) await setS('ve_source', data.source);
  if (data.paired !== undefined) {
    await setS('ve_paired', data.paired ? 'true' : '');
    await setS('ve_file_key', data.paired ? currentFileKey() : '');
  }
  if (data.collectionId !== undefined) await setS('ve_collection_id', data.collectionId);
  if (data.collectionName !== undefined) await setS('ve_collection_name', data.collectionName);
}

// ── Convert Figma variable name to VE name ──
// color/accent-d-1 → color.accent.d.1
// color/brand/primary-d-1 → color.brand.primary.d.1
function veNameParts(raw) {
  return String(raw || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '.')
    .replace(/^\.+|\.+$/g, '')
    .split('.')
    .filter(function(p) { return !!p; });
}

function figmaToVeName(name) {
  var raw = String(name || '');
  var path = raw.split(/[\/\\]+/).filter(function(p) { return !!String(p || '').trim(); });
  var parts = [];

  if (path.length > 1) {
    var groupParts = veNameParts(path[0]);
    var restParts = [];
    for (var i = 1; i < path.length; i++) {
      restParts = restParts.concat(veNameParts(path[i]));
    }

    // VE's public Figma format keeps the full token inside the group:
    // color/color-primary-d-1, space/space-20. Drop the duplicated family
    // segment when reading that format back into WordPress.
    if (groupParts.length && restParts.length && restParts[0] === groupParts[0]) {
      restParts.shift();
    }
    parts = groupParts.concat(restParts);
  } else {
    parts = veNameParts(raw);
  }

  if (!parts.length) return 'token.unnamed';
  var out = parts.join('.');
  if (!/^[a-z]/.test(out)) out = 'token.' + out;
  return out;
}

// ── Convert VE name to Figma variable name ──
// color.accent.d.1 → color/accent-d-1
function veToFigmaName(name) {
  var dotIdx = name.indexOf('.');
  if (dotIdx === -1) return name;
  var ns = name.substring(0, dotIdx);
  var rest = name.substring(dotIdx + 1).replace(/\./g, '-');
  return ns + '/' + rest;
}

// Public token helpers. WordPress may store organizational wrappers such as
// size.space, but the public token should be space / --space.
function tokenPublicName(wp) {
  var raw = (wp && (wp.public_name || wp.css_name || wp.name)) || '';
  raw = String(raw).toLowerCase().trim();
  raw = raw.replace(/^--/, '');
  raw = raw.replace(/\./g, '-');
  raw = raw.replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '');
  return raw;
}


function tokenIdentityKey(wp) {
  if (wp && wp.identity_key) return String(wp.identity_key);
  if (wp && wp.id !== undefined && wp.id !== null) return 'id:' + String(wp.id);
  return tokenPublicName(wp);
}

function getVarPluginDataSafe(v, key) {
  try { return v && typeof v.getPluginData === 'function' ? (v.getPluginData(key) || '') : ''; } catch(e) { return ''; }
}

function setVarPluginDataSafe(v, key, value) {
  try { if (v && typeof v.setPluginData === 'function') v.setPluginData(key, String(value || '')); } catch(e) {}
}

function publicToFigmaName(publicName) {
  publicName = String(publicName || '').toLowerCase().replace(/^--/, '').replace(/\./g, '-').replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '');
  if (!publicName) return '';
  // Figma should group by family, but the variable name itself should remain
  // the full public token name for clarity.
  // Example: space-20 -> space/space-20, color-primary-d-1 -> color/color-primary-d-1
  var i = publicName.indexOf('-');
  var group = i === -1 ? publicName : publicName.substring(0, i);
  return group + '/' + publicName;
}

function figmaNameToPublicName(figmaName) {
  var n = String(figmaName || '').toLowerCase();
  if (n.indexOf('/') !== -1) {
    var parts = n.split('/');
    var group = parts.shift();
    var rest = parts.join('-');
    // New format keeps full public name inside the group: space/space-20.
    // Use the rest as the public name in that case.
    if (rest.indexOf(group + '-') === 0 || rest === group) n = rest;
    else n = group + '-' + rest;
  }
  return n.replace(/\./g, '-').replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '');
}

function publicGroup(publicName) {
  publicName = String(publicName || '').toLowerCase().replace(/^--/, '').replace(/\./g, '-').replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '');
  var i = publicName.indexOf('-');
  return i === -1 ? publicName : publicName.substring(0, i);
}

// ── Extract domain from URL ──
function getDomain(url) {
  try {
    var m = (url || '').replace(/\/+$/, '').match(/\/\/([^\/]+)/);
    return m ? m[1] : url;
  } catch(e) { return url; }
}

// ── Get all local collections ──
async function getCollections() {
  if (typeof figma.variables.getLocalVariableCollectionsAsync === 'function') {
    return await figma.variables.getLocalVariableCollectionsAsync();
  }
  return figma.variables.getLocalVariableCollections();
}

async function collectionSummaries() {
  var collections = await getCollections();
  return collections.map(function(c) {
    return { id: c.id, name: c.name, count: c.variableIds ? c.variableIds.length : 0 };
  });
}

async function findCollectionById(id) {
  if (!id) return null;
  var collections = await getCollections();
  for (var i = 0; i < collections.length; i++) {
    if (collections[i].id === id) return collections[i];
  }
  return null;
}

async function findCollectionByName(name) {
  if (!name) return null;
  var collections = await getCollections();
  for (var i = 0; i < collections.length; i++) {
    if (collections[i].name === name) return collections[i];
  }
  return null;
}

// ── Get variable by ID (async-safe) ──
async function getVarById(id) {
  if (typeof figma.variables.getVariableByIdAsync === 'function') {
    return await figma.variables.getVariableByIdAsync(id);
  }
  return figma.variables.getVariableById(id);
}

// ── Find the VE collection using multiple strategies ──
async function findVeCollection(siteTitle, preferredId) {
  var collections = await getCollections();
  var col = null;

  // 1. Stored collection ID (most reliable)
  var storedId = preferredId || await getS('ve_collection_id');
  if (storedId) {
    for (var i = 0; i < collections.length; i++) {
      if (collections[i].id === storedId) { col = collections[i]; break; }
    }
  }

  // 2. Site title match
  if (!col && siteTitle) {
    for (var j = 0; j < collections.length; j++) {
      if (collections[j].name === siteTitle) { col = collections[j]; break; }
    }
  }

  // 3. Domain URL match
  if (!col) {
    var domain = getDomain(await getS('ve_wp_url'));
    if (domain) {
      for (var k = 0; k < collections.length; k++) {
        if (collections[k].name === domain) { col = collections[k]; break; }
      }
    }
  }

  // 4. Largest collection fallback (if has VE-style variable names with /)
  if (!col) {
    var best = null;
    for (var bi = 0; bi < collections.length; bi++) {
      var c = collections[bi];
      if (!best || c.variableIds.length > best.variableIds.length) {
        // Quick check: does first variable have a / in its name?
        if (c.variableIds.length > 0) {
          var testVar = await getVarById(c.variableIds[0]);
          if (testVar && testVar.name.indexOf('/') !== -1) {
            best = c;
          }
        }
      }
    }
    if (best) col = best;
  }

  // Store found collection ID
  if (col) {
    await setS('ve_collection_id', col.id);
    await setS('ve_collection_name', col.name);
  }

  return col;
}

// ── Read variables from a specific collection ──
async function readCollectionVars(col) {
  var allVars = [];
  var modeId = col.defaultModeId;

  for (var i = 0; i < col.variableIds.length; i++) {
    var v = await getVarById(col.variableIds[i]);
    if (!v) continue;

    var mv = v.valuesByMode[modeId];
    var value = '';
    var rt = v.resolvedType;
    var type = 'base';
    var sourceName = '';
    var sourceCssName = '';

    if (rt === 'COLOR' && typeof mv === 'object' && mv !== null && 'r' in mv) {
      var r = Math.round(mv.r * 255), g = Math.round(mv.g * 255), b = Math.round(mv.b * 255);
      var a = mv.a !== undefined ? mv.a : 1;
      value = a < 1
        ? 'rgba(' + r + ',' + g + ',' + b + ',' + a.toFixed(2) + ')'
        : '#' + ('0'+r.toString(16)).slice(-2) + ('0'+g.toString(16)).slice(-2) + ('0'+b.toString(16)).slice(-2);
    } else if (typeof mv === 'object' && mv !== null && mv.type === 'VARIABLE_ALIAS') {
      var target = await getVarById(mv.id);
      value = target ? 'var(--' + target.name.replace(/\//g, '-').toLowerCase() + ')' : '';
      if (target) {
        type = 'alias';
        sourceName = figmaToVeName(target.name);
        sourceCssName = target.name.replace(/\//g, '-').toLowerCase();
      }
    } else if (rt === 'FLOAT') {
      value = String(mv !== undefined ? mv : 0);
    } else {
      value = String(mv !== undefined ? mv : '');
    }

    var publicCssName = '';
    var storedPublic = getVarPluginDataSafe(v, 've_public_name');
    if (storedPublic) {
      publicCssName = '--' + storedPublic;
    } else {
      var veName = figmaToVeName(v.name);
      var parts = veName.split('.');
      var storage_wrappers = ['size', 'font', 'typography'];
      if (parts.length > 1 && storage_wrappers.indexOf(parts[0]) !== -1) {
        parts.shift();
      }
      publicCssName = '--' + parts.join('-');
    }

    var externalCssName = '--' + figmaNameToPublicName(v.name);

    allVars.push({
      figma_id: v.id,
      figma_name: v.name,
      name: figmaToVeName(v.name),
      value: value,
      namespace: figmaToVeName(v.name).split('.')[0],
      collection: col.name,
      resolvedType: rt,
      type: type,
      source_name: sourceName,
      source_css_name: sourceCssName,
      public_css_name: publicCssName,
      external_css_name: externalCssName
    });
  }
  return allVars;
}

// ── Read ALL Figma variables (for pull) ──
async function readAllFigmaVars() {
  var all = [];
  var collections = await getCollections();
  for (var i = 0; i < collections.length; i++) {
    var vars = await readCollectionVars(collections[i]);
    all = all.concat(vars);
  }
  return all;
}

async function readSelectedFigmaVars(collectionId, collectionName) {
  var col = await findCollectionById(collectionId);
  if (!col && collectionName) col = await findCollectionByName(collectionName);
  if (!col) return await readAllFigmaVars();
  await setS('ve_collection_id', col.id);
  await setS('ve_collection_name', col.name);
  return await readCollectionVars(col);
}

// ── Write variables to Figma ──
// Creates/updates in a single collection named after the site title.
// Deletes variables in the collection that don't exist in WP (when skipDeletes=false).
async function writeFigmaVariables(wpVars, options) {
  var skipDeletes = options && options.skipDeletes !== undefined ? options.skipDeletes : true;
  var explicitCollectionName = options && options.collectionName ? options.collectionName : '';
  var colName = explicitCollectionName || (options && options.domain ? options.domain : 'WordPress');
  var selectedId = options && options.collectionId ? options.collectionId : '';
  var results = { created: 0, updated: 0, deleted: 0, skipped: 0, errors: [] };

  // Find or create the collection
  var col = await findCollectionById(selectedId);
  if (!col && colName) col = await findCollectionByName(colName);
  if (!col && !explicitCollectionName) col = await findVeCollection(colName, selectedId);

  if (!col) {
    // Check for old domain-named collection to rename
    var collections = await getCollections();
    var domain = getDomain(await getS('ve_wp_url'));
    for (var ri = 0; ri < collections.length; ri++) {
      if (collections[ri].name === domain) {
        col = collections[ri];
        col.name = colName;
        break;
      }
    }
  }

  if (!col) {
    col = figma.variables.createVariableCollection(colName);
    if (col.modes && col.modes.length > 0) {
      col.renameMode(col.modes[0].modeId, 'Default');
    }
  }

  // Rename if site title changed
  if (!selectedId && col.name !== colName) col.name = colName;

  await setS('ve_collection_id', col.id);
  await setS('ve_collection_name', col.name);
  await setS('ve_site_title', colName);

  var modeId = col.defaultModeId;

  // Index existing variables by internal name, public token name, and ID.
  // The ID map is stored locally after every successful push so future WP renames
  // can rename the same Figma variable instead of creating duplicates when
  // "delete variables" is not checked.
  var existingMap = {};
  var existingPublicMap = {};
  var existingById = {};
  var existingByWpKey = {};
  for (var ei = 0; ei < col.variableIds.length; ei++) {
    var ev = await getVarById(col.variableIds[ei]);
    if (!ev) continue;
    existingMap[figmaToVeName(ev.name)] = ev;
    existingPublicMap[figmaNameToPublicName(ev.name)] = ev;
    existingById[ev.id] = ev;
    var storedWpKey = getVarPluginDataSafe(ev, 've_wp_key');
    if (storedWpKey) existingByWpKey[storedWpKey] = ev;
  }
  var storedIdMap = await getJsonS('ve_wp_to_figma_var_map');
  var previousPublicMap = await getJsonS('ve_wp_public_name_map');
  var nextIdMap = {};
  var nextPublicMap = {};

  // Process each WP variable
  for (var wi = 0; wi < wpVars.length; wi++) {
    var wp = wpVars[wi];
    try {
      var veName = wp.name;
      var publicName = tokenPublicName(wp);
      var figmaName = publicToFigmaName(publicName || wp.name);

      // Determine type and value
      var resolvedType = 'STRING';
      var figmaValue;
      var rawVal = wp.value || '';

      if (isColor(rawVal)) {
        resolvedType = 'COLOR';
        figmaValue = parseColorToFigma(rawVal);
      } else {
        var numVal = extractNumber(rawVal);
        if (numVal !== null) {
          resolvedType = 'FLOAT';
          figmaValue = numVal;
        } else {
          figmaValue = rawVal;
        }
      }

      var wpKey = tokenIdentityKey(wp);
      var mappedId = wpKey && storedIdMap ? storedIdMap[wpKey] : '';
      var mappedExisting = mappedId && existingById[mappedId] ? existingById[mappedId] : null;
      var pluginDataExisting = wpKey && existingByWpKey[wpKey] ? existingByWpKey[wpKey] : null;
      var previousNames = [];
      if (wp && Array.isArray(wp.previous_public_names)) previousNames = wp.previous_public_names;
      var previousPublicName = wpKey && previousPublicMap ? previousPublicMap[wpKey] : '';
      if (previousPublicName) previousNames.push(previousPublicName);
      var previousExisting = null;
      for (var pi = 0; pi < previousNames.length; pi++) {
        var pn = String(previousNames[pi] || '').toLowerCase().replace(/^--/, '').replace(/\./g, '-').replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '');
        if (pn && existingPublicMap[pn]) { previousExisting = existingPublicMap[pn]; break; }
      }
      var existing = pluginDataExisting || mappedExisting || previousExisting || existingPublicMap[publicName] || existingMap[veName] || findRenameCandidate(existingPublicMap, publicName, rawVal, resolvedType, modeId);
      if (existing) {
        // Update existing, renaming if the public token name changed.
        var oldInternalKey = figmaToVeName(existing.name);
        var oldPublicKey = figmaNameToPublicName(existing.name);
        try { if (existing.name !== figmaName) existing.name = figmaName; } catch(rn) {}
        try {
          if (existing.resolvedType === resolvedType) {
            existing.setValueForMode(modeId, figmaValue);
          } else {
            // Type mismatch — try as string
            existing.setValueForMode(modeId, String(rawVal));
          }
          results.updated++;
          if (wpKey) {
            setVarPluginDataSafe(existing, 've_wp_key', wpKey);
            setVarPluginDataSafe(existing, 've_public_name', publicName);
            nextIdMap[wpKey] = existing.id; nextPublicMap[wpKey] = publicName;
          }
        } catch(ue) {
          results.errors.push(veName + ': ' + (ue.message || String(ue)));
        }
        delete existingMap[oldInternalKey];
        delete existingMap[figmaToVeName(existing.name)];
        delete existingPublicMap[oldPublicKey];
        delete existingPublicMap[figmaNameToPublicName(existing.name)];
        delete existingPublicMap[publicName];
      } else {
        // Create new
        var newVar = figma.variables.createVariable(figmaName, col, resolvedType);
        newVar.setValueForMode(modeId, figmaValue);
        results.created++;
        if (wpKey) {
          setVarPluginDataSafe(newVar, 've_wp_key', wpKey);
          setVarPluginDataSafe(newVar, 've_public_name', publicName);
          nextIdMap[wpKey] = newVar.id; nextPublicMap[wpKey] = publicName;
        }
      }
    } catch(err) {
      results.errors.push(wp.name + ': ' + (err.message || String(err)));
    }
  }

  // Delete remaining (in Figma but not in WP)
  if (!skipDeletes) {
    var delKeys = Object.keys(existingMap);
    for (var di = 0; di < delKeys.length; di++) {
      try {
        existingMap[delKeys[di]].remove();
        results.deleted++;
      } catch(de) {
        results.errors.push('Delete ' + delKeys[di] + ': ' + (de.message || String(de)));
      }
    }
  }

  await setJsonS('ve_wp_to_figma_var_map', nextIdMap);
  await setJsonS('ve_wp_public_name_map', nextPublicMap);
  return results;
}

function figmaValueToComparable(v, modeId) {
  try {
    var mv = v.valuesByMode[modeId];
    if (v.resolvedType === 'COLOR' && mv && typeof mv === 'object' && 'r' in mv) {
      var r = Math.round(mv.r * 255), g = Math.round(mv.g * 255), b = Math.round(mv.b * 255);
      var a = mv.a !== undefined ? mv.a : 1;
      return a < 1 ? ('rgba(' + r + ',' + g + ',' + b + ',' + a.toFixed(2) + ')') : ('#' + ('0'+r.toString(16)).slice(-2) + ('0'+g.toString(16)).slice(-2) + ('0'+b.toString(16)).slice(-2));
    }
    return String(mv !== undefined ? mv : '');
  } catch(e) { return ''; }
}

function valuesLikelySame(rawVal, existingVar, resolvedType, modeId) {
  if (!existingVar) return false;
  if (existingVar.resolvedType !== resolvedType) return false;
  if (resolvedType === 'FLOAT') {
    var a = extractNumber(rawVal);
    var b = extractNumber(figmaValueToComparable(existingVar, modeId));
    return a !== null && b !== null && Math.abs(a - b) < 0.01;
  }
  if (resolvedType === 'COLOR') {
    return String(rawVal || '').trim().toLowerCase() === figmaValueToComparable(existingVar, modeId).trim().toLowerCase();
  }
  return String(rawVal || '').trim() === figmaValueToComparable(existingVar, modeId).trim();
}

function findRenameCandidate(existingPublicMap, publicName, rawVal, resolvedType, modeId) {
  var keys = Object.keys(existingPublicMap || {});
  var matches = [];
  var group = publicGroup(publicName);
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    var ev = existingPublicMap[k];
    if (!ev) continue;
    var keyGroup = publicGroup(k);
    var suffixMatch = k === publicName || k.endsWith('-' + publicName) || publicName.endsWith('-' + k);
    var sameFamily = group && keyGroup && group === keyGroup;
    // For a rename, the name may be completely different, but the old variable
    // should usually stay in the same top-level family and keep the same value/type.
    // Example: color-primary -> color-secondary, space-20 -> gap-20, etc.
    if ((suffixMatch || sameFamily) && valuesLikelySame(rawVal, ev, resolvedType, modeId)) matches.push(ev);
  }
  return matches.length === 1 ? matches[0] : null;
}

// ── Color detection ──
function isColor(val) {
  return /^(#[0-9a-fA-F]{3,8}|rgba?\(|hsla?\(|oklch\()/.test(val || '');
}

// ── OKLCH → RGB via OKLab ──
function oklchToRgb(L, C, H) {
  var hRad = H * Math.PI / 180;
  var a = C * Math.cos(hRad), b = C * Math.sin(hRad);
  var l_ = L + 0.3963377774*a + 0.2158037573*b;
  var m_ = L - 0.1055613458*a - 0.0638541728*b;
  var s_ = L - 0.0894841775*a - 1.2914855480*b;
  var l = l_*l_*l_, m = m_*m_*m_, s = s_*s_*s_;
  var rL = 4.0767416621*l - 3.3077115913*m + 0.2309699292*s;
  var gL = -1.2684380046*l + 2.6097574011*m - 0.3413193965*s;
  var bL = -0.0041960863*l - 0.7034186147*m + 1.7076147010*s;
  function gamma(v) { return v <= 0.0031308 ? 12.92*v : 1.055*Math.pow(Math.max(0,v), 1/2.4) - 0.055; }
  return { r: Math.max(0, Math.min(1, gamma(rL))), g: Math.max(0, Math.min(1, gamma(gL))), b: Math.max(0, Math.min(1, gamma(bL))) };
}

// ── Parse any color to Figma {r,g,b,a} ──
function parseColorToFigma(val) {
  if (val.charAt(0) === '#') {
    var hex = val.slice(1);
    if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
    if (hex.length === 8) return { r:parseInt(hex.slice(0,2),16)/255, g:parseInt(hex.slice(2,4),16)/255, b:parseInt(hex.slice(4,6),16)/255, a:parseInt(hex.slice(6,8),16)/255 };
    return { r:parseInt(hex.slice(0,2),16)/255, g:parseInt(hex.slice(2,4),16)/255, b:parseInt(hex.slice(4,6),16)/255, a:1 };
  }
  var om = val.match(/oklch\(\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)\s*(?:\/\s*([\d.]+))?\s*\)/);
  if (om) { var rgb = oklchToRgb(+om[1], +om[2], +om[3]); return { r:rgb.r, g:rgb.g, b:rgb.b, a:om[4]!==undefined?+om[4]:1 }; }
  var hm = val.match(/hsla?\(\s*([\d.]+)\s*,?\s*([\d.]+)%?\s*,?\s*([\d.]+)%?\s*(?:[,\/]\s*([\d.]+))?\s*\)/);
  if (hm) {
    var hu=+hm[1]/360, sa=+hm[2]/100, li=+hm[3]/100;
    function h2r(p,q,t){if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return p+(q-p)*6*t;if(t<.5)return q;if(t<2/3)return p+(q-p)*(2/3-t)*6;return p;}
    var q=li<.5?li*(1+sa):li+sa-li*sa, p=2*li-q;
    return { r:sa===0?li:h2r(p,q,hu+1/3), g:sa===0?li:h2r(p,q,hu), b:sa===0?li:h2r(p,q,hu-1/3), a:hm[4]!==undefined?+hm[4]:1 };
  }
  var rm = val.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+))?\s*\)/);
  if (rm) return { r:+rm[1]/255, g:+rm[2]/255, b:+rm[3]/255, a:rm[4]!==undefined?+rm[4]:1 };
  return { r:0, g:0, b:0, a:1 };
}

// ── Extract numeric value for Figma FLOAT ──
// clamp() → max value, rem×10, px strip, em×16, generic unit strip
function extractNumber(val) {
  val = (val || '').trim();
  var cm = val.match(/clamp\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)/);
  if (cm) return extractNumber(cm[3].trim());
  var rem = val.match(/^([\d.]+)\s*rem$/i);
  if (rem) return Math.round(parseFloat(rem[1]) * 10 * 100) / 100;
  var px = val.match(/^([\d.]+)\s*px$/i);
  if (px) return parseFloat(px[1]);
  var em = val.match(/^([\d.]+)\s*em$/i);
  if (em) return Math.round(parseFloat(em[1]) * 16 * 100) / 100;
  var pct = val.match(/^([\d.]+)\s*%$/);
  if (pct) return parseFloat(pct[1]);
  if (/^[\d.]+$/.test(val)) return parseFloat(val);
  var gen = val.match(/^([\d.]+)\s*[a-z]+$/i);
  if (gen) return parseFloat(gen[1]);
  return null;
}

// ── Smart Apply ──
// Scan current page for unbound style values and group by family + value.
// Skips nodes whose property is already bound to a variable.

function rgbToHex6(r, g, b) {
  function ch(v) { var n = Math.max(0, Math.min(255, Math.round(v * 255))); var s = n.toString(16); return s.length === 1 ? '0' + s : s; }
  return '#' + ch(r) + ch(g) + ch(b);
}

function isVarBound(node, field) {
  try {
    var b = node.boundVariables;
    if (!b) return false;
    if (field === 'fills' || field === 'strokes') {
      var arr = b[field];
      return Array.isArray(arr) && arr.length > 0 && !!arr[0];
    }
    return !!b[field];
  } catch (e) { return false; }
}

function pushDetected(map, family, value, nodeId, field, fillIndex) {
  var key = family + '::' + value;
  if (!map[key]) map[key] = { family: family, value: value, count: 0, refs: [] };
  map[key].count++;
  map[key].refs.push({ id: nodeId, field: field, fillIndex: typeof fillIndex === 'number' ? fillIndex : -1 });
}

async function scanCurrentPage() {
  // Force-load all descendants so all nodes are available for traversal.
  await figma.currentPage.loadAsync();
  var map = {};
  var nodes = figma.currentPage.findAll(function(n) { return true; });

  for (var i = 0; i < nodes.length; i++) {
    var n = nodes[i];

    // Fills (solid colors only)
    if ('fills' in n && Array.isArray(n.fills) && !isVarBound(n, 'fills')) {
      for (var fi = 0; fi < n.fills.length; fi++) {
        var f = n.fills[fi];
        if (f && f.type === 'SOLID' && f.visible !== false && f.color) {
          var hex = rgbToHex6(f.color.r, f.color.g, f.color.b);
          pushDetected(map, 'color', hex, n.id, 'fills', fi);
          break; // only the first visible solid fill per node
        }
      }
    }

    // Strokes (solid colors only)
    if ('strokes' in n && Array.isArray(n.strokes) && !isVarBound(n, 'strokes')) {
      for (var si = 0; si < n.strokes.length; si++) {
        var s = n.strokes[si];
        if (s && s.type === 'SOLID' && s.visible !== false && s.color) {
          var hexS = rgbToHex6(s.color.r, s.color.g, s.color.b);
          pushDetected(map, 'color', hexS, n.id, 'strokes', si);
          break;
        }
      }
    }

    // Spacing — auto-layout properties
    if ('itemSpacing' in n && typeof n.itemSpacing === 'number' && n.itemSpacing > 0 && !isVarBound(n, 'itemSpacing')) {
      pushDetected(map, 'space', String(n.itemSpacing), n.id, 'itemSpacing');
    }
    var padFields = ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft'];
    for (var pi = 0; pi < padFields.length; pi++) {
      var pf = padFields[pi];
      if (pf in n && typeof n[pf] === 'number' && n[pf] > 0 && !isVarBound(n, pf)) {
        pushDetected(map, 'space', String(n[pf]), n.id, pf);
      }
    }

    // Radius
    if ('cornerRadius' in n && typeof n.cornerRadius === 'number' && n.cornerRadius > 0 && !isVarBound(n, 'cornerRadius')) {
      pushDetected(map, 'radius', String(n.cornerRadius), n.id, 'cornerRadius');
    }

    // Typography — fontSize on text nodes (skip mixed)
    if (n.type === 'TEXT' && typeof n.fontSize === 'number' && n.fontSize > 0 && !isVarBound(n, 'fontSize')) {
      pushDetected(map, 'typography', String(n.fontSize), n.id, 'fontSize');
    }
  }

  var out = [];
  for (var k in map) { if (Object.prototype.hasOwnProperty.call(map, k)) out.push(map[k]); }
  // Sort: family asc, count desc.
  out.sort(function(a, b) { if (a.family !== b.family) return a.family < b.family ? -1 : 1; return b.count - a.count; });
  return out;
}

async function ensureFigmaVarForApply(opts) {
  // opts: { name (public token name like 'space-20'), family, value, collection }
  // Returns the Figma variable, creating it if it doesn't exist in the collection.
  var col = opts.collection;
  if (!col) throw new Error('No VE collection available for binding');

  // Try to find existing in this collection by full name (group/name).
  var allVars = await figma.variables.getLocalVariablesAsync();
  var fullName = opts.family === 'color' ? 'color/' + opts.name : opts.family + '/' + opts.name;
  for (var i = 0; i < allVars.length; i++) {
    var v = allVars[i];
    if (v.variableCollectionId === col.id && v.name === fullName) return v;
  }

  // Create it.
  var fType = opts.family === 'color' ? 'COLOR' : 'FLOAT';
  var newVar = figma.variables.createVariable(fullName, col, fType);
  var modeId = col.modes && col.modes[0] ? col.modes[0].modeId : null;
  if (modeId) {
    if (opts.family === 'color') {
      var hex = String(opts.value).replace('#', '');
      var r = parseInt(hex.substring(0, 2), 16) / 255;
      var g = parseInt(hex.substring(2, 4), 16) / 255;
      var b = parseInt(hex.substring(4, 6), 16) / 255;
      newVar.setValueForMode(modeId, { r: r, g: g, b: b, a: 1 });
    } else {
      newVar.setValueForMode(modeId, parseFloat(opts.value));
    }
  }
  return newVar;
}

function bindNodeField(node, field, fillIndex, variable) {
  if (field === 'fills' || field === 'strokes') {
    var arr = node[field];
    if (!Array.isArray(arr) || arr.length === 0) return false;
    var idx = fillIndex >= 0 && fillIndex < arr.length ? fillIndex : 0;
    // Clone the array and the target paint, then set the bound variable on the clone.
    var newArr = arr.slice();
    var paint = Object.assign({}, newArr[idx]);
    paint = figma.variables.setBoundVariableForPaint(paint, 'color', variable);
    newArr[idx] = paint;
    node[field] = newArr;
    return true;
  }
  // Numeric fields use the direct setBoundVariable API.
  node.setBoundVariable(field, variable);
  return true;
}

async function applySmartDecisions(decisions, siteTitle) {
  // decisions: array of { family, value, action: 'apply'|'create'|'skip', figmaVarId?, name?, refs: [...] }
  var col = await findVeCollection(siteTitle || await getS('ve_site_title') || '');
  if (!col) throw new Error('VE collection not found in this Figma file. Push variables from WordPress first.');

  var applied = 0, created = 0, skipped = 0, errors = 0;
  var allVars = await figma.variables.getLocalVariablesAsync();
  var byId = {};
  for (var ai = 0; ai < allVars.length; ai++) byId[allVars[ai].id] = allVars[ai];

  for (var i = 0; i < decisions.length; i++) {
    var d = decisions[i];
    if (d.action === 'skip') { skipped += (d.refs || []).length; continue; }

    try {
      var v = null;
      if (d.action === 'apply' && d.figmaVarId) {
        v = byId[d.figmaVarId] || await figma.variables.getVariableByIdAsync(d.figmaVarId);
      } else if (d.action === 'create' && d.name) {
        v = await ensureFigmaVarForApply({ name: d.name, family: d.family, value: d.value, collection: col });
        created++;
      }
      if (!v) { errors++; continue; }

      var refs = d.refs || [];
      for (var ri = 0; ri < refs.length; ri++) {
        var ref = refs[ri];
        var node = await figma.getNodeByIdAsync(ref.id);
        if (!node) { errors++; continue; }
        try {
          bindNodeField(node, ref.field, ref.fillIndex, v);
          applied++;
        } catch (be) { errors++; }
      }
    } catch (e) {
      errors++;
    }
  }

  return { applied: applied, created: created, skipped: skipped, errors: errors };
}

// ── Message handler ──
figma.ui.onmessage = async function(msg) {
  try {
    if (msg.type === 'init') {
      await loadSettings();
    }
    else if (msg.type === 'list-collections') {
      figma.ui.postMessage({
        type: 'collections',
        collections: await collectionSummaries(),
        collectionId: await getS('ve_collection_id'),
        collectionName: await getS('ve_collection_name')
      });
    }
    else if (msg.type === 'set-collection') {
      await saveSettings({ collectionId: msg.collectionId || '', collectionName: msg.collectionName || '' });
      figma.ui.postMessage({
        type: 'collections',
        collections: await collectionSummaries(),
        collectionId: await getS('ve_collection_id'),
        collectionName: await getS('ve_collection_name')
      });
    }
    else if (msg.type === 'read-figma-vars') {
      var vars = await readSelectedFigmaVars(msg.collectionId || '', msg.collectionName || '');
      figma.ui.postMessage({ type: 'figma-vars', variables: vars });
    }
    else if (msg.type === 'read-figma-domain-vars') {
      // Push diff: read only from the VE collection
      if (msg.siteTitle) await setS('ve_site_title', msg.siteTitle);
      var siteTitle = msg.siteTitle || await getS('ve_site_title') || '';
      var col = await findVeCollection(siteTitle, msg.collectionId || '');
      var domainVars = col ? await readCollectionVars(col) : [];
      figma.ui.postMessage({ type: 'figma-domain-vars', variables: domainVars, collection: col ? col.name : 'NOT FOUND', count: domainVars.length });
    }
    else if (msg.type === 'write-figma-vars') {
      if (msg.siteTitle) await setS('ve_site_title', msg.siteTitle);
      var colName = msg.siteTitle || await getS('ve_site_title') || getDomain(await getS('ve_wp_url'));
      if (msg.collectionName) colName = msg.collectionName;
      var res = await writeFigmaVariables(msg.variables, {
        skipDeletes: msg.skipDeletes !== undefined ? msg.skipDeletes : true,
        domain: colName,
        collectionId: msg.collectionId || '',
        collectionName: msg.collectionName || ''
      });
      figma.ui.postMessage({ type: 'write-result', created: res.created, updated: res.updated, deleted: res.deleted, skipped: res.skipped, errors: res.errors, collections: await collectionSummaries(), collectionId: await getS('ve_collection_id'), collectionName: await getS('ve_collection_name') });
    }
    else if (msg.type === 'complete-pair') {
      await saveSettings({ wpUrl: msg.wpUrl, apiKey: msg.apiKey, source: msg.source, paired: true });
      var fileName = figma.root ? figma.root.name : 'Unknown';
      figma.ui.postMessage({ type: 'pair-complete', figmaFileName: fileName });
    }
    else if (msg.type === 'disconnect') {
      await saveSettings({ apiKey: '', source: '', paired: false });
      await setS('ve_collection_id', '');
      await setS('ve_collection_name', '');
      await setS('ve_site_title', '');
      await setJsonS('ve_wp_to_figma_var_map', {});
      await setJsonS('ve_wp_public_name_map', {});
      figma.ui.postMessage({ type: 'disconnected' });
    }
    else if (msg.type === 'get-file-name') {
      figma.ui.postMessage({ type: 'file-name', name: figma.root ? figma.root.name : 'Unknown' });
    }
    else if (msg.type === 'smart-scan') {
      var detected = await scanCurrentPage();
      figma.ui.postMessage({ type: 'smart-scan-result', detected: detected, page: figma.currentPage.name });
    }
    else if (msg.type === 'smart-apply') {
      var res = await applySmartDecisions(msg.decisions || [], msg.siteTitle || '');
      figma.ui.postMessage({ type: 'smart-apply-result', applied: res.applied, created: res.created, skipped: res.skipped, errors: res.errors });
    }
    else if (msg.type === 'gen-system-scan') {
      var detectedAll = await scanCurrentPage();
      // Filter to colors only and strip node refs (we don't need them for system generation).
      var colors = detectedAll
        .filter(function(d) { return d.family === 'color'; })
        .map(function(d) { return { value: d.value, count: d.count }; });
      figma.ui.postMessage({ type: 'gen-system-scan-result', colors: colors, page: figma.currentPage.name });
    }
    else if (msg.type === 'close') {
      figma.closePlugin();
    }
  } catch(err) {
    figma.ui.postMessage({ type: 'error', message: err.message || String(err) });
  }
};
