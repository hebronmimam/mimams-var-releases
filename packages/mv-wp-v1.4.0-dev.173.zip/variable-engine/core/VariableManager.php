<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

class VariableManager {

    // ── Reserved namespaces from V0.4 spec ─────────────────────────────
    private const RESERVED_NS = [
        'color', 'space', 'font', 'radius', 'shadow',
        'motion', 'opacity', 'breakpoint', 'size',
        'heading', 'text', 'grid',
    ];

    // ── Naming regex: lowercase storage segments with CSS-safe hyphens ─
    public const NAME_PATTERN = '/^[a-z][a-z0-9]*(?:-[a-z0-9]+)*(?:\.[a-z0-9]+(?:-[a-z0-9]+)*)*$/';

    /**
     * Normalize user-entered names without exposing storage separators.
     * Dots remain the internal namespace separator; spaces become CSS-safe hyphens.
     */
    public static function normalize_name( string $name ): string {
        $name = strtolower( sanitize_text_field( $name ) );
        $segments = explode( '.', $name );
        $segments = array_map( static function ( string $segment ): string {
            $segment = preg_replace( '/\s+/', '-', trim( $segment ) );
            $segment = preg_replace( '/-+/', '-', (string) $segment );
            return trim( (string) $segment, '-' );
        }, $segments );

        return implode( '.', $segments );
    }

    /* ================================================================
     *  CREATE
     * ================================================================ */
    public function create( array $data, bool $defer_css_export = false ) {
        global $wpdb;
        $table = Schema::table( 'variables' );

        // Validate & sanitise.
        $prepared = $this->validate( $data );
        if ( is_wp_error( $prepared ) ) {
            return $prepared;
        }

        $css_conflict = $this->get_css_name_conflict( $prepared['name'] );
        if ( $css_conflict ) {
            return new \WP_Error(
                've_css_name_conflict',
                "Variable '{$prepared['name']}' would use the same CSS custom property as '{$css_conflict['name']}'.",
                [
                    'status'       => 409,
                    'css_name'     => $this->to_css_name( $prepared['name'] ),
                    'conflict_id'  => (int) $css_conflict['id'],
                    'conflict_name'=> $css_conflict['name'],
                ]
            );
        }

        // Derive namespace from first segment.
        $prepared['namespace'] = explode( '.', $prepared['name'] )[0];

        // Compile CSS value.
        $prepared['css_value'] = $this->compile_css_value( $prepared );

        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_transaction_failed', $wpdb->last_error ?: 'Could not start the variable transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;

        $inserted = $wpdb->insert( $table, [
            'name'           => $prepared['name'],
            'type'           => $prepared['type'],
            'namespace'      => $prepared['namespace'],
            'category_slug'  => $prepared['category_slug'],
            'origin'         => $prepared['origin'],
            'value'          => $prepared['value'],
            'css_value'      => $prepared['css_value'],
            'source_id'      => $prepared['source_id'] ?? null,
            'generator_type' => $prepared['generator_type'] ?? null,
        ], [ '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s' ] );

        if ( false === $inserted ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_create_failed', $wpdb->last_error, [ 'status' => 500 ] );
        }

        $id  = (int) $wpdb->insert_id;
        $var = $this->get( $id );

        // Register explicit parent/child relationships for imported dependents.
        if ( ! empty( $prepared['source_id'] ) && in_array( $prepared['type'], [ 'alias', 'generated' ], true ) ) {
            if ( ! ( new DependencyGraph() )->register( (int) $prepared['source_id'], $id, $prepared['type'] ) ) {
                $this->rollback_if_owned( $owns_transaction );
                return new \WP_Error( 've_dependency_failed', 'Could not register the variable dependency.', [ 'status' => 500 ] );
            }
        }

        // Re-export CSS.
        if ( ! $defer_css_export && ! ( new CssExporter() )->export() ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_css_write_failed', 'The variable was not created because the CSS file could not be written.', [ 'status' => 500 ] );
        }
        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            $this->rollback_if_owned( $owns_transaction );
            ( new CssExporter() )->export();
            return new \WP_Error( 've_commit_failed', $wpdb->last_error ?: 'Could not commit the variable creation.', [ 'status' => 500 ] );
        }

        return $var;
    }

    /* ================================================================
     *  READ
     * ================================================================ */
    public function get( int $id ): ?array {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'variables' ) . ' WHERE id = %d', $id ),
            ARRAY_A
        );
        return $row ?: null;
    }

    public function get_by_name( string $name ): ?array {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM ' . Schema::table( 'variables' ) . ' WHERE name = %s', $name ),
            ARRAY_A
        );
        return $row ?: null;
    }

    public function get_all( array $args = [] ): array {
        global $wpdb;
        $table = Schema::table( 'variables' );
        $where = [];
        $vals  = [];

        if ( ! empty( $args['namespace'] ) ) {
            $where[] = 'namespace = %s';
            $vals[]  = $args['namespace'];
        }
        if ( ! empty( $args['category_slug'] ) ) {
            $where[] = 'category_slug = %s';
            $vals[]  = sanitize_key( (string) $args['category_slug'] );
        }
        if ( ! empty( $args['type'] ) ) {
            $where[] = 'type = %s';
            $vals[]  = $args['type'];
        }

        $sql = "SELECT * FROM {$table}";
        if ( $where ) {
            $sql .= ' WHERE ' . implode( ' AND ', $where );
        }
        $sql .= ' ORDER BY position ASC, namespace ASC, name ASC';

        if ( $vals ) {
            $sql = $wpdb->prepare( $sql, ...$vals );
        }

        return $wpdb->get_results( $sql, ARRAY_A ) ?: [];
    }

    /**
     * Recompile css_value for every fluid variable.
     *
     * Called when the global viewport settings change, since a fluid
     * variable's clamp() output depends on vw_min / vw_max. Runs a single
     * CSS export at the end rather than one per variable.
     *
     * @return int|\WP_Error Number of fluid variables recompiled, or an explicit failure.
     */
    public function recompile_fluid() {
        global $wpdb;
        $table = Schema::table( 'variables' );
        $rows  = $wpdb->get_results( "SELECT id, value FROM {$table}", ARRAY_A );
        if ( null === $rows ) {
            return new \WP_Error( 've_fluid_read_failed', $wpdb->last_error ?: 'Could not read fluid variables.', [ 'status' => 500 ] );
        }

        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_transaction_failed', $wpdb->last_error ?: 'Could not start the fluid-variable transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;

        $count = 0;
        foreach ( $rows as $row ) {
            if ( ! FluidValue::is_fluid( (string) $row['value'] ) ) {
                continue;
            }
            $new_css = FluidValue::compile( (string) $row['value'], 'rem' );
            $updated = $wpdb->update(
                $table,
                [ 'css_value' => $new_css ],
                [ 'id' => (int) $row['id'] ],
                [ '%s' ],
                [ '%d' ]
            );
            if ( false === $updated ) {
                $this->rollback_if_owned( $owns_transaction );
                return new \WP_Error( 've_fluid_update_failed', $wpdb->last_error ?: 'Could not update a fluid variable.', [ 'status' => 500 ] );
            }
            $count++;
        }

        if ( $count > 0 && ! ( new CssExporter() )->export() ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_css_write_failed', 'Fluid variables were not changed because the generated CSS file could not be written.', [ 'status' => 500 ] );
        }
        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            $this->rollback_if_owned( $owns_transaction );
            if ( $count > 0 ) {
                ( new CssExporter() )->export();
            }
            return new \WP_Error( 've_commit_failed', $wpdb->last_error ?: 'Could not commit the fluid-variable changes.', [ 'status' => 500 ] );
        }
        return $count;
    }

    /* ================================================================
     *  SEARCH (fuzzy — LIKE-based for MVP, upgrade to full-text later)
     * ================================================================ */
    public function search( string $query, int $limit = 50 ): array {
        global $wpdb;
        $table = Schema::table( 'variables' );
        $like  = '%' . $wpdb->esc_like( $query ) . '%';

        return $wpdb->get_results(
            $wpdb->prepare(
                "SELECT * FROM {$table} WHERE name LIKE %s ORDER BY name ASC LIMIT %d",
                $like,
                $limit
            ),
            ARRAY_A
        ) ?: [];
    }

    /* ================================================================
     *  UPDATE
     * ================================================================ */
    public function update( int $id, array $data, bool $defer_css_export = false ) {
        global $wpdb;
        $table    = Schema::table( 'variables' );
        $existing = $this->get( $id );

        if ( ! $existing ) {
            return new \WP_Error( 've_not_found', 'Variable not found.', [ 'status' => 404 ] );
        }

        // Generated variables cannot be edited directly.
        if ( 'generated' === $existing['type'] ) {
            return new \WP_Error( 've_locked', 'Generated variables cannot be edited directly. Update the base variable.', [ 'status' => 403 ] );
        }

        $update = [];
        if ( isset( $data['value'] ) && ! isset( $data['type'] ) && ! isset( $data['source_id'] ) ) {
            $alias_source = $this->find_alias_source_by_value( sanitize_text_field( $data['value'] ), $id );
            if ( $alias_source ) {
                $data['type'] = 'alias';
                $data['source_id'] = (int) $alias_source['id'];
            } elseif ( 'alias' === $existing['type'] ) {
                $data['type'] = 'base';
                $data['source_id'] = 0;
            }
        }

        if ( isset( $data['category_slug'] ) ) {
            $category_slug = sanitize_key( (string) $data['category_slug'] );
            if ( ! ( new VariableCategoryManager() )->get_by_slug( $category_slug ) ) {
                return new \WP_Error( 've_category_not_found', 'Selected category does not exist.', [ 'status' => 400 ] );
            }
            $update['category_slug'] = $category_slug;
        }
        if ( isset( $data['origin'] ) ) {
            $update['origin'] = sanitize_key( (string) $data['origin'] );
        }

        // Name change.
        if ( isset( $data['name'] ) ) {
            $new_name = self::normalize_name( (string) $data['name'] );
        } else {
            $new_name = $existing['name'];
        }
        if ( $new_name !== $existing['name'] ) {
            if ( ! preg_match( self::NAME_PATTERN, $new_name ) ) {
                return new \WP_Error( 've_invalid_name', 'Variable names may use lowercase letters, numbers, and hyphens.', [ 'status' => 400 ] );
            }
            $duplicate = $this->get_by_name( $new_name );
            if ( $duplicate && (int) $duplicate['id'] !== $id ) {
                return new \WP_Error( 've_duplicate', "Variable '{$new_name}' already exists.", [ 'status' => 409 ] );
            }
            $css_conflict = $this->get_css_name_conflict( $new_name, $id );
            if ( $css_conflict ) {
                return new \WP_Error(
                    've_css_name_conflict',
                    "Variable '{$new_name}' would use the same CSS custom property as '{$css_conflict['name']}'.",
                    [
                        'status'        => 409,
                        'css_name'      => $this->to_css_name( $new_name ),
                        'conflict_id'   => (int) $css_conflict['id'],
                        'conflict_name' => $css_conflict['name'],
                    ]
                );
            }
            $update['name']      = $new_name;
            $update['namespace'] = explode( '.', $update['name'] )[0];
        }

        // Type change.
        if ( isset( $data['type'] ) ) {
            $new_type = sanitize_text_field( $data['type'] );
            if ( ! in_array( $new_type, [ 'base', 'alias' ], true ) ) {
                return new \WP_Error( 've_invalid_type', 'Invalid variable type.', [ 'status' => 400 ] );
            }
            if ( $new_type !== $existing['type'] ) {
                $update['type'] = $new_type;
            }
        }

        // Source ID change.
        if ( isset( $data['source_id'] ) ) {
            $new_source_id = absint( $data['source_id'] );
            if ( $new_source_id > 0 ) {
                if ( $new_source_id === $id ) {
                    return new \WP_Error( 've_self_reference', 'A variable cannot reference itself.', [ 'status' => 400 ] );
                }
                $source_var = $this->get( $new_source_id );
                if ( ! $source_var ) {
                    return new \WP_Error( 've_invalid_source', 'Referenced source variable does not exist.', [ 'status' => 400 ] );
                }
                if ( (int) $existing['source_id'] !== $new_source_id ) {
                    $update['source_id'] = $new_source_id;
                }
            } else {
                if ( $existing['source_id'] !== null ) {
                    $update['source_id'] = null;
                }
            }
        }

        $resolved_type = isset( $update['type'] ) ? $update['type'] : $existing['type'];
        $resolved_source_id = isset( $update['source_id'] ) ? $update['source_id'] : ( $existing['source_id'] ? (int) $existing['source_id'] : null );

        if ( 'alias' === $resolved_type ) {
            if ( ! $resolved_source_id || $resolved_source_id <= 0 ) {
                return new \WP_Error( 've_invalid_source', 'Alias variables require a valid source variable.', [ 'status' => 400 ] );
            }
            $source_var = $this->get( (int) $resolved_source_id );
            if ( ! $source_var ) {
                return new \WP_Error( 've_invalid_source', 'Referenced source variable does not exist.', [ 'status' => 400 ] );
            }
            if ( (int) $resolved_source_id === $id ) {
                return new \WP_Error( 've_self_reference', 'A variable cannot reference itself.', [ 'status' => 400 ] );
            }
        } else {
            if ( isset( $update['type'] ) ) {
                $update['source_id'] = null;
                $resolved_source_id = null;
            }
        }

        // Value change.
        if ( isset( $data['value'] ) ) {
            $update['value']     = $this->normalize_value_for_name( $existing['name'], sanitize_text_field( $data['value'] ) );
            $merged              = array_merge( $existing, $update );
            if ( isset( $update['name'] ) ) {
                $update['value'] = $this->normalize_value_for_name( $update['name'], $update['value'] );
                $merged['value'] = $update['value'];
            }
        }

        // If it is an alias, force value to be empty.
        $merged = array_merge( $existing, $update );
        if ( 'alias' === $merged['type'] ) {
            $update['value'] = '';
            $merged['value'] = '';
        }

        if ( isset( $update['value'] ) || isset( $update['name'] ) || isset( $update['type'] ) || isset( $update['source_id'] ) ) {
            $update['css_value'] = $this->compile_css_value( $merged );
        }

        if ( empty( $update ) ) {
            return $existing;
        }

        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_transaction_failed', $wpdb->last_error ?: 'Could not start the variable transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;

        $updated = $wpdb->update( $table, $update, [ 'id' => $id ] );
        if ( false === $updated ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error(
                've_update_failed',
                $wpdb->last_error ?: 'Variable update failed.',
                [ 'status' => 500 ]
            );
        }

        // Handle dependency updates if type/source_id changed.
        if ( isset( $update['type'] ) || isset( $update['source_id'] ) ) {
            $dep_table = Schema::table( 'dependencies' );
            // Delete old alias relation dependencies for this child.
            $wpdb->delete( $dep_table, [ 'child_id' => $id, 'relation' => 'alias' ] );
            
            // If new type is alias, register the new parent relationship.
            if ( 'alias' === $resolved_type && $resolved_source_id > 0 ) {
                if ( ! ( new DependencyGraph() )->register( (int) $resolved_source_id, $id, 'alias' ) ) {
                    $this->rollback_if_owned( $owns_transaction );
                    return new \WP_Error( 've_dependency_failed', 'Could not register the variable dependency.', [ 'status' => 500 ] );
                }
            }
        }

        // Regenerate dependent generated variables when the value OR name changes.
        // Name changes alter generated token names/CSS names too, e.g.
        // font.space → size.space should rebuild --font-* into --size-*.
        if ( isset( $update['value'] ) || isset( $update['name'] ) ) {
            $regenerated = ( new GeneratorEngine() )->regenerate( $id, false, (string) ( $existing['value'] ?? '' ) );
            if ( is_wp_error( $regenerated ) ) {
                $this->rollback_if_owned( $owns_transaction );
                return $regenerated;
            }
        }

        // A source or generated token rename changes the CSS custom property
        // referenced by aliases. Refresh aliases inside the same transaction so
        // none can keep emitting var(--old-name).
        if ( isset( $update['name'] ) ) {
            $aliases_refreshed = $this->refresh_alias_css_values();
            if ( is_wp_error( $aliases_refreshed ) ) {
                $this->rollback_if_owned( $owns_transaction );
                return $aliases_refreshed;
            }
        }

        // Re-export CSS.
        if ( ! $defer_css_export && ! ( new CssExporter() )->export() ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_css_write_failed', 'The variable update was rolled back because the CSS file could not be written.', [ 'status' => 500 ] );
        }
        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            $this->rollback_if_owned( $owns_transaction );
            ( new CssExporter() )->export();
            return new \WP_Error( 've_commit_failed', $wpdb->last_error ?: 'Could not commit the variable update.', [ 'status' => 500 ] );
        }

        return $this->get( $id );
    }

    /* ================================================================
     *  DELETE
     * ================================================================ */
    public function delete( int $id, bool $force = false, bool $defer_css_export = false ) {
        global $wpdb;
        $table    = Schema::table( 'variables' );
        $existing = $this->get( $id );

        if ( ! $existing ) {
            return new \WP_Error( 've_not_found', 'Variable not found.', [ 'status' => 404 ] );
        }

        // Check dependents.
        $deps = ( new DependencyGraph() )->get_dependents( $id );
        if ( ! empty( $deps ) && ! $force ) {
            return new \WP_Error(
                've_has_dependents',
                'This variable has dependents. Resolve them first or pass force=true.',
                [ 'status' => 409, 'dependents' => $deps ]
            );
        }

        $dep_table = Schema::table( 'dependencies' );
        $gen_table = Schema::table( 'generators' );
        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_transaction_failed', $wpdb->last_error ?: 'Could not start the variable transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;

        // CASCADE: delete the complete dependency tree so aliases of generated
        // variables cannot survive with missing source IDs.
        $dependent_ids = $force ? $this->collect_dependent_ids( $id ) : [];
        if ( ! empty( $dependent_ids ) ) {
            $placeholders = implode( ',', array_fill( 0, count( $dependent_ids ), '%d' ) );
            if (
                false === $wpdb->query( $wpdb->prepare(
                    "DELETE FROM {$dep_table} WHERE parent_id IN ({$placeholders}) OR child_id IN ({$placeholders})",
                    array_merge( $dependent_ids, $dependent_ids )
                ) )
                || false === $wpdb->query( $wpdb->prepare(
                    "DELETE FROM {$gen_table} WHERE variable_id IN ({$placeholders})",
                    $dependent_ids
                ) )
                || false === $wpdb->query( $wpdb->prepare(
                    "DELETE FROM {$table} WHERE id IN ({$placeholders})",
                    $dependent_ids
                ) )
            ) {
                $this->rollback_if_owned( $owns_transaction );
                return new \WP_Error( 've_delete_failed', $wpdb->last_error ?: 'Could not delete the dependent variable tree.', [ 'status' => 500 ] );
            }
        }

        // Remove dependency records for this variable.
        if (
            false === $wpdb->delete( $dep_table, [ 'parent_id' => $id ] )
            || false === $wpdb->delete( $dep_table, [ 'child_id' => $id ] )
        ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_delete_failed', $wpdb->last_error ?: 'Could not remove variable dependencies.', [ 'status' => 500 ] );
        }

        // Remove generator records.
        if ( false === $wpdb->delete( $gen_table, [ 'variable_id' => $id ] ) ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_delete_failed', $wpdb->last_error ?: 'Could not remove variable generators.', [ 'status' => 500 ] );
        }

        // Delete the variable itself.
        if ( false === $wpdb->delete( $table, [ 'id' => $id ] ) ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_delete_failed', $wpdb->last_error ?: 'Could not delete the variable.', [ 'status' => 500 ] );
        }

        // Re-export CSS.
        if ( ! $defer_css_export && ! ( new CssExporter() )->export() ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_css_write_failed', 'The variable deletion was rolled back because the CSS file could not be written.', [ 'status' => 500 ] );
        }
        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            $this->rollback_if_owned( $owns_transaction );
            ( new CssExporter() )->export();
            return new \WP_Error( 've_commit_failed', $wpdb->last_error ?: 'Could not commit the variable deletion.', [ 'status' => 500 ] );
        }

        return true;
    }

    public function batch_delete( array $ids, bool $force = false ) {
        global $wpdb;
        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_transaction_failed', $wpdb->last_error ?: 'Could not start the batch transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;

        foreach ( $ids as $id ) {
            $res = $this->delete( (int) $id, $force );
            if ( is_wp_error( $res ) ) {
                $this->rollback_if_owned( $owns_transaction );
                return $res;
            }
        }

        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            $this->rollback_if_owned( $owns_transaction );
            ( new CssExporter() )->export();
            return new \WP_Error( 've_commit_failed', $wpdb->last_error ?: 'Could not commit batch variable deletion.', [ 'status' => 500 ] );
        }

        ( new CssExporter() )->export();
        return true;
    }

    public function reorder( array $ids ) {
        global $wpdb;
        $table = Schema::table( 'variables' );
        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_transaction_failed', $wpdb->last_error ?: 'Could not start reorder transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;

        foreach ( $ids as $position => $id ) {
            $updated = $wpdb->update(
                $table,
                [ 'position' => (int) $position ],
                [ 'id' => (int) $id ],
                [ '%d' ],
                [ '%d' ]
            );
            if ( false === $updated ) {
                $this->rollback_if_owned( $owns_transaction );
                return new \WP_Error( 've_reorder_failed', $wpdb->last_error ?: 'Could not update variable position.', [ 'status' => 500 ] );
            }
        }

        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            $this->rollback_if_owned( $owns_transaction );
            ( new CssExporter() )->export();
            return new \WP_Error( 've_commit_failed', $wpdb->last_error ?: 'Could not commit variable positions.', [ 'status' => 500 ] );
        }

        ( new CssExporter() )->export();
        return true;
    }

    /* ================================================================
     *  VALIDATION
     * ================================================================ */
    private function validate( array $data ) {
        // Name is required.
        if ( empty( $data['name'] ) ) {
            return new \WP_Error( 've_missing_name', 'Variable name is required.', [ 'status' => 400 ] );
        }

        $name = self::normalize_name( (string) $data['name'] );

        if ( ! preg_match( self::NAME_PATTERN, $name ) ) {
            return new \WP_Error(
                've_invalid_name',
                'Variable names may use lowercase letters, numbers, and hyphens.',
                [ 'status' => 400 ]
            );
        }

        // Check uniqueness.
        if ( $this->get_by_name( $name ) ) {
            return new \WP_Error( 've_duplicate', "Variable '{$name}' already exists.", [ 'status' => 409 ] );
        }

        $raw_value = sanitize_text_field( $data['value'] ?? '' );
        $raw_type = isset( $data['type'] ) ? $data['type'] : 'base';
        $type = in_array( $raw_type, [ 'base', 'generated', 'alias' ], true )
            ? $raw_type
            : 'base';
        $source_id = isset( $data['source_id'] ) ? absint( $data['source_id'] ) : 0;
        if ( 'base' === $type && 0 === $source_id ) {
            $alias_source = $this->find_alias_source_by_value( $raw_value );
            if ( $alias_source ) {
                $type = 'alias';
                $source_id = (int) $alias_source['id'];
            }
        }

        if ( in_array( $type, [ 'generated', 'alias' ], true ) ) {
            if ( $source_id <= 0 || ! $this->get( $source_id ) ) {
                return new \WP_Error(
                    've_invalid_source',
                    ucfirst( $type ) . ' variables require a valid source variable.',
                    [ 'status' => 400 ]
                );
            }
        }

        return [
            'name'           => $name,
            'type'           => $type,
            'value'          => 'alias' === $type ? '' : $this->normalize_value_for_name( $name, $raw_value ),
            'source_id'      => $source_id > 0 ? $source_id : null,
            'generator_type' => isset( $data['generator_type'] ) ? sanitize_text_field( $data['generator_type'] ) : null,
            'category_slug'  => $this->validated_category_slug( (string) ( $data['category_slug'] ?? 'uncategorized' ) ),
            'origin'         => sanitize_key( (string) ( $data['origin'] ?? '' ) ),
        ];
    }

    private function validated_category_slug( string $slug ): string {
        $slug = sanitize_key( $slug );
        return ( new VariableCategoryManager() )->get_by_slug( $slug ) ? $slug : 'uncategorized';
    }

    /* ================================================================
     *  CSS VALUE COMPILATION
     * ================================================================ */
    private function compile_css_value( array $var ): string {
        // For alias types, output var() reference.
        if ( 'alias' === $var['type'] && ! empty( $var['source_id'] ) ) {
            $source = $this->get( (int) $var['source_id'] );
            if ( $source ) {
                $css_name = $this->to_css_name( $source['name'] );
                return "var({$css_name})";
            }
        }

        // Fluid variables store a "fluid:min,max" marker — compile it to clamp().
        if ( FluidValue::is_fluid( (string) $var['value'] ) ) {
            return FluidValue::compile( (string) $var['value'], 'rem' );
        }

        // For base / generated, the value is used directly.
        return $var['value'];
    }



    /**
     * Numeric dimension tokens use the user's 10px rem system.
     * Example: space.20 = --space-20 = 20px = 2rem.
     * This keeps Figma FLOAT values and simple numeric inputs aligned with CSS rem output.
     */
    public function normalize_value_for_name( string $name, string $value ): string {
        if ( ! $this->is_dimension_token( $name ) ) {
            return $value;
        }

        $value = trim( $value );
        if ( $value === '' || stripos( $value, 'clamp(' ) !== false || stripos( $value, 'var(' ) !== false || FluidValue::is_fluid( $value ) ) {
            return $value;
        }

        $unit = $this->output_unit();

        // Bare number authored in px-equivalent terms (space.20 == 20px worth).
        if ( preg_match( '/^-?\d+(?:\.\d+)?$/', $value ) ) {
            return $this->apply_output_unit( (float) $value, $unit );
        }

        // Explicit px input. rem modes re-express it; px/raw honor the authored unit
        // instead of re-baking it (so Figma-pushed px and manual px survive intact).
        if ( preg_match( '/^(-?\d+(?:\.\d+)?)px$/i', $value, $m ) ) {
            if ( 'px' === $unit ) {
                return $value;
            }
            return $this->apply_output_unit( (float) $m[1], $unit );
        }

        return $value;
    }

    /**
     * Currently selected output unit for dimension tokens.
     * 'rem10' (1rem=10px, default), 'rem16' (1rem=16px), 'px', or 'raw' (no unit).
     */
    public function output_unit(): string {
        $settings = get_option( 've_settings', [] );
        $unit     = is_array( $settings ) && ! empty( $settings['output_unit'] )
            ? (string) $settings['output_unit']
            : 'rem10';
        return in_array( $unit, [ 'rem10', 'rem16', 'px', 'raw' ], true ) ? $unit : 'rem10';
    }

    /**
     * Format a px-equivalent numeric value in the selected output unit.
     */
    private function apply_output_unit( float $n, string $unit ): string {
        switch ( $unit ) {
            case 'rem16':
                return $this->trim_number( round( $n / 16, 4 ) ) . 'rem';
            case 'px':
                return $this->trim_number( round( $n, 4 ) ) . 'px';
            case 'raw':
                return $this->trim_number( round( $n, 4 ) );
            case 'rem10':
            default:
                return $this->trim_number( round( $n / 10, 4 ) ) . 'rem';
        }
    }

    /**
     * Strip trailing zeros / dangling decimal point from a number for clean CSS output.
     */
    private function trim_number( float $n ): string {
        return rtrim( rtrim( (string) $n, '0' ), '.' );
    }

    /**
     * A length token that takes an output unit. Unitless families (font-weight,
     * line-height, z-index, opacity, order, flex) and non-dimension namespaces are excluded.
     */
    private function is_dimension_token( string $name ): bool {
        // The `font` namespace holds both font-size (rem) and font-weight (a bare 100–900),
        // so gate on the family, not the namespace, or a weight of 100 becomes "1rem".
        if ( preg_match( '#(?:^|[.\-])(?:font-)?weight(?:[.\-]|$)|(?:^|[.\-])(?:line-?height|z-?index|order|opacity|flex-grow|flex-shrink)(?:[.\-]|$)#i', $name ) ) {
            return false;
        }
        $ns = explode( '.', $name )[0] ?? '';
        return in_array( $ns, [ 'space', 'radius', 'heading', 'text', 'grid', 'font', 'size' ], true );
    }

    /**
     * Parse a stored dimension value to its px-equivalent, or null if it can't be
     * cleanly reconverted (clamp/var/fluid/%/vw stay as-authored). rem is read at
     * MV's 1rem = 10px baseline — how the value actually renders on the site.
     */
    private function value_to_px( string $value ): ?float {
        $value = trim( $value );
        if ( $value === '' || stripos( $value, 'clamp(' ) !== false || stripos( $value, 'var(' ) !== false || FluidValue::is_fluid( $value ) ) {
            return null;
        }
        if ( preg_match( '/^-?\d+(?:\.\d+)?$/', $value ) ) {
            return (float) $value;
        }
        if ( preg_match( '/^(-?\d+(?:\.\d+)?)px$/i', $value, $m ) ) {
            return (float) $m[1];
        }
        if ( preg_match( '/^(-?\d+(?:\.\d+)?)rem$/i', $value, $m ) ) {
            return (float) $m[1] * 10;
        }
        if ( preg_match( '/^(-?\d+(?:\.\d+)?)em$/i', $value, $m ) ) {
            return (float) $m[1] * 16;
        }
        return null;
    }

    /**
     * Re-express every existing dimension token in $unit and adopt it as the default.
     * Non-destructive by design elsewhere; this is the explicit, user-triggered
     * "convert everything now" action. Values that can't be cleanly parsed
     * (clamp/var/fluid/%/vw) are left untouched. One CSS export at the end.
     *
     * @return int|\WP_Error Number of tokens re-expressed, or an explicit failure.
     */
    public function reconvert_units( string $unit ) {
        $unit = in_array( $unit, [ 'rem10', 'rem16', 'px', 'raw' ], true ) ? $unit : 'rem10';

        // Adopt the chosen unit as the default so newly created/edited tokens match.
        $settings = get_option( 've_settings', [] );
        if ( ! is_array( $settings ) ) {
            $settings = [];
        }
        $settings['output_unit'] = $unit;
        update_option( 've_settings', $settings );

        global $wpdb;
        $table = Schema::table( 'variables' );
        $rows  = $wpdb->get_results( "SELECT id, name, type, value FROM {$table}", ARRAY_A );
        if ( null === $rows ) {
            return new \WP_Error( 've_reconvert_read_failed', $wpdb->last_error ?: 'Could not read variables.', [ 'status' => 500 ] );
        }

        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_transaction_failed', $wpdb->last_error ?: 'Could not start the reconvert transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;

        $count = 0;
        foreach ( $rows as $row ) {
            if ( 'alias' === ( $row['type'] ?? '' ) || ! $this->is_dimension_token( (string) $row['name'] ) ) {
                continue;
            }
            $px = $this->value_to_px( (string) $row['value'] );
            if ( null === $px ) {
                continue;
            }
            $new = $this->apply_output_unit( $px, $unit );
            if ( $new === trim( (string) $row['value'] ) ) {
                continue;
            }
            // Base/generated dimension tokens compile css_value straight from value.
            $updated = $wpdb->update(
                $table,
                [ 'value' => $new, 'css_value' => $new ],
                [ 'id' => (int) $row['id'] ],
                [ '%s', '%s' ],
                [ '%d' ]
            );
            if ( false === $updated ) {
                $this->rollback_if_owned( $owns_transaction );
                return new \WP_Error( 've_reconvert_update_failed', $wpdb->last_error ?: 'Could not re-express a variable.', [ 'status' => 500 ] );
            }
            $count++;
        }

        if ( $count > 0 && ! ( new CssExporter() )->export() ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_css_write_failed', 'Variables were not changed because the generated CSS file could not be written.', [ 'status' => 500 ] );
        }
        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            $this->rollback_if_owned( $owns_transaction );
            if ( $count > 0 ) {
                ( new CssExporter() )->export();
            }
            return new \WP_Error( 've_commit_failed', $wpdb->last_error ?: 'Could not commit the reconvert.', [ 'status' => 500 ] );
        }
        return $count;
    }

    /**
     * Convert dot-notation name to CSS custom property name.
     *
     * Some namespaces are storage/category wrappers, not public token families.
     * Example: size.space should export as --space, not --size-space.
     * Generated children already use the public family name, e.g. space.20 → --space-20.
     */
    public function to_css_name( string $name ): string {
        $parts = array_values( array_filter( explode( '.', $name ), static fn( $p ) => '' !== $p ) );
        $storage_wrappers = [ 'size', 'font', 'typography' ];

        if ( count( $parts ) > 1 && in_array( $parts[0], $storage_wrappers, true ) ) {
            array_shift( $parts );
        }

        return '--' . str_replace( '.', '-', implode( '.', $parts ) );
    }

    /**
     * Extract an exact CSS custom-property reference from a static value.
     */
    public static function alias_css_name_from_value( string $value ): string {
        $value = trim( $value );
        if ( preg_match( '/^var\(\s*(--[a-z0-9.-]+)\s*\)$/i', $value, $match ) ) {
            return strtolower( $match[1] );
        }
        if ( preg_match( '/^(--[a-z0-9.-]+)$/i', $value, $match ) ) {
            return strtolower( $match[1] );
        }
        return '';
    }

    private function find_alias_source_by_value( string $value, int $exclude_id = 0 ): ?array {
        $css_name = self::alias_css_name_from_value( $value );
        if ( '' === $css_name ) {
            return null;
        }
        foreach ( $this->get_all() as $variable ) {
            if ( $exclude_id > 0 && (int) ( $variable['id'] ?? 0 ) === $exclude_id ) {
                continue;
            }
            if ( strtolower( $this->to_css_name( (string) ( $variable['name'] ?? '' ) ) ) === $css_name ) {
                return $variable;
            }
        }
        return null;
    }

    /**
     * Find another stored variable that resolves to the same public CSS name.
     */
    public function get_css_name_conflict( string $name, int $exclude_id = 0 ): ?array {
        $css_name = $this->to_css_name( $name );
        foreach ( $this->get_all() as $variable ) {
            if ( $exclude_id > 0 && (int) ( $variable['id'] ?? 0 ) === $exclude_id ) {
                continue;
            }
            if ( $this->to_css_name( (string) ( $variable['name'] ?? '' ) ) === $css_name ) {
                return $variable;
            }
        }
        return null;
    }

    private function begin_transaction_if_needed(): int {
        global $wpdb;
        $in_transaction = (int) $wpdb->get_var( 'SELECT @@in_transaction' );
        if ( $in_transaction > 0 ) {
            return 0;
        }
        return false === $wpdb->query( 'START TRANSACTION' ) ? -1 : 1;
    }

    private function rollback_if_owned( bool $owns_transaction ): void {
        global $wpdb;
        if ( $owns_transaction ) {
            $wpdb->query( 'ROLLBACK' );
        }
    }

    private function commit_if_owned( bool $owns_transaction ): bool {
        global $wpdb;
        return ! $owns_transaction || false !== $wpdb->query( 'COMMIT' );
    }

    private function collect_dependent_ids( int $root_id ): array {
        global $wpdb;
        $table = Schema::table( 'dependencies' );
        $seen = [ $root_id => true ];
        $queue = [ $root_id ];
        $dependents = [];

        while ( ! empty( $queue ) ) {
            $parent_id = array_shift( $queue );
            $child_ids = $wpdb->get_col( $wpdb->prepare(
                "SELECT child_id FROM {$table} WHERE parent_id = %d",
                $parent_id
            ) ) ?: [];

            foreach ( $child_ids as $child_id ) {
                $child_id = (int) $child_id;
                if ( $child_id <= 0 || isset( $seen[ $child_id ] ) ) {
                    continue;
                }
                $seen[ $child_id ] = true;
                $dependents[] = $child_id;
                $queue[] = $child_id;
            }
        }

        return $dependents;
    }

    private function refresh_alias_css_values() {
        global $wpdb;
        $table = Schema::table( 'variables' );
        $aliases = $wpdb->get_results(
            "SELECT * FROM {$table} WHERE type = 'alias' ORDER BY id ASC",
            ARRAY_A
        );
        if ( null === $aliases ) {
            return new \WP_Error( 've_alias_refresh_failed', $wpdb->last_error ?: 'Could not read alias variables after the rename.', [ 'status' => 500 ] );
        }

        foreach ( $aliases as $alias ) {
            $source_id = (int) ( $alias['source_id'] ?? 0 );
            $source = $source_id > 0 ? $this->get( $source_id ) : null;
            if ( ! $source ) {
                continue;
            }
            $css_value = 'var(' . $this->to_css_name( (string) $source['name'] ) . ')';
            if ( $css_value === (string) ( $alias['css_value'] ?? '' ) ) {
                continue;
            }
            $updated = $wpdb->update(
                $table,
                [ 'css_value' => $css_value ],
                [ 'id' => (int) $alias['id'] ],
                [ '%s' ],
                [ '%d' ]
            );
            if ( false === $updated ) {
                return new \WP_Error( 've_alias_refresh_failed', $wpdb->last_error ?: 'Could not refresh an alias after the source rename.', [ 'status' => 500 ] );
            }
        }

        return true;
    }
}
