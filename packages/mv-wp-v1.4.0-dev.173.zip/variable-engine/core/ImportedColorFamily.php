<?php

namespace VE\Core;

/**
 * A colour family MV did not generate itself - Advanced Themer's shades,
 * tints and transparencies, brought in by an import - follows its base.
 *
 * MV has no generator for these, so nothing used to rebuild them: change
 * color-primary (in MV, or in Bricks and pulled in) and its 24 children kept
 * the old colour. Rebuilding them with MV's own generator would replace the
 * importer's steps with MV's, so instead each child keeps its place:
 *
 *   darker than the base   keeps how far it sits between the base and black
 *   lighter than the base  keeps how far it sits between the base and white
 *   the base's own shade   (a transparency) keeps its transparency
 *
 * and takes the new base's hue and saturation. Worked in HSL, which is how
 * these families are built (one hue and saturation, lightness stepped).
 *
 * A child whose hue is far from the family's is not a shade, and is left alone.
 * Pure: values in, values out.
 */
class ImportedColorFamily {

    /** A child more than this many degrees from the base's hue is not a shade of it. */
    private const HUE_TOLERANCE = 12.0;

    /**
     * @param string      $new_base  The base's value now.
     * @param string|null $old_base  The base's value before the change, when known.
     * @param array       $children  id => [ 'name' => string, 'value' => string ]
     * @return array id => new value, for the children that follow. Empty when
     *               the base or the family is not colour.
     */
    public static function rebase( string $new_base, ?string $old_base, array $children ): array {
        $to = self::parse( $new_base );
        if ( ! $to || ! $children ) {
            return [];
        }
        $kids = [];
        foreach ( $children as $id => $child ) {
            $hsl = self::parse( (string) ( $child['value'] ?? '' ) );
            if ( $hsl ) {
                $kids[ $id ] = [ 'name' => (string) ( $child['name'] ?? '' ), 'hsl' => $hsl ];
            }
        }
        if ( ! $kids ) {
            return [];
        }

        // What the family was built from. The old value only counts if the
        // family was built from it - if the base had already moved without
        // the family following, the family itself says where it was.
        $from = null !== $old_base ? self::parse( $old_base ) : null;
        if ( ! $from || ! self::family_matches( $from, $kids ) ) {
            $from = self::infer_base( $kids );
        }
        if ( ! $from ) {
            return [];
        }

        $out = [];
        foreach ( $kids as $id => $kid ) {
            $c = $kid['hsl'];
            if ( $c['s'] > 5 && $from['s'] > 5 && self::hue_gap( $c['h'], $from['h'] ) > self::HUE_TOLERANCE ) {
                continue;
            }
            if ( $c['l'] < $from['l'] - 0.25 && $from['l'] > 0 ) {
                $l = $to['l'] * ( $c['l'] / $from['l'] );
            } elseif ( $c['l'] > $from['l'] + 0.25 && $from['l'] < 100 ) {
                $l = $to['l'] + ( 100 - $to['l'] ) * ( ( $c['l'] - $from['l'] ) / ( 100 - $from['l'] ) );
            } else {
                $l = $to['l'];
            }
            $s = $from['s'] > 0 ? min( 100, $to['s'] * ( $c['s'] / $from['s'] ) ) : $to['s'];
            $a = $from['a'] > 0 ? $c['a'] * ( $to['a'] / $from['a'] ) : $c['a'];
            $value = self::format( $to['h'], $s, $l, $a );
            if ( $value !== trim( (string) $children[ $id ]['value'] ) ) {
                $out[ $id ] = $value;
            }
        }
        return $out;
    }

    /** Does this family look built from this base: same hue, where hue means anything? */
    private static function family_matches( array $base, array $kids ): bool {
        foreach ( $kids as $kid ) {
            $c = $kid['hsl'];
            if ( $c['s'] > 5 && $base['s'] > 5 ) {
                return self::hue_gap( $c['h'], $base['h'] ) <= self::HUE_TOLERANCE;
            }
        }
        return true;
    }

    /**
     * The base a family was built from, read off the family: a transparency is
     * the base itself at less than full opacity; otherwise the base sits between
     * the lightest of the darker steps and the darkest of the lighter ones.
     */
    private static function infer_base( array $kids ): ?array {
        foreach ( $kids as $kid ) {
            if ( $kid['hsl']['a'] < 1 && 1 === preg_match( '/[.\-]t[.\-]\d+$/i', $kid['name'] ) ) {
                return [ 'h' => $kid['hsl']['h'], 's' => $kid['hsl']['s'], 'l' => $kid['hsl']['l'], 'a' => 1.0 ];
            }
        }
        $dark = null;
        $light = null;
        foreach ( $kids as $kid ) {
            if ( 1 === preg_match( '/[.\-]d[.\-]\d+$/i', $kid['name'] ) ) {
                if ( ! $dark || $kid['hsl']['l'] > $dark['l'] ) { $dark = $kid['hsl']; }
            } elseif ( 1 === preg_match( '/[.\-]l[.\-]\d+$/i', $kid['name'] ) ) {
                if ( ! $light || $kid['hsl']['l'] < $light['l'] ) { $light = $kid['hsl']; }
            }
        }
        if ( ! $dark || ! $light ) {
            return null;
        }
        return [ 'h' => $light['h'], 's' => $light['s'], 'l' => ( $dark['l'] + $light['l'] ) / 2, 'a' => 1.0 ];
    }

    private static function hue_gap( float $a, float $b ): float {
        $d = fmod( abs( $a - $b ), 360.0 );
        return $d > 180 ? 360 - $d : $d;
    }

    private static function format( float $h, float $s, float $l, float $a ): string {
        $n = static function ( float $v ): string {
            $v = round( $v, 2 );
            return rtrim( rtrim( number_format( $v, 2, '.', '' ), '0' ), '.' );
        };
        $h = fmod( $h + 360.0, 360.0 );
        return 'hsla(' . $n( $h ) . ',' . $n( max( 0, min( 100, $s ) ) ) . '%,' . $n( max( 0, min( 100, $l ) ) ) . '%,' . $n( max( 0, min( 1, $a ) ) ) . ')';
    }

    /**
     * Any colour MV stores - hex, rgb(), hsl(), oklch(), with or without
     * transparency - as [ h 0-360, s 0-100, l 0-100, a 0-1 ]. Null if not a colour.
     */
    public static function parse( string $value ): ?array {
        $v = strtolower( trim( $value ) );
        if ( 1 === preg_match( '/^#([0-9a-f]{3,4}|[0-9a-f]{6}|[0-9a-f]{8})$/', $v, $m ) ) {
            $hex = $m[1];
            if ( strlen( $hex ) <= 4 ) {
                $hex = preg_replace( '/(.)/', '$1$1', $hex );
            }
            $a = strlen( $hex ) === 8 ? hexdec( substr( $hex, 6, 2 ) ) / 255 : 1.0;
            return self::rgb_to_hsl( hexdec( substr( $hex, 0, 2 ) ), hexdec( substr( $hex, 2, 2 ) ), hexdec( substr( $hex, 4, 2 ) ), $a );
        }
        if ( 1 !== preg_match( '/^(rgba?|hsla?|oklch)\(\s*([^)]*)\)$/', $v, $m ) ) {
            return null;
        }
        $parts = preg_split( '/\s*[,\/]\s*|\s+/', trim( $m[2] ) );
        if ( count( $parts ) < 3 ) {
            return null;
        }
        $num = static function ( string $p, float $pct_scale ): ?float {
            if ( 1 !== preg_match( '/^(-?[\d.]+)(%|deg)?$/', $p, $x ) ) {
                return null;
            }
            $f = (float) $x[1];
            return ( $x[2] ?? '' ) === '%' ? $f * $pct_scale / 100 : $f;
        };
        $a = isset( $parts[3] ) ? $num( $parts[3], 1 ) : 1.0;
        if ( null === $a ) {
            return null;
        }
        $a = max( 0.0, min( 1.0, $a ) );
        if ( 'oklch' === $m[1] ) {
            $l = $num( $parts[0], 1 );
            $c = $num( $parts[1], 0.4 );
            $h = $num( $parts[2], 360 );
            if ( null === $l || null === $c || null === $h ) {
                return null;
            }
            $rgb = self::oklch_to_rgb( $l, $c, $h );
            return self::rgb_to_hsl( $rgb[0], $rgb[1], $rgb[2], $a );
        }
        if ( 'h' === $m[1][0] ) {
            $h = $num( $parts[0], 360 );
            $s = $num( str_replace( '%', '', $parts[1] ), 100 );
            $l = $num( str_replace( '%', '', $parts[2] ), 100 );
            if ( null === $h || null === $s || null === $l ) {
                return null;
            }
            return [ 'h' => fmod( $h + 360.0, 360.0 ), 's' => $s, 'l' => $l, 'a' => $a ];
        }
        $r = $num( $parts[0], 255 );
        $g = $num( $parts[1], 255 );
        $b = $num( $parts[2], 255 );
        if ( null === $r || null === $g || null === $b ) {
            return null;
        }
        return self::rgb_to_hsl( $r, $g, $b, $a );
    }

    /** @return float[] r, g, b in 0-255, clipped to what a screen shows. */
    private static function oklch_to_rgb( float $L, float $C, float $H ): array {
        $a  = $C * cos( deg2rad( $H ) );
        $b  = $C * sin( deg2rad( $H ) );
        $l_ = pow( $L + 0.3963377774 * $a + 0.2158037573 * $b, 3 );
        $m_ = pow( $L - 0.1055613458 * $a - 0.0638541728 * $b, 3 );
        $s_ = pow( $L - 0.0894841775 * $a - 1.2914855480 * $b, 3 );
        $lin = [
            4.0767416621 * $l_ - 3.3077115913 * $m_ + 0.2309699292 * $s_,
            -1.2684380046 * $l_ + 2.6097574011 * $m_ - 0.3413193965 * $s_,
            -0.0041960863 * $l_ - 0.7034186147 * $m_ + 1.7076147010 * $s_,
        ];
        $out = [];
        foreach ( $lin as $x ) {
            $x     = max( 0.0, min( 1.0, $x ) );
            $srgb  = $x <= 0.0031308 ? 12.92 * $x : 1.055 * pow( $x, 1 / 2.4 ) - 0.055;
            $out[] = $srgb * 255;
        }
        return $out;
    }

    private static function rgb_to_hsl( float $r, float $g, float $b, float $a ): array {
        $r /= 255; $g /= 255; $b /= 255;
        $max = max( $r, $g, $b );
        $min = min( $r, $g, $b );
        $l   = ( $max + $min ) / 2;
        $h   = 0.0;
        $s   = 0.0;
        $d   = $max - $min;
        if ( $d > 0.00001 ) {
            $s = $d / ( 1 - abs( 2 * $l - 1 ) );
            if ( $max === $r ) {
                $h = 60 * fmod( ( $g - $b ) / $d, 6 );
            } elseif ( $max === $g ) {
                $h = 60 * ( ( $b - $r ) / $d + 2 );
            } else {
                $h = 60 * ( ( $r - $g ) / $d + 4 );
            }
        }
        return [ 'h' => fmod( $h + 360.0, 360.0 ), 's' => min( 100.0, $s * 100 ), 'l' => $l * 100, 'a' => $a ];
    }
}
