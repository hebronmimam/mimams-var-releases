<?php
/**
 * C143 / C144 — MV's own variables, inside a workspace, do not reach the site.
 *
 * "the changed value of the variable was made in the workspace copy and it
 *  still leaked into the front end live site."  /  "actually I did change the
 *  variable via mv."
 *
 * dev.160 made the builder start a workspace session, and with a session running
 * Bricks' own global variables are held by the workspace - measured. MV's own
 * variables are not. They live in MV's table and are written out to
 * `variables.css`, a file every visitor is served, and no workspace family covers
 * either. Measured on a real site with the session running: a variable changed
 * through MV's Variables panel was in the file a logged-out request received.
 *
 * The proper answer is for a workspace to hold MV's variables the way it holds
 * Bricks' - reads answered from the workspace, the stylesheet kept out of the
 * live file, publish applying them. That is a slice of its own. The tempting
 * shortcut - route MV's edits only into Bricks' copy, which IS held - is wrong:
 * MV's table would keep the old value, and the next ordinary MV save re-mirrors
 * every MV variable into Bricks and would silently put the old value back over
 * a change that had been published.
 *
 * So until that slice, the only honest behaviour is to refuse: inside a
 * workspace, a write to MV's variable store is not made, and the person is told
 * why and what to do instead. A leak into the live site is the failure §85 exists
 * to prevent; a refused edit with a reason is an inconvenience.
 *
 * Refused at REST dispatch rather than inside the managers, because six manager
 * classes write that store and a route is the one thing all of them are reached
 * through. `check-workspace-holds-mv-variables.php` classifies every route family
 * the plugin registers, so a new one cannot slip past unconsidered.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceVariableHold {

    public const NS = '/variable-engine/v1/';

    /**
     * Route families whose writes change MV's variable store - the table, or the
     * `variables.css` built from it.
     */
    public const HELD = [
        'variables',
        'variable-categories',
        'variable-families',
        'palettes',
        'color-palettes',
        'themes',
        'generators',
        'migration',
        'settings-transfer',
    ];

    /**
     * Inside `sync`, only these write variables. Previews, exports, drift
     * reports and Figma pairing read them or touch something else entirely.
     */
    public const HELD_SYNC = [
        'apply',
        'apply-bundle',
        'rollback/',
        'drift/apply',
        'drift/complete',
    ];

    public static function register(): void {
        add_filter( 'rest_pre_dispatch', [ self::class, 'hold' ], 10, 3 );
    }

    /**
     * Whether this request would write MV's variable store inside a workspace.
     *
     * Pure, so a guard can walk every family rather than the one a test sets up.
     */
    public static function should_hold( string $method, string $route, int $session ): bool {
        if ( $session <= 0 ) {
            return false;
        }
        if ( in_array( strtoupper( $method ), [ 'GET', 'HEAD', 'OPTIONS' ], true ) ) {
            return false;
        }
        if ( 0 !== strpos( $route, self::NS ) ) {
            return false;
        }
        $rest   = substr( $route, strlen( self::NS ) );
        $family = strtok( $rest, '/' );
        if ( in_array( $family, self::HELD, true ) ) {
            return true;
        }
        if ( 'sync' === $family ) {
            $sub = (string) substr( $rest, strlen( 'sync/' ) );
            foreach ( self::HELD_SYNC as $prefix ) {
                if ( $sub === rtrim( $prefix, '/' ) || 0 === strpos( $sub, $prefix ) ) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * @param mixed            $result
     * @param \WP_REST_Server  $server
     * @param \WP_REST_Request $request
     * @return mixed
     */
    public static function hold( $result, $server, $request ) {
        if ( null !== $result || ! is_object( $request ) ) {
            return $result;
        }
        $session = WorkspaceRuntime::session_id();
        if ( ! self::should_hold( (string) $request->get_method(), (string) $request->get_route(), $session ) ) {
            return $result;
        }
        $workspace = WorkspaceStore::get( $session );
        $name      = is_array( $workspace ) && ! empty( $workspace['name'] ) ? (string) $workspace['name'] : 'this workspace';

        return new \WP_Error(
            've_workspace_holds_no_mv_variables',
            sprintf(
                /* translators: %s: workspace name */
                'Not saved - it would have changed the live site. You are working inside “%s”, and MV’s own variables cannot be held in a workspace yet. Change it in Bricks’ Variables panel, which the workspace does hold, or open a live page to change it here.',
                $name
            ),
            [ 'status' => 409, 'workspace' => $session ]
        );
    }
}
