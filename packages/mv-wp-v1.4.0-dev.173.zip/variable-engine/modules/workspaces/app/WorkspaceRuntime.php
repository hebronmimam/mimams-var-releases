<?php
/**
 * Slice 7 — the first runtime family: Bricks variables.
 *
 * Slices 1–6 isolated STRUCTURAL objects: a page becomes a private shadow post,
 * and WordPress keeps a draft out of public queries without any help from MV.
 * That isolation survives MV being switched off, which is why §100.1.a could be
 * claimed plainly.
 *
 * A runtime family has no post to hide in. `bricks_global_variables` is one site
 * option that every request reads, so isolating it means answering that read
 * differently depending on who is asking. That is a weaker kind of isolation and
 * the wording matters: **isolation while MV runs**. Switch MV off and every
 * request sees the live option again, which is the honest behaviour and is what
 * §109.1 permits this slice to claim — no more.
 *
 * ── What the object-cache test settled (2026-09-16) ──────────────────────────
 *
 * Running WordPress's own option.php proved the read path is safe:
 * `get_option()` returns on `pre_option_{$option}` BEFORE it touches
 * `wp_load_alloptions()` or any `wp_cache_*`. An overlaid value therefore never
 * enters a persistent object cache, never enters `alloptions`, and a public
 * request reads the live row. See `scripts/check-workspace-object-cache.php`.
 *
 * The same test found the leak that is NOT obvious, and this class exists as
 * much for it as for the overlay: `update_option()` takes its old value THROUGH
 * `get_option()`, and therefore through the overlay. So a write during a
 * workspace session is compared against the workspace value rather than the live
 * one, and when they differ core writes it to the real row and caches it for
 * every visitor. `pre_update_option_*` is not tidiness. It is the only thing
 * standing between a workspace session and a real write.
 *
 * ── Why registration is early and resolution is late ─────────────────────────
 *
 * From core's own wp-settings.php: pluggable.php loads at line 623,
 * `plugins_loaded` fires at 641, `init` at 790. So the filters can be registered
 * on `plugins_loaded` — early enough to precede Bricks constructing its
 * `Database` and caching globals into a static, which a later filter could never
 * reach.
 *
 * But WHO is asking cannot be answered that early without deciding the current
 * user before other plugins have had their say on `determine_current_user`. So
 * registration is early and resolution is lazy: before `init`, this class
 * answers "no session", and a request that cannot know who it is serves LIVE.
 * Every uncertainty in here falls the same way. A workspace value reaching a
 * visitor is the failure §85 exists to prevent; an editor seeing the live value
 * for one early read is an inconvenience.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceRuntime {

    /** Kept as a name because the rest of MV refers to it. */
    public const FAMILY_VARIABLES = 'bricks_global_variables';

    /**
     * SLICE 9 — every global the builder's Save writes that carries design
     * state, plus the two stamps Bricks' own conflict model reads.
     *
     * Taken from the save path in Bricks' `Ajax::save_post()` rather than from
     * a list somebody wrote down: each of these is an `update_option()` in that
     * one request, which is why they all leak together or not at all.
     *
     * The two stamps at the end are not design state. They are overlaid anyway,
     * and that is the point of §100's "made consistent rather than fought":
     * Bricks compares `bricks_global_classes` against
     * `bricks_global_classes_timestamp` to decide whether another user has
     * changed classes since the builder loaded. Overlay the classes and not the
     * stamp and the builder compares a workspace value against a live clock —
     * it would raise a conflict over the editor's own unsaved work. Overlay
     * both and the whole model is internally consistent inside the workspace,
     * and still fires correctly for a second session in the SAME workspace.
     */
    private const FAMILIES = [
        // classes
        'bricks_global_classes',
        'bricks_global_classes_categories',
        'bricks_global_classes_locked',
        'bricks_global_classes_trash',
        // variables (slice 7 covered the first of these three)
        'bricks_global_variables',
        'bricks_global_variables_categories',
        /* Bricks 2.4 gave variables a trash, the way classes have had one.
           `Ajax::save_post()` writes it through
           `Helpers::save_global_variables_array_option()`, which is
           update_option() on a single site - so the overlay catches it - but it
           was not on this list, and a variable trashed inside a workspace put
           the trash on the live site. Found by diffing 2.4 against the 2.1.4
           this module was built on. */
        'bricks_global_variables_trash',
        // the rest of the design state
        'bricks_theme_styles',
        'bricks_components',
        'bricks_global_elements',
        'bricks_color_palette',
        'bricks_style_manager',
        'bricks_global_queries',
        'bricks_global_queries_categories',
        'bricks_global_pseudo_classes',
        // the stamps
        'bricks_global_classes_timestamp',
        'bricks_global_classes_user',
    ];

    /** The stamps: overlaid so Bricks stays consistent, not watched for drift. */
    private const STAMPS = [
        'bricks_global_classes_timestamp',
        'bricks_global_classes_user',
    ];

    /** Everything the overlay answers for. */
    public static function families(): array {
        return self::FAMILIES;
    }

    /**
     * The subset slice 8 fingerprints.
     *
     * The stamps are left out deliberately. They change every time anybody
     * saves classes anywhere, so watching them would log drift for a fact
     * ABOUT the data rather than a change to it — noise that would bury the
     * one event somebody needs to read.
     */
    public static function watched_families(): array {
        return array_values( array_diff( self::FAMILIES, self::STAMPS ) );
    }

    public static function covers( string $option ): bool {
        return in_array( $option, self::FAMILIES, true );
    }

    /**
     * What is NOT here, said out loud rather than left to be noticed:
     *
     * - Builder preferences. Per-user convenience, not design state.
     *   Bricks 2.4 folded `bricks_panel_width` and `bricks_structure_width`
     *   into `bricks_builder_ui_preferences` and added
     *   `bricks_builder_ui_profiles`; none of them belong here, and the names
     *   are written down so the next person diffing a Bricks release can see
     *   this was considered rather than missed.
     * - Icon sets and custom icons. The builder does write them, but the SVG
     *   files they point at are shared uploads — isolating the list while the
     *   files are common would isolate the option and not the site, which is
     *   the same argument §109.1 makes about file-mode CSS.
     * - `bricks_global_settings` and breakpoints. Not written by the builder's
     *   Save at all; they belong to the settings screen. Overlaying settings
     *   would also overlay the `cssLoading` mode that decides what slice 10 does.
     * - Custom fonts. `bricks_font_face_rules` IS written by the save path - a
     *   regenerated cache of the @font-face CSS - but the woff files it points
     *   at are shared uploads, so holding the rules while the files are common
     *   isolates the option and not the site. Same as icons.
     */

    /** Where a user's current workspace is remembered. */
    public const SESSION_META = '_ve_workspace_session';

    /** @var int|null Resolved session, per request. Null means "not yet". */
    private static $session = null;

    /** @var bool Re-entrancy: our own reads must not come back through us. */
    private static $resolving = false;

    /** @var bool|null Cached per request. */
    private static $inline_mode = null;

    /** @var array<string,array> Slice 9. Values caught on their way out. */
    private static $deleting = [];

    /** Slice 8. Hashes of Live writes MV was present for. */
    public const WITNESS_KEY = 've_ws_witnessed';

    /** How many recent Live writes are remembered per family. */
    private const WITNESS_KEEP = 20;

    public static function register(): void {
        foreach ( self::FAMILIES as $family ) {
            /* Three args on the read and the write, because core passes the
               option name and that is how one pair of callbacks serves the
               whole list instead of sixteen near-identical closures. */
            add_filter( 'pre_option_' . $family, [ self::class, 'read_overlay' ], 10, 3 );
            add_filter( 'pre_update_option_' . $family, [ self::class, 'hold_write' ], 10, 3 );

            /* And the hole slice 7 did not have to face, because variables are
               never deleted. Bricks' `save_global_classes_in_db()` calls
               `delete_option( bricks_global_classes )` when the last class is
               removed — and core's `delete_option()` has NO short-circuit
               filter. There is no `pre_delete_option`. So the delete cannot be
               held; it can only be undone, in the same request, before anything
               else reads the row. `delete_option_{$option}` fires after a
               successful delete and is the place to do it. */
            add_action( 'delete_option_' . $family, [ self::class, 'undo_delete' ], 10, 1 );
        }

        // Registered once, not per family: core's generic before-delete action
        // is where the value is still readable.
        add_action( 'delete_option', [ self::class, 'note_delete' ], 10, 1 );

        /* Priority 0: before anything else at init can read Bricks' copy. */
        add_action( 'init', [ self::class, 'refresh_bricks_globals' ], 0, 0 );

        /* Priority 0: before Bricks' own handler, which exits when it is done. */
        add_action( 'wp_ajax_bricks_save_post', [ self::class, 'hold_emptied_families' ], 0, 0 );
    }

    /**
     * The builder's Save field for each family it DELETES when emptied, as
     * `Ajax::save_post()` reads them. Only fields whose posted value IS the
     * stored value: the variables trash is merged server-side, so an empty
     * post there does not mean an empty option, and it is left out.
     */
    private const EMPTIED_BY = [
        'globalClasses'             => 'bricks_global_classes',
        'globalClassesLocked'       => 'bricks_global_classes_locked',
        'globalClassesCategories'   => 'bricks_global_classes_categories',
        'globalVariables'           => 'bricks_global_variables',
        'globalVariablesCategories' => 'bricks_global_variables_categories',
        'themeStyles'               => 'bricks_theme_styles',
        'components'                => 'bricks_components',
        'globalElements'            => 'bricks_global_elements',
        'colorPalette'              => 'bricks_color_palette',
        'styleManager'              => 'bricks_style_manager',
        'globalQueries'             => 'bricks_global_queries',
        'globalQueriesCategories'   => 'bricks_global_queries_categories',
        'pseudoClasses'             => 'bricks_global_pseudo_classes',
    ];

    /**
     * C146, found on test7 2026-09-23: on a site with no live global classes,
     * deleting the last class inside a workspace did not stick - the workspace
     * went on showing it.
     *
     * Bricks empties a family with `delete_option()`, and the delete path above
     * (note_delete / undo_delete) hangs on `delete_option` and
     * `delete_option_{$option}`. Core fires neither when there is no row to
     * delete: it looks the row up first and returns false in silence. So when
     * Live has never had that option, nothing tells the workspace the list was
     * emptied, and its old payload goes on being served.
     *
     * There is no hook left in core to catch it, so this reads the intent where
     * it is stated - Bricks' Save request - and records the empty list before
     * Bricks runs. Only when Live has no row: when it has one, the delete path
     * handles it and records the same empty value. Bricks' own nonce is checked
     * first, so a forged request cannot empty somebody's workspace.
     */
    public static function hold_emptied_families(): void {
        $workspace_id = self::session_id();
        if ( $workspace_id <= 0 ) {
            return;
        }
        if ( ! function_exists( 'check_ajax_referer' ) || ! check_ajax_referer( 'bricks-nonce-builder', 'nonce', false ) ) {
            return;
        }
        foreach ( self::EMPTIED_BY as $field => $option ) {
            if ( ! isset( $_POST[ $field ] ) || ! self::covers( $option ) ) {
                continue;
            }
            $posted = json_decode( stripslashes( (string) $_POST[ $field ] ), true );
            if ( [] !== $posted ) {
                continue;
            }
            if ( null !== self::live_row_autoload( $option ) ) {
                continue;                   // a row exists, so the delete path will see it
            }
            self::set_payload( $workspace_id, $option, [] );
        }
    }

    /**
     * Whether Live has a row for this option at all - the same lookup core's
     * delete_option() makes, so the two cannot disagree about "no row".
     *
     * @return string|null The row's autoload value, or null when there is no row.
     */
    private static function live_row_autoload( string $option ) {
        global $wpdb;
        if ( ! isset( $wpdb ) || ! is_object( $wpdb ) ) {
            return null;
        }
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT autoload FROM {$wpdb->options} WHERE option_name = %s", $option ) );
        return is_object( $row ) ? (string) ( $row->autoload ?? '' ) : null;
    }

    /**
     * Bricks reads every design global ONCE, while the theme loads - `new
     * Database()` in `Bricks\Init`, which runs from functions.php - and keeps
     * them in `Database::$global_data`. That is before `init`, and before init
     * this class cannot know who is asking (see session_id()), so the overlay
     * stands aside and Bricks caches LIVE.
     *
     * The builder is filled from that cache (`Builder::builder_data()`), so a
     * workspace page opened in Bricks showed the live classes, variables and
     * palette. Measured on a real site: a variable changed inside a workspace
     * was held correctly, the live site kept its value - and on reload the
     * builder showed the live value again. The next save from that builder
     * would then have written the live value back over the workspace's own.
     *
     * Every guard read the overlay after init with get_option(), so all of them
     * passed. The fault was never in the overlay; it was in when Bricks asked.
     *
     * So once the session is knowable, Bricks is asked again, and this time the
     * overlay answers. Its SETTINGS are put back exactly as they were: they are
     * not a workspace family, and other code may have adjusted them since the
     * theme loaded. Outside a session nothing is re-read - a visitor never gets
     * here.
     */
    public static function refresh_bricks_globals(): void {
        if ( self::session_id() <= 0 ) {
            return;
        }
        $db = '\\Bricks\\Database';
        if ( ! class_exists( $db ) || ! method_exists( $db, 'get_global_data' ) ) {
            return;
        }
        $settings     = $db::$global_settings;
        $has_row      = is_array( $db::$global_data ) && array_key_exists( 'settings', $db::$global_data );
        $settings_row = $has_row ? $db::$global_data['settings'] : null;

        $db::get_global_data();

        $db::$global_settings = $settings;
        if ( $has_row ) {
            $db::$global_data['settings'] = $settings_row;
        }
    }

    /**
     * The workspace this request is working inside, or 0.
     *
     * Not cached before `init`: the answer there is "cannot know", which is a
     * different thing from "none", and caching it would make the rest of the
     * request wrong.
     */
    public static function session_id(): int {
        if ( null !== self::$session ) {
            return self::$session;
        }
        if ( ! did_action( 'init' ) ) {
            return 0;
        }
        if ( ! function_exists( 'get_current_user_id' ) ) {
            return 0;
        }

        $user_id = (int) get_current_user_id();
        if ( $user_id <= 0 ) {
            // A logged-out visitor is never inside a workspace. This is §85.
            self::$session = 0;
            return 0;
        }

        $id = (int) get_user_meta( $user_id, self::SESSION_META, true );
        if ( $id <= 0 ) {
            self::$session = 0;
            return 0;
        }

        /* A session pointing at a workspace that has been discarded, archived or
           published is not a session. Checked every request rather than trusted,
           because the meta outlives the workspace. */
        $workspace = class_exists( __NAMESPACE__ . '\WorkspaceStore' ) ? WorkspaceStore::get( $id ) : null;
        $open      = is_array( $workspace ) && in_array( (string) ( $workspace['status'] ?? '' ), [ 'open', 'active', 'draft' ], true );

        self::$session = $open ? $id : 0;
        return self::$session;
    }

    /** Somebody opened a workspace. */
    public static function begin_session( int $user_id, int $workspace_id ): bool {
        if ( $user_id <= 0 || $workspace_id <= 0 ) {
            return false;
        }
        self::$session = null;
        $ok = (bool) update_user_meta( $user_id, self::SESSION_META, $workspace_id );

        /* §100.1.1. Live is written down at the moment the session opens, and
           this is the only moment it can be: after this the overlay is answering
           for the family, and a later reading would record the workspace's own
           value as the base it is supposed to be measured against. */
        if ( $ok && class_exists( __NAMESPACE__ . '\\WorkspaceFingerprint' ) ) {
            WorkspaceFingerprint::record( $workspace_id );
        }

        /* Slice 10. In file mode the workspace needs its own copy of the shared
           stylesheets before anything reads them, or the editor's first look at
           their workspace is a page with no global CSS at all. */
        if ( $ok && class_exists( __NAMESPACE__ . '\\WorkspaceCss' ) && WorkspaceCss::file_mode() ) {
            WorkspaceCss::seed( $workspace_id );
        }

        return $ok;
    }

    /** …and closed it. */
    public static function end_session( int $user_id ): bool {
        if ( $user_id <= 0 ) {
            return false;
        }
        self::$session = null;
        return (bool) delete_user_meta( $user_id, self::SESSION_META );
    }

    /**
     * §109.1 — and slice 10 is where this stopped meaning "inline only".
     *
     * Slices 7 to 9 returned false in file CSS mode, on the reasoning that
     * Bricks writes the globals into shared .css files on save, so overlaying
     * the option would isolate the option and not the site.
     *
     * Reading `includes/assets/` settled that it is not what this Bricks does.
     * Every shared-file generator is hooked on `add_option_{$option}` /
     * `update_option_{$option}`, and a held write fires neither — core applies
     * `pre_update_option_*` before its own equality check and returns early. So
     * the overlay never put a workspace value into a shared file; it stopped the
     * files being written at all, which left the EDITOR looking at Live's
     * styling inside their own workspace.
     *
     * `WorkspaceCss` fixes that by pointing Bricks' own `Assets::$css_dir` at a
     * per-workspace directory for the length of the session, so the overlay can
     * run in both modes and this now answers the only question it was ever
     * really asking: is the module switched on.
     */
    public static function enabled(): bool {
        return true;
    }

    /**
     * Bricks 2.4's Abilities API, which the overlay cannot see behind.
     *
     * `includes/abilities/design-option-store.php` reads and writes the design
     * options with raw `$wpdb` SQL - deliberately, and commented as such: "An
     * exact uncached before-image is required for compare-and-swap." It calls
     * neither `get_option()` nor `update_option()`, so `pre_option_*` and
     * `pre_update_option_*` never fire and MV is not in the path at all.
     *
     * It is opt-in and off by default - `Bricks\Init` only constructs
     * `Abilities\Manager` when `Database::$global_settings['abilitiesApi']` is
     * set - so an ordinary builder save is unaffected and slices 7-10 hold.
     *
     * With it ON, a workspace is not partially isolated for those families; it
     * is not isolated at all, and a design change made through that API goes
     * straight to the live site. §85.1 forbids claiming safety that is not
     * there, so this is reported rather than papered over: the module says so
     * and the UI has something true to print.
     *
     * Deliberately NOT standing the overlay down when this is on. The API is
     * one way into the design options and the builder is another; switching off
     * the protection that still works, because a second door exists, would make
     * every ordinary save leak as well.
     */
    public static function abilities_api_on(): bool {
        $settings = self::without_overlay( static function () {
            return get_option( 'bricks_global_settings', [] );
        } );
        $settings = is_array( $settings ) ? $settings : [];

        return ! empty( $settings['abilitiesApi'] );
    }

    /**
     * Whether the overlay can be trusted to see every write to a family.
     *
     * The one question the UI should ask before printing the word "isolated".
     */
    public static function isolation_is_complete(): bool {
        return ! self::abilities_api_on();
    }

    /**
     * Whether Bricks is generating CSS inline rather than from files.
     *
     * Kept as its own question because slice 10 needs the answer and the
     * overlay no longer does. Unknown shape means inline, which is the mode
     * that needs nothing from WorkspaceCss.
     */
    public static function inline_mode(): bool {
        if ( null !== self::$inline_mode ) {
            return self::$inline_mode;
        }
        self::$resolving = true;
        $settings = get_option( 'bricks_global_settings', [] );
        self::$resolving = false;

        $settings = is_array( $settings ) ? $settings : [];
        $mode     = isset( $settings['cssLoading'] ) ? (string) $settings['cssLoading'] : '';

        self::$inline_mode = ( 'file' !== $mode );
        return self::$inline_mode;
    }

    /** Where a workspace keeps its runtime values. One option per workspace. */
    public static function store_key( int $workspace_id ): string {
        return 've_ws_runtime_' . $workspace_id;
    }

    /**
     * @return mixed The workspace's value for a family, or null if it has none.
     *               Null is not "empty" — it means the workspace has never been
     *               told about this family, and the answer is Live.
     */
    public static function payload( int $workspace_id, string $family ) {
        if ( $workspace_id <= 0 ) {
            return null;
        }
        self::$resolving = true;
        $all = get_option( self::store_key( $workspace_id ), [] );
        self::$resolving = false;

        if ( ! is_array( $all ) || ! array_key_exists( $family, $all ) ) {
            return null;
        }
        return $all[ $family ];
    }

    public static function set_payload( int $workspace_id, string $family, $value ): bool {
        if ( $workspace_id <= 0 ) {
            return false;
        }
        self::$resolving = true;
        $key = self::store_key( $workspace_id );
        $all = get_option( $key, [] );
        $all = is_array( $all ) ? $all : [];
        $all[ $family ] = $value;
        $ok = update_option( $key, $all, false );
        self::$resolving = false;

        return (bool) $ok;
    }

    /**
     * Slice 11. Drop ONE family from a workspace, leaving the rest.
     *
     * Used after that family is published: the workspace no longer differs from
     * Live, and a payload that still says it does is what slice 8 would read as
     * a leak on the next admin request - and then "repair" by putting the old
     * value back, undoing the publish. Letting go is part of publishing.
     */
    public static function forget_family( int $workspace_id, string $family ): bool {
        if ( $workspace_id <= 0 || '' === $family ) {
            return false;
        }
        return (bool) self::without_overlay( static function () use ( $workspace_id, $family ) {
            $key = self::store_key( $workspace_id );
            $all = get_option( $key, [] );
            if ( ! is_array( $all ) || ! array_key_exists( $family, $all ) ) {
                return true;
            }
            unset( $all[ $family ] );
            return update_option( $key, $all, false );
        } );
    }

    /** Forget everything a workspace held. Used when one is discarded. */
    public static function forget( int $workspace_id ): bool {
        if ( $workspace_id <= 0 ) {
            return false;
        }
        self::$resolving = true;
        $ok = delete_option( self::store_key( $workspace_id ) );
        self::$resolving = false;
        return (bool) $ok;
    }

    /**
     * The read side. Returning anything but false short-circuits get_option(),
     * BEFORE it reads or writes any cache — which is the whole reason this is
     * safe, and is proved against core rather than assumed.
     *
     * @param mixed  $pre    False to carry on to the real option.
     * @param string $option Which family fired. Core passes it; slice 9 needs it.
     * @return mixed
     */
    public static function read_overlay( $pre, $option = '' ) {
        if ( self::$resolving ) {
            return $pre;
        }
        if ( ! self::enabled() ) {
            return $pre;
        }
        if ( '' === $option || ! self::covers( $option ) ) {
            return $pre;
        }
        $workspace_id = self::session_id();
        if ( $workspace_id <= 0 ) {
            return $pre;
        }

        $value = self::payload( $workspace_id, $option );
        if ( null === $value ) {
            /* The workspace has not touched this family, so there is nothing to
               overlay and Live is the correct answer. Inventing an empty array
               here would blank every class or variable on the site for the
               editor. Null is "never told about it"; an empty array is a real
               workspace value and IS served — that is how a workspace that
               deleted its last class shows an empty list. */
            return $pre;
        }
        return $value;
    }

    /**
     * The write side, and the half the object-cache test made non-optional.
     *
     * Returning $old is what makes core's own equality check return false
     * before it writes the row or the cache. The value goes to the workspace
     * instead.
     *
     * Slice 9 found a second thing this buys, and it is worth stating because
     * it is the reason theme styles and the colour palette could be included
     * here rather than waiting for slice 10. Core applies this filter BEFORE
     * its own equality check, and returns early when the value has not changed
     * — so a held write fires no `update_option_{$option}` either. Bricks hangs
     * its CSS-file generators on exactly that action
     * (`Assets_Color_Palettes::__construct`), so holding the write suppresses
     * the shared-file regeneration too, by the same mechanism and for free.
     *
     * @param mixed  $value  The value somebody is trying to store.
     * @param mixed  $old    What get_option() said — and get_option() went
     *                       through the overlay above, so this is the WORKSPACE
     *                       value when a session is on.
     * @param string $option Which family fired.
     * @return mixed
     */
    public static function hold_write( $value, $old, $option = '' ) {
        if ( self::$resolving ) {
            return $value;
        }
        if ( ! self::enabled() ) {
            return $value;
        }
        if ( '' === $option || ! self::covers( $option ) ) {
            return $value;
        }
        $workspace_id = self::session_id();
        if ( $workspace_id <= 0 ) {
            /* No session, so this write is going to Live and MV is standing here
               watching it happen. Slice 8 needs that fact recorded: it is what
               tells a legitimate edit apart from a value that appeared while MV
               was not running. See WorkspaceFingerprint's header. */
            self::witness( $option, $value );
            return $value;
        }

        self::set_payload( $workspace_id, $option, $value );

        /* Slice 10. Holding the write is what stops Bricks regenerating the
           shared file - which is right, and is also why the workspace's own
           copy has to be rebuilt here instead. In inline mode this does
           nothing, because there are no files. */
        if ( class_exists( __NAMESPACE__ . '\\WorkspaceCss' ) ) {
            WorkspaceCss::regenerate( $workspace_id );
        }

        /* Hand core back what it already believes, so it writes nothing. */
        return $old;
    }

    /**
     * Run something with the overlay stood down.
     *
     * Restores the previous state rather than setting false, because these nest:
     * the fingerprint reads its own option inside a call that is already inside
     * one, and a naive reset would switch the overlay back on halfway through
     * somebody else's raw read.
     *
     * @param callable $fn
     * @return mixed Whatever $fn returned.
     */
    public static function without_overlay( callable $fn ) {
        $was = self::$resolving;
        self::$resolving = true;
        try {
            return $fn();
        } finally {
            self::$resolving = $was;
        }
    }

    /**
     * The option as the SITE has it, with the overlay stood down.
     *
     * Slice 8 needs this: a fingerprint of Live taken through the overlay would
     * be a fingerprint of the workspace, and would match itself forever.
     *
     * @return mixed
     */
    public static function live_value( string $family ) {
        return self::without_overlay( static function () use ( $family ) {
            return get_option( $family, null );
        } );
    }

    /**
     * Put Live back, with the overlay stood down so the write is not held.
     *
     * The only place in the module that writes a live global on purpose, and it
     * only ever writes back a value MV recorded itself.
     */
    public static function restore_live( string $family, $value, $autoload = null ): bool {
        return (bool) self::without_overlay( static function () use ( $family, $value, $autoload ) {
            return update_option( $family, $value, $autoload );
        } );
    }

    /**
     * Slice 8 - write down that MV was present when Live changed.
     *
     * This is the whole discriminator behind §100.1.b, so it is worth being
     * plain about what it means. `pre_update_option_*` fires for EVERY write to
     * the family, including writes by somebody with no workspace open. A write
     * MV saw is a write MV could have held had it needed holding - so it is not
     * a leak, whatever value it happens to carry. A leak is by definition a
     * write MV was not running for.
     *
     * A short list rather than one hash: an admin can make several Live edits
     * between two inspections, and only the newest would otherwise be witnessed.
     */
    public static function witness( string $family, $value ): void {
        $hash = self::hash( $value );
        self::without_overlay( static function () use ( $family, $hash ) {
            $all = get_option( self::WITNESS_KEY, [] );
            $all = is_array( $all ) ? $all : [];
            $for = isset( $all[ $family ] ) && is_array( $all[ $family ] ) ? $all[ $family ] : [];

            if ( in_array( $hash, $for, true ) ) {
                return;
            }
            array_unshift( $for, $hash );
            $all[ $family ] = array_slice( $for, 0, self::WITNESS_KEEP );

            update_option( self::WITNESS_KEY, $all, false );
        } );
    }

    public static function was_witnessed( string $family, string $hash ): bool {
        $all = self::without_overlay( static function () {
            return get_option( self::WITNESS_KEY, [] );
        } );
        $all = is_array( $all ) ? $all : [];
        $for = isset( $all[ $family ] ) && is_array( $all[ $family ] ) ? $all[ $family ] : [];

        return in_array( $hash, $for, true );
    }

    /**
     * Hash an option value.
     *
     * Public since slice 11: publishing has to check what LANDED on Live rather
     * than what `update_option()` returned, and a second implementation of the
     * same hash is a second thing to get wrong.
     *
     * @param mixed $value
     */
    public static function hash( $value ): string {
        if ( class_exists( 'VE\\Core\\CanonicalJson' ) ) {
            return \VE\Core\CanonicalJson::hash( $value );
        }
        return hash( 'sha256', (string) maybe_serialize( $value ) );
    }

    /**
     * Slice 9 — the delete that cannot be held, first half.
     *
     * Core's `delete_option()` takes no filter that can stop it. It reads the
     * row, fires `delete_option` as an ACTION, deletes, and fires
     * `delete_option_{$option}`. So the only honest handling is: read the value
     * while the row is still there, and put it back immediately afterwards.
     *
     * Kept per option rather than as one slot because nothing promises a single
     * delete per request.
     */
    public static function note_delete( $option ): void {
        $option = (string) $option;

        if ( self::$resolving || ! self::covers( $option ) ) {
            return;
        }
        if ( ! self::enabled() || self::session_id() <= 0 ) {
            return;
        }

        self::$deleting[ $option ] = [
            'value'    => self::live_value( $option ),
            'autoload' => self::autoload_of( $option ),
        ];
    }

    /**
     * …and the second half. The row is already gone when this runs.
     *
     * The workspace records the EMPTY form rather than the value that was
     * there: the caller's intent was "this family is now empty", and that is a
     * real workspace value which `read_overlay` serves — which is how an editor
     * who deleted their last global class sees an empty list while the site
     * keeps its classes.
     */
    public static function undo_delete( $option ): void {
        $option = (string) $option;

        if ( ! array_key_exists( $option, self::$deleting ) ) {
            return;
        }
        $held = self::$deleting[ $option ];
        unset( self::$deleting[ $option ] );

        $workspace_id = self::session_id();
        if ( $workspace_id > 0 ) {
            self::set_payload( $workspace_id, $option, is_array( $held['value'] ) ? [] : '' );
        }

        if ( null !== $held['value'] && false !== $held['value'] ) {
            self::restore_live( $option, $held['value'], $held['autoload'] );
        }
    }

    /**
     * Whether an option is autoloaded, read the same way core reads it in
     * `delete_option()`.
     *
     * Asked because putting the row back with core's default heuristics could
     * quietly change whether every request on the site loads it. One indexed
     * query, and only on a delete inside a workspace session.
     *
     * @return bool|null Null when it cannot be told, which means "let core decide".
     */
    private static function autoload_of( string $option ) {
        global $wpdb;

        if ( ! isset( $wpdb ) || ! is_object( $wpdb ) || ! method_exists( $wpdb, 'get_row' ) ) {
            return null;
        }
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT autoload FROM {$wpdb->options} WHERE option_name = %s", $option ) );

        if ( ! is_object( $row ) || ! isset( $row->autoload ) ) {
            return null;
        }
        if ( function_exists( 'wp_autoload_values_to_autoload' ) ) {
            return in_array( $row->autoload, wp_autoload_values_to_autoload(), true );
        }
        return in_array( (string) $row->autoload, [ 'yes', 'on', 'auto', 'auto-on' ], true );
    }

    /** For tests and for a request that has genuinely changed identity. */
    public static function forget_session_cache(): void {
        self::$session     = null;
        self::$inline_mode = null;
        self::$deleting    = [];
    }
}
