<?php
/**
 * Slice 10 — file CSS-loading mode, and why it turned out to be a different
 * problem from the one the plan described.
 *
 * Slices 7, 8 and 9 all stand down when Bricks is set to load CSS from files.
 * The reason recorded at the time was: "Bricks writes the variables into shared
 * .css files on save, and overlaying the option would leave those files holding
 * workspace values for every visitor."
 *
 * **That is not true of this Bricks.** Reading `includes/assets/` rather than
 * recalling it: every one of the six shared-file generators is hooked on
 * `add_option_{$option}` / `update_option_{$option}` —
 *
 *   color-palettes.php      update_option_bricks_color_palette
 *   global-variables.php    update_option_bricks_global_variables
 *   global-elements.php     update_option_bricks_global_elements
 *   theme-styles.php        update_option_bricks_theme_styles
 *   global-custom-css.php   update_option_bricks_global_settings
 *   files.php               save_post  (per-post, and a shadow post is its own)
 *
 * — and slice 9 established that a held write fires none of them, because core
 * applies `pre_update_option_*` BEFORE its own equality check and returns early.
 * So in file mode the overlay does not leak a workspace value into a shared
 * file. The audit's claim that `save_post()` calls two generators inline
 * (`ajax.php:1543`, `:2103`) does not hold here either: those functions do not
 * exist in 2.1.4.
 *
 * ── So what IS wrong with file mode ──────────────────────────────────────────
 *
 * The opposite of a leak. With the write held, the shared files keep their LIVE
 * contents — and in file mode Bricks styles the page from those files, not from
 * the option. The editor would change a variable, MV would file it safely into
 * the workspace, and nothing on screen would move. A workspace that does not
 * show you your own work is not a workspace.
 *
 * ── One seam, not five ───────────────────────────────────────────────────────
 *
 * `Assets::$css_dir` and `$css_url` are public statics that every generator
 * writes through and `Assets_Files::load_css_files()` enqueues from. Point them
 * at a per-workspace directory for the length of a session and all six files
 * follow at once: written there, read from there, and the live directory is
 * never opened. An admin hitting "Regenerate CSS files" mid-session lands there
 * too, which is the one path that would otherwise have written workspace values
 * into the shared files on purpose.
 *
 * The directory is seeded by copying the live files when the session opens, so
 * the editor starts from the site as it is rather than from a page with no
 * global CSS at all.
 *
 * ── What this does NOT do, said here rather than discovered later ────────────
 *
 * - **A preview link still renders with LIVE globals.** `WorkspacePreview`
 *   redirects to WordPress's own preview URL for the shadow post, and that is a
 *   separate request which may carry no workspace session. The page's own
 *   `post-{ID}.min.css` is correct, because a shadow post is its own post. The
 *   global files are Live's. Naming it because "preview enqueues the workspace
 *   files" is in the plan and is not in this slice.
 * - **`bricks_global_settings` is still not overlaid** (slice 9 declined it, and
 *   still declines it: overlaying it would overlay the `cssLoading` setting that
 *   decides whether any of this runs). So editing global custom CSS inside a
 *   workspace still changes the site's setting. The generated file follows the
 *   session into the workspace directory; the option does not.
 * - **The workspace directory is under uploads and is readable by URL** to
 *   anyone who guesses the path, exactly as Bricks' own files are. It holds an
 *   editor's unpublished CSS. That is a different risk from serving it to a
 *   visitor, and it is not one this slice removes.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceCss {

    /** Where a workspace's files live, under Bricks' own css directory. */
    public const PREFIX = 've-ws-';

    /** @var string|null The shared directory, captured before any retarget. */
    private static $live_dir = null;

    /** @var string|null */
    private static $live_url = null;

    /** @var int The workspace this request has been retargeted to, or 0. */
    private static $pointed_at = 0;

    public static function register(): void {
        /* `init`, and late: retargeting needs to know who is asking, which is
           the same reason WorkspaceFingerprint waits. Bricks has set the
           directory in its constructor by then (the theme loads at
           wp-settings.php:752, before `init` at 790), and nothing reads it
           until `wp_enqueue_scripts`. */
        add_action( 'init', [ self::class, 'retarget' ], 21 );
    }

    /** Whether Bricks is serving CSS from files rather than inline. */
    public static function file_mode(): bool {
        return ! WorkspaceRuntime::inline_mode();
    }

    // ── where things are ────────────────────────────────────────────────────

    /**
     * The shared directory, as Bricks had it before MV touched anything.
     *
     * Captured once. Reading it back off `Assets::$css_dir` after a retarget
     * would return the workspace directory, and every path below would then be
     * nested inside the last one.
     */
    public static function live_dir(): string {
        if ( null !== self::$live_dir ) {
            return self::$live_dir;
        }
        if ( class_exists( '\Bricks\Assets' ) && ! empty( \Bricks\Assets::$css_dir ) ) {
            self::$live_dir = (string) \Bricks\Assets::$css_dir;
            self::$live_url = (string) \Bricks\Assets::$css_url;
            return self::$live_dir;
        }

        $uploads = function_exists( 'wp_upload_dir' ) ? wp_upload_dir( null, false ) : [];
        self::$live_dir = isset( $uploads['basedir'] ) ? $uploads['basedir'] . '/bricks/css' : '';
        self::$live_url = isset( $uploads['baseurl'] ) ? $uploads['baseurl'] . '/bricks/css' : '';

        return self::$live_dir;
    }

    public static function live_url(): string {
        self::live_dir();
        return (string) self::$live_url;
    }

    public static function dir_for( int $workspace_id ): string {
        $base = self::live_dir();
        return '' === $base ? '' : $base . '/' . self::PREFIX . $workspace_id;
    }

    public static function url_for( int $workspace_id ): string {
        $base = self::live_url();
        return '' === $base ? '' : $base . '/' . self::PREFIX . $workspace_id;
    }

    /** Which workspace this request's CSS paths are pointing at. */
    public static function pointed_at(): int {
        return self::$pointed_at;
    }

    // ── the seam ────────────────────────────────────────────────────────────

    /**
     * Point Bricks' CSS directory at this session's workspace.
     *
     * Every uncertainty falls towards Live, the same way the overlay's do: no
     * session, inline mode, no Bricks, or a directory that cannot be made, and
     * the shared files are what get written and read.
     */
    public static function retarget(): void {
        if ( ! class_exists( '\Bricks\Assets' ) ) {
            return;
        }
        if ( ! self::file_mode() ) {
            return;
        }
        $workspace_id = WorkspaceRuntime::session_id();
        if ( $workspace_id <= 0 ) {
            return;
        }
        self::point_at( $workspace_id );
    }

    /** @return bool Whether the paths were moved. */
    public static function point_at( int $workspace_id ): bool {
        if ( $workspace_id <= 0 || ! class_exists( '\Bricks\Assets' ) ) {
            return false;
        }
        $dir = self::dir_for( $workspace_id );
        /* C144, found on test7 2026-09-23 in file mode: publishing empties and
           removes this directory, but the editor is usually still in the
           builder, still inside the workspace. The next request made the
           directory again - EMPTY, because seeding only happened when a session
           began - and pointed Bricks at it, so the builder asked for global
           stylesheets that were not there. A directory made here for the first
           time is filled from Live first, the same as a new session's. */
        $fresh = '' !== $dir && ! is_dir( $dir );
        if ( '' === $dir || ! self::ensure_dir( $dir ) ) {
            return false;
        }
        if ( $fresh ) {
            self::seed( $workspace_id );
        }

        \Bricks\Assets::$css_dir = $dir;
        \Bricks\Assets::$css_url = self::url_for( $workspace_id );
        self::$pointed_at        = $workspace_id;

        return true;
    }

    /** Put them back. Used on publish, and by tests. */
    public static function point_at_live(): void {
        if ( ! class_exists( '\Bricks\Assets' ) ) {
            return;
        }
        \Bricks\Assets::$css_dir = self::live_dir();
        \Bricks\Assets::$css_url = self::live_url();
        self::$pointed_at        = 0;
    }

    // ── filling it ──────────────────────────────────────────────────────────

    /**
     * Copy the live files in, so a workspace opens on the site as it is.
     *
     * Without this the workspace directory is empty, `load_css_files()` skips
     * every file it cannot find, and the editor's first look at their own
     * workspace is a page with no global CSS at all — which would read as MV
     * having broken the site rather than as a workspace being empty.
     *
     * Only ever copies IN. Nothing here writes to the live directory.
     */
    public static function seed( int $workspace_id ): int {
        $from = self::live_dir();
        $to   = self::dir_for( $workspace_id );

        if ( '' === $from || '' === $to || ! is_dir( $from ) || ! self::ensure_dir( $to ) ) {
            return 0;
        }

        $copied = 0;
        foreach ( (array) glob( $from . '/*.css' ) as $file ) {
            if ( ! is_file( $file ) ) {
                continue;
            }
            if ( @copy( $file, $to . '/' . basename( $file ) ) ) {
                $copied++;
            }
        }
        return $copied;
    }

    /**
     * Rebuild the workspace's shared files from the workspace's own values.
     *
     * Bricks' own generators, called with the workspace's values while the
     * directory points at the workspace. Writing the CSS here instead would be
     * a second implementation of Bricks' stylesheet, and the first time the two
     * disagreed the workspace would be showing something the site would never
     * produce.
     *
     * @return array<string> The generators that ran.
     */
    public static function regenerate( int $workspace_id ): array {
        if ( $workspace_id <= 0 || ! self::file_mode() ) {
            return [];
        }
        $was = self::$pointed_at;
        if ( ! self::point_at( $workspace_id ) ) {
            return [];
        }

        $ran = [];
        foreach ( self::generators() as $family => $generator ) {
            if ( ! is_callable( $generator ) ) {
                continue;
            }
            $value = WorkspaceRuntime::payload( $workspace_id, $family );
            if ( null === $value ) {
                // Untouched by this workspace: the seeded copy is still right,
                // and regenerating from Live would only rewrite it identically.
                continue;
            }
            $generator( $value );
            $ran[] = $family;
        }

        if ( $was > 0 && $was !== $workspace_id ) {
            self::point_at( $was );
        }
        return $ran;
    }

    /**
     * The families that have a shared file behind them, and what writes it.
     *
     * Read off Bricks' `includes/assets/` rather than listed from memory. A
     * family with no entry here has no shared file — global classes, for one,
     * which are written into each post's own CSS.
     *
     * @return array<string,callable|null>
     */
    public static function generators(): array {
        return [
            'bricks_global_variables' => class_exists( '\Bricks\Assets_Global_Variables' )
                ? [ '\Bricks\Assets_Global_Variables', 'generate_css_file' ] : null,
            'bricks_color_palette'    => class_exists( '\Bricks\Assets_Color_Palettes' )
                ? [ '\Bricks\Assets_Color_Palettes', 'generate_css_file' ] : null,
            'bricks_global_elements'  => class_exists( '\Bricks\Assets_Global_Elements' )
                ? [ '\Bricks\Assets_Global_Elements', 'generate_css_file' ] : null,
            'bricks_theme_styles'     => class_exists( '\Bricks\Assets_Theme_Styles' )
                ? [ '\Bricks\Assets_Theme_Styles', 'generate_css_file' ] : null,
        ];
    }

    // ── ending ──────────────────────────────────────────────────────────────

    /**
     * A workspace was published: put the paths back and rebuild Live once.
     *
     * After apply, so the options already hold the published values and the
     * generators read the right thing. Called explicitly rather than hooked,
     * because "once, after apply" is a position in a sequence and not an event.
     */
    public static function promote( int $workspace_id ): array {
        self::point_at_live();

        if ( ! self::file_mode() ) {
            return [];
        }

        $ran = [];
        foreach ( self::generators() as $family => $generator ) {
            if ( ! is_callable( $generator ) ) {
                continue;
            }
            $value = WorkspaceRuntime::live_value( $family );
            if ( null === $value || false === $value ) {
                continue;
            }
            $generator( $value );
            $ran[] = $family;
        }
        return $ran;
    }

    /** Discarded or published — the workspace's copies are not wanted either way. */
    public static function forget( int $workspace_id ): bool {
        $dir = self::dir_for( $workspace_id );
        if ( '' === $dir || ! is_dir( $dir ) ) {
            return false;
        }
        foreach ( (array) glob( $dir . '/*' ) as $file ) {
            if ( is_file( $file ) ) {
                @unlink( $file );
            }
        }
        return @rmdir( $dir );
    }

    // ── plumbing ────────────────────────────────────────────────────────────

    private static function ensure_dir( string $dir ): bool {
        if ( is_dir( $dir ) ) {
            return true;
        }
        if ( function_exists( 'wp_mkdir_p' ) ) {
            return (bool) wp_mkdir_p( $dir );
        }
        return @mkdir( $dir, 0755, true );
    }

    /** For tests, and for a request that has genuinely changed identity. */
    public static function forget_request_cache(): void {
        self::$live_dir   = null;
        self::$live_url   = null;
        self::$pointed_at = 0;
    }
}
