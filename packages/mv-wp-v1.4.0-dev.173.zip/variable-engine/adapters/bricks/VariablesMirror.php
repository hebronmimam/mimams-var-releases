<?php

namespace VE\Adapters\Bricks;

use VE\Core\VariableManager;

defined( 'ABSPATH' ) || exit;

class VariablesMirror {

    private const CATEGORY_ID = 'mimams-var';
    private const ID_PREFIX   = 'mv-';

    /* R47, 2026-09-23 - "a clean 2 way sync", and on a clash "the newer change
       wins and you're told". The owner's words.

       It went one way: every MV save rewrote MV's copies in Bricks, so a
       variable changed in Bricks' own panel was put back by the next MV save.
       Two-way needs one fact the mirror never kept - the value both sides last
       AGREED on. Bricks' Save sends every variable it holds, including copies
       loaded before an MV edit, so "Bricks has a different value" means nothing
       by itself: equal to the agreed value is a stale copy, anything else is an
       edit made in Bricks. */
    public const BASE_OPTION    = 've_bricks_mirror_base';
    public const NOTICES_OPTION = 've_bricks_sync_notices';
    private const NOTICES_KEEP  = 30;
    /** How many earlier agreed values are remembered per variable, to recognise a stale copy. */
    private const HISTORY_KEEP  = 12;

    /** @var bool Set while this class writes Bricks' option, so its own write is not read back as a Bricks edit. */
    private static $writing = false;
    /** @var bool Set while pulling Bricks' values into MV, so the export that follows cannot start another pull. */
    private static $pulling = false;

    public static function register(): void {
        add_action( 'update_option_bricks_global_variables', [ self::class, 'on_bricks_saved' ], 10, 2 );
    }

    public function sync( ?array $variables = null ): bool {
        if ( ! $this->bricks_available() ) {
            return true;
        }

        if ( null === $variables ) {
            $variables = ( new VariableManager() )->get_all();
        }

        $current = get_option( 'bricks_global_variables', [] );
        $current = is_array( $current ) ? $current : [];

        /* R47, MV's side. MV is writing now, so on a clash MV's value is the
           newer one - but a variable changed only in Bricks (say while MV was
           switched off) is pulled in first rather than written over. */
        if ( ! self::$pulling && ! self::in_workspace_session() ) {
            $plan = self::reconcile( $current, $variables, self::raw_values(), self::base(), 'mv' );
            if ( $plan['pulls'] ) {
                self::apply_pulls( $plan['pulls'] );
                self::add_notices( $plan['notices'] );
                // The CSS file and this mirror are rebuilt from the pulled values.
                return ( new \VE\Core\CssExporter() )->export();
            }
            self::add_notices( $plan['notices'] );
        }

        $merged  = self::merge_variables( $current, $variables );

        /* §112, and slice 7 does not ship without this.

           This mirror writes `bricks_global_variables` straight through the
           option API, which is how it bypasses the builder - and it is also why
           WorkspaceRuntime's `pre_update_option_*` catches it: a sync during a
           workspace session is held and put in the workspace rather than on the
           site. That part needs no change here.

           What DOES need changing is how the answer is read. Holding the write
           makes core's own equality check return false, and this line treated a
           false from update_option() as a failure - so a sync inside a workspace
           would have reported "the mirror is broken" while doing exactly the
           right thing. Under a session, false is success. */
        self::$writing = true;
        $wrote = $merged === $current || update_option( 'bricks_global_variables', $merged, false );
        self::$writing = false;
        if ( ! $wrote ) {
            if ( ! self::in_workspace_session() ) {
                return false;
            }
        }
        if ( ! self::in_workspace_session() ) {
            self::remember_base( $merged );
        }

        $categories = get_option( 'bricks_global_variables_categories', [] );
        $categories = is_array( $categories ) ? $categories : [];
        $has_category = false;
        foreach ( $categories as $category ) {
            if ( is_array( $category ) && ( $category['id'] ?? '' ) === self::CATEGORY_ID ) {
                $has_category = true;
                break;
            }
        }
        if ( ! $has_category ) {
            $categories[] = [
                'id'   => self::CATEGORY_ID,
                'name' => "Mimam's Var",
            ];
            if ( ! update_option( 'bricks_global_variables_categories', array_values( $categories ), false ) ) {
                /* Slice 9 changed the answer here, and left the previous one in
                   view because the change is the interesting part.

                   Under slice 7 the categories option was NOT overlaid, so a
                   false was a real failure and this returned false. Slice 9
                   overlays it along with every other global the builder's Save
                   writes - so under a session a false now means the same thing
                   it means on the line above: held, filed into the workspace,
                   nothing wrong. Judging the two lines differently would now be
                   the bug rather than the care. */
                if ( ! self::in_workspace_session() ) {
                    return false;
                }
            }
        }

        return true;
    }

    public static function merge_variables( array $current, array $variables ): array {
        $manager = new VariableManager();
        $external = [];
        $external_names = [];

        foreach ( $current as $variable ) {
            if ( ! is_array( $variable ) ) {
                continue;
            }
            $id = (string) ( $variable['id'] ?? '' );
            $category = (string) ( $variable['category'] ?? '' );
            if ( self::CATEGORY_ID === $category || 0 === strpos( $id, self::ID_PREFIX ) ) {
                continue;
            }
            $name = ltrim( (string) ( $variable['name'] ?? '' ), '-' );
            if ( '' !== $name ) {
                $external_names[ $name ] = true;
            }
            $external[] = $variable;
        }

        $mirrored = [];
        foreach ( $variables as $variable ) {
            if ( ! is_array( $variable ) || empty( $variable['id'] ) || empty( $variable['name'] ) ) {
                continue;
            }
            $name = ltrim( $manager->to_css_name( (string) $variable['name'] ), '-' );
            if ( '' === $name || isset( $external_names[ $name ] ) ) {
                continue;
            }
            $mirrored[] = [
                'id'       => self::ID_PREFIX . (int) $variable['id'],
                'name'     => $name,
                'value'    => (string) ( $variable['css_value'] ?? $variable['value'] ?? '' ),
                'category' => self::CATEGORY_ID,
            ];
        }

        usort( $mirrored, static function ( array $a, array $b ): int {
            return strnatcasecmp( $a['name'], $b['name'] );
        } );

        return array_values( array_merge( $external, $mirrored ) );
    }

    /**
     * R47, Bricks' side: Bricks has just saved its variables.
     *
     * Bricks is writing now, so on a clash its value is the newer one. A copy
     * that is merely stale - equal to what both last agreed on - is not an
     * edit, and MV's newer value is put back.
     *
     * @param mixed $old
     * @param mixed $new
     */
    public static function on_bricks_saved( $old, $new ): void {
        if ( self::$writing || self::$pulling || ! is_array( $new ) || self::in_workspace_session() ) {
            return;
        }
        $vars = ( new \VE\Core\ThemeManager() )->apply_to_variables( ( new VariableManager() )->get_all() );
        $plan = self::reconcile( $new, $vars, self::raw_values(), self::base(), 'bricks' );
        self::add_notices( $plan['notices'] );
        if ( $plan['pulls'] ) {
            self::apply_pulls( $plan['pulls'] );
        }
        if ( $plan['pulls'] || $plan['restores'] ) {
            // Rebuilds variables.css from MV, and writes MV's values back over any stale copy.
            ( new \VE\Core\CssExporter() )->export();
        } else {
            self::remember_base( $new );
        }
    }

    /**
     * What to do with each of MV's copies in Bricks. Pure, so a guard can walk
     * every case.
     *
     * @param array  $bricks MV's copies are the `mv-<id>` entries in here.
     * @param array  $vars   MV's variables as the mirror writes them (themes applied).
     * @param array  $raw    id => the value typed into MV, before any theme or formula.
     * @param array  $base   `mv-<id>` => the value both sides last agreed on.
     * @param string $side   Who is writing now, and so whose change is newer: 'bricks' or 'mv'.
     * @return array{pulls:array<int,string>,restores:array<int,bool>,notices:array}
     */
    public static function reconcile( array $bricks, array $vars, array $raw, array $base, string $side ): array {
        $mirrored = [];
        $names    = [];
        foreach ( $vars as $v ) {
            if ( ! is_array( $v ) || empty( $v['id'] ) ) {
                continue;
            }
            $mirrored[ (int) $v['id'] ] = (string) ( ( $v['css_value'] ?? '' ) !== '' ? $v['css_value'] : ( $v['value'] ?? '' ) );
            $names[ (int) $v['id'] ]    = (string) ( $v['name'] ?? '' );
        }
        $out = [ 'pulls' => [], 'restores' => [], 'notices' => [] ];
        foreach ( $bricks as $b ) {
            if ( ! is_array( $b ) ) {
                continue;
            }
            $bid = (string) ( $b['id'] ?? '' );
            if ( 0 !== strpos( $bid, self::ID_PREFIX ) ) {
                continue;
            }
            $id = (int) substr( $bid, strlen( self::ID_PREFIX ) );
            if ( ! isset( $mirrored[ $id ] ) ) {
                continue;               // gone from MV; the next mirror drops it
            }
            $bv = (string) ( $b['value'] ?? '' );
            $mv = $mirrored[ $id ];
            if ( $bv === $mv ) {
                continue;
            }
            $entry   = $base[ $bid ] ?? null;
            $agreed  = is_array( $entry ) ? (string) ( $entry['v'] ?? '' ) : ( null === $entry ? null : (string) $entry );
            $earlier = is_array( $entry ) ? array_map( 'strval', (array) ( $entry['h'] ?? [] ) ) : [];
            if ( null === $agreed ) {
                // Never agreed on anything: nothing to tell an edit from a stale copy by.
                if ( 'bricks' === $side ) {
                    $out['restores'][ $id ] = true;
                }
                continue;
            }
            /* A stale copy is ANY value the two once agreed on, not only the
               latest. The builder can be holding a value from two MV edits ago;
               checking only the newest agreement read that copy as a Bricks edit
               and put the old value back over MV's newer one. (A value typed in
               Bricks that happens to equal an earlier one reads as stale too -
               the one case this cannot tell apart, and MV's newer value stands.) */
            if ( $bv === $agreed || in_array( $bv, $earlier, true ) ) {
                $out['restores'][ $id ] = true;
                continue;
            }
            // Changed in Bricks.
            $both     = $mv !== $agreed;
            $pullable = isset( $raw[ $id ] ) && (string) $raw[ $id ] === $mv;
            $notice   = [ 'name' => $names[ $id ], 'mv_value' => $mv, 'bricks_value' => $bv ];
            if ( ! $pullable ) {
                // MV works this value out (a theme, a generator, a formula); a typed value cannot flow back.
                $out['restores'][ $id ] = true;
                $out['notices'][] = $notice + [ 'kept' => 'mv', 'reason' => 'worked-out' ];
                continue;
            }
            if ( $both && 'mv' === $side ) {
                $out['restores'][ $id ] = true;
                $out['notices'][] = $notice + [ 'kept' => 'mv', 'reason' => 'both' ];
                continue;
            }
            $out['pulls'][ $id ] = $bv;
            if ( $both ) {
                $out['notices'][] = $notice + [ 'kept' => 'bricks', 'reason' => 'both' ];
            }
        }
        return $out;
    }

    /** id => the value typed into MV. */
    private static function raw_values(): array {
        $raw = [];
        foreach ( ( new VariableManager() )->get_all() as $v ) {
            if ( is_array( $v ) && ! empty( $v['id'] ) && 'base' === (string) ( $v['type'] ?? 'base' ) ) {
                $raw[ (int) $v['id'] ] = (string) ( $v['value'] ?? '' );
            }
        }
        return $raw;
    }

    private static function apply_pulls( array $pulls ): void {
        self::$pulling = true;
        $manager = new VariableManager();
        foreach ( $pulls as $id => $value ) {
            $manager->update( (int) $id, [ 'value' => (string) $value ], true );
        }
        self::$pulling = false;
    }

    private static function base(): array {
        $b = get_option( self::BASE_OPTION, [] );
        return is_array( $b ) ? $b : [];
    }

    /** What both sides now agree on, and what they agreed on before it. */
    private static function remember_base( array $bricks ): void {
        $before = self::base();
        $base   = [];
        foreach ( $bricks as $b ) {
            if ( ! is_array( $b ) || 0 !== strpos( (string) ( $b['id'] ?? '' ), self::ID_PREFIX ) ) {
                continue;
            }
            $bid = (string) $b['id'];
            $now = (string) ( $b['value'] ?? '' );
            $old = $before[ $bid ] ?? null;
            $was = is_array( $old ) ? (string) ( $old['v'] ?? '' ) : ( null === $old ? null : (string) $old );
            $h   = is_array( $old ) ? array_values( (array) ( $old['h'] ?? [] ) ) : [];
            if ( null !== $was && $was !== $now ) {
                $h[] = $was;
            }
            $h = array_values( array_diff( array_unique( $h ), [ $now ] ) );
            $base[ $bid ] = [ 'v' => $now, 'h' => array_slice( $h, -self::HISTORY_KEEP ) ];
        }
        if ( $base !== $before ) {
            update_option( self::BASE_OPTION, $base, false );
        }
    }

    private static function add_notices( array $notices ): void {
        if ( ! $notices ) {
            return;
        }
        $list = get_option( self::NOTICES_OPTION, [] );
        $list = is_array( $list ) ? $list : [];
        foreach ( $notices as $n ) {
            $list[] = $n + [ 'at' => time() ];
        }
        update_option( self::NOTICES_OPTION, array_slice( $list, -self::NOTICES_KEEP ), false );
    }

    /**
     * Whether this write is happening inside a workspace session.
     *
     * Asked of the module rather than worked out here: one place decides what a
     * session is, and a second copy of that rule would be the way the two come
     * to disagree. Absent module, absent session - which is also the answer on
     * any site where Workspaces is switched off.
     */
    private static function in_workspace_session(): bool {
        if ( ! class_exists( '\\VE\\Modules\\Workspaces\\WorkspaceRuntime' ) ) {
            return false;
        }
        return \VE\Modules\Workspaces\WorkspaceRuntime::session_id() > 0;
    }

    private function bricks_available(): bool {
        return defined( 'BRICKS_VERSION' )
            || function_exists( 'bricks_is_builder' )
            || false !== get_option( 'bricks_global_variables', false );
    }
}
