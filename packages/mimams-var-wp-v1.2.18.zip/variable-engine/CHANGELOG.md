# v1.2.18 — Update Feed Freshness

- Switched the default update manifest from GitHub raw CDN to the GitHub contents API raw response.
- Forced update checks now append a cache-buster so the panel can detect newly published updates sooner.
- Legacy saved raw manifest URLs are normalized back to the fresher default update feed.

# v1.2.17 — Docking Snap and CSS Studio UX

- Added a dedicated drag-handle icon before the panel logo.
- Dragging the handle now turns the panel into a floating panel automatically.
- Dragging near the left or right edge shows snap zones, and dropping there docks the panel.
- CSS Studio now renders immediately from local default sheets instead of showing a loading state.
- Fixed checkbox styling globally inside the MV panel so admin and builder panels match.
- Reworked CSS Studio suggestion priority around source names like Mimam's Var, Advanced Themer, Bricks, Core Framework, and Automatic.css.
- Replaced source-priority Up/Down buttons with drag-handle reordering.
- Moved CSS autocomplete suggestions near the editor caret instead of under the full editor.

# v1.2.16 — Dockable Panel and CSS Studio

- Added dock-right, dock-left, and floating panel modes, saved per browser.
- Floating panels can be dragged from the header.
- Removed GSAP scale hover from panel controls so buttons no longer jump, squeeze, or resize on hover.
- Standardized checkbox styling across sub-panels, including CSS Studio.
- Renamed the user-facing Advanced CSS area to CSS Studio.
- Expanded CSS Studio with editor settings, line numbers, Tab autocomplete foundations for variables/classes/IDs/properties, source-priority controls, and auto-format/SCSS-mode toggles.
- Added explanatory scope help for page, global, child, custom, and recipe stylesheets.

# v1.2.15 — Migration, Advanced CSS, and UI Standards

- Added a migration preview foundation for Bricks/Advanced Themer, Core Framework, and Automatic.css variables.
- Added an Advanced CSS panel and backend manager that compiles enabled stylesheets to `/wp-content/uploads/variable-engine/advanced.css`.
- Added frontend/admin loading for the compiled Advanced CSS file.
- Standardized panel inputs, textareas, checkboxes, and buttons so license and future feature controls inherit the same premium styling.
- Replaced ghost/outlined buttons with a filled neutral secondary button to permanently fix harsh hover text contrast.
- Added the backend route support Figma needs to read WordPress license status.

# v1.2.14 — Licensing Foundation and Hover Cleanup

- Added the first licensing gate foundation: license status, activate, check, and deactivate REST endpoints.
- Added license key, status, and optional license server URL controls to the WordPress settings panel.
- License keys are stored server-side and only a masked key/status is returned to the UI.
- Removed the panel background blur and kept a darker non-blurred overlay.
- Locked ghost/outlined button hover text to the same calm readable color so hover no longer causes bright text glare.

# v1.2.13 — Update Link and Admin Bar Hotfix

- Fixed the panel update button URL so WordPress receives real query parameters instead of an HTML-escaped nonce URL.
- Injected Mimam's Var into WordPress' cached update transient as well as the pre-set transient so the Plugins page/update count can detect available updates sooner.
- Reworked the admin bar toggle to use a fixed logo mark with centered `MV` text.
- Darkened and softened the panel background blur overlay.
- Reduced outlined/ghost button hover glare further while keeping the dark premium feel.

# v1.2.12 — Admin Bar, Overlay, and Sync Stats Polish

- Centered the WordPress admin bar logo and `MV` label so the toggle sits cleanly in the toolbar.
- Replaced the WordPress panel color overlay with a background blur when the panel is open.
- Changed `.base` parent groups to start collapsed by default; the toggle now opens them instead of first needing to close an already-open group.
- Softened outlined/ghost button hover states again so text remains readable without harsh brand-color glare.
- Removed duplicated "active variables on WordPress" text from the Figma stats card; the card now shows supporting record stats only.

# v1.2.11 — Panel Polish and Startup Collection Metadata

- Fixed default-open `.base` group toggling so the first click closes the parent.
- Replaced the WP admin bar placeholder/icon slot with the Hebronmimam logo image.
- Softened ghost-button hover colors to avoid harsh neon text on dark surfaces.
- Let the Snapshots view use the full sub-panel height.
- Improved Figma startup collection metadata sync so WordPress can show the active Figma collection after the Figma plugin opens.

# v1.2.10 — Sync Navigation, Collection Metadata, and Update Notice Polish

- Fixed generated/base parent rows so default-open `.base` groups can still be collapsed manually.
- Renamed and toggled the diagnostics viewer button so it is clear that it opens plugin diagnostic logs and can be hidden again.
- Hid Clean WP DB actions unless stats report stale, orphan, duplicate, or older-generator cleanup work.
- Added selected Figma collection metadata to the pairing status so WordPress can show the active collection under the Figma file name.
- Added a panel update notice with Update and Skip actions when the GitHub manifest reports a newer version.
- Fixed Snapshot back navigation so nested snapshot views return to the Sync panel instead of closing back to the main variable list.
- Added child-variant copy tooltips and switched panel icon rendering to Phosphor duotone classes.
- Improved destructive button hover contrast and replaced the WP admin bar icon with the Hebronmimam logo asset.

# v1.2.9 — Update Feed, UI Polish, and Imported Variant Preservation

- Added the GitHub raw update-feed URL as the default update source so WordPress can show plugin updates without manual feed setup.
- Added the Hebronmimam logo asset to the WordPress panel header instead of the placeholder color box.
- Improved number inputs, checkbox alignment/styling, hover action groups, and type-colored variable stripes across the WordPress panel.
- Protected imported generated children from cleanup when they belong to Figma-pushed synthetic bases, so nested variants remain visible after cleanup.
- Auto-expands safe `.base` groups in the WordPress variable browser so imported scale-like children are visible under their base.

# v1.2.8 — Dropdown, Cleanup, and Variant Base Refinement

- Replaced the WP new-variable category and scale selectors with custom dark menus to remove native select flicker, blue focus styling, and unreadable open states.
- Added a visible WP cleanup notice in the main variable browser when stale generated, orphan generated, duplicate, or older generator records are detected.
- Extended Figma-to-WordPress push nesting beyond colors: scale-like children can now nest under an existing parent, or a safe synthetic `{parent}.base` token when no parent exists.
- Fixed the new-variable header spacing and the create/close toolbar tooltip.

# v1.2.7 — Color Creation Control Refinement

- Updated the color creation/editing control so the color picker is a true 1:1 square.
- The generated color value preview now spans the remaining row width beside the picker.
- Replaced the HEX/RGB/HSL/OKLCH native dropdown with a full-width segmented control below the picker row to avoid white native popup edges.
- Reduced excessive rounding on form controls and tightened the dark dropdown/input styling.
- File-manager workflow now refreshes only the extracted `file-manager-upload/variable-engine` folder; no separate file-manager ZIP is produced.

# v1.2.6 — Figma Push Variant Cleanup + Straight Type Stripe

- Figma-to-WordPress import repair now also recognizes numeric color variants such as `color.background.bg.body.5`, `color.background.bg.body.10`, and `color.background.bg.body.20`.
- Numeric color variants are migrated into generated children of their base color when the base exists or is part of the same push.
- Restored the WordPress panel property/type marker to a straight vertical stripe instead of a rounded left border.
- Reviewed plugin inspiration packages for admin/builder UI direction; kept the current scoped refinement instead of a broad UI rewrite.

# v1.2.5 — Activation Diagnostics and CSS Import/Export

- Fixed an activation fatal caused by a UTF-8 BOM before the namespace declaration in `AdminAdapter.php`.
- Added early diagnostic logging for activation exceptions and plugin-owned fatal shutdown errors.
- Added a diagnostics log viewer endpoint and panel button so install/activation failures have a readable trail.
- Added commented CSS export with all current variables grouped by namespace.
- Added CSS import from uploaded `.css` files or pasted CSS custom properties, using the existing preview/apply workflow.
- Updated WordPress panel button hover behavior to remove jumpy vertical movement and use cleaner GSAP-assisted feedback.

# v1.2.4 — File Manager Hotfix

- Hardened the update-feed integration with more conservative PHP syntax and function guards.
- Bumped the WordPress plugin to `1.2.4` so it can be installed over the problematic `1.2.3` build.
- Kept the Figma → WordPress `repair_generated` nesting fix from v1.2.3.
- Refined button styling and line heights in the WordPress panel.
- Prepared a file-manager-ready extracted plugin folder and ZIP.

# v1.2.3 — Mimam's Var Rename, Update Feed, and Figma Nest Repair

- Renamed the WordPress plugin header/UI to "Mimam's Var - WP".
- Added private update-feed support so test sites can receive WordPress-native plugin update prompts from a JSON manifest URL.
- Added a Settings option to enable automatic updates for this plugin on test installs.
- Added an update check action in the panel settings.
- Fixed Figma → WordPress push previews that previously showed "No changes" when existing color variants only needed to be migrated under their base color.
- Improved the WordPress panel spacing, controls, borders, and button finish while preserving the existing dark/accent color system.

# v1.2.2 — Figma Color Variant Import Nesting

- Figma → WordPress push now imports color variants such as `color.brand.primary.d.4` as generated children of `color.brand.primary`.
- Imported generated color variants now receive `source_id`, `generator_type`, and dependency records so WordPress can display them under their base color instead of as unrelated base tokens.
- Updating an existing imported color variant now preserves/migrates it as a generated child instead of failing on the generated-variable edit lock.

# v1.2.1 — Activation Compatibility Fix

- Fixed activation fatal on PHP 7.4 sites by removing PHP 8-only syntax from loaded plugin files.
- Replaced `match` expressions with PHP 7.4-compatible `switch` logic.
- Removed union return type declarations such as `array|\WP_Error`, `true|\WP_Error`, and `\WP_REST_Response|\WP_Error`.
- No functional changes to fluid variables, sync, generators, cleanup, or pairing.

# v1.2.0 — Fluid Responsive Variables

- Added a new "Fluid" variable mode. Any single variable can now hold a responsive value that scales smoothly between the global min and max viewport widths.
- A fluid variable stores a compact `fluid:min,max` marker (px values); its `css_value` is compiled to a real `clamp()`.
- New shared `FluidValue` helper centralizes all clamp() math. `FluidScaleGenerator` now delegates to it, so single fluid variables and generated fluid scales use identical math.
- The builder panel's variable mode toggle is now Color / Fixed / Fluid / Static. The old "Clamp" mode is relabeled "Fixed" (single rem value — unchanged behaviour).
- Fluid mode shows min/max px inputs with a live clamp() preview using the global viewport settings.
- Changing the viewport range in Settings now automatically recompiles every fluid variable's clamp() output and re-exports CSS.
- The variable detail panel shows fluid variables in a friendly "16 → 24px fluid" form plus the computed clamp(); editing a fluid variable opens the full edit panel.
- Figma sync is unchanged: `extractNumber()` already extracts the max value from clamp(), so fluid variables push their desktop value correctly with no Figma plugin changes.

# v1.1.23
- Fixed fatal error in sync export caused by missing rename-history helper methods.
- Added stable identity key generation for base and generated variables.
- Added previous public token names to sync export for rename-aware Figma syncing.

# v1.1.22

- Added rename history metadata to sync exports so Figma can rename variables even when values changed.
- Added stable identity keys for Figma sync.
- Added client local time metadata support for sync logs.

# v1.1.21

- Sync export now includes stable variable IDs, source IDs, and generator type metadata so the Figma plugin can rename existing variables even when the variable value also changes.
- This supports safer Figma rename matching without requiring destructive delete sync.

# v1.1.21 — Rename Preview Fatal Fix

- Fixed rename impact preview fatal error caused by accessing a private validation constant from the REST controller.
- `VariableManager::NAME_PATTERN` is now public so rename preview can validate proposed names safely.
- This fixes the WordPress critical-error HTML appearing inside the edit panel when Preview impact is clicked.

# 1.1.17
- Added public token names to sync export (`public_name` and `css_name`) so Figma can use clean public names instead of internal storage wrappers.
- This lets `size.space` sync as `space` and generated children sync as `space-20`, while keeping the internal WordPress storage name intact.

# v1.1.16

- Added rename impact preview in the edit panel.
- Added optional WordPress/Bricks storage usage propagation when renaming variables.
- Searches post content, post meta, and targeted builder/theme options for CSS custom property references.
- Creates mappings for base variables and generated children.

# v1.1.15
- Public CSS/token name generation now strips storage-only wrappers such as `size`, `font`, and `typography` from base variable names. Example: `size.space` exports as `--space`.
- Copy var(), detail CSS display, and variable autocomplete now use the same public token-name logic.
- Reverted row-click auto expansion for generated children. Only the explicit plus/minus toggle opens generated children again.

## v1.1.10 — Cleanup Recovery + WordPress Cleanup UI
- Added Clean WP DB directly inside the WordPress Sync panel.
- WordPress panel now auto-refreshes while open and on window focus/visibility changes, so external cleanup/sync changes reflect without manual refresh.
- Cleanup now recovers missing color generator records from existing generated variable names before deleting stale/orphan rows.
- Cleanup now rebuilds recoverable generated variants after repair instead of leaving only base variables.
- Regeneration now repairs source_id, generator_type, type, and dependency links for existing generated rows.

## v1.1.9 — Generated Variable Repair + Live Pair Status

- Added deeper WordPress variable diagnostics: expected generated count, stale generated count, orphan generated count, duplicate name count, and older generator count.
- Clean WP DB now removes duplicate, orphan, and stale generated records, then reruns current active generators.
- WordPress panel footer now shows base/generated breakdown instead of a misleading single raw count.
- Sync panel now polls pairing status while open, so Figma file name updates without leaving and returning to the tab.

# Variable Engine Changelog

## 1.1.8
- WordPress panel now loads the deduped active variable list, so the footer count no longer shows old/raw database records.
- Keeps cleanup endpoints from v1.1.7 for removing stale duplicate/orphan rows when needed.
- Better Figma file name metadata handling via the companion plugin.

## v1.1.6 — Figma UX Stabilization

- Added `dedupe=true` support to the variables REST endpoint.
- Deduped flat sync exports by variable name so Figma shows/syncs the current variable set instead of counting duplicate legacy rows.
- Preserved raw DB records; dedupe is a safe read/export layer, not destructive cleanup.

## v1.1.5 — Stabilization Release

### Fixed
- Allowed paired Figma plugin requests using `X-VE-Key` to access Variable Engine read/write routes, not only sync routes.
- Fixed Figma connection checks that could fail because `/variables` and `/settings` still required browser-based WordPress permissions.
- Fixed Figma-side variable management routes so the companion plugin can list, create, and delete variables after pairing.
- Fixed Figma disconnect flow so API-key authenticated disconnect requests can reach WordPress.
- Improved sync log storage by saving both raw changes and a summary payload.
- Improved sync log output by returning parsed summaries instead of hiding the stored diff data.

### Notes
- This release focuses on stabilizing the existing MVP rather than adding new product surface area.
- Figma collection deletion sync still needs live testing inside Figma because it depends on Figma's plugin runtime behavior.

## 1.1.7
- Added variable database stats endpoint.
- Added cleanup endpoint for duplicate and orphan generated variable records.
- Cleanup regenerates the CSS export after removing stale rows.

## 1.1.13 - 2026-05-10
- Fixed numeric scale child ordering in the WordPress panel so generated scale tokens display from small to large.
- Changed numeric fluid-scale generated names to use the base token family/name instead of the storage category.
  - `size.space` now generates `space.20` / `--space-20`.
  - `size.heading` now generates `heading.58` / `--heading-58`.
  - `size.text` now generates `text.46` / `--text-46`.
  - `size.grid.gap` now generates `grid.gap.20` / `--grid-gap-20`.
- Clicking a base variable with generated children now opens/expands its generated list automatically.
- Existing generated values are still preserved inside `clamp()`; only token naming and panel ordering were improved.

## 1.1.12 - 2026-05-10
- Fixed numeric generator labels so generated tokens use rounded readable px suffixes such as `size.107`, not decimal-safe names like `font.107-29`.
- Fixed generated variable regeneration on base variable rename, not only value changes.
- Regeneration now removes old generated children for the same base/generator when their names no longer match the current base name or naming rule.
- Prevents renamed bases such as `font.space` → `size.space` from leaving old CSS variables like `--font-*` behind.

## 1.1.11 - 2026-05-10
- Added numeric dimension naming support for space, radius, heading, text, grid, font, and size tokens.
- Allows numeric dot segments such as `space.20`, `radius.8`, `heading.58`, `text.46`, and `grid.gap.20`.
- Normalizes numeric dimension values using the 10px rem system: `20` or `20px` becomes `2rem`.
- Fluid scale generation now uses numeric labels based on the desktop/max pixel value.
- Fluid scale rem output now uses `1rem = 10px` instead of browser-default `16px` conversion.
