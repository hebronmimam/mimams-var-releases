<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

class AdvancedCssManager {

    private const OPTION = 've_advanced_css';

    public function get(): array {
        $data = get_option( self::OPTION, [] );
        if ( ! is_array( $data ) ) {
            $data = [];
        }

        $sheets = $data['stylesheets'] ?? [];
        if ( ! is_array( $sheets ) || empty( $sheets ) ) {
            $sheets = $this->default_sheets();
        }

        return [
            'stylesheets' => array_values( array_map( [ $this, 'normalize_sheet' ], $sheets ) ),
            'file_url'    => $this->file_url(),
            'file_path'   => $this->file_path(),
        ];
    }

    public function save( array $sheets ): array {
        $clean = [];
        foreach ( $sheets as $sheet ) {
            if ( ! is_array( $sheet ) ) {
                continue;
            }
            $clean[] = $this->normalize_sheet( $sheet );
        }

        if ( empty( $clean ) ) {
            $clean = $this->default_sheets();
        }

        update_option( self::OPTION, [ 'stylesheets' => $clean ], false );
        $this->compile();

        return $this->get();
    }

    public function compile(): array {
        $data   = $this->get();
        $sheets = $data['stylesheets'];
        $lines  = [
            '/*',
            " * Mimam's Var - CSS Studio",
            ' * Version: ' . VE_VERSION,
            ' * Compiled: ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC',
            ' */',
            '',
        ];

        foreach ( $sheets as $sheet ) {
            if ( empty( $sheet['enabled'] ) || '' === trim( (string) $sheet['css'] ) ) {
                continue;
            }
            $lines[] = '/* === ' . $sheet['name'] . ' (' . $sheet['scope'] . ') === */';
            $lines[] = rtrim( (string) $sheet['css'] );
            $lines[] = '';
        }

        if ( ! is_dir( VE_CSS_OUTPUT_DIR ) ) {
            wp_mkdir_p( VE_CSS_OUTPUT_DIR );
        }

        $written = file_put_contents( $this->file_path(), implode( "\n", $lines ) );

        return [
            'compiled'  => false !== $written,
            'file_url'  => $this->file_url(),
            'file_path' => $this->file_path(),
        ];
    }

    private function normalize_sheet( array $sheet ): array {
        $id = sanitize_key( (string) ( $sheet['id'] ?? '' ) );
        if ( '' === $id ) {
            $id = 'sheet_' . substr( md5( wp_json_encode( $sheet ) . microtime( true ) ), 0, 8 );
        }

        $scope = sanitize_key( (string) ( $sheet['scope'] ?? 'global' ) );
        if ( ! in_array( $scope, [ 'page', 'global', 'child', 'custom', 'recipe' ], true ) ) {
            $scope = 'custom';
        }

        return [
            'id'      => $id,
            'name'    => sanitize_text_field( (string) ( $sheet['name'] ?? 'custom.css' ) ),
            'scope'   => $scope,
            'enabled' => ! isset( $sheet['enabled'] ) || ! empty( $sheet['enabled'] ),
            'css'     => wp_kses_post( (string) ( $sheet['css'] ?? '' ) ),
        ];
    }

    private function default_sheets(): array {
        return [
            [ 'id' => 'page', 'name' => 'page.css', 'scope' => 'page', 'enabled' => true, 'css' => '' ],
            [ 'id' => 'global', 'name' => 'global.css', 'scope' => 'global', 'enabled' => true, 'css' => '' ],
            [ 'id' => 'child', 'name' => 'child.css', 'scope' => 'child', 'enabled' => true, 'css' => '' ],
        ];
    }

    private function file_path(): string {
        return VE_CSS_OUTPUT_DIR . 'advanced.css';
    }

    private function file_url(): string {
        return VE_CSS_OUTPUT_URL . 'advanced.css';
    }
}
