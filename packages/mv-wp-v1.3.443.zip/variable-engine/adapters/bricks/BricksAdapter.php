<?php
namespace VE\Adapters;
defined('ABSPATH') || exit;

class BricksAdapter {
    public function __construct() {
        add_action('wp', [$this, 'init']);
        // Merge owner-defined custom tags into Bricks' HTML sanitiser allow-list.
        // Registered unconditionally (not gated by ?bricks=run) because Bricks
        // applies this filter on both the front end and inside the builder.
        add_filter('bricks/allowed_html_tags', [$this, 'allowed_html_tags']);
    }

    /**
     * @param mixed $allowed_tags Bricks passes an array of tag-name strings.
     * @return array
     */
    public function allowed_html_tags($allowed_tags): array {
        $allowed_tags = is_array($allowed_tags) ? $allowed_tags : (array) $allowed_tags;
        $custom = get_option('ve_bricks_custom_tags', []);
        if (!is_array($custom)) {
            $custom = [];
        }
        foreach ($custom as $tag) {
            $tag = strtolower(trim((string) $tag));
            $tag = preg_replace('/[^a-z0-9-]/', '', $tag);
            if ('' !== $tag && !in_array($tag, $allowed_tags, true)) {
                $allowed_tags[] = $tag;
            }
        }
        return $allowed_tags;
    }

    public function init(): void {
        if (!isset($_GET['bricks']) || $_GET['bricks'] !== 'run') return;
        ( new \VE\Adapters\Bricks\VariablesMirror() )->sync();
        add_action('wp_enqueue_scripts', [$this, 'enqueue'], 9999);
        add_action('wp_footer', [$this, 'min_canvas_runtime'], 100);
    }

    /**
     * #11 — Minimum canvas viewport for the Bricks builder.
     *
     * Widening the structure or right panel physically shrinks the canvas, so the page
     * starts laying out at a narrower viewport than intended. With this on, the canvas
     * keeps rendering at the configured width and is scaled down to fit instead — the
     * same idea as a builder's zoom control. Only a deliberate viewport change (the
     * Code2Bricks drag handle, or Bricks' device buttons) may set a smaller viewport.
     *
     * This targets Code2Bricks' own markup, so it is written defensively: if the
     * wrapper cannot be found nothing happens and a single console notice explains why.
     */
    public function min_canvas_runtime(): void {
        $settings = get_option('ve_min_canvas', []);
        if (!is_array($settings) || empty($settings['enabled'])) {
            return;
        }

        $config = wp_json_encode([
            'min'         => max(320, (int) ($settings['min'] ?? 1440)),
            'allowHandle' => !empty($settings['allow_handle']),
            'allowDevice' => !empty($settings['allow_device']),
            'showBadge'   => !empty($settings['show_badge']),
        ]);
        if (!$config) {
            return;
        }
        ?>
<script id="ve-min-canvas">
(function(){
  var cfg = <?php echo $config; ?>;
  var SEL = '.c2b-iframe-wrapper';
  function boot(tries){
    var wrap = document.querySelector(SEL);
    if (!wrap) {
      if (tries > 0) { return setTimeout(function(){ boot(tries - 1); }, 400); }
      // Code2Bricks owns this markup; say so plainly rather than failing silently.
      console.info('[Mimam\'s Var] Minimum canvas is on but ' + SEL + ' was not found — Code2Bricks may be inactive or may have renamed it. The setting is being ignored.');
      return;
    }
    var frame = wrap.querySelector('iframe') || document.getElementById('bricks-builder-iframe');
    if (!frame) { return; }

    var badge = null;
    if (cfg.showBadge) {
      badge = document.createElement('div');
      badge.className = 've-min-canvas-badge';
      badge.style.cssText = 'position:absolute;top:8px;left:8px;z-index:9;padding:2px 8px;border-radius:999px;font:700 10px/1.6 -apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:rgba(186,244,0,.16);color:#baf400;border:1px solid rgba(186,244,0,.34);pointer-events:none;display:none';
      if (getComputedStyle(wrap).position === 'static') { wrap.style.position = 'relative'; }
      wrap.appendChild(badge);
    }

    // A viewport deliberately chosen by the user (drag handle or device button) wins,
    // provided that source is allowed past the minimum.
    function deliberateWidth(){
      var w = parseInt(frame.style.width, 10);
      if (!w || !isFinite(w)) { return 0; }
      // Bricks/C2B set an explicit px width when a device or the handle is used.
      return w;
    }

    function apply(){
      var avail = wrap.clientWidth;
      if (!avail) { return; }
      var chosen = deliberateWidth();
      var exempt = cfg.allowHandle || cfg.allowDevice;
      var viewport = (chosen && exempt) ? chosen : Math.max(cfg.min, chosen || 0);
      if (!chosen) { viewport = cfg.min; }
      var scale = Math.min(1, avail / viewport);

      frame.style.width = viewport + 'px';
      frame.style.transformOrigin = 'top left';
      frame.style.transform = scale < 0.999 ? 'scale(' + scale + ')' : '';
      frame.style.height = scale < 0.999 ? (wrap.clientHeight / scale) + 'px' : '';

      if (badge) {
        var zoomed = scale < 0.999;
        badge.style.display = zoomed ? 'block' : 'none';
        badge.textContent = viewport + 'px · ' + Math.round(scale * 100) + '%';
      }
    }

    if (window.ResizeObserver) { new ResizeObserver(apply).observe(wrap); }
    window.addEventListener('resize', apply);
    apply();
  }
  if (document.readyState === 'loading') { document.addEventListener('DOMContentLoaded', function(){ boot(12); }); }
  else { boot(12); }
})();
</script>
        <?php
    }
    public function enqueue(): void {
        // All runtime vendor assets are bundled with the plugin, not loaded from a CDN, so
        // the builder works offline, under strict CSP, and on privacy-strict hosts. GSAP was
        // enqueued but never referenced by the panel; it has been removed.
        $ver = VE_VERSION;
        wp_enqueue_style('ve-ph', VE_URL.'assets/phosphor/style.css', [], $ver.'.'.filemtime(VE_DIR.'assets/phosphor/style.css'));
        wp_enqueue_style('ve-components', VE_URL.'assets/components.css', [], $ver.'.'.filemtime(VE_DIR.'assets/components.css'));
        // CodeMirror's editor CSS is pre-scoped to `.ve-cm-host` (codemirror.scoped.css), so it
        // styles only MV's own editors and never bleeds into — or gets neutralized against —
        // other plugins' code editors (Advanced Themer Style Manager, Code2Bricks Quick Import).
        wp_enqueue_style('ve-codemirror', VE_URL.'assets/vendor/codemirror/codemirror.scoped.css', [], '5.65.16');
        wp_enqueue_style('ve-codemirror-hint', VE_URL.'assets/vendor/codemirror/show-hint.css', ['ve-codemirror'], '5.65.16');
        wp_enqueue_script('ve-p', VE_URL.'assets/vendor/preact.umd.js', [], '10', true);
        wp_enqueue_script('ve-ph', VE_URL.'assets/vendor/preact-hooks.umd.js', ['ve-p'], '10', true);
        wp_enqueue_script('ve-codemirror', VE_URL.'assets/vendor/codemirror/codemirror.js', [], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-css', VE_URL.'assets/vendor/codemirror/mode-css.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-xml', VE_URL.'assets/vendor/codemirror/mode-xml.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-javascript', VE_URL.'assets/vendor/codemirror/mode-javascript.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-htmlmixed', VE_URL.'assets/vendor/codemirror/mode-htmlmixed.js', ['ve-codemirror-xml','ve-codemirror-javascript','ve-codemirror-css'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-closebrackets', VE_URL.'assets/vendor/codemirror/closebrackets.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-hint', VE_URL.'assets/vendor/codemirror/show-hint.js', ['ve-codemirror'], '5.65.16', true);
        $app_dependencies = array_merge(
            ['ve-p','ve-ph','ve-codemirror-htmlmixed','ve-codemirror-closebrackets','ve-codemirror-hint'],
            \VE\Core\RankMathAnalysisBridge::enqueue()
        );
        wp_enqueue_script('ve-app', VE_URL.'assets/js/builder-panel.js', $app_dependencies, $ver.'.'.filemtime(VE_DIR.'assets/js/builder-panel.js'), true);
        $preferences = get_user_meta( get_current_user_id(), 've_user_preferences', true );
        wp_localize_script('ve-app', 'vePanel', ['apiRoot'=>esc_url_raw(rest_url()),'ajaxUrl'=>esc_url_raw(admin_url('admin-ajax.php')),'nonce'=>wp_create_nonce('wp_rest'),'version'=>VE_VERSION,'mode'=>'builder','siteTitle'=>sanitize_text_field(get_bloginfo('name')),'logoUrl'=>esc_url_raw(VE_URL.'assets/hebronmimam-logo-icon.png'),'assetUrl'=>esc_url_raw(VE_URL.'assets/'),'fontToolsScript'=>esc_url_raw(VE_URL.'assets/vendor/fonteditor-core/fonteditor-core.iife.js'),'fontToolsWasm'=>esc_url_raw(VE_URL.'assets/vendor/fonteditor-core/woff2.wasm'),'newPostDefaults'=>['comment_status'=>get_option('default_comment_status')?:'open','ping_status'=>get_option('default_ping_status')?:'open'],'userPreferences'=>is_array($preferences)?$preferences:[]]);
        if (class_exists('\VE\Modules\BuilderTools\MimamsBarModule')) {
            (new \VE\Modules\BuilderTools\MimamsBarModule())->enqueue('builder');
        }
    }
}
