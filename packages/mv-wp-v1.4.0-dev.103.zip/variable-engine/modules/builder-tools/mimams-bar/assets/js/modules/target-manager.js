(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarTargetManager) return;

  function refresh(app, options) {
    if (!app || !app.target) return;
    options = options || {};
    var element = app.adapter.getSelectedElement();
    var nextId = element && element.id ? String(element.id) : '';

    /* Editing a class makes Bricks rebuild the element, and for a frame or two
       in the middle of that the selection reads as nothing at all. Taking that
       at face value emptied the class and attribute rows, which then refilled
       themselves a moment later with exactly what had been there — the flicker
       in the report. A selection that has just gone empty is treated as "not
       settled yet": the rows are left alone and looked at again shortly. Only a
       re-check that still finds nothing clears them, so a real deselection
       still empties the bar. */
    if (!element && app._lastKnownTargetId && !options.settled) {
      if (app._targetSettleTimer) window.clearTimeout(app._targetSettleTimer);
      app._targetSettleTimer = window.setTimeout(function () {
        app._targetSettleTimer = null;
        refresh(app, { settled: true });
      }, 140);
      return;
    }
    if (app._targetSettleTimer) {
      window.clearTimeout(app._targetSettleTimer);
      app._targetSettleTimer = null;
    }

    if (options.light && nextId === app._lastKnownTargetId) return;
    app._lastKnownTargetId = nextId;

    app.target.textContent = app.adapter.getElementLabel(element);
    app.target.setAttribute('title', app.adapter.getElementFullLabel(element));
    app.target.classList.toggle('is-empty', !element);
    renderIdentity(app, element);
    renderExistingAttributes(app, element);
  }

  function renderIdentity(app, element) {
    app.renderer.renderIdentity(app.identityList, element, app.adapter, {
      loadTextCommand: app.loadTextCommand.bind(app),
      deleteClass: function (className) {
        var parseResult = app.parser.parse('-' + className);
        if (parseResult.ok) {
          app.applyOperations(parseResult.ops || parseResult.attrs);
        }
      },
      renameClass: function (oldName, newName) {
        if (!newName || newName === oldName) return;
        var parseResult = app.parser.parse('.' + oldName + ' -> .' + newName);
        if (parseResult.ok) {
          app._pendingTokenFocus = { kind: 'class', key: newName };
          app.applyOperations(parseResult.ops || parseResult.attrs);
        }
      },
      duplicateClass: function (className) {
        if (!app.adapter || typeof app.adapter.duplicateGlobalClass !== 'function') return;
        var newName = app.adapter.duplicateGlobalClass(className);
        if (!newName) return;
        // Add the cloned class (styles copied) to the current element; the refresh renders
        // its chip so it's there to rename/edit.
        var parseResult = app.parser.parse('.' + newName);
        if (parseResult.ok) {
          app.applyOperations(parseResult.ops || parseResult.attrs);
        }
      },
      setId: function (newId) {
        if (!newId) return;
        var parseResult = app.parser.parse('#' + newId);
        if (parseResult.ok) {
          app._pendingTokenFocus = { kind: 'id', key: newId };
          app.applyOperations(parseResult.ops || parseResult.attrs);
        }
      },
      clearId: function () {
        app.applyOperations([ { type: 'set-id', value: '' } ]);
      }
    });
  }

  function toggleAttributesPanel(app) {
    app.attrsExpanded = !app.attrsExpanded;
    updateAttributesPanelState(app);
  }

  function updateAttributesPanelState(app) {
    if (!app.existingBox) return;
    app.existingBox.classList.toggle('is-collapsed', !app.attrsExpanded);
    if (app.attrToggleLabel) app.attrToggleLabel.textContent = app.attrsExpanded ? 'Hide' : 'Show';
  }

  function renderExistingAttributes(app, element) {
    if (!app.attrList) return;

    var result = app.renderer.renderExistingAttributes({
      list: app.attrList,
      element: element,
      adapter: app.adapter,
      callbacks: {
        loadAttributeCommand: app.loadAttributeCommand.bind(app),
        deleteAttribute: function (attr) {
          var command = 'delete ' + attr.name;
          var parseResult = app.parser.parse(command);
          if (parseResult.ok) {
            app.applyOperations(parseResult.ops || parseResult.attrs);
          }
        },
        editAttribute: function (attr, newValue) {
          var esc = String(newValue == null ? '' : newValue).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
          var command = attr.name + '="' + esc + '"';
          var parseResult = app.parser.parse(command);
          if (parseResult.ok) {
            app._pendingTokenFocus = { kind: 'attribute', key: attr.name };
            app.applyOperations(parseResult.ops || parseResult.attrs);
          }
        },
        toggleSavedAttribute: function (attr, star) {
          var manager = app.savedAttributes || window.MimamsBarSavedAttributes;
          if (!manager || typeof manager.toggle !== 'function') return;
          var wasSaved = typeof manager.isSaved === 'function' && manager.isSaved(attr.name);
          manager.toggle(attr.name, attr.value).then(function () {
            if (star && star.classList) {
              star.classList.toggle('is-saved', !wasSaved);
              star.setAttribute('title', wasSaved ? 'Save this attribute and value' : 'Remove from saved attributes');
            }
            if (app.toast && typeof app.toast.show === 'function') {
              app.toast.show(attr.name + (wasSaved ? ' removed from saved attributes.' : ' saved for this site.'));
            }
          }).catch(function (error) {
            if (app.toast && typeof app.toast.show === 'function') {
              app.toast.show(error && error.message ? error.message : 'Saved attributes could not be updated.', 'error');
            }
          });
        }
      }
    });

    if (app.attrCount) app.attrCount.textContent = String((result && result.count) || 0);
    if (result && result.collapse) app.attrsExpanded = false;
    updateAttributesPanelState(app);
  }

  function scheduleRefresh(app) {
    if (!app) return;

    // v1.2.48: keep refreshes light while the bar is open. The old flow
    // scheduled three separate refresh passes for every canvas click, which
    // could stack up in Bricks and make the builder feel frozen.
    if (app._targetRefreshTimer) {
      window.clearTimeout(app._targetRefreshTimer);
    }

    app._targetRefreshTimer = window.setTimeout(function () {
      app._targetRefreshTimer = null;
      refresh(app, { light: true });
    }, 260);
  }

  /* R39: "I added that to the element and it added, but I have to close and open
     before it shows on the bar."

     applyOperations() calls refresh() the instant applyAttributes() returns, and
     Bricks has not written the change into its model yet - its Vue state settles
     a tick or two later. So the chips were rendered from the element as it was
     BEFORE the class was added: correct data, read one moment too early. Closing
     and reopening read it again, by which time it was there.

     The file already handles the neighbouring race - a selection that briefly
     reads as nothing during the rebuild - with a settle timer. This is the same
     idea keyed on the same expectation the owner has: the class they just asked
     for is either on the element or it is not.

     It waits for the thing it is waiting for rather than for a guessed number of
     milliseconds, and it gives up after about a second and renders whatever is
     there - an apply that silently failed must not leave the bar spinning. */
  function expectationsOf(ops) {
    var added = [];
    var removed = [];
    (ops || []).forEach(function (op) {
      if (!op) return;
      if (op.type === 'add-class' && op.name) added.push(String(op.name));
      else if (op.type === 'remove-class' && op.name) removed.push(String(op.name));
      else if (op.type === 'rename-class' && op.to) {
        added.push(String(op.to));
        if (op.from) removed.push(String(op.from));
      }
    });
    return { added: added, removed: removed };
  }

  function agrees(app, want) {
    if (!want.added.length && !want.removed.length) return true;
    var element = app.adapter.getSelectedElement();
    if (!element) return false;
    var now = app.adapter.getElementClasses(element) || [];
    var has = function (name) {
      return now.some(function (c) { return String(c) === name; });
    };
    return want.added.every(has) && !want.removed.some(has);
  }

  function refreshAfterApply(app, ops) {
    if (!app || !app.target) return;
    var want = expectationsOf(ops);
    var waits = [ 0, 60, 120, 240, 480 ];
    var at = 0;

    if (app._applySettleTimer) {
      window.clearTimeout(app._applySettleTimer);
      app._applySettleTimer = null;
    }

    var step = function () {
      app._applySettleTimer = null;
      refresh(app);
      if (agrees(app, want) || at >= waits.length) return;
      var delay = waits[at];
      at += 1;
      app._applySettleTimer = window.setTimeout(step, delay);
    };
    step();
  }

  window.MimamsBarTargetManager = {
    refresh: refresh,
    refreshAfterApply: refreshAfterApply,
    renderIdentity: renderIdentity,
    renderExistingAttributes: renderExistingAttributes,
    toggleAttributesPanel: toggleAttributesPanel,
    updateAttributesPanelState: updateAttributesPanelState,
    scheduleRefresh: scheduleRefresh
  };
})();
