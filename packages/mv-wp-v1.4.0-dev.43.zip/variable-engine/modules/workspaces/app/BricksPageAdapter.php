<?php
/**
 * Bricks pages and templates, shadowed as their own posts.
 *
 * Slice 2 of the Workspaces module, and the first that touches Bricks at all.
 *
 * WHY THIS IS THE SAFE PLACE TO START
 *
 * `BRICKS-WORKSPACE-STORAGE-AUDIT.md` established that Bricks keeps page and
 * template payloads in POST META, one set per post:
 *
 *     _bricks_page_content_2     _bricks_page_settings
 *     _bricks_page_header_2      _bricks_template_settings   (incl. conditions)
 *     _bricks_page_footer_2      _bricks_template_type
 *
 * Post meta is per-object, so a shadow is simply a different post. Bricks writes
 * to the post ID it was opened with — `Ajax::save_post()` reads `$_POST['postId']`
 * and calls `update_post_meta( $post_id, ... )` — so a save inside a workspace
 * lands on the shadow whether or not MV is running. Nothing has to be
 * intercepted, and there is no hook to fail closed with because none is needed.
 *
 * That is handoff §100.1.a: STRUCTURAL isolation. It is the only class this
 * adapter may claim, and it claims it for pages and templates only.
 *
 * WHAT THIS FILE MUST NEVER DO
 *
 *   - write to the live post, its meta, or its status;
 *   - touch any `bricks_*` site option (those are runtime-class, slices 7-9);
 *   - publish, apply or roll anything back.
 *
 * A shadow is created as a DRAFT. That is deliberate and load-bearing: WordPress
 * core excludes drafts from public queries with no help from MV, so the isolation
 * survives MV being deactivated or deleted, which is what §102 requires. It is
 * not MV hiding the post; it is the post genuinely not being published.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class BricksPageAdapter {

    /** The post meta a Bricks page or template owns. Audit section 2. */
    public const META = [
        '_bricks_page_content_2',
        '_bricks_page_header_2',
        '_bricks_page_footer_2',
        '_bricks_page_settings',
        '_bricks_template_settings',
        '_bricks_template_type',
        '_bricks_editor_mode',
    ];

    /** Marks a post as MV's, so it can be recognised without consulting the map. */
    public const SHADOW_FLAG      = '_ve_workspace_shadow';
    public const SHADOW_WORKSPACE = '_ve_workspace_id';
    public const SHADOW_SOURCE    = '_ve_workspace_source_id';

    public const TEMPLATE_POST_TYPE = 'bricks_template';

    /**
     * Is this post something a workspace can shadow?
     *
     * Bricks stores its payload in `_bricks_page_content_2`, so a post without
     * it was not built with Bricks and copying it would produce an empty shadow
     * that looks broken rather than a refusal that explains itself.
     */
    public static function is_bricks_post( int $post_id ): bool {
        if ( $post_id <= 0 || ! get_post( $post_id ) ) {
            return false;
        }
        $content = get_post_meta( $post_id, '_bricks_page_content_2', true );
        return ! empty( $content );
    }

    /**
     * Create the shadow.
     *
     * The live post is READ here and never written. Everything this method
     * changes belongs to a post that did not exist when it was called.
     *
     * @return array|\WP_Error The workspace object row.
     */
    public static function create_shadow( int $workspace_id, int $live_id ) {
        $workspace = WorkspaceStore::get( $workspace_id );
        if ( ! $workspace ) {
            return self::error( 've_workspace_missing', 'That workspace no longer exists.' );
        }
        if ( WorkspaceStore::STATUS_ARCHIVED === $workspace['status'] ) {
            return self::error( 've_workspace_archived', 'Bring the workspace back before adding pages to it.' );
        }

        $live = get_post( $live_id );
        if ( ! $live ) {
            return self::error( 've_live_missing', 'That page does not exist.' );
        }
        if ( ! self::is_bricks_post( $live_id ) ) {
            return self::error(
                've_not_bricks',
                'That page was not built with Bricks, so there is nothing for a workspace to hold yet.'
            );
        }
        if ( WorkspaceObjectMap::find( $workspace_id, $live_id ) ) {
            return self::error( 've_object_already_added', 'That page is already in this workspace.' );
        }

        // A draft, owned by nobody's menu and no public query. Not MV hiding it.
        $shadow_id = wp_insert_post(
            [
                'post_title'   => self::shadow_title( $live->post_title, $workspace['name'] ),
                'post_name'    => '',
                'post_type'    => $live->post_type,
                'post_status'  => 'draft',
                'post_content' => $live->post_content,
                'post_excerpt' => $live->post_excerpt,
                'post_parent'  => (int) $live->post_parent,
                'post_author'  => get_current_user_id() ? get_current_user_id() : (int) $live->post_author,
                'menu_order'   => (int) $live->menu_order,
                'comment_status' => 'closed',
                'ping_status'    => 'closed',
            ],
            true
        );

        if ( is_wp_error( $shadow_id ) || ! $shadow_id ) {
            return self::error( 've_shadow_not_created', 'The workspace copy could not be created.' );
        }
        $shadow_id = (int) $shadow_id;

        // Copy the Bricks payload across. update_post_meta on the SHADOW only.
        foreach ( self::META as $key ) {
            $value = get_post_meta( $live_id, $key, true );
            if ( '' === $value || null === $value || [] === $value ) {
                continue;
            }
            update_post_meta( $shadow_id, $key, $value );
        }

        // And the marks that make it recognisable without a database lookup.
        update_post_meta( $shadow_id, self::SHADOW_FLAG, '1' );
        update_post_meta( $shadow_id, self::SHADOW_WORKSPACE, $workspace_id );
        update_post_meta( $shadow_id, self::SHADOW_SOURCE, $live_id );

        $object = WorkspaceObjectMap::add( $workspace_id, [
            'object_type' => self::TEMPLATE_POST_TYPE === $live->post_type ? 'bricks_template' : 'bricks_page',
            'adapter'     => 'bricks_page',
            'isolation'   => WorkspaceObjectMap::ISO_STRUCTURAL,
            'label'       => (string) $live->post_title,
            'live_id'     => $live_id,
            'shadow_id'   => $shadow_id,
            'state'       => WorkspaceObjectMap::STATE_UNCHANGED,
        ] );

        if ( is_wp_error( $object ) || ( is_array( $object ) && isset( $object['error'] ) ) ) {
            // The map is the record of truth. A shadow it does not know about is
            // an orphan, so remove it rather than leave one behind (§57).
            wp_delete_post( $shadow_id, true );
            return $object;
        }

        return $object;
    }

    /**
     * Remove an object from a workspace, and its shadow with it.
     *
     * The live post is untouched. Removing a page from a workspace is not a
     * rollback and not a deletion of anything published.
     *
     * @return true|\WP_Error
     */
    public static function remove_shadow( int $object_id ) {
        $object = WorkspaceObjectMap::get( $object_id );
        if ( ! $object ) {
            return self::error( 've_object_missing', 'That object is no longer in the workspace.' );
        }

        if ( $object['shadow_id'] ) {
            // Guard: only ever delete a post MV made. If the flag is absent, the
            // id is pointing at something MV does not own and deleting it would
            // be destroying a real page.
            $flag = get_post_meta( $object['shadow_id'], self::SHADOW_FLAG, true );
            if ( '1' === (string) $flag ) {
                wp_delete_post( $object['shadow_id'], true );
            }
        }

        return WorkspaceObjectMap::remove( $object_id );
    }

    /** Every shadow a workspace owns, removed together. */
    public static function remove_all( int $workspace_id ): int {
        $removed = 0;
        foreach ( WorkspaceObjectMap::all( $workspace_id ) as $object ) {
            if ( true === self::remove_shadow( $object['id'] ) ) {
                $removed++;
            }
        }
        return $removed;
    }

    /**
     * Where Bricks should open this object.
     *
     * Bricks' own `Helpers::get_builder_edit_link()` is `get_permalink( $id )`
     * plus `?bricks=run`. The whole of this slice's isolation rests on which id
     * goes in: the SHADOW's. Composed here rather than called from Bricks so the
     * adapter cannot accidentally be handed the live id by a caller that meant
     * well.
     *
     * @return string|\WP_Error
     */
    public static function builder_url( int $object_id ) {
        $object = WorkspaceObjectMap::get( $object_id );
        if ( ! $object ) {
            return self::error( 've_object_missing', 'That object is no longer in the workspace.' );
        }
        if ( ! $object['shadow_id'] ) {
            return self::error( 've_no_shadow', 'That object has no workspace copy to open.' );
        }

        $url = get_permalink( $object['shadow_id'] );
        if ( ! $url ) {
            return self::error( 've_no_permalink', 'WordPress could not produce a link for the workspace copy.' );
        }

        $param = defined( 'BRICKS_BUILDER_PARAM' ) ? BRICKS_BUILDER_PARAM : 'bricks';
        return add_query_arg( $param, 'run', $url );
    }

    /**
     * Bricks posts on this site that a workspace could take, minus the ones it
     * already has, minus every shadow. A shadow appearing in this list would let
     * someone shadow a shadow.
     */
    public static function candidates( int $workspace_id, string $search = '', int $limit = 40 ): array {
        $taken = [];
        foreach ( WorkspaceObjectMap::all( $workspace_id ) as $object ) {
            if ( $object['live_id'] ) {
                $taken[] = $object['live_id'];
            }
        }

        $args = [
            'post_type'      => self::post_types(),
            'post_status'    => [ 'publish', 'draft', 'private' ],
            'posts_per_page' => $limit,
            'orderby'        => 'title',
            'order'          => 'ASC',
            'post__not_in'   => $taken,
            'meta_query'     => [
                'relation' => 'AND',
                [ 'key' => '_bricks_page_content_2', 'compare' => 'EXISTS' ],
                [ 'key' => self::SHADOW_FLAG, 'compare' => 'NOT EXISTS' ],
            ],
            'fields'         => 'ids',
            'no_found_rows'  => true,
        ];
        if ( '' !== $search ) {
            $args['s'] = $search;
        }

        $out = [];
        foreach ( get_posts( $args ) as $id ) {
            $post = get_post( $id );
            if ( ! $post ) {
                continue;
            }
            $out[] = [
                'id'     => (int) $id,
                'title'  => (string) $post->post_title,
                'type'   => (string) $post->post_type,
                'status' => (string) $post->post_status,
            ];
        }
        return $out;
    }

    /** Post types Bricks can build. Templates included; attachments never. */
    public static function post_types(): array {
        $types = [ 'page', 'post', self::TEMPLATE_POST_TYPE ];
        if ( class_exists( '\Bricks\Helpers' ) && method_exists( '\Bricks\Helpers', 'get_supported_post_types' ) ) {
            $supported = \Bricks\Helpers::get_supported_post_types();
            if ( is_array( $supported ) && $supported ) {
                $types = array_values( array_unique( array_merge( array_keys( $supported ), [ self::TEMPLATE_POST_TYPE ] ) ) );
            }
        }
        return $types;
    }

    /**
     * A title that reads as what it is in the Pages list, where the shadow will
     * be visible to any administrator. Being findable and obviously MV's is
     * better than being hidden and mysterious.
     */
    public static function shadow_title( string $live_title, string $workspace_name ): string {
        $title = trim( $live_title ) !== '' ? trim( $live_title ) : 'Untitled';
        return $title . ' — ' . $workspace_name . ' (workspace copy)';
    }

    /** @return \WP_Error|array */
    private static function error( string $code, string $message ) {
        if ( class_exists( '\WP_Error' ) ) {
            return new \WP_Error( $code, $message, [ 'status' => 400 ] );
        }
        return [ 'error' => $code, 'message' => $message ];
    }
}
