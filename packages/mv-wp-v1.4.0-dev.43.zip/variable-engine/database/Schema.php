<?php

namespace VE\Database;

defined( 'ABSPATH' ) || exit;

class Schema {

    /**
     * Return the full SQL for all tables.
     * Uses $wpdb->prefix so it works on any WP install.
     *
     * Note on `ve_color_palettes`: it stores THEMES (value layers), not colour
     * palettes. The name is historical (v1.3.05) and was never migrated. Colour
     * palettes live in the `color_palettes` tables, owned by ColorPaletteManager.
     * See core/ThemeManager.php.
     *
     * That note used to sit INSIDE the SQL string as a `//` comment, immediately
     * above `CREATE TABLE ve_css_versions`. dbDelta() splits this string on `;`
     * and hands each chunk to $wpdb->query() verbatim, so the comment travelled
     * into the same chunk as that CREATE TABLE. MySQL has no `//` comment syntax
     * — it accepts `#`, `-- ` and `/* *​/` — so the statement was a syntax error
     * and `ve_css_versions` was never created on a fresh install. Existing sites
     * were unaffected because they created the table before the comment was
     * added. Keep prose out of this string.
     */
    public static function get_sql(): string {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $p       = $wpdb->prefix;

        return "
CREATE TABLE {$p}ve_variables (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name        VARCHAR(255)    NOT NULL,
    type        ENUM('base','generated','alias') NOT NULL DEFAULT 'base',
    namespace   VARCHAR(64)     NOT NULL DEFAULT '',
    category_slug VARCHAR(191)  NOT NULL DEFAULT 'uncategorized',
    origin      VARCHAR(32)     NOT NULL DEFAULT '',
    value       TEXT            NOT NULL DEFAULT '',
    css_value   TEXT            NOT NULL DEFAULT '',
    source_id   BIGINT UNSIGNED DEFAULT NULL,
    generator_type VARCHAR(64) DEFAULT NULL,
    position    INT UNSIGNED    NOT NULL DEFAULT 0,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY name (name),
    KEY namespace (namespace),
    KEY category_slug (category_slug),
    KEY origin (origin),
    KEY type (type),
    KEY source_id (source_id),
    KEY position (position)
) {$charset};

CREATE TABLE {$p}ve_variable_categories (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    slug        VARCHAR(191)    NOT NULL,
    name        VARCHAR(255)    NOT NULL,
    position    INT UNSIGNED    NOT NULL DEFAULT 0,
    protected   TINYINT(1)      NOT NULL DEFAULT 0,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY slug (slug),
    KEY position (position)
) {$charset};

CREATE TABLE {$p}ve_generators (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    variable_id BIGINT UNSIGNED NOT NULL,
    type        VARCHAR(64)     NOT NULL,
    config      LONGTEXT        NOT NULL DEFAULT '{}',
    active      TINYINT(1)      NOT NULL DEFAULT 1,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY variable_id (variable_id)
) {$charset};

CREATE TABLE {$p}ve_dependencies (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    parent_id   BIGINT UNSIGNED NOT NULL,
    child_id    BIGINT UNSIGNED NOT NULL,
    relation    ENUM('generated','alias') NOT NULL,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY parent_child (parent_id, child_id),
    KEY child_id (child_id)
) {$charset};

CREATE TABLE {$p}ve_sync_logs (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    source      VARCHAR(32)     NOT NULL DEFAULT 'wordpress',
    author      VARCHAR(255)    NOT NULL DEFAULT '',
    diff        LONGTEXT        NOT NULL DEFAULT '[]',
    snapshot_id BIGINT UNSIGNED DEFAULT NULL,
    synced_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY snapshot_id (snapshot_id)
) {$charset};

CREATE TABLE {$p}ve_snapshots (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    variables_state LONGTEXT        NOT NULL,
    trigger_type    VARCHAR(32)     NOT NULL DEFAULT 'manual',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) {$charset};

CREATE TABLE {$p}ve_css_versions (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    sheet_id    VARCHAR(64)     NOT NULL,
    sheet_name  VARCHAR(191)    NOT NULL DEFAULT '',
    scope       VARCHAR(32)     NOT NULL DEFAULT 'custom',
    css         LONGTEXT        NOT NULL,
    bytes       INT UNSIGNED    NOT NULL DEFAULT 0,
    note        VARCHAR(191)    NOT NULL DEFAULT '',
    created_by  BIGINT UNSIGNED DEFAULT NULL,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY sheet_id (sheet_id, id),
    KEY created_at (created_at)
) {$charset};

CREATE TABLE {$p}ve_color_palettes (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    slug        VARCHAR(191)    NOT NULL,
    name        VARCHAR(255)    NOT NULL,
    position    INT UNSIGNED    NOT NULL DEFAULT 0,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY slug (slug),
    KEY position (position)
) {$charset};

CREATE TABLE {$p}ve_color_palette_members (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    palette_id  BIGINT UNSIGNED NOT NULL,
    variable_id BIGINT UNSIGNED NOT NULL,
    position    INT UNSIGNED    NOT NULL DEFAULT 0,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY variable_id (variable_id),
    KEY palette_id (palette_id),
    KEY position (position)
) {$charset};

CREATE TABLE {$p}ve_workspaces (
    id            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    uuid          VARCHAR(36)     NOT NULL,
    name          VARCHAR(191)    NOT NULL,
    status        VARCHAR(16)     NOT NULL DEFAULT 'draft',
    base_source   VARCHAR(64)     NOT NULL DEFAULT 'live',
    base_taken_at DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    created_by    BIGINT UNSIGNED DEFAULT NULL,
    created_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    archived_at   DATETIME        DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uuid (uuid),
    KEY status (status, updated_at)
) {$charset};

CREATE TABLE {$p}ve_workspace_objects (
    id             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    workspace_id   BIGINT UNSIGNED NOT NULL,
    object_uuid    VARCHAR(36)     NOT NULL,
    object_type    VARCHAR(64)     NOT NULL DEFAULT 'bricks_page',
    adapter        VARCHAR(64)     NOT NULL DEFAULT 'bricks_page',
    isolation      VARCHAR(16)     NOT NULL DEFAULT 'structural',
    label          VARCHAR(191)    NOT NULL DEFAULT '',
    live_id        BIGINT UNSIGNED DEFAULT NULL,
    shadow_id      BIGINT UNSIGNED DEFAULT NULL,
    base_hash      VARCHAR(64)     NOT NULL DEFAULT '',
    workspace_hash VARCHAR(64)     NOT NULL DEFAULT '',
    live_hash      VARCHAR(64)     NOT NULL DEFAULT '',
    state          VARCHAR(16)     NOT NULL DEFAULT 'unchanged',
    created_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at     DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY object_uuid (object_uuid),
    KEY workspace_id (workspace_id, object_type),
    KEY shadow_id (shadow_id),
    KEY live_id (live_id)
) {$charset};
        ";
    }

    /** Table name helpers. */
    public static function table( string $name ): string {
        global $wpdb;
        return $wpdb->prefix . 've_' . $name;
    }
}
