<?php
/**
 * Workspaces module registrar.
 *
 * Direction C ("The Desk") from
 * docs/mocks/tools/2026-09-04-workspaces-desk.html, built against
 * docs/MV-Workspace-First-Release-Deploy-Handoff-v5.md (v6) and
 * docs/BRICKS-WORKSPACE-STORAGE-AUDIT.md.
 *
 * SLICE 3 — the record, structural shadows, and a private preview of one.
 *
 * What this ships: a workspace exists, is named, and is dated against the Live
 * state it started from. It can hold Bricks pages and templates, each shadowed
 * as its own private post that Bricks edits in place of the live one.
 *
 * What this deliberately does NOT ship, and why it is still safe:
 *   - no `bricks_*` site option is read or written, so global classes,
 *     variables and theme styles are untouched and NOT isolated;
 *   - no publish, no release, no rollback;
 *   - no runtime resolver: a preview resolves a STRUCTURAL object to its shadow
 *     and nothing else, because runtime families have no workspace state yet.
 *
 * The preview added in slice 3 needs a valid token AND a user who could have
 * edited the object anyway. §18 allows that: a shareable link for logged-out
 * reviewers "is not required for the first technical proof". It makes "public
 * visitors receive Live state" true by construction rather than by a rule that
 * has to be got right, and a leaked link is worth nothing on its own.
 *
 * The live post is read when a shadow is created and never written. The shadow
 * is a WordPress draft, which WordPress itself keeps out of public queries with
 * no help from MV - so the isolation survives MV being deactivated or deleted,
 * as §102 requires. That is §100.1.a structural isolation, and it is the only
 * class this slice may claim.
 *
 * Registration mirrors MimamsBarModule and RecoveryModule: the file is inert
 * until variable-engine.php calls init(), and it self-gates on capability.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspacesModule {

    public const VERSION = '0.3.0-slice3';

    /** Ordered load list — dependencies first. */
    private const FILES = [
        'app/WorkspaceStore.php',
        'app/WorkspaceObjectMap.php',
        'app/BricksPageAdapter.php',
        'app/WorkspacePreview.php',
        'app/WorkspacesController.php',
    ];

    /** @var bool */
    private static $booted = false;

    /**
     * @param \VE\API\Routes|null $routes Passed so the module reuses MV's
     *                                    existing permission callbacks rather
     *                                    than inventing a second model.
     */
    public static function init( $routes = null ): void {
        if ( self::$booted ) {
            return;
        }
        self::$booted = true;

        $dir = __DIR__ . '/';
        foreach ( self::FILES as $file ) {
            $path = $dir . $file;
            if ( is_readable( $path ) ) {
                require_once $path;
            }
        }

        if ( ! class_exists( __NAMESPACE__ . '\WorkspacesController' ) ) {
            return;
        }

        ( new WorkspacesController( $routes ) )->register();
    }

    /**
     * Whether the module is switched off in MV settings, mirroring how the other
     * modules gate themselves. Unknown settings shape means "on" — a module that
     * disappears because an option was reshaped is worse than one that stays.
     */
    public static function is_disabled(): bool {
        $settings = get_option( 've_settings', [] );
        if ( ! is_array( $settings ) ) {
            return false;
        }
        $off = isset( $settings['deactivated_tools'] ) ? $settings['deactivated_tools'] : [];
        return is_array( $off ) && in_array( 'workspaces', $off, true );
    }
}
