<?php

namespace VE\Modules\Recovery\Admin;

use VE\Modules\Recovery\Agency\AgencyDashboard;
use VE\Modules\Recovery\Backup\PackageBuilder;
use VE\Modules\Recovery\Backup\PackageValidator;
use VE\Modules\Recovery\Backup\SnapshotJob;
use VE\Modules\Recovery\Backup\SnapshotManager;
use VE\Modules\Recovery\Database\Schema;
use VE\Modules\Recovery\Emergency\EmergencyRecovery;
use VE\Modules\Recovery\Jobs\JobStore;
use VE\Modules\Recovery\Restore\RollbackManager;
use VE\Modules\Recovery\Restore\RollbackExecutor;
use VE\Modules\Recovery\Restore\RestoreDryRun;
use VE\Modules\Recovery\Restore\RestorePreparation;
use VE\Modules\Recovery\Restore\RestorePreview;
use VE\Modules\Recovery\Restore\RestoreReadiness;
use VE\Modules\Recovery\Restore\RestoreVerifier;
use VE\Modules\Recovery\Restore\StagingRestoreExecutor;
use VE\Modules\Recovery\Restore\ProductionRestoreExecutor;
use VE\Modules\Recovery\Restore\RankMathConfigGuard;
use VE\Modules\Recovery\Schedule\ScheduleManager;
use VE\Modules\Recovery\Security\Capability;
use VE\Modules\Recovery\Security\SecurityAudit;
use VE\Modules\Recovery\Security\ProductionReadiness;
use VE\Modules\Recovery\Storage\LocalStorage;
use VE\Modules\Recovery\Storage\RemoteStorageManager;
use VE\Modules\Recovery\Utils\Logger;
use VE\Modules\Recovery\WooCommerce\WooSafety;
use VE\Modules\Recovery\Workflow\MigrationPlanner;
use VE\Modules\Recovery\Workflow\MigrationImporter;
use VE\Modules\Recovery\Workflow\StagingCloneBuilder;
use VE\Modules\Recovery\Workflow\StagingWorkflow;

defined( 'ABSPATH' ) || exit;

final class AdminPage {
    public function register(): void {
        add_action( 'admin_bar_menu', [ $this, 'add_admin_bar_button' ], 999 );
        add_action( 'admin_enqueue_scripts', [ $this, 'enqueue_assets' ] );
        add_action( 'admin_notices', [ $this, 'render_restore_outcome_notice' ] );
        add_action( 'admin_footer', [ $this, 'render_floating_panel' ] );
        add_action( 'admin_post_restorebase_download_package', [ $this, 'download_package' ] );

        add_action( 'wp_ajax_restorebase_status', [ $this, 'ajax_status' ] );
        add_action( 'wp_ajax_restorebase_snapshots', [ $this, 'ajax_snapshots' ] );
        add_action( 'wp_ajax_restorebase_jobs', [ $this, 'ajax_jobs' ] );
        add_action( 'wp_ajax_restorebase_create_snapshot', [ $this, 'ajax_create_snapshot' ] );
        add_action( 'wp_ajax_restorebase_create_package', [ $this, 'ajax_create_package' ] );
        add_action( 'wp_ajax_restorebase_save_backup_options', [ $this, 'ajax_save_backup_options' ] );
        add_action( 'wp_ajax_restorebase_begin_package', [ $this, 'ajax_begin_package' ] );
        add_action( 'wp_ajax_restorebase_run_package_job', [ $this, 'ajax_run_package_job' ] );
        add_action( 'wp_ajax_restorebase_package_job_status', [ $this, 'ajax_package_job_status' ] );
        add_action( 'wp_ajax_restorebase_validate_package', [ $this, 'ajax_validate_package' ] );
        add_action( 'wp_ajax_restorebase_restore_preview', [ $this, 'ajax_restore_preview' ] );
        add_action( 'wp_ajax_restorebase_restore_dry_run', [ $this, 'ajax_restore_dry_run' ] );
        add_action( 'wp_ajax_restorebase_prepare_restore', [ $this, 'ajax_prepare_restore' ] );
        add_action( 'wp_ajax_restorebase_readiness', [ $this, 'ajax_readiness' ] );
        add_action( 'wp_ajax_restorebase_execute_staging_restore', [ $this, 'ajax_execute_staging_restore' ] );
        add_action( 'wp_ajax_restorebase_execute_production_restore', [ $this, 'ajax_execute_production_restore' ] );
        add_action( 'wp_ajax_restorebase_begin_production_restore', [ $this, 'ajax_begin_production_restore' ] );
        add_action( 'wp_ajax_restorebase_run_production_restore_job', [ $this, 'ajax_run_production_restore_job' ] );
        add_action( 'wp_ajax_nopriv_restorebase_run_production_restore_job', [ $this, 'ajax_run_production_restore_job' ] );
        add_action( 'wp_ajax_restorebase_restore_job_status', [ $this, 'ajax_restore_job_status' ] );
        add_action( 'wp_ajax_restorebase_cancel_job', [ $this, 'ajax_cancel_job' ] );
        add_action( 'wp_ajax_restorebase_ack_restore_result', [ $this, 'ajax_ack_restore_result' ] );
        add_action( 'wp_ajax_nopriv_restorebase_restore_job_status', [ $this, 'ajax_restore_job_status' ] );
        add_action( 'wp_ajax_restorebase_remote_upload', [ $this, 'ajax_remote_upload' ] );
        add_action( 'wp_ajax_restorebase_schedule_enable', [ $this, 'ajax_schedule_enable' ] );
        add_action( 'wp_ajax_restorebase_schedule_run_now', [ $this, 'ajax_schedule_run_now' ] );
        add_action( 'wp_ajax_restorebase_emergency_enable', [ $this, 'ajax_emergency_enable' ] );
        add_action( 'wp_ajax_restorebase_create_staging_clone', [ $this, 'ajax_create_staging_clone' ] );
        add_action( 'wp_ajax_restorebase_migration_bundle', [ $this, 'ajax_migration_bundle' ] );
        add_action( 'wp_ajax_restorebase_import_migration_package', [ $this, 'ajax_import_migration_package' ] );
        add_action( 'wp_ajax_restorebase_import_chunk', [ $this, 'ajax_import_chunk' ] );
        add_action( 'wp_ajax_restorebase_delete_snapshot', [ $this, 'ajax_delete_snapshot' ] );
        add_action( 'wp_ajax_restorebase_verify', [ $this, 'ajax_verify' ] );
        add_action( 'wp_ajax_restorebase_rollback_plan', [ $this, 'ajax_rollback_plan' ] );
        add_action( 'wp_ajax_restorebase_rollback_dry_run', [ $this, 'ajax_rollback_dry_run' ] );
        add_action( 'wp_ajax_restorebase_execute_rollback', [ $this, 'ajax_execute_rollback' ] );
        add_action( 'wp_ajax_restorebase_staging_plan', [ $this, 'ajax_staging_plan' ] );
        add_action( 'wp_ajax_restorebase_migration_plan', [ $this, 'ajax_migration_plan' ] );
        add_action( 'wp_ajax_restorebase_remote_storage', [ $this, 'ajax_remote_storage' ] );
        add_action( 'wp_ajax_restorebase_schedule_plan', [ $this, 'ajax_schedule_plan' ] );
        add_action( 'wp_ajax_restorebase_woo_safety', [ $this, 'ajax_woo_safety' ] );
        add_action( 'wp_ajax_restorebase_emergency_plan', [ $this, 'ajax_emergency_plan' ] );
        add_action( 'wp_ajax_restorebase_agency_report', [ $this, 'ajax_agency_report' ] );
        add_action( 'wp_ajax_restorebase_security_audit', [ $this, 'ajax_security_audit' ] );
        add_action( 'wp_ajax_restorebase_production_readiness', [ $this, 'ajax_production_readiness' ] );
        add_action( 'wp_ajax_restorebase_logs', [ $this, 'ajax_logs' ] );
        add_action( 'wp_ajax_restorebase_rank_math_guard', [ $this, 'ajax_rank_math_guard' ] );
    }

    public function add_admin_bar_button( \WP_Admin_Bar $bar ): void {
        if ( ! Capability::can_manage() || ! is_admin_bar_showing() ) {
            return;
        }

        // Inside Mimam's Var, Recovery is reached from the Studio rail / speed dial.
        // A second "RB" admin-bar item would be a competing entry point for the same
        // panel. Only show it when running standalone.
        if ( defined( 'VE_VERSION' ) ) {
            return;
        }

        $bar->add_node( [
            'id'     => 'restorebase-toggle',
            'parent' => 'top-secondary',
            'title'  => '<span class="rb-adminbar-dot" aria-hidden="true"></span><span class="ab-label">RB</span>',
            'href'   => '#restorebase',
            'meta'   => [ 'title' => __( 'RestoreBase Recovery Panel', 'restorebase' ) ],
        ] );
    }

    public function enqueue_assets(): void {
        if ( ! Capability::can_manage() ) {
            return;
        }

        // Cache-bust on the host plugin's version and file mtime, not just the module
        // version: VE_RECOVERY_VERSION does not change when Mimam's Var is updated, so
        // browsers kept serving stale Recovery JS/CSS after an MV release.
        // Mirrors MimamsBarModule's asset versioning.
        $css_path = VE_RECOVERY_DIR . 'assets/admin.css';
        $js_path  = VE_RECOVERY_DIR . 'assets/admin.js';
        $host     = defined( 'VE_VERSION' ) ? VE_VERSION : '';
        $css_ver  = VE_RECOVERY_VERSION . '.' . $host . '.' . ( file_exists( $css_path ) ? filemtime( $css_path ) : '0' );
        $js_ver   = VE_RECOVERY_VERSION . '.' . $host . '.' . ( file_exists( $js_path ) ? filemtime( $js_path ) : '0' );

        // The panel header uses a Phosphor icon. MV registers this same handle in its
        // own adapters, so enqueueing it here is deduped rather than duplicated - but
        // the panel renders on admin screens MV does not style, where it would
        // otherwise be a blank box.
        wp_enqueue_style( 've-ph', 'https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2/src/duotone/style.css', [], '2' );
        $style_dependencies = [];
        if ( defined( 'VE_DIR' ) && defined( 'VE_URL' ) && file_exists( VE_DIR . 'assets/components.css' ) ) {
            wp_enqueue_style( 've-components', VE_URL . 'assets/components.css', [], VE_VERSION . '.' . filemtime( VE_DIR . 'assets/components.css' ) );
            $style_dependencies[] = 've-components';
        }
        wp_enqueue_style( 'restorebase-admin', VE_RECOVERY_URL . 'assets/admin.css', $style_dependencies, $css_ver );
        wp_enqueue_script( 'restorebase-admin', VE_RECOVERY_URL . 'assets/admin.js', [], $js_ver, true );

        wp_localize_script( 'restorebase-admin', 'restoreBaseAdmin', [
            'version'   => VE_RECOVERY_VERSION,
            'apiRoot'   => esc_url_raw( rest_url( VE_RECOVERY_API_NAMESPACE ) ),
            'nonce'     => wp_create_nonce( 'wp_rest' ),
            'ajaxUrl'   => esc_url_raw( admin_url( 'admin-ajax.php' ) ),
            'ajaxNonce' => wp_create_nonce( 'restorebase_admin' ),
            'maxChunkSize' => $this->max_chunk_size(),
            'lastRestoreJob' => ( new JobStore() )->latest_restore(),
            'displayLimits' => [
                'packages' => $this->recent_display_limit( 'restorebase_recent_packages_limit' ),
                'jobs'     => $this->recent_display_limit( 'restorebase_recent_jobs_limit' ),
            ],
            'labels'    => [
                'creating'   => __( 'Creating manifest snapshot job...', 'restorebase' ),
                'created'    => __( 'Manifest snapshot job completed.', 'restorebase' ),
                'packaging'  => __( 'Creating backup...', 'restorebase' ),
                'packaged'   => __( 'Backup completed.', 'restorebase' ),
                'validating' => __( 'Validating package...', 'restorebase' ),
                'validated'  => __( 'Package validation completed.', 'restorebase' ),
                'previewing' => __( 'Preparing restore preview...', 'restorebase' ),
                'previewed'  => __( 'Restore preview ready.', 'restorebase' ),
                'dryRun'     => __( 'Running restore dry-run...', 'restorebase' ),
                'dryRunDone' => __( 'Restore dry-run completed.', 'restorebase' ),
                'preparing'  => __( 'Preparing guarded restore workspace...', 'restorebase' ),
                'prepared'   => __( 'Guarded restore preparation completed.', 'restorebase' ),
                'readiness'  => __( 'Checking readiness...', 'restorebase' ),
                'readyScore' => __( 'Readiness completed.', 'restorebase' ),
                'executing'  => __( 'Executing staging-only restore...', 'restorebase' ),
                'executed'   => __( 'Staging-only restore execution completed.', 'restorebase' ),
                'production' => __( 'Running guarded production restore...', 'restorebase' ),
                'remote'     => __( 'Uploading package to remote storage...', 'restorebase' ),
                'schedule'   => __( 'Updating backup schedule...', 'restorebase' ),
                'emergency'  => __( 'Enabling emergency recovery...', 'restorebase' ),
                'staging'    => __( 'Creating staging clone...', 'restorebase' ),
                'migration'  => __( 'Creating backup...', 'restorebase' ),
                'importing'  => __( 'Importing backup...', 'restorebase' ),
                'imported'   => __( 'Backup imported.', 'restorebase' ),
                'deleting'   => __( 'Deleting snapshot/package...', 'restorebase' ),
                'deleted'    => __( 'Snapshot/package deleted.', 'restorebase' ),
                'rollback'   => __( 'Preparing rollback dry-run...', 'restorebase' ),
                'rollbacked' => __( 'Rollback action completed.', 'restorebase' ),
                'audit'      => __( 'Running security audit...', 'restorebase' ),
                'failed'     => __( 'Action failed.', 'restorebase' ),
                'ready'      => __( 'Ready', 'restorebase' ),
            ],
        ] );
    }

    public function render_restore_outcome_notice(): void {
        if ( ! Capability::can_manage() ) {
            return;
        }

        $job = ( new JobStore() )->latest_restore();
        if ( ! is_array( $job ) || empty( $job['job_key'] ) ) {
            return;
        }

        $status = (string) ( $job['status'] ?? '' );
        if ( ! in_array( $status, [ 'completed', 'failed', 'cancelled', 'running' ], true ) ) {
            return;
        }

        $job_key = (string) ( $job['job_key'] ?? '' );
        $seen = get_user_meta( get_current_user_id(), 'restorebase_seen_restore_outcomes', true );
        $seen = is_array( $seen ) ? array_map( 'strval', $seen ) : [];
        if ( '' !== $job_key && in_array( $job_key, $seen, true ) ) {
            return;
        }

        $finished_at = (string) ( $job['finished_at'] ?? '' );
        if ( '' !== $finished_at && strtotime( $finished_at ) && ( time() - strtotime( $finished_at ) ) > DAY_IN_SECONDS ) {
            return;
        }

        $summary = $this->restore_outcome_summary( $job );
        $class = 'completed' === $status && ! empty( $summary['verification_ok'] ) ? 'notice-success' : ( 'running' === $status ? 'notice-info' : 'notice-warning' );
        $title = 'running' === $status ? __( 'RestoreBase restore is still running.', 'restorebase' ) : ( 'completed' === $status ? __( 'RestoreBase restore completed.', 'restorebase' ) : __( 'RestoreBase restore needs attention.', 'restorebase' ) );
        $message = (string) ( $summary['message'] ?: ( $job['message'] ?? '' ) );
        ?>
        <div class="notice <?php echo esc_attr( $class ); ?> is-dismissible restorebase-outcome-notice" data-rb-outcome-job="<?php echo esc_attr( (string) $job['job_key'] ); ?>">
            <p>
                <strong><?php echo esc_html( $title ); ?></strong>
                <?php echo esc_html( $message ); ?>
                <?php if ( ! empty( $summary['steps'] ) ) : ?>
                    <span><?php echo esc_html( sprintf( __( 'Steps: %s.', 'restorebase' ), $summary['steps'] ) ); ?></span>
                <?php endif; ?>
                <a href="#restorebase" class="button button-small rb-open-panel-from-notice"><?php echo esc_html__( 'Open RestoreBase result', 'restorebase' ); ?></a>
                <a href="<?php echo esc_url( remove_query_arg( [ '_wpnonce', 'action' ] ) ); ?>" class="button button-small"><?php echo esc_html__( 'Refresh admin', 'restorebase' ); ?></a>
            </p>
        </div>
        <?php
    }

    private function restore_outcome_summary( array $job ): array {
        $tasks = isset( $job['task_state'] ) && is_array( $job['task_state'] ) ? $job['task_state'] : [];
        $total = count( $tasks );
        $done = 0;
        $failed = 0;
        foreach ( $tasks as $task ) {
            if ( ! is_array( $task ) ) {
                continue;
            }
            if ( 'completed' === (string) ( $task['status'] ?? '' ) ) {
                $done++;
            }
            if ( 'failed' === (string) ( $task['status'] ?? '' ) ) {
                $failed++;
            }
        }

        $result = isset( $job['result'] ) && is_array( $job['result'] ) ? $job['result'] : [];
        $verification = [];
        if ( isset( $result['post_restore_verification'] ) && is_array( $result['post_restore_verification'] ) ) {
            $verification = $result['post_restore_verification'];
        } elseif ( isset( $result['finish_execution']['post_restore_verification'] ) && is_array( $result['finish_execution']['post_restore_verification'] ) ) {
            $verification = $result['finish_execution']['post_restore_verification'];
        }

        $verification_ok = isset( $verification['ok'] ) ? (bool) $verification['ok'] : ( 'completed' === (string) ( $job['status'] ?? '' ) && 0 === $failed );
        $message = '';
        if ( ! empty( $verification['message'] ) ) {
            $message = (string) $verification['message'];
        } elseif ( ! empty( $job['message'] ) ) {
            $message = (string) $job['message'];
        }

        return [
            'steps'           => $total ? $done . '/' . $total . ( $failed ? ' · ' . $failed . ' failed' : '' ) : '',
            'verification_ok' => $verification_ok,
            'message'         => $message,
        ];
    }

    private function render_toggle_control( string $data_attribute, bool $is_checked, bool $is_disabled, string $accessible_label ): void {
        $allowed_attributes = [ 'data-rb-encrypt', 'data-rb-mysqldump' ];
        if ( ! in_array( $data_attribute, $allowed_attributes, true ) ) {
            return;
        }
        ?>
        <label class="ve-toggle-control">
            <input class="ve-toggle-input" type="checkbox" <?php echo esc_attr( $data_attribute ); ?> <?php checked( $is_checked ); ?> <?php disabled( $is_disabled ); ?> aria-label="<?php echo esc_attr( $accessible_label ); ?>" />
            <span class="ve-toggle" aria-hidden="true">
                <span class="ve-toggle-label ve-toggle-label-off"><?php echo esc_html__( 'Off', 'restorebase' ); ?></span>
                <span class="ve-toggle-label ve-toggle-label-on"><?php echo esc_html__( 'On', 'restorebase' ); ?></span>
                <span class="ve-toggle-knob"></span>
            </span>
        </label>
        <?php
    }

    public function render_floating_panel(): void {
        if ( ! Capability::can_manage() ) {
            return;
        }
        $rb_encryption_on = '' !== (string) get_option( 'restorebase_package_passphrase', '' );
        $rb_mysqldump_on  = (bool) get_option( 'restorebase_enable_mysqldump', true );
        $rb_cipher_ready  = class_exists( '\VE\Modules\Recovery\Backup\PackageCipher' ) && \VE\Modules\Recovery\Backup\PackageCipher::available();
        $rb_site_host     = (string) wp_parse_url( home_url( '/' ), PHP_URL_HOST );
        $rb_package_limit = $this->recent_display_limit( 'restorebase_recent_packages_limit' );
        $rb_job_limit     = $this->recent_display_limit( 'restorebase_recent_jobs_limit' );
        ?>
        <div id="restorebase-backdrop" class="rb-backdrop" aria-hidden="true"></div>
        <div id="restorebase-panel" class="rb-panel" data-panel="recovery" aria-hidden="true" tabindex="-1">
            <div class="rb-hdr">
                <div class="rb-hdr-ic" aria-hidden="true"><i class="ph-duotone ph-arrow-counter-clockwise"></i></div>
                <div class="rb-brand">
                    <span class="rb-hdr-t"><?php echo esc_html__( 'Recovery Studio', 'restorebase' ); ?></span>
                    <span class="rb-hdr-sub"><?php echo esc_html( $rb_site_host ); ?> · <?php echo esc_html__( 'isolated recovery workspace', 'restorebase' ); ?></span>
                </div>
                <div class="rb-hdr-a">
                    <button type="button" data-rb-refresh aria-label="<?php echo esc_attr__( 'Refresh Recovery Studio', 'restorebase' ); ?>"><i class="ph-duotone ph-arrows-clockwise"></i></button>
                    <button type="button" class="rb-close" aria-label="<?php echo esc_attr__( 'Close Recovery Studio', 'restorebase' ); ?>"><i class="ph-duotone ph-x"></i></button>
                </div>
            </div>

            <div class="rb-action-progress" data-rb-action-progress hidden aria-live="polite">
                <div class="rb-action-progress-top">
                    <span data-rb-progress-label><?php echo esc_html__( 'Working...', 'restorebase' ); ?></span>
                    <div class="rb-action-progress-tools">
                        <strong data-rb-progress-percent>0%</strong>
                        <button type="button" class="rb-progress-cancel" data-rb-cancel-action hidden><?php echo esc_html__( 'Cancel', 'restorebase' ); ?></button>
                    </div>
                </div>
                <div class="rb-action-progress-track" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0">
                    <span data-rb-progress-fill style="width:0%"></span>
                </div>
                <div class="rb-action-progress-meta" data-rb-progress-meta hidden></div>
                <div class="rb-action-progress-subtrack" data-rb-progress-subtrack hidden aria-hidden="true">
                    <span data-rb-subprogress-fill style="width:0%"></span>
                </div>
            </div>

            <div class="rb-tabs" role="tablist" data-rb-tabs>
                <button type="button" class="rb-tab is-on" data-rb-tab="backup" role="tab" aria-selected="true" aria-controls="rb-pane-backup"><?php echo esc_html__( 'Backup', 'restorebase' ); ?></button>
                <button type="button" class="rb-tab" data-rb-tab="restore" role="tab" aria-selected="false" aria-controls="rb-pane-restore"><?php echo esc_html__( 'Restore', 'restorebase' ); ?></button>
                <button type="button" class="rb-tab" data-rb-tab="tools" role="tab" aria-selected="false" aria-controls="rb-pane-tools"><?php echo esc_html__( 'Tools', 'restorebase' ); ?></button>
            </div>

            <div class="rb-body">

                <div class="rb-pane is-on" id="rb-pane-backup" data-rb-pane="backup" role="tabpanel">

                    <section class="rb-ui-section">
                        <div class="rb-section-heading">
                            <div><span class="rb-eyebrow"><?php echo esc_html__( 'New package', 'restorebase' ); ?></span><h2 class="rb-ui-title"><?php echo esc_html__( 'Create a recoverable backup', 'restorebase' ); ?></h2></div>
                            <p><?php echo esc_html__( 'A manifest, checksums, database, and the recoverable WordPress content are included.', 'restorebase' ); ?></p>
                        </div>

                        <div class="rb-payload-grid" aria-label="<?php echo esc_attr__( 'Backup contents', 'restorebase' ); ?>">
                            <span class="rb-payload-choice"><i class="ph-duotone ph-database"></i><span><strong><?php echo esc_html__( 'Database', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'Tables, options, users', 'restorebase' ); ?></small></span></span>
                            <span class="rb-payload-choice"><i class="ph-duotone ph-images"></i><span><strong><?php echo esc_html__( 'Uploads', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'Media library files', 'restorebase' ); ?></small></span></span>
                            <span class="rb-payload-choice"><i class="ph-duotone ph-plugs-connected"></i><span><strong><?php echo esc_html__( 'Plugins', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'Plugin files and state', 'restorebase' ); ?></small></span></span>
                            <span class="rb-payload-choice"><i class="ph-duotone ph-paint-brush"></i><span><strong><?php echo esc_html__( 'Themes', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'Active and installed themes', 'restorebase' ); ?></small></span></span>
                        </div>

                        <div class="rb-field rb-package-label-field">
                            <label class="rb-field-label" for="rb-backup-label"><?php echo esc_html__( 'Package label', 'restorebase' ); ?></label>
                            <input id="rb-backup-label" type="text" class="rb-input" data-rb-backup-label placeholder="<?php echo esc_attr__( 'e.g. Before layout changes', 'restorebase' ); ?>" />
                        </div>

                        <div class="rb-field">
                            <div class="rb-option-row rb-option-inline">
                                <span><strong><?php echo esc_html__( 'Encrypt package', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'AES-256-GCM; a recovery key is required.', 'restorebase' ); ?></small></span>
                                <?php $this->render_toggle_control( 'data-rb-encrypt', $rb_encryption_on, ! $rb_cipher_ready, __( 'Encrypt package', 'restorebase' ) ); ?>
                            </div>
                            <div id="rb-backup-passphrase-options" class="rb-option-field" data-rb-passphrase-wrap<?php if ( ! $rb_encryption_on ) : ?> hidden<?php endif; ?>>
                                <span class="rb-password-field"><input id="rb-passphrase" type="password" class="rb-input" data-rb-passphrase autocomplete="new-password" placeholder="<?php echo $rb_encryption_on ? esc_attr__( 'Leave blank to keep the saved passphrase', 'restorebase' ) : esc_attr__( 'Set a passphrase to encrypt', 'restorebase' ); ?>" /><button type="button" class="rb-pass-toggle" data-rb-pass-toggle aria-label="Show passphrase" aria-pressed="false"><i class="ph-duotone ph-eye" aria-hidden="true"></i></button></span>
                            </div>
                            <?php if ( ! $rb_cipher_ready ) : ?><div class="rb-hint"><?php echo esc_html__( 'OpenSSL AES-256-GCM is unavailable on this server, so encryption is disabled.', 'restorebase' ); ?></div><?php endif; ?>
                        </div>

                        <div class="rb-field">
                            <div class="rb-option-row">
                                <span><strong><?php echo esc_html__( 'Use server dump', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'Faster database export when available.', 'restorebase' ); ?></small></span>
                                <?php $this->render_toggle_control( 'data-rb-mysqldump', $rb_mysqldump_on, false, __( 'Use server dump', 'restorebase' ) ); ?>
                            </div>
                        </div>

                        <div class="rb-primary-actions">
                            <button type="button" class="rb-btn rb-btn-accent rb-migration-bundle"><i class="ph-duotone ph-package"></i><?php echo esc_html__( 'Create backup', 'restorebase' ); ?></button>
                        </div>
                    </section>

                    <section class="rb-ui-section">
                        <div class="rb-section-heading rb-section-heading-row">
                            <div><span class="rb-eyebrow"><?php echo esc_html__( 'Packages', 'restorebase' ); ?></span><h2 class="rb-ui-title"><?php echo esc_html__( 'Recent recovery points', 'restorebase' ); ?></h2></div>
                            <button type="button" class="rb-icon-btn" data-rb-refresh aria-label="<?php echo esc_attr__( 'Refresh packages', 'restorebase' ); ?>"><i class="ph-duotone ph-arrows-clockwise"></i></button>
                        </div>
                        <div class="rb-snapshot-list" data-rb-snapshots><p class="rb-empty"><?php echo esc_html__( 'Loading packages...', 'restorebase' ); ?></p></div>
                    </section>

                </div>

                <div class="rb-pane" id="rb-pane-restore" data-rb-pane="restore" role="tabpanel" hidden>

                    <section class="rb-ui-section rb-source-section">
                        <div class="rb-section-heading rb-section-heading-row">
                            <div><span class="rb-eyebrow"><?php echo esc_html__( 'Selected package', 'restorebase' ); ?></span><h2 class="rb-ui-title"><?php echo esc_html__( 'Restore source', 'restorebase' ); ?></h2></div>
                            <button type="button" class="rb-btn rb-btn-ghost rb-btn-s" data-rb-change-package data-rb-package-menu-button aria-expanded="false" aria-controls="rb-package-menu-list"><?php echo esc_html__( 'Change', 'restorebase' ); ?></button>
                        </div>
                        <select id="rb-package-select" class="rb-select rb-select-hidden" data-rb-package-select aria-hidden="true" tabindex="-1">
                            <option value=""><?php echo esc_html__( 'Latest backup', 'restorebase' ); ?></option>
                        </select>
                        <div class="rb-menu rb-package-picker" data-rb-package-menu>
                            <div class="rb-package-bar">
                                <span class="rb-source-icon" aria-hidden="true"><i class="ph-duotone ph-package"></i></span>
                                <span class="rb-package-info"><strong data-rb-package-name><?php echo esc_html__( 'Latest backup', 'restorebase' ); ?></strong><small data-rb-package-meta><?php echo esc_html__( 'Use the newest completed package', 'restorebase' ); ?></small></span>
                                <span class="rb-source-state" data-rb-source-state><i class="ph-duotone ph-check-circle"></i><span data-rb-source-state-label><?php echo esc_html__( 'Ready', 'restorebase' ); ?></span></span>
                            </div>
                            <div class="rb-menu-list" id="rb-package-menu-list" data-rb-package-menu-list hidden></div>
                        </div>

                        <details class="rb-import-disclosure" data-rb-import-disclosure open>
                            <summary><i class="ph-duotone ph-upload-simple"></i><span><strong><?php echo esc_html__( 'Import a package', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'Use a Recovery ZIP from this or another site.', 'restorebase' ); ?></small></span><i class="ph-duotone ph-caret-down"></i></summary>
                            <div class="rb-import-content">
                                <div class="rb-import-row" data-rb-dropzone>
                                    <label class="rb-file-dropzone rb-file-dropzone-wide" data-rb-file-dropzone>
                                        <input type="file" class="rb-file-input" data-rb-import-file accept=".zip,application/zip" />
                                        <span class="rb-file-big" aria-hidden="true"><i class="ph-duotone ph-upload-simple"></i></span>
                                        <span class="rb-file-name" data-rb-file-name><?php echo esc_html__( 'Drop a package or click to select', 'restorebase' ); ?></span>
                                        <span class="rb-file-hint"><?php echo esc_html__( 'Recovery package (.zip)', 'restorebase' ); ?></span>
                                        <span class="rb-file-drop-text"><?php echo esc_html__( 'Drop backup ZIP to upload', 'restorebase' ); ?></span>
                                    </label>
                                </div>

                                <div class="rb-restore-passphrase" data-rb-restore-pass-wrap>
                                    <label class="rb-field-label" for="rb-restore-passphrase"><?php echo esc_html__( 'Encrypted backup passphrase', 'restorebase' ); ?></label>
                                    <span class="rb-password-field"><input id="rb-restore-passphrase" type="password" class="rb-input" data-rb-restore-passphrase autocomplete="off" placeholder="<?php echo esc_attr__( 'Enter the package passphrase', 'restorebase' ); ?>" /><button type="button" class="rb-pass-toggle" data-rb-pass-toggle aria-label="Show passphrase" aria-pressed="false"><i class="ph-duotone ph-eye" aria-hidden="true"></i></button></span>
                                    <small class="rb-restore-pass-hint"><?php echo esc_html__( 'Only needed for encrypted packages. It is reused for validation, preview, and restore.', 'restorebase' ); ?></small>
                                </div>

                                <button type="button" class="rb-btn rb-btn-full rb-import-migration"><i class="ph-duotone ph-upload-simple"></i><?php echo esc_html__( 'Import backup', 'restorebase' ); ?></button>
                            </div>
                        </details>

                        <div class="rb-safety-note"><i class="ph-duotone ph-shield-check"></i><span><?php echo esc_html__( 'The destination stays untouched until the guarded restore. Database credentials, site URL, wp-config.php, and .htaccess remain protected.', 'restorebase' ); ?></span></div>
                    </section>

                    <section class="rb-ui-section">
                        <div class="rb-section-heading rb-section-heading-row">
                            <div><span class="rb-eyebrow"><?php echo esc_html__( 'Guarded workflow', 'restorebase' ); ?></span><h2 class="rb-ui-title"><?php echo esc_html__( 'Restore in six verified stages', 'restorebase' ); ?></h2><p><?php echo esc_html__( 'Each successful check unlocks the next action.', 'restorebase' ); ?></p></div>
                            <button type="button" class="rb-btn rb-btn-ghost rb-btn-s" data-rb-reset-flow><?php echo esc_html__( 'Reset', 'restorebase' ); ?></button>
                        </div>

                    <div class="rb-steps">
                        <div class="rb-step" data-rb-step="validate">
                            <div class="rb-step-num">1</div>
                            <div class="rb-step-b">
                                <div class="rb-step-nm"><?php echo esc_html__( 'Validate package', 'restorebase' ); ?> <span class="rb-tag rb-tag-safe"><?php echo esc_html__( 'safe', 'restorebase' ); ?></span></div>
                                <div class="rb-step-ds"><?php echo esc_html__( 'Manifest, checksums, encryption, and package members.', 'restorebase' ); ?></div>
                                <div class="rb-step-act"><button type="button" class="rb-btn rb-btn-s rb-validate-package"><?php echo esc_html__( 'Run validation', 'restorebase' ); ?></button></div>
                            </div>
                            <i class="ph-duotone ph-caret-right rb-step-chevron" aria-hidden="true"></i><div class="rb-step-res"></div>
                        </div>
                        <div class="rb-step" data-rb-step="preview">
                            <div class="rb-step-num">2</div>
                            <div class="rb-step-b">
                                <div class="rb-step-nm"><?php echo esc_html__( 'Preview impact', 'restorebase' ); ?> <span class="rb-tag rb-tag-safe"><?php echo esc_html__( 'safe', 'restorebase' ); ?></span></div>
                                <div class="rb-step-ds"><?php echo esc_html__( 'Compare URLs, versions, size, and overwritten paths.', 'restorebase' ); ?></div>
                                <div class="rb-step-act"><button type="button" class="rb-btn rb-btn-s rb-preview-latest"><?php echo esc_html__( 'Build impact preview', 'restorebase' ); ?></button></div>
                            </div>
                            <i class="ph-duotone ph-caret-right rb-step-chevron" aria-hidden="true"></i><div class="rb-step-res"></div>
                        </div>
                        <div class="rb-step" data-rb-step="dryrun">
                            <div class="rb-step-num">3</div>
                            <div class="rb-step-b">
                                <div class="rb-step-nm"><?php echo esc_html__( 'Dry run', 'restorebase' ); ?> <span class="rb-tag rb-tag-safe"><?php echo esc_html__( 'safe', 'restorebase' ); ?></span></div>
                                <div class="rb-step-ds"><?php echo esc_html__( 'Simulate the complete plan without writing changes.', 'restorebase' ); ?></div>
                                <div class="rb-step-act"><button type="button" class="rb-btn rb-btn-s rb-dry-run"><?php echo esc_html__( 'Run simulation', 'restorebase' ); ?></button></div>
                            </div>
                            <i class="ph-duotone ph-caret-right rb-step-chevron" aria-hidden="true"></i><div class="rb-step-res"></div>
                        </div>
                        <div class="rb-step" data-rb-step="prepare">
                            <div class="rb-step-num">4</div>
                            <div class="rb-step-b">
                                <div class="rb-step-nm"><?php echo esc_html__( 'Prepare workspace', 'restorebase' ); ?> <span class="rb-tag rb-tag-safe"><?php echo esc_html__( 'safe', 'restorebase' ); ?></span></div>
                                <div class="rb-step-ds"><?php echo esc_html__( 'Extract safely and create the pre-restore rollback point.', 'restorebase' ); ?></div>
                                <div class="rb-step-act"><button type="button" class="rb-btn rb-btn-s rb-prepare-restore"><?php echo esc_html__( 'Prepare and snapshot', 'restorebase' ); ?></button></div>
                            </div>
                            <i class="ph-duotone ph-caret-right rb-step-chevron" aria-hidden="true"></i><div class="rb-step-res"></div>
                        </div>
                        <div class="rb-step" data-rb-step="restore">
                            <div class="rb-step-num">5</div>
                            <div class="rb-step-b">
                                <div class="rb-step-nm"><?php echo esc_html__( 'Guarded restore', 'restorebase' ); ?> <span class="rb-tag rb-tag-destr"><?php echo esc_html__( 'destructive', 'restorebase' ); ?></span></div>
                                <div class="rb-step-ds"><?php echo esc_html__( 'Swap the database and restore selected files through a resumable job.', 'restorebase' ); ?></div>
                                <div class="rb-step-act"><div class="rb-gate"><p><?php echo esc_html__( 'This is the only destructive stage. Typed confirmation is required before anything is written.', 'restorebase' ); ?></p><button type="button" class="rb-btn rb-btn-danger rb-btn-s rb-restore-selected"><?php echo esc_html__( 'Run guarded restore', 'restorebase' ); ?></button></div></div>
                            </div>
                            <i class="ph-duotone ph-caret-right rb-step-chevron" aria-hidden="true"></i><div class="rb-step-res"></div>
                        </div>
                        <div class="rb-step" data-rb-step="verify">
                            <div class="rb-step-num">6</div>
                            <div class="rb-step-b">
                                <div class="rb-step-nm"><?php echo esc_html__( 'Verify destination', 'restorebase' ); ?> <span class="rb-tag rb-tag-safe"><?php echo esc_html__( 'safe', 'restorebase' ); ?></span></div>
                                <div class="rb-step-ds"><?php echo esc_html__( 'Check front end, admin, tables, plugins, and theme state.', 'restorebase' ); ?></div>
                                <div class="rb-step-act"><button type="button" class="rb-btn rb-btn-s rb-verify"><?php echo esc_html__( 'Verify restored site', 'restorebase' ); ?></button></div>
                            </div>
                            <i class="ph-duotone ph-caret-right rb-step-chevron" aria-hidden="true"></i><div class="rb-step-res"></div>
                        </div>
                    </div>
                    </section>

                    <section class="rb-ui-section rb-preview-section rb-safe-dock">
                        <div class="rb-section-heading"><div><span class="rb-eyebrow"><?php echo esc_html__( 'Report', 'restorebase' ); ?></span><h2 class="rb-ui-title"><?php echo esc_html__( 'Latest safety result', 'restorebase' ); ?></h2></div></div>
                        <div data-rb-preview class="rb-preview-box">
                            <div class="rb-help-card">
                                <strong><?php echo esc_html__( 'What should I do first?', 'restorebase' ); ?></strong>
                                <p><?php echo esc_html__( 'Choose a package, then run Validate and Preview impact. Nothing is written until the guarded restore.', 'restorebase' ); ?></p>
                            </div>
                        </div>
                        <div class="rb-row2 rb-mt"><button type="button" class="rb-btn rb-btn-ghost rb-btn-s rb-rollback-plan"><?php echo esc_html__( 'Build rollback plan', 'restorebase' ); ?></button><button type="button" class="rb-btn rb-btn-ghost rb-btn-s" data-rb-refresh><?php echo esc_html__( 'Refresh report', 'restorebase' ); ?></button></div>
                    </section>

                </div>

                <div class="rb-pane" id="rb-pane-tools" data-rb-pane="tools" role="tabpanel" hidden>

                    <section class="rb-ui-section">
                        <div class="rb-section-heading"><div><span class="rb-eyebrow"><?php echo esc_html__( 'Utilities', 'restorebase' ); ?></span><h2 class="rb-ui-title"><?php echo esc_html__( 'Recovery tools', 'restorebase' ); ?></h2><p><?php echo esc_html__( 'Routine checks come first. Direct recovery controls stay folded away.', 'restorebase' ); ?></p></div></div>
                    </section>

                    <details class="rb-tool-group" open>
                        <summary><span class="rb-tool-icon"><i class="ph-duotone ph-shield-check"></i></span><span><strong><?php echo esc_html__( 'Safety and readiness', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'Verify, audit, dry run, and rollback planning', 'restorebase' ); ?></small></span><i class="ph-duotone ph-caret-down"></i></summary>
                        <div class="rb-tool-content"><div class="rb-action-grid rb-advanced-grid">
                            <button type="button" class="rb-btn rb-create-snapshot"><?php echo esc_html__( 'Manifest snapshot', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-readiness"><?php echo esc_html__( 'Readiness score', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-verify"><?php echo esc_html__( 'Verify site', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-rollback-plan"><?php echo esc_html__( 'Rollback plan', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-rollback-dry-run"><?php echo esc_html__( 'Rollback dry run', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-security-audit"><?php echo esc_html__( 'Security audit', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-rank-math-guard"><?php echo esc_html__( 'Rank Math key guard', 'restorebase' ); ?></button>
                        </div></div>
                    </details>

                    <details class="rb-tool-group">
                        <summary><span class="rb-tool-icon"><i class="ph-duotone ph-clock-counter-clockwise"></i></span><span><strong><?php echo esc_html__( 'Scheduling and storage', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'Automatic backups, retention, and remote targets', 'restorebase' ); ?></small></span><i class="ph-duotone ph-caret-down"></i></summary>
                        <div class="rb-tool-content"><div class="rb-storage-path"><span><?php echo esc_html__( 'Local storage', 'restorebase' ); ?></span><code data-rb-storage><?php echo esc_html__( 'Loading...', 'restorebase' ); ?></code></div>
                            <div class="rb-history-settings">
                                <div class="rb-history-setting"><span><strong><?php echo esc_html__( 'Recent packages shown', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'Display only; does not delete backups', 'restorebase' ); ?></small></span><?php $this->render_recent_limit_select( 'packages', $rb_package_limit ); ?></div>
                                <div class="rb-history-setting"><span><strong><?php echo esc_html__( 'Recent jobs shown', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'Display only; history stays intact', 'restorebase' ); ?></small></span><?php $this->render_recent_limit_select( 'jobs', $rb_job_limit ); ?></div>
                            </div>
                            <div class="rb-action-grid rb-advanced-grid">
                            <button type="button" class="rb-btn rb-save-backup-options"><?php echo esc_html__( 'Save display settings', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-schedule-plan"><?php echo esc_html__( 'View schedule', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-schedule-enable"><?php echo esc_html__( 'Enable schedule', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-schedule-run-now"><?php echo esc_html__( 'Run backup now', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-remote-storage"><?php echo esc_html__( 'Remote storage', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-remote-upload"><?php echo esc_html__( 'Upload remote', 'restorebase' ); ?></button>
                        </div></div>
                    </details>

                    <details class="rb-tool-group">
                        <summary><span class="rb-tool-icon"><i class="ph-duotone ph-arrows-left-right"></i></span><span><strong><?php echo esc_html__( 'Staging and migration', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'Plans, staging clone, and destination checks', 'restorebase' ); ?></small></span><i class="ph-duotone ph-caret-down"></i></summary>
                        <div class="rb-tool-content"><div class="rb-action-grid rb-advanced-grid">
                            <button type="button" class="rb-btn rb-staging-plan"><?php echo esc_html__( 'Staging plan', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-migration-plan"><?php echo esc_html__( 'Restore plan', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-create-staging-clone"><?php echo esc_html__( 'Create staging clone', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-woo-safety"><?php echo esc_html__( 'WooCommerce safety', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-agency-report"><?php echo esc_html__( 'Agency report', 'restorebase' ); ?></button>
                            <button type="button" class="rb-btn rb-production-readiness"><?php echo esc_html__( 'Production readiness', 'restorebase' ); ?></button>
                        </div></div>
                    </details>

                    <details class="rb-tool-group rb-tool-danger">
                        <summary><span class="rb-tool-icon"><i class="ph-duotone ph-warning-octagon"></i></span><span><strong><?php echo esc_html__( 'Emergency recovery', 'restorebase' ); ?></strong><small><?php echo esc_html__( 'Direct production, staging, rollback, and emergency URL', 'restorebase' ); ?></small></span><i class="ph-duotone ph-caret-down"></i></summary>
                        <div class="rb-tool-content">
                            <p class="rb-tool-warning"><?php echo esc_html__( 'Use the guarded Restore tab for normal recovery. These direct paths require their exact typed phrases.', 'restorebase' ); ?></p>
                            <div class="rb-execute-gate">
                                <label class="rb-field-label" for="rb-confirm-production"><?php echo esc_html__( 'Production restore', 'restorebase' ); ?></label>
                                <input id="rb-confirm-production" type="text" class="rb-input" data-rb-production-confirm placeholder="<?php echo esc_attr__( 'Type RESTORE PRODUCTION', 'restorebase' ); ?>" autocomplete="off" />
                                <button type="button" class="rb-btn rb-btn-danger rb-execute-production"><?php echo esc_html__( 'Execute production restore', 'restorebase' ); ?></button>
                                <label class="rb-field-label" for="rb-confirm-restore"><?php echo esc_html__( 'Staging restore', 'restorebase' ); ?></label>
                                <input id="rb-confirm-restore" type="text" class="rb-input" data-rb-confirm placeholder="<?php echo esc_attr__( 'Type RESTORE STAGING', 'restorebase' ); ?>" autocomplete="off" />
                                <button type="button" class="rb-btn rb-btn-danger rb-execute-staging"><?php echo esc_html__( 'Execute staging restore', 'restorebase' ); ?></button>
                                <label class="rb-field-label" for="rb-confirm-rollback"><?php echo esc_html__( 'Staging rollback', 'restorebase' ); ?></label>
                                <input id="rb-confirm-rollback" type="text" class="rb-input" data-rb-rollback-confirm placeholder="<?php echo esc_attr__( 'Type ROLLBACK STAGING', 'restorebase' ); ?>" autocomplete="off" />
                                <button type="button" class="rb-btn rb-btn-danger rb-execute-rollback"><?php echo esc_html__( 'Execute staging rollback', 'restorebase' ); ?></button>
                            </div>
                            <div class="rb-action-grid rb-advanced-grid rb-emergency-actions"><button type="button" class="rb-btn rb-btn-danger rb-emergency-plan"><?php echo esc_html__( 'Emergency plan', 'restorebase' ); ?></button><button type="button" class="rb-btn rb-btn-danger rb-emergency-enable"><?php echo esc_html__( 'Enable emergency URL', 'restorebase' ); ?></button></div>
                        </div>
                    </details>

                    <section class="rb-ui-section">
                        <div class="rb-section-heading rb-section-heading-row"><div><span class="rb-eyebrow"><?php echo esc_html__( 'Activity', 'restorebase' ); ?></span><h2 class="rb-ui-title"><?php echo esc_html__( 'Recent jobs', 'restorebase' ); ?></h2></div><button type="button" class="rb-icon-btn" data-rb-refresh aria-label="<?php echo esc_attr__( 'Refresh jobs', 'restorebase' ); ?>"><i class="ph-duotone ph-arrows-clockwise"></i></button></div>
                        <div data-rb-jobs class="rb-job-list"><p class="rb-empty"><?php echo esc_html__( 'Loading jobs...', 'restorebase' ); ?></p></div>
                    </section>

                </div>

            </div>
            <div class="rb-footer">
                <span class="rb-footer-meta"><?php echo esc_html__( 'Recovery Studio · MV module', 'restorebase' ); ?> · <?php echo esc_html( 'v' . ( defined( 'VE_VERSION' ) ? VE_VERSION : VE_RECOVERY_VERSION ) ); ?> · <b data-rb-total>—</b>/<b data-rb-packages>—</b></span>
                <span class="rb-footer-state" data-rb-status><?php echo esc_html__( 'Ready', 'restorebase' ); ?></span>
            </div>
        </div>
        <?php
    }

    public function ajax_status(): void { $this->check_ajax_request(); wp_send_json_success( ( new SnapshotManager() )->status() ); }
    public function ajax_snapshots(): void { $this->check_ajax_request(); $limit = isset( $_REQUEST['limit'] ) ? absint( wp_unslash( $_REQUEST['limit'] ) ) : $this->recent_display_limit( 'restorebase_recent_packages_limit' ); wp_send_json_success( ( new SnapshotManager() )->all( $limit ) ); }
    public function ajax_jobs(): void { $this->check_ajax_request(); $limit = isset( $_REQUEST['limit'] ) ? absint( wp_unslash( $_REQUEST['limit'] ) ) : $this->recent_display_limit( 'restorebase_recent_jobs_limit' ); wp_send_json_success( ( new JobStore() )->all( $limit ) ); }
    public function ajax_create_snapshot(): void { $this->check_ajax_request(); $label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : ''; wp_send_json_success( ( new SnapshotJob() )->create( $label ) ); }
    public function ajax_save_backup_options(): void {
        $this->check_ajax_request();
        $encrypt       = isset( $_POST['encrypt'] ) && '' !== (string) $_POST['encrypt'] && 'false' !== (string) $_POST['encrypt'] && '0' !== (string) $_POST['encrypt'];
        $use_mysqldump = isset( $_POST['use_mysqldump'] ) && '' !== (string) $_POST['use_mysqldump'] && 'false' !== (string) $_POST['use_mysqldump'] && '0' !== (string) $_POST['use_mysqldump'];
        $package_limit  = $this->sanitize_recent_limit( isset( $_POST['recent_packages_limit'] ) ? absint( wp_unslash( $_POST['recent_packages_limit'] ) ) : $this->recent_display_limit( 'restorebase_recent_packages_limit' ) );
        $job_limit      = $this->sanitize_recent_limit( isset( $_POST['recent_jobs_limit'] ) ? absint( wp_unslash( $_POST['recent_jobs_limit'] ) ) : $this->recent_display_limit( 'restorebase_recent_jobs_limit' ) );
        // Passphrase can contain spaces/symbols — do not sanitize_text_field it.
        $passphrase = isset( $_POST['passphrase'] ) ? trim( (string) wp_unslash( $_POST['passphrase'] ) ) : '';

        $cipher_ready = class_exists( '\VE\Modules\Recovery\Backup\PackageCipher' ) && \VE\Modules\Recovery\Backup\PackageCipher::available();

        if ( $encrypt && $cipher_ready ) {
            if ( '' !== $passphrase ) {
                update_option( 'restorebase_package_passphrase', $passphrase, false );
            } elseif ( '' === (string) get_option( 'restorebase_package_passphrase', '' ) ) {
                wp_send_json_error( [ 'message' => __( 'Enter a passphrase to turn on encryption.', 'restorebase' ) ], 400 );
            }
            // else: encryption already on and no new passphrase — keep the existing one.
        } else {
            delete_option( 'restorebase_package_passphrase' );
        }

        update_option( 'restorebase_enable_mysqldump', $use_mysqldump ? 1 : 0, false );
        update_option( 'restorebase_recent_packages_limit', $package_limit, false );
        update_option( 'restorebase_recent_jobs_limit', $job_limit, false );

        wp_send_json_success( [
            'ok'                 => true,
            'message'            => __( 'Backup options saved.', 'restorebase' ),
            'encryption_enabled' => '' !== (string) get_option( 'restorebase_package_passphrase', '' ),
            'mysqldump_enabled'  => (bool) get_option( 'restorebase_enable_mysqldump', false ),
            'cipher_available'   => $cipher_ready,
            'recent_packages_limit' => $package_limit,
            'recent_jobs_limit'     => $job_limit,
        ] );
    }

    public function ajax_create_package(): void { $this->check_ajax_request(); $label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : ''; wp_send_json_success( ( new PackageBuilder() )->create( $label ) ); }
    public function ajax_begin_package(): void {
        $this->check_ajax_request();
        $this->prepare_backup_ajax_request();
        $label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '';
        wp_send_json_success( ( new PackageBuilder() )->begin( $label ) );
    }

    public function ajax_run_package_job(): void {
        $this->check_ajax_request();
        $this->prepare_backup_ajax_request();
        $job_key = isset( $_REQUEST['job_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['job_key'] ) ) : '';
        $result = ( new PackageBuilder() )->execute_job( $job_key );
        if ( empty( $result['ok'] ) ) {
            wp_send_json_error( $result, 403 );
        }
        wp_send_json_success( $result );
    }

    public function ajax_package_job_status(): void {
        $this->check_ajax_request();
        $this->prepare_backup_ajax_request( false );
        $job_key = isset( $_REQUEST['job_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['job_key'] ) ) : '';
        $result = ( new PackageBuilder() )->status( $job_key );
        if ( empty( $result['ok'] ) ) {
            wp_send_json_error( $result, 404 );
        }
        wp_send_json_success( $result );
    }
    public function ajax_validate_package(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); wp_send_json_success( ( new PackageValidator() )->validate_snapshot( $snapshot_key, $this->request_passphrase() ) ); }
    public function ajax_restore_preview(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); wp_send_json_success( ( new RestorePreview() )->preview_snapshot( $snapshot_key ) ); }
    public function ajax_restore_dry_run(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); wp_send_json_success( ( new RestoreDryRun() )->run( $snapshot_key, $this->request_passphrase() ) ); }
    public function ajax_prepare_restore(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); wp_send_json_success( ( new RestorePreparation() )->prepare( $snapshot_key, $this->request_passphrase() ) ); }
    public function ajax_readiness(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); wp_send_json_success( ( new RestoreReadiness() )->assess( $snapshot_key, [], $this->request_passphrase() ) ); }
    public function ajax_execute_staging_restore(): void { $this->check_ajax_restore_request(); $snapshot_key = $this->request_snapshot_key(); $confirmation = isset( $_REQUEST['confirmation'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['confirmation'] ) ) : ''; wp_send_json_success( ( new StagingRestoreExecutor() )->execute( $snapshot_key, $confirmation, $this->request_passphrase() ) ); }
    public function ajax_execute_production_restore(): void { $this->check_ajax_restore_request(); $snapshot_key = $this->request_snapshot_key(); $confirmation = isset( $_REQUEST['confirmation'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['confirmation'] ) ) : ''; wp_send_json_success( ( new ProductionRestoreExecutor() )->execute( $snapshot_key, $confirmation, $this->request_passphrase() ) ); }
    public function ajax_begin_production_restore(): void { $this->check_ajax_restore_request(); $snapshot_key = $this->request_snapshot_key(); $confirmation = isset( $_REQUEST['confirmation'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['confirmation'] ) ) : ''; wp_send_json_success( ( new ProductionRestoreExecutor() )->begin( $snapshot_key, $confirmation, $this->request_passphrase() ) ); }
    public function ajax_run_production_restore_job(): void { $job_key = isset( $_REQUEST['job_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['job_key'] ) ) : ''; $token = isset( $_REQUEST['status_token'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['status_token'] ) ) : ''; if ( is_user_logged_in() ) { $this->check_ajax_request(); } elseif ( '' === $job_key || '' === $token ) { wp_send_json_error( [ 'message' => __( 'Restore job token is missing.', 'restorebase' ) ], 403 ); } $result = ( new ProductionRestoreExecutor() )->execute_job( $job_key, $token ); if ( empty( $result['ok'] ) ) { wp_send_json_error( $result, 403 ); } wp_send_json_success( $result ); }
    public function ajax_restore_job_status(): void { $job_key = isset( $_REQUEST['job_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['job_key'] ) ) : ''; $token = isset( $_REQUEST['status_token'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['status_token'] ) ) : ''; $result = ( new ProductionRestoreExecutor() )->status( $job_key, $token ); if ( empty( $result['ok'] ) ) { wp_send_json_error( $result, 403 ); } wp_send_json_success( $result ); }
    public function ajax_cancel_job(): void { $this->check_ajax_request(); $job_key = isset( $_REQUEST['job_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['job_key'] ) ) : ''; wp_send_json_success( ( new JobStore() )->cancel( $job_key ) ); }
    public function ajax_ack_restore_result(): void { $this->check_ajax_request(); $job_key = isset( $_REQUEST['job_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['job_key'] ) ) : ''; $seen = get_user_meta( get_current_user_id(), 'restorebase_seen_restore_outcomes', true ); $seen = is_array( $seen ) ? array_map( 'strval', $seen ) : []; if ( '' !== $job_key && ! in_array( $job_key, $seen, true ) ) { $seen[] = $job_key; $seen = array_slice( array_values( array_unique( $seen ) ), -20 ); update_user_meta( get_current_user_id(), 'restorebase_seen_restore_outcomes', $seen ); } wp_send_json_success( [ 'ok' => true, 'job_key' => $job_key, 'seen' => $seen ] ); }
    public function ajax_remote_upload(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); $result = '' !== $snapshot_key ? ( new RemoteStorageManager() )->upload_snapshot( $snapshot_key ) : ( new RemoteStorageManager() )->upload_latest(); wp_send_json_success( $result ); }
    public function ajax_schedule_enable(): void { $this->check_ajax_request(); wp_send_json_success( ( new ScheduleManager() )->enable() ); }
    public function ajax_schedule_run_now(): void { $this->check_ajax_request(); wp_send_json_success( ( new ScheduleManager() )->run_now( 'manual_panel' ) ); }
    public function ajax_emergency_enable(): void { $this->check_ajax_request(); wp_send_json_success( ( new EmergencyRecovery() )->enable() ); }
    public function ajax_create_staging_clone(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); wp_send_json_success( ( new StagingCloneBuilder() )->create( $snapshot_key ) ); }
    public function ajax_migration_bundle(): void { $this->check_ajax_request(); wp_send_json_success( ( new PackageBuilder() )->create( 'Backup ' . current_time( 'mysql' ) ) ); }
    public function ajax_import_migration_package(): void { $this->check_ajax_request(); $label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : ''; $file = isset( $_FILES['package'] ) && is_array( $_FILES['package'] ) ? $_FILES['package'] : []; wp_send_json_success( ( new MigrationImporter() )->import_uploaded( $file, $label, $this->request_passphrase() ) ); }

    /**
     * Receive one chunk of a backup upload and append it to the assembly file.
     *
     * A whole backup cannot be posted in one request — post_max_size,
     * upload_max_filesize and proxy body limits (nginx client_max_body_size
     * defaults to 1MB) silently kill it, which left the destination with 0
     * packages. The browser slices the ZIP and posts it a chunk at a time.
     */
    public function ajax_import_chunk(): void {
        $this->check_ajax_request();
        $this->prepare_backup_ajax_request();

        $key   = isset( $_POST['upload_key'] ) ? preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_POST['upload_key'] ) ) : '';
        $index = isset( $_POST['chunk_index'] ) ? absint( $_POST['chunk_index'] ) : 0;
        $total = isset( $_POST['total_chunks'] ) ? absint( $_POST['total_chunks'] ) : 0;
        $name  = isset( $_POST['filename'] ) ? sanitize_file_name( (string) wp_unslash( $_POST['filename'] ) ) : 'restorebase-import.zip';
        $label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '';

        if ( '' === $key || strlen( $key ) < 8 || $total < 1 || $index >= $total ) {
            wp_send_json_error( [ 'message' => __( 'Invalid upload session.', 'restorebase' ) ], 400 );
        }
        if ( ! isset( $_FILES['chunk']['tmp_name'] ) || ! is_uploaded_file( (string) $_FILES['chunk']['tmp_name'] ) ) {
            wp_send_json_error( [ 'message' => __( 'Upload chunk is missing. The server may have rejected the request size.', 'restorebase' ) ], 400 );
        }
        if ( isset( $_FILES['chunk']['error'] ) && UPLOAD_ERR_OK !== (int) $_FILES['chunk']['error'] ) {
            wp_send_json_error( [ 'message' => __( 'Upload chunk failed. Check the server upload limits.', 'restorebase' ) ], 400 );
        }

        $dir = LocalStorage::base_dir() . 'tmp/';
        if ( ! is_dir( $dir ) ) {
            wp_mkdir_p( $dir );
        }
        LocalStorage::protect_dir( $dir );

        $part = $dir . 'upload-' . $key . '.part';
        if ( 0 === $index && file_exists( $part ) ) {
            @unlink( $part ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
        }

        $in  = @fopen( (string) $_FILES['chunk']['tmp_name'], 'rb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged
        $out = @fopen( $part, 'ab' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen, WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! is_resource( $in ) || ! is_resource( $out ) ) {
            if ( is_resource( $in ) ) { fclose( $in ); }
            if ( is_resource( $out ) ) { fclose( $out ); }
            wp_send_json_error( [ 'message' => __( 'RestoreBase could not write the upload chunk to storage.', 'restorebase' ) ], 500 );
        }
        while ( ! feof( $in ) ) {
            $buffer = fread( $in, 1048576 );
            if ( false === $buffer || '' === $buffer ) {
                break;
            }
            fwrite( $out, $buffer );
        }
        fclose( $in );
        fclose( $out );

        if ( $index + 1 < $total ) {
            wp_send_json_success( [
                'ok'        => true,
                'assembling'=> true,
                'received'  => $index + 1,
                'total'     => $total,
                'bytes'     => file_exists( $part ) ? (int) filesize( $part ) : 0,
                'message'   => sprintf( 'Uploaded %d of %d chunks.', $index + 1, $total ),
            ] );
        }

        // Final chunk — confirm the assembly is the size the browser sent before
        // handing it to the importer, so a dropped chunk is caught here.
        $expected_size = isset( $_POST['total_size'] ) ? absint( $_POST['total_size'] ) : 0;
        $actual_size   = file_exists( $part ) ? (int) filesize( $part ) : 0;
        if ( $expected_size > 0 && $actual_size !== $expected_size ) {
            @unlink( $part ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
            wp_send_json_error( [
                'message' => sprintf(
                    /* translators: 1: received bytes, 2: expected bytes */
                    __( 'The upload is incomplete (%1$s of %2$s bytes arrived). Please try importing again.', 'restorebase' ),
                    number_format_i18n( $actual_size ),
                    number_format_i18n( $expected_size )
                ),
            ], 400 );
        }

        $result = ( new MigrationImporter() )->import_local_file( $part, $name, $label, $this->request_passphrase() );
        if ( file_exists( $part ) ) {
            @unlink( $part ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
        }
        if ( empty( $result['ok'] ) ) {
            wp_send_json_error( $result, 400 );
        }
        wp_send_json_success( $result );
    }

    /** Largest chunk this server will actually accept, with headroom for the rest of the POST body. */
    private function max_chunk_size(): int {
        $cap = 5 * 1024 * 1024;
        $limits = [];
        foreach ( [ 'post_max_size', 'upload_max_filesize' ] as $setting ) {
            $value = $this->parse_ini_size( (string) ini_get( $setting ) );
            if ( $value > 0 ) {
                $limits[] = $value;
            }
        }
        $limits[] = $cap;
        // 80% headroom covers multipart overhead, the nonce, and the other fields.
        return (int) max( 262144, min( $cap, (int) floor( min( $limits ) * 0.8 ) ) );
    }

    private function parse_ini_size( string $size ): int {
        $size = trim( $size );
        if ( '' === $size ) {
            return 0;
        }
        $unit = strtolower( substr( $size, -1 ) );
        $value = (float) $size;
        switch ( $unit ) {
            case 'g': $value *= 1024 * 1024 * 1024; break;
            case 'm': $value *= 1024 * 1024; break;
            case 'k': $value *= 1024; break;
        }
        return (int) $value;
    }
    public function ajax_delete_snapshot(): void { $this->check_ajax_request(); $snapshot_key = $this->request_snapshot_key(); $delete_files = ! isset( $_REQUEST['delete_files'] ) || '0' !== (string) wp_unslash( $_REQUEST['delete_files'] ); wp_send_json_success( ( new SnapshotManager() )->delete( $snapshot_key, $delete_files ) ); }
    public function ajax_verify(): void { $this->check_ajax_request(); wp_send_json_success( ( new RestoreVerifier() )->verify() ); }
    public function ajax_rollback_plan(): void { $this->check_ajax_request(); wp_send_json_success( ( new RollbackManager() )->plan() ); }
    public function ajax_rollback_dry_run(): void { $this->check_ajax_request(); $confirmation = isset( $_REQUEST['confirmation'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['confirmation'] ) ) : ''; wp_send_json_success( ( new RollbackExecutor() )->dry_run( $confirmation ) ); }
    public function ajax_execute_rollback(): void { $this->check_ajax_restore_request(); $confirmation = isset( $_REQUEST['confirmation'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['confirmation'] ) ) : ''; wp_send_json_success( ( new RollbackExecutor() )->execute( $confirmation ) ); }
    public function ajax_staging_plan(): void { $this->check_ajax_request(); wp_send_json_success( ( new StagingWorkflow() )->plan() ); }
    public function ajax_migration_plan(): void { $this->check_ajax_request(); wp_send_json_success( ( new MigrationPlanner() )->plan() ); }
    public function ajax_remote_storage(): void { $this->check_ajax_request(); wp_send_json_success( ( new RemoteStorageManager() )->plan() ); }
    public function ajax_schedule_plan(): void { $this->check_ajax_request(); wp_send_json_success( ( new ScheduleManager() )->plan() ); }
    public function ajax_woo_safety(): void { $this->check_ajax_request(); wp_send_json_success( ( new WooSafety() )->report() ); }
    public function ajax_emergency_plan(): void { $this->check_ajax_request(); wp_send_json_success( ( new EmergencyRecovery() )->plan() ); }
    public function ajax_agency_report(): void { $this->check_ajax_request(); wp_send_json_success( ( new AgencyDashboard() )->report() ); }
    public function ajax_security_audit(): void { $this->check_ajax_request(); wp_send_json_success( ( new SecurityAudit() )->report() ); }
    public function ajax_production_readiness(): void { $this->check_ajax_request(); wp_send_json_success( ( new ProductionReadiness() )->report() ); }
    public function ajax_logs(): void { $this->check_ajax_request(); $limit = isset( $_REQUEST['limit'] ) ? absint( wp_unslash( $_REQUEST['limit'] ) ) : 20; wp_send_json_success( Logger::latest( $limit ) ); }
    public function ajax_rank_math_guard(): void { $this->check_ajax_request(); wp_send_json_success( ( new RankMathConfigGuard() )->ensure_stable_constants( 'manual_panel' ) ); }

    public function download_package(): void {
        if ( ! Capability::can_manage() ) {
            wp_die( esc_html__( 'You do not have permission to download RestoreBase packages.', 'restorebase' ) );
        }

        $snapshot_key = isset( $_GET['snapshot_key'] ) ? sanitize_text_field( wp_unslash( $_GET['snapshot_key'] ) ) : '';
        if ( '' === $snapshot_key || ! wp_verify_nonce( $_GET['_wpnonce'] ?? '', 'restorebase_download_' . $snapshot_key ) ) {
            wp_die( esc_html__( 'Invalid RestoreBase download request.', 'restorebase' ) );
        }

        global $wpdb;
        $row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM " . Schema::table( 'snapshots' ) . " WHERE snapshot_key = %s LIMIT 1", $snapshot_key ), ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        if ( ! is_array( $row ) || empty( $row['meta_json'] ) ) {
            wp_die( esc_html__( 'RestoreBase package was not found.', 'restorebase' ) );
        }

        $meta = json_decode( (string) $row['meta_json'], true );
        $path = is_array( $meta ) && ! empty( $meta['package_path'] ) ? (string) $meta['package_path'] : '';
        if ( '' === $path || ! is_readable( $path ) ) {
            wp_die( esc_html__( 'RestoreBase package file is missing.', 'restorebase' ) );
        }

        Logger::info( 'package_downloaded', 'RestoreBase package downloaded.', [ 'snapshot_key' => $snapshot_key ] );

        // Chunked + resumable. readfile() buffered the whole package in memory and
        // was killed at memory_limit, producing a truncated "backup" that only
        // failed later at restore time.
        \VE\Modules\Recovery\Utils\FileStreamer::stream( $path, $this->download_name( $row, $meta ) );
    }


    private function download_name( array $row, array $meta ): string {
        if ( ! empty( $meta['package_filename'] ) && is_string( $meta['package_filename'] ) ) {
            // Whitelist instead of sanitize_file_name(): that function treats each dot
            // as an extension boundary and would rewrite the readable domain in the
            // name (example.com.zip -> example.com_.zip). basename() blocks traversal.
            $filename = basename( (string) $meta['package_filename'] );
            if ( preg_match( '/^[A-Za-z0-9._\-]{1,180}\.zip$/', $filename ) ) {
                return $filename;
            }
        }

        $source = '';
        if ( ! empty( $meta['source_site_url'] ) && is_string( $meta['source_site_url'] ) ) {
            $source = (string) wp_parse_url( $meta['source_site_url'], PHP_URL_HOST );
        }
        if ( '' === $source ) {
            $source = (string) wp_parse_url( home_url(), PHP_URL_HOST );
        }
        if ( '' === $source ) {
            $source = (string) get_bloginfo( 'name' );
        }

        // Same readable shape as PackageBuilder so the download name never drifts from
        // the stored package filename.
        $created = ! empty( $row['created_at'] ) ? strtotime( (string) $row['created_at'] ) : false;
        $stamp = gmdate( 'Y-m-d-Hi', $created ?: time() );

        return PackageBuilder::build_file_name( $source, $stamp, $this->backup_version_slug( $meta ) );
    }

    private function backup_version_slug( array $meta ): string {
        $version = '';
        foreach ( [ 'restorebase_version', 'created_with_version', 'product_version' ] as $key ) {
            if ( ! empty( $meta[ $key ] ) && is_string( $meta[ $key ] ) ) {
                $version = (string) $meta[ $key ];
                break;
            }
        }
        if ( '' === $version ) {
            $version = defined( 'VE_RECOVERY_VERSION' ) ? (string) VE_RECOVERY_VERSION : 'unknown';
        }
        $version = strtolower( (string) preg_replace( '/[^A-Za-z0-9]+/', '-', $version ) );
        $version = trim( $version, '-' );
        $version = preg_replace( '/^v+/', '', $version );
        return $version ?: 'unknown-version';
    }

    private function sanitize_recent_limit( int $limit ): int {
        return in_array( $limit, [ 3, 5, 10 ], true ) ? $limit : 5;
    }

    private function recent_display_limit( string $option_name ): int {
        return $this->sanitize_recent_limit( absint( get_option( $option_name, 5 ) ) );
    }

    private function render_recent_limit_select( string $kind, int $selected ): void {
        $selected = $this->sanitize_recent_limit( $selected );
        ?>
        <div class="rb-limit-select" data-rb-limit-select="<?php echo esc_attr( $kind ); ?>">
            <button type="button" class="rb-limit-button" aria-expanded="false">
                <span data-rb-limit-value><?php echo esc_html( (string) $selected ); ?></span>
                <i class="ph-duotone ph-caret-down" aria-hidden="true"></i>
            </button>
            <div class="rb-limit-menu" hidden>
                <?php foreach ( [ 3, 5, 10 ] as $limit ) : ?>
                    <button type="button" class="rb-limit-option<?php echo $selected === $limit ? ' is-on' : ''; ?>" data-rb-limit-option="<?php echo esc_attr( (string) $limit ); ?>">
                        <span><?php echo esc_html( (string) $limit ); ?></span>
                        <i class="ph ph-check" aria-hidden="true"></i>
                    </button>
                <?php endforeach; ?>
            </div>
        </div>
        <?php
    }



    private function prepare_backup_ajax_request( bool $long = true ): void {
        if ( function_exists( 'nocache_headers' ) ) {
            nocache_headers();
        }
        if ( $long ) {
            @ignore_user_abort( true );
            if ( function_exists( 'set_time_limit' ) ) {
                @set_time_limit( 0 );
            }
        }
        if ( function_exists( 'wp_suspend_cache_addition' ) ) {
            wp_suspend_cache_addition( true );
        }
    }

    private function request_snapshot_key(): string {
        return isset( $_REQUEST['snapshot_key'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['snapshot_key'] ) ) : '';
    }

    /** Inline restore passphrase for encrypted packages. Not sanitize_text_field'd so symbols survive. */
    private function request_passphrase(): string {
        return isset( $_REQUEST['passphrase'] ) ? trim( (string) wp_unslash( $_REQUEST['passphrase'] ) ) : '';
    }

    private function check_ajax_request(): void {
        if ( ! Capability::can_manage() ) {
            wp_send_json_error( [ 'message' => __( 'Permission denied.', 'restorebase' ) ], 403 );
        }

        check_ajax_referer( 'restorebase_admin', 'nonce' );
    }

    /** Stricter gate for destructive actions (restore, rollback, staging swap). */
    private function check_ajax_restore_request(): void {
        if ( ! Capability::can_restore() ) {
            wp_send_json_error( [ 'message' => __( 'Restore permission denied.', 'restorebase' ) ], 403 );
        }

        check_ajax_referer( 'restorebase_admin', 'nonce' );
    }
}
