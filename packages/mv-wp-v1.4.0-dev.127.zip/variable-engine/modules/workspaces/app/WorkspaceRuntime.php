<?php
/**
 * Slice 7 — the first runtime family: Bricks variables.
 *
 * Slices 1–6 isolated STRUCTURAL objects: a page becomes a private shadow post,
 * and WordPress keeps a draft out of public queries without any help from MV.
 * That isolation survives MV being switched off, which is why §100.1.a could be
 * claimed plainly.
 *
 * A runtime family has no post to hide in. `bricks_global_variables` is one site
 * option that every request reads, so isolating it means answering that read
 * differently depending on who is asking. That is a weaker kind of isolation and
 * the wording matters: **isolation while MV runs**. Switch MV off and every
 * request sees the live option again, which is the honest behaviour and is what
 * §109.1 permits this slice to claim — no more.
 *
 * ── What the object-cache test settled (2026-09-16) ──────────────────────────
 *
 * Running WordPress's own option.php proved the read path is safe:
 * `get_option()` returns on `pre_option_{$option}` BEFORE it touches
 * `wp_load_alloptions()` or any `wp_cache_*`. An overlaid value therefore never
 * enters a persistent object cache, never enters `alloptions`, and a public
 * request reads the live row. See `scripts/check-workspace-object-cache.php`.
 *
 * The same test found the leak that is NOT obvious, and this class exists as
 * much for it as for the overlay: `update_option()` takes its old value THROUGH
 * `get_option()`, and therefore through the overlay. So a write during a
 * workspace session is compared against the workspace value rather than the live
 * one, and when they differ core writes it to the real row and caches it for
 * every visitor. `pre_update_option_*` is not tidiness. It is the only thing
 * standing between a workspace session and a real write.
 *
 * ── Why registration is early and resolution is late ─────────────────────────
 *
 * From core's own wp-settings.php: pluggable.php loads at line 623,
 * `plugins_loaded` fires at 641, `init` at 790. So the filters can be registered
 * on `plugins_loaded` — early enough to precede Bricks constructing its
 * `Database` and caching globals into a static, which a later filter could never
 * reach.
 *
 * But WHO is asking cannot be answered that early without deciding the current
 * user before other plugins have had their say on `determine_current_user`. So
 * registration is early and resolution is lazy: before `init`, this class
 * answers "no session", and a request that cannot know who it is serves LIVE.
 * Every uncertainty in here falls the same way. A workspace value reaching a
 * visitor is the failure §85 exists to prevent; an editor seeing the live value
 * for one early read is an inconvenience.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceRuntime {

    /** The one family this slice covers. Slice 9 adds the others. */
    public const FAMILY_VARIABLES = 'bricks_global_variables';

    /** Where a user's current workspace is remembered. */
    public const SESSION_META = '_ve_workspace_session';

    /** @var int|null Resolved session, per request. Null means "not yet". */
    private static $session = null;

    /** @var bool Re-entrancy: our own reads must not come back through us. */
    private static $resolving = false;

    /** @var bool|null Cached per request. */
    private static $inline_mode = null;

    /** Slice 8. Hashes of Live writes MV was present for. */
    public const WITNESS_KEY = 've_ws_witnessed';

    /** How many recent Live writes are remembered per family. */
    private const WITNESS_KEEP = 20;

    public static function register(): void {
        add_filter( 'pre_option_' . self::FAMILY_VARIABLES, [ self::class, 'read_overlay' ], 10, 1 );
        add_filter( 'pre_update_option_' . self::FAMILY_VARIABLES, [ self::class, 'hold_write' ], 10, 2 );
    }

    /**
     * The workspace this request is working inside, or 0.
     *
     * Not cached before `init`: the answer there is "cannot know", which is a
     * different thing from "none", and caching it would make the rest of the
     * request wrong.
     */
    public static function session_id(): int {
        if ( null !== self::$session ) {
            return self::$session;
        }
        if ( ! did_action( 'init' ) ) {
            return 0;
        }
        if ( ! function_exists( 'get_current_user_id' ) ) {
            return 0;
        }

        $user_id = (int) get_current_user_id();
        if ( $user_id <= 0 ) {
            // A logged-out visitor is never inside a workspace. This is §85.
            self::$session = 0;
            return 0;
        }

        $id = (int) get_user_meta( $user_id, self::SESSION_META, true );
        if ( $id <= 0 ) {
            self::$session = 0;
            return 0;
        }

        /* A session pointing at a workspace that has been discarded, archived or
           published is not a session. Checked every request rather than trusted,
           because the meta outlives the workspace. */
        $workspace = class_exists( __NAMESPACE__ . '\WorkspaceStore' ) ? WorkspaceStore::get( $id ) : null;
        $open      = is_array( $workspace ) && in_array( (string) ( $workspace['status'] ?? '' ), [ 'open', 'active', 'draft' ], true );

        self::$session = $open ? $id : 0;
        return self::$session;
    }

    /** Somebody opened a workspace. */
    public static function begin_session( int $user_id, int $workspace_id ): bool {
        if ( $user_id <= 0 || $workspace_id <= 0 ) {
            return false;
        }
        self::$session = null;
        $ok = (bool) update_user_meta( $user_id, self::SESSION_META, $workspace_id );

        /* §100.1.1. Live is written down at the moment the session opens, and
           this is the only moment it can be: after this the overlay is answering
           for the family, and a later reading would record the workspace's own
           value as the base it is supposed to be measured against. */
        if ( $ok && class_exists( __NAMESPACE__ . '\\WorkspaceFingerprint' ) ) {
            WorkspaceFingerprint::record( $workspace_id );
        }

        return $ok;
    }

    /** …and closed it. */
    public static function end_session( int $user_id ): bool {
        if ( $user_id <= 0 ) {
            return false;
        }
        self::$session = null;
        return (bool) delete_user_meta( $user_id, self::SESSION_META );
    }

    /**
     * §109.1 — inline CSS mode only.
     *
     * In file mode Bricks writes the variables into shared .css files on save,
     * and overlaying the option would leave those files holding workspace
     * values for every visitor. The option would be isolated and the site would
     * not be. Slice 10 is where file mode is dealt with; until then this slice
     * declines rather than claims something it cannot deliver.
     */
    public static function enabled(): bool {
        if ( null !== self::$inline_mode ) {
            return self::$inline_mode;
        }
        self::$resolving = true;
        $settings = get_option( 'bricks_global_settings', [] );
        self::$resolving = false;

        $settings = is_array( $settings ) ? $settings : [];
        $mode     = isset( $settings['cssLoading'] ) ? (string) $settings['cssLoading'] : '';

        self::$inline_mode = ( 'file' !== $mode );
        return self::$inline_mode;
    }

    /** Where a workspace keeps its runtime values. One option per workspace. */
    public static function store_key( int $workspace_id ): string {
        return 've_ws_runtime_' . $workspace_id;
    }

    /**
     * @return mixed The workspace's value for a family, or null if it has none.
     *               Null is not "empty" — it means the workspace has never been
     *               told about this family, and the answer is Live.
     */
    public static function payload( int $workspace_id, string $family ) {
        if ( $workspace_id <= 0 ) {
            return null;
        }
        self::$resolving = true;
        $all = get_option( self::store_key( $workspace_id ), [] );
        self::$resolving = false;

        if ( ! is_array( $all ) || ! array_key_exists( $family, $all ) ) {
            return null;
        }
        return $all[ $family ];
    }

    public static function set_payload( int $workspace_id, string $family, $value ): bool {
        if ( $workspace_id <= 0 ) {
            return false;
        }
        self::$resolving = true;
        $key = self::store_key( $workspace_id );
        $all = get_option( $key, [] );
        $all = is_array( $all ) ? $all : [];
        $all[ $family ] = $value;
        $ok = update_option( $key, $all, false );
        self::$resolving = false;

        return (bool) $ok;
    }

    /** Forget everything a workspace held. Used when one is discarded. */
    public static function forget( int $workspace_id ): bool {
        if ( $workspace_id <= 0 ) {
            return false;
        }
        self::$resolving = true;
        $ok = delete_option( self::store_key( $workspace_id ) );
        self::$resolving = false;
        return (bool) $ok;
    }

    /**
     * The read side. Returning anything but false short-circuits get_option(),
     * BEFORE it reads or writes any cache — which is the whole reason this is
     * safe, and is proved against core rather than assumed.
     *
     * @param mixed $pre False to carry on to the real option.
     * @return mixed
     */
    public static function read_overlay( $pre ) {
        if ( self::$resolving ) {
            return $pre;
        }
        if ( ! self::enabled() ) {
            return $pre;
        }
        $workspace_id = self::session_id();
        if ( $workspace_id <= 0 ) {
            return $pre;
        }

        $value = self::payload( $workspace_id, self::FAMILY_VARIABLES );
        if ( null === $value ) {
            /* The workspace has not touched variables, so there is nothing to
               overlay and Live is the correct answer. Inventing an empty array
               here would blank every variable on the site for the editor. */
            return $pre;
        }
        return $value;
    }

    /**
     * The write side, and the half the object-cache test made non-optional.
     *
     * Returning $old is what makes core's own equality check return false
     * before it writes the row or the cache. The value goes to the workspace
     * instead.
     *
     * @param mixed $value The value somebody is trying to store.
     * @param mixed $old   What get_option() said — and get_option() went
     *                     through the overlay above, so this is the WORKSPACE
     *                     value when a session is on.
     * @return mixed
     */
    public static function hold_write( $value, $old ) {
        if ( self::$resolving ) {
            return $value;
        }
        if ( ! self::enabled() ) {
            return $value;
        }
        $workspace_id = self::session_id();
        if ( $workspace_id <= 0 ) {
            /* No session, so this write is going to Live and MV is standing here
               watching it happen. Slice 8 needs that fact recorded: it is what
               tells a legitimate edit apart from a value that appeared while MV
               was not running. See WorkspaceFingerprint's header. */
            self::witness( self::FAMILY_VARIABLES, $value );
            return $value;
        }

        self::set_payload( $workspace_id, self::FAMILY_VARIABLES, $value );

        /* Hand core back what it already believes, so it writes nothing. */
        return $old;
    }

    /**
     * Run something with the overlay stood down.
     *
     * Restores the previous state rather than setting false, because these nest:
     * the fingerprint reads its own option inside a call that is already inside
     * one, and a naive reset would switch the overlay back on halfway through
     * somebody else's raw read.
     *
     * @param callable $fn
     * @return mixed Whatever $fn returned.
     */
    public static function without_overlay( callable $fn ) {
        $was = self::$resolving;
        self::$resolving = true;
        try {
            return $fn();
        } finally {
            self::$resolving = $was;
        }
    }

    /**
     * The option as the SITE has it, with the overlay stood down.
     *
     * Slice 8 needs this: a fingerprint of Live taken through the overlay would
     * be a fingerprint of the workspace, and would match itself forever.
     *
     * @return mixed
     */
    public static function live_value( string $family ) {
        return self::without_overlay( static function () use ( $family ) {
            return get_option( $family, null );
        } );
    }

    /**
     * Put Live back, with the overlay stood down so the write is not held.
     *
     * The only place in the module that writes a live global on purpose, and it
     * only ever writes back a value MV recorded itself.
     */
    public static function restore_live( string $family, $value ): bool {
        return (bool) self::without_overlay( static function () use ( $family, $value ) {
            return update_option( $family, $value );
        } );
    }

    /**
     * Slice 8 - write down that MV was present when Live changed.
     *
     * This is the whole discriminator behind §100.1.b, so it is worth being
     * plain about what it means. `pre_update_option_*` fires for EVERY write to
     * the family, including writes by somebody with no workspace open. A write
     * MV saw is a write MV could have held had it needed holding - so it is not
     * a leak, whatever value it happens to carry. A leak is by definition a
     * write MV was not running for.
     *
     * A short list rather than one hash: an admin can make several Live edits
     * between two inspections, and only the newest would otherwise be witnessed.
     */
    public static function witness( string $family, $value ): void {
        $hash = self::hash( $value );
        self::without_overlay( static function () use ( $family, $hash ) {
            $all = get_option( self::WITNESS_KEY, [] );
            $all = is_array( $all ) ? $all : [];
            $for = isset( $all[ $family ] ) && is_array( $all[ $family ] ) ? $all[ $family ] : [];

            if ( in_array( $hash, $for, true ) ) {
                return;
            }
            array_unshift( $for, $hash );
            $all[ $family ] = array_slice( $for, 0, self::WITNESS_KEEP );

            update_option( self::WITNESS_KEY, $all, false );
        } );
    }

    public static function was_witnessed( string $family, string $hash ): bool {
        $all = self::without_overlay( static function () {
            return get_option( self::WITNESS_KEY, [] );
        } );
        $all = is_array( $all ) ? $all : [];
        $for = isset( $all[ $family ] ) && is_array( $all[ $family ] ) ? $all[ $family ] : [];

        return in_array( $hash, $for, true );
    }

    /** @param mixed $value */
    private static function hash( $value ): string {
        if ( class_exists( 'VE\\Core\\CanonicalJson' ) ) {
            return \VE\Core\CanonicalJson::hash( $value );
        }
        return hash( 'sha256', (string) maybe_serialize( $value ) );
    }

    /** For tests and for a request that has genuinely changed identity. */
    public static function forget_session_cache(): void {
        self::$session     = null;
        self::$inline_mode = null;
    }
}
