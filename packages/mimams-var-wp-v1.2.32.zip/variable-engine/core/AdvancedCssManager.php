<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

class AdvancedCssManager {

    private const OPTION = 've_advanced_css';

    public function get(): array {
        $data = get_option( self::OPTION, [] );
        if ( ! is_array( $data ) ) {
            $data = [];
        }

        $sheets = $data['stylesheets'] ?? [];
        if ( ! is_array( $sheets ) || empty( $sheets ) ) {
            $sheets = $this->default_sheets();
        }

        return [
            'stylesheets' => array_values( array_map( [ $this, 'normalize_sheet' ], $sheets ) ),
            'file_url'    => $this->file_url(),
            'file_path'   => $this->file_path(),
        ];
    }

    public function save( array $sheets ): array {
        $clean = [];
        foreach ( $sheets as $sheet ) {
            if ( ! is_array( $sheet ) ) {
                continue;
            }
            $clean[] = $this->normalize_sheet( $sheet );
        }

        if ( empty( $clean ) ) {
            $clean = $this->default_sheets();
        }

        update_option( self::OPTION, [ 'stylesheets' => $clean ], false );
        $this->compile();

        return $this->get();
    }

    public function suggestions(): array {
        global $wpdb;

        $classes = [];
        $ids     = [];
        $vars    = [];
        $cached  = get_transient( 've_advanced_css_suggestions_scan_v8' );

        $var_table = Schema::table( 'variables' );
        $rows = $wpdb->get_results( "SELECT name FROM {$var_table} ORDER BY name ASC", ARRAY_A ) ?: [];
        $manager = new VariableManager();
        foreach ( $rows as $row ) {
            $name = (string) ( $row['name'] ?? '' );
            if ( '' !== $name ) {
                $vars[] = $manager->to_css_name( $name );
            }
        }

        if ( is_array( $cached ) ) {
            return [
                'variables' => $this->sorted_keys( array_merge( $vars, $cached['variables'] ?? [] ) ),
                'classes'   => $cached['classes'] ?? [],
                'ids'       => $cached['ids'] ?? [],
                'sources'   => $cached['sources'] ?? [ "Mimam's Var" ],
            ];
        }

        $scan_text = [];
        $posts = $wpdb->get_col(
             "SELECT post_content FROM {$wpdb->posts}
             WHERE post_status NOT IN ('trash','auto-draft')
             ORDER BY post_modified_gmt DESC
             LIMIT 2000"
        ) ?: [];
        $scan_text = array_merge( $scan_text, $posts );

        $meta_rows = $wpdb->get_col(
            "SELECT meta_value FROM {$wpdb->postmeta}
             WHERE meta_key LIKE '_bricks_%'
                OR meta_key LIKE 'bricks_%'
                OR meta_key LIKE '%global%class%'
                OR meta_key LIKE '%class%'
                OR meta_key LIKE '%css%'
             ORDER BY meta_id DESC
             LIMIT 5000"
        ) ?: [];
        $scan_text = array_merge( $scan_text, $meta_rows );

        $option_rows = $wpdb->get_col(
            "SELECT option_value FROM {$wpdb->options}
             WHERE option_name LIKE 'bricks_%'
                OR option_name LIKE '_bricks_%'
                OR option_name LIKE '%bricks%'
                OR option_name IN ('bricks_global_classes','bricks_global_variables','bricks_theme_styles','bricks_global_elements','bricks_global_settings')
                OR option_name LIKE '%global_classes%'
                OR option_name LIKE '%global%classes%'
                OR option_name LIKE 'core_framework%'
                OR option_name LIKE '%core%framework%'
                OR option_name LIKE 'automatic_css%'
                OR option_name LIKE '%automatic%css%'
                OR option_name LIKE '%acss%'
                OR option_name LIKE '%advanced%themer%'
                OR option_name LIKE '%advanced_themer%'
                OR option_name LIKE '%plain%classes%'
                OR option_name LIKE '%css%variable%'
                OR option_name LIKE '%class%'
                OR option_name LIKE '%custom_css%'
             LIMIT 1500"
        ) ?: [];
        $scan_text = array_merge( $scan_text, $option_rows );
        $scan_text = array_merge( $scan_text, $this->generated_css_chunks() );
        $scan_text = array_merge( $scan_text, $this->source_file_chunks() );

        $terms = $wpdb->get_col(
            "SELECT slug FROM {$wpdb->terms}
             WHERE slug REGEXP '^[A-Za-z_][A-Za-z0-9_-]+$'
             ORDER BY term_id DESC
             LIMIT 1500"
        ) ?: [];
        foreach ( $terms as $term ) {
            $this->add_identifier( $classes, (string) $term, '.' );
        }

        foreach ( $scan_text as $text ) {
            $text = maybe_unserialize( $text );
            if ( is_array( $text ) || is_object( $text ) ) {
                $this->extract_identifiers_from_data( $text, $classes, $ids, $vars );
                $text = wp_json_encode( $text );
            }
            $text = substr( (string) $text, 0, 250000 );
            if ( '' === $text ) {
                continue;
            }

            $decoded = json_decode( $text, true );
            if ( is_array( $decoded ) ) {
                $this->extract_identifiers_from_data( $decoded, $classes, $ids, $vars );
            }

            $this->extract_css_custom_properties( $text, $vars );
            $this->extract_bricks_class_records( $text, $classes );

            if ( preg_match_all( '/class(?:Name)?=["\']([^"\']+)["\']/i', $text, $matches ) ) {
                foreach ( $matches[1] as $match ) {
                    foreach ( preg_split( '/\s+/', $match ) as $class ) {
                        $this->add_identifier( $classes, $class, '.' );
                    }
                }
            }

            if ( preg_match_all( '/"class(?:Name)?"\s*:\s*"([^"]+)"/i', $text, $matches ) ) {
                foreach ( $matches[1] as $match ) {
                    foreach ( preg_split( '/\s+/', $match ) as $class ) {
                        $this->add_identifier( $classes, $class, '.' );
                    }
                }
            }

            if ( preg_match_all( '/id=["\']([A-Za-z][A-Za-z0-9_-]*)["\']/i', $text, $matches ) ) {
                foreach ( $matches[1] as $id ) {
                    $this->add_identifier( $ids, $id, '#' );
                }
            }

            if ( preg_match_all( '/"id"\s*:\s*"([A-Za-z][A-Za-z0-9_-]*)"/i', $text, $matches ) ) {
                foreach ( $matches[1] as $id ) {
                    $this->add_identifier( $ids, $id, '#' );
                }
            }

            if ( preg_match_all( '/\.([A-Za-z_][A-Za-z0-9_-]*)/', $text, $matches ) ) {
                foreach ( $matches[1] as $class ) {
                    $this->add_identifier( $classes, $class, '.' );
                }
            }

            if ( preg_match_all( '/#([A-Za-z_][A-Za-z0-9_-]*)/', $text, $matches ) ) {
                foreach ( $matches[1] as $id ) {
                    $this->add_identifier( $ids, $id, '#' );
                }
            }
        }

        $migration_scanner = new MigrationScanner();
        foreach ( $migration_scanner->scan( 'all' ) as $external_var ) {
            if ( ! empty( $external_var['name'] ) ) {
                $vars[] = $manager->to_css_name( (string) $external_var['name'] );
            }
        }

        $sources = $migration_scanner->sources();
        $source_labels = [ "Mimam's Var" ];
        foreach ( $sources as $source ) {
            if ( ! empty( $source['available'] ) ) {
                if ( 'Bricks / Advanced Themer' === $source['name'] ) {
                    $source_labels[] = 'Bricks';
                    $source_labels[] = 'Advanced Themer';
                } else {
                    $source_labels[] = (string) $source['name'];
                }
            }
        }
        if ( ! empty( $classes ) ) {
            $source_labels[] = 'CSS Classes';
        }
        if ( ! empty( $ids ) ) {
            $source_labels[] = 'Element IDs';
        }

        $scan = [
            'variables' => $this->sorted_keys( $vars ),
            'classes' => $this->sorted_keys( array_keys( $classes ) ),
            'ids'     => $this->sorted_keys( array_keys( $ids ) ),
            'sources' => array_values( array_unique( $source_labels ) ),
        ];
        set_transient( 've_advanced_css_suggestions_scan_v8', $scan, 5 * MINUTE_IN_SECONDS );

        return [
            'variables' => $scan['variables'],
            'classes'   => $scan['classes'],
            'ids'       => $scan['ids'],
            'sources'   => $scan['sources'],
        ];
    }

    public function compile(): array {
        $data   = $this->get();
        $sheets = $data['stylesheets'];
        $lines  = [
            '/*',
            " * Mimam's Var - CSS Studio",
            ' * Version: ' . VE_VERSION,
            ' * Compiled: ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC',
            ' */',
            '',
        ];

        foreach ( $sheets as $sheet ) {
            if ( empty( $sheet['enabled'] ) || '' === trim( (string) $sheet['css'] ) ) {
                continue;
            }
            $lines[] = '/* === ' . $sheet['name'] . ' (' . $sheet['scope'] . ') === */';
            $lines[] = rtrim( (string) $sheet['css'] );
            $lines[] = '';
        }

        if ( ! is_dir( VE_CSS_OUTPUT_DIR ) ) {
            wp_mkdir_p( VE_CSS_OUTPUT_DIR );
        }

        $written = file_put_contents( $this->file_path(), implode( "\n", $lines ) );

        return [
            'compiled'  => false !== $written,
            'file_url'  => $this->file_url(),
            'file_path' => $this->file_path(),
        ];
    }

    private function normalize_sheet( array $sheet ): array {
        $id = sanitize_key( (string) ( $sheet['id'] ?? '' ) );
        if ( '' === $id ) {
            $id = 'sheet_' . substr( md5( wp_json_encode( $sheet ) . microtime( true ) ), 0, 8 );
        }

        $scope = sanitize_key( (string) ( $sheet['scope'] ?? 'global' ) );
        if ( ! in_array( $scope, [ 'page', 'global', 'child', 'custom', 'recipe' ], true ) ) {
            $scope = 'custom';
        }

        return [
            'id'      => $id,
            'name'    => sanitize_text_field( (string) ( $sheet['name'] ?? 'custom.css' ) ),
            'scope'   => $scope,
            'enabled' => ! isset( $sheet['enabled'] ) || ! empty( $sheet['enabled'] ),
            'css'     => wp_kses_post( (string) ( $sheet['css'] ?? '' ) ),
        ];
    }

    private function default_sheets(): array {
        return [
            [ 'id' => 'global', 'name' => 'global.css', 'scope' => 'global', 'enabled' => true, 'css' => '' ],
        ];
    }

    private function add_identifier( array &$bucket, string $value, string $prefix ): void {
        $value = trim( html_entity_decode( $value, ENT_QUOTES, 'UTF-8' ) );
        $value = preg_replace( '/[^A-Za-z0-9_-]/', '', $value );
        if ( ! is_string( $value ) || '' === $value || is_numeric( $value[0] ) ) {
            return;
        }
        if ( 80 < strlen( $value ) ) {
            return;
        }
        if ( '#' === $prefix && preg_match( '/^[A-Fa-f0-9]{3,8}$/', $value ) ) {
            return;
        }
        $bucket[ $prefix . $value ] = true;
    }

    private function add_css_variable( array &$vars, string $value ): void {
        $value = trim( html_entity_decode( $value, ENT_QUOTES, 'UTF-8' ) );
        if ( '' === $value ) {
            return;
        }
        if ( 0 !== strpos( $value, '--' ) ) {
            $value = '--' . ltrim( $value, '-' );
        }
        $value = strtolower( preg_replace( '/[^a-zA-Z0-9_-]/', '-', $value ) );
        $value = preg_replace( '/-+/', '-', $value );
        $value = '--' . trim( substr( $value, 2 ), '-' );
        if ( ! preg_match( '/^--[a-z][a-z0-9_-]{1,120}$/', $value ) ) {
            return;
        }
        $vars[] = $value;
    }

    private function extract_css_custom_properties( string $text, array &$vars ): void {
        if ( preg_match_all( '/--([a-zA-Z][a-zA-Z0-9_-]*)\s*:/', $text, $matches ) ) {
            foreach ( $matches[1] as $name ) {
                $this->add_css_variable( $vars, '--' . $name );
            }
        }
        if ( preg_match_all( '/var\(\s*(--[a-zA-Z][a-zA-Z0-9_-]*)/', $text, $matches ) ) {
            foreach ( $matches[1] as $name ) {
                $this->add_css_variable( $vars, $name );
            }
        }
    }

    private function extract_bricks_class_records( string $text, array &$classes ): void {
        if ( false === stripos( $text, 'globalClassesNamesIds' )
            && false === stripos( $text, 'global_classes' )
            && false === stripos( $text, 'globalClasses' )
        ) {
            return;
        }

        if ( preg_match_all( '/["\']name["\']\s*:\s*["\']([^"\']{1,120})["\']/i', $text, $matches ) ) {
            foreach ( $matches[1] as $name ) {
                $this->add_identifier( $classes, ltrim( (string) $name, '.' ), '.' );
            }
        }

        if ( preg_match_all( '/["\']selector["\']\s*:\s*["\']\.([^"\']{1,120})["\']/i', $text, $matches ) ) {
            foreach ( $matches[1] as $name ) {
                $this->add_identifier( $classes, (string) $name, '.' );
            }
        }
    }

    private function generated_css_chunks(): array {
        $upload = wp_upload_dir();
        $root   = (string) ( $upload['basedir'] ?? '' );
        if ( '' === $root || ! is_dir( $root ) ) {
            return [];
        }

        $chunks = [];
        $files  = 0;
        $bytes  = 0;

        try {
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS )
            );

            foreach ( $iterator as $file ) {
                if ( 80 <= $files || 3000000 <= $bytes ) {
                    break;
                }
                if ( ! $file->isFile() || 'css' !== strtolower( $file->getExtension() ) ) {
                    continue;
                }

                $path = strtolower( str_replace( '\\', '/', $file->getPathname() ) );
                if ( false === strpos( $path, '/bricks/' )
                    && false === strpos( $path, '/automatic' )
                    && false === strpos( $path, '/acss' )
                    && false === strpos( $path, '/core-framework' )
                    && false === strpos( $path, '/advanced-themer' )
                    && false === strpos( $path, '/variable-engine' )
                ) {
                    continue;
                }

                $size = (int) $file->getSize();
                if ( 0 >= $size || 500000 < $size ) {
                    continue;
                }

                $content = file_get_contents( $file->getPathname() );
                if ( false === $content || '' === $content ) {
                    continue;
                }

                $chunks[] = substr( $content, 0, 250000 );
                $files++;
                $bytes += $size;
            }
        } catch ( \Throwable $e ) {
            return $chunks;
        }

        return $chunks;
    }

    private function source_file_chunks(): array {
        $roots = [];
        if ( function_exists( 'get_stylesheet_directory' ) ) {
            $roots[] = get_stylesheet_directory();
        }
        if ( function_exists( 'get_template_directory' ) ) {
            $roots[] = get_template_directory();
        }

        if ( defined( 'WP_PLUGIN_DIR' ) && is_dir( WP_PLUGIN_DIR ) ) {
            try {
                foreach ( new \DirectoryIterator( WP_PLUGIN_DIR ) as $plugin ) {
                    if ( ! $plugin->isDir() || $plugin->isDot() ) {
                        continue;
                    }
                    $name = strtolower( $plugin->getFilename() );
                    if ( preg_match( '/(bricks|automatic|acss|advanced[-_]?themer|core[-_]?framework|wpcodebox|code2bricks|etch)/', $name ) ) {
                        $roots[] = $plugin->getPathname();
                    }
                }
            } catch ( \Throwable $e ) {
                // Keep suggestions available even if a plugin folder cannot be read.
            }
        }

        return $this->read_source_chunks( array_values( array_unique( array_filter( $roots ) ) ) );
    }

    private function read_source_chunks( array $roots ): array {
        $chunks = [];
        $files  = 0;
        $bytes  = 0;
        $exts   = [ 'css' => true, 'scss' => true, 'less' => true, 'json' => true ];

        foreach ( $roots as $root ) {
            if ( 120 <= $files || 4000000 <= $bytes || ! is_string( $root ) || ! is_dir( $root ) ) {
                continue;
            }

            try {
                $iterator = new \RecursiveIteratorIterator(
                    new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS )
                );

                foreach ( $iterator as $file ) {
                    if ( 120 <= $files || 4000000 <= $bytes ) {
                        break 2;
                    }
                    if ( ! $file->isFile() ) {
                        continue;
                    }

                    $ext = strtolower( $file->getExtension() );
                    if ( ! isset( $exts[ $ext ] ) ) {
                        continue;
                    }

                    $path = strtolower( str_replace( '\\', '/', $file->getPathname() ) );
                    if ( false !== strpos( $path, '/vendor/' )
                        || false !== strpos( $path, '/node_modules/' )
                        || false !== strpos( $path, '/acf-pro/' )
                        || false !== strpos( $path, '/codemirror/' )
                        || false !== strpos( $path, '.min.css' )
                        || false !== strpos( $path, '.min.js' )
                    ) {
                        continue;
                    }

                    $size = (int) $file->getSize();
                    if ( 0 >= $size || 400000 < $size ) {
                        continue;
                    }

                    $content = file_get_contents( $file->getPathname() );
                    if ( false === $content || '' === $content ) {
                        continue;
                    }

                    $chunks[] = substr( $content, 0, 250000 );
                    $files++;
                    $bytes += $size;
                }
            } catch ( \Throwable $e ) {
                continue;
            }
        }

        return $chunks;
    }

    private function extract_identifiers_from_data( $data, array &$classes, array &$ids, array &$vars, string $parent_key = '', int $depth = 0 ): void {
        if ( 8 < $depth ) {
            return;
        }

        if ( is_object( $data ) ) {
            $data = (array) $data;
        }

        if ( ! is_array( $data ) ) {
            if ( '' !== $parent_key ) {
                $this->extract_identifier_value( $parent_key, $data, $classes, $ids, $vars );
            }
            return;
        }

        foreach ( $data as $key => $value ) {
            $key_string = is_string( $key ) ? $key : $parent_key;
            if ( '' !== $key_string ) {
                $this->extract_identifier_value( $key_string, $value, $classes, $ids, $vars, $parent_key );
            }

            if ( is_array( $value ) || is_object( $value ) ) {
                $this->extract_structured_item( $value, $classes, $ids, $vars, $key_string );
                $this->extract_identifiers_from_data( $value, $classes, $ids, $vars, $key_string, $depth + 1 );
            }
        }
    }

    private function extract_structured_item( $value, array &$classes, array &$ids, array &$vars, string $context ): void {
        if ( is_object( $value ) ) {
            $value = (array) $value;
        }
        if ( ! is_array( $value ) ) {
            return;
        }

        $context = strtolower( $context );
        $class_context = false !== strpos( $context, 'class' ) || false !== strpos( $context, 'globalclasses' );
        $var_context   = false !== strpos( $context, 'variable' ) || false !== strpos( $context, 'token' ) || false !== strpos( $context, 'cssvar' );

        foreach ( [ 'name', 'label', 'title', 'selector', 'class', 'className', 'class_name', 'slug' ] as $field ) {
            if ( isset( $value[ $field ] ) && ( $class_context || in_array( $field, [ 'selector', 'class', 'className', 'class_name' ], true ) ) ) {
                $raw = (string) $value[ $field ];
                foreach ( preg_split( '/[\s,]+/', $raw ) ?: [] as $part ) {
                    $this->add_identifier( $classes, ltrim( trim( $part ), '.' ), '.' );
                }
            }
        }

        foreach ( [ 'id', '_id', 'elementId', 'anchor', 'cssId' ] as $field ) {
            if ( isset( $value[ $field ] ) && false !== strpos( strtolower( $field ), 'id' ) ) {
                $this->add_identifier( $ids, ltrim( (string) $value[ $field ], '#' ), '#' );
            }
        }

        foreach ( [ 'var', 'variable', 'cssVar', 'css_var', 'token', 'name', 'id' ] as $field ) {
            if ( isset( $value[ $field ] ) && $var_context ) {
                $this->add_css_variable( $vars, (string) $value[ $field ] );
            }
        }
    }

    private function extract_identifier_value( string $key, $value, array &$classes, array &$ids, array &$vars, string $parent_key = '' ): void {
        $key_l = strtolower( $key );
        $parent_l = strtolower( $parent_key );
        $is_class_key = false !== strpos( $key_l, 'class' ) || false !== strpos( $parent_l, 'class' );
        $is_id_key    = 'id' === $key_l || false !== strpos( $key_l, '_id' ) || false !== strpos( $key_l, '-id' ) || false !== strpos( $key_l, 'id_' );
        $is_var_key   = false !== strpos( $key_l, 'variable' ) || false !== strpos( $key_l, 'cssvar' ) || false !== strpos( $key_l, 'css_var' ) || false !== strpos( $key_l, 'token' ) || false !== strpos( $parent_l, 'variable' ) || false !== strpos( $parent_l, 'token' );

        if ( ! $is_class_key && ! $is_id_key && ! $is_var_key ) {
            return;
        }

        if ( is_array( $value ) || is_object( $value ) ) {
            $value = wp_json_encode( $value );
        }

        $value = trim( (string) $value );
        if ( '' === $value || 2000 < strlen( $value ) ) {
            return;
        }

        $tokens = preg_split( '/[\s,"\':;\[\]\{\}]+/', $value ) ?: [];
        foreach ( $tokens as $token ) {
            $token = trim( $token );
            if ( '' === $token ) {
                continue;
            }
            if ( $is_class_key ) {
                $this->add_identifier( $classes, ltrim( $token, '.' ), '.' );
            }
            if ( $is_id_key ) {
                $this->add_identifier( $ids, ltrim( $token, '#' ), '#' );
            }
            if ( $is_var_key || 0 === strpos( $token, '--' ) ) {
                $this->add_css_variable( $vars, $token );
            }
        }
    }

    private function sorted_keys( array $items ): array {
        $items = array_values( array_unique( array_filter( $items ) ) );
        natcasesort( $items );
        return array_values( array_slice( $items, 0, 10000 ) );
    }

    private function file_path(): string {
        return VE_CSS_OUTPUT_DIR . 'advanced.css';
    }

    private function file_url(): string {
        return VE_CSS_OUTPUT_URL . 'advanced.css';
    }
}
