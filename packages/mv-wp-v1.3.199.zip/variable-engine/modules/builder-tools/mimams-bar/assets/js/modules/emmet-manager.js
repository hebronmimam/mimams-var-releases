(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarEmmet) return;

  var ALIASES = {
    sec: 'section', section: 'section',
    cont: 'container', container: 'container',
    wrap: 'container', wrapper: 'container',
    block: 'block', blk: 'block',
    div: 'div',
    btn: 'button', button: 'button',
    img: 'image', image: 'image',
    icon: 'icon',
    svg: 'svg',
    text: 'text', txt: 'text', p: 'text',
    rich: 'rich-text', 'rich-text': 'rich-text',
    h: 'heading', h1: 'heading', h2: 'heading', h3: 'heading', h4: 'heading', h5: 'heading', h6: 'heading', heading: 'heading'
  };

  var SEMANTIC_BLOCK_TAGS = {
    article: true, aside: true, footer: true, header: true, main: true,
    figure: true, figcaption: true, ul: true, ol: true, li: true
  };

  var SEMANTIC_TEXT_TAGS = {
    p: true, span: true, a: true, label: true, blockquote: true,
    cite: true, small: true, strong: true, em: true
  };

  function cleanToken(token) {
    token = String(token || '').trim().toLowerCase();
    token = token.replace(/[#.][a-z0-9_-]+/g, '');
    token = token.replace(/\[[^\]]*\]/g, '');
    token = token.replace(/\*\d+$/g, '');
    return token.trim();
  }

  function alias(value) {
    value = cleanToken(value);
    return ALIASES[value] || value;
  }

  function resolveElement(value) {
    var token = cleanToken(value);
    if (!token) return null;

    if (/^h[1-6]$/.test(token)) {
      return { name: 'heading', label: token, settings: { _tag: token } };
    }
    if (SEMANTIC_BLOCK_TAGS[token]) {
      return { name: 'block', label: token, settings: { _tag: token } };
    }
    if (SEMANTIC_TEXT_TAGS[token]) {
      return { name: 'text', label: token, settings: { _tag: token } };
    }

    var name = alias(token);
    return { name: name, label: name, settings: {} };
  }



  function getLastTokenRange(value, caret) {
    value = String(value || '');
    caret = typeof caret === 'number' ? caret : value.length;
    if (caret < 0) caret = 0;
    if (caret > value.length) caret = value.length;

    var start = caret;
    while (start > 0 && !/[>+\s]/.test(value.charAt(start - 1))) start--;

    var end = caret;
    while (end < value.length && !/[>+\s]/.test(value.charAt(end))) end++;

    return { start: start, end: end, token: value.slice(start, end) };
  }

  function completeToken(token) {
    var raw = String(token || '');
    var cleaned = cleanToken(raw);
    if (!cleaned) return '';

    // Preserve heading shortcuts because h2/h3 are useful element aliases already.
    if (/^h[1-6]$/.test(cleaned)) return cleaned;

    if (ALIASES[cleaned]) return ALIASES[cleaned];

    // Also complete partial aliases / canonical element names.
    // This makes cont, con, btn, but, img, sec, blk, etc. reliable.
    var candidates = [];
    Object.keys(ALIASES).forEach(function (key) {
      var value = ALIASES[key];
      if (key.indexOf(cleaned) === 0 || value.indexOf(cleaned) === 0) {
        candidates.push(value);
      }
    });

    if (!candidates.length) return '';
    candidates.sort(function (a, b) {
      if (a.length !== b.length) return a.length - b.length;
      return a.localeCompare(b);
    });
    return candidates[0];
  }

  function completeAt(value, caret) {
    value = String(value || '');
    caret = typeof caret === 'number' ? caret : value.length;
    var range = getLastTokenRange(value, caret);
    var completion = completeToken(range.token);

    if (!completion || completion === range.token) {
      return { changed: false, value: value, caret: caret, completion: completion || '' };
    }

    var nextValue = value.slice(0, range.start) + completion + value.slice(range.end);
    var nextCaret = range.start + completion.length;
    return { changed: true, value: nextValue, caret: nextCaret, completion: completion };
  }

  function looksLikeChain(value) {
    return /[>+*#.[\]]/.test(String(value || ''));
  }

  function parse(value) {
    value = String(value || '').trim();
    if (!value || !looksLikeChain(value)) return null;

    // Safe first pass: support simple parent chain with >. Siblings/classes/ids
    // are accepted for recognition but ignored until deeper Bricks state work is stable.
    var elements = value.split('>').map(function (part) {
      return resolveElement(part.split('+')[0]);
    }).filter(Boolean);
    var chain = elements.map(function (element) { return element.label; });

    if (!chain.length) return null;
    if (chain.length > 4) {
      return { ok: false, reason: 'too-deep', abbreviation: value, chain: chain, elements: elements };
    }

    return { ok: true, abbreviation: value, chain: chain, elements: elements };
  }

  function label(plan) {
    if (!plan || !plan.chain) return '';
    return plan.chain.join(' > ');
  }

  var Emmet = {
    alias: alias,
    parse: parse,
    looksLikeChain: looksLikeChain,
    label: label,
    completeToken: completeToken,
    completeAt: completeAt,
    resolveElement: resolveElement,
    aliases: ALIASES
  };

  window.MimamsBarEmmet = Emmet;
  window.MimamsBar = window.MimamsBar || {};
  window.MimamsBar.Emmet = Emmet;
})();
