// Mimam's Var - Figma — Figma Plugin (code.js) v2.20.0
// Clean rebuild with all fixes incorporated

try { figma.showUI(__html__, { width: 400, height: 560, themeColors: true }); }
catch(e) { figma.showUI(__html__, { width: 400, height: 560 }); }

// ── Storage helpers ──
const DOC_KEYS = [
  've_wp_url',
  've_api_key',
  've_source',
  've_paired',
  've_collection_id',
  've_collection_name',
  've_site_title',
  've_file_key',
  've_wp_to_figma_var_map',
  've_wp_public_name_map'
];

function currentFileKey() {
  return (typeof figma.fileKey === 'string' && figma.fileKey) || (figma.root && figma.root.id) || (figma.root && figma.root.name) || 'unknown-file';
}

async function getS(k) {
  if (DOC_KEYS.indexOf(k) !== -1) {
    try {
      return figma.root ? (figma.root.getPluginData(k) || '') : '';
    } catch(e) { return ''; }
  }
  return await figma.clientStorage.getAsync(k) || '';
}

async function setS(k, v) {
  if (DOC_KEYS.indexOf(k) !== -1) {
    try {
      if (figma.root) figma.root.setPluginData(k, String(v || ''));
    } catch(e) {}
    return;
  }
  await figma.clientStorage.setAsync(k, v);
}

async function getJsonS(k) {
  try {
    var raw = await getS(k);
    return raw ? JSON.parse(raw) : {};
  } catch(e) { return {}; }
}

async function setJsonS(k, v) {
  try { await setS(k, JSON.stringify(v || {})); } catch(e) {}
}

// ── Load/Save settings ──
async function loadSettings() {
  var collections = await collectionSummaries();
  var selectedId = await getS('ve_collection_id');
  var selectedName = await getS('ve_collection_name');
  var fileKey = currentFileKey();
  var storedFileKey = await getS('ve_file_key');
  var paired = (await getS('ve_paired')) === 'true';
  var apiKey = await getS('ve_api_key');
  if (paired && apiKey && storedFileKey && storedFileKey !== fileKey) {
    await saveSettings({ wpUrl: '', apiKey: '', source: '', paired: false, collectionId: '', collectionName: '' });
    await setS('ve_site_title', '');
    await setS('ve_file_key', '');
    paired = false;
    apiKey = '';
  } else if (paired && apiKey && !storedFileKey) {
    await setS('ve_file_key', fileKey);
  }
  figma.ui.postMessage({
    type: 'settings',
    wpUrl: await getS('ve_wp_url'),
    apiKey: apiKey,
    source: await getS('ve_source'),
    paired: paired,
    figmaFileName: figma.root ? figma.root.name : 'Unknown',
    siteTitle: await getS('ve_site_title'),
    collectionId: selectedId,
    collectionName: selectedName,
    collections: collections
  });
}

async function saveSettings(data) {
  if (data.wpUrl !== undefined) await setS('ve_wp_url', data.wpUrl);
  if (data.apiKey !== undefined) await setS('ve_api_key', data.apiKey);
  if (data.source !== undefined) await setS('ve_source', data.source);
  if (data.paired !== undefined) {
    await setS('ve_paired', data.paired ? 'true' : '');
    await setS('ve_file_key', data.paired ? currentFileKey() : '');
  }
  if (data.collectionId !== undefined) await setS('ve_collection_id', data.collectionId);
  if (data.collectionName !== undefined) await setS('ve_collection_name', data.collectionName);
}

// ── Convert Figma variable name to VE name ──
// color/accent-d-1 → color.accent.d.1
// color/brand/primary-d-1 → color.brand.primary.d.1
function veNameParts(raw) {
  return String(raw || '')
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '.')
    .replace(/^\.+|\.+$/g, '')
    .split('.')
    .filter(function(p) { return !!p; });
}

function figmaToVeName(name) {
  var raw = String(name || '');
  var path = raw.split(/[\/\\]+/).filter(function(p) { return !!String(p || '').trim(); });
  var parts = [];

  if (path.length > 1) {
    var groupParts = veNameParts(path[0]);
    var restParts = [];
    for (var i = 1; i < path.length; i++) {
      restParts = restParts.concat(veNameParts(path[i]));
    }

    // VE's public Figma format keeps the full token inside the group:
    // color/color-primary-d-1, space/space-20. Drop the duplicated family
    // segment when reading that format back into WordPress.
    if (groupParts.length && restParts.length && restParts[0] === groupParts[0]) {
      restParts.shift();
    }
    parts = groupParts.concat(restParts);
  } else {
    parts = veNameParts(raw);
  }

  if (!parts.length) return 'token.unnamed';
  var out = parts.join('.');
  if (!/^[a-z]/.test(out)) out = 'token.' + out;
  return out;
}

// ── Convert VE name to Figma variable name ──
// color.accent.d.1 → color/accent-d-1
function veToFigmaName(name) {
  var dotIdx = name.indexOf('.');
  if (dotIdx === -1) return name;
  var ns = name.substring(0, dotIdx);
  var rest = name.substring(dotIdx + 1).replace(/\./g, '-');
  return ns + '/' + rest;
}

// Public token helpers. WordPress may store organizational wrappers such as
// size.space, but the public token should be space / --space.
function tokenPublicName(wp) {
  var raw = (wp && (wp.public_name || wp.css_name || wp.name)) || '';
  raw = String(raw).toLowerCase().trim();
  raw = raw.replace(/^--/, '');
  raw = raw.replace(/\./g, '-');
  raw = raw.replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '');
  return raw;
}


function tokenIdentityKey(wp) {
  if (wp && wp.identity_key) return String(wp.identity_key);
  if (wp && wp.id !== undefined && wp.id !== null) return 'id:' + String(wp.id);
  return tokenPublicName(wp);
}

function getVarPluginDataSafe(v, key) {
  try { return v && typeof v.getPluginData === 'function' ? (v.getPluginData(key) || '') : ''; } catch(e) { return ''; }
}

function setVarPluginDataSafe(v, key, value) {
  try { if (v && typeof v.setPluginData === 'function') v.setPluginData(key, String(value || '')); } catch(e) {}
}

function publicToFigmaName(publicName) {
  publicName = String(publicName || '').toLowerCase().replace(/^--/, '').replace(/\./g, '-').replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '');
  if (!publicName) return '';
  // Figma should group by family, but the variable name itself should remain
  // the full public token name for clarity.
  // Example: space-20 -> space/space-20, color-primary-d-1 -> color/color-primary-d-1
  var i = publicName.indexOf('-');
  var group = i === -1 ? publicName : publicName.substring(0, i);
  return group + '/' + publicName;
}

function figmaNameToPublicName(figmaName) {
  var n = String(figmaName || '').toLowerCase();
  if (n.indexOf('/') !== -1) {
    var parts = n.split('/');
    var group = parts.shift();
    var rest = parts.join('-');
    // New format keeps full public name inside the group: space/space-20.
    // Use the rest as the public name in that case.
    if (rest.indexOf(group + '-') === 0 || rest === group) n = rest;
    else n = group + '-' + rest;
  }
  return n.replace(/\./g, '-').replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '');
}

function publicGroup(publicName) {
  publicName = String(publicName || '').toLowerCase().replace(/^--/, '').replace(/\./g, '-').replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '');
  var i = publicName.indexOf('-');
  return i === -1 ? publicName : publicName.substring(0, i);
}

// ── Extract domain from URL ──
function getDomain(url) {
  try {
    var m = (url || '').replace(/\/+$/, '').match(/\/\/([^\/]+)/);
    return m ? m[1] : url;
  } catch(e) { return url; }
}

// ── Get all local collections ──
async function getCollections() {
  if (typeof figma.variables.getLocalVariableCollectionsAsync === 'function') {
    return await figma.variables.getLocalVariableCollectionsAsync();
  }
  return figma.variables.getLocalVariableCollections();
}

async function collectionSummaries() {
  var collections = await getCollections();
  return collections.map(function(c) {
    return { id: c.id, name: c.name, count: c.variableIds ? c.variableIds.length : 0 };
  });
}

async function findCollectionById(id) {
  if (!id) return null;
  var collections = await getCollections();
  for (var i = 0; i < collections.length; i++) {
    if (collections[i].id === id) return collections[i];
  }
  return null;
}

async function findCollectionByName(name) {
  if (!name) return null;
  var collections = await getCollections();
  for (var i = 0; i < collections.length; i++) {
    if (collections[i].name === name) return collections[i];
  }
  return null;
}

// ── Get variable by ID (async-safe) ──
async function getVarById(id) {
  if (typeof figma.variables.getVariableByIdAsync === 'function') {
    return await figma.variables.getVariableByIdAsync(id);
  }
  return figma.variables.getVariableById(id);
}

// ── Find the VE collection using multiple strategies ──
async function findVeCollection(siteTitle, preferredId) {
  var collections = await getCollections();
  var col = null;

  // 1. Stored collection ID (most reliable)
  var storedId = preferredId || await getS('ve_collection_id');
  if (storedId) {
    for (var i = 0; i < collections.length; i++) {
      if (collections[i].id === storedId) { col = collections[i]; break; }
    }
  }

  // 2. Site title match
  if (!col && siteTitle) {
    for (var j = 0; j < collections.length; j++) {
      if (collections[j].name === siteTitle) { col = collections[j]; break; }
    }
  }

  // 3. Domain URL match
  if (!col) {
    var domain = getDomain(await getS('ve_wp_url'));
    if (domain) {
      for (var k = 0; k < collections.length; k++) {
        if (collections[k].name === domain) { col = collections[k]; break; }
      }
    }
  }

  // 4. Largest collection fallback (if has VE-style variable names with /)
  if (!col) {
    var best = null;
    for (var bi = 0; bi < collections.length; bi++) {
      var c = collections[bi];
      if (!best || c.variableIds.length > best.variableIds.length) {
        // Quick check: does first variable have a / in its name?
        if (c.variableIds.length > 0) {
          var testVar = await getVarById(c.variableIds[0]);
          if (testVar && testVar.name.indexOf('/') !== -1) {
            best = c;
          }
        }
      }
    }
    if (best) col = best;
  }

  // Store found collection ID
  if (col) {
    await setS('ve_collection_id', col.id);
    await setS('ve_collection_name', col.name);
  }

  return col;
}

// ── Read variables from a specific collection ──
async function readCollectionVars(col) {
  var allVars = [];
  var modeId = col.defaultModeId;

  for (var i = 0; i < col.variableIds.length; i++) {
    var v = await getVarById(col.variableIds[i]);
    if (!v) continue;

    // A fluid variable is a PREVIEW here, not a source of truth.
    //
    // WordPress holds the real thing: a range, stored as one clamp() expression.
    // Figma (free plan, one mode) can only hold a single number, so the plugin keeps
    // the true min/max in plugin data and shows one of them; the Mobile/Desktop
    // buttons swap which one is on display.
    //
    // Reading that displayed number and pushing it would overwrite WordPress's
    // clamp() with a flat value — the variable silently stops being fluid, and which
    // value you destroy depends on which preview button was last clicked. Skip them:
    // WordPress owns the range, Figma is only ever showing a frame of it.
    //
    // This also stops drift reporting every fluid variable as "changed", since the
    // shown number can never equal the clamp() expression it came from.
    var isFluidPreview = false;
    try {
      isFluidPreview = !!(v.getPluginData('ve_min_px') && v.getPluginData('ve_max_px'));
    } catch (e) {}
    if (isFluidPreview) continue;

    var mv = v.valuesByMode[modeId];
    var value = '';
    var rt = v.resolvedType;
    var type = 'base';
    var sourceName = '';
    var sourceCssName = '';

    if (rt === 'COLOR' && typeof mv === 'object' && mv !== null && 'r' in mv) {
      var r = Math.round(mv.r * 255), g = Math.round(mv.g * 255), b = Math.round(mv.b * 255);
      var a = mv.a !== undefined ? mv.a : 1;
      value = a < 1
        ? 'rgba(' + r + ',' + g + ',' + b + ',' + a.toFixed(2) + ')'
        : '#' + ('0'+r.toString(16)).slice(-2) + ('0'+g.toString(16)).slice(-2) + ('0'+b.toString(16)).slice(-2);
    } else if (typeof mv === 'object' && mv !== null && mv.type === 'VARIABLE_ALIAS') {
      var target = await getVarById(mv.id);
      value = target ? 'var(--' + target.name.replace(/\//g, '-').toLowerCase() + ')' : '';
      if (target) {
        type = 'alias';
        sourceName = figmaToVeName(target.name);
        sourceCssName = target.name.replace(/\//g, '-').toLowerCase();
      }
    } else if (rt === 'FLOAT') {
      value = String(mv !== undefined ? mv : 0);
    } else {
      value = String(mv !== undefined ? mv : '');
    }

    var publicCssName = '';
    var storedPublic = getVarPluginDataSafe(v, 've_public_name');
    if (storedPublic) {
      publicCssName = '--' + storedPublic;
    } else {
      var veName = figmaToVeName(v.name);
      var parts = veName.split('.');
      var storage_wrappers = ['size', 'font', 'typography'];
      if (parts.length > 1 && storage_wrappers.indexOf(parts[0]) !== -1) {
        parts.shift();
      }
      publicCssName = '--' + parts.join('-');
    }

    var externalCssName = '--' + figmaNameToPublicName(v.name);

    allVars.push({
      figma_id: v.id,
      figma_name: v.name,
      name: figmaToVeName(v.name),
      value: value,
      namespace: figmaToVeName(v.name).split('.')[0],
      collection: col.name,
      resolvedType: rt,
      type: type,
      source_name: sourceName,
      source_css_name: sourceCssName,
      public_css_name: publicCssName,
      external_css_name: externalCssName
    });
  }
  return allVars;
}

// ── Read ALL Figma variables (for pull) ──
async function readAllFigmaVars() {
  var all = [];
  var collections = await getCollections();
  for (var i = 0; i < collections.length; i++) {
    var vars = await readCollectionVars(collections[i]);
    all = all.concat(vars);
  }
  return all;
}

async function readSelectedFigmaVars(collectionId, collectionName) {
  var col = await findCollectionById(collectionId);
  if (!col && collectionName) col = await findCollectionByName(collectionName);
  if (!col) return await readAllFigmaVars();
  await setS('ve_collection_id', col.id);
  await setS('ve_collection_name', col.name);
  return await readCollectionVars(col);
}

// ── Write variables to Figma ──
// Creates/updates in a single collection named after the site title.
// Deletes variables in the collection that don't exist in WP (when skipDeletes=false).
async function writeFigmaVariables(wpVars, options) {
  var skipDeletes = options && options.skipDeletes !== undefined ? options.skipDeletes : true;
  var partial = !!(options && options.partial);
  var explicitCollectionName = options && options.collectionName ? options.collectionName : '';
  var colName = explicitCollectionName || (options && options.domain ? options.domain : 'WordPress');
  var selectedId = options && options.collectionId ? options.collectionId : '';
  var results = { created: 0, updated: 0, deleted: 0, skipped: 0, errors: [] };

  // Find or create the collection
  var col = await findCollectionById(selectedId);
  if (!col && colName) col = await findCollectionByName(colName);
  if (!col && !explicitCollectionName) col = await findVeCollection(colName, selectedId);

  if (!col) {
    // Check for old domain-named collection to rename
    var collections = await getCollections();
    var domain = getDomain(await getS('ve_wp_url'));
    for (var ri = 0; ri < collections.length; ri++) {
      if (collections[ri].name === domain) {
        col = collections[ri];
        col.name = colName;
        break;
      }
    }
  }

  if (!col) {
    col = figma.variables.createVariableCollection(colName);
    if (col.modes && col.modes.length > 0) {
      col.renameMode(col.modes[0].modeId, 'Default');
    }
  }

  // Rename if site title changed
  if (!selectedId && col.name !== colName) col.name = colName;

  await setS('ve_collection_id', col.id);
  await setS('ve_collection_name', col.name);
  await setS('ve_site_title', colName);

  var modeId = col.defaultModeId;

  // Index existing variables by internal name, public token name, and ID.
  // The ID map is stored locally after every successful push so future WP renames
  // can rename the same Figma variable instead of creating duplicates when
  // "delete variables" is not checked.
  var existingMap = {};
  var existingPublicMap = {};
  var existingById = {};
  var existingByWpKey = {};
  for (var ei = 0; ei < col.variableIds.length; ei++) {
    var ev = await getVarById(col.variableIds[ei]);
    if (!ev) continue;
    existingMap[figmaToVeName(ev.name)] = ev;
    existingPublicMap[figmaNameToPublicName(ev.name)] = ev;
    existingById[ev.id] = ev;
    var storedWpKey = getVarPluginDataSafe(ev, 've_wp_key');
    if (storedWpKey) existingByWpKey[storedWpKey] = ev;
  }
  // Exact WP-name -> Figma variable map, filled as the loop resolves each variable.
  // Theme values are keyed by the WP `name` field (ThemeManager::apply_to_variables),
  // so reuse this loop's own resolution rather than re-deriving the name — a second
  // derivation that drifts would match nothing and fail silently.
  var varsByWpName = {};
  var storedIdMap = await getJsonS('ve_wp_to_figma_var_map');
  var previousPublicMap = await getJsonS('ve_wp_public_name_map');
  var nextIdMap = partial ? Object.assign({}, storedIdMap || {}) : {};
  var nextPublicMap = partial ? Object.assign({}, previousPublicMap || {}) : {};

  // Process each WP variable
  for (var wi = 0; wi < wpVars.length; wi++) {
    var wp = wpVars[wi];
    try {
      var veName = wp.name;
      var publicName = tokenPublicName(wp);
      var figmaName = publicToFigmaName(publicName || wp.name);

      // Determine type and value
      var resolvedType = 'STRING';
      var figmaValue;
      var rawVal = wp.value || '';

      if (isColor(rawVal)) {
        resolvedType = 'COLOR';
        figmaValue = parseColorToFigma(rawVal);
      } else {
        var numVal = extractNumber(rawVal);
        if (numVal !== null) {
          resolvedType = 'FLOAT';
          figmaValue = numVal;
        } else {
          figmaValue = rawVal;
        }
      }

      var wpKey = tokenIdentityKey(wp);
      var mappedId = wpKey && storedIdMap ? storedIdMap[wpKey] : '';
      var mappedExisting = mappedId && existingById[mappedId] ? existingById[mappedId] : null;
      var pluginDataExisting = wpKey && existingByWpKey[wpKey] ? existingByWpKey[wpKey] : null;
      var previousNames = [];
      if (wp && Array.isArray(wp.previous_public_names)) previousNames = wp.previous_public_names;
      var previousPublicName = wpKey && previousPublicMap ? previousPublicMap[wpKey] : '';
      if (previousPublicName) previousNames.push(previousPublicName);
      var previousExisting = null;
      for (var pi = 0; pi < previousNames.length; pi++) {
        var pn = String(previousNames[pi] || '').toLowerCase().replace(/^--/, '').replace(/\./g, '-').replace(/[^a-z0-9-]+/g, '-').replace(/^-+|-+$/g, '');
        if (pn && existingPublicMap[pn]) { previousExisting = existingPublicMap[pn]; break; }
      }
      var existing = pluginDataExisting || mappedExisting || previousExisting || existingPublicMap[publicName] || existingMap[veName] || findRenameCandidate(existingPublicMap, publicName, rawVal, resolvedType, modeId);
      if (existing) varsByWpName[veName] = existing;
      if (existing) {
        // Update existing, renaming if the public token name changed.
        var oldInternalKey = figmaToVeName(existing.name);
        var oldPublicKey = figmaNameToPublicName(existing.name);
        try { if (existing.name !== figmaName) existing.name = figmaName; } catch(rn) {}
        try {
          if (existing.resolvedType === resolvedType) {
            existing.setValueForMode(modeId, figmaValue);
          } else {
            // Type mismatch — try as string
            existing.setValueForMode(modeId, String(rawVal));
          }
          results.updated++;
          if (wpKey) {
            setVarPluginDataSafe(existing, 've_wp_key', wpKey);
            setVarPluginDataSafe(existing, 've_public_name', publicName);
            nextIdMap[wpKey] = existing.id; nextPublicMap[wpKey] = publicName;
          }
        } catch(ue) {
          results.errors.push(veName + ': ' + (ue.message || String(ue)));
        }
        delete existingMap[oldInternalKey];
        delete existingMap[figmaToVeName(existing.name)];
        delete existingPublicMap[oldPublicKey];
        delete existingPublicMap[figmaNameToPublicName(existing.name)];
        delete existingPublicMap[publicName];
      } else {
        // Create new
        var newVar = figma.variables.createVariable(figmaName, col, resolvedType);
        newVar.setValueForMode(modeId, figmaValue);
        varsByWpName[veName] = newVar;
        results.created++;
        if (wpKey) {
          setVarPluginDataSafe(newVar, 've_wp_key', wpKey);
          setVarPluginDataSafe(newVar, 've_public_name', publicName);
          nextIdMap[wpKey] = newVar.id; nextPublicMap[wpKey] = publicName;
        }
      }
    } catch(err) {
      results.errors.push(wp.name + ': ' + (err.message || String(err)));
    }
  }

  // Delete remaining (in Figma but not in WP)
  if (!skipDeletes) {
    var delKeys = Object.keys(existingMap);
    for (var di = 0; di < delKeys.length; di++) {
      try {
        existingMap[delKeys[di]].remove();
        results.deleted++;
      } catch(de) {
        results.errors.push('Delete ' + delKeys[di] + ': ' + (de.message || String(de)));
      }
    }
  }

  // Themes -> Figma modes. Everything above wrote the Default mode only.
  if (options && options.themes) {
    try {
      var themeRes = await applyThemeModes(col, options.themes, varsByWpName);
      results.themeModes = themeRes.modes;
      results.themeValues = themeRes.values;
      results.unknownModes = themeRes.unknown;
    } catch (te) {
      results.errors.push('Themes: ' + (te.message || String(te)));
    }
  }

  await setJsonS('ve_wp_to_figma_var_map', nextIdMap);
  await setJsonS('ve_wp_public_name_map', nextPublicMap);
  return results;
}

/**
 * Map MV themes onto this collection's Figma modes. Decision 2026-07-16.
 *
 * MV themes and Figma modes are the same concept: alternate values under the same
 * token names. This collection carries the theme axis; fluid scales own the viewport
 * axis in their own collection, because Figma allows one axis per collection.
 *
 * Rules:
 *  - Merge, never replace. Modes are matched by name, the same way the System Bundle
 *    reconnects themes "by stable names".
 *  - A mode MV does not recognise is drift: reported, never deleted. Deleting it
 *    would destroy a designer's work, which is the exact failure the drift rule exists
 *    to prevent.
 *  - Viewport modes (Mobile/Desktop) are MV's own, from fluid scales — not drift.
 *    Only genuinely unrecognised modes are reported.
 *  - Themes override colour variables only, and never aliases. That is enforced
 *    server-side in ThemeManager::apply_to_variables(); this mirrors it.
 *
 * @param col               VariableCollection carrying the theme axis.
 * @param themes            `sync/export-bundle` -> themes: { items: {slug:{name,values}}, active }
 * @param varsByWpName      WP variable `name` -> Figma Variable, resolved by the
 *                          main write loop. Theme values are keyed by that same field.
 */
async function applyThemeModes(col, themes, varsByWpName) {
  var out = { modes: 0, values: 0, unknown: [] };
  var items = themes && themes.items ? themes.items : null;
  if (!items || typeof items !== 'object') return out;

  var slugs = Object.keys(items);
  if (!slugs.length) return out;

  // Default mode holds each variable's base value — already written above.
  var defaultId = col.defaultModeId;
  try { col.renameMode(defaultId, 'Default'); } catch (e) {}

  var knownNames = { 'default': true };
  var VIEWPORT = /^(mobile|desktop|min|max)$/i;

  for (var i = 0; i < slugs.length; i++) {
    var slug = slugs[i];
    var theme = items[slug] || {};
    var themeName = String(theme.name || slug);
    knownNames[themeName.toLowerCase()] = true;

    // Match an existing mode by name before creating one — merge, never duplicate.
    var modeId = null;
    for (var m = 0; m < col.modes.length; m++) {
      if (String(col.modes[m].name).toLowerCase() === themeName.toLowerCase()) {
        modeId = col.modes[m].modeId;
        break;
      }
    }
    if (!modeId) {
      try {
        modeId = col.addMode(themeName);
        out.modes++;
      } catch (e) {
        // Figma caps modes per collection by plan. Report rather than fail the sync.
        out.unknown.push('Could not add mode "' + themeName + '": ' + (e.message || String(e)));
        continue;
      }
    }

    var values = theme.values && typeof theme.values === 'object' ? theme.values : {};
    var names = Object.keys(values);
    for (var n = 0; n < names.length; n++) {
      var wpName = names[n];
      var v = varsByWpName[wpName];
      if (!v || v.resolvedType !== 'COLOR') continue;
      var fv = parseColorToFigma(values[wpName]);
      if (!fv) continue;
      try {
        v.setValueForMode(modeId, fv);
        out.values++;
      } catch (e) {
        out.unknown.push(wpName + ' in "' + themeName + '": ' + (e.message || String(e)));
      }
    }
  }

  // Anything left that MV neither owns nor recognises is drift, not rubbish.
  for (var k = 0; k < col.modes.length; k++) {
    var name = String(col.modes[k].name);
    if (knownNames[name.toLowerCase()] || VIEWPORT.test(name)) continue;
    out.unknown.push(name);
  }

  return out;
}

function figmaValueToComparable(v, modeId) {
  try {
    var mv = v.valuesByMode[modeId];
    if (v.resolvedType === 'COLOR' && mv && typeof mv === 'object' && 'r' in mv) {
      var r = Math.round(mv.r * 255), g = Math.round(mv.g * 255), b = Math.round(mv.b * 255);
      var a = mv.a !== undefined ? mv.a : 1;
      return a < 1 ? ('rgba(' + r + ',' + g + ',' + b + ',' + a.toFixed(2) + ')') : ('#' + ('0'+r.toString(16)).slice(-2) + ('0'+g.toString(16)).slice(-2) + ('0'+b.toString(16)).slice(-2));
    }
    return String(mv !== undefined ? mv : '');
  } catch(e) { return ''; }
}

function valuesLikelySame(rawVal, existingVar, resolvedType, modeId) {
  if (!existingVar) return false;
  if (existingVar.resolvedType !== resolvedType) return false;
  if (resolvedType === 'FLOAT') {
    var a = extractNumber(rawVal);
    var b = extractNumber(figmaValueToComparable(existingVar, modeId));
    return a !== null && b !== null && Math.abs(a - b) < 0.01;
  }
  if (resolvedType === 'COLOR') {
    return String(rawVal || '').trim().toLowerCase() === figmaValueToComparable(existingVar, modeId).trim().toLowerCase();
  }
  return String(rawVal || '').trim() === figmaValueToComparable(existingVar, modeId).trim();
}

function findRenameCandidate(existingPublicMap, publicName, rawVal, resolvedType, modeId) {
  var keys = Object.keys(existingPublicMap || {});
  var matches = [];
  var group = publicGroup(publicName);
  for (var i = 0; i < keys.length; i++) {
    var k = keys[i];
    var ev = existingPublicMap[k];
    if (!ev) continue;
    var keyGroup = publicGroup(k);
    var suffixMatch = k === publicName || k.endsWith('-' + publicName) || publicName.endsWith('-' + k);
    var sameFamily = group && keyGroup && group === keyGroup;
    // For a rename, the name may be completely different, but the old variable
    // should usually stay in the same top-level family and keep the same value/type.
    // Example: color-primary -> color-secondary, space-20 -> gap-20, etc.
    if ((suffixMatch || sameFamily) && valuesLikelySame(rawVal, ev, resolvedType, modeId)) matches.push(ev);
  }
  return matches.length === 1 ? matches[0] : null;
}

// ── Color detection ──
function isColor(val) {
  return /^(#[0-9a-fA-F]{3,8}|rgba?\(|hsla?\(|oklch\()/.test(val || '');
}

// ── OKLCH → RGB via OKLab ──
function oklchToRgb(L, C, H) {
  var hRad = H * Math.PI / 180;
  var a = C * Math.cos(hRad), b = C * Math.sin(hRad);
  var l_ = L + 0.3963377774*a + 0.2158037573*b;
  var m_ = L - 0.1055613458*a - 0.0638541728*b;
  var s_ = L - 0.0894841775*a - 1.2914855480*b;
  var l = l_*l_*l_, m = m_*m_*m_, s = s_*s_*s_;
  var rL = 4.0767416621*l - 3.3077115913*m + 0.2309699292*s;
  var gL = -1.2684380046*l + 2.6097574011*m - 0.3413193965*s;
  var bL = -0.0041960863*l - 0.7034186147*m + 1.7076147010*s;
  function gamma(v) { return v <= 0.0031308 ? 12.92*v : 1.055*Math.pow(Math.max(0,v), 1/2.4) - 0.055; }
  return { r: Math.max(0, Math.min(1, gamma(rL))), g: Math.max(0, Math.min(1, gamma(gL))), b: Math.max(0, Math.min(1, gamma(bL))) };
}

// ── Parse any color to Figma {r,g,b,a} ──
function parseColorToFigma(val) {
  if (val.charAt(0) === '#') {
    var hex = val.slice(1);
    if (hex.length === 3) hex = hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];
    if (hex.length === 8) return { r:parseInt(hex.slice(0,2),16)/255, g:parseInt(hex.slice(2,4),16)/255, b:parseInt(hex.slice(4,6),16)/255, a:parseInt(hex.slice(6,8),16)/255 };
    return { r:parseInt(hex.slice(0,2),16)/255, g:parseInt(hex.slice(2,4),16)/255, b:parseInt(hex.slice(4,6),16)/255, a:1 };
  }
  var om = val.match(/oklch\(\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)\s*(?:\/\s*([\d.]+))?\s*\)/);
  if (om) { var rgb = oklchToRgb(+om[1], +om[2], +om[3]); return { r:rgb.r, g:rgb.g, b:rgb.b, a:om[4]!==undefined?+om[4]:1 }; }
  var hm = val.match(/hsla?\(\s*([\d.]+)\s*,?\s*([\d.]+)%?\s*,?\s*([\d.]+)%?\s*(?:[,\/]\s*([\d.]+))?\s*\)/);
  if (hm) {
    var hu=+hm[1]/360, sa=+hm[2]/100, li=+hm[3]/100;
    function h2r(p,q,t){if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return p+(q-p)*6*t;if(t<.5)return q;if(t<2/3)return p+(q-p)*(2/3-t)*6;return p;}
    var q=li<.5?li*(1+sa):li+sa-li*sa, p=2*li-q;
    return { r:sa===0?li:h2r(p,q,hu+1/3), g:sa===0?li:h2r(p,q,hu), b:sa===0?li:h2r(p,q,hu-1/3), a:hm[4]!==undefined?+hm[4]:1 };
  }
  var rm = val.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*(?:,\s*([\d.]+))?\s*\)/);
  if (rm) return { r:+rm[1]/255, g:+rm[2]/255, b:+rm[3]/255, a:rm[4]!==undefined?+rm[4]:1 };
  return { r:0, g:0, b:0, a:1 };
}

// ── Extract numeric value for Figma FLOAT ──
// clamp() → max value, rem×10, px strip, em×16, generic unit strip
function extractNumber(val) {
  val = (val || '').trim();
  var cm = val.match(/clamp\(\s*([^,]+)\s*,\s*([^,]+)\s*,\s*([^)]+)\s*\)/);
  if (cm) return extractNumber(cm[3].trim());
  var rem = val.match(/^([\d.]+)\s*rem$/i);
  if (rem) return Math.round(parseFloat(rem[1]) * 10 * 100) / 100;
  var px = val.match(/^([\d.]+)\s*px$/i);
  if (px) return parseFloat(px[1]);
  var em = val.match(/^([\d.]+)\s*em$/i);
  if (em) return Math.round(parseFloat(em[1]) * 16 * 100) / 100;
  var pct = val.match(/^([\d.]+)\s*%$/);
  if (pct) return parseFloat(pct[1]);
  if (/^[\d.]+$/.test(val)) return parseFloat(val);
  var gen = val.match(/^([\d.]+)\s*[a-z]+$/i);
  if (gen) return parseFloat(gen[1]);
  return null;
}

// ── Smart Apply ──
// Scan current page for unbound style values and group by family + value.
// Skips nodes whose property is already bound to a variable.

function rgbToHex6(r, g, b) {
  function ch(v) { var n = Math.max(0, Math.min(255, Math.round(v * 255))); var s = n.toString(16); return s.length === 1 ? '0' + s : s; }
  return '#' + ch(r) + ch(g) + ch(b);
}

function isVarBound(node, field) {
  try {
    var b = node.boundVariables;
    if (!b) return false;
    if (field === 'fills' || field === 'strokes') {
      var arr = b[field];
      return Array.isArray(arr) && arr.length > 0 && !!arr[0];
    }
    return !!b[field];
  } catch (e) { return false; }
}

function pushDetected(map, family, value, nodeId, field, fillIndex) {
  var key = family + '::' + value;
  if (!map[key]) map[key] = { family: family, value: value, count: 0, refs: [] };
  map[key].count++;
  map[key].refs.push({ id: nodeId, field: field, fillIndex: typeof fillIndex === 'number' ? fillIndex : -1 });
}

async function scanCurrentPage() {
  // Force-load all descendants so all nodes are available for traversal.
  await figma.currentPage.loadAsync();
  var map = {};
  var nodes = figma.currentPage.findAll(function(n) { return true; });

  for (var i = 0; i < nodes.length; i++) {
    var n = nodes[i];

    // Fills (solid colors only)
    if ('fills' in n && Array.isArray(n.fills) && !isVarBound(n, 'fills')) {
      for (var fi = 0; fi < n.fills.length; fi++) {
        var f = n.fills[fi];
        if (f && f.type === 'SOLID' && f.visible !== false && f.color) {
          var hex = rgbToHex6(f.color.r, f.color.g, f.color.b);
          pushDetected(map, 'color', hex, n.id, 'fills', fi);
          break; // only the first visible solid fill per node
        }
      }
    }

    // Strokes (solid colors only)
    if ('strokes' in n && Array.isArray(n.strokes) && !isVarBound(n, 'strokes')) {
      for (var si = 0; si < n.strokes.length; si++) {
        var s = n.strokes[si];
        if (s && s.type === 'SOLID' && s.visible !== false && s.color) {
          var hexS = rgbToHex6(s.color.r, s.color.g, s.color.b);
          pushDetected(map, 'color', hexS, n.id, 'strokes', si);
          break;
        }
      }
    }

    // Spacing — auto-layout properties
    if ('itemSpacing' in n && typeof n.itemSpacing === 'number' && n.itemSpacing > 0 && !isVarBound(n, 'itemSpacing')) {
      pushDetected(map, 'space', String(n.itemSpacing), n.id, 'itemSpacing');
    }
    var padFields = ['paddingTop', 'paddingRight', 'paddingBottom', 'paddingLeft'];
    for (var pi = 0; pi < padFields.length; pi++) {
      var pf = padFields[pi];
      if (pf in n && typeof n[pf] === 'number' && n[pf] > 0 && !isVarBound(n, pf)) {
        pushDetected(map, 'space', String(n[pf]), n.id, pf);
      }
    }

    // Radius
    if ('cornerRadius' in n && typeof n.cornerRadius === 'number' && n.cornerRadius > 0 && !isVarBound(n, 'cornerRadius')) {
      pushDetected(map, 'radius', String(n.cornerRadius), n.id, 'cornerRadius');
    }

    // Typography — fontSize on text nodes (skip mixed)
    if (n.type === 'TEXT' && typeof n.fontSize === 'number' && n.fontSize > 0 && !isVarBound(n, 'fontSize')) {
      pushDetected(map, 'typography', String(n.fontSize), n.id, 'fontSize');
    }
  }

  var out = [];
  for (var k in map) { if (Object.prototype.hasOwnProperty.call(map, k)) out.push(map[k]); }
  // Sort: family asc, count desc.
  out.sort(function(a, b) { if (a.family !== b.family) return a.family < b.family ? -1 : 1; return b.count - a.count; });
  return out;
}

async function ensureFigmaVarForApply(opts) {
  // opts: { name (public token name like 'space-20'), family, value, collection }
  // Returns the Figma variable, creating it if it doesn't exist in the collection.
  var col = opts.collection;
  if (!col) throw new Error('No VE collection available for binding');

  // Try to find existing in this collection by full name (group/name).
  var allVars = await figma.variables.getLocalVariablesAsync();
  var fullName = opts.family === 'color' ? 'color/' + opts.name : opts.family + '/' + opts.name;
  for (var i = 0; i < allVars.length; i++) {
    var v = allVars[i];
    if (v.variableCollectionId === col.id && v.name === fullName) return v;
  }

  // Create it.
  var fType = opts.family === 'color' ? 'COLOR' : 'FLOAT';
  var newVar = figma.variables.createVariable(fullName, col, fType);
  var modeId = col.modes && col.modes[0] ? col.modes[0].modeId : null;
  if (modeId) {
    if (opts.family === 'color') {
      var hex = String(opts.value).replace('#', '');
      var r = parseInt(hex.substring(0, 2), 16) / 255;
      var g = parseInt(hex.substring(2, 4), 16) / 255;
      var b = parseInt(hex.substring(4, 6), 16) / 255;
      newVar.setValueForMode(modeId, { r: r, g: g, b: b, a: 1 });
    } else {
      newVar.setValueForMode(modeId, parseFloat(opts.value));
    }
  }
  return newVar;
}

function bindNodeField(node, field, fillIndex, variable) {
  if (field === 'fills' || field === 'strokes') {
    var arr = node[field];
    if (!Array.isArray(arr) || arr.length === 0) return false;
    var idx = fillIndex >= 0 && fillIndex < arr.length ? fillIndex : 0;
    // Clone the array and the target paint, then set the bound variable on the clone.
    var newArr = arr.slice();
    var paint = Object.assign({}, newArr[idx]);
    paint = figma.variables.setBoundVariableForPaint(paint, 'color', variable);
    newArr[idx] = paint;
    node[field] = newArr;
    return true;
  }
  // Numeric fields use the direct setBoundVariable API.
  node.setBoundVariable(field, variable);
  return true;
}

async function applySmartDecisions(decisions, siteTitle) {
  // decisions: array of { family, value, action: 'apply'|'create'|'skip', figmaVarId?, name?, refs: [...] }
  var col = await findVeCollection(siteTitle || await getS('ve_site_title') || '');
  if (!col) throw new Error('VE collection not found in this Figma file. Push variables from WordPress first.');

  var applied = 0, created = 0, skipped = 0, errors = 0;
  var allVars = await figma.variables.getLocalVariablesAsync();
  var byId = {};
  for (var ai = 0; ai < allVars.length; ai++) byId[allVars[ai].id] = allVars[ai];

  for (var i = 0; i < decisions.length; i++) {
    var d = decisions[i];
    if (d.action === 'skip') { skipped += (d.refs || []).length; continue; }

    try {
      var v = null;
      if (d.action === 'apply' && d.figmaVarId) {
        v = byId[d.figmaVarId] || await figma.variables.getVariableByIdAsync(d.figmaVarId);
      } else if (d.action === 'create' && d.name) {
        v = await ensureFigmaVarForApply({ name: d.name, family: d.family, value: d.value, collection: col });
        created++;
      }
      if (!v) { errors++; continue; }

      var refs = d.refs || [];
      for (var ri = 0; ri < refs.length; ri++) {
        var ref = refs[ri];
        var node = await figma.getNodeByIdAsync(ref.id);
        if (!node) { errors++; continue; }
        try {
          bindNodeField(node, ref.field, ref.fillIndex, v);
          applied++;
        } catch (be) { errors++; }
      }
    } catch (e) {
      errors++;
    }
  }

  return { applied: applied, created: created, skipped: skipped, errors: errors };
}

// ── Message handler ──
figma.ui.onmessage = async function(msg) {
  try {
    if (msg.type === 'init') {
      await loadSettings();
    }
    else if (msg.type === 'list-collections') {
      figma.ui.postMessage({
        type: 'collections',
        collections: await collectionSummaries(),
        collectionId: await getS('ve_collection_id'),
        collectionName: await getS('ve_collection_name')
      });
    }
    else if (msg.type === 'set-collection') {
      await saveSettings({ collectionId: msg.collectionId || '', collectionName: msg.collectionName || '' });
      figma.ui.postMessage({
        type: 'collections',
        collections: await collectionSummaries(),
        collectionId: await getS('ve_collection_id'),
        collectionName: await getS('ve_collection_name')
      });
    }
    else if (msg.type === 'read-figma-vars') {
      var vars = await readSelectedFigmaVars(msg.collectionId || '', msg.collectionName || '');
      figma.ui.postMessage({ type: 'figma-vars', variables: vars });
    }
    else if (msg.type === 'read-drift-vars') {
      var driftVars = await readSelectedFigmaVars(msg.collectionId || '', msg.collectionName || '');
      figma.ui.postMessage({ type: 'drift-vars', variables: driftVars });
    }
    else if (msg.type === 'read-figma-domain-vars') {
      // Push diff: read only from the VE collection
      if (msg.siteTitle) await setS('ve_site_title', msg.siteTitle);
      var siteTitle = msg.siteTitle || await getS('ve_site_title') || '';
      var col = await findVeCollection(siteTitle, msg.collectionId || '');
      var domainVars = col ? await readCollectionVars(col) : [];
      figma.ui.postMessage({ type: 'figma-domain-vars', variables: domainVars, collection: col ? col.name : 'NOT FOUND', count: domainVars.length });
    }
    else if (msg.type === 'write-figma-vars') {
      if (msg.siteTitle) await setS('ve_site_title', msg.siteTitle);
      var colName = msg.siteTitle || await getS('ve_site_title') || getDomain(await getS('ve_wp_url'));
      if (msg.collectionName) colName = msg.collectionName;
      var res = await writeFigmaVariables(msg.variables, {
        skipDeletes: msg.skipDeletes !== undefined ? msg.skipDeletes : true,
        domain: colName,
        collectionId: msg.collectionId || '',
        collectionName: msg.collectionName || '',
        // Optional: absent when the site predates theme sync, or the bundle call
        // failed. The pull still works, just without modes.
        themes: msg.themes || null
      });
      figma.ui.postMessage({ type: 'write-result', created: res.created, updated: res.updated, deleted: res.deleted, skipped: res.skipped, errors: res.errors, collections: await collectionSummaries(), collectionId: await getS('ve_collection_id'), collectionName: await getS('ve_collection_name') });
    }
    else if (msg.type === 'write-drift-vars') {
      var driftResult = await writeFigmaVariables(msg.variables || [], {
        skipDeletes: true,
        partial: true,
        domain: msg.collectionName || await getS('ve_site_title') || getDomain(await getS('ve_wp_url')),
        collectionId: msg.collectionId || '',
        collectionName: msg.collectionName || ''
      });
      var driftCurrent = await readSelectedFigmaVars(await getS('ve_collection_id'), await getS('ve_collection_name'));
      figma.ui.postMessage({
        type: 'drift-write-result',
        commandId: msg.commandId || '',
        variables: driftCurrent,
        result: {
          created: driftResult.created,
          updated: driftResult.updated,
          deleted: driftResult.deleted,
          skipped: driftResult.skipped,
          errors: driftResult.errors
        }
      });
    }
    else if (msg.type === 'complete-pair') {
      await saveSettings({ wpUrl: msg.wpUrl, apiKey: msg.apiKey, source: msg.source, paired: true });
      var fileName = figma.root ? figma.root.name : 'Unknown';
      figma.ui.postMessage({ type: 'pair-complete', figmaFileName: fileName });
    }
    else if (msg.type === 'disconnect') {
      await saveSettings({ apiKey: '', source: '', paired: false });
      await setS('ve_collection_id', '');
      await setS('ve_collection_name', '');
      await setS('ve_site_title', '');
      await setJsonS('ve_wp_to_figma_var_map', {});
      await setJsonS('ve_wp_public_name_map', {});
      figma.ui.postMessage({ type: 'disconnected' });
    }
    else if (msg.type === 'get-file-name') {
      figma.ui.postMessage({ type: 'file-name', name: figma.root ? figma.root.name : 'Unknown' });
    }
    else if (msg.type === 'smart-scan') {
      var detected = await scanCurrentPage();
      figma.ui.postMessage({ type: 'smart-scan-result', detected: detected, page: figma.currentPage.name });
    }
    else if (msg.type === 'smart-apply') {
      var res = await applySmartDecisions(msg.decisions || [], msg.siteTitle || '');
      figma.ui.postMessage({ type: 'smart-apply-result', applied: res.applied, created: res.created, skipped: res.skipped, errors: res.errors });
    }
    else if (msg.type === 'gen-system-scan') {
      var detectedAll = await scanCurrentPage();
      // Filter to colors only and strip node refs (we don't need them for system generation).
      var colors = detectedAll
        .filter(function(d) { return d.family === 'color'; })
        .map(function(d) { return { value: d.value, count: d.count }; });
      figma.ui.postMessage({ type: 'gen-system-scan-result', colors: colors, page: figma.currentPage.name });
    }
    else if (msg.type === 'create-fluid-scale') {
      try {
        var siteCol = await getOrCreateCollection(msg.collectionId, msg.collectionName);
        var figmaName = publicToFigmaName(msg.name);

        // A scale that already exists stays exactly where it is — moving it would
        // break every layer bound to it. Only new scales go to the fluid collection,
        // where the viewport axis does not compete with themes for the site
        // collection's modes. Decision 2026-07-16.
        var existing = await findVarInCollection(siteCol, figmaName);
        var col = existing ? siteCol : await getOrCreateFluidCollection(siteCol);
        if (!existing) existing = await findVarInCollection(col, figmaName);

        if (!existing) {
          existing = figma.variables.createVariable(figmaName, col, 'FLOAT');
        }

        var mobileModeId = null;
        var desktopModeId = null;
        for (var m = 0; m < col.modes.length; m++) {
          var mName = col.modes[m].name.toLowerCase();
          if (mName.indexOf('mobile') !== -1 || mName.indexOf('min') !== -1) {
            mobileModeId = col.modes[m].modeId;
          }
          if (mName.indexOf('desktop') !== -1 || mName.indexOf('max') !== -1) {
            desktopModeId = col.modes[m].modeId;
          }
        }
        if (!mobileModeId) mobileModeId = col.modes[0].modeId;
        if (!desktopModeId) {
          if (col.modes.length > 1) {
            desktopModeId = col.modes[1].modeId;
          } else {
            try {
              desktopModeId = col.addMode('Desktop');
              col.renameMode(mobileModeId, 'Mobile');
            } catch(e) {
              desktopModeId = mobileModeId;
            }
          }
        }
        
        existing.setValueForMode(mobileModeId, msg.minPx);
        if (desktopModeId !== mobileModeId) {
          existing.setValueForMode(desktopModeId, msg.maxPx);
        }
        
        existing.setPluginData('ve_wp_key', msg.name);
        existing.setPluginData('ve_public_name', msg.name);
        existing.setPluginData('ve_min_px', String(msg.minPx));
        existing.setPluginData('ve_max_px', String(msg.maxPx));
        
        figma.ui.postMessage({
          type: 'create-result',
          success: true,
          name: msg.name
        });
      } catch(err) {
        figma.ui.postMessage({
          type: 'create-result',
          success: false,
          error: err.message
        });
      }
    }
    else if (msg.type === 'create-color-scale') {
      try {
        var col = await getOrCreateCollection(msg.collectionId, msg.collectionName);
        var vars = msg.variables || [];
        var createdCount = 0;
        
        for (var vi = 0; vi < vars.length; vi++) {
          var vData = vars[vi];
          var figmaName = publicToFigmaName(vData.name);
          
          var existing = null;
          for (var ei = 0; ei < col.variableIds.length; ei++) {
            var ev = await getVarById(col.variableIds[ei]);
            if (ev && ev.name === figmaName) {
              existing = ev;
              break;
            }
          }
          
          if (!existing) {
            existing = figma.variables.createVariable(figmaName, col, 'COLOR');
          }
          
          var figmaValue = parseColorToFigma(vData.value);
          var defaultModeId = col.defaultModeId;
          existing.setValueForMode(defaultModeId, figmaValue);
          
          existing.setPluginData('ve_wp_key', vData.name);
          existing.setPluginData('ve_public_name', vData.name);
          createdCount++;
        }
        
        figma.ui.postMessage({
          type: 'create-result',
          success: true,
          name: vars[0].name.split('.').slice(0, 2).join('.') + '.* (' + createdCount + ' steps)'
        });
      } catch(err) {
        figma.ui.postMessage({
          type: 'create-result',
          success: false,
          error: err.message
        });
      }
    }
    else if (msg.type === 'create-figma-var') {
      try {
        var col = await getOrCreateCollection(msg.collectionId, msg.collectionName);
        var figmaName = publicToFigmaName(msg.name);
        
        var existing = null;
        for (var ei = 0; ei < col.variableIds.length; ei++) {
          var ev = await getVarById(col.variableIds[ei]);
          if (ev && ev.name === figmaName) {
            existing = ev;
            break;
          }
        }
        
        var resolvedType = 'STRING';
        var figmaValue = msg.value;
        if (isColor(msg.value)) {
          resolvedType = 'COLOR';
          figmaValue = parseColorToFigma(msg.value);
        } else {
          var numVal = extractNumber(msg.value);
          if (numVal !== null) {
            resolvedType = 'FLOAT';
            figmaValue = numVal;
          }
        }
        
        if (!existing) {
          existing = figma.variables.createVariable(figmaName, col, resolvedType);
        }
        
        var defaultModeId = col.defaultModeId;
        existing.setValueForMode(defaultModeId, figmaValue);
        
        existing.setPluginData('ve_wp_key', msg.name);
        existing.setPluginData('ve_public_name', msg.name);
        
        figma.ui.postMessage({
          type: 'create-result',
          success: true,
          name: msg.name
        });
      } catch(err) {
        figma.ui.postMessage({
          type: 'create-result',
          success: false,
          error: err.message
        });
      }
    }
    else if (msg.type === 'delete-figma-var') {
      try {
        var v = await getVarById(msg.id);
        if (v) {
          v.remove();
        }
        figma.ui.postMessage({
          type: 'create-result',
          success: true,
          name: 'Deleted variable'
        });
      } catch(err) {
        figma.ui.postMessage({
          type: 'create-result',
          success: false,
          error: err.message
        });
      }
    }
    else if (msg.type === 'scan-local-styles') {
      try {
        var styles = await scanLocalStyles();
        figma.ui.postMessage({ type: 'scan-local-styles-result', styles: styles });
      } catch (err) {
        figma.ui.postMessage({ type: 'error', message: err.message || String(err) });
      }
    }
    else if (msg.type === 'convert-local-styles') {
      try {
        var res = await convertLocalStyles(msg.styles, msg.collectionId, msg.collectionName);
        figma.ui.postMessage({ type: 'convert-local-styles-result', result: res });
      } catch (err) {
        figma.ui.postMessage({ type: 'error', message: err.message || String(err) });
      }
    }
    else if (msg.type === 'bind-styles-to-variables') {
      try {
        var res = await bindStylesToVariables(msg.collectionId, msg.collectionName);
        figma.ui.postMessage({ type: 'bind-styles-to-variables-result', result: res });
      } catch (err) {
        figma.ui.postMessage({ type: 'error', message: err.message || String(err) });
      }
    }
    else if (msg.type === 'set-preview-mode') {
      try {
        var res = await setPreviewMode(msg.mode, msg.collectionId, msg.collectionName);
        figma.ui.postMessage({ type: 'set-preview-mode-result', result: res });
      } catch (err) {
        figma.ui.postMessage({ type: 'error', message: err.message || String(err) });
      }
    }
    else if (msg.type === 'close') {
      figma.closePlugin();
    }
  } catch(err) {
    figma.ui.postMessage({ type: 'error', message: err.message || String(err) });
  }
};

async function getOrCreateCollection(collectionId, collectionName) {
  var col = null;
  if (collectionId) col = await findCollectionById(collectionId);
  if (!col && collectionName) col = await findCollectionByName(collectionName);
  if (!col) {
    col = figma.variables.createVariableCollection(collectionName || 'WordPress');
    if (col.modes && col.modes.length > 0) {
      col.renameMode(col.modes[0].modeId, 'Default');
    }
  }
  return col;
}

/**
 * Fluid scales get their own collection. Decision 2026-07-16.
 *
 * A Figma collection has exactly one mode axis, and MV needs two independent ones:
 * viewport (Mobile/Desktop, used by fluid scales) and theme (Default/Dark/...).
 * They cannot share a collection — Figma has no cross-product of modes. So the site
 * collection carries the theme axis, and fluid scales move here where viewport owns it.
 *
 * Existing fluid variables are never moved: the caller keeps them in whatever
 * collection they already live in. Only new ones land here.
 */
function fluidCollectionName(siteCollection) {
  var base = siteCollection && siteCollection.name ? siteCollection.name : 'WordPress';
  return base + ' — Fluid';
}

async function getOrCreateFluidCollection(siteCollection) {
  var name = fluidCollectionName(siteCollection);
  var col = await findCollectionByName(name);
  if (!col) {
    col = figma.variables.createVariableCollection(name);
    if (col.modes && col.modes.length > 0) {
      col.renameMode(col.modes[0].modeId, 'Mobile');
    }
  }
  return col;
}

/** Find a variable by exact Figma name within one collection. */
async function findVarInCollection(col, figmaName) {
  if (!col || !col.variableIds) return null;
  for (var i = 0; i < col.variableIds.length; i++) {
    var v = await getVarById(col.variableIds[i]);
    if (v && v.name === figmaName) return v;
  }
  return null;
}

async function scanLocalStyles() {
  var paintStyles = figma.getLocalPaintStyles();
  var textStyles = figma.getLocalTextStyles();
  var list = [];

  // 1. Paint styles (Colors)
  for (var i = 0; i < paintStyles.length; i++) {
    var ps = paintStyles[i];
    var solidColor = null;
    if (Array.isArray(ps.paints)) {
      for (var pi = 0; pi < ps.paints.length; pi++) {
        var p = ps.paints[pi];
        if (p && p.type === 'SOLID' && p.visible !== false && p.color) {
          solidColor = rgbToHex6(p.color.r, p.color.g, p.color.b);
          break;
        }
      }
    }
    if (solidColor) {
      list.push({
        id: ps.id,
        name: ps.name,
        type: 'paint',
        family: 'color',
        value: solidColor,
        description: ps.description || ''
      });
    }
  }

  // 2. Text styles (Typography)
  for (var j = 0; j < textStyles.length; j++) {
    var ts = textStyles[j];
    if (typeof ts.fontSize === 'number' && ts.fontSize > 0) {
      list.push({
        id: ts.id,
        name: ts.name,
        type: 'text',
        family: 'typography',
        value: String(ts.fontSize),
        description: ts.description || '',
        fontSize: ts.fontSize
      });
    }
  }

  return list;
}

async function convertLocalStyles(stylesToConvert, collectionId, collectionName) {
  var activeCol = await getOrCreateCollection(collectionId, collectionName);
  if (!activeCol) {
    return { error: 'No collection selected or available.' };
  }

  var allVars = await figma.variables.getLocalVariablesAsync();
  var createdCount = 0;
  var skippedCount = 0;
  var errorsCount = 0;

  for (var i = 0; i < stylesToConvert.length; i++) {
    var style = stylesToConvert[i];
    try {
      var variableName = style.name.trim();
      var fullName = '';
      if (style.family === 'color') {
        fullName = variableName.startsWith('color/') ? variableName : 'color/' + variableName;
      } else {
        fullName = variableName.startsWith('typography/') ? variableName : 'typography/' + variableName;
      }

      // Check if variable already exists in this collection
      var existing = null;
      for (var vi = 0; vi < allVars.length; vi++) {
        var v = allVars[vi];
        if (v.variableCollectionId === activeCol.id && v.name.toLowerCase() === fullName.toLowerCase()) {
          existing = v;
          break;
        }
      }

      if (existing) {
        skippedCount++;
        continue;
      }

      var fType = style.family === 'color' ? 'COLOR' : 'FLOAT';
      var newVar = figma.variables.createVariable(fullName, activeCol, fType);
      
      if (style.description) {
        newVar.description = style.description;
      }

      var modeId = activeCol.modes && activeCol.modes[0] ? activeCol.modes[0].modeId : null;
      if (modeId) {
        if (style.family === 'color') {
          var hex = String(style.value).replace('#', '');
          var r = parseInt(hex.substring(0, 2), 16) / 255;
          var g = parseInt(hex.substring(2, 4), 16) / 255;
          var b = parseInt(hex.substring(4, 6), 16) / 255;
          newVar.setValueForMode(modeId, { r: r, g: g, b: b, a: 1 });
        } else {
          newVar.setValueForMode(modeId, parseFloat(style.value));
        }
      }

      createdCount++;
    } catch (e) {
      console.error('Failed to convert style:', style.name, e);
      errorsCount++;
    }
  }

  return { created: createdCount, skipped: skippedCount, errors: errorsCount };
}

async function bindStylesToVariables(collectionId, collectionName) {
  var debugLog = [];
  var col = await getOrCreateCollection(collectionId, collectionName);
  if (!col) {
    return { error: 'No active collection. Select a collection first.', debug: ['No collection resolved'] };
  }

  debugLog.push('Active collection resolved: ' + col.name + ' (ID: ' + col.id + ')');

  // List all collections in file for diagnostics
  var allCols = await getCollections();
  debugLog.push('All Variable Collections in this Figma file: ' + allCols.map(function(c) {
    return c.name + ' (ID: ' + c.id + ', vars: ' + (c.variableIds || []).length + ')';
  }).join(' · '));

  // Load variables in the collection
  var allVars = await figma.variables.getLocalVariablesAsync();
  var colVars = allVars.filter(function(v) { return v.variableCollectionId === col.id; });
  debugLog.push('Variables in active collection: ' + colVars.length);
  
  if (colVars.length === 0) {
    for (var c = 0; c < allCols.length; c++) {
      var otherCol = allCols[c];
      if (otherCol.name === col.name && otherCol.id !== col.id && (otherCol.variableIds || []).length > 0) {
        debugLog.push('Active collection was empty, but found another collection named "' + col.name + '" with ' + otherCol.variableIds.length + ' variables. Falling back to ID: ' + otherCol.id);
        col = otherCol;
        colVars = allVars.filter(function(v) { return v.variableCollectionId === col.id; });
        break;
      }
    }
  }
  
  // Build a lookup map of variable names to Variable objects
  var varMap = {};
  for (var i = 0; i < colVars.length; i++) {
    var v = colVars[i];
    var varName = v.name.toLowerCase();
    varMap[varName] = v;
    var shortName = varName.replace(/^(color|typography|space|radius)\//, '');
    if (shortName !== varName) {
      varMap[shortName] = v;
    }
  }
  debugLog.push('Variables Map keys: ' + JSON.stringify(Object.keys(varMap)));

  // Traversal
  await figma.currentPage.loadAsync();
  var nodes = figma.currentPage.findAll(function(n) { return true; });
  debugLog.push('Total nodes on current page: ' + nodes.length);
  var boundFills = 0;
  var boundStrokes = 0;
  var boundText = 0;

  var checkedFills = 0;
  var checkedStrokes = 0;
  var checkedTexts = 0;

  for (var j = 0; j < nodes.length; j++) {
    var n = nodes[j];

    // Fills
    if ('fillStyleId' in n && n.fillStyleId && typeof n.fillStyleId === 'string') {
      checkedFills++;
      var style = figma.getStyleById(n.fillStyleId);
      if (style) {
        var styleName = style.name.toLowerCase();
        var matchedVar = varMap['color/' + styleName] || varMap[styleName];
        if (!matchedVar) {
          var cleanName = styleName
            .replace(/[\/_-](desktop|mobile|tablet|max|min|large|small|xl|sm|xs|lg|md)$/i, '')
            .replace(/\s+(desktop|mobile|tablet|max|min|large|small|xl|sm|xs|lg|md)$/i, '');
          if (cleanName !== styleName) {
            matchedVar = varMap['color/' + cleanName] || varMap[cleanName];
          }
        }
        if (matchedVar) {
          if (Array.isArray(n.fills) && n.fills.length > 0) {
            var newFills = n.fills.map(function(paint, idx) {
              if (idx === 0 && paint.type === 'SOLID') {
                return figma.variables.setBoundVariableForPaint(Object.assign({}, paint), 'color', matchedVar);
              }
              return paint;
            });
            n.fills = newFills;
            boundFills++;
          }
        } else {
          if (checkedFills <= 5) {
            debugLog.push('Fill Style "' + style.name + '" on node "' + n.name + '" not matched to any variable.');
          }
        }
      } else {
        if (checkedFills <= 5) {
          debugLog.push('Fill Style ID "' + n.fillStyleId + '" on node "' + n.name + '" could not be resolved.');
        }
      }
    }

    // Strokes
    if ('strokeStyleId' in n && n.strokeStyleId && typeof n.strokeStyleId === 'string') {
      checkedStrokes++;
      var styleS = figma.getStyleById(n.strokeStyleId);
      if (styleS) {
        var styleNameS = styleS.name.toLowerCase();
        var matchedVarS = varMap['color/' + styleNameS] || varMap[styleNameS];
        if (!matchedVarS) {
          var cleanNameS = styleNameS
            .replace(/[\/_-](desktop|mobile|tablet|max|min|large|small|xl|sm|xs|lg|md)$/i, '')
            .replace(/\s+(desktop|mobile|tablet|max|min|large|small|xl|sm|xs|lg|md)$/i, '');
          if (cleanNameS !== styleNameS) {
            matchedVarS = varMap['color/' + cleanNameS] || varMap[cleanNameS];
          }
        }
        if (matchedVarS) {
          if (Array.isArray(n.strokes) && n.strokes.length > 0) {
            var newStrokes = n.strokes.map(function(paint, idx) {
              if (idx === 0 && paint.type === 'SOLID') {
                return figma.variables.setBoundVariableForPaint(Object.assign({}, paint), 'color', matchedVarS);
              }
              return paint;
            });
            n.strokes = newStrokes;
            boundStrokes++;
          }
        } else {
          if (checkedStrokes <= 5) {
            debugLog.push('Stroke Style "' + styleS.name + '" on node "' + n.name + '" not matched.');
          }
        }
      } else {
        if (checkedStrokes <= 5) {
          debugLog.push('Stroke Style ID "' + n.strokeStyleId + '" on node "' + n.name + '" could not be resolved.');
        }
      }
    }

    // Text Style -> Font Size variable
    if (n.type === 'TEXT' && n.textStyleId && typeof n.textStyleId === 'string') {
      checkedTexts++;
      var styleT = figma.getStyleById(n.textStyleId);
      if (styleT) {
        var styleNameT = styleT.name.toLowerCase();
        var matchedVarT = varMap['typography/' + styleNameT] || varMap[styleNameT];
        if (!matchedVarT) {
          var cleanNameT = styleNameT
            .replace(/[\/_-](desktop|mobile|tablet|max|min|large|small|xl|sm|xs|lg|md)$/i, '')
            .replace(/\s+(desktop|mobile|tablet|max|min|large|small|xl|sm|xs|lg|md)$/i, '');
          if (cleanNameT !== styleNameT) {
            matchedVarT = varMap['typography/' + cleanNameT] || varMap[cleanNameT];
          }
        }
        if (matchedVarT) {
          try {
            n.textStyleId = '';
            n.setBoundVariable('fontSize', matchedVarT);
            boundText++;
          } catch (err) {
            debugLog.push('Error binding text style on node "' + n.name + '": ' + err.toString());
          }
        } else {
          if (checkedTexts <= 5) {
            debugLog.push('Text Style "' + styleT.name + '" on node "' + n.name + '" not matched.');
          }
        }
      } else {
        if (checkedTexts <= 5) {
          debugLog.push('Text Style ID "' + n.textStyleId + '" on node "' + n.name + '" could not be resolved.');
        }
      }
    }
  }

  debugLog.push('Summary checked: fills=' + checkedFills + ', strokes=' + checkedStrokes + ', texts=' + checkedTexts);
  debugLog.push('Summary bound: fills=' + boundFills + ', strokes=' + boundStrokes + ', texts=' + boundText);

  return { boundFills: boundFills, boundStrokes: boundStrokes, boundText: boundText, debug: debugLog };
}

async function setPreviewMode(mode, collectionId, collectionName) {
  var col = await getOrCreateCollection(collectionId, collectionName);
  if (!col) {
    return { error: 'No active collection. Select a collection first.' };
  }

  // This is a FREE-PLAN tool only.
  //
  // With one mode available, a fluid variable can hold a single number, so this
  // swaps that number between min and max to preview each breakpoint. It writes to
  // col.modes[0].
  //
  // On a plan with modes, modes[0] is the *Mobile* mode — so previewing "desktop"
  // here would write max values straight into the Mobile mode and silently corrupt
  // it. Once real modes exist, Figma's own mode switcher is the mechanism and this
  // must not run.
  var hasRealModes = false;
  for (var mi = 0; mi < col.modes.length; mi++) {
    var mn = String(col.modes[mi].name).toLowerCase();
    if (mn.indexOf('desktop') !== -1 || mn.indexOf('max') !== -1) { hasRealModes = true; break; }
  }
  if (hasRealModes && col.modes.length > 1) {
    return {
      unavailable: true,
      message: 'This file has Mobile and Desktop modes. Switch modes in Figma instead — each frame can use its own, which this preview cannot do.'
    };
  }

  var allVars = await figma.variables.getLocalVariablesAsync();
  var colVars = allVars.filter(function(v) { return v.variableCollectionId === col.id; });
  var updated = 0;

  for (var i = 0; i < colVars.length; i++) {
    var v = colVars[i];
    var minVal = v.getPluginData('ve_min_px');
    var maxVal = v.getPluginData('ve_max_px');
    if (minVal && maxVal) {
      var val = mode === 'mobile' ? parseFloat(minVal) : parseFloat(maxVal);
      if (!isNaN(val)) {
        var modeId = col.modes[0].modeId;
        v.setValueForMode(modeId, val);
        updated++;
      }
    }
  }

  return { updated: updated };
}

