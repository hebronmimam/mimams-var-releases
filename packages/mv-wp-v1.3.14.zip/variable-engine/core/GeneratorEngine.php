<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

class GeneratorEngine {

    private const HANDLERS = [
        'color'      => Generators\ColorGenerator::class,
        'spacing'    => Generators\FluidScaleGenerator::class,
        'typography' => Generators\FluidScaleGenerator::class,
        'radius'     => Generators\FluidScaleGenerator::class,
        'size'       => Generators\FluidScaleGenerator::class,
    ];

    /* ── ATTACH a generator to a base variable ───────────────────── */
    public function attach( int $variable_id, string $type, array $config = [], bool $replace_existing = false ) {
        global $wpdb;

        $vm       = new VariableManager();
        $variable = $vm->get( $variable_id );

        if ( ! $variable ) {
            return new \WP_Error( 've_not_found', 'Base variable not found.', [ 'status' => 404 ] );
        }
        if ( 'base' !== $variable['type'] ) {
            return new \WP_Error( 've_not_base', 'Generators can only attach to base variables.', [ 'status' => 400 ] );
        }
        if ( ! isset( self::HANDLERS[ $type ] ) ) {
            return new \WP_Error( 've_invalid_generator', "Unknown generator type: {$type}", [ 'status' => 400 ] );
        }

        $table = Schema::table( 'generators' );
        $existing_generator = $wpdb->get_var( $wpdb->prepare(
            "SELECT id FROM {$table} WHERE variable_id = %d AND type = %s AND active = 1 LIMIT 1",
            $variable_id,
            $type
        ) );
        if ( $existing_generator && ! $replace_existing ) {
            return new \WP_Error(
                've_generator_exists',
                'An active generator of this type is already attached to the variable.',
                [ 'status' => 409, 'generator_id' => (int) $existing_generator ]
            );
        }

        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_transaction_failed', $wpdb->last_error ?: 'Could not start the generator transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;
        if ( $replace_existing ) {
            $removed = $this->remove_generator_type( $variable_id, $type );
            if ( is_wp_error( $removed ) ) {
                $this->rollback_if_owned( $owns_transaction );
                return $removed;
            }
        }

        $inserted = $wpdb->insert( $table, [
            'variable_id' => $variable_id,
            'type'        => $type,
            'config'      => wp_json_encode( $config ),
            'active'      => 1,
        ], [ '%d', '%s', '%s', '%d' ] );
        if ( false === $inserted ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_generator_create_failed', $wpdb->last_error ?: 'Could not attach the generator.', [ 'status' => 500 ] );
        }

        $generator_id  = (int) $wpdb->insert_id;
        $generated_ids = $this->run_generator( $generator_id, $variable, $type, $config );
        if ( is_wp_error( $generated_ids ) ) {
            $this->rollback_if_owned( $owns_transaction );
            return $generated_ids;
        }

        if ( ! ( new CssExporter() )->export() ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_css_write_failed', 'The generator was not attached because the CSS file could not be written.', [ 'status' => 500 ] );
        }
        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            $this->rollback_if_owned( $owns_transaction );
            ( new CssExporter() )->export();
            return new \WP_Error( 've_generator_commit_failed', $wpdb->last_error ?: 'Could not commit the generator changes.', [ 'status' => 500 ] );
        }

        return [
            'generator_id' => $generator_id,
            'type'         => $type,
            'config'       => $config,
            'generated'    => $generated_ids,
        ];
    }

    /* ── DETACH — remove generator + its generated variables ──────── */
    public function detach( int $generator_id ) {
        global $wpdb;
        $table = Schema::table( 'generators' );
        $gen   = $wpdb->get_row( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE id = %d", $generator_id
        ), ARRAY_A );

        if ( ! $gen ) {
            return new \WP_Error( 've_not_found', 'Generator not found.', [ 'status' => 404 ] );
        }

        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_transaction_failed', $wpdb->last_error ?: 'Could not start the generator transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;
        $var_table = Schema::table( 'variables' );
        $dep_table = Schema::table( 'dependencies' );

        // Get IDs of generated variables before deleting.
        $gen_var_ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT id FROM {$var_table} WHERE source_id = %d AND generator_type = %s AND type = 'generated'",
            $gen['variable_id'],
            $gen['type']
        ) );

        if ( $gen_var_ids ) {
            $ids_in = implode( ',', array_map( 'intval', $gen_var_ids ) );
            $external_dependents = (int) $wpdb->get_var(
                "SELECT COUNT(*) FROM {$dep_table} WHERE parent_id IN ({$ids_in}) AND child_id NOT IN ({$ids_in})"
            );
            if ( $external_dependents > 0 ) {
                $this->rollback_if_owned( $owns_transaction );
                return new \WP_Error(
                    've_generated_has_dependents',
                    'This generator cannot be removed while generated variables are used by other variables.',
                    [ 'status' => 409, 'dependent_count' => $external_dependents ]
                );
            }
            if (
                false === $wpdb->query( "DELETE FROM {$dep_table} WHERE child_id IN ({$ids_in})" )
                || false === $wpdb->query( "DELETE FROM {$var_table} WHERE id IN ({$ids_in})" )
            ) {
                $this->rollback_if_owned( $owns_transaction );
                return new \WP_Error( 've_generator_detach_failed', $wpdb->last_error ?: 'Could not remove generated variables.', [ 'status' => 500 ] );
            }
        }

        if ( false === $wpdb->delete( $table, [ 'id' => $generator_id ] ) ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_generator_detach_failed', $wpdb->last_error ?: 'Could not remove the generator.', [ 'status' => 500 ] );
        }
        if ( ! ( new CssExporter() )->export() ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_css_write_failed', 'The generator was not removed because the CSS file could not be written.', [ 'status' => 500 ] );
        }
        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            $this->rollback_if_owned( $owns_transaction );
            ( new CssExporter() )->export();
            return new \WP_Error( 've_generator_commit_failed', $wpdb->last_error ?: 'Could not commit the generator removal.', [ 'status' => 500 ] );
        }

        return true;
    }

    /* ── REGENERATE all active generators for a variable ──────────── */
    public function regenerate( int $variable_id, bool $export_css = true ) {
        global $wpdb;
        $vm    = new VariableManager();
        $variable = $vm->get( $variable_id );
        if ( ! $variable ) {
            return new \WP_Error( 've_not_found', 'Base variable not found.', [ 'status' => 404 ] );
        }
        $transaction_state = $this->begin_transaction_if_needed();
        if ( $transaction_state < 0 ) {
            return new \WP_Error( 've_transaction_failed', $wpdb->last_error ?: 'Could not start the regeneration transaction.', [ 'status' => 500 ] );
        }
        $owns_transaction = 1 === $transaction_state;

        // Try generators table first
        $table = Schema::table( 'generators' );
        $generators = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$table} WHERE variable_id = %d",
            $variable_id
        ), ARRAY_A );

        if ( ! empty( $generators ) ) {
            foreach ( $generators as $gen ) {
                $config = json_decode( $gen['config'], true ) ?: [];
                $result = $this->run_generator( (int) $gen['id'], $variable, $gen['type'], $config );
                if ( is_wp_error( $result ) ) {
                    $this->rollback_if_owned( $owns_transaction );
                    return $result;
                }
            }
            return $this->finish_regeneration( $owns_transaction, $export_css );
        }

        // Fallback: check dependencies table for children, detect type from generator_type
        $dep_table = Schema::table( 'dependencies' );
        $children = $wpdb->get_results( $wpdb->prepare(
            "SELECT child_id FROM {$dep_table} WHERE parent_id = %d AND relation = 'generated'",
            $variable_id
        ), ARRAY_A );

        if ( empty( $children ) ) return $this->finish_regeneration( $owns_transaction, $export_css );

        // Get one child to detect what kind of generator was used
        $child = $vm->get( (int) $children[0]['child_id'] );
        if ( ! $child || empty( $child['generator_type'] ) ) return $this->finish_regeneration( $owns_transaction, $export_css );

        $gen_type = $child['generator_type'];
        // Count children to determine config
        $child_count = count( $children );

        // Build a reasonable config based on what exists
        if ( $gen_type === 'color' ) {
            $tints = $shades = $alphas = 0;
            foreach ( $children as $ch ) {
                $c = $vm->get( (int) $ch['child_id'] );
                if ( ! $c ) continue;
                $name = $c['name'];
                if ( strpos( $name, '.l.' ) !== false ) $tints++;
                elseif ( strpos( $name, '.d.' ) !== false ) $shades++;
                elseif ( strpos( $name, '.t.' ) !== false ) $alphas++;
            }
            $config = [
                'tint_count'    => $tints,
                'shade_count'   => $shades,
                'include_alpha' => $alphas > 0,
                'alpha_count'   => $alphas,
            ];
        } else {
            // For scale generators, we can't easily reconstruct config
            // Just skip — they don't change with base value typically
            return $this->finish_regeneration( $owns_transaction, $export_css );
        }

        // Run the generator with reconstructed config
        $handler_class = self::HANDLERS[ $gen_type ] ?? null;
        if ( ! $handler_class || ! class_exists( $handler_class ) ) {
            return $this->finish_regeneration( $owns_transaction, $export_css );
        }

        $handler = new $handler_class();
        $scales  = $handler->generate( $variable, $config );
        $var_table = Schema::table( 'variables' );

        foreach ( $scales as $item ) {
            $existing = $vm->get_by_name( $item['name'] );
            if ( $existing ) {
                $updated = $wpdb->update( $var_table, [
                    'value'     => $item['value'],
                    'css_value' => $item['value'],
                ], [ 'id' => $existing['id'] ], [ '%s', '%s' ], [ '%d' ] );
                if ( false === $updated ) {
                    $this->rollback_if_owned( $owns_transaction );
                    return new \WP_Error( 've_regenerate_failed', $wpdb->last_error ?: 'Could not update a generated variable.', [ 'status' => 500 ] );
                }
            }
        }
        return $this->finish_regeneration( $owns_transaction, $export_css );
    }

    /* ── LIST generators for a variable ───────────────────────────── */
    public function list_for_variable( int $variable_id ): array {
        global $wpdb;
        return $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM " . Schema::table( 'generators' ) . " WHERE variable_id = %d ORDER BY id ASC",
            $variable_id
        ), ARRAY_A ) ?: [];
    }

    /* ── INTERNAL: execute a single generator ─────────────────────── */
    private function run_generator( int $generator_id, array $base_variable, string $type, array $config ) {
        $handler_class = self::HANDLERS[ $type ] ?? null;
        if ( ! $handler_class || ! class_exists( $handler_class ) ) {
            return new \WP_Error( 've_invalid_generator', "Unknown generator type: {$type}", [ 'status' => 400 ] );
        }

        $handler     = new $handler_class();
        $scales      = $handler->generate( $base_variable, $config );
        $vm          = new VariableManager();
        $graph       = new DependencyGraph();
        $created_ids = [];

        global $wpdb;
        $var_table = Schema::table( 'variables' );
        $owned_rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT * FROM {$var_table}
             WHERE source_id = %d
               AND generator_type = %s
               AND type = 'generated'
             ORDER BY id DESC",
            (int) $base_variable['id'],
            $type
        ), ARRAY_A ) ?: [];
        $owned_by_key = [];
        foreach ( $owned_rows as $owned_row ) {
            $key = $this->generated_item_key( (string) ( $owned_row['name'] ?? '' ), $type );
            if ( '' !== $key && ! isset( $owned_by_key[ $key ] ) ) {
                $owned_by_key[ $key ] = $owned_row;
            }
        }
        $assignments = [];
        $assigned_ids = [];

        foreach ( $scales as $index => $item ) {
            $existing = $vm->get_by_name( $item['name'] );
            if (
                $existing
                && (
                    'generated' !== ( $existing['type'] ?? '' )
                    || (int) ( $existing['source_id'] ?? 0 ) !== (int) $base_variable['id']
                    || (string) ( $existing['generator_type'] ?? '' ) !== $type
                )
            ) {
                return new \WP_Error(
                    've_generated_name_conflict',
                    "Generated variable '{$item['name']}' conflicts with an existing variable.",
                    [ 'status' => 409, 'conflict_id' => (int) $existing['id'] ]
                );
            }

            $candidate = $existing;
            if ( ! $candidate ) {
                $key = $this->generated_item_key( (string) $item['name'], $type );
                $stable_candidate = $owned_by_key[ $key ] ?? null;
                if ( $stable_candidate && ! isset( $assigned_ids[ (int) $stable_candidate['id'] ] ) ) {
                    $candidate = $stable_candidate;
                }
            }

            $css_conflict = $vm->get_css_name_conflict( $item['name'], $candidate ? (int) $candidate['id'] : 0 );
            if ( $css_conflict ) {
                return new \WP_Error(
                    've_generated_css_name_conflict',
                    "Generated variable '{$item['name']}' would share a CSS custom property with '{$css_conflict['name']}'.",
                    [ 'status' => 409, 'conflict_id' => (int) $css_conflict['id'] ]
                );
            }

            $assignments[ $index ] = $candidate;
            if ( $candidate ) {
                $assigned_ids[ (int) $candidate['id'] ] = true;
            }
        }

        foreach ( $scales as $index => $item ) {
            $existing = $assignments[ $index ] ?? null;

            if ( $existing ) {
                $updated = $wpdb->update( $var_table, [
                    'name'           => $item['name'],
                    'value'          => $item['value'],
                    'css_value'      => $item['value'],
                    'source_id'      => (int) $base_variable['id'],
                    'generator_type' => $type,
                    'type'           => 'generated',
                    'namespace'      => explode( '.', $item['name'] )[0],
                ], [ 'id' => $existing['id'] ], [ '%s', '%s', '%s', '%d', '%s', '%s', '%s' ], [ '%d' ] );
                if ( false === $updated ) {
                    return new \WP_Error( 've_generate_failed', $wpdb->last_error ?: "Could not update '{$item['name']}'.", [ 'status' => 500 ] );
                }
                $created_ids[] = (int) $existing['id'];
                if ( ! $graph->register( (int) $base_variable['id'], (int) $existing['id'], 'generated' ) ) {
                    return new \WP_Error( 've_dependency_failed', "Could not register the dependency for '{$item['name']}'.", [ 'status' => 500 ] );
                }
            } else {
                $namespace = explode( '.', $item['name'] )[0];
                $inserted = $wpdb->insert( $var_table, [
                    'name'           => $item['name'],
                    'type'           => 'generated',
                    'namespace'      => $namespace,
                    'value'          => $item['value'],
                    'css_value'      => $item['value'],
                    'source_id'      => $base_variable['id'],
                    'generator_type' => $type,
                ], [ '%s', '%s', '%s', '%s', '%s', '%d', '%s' ] );
                if ( false === $inserted ) {
                    return new \WP_Error( 've_generate_failed', $wpdb->last_error ?: "Could not create '{$item['name']}'.", [ 'status' => 500 ] );
                }

                $child_id      = (int) $wpdb->insert_id;
                $created_ids[] = $child_id;
                if ( ! $graph->register( (int) $base_variable['id'], $child_id, 'generated' ) ) {
                    return new \WP_Error( 've_dependency_failed', "Could not register the dependency for '{$item['name']}'.", [ 'status' => 500 ] );
                }
            }
        }

        // Remove generated rows from older naming patterns for this same base/generator.
        // This keeps a rename from `font.space` to `size.space` from leaving old
        // CSS variables like --font-107 behind after the new --size-107 set exists.
        $created_ids = array_values( array_unique( array_map( 'intval', $created_ids ) ) );
        $dep_table = Schema::table( 'dependencies' );
        if ( ! empty( $created_ids ) ) {
            $placeholders = implode( ',', array_fill( 0, count( $created_ids ), '%d' ) );
            $params = array_merge( [ (int) $base_variable['id'], $type ], $created_ids );
            $old_ids = $wpdb->get_col( $wpdb->prepare(
                "SELECT id FROM {$var_table}
                 WHERE source_id = %d
                   AND generator_type = %s
                   AND type = 'generated'
                   AND id NOT IN ({$placeholders})",
                $params
            ) ) ?: [];
        } else {
            $old_ids = $wpdb->get_col( $wpdb->prepare(
                "SELECT id FROM {$var_table}
                 WHERE source_id = %d
                   AND generator_type = %s
                   AND type = 'generated'",
                (int) $base_variable['id'],
                $type
            ) ) ?: [];
        }

        if ( ! empty( $old_ids ) ) {
            $old_ids = array_values( array_unique( array_map( 'intval', $old_ids ) ) );
            $old_placeholders = implode( ',', array_fill( 0, count( $old_ids ), '%d' ) );
            $external_dependents = (int) $wpdb->get_var( $wpdb->prepare(
                "SELECT COUNT(*) FROM {$dep_table}
                 WHERE parent_id IN ({$old_placeholders})
                   AND child_id NOT IN ({$old_placeholders})",
                array_merge( $old_ids, $old_ids )
            ) );
            if ( $external_dependents > 0 ) {
                return new \WP_Error(
                    've_generated_has_dependents',
                    'The generator change would remove generated variables that are used by other variables.',
                    [ 'status' => 409, 'dependent_count' => $external_dependents ]
                );
            }
            if (
                false === $wpdb->query( $wpdb->prepare( "DELETE FROM {$dep_table} WHERE parent_id IN ({$old_placeholders}) OR child_id IN ({$old_placeholders})", array_merge( $old_ids, $old_ids ) ) )
                || false === $wpdb->query( $wpdb->prepare( "DELETE FROM {$var_table} WHERE id IN ({$old_placeholders})", $old_ids ) )
            ) {
                return new \WP_Error( 've_generate_cleanup_failed', $wpdb->last_error ?: 'Could not remove stale generated variables.', [ 'status' => 500 ] );
            }
        }

        return $created_ids;
    }

    private function generated_item_key( string $name, string $type ): string {
        if ( 'color' === $type && preg_match( '/\.([ldt])\.(\d+)$/', $name, $match ) ) {
            return $match[1] . ':' . $match[2];
        }

        $parts = array_values( array_filter( explode( '.', $name ), static function ( $part ) {
            return '' !== $part;
        } ) );
        if ( empty( $parts ) ) {
            return '';
        }

        return 'leaf:' . strtolower( (string) end( $parts ) );
    }

    private function begin_transaction_if_needed(): int {
        global $wpdb;
        $in_transaction = (int) $wpdb->get_var( 'SELECT @@in_transaction' );
        if ( $in_transaction > 0 ) {
            return 0;
        }
        return false === $wpdb->query( 'START TRANSACTION' ) ? -1 : 1;
    }

    private function rollback_if_owned( bool $owns_transaction ): void {
        global $wpdb;
        if ( $owns_transaction ) {
            $wpdb->query( 'ROLLBACK' );
        }
    }

    private function commit_if_owned( bool $owns_transaction ): bool {
        global $wpdb;
        return ! $owns_transaction || false !== $wpdb->query( 'COMMIT' );
    }

    private function finish_regeneration( bool $owns_transaction, bool $export_css ) {
        global $wpdb;

        if ( $export_css && ! ( new CssExporter() )->export() ) {
            $this->rollback_if_owned( $owns_transaction );
            return new \WP_Error( 've_css_write_failed', 'Generated variables changed, but the CSS file could not be written.', [ 'status' => 500 ] );
        }
        if ( ! $this->commit_if_owned( $owns_transaction ) ) {
            $this->rollback_if_owned( $owns_transaction );
            if ( $export_css ) {
                ( new CssExporter() )->export();
            }
            return new \WP_Error( 've_generator_commit_failed', $wpdb->last_error ?: 'Could not commit generated-variable changes.', [ 'status' => 500 ] );
        }
        return true;
    }

    private function remove_generator_type( int $variable_id, string $type ) {
        global $wpdb;

        $gen_table = Schema::table( 'generators' );

        $deleted = $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$gen_table} WHERE variable_id = %d AND type = %s",
            $variable_id,
            $type
        ) );
        if ( false === $deleted ) {
            return new \WP_Error( 've_generator_replace_failed', $wpdb->last_error ?: 'Could not remove the previous generator.', [ 'status' => 500 ] );
        }

        return true;
    }
}
