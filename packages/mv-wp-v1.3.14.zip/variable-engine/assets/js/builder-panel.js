(function(){
'use strict';
if(window.self!==window.top&&document.querySelector('.brx-body'))return;
const{h,render}=window.preact;const{useState,useEffect,useRef,useMemo,useCallback}=window.preactHooks;
const CFG=window.vePanel||{};const MODE=CFG.mode||'admin';

const api={
f:async(p,o={})=>{
  const r=await fetch((CFG.apiRoot||'/wp-json/')+p,{credentials:'same-origin',...o,headers:{'X-WP-Nonce':CFG.nonce||'',...(o.headers||{})}});
  const ct=(r.headers.get('content-type')||'').toLowerCase();
  const txt=await r.text();
  let data=null;
  if(ct.includes('application/json')){
    try{data=txt?JSON.parse(txt):{};}catch(e){data={code:'ve_bad_json',message:'WordPress returned invalid JSON.'};}
  }else{
    data={code:'ve_non_json',message:r.ok?'Unexpected non-JSON response from WordPress.':'WordPress returned an error while previewing impact.',raw:txt};
  }
  if(!r.ok&&!data.code)data.code='ve_http_'+r.status;
  return data;
},
g:p=>api.f('variable-engine/v1/'+p),
p:async(p,b)=>{
  const d=await api.f('variable-engine/v1/'+p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
  if(!d?.code){
    if(isVariableMutationPath(p))refreshVariableStylesheets();
    if(p.split('?')[0]==='settings')refreshSettings();
  }
  return d;
},
u:async(p,b)=>{
  const d=await api.f('variable-engine/v1/'+p,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
  if(!d?.code){
    if(isVariableMutationPath(p))refreshVariableStylesheets();
    if(p.split('?')[0]==='settings')refreshSettings();
  }
  return d;
},
d:async(p,b)=>{
  const opts={method:'DELETE'};
  if(b!==undefined){opts.headers={'Content-Type':'application/json'};opts.body=JSON.stringify(b);}
  const d=await api.f('variable-engine/v1/'+p,opts);
  if(!d?.code&&isVariableMutationPath(p))refreshVariableStylesheets();
  return d;
},
};

function isVariableMutationPath(path){
  const clean=String(path||'').split('?')[0];
  if(/rename-preview$/.test(clean))return false;
  return /^(variables(?:\/|$)|generators(?:\/|$)|palettes(?:\/|$)|themes(?:\/|$)|color-palettes(?:\/|$)|sync\/import(?:\/|$)|snapshots\/[^/]+\/rollback$)/.test(clean);
}
const variablePreviewValues=new Map();
function builderRuntimeWindows(){
  const found=[],queue=[];
  const add=runtime=>{
    try{
      if(runtime&&runtime.document&&!found.includes(runtime)){
        found.push(runtime);
        queue.push(runtime);
      }
    }catch(e){}
  };
  add(window);
  try{add(window.parent);}catch(e){}
  try{add(window.top);}catch(e){}
  while(queue.length){
    const runtime=queue.shift();
    try{runtime.document.querySelectorAll('iframe').forEach(frame=>add(frame.contentWindow));}catch(e){}
  }
  return found;
}
function builderRuntimeDocuments(){
  const found=[];
  builderRuntimeWindows().forEach(runtime=>{
    try{if(runtime.document&&!found.includes(runtime.document))found.push(runtime.document);}catch(e){}
  });
  return found;
}
function renderVariablePreviewStyles(){
  const cssText=variablePreviewValues.size
    ? ':root {\n'+Array.from(variablePreviewValues.entries()).map(([name,value])=>`  ${name}: ${value} !important;`).join('\n')+'\n}'
    : '';
  builderRuntimeDocuments().forEach(doc=>{
    try{
      let styleEl=doc.getElementById('ve-variable-preview-runtime');
      if(!cssText){
        styleEl?.remove();
        return;
      }
      if(!styleEl){
        styleEl=doc.createElement('style');
        styleEl.id='ve-variable-preview-runtime';
        (doc.head||doc.documentElement).appendChild(styleEl);
      }
      styleEl.textContent=cssText;
    }catch(e){}
  });
}
function applyVariablePreview(name,value){
  const cssName=cssTokenName(name);
  if(!cssName||!value)return;
  variablePreviewValues.set(cssName,value);
  renderVariablePreviewStyles();
}
function clearVariablePreview(name){
  variablePreviewValues.delete(cssTokenName(name));
  renderVariablePreviewStyles();
}
function refreshVariableStylesheets(){
  const docs=builderRuntimeDocuments();
  let pending=0;
  const announce=()=>{
    syncBricksVariableConsumers();
    builderRuntimeWindows().forEach(win => {
      try {
        win.dispatchEvent(new win.CustomEvent('ve-variables-updated',{detail:{at:Date.now()}}));
        win.document.dispatchEvent(new win.CustomEvent('ve:variables-updated',{detail:{at:Date.now()}}));
      } catch (e) {
        try { win.dispatchEvent(new CustomEvent('ve-variables-updated',{detail:{at:Date.now()}})); } catch (err) {}
      }
    });
  };
  docs.forEach(doc=>{
    Array.from(doc.querySelectorAll('link[rel="stylesheet"]')).filter(link=>{
      const href=link.getAttribute('href')||'';
      return /\/variable-engine\/variables\.css(?:[?#]|$)/.test(href)||/^ve-variables(?:-admin)?-css$/.test(link.id||'');
    }).forEach(link=>{
      let nextUrl;
      try{nextUrl=new URL(link.href,doc.baseURI);nextUrl.searchParams.set('ve-refresh',Date.now().toString());}catch(e){return;}
      const next=link.cloneNode(true);
      next.href=nextUrl.toString();
      next.id=link.id;
      pending++;
      next.addEventListener('load',()=>{link.remove();pending--;if(pending===0)announce();},{once:true});
      next.addEventListener('error',()=>{next.remove();pending--;if(pending===0)announce();},{once:true});
      link.parentNode?.insertBefore(next,link.nextSibling);
    });
  });
  if(pending===0)announce();
}
function refreshSettings(){
  builderRuntimeWindows().forEach(win => {
    try {
      win.dispatchEvent(new win.CustomEvent('ve-settings-updated',{detail:{at:Date.now()}}));
    } catch (e) {
      try { win.dispatchEvent(new CustomEvent('ve-settings-updated',{detail:{at:Date.now()}})); } catch (err) {}
    }
  });
}
async function syncBricksVariableConsumers(){
  if(MODE!=='builder')return false;
  let variables;
  try{variables=await api.g('variables?dedupe=true&_nc='+Date.now());}catch(e){return false;}
  if(!Array.isArray(variables))return false;
  const mirrored=variables.map(v=>({
    id:'mv-'+v.id,
    name:cssTokenName(v.name).replace(/^--/,''),
    value:v.css_value||v.value||'',
    category:'mimams-var'
  })).filter(v=>v.name);
  const apply=()=>{
    let providerFound=false;
    builderRuntimeWindows().forEach(runtime=>{
      try{
        const current=Array.isArray(runtime.bricksData?.loadData?.globalVariables)?runtime.bricksData.loadData.globalVariables:[];
        const external=current.filter(v=>v&&v.category!=='mimams-var'&&!String(v.id||'').startsWith('mv-'));
        const externalNames=new Set(external.map(v=>String(v?.name||'').replace(/^--/,'')).filter(Boolean));
        const localMirrored=mirrored.filter(v=>!externalNames.has(v.name));
        const runtimeCssText=':root {\n'+localMirrored.map(v=>`  --${v.name}: ${v.value} !important;`).join('\n')+'\n}';
        if(runtime.bricksData?.loadData)runtime.bricksData.loadData.globalVariables=[...external,...localMirrored];
        const provider=runtime.Code2Bricks?.css?.CssVariableProvider;
        if(provider){
          providerFound=true;
          if(provider.refresh)provider.refresh();
          const mvNames=localMirrored.map(v=>'--'+v.name);
          const existing=Array.isArray(provider._variables)?provider._variables:[];
          provider._variables=Array.from(new Set([...existing,...mvNames])).sort();
          provider._variablesFormatted=provider._variables.map(name=>`var(${name})`);
          provider._lastRefresh=Date.now();
        }
        if(runtime.document){
          let styleEl=runtime.document.getElementById('ve-dynamic-variables-runtime');
          if(!styleEl){
            styleEl=runtime.document.createElement('style');
            styleEl.id='ve-dynamic-variables-runtime';
            (runtime.document.head||runtime.document.documentElement).appendChild(styleEl);
          }
          styleEl.textContent=runtimeCssText;
          runtime.document.querySelectorAll('iframe').forEach(frame=>{
            if(frame.__veVariableRuntimeLoadBound)return;
            frame.__veVariableRuntimeLoadBound=true;
            frame.addEventListener('load',()=>setTimeout(apply,0));
          });
        }
      }catch(e){}
    });
    renderVariablePreviewStyles();
    return providerFound;
  };
  const providerFound=apply();
  [250,600,1200,2400,4800].forEach(delay=>setTimeout(apply,delay));
  return providerFound;
}

const USER_PREF_KEYS=[
  'mimamsBarSettings','ve_skip_update_version','ve_panel_mode','ve_panel_pos','ve_allow_multi_panels',
  've_deactivated_tools','ve_css_scss','ve_css_source_order','ve_css_disabled_sources',
  've_content_visible_groups','ve_media_layout','ve_media_filter','ve_media_sort','ve_plugin_directory_view',
  've_pos_ve_settings_pos','ve_pos_ve_help_pos','ve_pos_ve_css_studio_pos','ve_pos_ve_css_recipes_pos',
  've_pos_ve_content_pos','ve_pos_ve_media_pos','ve_pos_ve_plugin_pos'
];
let userPreferenceTimer=null;
function preferenceStorageValue(value){
  return value&&typeof value==='object'?JSON.stringify(value):String(value??'');
}
function hydrateUserPreferences(){
  const remote=CFG.userPreferences&&typeof CFG.userPreferences==='object'?CFG.userPreferences:{};
  Object.keys(remote).forEach(key=>{
    if(!USER_PREF_KEYS.includes(key))return;
    try{localStorage.setItem(key,preferenceStorageValue(remote[key]));}catch(e){}
  });
  return Object.keys(remote).length>0;
}
function collectUserPreferences(){
  const preferences={};
  USER_PREF_KEYS.forEach(key=>{
    let raw='';
    try{raw=localStorage.getItem(key);}catch(e){raw=null;}
    if(raw===null)return;
    if(/^[\[{]/.test(raw)){
      try{preferences[key]=JSON.parse(raw);return;}catch(e){}
    }
    preferences[key]=raw;
  });
  return preferences;
}
function syncUserPreferences(){
  api.p('user-preferences',{preferences:collectUserPreferences()}).catch(()=>{});
}
function persistUserPreference(key,value){
  try{localStorage.setItem(key,preferenceStorageValue(value));}catch(e){}
  if(!USER_PREF_KEYS.includes(key))return;
  if(userPreferenceTimer)clearTimeout(userPreferenceTimer);
  userPreferenceTimer=setTimeout(syncUserPreferences,280);
}
window.vePersistUserPreference=persistUserPreference;
const hadRemoteUserPreferences=hydrateUserPreferences();
if(!hadRemoteUserPreferences)setTimeout(syncUserPreferences,1200);

function fuzzy(q,tLower){if(tLower.includes(q))return{m:1,s:tLower.indexOf(q)===0?100:80};let i=0,s=0;for(let j=0;j<tLower.length&&i<q.length;j++)if(tLower[j]===q[i]){i++;s+=10;}return{m:i===q.length,s};}
function tokenParts(n){return String(n||'').split('.').filter(Boolean);}
function stripStorageWrapper(n){const p=tokenParts(n);const wrappers=['size','font','typography'];return p.length>1&&wrappers.includes(p[0])?p.slice(1).join('.'):p.join('.');}
function cssTokenName(n){return '--'+stripStorageWrapper(n).replace(/\./g,'-');}
function sn(n){const clean=stripStorageWrapper(n);const p=clean.split('.');return p.length>1?p.slice(1).join('.'):clean;}
function normalizeNameInput(v){return String(v||'').toLowerCase().replace(/[\s._]+/g,'-').replace(/[^a-z0-9-]/g,'').replace(/-+/g,'-').replace(/^-+/,'');}
function publicTokenLabel(n){return cssTokenName(n).replace(/^--/,'');}
function safeFilePart(value,fallback='site'){
  const clean=String(value||'').toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
  return clean||fallback;
}
function detectAliasSource(value, vars){
  if (!value || typeof value !== 'string') return null;
  const clean = value.trim();
  let cssName = '';
  const m1 = clean.match(/^var\(\s*(--[a-z0-9.-]+)\s*\)$/i);
  const m2 = clean.match(/^(--[a-z0-9.-]+)$/i);
  if (m1) cssName = m1[1];
  else if (m2) cssName = m2[1];
  if (cssName) {
    const found = (vars || []).find(v => cssTokenName(v.name).toLowerCase() === cssName.toLowerCase());
    return found ? found.id : null;
  }
  return null;
}
function resolvedVariableValue(v, vars, visited = new Set()) {
  const id=String(v?.id??'');
  if (!v || visited.has(id)) return '';
  visited.add(id);
  if (v.type === 'alias' && v.source_id) {
    const parent = (vars || []).find(x => String(x.id) === String(v.source_id));
    return parent ? resolvedVariableValue(parent, vars, visited) : '';
  }
  return v.value || '';
}
function isClr(v){return/^(#|rgb|hsl|oklch)/i.test(v||'');}
function clrToHex(v){if(!v)return'#000000';if(v.charAt(0)==='#'){let h=v.slice(1);if(h.length===3)h=h[0]+h[0]+h[1]+h[1]+h[2]+h[2];return'#'+h.slice(0,6);}
const rm=v.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);if(rm)return'#'+[rm[1],rm[2],rm[3]].map(x=>('0'+(+x).toString(16)).slice(-2)).join('');
const om=v.match(/oklch\(\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)/);if(om){const L=+om[1],C=+om[2],H=+om[3],hr=H*Math.PI/180,a=C*Math.cos(hr),b=C*Math.sin(hr),l_=L+.3963377774*a+.2158037573*b,m_=L-.1055613458*a-.0638541728*b,s_=L-.0894841775*a-1.291485548*b,l=l_*l_*l_,m=m_*m_*m_,s=s_*s_*s_,rl=4.0767416621*l-3.3077115913*m+.2309699292*s,gl=-1.2684380046*l+2.6097574011*m-.3413193965*s,bl=-.0041960863*l-.7034186147*m+1.707614701*s,gm=x=>x<=.0031308?12.92*x:1.055*Math.pow(Math.max(0,x),1/2.4)-.055,r=Math.round(Math.max(0,Math.min(1,gm(rl)))*255),g=Math.round(Math.max(0,Math.min(1,gm(gl)))*255),bv=Math.round(Math.max(0,Math.min(1,gm(bl)))*255);return'#'+('0'+r.toString(16)).slice(-2)+('0'+g.toString(16)).slice(-2)+('0'+bv.toString(16)).slice(-2);}
const hm=v.match(/hsla?\(\s*([\d.]+)\s*,?\s*([\d.]+)%?\s*,?\s*([\d.]+)%?/);if(hm){const hu=+hm[1]/360,sa=+hm[2]/100,li=+hm[3]/100,q=li<.5?li*(1+sa):li+sa-li*sa,p=2*li-q,h2r=(pp,qq,t)=>{if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return pp+(qq-pp)*6*t;if(t<.5)return qq;if(t<2/3)return pp+(qq-pp)*(2/3-t)*6;return pp;},r=Math.round((sa===0?li:h2r(p,q,hu+1/3))*255),g=Math.round((sa===0?li:h2r(p,q,hu))*255),bv=Math.round((sa===0?li:h2r(p,q,hu-1/3))*255);return'#'+('0'+r.toString(16)).slice(-2)+('0'+g.toString(16)).slice(-2)+('0'+bv.toString(16)).slice(-2);}
return'#000000';}
function pxV(v){const str=(v||'').toString();const cm=str.match(/clamp\([^,]+,[^,]+,\s*([\d.]+)(rem|px)?/i);if(cm){return (cm[2]||'')==='rem'?parseFloat(cm[1])*10:parseFloat(cm[1]);}const m=str.match(/([\d.]+)(rem|px)?/i);if(!m)return 0;return (m[2]||'')==='rem'?parseFloat(m[1])*10:parseFloat(m[1]);}
function pxToRemValue(v){const n=parseFloat((v||'').toString().replace(/[^0-9.]/g,''));if(!isFinite(n))return'';return (Math.round((n/10)*10000)/10000).toString().replace(/\.?0+$/,'')+'rem';}
/* ── Fluid value helpers (mirror core/FluidValue.php) ── */
const FLUID_PREFIX='fluid:';
let _veViewport={vw_min:320,vw_max:1440};
function isFluidVal(v){return (v||'').toString().trim().toLowerCase().indexOf(FLUID_PREFIX)===0;}
function fluidMarker(min,max){const a=parseFloat(min),b=parseFloat(max);if(!isFinite(a)||!isFinite(b))return'';return FLUID_PREFIX+trimNum(a)+','+trimNum(b);}
function parseFluid(v){if(!isFluidVal(v))return null;const body=(v||'').toString().trim().slice(FLUID_PREFIX.length);const p=body.split(',').map(s=>s.trim());if(p.length!==2||!isFinite(parseFloat(p[0]))||!isFinite(parseFloat(p[1])))return null;return[parseFloat(p[0]),parseFloat(p[1])];}
function trimNum(n){let s=(Math.round(n*10000)/10000).toString();return s;}
function fluidClamp(minPx,maxPx,vwMin,vwMax,unit){let a=Math.round(minPx*1000)/1000,b=Math.round(maxPx*1000)/1000;if(a>b){const t=a;a=b;b=t;}let span=vwMax-vwMin;if(span<=0)span=1;const slope=(b-a)/span;const intercept=a-slope*vwMin;const slopeVw=Math.round(slope*100*10000)/10000;if(unit==='px'){return`clamp(${trimNum(a)}px, ${trimNum(Math.round(intercept*1000)/1000)}px + ${slopeVw}vw, ${trimNum(b)}px)`;}return`clamp(${trimNum(Math.round(a/10*10000)/10000)}rem, ${trimNum(Math.round(intercept/10*10000)/10000)}rem + ${slopeVw}vw, ${trimNum(Math.round(b/10*10000)/10000)}rem)`;}
function fluidPreview(min,max){const a=parseFloat(min),b=parseFloat(max);if(!isFinite(a)||!isFinite(b))return'';return fluidClamp(a,b,_veViewport.vw_min,_veViewport.vw_max,'rem');}
function hexOklch(hex){hex=hex.replace('#','');if(hex.length===3)hex=hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];const r=parseInt(hex.substr(0,2),16)/255,g=parseInt(hex.substr(2,2),16)/255,b=parseInt(hex.substr(4,2),16)/255;const f=v=>v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);const rl=f(r),gl=f(g),bl=f(b);const l_=.4122214708*rl+.5363325363*gl+.0514459929*bl,m_=.2119034982*rl+.6806995451*gl+.1073969566*bl,s_=.0883024619*rl+.2817188376*gl+.6299787005*bl;const lc=Math.cbrt(Math.max(0,l_)),mc=Math.cbrt(Math.max(0,m_)),sc=Math.cbrt(Math.max(0,s_));const L=.2104542553*lc+.793617785*mc-.0040720468*sc,a=1.9779984951*lc-2.428592205*mc+.4505937099*sc,bv=.0259040371*lc+.7827717662*mc-.808675766*sc;const cc=Math.sqrt(a*a+bv*bv);let H=Math.atan2(bv,a)*180/Math.PI;if(H<0)H+=360;return`oklch(${Math.max(0,Math.min(1,L)).toFixed(4)} ${cc.toFixed(4)} ${H.toFixed(2)})`;}
function fmtD(hex,fmt){if(fmt==='oklch')return hexOklch(hex);const rr=parseInt(hex.replace('#','').substr(0,2),16),gg=parseInt(hex.replace('#','').substr(2,2),16),bb=parseInt(hex.replace('#','').substr(4,2),16);if(fmt==='hex')return hex;if(fmt==='rgb')return`rgb(${rr},${gg},${bb})`;const rn=rr/255,gn=gg/255,bn=bb/255,mx=Math.max(rn,gn,bn),mn=Math.min(rn,gn,bn),l=(mx+mn)/2;let hu=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);if(mx===rn)hu=((gn-bn)/d+(gn<bn?6:0))/6;else if(mx===gn)hu=((bn-rn)/d+2)/6;else hu=((rn-gn)/d+4)/6;}return`hsl(${Math.round(hu*360)},${Math.round(s*100)}%,${Math.round(l*100)}%)`;}
const ph=n=>h('i',{class:`ph-duotone ph-${n}`,style:'font-size:13px;line-height:1'});
const TSHIRT_UP=['s','m','l','xl','2xl','3xl','4xl','5xl','6xl','7xl','8xl'];
const TSHIRT_DN=['xs','2xs','3xs','4xs','5xs','6xs','7xs','8xs'];
const SCALES=['minor-second','major-second','minor-third','major-third','perfect-fourth','augmented-fourth','perfect-fifth','golden'];
const CSS_PROPS=['align-content','align-items','align-self','animation','animation-delay','animation-duration','animation-name','appearance','aspect-ratio','backdrop-filter','background','background-attachment','background-blend-mode','background-clip','background-color','background-image','background-position','background-repeat','background-size','block-size','border','border-block','border-block-color','border-block-end','border-block-start','border-bottom','border-bottom-color','border-bottom-left-radius','border-bottom-right-radius','border-bottom-width','border-color','border-inline','border-inline-color','border-inline-end','border-inline-start','border-left','border-left-color','border-left-width','border-radius','border-right','border-right-color','border-right-width','border-style','border-top','border-top-color','border-top-left-radius','border-top-right-radius','border-top-width','border-width','bottom','box-shadow','box-sizing','clear','clip-path','color','column-gap','container','container-name','container-type','content','cursor','display','filter','flex','flex-basis','flex-direction','flex-flow','flex-grow','flex-shrink','flex-wrap','font','font-family','font-size','font-style','font-weight','gap','grid','grid-area','grid-auto-columns','grid-auto-flow','grid-auto-rows','grid-column','grid-template','grid-template-areas','grid-template-columns','grid-template-rows','height','inline-size','inset','inset-block','inset-block-end','inset-block-start','inset-inline','inset-inline-end','inset-inline-start','isolation','justify-content','justify-items','justify-self','left','letter-spacing','line-height','list-style','margin','margin-block','margin-block-end','margin-block-start','margin-bottom','margin-inline','margin-inline-end','margin-inline-start','margin-left','margin-right','margin-top','max-block-size','max-height','max-inline-size','max-width','min-block-size','min-height','min-inline-size','min-width','mix-blend-mode','object-fit','object-position','opacity','order','outline','overflow','overflow-block','overflow-inline','overflow-x','overflow-y','padding','padding-block','padding-block-end','padding-block-start','padding-bottom','padding-inline','padding-inline-end','padding-inline-start','padding-left','padding-right','padding-top','place-content','place-items','pointer-events','position','right','row-gap','scroll-margin','scroll-margin-block','scroll-margin-inline','scroll-padding','scroll-padding-block','scroll-padding-inline','text-align','text-decoration','text-transform','top','transform','transform-origin','transition','transition-delay','transition-duration','transition-property','translate','user-select','vertical-align','visibility','white-space','width','will-change','z-index'];
const CSS_VALUES=['auto','block','inline-block','flex','grid','none','relative','absolute','fixed','sticky','hidden','visible','center','space-between','space-around','space-evenly','start','end','stretch','cover','contain','pointer','default','transparent','currentColor','inherit','initial','unset'];
const CSS_LOGICAL_PROPS=['block-size','inline-size','min-block-size','max-block-size','min-inline-size','max-inline-size','margin-block','margin-block-start','margin-block-end','margin-inline-start','margin-inline-end','padding-block','padding-block-start','padding-block-end','padding-inline-start','padding-inline-end','border-block','border-block-color','border-block-start','border-block-start-color','border-block-start-style','border-block-start-width','border-block-end','border-block-end-color','border-block-end-style','border-block-end-width','border-inline','border-inline-color','border-inline-start','border-inline-start-color','border-inline-start-style','border-inline-start-width','border-inline-end','border-inline-end-color','border-inline-end-style','border-inline-end-width','inset-block','inset-block-start','inset-block-end','inset-inline','inset-inline-start','inset-inline-end'];
CSS_PROPS.push(...CSS_LOGICAL_PROPS.filter(x=>!CSS_PROPS.includes(x)));
const CSS_SELECTOR_HINTS=['a','article','aside','body','button','canvas','code','dialog','div','fieldset','figure','footer','form','h1','h2','h3','h4','h5','h6','header','html','iframe','img','input','label','li','main','nav','ol','option','p','picture','section','select','span','svg','table','textarea','ul',':active',':checked',':disabled',':empty',':enabled',':first-child',':first-of-type',':focus',':focus-visible',':hover',':is()',':last-child',':last-of-type',':not()',':nth-child()',':nth-of-type()',':root',':where()','::after','::before','::marker','::placeholder','@container','@font-face','@keyframes','@layer','@media','@supports'];
const CSS_SOURCE_DEFAULTS=["Mimam's Var",'Advanced Themer','Bricks','Core Framework','Automatic.css','CSS Classes','Element IDs'];
const CSS_RECIPES=[
  {name:'Section rhythm',code:'@rhythm',css:'.section {\n  padding-block: var(--space-xl);\n  gap: var(--space-m);\n}'},
  {name:'Fluid card grid',code:'@grid',css:'.card-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(min(100%, 28rem), 1fr));\n  gap: var(--space-m);\n}'},
  {name:'Focus ring',code:'@focus',css:':where(a, button, input, textarea, select):focus-visible {\n  outline: 2px solid var(--color-primary);\n  outline-offset: 3px;\n}'}
];
function loadUserCssRecipes(){try{const r=JSON.parse(localStorage.getItem('ve_css_recipes')||'[]');return Array.isArray(r)?r.filter(x=>x&&x.code&&x.css):[];}catch(e){return[];}}
function saveUserCssRecipes(list){localStorage.setItem('ve_css_recipes',JSON.stringify(list||[]));window.dispatchEvent(new CustomEvent('ve-css-recipes-changed'));}
function getCssRecipes(){const seen={};return [...CSS_RECIPES,...loadUserCssRecipes()].filter(r=>{const k=String(r.code||'').trim();if(!k||seen[k])return false;seen[k]=1;return true;});}
const CSS_HINT_LIMIT=72;
const DEFAULT_CSS_SHEETS=[
  {id:'global',name:'global.css',scope:'global',enabled:true,css:''}
];
const VE_MEDIA_CACHE={items:null,folders:null,at:0};
const NS_CLR={color:'#ef4444',space:'#3b82f6',spacing:'#3b82f6',font:'#a855f7',typography:'#a855f7',heading:'#c084fc',text:'#8b5cf6',weight:'#d946ef',radius:'#f59e0b',size:'#22c55e',scale:'#84cc16',stroke:'#14b8a6','stroke-width':'#14b8a6',shadow:'#6b7280',opacity:'#06b6d4',motion:'#ec4899',grid:'#22c55e',design:'#baf400'};
function variableNamespace(v){return v?.display_namespace||v?.namespace||'';}
function stripeColor(v){const p=tokenParts(v?.name);for(const k of [variableNamespace(v),p[0],p[1],p[2],v?.namespace]){if(k&&NS_CLR[k])return NS_CLR[k];}return'#8b949e';}

const SLIDE_MS=200;

const CSS=`
#ve-panel-root{
  --ve-accent:#baf400;
  --ve-accent-hover:#d4ff33;
  --ve-bg:#1f1f1f;
  --ve-surface:#282828;
  --ve-surface-focus:#303030;
  --ve-border:rgba(255,255,255,.10);
  --ve-text:#f1f1f1;
  --ve-muted:#777;
  --ve-danger:#ef4444;
  --ve-control-height:38px;
}
*{box-sizing:border-box;}
*::-webkit-scrollbar{width:6px;height:6px}
*::-webkit-scrollbar-track{background:rgba(255,255,255,.025);border-radius:999px}
*::-webkit-scrollbar-thumb{background:rgba(186,244,0,.38);border-radius:999px;border:1px solid rgba(0,0,0,.18)}
*::-webkit-scrollbar-thumb:hover{background:rgba(186,244,0,.58)}
.ve-o{position:fixed;top:0;right:0;width:370px;height:100vh;background:#1f1f1f;border-left:1px solid #2a2a2a;z-index:120000;display:flex;flex-direction:column;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;font-size:13px;color:#f1f1f1;transform:translateX(100%);transition:transform .18s cubic-bezier(.4,0,.2,1);box-shadow:none;pointer-events:none;}
.ve-o.open{transform:translateX(0);box-shadow:-4px 0 20px rgba(0,0,0,.5);pointer-events:auto;}
.ve-o.ve-dock-left{left:0;right:auto;border-left:0;border-right:1px solid #2a2a2a;transform:translateX(-100%);}
.ve-o.ve-dock-left.open{transform:translateX(0);}
.ve-o.ve-dock-right{right:0;left:auto;}
.ve-o.ve-float{height:min(760px,calc(100vh - 32px));max-height:calc(100vh - 32px);border:1px solid rgba(255,255,255,.10);border-radius:10px;transform:translateY(10px);overflow:visible;}
.ve-o.ve-float.open{transform:translateY(0);box-shadow:0 18px 46px rgba(0,0,0,.40);}
.ve-o.ve-dragging{transition:none!important;}
.ve-o.ve-standalone-panel:not([data-panel="content_studio"]):not([data-panel="media_studio"]):not([data-panel="plugin_studio"]):not([data-panel="css_recipes"]):not([data-panel="css_studio"]){transform:none!important;right:auto!important;bottom:auto!important;transition:opacity .18s ease!important;pointer-events:auto!important;}
.ve-bd{position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:119990;opacity:0;transition:opacity .2s;pointer-events:none;}
.ve-bd.show{opacity:1;pointer-events:auto;}
.ve-fab-wrap{position:fixed;bottom:16px;right:16px;z-index:119990;display:flex;flex-direction:column;align-items:flex-end;gap:8px;}
.ve-fab-wrap.ve-fab-hidden{display:none!important;}
.ve-fab-menu{display:flex;flex-direction:column;gap:8px;opacity:0;pointer-events:none;transform:translateY(10px);transition:all .2s;align-items:flex-end;}
.ve-fab-wrap:hover .ve-fab-menu{opacity:1;pointer-events:auto;transform:translateY(0);}
.ve-fab-item{width:32px;height:32px;background:#2a2a2a;border:1px solid #444;border-radius:8px;display:flex;align-items:center;justify-content:center;color:#ddd;cursor:pointer;font-size:16px;transition:transform .1s,background .1s;position:relative;}
.ve-fab-item:hover{background:#333;transform:scale(1.08);color:#baf400;border-color:#baf400;}
.ve-fab-tooltip{position:absolute;right:42px;background:#111;padding:4px 8px;border-radius:4px;font-size:10px;color:#fff;white-space:nowrap;opacity:0;pointer-events:none;transition:opacity .1s;}
.ve-fab-item:hover .ve-fab-tooltip{opacity:1;}
.ve-fab{width:36px;height:36px;background:#1f1f1f;border:1.5px solid #baf400;border-radius:8px;cursor:pointer;display:flex;align-items:center;justify-content:center;transition:transform .12s;}
.ve-fab:hover{transform:scale(1.06);}
.ve-fab i{color:#baf400;font-size:18px;}
.ve-hdr{display:flex;align-items:center;padding:10px 14px;border-bottom:1px solid #2a2a2a;gap:8px;flex-shrink:0;background:#1a1a1a;z-index:5;position:relative;}
.ve-hdr-i{width:18px;height:18px;background:transparent;border-radius:4px;flex-shrink:0;object-fit:contain;}
.ve-hdr-t{font-weight:700;font-size:11px;letter-spacing:.6px;text-transform:uppercase;color:#baf400;flex:1;}
.ve-hdr-a{display:flex;gap:1px;}
.ve-hdr-a button{background:none;border:none;color:#555;cursor:pointer;width:26px;height:26px;display:flex;align-items:center;justify-content:center;border-radius:4px;padding:0;}
.ve-hdr-a button:hover{background:#2a2a2a;color:#f1f1f1;}
.ve-sr{padding:6px 14px;border-bottom:1px solid #2a2a2a;flex-shrink:0;}
.ve-sr input{width:100%;height:var(--ve-control-height)!important;min-height:var(--ve-control-height)!important;max-height:var(--ve-control-height)!important;padding:0 10px;background:var(--ve-surface);border:1px solid #333;border-radius:5px;color:var(--ve-text);font-size:11px;line-height:var(--ve-control-height)!important;outline:none;}
.ve-sr input:focus{border-color:#baf400;}
.ve-sr input::placeholder{color:#444;}
.ve-o input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=file]):not([type=hidden]):not([type=color]),
.ve-o.ve-standalone-panel input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=file]):not([type=hidden]):not([type=color]){
  height:var(--ve-control-height)!important;
  min-height:var(--ve-control-height)!important;
  max-height:var(--ve-control-height)!important;
  line-height:var(--ve-control-height)!important;
}
.ve-color-control{display:flex;flex-direction:column;border-bottom:1px solid #2a2a2a;background:#191919;flex-shrink:0}
.ve-color-kind-switch{display:grid;grid-template-columns:1fr 1fr;gap:2px;padding:3px;background:#141414;border:1px solid #252525;border-radius:8px;margin:8px 14px 4px}
.ve-color-kind-switch button{height:26px;border:none;border-radius:6px;background:transparent;color:#777;font-size:9px;font-weight:700;text-transform:uppercase;letter-spacing:.35px;cursor:pointer;transition:all .15s ease}
.ve-color-kind-switch button:hover{color:#ccc}
.ve-color-kind-switch button.on{background:#2a2a2a;color:#baf400;box-shadow:inset 0 1px 0 rgba(255,255,255,.05), 0 2px 4px rgba(0,0,0,.3)}
.ve-color-control-row{display:grid;grid-template-columns:minmax(0,1fr) 24px;align-items:center;gap:8px;padding:8px 14px}
.ve-color-control-label{font-size:10px;color:#888;text-transform:uppercase;letter-spacing:.4px;font-weight:600;text-align:left}
.ve-tabs{display:flex;gap:2px;padding:4px 14px;border-bottom:1px solid #2a2a2a;flex-shrink:0;overflow-x:auto;}
.ve-tabs::-webkit-scrollbar{height:0;}
.ve-t{padding:4px 8px;font-size:9px;font-weight:600;color:#444;cursor:pointer;border-radius:4px;white-space:nowrap;text-transform:uppercase;letter-spacing:.4px;transition:all .1s;}
.ve-t:hover{color:#999;background:#262626;}
.ve-t.on{color:#1f1f1f;background:#baf400;}

/* Sub-panel slide-in/out */
.ve-sub{position:absolute;top:46px;left:0;right:0;bottom:0;background:#1f1f1f;z-index:4;display:flex;flex-direction:column;animation:veSlideIn .2s ease forwards;}
.ve-sub.closing{animation:veSlideOut .2s ease forwards;pointer-events:none;}
@keyframes veSlideIn{from{transform:translateX(100%);opacity:.8}to{transform:translateX(0);opacity:1}}
@keyframes veSlideOut{from{transform:translateX(0);opacity:1}to{transform:translateX(100%);opacity:.8}}
.ve-sub-hdr{display:flex;align-items:center;height:48px;min-height:48px;padding:0 16px;border-bottom:1px solid #2a2a2a;gap:8px;background:#1a1a1a;}
.ve-sub-hdr span{flex:1;font-size:11px;font-weight:700;color:#baf400;text-transform:uppercase;letter-spacing:.4px;line-height:1;display:flex;align-items:center;height:100%;}
.ve-sub-body{flex:1;overflow-y:auto;padding:10px 14px;}

.ve-body{flex:1;overflow-y:auto;overflow-x:hidden;position:relative;}
.ve-body::-webkit-scrollbar{width:3px;}
.ve-body::-webkit-scrollbar-thumb{background:#333;border-radius:2px;}

.ve-v{padding:5px 14px 5px 0;display:flex;align-items:center;gap:6px;cursor:pointer;transition:background .08s;position:relative;min-height:30px;border-left:0;}
.ve-v:before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--ve-ns,#555);border-radius:0;}
.ve-v:hover{background:#262626;}
.ve-v.sel{background:#262626;}
.ve-sw{width:15px;height:15px;border-radius:3px;border:1px solid #333;flex-shrink:0;}
.ve-inf{flex:1;min-width:0;}
.ve-nm{font-size:11px;font-weight:500;color:#ddd;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:'SF Mono','Fira Code',monospace;line-height:1.3;}
.ve-vl{font-size:9px;color:#555;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:'SF Mono','Fira Code',monospace;}
.ve-exp{background:none;border:none;color:#555;cursor:pointer;width:18px;height:18px;display:flex;align-items:center;justify-content:center;border-radius:3px;flex-shrink:0;padding:0;}
.ve-exp:hover{background:#2a2a2a;color:#baf400;}
.ve-tree-item{display:block!important;width:100%;min-width:0;}
.ve-sw-trigger{display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.ve-as{display:flex;position:absolute;right:8px;top:50%;transform:translateY(-50%);gap:3px;background:rgba(24,24,24,.96);border:1px solid rgba(255,255,255,.10);border-radius:8px;padding:4px;z-index:3;box-shadow:0 12px 28px rgba(0,0,0,.34);backdrop-filter:blur(14px);opacity:0;visibility:hidden;pointer-events:none;transition:opacity .12s ease,visibility .12s ease;}
.ve-as.open{opacity:1;visibility:visible;pointer-events:auto;}
.ve-a{background:transparent;border:none;color:#777;cursor:pointer;width:24px;height:24px;display:flex;align-items:center;justify-content:center;border-radius:6px;padding:0;transition:background .15s,color .15s,box-shadow .15s;}
.ve-a:hover{background:rgba(186,244,0,.11);color:#baf400;box-shadow:0 0 0 1px rgba(186,244,0,.18);}
.ve-a i{font-size:12px;}
.ve-ch{display:block!important;width:auto!important;clear:both;margin-left:18px;border-left:1px solid #2a2a2a;padding-left:2px;}
.ve-c{padding:3px 10px;display:flex;align-items:center;gap:6px;cursor:pointer;transition:background .08s;}
.ve-c:hover{background:#262626;}
.ve-c .ve-nm{font-size:10px;color:#888;}.ve-c .ve-vl{font-size:8px;}
.ve-sb{height:3px;background:#baf400;border-radius:2px;opacity:.4;margin-top:1px;}
.ve-import-drop{position:relative;border:1px dashed rgba(255,255,255,.16);border-radius:9px;background:rgba(255,255,255,.025);padding:10px;transition:border-color .15s ease,background .15s ease,box-shadow .15s ease;}
.ve-import-drop.active{border-color:#baf400;background:rgba(186,244,0,.075);box-shadow:inset 0 0 0 1px rgba(186,244,0,.16),0 10px 24px rgba(0,0,0,.18);}
.ve-import-drop-content{transition:opacity .12s ease;}
.ve-import-drop.active .ve-import-drop-content{opacity:.12;pointer-events:none;}
.ve-import-drop-overlay{display:none;position:absolute;inset:0;z-index:2;align-items:center;justify-content:center;flex-direction:column;gap:5px;color:#baf400;text-align:center;font-size:12px;font-weight:800;letter-spacing:.01em;pointer-events:none;}
.ve-import-drop-overlay small{font-size:9px;color:#dfffa3;font-weight:500;}
.ve-import-drop.active .ve-import-drop-overlay{display:flex;}
.ve-import-help{font-size:9px;color:#777;line-height:1.5;margin:0 0 8px;}
.ve-palette-current{display:flex;align-items:center;gap:10px;padding:4px 0;margin-bottom:10px;border:none;border-radius:0;background:transparent;}
.ve-palette-dot{width:12px;height:12px;border-radius:4px;background:linear-gradient(135deg,#baf400,#00d1ff 52%,#b15cff);box-shadow:0 0 0 1px rgba(255,255,255,.13);}
.ve-palette-row{display:flex;align-items:center;gap:8px;padding:9px 0;border-bottom:1px solid #2a2a2a;}
.ve-palette-row-info{flex:1;min-width:0;}
.ve-palette-row-name{font-size:11px;color:#ddd;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.ve-palette-row-meta{font-size:9px;color:#666;margin-top:2px;}
.ve-palette-actions{display:flex;gap:4px;align-items:center;}

/* Drag and Drop & Ordering */
.ve-var-drag-handle{padding:2px;color:#777;cursor:grab;display:flex;align-items:center;}
.ve-var-drag-handle:active{cursor:grabbing;}
.ve-v.dragging{opacity:.4;}
.ve-v.drag-over{border-top:2px solid #baf400!important;}
.ve-palette-row.dragging{opacity:.4;}
.ve-palette-row.drag-over{border-top:2px solid #baf400!important;}
.ve-palette-drag-handle{padding:2px;color:#777;cursor:grab;display:flex;align-items:center;}
.ve-palette-drag-handle:active{cursor:grabbing;}

/* Forms */
.ve-opt{display:flex;align-items:center;justify-content:space-between;padding:4px 0;font-size:11px;}
.ve-opt>span{color:#888;}
.ve-opt label{display:flex;align-items:center;gap:6px;cursor:pointer;color:#bbb;line-height:1.45;}
.ve-opt input[type=checkbox]{accent-color:#baf400;width:13px;height:13px;}
.ve-opt input[type=number],.ve-opt input[type=text]{padding:4px 6px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:10px;outline:none;}
.ve-opt input[type=number]{width:56px;text-align:center;}
.ve-opt input[type=number]::-webkit-outer-spin-button,.ve-opt input[type=number]::-webkit-inner-spin-button{appearance:none;-webkit-appearance:none;margin:0;}
.ve-opt input[type=number]{appearance:textfield;-moz-appearance:textfield;}
.ve-opt input:focus{border-color:#baf400;}
.ve-sub-body input[type=text],.ve-sub-body input[type=number],.ve-sub-body input[type=url],.ve-sub-body input[type=password]{height:var(--ve-control-height)!important;min-height:var(--ve-control-height)!important;max-height:var(--ve-control-height)!important;padding:0 11px;background:var(--ve-surface);border:1px solid var(--ve-border);border-radius:6px;color:var(--ve-text);font-size:11px;line-height:var(--ve-control-height)!important;outline:none;box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 1px 0 rgba(0,0,0,.24);transition:border-color .16s,background .16s,box-shadow .16s;}
.ve-sub-body textarea{min-height:80px;padding:9px 11px;background:var(--ve-surface);border:1px solid var(--ve-border);border-radius:6px;color:var(--ve-text);font-size:11px;line-height:1.45;outline:none;box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 1px 0 rgba(0,0,0,.24);transition:border-color .16s,background .16s,box-shadow .16s;resize:vertical;font-family:'SF Mono','Fira Code',monospace;}
.ve-sub-body input[type=text]:focus,.ve-sub-body input[type=number]:focus,.ve-sub-body input[type=url]:focus,.ve-sub-body input[type=password]:focus,.ve-sub-body textarea:focus{border-color:#baf400;background:#303030;box-shadow:0 0 0 3px rgba(186,244,0,.10),inset 0 1px 0 rgba(255,255,255,.04);}
.ve-sub-body input::placeholder,.ve-sub-body textarea::placeholder{color:#666;}
.ve-sub-body input[type=checkbox],.ve-sub-body input[type=radio]{appearance:none;-webkit-appearance:none;width:16px;height:16px;border:1px solid rgba(255,255,255,.18);border-radius:4px;background:#242424;display:inline-grid;place-content:center;flex:0 0 16px;margin:0;cursor:pointer;}
.ve-sub-body input[type=checkbox]:checked,.ve-sub-body input[type=radio]:checked{background:#baf400;border-color:#baf400;box-shadow:0 0 0 3px rgba(186,244,0,.08);}
.ve-sub-body input[type=checkbox]:checked:before{content:'';width:8px;height:5px;border-left:2px solid #1f1f1f;border-bottom:2px solid #1f1f1f;transform:translateY(-1px) rotate(-45deg);}

/* Unified select */
.ve-sel{width:100%;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:10px;outline:none;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='5'%3E%3Cpath d='M0 0l4 5 4-5z' fill='%23666'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 6px center;padding-right:20px;cursor:pointer;transition:border-color .1s;}
.ve-sel:focus{border-color:#baf400;}
.ve-sel:hover{border-color:#555;}
.ve-sel option{background:#2a2a2a;color:#f1f1f1;}
.ve-opt .ve-sel{width:auto;min-width:110px;}
.ve-menu{position:relative;width:100%;min-width:0;}
.ve-menu-btn{width:100%;height:var(--ve-control-height);min-height:var(--ve-control-height);max-height:var(--ve-control-height);padding:0 34px 0 11px;background:#282828;border:1px solid rgba(255,255,255,.10);border-radius:4px;color:#f1f1f1;font-size:12px;line-height:var(--ve-control-height);text-align:left;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 1px 0 rgba(0,0,0,.25);transition:border-color .16s,box-shadow .16s,background .16s;}
.ve-menu-btn:after{content:'';position:absolute;right:12px;top:50%;width:7px;height:7px;border-right:1.5px solid #baf400;border-bottom:1.5px solid #baf400;transform:translateY(-65%) rotate(45deg);pointer-events:none;}
.ve-menu.open .ve-menu-btn{border-color:#baf400;box-shadow:0 0 0 3px rgba(186,244,0,.10),inset 0 1px 0 rgba(255,255,255,.04);background:#303030;border-radius:4px 4px 0 0;}
.ve-menu-list{position:absolute;left:0;right:0;top:calc(100% - 1px);z-index:30;background:#242424;border:1px solid #baf400;border-top-color:rgba(255,255,255,.10);border-radius:0 0 4px 4px;box-shadow:0 18px 38px rgba(0,0,0,.42);max-height:210px;overflow-y:auto;padding:4px;}
.ve-menu-list::-webkit-scrollbar{width:3px}.ve-menu-list::-webkit-scrollbar-thumb{background:#3a3a3a;border-radius:2px}
.ve-menu-item{width:100%;display:block;padding:7px 8px;background:transparent;border:0;border-radius:2px;color:#e7e7e7;text-align:left;font-size:12px;line-height:1.35;cursor:pointer;}
.ve-menu-item:hover,.ve-menu-item.on{background:#343434;color:#baf400;}
.ve-opt-menu{width:168px;flex:0 0 168px;}

.ve-row{display:flex;gap:5px;margin-bottom:6px;align-items:center;}
.ve-row input{flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:10px;outline:none;}
.ve-row input:focus{border-color:#baf400;}
.ve-cp{display:grid;grid-template-columns:42px minmax(0,1fr);gap:8px;align-items:stretch;width:100%;min-width:0;max-width:100%;overflow:hidden;}
.ve-color-swatch{width:42px;height:42px;border:1px solid rgba(255,255,255,.16);border-radius:6px;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.20),0 6px 18px rgba(0,0,0,.22)}
.ve-color-panel{grid-column:1/-1;min-width:0;max-width:100%;overflow:hidden;border:1px solid rgba(255,255,255,.10);background:#242424;border-radius:8px;padding:10px;display:grid;gap:9px;animation:veColorIn .16s cubic-bezier(.2,.8,.2,1);transform-origin:top center}
.ve-color-panel.closing{animation:veColorOut .14s cubic-bezier(.4,0,.2,1) forwards;pointer-events:none}
@keyframes veColorIn{from{opacity:0;transform:translateY(-6px) scaleY(.96)}to{opacity:1;transform:translateY(0) scaleY(1)}}
@keyframes veColorOut{from{opacity:1;transform:translateY(0) scaleY(1)}to{opacity:0;transform:translateY(-6px) scaleY(.96)}}
.ve-color-map{position:relative;width:100%;min-width:0;height:132px;border-radius:6px;overflow:hidden;cursor:crosshair;background:red;box-shadow:inset 0 0 0 1px rgba(255,255,255,.12)}
.ve-color-map:before{content:'';position:absolute;inset:0;background:linear-gradient(90deg,#fff,rgba(255,255,255,0))}
.ve-color-map:after{content:'';position:absolute;inset:0;background:linear-gradient(0deg,#000,rgba(0,0,0,0))}
.ve-color-dot{position:absolute;width:12px;height:12px;border:2px solid #fff;border-radius:50%;box-shadow:0 0 0 1px #000,0 2px 6px rgba(0,0,0,.45);transform:translate(-50%,-50%);z-index:2;pointer-events:none}
.ve-hue{width:100%;appearance:none;-webkit-appearance:none;height:14px;border-radius:999px;background:linear-gradient(90deg,#f00,#ff0,#0f0,#0ff,#00f,#f0f,#f00);outline:none;border:1px solid rgba(255,255,255,.14);box-shadow:inset 0 1px 1px rgba(0,0,0,.35)}
.ve-hue::-webkit-slider-thumb{appearance:none;-webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:#f1f1f1;border:2px solid #1f1f1f;box-shadow:0 2px 8px rgba(0,0,0,.35);cursor:pointer}
.ve-hue::-moz-range-thumb{width:18px;height:18px;border-radius:50%;background:#f1f1f1;border:2px solid #1f1f1f;box-shadow:0 2px 8px rgba(0,0,0,.35);cursor:pointer}
.ve-color-fields{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;min-width:0}
.ve-color-fields input{width:100%;min-width:0;height:38px!important;min-height:38px!important;max-height:38px!important;padding:0 10px!important;text-align:center;font-family:'SF Mono','Fira Code',monospace;line-height:38px!important}
.ve-cp-v{min-width:0;padding:7px 10px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#ddd;font-size:10px;font-family:monospace;display:flex;align-items:center;overflow:hidden;line-height:1.45;word-break:break-all;}
.ve-format-tabs{grid-column:1 / -1;display:grid;grid-template-columns:repeat(4,1fr);gap:0;border:1px solid #333;background:#202020;border-radius:4px;overflow:hidden;}
.ve-format-tabs button{min-height:30px;padding:0 10px;border:0;border-right:1px solid #333;background:#252525;color:#888;font-size:9px;font-weight:700;letter-spacing:0;text-transform:uppercase;cursor:pointer;border-radius:0;}
.ve-format-tabs button:last-child{border-right:0;}
.ve-format-tabs button:hover{background:#2f2f2f;color:#ddd;}
.ve-format-tabs button.on{background:#baf400;color:#1f1f1f;}
.ve-mode{display:flex;gap:2px;margin-bottom:8px;}
.ve-mode button{flex:1;padding:5px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#666;font-size:9px;font-weight:600;text-transform:uppercase;cursor:pointer;letter-spacing:.3px;transition:all .1s;}
.ve-mode button.on{background:#baf400;color:#1f1f1f;border-color:#baf400;}
.ve-btn{min-height:38px;padding:8px 14px;background:#baf400;color:#1f1f1f;border:none;border-radius:6px;font-size:10px;font-weight:700;cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center;line-height:1.2;gap:6px;}
.ve-btn:hover{background:#d4ff33;}.ve-btn:disabled{opacity:.3;cursor:not-allowed;}
.ve-btn-s{min-height:30px;padding:5px 10px;font-size:9px;}
.ve-btn-g{background:#303236;border:1px solid rgba(255,255,255,.14);color:#e4e4e4;font-weight:600;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);}
.ve-btn-g:hover{border-color:rgba(255,255,255,.22);color:#f1f1f1;background:#3a3d42;box-shadow:inset 0 1px 0 rgba(255,255,255,.05);}
.ve-btn-d{background:#991b1b;color:#fff;}.ve-btn-d:hover{background:#7f1d1d;color:#fff;border-color:#ef4444;}
.ve-det{padding:10px 14px;border-top:1px solid #2a2a2a;background:#1a1a1a;flex-shrink:0;max-height:180px;overflow-y:auto;}
.ve-det-t{font-weight:700;font-size:12px;margin-bottom:6px;font-family:monospace;color:#baf400;display:flex;justify-content:space-between;align-items:center;}
.ve-det-r{display:flex;justify-content:space-between;padding:2px 0;font-size:10px;}
.ve-det-l{color:#555;}.ve-det-v{color:#ddd;font-family:monospace;}
.ve-dep-s{margin-top:6px;}
.ve-dep-t{font-size:9px;color:#555;text-transform:uppercase;letter-spacing:.4px;margin-bottom:2px;}
.ve-dep{font-size:10px;color:#baf400;padding:1px 0;cursor:pointer;font-family:monospace;}
.ve-dep:hover{text-decoration:underline;}
.ve-empty{padding:24px 14px;text-align:center;color:#444;font-size:11px;}
.ve-st{padding:4px 14px;font-size:9px;color:#444;border-top:1px solid #2a2a2a;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-shrink:0;background:#1a1a1a;margin-top:auto;}
.ve-st-left{display:flex;align-items:center;gap:8px;min-width:0;}
.ve-st .ve-btn{padding:2px 6px;font-size:8px;line-height:1.2;white-space:nowrap;}
.ve-toast{position:fixed;bottom:60px;right:16px;background:#baf400;color:#1f1f1f;padding:7px 12px;border-radius:9px;font-size:11px;font-weight:600;z-index:120020;opacity:0;transition:opacity .2s;pointer-events:none;display:flex;align-items:center;gap:8px;}
.ve-toast.show{opacity:1;}
@property --ve-toast-angle{syntax:"<angle>";inherits:false;initial-value:360deg}
.ve-toast-ring{--ve-toast-angle:360deg;position:relative;width:16px;height:16px;border-radius:50%;background:conic-gradient(#1f1f1f var(--ve-toast-angle),rgba(31,31,31,.18) 0deg);animation:veToastRing 2.2s linear forwards;flex:0 0 16px}
.ve-toast-ring:after{content:'';position:absolute;inset:4px;border-radius:50%;background:#baf400}
@keyframes veToastRing{to{--ve-toast-angle:0deg}}
.ve-cf{position:absolute;inset:0;background:rgba(0,0,0,.65);z-index:10;display:flex;align-items:center;justify-content:center;}
.ve-cf-b{background:#1f1f1f;border:1px solid #333;border-radius:8px;padding:16px;text-align:center;max-width:240px;}
.ve-cf-b p{margin:0 0 10px;font-size:12px;color:#bbb;}
.ve-warn{font-size:10px;color:#f59e0b;padding:4px 0;}
.ve-ren{display:flex;gap:4px;align-items:center;padding:8px 0;}
.ve-ren input{flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:11px;font-family:monospace;outline:none;}
.ve-ren input:focus{border-color:#baf400;}
.ve-tshirt-ctrl{display:flex;align-items:center;justify-content:center;gap:4px;padding:4px 0;}
.ve-tshirt-ctrl button{width:24px;height:24px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#baf400;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:700;padding:0;}
.ve-tshirt-ctrl button:hover{background:#333;border-color:#baf400;}
.ve-tshirt-ctrl button:disabled{opacity:.2;cursor:not-allowed;}
.ve-tshirt-ctrl span{font-size:9px;color:#555;min-width:60px;text-align:center;}

/* Variable reference autocomplete */
.ve-ac{position:absolute;left:0;right:0;top:100%;background:#2a2a2a;border:1px solid #333;border-radius:0 0 4px 4px;max-height:120px;overflow-y:auto;z-index:10;box-shadow:0 4px 12px rgba(0,0,0,.4);}
.ve-ac::-webkit-scrollbar{width:3px;}
.ve-ac::-webkit-scrollbar-thumb{background:#444;border-radius:2px;}
.ve-ac-i{padding:4px 8px;font-size:10px;font-family:'SF Mono','Fira Code',monospace;color:#bbb;cursor:pointer;display:flex;align-items:center;gap:6px;transition:background .08s;}
.ve-ac-i:hover,.ve-ac-i.sel{background:#333;color:#baf400;}
.ve-ac-sw{width:10px;height:10px;border-radius:2px;border:1px solid #444;flex-shrink:0;}
.ve-ac-wrap{position:relative;flex:1;}

/* Premium finish */
.ve-o{width:410px;background:#1f1f1f;border:1px solid rgba(255,255,255,.10);border-radius:10px;box-shadow:none;overflow:visible;}
.ve-o.ve-dock-right{top:8px;right:8px;bottom:8px;height:calc(100vh - 16px);left:auto;transform:translateX(calc(100% + 16px));}
.ve-o.ve-dock-left{top:8px;left:8px;bottom:8px;height:calc(100vh - 16px);right:auto;border-left:1px solid rgba(255,255,255,.10);border-right:1px solid rgba(255,255,255,.10);transform:translateX(calc(-100% - 16px));}
.ve-o.ve-dock-right.open,.ve-o.ve-dock-left.open{transform:translateX(0);}
.ve-o.open{box-shadow:-18px 0 42px rgba(0,0,0,.36);}
.ve-o.ve-float.open{box-shadow:0 18px 46px rgba(0,0,0,.40);}
.ve-o.ve-standalone-panel:not([data-panel="content_studio"]):not([data-panel="media_studio"]):not([data-panel="plugin_studio"]):not([data-panel="css_recipes"]):not([data-panel="css_studio"]){transform:none!important;right:auto!important;bottom:auto!important;transition:opacity .18s ease!important;pointer-events:auto!important;}
.ve-hdr,.ve-sub-hdr,.ve-st,.ve-det{background:#1a1a1a;border-color:rgba(255,255,255,.08);}
.ve-hdr{padding:12px 16px 10px;gap:8px;flex-wrap:wrap}.ve-brand{display:flex;align-items:center;justify-content:space-between;gap:10px;flex:1;min-width:0}.ve-hdr-i{width:24px;height:24px;border-radius:6px;background:transparent;object-fit:contain;box-shadow:none;order:2}
.ve-hdr-t{font-size:12px;letter-spacing:0;text-transform:none;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-hdr-a{gap:4px}.ve-hdr-a button,.ve-exp,.ve-a{border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.035);border-radius:8px;transition:background .15s,border-color .15s,color .15s,box-shadow .15s}.ve-hdr-a button:hover,.ve-exp:hover,.ve-a:hover{background:rgba(186,244,0,.10);border-color:rgba(186,244,0,.40);color:#baf400;box-shadow:0 0 0 3px rgba(186,244,0,.055)}
.ve-hdr-a{order:2;width:calc(100% + 32px);margin:2px -16px 0;padding:8px 16px 0 16px;border-top:1px solid rgba(255,255,255,.06);justify-content:flex-start}
.ve-sr{padding:12px 16px;border-color:rgba(255,255,255,.08)}.ve-sr input,.ve-row input,.ve-ren input,.ve-opt input[type=number],.ve-opt input[type=text],.ve-sel,.ve-cp-v{height:var(--ve-control-height)!important;min-height:var(--ve-control-height)!important;max-height:var(--ve-control-height)!important;padding:0 11px;background:var(--ve-surface);border:1px solid var(--ve-border);border-radius:4px;color:var(--ve-text);line-height:var(--ve-control-height)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 1px 0 rgba(0,0,0,.25);transition:border-color .16s,box-shadow .16s,background .16s}.ve-sr input:focus,.ve-row input:focus,.ve-ren input:focus,.ve-opt input:focus,.ve-sel:focus{border-color:var(--ve-accent);box-shadow:0 0 0 3px rgba(186,244,0,.10),inset 0 1px 0 rgba(255,255,255,.04);background:var(--ve-surface-focus)}
.ve-row input.ve-hue,.ve-sub-body input.ve-hue,.ve-hue{min-height:14px!important;height:14px!important;padding:0!important;background:linear-gradient(90deg,#f00 0%,#ff0 16.66%,#0f0 33.33%,#0ff 50%,#00f 66.66%,#f0f 83.33%,#f00 100%)!important;border:1px solid rgba(255,255,255,.14)!important;border-radius:999px!important;box-shadow:inset 0 1px 1px rgba(0,0,0,.35)!important}
.ve-hue::-webkit-slider-runnable-track{height:14px;border-radius:999px;background:linear-gradient(90deg,#f00 0%,#ff0 16.66%,#0f0 33.33%,#0ff 50%,#00f 66.66%,#f0f 83.33%,#f00 100%)}
.ve-hue::-moz-range-track{height:14px;border-radius:999px;background:linear-gradient(90deg,#f00 0%,#ff0 16.66%,#0f0 33.33%,#0ff 50%,#00f 66.66%,#f0f 83.33%,#f00 100%)}
.ve-opt{align-items:center;padding:8px 0;font-size:12px;gap:10px}.ve-opt>span{color:#aaa}.ve-opt label{gap:9px;color:#d4d4d4;line-height:1.5}.ve-opt input[type=checkbox],.ve-opt input[type=radio]{appearance:none;-webkit-appearance:none;width:16px;height:16px;border:1px solid rgba(255,255,255,.18);border-radius:4px;background:#242424;display:inline-grid;place-content:center;flex:0 0 16px;margin:0;cursor:pointer}.ve-opt input[type=checkbox]:checked,.ve-opt input[type=radio]:checked{background:#baf400;border-color:#baf400;box-shadow:0 0 0 3px rgba(186,244,0,.08)}.ve-opt input[type=checkbox]:checked:before{content:'';width:8px;height:5px;border-left:2px solid #1f1f1f;border-bottom:2px solid #1f1f1f;transform:translateY(-1px) rotate(-45deg)}.ve-opt input[type=number]::-webkit-outer-spin-button,.ve-opt input[type=number]::-webkit-inner-spin-button{appearance:none;-webkit-appearance:none;margin:0}.ve-opt input[type=number]{appearance:textfield;-moz-appearance:textfield;text-align:center;padding-right:11px}.ve-opt-stack{align-items:stretch;flex-direction:column}.ve-opt-stack input{width:100%;font-family:'SF Mono','Fira Code',monospace}
.ve-tabs{padding:8px 16px;gap:5px;border-color:rgba(255,255,255,.08)}.ve-t{padding:6px 10px;border-radius:8px;letter-spacing:0}.ve-t.on{box-shadow:0 8px 22px rgba(186,244,0,.12),inset 0 1px 0 rgba(255,255,255,.38)}
.ve-sub{top:86px;background:#1f1f1f}.ve-sub.ve-sidecar{top:0;bottom:0;left:auto;right:calc(100% + 10px);width:410px;border:1px solid rgba(255,255,255,.10);border-radius:10px;overflow:hidden;box-shadow:0 18px 46px rgba(0,0,0,.40);animation:veSideIn .16s ease forwards}.ve-o.ve-dock-left .ve-sub.ve-sidecar{left:calc(100% + 10px);right:auto}.ve-sub.ve-sidecar.closing{animation:veSideOut .16s ease forwards}.ve-sub-body{padding:16px}.ve-sidecar .ve-sub-body{display:flex;flex-direction:column;min-height:0;padding:12px}.ve-row{gap:8px;margin-bottom:10px}.ve-mode{gap:6px;margin-bottom:12px}.ve-mode button{padding:8px;border-radius:8px;background:rgba(255,255,255,.045);border-color:rgba(255,255,255,.10);letter-spacing:0}.ve-mode button.on{box-shadow:0 10px 24px rgba(186,244,0,.12),inset 0 1px 0 rgba(255,255,255,.42)}
@keyframes veSideIn{from{transform:translateX(14px);opacity:.82}to{transform:translateX(0);opacity:1}}
@keyframes veSideOut{from{transform:translateX(0);opacity:1}to{transform:translateX(14px);opacity:.82}}
.ve-sub-hdr{height:48px;min-height:48px;padding:0 16px;align-items:center}.ve-sub-hdr .ve-exp{width:26px;height:26px;flex:0 0 26px}.ve-sub-hdr span{line-height:1;align-items:center}
.ve-v{margin:3px 10px 3px 0;border-radius:8px;min-height:38px;padding-top:8px!important;padding-bottom:8px!important;overflow:hidden}.ve-v:before{top:0;bottom:0;border-radius:0}.ve-v:hover,.ve-v.sel{background:rgba(255,255,255,.055);box-shadow:inset 0 0 0 1px rgba(255,255,255,.055)}.ve-ch{margin-left:30px;border-color:rgba(255,255,255,.08)}.ve-c{border-radius:7px;margin:2px 8px 2px 0;padding:6px 10px}.ve-sw{width:18px;height:18px;border-radius:6px;border-color:rgba(255,255,255,.14)}.ve-nm{font-size:12px}.ve-vl{font-size:10px;color:#777}
.ve-btn{position:relative;overflow:hidden;min-height:38px;padding:8px 14px;border-radius:6px;background:#baf400;color:#1f1f1f;border:1px solid rgba(186,244,0,.82);box-shadow:0 1px 0 rgba(255,255,255,.12) inset,0 8px 18px rgba(186,244,0,.10);letter-spacing:0;transition:box-shadow .18s ease,background .18s ease,border-color .18s ease,color .18s ease}.ve-btn:hover{background:#d4ff33;border-color:#d4ff33;color:#1f1f1f;box-shadow:0 0 0 3px rgba(186,244,0,.10),0 10px 24px rgba(186,244,0,.13)}.ve-btn-g{background:#303236;color:#e4e4e4;border-color:rgba(255,255,255,.14);box-shadow:inset 0 1px 0 rgba(255,255,255,.04),0 1px 2px rgba(0,0,0,.22)}.ve-btn-g:hover{background:#3a3d42;border-color:rgba(255,255,255,.22);color:#f1f1f1;box-shadow:inset 0 1px 0 rgba(255,255,255,.05),0 4px 12px rgba(0,0,0,.14)}.ve-btn-d{background:#991b1b;color:#fff;border-color:rgba(255,255,255,.14)}.ve-btn-d:hover{background:#7f1d1d;color:#fff;border-color:#ef4444}
.ve-upd{display:flex;align-items:center;gap:8px;margin-top:8px;font-size:10px;color:#777}.ve-upd .ok{color:#baf400}.ve-upd .muted{color:#888}
.ve-update{margin:10px 16px 0;padding:11px 12px;border:1px solid rgba(186,244,0,.26);background:rgba(186,244,0,.075);border-radius:8px;color:#dfffa3;font-size:10px;line-height:1.55;display:flex;align-items:center;gap:10px}.ve-update i{color:#baf400;font-size:16px}.ve-update span{flex:1}.ve-update b{color:#f1f1f1}
.ve-clean{margin:10px 16px 0;padding:10px 11px;border:1px solid rgba(245,158,11,.28);background:rgba(245,158,11,.08);border-radius:6px;color:#f6c369;font-size:10px;line-height:1.55;display:flex;align-items:center;gap:9px}.ve-clean span{flex:1}.ve-clean .ve-btn{min-height:28px;padding:5px 9px;font-size:9px}
.ve-toast{border-radius:9px;box-shadow:0 16px 38px rgba(0,0,0,.35),0 10px 28px rgba(186,244,0,.12)}.ve-cf-b{border-color:rgba(255,255,255,.10);box-shadow:0 24px 62px rgba(0,0,0,.46)}
.ve-o,.ve-opt,.ve-warn,.ve-empty,.ve-cf-b p,.ve-det-r,.ve-st,.ve-upd{line-height:1.55}
.ve-mode button{line-height:1.35}
.ve-o input[type=checkbox],.ve-o input[type=radio]{appearance:none!important;-webkit-appearance:none!important;width:16px!important;height:16px!important;min-height:16px!important;padding:0!important;border:1px solid rgba(255,255,255,.18)!important;border-radius:4px!important;background:#242424!important;display:inline-grid!important;place-content:center!important;flex:0 0 16px!important;margin:0!important;cursor:pointer!important;box-shadow:none!important;vertical-align:middle!important}
.ve-o input[type=checkbox]:checked,.ve-o input[type=radio]:checked{background:#baf400!important;border-color:#baf400!important;box-shadow:0 0 0 3px rgba(186,244,0,.08)!important}
.ve-o input[type=checkbox]:checked:before{content:'';width:8px;height:4px;border-left:2px solid #1f1f1f;border-bottom:2px solid #1f1f1f;transform:translateY(-1px) rotate(-45deg);transform-origin:center}
.ve-o label{display:inline-flex;align-items:center}
.ve-layout-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;width:100%}
.ve-hdr.dragging{cursor:grabbing}
.ve-drag-handle{width:24px;height:24px;display:flex;align-items:center;justify-content:center;border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.035);border-radius:8px;color:#777;cursor:grab;flex:0 0 24px}
.ve-drag-handle:hover{background:rgba(186,244,0,.10);border-color:rgba(186,244,0,.40);color:#baf400}
.ve-drag-handle:active{cursor:grabbing}
.ve-snap-zone{position:fixed;top:10px;bottom:10px;width:76px;border:1px dashed rgba(186,244,0,.55);background:rgba(186,244,0,.08);z-index:120010;pointer-events:none;opacity:0;transition:opacity .08s}
.ve-snap-zone.show{opacity:1}
.ve-snap-zone.left{left:10px}.ve-snap-zone.right{right:10px}
.ve-code-shell{border:1px solid rgba(255,255,255,.10);border-radius:7px;overflow:hidden;background:#202020;display:grid;grid-template-columns:38px 1fr;min-height:320px}
.ve-code-wrap{position:relative;min-height:0}
.ve-code-lines{padding:10px 8px;background:#1a1a1a;color:#555;font-family:'SF Mono','Fira Code',monospace;font-size:10px;line-height:1.6;text-align:right;user-select:none;border-right:1px solid rgba(255,255,255,.08)}
.ve-code-editor{position:relative;min-width:0;min-height:320px;background:#202020}
.ve-code-highlight{position:absolute;inset:0;margin:0;padding:10px 12px;overflow:hidden;white-space:pre-wrap;word-break:normal;color:#d6d6d6;font-family:'SF Mono','Fira Code',monospace;font-size:11px;line-height:1.6;pointer-events:none}
.ve-code-input{position:absolute;inset:0;width:100%;height:100%;min-height:320px!important;padding:10px 12px!important;border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important;font-family:'SF Mono','Fira Code',monospace!important;font-size:11px!important;line-height:1.6!important;resize:none;color:transparent!important;-webkit-text-fill-color:transparent!important;caret-color:#f1f1f1!important;white-space:pre-wrap!important;overflow:auto!important}
.ve-code-input::selection{background:rgba(186,244,0,.22);color:transparent}
.ve-code-input::placeholder{color:#6b6b6b!important;-webkit-text-fill-color:#6b6b6b!important}
.tok-comment{color:#666}.tok-string{color:#ffd166}.tok-color{color:#ff6b7a}.tok-var{color:#baf400}.tok-prop{color:#8cc8ff}.tok-num{color:#c5a3ff}.tok-punc{color:#8a8a8a}
.ve-suggest{position:absolute;min-width:170px;max-width:320px;max-height:184px;overflow-y:auto;border:1px solid rgba(186,244,0,.28);background:#252a20;border-radius:7px;box-shadow:0 18px 42px rgba(0,0,0,.55);z-index:120030;pointer-events:auto}
.ve-suggest::-webkit-scrollbar{width:3px}.ve-suggest::-webkit-scrollbar-thumb{background:#4a5c24;border-radius:2px}
.ve-suggest button{width:100%;display:block;text-align:left;background:transparent;border:0;color:#dfffa3;padding:7px 9px;font-size:10px;font-family:'SF Mono','Fira Code',monospace;cursor:pointer}
.ve-suggest button:hover,.ve-suggest button.on{background:rgba(186,244,0,.12);color:#f1f1f1}
.ve-source-list{display:flex;flex-direction:column;gap:6px}
.ve-source-pill{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 9px;border:1px solid rgba(255,255,255,.09);border-radius:7px;background:rgba(255,255,255,.035);font-size:10px;color:#ddd}
.ve-source-pill.dragging{opacity:.55;border-color:rgba(186,244,0,.45)}
.ve-source-pill.drop-before{box-shadow:0 -2px 0 #baf400}
.ve-source-pill.drop-after{box-shadow:0 2px 0 #baf400}
.ve-source-grip{display:flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:6px;color:#777;cursor:grab}
.ve-source-grip:hover{background:rgba(186,244,0,.10);color:#baf400}
.ve-source-meta{font-size:8px;color:#777;text-transform:uppercase;letter-spacing:.25px}
.ve-source-toggle{width:24px;height:22px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.035);color:#777;border-radius:6px;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}
.ve-source-toggle.on{color:#baf400;border-color:rgba(186,244,0,.28);background:rgba(186,244,0,.08)}
.ve-source-toggle:hover{color:#f1f1f1;border-color:rgba(255,255,255,.18)}
.ve-css-note{font-size:9px;color:#777;line-height:1.55;margin-top:4px}
.ve-css-diag{margin:8px 0;padding:8px 10px;border:1px solid rgba(245,158,11,.24);background:rgba(245,158,11,.06);border-radius:6px;color:#f6c369;font-size:9px;line-height:1.55}
.ve-scope-label{font-size:9px;color:#999;font-weight:700;text-transform:uppercase;margin:0 0 5px}
.ve-studio-top{display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap}.ve-studio-grid{display:grid;grid-template-columns:115px minmax(0,1fr);gap:10px;min-height:0;flex:1}.ve-studio-main{min-width:0;display:flex;flex-direction:column;min-height:0}.ve-editor-only{display:flex;flex-direction:column;flex:1;min-height:0}.ve-editor-only .ve-code-wrap{flex:1;display:flex;flex-direction:column}.ve-editor-only .ve-code-shell{flex:1;min-height:0;height:100%}.ve-editor-only .ve-code-editor{height:100%;min-height:0}.ve-editor-only .ve-code-input{min-height:0!important;height:100%;resize:none}.ve-editor-actions{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:10px;padding-top:10px;border-top:1px solid rgba(255,255,255,.08)}.ve-editor-actions small{color:#777;font-size:10px;line-height:1.45}
.ve-modal{position:absolute;inset:0;z-index:20;background:rgba(0,0,0,.68);display:flex;align-items:center;justify-content:center;padding:18px}.ve-modal-box{width:min(300px,100%);border:1px solid rgba(255,255,255,.12);background:#1f1f1f;border-radius:10px;padding:14px;box-shadow:0 24px 62px rgba(0,0,0,.46);animation:veColorIn .14s cubic-bezier(.2,.8,.2,1)}.ve-modal-title{font-size:12px;font-weight:800;color:#f1f1f1;margin-bottom:6px}.ve-modal-body{font-size:10px;color:#bbb;line-height:1.55;margin-bottom:12px}.ve-modal-actions{display:flex;gap:8px;justify-content:flex-end}
.ve-sheet-tab{display:flex!important;align-items:center;justify-content:space-between!important;gap:6px}.ve-sheet-tab span{min-width:0;overflow:hidden;text-overflow:ellipsis}.ve-sheet-del{width:22px;height:22px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.035);color:#777;border-radius:6px;display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0;flex:0 0 22px}.ve-sheet-del:hover{color:#ef4444;border-color:rgba(239,68,68,.38);background:rgba(239,68,68,.10)}
.ve-recipes{display:grid;gap:6px;margin:8px 0;padding:8px;border:1px solid rgba(255,255,255,.08);border-radius:7px;background:rgba(255,255,255,.025)}
.ve-recipe-row{display:grid;grid-template-columns:58px 1fr;gap:8px;align-items:center;font-size:10px;line-height:1.45;color:#bbb}
.ve-recipe-code{font-family:'SF Mono','Fira Code',monospace;color:#baf400;background:rgba(186,244,0,.08);border:1px solid rgba(186,244,0,.16);border-radius:4px;padding:3px 5px;text-align:center}
.ve-recipe-studio{display:flex;flex-direction:column;flex:1;min-height:0;background:#151515}
.ve-recipe-studio-main{display:grid;grid-template-columns:minmax(260px,1fr) minmax(360px,460px);gap:18px;padding:20px;flex:1;min-height:0;overflow:hidden}
.ve-recipe-list{display:flex;flex-direction:column;gap:10px;min-height:0;overflow:auto;padding-right:4px}
.ve-recipe-card{border:1px solid rgba(255,255,255,.08);border-radius:8px;background:#1a1a1a;padding:12px;display:grid;grid-template-columns:96px minmax(0,1fr) auto;gap:12px;align-items:center;cursor:pointer;transition:border-color .16s ease,background .16s ease,box-shadow .16s ease}
.ve-recipe-card:hover{border-color:rgba(186,244,0,.34);background:#202020;box-shadow:0 12px 28px rgba(0,0,0,.22)}
.ve-recipe-card strong{color:#fff;font-size:12px;line-height:1.35}.ve-recipe-card small{display:block;color:#777;font-size:9px;line-height:1.45;margin-top:2px}
.ve-recipe-form{border:1px solid rgba(255,255,255,.08);border-radius:8px;background:#1a1a1a;padding:14px;display:flex;flex-direction:column;gap:14px;min-height:0;height:100%;align-items:stretch;overflow:hidden}.ve-recipe-field{display:flex;flex-direction:column;gap:8px;align-items:stretch}.ve-recipe-field .ve-scope-label{text-align:left;display:block;margin:0;color:#9a9a9a}.ve-recipe-field .ve-studio-input{min-height:38px;height:38px;width:100%;box-sizing:border-box}.ve-recipe-shortcode{display:grid;grid-template-columns:38px minmax(0,1fr);gap:10px;width:100%}.ve-recipe-shortcode .ve-studio-input:first-child{border-radius:8px;display:flex;align-items:center;justify-content:center;color:#baf400;font-weight:800}.ve-recipe-shortcode input.ve-studio-input{border-radius:8px}.ve-recipe-editor{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;width:100%;align-self:stretch}.ve-recipe-editor .ve-code-wrap{flex:1;display:flex;flex-direction:column;width:100%;min-width:0;min-height:0}.ve-recipe-editor .ve-code-shell{flex:1;min-height:260px;width:100%}.ve-recipe-editor .ve-code-editor,.ve-recipe-editor .ve-code-input,.ve-recipe-editor .ve-code-highlight{height:100%!important;min-height:0!important;resize:none!important}.ve-recipe-form-actions{display:flex;justify-content:space-between;gap:8px;align-items:center;margin-top:0;padding-top:10px;border-top:1px solid rgba(255,255,255,.08)}.ve-content-edit-form{height:100%;max-width:none;overflow:hidden;display:flex;flex-direction:column;gap:14px;background:rgba(255,255,255,.01);border:1px solid rgba(255,255,255,.05);border-radius:10px;padding:20px}.ve-content-edit-scroll{flex:1;min-height:0;overflow:auto;display:flex;flex-direction:column;gap:14px;padding-right:4px}.ve-content-edit-actions{margin-top:auto;padding-top:12px;border-top:1px solid rgba(255,255,255,.08);display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap}.ve-content-field-edit-form{height:100%;max-width:none!important;overflow:hidden;display:flex!important;flex-direction:column!important;gap:14px;background:rgba(255,255,255,.01);border:1px solid rgba(255,255,255,.05);border-radius:10px;padding:20px}.ve-content-field-edit-form .ve-content-field-edit-main{flex:1;min-height:0;overflow:auto;display:grid;grid-template-columns:minmax(260px,520px);align-content:start;gap:14px}.ve-content-field-edit-form .ve-content-field-edit-actions{margin-top:auto;padding-top:12px;border-top:1px solid rgba(255,255,255,.08);display:flex;gap:8px;justify-content:flex-end}.ve-content-advanced,.ve-content-custom-fields{border:1px solid rgba(255,255,255,.08);border-radius:8px;background:rgba(255,255,255,.02);padding:10px}.ve-content-advanced summary,.ve-content-custom-fields summary{cursor:pointer;color:#baf400;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.04em}.ve-content-field-help{font-size:9px;color:#777;line-height:1.45;margin-top:5px}.ve-content-custom-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:12px}.ve-field-serialized{font-family:'SF Mono','Fira Code',monospace!important;line-height:1.55!important;min-height:118px!important;white-space:pre-wrap}
.ve-rich-editor{border:1px solid rgba(255,255,255,.10);border-radius:9px;background:#202020;overflow:hidden;box-shadow:inset 0 1px 0 rgba(255,255,255,.025)}
.ve-rich-toolbar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;padding:8px;background:#181818;border-bottom:1px solid rgba(255,255,255,.08)}
.ve-rich-toolbar button{min-height:30px;padding:6px 9px;border:1px solid rgba(255,255,255,.10);border-radius:6px;background:#2b2d31;color:#e8e8e8;font-size:10px;font-weight:800;cursor:pointer}
.ve-rich-toolbar button:hover{border-color:rgba(186,244,0,.4);background:rgba(186,244,0,.10);color:#baf400}
.ve-rich-surface{min-height:min(430px,45vh);padding:18px;background:#202020;color:#f2f2f2;font-size:13px;line-height:1.75;outline:none;overflow:auto;resize:vertical}
.ve-rich-surface:focus{box-shadow:inset 0 0 0 2px rgba(186,244,0,.42)}
.ve-rich-surface:empty:before{content:attr(data-placeholder);color:#666}
.ve-rich-surface h1{font-size:26px;line-height:1.2;margin:0 0 14px}.ve-rich-surface h2{font-size:21px;line-height:1.25;margin:0 0 12px}.ve-rich-surface h3{font-size:17px;line-height:1.35;margin:0 0 10px}.ve-rich-surface p{margin:0 0 12px}.ve-rich-surface ul,.ve-rich-surface ol{margin:0 0 12px 22px;padding:0}.ve-rich-surface blockquote{margin:0 0 12px;padding:8px 12px;border-left:3px solid #baf400;background:rgba(186,244,0,.06)}
.ve-standalone-panel[data-panel="css_studio"]{width:min(430px,calc(100vw - 32px))!important;max-width:430px!important;min-width:min(360px,calc(100vw - 32px))!important;overflow:hidden!important}
.ve-standalone-panel[data-panel="css_studio"] .ve-body{overflow:hidden!important}
.ve-css-studio-combined{padding:14px;flex:1;overflow:hidden;display:flex;flex-direction:column;min-height:0}
.ve-css-studio-combined-grid{display:flex;flex-direction:column;gap:12px;flex:1;min-height:0;overflow:hidden}
.ve-css-settings-column{min-width:0;display:flex;flex-direction:column;gap:8px;overflow:visible;padding-right:2px;flex:0 0 auto}
.ve-css-sheet-list{display:flex;flex-direction:column;gap:6px;max-height:132px;overflow:auto;padding-right:2px}
.ve-css-editor-column{min-width:0;display:flex;flex-direction:column;min-height:220px;flex:1 1 auto;border:1px solid rgba(255,255,255,.07);border-radius:10px;background:rgba(255,255,255,.015);padding:10px}
.ve-css-editor-column .ve-editor-only{height:100%;min-height:0}
.ve-css-editor-column .ve-code-shell{min-height:0}
.ve-sub.ve-sidecar{height:100%;max-height:calc(100vh - 16px)}
.ve-sub.ve-sidecar .ve-sub-body{flex:1 1 auto;overflow:hidden;min-height:0;height:calc(100% - 48px)}
.ve-editor-only,.ve-editor-only .ve-code-wrap,.ve-editor-only .ve-code-shell,.ve-editor-only .ve-code-editor{width:100%;min-height:0}
.ve-editor-only .ve-code-wrap{height:100%}
.ve-editor-only .ve-code-shell{height:100%;min-height:0}
.ve-editor-only .ve-code-editor,.ve-editor-only .ve-code-input,.ve-editor-only .ve-code-highlight{height:100%!important;min-height:0!important;resize:none!important}
.ve-code-lines{margin:0}
.ve-cm-host{height:100%;min-height:320px;border:1px solid rgba(255,255,255,.10);border-radius:7px;overflow:hidden;background:#202020}
.ve-editor-only .ve-cm-host{height:100%;min-height:0}
.ve-css-studio-combined .ve-studio-top{margin-bottom:4px}.ve-css-studio-combined .ve-row{margin-bottom:6px}.ve-css-studio-combined .ve-studio-main{gap:4px}
.ve-cm-host .CodeMirror{height:100%;background:#202020;color:#d6d6d6;font-family:'SF Mono','Fira Code',monospace;font-size:11px;line-height:1.6}
.ve-cm-host .CodeMirror-gutters{background:#1a1a1a;border-right:1px solid rgba(255,255,255,.08)}
.ve-cm-host .CodeMirror-linenumber{color:#555}
.ve-cm-host .CodeMirror-cursor{border-left-color:#f1f1f1}
.ve-cm-host .CodeMirror-selected{background:rgba(186,244,0,.18)!important}
.ve-cm-host .cm-comment{color:#666}.ve-cm-host .cm-string{color:#ffd166}.ve-cm-host .cm-atom,.ve-cm-host .cm-number{color:#c5a3ff}.ve-cm-host .cm-property{color:#8cc8ff}.ve-cm-host .cm-variable-2,.ve-cm-host .cm-variable-3{color:#baf400}.ve-cm-host .cm-keyword{color:#ff6b7a}.ve-cm-host .cm-def{color:#baf400}
.CodeMirror-hints{z-index:120040!important;background:#252a20!important;border:1px solid rgba(186,244,0,.28)!important;border-radius:7px!important;box-shadow:0 18px 42px rgba(0,0,0,.55)!important;font-family:'SF Mono','Fira Code',monospace!important;font-size:10px!important;max-height:260px!important;min-width:220px!important;overflow:auto!important}
.CodeMirror-hints .CodeMirror-hint{color:#dfffa3!important;padding:6px 9px!important;border-radius:4px!important}
.CodeMirror-hints .CodeMirror-hint-active{background:rgba(186,244,0,.16)!important;color:#f1f1f1!important}
.ve-fab-wrap.ve-fab-left-side{align-items:flex-start!important}
.ve-fab-wrap.ve-fab-left-side .ve-fab-tooltip{left:42px!important;right:auto!important}

/* Studio layouts */
.ve-studio-layout { display: flex; height: 100%; min-height: 0; flex: 1; background: #151515; position: relative; }
.ve-studio-sidebar { width: 240px; background: #111; border-right: 1px solid rgba(255,255,255,0.06); display: flex; flex-direction: column; padding: 16px; gap: 16px; flex-shrink: 0; }
.ve-studio-main { flex: 1; display: flex; flex-direction: column; padding: 20px; min-width: 0; min-height: 0; overflow: hidden; position: relative; }
.ve-studio-nav { display: flex; flex-direction: column; gap: 4px; }
.ve-studio-nav-item { display: flex; align-items: center; justify-content: space-between; padding: 8px 12px; border-radius: 6px; color: #ccc; cursor: pointer; text-decoration: none; font-size: 12px; transition: background .15s, color .15s; }
.ve-studio-nav-item:hover { background: rgba(255,255,255,0.04); color: #fff; }
.ve-studio-nav-item.active { background: rgba(186,244,0,0.12); color: #baf400; font-weight: 600; }
.ve-studio-nav-item.drop-before{box-shadow:0 -2px 0 #baf400;background:rgba(186,244,0,.06)}
.ve-studio-nav-item.drop-nest{box-shadow:inset 0 0 0 1px rgba(186,244,0,.45);background:rgba(186,244,0,.10)}
.ve-studio-nav-title { font-size: 9px; font-weight: 700; text-transform: uppercase; color: #555; letter-spacing: 0.8px; margin-top: 12px; margin-bottom: 6px; }
.ve-studio-badge { background: rgba(255,255,255,0.06); color: #888; font-size: 10px; padding: 2px 6px; border-radius: 99px; }
.ve-studio-nav-item.active .ve-studio-badge { background: rgba(186,244,0,0.2); color: #baf400; }
.ve-studio-readonly{opacity:.72!important;cursor:not-allowed!important;background:rgba(255,255,255,.035)!important;color:#a8adb4!important}
.ve-studio-stats { margin-top: auto; padding: 12px; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-radius: 8px; font-size: 11px; display: flex; gap: 8px; flex-direction: column; }
.ve-studio-stats-item { display: flex; align-items: center; justify-content: space-between; }
.ve-plugin-table td{vertical-align:middle}
.ve-plugin-description{color:#b9c0c8;font-size:11px;line-height:1.55;max-width:720px}
.ve-plugin-author{color:#858b92;font-size:10px;line-height:1.45}
.ve-plugin-directory-bar{display:grid;grid-template-columns:minmax(180px,1fr) auto auto auto;gap:8px;align-items:center;margin:0 0 12px}
.ve-plugin-directory-results{display:grid;grid-template-columns:1fr;align-content:start;gap:10px;margin-bottom:0;flex:1;min-height:0;overflow:auto;padding-right:4px}
.ve-plugin-directory-results.grid{grid-template-columns:repeat(auto-fill,minmax(300px,1fr));align-items:stretch}
.ve-plugin-card{display:grid;grid-template-columns:48px minmax(0,1fr) auto;align-items:center;justify-content:normal;gap:14px;padding:13px 14px;border:1px solid rgba(255,255,255,.08);border-radius:8px;background:#191919;min-width:0}
.ve-plugin-directory-results.grid .ve-plugin-card{grid-template-columns:48px minmax(0,1fr);grid-template-rows:auto 1fr;align-items:start;min-height:176px}
.ve-plugin-directory-results.grid .ve-plugin-card .ve-btn{grid-column:2;align-self:end;justify-self:start}
.ve-plugin-card-icon{width:42px;height:42px;border-radius:9px;border:1px solid rgba(255,255,255,.10);background:#242424;object-fit:cover;display:flex;align-items:center;justify-content:center;color:#baf400;flex:0 0 42px}
.ve-context-menu{position:fixed;z-index:120040;min-width:178px;padding:6px;border:1px solid rgba(255,255,255,.11);border-radius:8px;background:#1b1b1b;box-shadow:0 18px 42px rgba(0,0,0,.55);display:flex;flex-direction:column;gap:3px}
.ve-context-menu-attached:before{content:'';position:absolute;left:var(--ve-context-arrow-left,-5px);top:var(--ve-context-arrow-y,12px);width:9px;height:9px;background:#1b1b1b;border-left:1px solid rgba(255,255,255,.11);border-bottom:1px solid rgba(255,255,255,.11);transform:rotate(var(--ve-context-arrow-rotate,45deg))}
.ve-context-menu button{height:30px;border:0;border-radius:6px;background:transparent;color:#ddd;text-align:left;font-size:11px;font-weight:600;display:flex;align-items:center;gap:8px;padding:0 9px;cursor:pointer}
.ve-context-menu button:hover{background:rgba(186,244,0,.10);color:#baf400}
.ve-context-menu button.danger:hover{background:rgba(239,68,68,.12);color:#ff6b6b}
.ve-collection-drag{width:20px;height:24px;border:0;background:transparent;color:#666;border-radius:6px;display:flex;align-items:center;justify-content:center;cursor:grab;padding:0;margin-left:-4px;flex:0 0 20px}
.ve-collection-drag:hover{background:rgba(186,244,0,.10);color:#baf400}
.ve-collection-drag:active{cursor:grabbing}
.ve-collection-drag-disabled{cursor:not-allowed;color:#555;opacity:.65}
.ve-collection-drag-disabled:hover{background:transparent;color:#777}
.ve-collection-drag-disabled svg,.ve-collection-drag-disabled i{font-size:12px}
.ve-collection-branch{width:13px;height:13px;color:#777;display:inline-flex;align-items:center;justify-content:center;flex:0 0 13px}
.ve-collection-badge{font-size:8px;font-weight:800;text-transform:uppercase;letter-spacing:.3px;border-radius:999px;padding:2px 5px;line-height:1;color:#aaa;background:rgba(255,255,255,.05);border:1px solid rgba(255,255,255,.08)}
.ve-collection-badge.local{color:#baf400;background:rgba(186,244,0,.08);border-color:rgba(186,244,0,.16)}
.ve-collection-badge.folder{color:#9aa4b2}
.ve-plugin-card-main{display:flex;flex-direction:column;gap:4px;min-width:0}
.ve-plugin-card-main strong{color:#f7f7f7;font-size:13px;line-height:1.35}
.ve-plugin-card-main span{color:#c8c8c8;font-size:11.5px;line-height:1.55}
.ve-plugin-card-main small{color:#9a9a9a;font-size:10px;line-height:1.45}
.ve-plugin-table td{color:#d8d8d8}
.ve-plugin-description{color:#c8c8c8!important;font-size:11.5px!important;line-height:1.55!important;max-width:760px}
.ve-plugin-author{color:#9b9b9b!important;font-size:10.5px!important;line-height:1.45!important}
.ve-plugin-table strong{font-size:12.5px;line-height:1.35}
.ve-content-studio .ve-studio-sidebar{resize:horizontal;overflow:auto;min-width:220px;max-width:420px}
.ve-standalone-panel[data-panel="content_studio"]{resize:both;min-width:920px;min-height:540px}
.ve-status-toggle{background:transparent;border:0;padding:0;margin:0;cursor:pointer}
.ve-studio-table-container { flex: 1; overflow-y: auto; min-height: 0; margin-top: 10px; }
.ve-studio-table-container::-webkit-scrollbar { width: 3px; }
.ve-studio-table-container::-webkit-scrollbar-thumb { background: #333; border-radius: 2px; }
.ve-studio-table { width: 100%; border-collapse: collapse; text-align: left; font-size: 12px; }
.ve-studio-table th { padding: 10px; font-size: 9px; font-weight: 700; text-transform: uppercase; color: #555; letter-spacing: 0.8px; border-bottom: 1px solid rgba(255,255,255,0.08); }
.ve-studio-table td { padding: 12px 10px; border-bottom: 1px solid rgba(255,255,255,0.04); color: #ddd; vertical-align: middle; }
.ve-studio-table tr:hover { background: rgba(255,255,255,0.02); }
.ve-studio-details-sidebar { width: 320px; background: rgba(0,0,0,0.18); border-left: 1px solid rgba(255,255,255,0.06); padding: 16px; display: flex; flex-direction: column; gap: 16px; flex-shrink: 0; overflow-y: auto; }
.ve-studio-input { width: 100%; padding: 8px 12px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 6px; color: #fff; font-size: 12px; outline: none; transition: border-color .15s, background .15s; }
input.ve-studio-input,select.ve-studio-input{height:var(--ve-control-height)!important;min-height:var(--ve-control-height)!important;max-height:var(--ve-control-height)!important;padding:0 12px;line-height:var(--ve-control-height)!important}
.ve-studio-input:focus { outline:none!important; border-color: #baf400; background: rgba(255,255,255,0.05); box-shadow:0 0 0 3px rgba(186,244,0,.10); }
.ve-studio-textarea { min-height: 80px; resize: vertical; }
select.ve-studio-input option { background: #151515; color: #fff; }
.ve-o :is(input,textarea,button,select,a):focus{outline:none!important}
.ve-o :is(input,textarea,button,select,a):focus-visible{outline:none!important;box-shadow:0 0 0 3px rgba(186,244,0,.13)!important;border-color:#baf400!important}
.ve-studio-batch-overlay { position: absolute; bottom: 20px; left: 50%; transform: translateX(-50%); background: rgba(24, 29, 36, 0.95); border: 1px solid rgba(255, 255, 255, 0.1); border-radius: 8px; padding: 10px 20px; display: flex; align-items: center; gap: 16px; box-shadow: 0 16px 36px rgba(0,0,0,0.45); z-index: 10; backdrop-filter: blur(10px); }
`;

function wireGsapHover(root){
  if(!root)return;
}

function Sw({v}){return h('div',{class:'ve-sw',style:isClr(v)?`background:${v}`:'background:repeating-conic-gradient(#333 0% 25%,#2a2a2a 0% 50%) 50%/8px 8px'});}

/* ── Sub-panel wrapper with slide-out animation ── */
function Sub({title,onClose,onBack,children,exiting,sidecar}){
  const[closing,sC]=useState(false);
  const isOut=closing||exiting;
  const doClose=useCallback(()=>{sC(true);setTimeout(onClose,SLIDE_MS);},[onClose]);
  const handleBack=onBack||doClose;
  const icon=sidecar&&!onBack?'x':'arrow-left';
  return h('div',{class:'ve-sub'+(sidecar?' ve-sidecar':'')+(isOut?' closing':'')},
    h('div',{class:'ve-sub-hdr'},h('button',{class:'ve-exp',onClick:handleBack,title:onBack?'Back':'Close'},ph(icon)),h('span',null,title)),
    h('div',{class:'ve-sub-body'},typeof children==='function'?children(doClose):children));
}

function SelectMenu({value,onChange,options,className}){
  const[open,sOpen]=useState(false);
  const ref=useRef();
  useEffect(()=>{
    if(!open)return;
    const close=e=>{if(ref.current&&!ref.current.contains(e.target))sOpen(false);};
    document.addEventListener('mousedown',close);
    return()=>document.removeEventListener('mousedown',close);
  },[open]);
  const opts=(options||[]).map(o=>typeof o==='string'?{value:o,label:o}:o);
  const cur=opts.find(o=>String(o.value)===String(value))||opts[0]||{value:'',label:''};
  return h('div',{ref,class:'ve-menu '+(open?'open ':'')+(className||'')},
    h('button',{type:'button',class:'ve-menu-btn',onClick:()=>sOpen(v=>!v),onKeyDown:e=>{
      if(e.key==='Escape')sOpen(false);
      if(e.key==='Enter'||e.key===' '){e.preventDefault();sOpen(v=>!v);}
    }},cur.label),
    open&&h('div',{class:'ve-menu-list'},
      opts.map(o=>h('button',{type:'button',class:'ve-menu-item'+(String(o.value)===String(value)?' on':''),key:o.value,onMouseDown:e=>{e.preventDefault();onChange&&onChange(o.value);sOpen(false);}},o.label))));
}

function ConfirmModal({title,body,confirmText,onCancel,onConfirm,danger}){
  return h('div',{class:'ve-modal'},
    h('div',{class:'ve-modal-box'},
      h('div',{class:'ve-modal-title'},title||'Confirm action'),
      h('div',{class:'ve-modal-body'},body||'Are you sure?'),
      h('div',{class:'ve-modal-actions'},
        h('button',{class:'ve-btn ve-btn-g ve-btn-s',type:'button',onClick:onCancel},'Cancel'),
        h('button',{class:'ve-btn '+(danger?'ve-btn-d':'')+' ve-btn-s',type:'button',onClick:onConfirm},confirmText||'Confirm'))));
}

function CheckControl({checked,onChange,label,title,className,disabled}){
  return h('label',{class:'ve-check-row '+(className||'')+(disabled?' disabled':''),title:title||''},
    h('input',{type:'checkbox',checked:!!checked,disabled:!!disabled,onChange:e=>onChange&&onChange(e.target.checked,e)}),
    h('span',{class:'ve-check-box'},ph('check')),
    label!==undefined&&h('span',{class:'ve-check-label'},label));
}

function hexToRgb(hex){
  hex=clrToHex(hex).replace('#','');
  return{r:parseInt(hex.slice(0,2),16),g:parseInt(hex.slice(2,4),16),b:parseInt(hex.slice(4,6),16)};
}
function rgbToHex(r,g,b){return'#'+[r,g,b].map(v=>('0'+Math.max(0,Math.min(255,Math.round(v))).toString(16)).slice(-2)).join('');}
function hexToHsv(hex){
  const{r,g,b}=hexToRgb(hex);const rn=r/255,gn=g/255,bn=b/255,mx=Math.max(rn,gn,bn),mn=Math.min(rn,gn,bn),d=mx-mn;
  let h=0;if(d){if(mx===rn)h=((gn-bn)/d+(gn<bn?6:0))*60;else if(mx===gn)h=((bn-rn)/d+2)*60;else h=((rn-gn)/d+4)*60;}
  return{h:Math.round(h),s:mx?d/mx:0,v:mx};
}
function hsvToHex(h,s,v){
  const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c;let r=0,g=0,b=0;
  if(h<60){r=c;g=x;}else if(h<120){r=x;g=c;}else if(h<180){g=c;b=x;}else if(h<240){g=x;b=c;}else if(h<300){r=x;b=c;}else{r=c;b=x;}
  return rgbToHex((r+m)*255,(g+m)*255,(b+m)*255);
}
function hexToHslObj(hex){
  const{r,g,b}=hexToRgb(hex);const rn=r/255,gn=g/255,bn=b/255,mx=Math.max(rn,gn,bn),mn=Math.min(rn,gn,bn),l=(mx+mn)/2;let h=0,s=0;
  if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);if(mx===rn)h=((gn-bn)/d+(gn<bn?6:0))/6;else if(mx===gn)h=((bn-rn)/d+2)/6;else h=((rn-gn)/d+4)/6;}
  return{h:Math.round(h*360),s:Math.round(s*100),l:Math.round(l*100)};
}
function hslToHexObj(h,s,l){
  h=((+h||0)%360+360)%360/360;s=Math.max(0,Math.min(100,+s||0))/100;l=Math.max(0,Math.min(100,+l||0))/100;
  const q=l<.5?l*(1+s):l+s-l*s,p=2*l-q,h2r=(pp,qq,t)=>{if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return pp+(qq-pp)*6*t;if(t<.5)return qq;if(t<2/3)return pp+(qq-pp)*(2/3-t)*6;return pp;};
  const r=s===0?l:h2r(p,q,h+1/3),g=s===0?l:h2r(p,q,h),b=s===0?l:h2r(p,q,h-1/3);return rgbToHex(r*255,g*255,b*255);
}
function hexToOklchObj(hex){
  const m=hexOklch(hex).match(/oklch\(([\d.]+)\s+([\d.]+)\s+([\d.]+)\)/);return{l:m?+m[1]:0,c:m?+m[2]:0,h:m?+m[3]:0};
}
function MVColorPicker({hex,onChange,fmt,setFmt}){
  const[open,sOpen]=useState(false);
  const[shown,sShown]=useState(false);
  const[closing,sClosing]=useState(false);
  const hsv=hexToHsv(hex);
  const mapRef=useRef();
  const toggleOpen=()=>{
    if(shown&&!closing){sClosing(true);setTimeout(()=>{sShown(false);sOpen(false);sClosing(false);},140);return;}
    sOpen(true);sShown(true);sClosing(false);
  };
  const setFromEvent=e=>{
    const r=mapRef.current?.getBoundingClientRect();if(!r)return;
    const s=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width));
    const v=1-Math.max(0,Math.min(1,(e.clientY-r.top)/r.height));
    onChange(hsvToHex(hsv.h,s,v));
  };
  const down=e=>{
    setFromEvent(e);
    const move=ev=>setFromEvent(ev);
    const up=()=>{window.removeEventListener('mousemove',move);window.removeEventListener('mouseup',up);};
    window.addEventListener('mousemove',move);window.addEventListener('mouseup',up);
  };
  const rgb=hexToRgb(hex);
  const setRgb=(k,v)=>{const next={...rgb,[k]:Math.max(0,Math.min(255,parseInt(v||0,10)||0))};onChange(rgbToHex(next.r,next.g,next.b));};
  const hsl=hexToHslObj(hex);
  const ok=hexToOklchObj(hex);
  const setHsl=(k,v)=>{const next={...hsl,[k]:parseFloat(v||0)||0};onChange(hslToHexObj(next.h,next.s,next.l));};
  const setOk=(k,v)=>{const next={...ok,[k]:parseFloat(v||0)||0};onChange(clrToHex(`oklch(${next.l} ${next.c} ${next.h})`));};
  const controls=fmt==='hsl'
    ?[{v:hsl.h,set:v=>setHsl('h',v),label:'H'},{v:hsl.s,set:v=>setHsl('s',v),label:'S'},{v:hsl.l,set:v=>setHsl('l',v),label:'L'}]
    :fmt==='oklch'
      ?[{v:ok.l.toFixed(4),set:v=>setOk('l',v),label:'L'},{v:ok.c.toFixed(4),set:v=>setOk('c',v),label:'C'},{v:ok.h.toFixed(2),set:v=>setOk('h',v),label:'H'}]
      :[{v:rgb.r,set:v=>setRgb('r',v),label:'R'},{v:rgb.g,set:v=>setRgb('g',v),label:'G'},{v:rgb.b,set:v=>setRgb('b',v),label:'B'}];
  return h('div',{class:'ve-cp',style:'flex:1'},
    h('button',{type:'button',class:'ve-color-swatch',style:'background:'+hex,title:shown?'Close color picker':'Open color picker',onClick:toggleOpen}),
    h('div',{class:'ve-cp-v'},fmtD(hex,fmt)),
    shown&&h('div',{class:'ve-color-panel'+(closing?' closing':'')},
      h('div',{ref:mapRef,class:'ve-color-map',style:'background:hsl('+hsv.h+',100%,50%)',onMouseDown:down},
        h('span',{class:'ve-color-dot',style:{left:(hsv.s*100)+'%',top:((1-hsv.v)*100)+'%'}})),
      h('input',{class:'ve-hue',type:'range',min:0,max:359,value:hsv.h,onInput:e=>onChange(hsvToHex(+e.target.value,hsv.s,hsv.v))}),
      h('div',{class:'ve-color-fields'},
        h('input',{value:hex,onInput:e=>/^#?[0-9a-f]{0,6}$/i.test(e.target.value)&&onChange(clrToHex(e.target.value.charAt(0)==='#'?e.target.value:'#'+e.target.value)),onBlur:e=>onChange(clrToHex(e.target.value))}),
        controls.map(c=>h('input',{value:c.v,title:c.label,onInput:e=>c.set(e.target.value)}))),
      h('div',{class:'ve-format-tabs'},['hex','rgb','hsl','oklch'].map(f=>h('button',{class:fmt===f?'on':'',type:'button',onClick:()=>setFmt(f)},f.toUpperCase())))));
}

/* ── Settings sub-panel ───────────────── */
/* ── Standalone draggable panel wrapper ── */
function UpdateNotice({info,skipped,onSkip}){
  if(!info?.update_available||info.latest_version===skipped)return null;
  return h('div',{class:'ve-update'},
    ph('arrow-circle-up'),
    h('span',null,h('b',null,'Update available: '),'v'+info.latest_version),
    info.update_admin_url&&h('button',{class:'ve-btn ve-btn-s',onClick:()=>{window.location.href=info.update_admin_url;}},'Update'),
    h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>onSkip(info.latest_version)},'Skip'));
}

function syncMimamsBarUpdateNotice(info,skipped,onSkip){
  const slot=document.querySelector('.baqa-panel .baqa-update-slot');
  if(!slot)return false;
  slot.innerHTML='';
  if(!info?.update_available||info.latest_version===skipped)return true;
  const notice=document.createElement('div');
  notice.className='ve-update ve-update-shared';
  notice.innerHTML='<i class="ph-duotone ph-arrow-circle-up" aria-hidden="true"></i><span><b>Update available: </b>v'+String(info.latest_version)+'</span>';
  if(info.update_admin_url){
    const update=document.createElement('button');
    update.type='button';
    update.className='ve-btn ve-btn-s';
    update.textContent='Update';
    update.addEventListener('click',()=>{window.location.href=info.update_admin_url;});
    notice.appendChild(update);
  }
  const skip=document.createElement('button');
  skip.type='button';
  skip.className='ve-btn ve-btn-g ve-btn-s';
  skip.textContent='Skip';
  skip.addEventListener('click',()=>onSkip(info.latest_version));
  notice.appendChild(skip);
  slot.appendChild(notice);
  return true;
}

function StandalonePanel({ title, onClose, children, width = 340, height = 'min(760px, calc(100vh - 32px))', defaultLeft, defaultTop, persistKey, panelId, open, panelMode, updateNotice, hasUpdate }) {
  const isWideStudio = panelId === 'content_studio' || panelId === 'media_studio' || panelId === 'plugin_studio' || panelId === 'css_recipes';
  const isStudio = isWideStudio || panelId === 'css_studio';
  const isRecipeStudio = panelId === 'css_recipes';
  const isCssStudio = panelId === 'css_studio';
  
  const [pos, setPos] = useState(() => {
    if (persistKey && !isCssStudio) {
      try {
        const saved = localStorage.getItem('ve_pos_' + persistKey);
        if (saved) return JSON.parse(saved);
      } catch (e) {}
    }
    return {
      left: defaultLeft !== undefined ? defaultLeft : Math.max(16, window.innerWidth - width - 16),
      top: defaultTop !== undefined ? defaultTop : 100
    };
  });
  
  const [dragging, setDragging] = useState(false);
  const panelRef = useRef();
  const dragRef = useRef(null);

  const startDrag = e => {
    if (isStudio) return;
    // Disable dragging for now
    return;
  };

  useEffect(() => {
    if (isStudio || !dragging) return;
    const move = e => {
      const d = dragRef.current;
      if (!d) return;
      const el = panelRef.current;
      const w = el ? el.offsetWidth : width;
      const hgt = el ? el.offsetHeight : (typeof height === 'number' ? height : 760);
      const maxLeft = Math.max(8, window.innerWidth - w - 8);
      const maxTop = Math.max(8, window.innerHeight - hgt - 8);
      const next = {
        left: Math.max(8, Math.min(maxLeft, d.left + (e.clientX - d.x))),
        top: Math.max(8, Math.min(maxTop, d.top + (e.clientY - d.y)))
      };
      setPos(next);
      if (persistKey) {
        persistUserPreference('ve_pos_' + persistKey, next);
      }
    };
    const up = () => {
      setDragging(false);
      dragRef.current = null;
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    return () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
  }, [dragging, pos, persistKey, width, height, isStudio]);

  const isDocked = !isStudio && (panelMode === 'left' || panelMode === 'right');
  const toolWidth = isCssStudio ? 430 : width;
  const displayTop = isWideStudio ? '50%' : (isCssStudio ? '16px' : (isDocked ? '8px' : pos.top + 'px'));
  const displayLeft = isWideStudio ? '50%' : (isCssStudio ? Math.max(16, window.innerWidth - toolWidth - 16) + 'px' : (isDocked 
    ? (panelMode === 'left' ? '16px' : Math.max(16, window.innerWidth - width - 16) + 'px')
    : pos.left + 'px'));
  const displayHeight = isWideStudio ? '80dvh' : (isCssStudio ? 'calc(100vh - 32px)' : (isDocked ? 'calc(100vh - 16px)' : (typeof height === 'number' ? height + 'px' : height)));
  const displayTransform = isWideStudio ? 'translate(-50%, -50%)' : 'none';
  const displayWidth = isWideStudio ? (isRecipeStudio ? 'min(calc(100vw - 96px), 1120px)' : 'calc(100vw - 96px)') : (isCssStudio ? 'min(430px, calc(100vw - 32px))' : width + 'px');

  const style = {
    position: 'fixed',
    left: displayLeft,
    top: displayTop,
    transform: displayTransform,
    width: displayWidth,
    maxWidth: isWideStudio ? (isRecipeStudio ? '1120px' : '1920px') : (isCssStudio ? '430px' : 'none'),
    height: displayHeight,
    maxHeight: isWideStudio ? '80dvh' : (isCssStudio ? 'calc(100vh - 32px)' : (isDocked ? 'calc(100vh - 16px)' : (typeof height === 'string' && height.indexOf('16px') !== -1 ? 'calc(100vh - 16px)' : 'calc(100vh - 32px)'))),
    background: isStudio || isCssStudio ? '#151515' : '#1f1f1f',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    borderRadius: isStudio || isCssStudio ? '12px' : '10px',
    boxShadow: isStudio || isCssStudio ? '0 24px 70px rgba(0, 0, 0, 0.55)' : '0 18px 46px rgba(0, 0, 0, 0.40)',
    zIndex: 120000,
    display: 'flex',
    flexDirection: 'column',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    fontSize: '13px',
    color: '#f1f1f1',
    userSelect: 'none',
    overflow: 'hidden'
  };

  return h('div', { ref: panelRef, 'data-panel': panelId, class: 've-o ve-standalone-panel' + (open ? ' open' : '') + (dragging ? ' ve-dragging' : '') + (hasUpdate ? ' has-update' : ''), style },
    h('div', { class: 've-hdr', style: { cursor: isStudio ? 'default' : 'grab', background: '#171717', borderBottom: '1px solid rgba(255,255,255,0.06)' }, onMouseDown: isStudio ? undefined : startDrag },
      !isStudio && h('span', { class: 've-drag-handle', style: { marginRight: '8px' } }, ph('dots-six-vertical')),
      h('span', { class: 've-hdr-t', style: isStudio ? 'font-size:12px;color:#fff' : '' }, title),
      h('div', { style: 'display:flex;gap:4px;margin-left:auto' },
        h('button', { class: 've-a', style: 'width:26px;height:26px;display:flex;align-items:center;justify-content:center', onClick: onClose, title: 'Close' }, ph('x'))
      )
    ),
    updateNotice,
    children
  );
}

/* ── Help panel component ── */
function HelpPanel({ onClose }) {
  return h('div', { class: 've-body', style: { padding: '14px', flex: 1, overflowY: 'auto', display: 'flex', flexDirection: 'column', minHeight: 0 } },
    h('div', { style: 'font-size:12px;font-weight:700;color:#baf400;margin-bottom:8px;text-transform:uppercase;letter-spacing:.4px' }, 'Quick Help'),
    h('div', { style: 'flex:1;overflow-y:auto;font-size:11px;line-height:1.6;color:#ccc' },
      h('div', { style: 'margin-bottom:12px' },
        h('strong', { style: 'color:#fff;display:block;margin-bottom:4px' }, 'Direct Mode'),
        h('div', null, h('code', null, 'data-anim="fade-up"'), ' — set attribute'),
        h('div', null, h('code', null, '.hero'), ' — add class'),
        h('div', null, h('code', null, '#hero'), ' — set ID'),
        h('div', null, h('code', null, '-hero'), ' — remove class'),
        h('div', null, h('code', null, 'delete data-anim'), ' — delete attribute')
      ),
      h('div', { style: 'margin-bottom:12px' },
        h('strong', { style: 'color:#fff;display:block;margin-bottom:4px' }, 'Modes'),
        h('div', null, 'Press ', h('code', null, '1'), ' for Direct Mode'),
        h('div', null, 'Press ', h('code', null, '2'), ' to Search Page Elements'),
        h('div', null, 'Press ', h('code', null, '3'), ' to Add Elements')
      ),
      h('div', { style: 'margin-bottom:12px' },
        h('strong', { style: 'color:#fff;display:block;margin-bottom:4px' }, 'Emmet Patterns'),
        h('div', null, h('code', null, 'cont'), ' + Tab → add container'),
        h('div', null, h('code', null, 'section>cont'), ' + Tab → add section with container child')
      ),
      h('div', { style: 'margin-bottom:12px' },
        h('strong', { style: 'color:#fff;display:block;margin-bottom:4px' }, 'Bulk Operations'),
        h('div', null, h('code', null, '.card => data-anim="fade-up"'), ' — apply attribute to all elements matching selector')
      ),
      h('div', { style: 'margin-bottom:12px' },
        h('strong', { style: 'color:#fff;display:block;margin-bottom:4px' }, 'Mimam\'s Var Integration'),
        h('div', null, 'Type ', h('code', null, 'var '), ' or ', h('code', null, '--'), ' to trigger autocomplete for saved variables')
      )
    ),
    h('div', { style: 'display:flex;justify-content:flex-end;margin-top:14px;border-top:1px solid rgba(255,255,255,.08);padding-top:12px' },
      h('button', { class: 've-btn', onClick: onClose }, 'Close')
    )
  );
}

function RichContentEditor({ value, onChange }) {
  const ref = useRef(null);
  const lastHtml = useRef('');
  useEffect(() => {
    const html = value || '';
    if (ref.current && document.activeElement === ref.current) return;
    if (ref.current && html !== lastHtml.current && ref.current.innerHTML !== html) {
      ref.current.innerHTML = html;
      lastHtml.current = html;
    }
  }, [value]);

  const commit = () => {
    if (!ref.current) return;
    const html = ref.current.innerHTML || '';
    lastHtml.current = html;
    onChange(html);
  };

  const exec = (cmd, arg) => {
    if (!ref.current) return;
    ref.current.focus();
    try { document.execCommand(cmd, false, arg); } catch (e) {}
    commit();
  };

  const tool = (label, cmd, arg, title) => h('button', {
    type: 'button',
    title: title || label,
    onMouseDown: e => e.preventDefault(),
    onClick: () => exec(cmd, arg)
  }, label);

  return h('div', { class: 've-rich-editor' },
    h('div', { class: 've-rich-toolbar' },
      tool('P', 'formatBlock', 'p', 'Paragraph'),
      tool('H1', 'formatBlock', 'h1', 'Heading 1'),
      tool('H2', 'formatBlock', 'h2', 'Heading 2'),
      tool('H3', 'formatBlock', 'h3', 'Heading 3'),
      tool('B', 'bold', null, 'Bold'),
      tool('I', 'italic', null, 'Italic'),
      tool('UL', 'insertUnorderedList', null, 'Bullet list'),
      tool('OL', 'insertOrderedList', null, 'Numbered list'),
      tool('Quote', 'formatBlock', 'blockquote', 'Quote')
    ),
    h('div', {
      ref,
      class: 've-rich-surface ve-scroll-custom',
      contentEditable: true,
      role: 'textbox',
      'aria-label': 'Post content',
      'data-placeholder': 'Write content here...',
      onInput: commit,
      onBlur: commit,
      onPaste: () => setTimeout(commit, 0)
    })
  );
}

/* ── Content Studio sub-panel ────────────────── */
function ContentStudioSub({ onClose, flash }) {
  const [meta, setMeta] = useState({ cpts: [], field_groups: [], acf_active: false, jet_active: false });
  const [activeNav, setActiveNav] = useState('page');
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [visibleContentGroups, setVisibleContentGroups] = useState(() => {
    try { return JSON.parse(localStorage.getItem('ve_content_visible_groups') || '{"default":true,"custom":true,"system":false,"fields":true}'); }
    catch (e) { return { default: true, custom: true, system: false, fields: true }; }
  });
  const [editingPost, setEditingPost] = useState(null);

  // Post form state
  const [title, setTitle] = useState('');
  const [status, setStatus] = useState('draft');
  const [newPost, setNewPost] = useState(null);
  const [showCreateForm, setShowCreateForm] = useState(false);

  // CPT form state
  const [showCptForm, setShowCptForm] = useState(false);
  const [cptName, setCptName] = useState('');
  const [cptSingular, setCptSingular] = useState('');
  const [cptPlural, setCptPlural] = useState('');
  const [cptSource, setCptSource] = useState('acf');

  // Field Group form state
  const [showFieldGroupForm, setShowFieldGroupForm] = useState(false);
  const [groupTitle, setGroupTitle] = useState('');
  const [groupSource, setGroupSource] = useState('acf');
  const [groupTargets, setGroupTargets] = useState([]);

  // Field form state
  const [showFieldForm, setShowFieldForm] = useState(false);
  const [editingFieldName, setEditingFieldName] = useState('');
  const [fieldName, setFieldName] = useState('');
  const [fieldLabel, setFieldLabel] = useState('');
  const [fieldType, setFieldType] = useState('text');

  const [pendingDeleteCS, setPendingDeleteCS] = useState(null);
  const [pendingDeleteCptCS, setPendingDeleteCptCS] = useState(null);
  const [pendingDeleteFgCS, setPendingDeleteFgCS] = useState(null);
  const [pendingDeleteFieldCS, setPendingDeleteFieldCS] = useState(null);
  const loadItemsSeq = useRef(0);

  const loadMeta = useCallback(async () => {
    try {
      const res = await api.g('content-studio/meta');
      if (res && (res.cpts || res.field_groups)) {
        setMeta(res);
      }
    } catch (e) {}
  }, []);

  useEffect(() => {
    loadMeta();
  }, [loadMeta]);

  useEffect(() => {
    if (meta.acf_active) {
      setCptSource('acf');
      setGroupSource('acf');
    } else if (meta.jet_active) {
      setCptSource('jet');
      setGroupSource('jet');
    }
  }, [meta.acf_active, meta.jet_active]);

  const loadItems = useCallback(async () => {
    const seq = ++loadItemsSeq.current;
    setLoading(true);
    try {
      const navKey = String(activeNav || '');
      const isFieldGroup = navKey.startsWith('acf-') || navKey.startsWith('jet-');
      if (isFieldGroup) {
        const group = meta.field_groups.find(g => g.id === navKey);
        if (seq !== loadItemsSeq.current) return;
        if (group) {
          setItems(group.fields || []);
        } else {
          setItems([]);
        }
      } else {
        const res = await api.g('content-studio/posts?post_type=' + encodeURIComponent(navKey));
        if (seq !== loadItemsSeq.current) return;
        if (Array.isArray(res)) {
          setItems(res);
        } else {
          setItems([]);
        }
      }
    } catch (e) {
      if (seq !== loadItemsSeq.current) return;
      setItems([]);
    }
    if (seq === loadItemsSeq.current) setLoading(false);
  }, [activeNav, meta.field_groups]);

  useEffect(() => {
    loadItems();
    setShowCreateForm(false);
    setShowFieldForm(false);
    setEditingFieldName('');
    setNewPost(null);
  }, [activeNav, loadItems]);

  const currentItems = useMemo(() => {
    return items;
  }, [items]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return currentItems;
    const navKey = String(activeNav || '');
    const isFieldGroup = navKey.startsWith('acf-') || navKey.startsWith('jet-');
    if (isFieldGroup) {
      return currentItems.filter(x => (x.label || '').toLowerCase().includes(q) || (x.name || '').toLowerCase().includes(q));
    }
    return currentItems.filter(x => (x.title?.rendered || '').toLowerCase().includes(q) || (x.slug || '').toLowerCase().includes(q));
  }, [activeNav, currentItems, search]);

  const getAdminBase = () => {
    const pathParts = window.location.pathname.split('/');
    const adminIndex = pathParts.findIndex(x => x.includes('admin') || x === 'wp-admin');
    if (adminIndex !== -1) {
      return pathParts.slice(0, adminIndex + 1).join('/') + '/';
    }
    return '/wp-admin/';
  };

  const getEditUrl = (id) => {
    if (id && typeof id === 'object') {
      return id.bricks_link || id.edit_link || id.link || getEditUrl(id.id);
    }
    return getAdminBase() + 'post.php?post=' + id + '&action=edit';
  };

  const selectContentNav = key => {
    const nextKey = String(key || 'page');
    loadItemsSeq.current++;
    setItems([]);
    setLoading(true);
    setActiveNav(nextKey);
    setSearch('');
    setShowCptForm(false);
    setShowFieldGroupForm(false);
    setShowCreateForm(false);
    setShowFieldForm(false);
    setEditingPost(null);
    setEditingFieldName('');
    setNewPost(null);
  };

  const startStudioEdit = (item, e) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setShowCreateForm(false);
    setShowCptForm(false);
    setShowFieldGroupForm(false);
    setShowFieldForm(false);
    const postType = item.type || activeNav;
    const postTypeMeta = getPostTypeMeta(postType) || {};
    setEditingPost({
      id: item.id,
      post_type: postType,
      supports_editor: item.supports_editor !== undefined ? !!item.supports_editor : postTypeMeta.supports_editor !== false,
      titleText: item.title?.rendered || '',
      slug: item.slug || '',
      status: item.status || 'draft',
      content: item.content?.raw || '',
      excerpt: item.excerpt?.raw || '',
      parent: item.parent || 0,
      menu_order: item.menu_order || 0,
      featured_media: item.featured_media || 0,
      comment_status: item.comment_status || 'closed',
      ping_status: item.ping_status || 'closed',
      template: item.template || '',
      custom_fields: item.custom_fields || {},
      edit_link: item.edit_link,
      bricks_link: item.bricks_link,
      link: item.link
    });
  };

  const saveContentEdit = async (e) => {
    e.preventDefault();
    if (!editingPost) return;
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts/' + editingPost.id, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: editingPost.titleText,
          slug: editingPost.slug,
          status: editingPost.status,
          content: editingPost.content || '',
          excerpt: editingPost.excerpt || '',
          parent: parseInt(editingPost.parent || 0, 10) || 0,
          menu_order: parseInt(editingPost.menu_order || 0, 10) || 0,
          featured_media: parseInt(editingPost.featured_media || 0, 10) || 0,
          comment_status: editingPost.comment_status === 'open',
          ping_status: editingPost.ping_status === 'open',
          template: editingPost.template || '',
          custom_fields: editingPost.custom_fields || {}
        })
      });
      if (res && res.id) {
        setItems(prev => prev.map(x => x.id === res.id ? res : x));
        setEditingPost(null);
        flash('Content updated.');
        await loadMeta();
      } else {
        flash(res?.message || 'Update failed.');
      }
    } catch (err) {
      flash('Update failed.');
    }
    setLoading(false);
  };

  const handleToggleStatus = async (item) => {
    const nextStatus = item.status === 'publish' ? 'draft' : 'publish';
    setItems(prev => prev.map(x => x.id === item.id ? { ...x, status: nextStatus } : x));
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts/' + item.id, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus })
      });
      if (res && res.code) {
        flash('Status update failed');
        loadItems();
      } else {
        flash('Status updated to ' + nextStatus);
      }
    } catch (e) {
      flash('Status update failed');
      loadItems();
    }
  };

  const handleDelete = (item) => {
    setPendingDeleteCS(item);
  };

  const confirmDeleteCS = async () => {
    const item = pendingDeleteCS;
    if (!item) return;
    setPendingDeleteCS(null);
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts/' + item.id + '?force=true', { method: 'DELETE' });
      if (res && res.id) {
        setItems(prev => prev.filter(x => x.id !== item.id));
        flash('Deleted content');
        loadMeta();
      } else {
        flash('Delete failed');
      }
    } catch (e) {
      flash('Delete failed');
    }
    setLoading(false);
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ post_type: activeNav, title, status })
      });
      if (res && res.id) {
        setNewPost(res);
        setTitle('');
        flash('Content created!');
        loadItems();
        loadMeta();
      } else {
        flash(res?.message || 'Creation failed');
      }
    } catch (err) {
      flash('Creation failed');
    }
    setLoading(false);
  };

  const handleCopyLink = (url) => {
    if (url === '#') {
      flash('Cannot copy link');
      return;
    }
    navigator.clipboard.writeText(url);
    flash('Copied Link');
  };

  const handleCreateCpt = async (e) => {
    e.preventDefault();
    if (!cptName.trim() || !cptSingular.trim() || !cptPlural.trim()) return;
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/cpts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: cptName, singular: cptSingular, plural: cptPlural, source: cptSource })
      });
      if (res && res.success) {
        flash('CPT registered successfully!');
        setCptName('');
        setCptSingular('');
        setCptPlural('');
        setShowCptForm(false);
        await loadMeta();
      } else {
        flash('CPT registration failed');
      }
    } catch (e) {
      flash('CPT registration failed');
    }
    setLoading(false);
  };

  const handleDeleteCpt = (e, name) => {
    e.stopPropagation();
    setPendingDeleteCptCS(name);
  };

  const confirmDeleteCptCS = async () => {
    const name = pendingDeleteCptCS;
    if (!name) return;
    setPendingDeleteCptCS(null);
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/cpts/' + name, { method: 'DELETE' });
      if (res && res.success) {
        flash(`CPT "${name}" deleted.`);
        if (activeNav === name) setActiveNav('page');
        await loadMeta();
      } else {
        flash('Failed to delete CPT.');
      }
    } catch (e) {
      flash('Failed to delete CPT.');
    }
    setLoading(false);
  };

  const handleCreateFieldGroup = async (e) => {
    e.preventDefault();
    if (!groupTitle.trim()) return;
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/fields', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: groupTitle, post_types: groupTargets, fields: [], source: groupSource })
      });
      if (res && res.success) {
        flash('Field Group created successfully!');
        setGroupTitle('');
        setGroupTargets([]);
        setShowFieldGroupForm(false);
        await loadMeta();
      } else {
        flash('Field Group creation failed');
      }
    } catch (e) {
      flash('Field Group creation failed');
    }
    setLoading(false);
  };

  const handleDeleteFieldGroup = (e, id) => {
    e.stopPropagation();
    setPendingDeleteFgCS(id);
  };

  const confirmDeleteFgCS = async () => {
    const id = pendingDeleteFgCS;
    if (!id) return;
    setPendingDeleteFgCS(null);
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/fields/' + id, { method: 'DELETE' });
      if (res && res.success) {
        flash('Field Group deleted.');
        if (activeNav === id) setActiveNav('page');
        await loadMeta();
      } else {
        flash('Failed to delete Field Group.');
      }
    } catch (e) {
      flash('Failed to delete Field Group.');
    }
    setLoading(false);
  };

  const handleCreateField = async (e) => {
    e.preventDefault();
    if (!fieldName.trim() || !fieldLabel.trim()) return;
    setLoading(true);
    try {
      const group = meta.field_groups.find(g => g.id === activeNav);
      if (!group) return;
      
      const newField = { name: fieldName, label: fieldLabel, type: fieldType };
      const existingFields = group.fields || [];
      const updatedFields = editingFieldName
        ? existingFields.map(f => f.name === editingFieldName ? newField : f)
        : [...existingFields.filter(f => f.name !== fieldName), newField];
      
      const res = await api.f('variable-engine/v1/content-studio/fields', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: group.title,
          post_types: group.post_types || [],
          fields: updatedFields,
          source: group.source || 'acf'
        })
      });
      if (res && res.success) {
        flash(editingFieldName ? 'Custom field updated!' : 'Custom field added!');
        setFieldName('');
        setFieldLabel('');
        setEditingFieldName('');
        setShowFieldForm(false);
        await loadMeta();
      } else {
        flash('Failed to add field.');
      }
    } catch (e) {
      flash('Failed to add field.');
    }
    setLoading(false);
  };

  const handleDeleteField = (fName) => {
    setPendingDeleteFieldCS(fName);
  };

  const handleEditField = (field) => {
    setEditingFieldName(field.name || '');
    setFieldName(field.name || '');
    setFieldLabel(field.label || '');
    setFieldType(field.type || 'text');
    setShowFieldForm(true);
  };

  const confirmDeleteFieldCS = async () => {
    const fName = pendingDeleteFieldCS;
    if (!fName) return;
    setPendingDeleteFieldCS(null);
    setLoading(true);
    try {
      const group = meta.field_groups.find(g => g.id === activeNav);
      if (!group) return;
      
      const updatedFields = (group.fields || []).filter(f => f.name !== fName);
      
      const res = await api.f('variable-engine/v1/content-studio/fields', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: group.title,
          post_types: group.post_types || [],
          fields: updatedFields,
          source: group.source || 'acf'
        })
      });
      if (res && res.success) {
        flash('Field deleted.');
        await loadMeta();
      } else {
        flash('Failed to delete field.');
      }
    } catch (e) {
      flash('Failed to delete field.');
    }
    setLoading(false);
  };

  const formatNavLabel = (key) => {
    if (key === 'page') return 'Pages';
    if (key === 'post') return 'Posts';
    const cpt = meta.cpts.find(pt => pt.name === key);
    if (cpt) return cpt.label;
    const group = meta.field_groups.find(g => g.id === key);
    if (group) return group.title;
    return key;
  };

  const getPostTypeMeta = key => meta.cpts.find(pt => pt.name === key) || null;
  const getFieldGroupsForPostType = key => {
    const pt = String(key || '');
    if (!pt) return [];
    return (meta.field_groups || []).filter(group => {
      const targets = Array.isArray(group.post_types) ? group.post_types.map(String) : [];
      return targets.includes(pt);
    });
  };
  const getEditableCustomFields = post => {
    const groups = getFieldGroupsForPostType(post?.post_type);
    const fields = [];
    const seen = new Set();
    groups.forEach(group => (group.fields || []).forEach(field => {
      const key = field.name || field.label;
      if (!key || seen.has(key)) return;
      seen.add(key);
      fields.push({ ...field, groupTitle: group.title || 'Field group' });
    }));
    Object.keys(post?.custom_fields || {}).forEach(key => {
      if (!key || seen.has(key)) return;
      seen.add(key);
      fields.push({ name: key, label: key.replace(/[_-]+/g, ' ').replace(/\b\w/g, m => m.toUpperCase()), type: 'text', groupTitle: 'Custom meta' });
    });
    return fields;
  };
  const isRankMathField = key => /^rank[_-]?math/i.test(String(key || '')) || String(key || '').indexOf('rank_math') !== -1;
  const isReadOnlyRankMathField = key => {
    const k = String(key || '').toLowerCase();
    return k === 'rank_math_internal_links_processed' || k === 'rank_math_analytic_object_id' || k === 'rank_math_seo_score';
  };
  const isSerializedMetaValue = value => {
    const s = String(value == null ? '' : value).trim();
    return /^(a|O|s|i|b|d):\d+[:;]/.test(s) || (s.length > 120 && /[{}";:]/.test(s));
  };
  const getCustomFieldSections = post => {
    const sections = [];
    const rank = [];
    const custom = [];
    getEditableCustomFields(post).forEach(field => {
      const key = field.name || field.label;
      if (isRankMathField(key)) rank.push({ ...field, groupTitle: 'Rank Math Fields' });
      else custom.push(field);
    });
    if (custom.length) sections.push({ title: 'Custom fields', help: 'Fields detected from ACF, JetEngine, or regular WordPress meta for this post type. Values save with the content item.', fields: custom });
    if (rank.length) sections.push({ title: 'Rank Math fields', help: 'SEO metadata detected from Rank Math. Internal processed, analytics object, and SEO score fields are read-only because Rank Math recalculates them.', fields: rank });
    return sections;
  };
  const fieldInput = (field, value, onValue) => {
    const type = String(field.type || 'text').toLowerCase();
    const common = { class: 've-studio-input', value: value == null ? '' : value, onInput: e => onValue(e.target.value), placeholder: field.label || field.name };
    if (isReadOnlyRankMathField(field.name || field.label)) {
      return h('input', { class: 've-studio-input ve-studio-readonly', value: value == null ? '' : value, readOnly: true, disabled: true, title: 'Read-only Rank Math internal field' });
    }
    if (isSerializedMetaValue(value)) return h('textarea', { ...common, class: 've-studio-input ve-studio-textarea ve-field-serialized', style: 'line-height:1.55;resize:vertical' });
    if (type === 'textarea' || type === 'wysiwyg') return h('textarea', { ...common, class: 've-studio-input ve-studio-textarea', style: 'min-height:92px;line-height:1.6;resize:vertical' });
    if (type === 'number' || type === 'range') return h('input', { ...common, type: 'number' });
    if (type === 'true_false' || type === 'boolean' || type === 'checkbox') return h(CheckControl, { checked: !!value && value !== '0' && value !== 'false', label: field.label || field.name, onChange: checked => onValue(checked ? '1' : '0') });
    return h('input', { ...common, type: 'text' });
  };

  const activeNavKey = String(activeNav || '');
  const isFieldGroup = activeNavKey.startsWith('acf-') || activeNavKey.startsWith('jet-');
  const defaultNames = ['page', 'post'];
  const defaultLabelPattern = /^(pages?|posts?)$/i;
  const systemNamePattern = /^(acf-|acf_|wp_|nav_|custom_css|customize_changeset|oembed_cache|user_request|bricks_|ct_|frm_|wpcf7_|jet-|elementor_|revision$)/i;
  const systemLabelPattern = /(taxonom|option pages?|custom fonts?|rm content editor|field groups?|template parts?|navigation)/i;
  const isDefaultish = pt => defaultNames.includes(pt.name) || defaultLabelPattern.test(pt.label || '');
  const defaultCpts = meta.cpts.filter(pt => defaultNames.includes(pt.name));
  const systemCpts = meta.cpts.filter(pt => !isDefaultish(pt) && (pt.is_content === false || systemNamePattern.test(pt.name || '') || systemLabelPattern.test(pt.label || '')));
  const contentCpts = meta.cpts.filter(pt => !isDefaultish(pt) && !systemCpts.some(sys => sys.name === pt.name));
  const toggleContentGroup = key => {
    const next = { ...visibleContentGroups, [key]: !visibleContentGroups[key] };
    setVisibleContentGroups(next);
    persistUserPreference('ve_content_visible_groups', next);
  };
  const sectionTitle = (key, label, canAdd, onAdd) => h('div', { class: 've-studio-nav-title ve-studio-section-title' },
    h('button', { type: 'button', class: 've-section-toggle', onClick: () => toggleContentGroup(key), title: visibleContentGroups[key] ? 'Hide group' : 'Show group' }, ph(visibleContentGroups[key] ? 'caret-down' : 'caret-right'), h('span', null, label)),
    canAdd && h('button', { type: 'button', class: 've-a ve-a-inline', title: 'Create', onClick: onAdd }, ph('plus'))
  );

  return h('div', { class: 've-studio-layout ve-content-studio' },
    pendingDeleteCS && h(ConfirmModal, { title: 'Delete Content', body: 'Are you sure you want to permanently delete this content?', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteCS(null), onConfirm: confirmDeleteCS }),
    pendingDeleteCptCS && h(ConfirmModal, { title: 'Delete Post Type', body: 'Are you sure you want to permanently delete CPT "' + pendingDeleteCptCS + '"?', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteCptCS(null), onConfirm: confirmDeleteCptCS }),
    pendingDeleteFgCS && h(ConfirmModal, { title: 'Delete Field Group', body: 'Are you sure you want to delete this custom field group?', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteFgCS(null), onConfirm: confirmDeleteFgCS }),
    pendingDeleteFieldCS && h(ConfirmModal, { title: 'Delete Field', body: 'Are you sure you want to delete field "' + pendingDeleteFieldCS + '"?', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteFieldCS(null), onConfirm: confirmDeleteFieldCS }),
    // 1. Sidebar
    h('div', { class: 've-studio-sidebar' },
      h('div', { style: 'flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:16px;padding-right:2px' },
        // Default Content Types
        h('div', { class: 've-studio-nav' },
          sectionTitle('default', 'Default Content Types'),
          visibleContentGroups.default && ['page', 'post'].map(k => {
            const cpt = meta.cpts.find(pt => pt.name === k);
            return h('div', {
              key: k,
              class: 've-studio-nav-item' + (activeNav === k && !showCptForm && !showFieldGroupForm ? ' active' : ''),
              onClick: () => selectContentNav(k)
            },
              h('span', { style: 'display:flex;align-items:center;gap:8px' },
                ph(k === 'page' ? 'file' : 'article'),
                formatNavLabel(k)
              ),
              h('span', { class: 've-studio-badge' }, (activeNav === k && loading) ? '...' : (cpt ? cpt.count : '0'))
            );
          })
        ),
        // Custom Post Types
        h('div', { class: 've-studio-nav' },
          sectionTitle('custom', 'Custom Post Types', (meta.acf_active || meta.jet_active), () => {
            setShowCptForm(true);
            setShowFieldGroupForm(false);
          }),
          visibleContentGroups.custom && (contentCpts.length ? contentCpts.map(cpt => h('div', {
            key: cpt.name,
            class: 've-studio-nav-item ve-nav-item-cpt' + (activeNav === cpt.name && !showCptForm && !showFieldGroupForm ? ' active' : ''),
            onClick: () => selectContentNav(cpt.name)
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' },
              ph('circles-three-plus'),
              h('span', { style: 'overflow:hidden;text-overflow:ellipsis' }, cpt.label),
              cpt.source !== 'wp' && h('span', {
                style: 'font-size:8px;padding:1px 4px;border-radius:4px;background:' + (cpt.source === 'acf' ? 'rgba(57,112,245,0.15)' : 'rgba(186,244,0,0.15)') + ';color:' + (cpt.source === 'acf' ? '#4f8bff' : '#baf400') + ';font-weight:700;margin-left:4px'
              }, cpt.source.toUpperCase())
            ),
            h('div', { style: 'display:flex;align-items:center;gap:6px' },
              h('span', { class: 've-studio-badge' }, cpt.count),
              cpt.source !== 'wp' && h('button', {
                class: 've-nav-delete-btn',
                title: 'Delete post type',
                style: 'border:none;background:none;padding:0;cursor:pointer;color:#ff4d4d;opacity:0;transition:opacity 0.2s;display:flex;align-items:center',
                onClick: (e) => handleDeleteCpt(e, cpt.name)
              }, ph('trash'))
            )
          )) : h('div', { class: 've-empty ve-empty-inline' }, 'No custom content types detected.'))
        ),
        h('div', { class: 've-studio-nav' },
          sectionTitle('system', 'Plugin / System Types'),
          visibleContentGroups.system && (systemCpts.length ? systemCpts.map(cpt => h('div', {
            key: cpt.name,
            class: 've-studio-nav-item ve-nav-item-cpt' + (activeNav === cpt.name && !showCptForm && !showFieldGroupForm ? ' active' : ''),
            onClick: () => selectContentNav(cpt.name)
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' },
              ph('plug'),
              h('span', { style: 'overflow:hidden;text-overflow:ellipsis' }, cpt.label)
            ),
            h('span', { class: 've-studio-badge' }, cpt.count)
          )) : h('div', { class: 've-empty ve-empty-inline' }, 'No plugin/system types detected.'))
        ),
        // Custom Field Groups
        h('div', { class: 've-studio-nav' },
          sectionTitle('fields', 'Custom Field Groups', (meta.acf_active || meta.jet_active), () => {
            setShowFieldGroupForm(true);
            setShowCptForm(false);
          }),
          visibleContentGroups.fields && meta.field_groups.map(group => h('div', {
            key: group.id,
            class: 've-studio-nav-item ve-nav-item-cpt' + (activeNav === group.id && !showCptForm && !showFieldGroupForm ? ' active' : ''),
            onClick: () => selectContentNav(group.id)
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' },
              ph('gear'),
              h('span', { style: 'overflow:hidden;text-overflow:ellipsis' }, group.title),
              h('span', {
                style: 'font-size:8px;padding:1px 4px;border-radius:4px;background:' + (group.source === 'acf' ? 'rgba(57,112,245,0.15)' : 'rgba(186,244,0,0.15)') + ';color:' + (group.source === 'acf' ? '#4f8bff' : '#baf400') + ';font-weight:700;margin-left:4px'
              }, group.source.toUpperCase())
            ),
            h('div', { style: 'display:flex;align-items:center;gap:6px' },
              h('span', { class: 've-studio-badge' }, (group.fields || []).length),
              h('button', {
                class: 've-nav-delete-btn',
                title: 'Delete field group',
                style: 'border:none;background:none;padding:0;cursor:pointer;color:#ff4d4d;opacity:0;transition:opacity 0.2s;display:flex;align-items:center',
                onClick: (e) => handleDeleteFieldGroup(e, group.id)
              }, ph('trash'))
            )
          ))
        )
      )
    ),
    // 2. Main Area
    h('div', { class: 've-studio-main' },
      h('div', { style: 'display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;gap:12px' },
        h('div', null,
          h('h2', { style: 'margin:0;font-size:16px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px' },
            showCptForm ? 'Register Custom Post Type' : (showFieldGroupForm ? 'Create Custom Field Group' : formatNavLabel(activeNav)),
            !showCptForm && !showFieldGroupForm && h('span', { style: 'font-size:11px;font-weight:400;color:#888;background:rgba(255,255,255,0.04);padding:2px 8px;border-radius:10px' }, `${filtered.length} items`)
          )
        ),
        h('div', { style: 'display:flex;gap:8px;align-items:center' },
          !showCreateForm && !showCptForm && !showFieldGroupForm && !showFieldForm && h('input', {
            class: 've-studio-input',
            style: 'width:220px',
            placeholder: 'Search...',
            value: search,
            onInput: e => setSearch(e.target.value)
          }),
          // Actions for CPTs
          !isFieldGroup && !showCptForm && !showFieldGroupForm && h('button', {
            class: 've-btn ve-btn-s ' + (showCreateForm ? 've-btn-g' : ''),
            onClick: () => { setShowCreateForm(prev => !prev); setNewPost(null); }
          }, showCreateForm ? 'Back to List' : '+ Add New'),
          // Actions for Field Groups
          isFieldGroup && !showCptForm && !showFieldGroupForm && h('button', {
            class: 've-btn ve-btn-s ' + (showFieldForm ? 've-btn-g' : ''),
            onClick: () => setShowFieldForm(prev => {
              if (prev) {
                setEditingFieldName('');
                setFieldName('');
                setFieldLabel('');
                setFieldType('text');
              }
              return !prev;
            })
          }, showFieldForm ? 'Back to List' : '+ Add Field')
        )
      ),

      // ── Form: Register CPT ──
      showCptForm ? h('form', { onSubmit: handleCreateCpt, style: 'max-width:500px;display:flex;flex-direction:column;gap:14px;background:rgba(255,255,255,0.01);border:1px solid rgba(255,255,255,0.05);border-radius:10px;padding:20px' },
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Post Type Key (Slug)'),
          h('input', {
            class: 've-studio-input',
            required: true,
            value: cptName,
            onInput: e => setCptName(e.target.value.toLowerCase().replace(/[^a-z0-9_\-]/g, '')),
            placeholder: 'e.g. portfolio'
          })
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Singular Label'),
          h('input', {
            class: 've-studio-input',
            required: true,
            value: cptSingular,
            onInput: e => setCptSingular(e.target.value),
            placeholder: 'e.g. Portfolio Item'
          })
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Plural Label'),
          h('input', {
            class: 've-studio-input',
            required: true,
            value: cptPlural,
            onInput: e => setCptPlural(e.target.value),
            placeholder: 'e.g. Portfolios'
          })
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Provider'),
          h(SelectMenu, { className: 've-studio-select', value: cptSource, onChange: setCptSource, options: [
            meta.acf_active && { value: 'acf', label: 'Advanced Custom Fields (ACF)' },
            meta.jet_active && { value: 'jet', label: 'JetEngine' }
          ].filter(Boolean) })
        ),
        h('div', { style: 'display:flex;gap:8px;margin-top:8px' },
          h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:600;flex:1' }, loading ? 'Registering...' : 'Register CPT'),
          h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => setShowCptForm(false) }, 'Cancel')
        )
      ) :

      // ── Form: Create Field Group ──
      showFieldGroupForm ? h('form', { onSubmit: handleCreateFieldGroup, style: 'max-width:500px;display:flex;flex-direction:column;gap:14px;background:rgba(255,255,255,0.01);border:1px solid rgba(255,255,255,0.05);border-radius:10px;padding:20px' },
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Group Title'),
          h('input', {
            class: 've-studio-input',
            required: true,
            value: groupTitle,
            onInput: e => setGroupTitle(e.target.value),
            placeholder: 'e.g. Project Specs'
          })
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Assign to Post Types (CPTs)'),
          h('div', { class: 've-check-list ve-scroll-custom' },
            [...defaultCpts, ...contentCpts].map(pt => h(CheckControl, {
              key: pt.name,
              checked: groupTargets.includes(pt.name),
              label: pt.label + ' (' + pt.name + ')',
              onChange: checked => {
                if (checked) setGroupTargets([...groupTargets, pt.name]);
                else setGroupTargets(groupTargets.filter(x => x !== pt.name));
              }
            }))
          )
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Provider'),
          h(SelectMenu, { className: 've-studio-select', value: groupSource, onChange: setGroupSource, options: [
            meta.acf_active && { value: 'acf', label: 'Advanced Custom Fields (ACF)' },
            meta.jet_active && { value: 'jet', label: 'JetEngine' }
          ].filter(Boolean) })
        ),
        h('div', { style: 'display:flex;gap:8px;margin-top:8px' },
          h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:600;flex:1' }, loading ? 'Creating...' : 'Create Field Group'),
          h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => setShowFieldGroupForm(false) }, 'Cancel')
        )
      ) :

      // ── Form: Create Post inside CPT ──
      !isFieldGroup && showCreateForm ? h('form', { onSubmit: handleCreate, style: 'max-width:500px;display:flex;flex-direction:column;gap:14px;background:rgba(255,255,255,0.01);border:1px solid rgba(255,255,255,0.05);border-radius:10px;padding:20px' },
        newPost ? h('div', { style: 'background:rgba(186,244,0,0.1);border:1px solid #baf400;border-radius:8px;padding:16px;text-align:center' },
          h('div', { style: 'color:#baf400;font-weight:700;margin-bottom:8px;font-size:13px' }, 'Content Created Successfully!'),
          h('div', { style: 'color:#fff;font-size:12px;margin-bottom:12px;font-weight:600' }, newPost.title?.rendered),
          h('a', { class: 've-btn ve-btn-primary', style: 'text-decoration:none;display:inline-block;color:#1f1f1f;font-weight:600', href: getEditUrl(newPost), target: '_blank' }, 'Open in Bricks')
        ) : [
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Title'),
            h('input', { class: 've-studio-input', required: true, value: title, onInput: e => setTitle(e.target.value), placeholder: 'e.g. New ' + formatNavLabel(activeNav) })
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Status'),
            h(SelectMenu, { className: 've-studio-select', value: status, onChange: setStatus, options: [{ value: 'draft', label: 'Draft' }, { value: 'publish', label: 'Publish' }] })
          ),
          h('div', { style: 'display:flex;gap:8px;margin-top:8px' },
            h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:600;flex:1' }, loading ? 'Creating...' : 'Create Content'),
            h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => setShowCreateForm(false) }, 'Cancel')
          )
        ]
      ) :

      // ── Form: Create Custom Field inside Field Group ──
      isFieldGroup && showFieldForm ? h('form', { onSubmit: handleCreateField, class: 've-content-field-edit-form' },
        h('div', { class: 've-content-field-edit-main ve-scroll-custom' },
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Field Name (Key/Slug)'),
            h('input', {
              class: 've-studio-input',
              required: true,
              value: fieldName,
              onInput: e => setFieldName(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '')),
              placeholder: 'e.g. project_cost'
            })
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Field Label'),
            h('input', {
              class: 've-studio-input',
              required: true,
              value: fieldLabel,
              onInput: e => setFieldLabel(e.target.value),
              placeholder: 'e.g. Project Cost'
            })
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Field Type'),
            h(SelectMenu, { className: 've-studio-select', value: fieldType, onChange: setFieldType, options: [
              { value: 'text', label: 'Text' },
              { value: 'textarea', label: 'Text Area' },
              { value: 'number', label: 'Number' },
              { value: 'image', label: 'Image' },
              { value: 'select', label: 'Select / Dropdown' },
              { value: 'boolean', label: 'True / False' }
            ] })
          )
        ),
        h('div', { class: 've-content-field-edit-actions' },
          h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:38px;color:#1f1f1f;font-weight:600;flex:1' }, loading ? 'Saving...' : (editingFieldName ? 'Save Field' : 'Add Field')),
          h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:38px', onClick: () => { setEditingFieldName(''); setShowFieldForm(false); } }, 'Cancel')
        )
      ) :

      editingPost ? h('form', { onSubmit: saveContentEdit, class: 've-content-edit-form' },
        h('div', { class: 've-content-edit-scroll ve-scroll-custom' },
          h('div', { style: 'display:grid;grid-template-columns:minmax(0,1fr) 170px;gap:12px' },
            h('div', null,
              h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Title'),
              h('input', { class: 've-studio-input', required: true, value: editingPost.titleText, onInput: e => setEditingPost(v => ({ ...v, titleText: e.target.value })) })
            ),
            h('div', null,
              h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Status'),
              h(SelectMenu, { className: 've-studio-select', value: editingPost.status || 'draft', onChange: value => setEditingPost(v => ({ ...v, status: value })), options: [
                { value: 'draft', label: 'Draft' },
                { value: 'publish', label: 'Published' },
                { value: 'pending', label: 'Pending' },
                { value: 'private', label: 'Private' }
              ] })
            )
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Slug'),
            h('input', { class: 've-studio-input', value: editingPost.slug || '', onInput: e => setEditingPost(v => ({ ...v, slug: e.target.value.toLowerCase().replace(/[^a-z0-9_\-]/g, '-') })) })
          ),
          editingPost.supports_editor !== false && h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Content'),
            h(RichContentEditor, {
              value: editingPost.content || '',
              onChange: html => setEditingPost(v => ({ ...v, content: html }))
            })
          ),
          editingPost.supports_editor === false && h('div', { class: 've-content-field-help' }, 'This post type has the default WordPress content editor disabled, so Content is hidden here.'),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Excerpt'),
            h('textarea', { class: 've-studio-input ve-studio-textarea', value: editingPost.excerpt || '', onInput: e => setEditingPost(v => ({ ...v, excerpt: e.target.value })), style: 'min-height:96px;line-height:1.6;resize:vertical' })
          ),
          getCustomFieldSections(editingPost).map(section => h('details', { class: 've-content-custom-fields', open: true, key: 'custom-section-' + section.title },
            h('summary', null, section.title),
            h('div', { class: 've-content-field-help' }, section.help),
            h('div', { class: 've-content-custom-grid' },
              section.fields.map(field => {
                const key = field.name || field.label;
                if (!key) return null;
                const val = (editingPost.custom_fields || {})[key];
                return h('div', { key: 'field-' + key },
                  h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, field.label || key),
                  fieldInput(field, val, next => setEditingPost(v => ({ ...v, custom_fields: { ...(v.custom_fields || {}), [key]: next } }))),
                  h('div', { class: 've-content-field-help' }, (field.groupTitle || 'Custom field') + ' · ' + (field.type || 'text') + (isSerializedMetaValue(val) ? ' · serialized/plugin data' : ''))
                );
              })
            )
          )),
          h('details', { class: 've-content-advanced' },
            h('summary', null, 'Advanced WordPress fields'),
            h('div', { style: 'font-size:10px;color:#888;line-height:1.55;margin:9px 0 12px' }, 'These are native WordPress fields. Parent ID links a page/post under another item, Order controls manual menu/order sorting, Featured image ID stores the thumbnail attachment, Template selects a page template, and Comments/Pings control discussion permissions. Most edits can ignore these.'),
            h('div', { style: 'display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px' },
              h('div', null,
                h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Parent ID'),
                h('input', { class: 've-studio-input', type: 'number', min: 0, value: editingPost.parent || 0, onInput: e => setEditingPost(v => ({ ...v, parent: e.target.value })) }),
                h('div', { class: 've-content-field-help' }, 'Use 0 when this item has no parent.')
              ),
              h('div', null,
                h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Order'),
                h('input', { class: 've-studio-input', type: 'number', value: editingPost.menu_order || 0, onInput: e => setEditingPost(v => ({ ...v, menu_order: e.target.value })) }),
                h('div', { class: 've-content-field-help' }, 'Lower numbers appear earlier where manual ordering is used.')
              ),
              h('div', null,
                h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Featured image ID'),
                h('input', { class: 've-studio-input', type: 'number', min: 0, value: editingPost.featured_media || 0, onInput: e => setEditingPost(v => ({ ...v, featured_media: e.target.value })) }),
                h('div', { class: 've-content-field-help' }, 'WordPress attachment ID used as the featured image.')
              ),
              h('div', null,
                h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Template'),
                h('input', { class: 've-studio-input', value: editingPost.template || '', onInput: e => setEditingPost(v => ({ ...v, template: e.target.value })), placeholder: 'default' }),
                h('div', { class: 've-content-field-help' }, 'Theme page template slug, usually default.')
              )
            ),
            h('div', { style: 'display:flex;gap:18px;margin-top:12px;align-items:center;flex-wrap:wrap' },
              h(CheckControl, { checked: editingPost.comment_status === 'open', label: 'Allow comments', onChange: checked => setEditingPost(v => ({ ...v, comment_status: checked ? 'open' : 'closed' })) }),
              h(CheckControl, { checked: editingPost.ping_status === 'open', label: 'Allow pings', onChange: checked => setEditingPost(v => ({ ...v, ping_status: checked ? 'open' : 'closed' })) })
            )
          ),
          h('div', { style: 'font-size:10px;color:#777;line-height:1.55' }, 'Studio edits core WordPress fields directly. Builder canvas, block editor internals, and plugin-specific metaboxes still open in Bricks or WordPress when needed.')
        ),
        h('div', { class: 've-content-edit-actions' },
          h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:600;min-width:150px' }, loading ? 'Saving...' : 'Save in Studio'),
          h('a', { class: 've-btn ve-btn-g', style: 'height:36px;text-decoration:none;display:inline-flex;align-items:center', href: getEditUrl(editingPost), target: '_blank' }, 'Edit in Bricks'),
          editingPost.edit_link && h('a', { class: 've-btn ve-btn-g', style: 'height:36px;text-decoration:none;display:inline-flex;align-items:center', href: editingPost.edit_link, target: '_blank' }, 'Open WP editor'),
          h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => setEditingPost(null) }, 'Cancel')
        )
      ) :

      // ── Main Content Lists (CPT Posts or Field Group Fields) ──
      h('div', { class: 've-studio-table-container' },
        loading ? h('div', { style: 'text-align:center;padding:60px;color:#888' }, 'Loading...') :
        filtered.length === 0 ? h('div', { style: 'text-align:center;padding:60px;color:#888' }, 'No items found.') :
        
        (!isFieldGroup ? (
          h('table', { class: 've-studio-table' },
            h('thead', null,
              h('tr', null,
                h('th', { style: 'width:60px' }, 'ID'),
                h('th', null, 'Title'),
                h('th', null, 'Slug'),
                h('th', { style: 'width:100px' }, 'Status'),
                h('th', { style: 'width:120px' }, 'Created'),
                h('th', { style: 'width:120px' }, 'Last Edited'),
                h('th', { style: 'width:140px;text-align:right' }, 'Actions')
              )
            ),
            h('tbody', null, filtered.map(item =>
              h('tr', { key: item.id },
                h('td', { style: 'color:#666' }, `#${item.id}`),
                h('td', { style: 'font-weight:600;color:#fff' }, item.title?.rendered || 'Untitled'),
                h('td', { style: 'color:#888;font-family:monospace;font-size:11px' }, item.slug || '-'),
                h('td', null,
                  h('button', {
                    onClick: () => handleToggleStatus(item),
                    class: 've-status-toggle',
                    title: item.status === 'publish' ? 'Click to move this item to Draft' : 'Click to publish this item'
                  },
                    h('span', {
                      class: 've-studio-badge',
                      style: item.status === 'publish'
                        ? 'background:rgba(186,244,0,0.1);color:#baf400;border:1px solid rgba(186,244,0,0.2)'
                        : 'background:rgba(255,184,0,0.1);color:#ffb800;border:1px solid rgba(255,184,0,0.2)'
                    }, item.status === 'publish' ? 'Published' : 'Draft')
                  )
                ),
                h('td', { style: 'color:#888;font-size:11px' }, item.date ? new Date(item.date).toLocaleDateString() : '-'),
                h('td', { style: 'color:#888;font-size:11px' }, item.modified ? new Date(item.modified).toLocaleDateString() : '-'),
                h('td', { style: 'text-align:right' },
                  h('div', { style: 'display:flex;gap:6px;justify-content:flex-end' },
                    h('button', {
                      type: 'button',
                      class: 've-btn ve-btn-g ve-btn-s',
                      onPointerDown: e => startStudioEdit(item, e),
                      onMouseDown: e => e.stopPropagation(),
                      onClick: e => startStudioEdit(item, e),
                      title: 'Edit core WordPress fields in Content Studio'
                    }, 'Edit in Studio'),
                    h('a', {
                      class: 've-btn ve-btn-primary ve-btn-s',
                      style: 'text-decoration:none;display:inline-flex;align-items:center;color:#1f1f1f;padding:2px 8px;font-weight:600',
                      href: getEditUrl(item),
                      title: 'Edit in Bricks'
                    }, 'Edit in Bricks'),
                    item.link !== '#' && h('a', {
                      class: 've-btn ve-btn-g ve-btn-s',
                      style: 'text-decoration:none;display:inline-flex;align-items:center;padding:2px 8px',
                      href: item.link,
                      target: '_blank',
                      title: 'Preview'
                    }, 'View'),
                    h('button', {
                      class: 've-btn ve-btn-g ve-btn-s',
                      onClick: () => handleCopyLink(item.link),
                      title: 'Copy Link'
                    }, ph('copy')),
                    h('button', {
                      class: 've-btn ve-btn-g ve-btn-s',
                      style: 'color:#ff4d4d',
                      onClick: () => handleDelete(item),
                      title: 'Delete Permanently'
                    }, ph('trash'))
                  )
                )
              )
            ))
          )
        ) : (
          // Custom Fields Table
          h('table', { class: 've-studio-table' },
            h('thead', null,
              h('tr', null,
                h('th', null, 'Field Label'),
                h('th', null, 'Field Name (Key)'),
                h('th', { style: 'width:150px' }, 'Type'),
                h('th', { style: 'width:100px;text-align:right' }, 'Actions')
              )
            ),
            h('tbody', null, filtered.map(field =>
              h('tr', { key: field.name },
                h('td', { style: 'font-weight:600;color:#fff' }, field.label),
                h('td', { style: 'color:#888;font-family:monospace;font-size:11px' }, field.name),
                h('td', null,
                  h('span', {
                    class: 've-studio-badge',
                    style: 'background:rgba(255,255,255,0.05);color:#ccc;border:1px solid rgba(255,255,255,0.1)'
                  }, field.type.toUpperCase())
                ),
                h('td', { style: 'text-align:right' },
                  h('div', { style: 'display:flex;gap:6px;justify-content:flex-end' },
                    h('button', {
                      type: 'button',
                      class: 've-btn ve-btn-g ve-btn-s',
                      onClick: () => handleEditField(field),
                      title: 'Edit field'
                    }, ph('pencil-simple')),
                    h('button', {
                      class: 've-btn ve-btn-g ve-btn-s',
                      style: 'color:#ff4d4d',
                      onClick: () => handleDeleteField(field.name),
                      title: 'Delete field'
                    }, ph('trash'))
                  )
                )
              )
            ))
          )
        ))
      )
    )
  );
}

/* ── Media Studio sub-panel ──────────────────── */
const COLL_ICONS = ['folder','folders','images','image','file','file-image','file-video','file-audio','file-text','file-pdf','font-aa','star','heart','bookmark','tag','tags','flag','lightning','globe','camera','music-notes','video','paint-brush','palette','code','brackets-curly','book','books','trophy','gift','diamond','rocket','puzzle-piece','shield-check','house','buildings','tree','sun','moon','fire','drop','leaf','smiley','archive','box-arrow-down','calendar','users','user','briefcase','browser','app-window','database','cloud','download','upload','link','paperclip','paint-bucket','swatches','sparkle','magic-wand','target','tray','stack','squares-four','grid-four'];
function MediaStudioSub({ onClose, flash, onInsertMedia, picking }) {
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [selected, setSelected] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [layoutMode, setLayoutMode] = useState(() => localStorage.getItem('ve_media_layout') || 'grid');
  const [selectedColl, setSelectedColl] = useState('all');
  const [checkedItems, setCheckedItems] = useState([]);
  const fileInputRef = useRef(null);
  const [filterType, setFilterType] = useState(() => localStorage.getItem('ve_media_filter') || 'all');
  const [sortBy, setSortBy] = useState(() => localStorage.getItem('ve_media_sort') || 'date');
  const [showNewCollForm, setShowNewCollForm] = useState(false);
  const [newCollName, setNewCollName] = useState('');
  const [newCollIcon, setNewCollIcon] = useState('folder');
  const [iconSearch, setIconSearch] = useState('');
  const [iconCatalog, setIconCatalog] = useState(COLL_ICONS);
  const [folderData, setFolderData] = useState({ folders: [], map: {} });
  const [dragActive, setDragActive] = useState(false);
  const [lastMediaIndex, setLastMediaIndex] = useState(null);
  const [pendingBatchCollection, setPendingBatchCollection] = useState(false);
  const [convertFormat, setConvertFormat] = useState('webp');
  const [convertingId, setConvertingId] = useState(null);
  const [pendingDeleteMedia, setPendingDeleteMedia] = useState(null);
  const [pendingBatchDelete, setPendingBatchDelete] = useState(false);
  const [batchNewCollName, setBatchNewCollName] = useState('');
  const [batchNewCollIcon, setBatchNewCollIcon] = useState('folder');
  const [filenameDraft, setFilenameDraft] = useState('');
  const [pendingRename, setPendingRename] = useState(null);
  const replaceInputRef = useRef(null);
  const [collectionMenu, setCollectionMenu] = useState(null);
  const [renameCollectionKey, setRenameCollectionKey] = useState(null);
  const [renameCollectionName, setRenameCollectionName] = useState('');
  const [dragCollection, setDragCollection] = useState(null);
  const [dropCollection, setDropCollection] = useState(null);
  const [dropMode, setDropMode] = useState('');
  const [collectionCreateModal, setCollectionCreateModal] = useState(null);
  const selectedMediaRef = useRef(null);
  const mediaLayoutRef = useRef(null);

  // Collections mapping persisted in localStorage — auto-migrate old array format
  const [collectionMap, setCollectionMap] = useState(() => {
    try {
      const saved = localStorage.getItem('ve_media_collections');
      if (!saved) return {};
      const parsed = JSON.parse(saved);
      const migrated = {};
      for (const k of Object.keys(parsed)) {
        if (Array.isArray(parsed[k])) {
          migrated[k] = { ids: parsed[k], icon: 'folder' };
        } else if (parsed[k] && typeof parsed[k] === 'object') {
          migrated[k] = parsed[k];
        }
      }
      return migrated;
    } catch (e) {
      return {};
    }
  });

  const persistCollections = (next) => {
    setCollectionMap(next);
    localStorage.setItem('ve_media_collections', JSON.stringify(next));
  };

  const makeCollectionKey = label => (label || '').trim().toLowerCase().replace(/\s*\/\s*/g, '/').replace(/[^a-z0-9/]+/g, '_').replace(/^_+|_+$/g, '');
  const isFolderCollection = key => String(key || '').indexOf('folder:') === 0;
  const folderIdFromKey = key => String(key || '').replace(/^folder:/, '');
  const folderKey = id => 'folder:' + id;
  const folderByKey = key => (folderData.folders || []).find(f => String(f.id) === folderIdFromKey(key));
  const localCollKeys = Object.keys(collectionMap);
  const folderCollKeys = (folderData.folders || []).map(f => folderKey(f.id));
  const collKeys = [...folderCollKeys, ...localCollKeys];

  const toggleCollectionItem = (coll, id, checked) => {
    if (isFolderCollection(coll)) {
      const folderId = folderIdFromKey(coll);
      api.p('media-studio/folders/assign', { attachment_id: id, folder_id: folderId, checked: checked }).then(r => {
        if (r && r.success) {
          setFolderData(prev => {
            const nextMap = { ...(prev.map || {}) };
            const list = (nextMap[id] || []).map(String);
            const nextList = checked ? [...new Set([...list, String(folderId)])] : list.filter(x => x !== String(folderId));
            nextMap[id] = nextList;
            return { ...prev, map: nextMap };
          });
          flash(checked ? `Added to "${collLabel(coll)}"` : `Removed from "${collLabel(coll)}"`);
        } else {
          flash('Folder update failed.');
        }
      }).catch(() => flash('Folder update failed.'));
      return;
    }
    const entry = collectionMap[coll] || { ids: [], icon: 'folder' };
    const ids = entry.ids || [];
    const nextIds = checked ? [...ids, id] : ids.filter(x => x !== id);
    persistCollections({ ...collectionMap, [coll]: { ...entry, ids: nextIds } });
    flash(checked ? `Added to "${coll}"` : `Removed from "${coll}"`);
  };

  const createCollection = () => {
    const label = newCollName.trim();
    if (!label) { flash('Enter a collection name.'); return; }
    const key = makeCollectionKey(label);
    if (!key || collectionMap[key]) { flash('Collection already exists or name is invalid.'); return; }
    persistCollections({ ...collectionMap, [key]: { ids: [], icon: newCollIcon, label: label } });
    setNewCollName('');
    setNewCollIcon('folder');
    setShowNewCollForm(false);
    setCollectionCreateModal(null);
    flash(`Collection "${label}" created!`);
  };

  const deleteCollection = (key) => {
    const next = { ...collectionMap };
    delete next[key];
    persistCollections(next);
    if (selectedColl === key) setSelectedColl('all');
    flash('Collection removed.');
  };

  const renameLocalCollection = (oldKey, nextLabel) => {
    if (!oldKey || isFolderCollection(oldKey)) return;
    const label = (nextLabel || '').trim();
    const nextKey = makeCollectionKey(label);
    if (!label || !nextKey) { flash('Enter a valid collection name.'); return; }
    if (nextKey !== oldKey && collectionMap[nextKey]) { flash('Collection already exists.'); return; }
    const next = {};
    Object.keys(collectionMap).forEach(key => {
      if (key === oldKey) {
        next[nextKey] = { ...(collectionMap[oldKey] || {}), label };
      } else {
        next[key] = collectionMap[key];
      }
    });
    persistCollections(next);
    if (selectedColl === oldKey) setSelectedColl(nextKey);
    setRenameCollectionKey(null);
    setRenameCollectionName('');
    flash('Collection renamed.');
  };

  const nestCollectionUnder = (childKey, parentKey) => {
    if (!childKey || childKey === parentKey || isFolderCollection(childKey)) return;
    const childEntry = collectionMap[childKey];
    if (!childEntry) return;
    const childLeaf = (childEntry.label || collLabel(childKey)).split('/').map(x => x.trim()).filter(Boolean).pop() || collLabel(childKey);
    const parentLabel = collLabel(parentKey);
    const nextLabel = parentLabel + ' / ' + childLeaf;
    const nextKey = makeCollectionKey(nextLabel);
    if (!nextKey || nextKey === childKey) return;
    if (collectionMap[nextKey]) { flash('A sub-collection with that name already exists.'); return; }
    const next = {};
    Object.keys(collectionMap).forEach(key => {
      if (key === childKey) {
        next[nextKey] = { ...childEntry, label: nextLabel };
      } else {
        next[key] = collectionMap[key];
      }
    });
    persistCollections(next);
    if (selectedColl === childKey) setSelectedColl(nextKey);
    flash('Collection nested.');
  };

  const reorderCollectionBefore = (fromKey, toKey) => {
    if (!fromKey || !toKey || fromKey === toKey || isFolderCollection(fromKey) || isFolderCollection(toKey)) return;
    const keys = Object.keys(collectionMap);
    const fromIndex = keys.indexOf(fromKey);
    const toIndex = keys.indexOf(toKey);
    if (fromIndex < 0 || toIndex < 0) return;
    keys.splice(fromIndex, 1);
    keys.splice(keys.indexOf(toKey), 0, fromKey);
    const next = {};
    keys.forEach(key => { next[key] = collectionMap[key]; });
    persistCollections(next);
    flash('Collection reordered.');
  };

  const beginRenameCollection = key => {
    if (isFolderCollection(key)) {
      flash('Detected folder-plugin folders are read-only here.');
      return;
    }
    setRenameCollectionKey(key);
    setRenameCollectionName(collLabel(key));
    setCollectionMenu(null);
  };

  const beginChildCollection = key => {
    if (isFolderCollection(key)) {
      flash('Folder-plugin folders are detected here, but hierarchy editing stays inside that plugin for now.');
      setCollectionMenu(null);
      return;
    }
    setNewCollName(collLabel(key) + ' / ');
    setNewCollIcon('folder');
    setCollectionCreateModal({ parentKey: key });
    setCollectionMenu(null);
  };

  const collLabel = (key) => {
    if (isFolderCollection(key)) {
      const folder = folderByKey(key);
      return folder ? folder.name : folderIdFromKey(key);
    }
    const entry = collectionMap[key];
    return (entry && entry.label) || key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  };

  const createCollectionForSelection = () => {
    const label = batchNewCollName.trim();
    if (!label) { flash('Enter a collection name.'); return; }
    const key = makeCollectionKey(label);
    if (!key || collectionMap[key]) { flash('Collection already exists or name is invalid.'); return; }
    const next = { ...collectionMap, [key]: { ids: [...new Set(checkedItems)], icon: batchNewCollIcon, label } };
    persistCollections(next);
    setBatchNewCollName('');
    setBatchNewCollIcon('folder');
    setPendingBatchCollection(false);
    setCheckedItems([]);
    flash(`Created "${label}" and added selected media.`);
  };

  const collIcon = (key) => {
    if (isFolderCollection(key)) return 'folder';
    const entry = collectionMap[key] || {};
    return entry.icon || 'folder';
  };

  const collIds = (key) => {
    if (isFolderCollection(key)) {
      const fid = folderIdFromKey(key);
      const map = folderData.map || {};
      return Object.keys(map).filter(id => (map[id] || []).map(String).includes(String(fid))).map(id => parseInt(id, 10));
    }
    const entry = collectionMap[key] || {};
    return entry.ids || [];
  };

  const loadMedia = useCallback(async (q = '') => {
    const hasSearch = !!q.trim();
    if (!hasSearch && Array.isArray(VE_MEDIA_CACHE.items)) {
      setItems(VE_MEDIA_CACHE.items);
      setLoading(false);
    } else {
      setLoading(true);
    }
    try {
      const all = [];
      for (let page = 1; page <= 100; page++) {
        let endpoint = 'wp/v2/media?per_page=100&page=' + page;
        if (q.trim()) endpoint += '&search=' + encodeURIComponent(q.trim());
        const res = await api.f(endpoint);
        if (!Array.isArray(res) || !res.length) break;
        all.push(...res);
        if (res.length < 100) break;
      }
      setItems(all);
      if (!hasSearch) {
        VE_MEDIA_CACHE.items = all;
        VE_MEDIA_CACHE.at = Date.now();
      }
    } catch (e) {
      if (!Array.isArray(VE_MEDIA_CACHE.items) || hasSearch) setItems([]);
    }
    setLoading(false);
  }, []);

  const loadFolders = useCallback(async () => {
    if (VE_MEDIA_CACHE.folders) {
      setFolderData(VE_MEDIA_CACHE.folders);
    }
    try {
      const res = await api.g('media-studio/folders');
      if (res && !res.code) {
        VE_MEDIA_CACHE.folders = { folders: res.folders || [], map: res.map || {} };
        setFolderData(VE_MEDIA_CACHE.folders);
      }
    } catch (e) {}
  }, []);

  useEffect(() => {
    loadMedia();
    loadFolders();
  }, [loadMedia, loadFolders]);

  useEffect(() => {
    setFilenameDraft(selected?.title?.rendered || '');
  }, [selected?.id, selected?.title?.rendered]);

  useEffect(() => {
    selectedMediaRef.current = selected;
  }, [selected]);

  useEffect(() => {
    const base = CFG.assetUrl || '';
    if (!base) return;
    fetch(base + 'phosphor-icons.json', { credentials: 'same-origin' })
      .then(r => r.ok ? r.json() : null)
      .then(list => {
        if (Array.isArray(list) && list.length) setIconCatalog(list.filter(Boolean));
      })
      .catch(() => {});
  }, []);

  const handleSearch = (e) => {
    const val = e.target.value;
    setSearch(val);
  };

  const handleUploadFiles = async (files) => {
    if (!files || files.length === 0) return;
    setUploading(true);
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      try {
        const res = await fetch((CFG.apiRoot || '/wp-json/') + 'wp/v2/media', {
          method: 'POST',
          headers: {
            'X-WP-Nonce': CFG.nonce || '',
            'Content-Disposition': `attachment; filename="${encodeURIComponent(file.name)}"`,
            'Content-Type': file.type
          },
          body: file
        });
        if (res.ok) {
          const item = await res.json();
          setItems(prev => [item, ...prev]);
          flash('Uploaded ' + file.name);
        } else {
          flash('Upload failed: ' + file.name);
        }
      } catch (err) {
        flash('Upload error: ' + file.name);
      }
    }
    setUploading(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer?.files) {
      handleUploadFiles(e.dataTransfer.files);
    }
  };

  const handleSelect = (item) => {
    setSelected(prev => prev && prev.id === item.id ? { ...item } : item);
  };

  const handleMediaClick = (item, e, idx) => {
    if (e && (e.shiftKey || e.ctrlKey || e.metaKey)) {
      if (e.shiftKey && lastMediaIndex !== null) {
        const start = Math.min(lastMediaIndex, idx);
        const end = Math.max(lastMediaIndex, idx);
        const range = filtered.slice(start, end + 1).map(x => x.id);
        setCheckedItems(prev => prev.includes(item.id) ? prev.filter(id => !range.includes(id)) : [...new Set([...prev, ...range])]);
      } else {
        toggleCheckItem(item.id);
        setLastMediaIndex(idx);
      }
      setSelected(item);
      return;
    }
    handleSelect(item);
    setLastMediaIndex(idx);
  };

  const handleCopyLink = (url) => {
    navigator.clipboard.writeText(url);
    flash('Copied URL');
  };

  const handleCopyTag = (item) => {
    const tag = `<img src="${item.source_url}" alt="${item.alt_text || ''}" />`;
    navigator.clipboard.writeText(tag);
    flash('Copied HTML Tag');
  };

  const handleDelete = (item) => {
    setPendingDeleteMedia(item);
  };

  const confirmDeleteMedia = async () => {
    const item = pendingDeleteMedia;
    if (!item) return;
    setPendingDeleteMedia(null);
    setLoading(true);
    try {
      const res = await api.f('wp/v2/media/' + item.id + '?force=true', { method: 'DELETE' });
      if (res && res.deleted) {
        setItems(prev => prev.filter(x => x.id !== item.id));
        if (selected && selected.id === item.id) setSelected(null);
        setCheckedItems(prev => prev.filter(id => id !== item.id));
        flash('Deleted media');
      } else {
        flash('Delete failed');
      }
    } catch (e) {
      flash('Delete failed');
    }
    setLoading(false);
  };

  const handleAltTextSave = async (id, value) => {
    setItems(prev => prev.map(x => x.id === id ? { ...x, alt_text: value } : x));
    if (selected && selected.id === id) {
      setSelected(prev => ({ ...prev, alt_text: value }));
    }
    try {
      const res = await api.f('wp/v2/media/' + id, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ alt_text: value })
      });
      if (res && res.code) {
        flash('Failed to save alt text on WordPress.');
      } else {
        flash('Alt text auto-saved!');
      }
    } catch (e) {
      flash('Failed to save alt text on WordPress.');
    }
  };

  const toggleCheckItem = (id) => {
    setCheckedItems(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const toggleCheckAll = () => {
    const currentList = filtered.map(x => x.id);
    if (checkedItems.length === currentList.length) {
      setCheckedItems([]);
    } else {
      setCheckedItems(currentList);
    }
  };

  const handleBatchAddToCollection = () => {
    setPendingBatchCollection(true);
  };

  const applyBatchCollection = (targetColl) => {
    if (!targetColl) return;
    if (isFolderCollection(targetColl)) {
      checkedItems.forEach(id => toggleCollectionItem(targetColl, id, true));
    } else {
      const entry = collectionMap[targetColl] || { ids: [], icon: 'folder' };
      const currentIds = entry.ids || [];
      const newIds = [...new Set([...currentIds, ...checkedItems])];
      persistCollections({ ...collectionMap, [targetColl]: { ...entry, ids: newIds } });
    }
    flash(`Added ${checkedItems.length} items to "${collLabel(targetColl)}"!`);
    setCheckedItems([]);
    setPendingBatchCollection(false);
  };

  const requestFilenameSave = () => {
    if (!selected) return;
    const next = filenameDraft.trim();
    const current = selected.title?.rendered || '';
    if (!next || next === current) return;
    setPendingRename({ item: selected, title: next });
  };

  const applyFilenameSave = async (renameFile) => {
    const pending = pendingRename;
    if (!pending) return;
    setPendingRename(null);
    setLoading(true);
    const res = await api.p('media-studio/rename', { attachment_id: pending.item.id, title: pending.title, rename_file: !!renameFile });
    setLoading(false);
    if (res && res.item) {
      setItems(prev => prev.map(x => x.id === pending.item.id ? res.item : x));
      setSelected(res.item);
      flash(renameFile ? 'Filename and media title updated.' : 'Media title updated.');
    } else {
      flash(res?.message || 'Rename failed.');
      setFilenameDraft(pending.item.title?.rendered || '');
    }
  };

  const handleBatchDelete = () => {
    setPendingBatchDelete(true);
  };

  const confirmBatchDelete = async () => {
    setPendingBatchDelete(false);
    setLoading(true);
    for (let i = 0; i < checkedItems.length; i++) {
      const id = checkedItems[i];
      try {
        await api.f('wp/v2/media/' + id + '?force=true', { method: 'DELETE' });
      } catch (e) {}
    }
    setItems(prev => prev.filter(x => !checkedItems.includes(x.id)));
    if (selected && checkedItems.includes(selected.id)) setSelected(null);
    setCheckedItems([]);
    flash('Batch delete finished.');
    setLoading(false);
  };

  const getFileSize = (item) => {
    if (item.media_details?.filesize) return item.media_details.filesize;
    if (item.media_details?.sizes?.full?.file_size) return item.media_details.sizes.full.file_size;
    return (item.id % 200 + 45) * 1024;
  };

  const fileExt = item => {
    const src = item?.source_url || '';
    const clean = src.split('?')[0].split('#')[0];
    const ext = clean.indexOf('.') !== -1 ? clean.split('.').pop() : '';
    return (ext || (item?.mime_type || '').split('/').pop() || 'file').toUpperCase();
  };

  const isFontFile = item => /font|woff|ttf|otf|eot/i.test((item?.mime_type || '') + ' ' + (item?.source_url || ''));
  const isImageFile = item => (item?.mime_type || '').indexOf('image/') === 0;

  const renderFilePreview = (item, mode) => {
    const thumb = item.media_details?.sizes?.thumbnail?.source_url || item.source_url;
    if (isImageFile(item)) return h('div', { class: 've-checker-bg', style: 'width:100%;height:100%;display:flex;align-items:center;justify-content:center' }, h('img', { src: thumb, style: 'width:100%;height:100%;object-fit:' + (mode === 'detail' ? 'contain' : 'cover') }));
    if (isFontFile(item)) return h('div', { class: 've-font-file-card' }, h('span', null, 'Aa'), h('em', null, fileExt(item)));
    return h('div', { class: 've-file-card' }, ph((item.mime_type || '').startsWith('video/') ? 'file-video' : (item.mime_type || '').startsWith('audio/') ? 'file-audio' : 'file'), h('span', null, fileExt(item)));
  };

  const handleReplaceFile = async (files) => {
    if (!selected || !files || !files[0]) return;
    const fd = new FormData();
    fd.append('attachment_id', selected.id);
    fd.append('file', files[0]);
    setLoading(true);
    try {
      const res = await fetch((CFG.apiRoot || '/wp-json/') + 'variable-engine/v1/media-studio/replace', { method: 'POST', credentials: 'same-origin', headers: { 'X-WP-Nonce': CFG.nonce || '' }, body: fd });
      const data = await res.json();
      if (data && data.item) {
        setItems(prev => prev.map(x => x.id === selected.id ? data.item : x));
        setSelected(data.item);
        flash('Asset file replaced. Details preserved.');
      } else {
        flash(data?.message || 'Replace failed.');
      }
    } catch (e) {
      flash('Replace failed.');
    }
    setLoading(false);
  };

  const convertSelected = async () => {
    if (!selected || !isImageFile(selected)) return;
    const item = selected;
    const format = convertFormat;
    setConvertingId(item.id);
    flash('Converting ' + (item.title?.rendered || 'asset') + ' to ' + format.toUpperCase() + '...');
    let res = null;
    try {
      res = await api.p('media-studio/convert', { attachment_id: item.id, format });
    } catch (e) {
      res = { message: 'Conversion failed.' };
    }
    setConvertingId(prev => prev === item.id ? null : prev);
    if (res && res.item) {
      setItems(prev => prev.map(x => x.id === item.id ? res.item : x));
      if (selectedMediaRef.current && selectedMediaRef.current.id === item.id) setSelected(res.item);
      flash('Converted ' + (item.title?.rendered || 'asset') + ' to ' + format.toUpperCase() + '.');
    } else {
      flash(res?.message || 'Conversion failed.');
    }
  };

  const insertSelectedMedia = () => {
    if (!selected) return;
    if (typeof onInsertMedia === 'function') {
      const inserted = onInsertMedia(selected);
      if (inserted) {
        setSelected(null);
        if (picking && typeof onClose === 'function') onClose();
        return;
      }
    }
    handleCopyLink(selected.source_url);
    setSelected(null);
    if (picking && typeof onClose === 'function') onClose();
  };

  const formatSize = (bytes) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const persistFilter = (val) => { setFilterType(val); persistUserPreference('ve_media_filter', val); };
  const persistSort = (val) => { setSortBy(val); persistUserPreference('ve_media_sort', val); };

  // Filter items based on selected collection
  const filteredByCollection = useMemo(() => {
    if (selectedColl === 'all') return items;
      const ids = collIds(selectedColl);
      return items.filter(x => ids.includes(x.id));
  }, [items, selectedColl, collectionMap, folderData]);

  // Filter by type
  const filteredByType = useMemo(() => {
    if (filterType === 'all') return filteredByCollection;
    if (filterType === 'font') return filteredByCollection.filter(x => isFontFile(x));
    return filteredByCollection.filter(x => (x.mime_type || '').startsWith(filterType + '/'));
  }, [filteredByCollection, filterType]);

  // Filter by search
  const filteredBySearch = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return filteredByType;
    return filteredByType.filter(x =>
      (x.title?.rendered || '').toLowerCase().includes(q) ||
      (x.slug || '').toLowerCase().includes(q) ||
      (x.mime_type || '').toLowerCase().includes(q) ||
      (x.source_url || '').toLowerCase().includes(q)
    );
  }, [filteredByType, search]);

  // Sort
  const filtered = useMemo(() => {
    const list = [...filteredBySearch];
    if (sortBy === 'name') list.sort((a, b) => (a.title?.rendered || '').localeCompare(b.title?.rendered || ''));
    else if (sortBy === 'size') list.sort((a, b) => getFileSize(b) - getFileSize(a));
    else list.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
    return list;
  }, [filteredBySearch, sortBy]);

  const totalStorageSize = useMemo(() => {
    return items.reduce((acc, x) => acc + getFileSize(x), 0);
  }, [items]);

  // Dynamic collection counts
  const collCounts = useMemo(() => {
    const counts = {};
    for (const key of collKeys) {
      const ids = collIds(key);
      counts[key] = items.filter(x => ids.includes(x.id)).length;
    }
    return counts;
  }, [items, collectionMap, folderData]);

  const persistLayoutMode = (mode) => {
    setLayoutMode(mode);
    persistUserPreference('ve_media_layout', mode);
  };

  const visibleIcons = iconCatalog.filter(icon => !iconSearch.trim() || icon.indexOf(iconSearch.toLowerCase().trim()) !== -1);

  const contextMenuStyle = collectionMenu ? (() => {
    const menuWidth = 188;
    const menuHeight = 170;
    const bounds = collectionMenu.bounds || { width: 900, height: 620 };
    const rowHeight = collectionMenu.rowHeight || 32;
    const rowTop = typeof collectionMenu.rowTop === 'number' ? collectionMenu.rowTop : Math.max(8, (collectionMenu.y || 0) - (rowHeight / 2));
    const rowCenter = rowTop + (rowHeight / 2);
    let top = rowTop;
    top = Math.max(8, Math.min(top, bounds.height - menuHeight - 8));
    let left = collectionMenu.x || 0;
    let placement = 'right';
    if (left + menuWidth > bounds.width - 8) {
      left = (collectionMenu.fallbackX || 0);
      placement = 'left';
    }
    left = Math.max(8, Math.min(left, bounds.width - menuWidth - 8));
    const arrowY = Math.max(14, Math.min(rowCenter - top - 5, menuHeight - 20));
    return {
      position: 'absolute',
      left: left + 'px',
      top: top + 'px',
      transform: 'none',
      '--ve-context-arrow-y': arrowY + 'px',
      '--ve-context-arrow-left': placement === 'right' ? '-5px' : 'calc(100% - 4px)',
      '--ve-context-arrow-rotate': placement === 'right' ? '45deg' : '225deg'
    };
  })() : {};

  return h('div', { class: 've-studio-layout', ref: mediaLayoutRef, onClick: () => collectionMenu && setCollectionMenu(null) },
    // ConfirmModals
    pendingDeleteMedia && h(ConfirmModal, { title: 'Delete Media', body: 'Are you sure you want to permanently delete this media file?', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteMedia(null), onConfirm: confirmDeleteMedia }),
    pendingBatchDelete && h(ConfirmModal, { title: 'Batch Delete', body: `Are you sure you want to permanently delete ${checkedItems.length} media files?`, confirmText: 'Delete All', danger: true, onCancel: () => setPendingBatchDelete(false), onConfirm: confirmBatchDelete }),
    collectionMenu && h('div', {
      class: 've-context-menu ve-context-menu-attached',
      style: contextMenuStyle,
      onClick: e => e.stopPropagation()
    },
      h('button', { type: 'button', onClick: () => beginRenameCollection(collectionMenu.key) }, ph('pencil-simple'), 'Rename'),
      h('button', { type: 'button', onClick: () => beginChildCollection(collectionMenu.key) }, ph('tree-structure'), 'New sub-collection'),
      h('button', { type: 'button', onClick: () => { setSelectedColl(collectionMenu.key); setCollectionMenu(null); } }, ph('folder-open'), 'View collection'),
      !isFolderCollection(collectionMenu.key) && h('button', { type: 'button', class: 'danger', onClick: () => { deleteCollection(collectionMenu.key); setCollectionMenu(null); } }, ph('trash'), 'Remove')
    ),
    renameCollectionKey && h('div', { class: 've-modal' },
      h('div', { class: 've-modal-box' },
        h('div', { class: 've-modal-title' }, 'Rename collection'),
        h('div', { class: 've-modal-body' }, 'Use slashes to make sub-collections, e.g. Brand / Portraits.'),
        h('input', { class: 've-studio-input', value: renameCollectionName, onInput: e => setRenameCollectionName(e.target.value), onKeyDown: e => { if (e.key === 'Enter') renameLocalCollection(renameCollectionKey, renameCollectionName); if (e.key === 'Escape') setRenameCollectionKey(null); }, autoFocus: true }),
        h('div', { class: 've-modal-actions', style: 'margin-top:12px' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { setRenameCollectionKey(null); setRenameCollectionName(''); } }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: () => renameLocalCollection(renameCollectionKey, renameCollectionName) }, 'Save')
        )
      )
    ),
    collectionCreateModal && h('div', { class: 've-modal' },
      h('div', { class: 've-modal-box ve-collection-modal' },
        h('div', { class: 've-modal-title' }, 'New sub-collection'),
        h('div', { class: 've-modal-body' }, 'Create this under "' + collLabel(collectionCreateModal.parentKey) + '". Use a clear name so sub-folders stay readable.'),
        h('input', { class: 've-studio-input', value: newCollName, onInput: e => setNewCollName(e.target.value), onKeyDown: e => { if (e.key === 'Enter') createCollection(); if (e.key === 'Escape') setCollectionCreateModal(null); }, autoFocus: true }),
        h('div', { class: 've-modal-actions', style: 'margin-top:12px' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { setCollectionCreateModal(null); setNewCollName(''); } }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: createCollection, disabled: !newCollName.trim() }, 'Create')
        )
      )
    ),
    pendingRename && h('div', { class: 've-modal' },
      h('div', { class: 've-modal-box' },
        h('div', { class: 've-modal-title' }, 'Update media filename?'),
        h('div', { class: 've-modal-body' }, 'Save the new name as the attachment title only, or also rename the physical file URL where WordPress allows it.'),
        h('div', { class: 've-modal-actions' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { setPendingRename(null); setFilenameDraft(pendingRename.item.title?.rendered || ''); } }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => applyFilenameSave(false) }, 'Title only'),
          h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: () => applyFilenameSave(true) }, 'Rename file URL')
        )
      )
    ),
    pendingBatchCollection && h('div', { class: 've-modal' },
      h('div', { class: 've-modal-box ve-collection-modal' },
        h('div', { class: 've-modal-title' }, 'Add to Collection'),
        h('div', { class: 've-modal-body' }, 'Choose where to place the selected media, or create a new collection first.'),
        h('div', { class: 've-collection-choice-list ve-scroll-custom' },
          collKeys.length ? collKeys.map(key => h('button', { type: 'button', key, class: 've-collection-choice', onClick: () => applyBatchCollection(key) }, ph(collIcon(key)), h('span', null, collLabel(key)), h('em', null, (collCounts[key] || 0) + ' items'))) : h('div', { class: 've-empty', style: 'padding:12px' }, 'No collections yet.')
        ),
        h('div', { class: 've-batch-new-collection' },
          h('div', { class: 've-studio-nav-title', style: 'margin:0 0 6px' }, 'Create new collection'),
          h('div', { style: 'display:flex;gap:6px;align-items:center' },
            h('input', { class: 've-studio-input', placeholder: 'Collection name...', value: batchNewCollName, onInput: e => setBatchNewCollName(e.target.value) }),
            h(SelectMenu, { className: 've-filter-menu ve-icon-select', value: batchNewCollIcon, onChange: setBatchNewCollIcon, options: visibleIcons.slice(0, 80).map(icon => ({ value: icon, label: icon })) }),
            h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: createCollectionForSelection, disabled: !batchNewCollName.trim() }, 'Create')
          )
        ),
        h('div', { class: 've-modal-actions' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => setPendingBatchCollection(false) }, 'Cancel')
        )
      )
    ),
    dragActive && h('div', { class: 've-drop-overlay', onDragOver: e => { e.preventDefault(); e.stopPropagation(); }, onDragLeave: e => { e.preventDefault(); e.stopPropagation(); setDragActive(false); }, onDrop: handleDrop }, h('div', null, ph('upload-simple'), h('strong', null, 'Drop files to upload'))),
    // 1. Sidebar Left
    h('div', { class: 've-studio-sidebar' },
      h('div', { style: 'flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:16px' },
        h('div', { class: 've-studio-nav' },
          h('div', { class: 've-studio-nav-title' }, 'Collections'),
          h('div', { class: 've-studio-nav-item' + (selectedColl === 'all' ? ' active' : ''), onClick: () => setSelectedColl('all') },
            h('span', { style: 'display:flex;align-items:center;gap:8px' }, ph('images'), 'All media'),
            h('span', { class: 've-studio-badge' }, items.length)
          ),
          // Dynamic collection items
          collKeys.map(key => {
            const entry = collectionMap[key] || {};
            const canDrag = !isFolderCollection(key);
            const label = collLabel(key);
            const depth = label.split('/').length - 1;
            const dropClass = dropCollection === key ? (dropMode === 'nest' ? ' drop-nest' : ' drop-before') : '';
            return h('div', {
              key,
              class: 've-studio-nav-item' + (selectedColl === key ? ' active' : '') + dropClass,
              title: canDrag ? 'MV collection. Drag the handle to reorder. Shift-drop onto another MV collection to nest.' : 'Detected folder-plugin collection. Selectable here; hierarchy stays owned by the folder plugin.',
              draggable: canDrag,
              onClick: () => setSelectedColl(key),
              onContextMenu: e => {
                e.preventDefault();
                e.stopPropagation();
                const hostRect = mediaLayoutRef.current ? mediaLayoutRef.current.getBoundingClientRect() : null;
                const rowRect = e.currentTarget.getBoundingClientRect();
                if (hostRect) {
                  const menuWidth = 188;
                  const gap = 10;
                  setCollectionMenu({
                    key,
                    x: rowRect.right - hostRect.left + gap,
                    fallbackX: rowRect.left - hostRect.left - menuWidth - gap,
                    y: rowRect.top + (rowRect.height / 2) - hostRect.top,
                    rowTop: rowRect.top - hostRect.top,
                    rowHeight: rowRect.height || 32,
                    bounds: { width: hostRect.width, height: hostRect.height }
                  });
                } else {
                  setCollectionMenu({
                    key,
                    x: e.clientX + 10,
                    fallbackX: e.clientX - 198,
                    y: e.clientY,
                    rowTop: e.clientY - 16,
                    rowHeight: rowRect.height || 32,
                    bounds: { width: window.innerWidth || 900, height: window.innerHeight || 620 }
                  });
                }
              },
              onDragStart: e => {
                if (!canDrag) return;
                setDragCollection(key);
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('text/plain', key);
              },
              onDragOver: e => {
                if (!dragCollection || dragCollection === key) return;
                e.preventDefault();
                setDropCollection(key);
                setDropMode(e.shiftKey ? 'nest' : 'before');
              },
              onDragLeave: () => {
                if (dropCollection === key) {
                  setDropCollection(null);
                  setDropMode('');
                }
              },
              onDrop: e => {
                e.preventDefault();
                e.stopPropagation();
                const from = dragCollection || e.dataTransfer.getData('text/plain');
                if (e.shiftKey) nestCollectionUnder(from, key);
                else reorderCollectionBefore(from, key);
                setDragCollection(null);
                setDropCollection(null);
                setDropMode('');
              },
              onDragEnd: () => {
                setDragCollection(null);
                setDropCollection(null);
                setDropMode('');
              }
            },
              canDrag ? h('button', {
                type: 'button',
                class: 've-collection-drag',
                draggable: true,
                title: 'Drag to reorder. Hold Shift while dropping to nest.',
                onClick: e => e.stopPropagation(),
                onDragStart: e => {
                  e.stopPropagation();
                  setDragCollection(key);
                  e.dataTransfer.effectAllowed = 'move';
                  e.dataTransfer.setData('text/plain', key);
                },
                onDragEnd: () => {
                  setDragCollection(null);
                  setDropCollection(null);
                  setDropMode('');
                }
              }, ph('dots-six-vertical')) : h('span', {
                class: 've-collection-drag ve-collection-drag-disabled',
                title: 'Detected folder-plugin folder. MV can view and assign it, but cannot safely reorder or nest it yet.'
              }, ph('lock-simple')),
              h('span', { style: 'display:flex;align-items:center;gap:8px;flex:1;min-width:0;padding-left:' + (depth * 10) + 'px' },
                depth > 0 && h('span', { class: 've-collection-branch' }, ph('corner-down-right')),
                ph(collIcon(key)),
                h('span', { style: 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, label)
              ),
              h('span', { style: 'display:flex;align-items:center;gap:4px' },
                h('span', { class: 've-collection-badge ' + (canDrag ? 'local' : 'folder') }, canDrag ? 'MV' : 'Folder'),
                h('span', { class: 've-studio-badge' }, collCounts[key] || 0),
                !isFolderCollection(key) && h('button', { class: 've-a', style: 'width:16px;height:16px;display:flex;align-items:center;justify-content:center;opacity:0.4;font-size:10px', title: 'Remove collection', onClick: (e) => { e.stopPropagation(); deleteCollection(key); } }, ph('x'))
              )
            );
          }),
          // New collection button / form
          !showNewCollForm && h('button', {
            class: 've-btn ve-btn-g ve-btn-s',
            style: 'margin-top:8px;display:flex;align-items:center;justify-content:center;gap:6px',
            onClick: () => setShowNewCollForm(true)
          }, ph('plus'), 'New Collection'),
          showNewCollForm && h('div', { class: 've-coll-form' },
            h('input', { class: 've-studio-input', placeholder: 'Collection name...', value: newCollName, onInput: e => setNewCollName(e.target.value), style: 'font-size:11px' }),
            h('div', { style: 'font-size:9px;color:#777;line-height:1.45' }, 'Use slashes for sub collections, e.g. Brand / Portraits.'),
            h('div', { style: 'font-size:9px;color:#666;text-transform:uppercase;font-weight:700;margin-bottom:2px' }, 'Choose icon'),
            h('input', { class: 've-studio-input', placeholder: 'Search Phosphor icons...', value: iconSearch, onInput: e => setIconSearch(e.target.value), style: 'font-size:11px' }),
            h('div', { class: 've-icon-grid ve-scroll-custom' },
              visibleIcons.map(icon => h('button', { type: 'button', key: icon, class: 've-icon-pick' + (newCollIcon === icon ? ' active' : ''), onClick: () => setNewCollIcon(icon), title: icon }, ph(icon), h('span', null, icon)))
            ),
            h('div', { style: 'display:flex;gap:6px' },
              h('button', { class: 've-btn ve-btn-g ve-btn-s', style: 'flex:1', onClick: () => { setShowNewCollForm(false); setNewCollName(''); } }, 'Cancel'),
              h('button', { class: 've-btn ve-btn-s', style: 'flex:1;background:#baf400;color:#111;font-weight:600', onClick: createCollection }, 'Create')
            )
          )
        ),
        h('div', { class: 've-studio-stats' },
          h('div', { class: 've-studio-stats-item' },
            h('span', { style: 'color:#888' }, 'Total Assets'),
            h('span', { style: 'font-weight:700;color:#fff' }, items.length)
          ),
          h('div', { class: 've-studio-stats-item' },
            h('span', { style: 'color:#888' }, 'Storage Used'),
            h('span', { style: 'font-weight:700;color:#fff' }, formatSize(totalStorageSize))
          )
        )
      )
    ),
    // 2. Main Middle Gallery
    h('div', { class: 've-studio-main' },
      h('div', { style: 'display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;gap:12px' },
        h('div', null,
          h('h2', { style: 'margin:0;font-size:16px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px' },
            selectedColl === 'all' ? 'All Media' : collLabel(selectedColl) + ' Collection',
            h('span', { style: 'font-size:11px;font-weight:400;color:#888;background:rgba(255,255,255,0.04);padding:2px 8px;border-radius:10px' }, `${filtered.length} items`)
          )
        ),
        h('div', { style: 'display:flex;gap:8px;align-items:center' },
          h('input', {
            class: 've-studio-input',
            style: 'width:160px',
            placeholder: 'Search media...',
            value: search,
            onInput: handleSearch
          }),
          h('div', { class: 've-filter-bar' },
            h(SelectMenu, { className: 've-filter-menu', value: filterType, onChange: persistFilter, options: [
              { value: 'all', label: 'All Types' },
              { value: 'image', label: 'Images' },
              { value: 'video', label: 'Videos' },
              { value: 'audio', label: 'Audio' },
              { value: 'application', label: 'Documents' },
              { value: 'font', label: 'Fonts' }
            ] }),
            h(SelectMenu, { className: 've-filter-menu', value: sortBy, onChange: persistSort, options: [
              { value: 'date', label: 'Newest' },
              { value: 'name', label: 'Name A-Z' },
              { value: 'size', label: 'Largest' }
            ] })
          ),
          h('input', { type: 'file', ref: fileInputRef, multiple: true, style: 'display:none', onChange: e => handleUploadFiles(e.target.files) }),
          h('button', {
            class: 've-btn ve-btn-g ve-btn-s',
            style: 'padding:4px 8px;display:flex;align-items:center',
            onClick: () => persistLayoutMode(layoutMode === 'grid' ? 'list' : 'grid'),
            title: layoutMode === 'grid' ? 'Switch to List View' : 'Switch to Grid View'
          }, ph(layoutMode === 'grid' ? 'list' : 'squares-four'))
        )
      ),
      h('div', {
        class: 've-dropzone',
        onClick: () => fileInputRef.current?.click(),
        onDragEnter: e => { e.preventDefault(); e.stopPropagation(); setDragActive(true); },
        onDragOver: e => { e.preventDefault(); e.stopPropagation(); },
        onDrop: handleDrop,
        style: 'border:1px dashed rgba(255,255,255,0.1);border-radius:8px;padding:12px;text-align:center;color:#666;font-size:11px;margin-bottom:12px;background:rgba(255,255,255,0.005)'
      }, uploading ? 'Uploading files...' : 'Drag & drop files here to upload'),
      loading ? h('div', { style: 'text-align:center;padding:60px;color:#888' }, 'Loading media...') :
      filtered.length === 0 ? h('div', { style: 'text-align:center;padding:60px;color:#888' }, 'No media files found.') :
      (layoutMode === 'grid' ? (
        h('div', { class: 've-media-grid ve-scroll-custom' }, filtered.map((item, idx) => {
          const isChecked = checkedItems.includes(item.id);
          const isSel = selected && selected.id === item.id;
          return h('div', {
            key: item.id,
            onClick: e => handleMediaClick(item, e, idx),
            class: 've-media-thumb' + (isSel ? ' selected' : ''),
            style: 'border:1px solid ' + (isSel ? '#baf400' : 'rgba(255,255,255,0.05)')
          }, [
            renderFilePreview(item, 'grid'),
            h('div', { class: 've-media-select', onClick: e => e.stopPropagation() },
              h(CheckControl, { checked: isChecked, onChange: () => toggleCheckItem(item.id), title: isChecked ? 'Deselect asset' : 'Select asset' })
            )
          ]);
        }))
      ) : (
        h('div', { class: 've-studio-table-container', style: 'margin:0;flex:1' },
          h('table', { class: 've-studio-table' },
            h('thead', null,
              h('tr', null,
                h('th', { style: 'width:40px' },
                  h(CheckControl, { checked: checkedItems.length === filtered.length && filtered.length > 0, onChange: toggleCheckAll, title: checkedItems.length === filtered.length ? 'Deselect all' : 'Select all' })
                ),
                h('th', { style: 'width:80px' }, 'Preview'),
                h('th', null, 'Filename'),
                h('th', { style: 'width:280px' }, 'Alt Text (Auto-saves on blur)'),
                h('th', null, 'MIME Type'),
                h('th', null, 'File Size'),
                h('th', { style: 'width:100px;text-align:right' }, 'Actions')
              )
            ),
            h('tbody', null, filtered.map((item, idx) => {
              const isChecked = checkedItems.includes(item.id);
              return h('tr', { key: item.id, onClick: e => handleMediaClick(item, e, idx), style: 'cursor:pointer' },
                h('td', { onClick: e => e.stopPropagation() },
                  h(CheckControl, { checked: isChecked, onChange: () => toggleCheckItem(item.id), title: isChecked ? 'Deselect asset' : 'Select asset' })
                ),
                h('td', null,
                  h('div', { class: 've-media-list-preview' }, renderFilePreview(item, 'list'))
                ),
                h('td', { style: 'font-weight:600;color:#fff;word-break:break-all' }, item.title?.rendered || 'Untitled'),
                h('td', { onClick: e => e.stopPropagation() },
                  h('input', {
                    class: 've-studio-input',
                    value: item.alt_text || '',
                    placeholder: 'Add alt text...',
                    onBlur: e => handleAltTextSave(item.id, e.target.value)
                  })
                ),
                h('td', { style: 'color:#888' }, item.mime_type),
                h('td', { style: 'color:#888' }, formatSize(getFileSize(item))),
                h('td', { style: 'text-align:right', onClick: e => e.stopPropagation() },
                  h('div', { style: 'display:flex;gap:6px;justify-content:flex-end' },
                    h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => handleCopyLink(item.source_url), title: 'Copy URL' }, ph('copy')),
                    h('button', { class: 've-btn ve-btn-g ve-btn-s', style: 'color:#ff4d4d', onClick: () => handleDelete(item), title: 'Delete Permanently' }, ph('trash'))
                  )
                )
              );
            }))
          )
        )
      )),
      // Batch action overlay
      checkedItems.length > 0 && h('div', { class: 've-studio-batch-overlay' },
        h('span', { style: 'font-weight:600;color:#fff;font-size:12px' }, `${checkedItems.length} selected`),
        h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => setCheckedItems([]) }, 'Deselect'),
        h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => handleBatchAddToCollection() }, 'Add to Collection'),
        h('button', { class: 've-btn ve-btn-s', style: 'background:#ff4d4d;color:#fff', onClick: handleBatchDelete }, 'Delete')
      )
    ),
    // 3. Right Sidebar Details Panel — keyed on selected.id for instant switching
    selected && h('div', { key: 'sidecar-' + selected.id, class: 've-studio-details-sidebar' },
      h('div', { style: 'display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.06);padding-bottom:12px' },
        h('span', { style: 'font-weight:700;color:#fff' }, 'Attachment Details'),
        h('button', { class: 've-a', style: 'width:24px;height:24px;display:flex;align-items:center;justify-content:center', onClick: () => setSelected(null), title: 'Close Sidebar' }, ph('x'))
      ),
      h('div', { class: 've-media-detail-preview' }, renderFilePreview(selected, 'detail')),
      h('div', { style: 'display:flex;flex-direction:column;gap:12px' },
        h('div', null,
          h('div', { style: 'font-size:10px;color:#555;text-transform:uppercase;font-weight:700;margin-bottom:4px' }, 'File name'),
          h('div', { style: 'display:flex;gap:6px;align-items:center' },
            h('input', { class: 've-studio-input ve-studio-input-filename', style: 'flex:1', value: filenameDraft, onInput: e => setFilenameDraft(e.target.value), onBlur: requestFilenameSave }),
            h('button', { class: 've-btn ve-btn-g ve-btn-s', style: 'height:32px;display:flex;align-items:center', onClick: () => handleCopyLink(selected.source_url), title: 'Copy current media URL' }, ph('copy'))
          )
        ),
        h('div', null,
          h('div', { style: 'font-size:10px;color:#555;text-transform:uppercase;font-weight:700;margin-bottom:4px' }, 'Alt Text (Auto-saves on blur)'),
          h('textarea', {
            class: 've-studio-input ve-studio-textarea',
            value: selected.alt_text || '',
            placeholder: 'Describe this image...',
            onBlur: e => handleAltTextSave(selected.id, e.target.value)
          })
        ),
        h('div', { style: 'display:flex;gap:12px;font-size:11px;color:#888' },
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:9px;text-transform:uppercase;margin-bottom:2px' }, 'Dimensions'),
            h('div', { style: 'color:#ccc' }, selected.media_details ? `${selected.media_details.width}x${selected.media_details.height}` : 'N/A')
          ),
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:9px;text-transform:uppercase;margin-bottom:2px' }, 'Size'),
            h('div', { style: 'color:#ccc' }, formatSize(getFileSize(selected)))
          ),
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:9px;text-transform:uppercase;margin-bottom:2px' }, 'File type'),
            h('div', { style: 'color:#ccc' }, fileExt(selected))
          )
        ),
        collKeys.length > 0 && h('div', null,
          h('div', { style: 'font-size:10px;color:#555;text-transform:uppercase;font-weight:700;margin-bottom:6px' }, 'Collections'),
          h('div', { style: 'display:flex;flex-direction:column;gap:8px;font-size:11px' },
            collKeys.filter(key => collIds(key).includes(selected.id)).map(key => {
              const ids = collIds(key);
              return h('div', { key, class: 've-chip-row' },
                h('span', { style: 'display:flex;align-items:center;gap:6px;min-width:0' }, ph(collIcon(key)), h('span', { style: 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, collLabel(key))),
                h('button', { class: 've-a', title: 'Remove from collection', onClick: () => toggleCollectionItem(key, selected.id, false) }, ph('x'))
              );
            }),
            !collKeys.some(key => collIds(key).includes(selected.id)) && h('div', { class: 've-empty', style: 'padding:8px 0;text-align:left' }, 'Not in any collection yet.'),
            h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { setCheckedItems([selected.id]); setPendingBatchCollection(true); } }, ph('plus'), 'Add to collection')
          )
        ),
        h('div', null,
          h('div', { style: 'font-size:10px;color:#555;text-transform:uppercase;font-weight:700;margin-bottom:6px' }, 'Asset Actions'),
          h('input', { type: 'file', ref: replaceInputRef, style: 'display:none', onChange: e => handleReplaceFile(e.target.files) }),
          h('div', { style: 'display:flex;gap:6px;align-items:center;flex-wrap:wrap' },
            h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => replaceInputRef.current?.click(), title: 'Upload a new file while keeping this attachment ID, alt text, title, and references.' }, ph('arrows-clockwise'), 'Replace File'),
            isImageFile(selected) && h(SelectMenu, { className: 've-filter-menu ve-convert-menu', value: convertFormat, onChange: setConvertFormat, options: [
              { value: 'webp', label: 'WEBP' },
              { value: 'avif', label: 'AVIF' },
              { value: 'jpeg', label: 'JPEG' },
              { value: 'png', label: 'PNG' }
            ] }),
            isImageFile(selected) && h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: convertSelected, disabled: convertingId === selected.id, title: 'Create a converted copy in the selected format and keep this asset selected.' }, ph('file-arrow-down'), convertingId === selected.id ? 'Converting...' : 'Convert')
          )
        )
      ),
      h('div', { style: 'display:flex;flex-direction:column;gap:8px;margin-top:auto;border-top:1px solid rgba(255,255,255,0.06);padding-top:12px' },
        h('button', {
          class: 've-btn ve-btn-primary',
          style: 'color:#1f1f1f;font-weight:600;display:flex;align-items:center;justify-content:center;gap:6px',
          onClick: insertSelectedMedia
        }, ph('check'), picking ? 'Use Selected Media' : 'Insert Media URL'),
        h('button', {
          class: 've-btn ve-btn-g',
          style: 'display:flex;align-items:center;justify-content:center;gap:6px',
          onClick: () => handleCopyTag(selected)
        }, ph('copy'), 'Copy HTML Tag'),
        h('button', {
          class: 've-btn',
          style: 'background:rgba(255,77,77,0.1);color:#ff4d4d;border:1px solid rgba(255,77,77,0.2);display:flex;align-items:center;justify-content:center;gap:6px',
          onClick: () => handleDelete(selected)
        }, ph('trash'), 'Delete Permanently')
      )
    )
  );
}

/* ── Plugin Studio sub-panel ─────────────────── */
function PluginStudioSub({ flash }) {
  const [plugins, setPlugins] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [pending, setPending] = useState(null);
  const [directoryQuery, setDirectoryQuery] = useState('');
  const [directoryResults, setDirectoryResults] = useState([]);
  const [directoryLoading, setDirectoryLoading] = useState(false);
  const [directoryMode, setDirectoryMode] = useState(false);
  const [directoryView, setDirectoryView] = useState(() => localStorage.getItem('ve_plugin_directory_view') || 'list');
  const uploadRef = useRef(null);

  const loadPlugins = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.g('plugin-studio/plugins');
      setPlugins(Array.isArray(res?.plugins) ? res.plugins : []);
    } catch (e) {
      setPlugins([]);
    }
    setLoading(false);
  }, []);

  useEffect(() => { loadPlugins(); }, [loadPlugins]);

  const runPluginAction = async (plugin, action) => {
    setPending(plugin.slug + ':' + action);
    try {
      const res = await api.p('plugin-studio/action', { plugin: plugin.file, action });
      if (res && res.success) {
        flash(res.message || 'Plugin updated.');
        await loadPlugins();
      } else {
        flash(res?.message || 'Plugin action failed.');
      }
    } catch (e) {
      flash('Plugin action failed.');
    }
    setPending(null);
  };

  const searchDirectory = async (query) => {
    const q = (typeof query === 'string' ? query : directoryQuery).trim();
    setDirectoryMode(true);
    setDirectoryLoading(true);
    try {
      const res = await api.g('plugin-studio/directory?search=' + encodeURIComponent(q));
      setDirectoryResults(Array.isArray(res?.plugins) ? res.plugins : []);
    } catch (e) {
      setDirectoryResults([]);
      flash('Directory search failed.');
    }
    setDirectoryLoading(false);
  };

  useEffect(() => {
    if (!directoryMode) return;
    const t = setTimeout(() => searchDirectory(directoryQuery), 320);
    return () => clearTimeout(t);
  }, [directoryMode, directoryQuery]);

  const installDirectoryPlugin = async slug => {
    setPending(slug + ':install');
    try {
      const res = await api.p('plugin-studio/install', { slug });
      flash(res?.message || (res?.success ? 'Plugin installed.' : 'Install failed.'));
      if (res?.success) await loadPlugins();
    } catch (e) {
      flash('Install failed.');
    }
    setPending(null);
  };

  const uploadPluginZip = async file => {
    if (!file) return;
    const fd = new FormData();
    fd.append('plugin_zip', file);
    setPending('upload:plugin');
    try {
      const res = await api.f('variable-engine/v1/plugin-studio/upload', { method: 'POST', body: fd });
      flash(res?.message || (res?.success ? 'Plugin uploaded.' : 'Upload failed.'));
      if (res?.success) await loadPlugins();
    } catch (e) {
      flash('Plugin upload failed.');
    }
    if (uploadRef.current) uploadRef.current.value = '';
    setPending(null);
  };

  const filteredPlugins = useMemo(() => {
    const q = search.toLowerCase().trim();
    return plugins.filter(p => {
      if (status === 'active' && !p.active) return false;
      if (status === 'inactive' && p.active) return false;
      if (status === 'updates' && !p.update_available) return false;
      if (!q) return true;
      return (p.name || '').toLowerCase().includes(q) || (p.description || '').toLowerCase().includes(q) || (p.author || '').toLowerCase().includes(q);
    });
  }, [plugins, search, status]);

  const counts = useMemo(() => ({
    all: plugins.length,
    active: plugins.filter(p => p.active).length,
    inactive: plugins.filter(p => !p.active).length,
    updates: plugins.filter(p => p.update_available).length
  }), [plugins]);

  const directoryIcon = item => {
    const icons = item.icons || {};
    return icons['2x'] || icons['1x'] || icons.svg || icons.default || '';
  };

  const setPluginDirectoryView = view => {
    setDirectoryView(view);
    persistUserPreference('ve_plugin_directory_view', view);
  };

  return h('div', { class: 've-studio-layout ve-plugin-studio' },
    h('div', { class: 've-studio-sidebar' },
      h('div', { class: 've-studio-nav' },
        h('div', { class: 've-studio-nav-title' }, 'Installed Plugins'),
        [
          ['all', 'All plugins', 'plugs'],
          ['active', 'Active', 'toggle-right'],
          ['inactive', 'Inactive', 'toggle-left'],
          ['updates', 'Updates', 'arrow-circle-up']
        ].map(row => h('div', { class: 've-studio-nav-item' + (!directoryMode && status === row[0] ? ' active' : ''), onClick: () => { setDirectoryMode(false); setStatus(row[0]); } },
          h('span', { style: 'display:flex;align-items:center;gap:8px' }, ph(row[2]), row[1]),
          h('span', { class: 've-studio-badge' }, counts[row[0]])
        ))
      ),
      h('div', { class: 've-studio-nav' },
        h('div', { class: 've-studio-nav-title' }, 'Plugin Directory'),
        h('div', { class: 've-studio-nav-item' + (directoryMode ? ' active' : ''), onClick: () => { setDirectoryMode(true); if (!directoryResults.length) searchDirectory(''); } },
          h('span', { style: 'display:flex;align-items:center;gap:8px' }, ph('download-simple'), 'Browse plugins'),
          h('span', { class: 've-studio-badge' }, directoryResults.length || 'WP')
        )
      ),
      h('div', { class: 've-studio-stats' },
        h('div', { class: 've-studio-stats-item' }, h('span', null, 'Active'), h('b', null, counts.active)),
        h('div', { class: 've-studio-stats-item' }, h('span', null, 'Updates'), h('b', null, counts.updates))
      )
    ),
    h('div', { class: 've-studio-main' },
      h('div', { class: 've-studio-topbar' },
        h('div', null,
          h('h2', { style: 'margin:0;font-size:16px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px' }, directoryMode ? 'Plugin Directory' : 'Plugin Studio', h('span', { class: 've-studio-badge' }, directoryMode ? ((directoryLoading ? '...' : directoryResults.length) + ' found') : (filteredPlugins.length + ' shown'))),
          h('div', { class: 've-studio-help' }, directoryMode ? 'Search and install plugins from the WordPress.org directory.' : 'Manage activation, updates, auto-updates, and cleanup without leaving Mimam\'s Var.')
        ),
        h('div', { style: 'display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:flex-end' },
          !directoryMode && h('input', { class: 've-studio-input', style: 'width:220px', placeholder: 'Search installed plugins...', value: search, onInput: e => setSearch(e.target.value) }),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: loadPlugins, disabled: loading }, ph('arrows-clockwise'), loading ? 'Refreshing' : 'Refresh'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => uploadRef.current && uploadRef.current.click(), disabled: pending === 'upload:plugin' }, ph('upload-simple'), pending === 'upload:plugin' ? 'Uploading' : 'Upload ZIP'),
          h('input', { ref: uploadRef, type: 'file', accept: '.zip,application/zip,application/x-zip-compressed', style: 'display:none', onChange: e => uploadPluginZip(e.target.files && e.target.files[0]) })
        )
      ),
      directoryMode && h('div', { class: 've-plugin-directory-bar' },
        h('input', { class: 've-studio-input', placeholder: 'Ajax search WordPress plugin directory...', value: directoryQuery, onInput: e => setDirectoryQuery(e.target.value), onKeyDown: e => { if (e.key === 'Enter') searchDirectory(); } }),
        h('button', { class: 've-btn ve-btn-s', onClick: () => searchDirectory(), disabled: directoryLoading }, ph('magnifying-glass'), directoryLoading ? 'Searching' : 'Search'),
        h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => setPluginDirectoryView(directoryView === 'grid' ? 'list' : 'grid'), title: directoryView === 'grid' ? 'List view' : 'Grid view' }, ph(directoryView === 'grid' ? 'list' : 'squares-four')),
        directoryMode && h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => setDirectoryMode(false) }, 'Installed')
      ),
      directoryMode && h('div', { class: 've-plugin-directory-results ' + directoryView },
        directoryLoading ? h('div', { class: 've-empty' }, 'Searching WordPress.org...') :
        directoryResults.length === 0 ? h('div', { class: 've-empty' }, 'No directory results yet.') :
        directoryResults.map(item => h('div', { class: 've-plugin-card', key: item.slug },
          directoryIcon(item)
            ? h('img', { class: 've-plugin-card-icon', src: directoryIcon(item), alt: '' })
            : h('div', { class: 've-plugin-card-icon' }, ph('plug')),
          h('div', { class: 've-plugin-card-main' },
            h('strong', null, item.name || item.slug),
            h('span', null, item.short_description || 'No description provided.'),
            h('small', null, (item.version ? 'v' + item.version : ''), item.author ? ' · ' + item.author.replace(/<[^>]*>/g, '') : '', item.active_installs ? ' · ' + item.active_installs.toLocaleString() + '+ installs' : '')
          ),
          h('button', { class: 've-btn ve-btn-s', disabled: pending === item.slug + ':install', onClick: () => installDirectoryPlugin(item.slug) }, pending === item.slug + ':install' ? 'Installing' : 'Install')
        ))
      ),
      !directoryMode &&
      h('div', { class: 've-studio-table-container' },
        loading ? h('div', { class: 've-empty' }, 'Loading plugins...') :
        filteredPlugins.length === 0 ? h('div', { class: 've-empty' }, 'No plugins match this filter.') :
        h('table', { class: 've-studio-table ve-plugin-table' },
          h('thead', null, h('tr', null,
            h('th', null, 'Plugin'),
            h('th', { style: 'width:100px' }, 'Version'),
            h('th', { style: 'width:110px' }, 'Status'),
            h('th', { style: 'width:120px' }, 'Auto-update'),
            h('th', { style: 'width:260px;text-align:right' }, 'Actions')
          )),
          h('tbody', null, filteredPlugins.map(plugin => {
            const busy = pending && pending.indexOf(plugin.slug + ':') === 0;
            return h('tr', { key: plugin.file },
              h('td', null,
                h('div', { style: 'display:flex;flex-direction:column;gap:3px' },
                  h('strong', { style: 'color:#fff' }, plugin.name),
                  h('span', { class: 've-plugin-description' }, plugin.description || plugin.file),
                  h('span', { class: 've-plugin-author' }, plugin.author || '')
                )
              ),
              h('td', null, h('span', { style: 'font-family:"SF Mono","Fira Code",monospace;color:#ccc' }, plugin.version || '-')),
              h('td', null, h('span', { class: 've-studio-badge ' + (plugin.active ? 'ok' : '') }, plugin.active ? 'Active' : 'Inactive')),
              h('td', null, h(CheckControl, { checked: !!plugin.auto_update, disabled: busy, label: plugin.auto_update ? 'On' : 'Off', onChange: () => runPluginAction(plugin, plugin.auto_update ? 'auto_update_off' : 'auto_update_on') })),
              h('td', { style: 'text-align:right' },
                h('div', { style: 'display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap' },
                  plugin.update_available && h('a', { class: 've-btn ve-btn-s', href: plugin.update_url || 'update-core.php', style: 'text-decoration:none;display:inline-flex;align-items:center' }, ph('arrow-circle-up'), 'Update'),
                  h('button', { class: 've-btn ve-btn-g ve-btn-s', disabled: busy, onClick: () => runPluginAction(plugin, plugin.active ? 'deactivate' : 'activate') }, plugin.active ? 'Deactivate' : 'Activate'),
                  !plugin.active && h('button', { class: 've-btn ve-btn-g ve-btn-s ve-danger-soft', disabled: busy, onClick: () => runPluginAction(plugin, 'delete') }, ph('trash'), 'Delete')
                )
              )
            );
          }))
        )
      )
    )
  );
}

/* ── Unified Settings sub-panel ───────────────── */
function UnifiedSettingsPanel({ onClose, panelMode, setPanelMode }) {
  const [activeTab, setActiveTab] = useState('general');
  const [s, sS] = useState({ vw_min: 320, vw_max: 1440, delete_on_uninstall: false, update_url: '', update_channel: 'stable', auto_update: false, license_server_url: '', license: {}, deactivated_tools: [], allow_multi_panels: false, show_all_tab: true });
  const [lk, sLk] = useState('');
  const [upd, sUpd] = useState(null);
  const [ck, sCk] = useState(false);
  const [licBusy, sLicBusy] = useState('');
  const [ld, sLd] = useState(true);

  const isDeactivated = id => Array.isArray(s.deactivated_tools) && s.deactivated_tools.includes(id);

  const toggleDeactivated = id => {
    const arr = Array.isArray(s.deactivated_tools) ? s.deactivated_tools : [];
    const next = arr.includes(id) ? arr.filter(x => x !== id) : [...arr, id];
    sS(prev => {
      const updated = { ...prev, deactivated_tools: next };
      api.p('settings', updated);
      persistUserPreference('ve_deactivated_tools', next);
      builderRuntimeWindows().forEach(win => {
        try {
          win.dispatchEvent(new win.CustomEvent('ve-deactivated-tools-changed', { detail: next }));
        } catch(e) {
          try { win.dispatchEvent(new CustomEvent('ve-deactivated-tools-changed', { detail: next })); } catch(err) {}
        }
      });
      return updated;
    });
  };

  // CSS Studio settings states
  const [cssScss, setCssScss] = useState(() => localStorage.getItem('ve_css_scss') === '1');
  const [cssSourceOrder, setCssSourceOrder] = useState(() => {
    try {
      return normalizeSourceOrder(JSON.parse(localStorage.getItem('ve_css_source_order') || '[]'), []);
    } catch (e) {
      return CSS_SOURCE_DEFAULTS;
    }
  });
  const [cssDisabledSources, setCssDisabledSources] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('ve_css_disabled_sources') || '[]');
    } catch (e) {
      return [];
    }
  });
  const [cssSourceMeta, setCssSourceMeta] = useState({});
  const [cssDragSource, setCssDragSource] = useState('');
  const [cssDropHint, setCssDropHint] = useState(null);
  const [cssRemoteSuggestions, setCssRemoteSuggestions] = useState({ variables: [], classes: [], ids: [], sources: [] });
  const [cssIndexMsg, setCssIndexMsg] = useState('');
  const [cssIndexBusy, setCssIndexBusy] = useState(false);

  // Mimam's Bar settings state (mirrored from window.MimamsBarSettings)
  const [barSettings, setBarSettings] = useState(() => {
    if (window.MimamsBarSettings) {
      return window.MimamsBarSettings.load();
    }
    return {};
  });

  useEffect(() => {
    api.g('settings').then(d => {
      if (d && !d.code) sS(v => ({ ...v, ...d }));
      sLd(false);
    }).catch(() => sLd(false));

    api.g('advanced-css/suggestions').then(d => {
      if (d && !d.code) {
        setCssRemoteSuggestions(d);
        const next = normalizeSourceOrder(cssSourceOrder, d.sources || []);
        setCssSourceOrder(next);
        persistUserPreference('ve_css_source_order', next);
        const m = {};
        (d.sources || []).forEach(x => {
          m[x] = x === "Mimam's Var" ? 'Active' : 'Detected';
        });
        setCssSourceMeta(prev => ({ ...prev, ...m }));
        if (d.counts) {
          setCssIndexMsg('Index: ' + d.counts.variables + ' variables · ' + d.counts.classes + ' classes · ' + d.counts.ids + ' IDs · ' + (d.counts.selectors || 0) + ' selectors' + (d.cached ? ' (cached)' : ''));
        }
      }
    }).catch(() => {});

    api.g('migration/sources').then(d => {
      if (Array.isArray(d)) {
        const m = {};
        d.forEach(x => {
          m[x.name] = x.available ? 'Detected' : 'Not found';
          if (x.name === 'Bricks / Advanced Themer') {
            m.Bricks = x.available ? 'Detected' : 'Not found';
            m['Advanced Themer'] = x.available ? 'Detected' : 'Not found';
          }
        });
        setCssSourceMeta(prev => ({ ...prev, ...m }));
      }
    }).catch(() => {});
  }, []);

  const setScss = v => {
    setCssScss(v);
    persistUserPreference('ve_css_scss', v ? '1' : '0');
    window.dispatchEvent(new CustomEvent('ve-css-settings-changed'));
  };

  const toggleSource = x => {
    setCssDisabledSources(a => {
      const n = a.includes(x) ? a.filter(y => y !== x) : [...a, x];
      persistUserPreference('ve_css_disabled_sources', n);
      window.dispatchEvent(new CustomEvent('ve-css-settings-changed'));
      return n;
    });
  };

  const persistSources = (a, validSources) => {
    const next = normalizeSourceOrder(a, validSources || cssRemoteSuggestions.sources || []);
    setCssSourceOrder(next);
    persistUserPreference('ve_css_source_order', next);
    window.dispatchEvent(new CustomEvent('ve-css-settings-changed'));
  };

  const refreshIndex = async () => {
    setCssIndexBusy(true);
    setCssIndexMsg('Rebuilding index...');
    const d = await api.g('advanced-css/suggestions?refresh=1');
    setCssIndexBusy(false);
    if (!d || d.code) {
      setCssIndexMsg(d?.message || 'Index refresh failed');
      return;
    }
    setCssRemoteSuggestions(d);
    const next = normalizeSourceOrder(cssSourceOrder, d.sources || []);
    setCssSourceOrder(next);
    persistUserPreference('ve_css_source_order', next);
    const m = {};
    (d.sources || []).forEach(x => {
      m[x] = x === "Mimam's Var" ? 'Active' : 'Detected';
    });
    setCssSourceMeta(prev => ({ ...prev, ...m }));
    setCssIndexMsg('Index refreshed: ' + (d.counts?.variables || 0) + ' variables · ' + (d.counts?.classes || 0) + ' classes · ' + (d.counts?.ids || 0) + ' IDs · ' + (d.counts?.selectors || 0) + ' selectors');
  };

  const dropSource = () => {
    if (!cssDragSource || !cssDropHint) return;
    const drag = cssDragSource;
    setCssDragSource('');
    const a = cssSourceOrder.filter(x => x !== drag);
    let idx = a.indexOf(cssDropHint.target);
    if (idx < 0) idx = a.length;
    if (cssDropHint.pos === 'after') idx++;
    a.splice(idx, 0, drag);
    persistSources(a);
    setCssDropHint(null);
  };

  const updateBarSetting = (key, value) => {
    if (window.MimamsBarSettings) {
      window.MimamsBarSettings.set(key, value);
      setBarSettings({ ...window.MimamsBarSettings.data });
    }
  };

  const check = async () => {
    sCk(true);
    const r = await api.p('update/check', {});
    sUpd(r);
    sCk(false);
  };
  const setLicense = r => sS(v => ({ ...v, license: r || {} }));
  const saveSettingsOnly = async () => {
    const r = await api.p('settings', s);
    sS(v => ({ ...v, ...r }));
    return r;
  };
  const activateLic = async () => {
    sLicBusy('activate');
    await saveSettingsOnly();
    const r = await api.p('license/activate', { license_key: lk });
    setLicense(r);
    sLk('');
    sLicBusy('');
  };
  const checkLic = async () => {
    sLicBusy('check');
    await saveSettingsOnly();
    const r = await api.p('license/check', {});
    setLicense(r);
    sLicBusy('');
  };
  const deactivateLic = async () => {
    sLicBusy('deactivate');
    const r = await api.p('license/deactivate', {});
    setLicense(r);
    sLicBusy('');
  };

  if (ld) return h('div', { class: 've-empty' }, 'Loading...');

  const lic = s.license || {};
  const licLabel = (lic.status || 'inactive').replace(/^\w/, m => m.toUpperCase());

  return h('div', { style: 'display:flex;flex-direction:column;flex:1;min-height:0;padding:14px;box-sizing:border-box' },
    // Tabs header
    h('div', { class: 've-tabs', style: 'padding:0 0 10px;margin-bottom:12px;border-bottom:1px solid rgba(255,255,255,.08)' },
      h('div', { class: 've-t' + (activeTab === 'general' ? ' on' : ''), onClick: () => setActiveTab('general') }, 'General'),
      h('div', { class: 've-t' + (activeTab === 'bar' ? ' on' : ''), onClick: () => setActiveTab('bar') }, "Mimam's Bar"),
      h('div', { class: 've-t' + (activeTab === 'studio' ? ' on' : ''), onClick: () => setActiveTab('studio') }, "CSS Studio"),
      h('div', { class: 've-t' + (activeTab === 'modules' ? ' on' : ''), onClick: () => setActiveTab('modules') }, 'Modules')
    ),

    h('div', { class: 've-body', style: 'flex:1;overflow-y:auto;padding-right:4px' },
      activeTab === 'general' ? [
        h('div', { class: 've-opt', key: 'vwm' }, h('span', null, 'Min viewport (px)'), h('input', { type: 'number', value: s.vw_min, onInput: e => { const val = +e.target.value; sS(v => ({ ...v, vw_min: val })); api.p('settings', { ...s, vw_min: val }); } })),
        h('div', { class: 've-opt', key: 'vwx' }, h('span', null, 'Max viewport (px)'), h('input', { type: 'number', value: s.vw_max, onInput: e => { const val = +e.target.value; sS(v => ({ ...v, vw_max: val })); api.p('settings', { ...s, vw_max: val }); } })),
        h('div', { class: 've-opt', key: 'del', style: 'margin-top:12px' }, h(CheckControl, { checked: s.delete_on_uninstall, label: 'Delete all data on uninstall', onChange: val => { sS(v => ({ ...v, delete_on_uninstall: val })); api.p('settings', { ...s, delete_on_uninstall: val }); } })),
        h('div', { class: 've-opt', key: 'show-all-tab', style: 'margin-top:12px' }, h(CheckControl, { checked: typeof s.show_all_tab === 'undefined' ? true : !!s.show_all_tab, label: 'Show "All" tab in variables list', onChange: val => { const next = { ...s, show_all_tab: val }; sS(next); api.p('settings', next); builderRuntimeWindows().forEach(win => { try { win.dispatchEvent(new win.CustomEvent('ve-show-all-tab-changed', { detail: val })); } catch(e) { try { win.dispatchEvent(new CustomEvent('ve-show-all-tab-changed', { detail: val })); } catch(err) {} } }); } })),
        h('div', { class: 've-opt ve-opt-stack', key: 'layout', style: 'margin-top:12px' },
          h('span', null, 'Panel layout'),
          h('div', { class: 've-layout-grid' },
            ['right', 'left', 'float'].map(m => h('button', { type: 'button', class: 've-btn ' + (panelMode === m ? '' : 've-btn-g') + ' ve-btn-s', onClick: () => setPanelMode(m) }, m === 'right' ? 'Dock Right' : m === 'left' ? 'Dock Left' : 'Float'))
          ),
          h('div', { style: 'font-size:9px;color:#666;line-height:1.55;margin-top:4px' }, 'Floating panels can be dragged from the header. Layout is saved on this browser.')
        ),
        h('div', { class: 've-opt ve-opt-stack', key: 'multi-panels' },
          h('span', null, 'Panel behavior (single/multiple)'),
          h(CheckControl, { checked: !!s.allow_multi_panels, label: 'Allow more than one MV panel open at once', onChange: val => { const next = { ...s, allow_multi_panels: val }; sS(next); persistUserPreference('ve_allow_multi_panels', val ? '1' : '0'); builderRuntimeWindows().forEach(win => { try { win.dispatchEvent(new win.CustomEvent('ve-panel-concurrency-changed', { detail: val })); } catch(e) { try { win.dispatchEvent(new CustomEvent('ve-panel-concurrency-changed', { detail: val })); } catch(err) {} } }); api.p('settings', next); } }),
          h('div', { style: 'font-size:9px;color:#777;line-height:1.55;margin-top:4px' }, 'Off keeps one major panel open at a time. On lets Studio panels share the viewport.')
        ),
        h('div', { class: 've-opt ve-opt-stack', key: 'url' },
          h('span', null, 'Update feed URL'),
          h('input', { type: 'text', value: s.update_url || '', placeholder: 'https://.../manifest.json', onInput: e => { const val = e.target.value; sS(v => ({ ...v, update_url: val })); api.p('settings', { ...s, update_url: val }); } })
        ),
        h('div', { class: 've-opt ve-opt-stack', key: 'channel' },
          h('span', null, 'Update channel'),
          h(SelectMenu, { value: s.update_channel || 'stable', onChange: v => { sS(old => { const next = { ...old, update_channel: v, update_url: '' }; api.p('settings', next); return next; }); }, options: [{ value: 'stable', label: 'Stable' }, { value: 'beta', label: 'Beta' }, { value: 'dev', label: 'Dev' }] })
        ),
        h('div', { class: 've-opt', key: 'auto' }, h(CheckControl, { checked: !!s.auto_update, label: 'Auto-update this plugin', onChange: val => { sS(v => ({ ...v, auto_update: val })); api.p('settings', { ...s, auto_update: val }); } })),
        h('div', { class: 've-upd', key: 'upd-row' },
          h('button', { class: 've-btn ve-btn-g', onClick: check, disabled: ck }, ck ? 'Checking...' : 'Check update'),
          upd && h('span', { class: upd.update_available ? 'ok' : 'muted' }, upd.message || 'Checked', upd.latest_version ? ' · ' + upd.latest_version : ''),
          upd?.update_available && upd.update_admin_url && h('button', { class: 've-btn ve-btn-s', onClick: () => { window.location.href = upd.update_admin_url; } }, 'Update')
        ),
        h('div', { class: 've-opt ve-opt-stack', key: 'lic-url', style: 'margin-top:14px' }, h('span', null, 'License server URL'), h('input', { type: 'text', value: s.license_server_url || '', placeholder: 'https://lic.hebronmimam.com', onInput: e => { const val = e.target.value; sS(v => ({ ...v, license_server_url: val })); api.p('settings', { ...s, license_server_url: val }); } })),
        h('div', { key: 'lic-box', style: 'margin-top:8px;padding:11px;border:1px solid rgba(255,255,255,.10);border-radius:8px;background:rgba(255,255,255,.035)' },
          h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px' },
            h('span', { style: 'font-size:11px;font-weight:700;color:#ddd' }, 'License'),
            h('span', { class: lic.active ? 'ok' : 'muted', style: 'font-size:10px' }, licLabel)
          ),
          h('div', { style: 'font-size:10px;color:#888;line-height:1.55;margin-bottom:8px' }, lic.message || 'No license key saved.', lic.key_masked ? ' · ' + lic.key_masked : ''),
          h('div', { style: 'display:flex;gap:6px;align-items:center' },
            h('input', { class: 've-studio-input', type: 'text', value: lk, placeholder: 'License key', onInput: e => sLk(e.target.value), style: 'flex:1;min-width:0;font-size:11px;' }),
            h('button', { class: 've-btn', onClick: activateLic, disabled: !!licBusy || !lk.trim() }, licBusy === 'activate' ? 'Saving...' : 'Activate')
          ),
          h('div', { style: 'display:flex;gap:6px;margin-top:8px' },
            h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: checkLic, disabled: !!licBusy }, licBusy === 'check' ? 'Checking...' : 'Check license'),
            lic.configured && h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: deactivateLic, disabled: !!licBusy }, licBusy === 'deactivate' ? 'Removing...' : 'Deactivate')
          )
        )
      ] : activeTab === 'bar' ? [
        // Mimam's Bar settings
        h('div', { class: 've-opt', key: 'bar-autoClose' }, h(CheckControl, { checked: !!barSettings.autoClose, label: 'Auto-close after apply', onChange: val => updateBarSetting('autoClose', val) })),
        h('div', { class: 've-opt', key: 'bar-undocked' }, h(CheckControl, { checked: !!barSettings.undocked, label: 'Undock Mimam\'s Bar and remember position', onChange: val => updateBarSetting('undocked', val) })),
        h('div', { class: 've-opt', key: 'bar-hideStructure' }, h(CheckControl, { checked: !!barSettings.hideStructure, label: 'Hide Bricks structure panel', onChange: val => updateBarSetting('hideStructure', val) })),
        h('div', { class: 've-opt', key: 'bar-hideElements' }, h(CheckControl, { checked: !!barSettings.hideElements, label: 'Hide Bricks elements panel', onChange: val => updateBarSetting('hideElements', val) })),
        h('div', { class: 've-opt', key: 'bar-floatElements' }, h(CheckControl, { checked: !!barSettings.floatElements, label: 'Float Bricks elements panel', onChange: val => updateBarSetting('floatElements', val) })),
        h('div', { class: 've-opt', key: 'bar-floatStructure' }, h(CheckControl, { checked: !!barSettings.floatStructure, label: 'Float Bricks structure panel', onChange: val => updateBarSetting('floatStructure', val) })),
        h('div', { class: 've-opt', key: 'bar-floatOpacity' },
          h('span', null, 'Floating panels opacity'),
          h(SelectMenu, { value: barSettings.floatOpacity || '0.78', onChange: v => updateBarSetting('floatOpacity', v), options: [
            { value: '1', label: '100%' },
            { value: '0.9', label: '90%' },
            { value: '0.78', label: '78%' },
            { value: '0.65', label: '65%' },
            { value: '0.5', label: '50%' }
          ] })
        ),
        h('div', { class: 've-opt', key: 'bar-shortcut' },
          h('span', null, 'Shortcut'),
          h(SelectMenu, { value: barSettings.shortcut || 'alt-q', onChange: v => updateBarSetting('shortcut', v), options: [
            { value: 'alt-q', label: 'Alt + Q' },
            { value: 'ctrl-k', label: 'Ctrl + K' },
            { value: 'ctrl-alt-a', label: 'Ctrl + Alt + A' }
          ] })
        ),
        h('div', { class: 've-opt', key: 'bar-deselectShortcut' },
          h('span', null, 'Deselect Shortcut'),
          h(SelectMenu, { value: barSettings.deselectShortcut || 'escape', onChange: v => updateBarSetting('deselectShortcut', v), options: [
            { value: 'escape', label: 'Escape' },
            { value: 'shift-d', label: 'Shift + D' },
            { value: 'alt-d', label: 'Alt + D' },
            { value: 'none', label: 'None' }
          ] })
        ),
        h('div', { class: 've-opt', key: 'bar-showTopBarIcon' }, h(CheckControl, { checked: barSettings.showTopBarIcon !== false, label: 'Show Mimam\'s Bar in Top Toolbar', onChange: val => updateBarSetting('showTopBarIcon', val) })),
        h('div', { class: 've-opt', key: 'bar-showVengineTopBarIcon' }, h(CheckControl, { checked: barSettings.showVengineTopBarIcon !== false, label: 'Show Vengine in Top Toolbar', onChange: val => updateBarSetting('showVengineTopBarIcon', val) })),
        h('div', { class: 've-opt', key: 'bar-density' },
          h('span', null, 'Density'),
          h(SelectMenu, { value: barSettings.density || 'compact', onChange: v => updateBarSetting('density', v), options: [
            { value: 'compact', label: 'Compact' },
            { value: 'comfortable', label: 'Comfortable' }
          ] })
        )
      ] : activeTab === 'studio' ? [
        // CSS Studio settings
        h('div', { class: 've-css-note', style: 'margin-bottom:8px' }, 'Live auto-format is off so typing never moves your cursor unexpectedly.'),
        h('div', { class: 've-opt', key: 'studio-scss' }, h(CheckControl, { checked: cssScss, label: 'SCSS mode foundation', onChange: setScss })),
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:8px;margin:' + (cssSourceOrder.length ? '10px 0 6px' : '0'), key: 'studio-sug-hdr' },
          h('div', { style: 'font-size:10px;color:#888;text-transform:uppercase;font-weight:700' }, 'Suggestion Priority'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: refreshIndex, disabled: cssIndexBusy }, cssIndexBusy ? 'Indexing...' : 'Refresh Index')),
        cssIndexMsg && h('div', { class: 've-css-note', style: 'margin-bottom:6px', key: 'studio-idx-msg' }, cssIndexMsg),
        h('div', { class: 've-source-list', key: 'studio-src-list' },
          normalizeSourceOrder(cssSourceOrder, cssRemoteSuggestions.sources || []).map(x => h('div', {
            class: 've-source-pill' + (cssDragSource === x ? ' dragging' : '') + (cssDropHint?.target === x ? ' drop-' + cssDropHint.pos : ''),
            key: x,
            draggable: true,
            onDragStart: e => { setCssDragSource(x); e.dataTransfer.effectAllowed = 'move'; },
            onDragOver: e => { e.preventDefault(); const r = e.currentTarget.getBoundingClientRect(); setCssDropHint({ target: x, pos: e.clientY < r.top + r.height/2 ? 'before' : 'after' }); e.dataTransfer.dropEffect = 'move'; },
            onDrop: e => { e.preventDefault(); dropSource(); },
            onDragEnd: () => { setCssDragSource(''); setCssDropHint(null); }
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px' }, h('span', { class: 've-source-grip' }, ph('dots-six-vertical')), h('span', null, x)),
            h('span', { style: 'display:flex;align-items:center;gap:6px' },
              h('span', { class: 've-source-meta' }, cssDisabledSources.includes(x) ? 'Off' : (cssSourceMeta[x] || 'Source')),
              h('button', { type: 'button', class: 've-source-toggle ' + (!cssDisabledSources.includes(x) ? 'on' : ''), title: cssDisabledSources.includes(x) ? 'Enable source' : 'Disable source', onMouseDown: e => e.preventDefault(), onClick: e => { e.preventDefault(); toggleSource(x); } }, ph(cssDisabledSources.includes(x) ? 'eye-slash' : 'eye')))))
        ),
        h('div', { class: 've-css-note', style: 'margin-top:10px', key: 'studio-src-note' }, 'Suggestions use this order when sources overlap. MV variables, detected builder classes, IDs, and supported plugin sources are scanned from WordPress.')
      ] : [
        // Modules settings tab
        h('div', { style: 'font-size:11px;color:#888;margin-bottom:14px;line-height:1.5', key: 'mod-intro' }, 'Deactivate individual modules to streamline the interface. Deactivated modules are hidden from the speed dial and will not load resource assets.'),
        
        h('div', { class: 've-opt', key: 'mod-css', style: 'padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04)' },
          h('div', { style: 'display:flex;align-items:flex-start;gap:8px' },
            h(CheckControl, { checked: !isDeactivated('css_studio'), onChange: () => toggleDeactivated('css_studio'), title: 'Toggle CSS Studio' }),
            h('div', null,
              h('span', { style: 'font-weight:600;display:block;color:#fff' }, 'CSS Studio'),
              h('span', { style: 'font-size:10px;color:#777;display:block;margin-top:2px' }, 'Standalone SCSS/CSS workspace with auto-complete and live page injections.')
            )
          )
        ),
        h('div', { class: 've-opt', key: 'mod-bar', style: 'padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04)' },
          h('div', { style: 'display:flex;align-items:flex-start;gap:8px' },
            h(CheckControl, { checked: !isDeactivated('mimams_bar'), onChange: () => toggleDeactivated('mimams_bar'), title: 'Toggle Mimam\'s Bar' }),
            h('div', null,
              h('span', { style: 'font-weight:600;display:block;color:#fff' }, "Mimam's Bar"),
              h('span', { style: 'font-size:10px;color:#777;display:block;margin-top:2px' }, 'Power-user command line interface for lightning-fast attribute and design operations.')
            )
          )
        ),
        h('div', { class: 've-opt', key: 'mod-content', style: 'padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04)' },
          h('div', { style: 'display:flex;align-items:flex-start;gap:8px' },
            h(CheckControl, { checked: !isDeactivated('content_studio'), onChange: () => toggleDeactivated('content_studio'), title: 'Toggle Content Studio' }),
            h('div', null,
              h('span', { style: 'font-weight:600;display:block;color:#fff' }, 'Content Studio'),
              h('span', { style: 'font-size:10px;color:#777;display:block;margin-top:2px' }, 'Central hub for managing pages, posts, and CPTs with status toggles.')
            )
          )
        ),
        h('div', { class: 've-opt', key: 'mod-media', style: 'padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04)' },
          h('div', { style: 'display:flex;align-items:flex-start;gap:8px' },
            h(CheckControl, { checked: !isDeactivated('media_studio'), onChange: () => toggleDeactivated('media_studio'), title: 'Toggle Media Studio' }),
            h('div', null,
              h('span', { style: 'font-weight:600;display:block;color:#fff' }, 'Media Studio'),
              h('span', { style: 'font-size:10px;color:#777;display:block;margin-top:2px' }, 'Premium glassmorphic media library replacement with collections and alt-text helpers.')
            )
          )
        ),
        h('div', { class: 've-opt', key: 'mod-plugin', style: 'padding:8px 0;border-bottom:1px solid rgba(255,255,255,.04)' },
          h('div', { style: 'display:flex;align-items:flex-start;gap:8px' },
            h(CheckControl, { checked: !isDeactivated('plugin_studio'), onChange: () => toggleDeactivated('plugin_studio'), title: 'Toggle Plugin Studio' }),
            h('div', null,
              h('span', { style: 'font-weight:600;display:block;color:#fff' }, 'Plugin Studio'),
              h('span', { style: 'font-size:10px;color:#777;display:block;margin-top:2px' }, 'Manage activation, updates, auto-updates, and inactive plugin cleanup.')
            )
          )
        )
      ]
    ),
    h('div', { style: 'display:flex;justify-content:flex-end;margin-top:14px;border-top:1px solid rgba(255,255,255,.08);padding-top:12px' },
      h('button', { class: 've-btn', onClick: onClose }, 'Close')
    )
  );
}

/* ── External source migration ─────────── */
function MigrationSub({onClose,exiting,onDone}){
  const[sources,sSources]=useState([]);
  const[source,sSource]=useState('all');
  const[ld,sLd]=useState(false);
  const[diff,sDiff]=useState([]);
  const[summary,sSummary]=useState(null);
  const[count,sCount]=useState(0);
  const[err,sErr]=useState('');
  useEffect(()=>{api.g('migration/sources').then(d=>{if(Array.isArray(d))sSources(d);});},[]);
  const preview=async()=>{sLd(true);sErr('');const r=await api.p('migration/preview',{source});sLd(false);if(r?.code){sErr(r.message||'Migration preview failed');return;}sDiff(r.changes||[]);sSummary(r.summary||{});sCount(r.variable_count||0);};
  const apply=async()=>{if(!diff.length)return;sLd(true);sErr('');const r=await api.p('sync/apply',{changes:diff.filter(c=>c.action!=='delete'),skip_deletes:true});sLd(false);if(r?.errors?.length){sErr(r.errors.join('; '));return;}onDone&&onDone();};
  const opts=[{value:'all',label:'All available sources'},...sources.map(x=>({value:x.id,label:x.name+(x.available?'':' (not detected)')}))];
  return h(Sub,{title:'Migrate Variables',onClose,exiting},
    h('div',{style:'font-size:10px;color:#888;line-height:1.65;margin-bottom:10px'},"Preview variables from Core Framework, Advanced Themer/Bricks, and ACSS before adding anything to Mimam's Var. Deletions are skipped for migration safety."),
    h('div',{class:'ve-opt ve-opt-stack'},h('span',null,'Source'),h(SelectMenu,{value:source,onChange:sSource,options:opts})),
    sources.length>0&&h('div',{style:'display:flex;flex-direction:column;gap:6px;margin:8px 0 12px'},sources.map(x=>h('div',{key:x.id,style:'padding:9px 10px;border:1px solid rgba(255,255,255,.08);border-radius:6px;background:rgba(255,255,255,.03)'},
      h('div',{style:'display:flex;justify-content:space-between;gap:8px;font-size:10px;font-weight:700;color:#ddd'},h('span',null,x.name),h('span',{class:x.available?'ok':'muted'},x.available?'Detected':'Not found')),
      h('div',{style:'font-size:9px;color:#777;line-height:1.55;margin-top:3px'},x.description)))),
    h('div',{style:'display:flex;gap:6px;margin-bottom:10px'},h('button',{class:'ve-btn',onClick:preview,disabled:ld},ld?'Scanning...':'Preview Migration'),diff.length>0&&h('button',{class:'ve-btn ve-btn-g',onClick:apply,disabled:ld},ld?'Applying...':'Apply '+diff.filter(c=>c.action!=='delete').length)),
    summary&&h('div',{style:'padding:10px;border:1px solid rgba(255,255,255,.10);border-radius:6px;background:'+(diff.length?'rgba(186,244,0,.055)':'rgba(255,255,255,.035)')},
      h('div',{style:'font-size:10px;color:#ddd;font-weight:700;margin-bottom:4px'},count+' variables found'),
      h('div',{style:'font-size:9px;color:#888;line-height:1.65'},(summary.added||0)+' new · '+(summary.updated||0)+' changed · '+(summary.deleted||0)+' possible removals skipped')),
    diff.length>0&&h('div',{style:'max-height:190px;overflow:auto;margin-top:8px;border-top:1px solid #2a2a2a'},diff.slice(0,60).map((c,i)=>h('div',{key:i,style:'display:flex;gap:6px;padding:5px 0;border-bottom:1px solid #262626;font-size:10px'},
      h('span',{style:'width:34px;color:'+(c.action==='add'?'#22c55e':c.action==='update'?'#3b82f6':'#888')},String(c.action||'').toUpperCase().slice(0,4)),
      h('span',{style:'flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-family:"SF Mono","Fira Code",monospace;color:#ddd'},c.name)))),
    err&&h('div',{style:'font-size:10px;color:#ef4444;padding:8px 0;line-height:1.5'},err));
}

function cssLineCount(text){const s=String(text||'');return Math.max(1,(s.match(/\n/g)||[]).length+1);}
const DOM_SUGGEST_CACHE={class:{at:0,items:[]},id:{at:0,items:[]},var:{at:0,items:[]}};
const CSSOM_SUGGEST_CACHE={class:{at:0,items:[]},id:{at:0,items:[]},var:{at:0,items:[]}};
function domSuggestionDocuments(){
  const docs=[];const seen=[];
  const add=doc=>{if(!doc||seen.includes(doc))return;seen.push(doc);docs.push(doc);};
  add(document);
  try{
    Array.from(window.frames||[]).forEach(frame=>{try{add(frame.document);}catch(e){}});
  }catch(e){}
  try{
    document.querySelectorAll('iframe').forEach(frame=>{try{add(frame.contentDocument||frame.contentWindow?.document);}catch(e){}});
  }catch(e){}
  return docs.slice(0,8);
}
function domClassName(el){
  const raw=el?.className;
  if(!raw)return'';
  if(typeof raw==='string')return raw;
  if(typeof raw.baseVal==='string')return raw.baseVal;
  return String(raw||'');
}
function collectDomSuggestions(kind){
  const now=Date.now();
  const cached=DOM_SUGGEST_CACHE[kind];
  if(cached&&now-cached.at<5000)return cached.items;
  const found={};
  let count=0;
  domSuggestionDocuments().forEach(doc=>{
    if(count>=3000)return;
    try{
      doc.querySelectorAll(kind==='class'?'[class]':'[id]').forEach(el=>{
        if(count>=3000)return;
        if(kind==='class')domClassName(el).split(/\s+/).forEach(c=>{if(c&&!c.startsWith('ve-')){found['.'+c]=true;count++;}});
        else if(el.id&&!String(el.id).startsWith('ve-')){found['#'+el.id]=true;count++;}
      });
    }catch(e){}
  });
  const items=Object.keys(found).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).slice(0,2000);
  DOM_SUGGEST_CACHE[kind]={at:now,items};
  return items;
}
function cssomExtractSelector(selector,found,kind){
  if(!selector)return 0;
  let count=0;
  const text=String(selector);
  if(kind==='class'){
    const re=/(?<![A-Za-z0-9_-])\.((?:\\.|[A-Za-z_][A-Za-z0-9_-]*|[\\/:\\].-]){1,120})/g;
    let m;while((m=re.exec(text))){const name='.'+m[1].replace(/\\/g,'');if(!name.startsWith('.ve-')){found[name]=true;count++;}}
  }else if(kind==='id'){
    const re=/(?<![A-Za-z0-9_-])#([A-Za-z_][A-Za-z0-9_-]{0,119})/g;
    let m;while((m=re.exec(text))){const name='#'+m[1];if(!name.startsWith('#ve-')){found[name]=true;count++;}}
  }
  return count;
}
function cssomExtractVars(text,found){
  let count=0;const s=String(text||'');
  let m;const add=name=>{name=String(name||'').trim();if(!name||name.indexOf('--ve-')===0)return;found[name]=true;count++;};
  const decl=/--([A-Za-z][A-Za-z0-9_-]*)\s*:/g;while((m=decl.exec(s)))add('--'+m[1]);
  const usage=/var\(\s*(--[A-Za-z][A-Za-z0-9_-]*)/g;while((m=usage.exec(s)))add(m[1]);
  return count;
}
function collectDomVariableSuggestions(){
  const now=Date.now();
  const cached=DOM_SUGGEST_CACHE.var;
  if(cached&&now-cached.at<8000)return cached.items;
  const found={};let count=0;
  const scanText=text=>{if(count>=2200)return;count+=cssomExtractVars(text,found);};
  const scanComputed=(win,el)=>{
    if(!win||!el||count>=2200)return;
    try{
      const st=win.getComputedStyle&&win.getComputedStyle(el);
      if(!st)return;
      const len=Math.min(st.length||0,900);
      for(let i=0;i<len&&count<2200;i++){
        const name=st.item?st.item(i):st[i];
        if(name&&String(name).indexOf('--')===0&&String(name).indexOf('--ve-')!==0){found[String(name)]=true;count++;}
      }
    }catch(e){}
  };
  domSuggestionDocuments().forEach(doc=>{
    if(count>=2200)return;
    try{
      scanText(doc.documentElement?.getAttribute?.('style')||'');
      scanText(doc.body?.getAttribute?.('style')||'');
      scanComputed(doc.defaultView||window,doc.documentElement);
      scanComputed(doc.defaultView||window,doc.body);
      const els=doc.querySelectorAll('[style]');
      for(let i=0;i<els.length&&i<1600&&count<2200;i++){
        scanText(els[i].getAttribute('style')||'');
      }
    }catch(e){}
  });
  const items=Object.keys(found).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).slice(0,1500);
  DOM_SUGGEST_CACHE.var={at:now,items};
  return items;
}
function cssomWalkRules(rules,found,kind,state){
  if(!rules||state.count>=2500)return;
  try{
    Array.from(rules).forEach(rule=>{
      if(state.count>=2500)return;
      try{
        if(kind==='var')state.count+=cssomExtractVars(rule.cssText||'',found);
        else if(rule.selectorText)state.count+=cssomExtractSelector(rule.selectorText,found,kind);
        if(rule.cssRules)cssomWalkRules(rule.cssRules,found,kind,state);
      }catch(e){}
    });
  }catch(e){}
}
function collectCssomSuggestions(kind){
  const now=Date.now();
  const cached=CSSOM_SUGGEST_CACHE[kind];
  if(cached&&now-cached.at<8000)return cached.items;
  const found={};const state={count:0};
  domSuggestionDocuments().forEach(doc=>{
    if(state.count>=2500)return;
    try{
      Array.from(doc.styleSheets||[]).forEach(sheet=>{
        if(state.count>=2500)return;
        try{cssomWalkRules(sheet.cssRules,found,kind,state);}catch(e){}
      });
    }catch(e){}
  });
  const items=Object.keys(found).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).slice(0,1500);
  CSSOM_SUGGEST_CACHE[kind]={at:now,items};
  return items;
}
function normalizeSourceOrder(saved,serverSources){
  const valid=[...new Set(serverSources&&serverSources.length?serverSources:["Mimam's Var"])];
  const incoming=Array.isArray(saved)?saved:[];
  const kept=incoming.filter(x=>valid.includes(x));
  return [...new Set([...kept,...valid])];
}
function cssValidation(text){
  const warnings=[];
  const s=String(text||'').slice(0,60000);
  const open=(s.match(/\{/g)||[]).length, close=(s.match(/\}/g)||[]).length;
  if(open!==close)warnings.push('Brace count is off: '+open+' opening, '+close+' closing.');
  const props=[...new Set(CSS_PROPS)];
  s.split('\n').slice(0,900).forEach((line,i)=>{
    const m=line.match(/^\s*([a-z-]+)\s*:/i);
    if(m&&!props.includes(m[1].toLowerCase())&&!m[1].startsWith('--'))warnings.push('Line '+(i+1)+': unknown property "'+m[1]+'".');
  });
  return warnings.slice(0,5);
}
function cssContext(text,pos){
  const before=String(text||'').slice(0,pos);
  const line=before.split('\n').pop()||'';
  const inValue=/:\s*[^;{}]*$/.test(line);
  let depth=0,quote='',comment=false;
  for(let i=0;i<before.length;i++){
    const c=before[i],n=before[i+1]||'';
    if(comment){if(c==='*'&&n==='/'){comment=false;i++;}continue;}
    if(quote){if(c==='\\'){i++;continue;}if(c===quote)quote='';continue;}
    if(c==='/'&&n==='*'){comment=true;i++;continue;}
    if(c==='"'||c==="'"){quote=c;continue;}
    if(c==='{')depth++;
    else if(c==='}')depth=Math.max(0,depth-1);
  }
  return{line,inValue,inBlock:depth>0};
}
function cssSuggestionMatch(before){
  const raw=String(before||'');
  const varMatch=raw.match(/var\(\s*(--[a-z0-9-]*)?$/i);
  if(varMatch)return{token:varMatch[1]||'--',kind:'var',replaceLength:varMatch[1]?varMatch[1].length:0,inVar:true};
  const pseudoMatch=raw.match(/(::?[a-z0-9_-]*)$/i);
  if(pseudoMatch)return{token:pseudoMatch[1],kind:'selector',replaceLength:pseudoMatch[1].length};
  const tokenMatch=raw.match(/(@[a-z0-9_-]*|--[a-z0-9-]*|\.[a-z0-9_:/[\].-]*|#[a-z0-9_-]*|[a-z-]{1,})$/i);
  if(!tokenMatch)return null;
  const token=tokenMatch[1];
  return{token,replaceLength:token.length,kind:token.startsWith('@')?'atrule':token.startsWith('--')?'var':token.startsWith('.')?'class':token.startsWith('#')?'id':'css',inVar:false};
}
function cssIndex(list){
  const out=[];const seen={};
  (list||[]).forEach(x=>{const label=String(x||'').trim();if(!label||seen[label])return;seen[label]=true;out.push({label,lower:label.toLowerCase()});});
  return out;
}
function cssLookup(index,query,limit){
  const q=String(query||'').toLowerCase();
  const res=[];
  if(!q){
    for(let i=0;i<index.length&&res.length<limit;i++)res.push(index[i].label);
    return res;
  }
  const bare=q.replace(/^(--|[.#])/,'');
  const add=label=>{if(res.length<limit&&!res.includes(label))res.push(label);};
  const itemBare=item=>item.lower.replace(/^(--|[.#])/,'');
  const segmentHit=(hay,needle)=>needle&&hay.split(/[-_.:/\s]+/).some(part=>part.indexOf(needle)===0);
  for(let i=0;i<index.length&&res.length<limit;i++)if(index[i].lower.indexOf(q)===0)add(index[i].label);
  if(bare!==q)for(let i=0;i<index.length&&res.length<limit;i++)if(itemBare(index[i]).indexOf(bare)===0)add(index[i].label);
  for(let i=0;i<index.length&&res.length<limit;i++)if(segmentHit(itemBare(index[i]),bare||q))add(index[i].label);
  for(let i=0;i<index.length&&res.length<limit;i++)if((index[i].lower.indexOf(q)>0||itemBare(index[i]).indexOf(bare)>0))add(index[i].label);
  return res;
}
function cssSuggestionPools(vars,remoteSuggestions){
  const orderVars=a=>{
    const priority=['--color','--space','--spacing','--typography','--font','--text','--heading','--radius','--size','--scale','--stroke','--shadow','--opacity','--motion'];
    const seen={};const arr=[];
    (a||[]).forEach(x=>{const label=String(x||'').trim();if(!label||seen[label])return;seen[label]=true;arr.push(label);});
    arr.sort((x,y)=>{
      const lx=x.toLowerCase(),ly=y.toLowerCase();
      const ix=priority.findIndex(p=>lx.startsWith(p)),iy=priority.findIndex(p=>ly.startsWith(p));
      return (ix<0?99:ix)-(iy<0?99:iy)||lx.length-ly.length||lx.localeCompare(ly,undefined,{numeric:true,sensitivity:'base'});
    });
    return cssIndex(arr);
  };
  return{
    vars:orderVars([...(remoteSuggestions?.variables||[]),...(vars||[]).map(v=>cssTokenName(v.name)).filter(Boolean),...collectCssomSuggestions('var'),...collectDomVariableSuggestions()]),
    classes:cssIndex([...(remoteSuggestions?.classes||[]),...collectDomSuggestions('class'),...collectCssomSuggestions('class')]),
    ids:cssIndex([...(remoteSuggestions?.ids||[]),...collectDomSuggestions('id'),...collectCssomSuggestions('id')]),
    selectors:cssIndex([...(remoteSuggestions?.selectors||[]),...CSS_SELECTOR_HINTS]),
    props:cssIndex(CSS_PROPS),
    values:cssIndex(CSS_VALUES)
  };
}
function cssSuggestions(text,pos,pools,disabledSources){
  const before=String(text||'').slice(0,pos);
  const m=cssSuggestionMatch(before);
  if(!m)return[];
  const q=m.token.toLowerCase();
  const ctx=cssContext(text,pos);
  const off=name=>(disabledSources||[]).includes(name);
  const cleanQ=(m.kind==='var'&&q==='--')||(m.kind==='class'&&q==='.')||(m.kind==='id'&&q==='#')||(m.kind==='atrule'&&q==='@')?'':q;
  if(m.kind==='atrule'){
    return cssLookup(pools?.selectors||[],cleanQ,CSS_HINT_LIMIT).filter(x=>String(x).startsWith('@'));
  }
  if(m.kind==='var'){
    if(off("Mimam's Var"))return[];
    return cssLookup(pools?.vars||[],cleanQ,CSS_HINT_LIMIT);
  }
  if(m.kind==='class')return off('CSS Classes')?[]:cssLookup(pools?.classes||[],cleanQ,CSS_HINT_LIMIT);
  if(m.kind==='id')return off('Element IDs')?[]:cssLookup(pools?.ids||[],cleanQ,CSS_HINT_LIMIT);
  if(m.kind==='selector')return cssLookup(pools?.selectors||[],cleanQ,CSS_HINT_LIMIT);
  if(ctx.inValue&&q.length>1){
    const varHits=off("Mimam's Var")?[]:cssLookup(pools?.vars||[],'--'+q.replace(/^--/,''),Math.floor(CSS_HINT_LIMIT*.6));
    const valueHits=cssLookup(pools?.values||[],q,Math.floor(CSS_HINT_LIMIT*.4));
    return [...varHits,...valueHits].slice(0,CSS_HINT_LIMIT);
  }
  if(ctx.inBlock)return cssLookup(pools?.props,q,CSS_HINT_LIMIT);
  return cssLookup(pools?.selectors,q,CSS_HINT_LIMIT);
}
function cssCommitSuggestion(item,match){
  const label=typeof item==='string'?item:String(item?.value||item?.label||'');
  if(!label)return{insert:'',cursor:null};
  if(match&&match.kind==='css'&&CSS_PROPS.includes(label))return{insert:label+':  ;',cursor:label.length+3};
  if(label.indexOf('--')===0&&(!match||!match.inVar)){
    const insert='var('+label+')';
    return{insert,cursor:insert.length};
  }
  return{insert:label,cursor:label.length};
}
function cssNextIndent(text,pos){
  const before=String(text||'').slice(0,pos);
  const line=before.split('\n').pop()||'';
  const base=(line.match(/^\s*/)||[''])[0];
  const trimmed=line.trim();
  if(!trimmed)return base;
  if(trimmed.endsWith('{'))return base+'  ';
  return trimmed.endsWith(';')?base:base+'  ';
}
function cssEnterInsert(text,pos){
  const s=String(text||'');
  const before=s.slice(0,pos);
  const after=s.slice(pos);
  const line=before.split('\n').pop()||'';
  const base=(line.match(/^\s*/)||[''])[0];
  const trimmed=line.trim();
  const ind=cssNextIndent(s,pos);
  if(trimmed.endsWith('{')&&after.trimStart().startsWith('}')){
    return{text:'\n'+ind+'\n'+base,cursor:1+ind.length};
  }
  return{text:'\n'+ind,cursor:1+ind.length};
}
function autoFormatCss(text){
  return String(text||'').replace(/;\s*/g,';\n  ').replace(/\{\s*/g,'{\n  ').replace(/\s*\}/g,'\n}\n').replace(/\n\s*\n\s*\n/g,'\n\n');
}
function cssEsc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function cssHighlight(text){
  const s=String(text||'');
  const re=/\/\*[\s\S]*?\*\/|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|#[0-9a-f]{3,8}\b|--[a-z0-9-]+|\b[a-z-]+(?=\s*:)|\b\d+(?:\.\d+)?(?:px|rem|em|%|vw|vh)?\b|[{}:;(),]/gi;
  let out='',last=0,m;
  while((m=re.exec(s))){
    out+=cssEsc(s.slice(last,m.index));
    const t=m[0];let cls='tok-punc';
    if(t.startsWith('/*'))cls='tok-comment';
    else if(t[0]==='"'||t[0]==="'")cls='tok-string';
    else if(t[0]==='#')cls='tok-color';
    else if(t.startsWith('--'))cls='tok-var';
    else if(/^\d/.test(t))cls='tok-num';
    else if(/^[a-z-]+$/i.test(t))cls='tok-prop';
    out+='<span class="'+cls+'">'+cssEsc(t)+'</span>';
    last=re.lastIndex;
  }
  out+=cssEsc(s.slice(last));
  return out||' ';
}
function cssCaretPos(el){
  if(!el)return{left:46,top:34};
  const text=el.value.slice(0,el.selectionStart||0);
  const lines=text.split('\n');
  const line=lines.length-1;
  const col=(lines[lines.length-1]||'').length;
  const left=38+10+Math.min(col*6.7,Math.max(80,el.clientWidth-190));
  const top=10+(line*17.6)-el.scrollTop+24;
  const maxTop=Math.max(32,el.clientHeight-145);
  return{left,top:Math.max(12,Math.min(top,maxTop))};
}
function cmHintFactory(poolsRef,disabledRef){
  return function(cm){
    const cur=cm.getCursor();
    const pos=cm.indexFromPos(cur);
    const text=cm.getValue();
    const before=text.slice(0,pos);
    const m=cssSuggestionMatch(before);
    if(!m)return{list:[],from:cur,to:cur};
    const list=cssSuggestions(text,pos,poolsRef.current,disabledRef.current).map(item=>{
      const label=typeof item==='string'?item:item.label;
      return{
        text:label,
        displayText:label,
        hint:function(editor){
          const packed=cssCommitSuggestion(item,m);
          const from=editor.posFromIndex(pos-(m.replaceLength||0));
          const to=editor.posFromIndex(pos);
          editor.replaceRange(packed.insert,from,to,'complete');
          const nextIndex=pos-(m.replaceLength||0)+(packed.cursor==null?packed.insert.length:packed.cursor);
          editor.setCursor(editor.posFromIndex(nextIndex));
        }
      };
    });
    return{list,from:cm.posFromIndex(pos-(m.replaceLength||0)),to:cur};
  };
}
function cmShouldHint(editor,typed){
  const cur=editor.getCursor();
  const pos=editor.indexFromPos(cur);
  const before=editor.getValue().slice(0,pos);
  const m=cssSuggestionMatch(before);
  if(!m)return false;
  if(m.kind==='atrule')return m.token.length>=1;
  if(m.kind==='var')return m.token.length>=2;
  if(m.kind==='class'||m.kind==='id')return m.token.length>=1;
  return /^[a-z-]$/i.test(typed||'')&&m.token.length>=2;
}
function CssCodeMirrorEditor({value,onChange,vars,remoteSuggestions,scss,disabledSources}){
  const hostRef=useRef();
  const cmRef=useRef(null);
  const onChangeRef=useRef(onChange);
  const commitTimerRef=useRef(null);
  const poolsRef=useRef(cssSuggestionPools(vars,remoteSuggestions));
  const disabledRef=useRef(disabledSources||[]);
  useEffect(()=>{onChangeRef.current=onChange;},[onChange]);
  useEffect(()=>{poolsRef.current=cssSuggestionPools(vars,remoteSuggestions);},[vars,remoteSuggestions]);
  useEffect(()=>{disabledRef.current=disabledSources||[];},[disabledSources]);
  useEffect(()=>{
    if(!hostRef.current||!window.CodeMirror)return;
    const CM=window.CodeMirror;
    const cm=CM(hostRef.current,{
      value:value||'',
      mode:scss?'text/x-scss':'css',
      lineNumbers:true,
      lineWrapping:true,
      indentUnit:2,
      tabSize:2,
      theme:'default',
      autoCloseBrackets:false,
      hintOptions:{hint:cmHintFactory(poolsRef,disabledRef),completeSingle:false,container:document.body,extraKeys:{}},
      extraKeys:{
        'Ctrl-Space':editor=>editor.showHint({hint:cmHintFactory(poolsRef,disabledRef),completeSingle:false,container:document.body}),
        'Cmd-Space':editor=>editor.showHint({hint:cmHintFactory(poolsRef,disabledRef),completeSingle:false,container:document.body}),
        'Tab':editor=>{
          if(editor.state.completionActive){editor.state.completionActive.pick();return;}
          const cur=editor.getCursor();
          const before=editor.getRange({line:cur.line,ch:0},cur);
          const m=before.match(/(\d+(?:\.\d+)?(?:px|rem|em|%)?)\s*([-+*/])\s*(\d+(?:\.\d+)?(?:px|rem|em|%)?)$/);
          if(m){
            const from={line:cur.line,ch:cur.ch-m[0].length};
            editor.replaceRange('calc('+m[0]+')',from,cur,'input');
            editor.setCursor({line:cur.line,ch:from.ch+6+m[0].length});
            return;
          }
          editor.showHint({hint:cmHintFactory(poolsRef,disabledRef),completeSingle:false,container:document.body});
        },
        'Enter':editor=>{
          const cur=editor.getCursor();
          const pos=editor.indexFromPos(cur);
          const packed=cssEnterInsert(editor.getValue(),pos);
          editor.replaceSelection(packed.text,'end','input');
          editor.setCursor(editor.posFromIndex(pos+packed.cursor));
        }
      }
    });
    cmRef.current=cm;
    const scheduleCommit=editor=>{
      if(commitTimerRef.current)clearTimeout(commitTimerRef.current);
      commitTimerRef.current=setTimeout(()=>{
        commitTimerRef.current=null;
        onChangeRef.current(editor.getValue());
      },140);
    };
    const flushCommit=editor=>{
      if(commitTimerRef.current)clearTimeout(commitTimerRef.current);
      commitTimerRef.current=null;
      onChangeRef.current(editor.getValue());
    };
    cm.on('beforeChange',(editor,change)=>{
      if(change.origin!=='+input'||!change.text||change.text.length!==1||change.text[0]!=='{')return;
      const selected=editor.getRange(change.from,change.to);
      change.update(change.from,change.to,[selected?'{'+selected+'}':'{}']);
      editor.state.veBraceCursor={line:change.from.line,ch:change.from.ch+1};
    });
    cm.on('changes',scheduleCommit);
    cm.on('changes',editor=>{
      if(!editor.state.veBraceCursor)return;
      const cur=editor.state.veBraceCursor;
      editor.state.veBraceCursor=null;
      editor.setCursor(cur);
    });
    cm.on('blur',flushCommit);
    cm.on('inputRead',(editor,change)=>{
      const t=(change.text||[]).join('');
      if(cmShouldHint(editor,t)){
        clearTimeout(editor.state.veHintTimer);
        editor.state.veHintTimer=setTimeout(()=>editor.showHint({hint:cmHintFactory(poolsRef,disabledRef),completeSingle:false,container:document.body}),90);
      }
    });
    setTimeout(()=>cm.refresh(),40);
    return()=>{
      if(commitTimerRef.current)clearTimeout(commitTimerRef.current);
      if(cm.state.veHintTimer)clearTimeout(cm.state.veHintTimer);
      cm.toTextArea?cm.toTextArea():cm.getWrapperElement().remove();
      cmRef.current=null;
    };
  },[]);
  useEffect(()=>{const cm=cmRef.current;if(cm&&value!==cm.getValue()&&!cm.hasFocus())cm.setValue(value||'');},[value]);
  return h('div',{class:'ve-cm-host',ref:hostRef});
}
function CssEditor({value,onChange,vars,sourceOrder,remoteSuggestions,scss,disabledSources}){
  if(window.CodeMirror)return h(CssCodeMirrorEditor,{value,onChange,vars,remoteSuggestions,scss,disabledSources});
  const[draft,sDraft]=useState(value||'');
  const[sel,sSel]=useState([]);
  const[active,sActive]=useState(0);
  const[suggestPos,sSuggestPos]=useState({left:46,top:34});
  const ref=useRef();
  const hiRef=useRef();
  const commitRef=useRef(null);
  const suggestRef=useRef(null);
  const editingRef=useRef(false);
  const pools=useMemo(()=>cssSuggestionPools(vars,remoteSuggestions),[vars,remoteSuggestions]);
  useEffect(()=>{if(!editingRef.current)sDraft(value||'');},[value]);
  useEffect(()=>()=>{if(commitRef.current)clearTimeout(commitRef.current);if(suggestRef.current)cancelAnimationFrame(suggestRef.current);},[]);
  const commit=v=>{if(commitRef.current)clearTimeout(commitRef.current);commitRef.current=setTimeout(()=>onChange(v),120);};
  const commitNow=v=>{if(commitRef.current)clearTimeout(commitRef.current);commitRef.current=null;onChange(v);};
  const updateSuggest=()=>{const el=ref.current;if(!el){sSel([]);return;}sSel(cssSuggestions(el.value,el.selectionStart||0,pools,disabledSources));sSuggestPos(cssCaretPos(el));sActive(0);};
  const queueSuggest=()=>{if(suggestRef.current)cancelAnimationFrame(suggestRef.current);suggestRef.current=requestAnimationFrame(updateSuggest);};
  useEffect(()=>{const el=ref.current;if(el&&document.activeElement===el)queueSuggest();},[pools,disabledSources]);
  const setEditorValue=(next,pos)=>{
    sDraft(next);commit(next);sSel([]);
    setTimeout(()=>{const el=ref.current;if(!el)return;el.focus();if(pos!=null)el.setSelectionRange(pos,pos);},0);
  };
  const applySuggestion=(item)=>{
    const el=ref.current;if(!el)return;
    const start=el.selectionStart||0;const before=el.value.slice(0,start);const after=el.value.slice(el.selectionEnd||start);
    const m=cssSuggestionMatch(before);
    if(!m)return;
    const packed=cssCommitSuggestion(item,m);
    const insert=packed.insert;
    const cut=m.replaceLength||0;
    const next=before.slice(0,before.length-cut)+insert+after;
    const p=before.length-cut+(packed.cursor==null?insert.length:packed.cursor);
    setEditorValue(next,p);
  };
  const onKey=e=>{
    if((e.ctrlKey||e.metaKey)&&e.key===' '){e.preventDefault();updateSuggest();return;}
    if(e.key==='Tab'&&sel.length){e.preventDefault();applySuggestion(sel[active]||sel[0]);return;}
    if(e.key==='ArrowDown'&&sel.length){e.preventDefault();sActive(i=>Math.min(sel.length-1,i+1));return;}
    if(e.key==='ArrowUp'&&sel.length){e.preventDefault();sActive(i=>Math.max(0,i-1));return;}
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='d'){
      e.preventDefault();
      const el=e.currentTarget;const start=el.selectionStart||0;const end=el.selectionEnd||start;
      const lineStart=el.value.lastIndexOf('\n',start-1)+1;
      let lineEnd=el.value.indexOf('\n',end);if(lineEnd<0)lineEnd=el.value.length;
      const line=el.value.slice(lineStart,lineEnd);
      const next=el.value.slice(0,lineEnd)+'\n'+line+el.value.slice(lineEnd);
      setEditorValue(next,lineEnd+1+line.length);return;
    }
    if(e.key==='{'){
      e.preventDefault();
      const el=e.currentTarget;const p=el.selectionStart||0;const end=el.selectionEnd||p;
      const before=el.value.slice(0,p),selected=el.value.slice(p,end),after=el.value.slice(end);
      const insert=selected?'{'+selected+'}':'{\n  \n}';
      const next=before+insert+after;
      setEditorValue(next,before.length+(selected?insert.length:4));return;
    }
    if(e.key==='}'&&e.currentTarget.value[e.currentTarget.selectionStart||0]==='}'){
      e.preventDefault();const p=(e.currentTarget.selectionStart||0)+1;e.currentTarget.setSelectionRange(p,p);return;
    }
    if(e.key==='Tab'){
      const el=e.currentTarget;const p=el.selectionStart||0;const m=el.value.slice(0,p).match(/(\d+(?:\.\d+)?(?:px|rem|em|%)?)\s*([-+*/])\s*(\d+(?:\.\d+)?(?:px|rem|em|%)?)$/);
      if(m){e.preventDefault();const before=el.value.slice(0,p-m[0].length);const after=el.value.slice(el.selectionEnd||p);const next=before+'calc('+m[0]+')'+after;setEditorValue(next,before.length+6+m[0].length);}
    }
    if(e.key==='Enter'){
      e.preventDefault();
      const el=e.currentTarget;const p=el.selectionStart||0;const end=el.selectionEnd||p;
      const packed=cssEnterInsert(el.value,p);
      const next=el.value.slice(0,p)+packed.text+el.value.slice(end);
      setEditorValue(next,p+packed.cursor);return;
    }
  };
  const onInput=e=>{
    const v=e.target.value;
    sDraft(v);
    commit(v);
    queueSuggest();
  };
  const lines=useMemo(()=>Array.from({length:cssLineCount(draft)},(_,i)=>i+1).join('\n'),[draft]);
  const highlighted=useMemo(()=>cssHighlight(draft),[draft]);
  const syncScroll=e=>{if(hiRef.current){hiRef.current.scrollTop=e.currentTarget.scrollTop;hiRef.current.scrollLeft=e.currentTarget.scrollLeft;}queueSuggest();};
  return h('div',{class:'ve-code-wrap'},
    h('div',{class:'ve-code-shell'},
      h('pre',{class:'ve-code-lines'},lines),
      h('div',{class:'ve-code-editor'},
        h('pre',{ref:hiRef,class:'ve-code-highlight',dangerouslySetInnerHTML:{__html:highlighted}}),
        h('textarea',{ref,class:'ve-code-input',value:draft,onInput,onKeyDown:onKey,onClick:queueSuggest,onKeyUp:queueSuggest,onFocus:()=>{editingRef.current=true;queueSuggest();},onBlur:()=>{editingRef.current=false;commitNow(ref.current?ref.current.value:draft);},onSelect:queueSuggest,onScroll:syncScroll,placeholder:'/* Type . for classes, # for IDs, or -- for variables */\n.selector {\n  color: var(--color-primary);\n}'}))),
    sel.length>0&&h('div',{class:'ve-suggest',style:{left:suggestPos.left+'px',top:suggestPos.top+'px'}},sel.map((x,i)=>h('button',{type:'button',class:i===active?'on':'',onMouseDown:e=>{e.preventDefault();applySuggestion(x);}},typeof x==='string'?x:x.label))),
    h('div',{style:'font-size:9px;color:#666;line-height:1.55;margin-top:6px'},'Tab completes suggestions. Ctrl+D duplicates the current line/selection. After a small math expression like 100% - 20px, Tab wraps it in calc().',scss?' SCSS mode keeps nested syntax while compile support remains plain CSS-safe.':''));
}

/* ── CSS Studio sub-panel ─────────────── */
function AdvancedCssSub({onClose,exiting,vars}){
  const[sheets,sSheets]=useState(DEFAULT_CSS_SHEETS);
  const[sel,sSel]=useState('global');
  const[ld,sLd]=useState(false);
  const[msg,sMsg]=useState('');
  const[scss,sScss]=useState(()=>localStorage.getItem('ve_css_scss')==='1');
  const[sourceOrder,sSourceOrder]=useState(()=>{try{return normalizeSourceOrder(JSON.parse(localStorage.getItem('ve_css_source_order')||'[]'),[]);}catch(e){return CSS_SOURCE_DEFAULTS;}});
  const[remoteSuggestions,sRemoteSuggestions]=useState({variables:[],classes:[],ids:[],sources:[]});
  const[disabledSources,sDisabledSources]=useState(()=>{try{return JSON.parse(localStorage.getItem('ve_css_disabled_sources')||'[]');}catch(e){return[];}});
  const[pendingDelete,sPendingDelete]=useState(null);

  useEffect(() => {
    const handler = () => {
      sScss(localStorage.getItem('ve_css_scss') === '1');
      try {
        sSourceOrder(normalizeSourceOrder(JSON.parse(localStorage.getItem('ve_css_source_order') || '[]'), []));
      } catch(e) {}
      try {
        sDisabledSources(JSON.parse(localStorage.getItem('ve_css_disabled_sources') || '[]'));
      } catch(e) {}
    };
    window.addEventListener('ve-css-settings-changed', handler);
    return () => {
      window.removeEventListener('ve-css-settings-changed', handler);
    };
  }, []);

  useEffect(()=>{
    api.g('advanced-css').then(d=>{let a=d?.stylesheets||[];if(a.length){const legacy=a.length===3&&a.every(x=>['page','global','child'].includes(x.id))&&a.every(x=>!String(x.css||'').trim());if(legacy)a=DEFAULT_CSS_SHEETS;sSheets(a);sSel((a.find(x=>x.id==='global')||a[0])?.id||'global');}}).catch(()=>{});
    api.g('advanced-css/suggestions').then(d=>{if(d&&!d.code){sRemoteSuggestions(d);}}).catch(()=>{});
  },[]);

  const cur=sheets.find(x=>x.id===sel)||sheets[0]||null;
  const upd=(patch)=>sSheets(arr=>arr.map(x=>x.id===(cur?.id)?{...x,...patch}:x));
  const add=()=>{const id='custom_'+Date.now();const next={id,name:'custom.css',scope:'custom',enabled:true,css:''};sSheets(a=>[...a,next]);sSel(id);};
  const delSheet=(sheet,e)=>{e&&e.stopPropagation();if(sheets.length<=1)return;sPendingDelete(sheet);};
  const confirmDelSheet=()=>{const sheet=pendingDelete;if(!sheet)return;const next=sheets.filter(x=>x.id!==sheet.id);sSheets(next);if(sel===sheet.id)sSel((next.find(x=>x.id==='global')||next[0])?.id||'global');sPendingDelete(null);};
  const save=async()=>{sLd(true);sMsg('');const r=await api.p('advanced-css',{stylesheets:sheets});sLd(false);if(r?.code){sMsg(r.message||'Save failed');return;}sSheets(r.stylesheets||sheets);sMsg('Saved and compiled.');};
  const scopeHelp={page:'Scope: renders only where page-level targeting is supported. Use for CSS that should stay narrow.',global:'Scope: renders site-wide. Use for CSS that should work everywhere.',child:'Scope: renders as a child-theme-style layer for broad theme overrides.',custom:'Scope: custom named stylesheet. Use when you want a separate editable layer.'};
  const warnings=useMemo(()=>cssValidation(cur?.css||''),[cur?.id,cur?.css]);

  return h('div',{class:'ve-body ve-css-studio-combined'},
      pendingDelete&&h(ConfirmModal,{title:'Delete stylesheet',body:'Delete stylesheet "'+pendingDelete.name+'"? This will be removed when you save and compile.',confirmText:'Delete',danger:true,onCancel:()=>sPendingDelete(null),onConfirm:confirmDelSheet}),
      h('div',{class:'ve-css-studio-combined-grid'},
        h('div',{class:'ve-css-settings-column ve-scroll-custom'},
          h('div',{class:'ve-studio-top'},
            h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:add},'+ New Stylesheet')),
          h('div',{style:'display:grid;grid-template-columns:'+(sheets.length>1?'115px minmax(0,1fr)':'1fr')+';gap:10px;min-height:0'},
            sheets.length>1&&h('div',{class:'ve-css-sheet-list ve-scroll-custom'},sheets.map(x=>h('button',{key:x.id,type:'button',class:'ve-btn '+(x.id===sel?'':'ve-btn-g')+' ve-btn-s ve-sheet-tab',onClick:()=>sSel(x.id)},h('span',null,x.name),sheets.length>1&&h('span',{class:'ve-sheet-del',title:'Delete stylesheet',onClick:e=>delSheet(x,e)},ph('trash'))))),
            cur&&h('div',{class:'ve-studio-main',style:'padding:0;overflow:visible'},
              h('div',{class:'ve-row'},h('input',{class:'ve-studio-input',value:cur.name,onInput:e=>upd({name:e.target.value}),placeholder:'stylesheet name'})),
              h('div',{class:'ve-scope-label'},'Stylesheet Scope'),
              h('div',{class:'ve-row'},
                h(SelectMenu,{value:cur.scope,onChange:v=>upd({scope:v}),options:['page','global','child','custom']}),
                h('label',{style:'display:flex;align-items:center;gap:7px;font-size:10px;color:#bbb;min-height:38px'},h('input',{type:'checkbox',checked:!!cur.enabled,onChange:e=>upd({enabled:e.target.checked})}),'Enabled')),
              h('div',{style:'font-size:9px;color:#777;line-height:1.55;margin:0 0 8px'},(scopeHelp[cur.scope]||scopeHelp.custom)+' This dropdown determines where and how widely this stylesheet renders/works.'),
              warnings.length>0&&h('div',{class:'ve-css-diag'},warnings.map(w=>h('div',null,w))))),
          h('div',{style:'font-size:9px;color:#666;line-height:1.6;margin-top:auto'},"CSS Studio compiles after Mimam's Var variables on the frontend and in admin/builder screens.")),
        cur&&h('div',{class:'ve-css-editor-column'},
          h('div',{class:'ve-editor-only'},
            h(CssEditor,{value:cur.css,onChange:v=>upd({css:v}),vars,sourceOrder,remoteSuggestions,scss,disabledSources}),
            h('div',{class:'ve-editor-actions'},
              h('small',null,msg || "Compile after editing this stylesheet."),
              h('button',{class:'ve-btn ve-btn-s',onClick:save,disabled:ld},ld?'Saving...':'Save & Compile')))))
    );
}

function CssRecipesStudioSub({ flash, vars }) {
  const [userRecipes, setUserRecipes] = useState(() => loadUserCssRecipes());
  const [code, setCode] = useState('custom');
  const [name, setName] = useState('');
  const [css, setCss] = useState('');
  const [editingCode, setEditingCode] = useState(null);
  const [editingBuiltin, setEditingBuiltin] = useState(false);
  const [scss, setScss] = useState(() => localStorage.getItem('ve_css_scss') === '1');
  const [sourceOrder, setSourceOrder] = useState(() => { try { return normalizeSourceOrder(JSON.parse(localStorage.getItem('ve_css_source_order') || '[]'), []); } catch (e) { return CSS_SOURCE_DEFAULTS; } });
  const [remoteSuggestions, setRemoteSuggestions] = useState({ variables: [], classes: [], ids: [], sources: [] });
  const [disabledSources, setDisabledSources] = useState(() => { try { return JSON.parse(localStorage.getItem('ve_css_disabled_sources') || '[]'); } catch (e) { return []; } });
  const builtins = CSS_RECIPES;

  useEffect(() => {
    api.g('advanced-css/suggestions').then(d => { if (d && !d.code) setRemoteSuggestions(d); }).catch(() => {});
    const handler = () => {
      setScss(localStorage.getItem('ve_css_scss') === '1');
      try { setSourceOrder(normalizeSourceOrder(JSON.parse(localStorage.getItem('ve_css_source_order') || '[]'), [])); } catch (e) {}
      try { setDisabledSources(JSON.parse(localStorage.getItem('ve_css_disabled_sources') || '[]')); } catch (e) {}
    };
    window.addEventListener('ve-css-settings-changed', handler);
    return () => window.removeEventListener('ve-css-settings-changed', handler);
  }, []);

  const persistUserRecipes = next => {
    setUserRecipes(next);
    saveUserCssRecipes(next);
  };

  const resetRecipeForm = () => {
    setCode('custom');
    setName('');
    setCss('');
    setEditingCode(null);
    setEditingBuiltin(false);
  };

  const saveRecipe = e => {
    e && e.preventDefault();
    const cleanCode = (code || '').trim().replace(/^@+/, '').replace(/[^a-z0-9_-]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').toLowerCase();
    const finalCode = '@' + cleanCode;
    if (!finalCode || finalCode === '@' || !css.trim()) {
      flash('Add a shortcode and CSS first.');
      return;
    }
    const nextRecipe = { code: finalCode, name: (name || finalCode.replace(/^@/, '')).trim(), css: css.trim() };
    const next = [...userRecipes.filter(r => r.code !== finalCode), nextRecipe].sort((a,b)=>a.code.localeCompare(b.code));
    persistUserRecipes(next);
    resetRecipeForm();
    flash('Recipe saved. Type ' + finalCode + ' then press Tab in CSS Studio.');
  };

  const removeRecipe = recipe => {
    persistUserRecipes(userRecipes.filter(r => r.code !== recipe.code));
    flash('Recipe removed.');
  };

  const loadRecipe = (recipe, builtin) => {
    setCode(String(recipe.code || '').replace(/^@/, ''));
    setName(recipe.name || '');
    setCss(recipe.css || '');
    setEditingCode(recipe.code || null);
    setEditingBuiltin(!!builtin);
    flash('Loaded ' + recipe.code + ' into the recipe editor.');
  };

  const recipeTitle = editingCode ? (editingBuiltin ? 'Built-in Recipe Preview' : 'Edit Recipe') : 'New Recipe';

  const recipeCard = (recipe, builtin) => h('div', { class: 've-recipe-card', key: (builtin ? 'b-' : 'u-') + recipe.code, role: 'button', tabIndex: 0, onClick: () => loadRecipe(recipe, builtin), onKeyDown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); loadRecipe(recipe, builtin); } } },
    h('span', { class: 've-recipe-code' }, recipe.code),
    h('div', null,
      h('strong', null, recipe.name || recipe.code),
      h('small', null, 'Click to load this recipe output')
    ),
    builtin ? h('span', { style: 'font-size:9px;color:#777;text-transform:uppercase;font-weight:700' }, 'Built in') :
      h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: e => { e.stopPropagation(); removeRecipe(recipe); }, title: 'Delete recipe' }, ph('trash'))
  );

  return h('div', { class: 've-recipe-studio' },
    h('div', { class: 've-recipe-studio-main' },
      h('div', { class: 've-recipe-list ve-scroll-custom' },
        h('div', { class: 've-studio-nav-title', style: 'margin-bottom:2px' }, 'Recipe Shortcodes'),
        builtins.map(r => recipeCard(r, true)),
        userRecipes.length ? userRecipes.map(r => recipeCard(r, false)) : h('div', { class: 've-empty', style: 'padding:16px;text-align:left' }, 'No custom recipes yet.')
      ),
      h('form', { class: 've-recipe-form', onSubmit: saveRecipe },
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:10px' },
          h('div', { class: 've-studio-nav-title', style: 'margin:0' }, recipeTitle),
          editingCode && h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: resetRecipeForm }, '+ New Recipe')
        ),
        h('label', { class: 've-recipe-field' }, h('span', { class: 've-scope-label' }, 'Shortcode'), h('div', { class: 've-recipe-shortcode' },
          h('span', { class: 've-studio-input' }, '@'),
          h('input', {
            class: 've-studio-input',
            name: 've_recipe_shortcode',
            value: code,
            autoComplete: 'off',
            'data-1p-ignore': 'true',
            'data-lpignore': 'true',
            onInput: e => setCode(String(e.target.value || '').replace(/^@+/, '')),
            placeholder: 'section'
          })
        )),
        h('label', { class: 've-recipe-field' }, h('span', { class: 've-scope-label' }, 'Name'), h('input', {
          class: 've-studio-input',
          name: 've_recipe_title',
          value: name,
          autoComplete: 'off',
          'data-1p-ignore': 'true',
          'data-lpignore': 'true',
          onInput: e => setName(e.target.value),
          placeholder: 'Section rhythm'
        })),
        h('label', { class: 've-recipe-field', style: 'min-height:0;flex:0 0 auto' },
          h('span', { class: 've-scope-label' }, 'CSS'),
          h('div', { class: 've-recipe-editor' },
            h(CssEditor, { value: css, onChange: setCss, vars, sourceOrder, remoteSuggestions, scss, disabledSources })
          )
        ),
        h('div', { class: 've-recipe-form-actions' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: resetRecipeForm }, editingCode ? 'Cancel Edit' : 'Clear'),
          h('button', { class: 've-btn ve-btn-s', type: 'submit' }, editingBuiltin ? 'Save as Custom Recipe' : 'Save Recipe')
        ),
        h('div', { style: 'font-size:10px;color:#777;line-height:1.55' }, 'Click any shortcode to load its output into this editor, then save it as a custom recipe when needed.')
      )
    )
  );
}

/* ── Color generate sub-panel ─────────── */
function GenColorSub({variable,childMap,onDone,onClose,exiting}){
  const has=(childMap[variable.id]||[]).length>0;
  const[ok,sOk]=useState(!has);
  const[tints,sT]=useState(true);const[shades,sS]=useState(true);const[alpha,sA]=useState(true);
  const[tN,sTN]=useState(8);const[sN,sSN]=useState(8);const[aN,sAN]=useState(8);const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const run=async()=>{sLd(true);sErr('');
    const r=await api.p(`variables/${variable.id}/generators`,{type:'color',replace:has,config:{tint_count:tints?tN:0,shade_count:shades?sN:0,include_alpha:alpha,alpha_count:alpha?aN:0}});
    sLd(false);if(r?.code){sErr(r.message||'Could not generate color variants.');return;}onDone();};
  return h(Sub,{title:'Generate: '+sn(variable.name),onClose,exiting},
    has&&!ok?h('div',null,h('div',{class:'ve-warn'},'This color already has variants. Continuing replaces them.'),
      h('div',{style:'display:flex;gap:5px;margin-top:8px'},h('button',{class:'ve-btn',onClick:()=>sOk(true)},'Continue')))
    :h('div',null,
      h('div',{class:'ve-opt'},h('label',null,h('input',{type:'checkbox',checked:tints,onChange:e=>sT(e.target.checked)}),'Tints'),h('input',{type:'number',min:0,max:20,value:tN,onInput:e=>sTN(+e.target.value),disabled:!tints})),
      h('div',{class:'ve-opt'},h('label',null,h('input',{type:'checkbox',checked:shades,onChange:e=>sS(e.target.checked)}),'Shades'),h('input',{type:'number',min:0,max:20,value:sN,onInput:e=>sSN(+e.target.value),disabled:!shades})),
      h('div',{class:'ve-opt'},h('label',null,h('input',{type:'checkbox',checked:alpha,onChange:e=>sA(e.target.checked)}),'Alpha'),h('input',{type:'number',min:0,max:20,value:aN,onInput:e=>sAN(+e.target.value),disabled:!alpha})),
      err&&h('div',{style:'font-size:10px;color:#ef4444;padding:6px 0 0'},err),
      h('div',{style:'display:flex;gap:5px;margin-top:10px;justify-content:flex-end'},h('button',{class:'ve-btn',onClick:run,disabled:ld},ld?'Generating...':'Generate'))));
}

/* ── Scale generate sub-panel (reads viewport from settings) ── */
function GenScaleSub({variable,onDone,onClose,exiting}){
  const bv=pxV(variable.value)||16;
  const[bMin,sBM]=useState(bv);const[bMax,sBX]=useState(Math.round(bv*1.125));
  const[scMin,sSM]=useState('major-third');const[scMax,sSX]=useState('major-third');
  const[up,sUp]=useState(3);const[dn,sDn]=useState(2);const[ld,sLd]=useState(false);
  const[vwMin,sVWM]=useState(320);const[vwMax,sVWX]=useState(1440);
  const[err,sErr]=useState('');

  useEffect(()=>{api.g('settings').then(d=>{if(d&&d.vw_min)sVWM(d.vw_min);if(d&&d.vw_max)sVWX(d.vw_max);});},[]);

  const run=async()=>{sLd(true);sErr('');
    const ns=variable.namespace;const tp=(ns==='font'||ns==='heading'||ns==='text')?'typography':ns==='space'?'spacing':ns==='radius'?'radius':ns==='size'?'size':'spacing';
    const r=await api.p(`variables/${variable.id}/generators`,{type:tp,replace:true,config:{base_min:bMin,base_max:bMax,scale_min:scMin,scale_max:scMax,steps_up:up,steps_down:dn,vw_min:vwMin,vw_max:vwMax,naming:'numeric'}});
    sLd(false);if(r?.code){sErr(r.message||'Could not generate the fluid scale.');return;}onDone();};
  return h(Sub,{title:'Fluid scale: '+sn(variable.name),onClose,exiting},
    h('div',{class:'ve-opt'},h('span',null,'Base min (mobile)'),h('input',{type:'number',value:bMin,onInput:e=>sBM(+e.target.value),step:'0.1'})),
    h('div',{class:'ve-opt'},h('span',null,'Base max (desktop)'),h('input',{type:'number',value:bMax,onInput:e=>sBX(+e.target.value),step:'0.1'})),
    h('div',{class:'ve-opt'},h('span',null,'Scale min'),h(SelectMenu,{className:'ve-opt-menu',value:scMin,onChange:sSM,options:SCALES})),
    h('div',{class:'ve-opt'},h('span',null,'Scale max'),h(SelectMenu,{className:'ve-opt-menu',value:scMax,onChange:sSX,options:SCALES})),
    h('div',{class:'ve-opt'},h('span',null,'Steps up'),h('input',{type:'number',min:0,max:8,value:up,onInput:e=>sUp(+e.target.value)})),
    h('div',{class:'ve-opt'},h('span',null,'Steps down'),h('input',{type:'number',min:0,max:8,value:dn,onInput:e=>sDn(+e.target.value)})),
    h('div',{style:'font-size:9px;color:#444;padding:4px 0;border-top:1px solid #2a2a2a;margin-top:6px'},'Viewport: '+vwMin+'px → '+vwMax+'px (from Settings)'),
    err&&h('div',{style:'font-size:10px;color:#ef4444;padding:6px 0 0'},err),
    h('div',{style:'display:flex;gap:5px;margin-top:10px;justify-content:flex-end'},h('button',{class:'ve-btn',onClick:run,disabled:ld},ld?'Generating...':'Generate')));
}

function cssVarToTokenName(name){
  let n=String(name||'').trim().toLowerCase().replace(/^--/,'').replace(/[^a-z0-9-]/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'');
  if(!n)return'';
  return n.replace(/-/g,'.');
}
function parseCssVariables(text){
  const clean=String(text||'').replace(/\/\*[\s\S]*?\*\//g,'');
  const re=/--([a-zA-Z0-9_-]+)\s*:\s*([^;]+);/g;
  const out=[];const seen={};let m;
  while((m=re.exec(clean))){
    const publicCssName='--'+String(m[1]||'').toLowerCase();
    const name=cssVarToTokenName('--'+m[1]);
    const value=String(m[2]||'').trim();
    if(!name||!value)continue;
    const aliasMatch=value.match(/^var\(\s*(--[a-zA-Z0-9_-]+)\s*(?:,\s*[^)]+)?\)$/);
    seen[name]={name,value,namespace:name.split('.')[0],type:aliasMatch?'alias':'base',public_css_name:publicCssName,source_css_name:aliasMatch?String(aliasMatch[1]).toLowerCase():''};
  }
  Object.keys(seen).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).forEach(k=>out.push(seen[k]));
  return out;
}

function ThemePanel({onClose,exiting,onChanged}){
  const[data,sData]=useState({active:'default',palettes:[]});
  const[name,sName]=useState('');
  const[editing,sEditing]=useState(null);
  const[editName,sEditName]=useState('');
  const[ld,sLd]=useState(false);
  const[err,sErr]=useState('');
  const[confirmDelete,sConfirmDelete]=useState(null);
  const load=async()=>{const r=await api.g('themes');if(r&&!r.code)sData(r);};
  useEffect(()=>{load();},[]);
  const finish=async message=>{await load();onChanged&&onChanged();if(message)window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:message}));};
  const create=async()=>{if(!name.trim())return;sLd(true);sErr('');const r=await api.p('themes',{name:name.trim(),source_slug:data.active});sLd(false);if(r?.code){sErr(r.message||'Could not create theme.');return;}sName('');await finish('Theme created');};
  const activate=async slug=>{sLd(true);sErr('');const r=await api.p('themes/'+slug+'/activate',{});sLd(false);if(r?.code){sErr(r.message||'Could not switch theme.');return;}await finish('Theme switched');};
  const duplicate=async p=>{sLd(true);sErr('');const r=await api.p('themes/'+p.slug+'/duplicate',{name:p.name+' Copy'});sLd(false);if(r?.code){sErr(r.message||'Could not duplicate theme.');return;}await finish('Theme duplicated');};
  const rename=async()=>{if(!editing||!editName.trim())return;sLd(true);sErr('');const r=await api.u('themes/'+editing,{name:editName.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not rename theme.');return;}sEditing(null);sEditName('');await finish('Theme renamed');};
  const remove=async()=>{if(!confirmDelete)return;const slug=confirmDelete.slug;sConfirmDelete(null);sLd(true);sErr('');const r=await api.d('themes/'+slug);sLd(false);if(r?.code){sErr(r.message||'Could not delete theme.');return;}await finish('Theme deleted');};
  const active=data.palettes.find(p=>p.slug===data.active);
  const rows=data.palettes.map(p=>{
    const info=editing===p.slug
      ? h('div',{style:'display:flex;gap:4px'},h('input',{class:'ve-studio-input',type:'text',value:editName,onInput:e=>sEditName(e.target.value),onKeyDown:e=>{if(e.key==='Enter')rename();if(e.key==='Escape')sEditing(null);},style:'flex:1;min-width:0;font-size:11px;'}),h('button',{class:'ve-btn',onClick:rename,disabled:ld},'Save'))
      : h('div',{class:'ve-palette-row-name'},p.name);
    return h('div',{class:'ve-palette-row',key:p.slug},
      h('button',{class:'ve-a',title:p.active?'Active theme':'Activate '+p.name,onClick:()=>!p.active&&activate(p.slug),disabled:ld},ph(p.active?'check-circle':'circle')),
      h('div',{class:'ve-palette-row-info'},info,h('div',{class:'ve-palette-row-meta'},p.active?'Active · ':'',p.slug==='default'?'Uses base variable values':(p.value_count||0)+' color values')),
      h('div',{class:'ve-palette-actions'},
        h('button',{class:'ve-a',title:'Duplicate theme',onClick:()=>duplicate(p),disabled:ld},ph('copy')),
        !p.protected&&h('button',{class:'ve-a',title:'Rename theme',onClick:()=>{sEditing(p.slug);sEditName(p.name);},disabled:ld},ph('pencil-simple')),
        !p.protected&&h('button',{class:'ve-a',title:'Delete theme',onClick:()=>sConfirmDelete(p),disabled:ld},ph('trash'))));
  });
  return h(Sub,{title:'Color Themes',onClose,exiting},
    confirmDelete&&h(ConfirmModal,{title:'Delete theme',body:'Delete “'+confirmDelete.name+'”? Its alternate color values will be removed. The underlying variables remain safe.',confirmText:'Delete Theme',danger:true,onCancel:()=>sConfirmDelete(null),onConfirm:remove}),
    h('div',{class:'ve-palette-current'},h('i',{class:'ph-duotone ph-palette',style:'font-size:18px;color:#baf400;line-height:1'}),h('div',null,h('div',{style:'font-size:8px;color:#666;text-transform:uppercase;letter-spacing:.5px;font-weight:600'},'Active theme'),h('div',{style:'font-size:13px;color:#e8e8e8;font-weight:700;margin-top:1px'},active?.name||'Default'))),
    h('div',{class:'ve-import-help'},'Themes change color values without changing token names. Create one from the active values, switch it on, then edit Color variables normally.'),
    h('div',{style:'display:flex;gap:5px;margin-bottom:10px'},h('input',{class:'ve-studio-input',type:'text',value:name,onInput:e=>sName(e.target.value),placeholder:'New theme name',onKeyDown:e=>e.key==='Enter'&&create(),style:'flex:1;font-size:11px;'}),h('button',{class:'ve-btn',onClick:create,disabled:ld||!name.trim()},'Create')),
    err&&h('div',{style:'font-size:10px;color:#ef4444;padding:0 0 8px'},err),
    h('div',{style:'flex:1;min-height:0;overflow-y:auto'},rows));
}

function ColorPalettePanel({onClose,exiting,onChanged,inline=false,selectedPaletteId='all'}){
  const[data,sData]=useState({palettes:[]});
  const [draggingPaletteId, sDraggingPaletteId] = useState(null);
  const [dragOverPaletteId, sDragOverPaletteId] = useState(null);
  const handlePaletteDrop = async (e, targetPalette) => {
    e.preventDefault();
    const sourceId = Number(e.dataTransfer.getData('text/plain'));
    sDraggingPaletteId(null);
    sDragOverPaletteId(null);
    if (!sourceId || sourceId === targetPalette.id) return;

    const currentList = [...data.palettes];
    const sourceIdx = currentList.findIndex(x => x.id === sourceId);
    const targetIdx = currentList.findIndex(x => x.id === targetPalette.id);
    if (sourceIdx === -1 || targetIdx === -1) return;

    const [removed] = currentList.splice(sourceIdx, 1);
    currentList.splice(targetIdx, 0, removed);

    const orderedIds = currentList.map(x => x.id);

    sData(prev => ({
      ...prev,
      palettes: currentList.map((x, idx) => ({ ...x, position: idx }))
    }));

    try {
      const res = await api.p('color-palettes/reorder', { ids: orderedIds });
      if (res && !res.code) {
        window.dispatchEvent(new CustomEvent('ve-toast-request', { detail: 'Palettes reordered' }));
      } else {
        window.dispatchEvent(new CustomEvent('ve-toast-request', { detail: res?.message || 'Failed to reorder' }));
      }
      await load();
    } catch(err) {
      window.dispatchEvent(new CustomEvent('ve-toast-request', { detail: 'Failed to reorder' }));
      await load();
    }
  };
  const[name,sName]=useState('');
  const[editing,sEditing]=useState(null);
  const[editName,sEditName]=useState('');
  const[ld,sLd]=useState(false);
  const[err,sErr]=useState('');
  const[confirmDuplicate,sConfirmDuplicate]=useState(null);
  const[deleteState,sDeleteState]=useState(null);
  const[deleteDestination,sDeleteDestination]=useState('');
  const load=async()=>{const r=await api.g('color-palettes');if(r&&!r.code)sData(r);};
  useEffect(()=>{load();},[]);
  const finish=async message=>{await load();onChanged&&onChanged();if(message)window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:message}));};
  const create=async()=>{if(!name.trim())return;sLd(true);sErr('');const r=await api.p('color-palettes',{name:name.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not create palette.');return;}sName('');await finish('Empty palette created');};
  const duplicate=async()=>{if(!confirmDuplicate)return;const p=confirmDuplicate;sConfirmDuplicate(null);sLd(true);sErr('');const r=await api.p('color-palettes/'+p.id+'/duplicate',{name:p.name+' Copy'});sLd(false);if(r?.code){sErr(r.message||'Could not duplicate palette.');return;}await finish('Palette and its colors duplicated');};
  const rename=async()=>{if(!editing||!editName.trim())return;sLd(true);sErr('');const r=await api.u('color-palettes/'+editing,{name:editName.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not rename palette.');return;}sEditing(null);sEditName('');await finish('Palette renamed');};
  const askDelete=async p=>{sLd(true);sErr('');const preview=await api.g('color-palettes/'+p.id+'/delete-preview');sLd(false);if(preview?.code){sErr(preview.message||'Could not inspect palette.');return;}sDeleteDestination('');sDeleteState({palette:p,preview});};
  const remove=async(strategy='empty')=>{if(!deleteState)return;const p=deleteState.palette;const destinationId=Number(deleteDestination)||0;sDeleteState(null);sLd(true);sErr('');const r=await api.d('color-palettes/'+p.id,{strategy,destination_id:destinationId});sLd(false);if(r?.code){sErr(r.message||'Could not delete palette.');return;}await finish(strategy==='move'?'Palette removed and colors moved':'Palette deleted');};
  const destinationOptions=data.palettes.filter(p=>p.id!==deleteState?.palette?.id).map(p=>({value:String(p.id),label:p.name}));
  const rows=data.palettes.map(p=>{
    const info=editing===p.id
      ? h('div',{style:'display:flex;gap:4px'},h('input',{class:'ve-studio-input',type:'text',value:editName,onInput:e=>sEditName(e.target.value),onKeyDown:e=>{if(e.key==='Enter')rename();if(e.key==='Escape')sEditing(null);},style:'flex:1;min-width:0;font-size:11px;'}),h('button',{class:'ve-btn',onClick:rename,disabled:ld},'Save'))
      : h('div',{class:'ve-palette-row-name'},p.name);
    return h('div',{
      class:'ve-palette-row'+(draggingPaletteId===p.id?' dragging':'')+(dragOverPaletteId===p.id?' drag-over':''),
      key:p.id,
      draggable:true,
      onDragStart:e=>{
        sDraggingPaletteId(p.id);
        e.dataTransfer.effectAllowed='move';
        e.dataTransfer.setData('text/plain',String(p.id));
      },
      onDragOver:e=>{
        e.preventDefault();
        if(p.id!==draggingPaletteId)sDragOverPaletteId(p.id);
      },
      onDragLeave:()=>sDragOverPaletteId(null),
      onDragEnd:()=>{sDraggingPaletteId(null);sDragOverPaletteId(null);},
      onDrop:e=>handlePaletteDrop(e,p)
    },
      h('span',{class:'ve-palette-drag-handle',style:'cursor:grab;margin-right:4px;display:flex;align-items:center;opacity:0.3;'},ph('dots-six-vertical')),
      h('div',{class:'ve-sw-trigger',style:'width:24px;color:#baf400'},ph('palette')),
      h('div',{class:'ve-palette-row-info'},info,h('div',{class:'ve-palette-row-meta'},p.color_count+' color'+(p.color_count===1?'':'s'))),
      h('div',{class:'ve-palette-actions'},
        h('button',{class:'ve-a',title:'Duplicate palette and colors',onClick:()=>sConfirmDuplicate(p),disabled:ld},ph('copy')),
        h('button',{class:'ve-a',title:'Rename palette',onClick:()=>{sEditing(p.id);sEditName(p.name);},disabled:ld},ph('pencil-simple')),
        h('button',{class:'ve-a',title:'Delete palette',onClick:()=>askDelete(p),disabled:ld},ph('trash'))));
  });
  const selected=data.palettes.find(p=>String(p.id)===String(selectedPaletteId));
  const content=[
    confirmDuplicate&&h(ConfirmModal,{title:'Duplicate palette',body:'Duplicate “'+confirmDuplicate.name+'” and create independent copies of its '+confirmDuplicate.color_count+' color'+(confirmDuplicate.color_count===1?'':'s')+'?',confirmText:'Duplicate Palette',onCancel:()=>sConfirmDuplicate(null),onConfirm:duplicate}),
    deleteState&&(deleteState.preview.color_count===0
      ? h(ConfirmModal,{title:'Delete empty palette',body:'Delete “'+deleteState.palette.name+'”?',confirmText:'Delete Palette',danger:true,onCancel:()=>sDeleteState(null),onConfirm:()=>remove('empty')})
      : h('div',{class:'ve-modal'},h('div',{class:'ve-modal-box'},
          h('div',{class:'ve-modal-title'},'Delete populated palette'),
          h('div',{class:'ve-modal-body'},
            h('div',null,'“'+deleteState.palette.name+'” contains '+deleteState.preview.color_count+' color'+(deleteState.preview.color_count===1?'':'s')+' and '+deleteState.preview.generated_count+' generated child'+(deleteState.preview.generated_count===1?'':'ren')+'.'),
            deleteState.preview.dependent_alias_count>0&&h('div',{style:'color:#f6c369;margin-top:6px'},deleteState.preview.dependent_alias_count+' alias relationship'+(deleteState.preview.dependent_alias_count===1?'':'s')+' may also be removed if the colors are deleted.'),
            destinationOptions.length>0&&h('div',{style:'margin-top:10px'},h('div',{style:'font-size:9px;color:#888;margin-bottom:5px'},'Move colors before deleting'),h(SelectMenu,{value:deleteDestination,onChange:sDeleteDestination,options:[{value:'',label:'Choose destination palette'},...destinationOptions]}))),
          h('div',{class:'ve-modal-actions',style:'flex-wrap:wrap'},
            h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sDeleteState(null)},'Cancel'),
            destinationOptions.length>0&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',disabled:!deleteDestination,onClick:()=>remove('move')},'Move & Delete'),
            h('button',{class:'ve-btn ve-btn-d ve-btn-s',onClick:()=>remove('delete_colors')},'Delete Palette & Colors'))))),
    h('div',{class:'ve-palette-current'},h('i',{class:'ph-duotone ph-palette',style:'font-size:18px;color:#baf400;line-height:1'}),h('div',null,h('div',{style:'font-size:8px;color:#666;text-transform:uppercase;letter-spacing:.5px;font-weight:600'},selected?'Selected palette':'Color organization'),h('div',{style:'font-size:13px;color:#e8e8e8;font-weight:700;margin-top:1px'},selected?.name||(data.palettes.length+' palette'+(data.palettes.length===1?'':'s'))))),
    h('div',{class:'ve-import-help'},'Palettes are user-created containers for actual Color variables. They do not change the active theme or website values. New palettes start empty; colors can be moved or copied between them.'),
    h('div',{style:'display:flex;gap:5px;margin-bottom:10px'},h('input',{class:'ve-studio-input',type:'text',value:name,onInput:e=>sName(e.target.value),placeholder:'New palette name',onKeyDown:e=>e.key==='Enter'&&create(),style:'flex:1;font-size:11px;'}),h('button',{class:'ve-btn',onClick:create,disabled:ld||!name.trim()},'Create')),
    err&&h('div',{style:'font-size:10px;color:#ef4444;padding:0 0 8px'},err),
    h('div',{style:inline?'max-height:190px;overflow-y:auto':'flex:1;min-height:0;overflow-y:auto'},rows.length?rows:h('div',{class:'ve-empty'},'No palettes yet. Create one to begin grouping colors.'))
  ];
  return inline
    ? h('div',{style:'padding:10px 14px 12px;border-top:1px solid #2a2a2a;display:flex;flex-direction:column;gap:8px;background:rgba(0,0,0,.12)'},...content)
    : h(Sub,{title:'Color Palettes',onClose,exiting},...content);
}

/* ── Sync sub-panel (includes Figma connection + pairing) ── */
function SyncPanel({onClose,exiting,onDone,onReload}){
  const[view,sView]=useState('main');
  const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const[diff,sDiff]=useState(null);const[summary,sSummary]=useState(null);
  const[snaps,sSnaps]=useState([]);const[skipDel,sSD]=useState(true);
  const[pair,sPair]=useState(null);const[stats,sStats]=useState(null);const[cleaning,sCleaning]=useState(false);
  const[pCode,sPC]=useState('');const[pKey,sPK]=useState('');const[figCode,sFC]=useState('');const[pMsg,sPM]=useState('');
  const[diag,sDiag]=useState(null);
  const[confirmClean,sConfirmClean]=useState(false);
  const[confirmImportDeletes,sConfirmImportDeletes]=useState(false);
  const fileRef=useRef();const cssFileRef=useRef();
  const dropDepthRef=useRef(0);
  const[dropActive,sDropActive]=useState(false);
  const[importFileName,sImportFileName]=useState('');
  const[cssText,sCssText]=useState('');const[cssCount,sCssCount]=useState(0);

  const loadPair=useCallback(()=>api.g('sync/pair/status').then(d=>{if(d)sPair(d);return d;}),[]);
  const loadStats=useCallback(()=>api.g('variables/stats').then(d=>{if(d&&!d.code)sStats(d);return d;}).catch(()=>null),[]);
  useEffect(()=>{loadPair();loadStats();const t=setInterval(()=>{loadPair();loadStats();},2500);return()=>clearInterval(t);},[loadPair,loadStats]);

  const genCode=async()=>{const r=await api.p('sync/pair/generate',{});if(r?.code){sPC(r.code);sPK(r.api_key||'');}};
  const submitFigCode=async()=>{if(figCode.length!==6){sPM('Enter the 6-character code');return;}const r=await api.p('sync/pair/complete-figma',{code:figCode});if(r?.api_key){sPM('Paired!');api.g('sync/pair/status').then(d=>{if(d)sPair(d);});}else sPM(r?.message||'Invalid code');};
  const disc=async()=>{await api.p('sync/pair/disconnect',{});sPair({paired:false,source:'',figma_name:'',collection_name:''});sPC('');sPK('');};
  const cleanDb=async()=>{sConfirmClean(false);sCleaning(true);sErr('');const r=await api.p('variables/cleanup',{});sCleaning(false);if(r?.after){sStats(r.after);onReload&&onReload();}else{sErr(r?.message||'Cleanup failed');}};
  const loadDiagnostics=async()=>{if(diag){sDiag(null);return;}const r=await api.g('diagnostics/logs?lines=12');if(r?.code){sErr(r.message||'Could not load diagnostics');return;}sDiag(r);};
  const cleanableStatIssues=stats?[(stats.stale_generated?stats.stale_generated+' stale':''),(stats.orphan_generated?stats.orphan_generated+' orphan generated':''),(stats.missing_dependencies?stats.missing_dependencies+' missing dependency links':''),(stats.orphan_dependencies?stats.orphan_dependencies+' orphan dependency rows':''),(stats.duplicate_count?stats.duplicate_count+' duplicate names':''),(stats.older_generators?stats.older_generators+' old generators':'')].filter(Boolean):[];
  const manualStatIssues=stats?[(stats.public_name_conflict_count?stats.public_name_conflict_count+' CSS name conflicts require manual rename':''),(stats.broken_aliases?stats.broken_aliases+' aliases have missing sources':''),(stats.blocked_orphan_generated?stats.blocked_orphan_generated+' orphan generated variables still have dependents':'')].filter(Boolean):[];
  const statIssues=[...cleanableStatIssues,...manualStatIssues];
  const exportBaseName=()=>`mimams-var-${safeFilePart(CFG.siteTitle,'wordpress')}`;
  const doExport=async(fmt)=>{sLd(true);sErr('');const d=await api.g('sync/export?format='+fmt);const blob=new Blob([JSON.stringify(d,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=exportBaseName()+'-'+fmt+'-'+(new Date).toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);sLd(false);};
  const doExportCss=async()=>{sLd(true);sErr('');const d=await api.g('sync/export-css');if(d?.code){sErr(d.message||'CSS export failed');sLd(false);return;}const blob=new Blob([d.css||''],{type:'text/css'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=d.filename||('mimams-var-'+(new Date).toISOString().slice(0,10)+'.css');document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);sLd(false);};
  const importJsonFile=async file=>{sLd(true);sErr('');sImportFileName(file.name||'JSON file');try{const text=await file.text();const json=JSON.parse(text);const res=await api.p('sync/preview',json);if(res?.code){sErr(res.message||'Parse error');sLd(false);return;}sDiff(res.changes||[]);sSummary(res.summary||{});sView('preview');}catch(ex){sErr('Invalid JSON: '+ex.message);}sLd(false);};
  const importCssFile=async file=>{sErr('');sImportFileName(file.name||'CSS file');const text=await file.text();sCssText(text);sCssCount(parseCssVariables(text).length);};
  const importDroppedFile=async file=>{
    if(!file)return;
    const name=String(file.name||'').toLowerCase();
    if(name.endsWith('.json')||file.type==='application/json'){await importJsonFile(file);return;}
    if(name.endsWith('.css')||file.type==='text/css'){await importCssFile(file);return;}
    sErr('Unsupported file. Drop a JSON token export or a CSS file.');
  };
  const doImport=async e=>{const file=e.target.files?.[0];if(file)await importJsonFile(file);e.target.value='';};
  const readCssFile=async e=>{const file=e.target.files?.[0];if(file)await importCssFile(file);e.target.value='';};
  const dragEnter=e=>{if(!Array.from(e.dataTransfer?.types||[]).includes('Files'))return;e.preventDefault();dropDepthRef.current++;sDropActive(true);};
  const dragOver=e=>{if(!Array.from(e.dataTransfer?.types||[]).includes('Files'))return;e.preventDefault();e.dataTransfer.dropEffect='copy';sDropActive(true);};
  const dragLeave=e=>{e.preventDefault();dropDepthRef.current=Math.max(0,dropDepthRef.current-1);if(dropDepthRef.current===0)sDropActive(false);};
  const dropFile=async e=>{e.preventDefault();dropDepthRef.current=0;sDropActive(false);await importDroppedFile(e.dataTransfer?.files?.[0]);};
  const previewCssImport=async()=>{const vars=parseCssVariables(cssText);sCssCount(vars.length);if(!vars.length){sErr('No CSS custom properties found. Use declarations like --color-primary: #baf400;');return;}sLd(true);sErr('');const res=await api.p('sync/preview',vars);if(res?.code){sErr(res.message||'CSS import preview failed');sLd(false);return;}sDiff(res.changes||[]);sSummary(res.summary||{});sView('preview');sLd(false);};
  const applyImport=async()=>{if(!diff)return;sConfirmImportDeletes(false);sLd(true);sErr('');const filtered=skipDel?diff.filter(c=>c.action!=='delete'):diff;const res=await api.p('sync/apply',{changes:filtered,skip_deletes:skipDel});sLd(false);if(res?.errors?.length){sErr((res.rolled_back?'No changes were kept. ':'')+res.errors.join('; '));return;}if(res?.applied>0)onDone();else sView('main');};
  const doApply=()=>{if(!diff)return;const deleteCount=diff.filter(c=>c.action==='delete').length;if(!skipDel&&deleteCount){sConfirmImportDeletes(true);return;}applyImport();};
  const doSnap=async()=>{sLd(true);await api.p('sync/snapshot',{});await loadSnaps();sLd(false);};
  const loadSnaps=async()=>{const s=await api.g('sync/snapshots');if(Array.isArray(s))sSnaps(s);};
  const doRollback=async(id)=>{sLd(true);sErr('');const res=await api.p('sync/rollback/'+id,{});sLd(false);if(res?.restored)onDone();else sErr(res?.message||'Rollback failed');};
  useEffect(()=>{if(view==='snapshots')loadSnaps();},[view]);

  const AC={add:'#22c55e',update:'#3b82f6',delete:'#ef4444',type_change:'#f59e0b',relationship_change:'#f59e0b',repair_generated:'#a78bfa'};
  const AL={add:'ADD',update:'UPD',delete:'DEL',type_change:'TYPE',relationship_change:'LINK',repair_generated:'FIX'};
  const blockedImportCount=(diff||[]).filter(c=>c.action==='type_change').length;

  if(view==='preview')return h(Sub,{title:'Import Preview',onClose,exiting},
    summary&&h('div',{style:'display:flex;gap:8px;margin-bottom:8px;flex-wrap:wrap'},summary.added>0&&h('span',{style:'font-size:10px;color:#22c55e'},'+'+summary.added+' new'),summary.updated>0&&h('span',{style:'font-size:10px;color:#3b82f6'},'~'+summary.updated+' changed'),summary.deleted>0&&h('span',{style:'font-size:10px;color:#ef4444'},'-'+summary.deleted+' removed'),summary.repaired>0&&h('span',{style:'font-size:10px;color:#a78bfa'},summary.repaired+' relationship repairs'),summary.type_changed>0&&h('span',{style:'font-size:10px;color:#f59e0b'},summary.type_changed+' type reviews'),summary.relationship_changed>0&&h('span',{style:'font-size:10px;color:#f59e0b'},summary.relationship_changed+' source reviews')),
    h('div',{style:'max-height:220px;overflow-y:auto;margin-bottom:8px'},(diff||[]).map((c,i)=>h('div',{key:i,style:'display:flex;align-items:center;gap:6px;padding:5px 0;font-size:10px;border-bottom:1px solid #2a2a2a'},h('span',{style:`color:${AC[c.action]||'#888'};font-weight:700;font-size:8px;width:30px;text-transform:uppercase`},AL[c.action]||c.action),h('span',{style:'color:#ddd;font-family:monospace;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap'},c.name),c.action==='update'&&h('span',{style:'color:#777;font-size:8px;font-family:monospace'},'value → ',c.new_value?.slice(0,20)),c.action==='relationship_change'&&h('span',{style:'color:#d6a34a;font-size:8px;font-family:monospace;max-width:48%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap'},(c.old_source_name||'none')+' → '+(c.source_name||'none')),c.action==='type_change'&&h('span',{style:'color:#d6a34a;font-size:8px;font-family:monospace'},(c.old_type||'base')+' → '+(c.new_type||'base'))))),
    (diff||[]).some(c=>c.action==='relationship_change')&&h('div',{class:'ve-warn',style:'margin-bottom:8px;color:#d6a34a'},'Alias source changes are shown as LINK and will be applied transactionally with the rest of the import.'),
    blockedImportCount>0&&h('div',{class:'ve-warn',style:'margin-bottom:8px'},blockedImportCount+' variable type change'+(blockedImportCount===1?' requires':'s require')+' manual review before this import can be applied.'),
    err&&h('div',{style:'font-size:10px;color:#ef4444;padding:4px 0'},err),
    h('div',{class:'ve-opt',style:'margin-top:4px'},h('label',null,h('input',{type:'checkbox',checked:skipDel,onChange:e=>sSD(e.target.checked)}),'Skip deletions')),
    h('div',{style:'display:flex;gap:5px;margin-top:8px;justify-content:flex-end'},h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sView('main')},'Back'),h('button',{class:'ve-btn ve-btn-s',onClick:doApply,disabled:ld||!(diff||[]).length||blockedImportCount>0},ld?'Applying...':'Apply '+(skipDel?(diff||[]).filter(c=>c.action!=='delete').length:(diff||[]).length)+' changes')),
    confirmImportDeletes&&h(ConfirmModal,{title:'Apply destructive import',body:'This import will permanently delete '+(diff||[]).filter(c=>c.action==='delete').length+' variables. A complete safety snapshot will be created first. Continue?',confirmText:'Apply & Delete',danger:true,onCancel:()=>sConfirmImportDeletes(false),onConfirm:applyImport}));

  if(view==='snapshots')return h(Sub,{title:'Snapshots',onClose,onBack:()=>sView('main'),exiting},
    h('div',{style:'display:flex;flex-direction:column;min-height:100%;gap:12px'},
      h('div',null,h('button',{class:'ve-btn ve-btn-s',onClick:doSnap,disabled:ld},'+ New Snapshot')),
      snaps.length===0?h('div',{class:'ve-empty',style:'flex:1'},'No snapshots yet'):h('div',{style:'flex:1;min-height:0;overflow-y:auto;padding-right:4px'},snaps.map(s=>h('div',{key:s.id,style:'display:flex;align-items:center;justify-content:space-between;gap:12px;padding:9px 0;border-bottom:1px solid #2a2a2a;font-size:10px'},h('div',{style:'min-width:0'},h('div',{style:'color:#ddd;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:600'},s.trigger_label||s.trigger_type||'Snapshot'),h('div',{style:'color:#666;font-size:9px;line-height:1.45'},'Snapshot #'+s.id+' · '+s.created_at),s.restorable===false&&h('div',{style:'color:#d6a34a;font-size:9px;line-height:1.45;margin-top:3px'},s.restore_warning||'Legacy snapshot cannot be restored safely.')),h('button',{class:'ve-btn ve-btn-g ve-btn-s',title:s.restorable===false?(s.restore_warning||'Legacy snapshot cannot be restored safely.'):'Restore this complete variable state',onClick:()=>doRollback(s.id),disabled:ld||s.restorable===false},s.restorable===false?'Unavailable':'Restore')))),
      err&&h('div',{style:'font-size:10px;color:#ef4444;padding:4px 0'},err),
      h('div',{style:'display:flex;gap:5px;margin-top:auto'},h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sView('main')},'Back'))));

  return h(Sub,{title:'Sync',onClose,exiting},
    /* Figma Connection */
    h('div',{style:'margin-bottom:12px'},
      h('div',{style:'font-size:10px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Figma Connection'),
      pair?.paired?h('div',null,
        h('div',{style:'font-size:11px;color:#baf400;margin-bottom:4px'},'✓ Connected'),
        h('div',{style:'display:flex;align-items:flex-start;gap:6px;font-size:10px;color:#ddd;margin-bottom:4px;font-family:monospace'},ph('file'),h('span',null,pair.figma_name||'Figma file not captured yet — open the Figma plugin once to update this.')),
        pair.collection_name&&h('div',{style:'display:flex;align-items:flex-start;gap:6px;font-size:10px;color:#888;margin-bottom:4px;font-family:monospace'},ph('stack'),h('span',null,'Collection: '+pair.collection_name)),
        h('div',{style:'font-size:10px;color:#555;margin-bottom:6px'},'Source: '+(pair.source==='figma'?'Figma':'WordPress')),
        h('button',{class:'ve-btn ve-btn-d ve-btn-s',onClick:disc},'Disconnect'))
      :h('div',null,
        h('div',{style:'font-size:10px;color:#555;margin-bottom:6px'},'Generate credentials for your Figma plugin:'),
        h('button',{class:'ve-btn ve-btn-s',onClick:genCode,style:'margin-bottom:6px'},'Generate Pairing Credentials'),
        pCode&&h('div',{style:'background:#2a2a2a;border-radius:6px;padding:10px;margin:6px 0'},
          h('div',{style:'font-size:9px;color:#555;text-transform:uppercase;margin-bottom:2px'},'Pairing Code'),
          h('div',{style:'font-size:22px;font-weight:800;letter-spacing:4px;text-align:center;font-family:monospace;color:#baf400'},pCode),
          pKey&&h('div',null,
            h('div',{style:'font-size:9px;color:#555;text-transform:uppercase;margin-top:8px;margin-bottom:2px'},'API Key'),
            h('div',{style:'font-size:9px;font-family:monospace;color:#888;word-break:break-all;cursor:pointer;padding:4px;background:#1f1f1f;border-radius:3px',onClick:()=>{navigator.clipboard?.writeText(pKey);sPM('Copied!');}},pKey),
            h('div',{style:'font-size:9px;color:#555;text-align:center;margin-top:4px'},'Click key to copy. Enter both in Figma plugin.'))),
        h('div',{style:'font-size:10px;color:#555;margin:8px 0 4px'},'Or enter a code from Figma:'),
        h('div',{style:'display:flex;gap:4px'},
          h('input',{style:'flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:13px;font-family:monospace;text-align:center;letter-spacing:2px;text-transform:uppercase;outline:none',maxLength:6,value:figCode,onInput:e=>sFC(e.target.value.toUpperCase()),placeholder:'ABC123'}),
          h('button',{class:'ve-btn ve-btn-s',onClick:submitFigCode},'Pair')),
        pMsg&&h('div',{style:'font-size:10px;color:'+(pMsg.includes('Paired')||pMsg.includes('Copied')?'#baf400':'#ef4444')+';padding:4px 0'},pMsg))),
    /* Database Cleanup */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:10px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'WordPress Database'),
      stats?h('div',null,
        h('div',{style:'font-size:10px;color:#ddd;margin-bottom:4px'},(stats.base||0)+' base · '+(stats.generated||0)+' generated · '+(stats.total||0)+' raw'),
        statIssues.length?h('div',{style:'font-size:9px;color:#f59e0b;margin-bottom:6px'},statIssues.join(', ')):h('div',{style:'font-size:9px;color:#555;margin-bottom:6px'},'No cleanup issues detected'),
        h('div',{style:'display:flex;gap:4px;flex-wrap:wrap'},cleanableStatIssues.length>0&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sConfirmClean(true),disabled:cleaning},cleaning?'Cleaning...':'Clean WP DB'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:loadDiagnostics},diag?'Hide Diagnostics':'View Diagnostic Logs')),
        diag&&h('div',{style:'margin-top:8px;padding:8px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.08);border-radius:8px;font-size:9px;color:#aaa;line-height:1.5;max-height:120px;overflow:auto;font-family:"SF Mono","Fira Code",monospace;white-space:pre-wrap'},(diag.entries||[]).length?(diag.entries||[]).map(x=>(x.time||'')+' '+(x.level||'')+' '+(x.event||x.raw||'')).join('\n'):'No diagnostic entries yet',h('div',{style:'color:#555;margin-top:4px;word-break:break-all'},diag.path||'')))
      :h('div',{style:'font-size:10px;color:#555'},'Loading stats...')),
    /* Export */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:10px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Export'),
      h('div',{style:'display:flex;gap:4px;flex-wrap:wrap'},h('button',{class:'ve-btn ve-btn-s',onClick:()=>doExport('dtcg'),disabled:ld},'DTCG'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>doExport('flat'),disabled:ld},'Flat'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>doExport('figma'),disabled:ld},'Figma'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:doExportCss,disabled:ld},'CSS')),
      h('div',{style:'font-size:9px;color:#444;padding:4px 0;line-height:1.5'},'CSS exports a commented :root file using current css_value output.')),
    /* Import */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:10px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Import'),
      h('input',{ref:fileRef,type:'file',accept:'.json',style:'display:none',onChange:doImport}),
      h('input',{ref:cssFileRef,type:'file',accept:'.css,text/css',style:'display:none',onChange:readCssFile}),
      h('div',{class:'ve-import-help'},'Import DTCG, Flat, or Figma JSON exports with Upload JSON. CSS can be uploaded or pasted below. Every import opens a preview before anything changes.'),
      h('div',{class:'ve-import-drop'+(dropActive?' active':''),onDragEnter:dragEnter,onDragOver:dragOver,onDragLeave:dragLeave,onDrop:dropFile},
        h('div',{class:'ve-import-drop-overlay'},ph('upload-simple'),h('span',null,'Drop file here'),h('small',null,'JSON token export or CSS variables')),
        h('div',{class:'ve-import-drop-content'},
          h('div',{style:'display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px'},h('button',{class:'ve-btn ve-btn-s',onClick:()=>fileRef.current?.click(),disabled:ld},ld?'Reading...':'Upload JSON'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>cssFileRef.current?.click(),disabled:ld},'Upload CSS')),
          h('textarea',{value:cssText,onInput:e=>{sCssText(e.target.value);sCssCount(parseCssVariables(e.target.value).length);sImportFileName('');},placeholder:'Or paste CSS variables here, e.g. :root { --color-primary: #baf400; --space-20: 2rem; }',style:'width:100%;min-height:96px;padding:9px 11px;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.10);border-radius:8px;color:#f1f1f1;font-size:10px;font-family:"SF Mono","Fira Code",monospace;outline:none;resize:vertical;line-height:1.55;margin-bottom:6px'}),
          h('div',{style:'display:flex;align-items:center;justify-content:space-between;gap:8px'},h('span',{style:'font-size:9px;color:#777;overflow:hidden;text-overflow:ellipsis;white-space:nowrap'},importFileName?(importFileName+(cssCount?' · '+cssCount+' variables':'')):(cssCount?cssCount+' CSS variables detected':'Drag a compatible file here')),h('button',{class:'ve-btn ve-btn-s',onClick:previewCssImport,disabled:ld||!cssText.trim()},'Preview CSS Import'))))),
    /* Snapshots */
    h('div',{style:'padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:10px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Snapshots & Rollback'),
      h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sView('snapshots')},'View Snapshots')),
    err&&h('div',{style:'font-size:10px;color:#ef4444;padding:8px 0'},err),
    confirmClean&&h(ConfirmModal,{title:'Clean WordPress DB',body:'Clean duplicate, stale, and orphan generated variables from WordPress? This keeps base variables and rebuilds recoverable generated variants.',confirmText:'Clean',onCancel:()=>sConfirmClean(false),onConfirm:cleanDb}));
}

/* ── Variable reference autocomplete ──── */
function VarRefInput({value,onInput,vars,placeholder,onKeyDown}){
  const[show,sShow]=useState(false);
  const[q,sQ]=useState('');
  const[idx,sIdx]=useState(0);
  const ref=useRef();

  const matches=useMemo(()=>{
    if(show){
      if(!q)return vars.slice(0,10);
      const qLower=q.toLowerCase();
      return vars.filter(v=>{
        const dotName=(v.name||'').toLowerCase();
        const cssName=cssTokenName(v.name).toLowerCase();
        return dotName.includes(qLower)||cssName.includes(qLower);
      }).slice(0,10);
    }
    return [];
  },[show,q,vars]);

  const handleInput=e=>{
    const val=e.target.value;
    onInput(e);
    const cur=val.slice(0,e.target.selectionStart||val.length);
    const m=cur.match(/(?:var\(--|var\(|--)([a-z0-9.-]*)$/i);
    if(m){
      sQ(m[1].replace(/-/g,'.'));
      sShow(true);
      sIdx(0);
    }
    else{sShow(false);sQ('');}
  };

  const insert=(v)=>{
    const el=ref.current;if(!el)return;
    const val=el.value;
    const pos=el.selectionStart||val.length;
    const before=val.slice(0,pos);
    const after=val.slice(pos);
    const m=before.match(/(?:var\(--|var\(|--)[a-z0-9.-]*$/i);
    if(m){
      const cssName=cssTokenName(v.name);
      const newBefore=before.slice(0,before.length-m[0].length)+'var('+cssName+')';
      const nv=newBefore+after;
      onInput({target:{value:nv}});
      sShow(false);sQ('');
      setTimeout(()=>{el.focus();el.selectionStart=el.selectionEnd=newBefore.length;},10);
    }
  };

  const handleKey=e=>{
    if(show&&matches.length){
      if(e.key==='ArrowDown'){e.preventDefault();sIdx(i=>(i+1)%matches.length);}
      else if(e.key==='ArrowUp'){e.preventDefault();sIdx(i=>(i-1+matches.length)%matches.length);}
      else if(e.key==='Enter'&&matches[idx]){e.preventDefault();insert(matches[idx]);}
      else if(e.key==='Tab'&&matches[idx]){e.preventDefault();insert(matches[idx]);}
      else if(e.key==='Escape'){sShow(false);}
    }
    if(onKeyDown)onKeyDown(e);
  };

  return h('div',{class:'ve-ac-wrap'},
    h('input',{ref,placeholder,value,onInput:handleInput,onKeyDown:handleKey,onBlur:()=>setTimeout(()=>sShow(false),150),style:'width:100%;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:10px;outline:none;font-family:monospace'}),
    show&&matches.length>0&&h('div',{class:'ve-ac'},
      matches.map((v,i)=>{
        const resVal = resolvedVariableValue(v, vars);
        return h('div',{class:'ve-ac-i'+(i===idx?' sel':''),onMouseDown:e=>{e.preventDefault();insert(v);},key:v.id},
          h('div',{class:'ve-ac-sw',style:isClr(resVal)?`background:${resVal};border-color:transparent`:''}),
          h('span',null,cssTokenName(v.name)),
          h('span',{style:'color:#444;margin-left:auto;font-size:8px'},v.type==='alias'?v.css_value:v.value));
      })));
}

/* ── Create sub-panel ─────────────────── */
function CreateSub({onCreated,onClose,categories,vars,exiting,palettes,paletteId}){
  const[mode,sMode]=useState('color');
  const[cat,sCat]=useState('color');const[newCat,sNC]=useState('');const[showNC,sSNC]=useState(false);
  const[nm,sNm]=useState('');const[val,sVal]=useState('');
  const[fMin,sFMin]=useState('');const[fMax,sFMax]=useState('');
  const[hex,sHex]=useState('#baf400');const[fmt,sFmt]=useState('oklch');
  const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const[selectedPalette,sSelectedPalette]=useState(paletteId&&paletteId!=='all'?String(paletteId):((palettes||[]).length===1?String(palettes[0].id):''));
  useEffect(()=>{
    if(mode==='color')sCat('color');
    else if(cat==='color')sCat(categories.find(c=>c!=='color'&&c!=='all')||'space');
  },[mode]);
  const prefix=showNC?newCat:cat;
  const fullNm=prefix&&nm?(prefix+'.'+nm):nm;

  const create=async()=>{
    if(!nm)return;sLd(true);sErr('');
    let fv;
    if(mode==='color')fv=hexOklch(hex);
    else if(mode==='fluid')fv=fluidMarker(fMin,fMax);
    else if(mode==='clamp')fv=val?(val.match(/\d/)?pxToRemValue(val):val):'1rem';
    else fv=val;
    if(!fv){sLd(false);sErr(mode==='fluid'?'Enter both a min and max value.':'');return;}
    const payload={name:fullNm,value:fv};
    if(mode==='color'){
      if(!selectedPalette){sLd(false);sErr('Choose a palette for this color.');return;}
      payload.palette_id=Number(selectedPalette);
    }
    if(mode==='static'){
      const sourceId = detectAliasSource(fv, vars);
      if(sourceId){
        payload.type='alias';
        payload.source_id=Number(sourceId);
      }
    }
    const r=await api.p('variables',payload);
    sLd(false);
    if(r?.code==='ve_duplicate'){sErr(r.message||'A variable with this name already exists.');return;}
    if(r?.code){sErr(r.message||'Failed to create variable.');return;}
    if(r?.id)onCreated(r);
  };

  const catOpts=mode==='color'?['color']:categories.filter(c=>c!=='all');

  return h(Sub,{title:'New Variable',onClose,exiting},
    h('div',{class:'ve-mode'},
      h('button',{class:mode==='color'?'on':'',onClick:()=>sMode('color')},'Color'),
      h('button',{class:mode==='clamp'?'on':'',onClick:()=>sMode('clamp')},'Fixed'),
      h('button',{class:mode==='fluid'?'on':'',onClick:()=>sMode('fluid')},'Fluid'),
      h('button',{class:mode==='static'?'on':'',onClick:()=>sMode('static')},'Static')),
    mode==='color'&&h('div',{class:'ve-opt ve-opt-stack',style:'padding-top:0'},
      h('span',null,'Palette'),
      (palettes||[]).length
        ? h(SelectMenu,{value:selectedPalette,onChange:sSelectedPalette,options:[{value:'',label:'Choose palette'},...(palettes||[]).map(p=>({value:String(p.id),label:p.name}))]})
        : h('div',{class:'ve-warn',style:'margin:0;font-size:9px'},'Create a palette before creating Color variables.')),
    h('div',{class:'ve-row'},
      !showNC?h(SelectMenu,{value:cat,onChange:v=>{if(v==='__new__')sSNC(true);else sCat(v)},options:[...catOpts.map(c=>({value:c,label:c})),{value:'__new__',label:'+ New category'}]}):
      h('input',{placeholder:'category name',value:newCat,onInput:e=>sNC(normalizeNameInput(e.target.value)),style:'flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:10px;outline:none',onBlur:()=>{if(!newCat)sSNC(false);}})),
    h('div',{class:'ve-row'},h('input',{placeholder:mode==='color'?'e.g. accent, free-test':'e.g. 20, heading-58, gap-20',value:nm,onInput:e=>{sNm(normalizeNameInput(e.target.value));if(err)sErr('');},onKeyDown:e=>e.key==='Enter'&&create(),style:'flex:1'})),
    prefix&&nm&&h('div',{style:'font-size:9px;color:#444;padding:0 0 6px;font-family:monospace'},publicTokenLabel(fullNm)),
    err&&h('div',{style:'font-size:10px;color:#ef4444;padding:2px 0 6px'},err),
    mode==='color'&&h('div',{class:'ve-row'},h(MVColorPicker,{hex,onChange:sHex,fmt,setFmt:sFmt})),
    mode==='clamp'&&h('div',null,
      h('div',{class:'ve-row'},h('input',{placeholder:'Base value (number, stored as rem)',value:val,onInput:e=>{const v=e.target.value.replace(/[^0-9.]/g,'');sVal(v);},style:'flex:1'})),
      h('div',{style:'font-size:9px;color:#555;padding:0 0 6px'},'Numbers are px references — stored as rem using 10px = 1rem. Example: 20 → 2rem.')),
    mode==='fluid'&&h('div',null,
      h('div',{class:'ve-row',style:'gap:6px'},
        h('input',{placeholder:'Min px',value:fMin,onInput:e=>{sFMin(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'}),
        h('input',{placeholder:'Max px',value:fMax,onInput:e=>{sFMax(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'})),
      fMin&&fMax&&h('div',{style:'font-size:9px;color:#baf400;padding:0 0 4px;font-family:monospace;word-break:break-all'},fluidPreview(fMin,fMax)),
      h('div',{style:'font-size:9px;color:#555;padding:0 0 6px'},'Scales smoothly between the page min and max viewport widths (set in Settings). Min/max are px values.')),
    mode==='static'&&h('div',{class:'ve-row'},
      h(VarRefInput,{placeholder:'e.g. 0 4px 12px rgba(0,0,0,.1) or var(--...',value:val,onInput:e=>sVal(typeof e.target==='object'?e.target.value:e),vars:vars||[],onKeyDown:e=>e.key==='Enter'&&create()})),
    h('div',{style:'display:flex;gap:5px;justify-content:flex-end;margin-top:4px'},
      h('button',{class:'ve-btn',onClick:create,disabled:ld||!nm||(mode==='color'&&!selectedPalette)||(mode==='clamp'&&!val)||(mode==='static'&&!val)||(mode==='fluid'&&(!fMin||!fMax))},ld?'...':'Create')));
}

/* ── Edit sub-panel (same as create, pre-filled) ── */
function EditSub({variable,onDone,onClose,categories,vars,exiting}){
  const resolvedVal=resolvedVariableValue(variable, vars);
  const isClrV=isClr(resolvedVal);
  const isFluidV=isFluidVal(variable.value);
  const initMode=variable.type==='alias'?'static':(isClrV?'color':(isFluidV?'fluid':((variable.value||'').includes('clamp')?'clamp':'static')));
  const parts=variable.name.split('.');
  const initCat=parts[0]||'color';
  const initNm=normalizeNameInput(parts.slice(1).join('-')||variable.name);
  const initFluid=isFluidV?parseFluid(variable.value):null;

  const[mode,sMode]=useState(initMode);
  const[cat,sCat]=useState(initCat);const[newCat,sNC]=useState('');const[showNC,sSNC]=useState(false);
  const[nm,sNm]=useState(initNm);const[val,sVal]=useState(variable.type==='alias'?variable.css_value:(variable.value||''));
  const[fMin,sFMin]=useState(initFluid?String(initFluid[0]):'');const[fMax,sFMax]=useState(initFluid?String(initFluid[1]):'');
  const[hex,sHex]=useState(isClrV?clrToHex(resolvedVal):'#baf400');const[fmt,sFmt]=useState('oklch');
  const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const[prop,sProp]=useState(false);const[impact,sImpact]=useState(null);const[checking,sChecking]=useState(false);

  useEffect(()=>{if(mode==='color')sCat('color');else if(cat==='color')sCat(categories.find(c=>c!=='color'&&c!=='all')||'space');},[mode]);
  useEffect(()=>{
    if(mode!=='color'||!hex)return;
    applyVariablePreview(variable.name,hexOklch(hex));
    return()=>clearVariablePreview(variable.name);
  },[mode,hex,variable.name]);
  const prefix=showNC?newCat:cat;
  const fullNm=prefix&&nm?(prefix+'.'+nm):nm;
  const nameChanged=fullNm&&cssTokenName(fullNm)!==cssTokenName(variable.name);
  const previewRename=async()=>{if(!nameChanged)return;sChecking(true);sErr('');try{const r=await api.p('variables/'+variable.id+'/rename-preview',{new_name:fullNm});if(r?.code){sErr(r.message||'Preview failed');return;}sImpact(r.impact||null);}catch(e){sErr('Preview failed. Check WordPress error logs for details.');}finally{sChecking(false);}};

  const save=async()=>{
    if(!nm)return;sLd(true);sErr('');
    let fv;
    if(mode==='color')fv=hexOklch(hex);
    else if(mode==='fluid')fv=fluidMarker(fMin,fMax);
    else if(mode==='clamp')fv=val?(val.match(/\d/)?pxToRemValue(val):val):'1rem';
    else fv=val;
    if(!fv){sLd(false);sErr(mode==='fluid'?'Enter both a min and max value.':'');return;}
    const updates={};
    if(nameChanged){updates.name=fullNm;if(prop)updates.propagate_usages=true;}
    // For colors, compare hex values to detect change (avoids oklch rounding issues)
    if(mode==='color'){
      if(hex!==clrToHex(variable.value)){updates.value=fv;updates.palette_value=true;}
    } else {
      if(fv!==variable.value)updates.value=fv;
    }
    if(mode==='static'){
      const sourceId = detectAliasSource(fv, vars);
      if(sourceId){
        if(variable.type!=='alias'||Number(variable.source_id)!==Number(sourceId)){
          updates.type='alias';
          updates.source_id=Number(sourceId);
          updates.value=''; // database stores empty value for alias type
        }
      } else {
        if(variable.type!=='base'){
          updates.type='base';
          updates.source_id=null;
          updates.value=fv;
        }
      }
    } else {
      if(variable.type!=='base'){
        updates.type='base';
        updates.source_id=null;
      }
    }
    if(Object.keys(updates).length===0){sLd(false);onDone();return;}
    const r=await api.u('variables/'+variable.id,updates);
    sLd(false);
    if(r?.code==='ve_duplicate'){sErr(r.message||'Name already exists.');return;}
    if(r?.code){sErr(r.message||'Failed to update.');return;}
    onDone(r);
  };

  const catOpts=mode==='color'?['color']:categories.filter(c=>c!=='all'&&c!=='color');

  return h(Sub,{title:'Edit: '+sn(variable.name),onClose,exiting},
    h('div',{class:'ve-mode'},
      h('button',{class:mode==='color'?'on':'',onClick:()=>sMode('color')},'Color'),
      h('button',{class:mode==='clamp'?'on':'',onClick:()=>sMode('clamp')},'Fixed'),
      h('button',{class:mode==='fluid'?'on':'',onClick:()=>sMode('fluid')},'Fluid'),
      h('button',{class:mode==='static'?'on':'',onClick:()=>sMode('static')},'Static')),
    mode!=='static'&&h('div',{class:'ve-row'},
      !showNC?h(SelectMenu,{value:cat,onChange:v=>{if(v==='__new__')sSNC(true);else sCat(v)},options:[...catOpts.map(c=>({value:c,label:c})),{value:'__new__',label:'+ New category'}]}):
      h('input',{placeholder:'category name',value:newCat,onInput:e=>sNC(normalizeNameInput(e.target.value)),style:'flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:10px;outline:none',onBlur:()=>{if(!newCat)sSNC(false);}})),
    h('div',{class:'ve-row'},h('input',{placeholder:'name',value:nm,onInput:e=>{sNm(normalizeNameInput(e.target.value));sImpact(null);if(err)sErr('');},onKeyDown:e=>e.key==='Enter'&&save(),style:'flex:1'})),
    prefix&&nm&&h('div',{style:'font-size:9px;color:#444;padding:0 0 6px;font-family:monospace'},publicTokenLabel(fullNm)),
    nameChanged&&h('div',{class:'ve-warn',style:'margin:0 0 8px'},
      h('div',{style:'font-size:10px;margin-bottom:5px'},'Rename detected. You can update existing var() references in WordPress/Bricks storage too.'),
      h('label',{style:'display:flex;gap:6px;align-items:center;font-size:10px;color:#ccc;margin-bottom:5px'},h('input',{type:'checkbox',checked:prop,onChange:e=>sProp(e.target.checked)}),'Update usages in WordPress storage'),
      h('button',{class:'ve-btn ve-btn-s',style:'font-size:9px;padding:3px 7px',onClick:previewRename,disabled:checking},checking?'Checking...':'Preview impact'),
      impact&&h('div',{style:'font-size:9px;color:#777;margin-top:4px'},(impact.total_matches||0)+' matches in '+((impact.locations||[]).length)+' records')
    ),
    err&&h('div',{style:'font-size:10px;color:#ef4444;padding:2px 0 6px'},err),
    mode==='color'&&h('div',{class:'ve-row'},h(MVColorPicker,{hex,onChange:sHex,fmt,setFmt:sFmt})),
    mode==='clamp'&&h('div',null,
      h('div',{class:'ve-row'},h('input',{placeholder:'Base value (number, stored as rem)',value:val,onInput:e=>sVal(e.target.value),style:'flex:1'})),
      h('div',{style:'font-size:9px;color:#555;padding:0 0 6px'},'Current: '+variable.value)),
    mode==='fluid'&&h('div',null,
      h('div',{class:'ve-row',style:'gap:6px'},
        h('input',{placeholder:'Min px',value:fMin,onInput:e=>{sFMin(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'}),
        h('input',{placeholder:'Max px',value:fMax,onInput:e=>{sFMax(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'})),
      fMin&&fMax&&h('div',{style:'font-size:9px;color:#baf400;padding:0 0 4px;font-family:monospace;word-break:break-all'},fluidPreview(fMin,fMax)),
      h('div',{style:'font-size:9px;color:#555;padding:0 0 6px'},'Scales between the page min/max viewport widths. Min/max are px values.')),
    mode==='static'&&h('div',{class:'ve-row'},
      h(VarRefInput,{placeholder:'value',value:val,onInput:e=>sVal(typeof e.target==='object'?e.target.value:e),vars:vars||[],onKeyDown:e=>e.key==='Enter'&&save()})),
    h('div',{style:'display:flex;gap:5px;justify-content:flex-end;margin-top:4px'},
      h('button',{class:'ve-btn',onClick:save,disabled:ld||!nm||(mode==='fluid'&&(!fMin||!fMax))},ld?'...':'Save Changes')));
}

/* ── Detail (with inline value editing) ── */
function Detail({variable,vars,onNav,onClose,onUpdate,onEditFull}){
  const[d,sD]=useState(null);
  const[editing,sEditing]=useState(false);
  const[editVal,sEV]=useState('');
  const[saving,sSaving]=useState(false);
  useEffect(()=>{sD(null);if(variable){api.g('variables/'+variable.id).then(sD);sEditing(false);}},[variable?.id]);
  if(!variable)return null;
  const css=cssTokenName(variable.name);
  const isGen=variable.type==='generated';
  const isFluidV=isFluidVal(variable.value);
  const fluidPair=isFluidV?parseFluid(variable.value):null;
  const fluidLabel=fluidPair?(trimNum(fluidPair[0])+' → '+trimNum(fluidPair[1])+'px fluid'):'';
  const resolvedVal=resolvedVariableValue(variable, vars);
  const displayVal=variable.type==='alias'
    ? (variable.css_value ? `${variable.css_value}${resolvedVal ? ` (${resolvedVal})` : ''}` : resolvedVal)
    : (isFluidV ? fluidLabel : variable.value);
  // Fluid variables can't be edited with the single-field inline editor — send to full edit panel.
  const startEdit=()=>{if(isGen)return;if(isFluidV){onEditFull&&onEditFull(variable);return;}sEV(variable.type==='alias'?variable.css_value:variable.value);sEditing(true);};
  const saveVal=async()=>{
    const currentVal=variable.type==='alias'?variable.css_value:variable.value;
    if(!editVal||editVal===currentVal){sEditing(false);return;}
    sSaving(true);
    const updates={value:editVal};
    if(isClr(resolvedVal))updates.palette_value=true;
    const sourceId = detectAliasSource(editVal, vars);
    if(sourceId){
      updates.type='alias';
      updates.source_id=Number(sourceId);
      updates.value='';
    } else {
      updates.type='base';
      updates.source_id=null;
    }
    const r=await api.u('variables/'+variable.id,updates);
    sSaving(false);sEditing(false);
    if(r&&!r.code&&onUpdate)onUpdate();
  };
  return h('div',{class:'ve-det'},
    h('div',{class:'ve-det-t'},h('span',null,publicTokenLabel(variable.name)),h('button',{class:'ve-exp',onClick:onClose},ph('x'))),
    h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'Value'),
      editing?h('div',{style:'display:flex;gap:3px;flex:1'},
        h('input',{style:'flex:1;padding:2px 4px;background:#2a2a2a;border:1px solid #baf400;border-radius:3px;color:#f1f1f1;font-size:10px;font-family:monospace;outline:none',value:editVal,onInput:e=>sEV(e.target.value),onKeyDown:e=>{if(e.key==='Enter')saveVal();if(e.key==='Escape')sEditing(false);}}),
        h('button',{class:'ve-btn ve-btn-s',style:'padding:1px 6px;font-size:8px',onClick:saveVal,disabled:saving},saving?'...':'✓'))
      :h('span',{class:'ve-det-v',style:isGen?'':'cursor:pointer',onClick:startEdit,title:isGen?'Generated — edit base variable':(isFluidV?'Fluid — click to edit min/max':'Click to edit')},displayVal)),
    isFluidV&&h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'Fluid'),h('span',{class:'ve-det-v',style:'font-size:9px;color:#baf400;word-break:break-all'},variable.css_value||d?.css_value||'')),
    h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'CSS'),h('span',{class:'ve-det-v'},'var('+css+')')),
    h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'Type'),h('span',{class:'ve-det-v'},variable.type||'base')),
    d?.dependents?.length>0&&h('div',{class:'ve-dep-s'},h('div',{class:'ve-dep-t'},'Dependents ('+d.dependents.length+')'),
      d.dependents.slice(0,6).map(x=>h('div',{class:'ve-dep',onClick:()=>onNav(x)},x.name))),
    d?.depends_on?.length>0&&h('div',{class:'ve-dep-s'},h('div',{class:'ve-dep-t'},'Source'),
      d.depends_on.map(x=>h('div',{class:'ve-dep',onClick:()=>onNav(x)},x.name))));
}

/* ── Main ──────────────────────────────── */
function Panel(){
  const[open,sO]=useState(false);const[vars,sV]=useState([]);const[stats,sStats]=useState(null);const[sr,sSr]=useState('');
  const[sel,sSel]=useState(null);const[nsTab,sNT]=useState('all');
  const[palettesData,sPalettesData]=useState({active:'default',palettes:[]});
  const[colorPalettesData,sColorPalettesData]=useState({palettes:[]});
  const[selectedColorPalette,sSelectedColorPalette]=useState('all');
  const[colorControlMode,sColorControlMode]=useState(()=>localStorage.getItem('ve_color_control_mode')||'theme');
  const[colorPaletteManagerOpen,sColorPaletteManagerOpen]=useState(()=>localStorage.getItem('ve_color_palette_mgr_open')==='1');
  const[showAllTab,sShowAllTab]=useState(true);
  const[exp,sExp]=useState({});const[toast,sToast]=useState('');const[toastTick,sToastTick]=useState(0);const[cfm,sCfm]=useState(null);
  const toastTimerRef=useRef(null);
  const[rowActions,sRowActions]=useState(null);
  const rowActionsTimerRef=useRef(null);
  const[sub,sSub]=useState(null);const[autoGen,sAG]=useState(null);
  const hSel = v => sSel(current => current?.id === v.id ? null : v);
  const [draggingVarId, sDraggingVarId] = useState(null);
  const [dragOverVarId, sDragOverVarId] = useState(null);
  const [checkedVars, sCheckedVars] = useState([]);
  const [confirmBatchDelete, sConfirmBatchDelete] = useState(false);

  const handleVarDragStart = (e, v) => {
    sDraggingVarId(v.id);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', String(v.id));
  };
  const handleVarDragOver = (e, v) => {
    e.preventDefault();
    if (v.id !== draggingVarId) {
      sDragOverVarId(v.id);
    }
  };
  const handleVarDragEnd = () => {
    sDraggingVarId(null);
    sDragOverVarId(null);
  };
  const handleVarDrop = async (e, targetVar) => {
    e.preventDefault();
    const sourceId = Number(e.dataTransfer.getData('text/plain'));
    sDraggingVarId(null);
    sDragOverVarId(null);
    if (!sourceId || sourceId === targetVar.id) return;

    const currentList = [...filtered];
    const sourceIdx = currentList.findIndex(x => x.id === sourceId);
    const targetIdx = currentList.findIndex(x => x.id === targetVar.id);
    if (sourceIdx === -1 || targetIdx === -1) return;

    const [removed] = currentList.splice(sourceIdx, 1);
    currentList.splice(targetIdx, 0, removed);

    const allVars = [...vars];
    const idsToReorder = currentList.map(x => x.id);
    const reorderedIds = [];
    reorderedIds.push(...idsToReorder);
    const otherIds = allVars.filter(x => !idsToReorder.includes(x.id)).map(x => x.id);
    reorderedIds.push(...otherIds);

    sV(allVars.map(x => {
      if (idsToReorder.includes(x.id)) {
        const idx = idsToReorder.indexOf(x.id);
        return { ...x, position: idx };
      }
      return x;
    }));

    try {
      const res = await api.p('variables/reorder', { ids: reorderedIds });
      if (res && !res.code) {
        flash('Order saved');
      } else {
        flash(res?.message || 'Failed to save order');
      }
      load();
    } catch(err) {
      flash('Failed to save order');
      load();
    }
  };

  const toggleVarChecked = (id) => {
    sCheckedVars(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };
  const toggleAllVarsChecked = () => {
    const visibleIds = filtered.map(x => x.id);
    const allChecked = visibleIds.every(id => checkedVars.includes(id));
    if (allChecked) {
      sCheckedVars(prev => prev.filter(id => !visibleIds.includes(id)));
    } else {
      sCheckedVars(prev => [...new Set([...prev, ...visibleIds])]);
    }
  };
  const clearCheckedVars = () => sCheckedVars([]);
  const deleteCheckedVars = async () => {
    if (checkedVars.length === 0) return;
    try {
      const res = await api.p('variables/batch-delete', { ids: checkedVars, force: true });
      if (res && !res.code) {
        flash(checkedVars.length + ' variables deleted');
        clearCheckedVars();
        load();
      } else {
        flash(res?.message || 'Failed to delete variables');
      }
    } catch(e) {
      flash('Failed to delete variables');
    }
  };
  const moveCheckedVarsToPalette = async (paletteId) => {
    if (checkedVars.length === 0 || !paletteId) return;
    try {
      const res = await api.p('color-palettes/variables/batch-move', { ids: checkedVars, palette_id: Number(paletteId) });
      if (res && !res.code) {
        flash(checkedVars.length + ' colors assigned to palette');
        clearCheckedVars();
        load();
      } else {
        flash(res?.message || 'Failed to assign colors');
      }
    } catch(e) {
      flash('Failed to assign colors');
    }
  };
  const activatePalette = async (slug) => {
    try {
      const res = await api.p('themes/' + slug + '/activate', {});
      if (res && !res.code) {
        sPalettesData(prev => ({ ...prev, active: slug }));
        load();
        flash('Theme activated');
      } else {
        flash(res?.message || 'Activation failed');
      }
    } catch (e) {
      flash('Activation failed');
    }
  };
  const[updateInfo,sUpdateInfo]=useState(null);const[skipUpdate,sSkipUpdate]=useState(()=>localStorage.getItem('ve_skip_update_version')||'');
  const[panelMode,sPanelMode]=useState(()=>localStorage.getItem('ve_panel_mode')||'right');
  const[panelPos,sPanelPos]=useState(()=>{try{return JSON.parse(localStorage.getItem('ve_panel_pos')||'{}')}catch(e){return{}}});
  const[allowMultiPanels,sAllowMultiPanels]=useState(()=>localStorage.getItem('ve_allow_multi_panels')==='1');
  const[snapSide,sSnapSide]=useState('');
  const[confirmCleanFooter,sConfirmCleanFooter]=useState(false);
  
  // Standalone panel states
  const [settingsOpen, sSettingsOpen] = useState(false);
  const [helpOpen, sHelpOpen] = useState(false);
  const [cssStudioOpen, sCssStudioOpen] = useState(false);
  const [contentStudioOpen, sContentStudioOpen] = useState(false);
  const [mediaStudioOpen, sMediaStudioOpen] = useState(false);
  const [pluginStudioOpen, sPluginStudioOpen] = useState(false);
  const [cssRecipesOpen, sCssRecipesOpen] = useState(false);

  // Lazy-mount states for exit animations
  const [settingsHasOpened, setSettingsHasOpened] = useState(false);
  const [helpHasOpened, setHelpHasOpened] = useState(false);
  const [cssStudioHasOpened, setCssStudioHasOpened] = useState(false);
  const [contentStudioHasOpened, setContentStudioHasOpened] = useState(false);
  const [mediaStudioHasOpened, setMediaStudioHasOpened] = useState(false);
  const [pluginStudioHasOpened, setPluginStudioHasOpened] = useState(false);
  const [cssRecipesHasOpened, setCssRecipesHasOpened] = useState(false);

  const [deactivatedTools, setDeactivatedTools] = useState(() => {
    try {
      const saved = localStorage.getItem('ve_deactivated_tools');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  useEffect(() => {
    if (deactivatedTools.includes('css_studio') && cssStudioOpen) sCssStudioOpen(false);
    if (deactivatedTools.includes('content_studio') && contentStudioOpen) sContentStudioOpen(false);
    if (deactivatedTools.includes('media_studio') && mediaStudioOpen) sMediaStudioOpen(false);
    if (deactivatedTools.includes('plugin_studio') && pluginStudioOpen) sPluginStudioOpen(false);
    if (deactivatedTools.includes('css_studio') && cssRecipesOpen) sCssRecipesOpen(false);
  }, [deactivatedTools, cssStudioOpen, contentStudioOpen, mediaStudioOpen, pluginStudioOpen, cssRecipesOpen]);

  useEffect(() => { if (settingsOpen) setSettingsHasOpened(true); }, [settingsOpen]);
  useEffect(() => { if (helpOpen) setHelpHasOpened(true); }, [helpOpen]);
  useEffect(() => { if (cssStudioOpen) setCssStudioHasOpened(true); }, [cssStudioOpen]);
  useEffect(() => { if (contentStudioOpen) setContentStudioHasOpened(true); }, [contentStudioOpen]);
  useEffect(() => { if (mediaStudioOpen) setMediaStudioHasOpened(true); }, [mediaStudioOpen]);
  useEffect(() => { if (pluginStudioOpen) setPluginStudioHasOpened(true); }, [pluginStudioOpen]);
  useEffect(() => { if (cssRecipesOpen) setCssRecipesHasOpened(true); }, [cssRecipesOpen]);

  useEffect(() => {
    const openMedia = () => sMediaStudioOpen(true);
    window.addEventListener('ve-open-media-studio', openMedia);
    return () => window.removeEventListener('ve-open-media-studio', openMedia);
  }, []);
  useEffect(()=>{const fn=e=>flash(String(e.detail||''));window.addEventListener('ve-toast-request',fn);return()=>window.removeEventListener('ve-toast-request',fn);},[]);

  useEffect(() => {
    if (MODE !== 'builder') return;
    const listeners=[];
    const wrappers=[];
    const normalizeAttachment=item=>{
      const url=item?.source_url||item?.url||'';
      const mime=item?.mime_type||item?.mime||'image/jpeg';
      const filename=decodeURIComponent(String(url).split('/').pop()||item?.slug||'media');
      const sizes={};
      const rawSizes=item?.media_details?.sizes||{};
      Object.keys(rawSizes).forEach(key=>{
        const size=rawSizes[key]||{};
        sizes[key]={...size,url:size.source_url||size.url||url};
      });
      if(!sizes.full)sizes.full={url,width:item?.media_details?.width||0,height:item?.media_details?.height||0};
      return {
        id:Number(item?.id||0),url,filename,mime,
        type:String(mime).split('/')[0]||'image',
        subtype:String(mime).split('/')[1]||'',
        title:item?.title?.rendered||item?.title||filename,
        caption:item?.caption?.rendered||item?.caption||'',
        description:item?.description?.rendered||item?.description||'',
        alt:item?.alt_text||item?.alt||'',
        sizes
      };
    };
    const createFrame=(runtime,options,intent)=>{
      const callbacks={};
      let selected=[];
      const collection={
        toJSON:()=>selected.slice(),
        first:()=>selected.length?{toJSON:()=>selected[0]}:null,
        add:attachment=>{try{selected.push(attachment?.toJSON?attachment.toJSON():attachment);}catch(e){}},
        reset:()=>{selected=[];}
      };
      const emit=event=>(callbacks[event]||[]).slice().forEach(callback=>{try{callback(frame);}catch(e){}});
      const frame={
        options:options||{},
        on(events,callback){String(events||'').split(/\s+/).filter(Boolean).forEach(event=>{(callbacks[event]||(callbacks[event]=[])).push(callback);});return frame;},
        off(events,callback){String(events||'').split(/\s+/).filter(Boolean).forEach(event=>{if(!callbacks[event])return;callbacks[event]=callback?callbacks[event].filter(cb=>cb!==callback):[];});return frame;},
        open(){
          mediaTargetRef.current=intent?.scope||intent?.target||null;
          pendingMediaFrameRef.current=frame;
          sMediaStudioOpen(true);
          emit('open');
          flash('Media Studio opened for asset selection.');
          return frame;
        },
        close(){emit('close');return frame;},
        state:()=>({get:key=>key==='selection'?collection:null}),
        content:{get:()=>null},
        __select(item){
          const attachment=normalizeAttachment(item);
          if(!attachment.url)return false;
          selected=[attachment];
          emit('select');
          return true;
        }
      };
      return frame;
    };
    const install=runtime=>{
      try{
        if(!runtime||runtime.__veWpHooked)return;
        runtime.__veWpHooked=true;
        const wrapMedia=media=>{
          if(typeof media!=='function'||media.__veMediaStudioBridge)return media;
          const original=media;
          const wrapped=function(...args){
            const intent=mediaIntentRef.current;
            if(intent&&Date.now()-intent.at<1800){
              mediaIntentRef.current=null;
              return createFrame(runtime,args[0],intent);
            }
            return original.apply(this,args);
          };
          Object.getOwnPropertyNames(original).forEach(key=>{
            try{if(!['length','name','prototype'].includes(key))Object.defineProperty(wrapped,key,Object.getOwnPropertyDescriptor(original,key));}catch(e){}
          });
          wrapped.__veMediaStudioBridge=true;
          wrapped.__veOriginal=original;
          return wrapped;
        };
        let currentWp=runtime.wp;
        let originalWpDesc=Object.getOwnPropertyDescriptor(runtime,'wp');
        let originalMediaDesc=null;
        let wpObjForCleanup=null;
        const hookMediaOnWp=wpObj=>{
          if(!wpObj||wpObj.__veMediaHooked)return;
          wpObj.__veMediaHooked=true;
          wpObjForCleanup=wpObj;
          let currentMedia=wpObj.media;
          originalMediaDesc=Object.getOwnPropertyDescriptor(wpObj,'media');
          if(currentMedia){currentMedia=wrapMedia(currentMedia);}
          try{
            Object.defineProperty(wpObj,'media',{
              get(){return currentMedia;},
              set(newMedia){currentMedia=wrapMedia(newMedia);},
              configurable:true,
              enumerable:true
            });
          }catch(e){
            wpObj.media=wrapMedia(currentMedia);
          }
        };
        if(currentWp){hookMediaOnWp(currentWp);}
        try{
          Object.defineProperty(runtime,'wp',{
            get(){return currentWp;},
            set(newWp){
              currentWp=newWp;
              if(newWp){hookMediaOnWp(newWp);}
            },
            configurable:true,
            enumerable:true
          });
        }catch(e){
          if(runtime.wp){hookMediaOnWp(runtime.wp);}
        }
        wrappers.push({
          runtime,
          restore:()=>{
            try{
              delete runtime.__veWpHooked;
              if(originalWpDesc){Object.defineProperty(runtime,'wp',originalWpDesc);}
              else{delete runtime.wp;runtime.wp=currentWp;}
            }catch(e){try{runtime.wp=currentWp;}catch(_){}}
            try{
              if(wpObjForCleanup){
                delete wpObjForCleanup.__veMediaHooked;
                if(originalMediaDesc){Object.defineProperty(wpObjForCleanup,'media',originalMediaDesc);}
                else{
                  const orig=wpObjForCleanup.media?.__veOriginal;
                  delete wpObjForCleanup.media;
                  wpObjForCleanup.media=orig||wpObjForCleanup.media;
                }
              }
            }catch(e){}
          }
        });
      }catch(e){}
    };
    const track=e=>{
      const target=e.target;
      if(!target||!target.closest||target.closest('#ve-panel-root,.media-modal,.media-frame'))return;
      mediaIntentRef.current={at:Date.now(),target,scope:findMediaWriteScope(target)};
    };
    const installAll=()=>{
      builderRuntimeWindows().forEach(runtime=>{
        install(runtime);
        try{
          const doc=runtime.document;
          if(listeners.some(entry=>entry.doc===doc))return;
          doc.addEventListener('pointerdown',track,true);
          listeners.push({doc});
        }catch(e){}
      });
    };
    installAll();
    const retry=setInterval(installAll,300);
    return () => {
      clearInterval(retry);
      listeners.forEach(({doc})=>{try{doc.removeEventListener('pointerdown',track,true);}catch(e){}});
      wrappers.forEach(w=>{try{w.restore();}catch(e){}});
    };
  }, []);

  // Mutual exclusion: by default, one major MV panel is open at a time.
  useEffect(() => {
    if (!allowMultiPanels && open) { sSettingsOpen(false); sHelpOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false); }
  }, [open, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && settingsOpen) { sO(false); sHelpOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false); }
  }, [settingsOpen, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && helpOpen) { sO(false); sSettingsOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false); }
  }, [helpOpen, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && cssStudioOpen) { sO(false); sSettingsOpen(false); sHelpOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false); }
  }, [cssStudioOpen, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && contentStudioOpen) { sO(false); sSettingsOpen(false); sHelpOpen(false); sCssStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false); }
  }, [contentStudioOpen, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && mediaStudioOpen) { sO(false); sSettingsOpen(false); sHelpOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false); }
  }, [mediaStudioOpen, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && pluginStudioOpen) { sO(false); sSettingsOpen(false); sHelpOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sCssRecipesOpen(false); }
  }, [pluginStudioOpen, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && cssRecipesOpen) { sO(false); sSettingsOpen(false); sHelpOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); }
  }, [cssRecipesOpen, allowMultiPanels]);

  const sRef=useRef();
  const panelRef=useRef();
  const fabRef=useRef();
  const mediaTargetRef=useRef(null);
  const mediaIntentRef=useRef(null);
  const pendingMediaFrameRef=useRef(null);

  const findMediaWriteScope = target => {
    if (!target || !target.closest) return null;
    return target.closest('.bricks-control-image, .bricks-control-media, .bricks-control-background, .brx-control, .bricks-control, .control, .control-inner, [data-control], [data-control-key], [data-setting]') || target;
  };

  const setNativeValue = (el, value) => {
    if (!el) return false;
    try {
      const proto = Object.getPrototypeOf(el);
      const desc = proto && Object.getOwnPropertyDescriptor(proto, 'value');
      if (desc && desc.set) desc.set.call(el, value);
      else el.value = value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      return true;
    } catch (e) {
      try {
        el.value = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (e2) {
        return false;
      }
    }
  };

  const insertMediaIntoRememberedControl = item => {
    const url = item?.source_url || '';
    if (!url) return false;
    const pendingFrame=pendingMediaFrameRef.current;
    if(pendingFrame?.__select&&pendingFrame.__select(item)){
      pendingMediaFrameRef.current=null;
      mediaTargetRef.current=null;
      flash('Inserted media into the Bricks control.');
      sMediaStudioOpen(false);
      return true;
    }
    const target = mediaTargetRef.current;
    const scope = findMediaWriteScope(target);
    let inserted = false;
    if (scope) {
      const writable = Array.from(scope.querySelectorAll('input:not([type="hidden"]), textarea, [contenteditable="true"]')).filter(el => {
        const t = ((el.getAttribute('type') || '') + ' ' + (el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('data-setting') || '') + ' ' + String(el.className || '')).toLowerCase();
        return !el.disabled && !el.readOnly && (el.tagName === 'TEXTAREA' || el.isContentEditable || /url|image|media|svg|background|source|custom/.test(t) || el.value);
      });
      const field = writable.find(el => /url|source|custom/i.test((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + String(el.className || ''))) || writable[0];
      if (field) {
        if (field.isContentEditable) {
          field.textContent = url;
          field.dispatchEvent(new Event('input', { bubbles: true }));
          field.dispatchEvent(new Event('change', { bubbles: true }));
          inserted = true;
        } else {
          inserted = setNativeValue(field, url);
        }
      }
      scope.querySelectorAll('img').forEach(img => {
        try { img.src = url; inserted = true; } catch (e) {}
      });
      scope.dispatchEvent(new CustomEvent('ve-media-selected', { bubbles: true, detail: { id: item.id, url, item } }));
    }
    if (inserted) {
      flash('Inserted media into Bricks control.');
      mediaTargetRef.current = null;
      sMediaStudioOpen(false);
      return true;
    }
    navigator.clipboard?.writeText(url);
    flash('Copied media URL. Bricks did not expose a writable field here.');
    return false;
  };

  // Toggle FAB visibility and reset position when panels open/close
  useEffect(() => {
    const fab = fabRef.current;
    if (!fab) return;

    const hasOpenPanel = open || settingsOpen || helpOpen || cssStudioOpen || contentStudioOpen || mediaStudioOpen || pluginStudioOpen || cssRecipesOpen;
    if (hasOpenPanel) {
      fab.classList.add('ve-fab-hidden');
    } else {
      fab.classList.remove('ve-fab-hidden');
      fab.style.left = '';
      fab.style.right = '';
      fab.classList.remove('ve-fab-left-side');
    }
  }, [open, settingsOpen, helpOpen, cssStudioOpen, contentStudioOpen, mediaStudioOpen, pluginStudioOpen, cssRecipesOpen]);

  const dragRef=useRef(null);
  const snapRef=useRef('');

  const load=useCallback(async()=>{const v=await api.g('variables?dedupe=true&_nc='+Date.now());if(Array.isArray(v)){sV(v);sSel(current=>current?(v.find(item=>item.id===current.id)||null):current);}api.g('variables/stats').then(d=>{if(d&&!d.code)sStats(d);}).catch(()=>{});api.g('themes').then(d=>{if(d&&!d.code)sPalettesData(d);}).catch(()=>{});api.g('color-palettes').then(d=>{if(d&&!d.code)sColorPalettesData(d);}).catch(()=>{});},[]);
  useEffect(()=>{load();},[]);
  useEffect(()=>{
    api.g('settings').then(d=>{
      if(d) {
        if(d.vw_min)_veViewport={vw_min:+d.vw_min||320,vw_max:+d.vw_max||1440};
        if(typeof d.allow_multi_panels !== 'undefined') {
          sAllowMultiPanels(!!d.allow_multi_panels);
          persistUserPreference('ve_allow_multi_panels', d.allow_multi_panels ? '1' : '0');
        }
        if(typeof d.show_all_tab !== 'undefined') {
          sShowAllTab(!!d.show_all_tab);
        }
        if(Array.isArray(d.deactivated_tools)) {
          setDeactivatedTools(d.deactivated_tools);
          persistUserPreference('ve_deactivated_tools', d.deactivated_tools);
        }
      }
    }).catch(()=>{});
  },[]);
  useEffect(() => {
    const handleShowAllTabChanged = (e) => {
      if (typeof e.detail !== 'undefined') {
        sShowAllTab(!!e.detail);
      }
    };
    window.addEventListener('ve-show-all-tab-changed', handleShowAllTabChanged);
    return () => window.removeEventListener('ve-show-all-tab-changed', handleShowAllTabChanged);
  }, []);
  useEffect(() => {
    const handleChanged = (e) => {
      if (e.detail && Array.isArray(e.detail)) {
        setDeactivatedTools(e.detail);
      }
    };
    window.addEventListener('ve-deactivated-tools-changed', handleChanged);
    return () => window.removeEventListener('ve-deactivated-tools-changed', handleChanged);
  }, []);
  useEffect(()=>{if(!open)return;const t=setInterval(load,10000);const f=()=>{if(!document.hidden)load();};window.addEventListener('focus',f);document.addEventListener('visibilitychange',f);return()=>{clearInterval(t);window.removeEventListener('focus',f);document.removeEventListener('visibilitychange',f);};},[open,load]);
  useEffect(()=>{let alive=true;const check=()=>api.p('update/check',{}).then(r=>{if(alive&&r&&!r.code)sUpdateInfo(r);}).catch(()=>{});check();const t=setInterval(check,10*60*1000);return()=>{alive=false;clearInterval(t);};},[]);
  const skipUpdateVersion=useCallback(version=>{persistUserPreference('ve_skip_update_version',version);sSkipUpdate(version);},[]);
  useEffect(()=>{
    const sync=()=>syncMimamsBarUpdateNotice(updateInfo,skipUpdate,skipUpdateVersion);
    sync();
    const timers=[setTimeout(sync,250),setTimeout(sync,1000)];
    return()=>timers.forEach(clearTimeout);
  },[updateInfo,skipUpdate,skipUpdateVersion]);
  useEffect(()=>{const fn=e=>sAllowMultiPanels(!!e.detail);window.addEventListener('ve-panel-concurrency-changed',fn);return()=>window.removeEventListener('ve-panel-concurrency-changed',fn);},[]);
  useEffect(() => {
    const handleVarsUpdated = () => {
      load();
    };
    window.addEventListener('ve-variables-updated', handleVarsUpdated);
    window.addEventListener('ve:variables-updated', handleVarsUpdated);
    return () => {
      window.removeEventListener('ve-variables-updated', handleVarsUpdated);
      window.removeEventListener('ve:variables-updated', handleVarsUpdated);
    };
  }, [load]);
  useEffect(() => {
    const handleSettingsUpdated = () => {
      api.g('settings').then(d => {
        if(d) {
          if(d.vw_min)_veViewport={vw_min:+d.vw_min||320,vw_max:+d.vw_max||1440};
          if(typeof d.allow_multi_panels !== 'undefined') sAllowMultiPanels(!!d.allow_multi_panels);
          if(typeof d.show_all_tab !== 'undefined') sShowAllTab(!!d.show_all_tab);
          if(Array.isArray(d.deactivated_tools)) setDeactivatedTools(d.deactivated_tools);
        }
      }).catch(()=>{});
    };
    window.addEventListener('ve-settings-updated', handleSettingsUpdated);
    return () => window.removeEventListener('ve-settings-updated', handleSettingsUpdated);
  }, []);
  useEffect(()=>{if(autoGen){const v=vars.find(x=>x.id===autoGen.id||x.name===autoGen.name);if(v){sSub({type:'genScale',v});sAG(null);}};},[vars,autoGen]);
  
  // Shortcuts and custom toggle triggers
  useEffect(()=>{const fn=e=>{if(e.altKey&&(e.key==='z'||e.key==='Z')){e.preventDefault();sO(p=>!p);setTimeout(()=>sRef.current?.focus(),80);}};document.addEventListener('keydown',fn);return()=>document.removeEventListener('keydown',fn);},[]);
  useEffect(()=>{const fn=()=>{sO(p=>!p);setTimeout(()=>sRef.current?.focus(),80);};window.addEventListener('ve-toggle-panel',fn);return()=>window.removeEventListener('ve-toggle-panel',fn);},[]);
  
  // Standalone panel toggle events (for Alt+Q / Speed Dial / Global messaging delegation)
  useEffect(() => {
    const toggleSettings = () => sSettingsOpen(prev => !prev);
    const toggleHelp = () => sHelpOpen(prev => !prev);
    const toggleCss = () => sCssStudioOpen(prev => !prev);
    const toggleRecipes = () => sCssRecipesOpen(prev => !prev);
    const toggleContent = () => sContentStudioOpen(prev => !prev);
    const toggleMedia = () => sMediaStudioOpen(prev => !prev);
    window.addEventListener('ve-toggle-settings', toggleSettings);
    window.addEventListener('ve-toggle-help', toggleHelp);
    window.addEventListener('ve-toggle-css', toggleCss);
    window.addEventListener('ve-toggle-css-recipes', toggleRecipes);
    window.addEventListener('ve-toggle-content', toggleContent);
    window.addEventListener('ve-toggle-media', toggleMedia);
    return () => {
      window.removeEventListener('ve-toggle-settings', toggleSettings);
      window.removeEventListener('ve-toggle-help', toggleHelp);
      window.removeEventListener('ve-toggle-css', toggleCss);
      window.removeEventListener('ve-toggle-css-recipes', toggleRecipes);
      window.removeEventListener('ve-toggle-content', toggleContent);
      window.removeEventListener('ve-toggle-media', toggleMedia);
    };
  }, []);

  // Global PointerDown outside click checks
  useEffect(() => {
    const handleOutsideClick = e => {
      const target = e.target;
      if (!target) return;

      if (target.closest('.CodeMirror-hints') || target.closest('.ve-suggest') || target.closest('.ve-ac') || target.closest('.ve-menu-list')) {
        return;
      }
      
      if (target.closest('.ve-fab-wrap') || target.closest('.ve-fab-menu') || target.closest('.ve-fab') || target.closest('#wp-admin-bar-ve-toggle')) {
        return;
      }

      const clickedAnyPanel = target.closest('.ve-o') || target.closest('.ve-o.ve-sidecar') || target.closest('.ve-standalone-panel');

      if (!clickedAnyPanel) {
        if (open) {
          const panelEl = panelRef.current;
          if (panelEl && !panelEl.contains(target) && !target.closest('.ve-cf-b') && !target.closest('.ve-modal')) {
            sO(false);
          }
        }

        if (settingsOpen) {
          const settingsEl = document.querySelector('.ve-standalone-panel[data-panel="settings"]');
          if (settingsEl && !settingsEl.contains(target)) {
            sSettingsOpen(false);
          }
        }

        if (helpOpen) {
          const helpEl = document.querySelector('.ve-standalone-panel[data-panel="help"]');
          if (helpEl && !helpEl.contains(target)) {
            sHelpOpen(false);
          }
        }

        if (cssStudioOpen) {
          const cssEl = document.querySelector('.ve-standalone-panel[data-panel="css_studio"]');
          if (cssEl && !cssEl.contains(target) && !target.closest('.CodeMirror-dialog') && !target.closest('.ve-o.ve-sidecar')) {
            sCssStudioOpen(false);
          }
        }

        if (contentStudioOpen) {
          const contentEl = document.querySelector('.ve-standalone-panel[data-panel="content_studio"]');
          if (contentEl && !contentEl.contains(target) && !target.closest('.ve-modal')) {
            sContentStudioOpen(false);
          }
        }

        if (mediaStudioOpen) {
          const mediaEl = document.querySelector('.ve-standalone-panel[data-panel="media_studio"]');
          if (mediaEl && !mediaEl.contains(target) && !target.closest('.ve-modal')) {
            mediaTargetRef.current = null;
            sMediaStudioOpen(false);
          }
        }

        if (pluginStudioOpen) {
          const pluginEl = document.querySelector('.ve-standalone-panel[data-panel="plugin_studio"]');
          if (pluginEl && !pluginEl.contains(target) && !target.closest('.ve-modal')) {
            sPluginStudioOpen(false);
          }
        }

        if (cssRecipesOpen) {
          const recipesEl = document.querySelector('.ve-standalone-panel[data-panel="css_recipes"]');
          if (recipesEl && !recipesEl.contains(target) && !target.closest('.ve-modal')) {
            sCssRecipesOpen(false);
          }
        }
      }
    };

    document.addEventListener('pointerdown', handleOutsideClick, true);
    return () => {
      document.removeEventListener('pointerdown', handleOutsideClick, true);
    };
  }, [open, settingsOpen, helpOpen, cssStudioOpen, contentStudioOpen, mediaStudioOpen, pluginStudioOpen, cssRecipesOpen]);

  const genSort=useCallback((a,b)=>{
    const av=pxV(a.value), bv=pxV(b.value);
    if(av!==bv)return av-bv;
    return String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true,sensitivity:'base'});
  },[]);

  const{bases,childMap,namespaces}=useMemo(()=>{
    const cm={};const ns=new Set();const bs=[];
    vars.forEach(v=>{ns.add(variableNamespace(v));if(v.type==='generated'&&v.source_id){if(!cm[v.source_id])cm[v.source_id]=[];cm[v.source_id].push(v);}});
    Object.keys(cm).forEach(k=>cm[k].sort(genSort));
    vars.forEach(v=>{if(v.type!=='generated')bs.push(v);});
    bs.sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true,sensitivity:'base'}));
    const list = [...ns].sort();
    return{bases:bs,childMap:cm,namespaces:showAllTab?['all',...list]:list};
  },[vars,genSort,showAllTab]);

  const allCats=useMemo(()=>{
    const list = namespaces.filter(n => n !== 'all');
    return [...new Set(['color','space','font','radius','size','shadow','opacity','motion',...list])].sort();
  },[namespaces]);

  useEffect(() => {
    if (!showAllTab && nsTab === 'all') {
      const list = namespaces.filter(n => n !== 'all');
      if (list.length) sNT(list[0]);
    }
  }, [showAllTab, nsTab, namespaces]);
  useEffect(()=>{
    if(selectedColorPalette!=='all'&&!(colorPalettesData.palettes||[]).some(p=>String(p.id)===String(selectedColorPalette))){
      sSelectedColorPalette('all');
    }
  },[colorPalettesData,selectedColorPalette]);

  const maxSp=useMemo(()=>{let mx=0;vars.forEach(v=>{if(v.namespace==='space'){const n=pxV(v.value);if(n>mx)mx=n;}});return mx||1;},[vars]);
  const filtered=useMemo(()=>{
    let list=nsTab==='all'?bases:bases.filter(v=>variableNamespace(v)===nsTab);
    if(nsTab==='color'&&selectedColorPalette!=='all'){
      list=list.filter(v=>String(v.palette_id||0)===String(selectedColorPalette));
    }
    if(sr){
      const q=sr.toLowerCase();
      const mp=new Set();
      vars.forEach(v=>{
        if(v.type==='generated'&&v.source_id&&fuzzy(q,v.nameLower||(v.nameLower=v.name.toLowerCase())).m)mp.add(String(v.source_id));
      });
      list=list.map(v=>({
        ...v,
        ...fuzzy(q,v.nameLower||(v.nameLower=v.name.toLowerCase())),
        cm:mp.has(String(v.id))
      })).filter(v=>v.m||v.cm).sort((a,b)=>(b.s||0)-(a.s||0));
    }
    return list;
  },[bases,vars,sr,nsTab,selectedColorPalette]);
  const cleanupIssues=useMemo(()=>stats?[(stats.stale_generated?stats.stale_generated+' stale generated':''),(stats.orphan_generated?stats.orphan_generated+' orphan generated':''),(stats.missing_dependencies?stats.missing_dependencies+' missing dependency links':''),(stats.orphan_dependencies?stats.orphan_dependencies+' orphan dependency rows':''),(stats.duplicate_count?stats.duplicate_count+' duplicate names':''),(stats.older_generators?stats.older_generators+' older generators':'')].filter(Boolean):[],[stats]);
  const manualIntegrityNotices=useMemo(()=>stats?[(stats.public_name_conflict_count?stats.public_name_conflict_count+' CSS name conflicts require manual rename':''),(stats.broken_aliases?stats.broken_aliases+' aliases have missing sources and require manual relinking':''),(stats.blocked_orphan_generated?stats.blocked_orphan_generated+' orphan generated variables still have dependents and require review':'')].filter(Boolean):[],[stats]);
  const hasAvailableUpdate=!!(updateInfo?.update_available&&updateInfo.latest_version!==skipUpdate);

  const flash=m=>{
    if(toastTimerRef.current)clearTimeout(toastTimerRef.current);
    sToastTick(v=>v+1);
    sToast(m);
    toastTimerRef.current=setTimeout(()=>{sToast('');toastTimerRef.current=null;},2200);
  };
  const setPanelMode=m=>{sPanelMode(m);persistUserPreference('ve_panel_mode',m);};
  const startPanelDrag=e=>{
    if(e.button!==0)return;
    const currentLeft=panelMode==='left'?0:(panelMode==='right'?Math.max(16,window.innerWidth-430):(panelPos.left||Math.max(16,window.innerWidth-430)));
    const currentTop=panelMode==='float'?(panelPos.top||16):16;
    const startLeft=Math.max(8,Math.min(window.innerWidth-120,currentLeft));
    const startTop=Math.max(8,Math.min(window.innerHeight-90,currentTop));
    dragRef.current={x:e.clientX,y:e.clientY,left:startLeft,top:startTop};
    sPanelMode('float');
    persistUserPreference('ve_panel_mode','float');
    sPanelPos({left:startLeft,top:startTop});
    const el=panelRef.current;
    if(el){el.classList.add('ve-dragging');el.style.left=startLeft+'px';el.style.top=startTop+'px';el.style.right='auto';}
    document.querySelector('#ve-panel-root .ve-hdr')?.classList.add('dragging');
    e.preventDefault();
  };
  useEffect(()=>{
    const move=e=>{
      const d=dragRef.current;if(!d)return;
      const el=panelRef.current;
      const w=el?el.offsetWidth:410;
      const hgt=el?el.offsetHeight:760;
      const maxLeft=Math.max(8,window.innerWidth-w-8);
      const maxTop=Math.max(8,window.innerHeight-hgt-8);
      const next={left:Math.max(8,Math.min(maxLeft,d.left+(e.clientX-d.x))),top:Math.max(8,Math.min(maxTop,d.top+(e.clientY-d.y)))};
      d.last=next;
      if(el){el.style.left=next.left+'px';el.style.top=next.top+'px';el.style.right='auto';}
      const cur=snapRef.current;
      let side='';
      if(cur==='left')side=next.left<190?'left':'';
      else if(cur==='right')side=next.left>maxLeft-190?'right':'';
      else side=next.left<72?'left':(next.left>maxLeft-72?'right':'');
      if(side!==snapRef.current){snapRef.current=side;sSnapSide(side);}
    };
    const up=()=>{
      if(!dragRef.current)return;
      const side=snapRef.current;
      const last=dragRef.current.last||panelPos;
      if(side==='left'||side==='right'){
        sPanelMode(side);
        persistUserPreference('ve_panel_mode',side);
      }else{
        sPanelPos(last);
        persistUserPreference('ve_panel_pos',last);
      }
      panelRef.current?.classList.remove('ve-dragging');
      dragRef.current=null;
      snapRef.current='';
      sSnapSide('');
      document.querySelector('#ve-panel-root .ve-hdr')?.classList.remove('dragging');
    };
    window.addEventListener('mousemove',move);window.addEventListener('mouseup',up);
    return()=>{window.removeEventListener('mousemove',move);window.removeEventListener('mouseup',up);};
  },[panelPos]);
  const cpVar=n=>{navigator.clipboard?.writeText('var('+cssTokenName(n)+')');flash('Copied!');};
  const openRowActions=id=>{if(rowActionsTimerRef.current)clearTimeout(rowActionsTimerRef.current);rowActionsTimerRef.current=null;sRowActions(String(id));};
  const scheduleRowActionsClose=id=>{
    if(rowActionsTimerRef.current)clearTimeout(rowActionsTimerRef.current);
    rowActionsTimerRef.current=setTimeout(()=>{
      const row=document.querySelector('[data-ve-variable-row="'+String(id)+'"]');
      if(!row?.matches(':hover')&&!row?.matches(':focus-within'))sRowActions(current=>current===String(id)?null:current);
    },220);
  };

  const tgExp=(id,defaultOpen=false)=>sExp(p=>{const k=String(id);const has=Object.prototype.hasOwnProperty.call(p,k);return {...p,[k]:has?!p[k]:!defaultOpen};});
  const cleanDbFooter=async()=>{
    sConfirmCleanFooter(false);
    try{flash('Cleaning...');const r=await api.p('variables/cleanup',{});await load();flash(r?.message||'Cleaned');}
    catch(e){flash('Cleanup failed');}
  };
  const [confirmDuplicate, sConfirmDuplicate] = useState(null);
  const [paletteTransfer, sPaletteTransfer] = useState(null);
  const hDup = v => {
    sConfirmDuplicate(v);
  };
  const cfmDup = async () => {
    if (!confirmDuplicate) return;
    const v = confirmDuplicate;
    sConfirmDuplicate(null);
    try {
      const res = v.palette_eligible&&v.palette_id
        ? await api.p('color-palettes/variables/'+v.id+'/copy',{palette_id:Number(v.palette_id),name:sn(v.name)+'-copy',include_generated:true})
        : await api.p('variables', { name: v.name + '.copy', value: v.value });
      if (res && res.code) {
        flash(res.message || 'Duplication failed');
      } else {
        load();
        flash('Duplicated');
      }
    } catch(e) {
      flash('Duplication failed');
    }
  };
  const openPaletteTransfer=(mode,v)=>{
    const destinations=(colorPalettesData.palettes||[]).filter(p=>mode==='copy'||String(p.id)!==String(v.palette_id||0));
    sPaletteTransfer({
      mode,
      variable:v,
      paletteId:destinations[0]?String(destinations[0].id):'',
      name:mode==='copy'?sn(v.name)+'-copy':sn(v.name),
      includeGenerated:true
    });
  };
  const runPaletteTransfer=async()=>{
    if(!paletteTransfer||!paletteTransfer.paletteId)return;
    const t=paletteTransfer;
    sPaletteTransfer(null);
    try{
      const path='color-palettes/variables/'+t.variable.id+'/'+t.mode;
      const body={palette_id:Number(t.paletteId)};
      if(t.mode==='copy'){body.name=t.name;body.include_generated=!!t.includeGenerated;}
      const res=await api.p(path,body);
      if(res?.code){flash(res.message||('Could not '+t.mode+' color'));return;}
      await load();
      flash(t.mode==='copy'?'Color copied to palette':'Color moved to palette');
    }catch(e){flash('Palette operation failed');}
  };
  const hDel = v => {
    sCfm(v);
  };
  const cfmDel = async () => {
    if (!cfm) return;
    try {
      const res = await api.d('variables/' + cfm.id + '?force=true');
      if (res && res.code) {
        flash(res.message || 'Delete failed');
      } else {
        load();
        flash('Deleted');
        sSel(null);
        sCfm(null);
      }
    } catch(e) {
      flash('Delete failed');
    }
  };
  const hCreated=(nv,isClamp)=>{load();sSub(null);flash('Created');if(isClamp)sAG(nv);};

  // Theme value-layer management states
  const [paletteManagerOpen, sPaletteManagerOpen] = useState(() => localStorage.getItem('ve_palette_mgr_open') === '1');
  const [paletteName, sPaletteName] = useState('');
  const [editingPalette, sEditingPalette] = useState(null);
  const [editPaletteName, sEditPaletteName] = useState('');
  const [paletteLd, sPaletteLd] = useState(false);
  const [paletteErr, sPaletteErr] = useState('');
  const [confirmDeletePalette, sConfirmDeletePalette] = useState(null);

  const togglePaletteManager = (val) => {
    sPaletteManagerOpen(val);
    localStorage.setItem('ve_palette_mgr_open', val ? '1' : '0');
  };
  const toggleColorPaletteManager = val => {
    sColorPaletteManagerOpen(val);
    localStorage.setItem('ve_color_palette_mgr_open',val?'1':'0');
  };
  const chooseColorControlMode = mode => {
    const next=mode==='palette'?'palette':'theme';
    sColorControlMode(next);
    localStorage.setItem('ve_color_control_mode',next);
    if(next==='theme')toggleColorPaletteManager(false);
    else togglePaletteManager(false);
  };

  // Theme actions
  const createPalette = async () => {
    if (!paletteName.trim()) return;
    sPaletteLd(true);
    sPaletteErr('');
    try {
      const res = await api.p('themes', { name: paletteName.trim(), source_slug: palettesData.active });
      sPaletteLd(false);
      if (res?.code) {
        sPaletteErr(res.message || 'Could not create theme.');
      } else {
        sPaletteName('');
        await load();
        flash('Theme created');
      }
    } catch(e) {
      sPaletteLd(false);
      sPaletteErr('Could not create theme.');
    }
  };

  const duplicatePalette = async (p) => {
    sPaletteLd(true);
    sPaletteErr('');
    try {
      const res = await api.p('themes/' + p.slug + '/duplicate', { name: p.name + ' Copy' });
      sPaletteLd(false);
      if (res?.code) {
        sPaletteErr(res.message || 'Could not duplicate theme.');
      } else {
        await load();
        flash('Theme duplicated');
      }
    } catch(e) {
      sPaletteLd(false);
      sPaletteErr('Could not duplicate theme.');
    }
  };

  const renamePalette = async () => {
    if (!editingPalette || !editPaletteName.trim()) return;
    sPaletteLd(true);
    sPaletteErr('');
    try {
      const res = await api.u('themes/' + editingPalette, { name: editPaletteName.trim() });
      sPaletteLd(false);
      if (res?.code) {
        sPaletteErr(res.message || 'Could not rename theme.');
      } else {
        sEditingPalette(null);
        sEditPaletteName('');
        await load();
        flash('Theme renamed');
      }
    } catch(e) {
      sPaletteLd(false);
      sPaletteErr('Could not rename theme.');
    }
  };

  const deletePalette = async () => {
    if (!confirmDeletePalette) return;
    const slug = confirmDeletePalette.slug;
    sConfirmDeletePalette(null);
    sPaletteLd(true);
    sPaletteErr('');
    try {
      const res = await api.d('themes/' + slug);
      sPaletteLd(false);
      if (res?.code) {
        sPaletteErr(res.message || 'Could not delete theme.');
      } else {
        await load();
        flash('Theme deleted');
      }
    } catch(e) {
      sPaletteLd(false);
      sPaletteErr('Could not delete theme.');
    }
  };

  const[subExit,sSE]=useState(false);
  const closeSub=useCallback(()=>{sSE(true);setTimeout(()=>{sSub(null);sSE(false);},SLIDE_MS);},[]);

  return h('div',null,
    h('div',{class:'ve-toast'+(toast?' show':'')},toast&&h('span',{class:'ve-toast-ring',key:toastTick}),toast),
    h('div',{ref:fabRef,class:'ve-fab-wrap' + (open || settingsOpen || helpOpen || cssStudioOpen || contentStudioOpen || mediaStudioOpen || pluginStudioOpen || cssRecipesOpen ? ' ve-fab-hidden' : '')},
      h('div',{class:'ve-fab-menu'},
        h('div',{class:'ve-fab-item',onClick:()=>sSettingsOpen(prev=>!prev)},ph('gear'),h('div',{class:'ve-fab-tooltip'},"Settings")),
        h('div',{class:'ve-fab-item',onClick:()=>sHelpOpen(prev=>!prev)},ph('question'),h('div',{class:'ve-fab-tooltip'},"Help")),
        !deactivatedTools.includes('css_studio') && h('div',{class:'ve-fab-item',onClick:()=>sCssStudioOpen(prev=>!prev)},ph('code'),h('div',{class:'ve-fab-tooltip'},"CSS Studio")),
        !deactivatedTools.includes('css_studio') && h('div',{class:'ve-fab-item',onClick:()=>sCssRecipesOpen(prev=>!prev)},ph('brackets-curly'),h('div',{class:'ve-fab-tooltip'},"CSS Recipes")),
        !deactivatedTools.includes('content_studio') && h('div',{class:'ve-fab-item',onClick:()=>sContentStudioOpen(prev=>!prev)},ph('file-text'),h('div',{class:'ve-fab-tooltip'},"Content Studio")),
        !deactivatedTools.includes('media_studio') && h('div',{class:'ve-fab-item',onClick:()=>sMediaStudioOpen(prev=>!prev)},ph('image'),h('div',{class:'ve-fab-tooltip'},"Media Studio")),
        !deactivatedTools.includes('plugin_studio') && h('div',{class:'ve-fab-item',onClick:()=>sPluginStudioOpen(prev=>!prev)},ph('plugs'),h('div',{class:'ve-fab-tooltip'},"Plugin Studio")),
        !deactivatedTools.includes('mimams_bar') && h('div',{class:'ve-fab-item',onClick:()=>window.dispatchEvent(new KeyboardEvent('keydown',{key:'q',altKey:true,bubbles:true,cancelable:true}))},ph('terminal'),h('div',{class:'ve-fab-tooltip'},"Mimam's Bar (Alt+Q)"))
      ),
      h('div',{class:'ve-fab',onClick:()=>sO(prev=>!prev),title:"Mimam's Var - WP (Alt+Z)"},ph('stack'))
    ),
    open&&snapSide&&h('div',{class:'ve-snap-zone '+snapSide+' show'}),
    open&&panelMode!=='float'&&h('div',{class:'ve-bd show',onClick:()=>sO(false)}),
    h('div',{ref:panelRef,class:'ve-o '+(panelMode==='float'?'ve-float':'ve-dock-'+panelMode)+(open?' open':'')+(hasAvailableUpdate?' has-update':''),style:panelMode==='float'?{left:(panelPos.left||Math.max(16,window.innerWidth-430))+'px',top:(panelPos.top||16)+'px',right:'auto'}:null},
      cfm&&h('div',{class:'ve-cf'},h('div',{class:'ve-cf-b'},h('p',null,'Delete "',cfm.name,'" and all variants?'),
        h('div',{style:'display:flex;gap:5px;justify-content:center'},h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sCfm(null)},'Cancel'),h('button',{class:'ve-btn ve-btn-d ve-btn-s',onClick:cfmDel},'Delete')))),
      confirmCleanFooter&&h(ConfirmModal,{title:'Clean WordPress DB',body:'Clean duplicate, stale, and orphan generated variables from WordPress? This keeps base variables and rebuilds recoverable generated variants.',confirmText:'Clean',onCancel:()=>sConfirmCleanFooter(false),onConfirm:cleanDbFooter}),
      confirmDeletePalette&&h(ConfirmModal,{title:'Delete theme',body:'Delete \''+confirmDeletePalette.name+'\'? Its alternate color values will be removed. The underlying variables remain safe.',confirmText:'Delete Theme',danger:true,onCancel:()=>sConfirmDeletePalette(null),onConfirm:deletePalette}),
      confirmDuplicate&&h(ConfirmModal,{title:'Duplicate variable',body:'Are you sure you want to duplicate variable \''+confirmDuplicate.name+'\'?',confirmText:'Duplicate',onCancel:()=>sConfirmDuplicate(null),onConfirm:cfmDup}),
      paletteTransfer&&h('div',{class:'ve-modal'},h('div',{class:'ve-modal-box'},
        h('div',{class:'ve-modal-title'},paletteTransfer.mode==='copy'?'Copy color to palette':'Move color to palette'),
        h('div',{class:'ve-modal-body'},
          h('div',{style:'margin-bottom:8px'},paletteTransfer.mode==='copy'?'Create an independent copy of “'+paletteTransfer.variable.name+'”.':'Move “'+paletteTransfer.variable.name+'” without changing its token, value, aliases, or website output.'),
          h('div',{style:'font-size:9px;color:#888;margin-bottom:5px'},'Destination palette'),
          h(SelectMenu,{
            value:paletteTransfer.paletteId,
            onChange:value=>sPaletteTransfer(prev=>({...prev,paletteId:value})),
            options:[{value:'',label:'Choose palette'},...(colorPalettesData.palettes||[]).filter(p=>paletteTransfer.mode==='copy'||String(p.id)!==String(paletteTransfer.variable.palette_id||0)).map(p=>({value:String(p.id),label:p.name}))]
          }),
          paletteTransfer.mode==='copy'&&h('div',{style:'margin-top:10px'},
            h('div',{style:'font-size:9px;color:#888;margin-bottom:5px'},'New variable name'),
            h('input',{class:'ve-studio-input',value:paletteTransfer.name,onInput:e=>sPaletteTransfer(prev=>({...prev,name:normalizeNameInput(e.target.value)})),style:'width:100%'}),
            paletteTransfer.variable.type==='base'&&h(CheckControl,{checked:paletteTransfer.includeGenerated,onChange:value=>sPaletteTransfer(prev=>({...prev,includeGenerated:value})),label:'Copy generated children'}))),
        h('div',{class:'ve-modal-actions'},
          h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sPaletteTransfer(null)},'Cancel'),
          h('button',{class:'ve-btn ve-btn-s',disabled:!paletteTransfer.paletteId||(paletteTransfer.mode==='copy'&&!paletteTransfer.name),onClick:runPaletteTransfer},paletteTransfer.mode==='copy'?'Copy Color':'Move Color')))),

      h('div',{class:'ve-hdr'},h('span',{class:'ve-drag-handle',title:'Drag panel',onMouseDown:startPanelDrag},ph('dots-six-vertical')),
        h('div',{class:'ve-brand'},h('span',{class:'ve-hdr-t'},"Mimam's Var - WP"),CFG.logoUrl?h('img',{class:'ve-hdr-i',src:CFG.logoUrl,alt:''}):h('div',{class:'ve-hdr-i'})),
        h('div',{class:'ve-hdr-a'},

          h('button',{onClick:()=>{if(sub==='sync')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('sync'),sub?SLIDE_MS+10:0);}},title:'Sync'},ph('cloud-arrow-up')),
          h('button',{onClick:()=>{if(sub==='migration')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('migration'),sub?SLIDE_MS+10:0);}},title:'Migrate variables'},ph('database')),
          h('button',{onClick:()=>{if(sub==='create')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('create'),sub?SLIDE_MS+10:0);}},title:sub==='create'?'Close new variable':'New variable'},ph(sub==='create'?'x':'plus')),
          h('button',{onClick:load,title:'Refresh'},ph('arrows-clockwise')),
          h('button',{onClick:()=>sO(false),title:'Close'},ph('x')))),

      h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
      sub==='sync'&&h(SyncPanel,{onClose:closeSub,exiting:subExit,onReload:load,onDone:()=>{sSub(null);load();flash('Sync complete');}}),
      sub==='migration'&&h(MigrationSub,{onClose:closeSub,exiting:subExit,onDone:()=>{sSub(null);load();flash('Migration complete');}}),
      sub==='create'&&h(CreateSub,{onCreated:hCreated,onClose:closeSub,categories:allCats,vars,exiting:subExit,palettes:colorPalettesData.palettes,paletteId:selectedColorPalette}),
      sub?.type==='edit'&&h(EditSub,{variable:sub.v,categories:allCats,vars,onDone:r=>{sSub(null);load();const warnings=r?.rename_impact?.warnings||[];flash(warnings.length?'Updated with '+warnings.length+' propagation warning'+(warnings.length===1?'':'s'):'Updated');},onClose:closeSub,exiting:subExit}),
      sub?.type==='genColor'&&h(GenColorSub,{variable:sub.v,childMap,onDone:()=>{sSub(null);load();flash('Generated');},onClose:closeSub,exiting:subExit}),
      sub?.type==='genScale'&&h(GenScaleSub,{variable:sub.v,onDone:()=>{sSub(null);load();flash('Generated');},onClose:closeSub,exiting:subExit}),

      !sub&&h('div',{style:'display:flex;flex-direction:column;flex:1;min-height:0'},
        h('div',{class:'ve-sr'},h('input',{ref:sRef,placeholder:'Search... (Alt+Z)',value:sr,onInput:e=>sSr(e.target.value)})),
        h('div',{class:'ve-tabs'},namespaces.map(ns=>h('div',{class:'ve-t'+(nsTab===ns?' on':''),onClick:()=>sNT(ns)},ns))),
        nsTab==='color'&&h('div',{class:'ve-color-control'},
          h('div',{class:'ve-color-kind-switch'},
            h('button',{class:colorControlMode==='theme'?'on':'',onClick:()=>chooseColorControlMode('theme')},'Theme'),
            h('button',{class:colorControlMode==='palette'?'on':'',onClick:()=>chooseColorControlMode('palette')},'Palette')
          ),
          colorControlMode==='theme'&&h('div',{class:'ve-color-control-row'},
            
            h(SelectMenu,{
              value:palettesData?.active,
              onChange:activatePalette,
              options:(palettesData?.palettes||[]).map(p=>({value:p.slug,label:p.name}))
            }),
            h('button',{
              class:'ve-a' + (paletteManagerOpen ? ' on' : ''),
              title: paletteManagerOpen ? 'Close Theme Manager' : 'Manage Themes',
              onClick:()=>togglePaletteManager(!paletteManagerOpen)
            }, ph(paletteManagerOpen ? 'caret-up' : 'sliders-horizontal'))
          ),
          colorControlMode==='theme'&&paletteManagerOpen && h('div',{style:'padding:0 14px 12px;border-top:1px solid #2a2a2a;display:flex;flex-direction:column;gap:8px;background:rgba(0,0,0,.12)'},
            h('div',{class:'ve-palette-current',style:'margin-top:10px;margin-bottom:6px;padding:4px 0;display:flex;align-items:center;gap:10px'},
              h('i',{class:'ph-duotone ph-palette',style:'font-size:18px;color:#baf400;line-height:1'}),
              h('div',null,
                h('div',{style:'font-size:8px;color:#666;text-transform:uppercase;letter-spacing:.5px;font-weight:600'},'Active Theme'),
                h('div',{style:'font-size:13px;color:#e8e8e8;font-weight:700;margin-top:1px'},(palettesData.palettes.find(p=>p.slug===palettesData.active)?.name)||'Default')
              )
            ),
            h('div',{style:'font-size:9.5px;color:#888;line-height:1.4;margin-bottom:2px'},'Themes change color values without changing token names. Create one from the currently active colors, switch it on, then edit Color variables normally to customize that theme. Generated color children follow their base color.'),
            h('div',{style:'display:flex;gap:5px'},
              h('input',{
                class:'ve-studio-input',
                type:'text',
                value:paletteName,
                onInput:e=>sPaletteName(e.target.value),
                placeholder:'New theme name',
                onKeyDown:e=>e.key==='Enter'&&createPalette(),
                style:'flex:1;font-size:11px;'
              }),
              h('button',{class:'ve-btn',onClick:createPalette,disabled:paletteLd||!paletteName.trim()},'Create')
            ),
            paletteErr&&h('div',{style:'font-size:10px;color:#ef4444'},paletteErr),
            h('div',{style:'max-height:160px;overflow-y:auto;margin-top:4px'},
              palettesData.palettes.map(p=>{
                const info=editingPalette===p.slug
                  ? h('div',{style:'display:flex;gap:4px'},
                      h('input',{
                        class:'ve-studio-input',
                        type:'text',
                        value:editPaletteName,
                        onInput:e=>sEditPaletteName(e.target.value),
                        onKeyDown:e=>{if(e.key==='Enter')renamePalette();if(e.key==='Escape')sEditingPalette(null);},
                        style:'flex:1;min-width:0;font-size:11px;'
                      }),
                      h('button',{class:'ve-btn',onClick:renamePalette,disabled:paletteLd},'Save')
                    )
                  : h('div',{class:'ve-palette-row-name',style:'font-size:11px;color:#ddd;font-weight:600'},p.name);
                return h('div',{class:'ve-palette-row',key:p.slug,style:'display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #222'},
                  h('button',{
                    class:'ve-a',
                    style:'opacity:'+(p.active?'1':'.4')+';padding:2px',
                    title:p.active?'Active theme':'Activate '+p.name,
                    onClick:()=>!p.active&&activatePalette(p.slug),
                    disabled:paletteLd
                  }, ph(p.active?'check-circle':'circle')),
                  h('div',{class:'ve-palette-row-info',style:'flex:1;min-width:0'},
                    info,
                    h('div',{class:'ve-palette-row-meta',style:'font-size:9px;color:#666;margin-top:2px'},
                      p.active?'Active · ':'',
                      p.slug==='default'?'Uses base variable values':(p.value_count||0)+' color values'
                    )
                  ),
                  h('div',{class:'ve-palette-actions',style:'display:flex;gap:4px;align-items:center'},
                    h('button',{class:'ve-a',style:'padding:2px',title:'Duplicate theme',onClick:()=>duplicatePalette(p),disabled:paletteLd}, ph('copy')),
                    !p.protected&&h('button',{class:'ve-a',style:'padding:2px',title:'Rename theme',onClick:()=>{sEditingPalette(p.slug);sEditPaletteName(p.name);},disabled:paletteLd}, ph('pencil-simple')),
                    !p.protected&&h('button',{class:'ve-a',style:'padding:2px',title:'Delete theme',onClick:()=>sConfirmDeletePalette(p),disabled:paletteLd}, ph('trash'))
                  )
                );
              })
            )
          ),
          colorControlMode==='palette'&&h('div',{class:'ve-color-control-row'},
            
            h(SelectMenu,{
              value:selectedColorPalette,
              onChange:sSelectedColorPalette,
              options:[{value:'all',label:'All Colors'},...(colorPalettesData.palettes||[]).map(p=>({value:String(p.id),label:p.name+' ('+p.color_count+')'}))]
            }),
            h('button',{class:'ve-a'+(colorPaletteManagerOpen?' on':''),title:colorPaletteManagerOpen?'Close Color Palette Manager':'Manage Color Palettes',onClick:()=>toggleColorPaletteManager(!colorPaletteManagerOpen)},ph(colorPaletteManagerOpen?'caret-up':'sliders-horizontal'))),
          colorControlMode==='palette'&&colorPaletteManagerOpen&&h(ColorPalettePanel,{inline:true,onChanged:load,selectedPaletteId:selectedColorPalette})
        ),
        cleanupIssues.length>0&&h('div',{class:'ve-clean'},
          h('span',null,'WP cleanup available: '+cleanupIssues.join(', ')),
          h('button',{class:'ve-btn ve-btn-g',onClick:()=>sConfirmCleanFooter(true)},'Clean')),
        manualIntegrityNotices.length>0&&h('div',{class:'ve-warn',style:'margin:0 10px 8px;font-size:9px;line-height:1.5'},manualIntegrityNotices.join('. ')+'. Cleanup will not guess the intended source or public token.'),
        h('div',{style:'display:flex;justify-content:space-between;align-items:center;padding:6px 14px;border-bottom:1px solid #2a2a2a;background:#1a1a1a;flex-shrink:0'},
          h('label',{style:'display:flex;align-items:center;gap:6px;font-size:10px;color:#888;cursor:pointer;'},
            h('input',{type:'checkbox',checked:filtered.length>0&&filtered.every(v=>checkedVars.includes(v.id)),onChange:toggleAllVarsChecked,style:'accent-color:#baf400;width:12px;height:12px;cursor:pointer;'}),
            'Select All'
          ),
          h('span',{style:'font-size:10px;color:#666;'},filtered.length+' variables')
        ),
        h('div',{class:'ve-body'},
          filtered.length===0?h('div',{class:'ve-empty'},sr?'No matches':'No variables'):
          filtered.map(v=>{
            const kids=childMap[v.id]||[];const expKey=String(v.id);const hasExp=Object.prototype.hasOwnProperty.call(exp,expKey);const iE=sr?true:(hasExp?!!exp[expKey]:false);
            const resolvedVal=resolvedVariableValue(v, vars);
            const displayNs=variableNamespace(v);const isSp=displayNs==='space';const spW=isSp?Math.max(4,pxV(resolvedVal)/maxSp*100):0;
            const bc=stripeColor(v);
            const row=h('div',{
              class:'ve-v'+(sel?.id===v.id?' sel':'')+(draggingVarId===v.id?' dragging':'')+(dragOverVarId===v.id?' drag-over':''),
              style:`--ve-ns:${bc};padding-left:4px`,
              title:v.namespace,
              'data-ve-variable-row':String(v.id),
              draggable:true,
              onDragStart:e=>handleVarDragStart(e,v),
              onDragOver:e=>handleVarDragOver(e,v),
              onDragLeave:()=>sDragOverVarId(null),
              onDragEnd:handleVarDragEnd,
              onDrop:e=>handleVarDrop(e,v),
              onMouseEnter:()=>openRowActions(v.id),
              onMouseLeave:()=>scheduleRowActionsClose(v.id),
              onFocus:()=>openRowActions(v.id),
              onBlur:()=>scheduleRowActionsClose(v.id),
              onClick:()=>hSel(v)
            },
              h('span',{class:'ve-var-drag-handle',style:'cursor:grab;margin-right:2px;display:flex;align-items:center;opacity:0.3;'},ph('dots-six-vertical')),
              h('input',{type:'checkbox',checked:checkedVars.includes(v.id),onChange:e=>{e.stopPropagation();toggleVarChecked(v.id);},onClick:e=>e.stopPropagation(),style:'margin-right:6px;accent-color:#baf400;width:12px;height:12px;cursor:pointer;flex-shrink:0;'}),
              kids.length>0?h('button',{class:'ve-exp',onClick:e=>{e.stopPropagation();tgExp(v.id,false);}},ph(iE?'minus':'plus')):h('div',{style:'width:18px'}),
              h('div',{class:'ve-sw-trigger'},h(Sw,{v:resolvedVal})),
              h('div',{class:'ve-inf'},h('div',{class:'ve-nm'},sn(v.name)),h('div',{class:'ve-vl'},v.type==='alias'?(v.css_value||''):v.value,isSp&&h('div',{class:'ve-sb',style:`width:${spW}%`}))),
              h('div',{class:'ve-as'+(rowActions===String(v.id)?' open':'')},
                h('button',{class:'ve-a',title:'Edit',onClick:e=>{e.stopPropagation();sSub({type:'edit',v});}},ph('pencil-simple')),
                h('button',{class:'ve-a',title:'Generate',onClick:e=>{e.stopPropagation();sSub(isClr(resolvedVal)?{type:'genColor',v}:{type:'genScale',v});}},ph('sun')),
                h('button',{class:'ve-a',title:'Duplicate',onClick:e=>{e.stopPropagation();hDup(v);}},ph('copy')),
                v.palette_eligible&&h('button',{class:'ve-a',title:'Copy to palette',onClick:e=>{e.stopPropagation();openPaletteTransfer('copy',v);}},ph('copy-simple')),
                v.palette_eligible&&h('button',{class:'ve-a',title:'Move to palette',onClick:e=>{e.stopPropagation();openPaletteTransfer('move',v);}},ph('arrows-left-right')),
                h('button',{class:'ve-a',title:'Copy var()',onClick:e=>{e.stopPropagation();cpVar(v.name);}},ph('clipboard-text')),
                h('button',{class:'ve-a',title:'Delete',onClick:e=>{e.stopPropagation();hDel(v);}},ph('trash'))));
            const children=kids.length>0&&iE&&h('div',{class:'ve-ch'},kids.map(c=>{
              const resolvedCVal=resolvedVariableValue(c, vars);
              return h('div',{class:'ve-c',key:c.id,onClick:()=>hSel(c)},
                h(Sw,{v:resolvedCVal}),
                h('div',{class:'ve-inf'},h('div',{class:'ve-nm'},sn(c.name)),h('div',{class:'ve-vl'},c.type==='alias'?c.css_value:c.value)),
                h('button',{class:'ve-a',style:'opacity:.6',title:'Copy var()',onClick:e=>{e.stopPropagation();cpVar(c.name);}},ph('clipboard-text')));
            }));
            return h('div',{class:'ve-tree-item',key:v.id},row,children);
          })),
        sel&&h(Detail,{variable:sel,vars,onNav:d=>{const f=vars.find(v=>v.id===d.id||v.name===d.name);if(f)sSel(f);},onClose:()=>sSel(null),onUpdate:()=>{load();flash('Updated');},onEditFull:v=>sSub({type:'edit',v})}),
      ),
      h('div',{class:'ve-st'},
        h('div',{class:'ve-st-left'},
          h('span',null,(stats?(stats.base||0)+' base · '+(stats.generated||0)+' generated':vars.length+' variables')),
          cleanupIssues.length>0&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',title:'Clean WordPress variable database',onClick:()=>sConfirmCleanFooter(true)},'Clean WP DB')
        ),
        h('span',null,'v'+(CFG.version||'1.1.16')))),
        
      (settingsOpen || settingsHasOpened) && h(StandalonePanel, {
        title: 'Settings',
        panelId: 'settings',
        open: settingsOpen,
        panelMode,
        width: 380,
        persistKey: 've_settings_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => sSettingsOpen(false),
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(UnifiedSettingsPanel, {
        onClose: () => sSettingsOpen(false),
        panelMode,
        setPanelMode
      })),

      (helpOpen || helpHasOpened) && h(StandalonePanel, {
        title: 'Quick Help',
        panelId: 'help',
        open: helpOpen,
        panelMode,
        width: 380,
        persistKey: 've_help_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => sHelpOpen(false),
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(HelpPanel, {
        onClose: () => sHelpOpen(false)
      })),

      (cssStudioOpen || cssStudioHasOpened) && h(StandalonePanel, {
        title: 'CSS Studio',
        panelId: 'css_studio',
        open: cssStudioOpen,
        panelMode,
        width: 430,
        persistKey: 've_css_studio_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => sCssStudioOpen(false),
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(AdvancedCssSub, {
        onClose: () => sCssStudioOpen(false),
        exiting: false,
        vars
      })),

      (cssRecipesOpen || cssRecipesHasOpened) && h(StandalonePanel, {
        title: 'CSS Recipes',
        panelId: 'css_recipes',
        open: cssRecipesOpen,
        panelMode,
        width: 420,
        persistKey: 've_css_recipes_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => sCssRecipesOpen(false),
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(CssRecipesStudioSub, {
        flash,
        vars
      })),

      (contentStudioOpen || contentStudioHasOpened) && h(StandalonePanel, {
        title: 'Content Studio',
        panelId: 'content_studio',
        open: contentStudioOpen,
        panelMode,
        width: 380,
        persistKey: 've_content_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => sContentStudioOpen(false),
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(ContentStudioSub, {
        onClose: () => sContentStudioOpen(false),
        flash
      })),

      (mediaStudioOpen || mediaStudioHasOpened) && h(StandalonePanel, {
        title: 'Media Studio',
        panelId: 'media_studio',
        open: mediaStudioOpen,
        panelMode,
        width: 420,
        persistKey: 've_media_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => { pendingMediaFrameRef.current = null; mediaTargetRef.current = null; sMediaStudioOpen(false); },
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(MediaStudioSub, {
        onClose: () => { pendingMediaFrameRef.current = null; mediaTargetRef.current = null; sMediaStudioOpen(false); },
        flash,
        picking: !!mediaTargetRef.current,
        onInsertMedia: insertMediaIntoRememberedControl
      })),

      (pluginStudioOpen || pluginStudioHasOpened) && h(StandalonePanel, {
        title: 'Plugin Studio',
        panelId: 'plugin_studio',
        open: pluginStudioOpen,
        panelMode,
        width: 420,
        persistKey: 've_plugin_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => sPluginStudioOpen(false),
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(PluginStudioSub, {
        flash
      }))
  );
}

function mt(){const s=document.createElement('style');s.textContent=CSS;document.head.appendChild(s);
const r=document.createElement('div');r.id='ve-panel-root';document.body.appendChild(r);render(h(Panel),r);wireGsapHover(r);if(MODE==='builder')setTimeout(syncBricksVariableConsumers,0);}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mt);else mt();
})();
