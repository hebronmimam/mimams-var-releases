<?php

namespace VE\API;

defined( 'ABSPATH' ) || exit;

class Routes {

    public function register(): void {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes(): void {
        $ns         = VE_API_NAMESPACE;
        $controller = new VariableController();

        // ── Variables CRUD ──────────────────────────────────────────
        register_rest_route( $ns, '/variables', [
            [
                'methods'             => 'GET',
                'callback'            => [ $controller, 'list_variables' ],
                'permission_callback' => [ $this, 'can_read' ],
                'args'                => [
                    'namespace' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ],
                    'type'      => [ 'type' => 'string', 'enum' => [ 'base', 'generated', 'alias' ] ],
                    'dedupe'    => [ 'type' => 'boolean', 'default' => false ],
                ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $controller, 'create_variable' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );


        register_rest_route( $ns, '/variables/stats', [
            'methods'             => 'GET',
            'callback'            => [ $controller, 'stats_variables' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/variables/cleanup', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'cleanup_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/reorder', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'reorder_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/batch-delete', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'batch_delete_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/(?P<id>\d+)', [
            [
                'methods'             => 'GET',
                'callback'            => [ $controller, 'get_variable' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'PUT',
                'callback'            => [ $controller, 'update_variable' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $controller, 'delete_variable' ],
                'permission_callback' => [ $this, 'can_write' ],
                'args'                => [
                    'force' => [ 'type' => 'boolean', 'default' => false ],
                ],
            ],
        ] );

        register_rest_route( $ns, '/variables/(?P<id>\d+)/rename-preview', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'rename_preview' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Themes (legacy /palettes routes remain compatible) ──────
        $palettes = new PaletteController();
        register_rest_route( $ns, '/palettes', [
            [
                'methods'             => 'GET',
                'callback'            => [ $palettes, 'list_palettes' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $palettes, 'create_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/palettes/(?P<slug>[a-z0-9-]+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $palettes, 'update_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $palettes, 'delete_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/palettes/(?P<slug>[a-z0-9-]+)/activate', [
            'methods'             => 'POST',
            'callback'            => [ $palettes, 'activate_palette' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/palettes/(?P<slug>[a-z0-9-]+)/duplicate', [
            'methods'             => 'POST',
            'callback'            => [ $palettes, 'duplicate_palette' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        $themes = new ThemeController();
        register_rest_route( $ns, '/themes', [
            [
                'methods'             => 'GET',
                'callback'            => [ $themes, 'list_themes' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $themes, 'create_theme' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/themes/(?P<slug>[a-z0-9-]+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $themes, 'update_theme' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $themes, 'delete_theme' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/themes/(?P<slug>[a-z0-9-]+)/activate', [
            'methods'             => 'POST',
            'callback'            => [ $themes, 'activate_theme' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/themes/(?P<slug>[a-z0-9-]+)/duplicate', [
            'methods'             => 'POST',
            'callback'            => [ $themes, 'duplicate_theme' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Organizational color palettes ────────────────────────────
        $color_palettes = new ColorPaletteController();
        register_rest_route( $ns, '/color-palettes', [
            [
                'methods'             => 'GET',
                'callback'            => [ $color_palettes, 'list_palettes' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $color_palettes, 'create_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/color-palettes/(?P<id>\d+)', [
            [
                'methods'             => 'PUT',
                'callback'            => [ $color_palettes, 'update_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $color_palettes, 'delete_palette' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
        register_rest_route( $ns, '/color-palettes/(?P<id>\d+)/duplicate', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'duplicate_palette' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/color-palettes/(?P<id>\d+)/delete-preview', [
            'methods'             => 'GET',
            'callback'            => [ $color_palettes, 'preview_delete' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/color-palettes/reorder', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'reorder_palettes' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/color-palettes/variables/batch-move', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'batch_move_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/color-palettes/variables/(?P<variable_id>\d+)/move', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'move_variable' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
        register_rest_route( $ns, '/color-palettes/variables/(?P<variable_id>\d+)/copy', [
            'methods'             => 'POST',
            'callback'            => [ $color_palettes, 'copy_variable' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Generators ────────────────────────────────────────────────
        $gen_controller = new GeneratorController();

        register_rest_route( $ns, '/variables/(?P<variable_id>\d+)/generators', [
            [
                'methods'             => 'GET',
                'callback'            => [ $gen_controller, 'list_generators' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $gen_controller, 'attach' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/variables/(?P<variable_id>\d+)/generators/regenerate', [
            'methods'             => 'POST',
            'callback'            => [ $gen_controller, 'regenerate' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/generators/(?P<generator_id>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $gen_controller, 'detach' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Search ──────────────────────────────────────────────────
        register_rest_route( $ns, '/search', [
            'methods'             => 'GET',
            'callback'            => [ $controller, 'search_variables' ],
            'permission_callback' => [ $this, 'can_read' ],
            'args'                => [
                'q'     => [ 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
                'limit' => [ 'type' => 'integer', 'default' => 50 ],
            ],
        ] );

        // ── Settings ────────────────────────────────────────────────
        register_rest_route( $ns, '/settings', [
            [
                'methods'             => 'GET',
                'callback'            => function () {
                    $defaults = [
                        'vw_min'              => 320,
                        'vw_max'              => 1440,
                        'delete_on_uninstall' => false,
                        'update_url'          => \VE\Core\Updater::DEFAULT_FEED_URL,
                        'update_channel'      => 'stable',
                        'auto_update'         => false,
                        'license_server_url'  => '',
                        'deactivated_tools'   => [],
                        'allow_multi_panels'  => false,
                        'show_all_tab'        => true,
                    ];
                    $settings = get_option( 've_settings', $defaults );
                    $out = wp_parse_args( $settings, $defaults );
                    $out['site_title'] = get_bloginfo( 'name' );
                    $out['license'] = ( new \VE\Core\LicenseManager() )->status();
                    return new \WP_REST_Response( $out, 200 );
                },
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => function ( \WP_REST_Request $request ) {
                    $data = $request->get_json_params();
                    $defaults = [
                        'vw_min'              => 320,
                        'vw_max'              => 1440,
                        'delete_on_uninstall' => false,
                        'update_url'          => \VE\Core\Updater::DEFAULT_FEED_URL,
                        'update_channel'      => 'stable',
                        'auto_update'         => false,
                        'license_server_url'  => '',
                        'deactivated_tools'   => [],
                        'allow_multi_panels'  => false,
                        'show_all_tab'        => true,
                    ];
                    $previous = get_option( 've_settings', $defaults );
                    $update_channel = sanitize_key( (string) ( $data['update_channel'] ?? ( $previous['update_channel'] ?? 'stable' ) ) );
                    if ( ! in_array( $update_channel, [ 'stable', 'beta', 'dev' ], true ) ) {
                        $update_channel = 'stable';
                    }
                    $update_url = isset( $data['update_url'] ) ? esc_url_raw( (string) $data['update_url'] ) : $defaults['update_url'];
                    if ( '' === $update_url || \VE\Core\Updater::LEGACY_FEED_URL === $update_url || \VE\Core\Updater::DEFAULT_FEED_URL === $update_url ) {
                        $update_url = \VE\Core\Updater::feed_url_for_channel( $update_channel );
                    }
                    $license_server_url = isset( $data['license_server_url'] ) ? esc_url_raw( (string) $data['license_server_url'] ) : '';
                    $deactivated_tools = isset( $data['deactivated_tools'] ) && is_array( $data['deactivated_tools'] )
                        ? array_map( 'sanitize_key', $data['deactivated_tools'] )
                        : [];
                    $settings = [
                        'vw_min'              => isset( $data['vw_min'] ) ? absint( $data['vw_min'] ) : 320,
                        'vw_max'              => isset( $data['vw_max'] ) ? absint( $data['vw_max'] ) : 1440,
                        'delete_on_uninstall' => ! empty( $data['delete_on_uninstall'] ),
                        'update_url'          => $update_url,
                        'update_channel'      => $update_channel,
                        'auto_update'         => ! empty( $data['auto_update'] ),
                        'license_server_url'  => $license_server_url,
                        'deactivated_tools'   => $deactivated_tools,
                        'allow_multi_panels'  => ! empty( $data['allow_multi_panels'] ),
                        'show_all_tab'        => isset( $data['show_all_tab'] ) ? ! empty( $data['show_all_tab'] ) : true,
                    ];
                    update_option( 've_settings', $settings );
                    update_option( 've_delete_on_uninstall', $settings['delete_on_uninstall'] );

                    // If the fluid viewport range changed, every fluid variable's
                    // clamp() output is now stale — recompile them.
                    $vw_changed = ( (int) ( $previous['vw_min'] ?? 320 ) !== $settings['vw_min'] )
                               || ( (int) ( $previous['vw_max'] ?? 1440 ) !== $settings['vw_max'] );
                    $recompiled = 0;
                    if ( $vw_changed ) {
                        $recompiled = ( new \VE\Core\VariableManager() )->recompile_fluid();
                        if ( is_wp_error( $recompiled ) ) {
                            update_option( 've_settings', $previous );
                            update_option( 've_delete_on_uninstall', ! empty( $previous['delete_on_uninstall'] ) );
                            return $recompiled;
                        }
                    }

                    $response = $settings;
                    $response['fluid_recompiled'] = $recompiled;
                    $response['license'] = ( new \VE\Core\LicenseManager() )->status();
                    return new \WP_REST_Response( $response, 200 );
                },
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/user-preferences', [
            [
                'methods'             => 'GET',
                'callback'            => function () {
                    $preferences = get_user_meta( get_current_user_id(), 've_user_preferences', true );
                    return new \WP_REST_Response( [
                        'preferences' => is_array( $preferences ) ? $preferences : [],
                    ], 200 );
                },
                'permission_callback' => [ $this, 'can_save_user_preferences' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => function ( \WP_REST_Request $request ) {
                    $data = $request->get_json_params();
                    $preferences = isset( $data['preferences'] ) && is_array( $data['preferences'] )
                        ? $this->sanitize_user_preferences( $data['preferences'] )
                        : [];
                    update_user_meta( get_current_user_id(), 've_user_preferences', $preferences );
                    return new \WP_REST_Response( [
                        'preferences' => $preferences,
                        'saved'       => true,
                    ], 200 );
                },
                'permission_callback' => [ $this, 'can_save_user_preferences' ],
            ],
        ] );

        register_rest_route( $ns, '/license/status', [
            'methods'             => 'GET',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->status(), 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/license/activate', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                $data = $request->get_json_params();
                $key  = isset( $data['license_key'] ) ? (string) $data['license_key'] : '';
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->activate( $key ), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/license/check', [
            'methods'             => 'POST',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->check(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/license/deactivate', [
            'methods'             => 'POST',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->deactivate(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/update/check', [
            'methods'             => 'POST',
            'callback'            => function () {
                $updater = new \VE\Core\Updater();
                return new \WP_REST_Response( $updater->check_now(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/advanced-css', [
            [
                'methods'             => 'GET',
                'callback'            => function () {
                    return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->get(), 200 );
                },
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => function ( \WP_REST_Request $request ) {
                    $data = $request->get_json_params();
                    $sheets = is_array( $data ) && isset( $data['stylesheets'] ) && is_array( $data['stylesheets'] )
                        ? $data['stylesheets']
                        : [];
                    return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->save( $sheets ), 200 );
                },
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/advanced-css/compile', [
            'methods'             => 'POST',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->compile(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/advanced-css/suggestions', [
            'methods'             => 'GET',
            'callback'            => function ( \WP_REST_Request $request ) {
                $refresh = rest_sanitize_boolean( $request->get_param( 'refresh' ) );
                return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->suggestions( $refresh ), 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/migration/sources', [
            'methods'             => 'GET',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\MigrationScanner() )->sources(), 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/migration/preview', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                $data = $request->get_json_params();
                $source = sanitize_key( (string) ( $data['source'] ?? 'all' ) );
                $scanner = new \VE\Core\MigrationScanner();
                $vars = $scanner->scan( $source ?: 'all' );
                $sync = new \VE\Sync\SyncEngine();
                $preview = $sync->preview_import( $vars );
                $preview['variables'] = $vars;
                $preview['variable_count'] = count( $vars );
                return new \WP_REST_Response( $preview, 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Sync ──────────────────────────────────────────────────────
        $sync = new SyncController();

        register_rest_route( $ns, '/sync/export', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'export' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
            'args'                => [
                'format' => [ 'type' => 'string', 'default' => 'dtcg', 'enum' => [ 'dtcg', 'flat', 'figma' ] ],
            ],
        ] );

        register_rest_route( $ns, '/sync/export-css', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'export_css' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/preview', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'preview' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/apply', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'apply' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/snapshots', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'list_snapshots' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/sync/snapshot', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'create_snapshot' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/rollback/(?P<snapshot_id>\d+)', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'rollback' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/logs', [
            [
                'methods'             => 'GET',
                'callback'            => [ $sync, 'list_logs' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $sync, 'write_log' ],
                'permission_callback' => [ SyncController::class, 'can_sync' ],
            ],
        ] );

        register_rest_route( $ns, '/diagnostics/logs', [
            [
                'methods'             => 'GET',
                'callback'            => [ $sync, 'diagnostics' ],
                'permission_callback' => [ $this, 'can_read' ],
                'args'                => [
                    'lines' => [ 'type' => 'integer', 'default' => 200 ],
                ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $sync, 'clear_diagnostics' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        // ── Pairing ─────────────────────────────────────────────────
        register_rest_route( $ns, '/sync/pair/generate', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'generate_pair' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/pair/validate', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'validate_pair' ],
            'permission_callback' => '__return_true', // Open — code is the auth
        ] );

        register_rest_route( $ns, '/sync/pair/register', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'register_figma_pair' ],
            'permission_callback' => '__return_true', // Open — Figma sends its code
        ] );

        register_rest_route( $ns, '/sync/pair/complete-figma', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'complete_figma_pair' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/pair/status', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'pair_status' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/pair/disconnect', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'disconnect' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Content Studio ─────────────────────────────────────────
        register_rest_route( $ns, '/content-studio/meta', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_content_studio_meta' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/content-studio/posts', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'list_studio_posts' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'create_studio_post' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/content-studio/posts/(?P<id>\d+)', [
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'update_studio_post' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'delete_studio_post' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/content-studio/cpts', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_or_update_studio_cpt' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/cpts/(?P<name>[a-zA-Z0-9_\-]+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_studio_cpt' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/fields', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_or_update_studio_fields' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/fields/(?P<id>[a-zA-Z0-9_\-]+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_studio_fields' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/migrate/jet-to-acf/preview', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'preview_jet_to_acf_migration' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/content-studio/migrate/jet-to-acf', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'run_jet_to_acf_migration' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/folders', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_media_folders' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/media-studio/folders/assign', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'assign_media_folder' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/replace', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'replace_media_file' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/convert', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'convert_media_file' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/media-studio/rename', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'rename_media_file' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/plugin-studio/plugins', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'list_studio_plugins' ],
            'permission_callback' => [ $this, 'can_manage_plugins' ],
        ] );

        register_rest_route( $ns, '/plugin-studio/action', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'run_studio_plugin_action' ],
            'permission_callback' => [ $this, 'can_manage_plugins' ],
        ] );

        register_rest_route( $ns, '/plugin-studio/directory', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'search_plugin_directory' ],
            'permission_callback' => [ $this, 'can_manage_plugins' ],
            'args'                => [
                'search' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ],
            ],
        ] );

        register_rest_route( $ns, '/plugin-studio/install', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'install_directory_plugin' ],
            'permission_callback' => [ $this, 'can_manage_plugins' ],
        ] );

        register_rest_route( $ns, '/plugin-studio/upload', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'upload_plugin_zip' ],
            'permission_callback' => [ $this, 'can_manage_plugins' ],
        ] );
    }

    /* ── Permission callbacks ─────────────────────────────────────── */

    public function can_read( ?\WP_REST_Request $request = null ): bool {
        // Allow the paired Figma plugin to read VE data with X-VE-Key.
        if ( $request && SyncController::can_sync( $request ) ) {
            return true;
        }

        return current_user_can( 'edit_posts' );
    }

    public function can_write( ?\WP_REST_Request $request = null ): bool {
        // Allow the paired Figma plugin to create/update/delete VE data with X-VE-Key.
        if ( $request && SyncController::can_sync( $request ) ) {
            return true;
        }

        return current_user_can( 'manage_options' );
    }

    public function can_manage_plugins( ?\WP_REST_Request $request = null ): bool {
        return current_user_can( 'activate_plugins' ) || current_user_can( 'update_plugins' ) || current_user_can( 'delete_plugins' );
    }

    public function can_save_user_preferences( ?\WP_REST_Request $request = null ): bool {
        return get_current_user_id() > 0 && current_user_can( 'edit_posts' );
    }

    private function sanitize_user_preferences( array $preferences ): array {
        $allowed = [
            'mimamsBarSettings',
            've_skip_update_version',
            've_panel_mode',
            've_panel_pos',
            've_allow_multi_panels',
            've_deactivated_tools',
            've_css_scss',
            've_css_source_order',
            've_css_disabled_sources',
            've_content_visible_groups',
            've_media_layout',
            've_media_filter',
            've_media_sort',
            've_plugin_directory_view',
            've_pos_ve_settings_pos',
            've_pos_ve_help_pos',
            've_pos_ve_css_studio_pos',
            've_pos_ve_css_recipes_pos',
            've_pos_ve_content_pos',
            've_pos_ve_media_pos',
            've_pos_ve_plugin_pos',
        ];
        $clean = [];
        foreach ( $allowed as $key ) {
            if ( ! array_key_exists( $key, $preferences ) ) {
                continue;
            }
            $value = $preferences[ $key ];
            if ( is_array( $value ) ) {
                $clean[ $key ] = $this->sanitize_preference_value( $value, 0 );
            } elseif ( is_bool( $value ) || is_int( $value ) || is_float( $value ) ) {
                $clean[ $key ] = $value;
            } else {
                $clean[ $key ] = substr( sanitize_textarea_field( (string) $value ), 0, 20000 );
            }
        }
        return $clean;
    }

    private function sanitize_preference_value( array $value, int $depth ): array {
        if ( $depth >= 5 ) {
            return [];
        }
        $clean = [];
        $count = 0;
        foreach ( $value as $key => $item ) {
            if ( $count >= 200 ) {
                break;
            }
            $safe_key = is_int( $key ) ? $key : sanitize_key( (string) $key );
            if ( is_array( $item ) ) {
                $clean[ $safe_key ] = $this->sanitize_preference_value( $item, $depth + 1 );
            } elseif ( is_bool( $item ) || is_int( $item ) || is_float( $item ) ) {
                $clean[ $safe_key ] = $item;
            } else {
                $clean[ $safe_key ] = substr( sanitize_text_field( (string) $item ), 0, 2000 );
            }
            $count++;
        }
        return $clean;
    }

    public function get_media_folders(): \WP_REST_Response {
        $folders = [];
        $attachment_map = [];

        $taxonomies = [ 'happyfiles_category', 'media_folder', 'folder', 'attachment_category' ];
        $active_tax = null;

        foreach ( $taxonomies as $tax ) {
            if ( taxonomy_exists( $tax ) ) {
                $active_tax = $tax;
                break;
            }
        }

        if ( $active_tax ) {
            $terms = get_terms( [ 'taxonomy' => $active_tax, 'hide_empty' => false ] );
            if ( ! is_wp_error( $terms ) ) {
                foreach ( $terms as $term ) {
                    $folders[] = [
                        'id'     => (string) $term->term_id,
                        'name'   => $term->name,
                        'slug'   => $term->slug,
                        'parent' => (string) ( $term->parent ?? 0 ),
                    ];

                    $posts = get_posts( [
                        'post_type'      => 'attachment',
                        'posts_per_page' => -1,
                        'post_status'    => 'any',
                        'fields'         => 'ids',
                        'tax_query'      => [
                            [
                                'taxonomy' => $active_tax,
                                'field'    => 'term_id',
                                'terms'    => $term->term_id,
                            ],
                        ],
                    ] );
                    foreach ( $posts as $pid ) {
                        $attachment_map[ $pid ][] = (string) $term->term_id;
                    }
                }
            }
        }

        global $wpdb;
        $fb_table = $wpdb->prefix . 'fb_attachment_folders';
        if ( $wpdb->get_var( "SHOW TABLES LIKE '$fb_table'" ) === $fb_table ) {
            $fb_folders_table = $wpdb->prefix . 'fb_folders';
            $fb_columns = $wpdb->get_col( "DESC $fb_folders_table", 0 );
            $fb_parent_column = in_array( 'parent', $fb_columns, true ) ? 'parent' : ( in_array( 'parent_id', $fb_columns, true ) ? 'parent_id' : '' );
            $fb_parent_select = $fb_parent_column ? ', ' . $fb_parent_column . ' AS parent_id' : ', 0 AS parent_id';
            $fb_folders = $wpdb->get_results( "SELECT id, name $fb_parent_select FROM $fb_folders_table" );
            foreach ( $fb_folders as $f ) {
                $folders[] = [
                    'id'   => 'fb-' . $f->id,
                    'name' => $f->name,
                    'slug' => 'fb-' . $f->id,
                    'parent' => ! empty( $f->parent_id ) ? 'fb-' . $f->parent_id : '0',
                ];
            }
            $fb_relations = $wpdb->get_results( "SELECT attachment_id, folder_id FROM $fb_table" );
            foreach ( $fb_relations as $r ) {
                $attachment_map[ $r->attachment_id ][] = 'fb-' . $r->folder_id;
            }
        }

        return new \WP_REST_Response( [
            'folders' => $folders,
            'map'     => $attachment_map,
        ], 200 );
    }

    public function assign_media_folder( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = (int) ( $params['attachment_id'] ?? 0 );
        $folder_id = $params['folder_id'] ?? '';
        $checked = (bool) ( $params['checked'] ?? false );

        if ( ! $attachment_id ) {
            return new \WP_REST_Response( [ 'success' => false ], 400 );
        }

        $taxonomies = [ 'happyfiles_category', 'media_folder', 'folder', 'attachment_category' ];
        $active_tax = null;
        foreach ( $taxonomies as $tax ) {
            if ( taxonomy_exists( $tax ) ) {
                $active_tax = $tax;
                break;
            }
        }

        if ( $active_tax && is_numeric( $folder_id ) ) {
            $term_id = (int) $folder_id;
            $current_terms = wp_get_object_terms( $attachment_id, $active_tax, [ 'fields' => 'ids' ] );
            if ( is_wp_error( $current_terms ) ) {
                $current_terms = [];
            }
            if ( $checked ) {
                $current_terms[] = $term_id;
            } else {
                $current_terms = array_filter( $current_terms, function( $id ) use ( $term_id ) {
                    return $id !== $term_id;
                } );
            }
            wp_set_object_terms( $attachment_id, array_values( array_unique( $current_terms ) ), $active_tax );
            return new \WP_REST_Response( [ 'success' => true ], 200 );
        }

        global $wpdb;
        $fb_table = $wpdb->prefix . 'fb_attachment_folders';
        if ( strpos( $folder_id, 'fb-' ) === 0 && $wpdb->get_var( "SHOW TABLES LIKE '$fb_table'" ) === $fb_table ) {
            $fb_folder_id = (int) substr( $folder_id, 3 );
            if ( $checked ) {
                $wpdb->delete( $fb_table, [ 'attachment_id' => $attachment_id ] );
                $wpdb->insert( $fb_table, [ 'attachment_id' => $attachment_id, 'folder_id' => $fb_folder_id ] );
            } else {
                $wpdb->delete( $fb_table, [ 'attachment_id' => $attachment_id, 'folder_id' => $fb_folder_id ] );
            }
            return new \WP_REST_Response( [ 'success' => true ], 200 );
        }

        return new \WP_REST_Response( [ 'success' => false ], 400 );
    }

    private function media_item_payload( int $attachment_id ): array {
        $post = get_post( $attachment_id );
        $meta = wp_get_attachment_metadata( $attachment_id );
        if ( ! is_array( $meta ) ) {
            $meta = [];
        }

        return [
            'id'            => $attachment_id,
            'date'          => $post ? $post->post_date_gmt : '',
            'slug'          => $post ? $post->post_name : '',
            'title'         => [ 'rendered' => $post ? get_the_title( $attachment_id ) : '' ],
            'source_url'    => wp_get_attachment_url( $attachment_id ),
            'mime_type'     => get_post_mime_type( $attachment_id ),
            'alt_text'      => get_post_meta( $attachment_id, '_wp_attachment_image_alt', true ),
            'media_details' => $meta,
        ];
    }

    public function replace_media_file( \WP_REST_Request $request ): \WP_REST_Response {
        $attachment_id = absint( $request->get_param( 'attachment_id' ) );
        $files = $request->get_file_params();

        if ( ! $attachment_id || empty( $files['file'] ) || ! get_post( $attachment_id ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Missing attachment or upload file.' ], 400 );
        }

        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/image.php';

        $old_file = get_attached_file( $attachment_id );
        $upload = wp_handle_upload( $files['file'], [ 'test_form' => false ] );
        if ( isset( $upload['error'] ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $upload['error'] ], 400 );
        }

        $new_file = $upload['file'];
        $target_file = $old_file ?: $new_file;

        if ( $old_file && file_exists( $old_file ) ) {
            @copy( $new_file, $old_file );
            @unlink( $new_file );
        } else {
            update_attached_file( $attachment_id, $new_file );
            $target_file = $new_file;
        }

        $filetype = wp_check_filetype( $target_file );
        wp_update_post( [
            'ID'             => $attachment_id,
            'post_mime_type' => $filetype['type'] ?: ( $upload['type'] ?? get_post_mime_type( $attachment_id ) ),
        ] );

        $metadata = wp_generate_attachment_metadata( $attachment_id, $target_file );
        if ( is_array( $metadata ) ) {
            wp_update_attachment_metadata( $attachment_id, $metadata );
        }

        return new \WP_REST_Response( [ 'success' => true, 'item' => $this->media_item_payload( $attachment_id ) ], 200 );
    }

    public function convert_media_file( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $format = sanitize_key( $params['format'] ?? 'webp' );
        $allowed = [ 'webp', 'avif', 'jpeg', 'jpg', 'png' ];

        if ( ! $attachment_id || ! in_array( $format, $allowed, true ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Invalid conversion request.' ], 400 );
        }

        $file = get_attached_file( $attachment_id );
        if ( ! $file || ! file_exists( $file ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Source file not found.' ], 404 );
        }

        require_once ABSPATH . 'wp-admin/includes/image.php';

        $editor = wp_get_image_editor( $file );
        if ( is_wp_error( $editor ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $editor->get_error_message() ], 400 );
        }

        $ext = $format === 'jpg' ? 'jpeg' : $format;
        $mime = 'image/' . $ext;
        $base = preg_replace( '/\.[^.]+$/', '', $file );
        $dest = $base . '.' . ( $ext === 'jpeg' ? 'jpg' : $ext );
        $saved = $editor->save( $dest, $mime );

        if ( is_wp_error( $saved ) || empty( $saved['path'] ) ) {
            $message = is_wp_error( $saved ) ? $saved->get_error_message() : 'The server image editor could not save that format.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        update_attached_file( $attachment_id, $saved['path'] );
        wp_update_post( [
            'ID'             => $attachment_id,
            'post_mime_type' => $saved['mime-type'] ?? $mime,
        ] );

        $metadata = wp_generate_attachment_metadata( $attachment_id, $saved['path'] );
        if ( is_array( $metadata ) ) {
            wp_update_attachment_metadata( $attachment_id, $metadata );
        }

        return new \WP_REST_Response( [ 'success' => true, 'item' => $this->media_item_payload( $attachment_id ) ], 200 );
    }

    public function rename_media_file( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $attachment_id = absint( $params['attachment_id'] ?? 0 );
        $title = sanitize_text_field( $params['title'] ?? '' );
        $rename_file = rest_sanitize_boolean( $params['rename_file'] ?? false );

        if ( ! $attachment_id || ! get_post( $attachment_id ) || get_post_type( $attachment_id ) !== 'attachment' ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Attachment not found.' ], 404 );
        }

        if ( empty( $title ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'A filename/title is required.' ], 400 );
        }

        wp_update_post( [
            'ID'         => $attachment_id,
            'post_title' => $title,
            'post_name'  => sanitize_title( $title ),
        ] );

        if ( $rename_file ) {
            $file = get_attached_file( $attachment_id );
            if ( $file && file_exists( $file ) && is_writable( dirname( $file ) ) ) {
                require_once ABSPATH . 'wp-admin/includes/image.php';
                $pathinfo = pathinfo( $file );
                $extension = isset( $pathinfo['extension'] ) ? '.' . strtolower( $pathinfo['extension'] ) : '';
                $new_name = wp_unique_filename( $pathinfo['dirname'], sanitize_file_name( $title ) . $extension );
                $new_path = trailingslashit( $pathinfo['dirname'] ) . $new_name;
                if ( @rename( $file, $new_path ) ) {
                    update_attached_file( $attachment_id, $new_path );
                    $metadata = wp_generate_attachment_metadata( $attachment_id, $new_path );
                    if ( is_array( $metadata ) ) {
                        wp_update_attachment_metadata( $attachment_id, $metadata );
                    }
                }
            }
        }

        return new \WP_REST_Response( [ 'success' => true, 'item' => $this->media_item_payload( $attachment_id ) ], 200 );
    }

    public function get_content_studio_meta(): \WP_REST_Response {
        $cpts = [];
        $field_groups = [];

        $post_types = get_post_types( [], 'objects' );
        $exclude = [
            'attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset',
            'oembed_cache', 'user_request', 'wp_block', 'wp_template', 'wp_template_part',
            'acf-field-group', 'acf-field', 'wp_navigation', 'wp_global_styles', 'wp_font_family',
            'wp_font_face', 'action_scheduler', 'bricks_template'
        ];

        $acf_cpts = [];
        if ( function_exists( 'acf_get_post_types' ) ) {
            $acf_cpts = acf_get_post_types();
        }
        $jet_cpts = get_option( 'jet_engine_cpt', [] );
        if ( ! is_array( $jet_cpts ) ) {
            $jet_cpts = [];
        }

        foreach ( $post_types as $pt ) {
            if ( in_array( $pt->name, $exclude, true ) ) {
                continue;
            }

            $source = 'wp';
            foreach ( $acf_cpts as $ac ) {
                if ( ( $ac['post_type'] ?? '' ) === $pt->name ) {
                    $source = 'acf';
                    break;
                }
            }
            if ( $source === 'wp' ) {
                foreach ( $jet_cpts as $jc ) {
                    if ( ( $jc['slug'] ?? '' ) === $pt->name ) {
                        $source = 'jet';
                        break;
                    }
                }
            }

            $counts = wp_count_posts( $pt->name );
            $total_count = (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 ) + (int) ( $counts->pending ?? 0 ) + (int) ( $counts->private ?? 0 );
            $label = $pt->label ?: $pt->name;
            $is_content = ! preg_match( '/(taxonom|option pages?|custom fonts?|rm content editor|field groups?|template parts?|navigation)/i', $label );

            $cpts[] = [
                'name'         => $pt->name,
                'label'        => $label,
                'singular'     => $pt->labels->singular_name ?: $pt->name,
                'show_in_rest' => ! empty( $pt->show_in_rest ),
                'rest_base'    => $pt->rest_base ?: $pt->name,
                'count'        => $total_count,
                'source'       => $source,
                'is_builtin'   => ! empty( $pt->_builtin ),
                'is_content'   => $is_content,
                'supports_editor' => post_type_supports( $pt->name, 'editor' ),
                'supports_custom_fields' => post_type_supports( $pt->name, 'custom-fields' ),
            ];
        }

        $known_cpt_names = array_fill_keys( array_map( static function( $pt ) {
            return $pt['name'];
        }, $cpts ), true );

        foreach ( (array) $acf_cpts as $acf_cpt ) {
            $name = sanitize_key( (string) ( $acf_cpt['post_type'] ?? $acf_cpt['name'] ?? '' ) );
            if ( empty( $name ) || in_array( $name, [ 'page', 'post' ], true ) || isset( $known_cpt_names[ $name ] ) || in_array( $name, $exclude, true ) ) {
                continue;
            }
            $label = sanitize_text_field( (string) ( $acf_cpt['title'] ?? $acf_cpt['labels']['name'] ?? $name ) );
            $singular = sanitize_text_field( (string) ( $acf_cpt['labels']['singular_name'] ?? ( $label ?: $name ) ) );
            $counts = wp_count_posts( $name );
            $total_count = is_object( $counts ) ? (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 ) + (int) ( $counts->pending ?? 0 ) + (int) ( $counts->private ?? 0 ) : 0;
            $cpts[] = [
                'name'         => $name,
                'label'        => $label ?: $name,
                'singular'     => $singular,
                'show_in_rest' => ! empty( $acf_cpt['show_in_rest'] ),
                'rest_base'    => sanitize_key( (string) ( $acf_cpt['rest_base'] ?? $name ) ),
                'count'        => $total_count,
                'source'       => 'acf',
                'is_builtin'   => false,
                'is_content'   => ! preg_match( '/(taxonom|option pages?|custom fonts?|rm content editor|field groups?|template parts?|navigation)/i', $label ),
                'supports_editor' => post_type_supports( $name, 'editor' ),
                'supports_custom_fields' => post_type_supports( $name, 'custom-fields' ),
            ];
            $known_cpt_names[ $name ] = true;
        }

        foreach ( (array) $jet_cpts as $jet_cpt ) {
            $name = sanitize_key( (string) ( $jet_cpt['slug'] ?? $jet_cpt['name'] ?? '' ) );
            if ( empty( $name ) || in_array( $name, [ 'page', 'post' ], true ) || isset( $known_cpt_names[ $name ] ) || in_array( $name, $exclude, true ) ) {
                continue;
            }
            $label = sanitize_text_field( (string) ( $jet_cpt['labels']['name'] ?? $jet_cpt['label'] ?? $name ) );
            $singular = sanitize_text_field( (string) ( $jet_cpt['labels']['singular_name'] ?? ( $label ?: $name ) ) );
            $counts = wp_count_posts( $name );
            $total_count = is_object( $counts ) ? (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 ) + (int) ( $counts->pending ?? 0 ) + (int) ( $counts->private ?? 0 ) : 0;
            $cpts[] = [
                'name'         => $name,
                'label'        => $label ?: $name,
                'singular'     => $singular,
                'show_in_rest' => ! empty( $jet_cpt['args']['show_in_rest'] ),
                'rest_base'    => sanitize_key( (string) ( $jet_cpt['args']['rest_base'] ?? $name ) ),
                'count'        => $total_count,
                'source'       => 'jet',
                'is_builtin'   => false,
                'is_content'   => ! preg_match( '/(taxonom|option pages?|custom fonts?|rm content editor|field groups?|template parts?|navigation)/i', $label ),
                'supports_editor' => post_type_supports( $name, 'editor' ),
                'supports_custom_fields' => post_type_supports( $name, 'custom-fields' ),
            ];
            $known_cpt_names[ $name ] = true;
        }

        if ( function_exists( 'acf_get_field_groups' ) ) {
            $acf_groups = acf_get_field_groups();
            foreach ( $acf_groups as $group ) {
                $group_title = (string) ( $group['title'] ?? '' );
                if ( preg_match( '/^option pages?$/i', $group_title ) ) {
                    continue;
                }
                $fields = [];
                $raw_fields = acf_get_fields( $group['ID'] ) ?: acf_get_fields( $group['key'] ) ?: [];
                foreach ( $raw_fields as $f ) {
                    $fields[] = [
                        'name'  => $f['name'] ?? '',
                        'label' => $f['label'] ?? ($f['name'] ?? ''),
                        'type'  => $f['type'] ?? 'text',
                    ];
                }

                $post_types_rules = [];
                if ( isset( $group['location'] ) && is_array( $group['location'] ) ) {
                    foreach ( $group['location'] as $rule_group ) {
                        foreach ( $rule_group as $rule ) {
                            if ( ( $rule['param'] ?? '' ) === 'options_page' ) {
                                continue 3;
                            }
                            if ( ( $rule['param'] ?? '' ) === 'post_type' && ( $rule['operator'] ?? '' ) === '==' ) {
                                $post_types_rules[] = $rule['value'];
                            }
                        }
                    }
                }

                $field_groups[] = [
                    'id'         => 'acf-' . $group['ID'],
                    'key'        => $group['key'],
                    'title'      => $group['title'] ?? 'ACF Field Group',
                    'fields'     => $fields,
                    'post_types' => array_values( array_unique( $post_types_rules ) ),
                    'source'     => 'acf',
                ];
            }
        }

        $jet_groups = [];
        if ( function_exists( 'jet_engine' ) && isset( jet_engine()->meta_boxes ) ) {
            $boxes = [];
            if ( method_exists( jet_engine()->meta_boxes, 'get_meta_boxes' ) ) {
                $boxes = jet_engine()->meta_boxes->get_meta_boxes();
            } elseif ( isset( jet_engine()->meta_boxes->data ) && method_exists( jet_engine()->meta_boxes->data, 'get_items' ) ) {
                $boxes = jet_engine()->meta_boxes->data->get_items();
            }
            foreach ( (array) $boxes as $box ) {
                $box_id = '';
                $box_title = '';
                $args = [];
                if ( is_object( $box ) ) {
                    $box_id = $box->id ?? '';
                    $box_title = $box->name ?? ($box->title ?? '');
                    $args = (array) ($box->args ?? []);
                } elseif ( is_array( $box ) ) {
                    $box_id = $box['id'] ?? '';
                    $box_title = $box['name'] ?? ($box['title'] ?? '');
                    $args = $box['args'] ?? [];
                }
                $allowed_posts = $args['allowed_post_types'] ?? [];

                $fields = [];
                $raw_fields = [];
                if ( is_object( $box ) && method_exists( $box, 'get_meta_fields' ) ) {
                    $raw_fields = $box->get_meta_fields();
                } elseif ( is_array( $box ) && isset( $box['meta_fields'] ) ) {
                    $raw_fields = $box['meta_fields'];
                } elseif ( is_object( $box ) && isset( $box->meta_fields ) ) {
                    $raw_fields = $box->meta_fields;
                }

                foreach ( (array) $raw_fields as $f ) {
                    $f_name = '';
                    $f_title = '';
                    $f_type = 'text';
                    if ( is_object( $f ) ) {
                        $f_name = $f->name ?? '';
                        $f_title = $f->title ?? '';
                        $f_type = $f->type ?? 'text';
                    } elseif ( is_array( $f ) ) {
                        $f_name = $f['name'] ?? '';
                        $f_title = $f['title'] ?? '';
                        $f_type = $f['type'] ?? 'text';
                    }
                    if ( $f_name ) {
                        $fields[] = [
                            'name'  => $f_name,
                            'label' => $f_title ?: $f_name,
                            'type'  => $f_type,
                        ];
                    }
                }

                if ( $box_id && ! empty( $fields ) ) {
                    $jet_groups[ $box_id ] = [
                        'id'         => 'jet-' . $box_id,
                        'key'        => $box_id,
                        'title'      => $box_title ?: 'JetEngine Field Group',
                        'fields'     => $fields,
                        'post_types' => (array) $allowed_posts,
                        'source'     => 'jet',
                    ];
                }
            }
        }

        $jet_options = get_option( 'jet_engine_meta_boxes', [] );
        if ( is_array( $jet_options ) ) {
            foreach ( $jet_options as $box ) {
                $box_id = $box['id'] ?? '';
                if ( ! $box_id || isset( $jet_groups[ $box_id ] ) ) {
                    continue;
                }
                $box_title = $box['name'] ?? ($box['title'] ?? '');
                $args = $box['args'] ?? [];
                $allowed_posts = $args['allowed_post_types'] ?? [];
                $raw_fields = $box['meta_fields'] ?? [];
                $fields = [];
                foreach ( (array) $raw_fields as $f ) {
                    $f_name = $f['name'] ?? '';
                    if ( $f_name ) {
                        $fields[] = [
                            'name'  => $f_name,
                            'label' => $f['title'] ?? ($f['label'] ?? $f_name),
                            'type'  => $f['type'] ?? 'text',
                        ];
                    }
                }
                if ( ! empty( $fields ) ) {
                    $jet_groups[ $box_id ] = [
                        'id'         => 'jet-' . $box_id,
                        'key'        => $box_id,
                        'title'      => $box_title ?: 'JetEngine Field Group',
                        'fields'     => $fields,
                        'post_types' => (array) $allowed_posts,
                        'source'     => 'jet',
                    ];
                }
            }
        }

        $field_groups = array_merge( $field_groups, array_values( $jet_groups ) );
        $deduped_cpts = [];
        foreach ( $cpts as $pt ) {
            $name = $pt['name'] ?? '';
            if ( ! $name || isset( $deduped_cpts[ $name ] ) ) {
                continue;
            }
            $deduped_cpts[ $name ] = $pt;
        }
        $cpts = array_values( $deduped_cpts );

        return new \WP_REST_Response( [
            'cpts'         => $cpts,
            'field_groups' => $field_groups,
            'acf_active'   => function_exists( 'acf_get_field_groups' ),
            'jet_active'   => function_exists( 'jet_engine' ) || ! empty( $jet_options ),
        ], 200 );
    }

    private function studio_post_payload( \WP_Post $post ): array {
        $link = get_permalink( $post->ID ) ?: '#';
        $edit_link = get_edit_post_link( $post->ID, 'raw' );
        if ( ! $edit_link ) {
            $edit_link = admin_url( 'post.php?post=' . $post->ID . '&action=edit' );
        }
        $bricks_link = $link && '#' !== $link ? add_query_arg( 'bricks', 'run', $link ) : $edit_link;

        return [
            'id'            => $post->ID,
            'type'          => $post->post_type,
            'title'         => [ 'rendered' => $post->post_title ],
            'slug'          => $post->post_name,
            'status'        => $post->post_status,
            'content'       => [ 'raw' => $post->post_content ],
            'excerpt'       => [ 'raw' => $post->post_excerpt ],
            'author'        => (int) $post->post_author,
            'parent'        => (int) $post->post_parent,
            'menu_order'    => (int) $post->menu_order,
            'featured_media'=> (int) get_post_thumbnail_id( $post->ID ),
            'comment_status'=> $post->comment_status,
            'ping_status'   => $post->ping_status,
            'template'      => get_page_template_slug( $post->ID ) ?: '',
            'date'          => $post->post_date_gmt,
            'modified'      => $post->post_modified_gmt,
            'link'          => $link,
            'edit_link'     => $edit_link,
            'bricks_link'   => $bricks_link,
            'supports_editor' => post_type_supports( $post->post_type, 'editor' ),
            'custom_fields' => $this->studio_post_custom_fields( $post->ID ),
        ];
    }

    private function studio_post_custom_fields( int $post_id ): array {
        $out = [];

        if ( function_exists( 'get_fields' ) ) {
            $acf_values = get_fields( $post_id );
            if ( is_array( $acf_values ) ) {
                foreach ( $acf_values as $key => $value ) {
                    $out[ sanitize_key( (string) $key ) ] = $this->studio_meta_value_for_ui( $value );
                }
            }
        }

        $raw_meta = get_post_meta( $post_id );
        foreach ( $raw_meta as $key => $values ) {
            if ( 0 === strpos( (string) $key, '_' ) || isset( $out[ $key ] ) ) {
                continue;
            }
            $value = is_array( $values ) ? reset( $values ) : $values;
            $out[ sanitize_key( (string) $key ) ] = $this->studio_meta_value_for_ui( $value );
        }

        return $out;
    }

    private function studio_meta_value_for_ui( $value ): string {
        if ( is_null( $value ) ) {
            return '';
        }

        if ( is_scalar( $value ) ) {
            return (string) $value;
        }

        $json = wp_json_encode( $value, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES );
        return is_string( $json ) ? $json : '';
    }

    private function studio_meta_value_from_ui( $value ) {
        if ( ! is_string( $value ) ) {
            return $value;
        }

        $trimmed = trim( $value );
        if ( '' === $trimmed ) {
            return '';
        }

        $first = substr( $trimmed, 0, 1 );
        if ( '{' === $first || '[' === $first ) {
            $decoded = json_decode( $trimmed, true );
            if ( JSON_ERROR_NONE === json_last_error() ) {
                return $decoded;
            }
        }

        return $value;
    }

    public function list_studio_posts( \WP_REST_Request $request ): \WP_REST_Response {
        $post_type = sanitize_key( $request->get_param( 'post_type' ) ?: 'post' );
        $search = sanitize_text_field( $request->get_param( 'search' ) ?: '' );

        $args = [
            'post_type'      => $post_type,
            'posts_per_page' => 100,
            'post_status'    => [ 'publish', 'draft', 'pending', 'private' ],
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ];

        if ( $search ) {
            $args['s'] = $search;
        }

        $query = new \WP_Query( $args );
        $posts = [];

        foreach ( $query->posts as $post ) {
            $posts[] = $this->studio_post_payload( $post );
        }

        return new \WP_REST_Response( $posts, 200 );
    }

    public function create_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $post_type = sanitize_key( $params['post_type'] ?? 'post' );
        $title = sanitize_text_field( $params['title'] ?? '' );
        $status = sanitize_key( $params['status'] ?? 'draft' );

        if ( empty( $title ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_title', 'message' => 'Post title is required.' ], 400 );
        }

        $post_id = wp_insert_post([
            'post_type'   => $post_type,
            'post_title'  => $title,
            'post_status' => $status,
        ]);

        if ( is_wp_error( $post_id ) ) {
            return new \WP_REST_Response( [ 'code' => 'create_failed', 'message' => $post_id->get_error_message() ], 500 );
        }

        if ( ! $post_id ) {
            return new \WP_REST_Response( [ 'code' => 'create_failed', 'message' => 'Could not create post.' ], 500 );
        }

        $post = get_post( $post_id );
        return new \WP_REST_Response( $this->studio_post_payload( $post ), 200 );
    }

    public function update_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $id = absint( $request->get_param( 'id' ) );
        $params = $request->get_json_params() ?: [];
        $status = sanitize_key( $params['status'] ?? '' );
        $title = sanitize_text_field( $params['title'] ?? '' );
        $slug = sanitize_title( $params['slug'] ?? '' );
        $content_provided = array_key_exists( 'content', $params );
        $excerpt_provided = array_key_exists( 'excerpt', $params );

        if ( ! $id || ! get_post( $id ) ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'Post not found.' ], 404 );
        }

        $update = [ 'ID' => $id ];
        if ( $status ) {
            $update['post_status'] = $status;
        }
        if ( $title ) {
            $update['post_title'] = $title;
        }
        if ( $slug ) {
            $update['post_name'] = $slug;
        }
        if ( $content_provided ) {
            $update['post_content'] = wp_kses_post( (string) $params['content'] );
        }
        if ( $excerpt_provided ) {
            $update['post_excerpt'] = sanitize_textarea_field( (string) $params['excerpt'] );
        }
        if ( array_key_exists( 'parent', $params ) ) {
            $update['post_parent'] = absint( $params['parent'] );
        }
        if ( array_key_exists( 'menu_order', $params ) ) {
            $update['menu_order'] = intval( $params['menu_order'] );
        }
        if ( array_key_exists( 'comment_status', $params ) ) {
            $update['comment_status'] = rest_sanitize_boolean( $params['comment_status'] ) ? 'open' : 'closed';
        }
        if ( array_key_exists( 'ping_status', $params ) ) {
            $update['ping_status'] = rest_sanitize_boolean( $params['ping_status'] ) ? 'open' : 'closed';
        }

        if ( count( $update ) > 1 ) {
            wp_update_post( $update );
        }
        if ( array_key_exists( 'featured_media', $params ) ) {
            $featured_media = absint( $params['featured_media'] );
            if ( $featured_media ) {
                set_post_thumbnail( $id, $featured_media );
            } else {
                delete_post_thumbnail( $id );
            }
        }
        if ( array_key_exists( 'template', $params ) ) {
            update_post_meta( $id, '_wp_page_template', sanitize_text_field( (string) $params['template'] ) );
        }
        if ( isset( $params['custom_fields'] ) && is_array( $params['custom_fields'] ) ) {
            foreach ( $params['custom_fields'] as $meta_key => $meta_value ) {
                $key = sanitize_key( (string) $meta_key );
                if ( '' === $key || 0 === strpos( $key, '_' ) ) {
                    continue;
                }
                $value = $this->studio_meta_value_from_ui( $meta_value );
                if ( is_string( $value ) ) {
                    $value = wp_kses_post( $value );
                }
                $updated = false;
                if ( function_exists( 'update_field' ) ) {
                    $updated = (bool) update_field( $key, $value, $id );
                }
                if ( ! $updated ) {
                    update_post_meta( $id, $key, $value );
                }
            }
        }

        $post = get_post( $id );
        return new \WP_REST_Response( $this->studio_post_payload( $post ), 200 );
    }

    public function delete_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $id = absint( $request->get_param( 'id' ) );
        $force = rest_sanitize_boolean( $request->get_param( 'force' ) );

        if ( ! $id || ! get_post( $id ) ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'Post not found.' ], 404 );
        }

        $res = wp_delete_post( $id, $force );
        if ( $res ) {
            return new \WP_REST_Response( [ 'id' => $id ], 200 );
        }

        return new \WP_REST_Response( [ 'code' => 'delete_failed', 'message' => 'Could not delete post.' ], 500 );
    }

    public function create_or_update_studio_cpt( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $name = sanitize_key( $params['name'] ?? '' );
        $singular = sanitize_text_field( $params['singular'] ?? '' );
        $plural = sanitize_text_field( $params['plural'] ?? '' );
        $source = sanitize_key( $params['source'] ?? 'acf' );

        if ( empty( $name ) || empty( $singular ) || empty( $plural ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_params', 'message' => 'Name, singular label, and plural label are required.' ], 400 );
        }

        if ( $source === 'jet' ) {
            $cpts = get_option( 'jet_engine_cpt', [] );
            if ( ! is_array( $cpts ) ) {
                $cpts = [];
            }
            $found = false;
            foreach ( $cpts as &$c ) {
                if ( ( $c['slug'] ?? '' ) === $name ) {
                    $c['labels']['name'] = $plural;
                    $c['labels']['singular_name'] = $singular;
                    $found = true;
                    break;
                }
            }
            if ( ! $found ) {
                $cpts[] = [
                    'slug'   => $name,
                    'labels' => [
                        'name'          => $plural,
                        'singular_name' => $singular,
                    ],
                    'args'   => [
                        'public'       => true,
                        'show_in_rest' => true,
                    ],
                ];
            }
            update_option( 'jet_engine_cpt', $cpts );
        } else {
            if ( function_exists( 'acf_update_post_type' ) ) {
                acf_update_post_type([
                    'post_type' => $name,
                    'title'     => $plural,
                    'labels'    => [
                        'name'          => $plural,
                        'singular_name' => $singular,
                    ],
                    'active'    => true,
                    'show_in_rest' => true,
                ]);
            } else {
                $cpts = get_option( 'jet_engine_cpt', [] );
                if ( ! is_array( $cpts ) ) {
                    $cpts = [];
                }
                $found = false;
                foreach ( $cpts as &$c ) {
                    if ( ( $c['slug'] ?? '' ) === $name ) {
                        $c['labels']['name'] = $plural;
                        $c['labels']['singular_name'] = $singular;
                        $found = true;
                        break;
                    }
                }
                if ( ! $found ) {
                    $cpts[] = [
                        'slug'   => $name,
                        'labels' => [
                            'name'          => $plural,
                            'singular_name' => $singular,
                        ],
                        'args'   => [
                            'public'       => true,
                            'show_in_rest' => true,
                        ],
                    ];
                }
                update_option( 'jet_engine_cpt', $cpts );
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function delete_studio_cpt( \WP_REST_Request $request ): \WP_REST_Response {
        $name = sanitize_key( $request->get_param( 'name' ) );

        $jet_cpts = get_option( 'jet_engine_cpt', [] );
        if ( is_array( $jet_cpts ) ) {
            $filtered = [];
            $found = false;
            foreach ( $jet_cpts as $c ) {
                if ( ( $c['slug'] ?? '' ) === $name ) {
                    $found = true;
                } else {
                    $filtered[] = $c;
                }
            }
            if ( $found ) {
                update_option( 'jet_engine_cpt', $filtered );
            }
        }

        if ( function_exists( 'acf_delete_post_type' ) ) {
            acf_delete_post_type( $name );
        } else {
            $acf_posts = get_posts([
                'post_type'   => 'acf-post-type',
                'name'        => $name,
                'post_status' => 'any',
                'numberposts' => 1,
            ]);
            if ( ! empty( $acf_posts ) ) {
                wp_delete_post( $acf_posts[0]->ID, true );
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function create_or_update_studio_fields( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $title = sanitize_text_field( $params['title'] ?? '' );
        $post_types = is_array( $params['post_types'] ?? null ) ? array_map( 'sanitize_key', $params['post_types'] ) : [ 'post' ];
        $fields = is_array( $params['fields'] ?? null ) ? $params['fields'] : [];
        $source = sanitize_key( $params['source'] ?? 'acf' );

        if ( empty( $title ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_title', 'message' => 'Title is required.' ], 400 );
        }

        $sanitized_fields = [];
        foreach ( $fields as $f ) {
            $f_name = sanitize_key( $f['name'] ?? '' );
            if ( $f_name ) {
                $sanitized_fields[] = [
                    'name'  => $f_name,
                    'label' => sanitize_text_field( $f['label'] ?? $f_name ),
                    'type'  => sanitize_key( $f['type'] ?? 'text' ),
                ];
            }
        }

        if ( $source === 'jet' ) {
            $boxes = get_option( 'jet_engine_meta_boxes', [] );
            if ( ! is_array( $boxes ) ) {
                $boxes = [];
            }
            $key = sanitize_key( $title );
            $meta_fields = [];
            foreach ( $sanitized_fields as $f ) {
                $meta_fields[] = [
                    'name'  => $f['name'],
                    'title' => $f['label'],
                    'type'  => $f['type'],
                ];
            }
            $new_box = [
                'id'           => $key,
                'name'         => $title,
                'args'         => [
                    'allowed_post_types' => $post_types,
                ],
                'meta_fields'  => $meta_fields,
            ];
            $found = false;
            foreach ( $boxes as &$b ) {
                if ( ( $b['id'] ?? '' ) === $key ) {
                    $b = $new_box;
                    $found = true;
                    break;
                }
            }
            if ( ! $found ) {
                $boxes[] = $new_box;
            }
            update_option( 'jet_engine_meta_boxes', $boxes );
        } else {
            if ( function_exists( 'acf_update_field_group' ) ) {
                $key = 'group_cs_' . sanitize_key( $title );
                $field_group = [
                    'key'      => $key,
                    'title'    => $title,
                    'location' => [],
                    'active'   => true,
                ];
                foreach ( $post_types as $pt ) {
                    $field_group['location'][] = [
                        [
                            'param'    => 'post_type',
                            'operator' => '==',
                            'value'    => $pt,
                        ]
                    ];
                }
                $group = acf_update_field_group( $field_group );
                if ( $group && isset( $group['ID'] ) ) {
                    $existing = acf_get_fields( $group['ID'] ) ?: [];
                    foreach ( $existing as $ef ) {
                        acf_delete_field( $ef['ID'] );
                    }
                    foreach ( $sanitized_fields as $f ) {
                        $f_key = 'field_' . sanitize_key( $group['key'] . '_' . $f['name'] );
                        acf_update_field([
                            'key'          => $f_key,
                            'parent'       => $group['ID'],
                            'name'         => $f['name'],
                            'label'        => $f['label'],
                            'type'         => $f['type'],
                        ]);
                    }
                }
            } else {
                $boxes = get_option( 'jet_engine_meta_boxes', [] );
                if ( ! is_array( $boxes ) ) {
                    $boxes = [];
                }
                $key = sanitize_key( $title );
                $meta_fields = [];
                foreach ( $sanitized_fields as $f ) {
                    $meta_fields[] = [
                        'name'  => $f['name'],
                        'title' => $f['label'],
                        'type'  => $f['type'],
                    ];
                }
                $new_box = [
                    'id'           => $key,
                    'name'         => $title,
                    'args'         => [
                        'allowed_post_types' => $post_types,
                    ],
                    'meta_fields'  => $meta_fields,
                ];
                $found = false;
                foreach ( $boxes as &$b ) {
                    if ( ( $b['id'] ?? '' ) === $key ) {
                        $b = $new_box;
                        $found = true;
                        break;
                    }
                }
                if ( ! $found ) {
                    $boxes[] = $new_box;
                }
                update_option( 'jet_engine_meta_boxes', $boxes );
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function delete_studio_fields( \WP_REST_Request $request ): \WP_REST_Response {
        $id = sanitize_key( $request->get_param( 'id' ) );

        if ( 0 === strpos( $id, 'jet-' ) ) {
            $key = substr( $id, 4 );
            $boxes = get_option( 'jet_engine_meta_boxes', [] );
            if ( is_array( $boxes ) ) {
                $filtered = [];
                foreach ( $boxes as $b ) {
                    if ( ( $b['id'] ?? '' ) !== $key ) {
                        $filtered[] = $b;
                    }
                }
                update_option( 'jet_engine_meta_boxes', $filtered );
            }
        } elseif ( 0 === strpos( $id, 'acf-' ) ) {
            $acf_id = (int) substr( $id, 4 );
            if ( function_exists( 'acf_delete_field_group' ) ) {
                acf_delete_field_group( $acf_id );
            } else {
                wp_delete_post( $acf_id, true );
            }
        } else {
            $boxes = get_option( 'jet_engine_meta_boxes', [] );
            if ( is_array( $boxes ) ) {
                $filtered = [];
                $found = false;
                foreach ( $boxes as $b ) {
                    if ( ( $b['id'] ?? '' ) === $id ) {
                        $found = true;
                    } else {
                        $filtered[] = $b;
                    }
                }
                if ( $found ) {
                    update_option( 'jet_engine_meta_boxes', $filtered );
                }
            }

            if ( function_exists( 'acf_delete_field_group' ) ) {
                acf_delete_field_group( $id );
            } else {
                $acf_id = (int) $id;
                if ( $acf_id ) {
                    wp_delete_post( $acf_id, true );
                }
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    private function studio_jet_to_acf_field_type( string $type ): string {
        $type = sanitize_key( $type );
        $map = [
            'text'      => 'text',
            'textarea'  => 'textarea',
            'wysiwyg'   => 'wysiwyg',
            'editor'    => 'wysiwyg',
            'number'    => 'number',
            'date'      => 'date_picker',
            'date_time' => 'date_time_picker',
            'datetime'  => 'date_time_picker',
            'time'      => 'time_picker',
            'media'     => 'image',
            'image'     => 'image',
            'gallery'   => 'gallery',
            'select'    => 'select',
            'radio'     => 'radio',
            'checkbox'  => 'checkbox',
            'switcher'  => 'true_false',
            'toggle'    => 'true_false',
            'colorpicker' => 'color_picker',
            'color'     => 'color_picker',
            'repeater'  => 'repeater',
        ];

        return $map[ $type ] ?? 'text';
    }

    private function studio_collect_jet_cpts(): array {
        $raw = get_option( 'jet_engine_cpt', [] );
        if ( ! is_array( $raw ) ) {
            return [];
        }

        $out = [];
        foreach ( $raw as $key => $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            $slug = sanitize_key( $item['slug'] ?? $item['post_type'] ?? $item['name'] ?? $key );
            if ( '' === $slug ) {
                continue;
            }
            $labels = is_array( $item['labels'] ?? null ) ? $item['labels'] : [];
            $plural = sanitize_text_field( $labels['name'] ?? $item['label'] ?? $item['title'] ?? ucwords( str_replace( [ '-', '_' ], ' ', $slug ) ) );
            $singular = sanitize_text_field( $labels['singular_name'] ?? $item['singular'] ?? $plural );
            $args = is_array( $item['args'] ?? null ) ? $item['args'] : [];
            $out[] = [
                'slug'     => $slug,
                'plural'   => $plural,
                'singular' => $singular,
                'public'   => isset( $args['public'] ) ? (bool) $args['public'] : true,
                'rest'     => isset( $args['show_in_rest'] ) ? (bool) $args['show_in_rest'] : true,
            ];
        }

        return $out;
    }

    private function studio_collect_jet_field_groups(): array {
        $boxes = get_option( 'jet_engine_meta_boxes', [] );
        if ( ! is_array( $boxes ) ) {
            return [];
        }

        $out = [];
        foreach ( $boxes as $index => $box ) {
            if ( ! is_array( $box ) ) {
                continue;
            }
            $id = sanitize_key( $box['id'] ?? $box['slug'] ?? $index );
            $title = sanitize_text_field( $box['name'] ?? $box['title'] ?? $id );
            $args = is_array( $box['args'] ?? null ) ? $box['args'] : [];
            $post_types = [];
            $allowed = $args['allowed_post_types'] ?? $args['post_types'] ?? $box['post_types'] ?? [];
            if ( is_string( $allowed ) ) {
                $allowed = [ $allowed ];
            }
            if ( is_array( $allowed ) ) {
                foreach ( $allowed as $pt ) {
                    $pt = sanitize_key( (string) $pt );
                    if ( $pt ) {
                        $post_types[] = $pt;
                    }
                }
            }
            if ( empty( $post_types ) ) {
                $post_types = [ 'post' ];
            }

            $fields = [];
            $raw_fields = is_array( $box['meta_fields'] ?? null ) ? $box['meta_fields'] : [];
            foreach ( $raw_fields as $field_index => $field ) {
                if ( ! is_array( $field ) ) {
                    continue;
                }
                $name = sanitize_key( $field['name'] ?? $field['id'] ?? $field['key'] ?? 'field_' . $field_index );
                if ( ! $name ) {
                    continue;
                }
                $fields[] = [
                    'name'  => $name,
                    'label' => sanitize_text_field( $field['title'] ?? $field['label'] ?? ucwords( str_replace( [ '-', '_' ], ' ', $name ) ) ),
                    'type'  => $this->studio_jet_to_acf_field_type( (string) ( $field['type'] ?? 'text' ) ),
                ];
            }

            $out[] = [
                'id'         => $id,
                'title'      => $title,
                'post_types' => array_values( array_unique( $post_types ) ),
                'fields'     => $fields,
            ];
        }

        return $out;
    }

    private function studio_jet_to_acf_plan(): array {
        return [
            'has_acf_fields_api' => function_exists( 'acf_update_field_group' ),
            'has_acf_cpt_api'    => function_exists( 'acf_update_post_type' ),
            'cpts'               => $this->studio_collect_jet_cpts(),
            'field_groups'       => $this->studio_collect_jet_field_groups(),
        ];
    }

    public function preview_jet_to_acf_migration(): \WP_REST_Response {
        $plan = $this->studio_jet_to_acf_plan();
        $plan['mode'] = 'preview';
        $plan['note'] = 'Preview only. Applying this creates ACF mirrors and does not delete JetEngine data.';
        return new \WP_REST_Response( $plan, 200 );
    }

    public function run_jet_to_acf_migration(): \WP_REST_Response {
        $plan = $this->studio_jet_to_acf_plan();
        if ( ! $plan['has_acf_fields_api'] ) {
            return new \WP_REST_Response( [
                'code'    => 'acf_unavailable',
                'message' => 'ACF field group APIs are not available. Activate ACF before running the JetEngine migration.',
            ], 400 );
        }

        $results = [
            'cpts'         => [],
            'field_groups' => [],
            'warnings'     => [],
        ];

        if ( ! $plan['has_acf_cpt_api'] ) {
            $results['warnings'][] = 'ACF post type API is unavailable, so CPT definitions were previewed but not mirrored.';
        } else {
            foreach ( $plan['cpts'] as $cpt ) {
                $updated = acf_update_post_type( [
                    'post_type'    => $cpt['slug'],
                    'title'        => $cpt['plural'],
                    'labels'       => [
                        'name'          => $cpt['plural'],
                        'singular_name' => $cpt['singular'],
                    ],
                    'active'       => true,
                    'public'       => $cpt['public'],
                    'show_in_rest' => $cpt['rest'],
                ] );
                $results['cpts'][] = [
                    'slug'    => $cpt['slug'],
                    'success' => ! empty( $updated ),
                ];
            }
        }

        foreach ( $plan['field_groups'] as $group ) {
            $group_key = 'group_mv_jet_' . sanitize_key( $group['id'] );
            $field_group = [
                'key'      => $group_key,
                'title'    => $group['title'],
                'location' => [],
                'active'   => true,
            ];
            foreach ( $group['post_types'] as $post_type ) {
                $field_group['location'][] = [
                    [
                        'param'    => 'post_type',
                        'operator' => '==',
                        'value'    => $post_type,
                    ],
                ];
            }
            $acf_group = acf_update_field_group( $field_group );
            $field_count = 0;
            if ( $acf_group && isset( $acf_group['ID'] ) ) {
                $existing = function_exists( 'acf_get_fields' ) ? acf_get_fields( $acf_group['ID'] ) : [];
                if ( is_array( $existing ) ) {
                    foreach ( $existing as $existing_field ) {
                        if ( isset( $existing_field['ID'] ) && function_exists( 'acf_delete_field' ) ) {
                            acf_delete_field( $existing_field['ID'] );
                        }
                    }
                }
                foreach ( $group['fields'] as $field ) {
                    acf_update_field( [
                        'key'    => 'field_mv_jet_' . sanitize_key( $group['id'] . '_' . $field['name'] ),
                        'parent' => $acf_group['ID'],
                        'name'   => $field['name'],
                        'label'  => $field['label'],
                        'type'   => $field['type'],
                    ] );
                    $field_count++;
                }
            }
            $results['field_groups'][] = [
                'id'          => $group['id'],
                'title'       => $group['title'],
                'field_count' => $field_count,
                'success'     => $field_count === count( $group['fields'] ),
            ];
        }

        return new \WP_REST_Response( [
            'success' => true,
            'results' => $results,
            'note'    => 'JetEngine data was left in place. Review ACF mirrors before disabling JetEngine.',
        ], 200 );
    }

    public function list_studio_plugins(): \WP_REST_Response {
        if ( ! function_exists( 'get_plugins' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $plugins = get_plugins();
        $active = (array) get_option( 'active_plugins', [] );
        $auto_updates = (array) get_site_option( 'auto_update_plugins', [] );
        $updates = get_site_transient( 'update_plugins' );
        $response = is_object( $updates ) && isset( $updates->response ) && is_array( $updates->response ) ? $updates->response : [];
        $rows = [];

        foreach ( $plugins as $file => $data ) {
            $update = $response[ $file ] ?? null;
            $rows[] = [
                'file'             => $file,
                'slug'             => sanitize_key( dirname( $file ) === '.' ? basename( $file, '.php' ) : dirname( $file ) ),
                'name'             => $data['Name'] ?? $file,
                'description'      => wp_strip_all_tags( $data['Description'] ?? '' ),
                'author'           => wp_strip_all_tags( $data['Author'] ?? '' ),
                'version'          => $data['Version'] ?? '',
                'active'           => in_array( $file, $active, true ),
                'auto_update'      => in_array( $file, $auto_updates, true ),
                'update_available' => ! empty( $update ),
                'new_version'      => is_object( $update ) ? ( $update->new_version ?? '' ) : '',
                'update_url'       => ! empty( $update ) ? wp_nonce_url( self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . urlencode( $file ) ), 'upgrade-plugin_' . $file ) : '',
            ];
        }

        usort( $rows, function( $a, $b ) {
            return strcasecmp( $a['name'], $b['name'] );
        } );

        return new \WP_REST_Response( [ 'plugins' => $rows ], 200 );
    }

    public function run_studio_plugin_action( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! function_exists( 'activate_plugin' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';

        $params = $request->get_json_params() ?: [];
        $plugin = plugin_basename( sanitize_text_field( $params['plugin'] ?? '' ) );
        $action = sanitize_key( $params['action'] ?? '' );

        if ( empty( $plugin ) || ! file_exists( WP_PLUGIN_DIR . '/' . $plugin ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Plugin not found.' ], 404 );
        }

        if ( $action === 'activate' ) {
            $result = activate_plugin( $plugin );
            if ( is_wp_error( $result ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
            }
            return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin activated.' ], 200 );
        }

        if ( $action === 'deactivate' ) {
            deactivate_plugins( [ $plugin ], false, false );
            return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin deactivated.' ], 200 );
        }

        if ( $action === 'auto_update_on' || $action === 'auto_update_off' ) {
            $list = (array) get_site_option( 'auto_update_plugins', [] );
            if ( $action === 'auto_update_on' ) {
                $list[] = $plugin;
                $list = array_values( array_unique( $list ) );
                update_site_option( 'auto_update_plugins', $list );
                return new \WP_REST_Response( [ 'success' => true, 'message' => 'Auto-update enabled.' ], 200 );
            }
            $list = array_values( array_diff( $list, [ $plugin ] ) );
            update_site_option( 'auto_update_plugins', $list );
            return new \WP_REST_Response( [ 'success' => true, 'message' => 'Auto-update disabled.' ], 200 );
        }

        if ( $action === 'delete' ) {
            if ( is_plugin_active( $plugin ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => 'Deactivate the plugin before deleting it.' ], 400 );
            }
            $result = delete_plugins( [ $plugin ] );
            if ( is_wp_error( $result ) ) {
                return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
            }
            return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin deleted.' ], 200 );
        }

        return new \WP_REST_Response( [ 'success' => false, 'message' => 'Unknown plugin action.' ], 400 );
    }

    private function load_plugin_installer_dependencies(): void {
        if ( ! function_exists( 'plugins_api' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin-install.php';
        }
        require_once ABSPATH . 'wp-admin/includes/file.php';
        require_once ABSPATH . 'wp-admin/includes/plugin.php';
        require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
    }

    public function search_plugin_directory( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! current_user_can( 'install_plugins' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'You do not have permission to install plugins.' ], 403 );
        }

        $search = sanitize_text_field( (string) ( $request->get_param( 'search' ) ?: '' ) );
        $this->load_plugin_installer_dependencies();
        $args = [
            'per_page' => 12,
            'page'     => 1,
            'fields'   => [
                'short_description' => true,
                'description'       => false,
                'sections'          => false,
                'icons'             => true,
                'rating'            => true,
                'ratings'           => false,
                'downloaded'        => false,
                'active_installs'   => true,
                'last_updated'      => true,
                'homepage'          => true,
            ],
        ];
        if ( strlen( $search ) >= 2 ) {
            $args['search'] = $search;
        } else {
            $args['browse'] = 'popular';
        }
        $api = plugins_api( 'query_plugins', $args );

        if ( is_wp_error( $api ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $api->get_error_message(), 'plugins' => [] ], 400 );
        }

        $rows = [];
        foreach ( (array) ( $api->plugins ?? [] ) as $plugin ) {
            $rows[] = [
                'slug'              => sanitize_key( $plugin['slug'] ?? '' ),
                'name'              => wp_strip_all_tags( $plugin['name'] ?? '' ),
                'version'           => sanitize_text_field( $plugin['version'] ?? '' ),
                'author'            => wp_strip_all_tags( $plugin['author'] ?? '' ),
                'short_description' => wp_strip_all_tags( $plugin['short_description'] ?? '' ),
                'rating'            => isset( $plugin['rating'] ) ? (float) $plugin['rating'] : 0,
                'active_installs'   => isset( $plugin['active_installs'] ) ? absint( $plugin['active_installs'] ) : 0,
                'last_updated'      => sanitize_text_field( $plugin['last_updated'] ?? '' ),
                'homepage'          => esc_url_raw( $plugin['homepage'] ?? '' ),
                'icons'             => is_array( $plugin['icons'] ?? null ) ? array_map( 'esc_url_raw', $plugin['icons'] ) : [],
            ];
        }

        return new \WP_REST_Response( [ 'plugins' => $rows ], 200 );
    }

    public function install_directory_plugin( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! current_user_can( 'install_plugins' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'You do not have permission to install plugins.' ], 403 );
        }

        $params = $request->get_json_params() ?: [];
        $slug = sanitize_key( (string) ( $params['slug'] ?? '' ) );
        if ( empty( $slug ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Missing plugin slug.' ], 400 );
        }

        $this->load_plugin_installer_dependencies();
        $api = plugins_api( 'plugin_information', [
            'slug'   => $slug,
            'fields' => [ 'sections' => false ],
        ] );
        if ( is_wp_error( $api ) || empty( $api->download_link ) ) {
            $message = is_wp_error( $api ) ? $api->get_error_message() : 'Could not find plugin download URL.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        $skin = new \Automatic_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader( $skin );
        $result = $upgrader->install( $api->download_link );
        if ( is_wp_error( $result ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
        }
        if ( ! $result ) {
            $errors = $skin->get_errors();
            $message = is_wp_error( $errors ) && $errors->has_errors() ? $errors->get_error_message() : 'Plugin install failed.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin installed.' ], 200 );
    }

    public function upload_plugin_zip( \WP_REST_Request $request ): \WP_REST_Response {
        if ( ! current_user_can( 'install_plugins' ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'You do not have permission to upload plugins.' ], 403 );
        }

        $files = $request->get_file_params();
        if ( empty( $files['plugin_zip'] ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => 'Choose a plugin ZIP first.' ], 400 );
        }

        $this->load_plugin_installer_dependencies();
        $upload = wp_handle_upload( $files['plugin_zip'], [
            'test_form' => false,
            'mimes'     => [ 'zip' => 'application/zip' ],
        ] );
        if ( isset( $upload['error'] ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $upload['error'] ], 400 );
        }

        $skin = new \Automatic_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader( $skin );
        $result = $upgrader->install( $upload['file'] );
        @unlink( $upload['file'] );

        if ( is_wp_error( $result ) ) {
            return new \WP_REST_Response( [ 'success' => false, 'message' => $result->get_error_message() ], 400 );
        }
        if ( ! $result ) {
            $errors = $skin->get_errors();
            $message = is_wp_error( $errors ) && $errors->has_errors() ? $errors->get_error_message() : 'Plugin upload install failed.';
            return new \WP_REST_Response( [ 'success' => false, 'message' => $message ], 400 );
        }

        return new \WP_REST_Response( [ 'success' => true, 'message' => 'Plugin uploaded and installed.' ], 200 );
    }
}
