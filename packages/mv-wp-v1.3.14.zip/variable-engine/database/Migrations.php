<?php

namespace VE\Database;

defined( 'ABSPATH' ) || exit;

class Migrations {

    /**
     * Run on plugin activation.
     * Uses dbDelta for safe, idempotent table creation / updates.
     */
    public static function run(): void {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $sql = Schema::get_sql();
        dbDelta( $sql );

        // Store the schema version so future migrations can diff.
        update_option( 've_db_version', VE_VERSION );

        ( new \VE\Core\ColorPaletteManager() )->repair_memberships();
    }

    public static function maybe_run(): void {
        if ( (string) get_option( 've_db_version', '' ) !== (string) VE_VERSION ) {
            self::run();
        }
    }
}
