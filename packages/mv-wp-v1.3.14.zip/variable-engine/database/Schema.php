<?php

namespace VE\Database;

defined( 'ABSPATH' ) || exit;

class Schema {

    /**
     * Return the full SQL for all tables.
     * Uses $wpdb->prefix so it works on any WP install.
     */
    public static function get_sql(): string {
        global $wpdb;
        $charset = $wpdb->get_charset_collate();
        $p       = $wpdb->prefix;

        return "
CREATE TABLE {$p}ve_variables (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    name        VARCHAR(255)    NOT NULL,
    type        ENUM('base','generated','alias') NOT NULL DEFAULT 'base',
    namespace   VARCHAR(64)     NOT NULL DEFAULT '',
    value       TEXT            NOT NULL DEFAULT '',
    css_value   TEXT            NOT NULL DEFAULT '',
    source_id   BIGINT UNSIGNED DEFAULT NULL,
    generator_type VARCHAR(64) DEFAULT NULL,
    position    INT UNSIGNED    NOT NULL DEFAULT 0,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY name (name),
    KEY namespace (namespace),
    KEY type (type),
    KEY source_id (source_id),
    KEY position (position)
) {$charset};

CREATE TABLE {$p}ve_generators (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    variable_id BIGINT UNSIGNED NOT NULL,
    type        VARCHAR(64)     NOT NULL,
    config      LONGTEXT        NOT NULL DEFAULT '{}',
    active      TINYINT(1)      NOT NULL DEFAULT 1,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY variable_id (variable_id)
) {$charset};

CREATE TABLE {$p}ve_dependencies (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    parent_id   BIGINT UNSIGNED NOT NULL,
    child_id    BIGINT UNSIGNED NOT NULL,
    relation    ENUM('generated','alias') NOT NULL,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY parent_child (parent_id, child_id),
    KEY child_id (child_id)
) {$charset};

CREATE TABLE {$p}ve_sync_logs (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    source      VARCHAR(32)     NOT NULL DEFAULT 'wordpress',
    author      VARCHAR(255)    NOT NULL DEFAULT '',
    diff        LONGTEXT        NOT NULL DEFAULT '[]',
    snapshot_id BIGINT UNSIGNED DEFAULT NULL,
    synced_at   DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    KEY snapshot_id (snapshot_id)
) {$charset};

CREATE TABLE {$p}ve_snapshots (
    id              BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    variables_state LONGTEXT        NOT NULL,
    trigger_type    VARCHAR(32)     NOT NULL DEFAULT 'manual',
    created_at      DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id)
) {$charset};

CREATE TABLE {$p}ve_color_palettes (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    slug        VARCHAR(191)    NOT NULL,
    name        VARCHAR(255)    NOT NULL,
    position    INT UNSIGNED    NOT NULL DEFAULT 0,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY slug (slug),
    KEY position (position)
) {$charset};

CREATE TABLE {$p}ve_color_palette_members (
    id          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    palette_id  BIGINT UNSIGNED NOT NULL,
    variable_id BIGINT UNSIGNED NOT NULL,
    position    INT UNSIGNED    NOT NULL DEFAULT 0,
    created_at  DATETIME        NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (id),
    UNIQUE KEY variable_id (variable_id),
    KEY palette_id (palette_id),
    KEY position (position)
) {$charset};
        ";
    }

    /** Table name helpers. */
    public static function table( string $name ): string {
        global $wpdb;
        return $wpdb->prefix . 've_' . $name;
    }
}
