<?php
namespace VE\Sync;

defined('ABSPATH') || exit;

/**
 * DiffEngine — compares two variable sets and produces a change list.
 *
 * Each set is an array of variables keyed by name.
 * Change types: add, update, delete, type_change
 */
class DiffEngine {

    /**
     * Compute the diff between a source set and a target set.
     *
     * "source" = incoming data (e.g. Figma JSON import)
     * "target" = current data (e.g. WordPress variables)
     *
     * Returns an array of change objects:
     * [
     *   { action: 'add',         name: 'color.accent', value: '#FF6B35', namespace: 'color' },
     *   { action: 'update',      name: 'color.primary', old_value: '#000', new_value: '#111' },
     *   { action: 'delete',      name: 'space.3xl' },
     *   { action: 'type_change', name: 'font.body', old_type: 'base', new_type: 'alias' },
     * ]
     *
     * @param array $source Incoming variables (array of assoc arrays with 'name', 'value', etc.)
     * @param array $target Current variables (same shape)
     * @param array $options  'ignore_generated' => bool (skip generated vars in diff)
     * @return array
     */
    public function diff( array $source, array $target, array $options = [] ): array {
        $ignore_generated = $options['ignore_generated'] ?? true;
        $changes = [];

        // Index target by name.
        $target_all_map = [];
        $target_map = [];
        $target_id_map = [];
        foreach ( $target as $v ) {
            $target_all_map[ $v['name'] ] = $v;
            if ( ! empty( $v['id'] ) ) {
                $target_id_map[ (int) $v['id'] ] = (string) $v['name'];
            }
            if ( $ignore_generated && ( $v['type'] ?? '' ) === 'generated' ) continue;
            $target_map[ $v['name'] ] = $v;
        }

        // Index source by name.
        $source_map = [];
        foreach ( $source as $v ) {
            $source_map[ $v['name'] ] = $v;
        }

        // 1. Additions + Updates — items in source but not in target, or changed.
        foreach ( $source_map as $name => $sv ) {
            $target_var = $target_map[ $name ] ?? null;
            if ( ! $target_var && $this->imported_variant_base_name( $name, $source_map, $target_all_map ) && isset( $target_all_map[ $name ] ) ) {
                $target_var = $target_all_map[ $name ];
            }

            if ( ! $target_var ) {
                // New variable.
                $changes[] = [
                    'action'    => 'add',
                    'name'      => $name,
                    'value'     => $sv['value'] ?? '',
                    'namespace' => $sv['namespace'] ?? explode('.', $name)[0],
                    'type'      => $sv['type'] ?? 'base',
                    'source_name' => $sv['source_name'] ?? '',
                    'generator_type' => $sv['generator_type'] ?? '',
                ];
            } else {
                $tv = $target_var;

                $variant_base = $this->imported_variant_base_name( $name, $source_map, $target_all_map );
                if ( $variant_base && ! $this->target_variant_is_nested( $tv, $variant_base, $target_all_map ) ) {
                    $changes[] = [
                        'action'    => 'repair_generated',
                        'name'      => $name,
                        'value'     => $sv['value'] ?? '',
                        'base_name' => $variant_base,
                    ];
                }

                // Type change.
                $s_type = $sv['type'] ?? 'base';
                $t_type = $tv['type'] ?? 'base';
                if ( $s_type !== $t_type && $s_type !== 'base' ) {
                    $changes[] = [
                        'action'   => 'type_change',
                        'name'     => $name,
                        'old_type' => $t_type,
                        'new_type' => $s_type,
                    ];
                }

                $source_name = strtolower( trim( (string) ( $sv['source_name'] ?? '' ) ) );
                if ( $source_name && in_array( $s_type, [ 'alias', 'generated' ], true ) ) {
                    $target_source_name = strtolower( trim( (string) ( $target_id_map[ (int) ( $tv['source_id'] ?? 0 ) ] ?? '' ) ) );
                    if ( $target_source_name !== $source_name ) {
                        $changes[] = [
                            'action'          => 'relationship_change',
                            'name'            => $name,
                            'old_source_name' => $target_source_name,
                            'source_name'     => $source_name,
                        ];
                    }
                }

                // Value change.
                $s_val = $this->normalize_value( $sv['value'] ?? '' );
                $t_val = $this->normalize_value( $tv['value'] ?? '' );
                if ( 'alias' !== $s_type && $s_val !== $t_val ) {
                    $changes[] = [
                        'action'    => 'update',
                        'name'      => $name,
                        'old_value' => $tv['value'] ?? '',
                        'new_value' => $sv['value'] ?? '',
                    ];
                }
            }
        }

        // 2. Deletions — items in target but not in source.
        foreach ( $target_map as $name => $tv ) {
            if ( ! isset( $source_map[ $name ] ) ) {
                if ( $this->source_has_children_for_base( $name, $source_map, $target_all_map ) ) {
                    continue;
                }
                $changes[] = [
                    'action' => 'delete',
                    'name'   => $name,
                    'value'  => $tv['value'] ?? '',
                ];
            }
        }

        return $changes;
    }

    private function imported_variant_base_name( string $name, array $source_map = [], array $target_all_map = [] ): string {
        $candidate = '';
        if ( preg_match( '/^(.*)\.(d|l|t)\.\d+$/', $name, $m ) ) {
            $candidate = (string) $m[1];
        } elseif ( preg_match( '/^(.*)\.\d+$/', $name, $m ) ) {
            $candidate = (string) $m[1];
        } else {
            $parts = explode( '.', $name );
            $leaf  = strtolower( (string) end( $parts ) );
            if ( count( $parts ) > 1 && $this->is_variant_leaf( $leaf ) ) {
                array_pop( $parts );
                $candidate = implode( '.', $parts );
            }
        }

        if ( '' === $candidate ) {
            return '';
        }

        if ( isset( $source_map[ $candidate ] ) || isset( $target_all_map[ $candidate ] ) ) {
            return $candidate;
        }

        $synthetic = $candidate . '.base';
        if ( isset( $source_map[ $synthetic ] ) || isset( $target_all_map[ $synthetic ] ) ) {
            return $synthetic;
        }

        return $synthetic;
    }

    private function is_variant_leaf( string $leaf ): bool {
        return (bool) preg_match( '/^(?:\d+(?:\.\d+)?|[2-9]xl|xl|l|m|s|xs|[2-9]xs|full|none|thin|extra-light|light|regular|normal|medium|semibold|semi-bold|bold|extra-bold|black)$/', $leaf );
    }

    private function source_has_children_for_base( string $base_name, array $source_map, array $target_all_map ): bool {
        if ( ! preg_match( '/\.base$/', $base_name ) ) {
            return false;
        }

        foreach ( array_keys( $source_map ) as $source_name ) {
            if ( $this->imported_variant_base_name( (string) $source_name, $source_map, $target_all_map ) === $base_name ) {
                return true;
            }
        }

        return false;
    }

    private function target_variant_is_nested( array $target, string $base_name, array $target_all_map ): bool {
        if ( 'generated' !== ( $target['type'] ?? '' ) ) {
            return false;
        }

        $source_id = (int) ( $target['source_id'] ?? 0 );
        if ( $source_id <= 0 ) {
            return false;
        }

        if ( empty( $target_all_map[ $base_name ] ) ) {
            return false;
        }

        return (int) ( $target_all_map[ $base_name ]['id'] ?? 0 ) === $source_id;
    }

    /**
     * Normalize a value for comparison.
     * Trims whitespace, lowercases hex colors.
     */
    private function normalize_value( string $val ): string {
        $val = trim( $val );
        // Normalize hex colors.
        if ( preg_match( '/^#[0-9a-fA-F]{3,8}$/', $val ) ) {
            $val = strtolower( $val );
        }
        return $val;
    }

    /**
     * Summarize a diff for display.
     *
     * @param array $changes Output from diff()
     * @return array { added: int, updated: int, deleted: int, type_changed: int, relationship_changed: int, repaired: int, total: int }
     */
    public function summary( array $changes ): array {
        $s = [ 'added' => 0, 'updated' => 0, 'deleted' => 0, 'type_changed' => 0, 'relationship_changed' => 0, 'repaired' => 0 ];
        foreach ( $changes as $c ) {
            switch ( $c['action'] ) {
                case 'add':
                    $s['added']++;
                    break;
                case 'update':
                    $s['updated']++;
                    break;
                case 'delete':
                    $s['deleted']++;
                    break;
                case 'type_change':
                    $s['type_changed']++;
                    break;
                case 'repair_generated':
                    $s['repaired']++;
                    break;
                case 'relationship_change':
                    $s['relationship_changed']++;
                    break;
            }
        }
        $s['total'] = array_sum( $s );
        return $s;
    }
}
