<?php
/**
 * Workspaces module registrar.
 *
 * Direction C ("The Desk") from
 * docs/mocks/tools/2026-09-04-workspaces-desk.html, built against
 * docs/MV-Workspace-First-Release-Deploy-Handoff-v5.md (v6) and
 * docs/BRICKS-WORKSPACE-STORAGE-AUDIT.md.
 *
 * SLICE 1 — the record only.
 *
 * What this ships: a workspace exists, is named, is dated against the Live state
 * it started from, and can be renamed, archived or discarded. That is all.
 *
 * What this deliberately does NOT ship, and why it is safe:
 *   - no Bricks read or write of any kind;
 *   - no post meta, no shadow post, no option overlay, no `pre_option_*` filter;
 *   - no publish, no release, no rollback.
 * The audit's section 10 says prove the structural path first, and even that is
 * the next slice. Nothing in this slice can alter what a visitor sees, because
 * nothing in it writes anything a visitor reads. That is the whole point of
 * starting here: the foundation is provable on its own.
 *
 * Registration mirrors MimamsBarModule and RecoveryModule: the file is inert
 * until variable-engine.php calls init(), and it self-gates on capability.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspacesModule {

    public const VERSION = '0.1.0-slice1';

    /** Ordered load list — dependencies first. */
    private const FILES = [
        'app/WorkspaceStore.php',
        'app/WorkspacesController.php',
    ];

    /** @var bool */
    private static $booted = false;

    /**
     * @param \VE\API\Routes|null $routes Passed so the module reuses MV's
     *                                    existing permission callbacks rather
     *                                    than inventing a second model.
     */
    public static function init( $routes = null ): void {
        if ( self::$booted ) {
            return;
        }
        self::$booted = true;

        $dir = __DIR__ . '/';
        foreach ( self::FILES as $file ) {
            $path = $dir . $file;
            if ( is_readable( $path ) ) {
                require_once $path;
            }
        }

        if ( ! class_exists( __NAMESPACE__ . '\WorkspacesController' ) ) {
            return;
        }

        ( new WorkspacesController( $routes ) )->register();
    }

    /**
     * Whether the module is switched off in MV settings, mirroring how the other
     * modules gate themselves. Unknown settings shape means "on" — a module that
     * disappears because an option was reshaped is worse than one that stays.
     */
    public static function is_disabled(): bool {
        $settings = get_option( 've_settings', [] );
        if ( ! is_array( $settings ) ) {
            return false;
        }
        $off = isset( $settings['deactivated_tools'] ) ? $settings['deactivated_tools'] : [];
        return is_array( $off ) && in_array( 'workspaces', $off, true );
    }
}
