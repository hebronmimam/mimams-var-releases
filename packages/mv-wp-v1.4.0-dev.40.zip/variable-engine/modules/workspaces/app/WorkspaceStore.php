<?php
/**
 * The workspace record.
 *
 * Slice 1 of the Workspaces module. This owns the record and nothing else: a
 * workspace is a named, dated intention to change the site, and at this slice it
 * holds no object payloads and touches no Bricks state whatsoever.
 *
 * That is deliberate. The handoff's §85 forbids claiming isolation MV cannot
 * deliver, and §100.1 splits isolation into two classes with different
 * guarantees. Neither can be honoured before the record exists, and the record
 * is provable on its own. Nothing in this file can change what a visitor sees,
 * because nothing in this file writes anything a visitor reads.
 *
 * Lifecycle contract this slice already satisfies:
 *   §92  deactivation mutates nothing — a table simply stops being read.
 *   §95  no path here publishes anything, so nothing can auto-publish on the
 *        way out.
 *   §96  uninstall preserves by default; the table is only dropped inside
 *        uninstall.php's existing `ve_delete_on_uninstall` branch.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspaceStore {

    /** Statuses a workspace may hold. Archived is a state, not a deletion. */
    public const STATUS_DRAFT    = 'draft';
    public const STATUS_REVIEW   = 'review';
    public const STATUS_ARCHIVED = 'archived';

    public const MAX_NAME = 191;

    /** @return string Fully-qualified table name. */
    public static function table(): string {
        global $wpdb;
        return $wpdb->prefix . 've_workspaces';
    }

    public static function statuses(): array {
        return [ self::STATUS_DRAFT, self::STATUS_REVIEW, self::STATUS_ARCHIVED ];
    }

    /**
     * A workspace identity that survives export, environment transfer and the
     * post IDs it will later shadow. §30: never rely on a native numeric ID.
     */
    public static function new_uuid(): string {
        if ( function_exists( 'wp_generate_uuid4' ) ) {
            return wp_generate_uuid4();
        }
        // 7.4-safe fallback; only reachable outside WordPress (the check harness).
        $b    = random_bytes( 16 );
        $b[6] = chr( ( ord( $b[6] ) & 0x0f ) | 0x40 ); // version 4
        $b[8] = chr( ( ord( $b[8] ) & 0x3f ) | 0x80 ); // variant 1
        $hex  = bin2hex( $b );

        return substr( $hex, 0, 8 ) . '-'
            . substr( $hex, 8, 4 ) . '-'
            . substr( $hex, 12, 4 ) . '-'
            . substr( $hex, 16, 4 ) . '-'
            . substr( $hex, 20, 12 );
    }

    /**
     * A name the owner typed, made safe without being made unrecognisable.
     * An empty result is refused by create() rather than silently renamed —
     * "Untitled" appearing where someone typed something is a small lie.
     */
    public static function clean_name( $raw ): string {
        $name = is_string( $raw ) ? $raw : '';
        $name = function_exists( 'wp_strip_all_tags' ) ? wp_strip_all_tags( $name ) : strip_tags( $name );
        $name = preg_replace( '/\s+/u', ' ', $name );
        $name = trim( (string) $name );
        if ( '' === $name ) {
            return '';
        }
        if ( function_exists( 'mb_substr' ) ) {
            return mb_substr( $name, 0, self::MAX_NAME );
        }
        return substr( $name, 0, self::MAX_NAME );
    }

    /**
     * Create a workspace against the current Live state.
     *
     * `base_taken_at` is the moment the workspace's base was fixed. Every later
     * drift and conflict question (§19) is asked relative to it, so it is
     * recorded now even though this slice compares nothing yet.
     *
     * @return array|\WP_Error
     */
    public static function create( $name, $user_id = 0 ) {
        global $wpdb;

        $clean = self::clean_name( $name );
        if ( '' === $clean ) {
            return self::error( 've_workspace_name_required', 'A workspace needs a name.' );
        }

        $now  = current_time( 'mysql', true );
        $uuid = self::new_uuid();

        $ok = $wpdb->insert(
            self::table(),
            [
                'uuid'          => $uuid,
                'name'          => $clean,
                'status'        => self::STATUS_DRAFT,
                'base_source'   => 'live',
                'base_taken_at' => $now,
                'created_by'    => $user_id ? (int) $user_id : null,
                'created_at'    => $now,
                'updated_at'    => $now,
            ],
            [ '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' ]
        );

        if ( ! $ok ) {
            return self::error( 've_workspace_not_created', 'The workspace could not be saved.' );
        }

        return self::get( (int) $wpdb->insert_id );
    }

    /** @return array|null */
    public static function get( int $id ) {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE id = %d', $id ),
            ARRAY_A
        );
        return $row ? self::shape( $row ) : null;
    }

    /** @return array|null */
    public static function get_by_uuid( string $uuid ) {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare( 'SELECT * FROM ' . self::table() . ' WHERE uuid = %s', $uuid ),
            ARRAY_A
        );
        return $row ? self::shape( $row ) : null;
    }

    /**
     * Active workspaces newest-touched first; archived ones only when asked for.
     * Archiving is how a workspace leaves the list without leaving the database,
     * so the default list must not show them and must not lose them.
     */
    public static function all( bool $include_archived = false ): array {
        global $wpdb;
        $sql = 'SELECT * FROM ' . self::table();
        if ( ! $include_archived ) {
            $sql .= $wpdb->prepare( ' WHERE status != %s', self::STATUS_ARCHIVED );
        }
        $sql .= ' ORDER BY updated_at DESC, id DESC';

        $rows = $wpdb->get_results( $sql, ARRAY_A );
        return array_map( [ __CLASS__, 'shape' ], is_array( $rows ) ? $rows : [] );
    }

    /** @return array|\WP_Error */
    public static function rename( int $id, $name ) {
        $clean = self::clean_name( $name );
        if ( '' === $clean ) {
            return self::error( 've_workspace_name_required', 'A workspace needs a name.' );
        }
        return self::update( $id, [ 'name' => $clean ], [ '%s' ] );
    }

    /** @return array|\WP_Error */
    public static function set_status( int $id, string $status ) {
        if ( ! in_array( $status, self::statuses(), true ) ) {
            return self::error( 've_workspace_bad_status', 'Unknown workspace status.' );
        }
        $fields  = [ 'status' => $status ];
        $formats = [ '%s' ];

        // Archiving records when, so a restored workspace can say how long it sat.
        $fields['archived_at']  = ( self::STATUS_ARCHIVED === $status ) ? current_time( 'mysql', true ) : null;
        $formats[]              = '%s';

        return self::update( $id, $fields, $formats );
    }

    /**
     * Permanent deletion. Separate from archiving on purpose: §96.3 requires a
     * destructive action to be its own explicit choice, never a side effect.
     *
     * Nothing about this touches Live. Discarding a workspace is not a rollback,
     * and this slice has nothing published to roll back to in the first place.
     *
     * @return true|\WP_Error
     */
    public static function discard( int $id ) {
        global $wpdb;
        $existing = self::get( $id );
        if ( ! $existing ) {
            return self::error( 've_workspace_missing', 'That workspace no longer exists.' );
        }
        $ok = $wpdb->delete( self::table(), [ 'id' => $id ], [ '%d' ] );
        if ( false === $ok ) {
            return self::error( 've_workspace_not_discarded', 'The workspace could not be discarded.' );
        }
        return true;
    }

    public static function count_active(): int {
        global $wpdb;
        return (int) $wpdb->get_var(
            $wpdb->prepare( 'SELECT COUNT(*) FROM ' . self::table() . ' WHERE status != %s', self::STATUS_ARCHIVED )
        );
    }

    // ── internals ──────────────────────────────────────────────────────────

    /** @return array|\WP_Error */
    private static function update( int $id, array $fields, array $formats ) {
        global $wpdb;

        $existing = self::get( $id );
        if ( ! $existing ) {
            return self::error( 've_workspace_missing', 'That workspace no longer exists.' );
        }

        $fields['updated_at'] = current_time( 'mysql', true );
        $formats[]            = '%s';

        $ok = $wpdb->update( self::table(), $fields, [ 'id' => $id ], $formats, [ '%d' ] );
        if ( false === $ok ) {
            return self::error( 've_workspace_not_updated', 'The workspace could not be updated.' );
        }
        return self::get( $id );
    }

    /**
     * One shape for every caller. The REST layer, the check harness and any
     * later UI read the same keys, so a column rename is one edit rather than a
     * hunt through call sites.
     */
    private static function shape( array $row ): array {
        return [
            'id'          => (int) $row['id'],
            'uuid'        => (string) $row['uuid'],
            'name'        => (string) $row['name'],
            'status'      => (string) $row['status'],
            'base'        => [
                'source'   => (string) $row['base_source'],
                'taken_at' => (string) $row['base_taken_at'],
            ],
            'created_by'  => isset( $row['created_by'] ) && null !== $row['created_by'] ? (int) $row['created_by'] : null,
            'created_at'  => (string) $row['created_at'],
            'updated_at'  => (string) $row['updated_at'],
            'archived_at' => empty( $row['archived_at'] ) ? null : (string) $row['archived_at'],
            // Stated, not implied. §100.1.d forbids a flat "isolated" claim, and
            // at this slice the honest answer is that nothing is isolated yet
            // because nothing is captured yet.
            'changes'     => 0,
            'isolation'   => 'none-yet',
        ];
    }

    /** @return \WP_Error|array */
    private static function error( string $code, string $message ) {
        if ( class_exists( '\WP_Error' ) ) {
            return new \WP_Error( $code, $message, [ 'status' => 400 ] );
        }
        return [ 'error' => $code, 'message' => $message ];
    }
}
