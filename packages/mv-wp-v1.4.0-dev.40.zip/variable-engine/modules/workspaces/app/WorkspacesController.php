<?php
/**
 * REST surface for the workspace record.
 *
 * Routes live under the existing VE_API_NAMESPACE rather than a namespace of
 * their own — AGENTS.md: preserve existing REST route names and shapes, and do
 * not stand up a parallel API for a new module.
 *
 *   GET    /workspaces                list active workspaces
 *   POST   /workspaces               create one
 *   GET    /workspaces/(?P<id>\d+)   read one
 *   POST   /workspaces/(?P<id>\d+)   rename, or change status
 *   DELETE /workspaces/(?P<id>\d+)   discard permanently
 *
 * Permissions reuse Routes::can_read / can_write, so a workspace is exactly as
 * protected as every other MV write and no new capability model is invented.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspacesController {

    /** @var \VE\API\Routes|null Reused for its permission callbacks. */
    private $routes;

    public function __construct( $routes = null ) {
        $this->routes = $routes;
    }

    public function register(): void {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes(): void {
        $ns = defined( 'VE_API_NAMESPACE' ) ? VE_API_NAMESPACE : 'variable-engine/v1';

        register_rest_route( $ns, '/workspaces', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'index' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'create' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/workspaces/(?P<id>\d+)', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'show' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'update' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'discard' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
    }

    // ── permissions ────────────────────────────────────────────────────────

    public function can_read( $request = null ): bool {
        if ( $this->routes && method_exists( $this->routes, 'can_read' ) ) {
            return (bool) $this->routes->can_read( $request );
        }
        return current_user_can( 'edit_posts' );
    }

    public function can_write( $request = null ): bool {
        if ( $this->routes && method_exists( $this->routes, 'can_write' ) ) {
            return (bool) $this->routes->can_write( $request );
        }
        return current_user_can( 'manage_options' );
    }

    // ── handlers ───────────────────────────────────────────────────────────

    public function index( $request ) {
        $include = $request ? (bool) $request->get_param( 'archived' ) : false;

        return rest_ensure_response( [
            'workspaces' => WorkspaceStore::all( $include ),
            'live'       => [
                // What a workspace is measured against. Named here so the client
                // never has to assume "the current site" means anything else.
                'source' => 'live',
                'url'    => home_url( '/' ),
            ],
            // §100.1.d. The client must never print a flat "isolated"; at this
            // slice the only honest answer is that no object is captured yet.
            'isolation'  => [
                'structural' => [],
                'runtime'    => [],
                'note'       => 'No object families are captured yet. Creating a workspace records an intention, not a change.',
            ],
        ] );
    }

    public function create( $request ) {
        $result = WorkspaceStore::create(
            $request->get_param( 'name' ),
            get_current_user_id()
        );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( [ 'workspace' => $result ] );
    }

    public function show( $request ) {
        $workspace = WorkspaceStore::get( (int) $request['id'] );
        if ( ! $workspace ) {
            return new \WP_Error( 've_workspace_missing', 'That workspace no longer exists.', [ 'status' => 404 ] );
        }
        return rest_ensure_response( [ 'workspace' => $workspace ] );
    }

    /**
     * Rename and status are one route because they are one edit to the owner.
     * Both may arrive together; neither is required.
     */
    public function update( $request ) {
        $id     = (int) $request['id'];
        $name   = $request->get_param( 'name' );
        $status = $request->get_param( 'status' );

        if ( null === $name && null === $status ) {
            return new \WP_Error( 've_workspace_nothing_to_do', 'Send a name, a status, or both.', [ 'status' => 400 ] );
        }

        if ( null !== $name ) {
            $result = WorkspaceStore::rename( $id, $name );
            if ( is_wp_error( $result ) ) {
                return $result;
            }
        }
        if ( null !== $status ) {
            $result = WorkspaceStore::set_status( $id, (string) $status );
            if ( is_wp_error( $result ) ) {
                return $result;
            }
        }

        return rest_ensure_response( [ 'workspace' => WorkspaceStore::get( $id ) ] );
    }

    public function discard( $request ) {
        $result = WorkspaceStore::discard( (int) $request['id'] );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        // Said plainly in the response, because the client shows it to a person
        // who has just deleted something: discarding is not rolling back.
        return rest_ensure_response( [
            'discarded' => true,
            'live'      => 'unchanged',
        ] );
    }
}
