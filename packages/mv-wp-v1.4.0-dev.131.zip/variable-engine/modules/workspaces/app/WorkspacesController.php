<?php
/**
 * REST surface for the workspace record.
 *
 * Routes live under the existing VE_API_NAMESPACE rather than a namespace of
 * their own — AGENTS.md: preserve existing REST route names and shapes, and do
 * not stand up a parallel API for a new module.
 *
 *   GET    /workspaces                list active workspaces
 *   POST   /workspaces               create one
 *   GET    /workspaces/(?P<id>\d+)   read one
 *   POST   /workspaces/(?P<id>\d+)   rename, or change status
 *   DELETE /workspaces/(?P<id>\d+)   discard permanently
 *
 * Permissions reuse Routes::can_read / can_write, so a workspace is exactly as
 * protected as every other MV write and no new capability model is invented.
 *
 * @package VE\Modules\Workspaces
 */

namespace VE\Modules\Workspaces;

defined( 'ABSPATH' ) || exit;

final class WorkspacesController {

    /** @var \VE\API\Routes|null Reused for its permission callbacks. */
    private $routes;

    public function __construct( $routes = null ) {
        $this->routes = $routes;
    }

    public function register(): void {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes(): void {
        $ns = defined( 'VE_API_NAMESPACE' ) ? VE_API_NAMESPACE : 'variable-engine/v1';

        register_rest_route( $ns, '/workspaces', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'index' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'create' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        /* Slice 2. The objects a workspace holds, and the shadows behind them. */
        /* Slice 8. What happened to Live while this workspace was open - the
           repaired leaks and the retained conflicts. Read-only: §93.6 makes
           resolving a conflict a decision a person takes, not one an endpoint
           takes for them, so there is deliberately no way to clear one here. */
        register_rest_route( $ns, '/workspaces/(?P<id>\d+)/lifecycle', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'lifecycle' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
        ] );

        register_rest_route( $ns, '/workspaces/(?P<id>\d+)/objects', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'objects' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'add_object' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        /* Slice 5. Preflight is a GET because it changes nothing a person
           would notice - it re-reads the workspace and says what publishing
           would do. Publish is a POST, and it is the only route in this module
           that writes to a published page. */
        register_rest_route( $ns, '/workspaces/(?P<id>\d+)/preflight', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'preflight' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/workspaces/(?P<id>\d+)/publish', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'publish' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        /* Slice 6. Rollback is addressed by RELEASE rather than by workspace,
           because that is what a person picks from a history - and because §113
           computes supersession per object against everything that landed
           after that release, whichever workspace it came from. */
        register_rest_route( $ns, '/workspaces/releases/(?P<release>\d+)/rollback-preflight', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'rollback_preflight' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/workspaces/releases/(?P<release>\d+)/rollback', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'rollback' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/workspaces/(?P<id>\d+)/releases', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'releases' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/workspaces/(?P<id>\d+)/candidates', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'candidates' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/workspaces/objects/(?P<object>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'remove_object' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/workspaces/objects/(?P<object>\d+)/builder-url', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'builder_url' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        /* SLICE 3 - private preview. Issuing and revoking need the same right
           as opening the builder. Redeeming is checked INSIDE the handler
           instead: a permission_callback that refused would answer 401, and a
           401 tells an anonymous caller the token was real. */
        register_rest_route( $ns, '/workspaces/objects/(?P<object>\d+)/preview', [
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'issue_preview' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'revoke_preview' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        /* There is no REST route for redeeming any more. REST cookie
           authentication cannot serve a link a person opens in a browser: with no
           nonce it zeroes the user, and with a nonce in the URL anyone but that
           one session is rejected by WordPress with a 403 before MV runs - which
           made a withdrawn link and a logged-out visitor answer differently.
           WorkspacePreview::handle_request() redeems on the front end instead. */

        register_rest_route( $ns, '/workspaces/(?P<id>\d+)', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'show' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'update' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'discard' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );
    }

    // ── permissions ────────────────────────────────────────────────────────

    public function can_read( $request = null ): bool {
        if ( $this->routes && method_exists( $this->routes, 'can_read' ) ) {
            return (bool) $this->routes->can_read( $request );
        }
        return current_user_can( 'edit_posts' );
    }

    public function can_write( $request = null ): bool {
        if ( $this->routes && method_exists( $this->routes, 'can_write' ) ) {
            return (bool) $this->routes->can_write( $request );
        }
        return current_user_can( 'manage_options' );
    }

    // ── handlers ───────────────────────────────────────────────────────────

    public function index( $request ) {
        $include = $request ? (bool) $request->get_param( 'archived' ) : false;

        return rest_ensure_response( [
            'workspaces' => WorkspaceStore::all( $include ),
            'live'       => [
                // What a workspace is measured against. Named here so the client
                // never has to assume "the current site" means anything else.
                'source' => 'live',
                'url'    => home_url( '/' ),
            ],
            // §100.1.d. The client must never print a flat "isolated"; at this
            // slice the only honest answer is that no object is captured yet.
            'isolation'  => [
                'structural' => [],
                'runtime'    => [],
                'note'       => 'No object families are captured yet. Creating a workspace records an intention, not a change.',
            ],
        ] );
    }

    public function create( $request ) {
        $result = WorkspaceStore::create(
            $request->get_param( 'name' ),
            get_current_user_id()
        );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( [ 'workspace' => $result ] );
    }

    public function show( $request ) {
        $id = (int) $request['id'];
        if ( class_exists( __NAMESPACE__ . '\\WorkspaceSnapshot' ) && WorkspaceStore::get( $id ) ) {
            WorkspaceSnapshot::refresh_all( $id );
        }
        $workspace = WorkspaceStore::get( $id );
        if ( ! $workspace ) {
            return new \WP_Error( 've_workspace_missing', 'That workspace no longer exists.', [ 'status' => 404 ] );
        }
        return rest_ensure_response( [ 'workspace' => $workspace ] );
    }

    /**
     * Rename and status are one route because they are one edit to the owner.
     * Both may arrive together; neither is required.
     */
    public function update( $request ) {
        $id     = (int) $request['id'];
        $name   = $request->get_param( 'name' );
        $status = $request->get_param( 'status' );

        if ( null === $name && null === $status ) {
            return new \WP_Error( 've_workspace_nothing_to_do', 'Send a name, a status, or both.', [ 'status' => 400 ] );
        }

        if ( null !== $name ) {
            $result = WorkspaceStore::rename( $id, $name );
            if ( is_wp_error( $result ) ) {
                return $result;
            }
        }
        if ( null !== $status ) {
            $result = WorkspaceStore::set_status( $id, (string) $status );
            if ( is_wp_error( $result ) ) {
                return $result;
            }
        }

        return rest_ensure_response( [ 'workspace' => WorkspaceStore::get( $id ) ] );
    }

    public function objects( $request ) {
        $id = (int) $request['id'];
        if ( ! WorkspaceStore::get( $id ) ) {
            return new \WP_Error( 've_workspace_missing', 'That workspace no longer exists.', [ 'status' => 404 ] );
        }
        // Slice 4: opening a workspace is the moment to re-read it. Every
        // object is re-hashed and its §19 state recorded before the list is
        // shaped, so the panel is never drawing a comparison from last week.
        if ( class_exists( __NAMESPACE__ . '\\WorkspaceSnapshot' ) ) {
            WorkspaceSnapshot::refresh_all( $id );
        }
        return rest_ensure_response( [
            'groups'    => WorkspaceObjectMap::grouped( $id ),
            'count'     => WorkspaceObjectMap::count( $id ),
            'changes'   => class_exists( __NAMESPACE__ . '\\WorkspaceSnapshot' )
                ? WorkspaceSnapshot::summary( $id, false )
                : null,
            'isolation' => self::isolation_report( $id ),
        ] );
    }

    public function preflight( $request ) {
        $id = (int) $request['id'];
        if ( ! WorkspaceStore::get( $id ) ) {
            return new \WP_Error( 've_workspace_missing', 'That workspace no longer exists.', [ 'status' => 404 ] );
        }
        return rest_ensure_response( WorkspacePublish::preflight( $id ) );
    }

    /**
     * The one route that writes to a published page.
     *
     * It re-runs its own preflight rather than trusting the one the panel
     * showed: what the owner saw a moment ago is not what the site says now,
     * and a conflict that appeared in between must still block.
     */
    public function publish( $request ) {
        $id = (int) $request['id'];
        if ( ! WorkspaceStore::get( $id ) ) {
            return new \WP_Error( 've_workspace_missing', 'That workspace no longer exists.', [ 'status' => 404 ] );
        }
        $result = WorkspacePublish::publish( $id );
        if ( is_wp_error( $result ) ) {
            return $result;
        }

        /* Slice 10, and the order is the whole of it: AFTER apply, so the
           options already hold the published values and Bricks' own generators
           read the right thing. Called here rather than hooked because "once,
           after apply" is a position in a sequence and not an event.

           The workspace's own copies go at the same time. They described a
           state that is now Live, and a stale directory left behind is one an
           editor could be handed again by a later session. */
        if ( class_exists( '\VE\Modules\Workspaces\WorkspaceCss' ) ) {
            $result['css'] = WorkspaceCss::promote( $id );
            WorkspaceCss::forget( $id );
        }

        return rest_ensure_response( $result );
    }

    public function rollback_preflight( $request ) {
        return rest_ensure_response( WorkspaceRollback::preflight( (int) $request['release'] ) );
    }

    /**
     * The second route that writes to a published page, and the only one that
     * writes a value the owner did not choose - it restores one they had. It
     * re-runs its own preflight for the same reason publish does: what the
     * panel showed a moment ago is not what the site says now.
     */
    public function rollback( $request ) {
        return rest_ensure_response( WorkspaceRollback::rollback( (int) $request['release'] ) );
    }

    public function releases( $request ) {
        $id = (int) $request['id'];
        if ( ! WorkspaceStore::get( $id ) ) {
            return new \WP_Error( 've_workspace_missing', 'That workspace no longer exists.', [ 'status' => 404 ] );
        }
        return rest_ensure_response( [ 'releases' => WorkspaceRelease::all( $id ) ] );
    }

    public function candidates( $request ) {
        $id = (int) $request['id'];
        if ( ! WorkspaceStore::get( $id ) ) {
            return new \WP_Error( 've_workspace_missing', 'That workspace no longer exists.', [ 'status' => 404 ] );
        }
        return rest_ensure_response( [
            'pages' => BricksPageAdapter::candidates( $id, (string) $request->get_param( 'search' ) ),
        ] );
    }

    public function add_object( $request ) {
        $result = BricksPageAdapter::create_shadow(
            (int) $request['id'],
            (int) $request->get_param( 'live_id' )
        );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        // 'live' is stated on the response because the client shows this to a
        // person who has just copied a published page. Nothing about Live moved.
        return rest_ensure_response( [ 'object' => $result, 'live' => 'unchanged' ] );
    }

    public function remove_object( $request ) {
        $result = BricksPageAdapter::remove_shadow( (int) $request['object'] );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        return rest_ensure_response( [ 'removed' => true, 'live' => 'unchanged' ] );
    }

    public function builder_url( $request ) {
        $url = BricksPageAdapter::builder_url( (int) $request['object'] );
        if ( is_wp_error( $url ) ) {
            return $url;
        }
        return rest_ensure_response( [ 'url' => $url ] );
    }

    /** SLICE 3 - a private preview link for one object in a workspace. */
    public function issue_preview( $request ) {
        $issued = WorkspacePreview::issue( (int) $request['object'] );
        if ( is_wp_error( $issued ) ) {
            return $issued;
        }
        WorkspacePreview::send_headers();
        return rest_ensure_response( $issued );
    }

    /** Withdraw one link, or every link this object has. */
    public function revoke_preview( $request ) {
        $object  = (int) $request['object'];
        $token   = (string) $request->get_param( 'token' );
        $removed = '' !== $token
            ? WorkspacePreview::revoke( $token )
            : WorkspacePreview::revoke_object( $object );
        return rest_ensure_response( [
            'revoked' => $removed,
            'live'    => WorkspacePreview::count_for_object( $object ),
        ] );
    }

    /**
     * What MV may honestly claim for this workspace right now, per object family.
     * §100.1.d forbids a flat "isolated", so this is computed from what the
     * workspace actually holds rather than written down as a constant that would
     * go on being true after it stopped being true.
     */
    private static function isolation_report( $id ) {
        $structural = [];
        $runtime    = [];
        foreach ( WorkspaceObjectMap::all( (int) $id ) as $object ) {
            $label = 'bricks_template' === $object['object_type'] ? 'Templates' : 'Pages';
            if ( WorkspaceObjectMap::ISO_RUNTIME === $object['isolation'] ) {
                if ( ! in_array( $label, $runtime, true ) ) {
                    $runtime[] = $label;
                }
            } elseif ( ! in_array( $label, $structural, true ) ) {
                $structural[] = $label;
            }
        }
        return [
            'structural' => $structural,
            'runtime'    => $runtime,
            'note'       => $structural
                ? 'Pages and templates write to their own workspace copy, so a save cannot reach Live whether or not MV is running. Global classes, variables and theme styles are not held yet - editing those still changes Live.'
                : 'No object families are captured yet. Creating a workspace records an intention, not a change.',
        ];
    }

    /**
     * Slice 8 - §100.1.4, the half that says "never silent".
     *
     * A recovered leak and a retained conflict are both things that happened to
     * the live site while somebody was not looking, so there has to be somewhere
     * to look at them. The builder polls this route too: what it is asking is
     * whether MV is still answering, and if MV is not, the request does not
     * arrive at all, which is the answer.
     */
    public function lifecycle( $request ) {
        $id = (int) $request['id'];

        if ( ! class_exists( '\VE\Modules\Workspaces\WorkspaceFingerprint' ) ) {
            return rest_ensure_response( [
                'alive'     => true,
                'watched'   => false,
                'events'    => [],
                'conflicts' => [],
            ] );
        }

        return rest_ensure_response( [
            'alive'     => true,
            'workspace' => $id,
            'watched'   => in_array( $id, WorkspaceFingerprint::index(), true ),
            'events'    => WorkspaceFingerprint::events( $id ),
            'conflicts' => WorkspaceFingerprint::conflicts( $id ),
        ] );
    }

    public function discard( $request ) {
        // Shadows first: the map is the only thing that knows they exist, so
        // removing it before them would strand every shadow post as an orphan.
        BricksPageAdapter::remove_all( (int) $request['id'] );

        /* Slices 7 and 8 leave two options behind per workspace - the runtime
           values and the fingerprint - and neither is reachable once the row is
           gone. §92 protects UNPUBLISHED payloads from being cleaned up by a
           deactivation; a discard is the explicit destructive cleanup that same
           line allows for, so this is where they go. */
        if ( class_exists( '\VE\Modules\Workspaces\WorkspaceRuntime' ) ) {
            WorkspaceRuntime::forget( (int) $request['id'] );
        }
        if ( class_exists( '\VE\Modules\Workspaces\WorkspaceFingerprint' ) ) {
            WorkspaceFingerprint::forget( (int) $request['id'] );
        }
        if ( class_exists( '\VE\Modules\Workspaces\WorkspaceCss' ) ) {
            WorkspaceCss::forget( (int) $request['id'] );
        }
        $result = WorkspaceStore::discard( (int) $request['id'] );
        if ( is_wp_error( $result ) ) {
            return $result;
        }
        // Said plainly in the response, because the client shows it to a person
        // who has just deleted something: discarding is not rolling back.
        return rest_ensure_response( [
            'discarded' => true,
            'live'      => 'unchanged',
        ] );
    }
}
