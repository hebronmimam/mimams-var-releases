(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;

  var Core = window.MimamsBarCore || {};
  var readStoredSettings = function () {
    if (window.MimamsBarCore && window.MimamsBarCore.readStoredSettings) {
      return window.MimamsBarCore.readStoredSettings();
    }
    try {
      var raw = window.localStorage ? window.localStorage.getItem('mimamsBarSettings') : '';
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  };
  var writeStoredSettings = function (value) {
    if (window.MimamsBarCore && window.MimamsBarCore.writeStoredSettings) {
      return window.MimamsBarCore.writeStoredSettings(value);
    }
    try {
      if (window.localStorage) {
        window.localStorage.setItem('mimamsBarSettings', JSON.stringify(value || {}));
      }
    } catch (e) {}
  };
  var getEffectiveShortcut = Core.getEffectiveShortcut || function () { return { alt: true, key: 'q' }; };
  var globalPanelDOMObserver = null;
  var globalReSyncTimer = null;

  function minimizeStructurePanel(panel) {
    if (!panel) return;
    var rect = safeRect(panel);
    if (rect) {
      panel.style.setProperty('--current-left', Math.round(rect.left) + 'px');
      panel.style.setProperty('--current-top', Math.round(rect.top) + 'px');
    }
    panel.classList.add('mimams-bar-structure-minimized');
    var rail = document.querySelector('.mimams-bar-floating-structure-rail');
    if (rail) {
      rail.classList.add('mimams-bar-structure-minimized');
    }
    if (document.getElementById('mimams-bar-minimized-structure')) return;
    var btn = document.createElement('button');
    btn.id = 'mimams-bar-minimized-structure';
    btn.setAttribute('type', 'button');
    btn.setAttribute('data-tooltip', 'Restore Structure');
    btn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" style="width: 18px; height: 18px; display: block;"><rect width="256" height="256" fill="none"/><line x1="88" y1="80" x2="88" y2="176" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><line x1="88" y1="128" x2="160" y2="128" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><circle cx="88" cy="80" r="24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><circle cx="88" cy="176" r="24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><circle cx="184" cy="128" r="24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/></svg>';
    btn.addEventListener('click', function () {
      restoreStructurePanel(panel);
    });
    document.body.appendChild(btn);
  }

  function restoreStructurePanel(panel) {
    if (panel) {
      panel.classList.remove('mimams-bar-structure-minimized');
    }
    var rail = document.querySelector('.mimams-bar-floating-structure-rail');
    if (rail) {
      rail.classList.remove('mimams-bar-structure-minimized');
    }
    var btn = document.getElementById('mimams-bar-minimized-structure');
    if (btn && btn.parentNode) {
      btn.parentNode.removeChild(btn);
    }
  }

  function removeMinimizedStructureButton() {
    var btn = document.getElementById('mimams-bar-minimized-structure');
    if (btn && btn.parentNode) {
      btn.parentNode.removeChild(btn);
    }
  }

  function restoreFloatingPanelStyle(node) {
    if (!node || !node.style) return;
    var props = ['position','z-index','top','left','right','bottom','width','height','max-height','min-height','inset-block-start','inset-inline-start','inset-inline-end','inset-block-end','inline-size','max-inline-size','min-inline-size','block-size','max-block-size','min-block-size','opacity','overflow','resize','padding-block-start','box-shadow','transition','border','border-radius','background','backdrop-filter','transform','will-change','touch-action','contain','display'];
    props.forEach(function (prop) { try { node.style.removeProperty(prop); } catch (e) {} });
    node.removeAttribute('data-mimams-bar-float-height-initialized');
    node.removeAttribute('data-mimams-bar-float-persist-key');
  }

  function clearDynamicPanelClasses() {
    var ownedRail = document.getElementById('mimams-bar-owned-structure-rail');
    if (ownedRail && ownedRail.parentNode) ownedRail.parentNode.removeChild(ownedRail);
    document.querySelectorAll('.mimams-bar-external-rail-hidden').forEach(function (node) {
      node.classList.remove('mimams-bar-external-rail-hidden');
    });
    document.querySelectorAll('.mimams-bar-hidden-elements-panel, .mimams-bar-floating-elements-panel, .mimams-bar-floating-structure-panel, .mimams-bar-floating-structure-rail, .mimams-bar-panel-host, [data-mimams-bar-float-side]').forEach(function (node) {
      node.classList.remove('mimams-bar-hidden-elements-panel', 'mimams-bar-floating-elements-panel', 'mimams-bar-floating-structure-panel', 'mimams-bar-floating-structure-rail', 'mimams-bar-floating-panel-ready', 'mimams-bar-panel-host', 'mimams-bar-structure-minimized');
      node.querySelectorAll('.mimams-bar-float-handle, .mimams-bar-float-minimize, :scope > .mimams-bar-float-resize').forEach(function (handle) { handle.remove(); });
      node.removeAttribute('data-mimams-bar-float-side');
      
      if (node._originalParent) {
        try { node._originalParent.insertBefore(node, node._originalSibling); } catch (e) {}
        delete node._originalParent;
        delete node._originalSibling;
      }
      
      restoreFloatingPanelStyle(node);
    });
    removeMinimizedStructureButton();
    if (globalPanelDOMObserver) {
      globalPanelDOMObserver.disconnect();
      globalPanelDOMObserver = null;
    }
  }


  function cleanupStalePanelClasses(activeNodes) {
    activeNodes = activeNodes || [];
    function isActive(node) { return activeNodes.indexOf(node) !== -1; }

    var hasStructure = false;
    for (var i = 0; i < activeNodes.length; i++) {
      if (activeNodes[i] && activeNodes[i].classList && activeNodes[i].classList.contains('mimams-bar-floating-structure-panel')) {
        hasStructure = true;
        break;
      }
    }
    if (!hasStructure) {
      removeMinimizedStructureButton();
    }

    document.querySelectorAll('.mimams-bar-hidden-elements-panel, .mimams-bar-floating-elements-panel, .mimams-bar-floating-structure-panel, .mimams-bar-floating-structure-rail, .mimams-bar-panel-host, [data-mimams-bar-float-side]').forEach(function (node) {
      if (isActive(node)) return;
      
      var isRail = node.classList.contains('mimams-bar-floating-structure-rail');
      var structureMinimized = !!document.getElementById('mimams-bar-minimized-structure');

      node.classList.remove('mimams-bar-hidden-elements-panel', 'mimams-bar-floating-elements-panel', 'mimams-bar-floating-structure-panel', 'mimams-bar-floating-structure-rail', 'mimams-bar-floating-panel-ready', 'mimams-bar-panel-host', 'is-dragging');
      if (!isRail || !structureMinimized) {
        node.classList.remove('mimams-bar-structure-minimized');
      }
      
      node.querySelectorAll('.mimams-bar-float-handle, .mimams-bar-float-minimize, :scope > .mimams-bar-float-resize').forEach(function (handle) { handle.remove(); });
      node.removeAttribute('data-mimams-bar-float-side');
      
      if (node._originalParent) {
        try { node._originalParent.insertBefore(node, node._originalSibling); } catch (e) {}
        delete node._originalParent;
        delete node._originalSibling;
      }
      
      restoreFloatingPanelStyle(node);
    });
  }

  function safeRect(node) {
    try { return node && node.getBoundingClientRect ? node.getBoundingClientRect() : null; } catch (e) { return null; }
  }

  function clampFloatPosition(left, top, width, height) {
    width = Math.max(160, Math.min(width || 320, Math.max(160, window.innerWidth - 16)));
    height = Math.max(160, Math.min(height || 360, Math.max(160, window.innerHeight - 46)));
    var maxLeft = Math.max(8, window.innerWidth - width - 8);
    var maxTop = Math.max(38, window.innerHeight - height - 8);
    return {
      left: Math.round(Math.max(8, Math.min(maxLeft, isNaN(left) ? 8 : left))),
      top: Math.round(Math.max(38, Math.min(maxTop, isNaN(top) ? 38 : top)))
    };
  }

  function applyFixedPosition(node, left, top) {
    if (!node || !node.style) return;
    node.style.setProperty('top', Math.round(top) + 'px', 'important');
    node.style.setProperty('left', Math.round(left) + 'px', 'important');
    node.style.setProperty('right', 'auto', 'important');
    node.style.setProperty('bottom', 'auto', 'important');
    node.style.setProperty('inset-block-start', Math.round(top) + 'px', 'important');
    node.style.setProperty('inset-inline-start', Math.round(left) + 'px', 'important');
    node.style.setProperty('inset-inline-end', 'auto', 'important');
    node.style.setProperty('--current-left', Math.round(left) + 'px');
    node.style.setProperty('--current-top', Math.round(top) + 'px');
  }

  function clampFloatingNode(node) {
    var rect = safeRect(node);
    if (!rect) return null;
    var pos = clampFloatPosition(rect.left, rect.top, rect.width, rect.height);
    applyFixedPosition(node, pos.left, pos.top);
    return pos;
  }

  function positionStructureRail(rail, panel, isMinimized) {
    if (!rail || !panel) return;
    var sr = safeRect(panel);
    if (!sr) return;
    rail.classList.add('mimams-bar-floating-structure-rail');
    rail.setAttribute('data-mimams-bar-float-side', 'right');
    rail.style.removeProperty('transform');
    rail.style.removeProperty('opacity');
    rail.style.removeProperty('visibility');
    if (isMinimized) {
      rail.classList.add('mimams-bar-structure-minimized');
    } else {
      rail.classList.remove('mimams-bar-structure-minimized');
    }
    rail.style.removeProperty('display');
    rail.style.setProperty('position', 'fixed', 'important');
    var railWidth = 44;
    var space = 10;
    var leftPos = sr.left + sr.width + space;
    if (leftPos + railWidth > window.innerWidth - 8) {
      leftPos = sr.left - railWidth - space;
    }
    leftPos = Math.max(8, Math.min(window.innerWidth - railWidth - 8, leftPos));
    var railTop = Math.max(38, Math.min(window.innerHeight - 120, sr.top));
    var railHeight = Math.max(120, Math.min(sr.height, window.innerHeight - railTop - 8));
    applyFixedPosition(rail, leftPos, railTop);
    rail.style.setProperty('height', Math.round(railHeight) + 'px', 'important');
    rail.style.setProperty('block-size', Math.round(railHeight) + 'px', 'important');
    rail.style.setProperty('z-index', '119965', 'important');
  }

  var cachedPanels = { elements: null, structure: null };
  var lastHeavyPanelScanAt = 0;

  function isConnected(node) {
    try { return !!(node && (node.isConnected || document.documentElement.contains(node))); } catch (e) { return false; }
  }

  function getCachedPanel(key, side) {
    var node = cachedPanels[key];
    if (isConnected(node) && isReasonableSidePanel(node, side)) return node;
    cachedPanels[key] = null;
    return null;
  }

  function rememberPanel(key, node) {
    if (node) cachedPanels[key] = node;
    return node;
  }

  function isReasonableSidePanel(node, side) {
    if (!node || node === document.body || node === document.documentElement) return false;
    
    // If it's already marked, it is our target, don't fail just because CSS hid it (width=0).
    if (node.classList && (node.classList.contains('mimams-bar-hidden-elements-panel') || 
        node.classList.contains('mimams-bar-floating-elements-panel') || 
        node.classList.contains('mimams-bar-floating-structure-panel'))) {
      return true;
    }

    var id = node.id || '';
    var isExactMatch = false;
    if (side === 'left' && (id === 'bricks-panel' || id === 'brx-panel' || (node.classList && (node.classList.contains('bricks-panel') || node.classList.contains('brx-panel'))))) {
      isExactMatch = true;
    }
    if (side === 'right' && (id === 'bricks-structure' || id === 'bricks-structure-resizable' || id === 'brx-structure' || (node.classList && (node.classList.contains('bricks-structure') || node.classList.contains('brx-structure'))))) {
      isExactMatch = true;
    }

    var rect = safeRect(node);
    if (!rect) return false;

    if (isExactMatch) {
      return true;
    }

    // Keep this deliberately narrow. Earlier versions could catch a large
    // builder wrapper and blank the whole screen. Only mark actual side panels.
    if (rect.width < 160 || rect.width > (side === 'right' ? 540 : 430) || rect.height < 250) return false;
    if (side === 'left') return rect.left >= -8 && rect.left < Math.min(460, window.innerWidth * 0.42);
    if (side === 'right') return rect.right <= window.innerWidth + 8 && rect.left > window.innerWidth * 0.48;
    return false;
  }


  function findPanelFromNode(node, side) {
    if (!node || !node.closest) return null;
    var current = node;
    var best = null;
    while (current && current !== document.body && current.nodeType === 1) {
      if (isReasonableSidePanel(current, side)) best = current;
      current = current.parentElement;
    }
    return best;
  }

  function textOf(node) {
    return [
      node && node.getAttribute && node.getAttribute('placeholder'),
      node && node.getAttribute && node.getAttribute('aria-label'),
      node && node.getAttribute && node.getAttribute('title'),
      node && node.textContent
    ].join(' ').replace(/\s+/g, ' ').trim().toLowerCase();
  }

  function findElementsPanel(options) {
    options = options || {};
    var cached = getCachedPanel('elements', 'left');
    if (cached) return cached;

    var direct = document.querySelector('#bricks-panel-elements, .bricks-panel-elements, #brx-panel-elements, .brx-panel-elements, [data-panel="elements"], [data-bricks-panel="elements"]');
    if (direct) {
      var panel = findPanelFromNode(direct, 'left') || direct;
      if (isReasonableSidePanel(panel, 'left')) return rememberPanel('elements', panel);
    }

    if (!options.forceHeavyScan) return null;

    var anchors = [];
    document.querySelectorAll('input[placeholder], [aria-label], [title], button, [role="tab"], [role="button"]').forEach(function (node) {
      var text = textOf(node);
      if (text.indexOf('search elements') !== -1 || text === 'elements' || text.indexOf('elements components') !== -1) anchors.push(node);
    });

    for (var i = 0; i < anchors.length; i++) {
      var panel = findPanelFromNode(anchors[i], 'left');
      if (panel) return rememberPanel('elements', panel);
    }
    return null;
  }

  function findStructurePanel(options) {
    options = options || {};
    var cached = getCachedPanel('structure', 'right');
    if (cached) return cached;

    var direct = document.querySelector('#bricks-structure, #bricks-structure-resizable, .bricks-structure, .brx-structure, #brx-structure, [data-panel="structure"], [data-bricks-panel="structure"]');
    if (direct) {
      var panel = findPanelFromNode(direct, 'right') || direct;
      if (isReasonableSidePanel(panel, 'right')) return rememberPanel('structure', panel);
    }

    if (!options.forceHeavyScan) return null;

    var anchors = [];
    document.querySelectorAll('input[placeholder], [aria-label], [title], button, [role="tab"], [role="button"], h1, h2, h3, h4').forEach(function (node) {
      var text = textOf(node);
      if (text === 'structure' || text.indexOf('structure') !== -1 && text.indexOf('search') !== -1) anchors.push(node);
    });

    for (var i = 0; i < anchors.length; i++) {
      var panel = findPanelFromNode(anchors[i], 'right');
      if (panel) return rememberPanel('structure', panel);
    }
    return null;
  }

  function ensureFloatingChrome(panel, side, Settings) {
    if (!panel || !panel.appendChild) return;
    panel.classList.add('mimams-bar-floating-panel-ready');
    panel.setAttribute('data-mimams-bar-float-side', side || 'left');

    var isElements = panel.classList.contains('mimams-bar-floating-elements-panel');
    var titleText = isElements ? 'Elements' : 'Structure';
    
    var header = panel.querySelector('#bricks-panel-header, .bricks-panel-header, #brx-panel-header, .brx-panel-header, #bricks-structure-header, .bricks-structure-header, #brx-structure-header, .brx-structure-header, header');
    
    if (!panel.querySelector('.mimams-bar-float-handle')) {
      var handle = document.createElement('div');
      handle.className = 'mimams-bar-float-handle';
      handle.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" style="width: 16px; height: 16px; display: block;"><rect width="256" height="256" fill="none"/><rect x="48" y="16" width="160" height="224" rx="16" opacity="0.2" fill="currentColor"/><circle cx="92" cy="60" r="12" fill="currentColor"/><circle cx="164" cy="60" r="12" fill="currentColor"/><circle cx="92" cy="128" r="12" fill="currentColor"/><circle cx="164" cy="128" r="12" fill="currentColor"/><circle cx="92" cy="196" r="12" fill="currentColor"/><circle cx="164" cy="196" r="12" fill="currentColor"/></svg>';
      handle.setAttribute('aria-label', 'Move panel');
      handle.setAttribute('data-tooltip', 'Move panel');
      
      var minBtn = null;
      if (!isElements) {
        minBtn = document.createElement('button');
        minBtn.className = 'mimams-bar-float-minimize';
        minBtn.setAttribute('type', 'button');
        minBtn.setAttribute('data-tooltip', 'Minimize structure panel');
        minBtn.innerHTML = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 256 256" style="width: 12px; height: 12px; display: block;"><rect width="256" height="256" fill="none"/><line x1="200" y1="56" x2="144" y2="112" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><polyline points="200,112 144,112 144,56" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><line x1="56" y1="200" x2="112" y2="144" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/><polyline points="56,144 112,144 112,200" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="16"/></svg>';
        
        minBtn.addEventListener('pointerdown', function (e) { e.stopPropagation(); });
        minBtn.addEventListener('mousedown', function (e) { e.stopPropagation(); });
        minBtn.addEventListener('mouseup', function (e) { e.stopPropagation(); });
        minBtn.addEventListener('pointerup', function (e) { e.stopPropagation(); });
        minBtn.addEventListener('click', function (e) {
          e.stopPropagation();
          minimizeStructurePanel(panel);
        });
      }
      
      if (isElements || !header) {
        panel.appendChild(handle);
        if (minBtn) panel.appendChild(minBtn);
      } else {
        var titleEl = header.querySelector('.title');
        if (titleEl) {
          var group = document.createElement('div');
          group.className = 'mimams-bar-float-header-group';
          header.insertBefore(group, titleEl);
          group.appendChild(handle);
          if (minBtn) group.appendChild(minBtn);
          group.appendChild(titleEl);
        } else {
          header.insertBefore(handle, header.firstChild);
          if (minBtn) header.insertBefore(minBtn, handle.nextSibling);
        }
      }
      bindFloatingDrag(panel, handle, side || 'left', Settings);
    }
 
    if (!panel.querySelector(':scope > .mimams-bar-float-resize')) {
      var resize = document.createElement('div');
      resize.className = 'mimams-bar-float-resize';
      resize.setAttribute('data-tooltip', 'Resize');
      panel.appendChild(resize);
      bindFloatingResize(panel, resize, Settings, side || 'left');
    }
 
    applyFloatingPanelStylesAndRail(panel, side, Settings);
 
    if (!panel._mimamsBarStyleObserver) {
      panel._mimamsBarStyleObserver = new MutationObserver(function() {
        if (panel.classList.contains('is-dragging') || document.body.classList.contains('mimams-bar-floating-dragging')) {
          return;
        }
        var posVal = panel.style.getPropertyValue('position');
        var displayVal = panel.style.getPropertyValue('display');
        var hasTop = panel.style.getPropertyValue('top');
        var hasLeft = panel.style.getPropertyValue('left');
        var isMin = panel.classList.contains('mimams-bar-structure-minimized') || !!document.getElementById('mimams-bar-minimized-structure');

        if (posVal !== 'fixed' || !hasTop || !hasLeft || (displayVal === 'none' && !isMin)) {
          panel._mimamsBarStyleObserver.disconnect();
          applyFloatingPanelStylesAndRail(panel, side, Settings);
          panel._mimamsBarStyleObserver.observe(panel, { attributes: true, attributeFilter: ['style', 'class'] });
        }
      });
      panel._mimamsBarStyleObserver.observe(panel, { attributes: true, attributeFilter: ['style', 'class'] });
    }
  }

  function observeRailStyles(rail, panel, side, Settings) {
    if (!rail) return;
    if (!rail._mimamsBarRailStyleObserver) {
      rail._mimamsBarRailStyleObserver = new MutationObserver(function() {
        if (panel.classList.contains('is-dragging') || document.body.classList.contains('mimams-bar-floating-dragging')) {
          return;
        }
        var posVal = rail.style.getPropertyValue('position');
        var leftVal = rail.style.getPropertyValue('left');
        var rightVal = rail.style.getPropertyValue('right');
        if (posVal !== 'fixed' || rightVal !== 'auto' || !leftVal) {
          rail._mimamsBarRailStyleObserver.disconnect();
          applyFloatingPanelStylesAndRail(panel, side, Settings);
          rail._mimamsBarRailStyleObserver.observe(rail, { attributes: true, attributeFilter: ['style', 'class'] });
        }
      });
      rail._mimamsBarRailStyleObserver.observe(rail, { attributes: true, attributeFilter: ['style', 'class'] });
    }
  }

  function applyFloatingPanelStylesAndRail(panel, side, Settings) {
    if (!panel) return;
    
    if (panel._mimamsBarStyleObserver) {
      panel._mimamsBarStyleObserver.disconnect();
    }
    var rail = side === 'right' ? findStructureRail(panel) : null;
    if (rail && rail._mimamsBarRailStyleObserver) {
      rail._mimamsBarRailStyleObserver.disconnect();
    }

    var isElements = panel.classList.contains('mimams-bar-floating-elements-panel');
    var key = side === 'right' ? 'structure' : 'elements';
    panel.setAttribute('data-mimams-bar-float-persist-key', key);
    var rectForBase = safeRect(panel) || { left: side === 'right' ? Math.max(12, window.innerWidth - 390) : 14, top: 62, width: side === 'right' ? 330 : 270, height: window.innerHeight - 100 };
    
    // Check if structure is minimized
    var isMinimized = panel.classList.contains('mimams-bar-structure-minimized') || (side === 'right' && !!document.getElementById('mimams-bar-minimized-structure'));
    if (isMinimized) {
      if (!panel.classList.contains('mimams-bar-structure-minimized')) {
        panel.classList.add('mimams-bar-structure-minimized');
      }
    } else {
      panel.classList.remove('mimams-bar-structure-minimized');
    }
    panel.style.removeProperty('display');

    panel.style.setProperty('position', 'fixed', 'important');
    panel.style.setProperty('z-index', '119960', 'important');
    panel.style.setProperty('inset-inline-end', 'auto', 'important');
    panel.style.setProperty('inline-size', Math.round(Math.max(220, Math.min(380, rectForBase.width || 300))) + 'px', 'important');
    panel.style.setProperty('top', Math.round(rectForBase.top || 62) + 'px', 'important');
    panel.style.setProperty('left', Math.round(rectForBase.left || (side === 'right' ? Math.max(12, window.innerWidth - 390) : 14)) + 'px', 'important');
    panel.style.setProperty('inset-block-start', Math.round(rectForBase.top || 62) + 'px', 'important');
    panel.style.setProperty('inset-inline-start', Math.round(rectForBase.left || (side === 'right' ? Math.max(12, window.innerWidth - 390) : 14)) + 'px', 'important');
    panel.style.setProperty('contain', 'layout paint', 'important');
    panel.style.setProperty('background', 'linear-gradient(180deg, var(--mimams-bar-panel-bg-2, rgba(17,23,28,.96)), var(--mimams-bar-panel-bg, rgba(13,18,22,.965)))', 'important');
    panel.style.setProperty('border', '1px solid rgba(255, 255, 255, 0.1)', 'important');
    panel.style.setProperty('border-radius', '10px', 'important');
    panel.style.setProperty('box-shadow', '0 24px 70px rgba(0, 0, 0, 0.42), inset 0 1px 0 rgba(255, 255, 255, 0.03)', 'important');
    panel.style.setProperty('backdrop-filter', 'blur(12px)', 'important');
    panel.style.setProperty('overflow', 'hidden', 'important');
    var saved = Settings && Settings.data && Settings.data.floatPanels && Settings.data.floatPanels[key] ? Settings.data.floatPanels[key] : null;
    var savedHeight = saved && typeof saved.height === 'number' ? Math.round(saved.height) + 'px' : '70dvh';
    panel.style.setProperty('block-size', savedHeight, 'important');
    panel.style.setProperty('max-block-size', savedHeight, 'important');
    panel.style.setProperty('height', savedHeight, 'important');
    panel.style.setProperty('max-height', savedHeight, 'important');
      
    var currentTop = saved && typeof saved.top === 'number' ? Math.round(saved.top) : Math.round(rectForBase.top || 62);
    var currentLeft = saved && typeof saved.left === 'number' ? Math.round(saved.left) : Math.round(rectForBase.left || (side === 'right' ? Math.max(12, window.innerWidth - 390) : 14));
    panel.style.setProperty('--current-left', currentLeft + 'px');
    panel.style.setProperty('--current-top', currentTop + 'px');

    if (saved) {
      if (typeof saved.top === 'number') { panel.style.setProperty('inset-block-start', Math.round(saved.top) + 'px', 'important'); panel.style.setProperty('top', Math.round(saved.top) + 'px', 'important'); }
      if (typeof saved.left === 'number') { panel.style.setProperty('inset-inline-start', Math.round(saved.left) + 'px', 'important'); panel.style.setProperty('left', Math.round(saved.left) + 'px', 'important'); }
    }
    panel.style.setProperty('inset-inline-end', 'auto', 'important');
    var clampedPos = clampFloatingNode(panel);
    if (clampedPos) {
      currentLeft = clampedPos.left;
      currentTop = clampedPos.top;
    }

    if (!panel.getAttribute('data-mimams-bar-float-height-initialized')) {
      if (!saved || typeof saved.height !== 'number') {
        panel.style.setProperty('block-size', '70dvh', 'important');
        panel.style.setProperty('max-block-size', '70dvh', 'important');
        panel.style.setProperty('height', '70dvh', 'important');
        panel.style.setProperty('max-height', '70dvh', 'important');
      }
      panel.setAttribute('data-mimams-bar-float-height-initialized', '1');
    }
      
    if (!isElements && !panel.querySelector('.mimams-bar-structure-wrapper')) {
      var wrapTargets = panel.querySelectorAll('#bricks-panel-header, main.panel-content, #brxcStructureTopContainer');
      if (wrapTargets.length > 0) {
        var wrapper = document.createElement('div');
        wrapper.className = 'mimams-bar-structure-wrapper';
        panel.insertBefore(wrapper, wrapTargets[0]);
        wrapTargets.forEach(function(el) { wrapper.appendChild(el); });
      }
    }

    if (side === 'right') {
      var activeRail = rail || findStructureRail(panel);
      if (activeRail) {
        if (activeRail.parentNode !== document.body) {
          document.body.appendChild(activeRail);
        }

        var lis = activeRail.querySelectorAll('li.brxc-right-sidebar-shortcuts');
        if (lis.length > 0 && !activeRail.querySelector('ul')) {
          var ul = document.createElement('ul');
          ul.style.display = 'flex';
          ul.style.flexDirection = 'column';
          ul.style.gap = '3rem';
          ul.style.margin = '0';
          ul.style.padding = '0';
          ul.style.listStyle = 'none';
          while (activeRail.firstChild) {
            ul.appendChild(activeRail.firstChild);
          }
          activeRail.appendChild(ul);
        }

        activeRail.querySelectorAll('[title]').forEach(function (el) {
          var t = el.getAttribute('title');
          if (t) {
            el.setAttribute('data-tooltip', t);
            el.removeAttribute('title');
          }
        });

        positionStructureRail(activeRail, panel, isMinimized);
        observeRailStyles(activeRail, panel, side, Settings);
      }
    }

    if (panel._mimamsBarStyleObserver) {
      panel._mimamsBarStyleObserver.observe(panel, { attributes: true, attributeFilter: ['style', 'class'] });
    }
    if (rail && rail._mimamsBarRailStyleObserver) {
      rail._mimamsBarRailStyleObserver.observe(rail, { attributes: true, attributeFilter: ['style', 'class'] });
    }
  }

  function persistFloatPanel(Settings, panel, side) {
    if (!Settings || !panel) return;
    var key = side === 'right' ? 'structure' : 'elements';
    var rect = safeRect(panel);
    if (!rect) return;
    Settings.data = Settings.data || {};
    Settings.data.floatPanels = Settings.data.floatPanels || {};
    Settings.data.floatPanels[key] = {
      top: Math.round(rect.top),
      left: Math.round(rect.left),
      height: Math.round(rect.height)
    };
    try { writeStoredSettings(Settings.data); } catch (e) {}
  }

  function ensureDragShield() {
    var shield = document.querySelector('.mimams-bar-floating-drag-shield');
    if (!shield) {
      shield = document.createElement('div');
      shield.className = 'mimams-bar-floating-drag-shield';
      document.body.appendChild(shield);
    }
    shield.hidden = false;
    shield.style.removeProperty('display');
    return shield;
  }

  function removeDragShield() {
    var shield = document.querySelector('.mimams-bar-floating-drag-shield');
    if (shield) {
      shield.hidden = true;
      shield.style.setProperty('display', 'none', 'important');
      if (shield.parentNode) {
        shield.parentNode.removeChild(shield);
      }
    }
  }

  function bindFloatingDrag(panel, handle, side, Settings) {
    if (!handle || handle._mimamsBarDragBound) return;
    handle._mimamsBarDragBound = true;
    var active = false;
    var lastPointerDownAt = 0;

    function begin(event) {
      if (active) return;
      if (event.type === 'mousedown') {
        if (event.button !== 0) return;
        if (lastPointerDownAt && Date.now && Date.now() - lastPointerDownAt < 900) return;
      } else if (event.type === 'pointerdown') {
        lastPointerDownAt = Date.now ? Date.now() : new Date().getTime();
      }
      if (!panel) return;
      active = true;
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
      try { if (event.pointerId != null && handle.setPointerCapture) handle.setPointerCapture(event.pointerId); } catch (eCapture) {}

      var rect = safeRect(panel) || { left: 8, top: 50, width: 300, height: 360 };
      var startX = event.clientX;
      var startY = event.clientY;
      var startLeft = rect.left;
      var startTop = rect.top;
      var panelWidth = rect.width || 300;
      var panelHeight = rect.height || 360;
      var dx = 0;
      var dy = 0;
      var raf = null;
      var shield = ensureDragShield();
      var rail = panel.classList.contains('mimams-bar-floating-structure-panel') ? (document.querySelector('.mimams-bar-floating-structure-rail') || findStructureRail(panel)) : null;

      document.body.classList.add('mimams-bar-floating-dragging');
      panel.classList.add('is-dragging');
      panel.style.setProperty('position', 'fixed', 'important');
      panel.style.setProperty('top', Math.round(startTop) + 'px', 'important');
      panel.style.setProperty('left', Math.round(startLeft) + 'px', 'important');
      panel.style.setProperty('inset-block-start', Math.round(startTop) + 'px', 'important');
      panel.style.setProperty('inset-inline-start', Math.round(startLeft) + 'px', 'important');
      panel.style.setProperty('inset-inline-end', 'auto', 'important');
      panel.style.setProperty('will-change', 'transform', 'important');
      panel.style.setProperty('touch-action', 'none', 'important');
      panel.style.setProperty('transition', 'none', 'important');

      function clampDelta() {
        var left = startLeft + dx;
        var top = startTop + dy;
        var pos = clampFloatPosition(left, top, panelWidth, panelHeight);
        left = pos.left;
        top = pos.top;
        dx = left - startLeft;
        dy = top - startTop;
      }

      function paint() {
        raf = null;
        clampDelta();
        panel.style.setProperty('transform', 'translate3d(' + Math.round(dx) + 'px,' + Math.round(dy) + 'px,0)', 'important');
        
        var activeRail = rail;
        if (activeRail && !activeRail.isConnected) {
          activeRail = document.querySelector('.mimams-bar-floating-structure-rail');
          rail = activeRail;
        }
        if (activeRail) {
          activeRail.style.setProperty('will-change', 'transform', 'important');
          activeRail.style.setProperty('transition', 'none', 'important');
          activeRail.style.setProperty('transform', 'translate3d(' + Math.round(dx) + 'px,' + Math.round(dy) + 'px,0)', 'important');
        }
      }

      function move(ev) {
        if (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          if (ev.stopImmediatePropagation) ev.stopImmediatePropagation();
          dx = ev.clientX - startX;
          dy = ev.clientY - startY;
        }
        if (!raf) raf = window.requestAnimationFrame(paint);
      }

      function cleanup(ev) {
        if (!active) return;
        active = false;
        // Do NOT preventDefault() or stopPropagation() on mouseup/pointerup.
        // This ensures the browser clears its active dragging state and click gestures.
        window.removeEventListener('pointermove', move, true);
        window.removeEventListener('pointerup', cleanup, true);
        window.removeEventListener('pointercancel', cleanup, true);
        window.removeEventListener('mousemove', move, true);
        window.removeEventListener('mouseup', cleanup, true);
        window.removeEventListener('blur', cleanup, true);
        if (shield) {
          shield.removeEventListener('pointermove', move, true);
          shield.removeEventListener('pointerup', cleanup, true);
          shield.removeEventListener('mousemove', move, true);
          shield.removeEventListener('mouseup', cleanup, true);
        }
        if (raf) window.cancelAnimationFrame(raf);
        clampDelta();
        var finalLeft = Math.round(startLeft + dx);
        var finalTop = Math.round(startTop + dy);
        panel.style.removeProperty('transform');
        applyFixedPosition(panel, finalLeft, finalTop);
        panel.style.removeProperty('will-change');
        panel.style.removeProperty('transition');
        
        var isMinimized = panel.classList.contains('mimams-bar-structure-minimized') || !!document.getElementById('mimams-bar-minimized-structure');
        if (rail) positionStructureRail(rail, panel, isMinimized);
        if (rail) {
          rail.style.removeProperty('transform');
          rail.style.removeProperty('will-change');
          rail.style.removeProperty('transition');
        }
        try { if (event.pointerId != null && handle.releasePointerCapture) handle.releasePointerCapture(event.pointerId); } catch (eRelease) {}
        removeDragShield();
        document.body.classList.remove('mimams-bar-floating-dragging');
        panel.classList.remove('is-dragging');
        if (rail) {
          observeRailStyles(rail, panel, side, Settings);
        }
        persistFloatPanel(Settings, panel, side);
      }

      window.addEventListener('pointermove', move, true);
      window.addEventListener('pointerup', cleanup, true);
      window.addEventListener('pointercancel', cleanup, true);
      window.addEventListener('mousemove', move, true);
      window.addEventListener('mouseup', cleanup, true);
      window.addEventListener('blur', cleanup, true);
      if (shield) {
        shield.addEventListener('pointermove', move, true);
        shield.addEventListener('pointerup', cleanup, true);
        shield.addEventListener('mousemove', move, true);
        shield.addEventListener('mouseup', cleanup, true);
      }
    }

    if (window.PointerEvent) handle.addEventListener('pointerdown', begin, true);
    else handle.addEventListener('mousedown', begin, true);
  }

  function bindFloatingResize(panel, resize, Settings, side) {
    if (!resize || resize._mimamsBarResizeBound) return;
    resize._mimamsBarResizeBound = true;
    resize.addEventListener('pointerdown', function (event) {
      if (!panel) return;
      event.preventDefault();
      event.stopPropagation();
      try { resize.setPointerCapture(event.pointerId); } catch (e) {}
      var rect = safeRect(panel) || { height: 360 };
      var startY = event.clientY;
      var startHeight = rect.height;
      var nextHeight = startHeight;
      var raf = null;
      document.body.classList.add('mimams-bar-floating-dragging');

      function paint() {
        raf = null;
        panel.style.setProperty('block-size', Math.round(nextHeight) + 'px', 'important');
        panel.style.setProperty('max-block-size', Math.round(nextHeight) + 'px', 'important');
        panel.style.setProperty('height', Math.round(nextHeight) + 'px', 'important');
        panel.style.setProperty('max-height', Math.round(nextHeight) + 'px', 'important');
        
        var rail = document.querySelector('.mimams-bar-floating-structure-rail');
        if (rail && panel.classList.contains('mimams-bar-floating-structure-panel')) {
          var rect = safeRect(panel);
          if (rect) {
            rail.style.setProperty('height', Math.round(Math.min(nextHeight, window.innerHeight - rect.top - 20)) + 'px', 'important');
            rail.style.setProperty('block-size', Math.round(Math.min(nextHeight, window.innerHeight - rect.top - 20)) + 'px', 'important');
          }
        }
      }

      function move(ev) {
        nextHeight = Math.max(220, Math.min(window.innerHeight - 70, startHeight + ev.clientY - startY));
        if (!raf) raf = window.requestAnimationFrame(paint);
      }

      function up() {
        document.removeEventListener('pointermove', move, true);
        document.removeEventListener('pointerup', up, true);
        if (raf) window.cancelAnimationFrame(raf);
        paint();
        clampFloatingNode(panel);
        document.body.classList.remove('mimams-bar-floating-dragging');
        if (panel.classList.contains('mimams-bar-floating-structure-panel')) {
          positionStructureRail(document.querySelector('.mimams-bar-floating-structure-rail') || findStructureRail(panel), panel, panel.classList.contains('mimams-bar-structure-minimized') || !!document.getElementById('mimams-bar-minimized-structure'));
        }
        persistFloatPanel(Settings, panel, side || panel.getAttribute('data-mimams-bar-float-side') || 'left');
        try { resize.releasePointerCapture(event.pointerId); } catch (e) {}
      }

      document.addEventListener('pointermove', move, true);
      document.addEventListener('pointerup', up, true);
    });
  }

  function findStructureRail(panel) {
    var owned = document.getElementById('mimams-bar-owned-structure-rail');
    if (owned) return owned;
    var direct = document.querySelector('.brxce-panel-shortcut__container, #brxce-panel-shortcut__container, .at-structure-shortcuts, #at-structure-shortcuts');
    if (direct) return direct;

    var rect = safeRect(panel);
    if (!rect || !document.elementsFromPoint) return null;
    var points = [
      [Math.min(window.innerWidth - 4, rect.right + 28), Math.max(40, rect.top + 80)],
      [Math.min(window.innerWidth - 4, rect.right + 28), Math.max(40, rect.top + rect.height / 2)],
      [Math.min(window.innerWidth - 4, rect.right + 48), Math.max(40, rect.top + 120)]
    ];
    for (var i = 0; i < points.length; i++) {
      var stack = [];
      try { stack = document.elementsFromPoint(points[i][0], points[i][1]) || []; } catch (e) { stack = []; }
      for (var j = 0; j < stack.length; j++) {
        var node = stack[j];
        if (!node || node === panel || panel.contains(node) || node === document.body) continue;
        var r = safeRect(node);
        if (!r) continue;
        if (r.width >= 22 && r.width <= 100 && r.height >= 160 && Math.abs(r.top - rect.top) < 140) return node;
      }
    }
    return null;
  }

  function findExternalStructureRail(panel) {
    return document.querySelector('.brxce-panel-shortcut__container:not(#mimams-bar-owned-structure-rail), #brxce-panel-shortcut__container, .at-structure-shortcuts, #at-structure-shortcuts');
  }

  function ensureOwnedStructureRail(panel, Settings) {
    if (!Settings.get('showShortcutPanel')) {
      var old = document.getElementById('mimams-bar-owned-structure-rail');
      if (old && old.parentNode) old.parentNode.removeChild(old);
      var external = findExternalStructureRail(panel);
      if (external) external.classList.remove('mimams-bar-external-rail-hidden');
      return null;
    }

    var rail = document.getElementById('mimams-bar-owned-structure-rail');
    if (!rail) {
      rail = document.createElement('div');
      rail.id = 'mimams-bar-owned-structure-rail';
      rail.className = 'mimams-bar-owned-structure-rail';
      document.body.appendChild(rail);
    }

    var source = findExternalStructureRail(panel);
    if (source && !rail.getAttribute('data-mimams-source-bound')) {
      var actions = source.querySelectorAll('button, a, li');
      var added = 0;
      var iconFor = function (label) {
        var text = String(label || '').toLowerCase();
        if (text.indexOf('structure') !== -1 || text.indexOf('layers') !== -1) return 'tree-structure';
        if (text.indexOf('style') !== -1 || text.indexOf('css') !== -1) return 'paint-brush';
        if (text.indexOf('class') !== -1 || text.indexOf('tag') !== -1) return 'tag';
        if (text.indexOf('template') !== -1 || text.indexOf('library') !== -1) return 'stack';
        if (text.indexOf('copy') !== -1 || text.indexOf('duplicate') !== -1) return 'copy';
        if (text.indexOf('delete') !== -1 || text.indexOf('trash') !== -1) return 'trash';
        if (text.indexOf('download') !== -1 || text.indexOf('export') !== -1) return 'download-simple';
        if (text.indexOf('image') !== -1 || text.indexOf('media') !== -1) return 'image';
        if (text.indexOf('more') !== -1 || text.indexOf('option') !== -1) return 'dots-three';
        return 'squares-four';
      };
      Array.prototype.slice.call(actions, 0, 12).forEach(function (action, idx) {
        var label = action.getAttribute('aria-label') || action.getAttribute('title') || action.getAttribute('data-tooltip') || action.getAttribute('data-balloon') || action.textContent || ('Shortcut ' + (idx + 1));
        if (!String(label).trim()) label = 'Shortcut ' + (idx + 1);
        var btn = document.createElement('button');
        btn.type = 'button';
        btn.className = 'mimams-bar-owned-rail-btn';
        btn.setAttribute('data-tooltip', String(label).trim());
        btn.innerHTML = '<i class="ph-duotone ph-' + iconFor(label) + '" aria-hidden="true"></i>';
        btn.addEventListener('click', function (ev) {
          ev.preventDefault();
          ev.stopPropagation();
          try { action.click(); } catch (e) {}
        });
        rail.appendChild(btn);
        added++;
      });
      if (!added) {
        rail.innerHTML = '<button type="button" class="mimams-bar-owned-rail-btn" data-tooltip="Structure"><i class="ph-duotone ph-tree-structure" aria-hidden="true"></i></button>';
      }
      rail.setAttribute('data-mimams-source-bound', '1');
      source.classList.add('mimams-bar-external-rail-hidden');
    } else if (!source && !rail.childNodes.length) {
      rail.innerHTML = '<button type="button" class="mimams-bar-owned-rail-btn" data-tooltip="Structure"><i class="ph-duotone ph-tree-structure" aria-hidden="true"></i></button>';
    }

    return rail;
  }

  function isBricksStillLoading() {
    var bodyClass = document.body ? String(document.body.className || '') : '';
    if (/loading|preload|bricks-is-loading|brx-is-loading/i.test(bodyClass)) return true;
    return !!document.querySelector('#bricks-preloader, .bricks-preloader, .brx-preloader, .bricks-loading, .brx-loading, .bricks-loading-screen, .brx-loading-screen');
  }

  function markSafeHosts(panel, activeArray, side) {
    if (!panel || !panel.parentElement) return;
    var current = panel.parentElement;
    // Walk up the DOM to mark intermediate wrappers, but stop safely before marking the whole app layout.
    while (current && current !== document.body && current.nodeType === 1) {
      var rect = safeRect(current);
      if (rect && rect.width > 550) break; // Don't collapse the main flex container!
      current.classList.add('mimams-bar-panel-host');
      current.setAttribute('data-mimams-bar-float-side', side);
      if (activeArray) activeArray.push(current);
      current = current.parentElement;
    }
  }

  var lastPanelSignature = '';
  function markPanels(Settings, options) {
    if (globalPanelDOMObserver) {
      globalPanelDOMObserver.disconnect();
    }
    options = options || {};
    var hideElements = !!Settings.get('hideElements') && !Settings.get('floatElements');
    var floatElements = !!Settings.get('floatElements');
    var floatStructure = !!Settings.get('floatStructure');
    var signature = [hideElements ? 'hide-el' : '', floatElements ? 'float-el' : '', floatStructure ? 'float-st' : '', Settings.get('floatOpacity')].join('|');

    if (!hideElements && !floatElements && !floatStructure) {
      if (lastPanelSignature || options.force) clearDynamicPanelClasses();
      lastPanelSignature = signature;
      return;
    }

    var now = Date.now ? Date.now() : new Date().getTime();
    var needsHeavyScan = !!options.force || (now - lastHeavyPanelScanAt > 1800);
    if (needsHeavyScan) lastHeavyPanelScanAt = now;

    var elementsPanel = (hideElements || floatElements) ? findElementsPanel({ forceHeavyScan: needsHeavyScan }) : null;
    var structurePanel = floatStructure ? findStructurePanel({ forceHeavyScan: needsHeavyScan }) : null;
    var active = [];

    if (elementsPanel) active.push(elementsPanel);
    if (structurePanel) active.push(structurePanel);
    cleanupStalePanelClasses(active);

    if (elementsPanel) {
      active.push(elementsPanel);
      elementsPanel.classList.toggle('mimams-bar-hidden-elements-panel', hideElements && !floatElements);
      if (floatElements) {
        elementsPanel.classList.remove('mimams-bar-hidden-elements-panel');
        elementsPanel.classList.add('mimams-bar-floating-elements-panel');
        ensureFloatingChrome(elementsPanel, 'left', Settings);
      }
      if (hideElements || floatElements) markSafeHosts(elementsPanel, active, 'left');
    }

    if (structurePanel) {
      active.push(structurePanel);
      structurePanel.classList.add('mimams-bar-floating-structure-panel');
      ensureFloatingChrome(structurePanel, 'right', Settings);
      markSafeHosts(structurePanel, active, 'right');
      var rail = ensureOwnedStructureRail(structurePanel, Settings) || findStructureRail(structurePanel);
      if (rail) {
        active.push(rail);
        if (!rail._originalParent) {
          rail._originalParent = rail.parentNode;
          rail._originalSibling = rail.nextSibling;
        }
        if (rail.parentNode !== document.body) {
          document.body.appendChild(rail);
        }
        rail.classList.add('mimams-bar-floating-structure-rail');
        rail.setAttribute('data-mimams-bar-float-side', 'right');
        clampFloatingNode(structurePanel);
        positionStructureRail(rail, structurePanel, structurePanel.classList.contains('mimams-bar-structure-minimized') || !!document.getElementById('mimams-bar-minimized-structure'));
        observeRailStyles(rail, structurePanel, 'right', Settings);
      }
    }

    cleanupStalePanelClasses(active);
    lastPanelSignature = signature;

    if (floatStructure) {
      if (!globalPanelDOMObserver) {
        globalPanelDOMObserver = new MutationObserver(function (mutations) {
          var needsReSync = false;
          for (var i = 0; i < mutations.length; i++) {
            var addedNodes = mutations[i].addedNodes;
            if (!addedNodes) continue;
            for (var j = 0; j < addedNodes.length; j++) {
              var node = addedNodes[j];
              if (node.nodeType !== 1) continue;

              // Fast pre-filter: skip small nodes that are definitely not panels/rails/shortcuts.
              // This bypasses matches() and querySelector() on 99.9% of routine builder mutations (spans, svgs, paths).
              var id = node.id || '';
              var cls = typeof node.className === 'string' ? node.className : '';
              var tag = node.tagName || '';
              var isPotential = false;
              if (id.indexOf('structure') !== -1 || id.indexOf('shortcut') !== -1) {
                isPotential = true;
              } else if (cls.indexOf('structure') !== -1 || cls.indexOf('shortcut') !== -1 || cls.indexOf('rail') !== -1) {
                isPotential = true;
              } else if (tag === 'DIV' || tag === 'SECTION' || tag === 'MAIN' || tag === 'HEADER') {
                isPotential = true;
              }
              if (!isPotential) continue;

              var match = node.matches('#bricks-structure, #bricks-structure-resizable, .bricks-structure, .brx-structure, #brx-structure, .brxce-panel-shortcut__container, #brxce-panel-shortcut__container, .at-structure-shortcuts, #at-structure-shortcuts')
                ? node
                : node.querySelector('#bricks-structure, #bricks-structure-resizable, .bricks-structure, .brx-structure, #brx-structure, .brxce-panel-shortcut__container, #brxce-panel-shortcut__container, .at-structure-shortcuts, #at-structure-shortcuts');

              if (match) {
                var isRail = match.matches('.brxce-panel-shortcut__container, #brxce-panel-shortcut__container, .at-structure-shortcuts, #at-structure-shortcuts');
                if (isRail) {
                  if (match.parentNode !== document.body || !match.classList.contains('mimams-bar-floating-structure-rail')) {
                    needsReSync = true;
                    break;
                  }
                } else {
                  if (!match.classList.contains('mimams-bar-floating-structure-panel')) {
                    needsReSync = true;
                    break;
                  }
                }
              }
            }
            if (needsReSync) break;
          }
          if (needsReSync) {
            if (globalReSyncTimer) window.clearTimeout(globalReSyncTimer);
            globalReSyncTimer = window.setTimeout(function () {
              markPanels(Settings, { force: true });
            }, 150);
          }
        });
      }
      globalPanelDOMObserver.observe(document.body, { childList: true, subtree: true });
    }
  }

  var panelRetryTimer = null;
  function schedulePanelRetry(Settings) {
    if (!Settings || (!Settings.get('floatElements') && !Settings.get('floatStructure') && !Settings.get('hideElements') && !Settings.get('hideStructure'))) return;
    if (panelRetryTimer) window.clearTimeout(panelRetryTimer);
    var tries = 0;
    function tick() {
      tries++;
      markPanels(Settings, { force: false }); // Disable heavy scan to prevent UI freezes
      if (tries < 3) panelRetryTimer = window.setTimeout(tick, tries === 1 ? 900 : 1600);
    }
    panelRetryTimer = window.setTimeout(tick, 500);
  }

  var Settings = {
    defaults: {
      autoClose: false,
      shortcut: 'alt-q',
      deselectShortcut: 'escape',
      showTopBarIcon: true,
      showVengineTopBarIcon: true,
      showShortcutPanel: true,
      density: 'compact',
      undocked: false,
      panelTop: 74,
      panelLeft: null,
      hideStructure: false,
      hideElements: false,
      floatElements: false,
      floatStructure: false,
      floatOpacity: '0.78',
      floatPanels: {}
    },
    data: null,

    load: function () {
      var stored = readStoredSettings();

      // v1.2.47: old builds treated missing/old autoClose values as enabled.
      // Reset once so the intended default is stay-open-after-apply, while still
      // allowing the user to intentionally enable Auto-close again afterward.
      if (!stored || stored._autoCloseDefaultFixedFor1247 !== true) {
        stored = stored || {};
        stored.autoClose = false;
        stored._autoCloseDefaultFixedFor1247 = true;
        writeStoredSettings(stored);
      }

      this.data = {};
      Object.keys(this.defaults).forEach(function (key) {
        Settings.data[key] = Object.prototype.hasOwnProperty.call(stored, key) ? stored[key] : Settings.defaults[key];
      });
      return this.data;
    },

    save: function () {
      writeStoredSettings(this.data || {});
      this.applyUiState();
    },

    get: function (key) {
      if (!this.data) this.load();
      return Object.prototype.hasOwnProperty.call(this.data, key) ? this.data[key] : this.defaults[key];
    },

    set: function (key, value) {
      if (!this.data) this.load();
      this.data[key] = value;
      this.save();
    },

    isAutoClose: function () {
      return this.get('autoClose') === true;
    },

    getShortcutLabel: function () {
      var value = this.get('shortcut');
      if (value === 'ctrl-k') return 'Ctrl + K';
      if (value === 'ctrl-alt-a') return 'Ctrl + Alt + A';
      return 'Alt + Q';
    },

    applyUiState: function () {
      if (!this.data) this.load();
      var panel = (window.BAQA && window.BAQA.UI ? window.BAQA.UI.panel : null) || document.querySelector('.baqa-panel');
      if (panel) {
        panel.classList.toggle('baqa-density-comfortable', this.get('density') === 'comfortable');
        panel.classList.toggle('is-undocked', !!this.get('undocked'));
        if (this.get('undocked')) {
          var top = parseInt(this.get('panelTop'), 10);
          var left = this.get('panelLeft');
          var panelRect = safeRect(panel) || { width: 430, height: 620 };
          var pos = clampFloatPosition(!isNaN(parseInt(left, 10)) ? parseInt(left, 10) : Math.max(8, window.innerWidth - (panelRect.width || 430) - 16), isNaN(top) ? 74 : top, panelRect.width || 430, panelRect.height || 620);
          panel.style.insetBlockStart = pos.top + 'px';
          if (left !== null && left !== '' && !isNaN(parseInt(left, 10))) {
            panel.style.insetInlineStart = pos.left + 'px';
            panel.style.insetInlineEnd = 'auto';
            panel.style.marginInline = '0';
          }
        } else {
          panel.style.insetBlockStart = '';
          panel.style.insetInlineStart = '';
          panel.style.insetInlineEnd = '';
          panel.style.marginInline = '';
        }
      }
      var opacity = parseFloat(this.get('floatOpacity'));
      if (isNaN(opacity)) opacity = 0.78;
      opacity = Math.max(0.25, Math.min(1, opacity));
      document.body.style.setProperty('--mimams-bar-floating-panel-opacity', String(opacity));
      var roots = [document.body, document.documentElement].filter(Boolean);
      roots.forEach(function(root) {
        root.classList.toggle('mimams-bar-hide-bricks-structure', !!Settings.get('hideStructure') && !Settings.get('floatStructure'));
        root.classList.toggle('mimams-bar-hide-bricks-elements', !!Settings.get('hideElements') && !Settings.get('floatElements'));
        root.classList.toggle('mimams-bar-float-bricks-elements', !!Settings.get('floatElements'));
        root.classList.toggle('mimams-bar-float-bricks-structure', !!Settings.get('floatStructure'));
      });
      document.body.classList.toggle('ve-hide-top-bar-icon', this.get('showVengineTopBarIcon') === false);
      document.body.classList.toggle('mimams-bar-hide-top-bar-icon', this.get('showTopBarIcon') === false);
      if (isBricksStillLoading()) {
        var self = this;
        window.setTimeout(function () { markPanels(self, { force: true }); }, 900);
        return;
      }
      markPanels(this, { force: false });
      schedulePanelRetry(this);
    }
  };



  window.MimamsBarSettings = Settings;
})();
