<?php
namespace VE\Adapters;
defined('ABSPATH') || exit;

class AdminAdapter {
    public function __construct() {
        if (defined('VE_IS_BRICKS') && VE_IS_BRICKS) return;
        if (!is_admin()) return;
        global $pagenow;
        if (in_array($pagenow, ['update.php', 'update-core.php'])) return;
        add_action('admin_bar_menu', [$this, 'toolbar'], 999);
        add_action('admin_enqueue_scripts', [$this, 'enqueue']);
        add_action('admin_footer', [$this, 'footer']);
    }
    public function toolbar(\WP_Admin_Bar $b): void {
        if (!current_user_can('manage_options')) return;
        $b->add_node(['id'=>'ve-toggle','parent'=>'top-secondary','title'=>'<span class="ve-admin-logo" aria-hidden="true"></span><span class="ab-label">MV</span>','href'=>'#','meta'=>['title'=>"Mimam's Var - WP (Alt+Z)"]]);
    }
    public function enqueue(): void {
        if (!current_user_can('manage_options')) return;
        wp_enqueue_style('ve-ph', 'https://cdn.jsdelivr.net/npm/@phosphor-icons/web@2/src/duotone/style.css', [], '2');
        wp_enqueue_style('ve-codemirror', 'https://cdn.jsdelivr.net/npm/codemirror@5.65.16/lib/codemirror.css', [], '5.65.16');
        wp_enqueue_style('ve-codemirror-hint', 'https://cdn.jsdelivr.net/npm/codemirror@5.65.16/addon/hint/show-hint.css', ['ve-codemirror'], '5.65.16');
        wp_enqueue_script('ve-p', 'https://cdn.jsdelivr.net/npm/preact@10/dist/preact.umd.js', [], '10', true);
        wp_enqueue_script('ve-ph', 'https://cdn.jsdelivr.net/npm/preact@10/hooks/dist/hooks.umd.js', ['ve-p'], '10', true);
        wp_enqueue_script('ve-gsap', 'https://cdn.jsdelivr.net/npm/gsap@3.12.5/dist/gsap.min.js', [], '3.12.5', true);
        wp_enqueue_script('ve-codemirror', 'https://cdn.jsdelivr.net/npm/codemirror@5.65.16/lib/codemirror.js', [], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-css', 'https://cdn.jsdelivr.net/npm/codemirror@5.65.16/mode/css/css.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-closebrackets', 'https://cdn.jsdelivr.net/npm/codemirror@5.65.16/addon/edit/closebrackets.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-hint', 'https://cdn.jsdelivr.net/npm/codemirror@5.65.16/addon/hint/show-hint.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-app', VE_URL.'assets/js/builder-panel.js', ['ve-p','ve-ph','ve-gsap','ve-codemirror-css','ve-codemirror-closebrackets','ve-codemirror-hint'], VE_VERSION.'.'.filemtime(VE_DIR.'assets/js/builder-panel.js'), true);
        $preferences = get_user_meta( get_current_user_id(), 've_user_preferences', true );
        wp_localize_script('ve-app', 'vePanel', ['apiRoot'=>esc_url_raw(rest_url()),'nonce'=>wp_create_nonce('wp_rest'),'version'=>VE_VERSION,'mode'=>'admin','logoUrl'=>esc_url_raw(VE_URL.'assets/hebronmimam-logo-icon.png'),'assetUrl'=>esc_url_raw(VE_URL.'assets/'),'userPreferences'=>is_array($preferences)?$preferences:[]]);
        if (class_exists('\VE\Modules\BuilderTools\MimamsBarModule')) {
            (new \VE\Modules\BuilderTools\MimamsBarModule())->enqueue();
        }
    }
    public function footer(): void {
        if (!current_user_can('manage_options')) return;
        echo '<script>document.addEventListener("DOMContentLoaded",function(){var b=document.getElementById("wp-admin-bar-ve-toggle");if(b)b.addEventListener("click",function(e){e.preventDefault();window.dispatchEvent(new Event("ve-toggle-panel"))})});</script>';
        echo '<style>#wp-admin-bar-ve-toggle .ab-item{display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:6px!important;height:32px!important;line-height:32px!important;padding:0 8px!important}#wp-admin-bar-ve-toggle .ve-admin-logo{display:block!important;width:18px!important;height:18px!important;flex:0 0 18px!important;margin:0!important;padding:0!important;border-radius:4px!important;background:url("' . esc_url( VE_URL . 'assets/hebronmimam-logo-icon.png' ) . '") center/contain no-repeat!important}#wp-admin-bar-ve-toggle .ab-label{display:block!important;height:12px!important;line-height:12px!important;padding:0!important;margin:0!important;font-size:11px!important;font-weight:600!important;color:#baf400!important}#wp-admin-bar-ve-toggle:hover .ab-label{color:#d4ff33!important}</style>';
    }
}
