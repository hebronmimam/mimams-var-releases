(function () {
  'use strict';

  var Core = window.MimamsBarCore || {};
  var labels = Core.labels || (Core.config && Core.config.labels) || {};

  function setInput(ui, value, placeholder) {
    if (!ui || !ui.input) return;
    ui.input.value = value || '';
    ui.input.placeholder = placeholder || '';
    ui.input.focus();
  }

  function hideResults(ui) {
    if (!ui || !ui.elementResults) return;
    ui.elementResults.hidden = true;
    ui.elementResults.innerHTML = '';
  }

  function clearCommandSuggestions(ui) {
    if (ui && ui.commandSuggestionsManager) ui.commandSuggestionsManager.clear(ui);
  }

  function showResults(ui) {
    if (!ui || !ui.elementResults) return;
    ui.elementResults.hidden = false;
  }

  function setModeLabel(ui, text) {
    if (ui && ui.elementModeLabel) ui.elementModeLabel.textContent = text;
  }

  var ModeManager = {
    handleModeKeys: function (ui, event) {
      if (!ui || !event) return false;
      if (event.ctrlKey || event.metaKey || event.altKey || event.shiftKey) return false;

      var key = String(event.key || '').toLowerCase();
      var inputEmpty = !ui.input || !String(ui.input.value || '').trim();

      if (key === '0' && ui.mode !== 'everything' && inputEmpty) {
        event.preventDefault();
        this.enterEverything(ui);
        return true;
      }

      if (key === '1' && ui.mode !== 'default' && inputEmpty) {
        event.preventDefault();
        this.enterDefault(ui);
        return true;
      }

      if (key === '2' && ui.mode !== 'elements' && inputEmpty) {
        event.preventDefault();
        this.enterPageSearch(ui);
        return true;
      }

      if (key === '3' && ui.mode !== 'add-elements' && inputEmpty) {
        event.preventDefault();
        this.enterAddElement(ui);
        return true;
      }

      return false;
    },

    enterEverything: function (ui) {
      if (!ui) return;
      ui.mode = 'everything';
      ui.activeElementResultIndex = 0;
      ui.pendingAddElementName = '';
      setInput(ui, '', 'Search elements, commands, settings, and tools...');
      setModeLabel(ui, 'Everything');
      clearCommandSuggestions(ui);
      showResults(ui);
      if (typeof ui.hideError === 'function') ui.hideError();
      if (typeof ui.renderElementResults === 'function') ui.renderElementResults();
      if (typeof ui.updateTabHint === 'function') ui.updateTabHint();
      if (typeof ui.afterModeChange === 'function') ui.afterModeChange();
    },

    enterPageSearch: function (ui) {
      if (!ui) return;
      ui.mode = 'elements';
      ui.activeElementResultIndex = 0;
      ui.pendingAddElementName = '';
      setInput(ui, '', 'Search current page elements by name, tag, class, ID, or Bricks ID...');
      setModeLabel(ui, 'Search page');
      clearCommandSuggestions(ui);
      showResults(ui);
      if (typeof ui.hideError === 'function') ui.hideError();
      if (typeof ui.renderElementResults === 'function') ui.renderElementResults();
      if (typeof ui.updateTabHint === 'function') ui.updateTabHint();
      if (typeof ui.afterModeChange === 'function') ui.afterModeChange();
    },

    enterAddElement: function (ui) {
      if (!ui) return;
      ui.mode = 'add-elements';
      ui.activeElementResultIndex = 0;
      ui.pendingAddElementName = '';
      setInput(ui, '', 'Search Bricks elements or Emmet: img, btn, h2, section>container>button');
      setModeLabel(ui, 'Add element');
      clearCommandSuggestions(ui);
      showResults(ui);
      if (typeof ui.hideError === 'function') ui.hideError();
      if (typeof ui.renderElementResults === 'function') ui.renderElementResults();
      if (typeof ui.updateTabHint === 'function') ui.updateTabHint();
      if (typeof ui.afterModeChange === 'function') ui.afterModeChange();
    },

    enterDefault: function (ui) {
      if (!ui) return;
      ui.mode = 'default';
      ui.activeElementResultIndex = 0;
      ui.pendingAddElementName = '';
      setInput(ui, '', labels.placeholder || 'data-anim="fade-up" data-delay="200"');
      setModeLabel(ui, 'Direct mode');
      clearCommandSuggestions(ui);
      hideResults(ui);
      if (typeof ui.hideError === 'function') ui.hideError();
      if (typeof ui.updateTabHint === 'function') ui.updateTabHint();
      if (typeof ui.afterModeChange === 'function') ui.afterModeChange();
    }
  };

  window.MimamsBarModeManager = ModeManager;
  window.MimamsBar = window.MimamsBar || {};
  window.MimamsBar.ModeManager = ModeManager;
})();
