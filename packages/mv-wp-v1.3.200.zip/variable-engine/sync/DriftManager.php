<?php
namespace VE\Sync;

use VE\Adapters\Bricks\VariablesMirror;
use VE\Core\VariableManager;

defined( 'ABSPATH' ) || exit;

/**
 * Compares Mimam's Var with paired consumers without making a builder the
 * source of truth. Pulls reuse Import Preview; pushes use adapter-owned paths.
 */
class DriftManager {

    private const REPORT_PREFIX = 've_sync_drift_report_';
    private const BASELINE_PREFIX = 've_sync_drift_baseline_';
    private const FIGMA_COMMAND = 've_sync_drift_figma_command';

    private SyncEngine $engine;
    private VariableManager $manager;

    public function __construct() {
        $this->engine = new SyncEngine();
        $this->manager = new VariableManager();
    }

    public function report( string $source, array $variables, array $context = [] ): array {
        $source = $this->sanitize_source( $source );
        if ( 'figma' !== $source ) {
            return [ 'code' => 've_drift_source_invalid', 'message' => 'Only the paired Figma companion may publish a remote report.' ];
        }

        $report = [
            'source'       => $source,
            'reported_at'  => current_time( 'mysql', true ),
            'reported_unix'=> time(),
            'context'      => [
                'file_name'       => sanitize_text_field( (string) ( $context['file_name'] ?? '' ) ),
                'collection_name' => sanitize_text_field( (string) ( $context['collection_name'] ?? '' ) ),
            ],
            'variables'    => $this->normalize_rows( $variables, $source ),
        ];
        update_option( self::REPORT_PREFIX . $source, $report, false );
        return [
            'reported' => true,
            'source' => $source,
            'count' => count( $report['variables'] ),
            'reported_at' => $report['reported_at'],
        ];
    }

    public function compare( string $source ): array {
        $source = $this->sanitize_source( $source );
        $mv = $this->mv_rows();
        $external_report = $this->source_report( $source );
        $external = $external_report['variables'];
        $baseline = get_option( self::BASELINE_PREFIX . $source, [] );
        $baseline = is_array( $baseline ) ? $baseline : [];

        $mv_map = $this->index_rows( $mv );
        $source_map = $this->index_rows( $external );
        $keys = array_values( array_unique( array_merge( array_keys( $mv_map ), array_keys( $source_map ) ) ) );
        natcasesort( $keys );

        $rows = [];
        $summary = [
            'total' => 0,
            'in_sync' => 0,
            'changed' => 0,
            'conflict' => 0,
            'missing_mv' => 0,
            'missing_source' => 0,
        ];

        foreach ( $keys as $key ) {
            $local = $mv_map[ $key ] ?? null;
            $remote = $source_map[ $key ] ?? null;
            $status = 'in_sync';
            $direction = '';
            if ( ! $local ) {
                $status = 'missing_mv';
                $direction = 'pull';
            } elseif ( ! $remote ) {
                $status = 'missing_source';
                $direction = 'push';
            } elseif ( ! $this->rows_equal( $local, $remote ) ) {
                $base = isset( $baseline[ $key ] ) && is_array( $baseline[ $key ] ) ? $baseline[ $key ] : null;
                $local_changed = $base ? ! $this->rows_equal( $local, $base ) : true;
                $source_changed = $base ? ! $this->rows_equal( $remote, $base ) : true;
                if ( $base && $local_changed && $source_changed ) {
                    $status = 'conflict';
                } else {
                    $status = 'changed';
                    $direction = $base && $source_changed && ! $local_changed ? 'pull' : ( $base && $local_changed && ! $source_changed ? 'push' : '' );
                }
            }

            $summary['total']++;
            $summary[ $status ]++;
            $rows[] = [
                'key' => $key,
                'name' => (string) ( $local['name'] ?? $remote['name'] ?? $key ),
                'public_name' => (string) ( $local['public_name'] ?? $remote['public_name'] ?? $key ),
                'status' => $status,
                'suggested_direction' => $direction,
                'mv' => $local,
                'source' => $remote,
            ];
        }

        return [
            'source' => $source,
            'source_label' => 'figma' === $source ? 'Figma' : 'Bricks',
            'available' => 'bricks' === $source || ! empty( $external_report['available'] ),
            'reported_at' => (string) ( $external_report['reported_at'] ?? '' ),
            'age_seconds' => isset( $external_report['reported_unix'] ) ? max( 0, time() - (int) $external_report['reported_unix'] ) : null,
            'context' => $external_report['context'] ?? [],
            'summary' => $summary,
            'rows' => $rows,
        ];
    }

    public function preview( string $source, string $direction, array $keys = [] ): array {
        $comparison = $this->compare( $source );
        $direction = 'pull' === $direction ? 'pull' : 'push';
        $wanted = array_fill_keys( array_map( 'strval', $keys ), true );
        $selected = array_values( array_filter( $comparison['rows'], static function ( array $row ) use ( $wanted ) {
            return empty( $wanted ) || isset( $wanted[ (string) $row['key'] ] );
        } ) );
        $selected = array_values( array_filter( $selected, static function ( array $row ) {
            return 'in_sync' !== (string) $row['status'];
        } ) );

        if ( 'pull' === $direction ) {
            $incoming = [];
            foreach ( $selected as $row ) {
                if ( ! empty( $row['source'] ) ) {
                    $incoming[] = $row['source'];
                }
            }
            $prepared = $this->engine->prepare_import_rows( $incoming );
            $result = $this->engine->preview_import( $prepared );
            return [
                'source' => $comparison['source'],
                'direction' => 'pull',
                'rows' => $selected,
                'changes' => $result['changes'] ?? [],
                'summary' => $result['summary'] ?? [],
                'count' => count( $result['changes'] ?? [] ),
            ];
        }

        $payload = [];
        foreach ( $selected as $row ) {
            if ( ! empty( $row['mv'] ) ) {
                $payload[] = $row['mv'];
            }
        }
        return [
            'source' => $comparison['source'],
            'direction' => 'push',
            'rows' => $selected,
            'variables' => $payload,
            'count' => count( $payload ),
            'queued' => 'figma' === $comparison['source'],
        ];
    }

    public function apply( string $source, string $direction, array $keys = [] ): array {
        $source = $this->sanitize_source( $source );
        $plan = $this->preview( $source, $direction, $keys );
        if ( (int) ( $plan['count'] ?? 0 ) < 1 ) {
            return [ 'applied' => 0, 'queued' => false, 'message' => 'No drift changes to apply.' ];
        }

        if ( 'pull' === $direction ) {
            $result = $this->engine->apply_changes( $plan['changes'], [
                'skip_deletes' => true,
                'snapshot_context' => [
                    'title' => 'Before pulling from ' . ( 'figma' === $source ? 'Figma' : 'Bricks' ),
                    'description' => 'Recovery point created before resolving ' . count( $plan['changes'] ) . ' Sync Drift change(s).',
                    'source' => 'sync_drift_' . $source,
                    'format' => 'drift',
                    'change_count' => count( $plan['changes'] ),
                ],
            ] );
            if ( empty( $result['errors'] ) ) {
                $this->save_baseline( $source );
            }
            return $result + [ 'queued' => false, 'direction' => 'pull', 'source' => $source ];
        }

        if ( 'bricks' === $source ) {
            $ok = ( new VariablesMirror() )->sync();
            if ( $ok ) {
                $this->save_baseline( 'bricks' );
            }
            return [
                'applied' => $ok ? (int) $plan['count'] : 0,
                'queued' => false,
                'source' => 'bricks',
                'direction' => 'push',
                'errors' => $ok ? [] : [ 'Bricks variable mirror could not be refreshed.' ],
            ];
        }

        $command = [
            'id' => wp_generate_uuid4(),
            'status' => 'pending',
            'created_at' => current_time( 'mysql', true ),
            'created_unix' => time(),
            'variables' => $plan['variables'],
            'skip_deletes' => true,
        ];
        update_option( self::FIGMA_COMMAND, $command, false );
        return [
            'applied' => 0,
            'queued' => true,
            'command_id' => $command['id'],
            'source' => 'figma',
            'direction' => 'push',
            'count' => count( $command['variables'] ),
            'message' => 'Push queued. Keep the paired Figma plugin open to apply it.',
        ];
    }

    public function figma_command(): array {
        $command = get_option( self::FIGMA_COMMAND, [] );
        if ( ! is_array( $command ) || 'pending' !== ( $command['status'] ?? '' ) ) {
            return [ 'pending' => false ];
        }
        return [ 'pending' => true, 'command' => $command ];
    }

    public function complete_figma_command( string $command_id, array $variables, array $result = [] ): array {
        $command = get_option( self::FIGMA_COMMAND, [] );
        if ( ! is_array( $command ) || ! hash_equals( (string) ( $command['id'] ?? '' ), $command_id ) ) {
            return [ 'code' => 've_drift_command_invalid', 'message' => 'The queued Figma command is no longer current.' ];
        }
        $this->report( 'figma', $variables, [
            'file_name' => (string) get_option( 've_sync_figma_name', '' ),
            'collection_name' => (string) get_option( 've_sync_figma_collection', '' ),
        ] );
        $command['status'] = empty( $result['errors'] ) ? 'complete' : 'failed';
        $command['completed_at'] = current_time( 'mysql', true );
        $command['result'] = $result;
        update_option( self::FIGMA_COMMAND, $command, false );
        if ( 'complete' === $command['status'] ) {
            $this->save_baseline( 'figma' );
        }
        return [ 'completed' => 'complete' === $command['status'], 'result' => $result ];
    }

    private function source_report( string $source ): array {
        if ( 'bricks' === $source ) {
            return [
                'available' => false !== get_option( 'bricks_global_variables', false ),
                'reported_at' => current_time( 'mysql', true ),
                'reported_unix' => time(),
                'context' => [ 'collection_name' => 'Bricks global variables' ],
                'variables' => $this->bricks_rows(),
            ];
        }
        $report = get_option( self::REPORT_PREFIX . 'figma', [] );
        if ( ! is_array( $report ) ) {
            $report = [];
        }
        $report['available'] = ! empty( $report['reported_at'] );
        $report['variables'] = isset( $report['variables'] ) && is_array( $report['variables'] ) ? $report['variables'] : [];
        return $report;
    }

    private function mv_rows(): array {
        return $this->normalize_rows( $this->engine->export( 'flat', true ), 'mv' );
    }

    private function bricks_rows(): array {
        $rows = get_option( 'bricks_global_variables', [] );
        $rows = is_array( $rows ) ? $rows : [];
        $normalized = [];
        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) || empty( $row['name'] ) ) {
                continue;
            }
            $normalized[] = [
                'name' => ltrim( (string) $row['name'], '-' ),
                'public_name' => ltrim( (string) $row['name'], '-' ),
                'value' => (string) ( $row['value'] ?? '' ),
                'type' => 'base',
                'origin' => 'bricks',
            ];
        }
        return $this->normalize_rows( $normalized, 'bricks' );
    }

    private function normalize_rows( array $variables, string $source ): array {
        $rows = [];
        foreach ( $variables as $variable ) {
            if ( ! is_array( $variable ) ) {
                continue;
            }
            $name = trim( (string) ( $variable['name'] ?? $variable['figma_name'] ?? '' ) );
            $public = trim( (string) ( $variable['public_name'] ?? $variable['public_css_name'] ?? $variable['css_name'] ?? '' ) );
            $public = strtolower( ltrim( $public, '-' ) );
            $public = str_replace( [ '.', '/', '\\' ], '-', $public );
            $public = preg_replace( '/[^a-z0-9-]+/', '-', $public );
            $public = trim( (string) $public, '-' );
            if ( '' === $public && '' !== $name ) {
                $public = ltrim( $this->manager->to_css_name( $name ), '-' );
            }
            if ( '' === $public ) {
                continue;
            }
            $source_name = trim( (string) ( $variable['source_name'] ?? '' ) );
            $rows[] = [
                'id' => (int) ( $variable['id'] ?? 0 ),
                'name' => '' !== $name ? $name : $public,
                'public_name' => $public,
                'css_name' => '--' . $public,
                'value' => (string) ( $variable['value'] ?? $variable['css_value'] ?? '' ),
                'type' => (string) ( $variable['type'] ?? 'base' ),
                'source_name' => $source_name,
                'origin' => (string) ( $variable['origin'] ?? $source ),
                'namespace' => (string) ( $variable['namespace'] ?? '' ),
            ];
        }
        return array_values( $this->index_rows( $rows ) );
    }

    private function index_rows( array $rows ): array {
        $indexed = [];
        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }
            $key = strtolower( trim( (string) ( $row['public_name'] ?? '' ) ) );
            if ( '' !== $key ) {
                $indexed[ $key ] = $row;
            }
        }
        return $indexed;
    }

    private function rows_equal( array $a, array $b ): bool {
        return $this->canonical_value( (string) ( $a['value'] ?? '' ) ) === $this->canonical_value( (string) ( $b['value'] ?? '' ) )
            && strtolower( (string) ( $a['type'] ?? 'base' ) ) === strtolower( (string) ( $b['type'] ?? 'base' ) )
            && strtolower( (string) ( $a['source_name'] ?? '' ) ) === strtolower( (string) ( $b['source_name'] ?? '' ) );
    }

    private function canonical_value( string $value ): string {
        return strtolower( trim( preg_replace( '/\s+/', ' ', $value ) ) );
    }

    private function save_baseline( string $source ): void {
        $comparison = $this->compare( $source );
        $baseline = [];
        foreach ( $comparison['rows'] as $row ) {
            $candidate = $row['source'] ?? $row['mv'] ?? null;
            if ( is_array( $candidate ) ) {
                $baseline[ (string) $row['key'] ] = $candidate;
            }
        }
        update_option( self::BASELINE_PREFIX . $source, $baseline, false );
    }

    private function sanitize_source( string $source ): string {
        return 'bricks' === sanitize_key( $source ) ? 'bricks' : 'figma';
    }
}
