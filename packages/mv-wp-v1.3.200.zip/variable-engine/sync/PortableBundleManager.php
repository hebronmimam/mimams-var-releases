<?php

namespace VE\Sync;

use VE\Core\ColorPaletteManager;
use VE\Core\CssExporter;
use VE\Core\GeneratorEngine;
use VE\Core\ThemeManager;
use VE\Core\VariableCategoryManager;
use VE\Core\VariableManager;
use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

/**
 * Portable, name-based transfer of the complete Mimam's Var system.
 *
 * Database IDs are deliberately excluded. Variables, relationships,
 * generators, themes, palettes, and memberships reconnect by stable names.
 */
class PortableBundleManager {

    private const FORMAT = 'mimams-var-system';
    private const BUNDLE_VERSION = 1;

    private SyncEngine $sync;
    private SnapshotManager $snapshots;
    private VariableManager $variables;

    public function __construct() {
        $this->sync = new SyncEngine();
        $this->snapshots = new SnapshotManager();
        $this->variables = new VariableManager();
    }

    public function export(): array {
        global $wpdb;

        $rows = $this->variables->get_all();
        $by_id = [];
        foreach ( $rows as $row ) {
            $by_id[ (int) ( $row['id'] ?? 0 ) ] = $row;
        }

        $variables = [];
        foreach ( $rows as $row ) {
            $source_id = (int) ( $row['source_id'] ?? 0 );
            $variables[] = [
                'name'        => (string) ( $row['name'] ?? '' ),
                'namespace'   => (string) ( $row['namespace'] ?? '' ),
                'category_slug' => (string) ( $row['category_slug'] ?? 'uncategorized' ),
                'origin'      => (string) ( $row['origin'] ?? '' ),
                'type'        => (string) ( $row['type'] ?? 'base' ),
                'value'       => (string) ( $row['value'] ?? '' ),
                'source_name' => $source_id > 0 ? (string) ( $by_id[ $source_id ]['name'] ?? '' ) : '',
                'generator_type' => (string) ( $row['generator_type'] ?? '' ),
                'position'    => (int) ( $row['position'] ?? 0 ),
            ];
        }

        $generator_rows = $wpdb->get_results(
            'SELECT g.*, v.name AS base_name
             FROM ' . Schema::table( 'generators' ) . ' g
             INNER JOIN ' . Schema::table( 'variables' ) . ' v ON v.id = g.variable_id
             WHERE g.active = 1
             ORDER BY v.position ASC, v.name ASC, g.id ASC',
            ARRAY_A
        ) ?: [];
        $generators = [];
        foreach ( $generator_rows as $generator ) {
            $config = json_decode( (string) ( $generator['config'] ?? '' ), true );
            $generators[] = [
                'base_name' => (string) ( $generator['base_name'] ?? '' ),
                'type'      => (string) ( $generator['type'] ?? '' ),
                'config'    => is_array( $config ) ? $config : [],
            ];
        }

        $palette_rows = $wpdb->get_results(
            'SELECT p.slug, p.name, p.position, v.name AS variable_name, m.position AS member_position
             FROM ' . Schema::table( 'color_palettes' ) . ' p
             LEFT JOIN ' . Schema::table( 'color_palette_members' ) . ' m ON m.palette_id = p.id
             LEFT JOIN ' . Schema::table( 'variables' ) . ' v ON v.id = m.variable_id
             ORDER BY p.position ASC, p.id ASC, m.position ASC, m.id ASC',
            ARRAY_A
        ) ?: [];
        $palette_map = [];
        foreach ( $palette_rows as $palette ) {
            $slug = (string) ( $palette['slug'] ?? '' );
            if ( '' === $slug ) {
                continue;
            }
            if ( ! isset( $palette_map[ $slug ] ) ) {
                $palette_map[ $slug ] = [
                    'slug'     => $slug,
                    'name'     => (string) ( $palette['name'] ?? $slug ),
                    'position' => (int) ( $palette['position'] ?? 0 ),
                    'members'  => [],
                ];
            }
            if ( ! empty( $palette['variable_name'] ) ) {
                $palette_map[ $slug ]['members'][] = (string) $palette['variable_name'];
            }
        }

        $variable_categories = [];
        foreach ( ( new VariableCategoryManager() )->list() as $category ) {
            $variable_categories[] = [
                'slug'      => (string) ( $category['slug'] ?? '' ),
                'name'      => (string) ( $category['name'] ?? '' ),
                'position'  => (int) ( $category['position'] ?? 0 ),
                'protected' => ! empty( $category['protected'] ),
            ];
        }

        return [
            'format'          => self::FORMAT,
            'bundle_version'  => self::BUNDLE_VERSION,
            'product_version' => defined( 'VE_VERSION' ) ? VE_VERSION : '',
            'exported_at'     => gmdate( 'c' ),
            'site'            => [
                'name' => function_exists( 'get_bloginfo' ) ? (string) get_bloginfo( 'name' ) : '',
                'url'  => function_exists( 'home_url' ) ? (string) home_url( '/' ) : '',
            ],
            'variables'       => $variables,
            'generators'      => $generators,
            'themes'          => ( new ThemeManager() )->snapshot_state(),
            'color_palettes'  => array_values( $palette_map ),
            'variable_categories' => $variable_categories,
        ];
    }

    public function validate_structure( array $bundle ): array {
        $errors = [];
        if ( self::FORMAT !== (string) ( $bundle['format'] ?? '' ) ) {
            $errors[] = 'This is not a Mimam’s Var System Bundle.';
        }
        if ( self::BUNDLE_VERSION !== (int) ( $bundle['bundle_version'] ?? 0 ) ) {
            $errors[] = 'This System Bundle version is unsupported.';
        }
        foreach ( [ 'variables', 'generators', 'themes', 'color_palettes' ] as $required ) {
            if ( ! isset( $bundle[ $required ] ) || ! is_array( $bundle[ $required ] ) ) {
                $errors[] = "System Bundle section '{$required}' is missing or invalid.";
            }
        }
        if ( ! empty( $errors ) ) {
            return $errors;
        }

        $variable_names = [];
        $variable_types = [];
        foreach ( $bundle['variables'] as $index => $row ) {
            if ( ! is_array( $row ) ) {
                $errors[] = 'Variable row ' . ( $index + 1 ) . ' is invalid.';
                continue;
            }
            $name = (string) ( $row['name'] ?? '' );
            $type = (string) ( $row['type'] ?? 'base' );
            if ( ! preg_match( VariableManager::NAME_PATTERN, $name ) ) {
                $errors[] = "System Bundle contains invalid variable name '{$name}'.";
            } elseif ( isset( $variable_names[ $name ] ) ) {
                $errors[] = "System Bundle contains duplicate variable '{$name}'.";
            }
            if ( ! in_array( $type, [ 'base', 'generated', 'alias' ], true ) ) {
                $errors[] = "Portable variable '{$name}' has an unsupported type.";
            }
            $variable_names[ $name ] = true;
            $variable_types[ $name ] = $type;
        }

        foreach ( $bundle['variables'] as $row ) {
            if ( ! is_array( $row ) || ! in_array( (string) ( $row['type'] ?? '' ), [ 'alias', 'generated' ], true ) ) {
                continue;
            }
            $name = (string) ( $row['name'] ?? '' );
            $source_name = (string) ( $row['source_name'] ?? '' );
            if ( '' === $source_name || $source_name === $name || ! isset( $variable_names[ $source_name ] ) ) {
                $errors[] = "Related variable '{$name}' has an invalid source.";
            }
        }

        $generator_keys = [];
        foreach ( $bundle['generators'] as $generator ) {
            $base_name = (string) ( $generator['base_name'] ?? '' );
            $type = (string) ( $generator['type'] ?? '' );
            $key = $base_name . ':' . $type;
            if (
                ! isset( $variable_names[ $base_name ] )
                || 'base' !== ( $variable_types[ $base_name ] ?? '' )
                || ! in_array( $type, [ 'color', 'spacing', 'typography', 'radius', 'size' ], true )
                || ! isset( $generator['config'] )
                || ! is_array( $generator['config'] )
                || isset( $generator_keys[ $key ] )
            ) {
                $errors[] = "Generator '{$key}' is invalid.";
            }
            $generator_keys[ $key ] = true;
        }

        if (
            ! isset( $bundle['themes']['items'], $bundle['themes']['active'] )
            || ! is_array( $bundle['themes']['items'] )
        ) {
            $errors[] = 'System Bundle theme state is invalid.';
        }

        $palette_slugs = [];
        $palette_members = [];
        if ( empty( $bundle['color_palettes'] ) ) {
            $errors[] = 'A System Bundle must contain at least one Color Palette.';
        }
        foreach ( $bundle['color_palettes'] as $palette ) {
            $slug = sanitize_key( (string) ( $palette['slug'] ?? '' ) );
            if ( '' === $slug || isset( $palette_slugs[ $slug ] ) || ! isset( $palette['members'] ) || ! is_array( $palette['members'] ) ) {
                $errors[] = "Color Palette '{$slug}' is invalid.";
                continue;
            }
            $palette_slugs[ $slug ] = true;
            foreach ( $palette['members'] as $member ) {
                $member = (string) $member;
                if (
                    ! isset( $variable_names[ $member ] )
                    || 'generated' === ( $variable_types[ $member ] ?? '' )
                    || isset( $palette_members[ $member ] )
                ) {
                    $errors[] = "Color Palette membership for '{$member}' is invalid or duplicated.";
                }
                $palette_members[ $member ] = $slug;
            }
        }

        $category_slugs = [];
        $categories = isset( $bundle['variable_categories'] ) && is_array( $bundle['variable_categories'] )
            ? $bundle['variable_categories']
            : [ [ 'slug' => 'uncategorized', 'name' => 'Uncategorized', 'position' => 0, 'protected' => true ] ];
        foreach ( $categories as $category ) {
            $slug = sanitize_key( (string) ( $category['slug'] ?? '' ) );
            if ( '' === $slug || isset( $category_slugs[ $slug ] ) ) {
                $errors[] = "Variable category '{$slug}' is invalid.";
                continue;
            }
            $category_slugs[ $slug ] = true;
        }
        if ( ! isset( $category_slugs['uncategorized'] ) ) {
            $errors[] = 'System Bundle variable categories must include Uncategorized.';
        }
        foreach ( $bundle['variables'] as $row ) {
            $category_slug = sanitize_key( (string) ( $row['category_slug'] ?? 'uncategorized' ) );
            if ( ! isset( $category_slugs[ $category_slug ] ) ) {
                $errors[] = "Variable '" . (string) ( $row['name'] ?? '' ) . "' uses a missing category.";
            }
        }

        return array_values( array_unique( $errors ) );
    }

    public function preview( array $bundle ): array {
        $errors = $this->validate_structure( $bundle );
        if ( ! empty( $errors ) ) {
            return [ 'errors' => $errors ];
        }

        $variables = $this->normalize_variable_rows( $bundle['variables'] );
        $variables = $this->sync->prepare_import_rows( $variables );
        $errors = $this->sync->validate_import_rows( $variables );
        if ( ! empty( $errors ) ) {
            return [ 'errors' => $errors ];
        }

        $variable_preview = $this->sync->preview_import( $variables );
        $system_changes = array_merge(
            $this->preview_generators( $bundle['generators'] ),
            $this->preview_themes( $bundle['themes'] ),
            $this->preview_palettes( $bundle['color_palettes'] ),
            $this->preview_categories( $bundle['variable_categories'] ?? [] )
        );
        $changes = array_merge( $variable_preview['changes'], $system_changes );
        $summary = $variable_preview['summary'];
        $summary['system_changed'] = count( $system_changes );
        $summary['total'] = (int) ( $summary['total'] ?? 0 ) + count( $system_changes );

        return [
            'changes'        => $changes,
            'summary'        => $summary,
            'variable_count' => count( $variables ),
            'bundle_version' => self::BUNDLE_VERSION,
            'source_site'    => (string) ( $bundle['site']['name'] ?? '' ),
            'errors'         => [],
        ];
    }

    public function apply( array $bundle, bool $skip_deletes = true ): array {
        global $wpdb;

        $preview = $this->preview( $bundle );
        if ( ! empty( $preview['errors'] ) ) {
            return [
                'applied'     => 0,
                'snapshot_id' => 0,
                'rolled_back' => false,
                'errors'      => $preview['errors'],
            ];
        }
        foreach ( $preview['changes'] as $change ) {
            if ( 'type_change' === (string) ( $change['action'] ?? '' ) ) {
                return [
                    'applied'     => 0,
                    'snapshot_id' => 0,
                    'rolled_back' => false,
                    'errors'      => [ "Type change '{$change['name']}' requires manual review before import." ],
                ];
            }
        }

        $snapshot_id = $this->snapshots->create( 'pre_import', [
            'title'        => 'Before System Bundle import',
            'description'  => 'Complete recovery point created before restoring the portable System Bundle.',
            'source'       => 'system_bundle',
            'format'       => 'system',
            'change_count' => count( $preview['changes'] ?? [] ),
        ] );
        if ( is_wp_error( $snapshot_id ) ) {
            return [
                'applied'     => 0,
                'snapshot_id' => 0,
                'rolled_back' => false,
                'errors'      => [ $snapshot_id->get_error_message() ],
            ];
        }

        $applied = 0;
        try {
            $applied += $this->sync_categories( $bundle['variable_categories'] ?? [], $skip_deletes );
            $variable_changes = array_values( array_filter( $preview['changes'], static function ( array $change ): bool {
                return in_array(
                    (string) ( $change['action'] ?? '' ),
                    [ 'add', 'update', 'delete', 'repair_generated', 'relationship_change', 'type_change' ],
                    true
                );
            } ) );
            $variable_changes = $this->sort_variable_changes( $variable_changes, $bundle['variables'] );
            if ( ! empty( $variable_changes ) ) {
                $variable_result = $this->sync->apply_changes(
                    $variable_changes,
                    [
                        'skip_deletes' => $skip_deletes,
                        'snapshot_id'  => (int) $snapshot_id,
                        'skip_log'     => true,
                    ]
                );
                if ( ! empty( $variable_result['errors'] ) ) {
                    throw new \RuntimeException( implode( '; ', $variable_result['errors'] ) );
                }
                $applied += (int) ( $variable_result['applied'] ?? 0 );
            }

            $applied += $this->sync_generators( $bundle['generators'], $skip_deletes );
            $applied += $this->sync_themes( $bundle['themes'], $skip_deletes );
            $applied += $this->sync_palettes( $bundle['color_palettes'], $skip_deletes );
            $applied += $this->sync_variable_metadata( $bundle['variables'] );
            $this->sync_variable_order( $bundle['variables'], $skip_deletes );

            if ( ! ( new CssExporter() )->export() ) {
                throw new \RuntimeException( 'The imported system was restored, but its CSS file could not be written.' );
            }

            $logged = $wpdb->insert(
                Schema::table( 'sync_logs' ),
                [
                    'source'      => 'system_bundle',
                    'author'      => wp_get_current_user()->user_login ?? 'system',
                    'diff'        => wp_json_encode( $preview['changes'] ),
                    'snapshot_id' => (int) $snapshot_id,
                ],
                [ '%s', '%s', '%s', '%d' ]
            );
            if ( false === $logged ) {
                throw new \RuntimeException( $wpdb->last_error ?: 'Could not write the System Bundle import log.' );
            }
        } catch ( \Throwable $e ) {
            $restored = $this->snapshots->rollback( (int) $snapshot_id );
            return [
                'applied'     => 0,
                'snapshot_id' => (int) $snapshot_id,
                'rolled_back' => ! is_wp_error( $restored ),
                'errors'      => [
                    $e->getMessage(),
                    is_wp_error( $restored )
                        ? 'Automatic recovery also failed: ' . $restored->get_error_message()
                        : 'The complete pre-import snapshot was restored.',
                ],
            ];
        }

        return [
            'applied'     => $applied,
            'snapshot_id' => (int) $snapshot_id,
            'rolled_back' => false,
            'errors'      => [],
        ];
    }

    private function normalize_variable_rows( array $rows ): array {
        $normalized = [];
        foreach ( $rows as $row ) {
            $normalized[] = [
                'name'        => (string) ( $row['name'] ?? '' ),
                'namespace'   => (string) ( $row['namespace'] ?? '' ),
                'category_slug' => sanitize_key( (string) ( $row['category_slug'] ?? 'uncategorized' ) ),
                'origin'      => sanitize_key( (string) ( $row['origin'] ?? '' ) ),
                'type'        => (string) ( $row['type'] ?? 'base' ),
                'value'       => (string) ( $row['value'] ?? '' ),
                'source_name' => (string) ( $row['source_name'] ?? '' ),
                'generator_type' => (string) ( $row['generator_type'] ?? '' ),
            ];
        }
        return $normalized;
    }

    private function sort_variable_changes( array $changes, array $variables ): array {
        $types = [];
        foreach ( $variables as $variable ) {
            $types[ (string) ( $variable['name'] ?? '' ) ] = (string) ( $variable['type'] ?? 'base' );
        }
        $rank = [
            'base'      => 10,
            'generated' => 20,
            'alias'     => 30,
        ];
        usort( $changes, static function ( array $a, array $b ) use ( $types, $rank ): int {
            $action_a = (string) ( $a['action'] ?? '' );
            $action_b = (string) ( $b['action'] ?? '' );
            $rank_a = 'delete' === $action_a ? 90 : ( $rank[ $types[ (string) ( $a['name'] ?? '' ) ] ?? 'base' ] ?? 40 );
            $rank_b = 'delete' === $action_b ? 90 : ( $rank[ $types[ (string) ( $b['name'] ?? '' ) ] ?? 'base' ] ?? 40 );
            if ( $rank_a === $rank_b ) {
                return strcmp( (string) ( $a['name'] ?? '' ), (string) ( $b['name'] ?? '' ) );
            }
            return $rank_a <=> $rank_b;
        } );
        return $changes;
    }

    private function preview_generators( array $desired ): array {
        global $wpdb;
        $current = $wpdb->get_results(
            'SELECT g.type, g.config, v.name AS base_name
             FROM ' . Schema::table( 'generators' ) . ' g
             INNER JOIN ' . Schema::table( 'variables' ) . ' v ON v.id = g.variable_id
             WHERE g.active = 1',
            ARRAY_A
        ) ?: [];
        $current_map = [];
        foreach ( $current as $row ) {
            $current_map[ (string) $row['base_name'] . ':' . (string) $row['type'] ] = $this->canonical_json( json_decode( (string) $row['config'], true ) ?: [] );
        }
        $desired_map = [];
        foreach ( $desired as $row ) {
            $key = (string) $row['base_name'] . ':' . (string) $row['type'];
            $desired_map[ $key ] = $this->canonical_json( $row['config'] );
        }
        $changes = [];
        foreach ( $desired_map as $key => $config ) {
            if ( ! isset( $current_map[ $key ] ) ) {
                $changes[] = [ 'action' => 'generator_add', 'name' => $key ];
            } elseif ( $current_map[ $key ] !== $config ) {
                $changes[] = [ 'action' => 'generator_update', 'name' => $key ];
            }
        }
        foreach ( $current_map as $key => $config ) {
            if ( ! isset( $desired_map[ $key ] ) ) {
                $changes[] = [ 'action' => 'generator_delete', 'name' => $key ];
            }
        }
        return $changes;
    }

    private function preview_themes( array $desired ): array {
        $current = ( new ThemeManager() )->snapshot_state();
        return $this->canonical_json( $current ) === $this->canonical_json( $desired )
            ? []
            : [ [ 'action' => 'themes_update', 'name' => 'Themes' ] ];
    }

    private function preview_palettes( array $desired ): array {
        $current_bundle = $this->export();
        $current = [];
        foreach ( $current_bundle['color_palettes'] as $palette ) {
            $current[ (string) $palette['slug'] ] = $this->canonical_json( $palette );
        }
        $wanted = [];
        foreach ( $desired as $palette ) {
            $wanted[ (string) $palette['slug'] ] = $this->canonical_json( $palette );
        }
        $changes = [];
        foreach ( $wanted as $slug => $value ) {
            if ( ! isset( $current[ $slug ] ) ) {
                $changes[] = [ 'action' => 'palette_add', 'name' => $slug ];
            } elseif ( $current[ $slug ] !== $value ) {
                $changes[] = [ 'action' => 'palette_update', 'name' => $slug ];
            }
        }
        foreach ( $current as $slug => $value ) {
            if ( ! isset( $wanted[ $slug ] ) ) {
                $changes[] = [ 'action' => 'palette_delete', 'name' => $slug ];
            }
        }
        return $changes;
    }

    private function preview_categories( array $desired ): array {
        if ( empty( $desired ) ) {
            return [];
        }
        $current = [];
        foreach ( ( new VariableCategoryManager() )->list() as $category ) {
            $current[ (string) $category['slug'] ] = $this->canonical_json( [
                'slug'      => (string) $category['slug'],
                'name'      => (string) $category['name'],
                'position'  => (int) $category['position'],
                'protected' => ! empty( $category['protected'] ),
            ] );
        }
        $wanted = [];
        foreach ( $desired as $category ) {
            $slug = sanitize_key( (string) ( $category['slug'] ?? '' ) );
            $wanted[ $slug ] = $this->canonical_json( [
                'slug'      => $slug,
                'name'      => sanitize_text_field( (string) ( $category['name'] ?? $slug ) ),
                'position'  => (int) ( $category['position'] ?? 0 ),
                'protected' => 'uncategorized' === $slug || ! empty( $category['protected'] ),
            ] );
        }
        $changes = [];
        foreach ( $wanted as $slug => $value ) {
            if ( ! isset( $current[ $slug ] ) ) {
                $changes[] = [ 'action' => 'category_add', 'name' => $slug ];
            } elseif ( $current[ $slug ] !== $value ) {
                $changes[] = [ 'action' => 'category_update', 'name' => $slug ];
            }
        }
        foreach ( $current as $slug => $value ) {
            if ( 'uncategorized' !== $slug && ! isset( $wanted[ $slug ] ) ) {
                $changes[] = [ 'action' => 'category_delete', 'name' => $slug ];
            }
        }
        return $changes;
    }

    private function sync_categories( array $desired, bool $skip_deletes ): int {
        global $wpdb;
        $table = Schema::table( 'variable_categories' );
        $variables_table = Schema::table( 'variables' );
        if ( empty( $desired ) ) {
            return 0;
        }
        $current_rows = $wpdb->get_results( "SELECT * FROM {$table}", ARRAY_A ) ?: [];
        $current = [];
        foreach ( $current_rows as $row ) {
            $current[ (string) $row['slug'] ] = $row;
        }
        $wanted = [];
        $applied = 0;
        foreach ( $desired as $category ) {
            $slug = sanitize_key( (string) ( $category['slug'] ?? '' ) );
            if ( '' === $slug ) {
                continue;
            }
            $wanted[ $slug ] = true;
            $data = [
                'name'       => sanitize_text_field( (string) ( $category['name'] ?? $slug ) ),
                'position'   => (int) ( $category['position'] ?? 0 ),
                'protected'  => 'uncategorized' === $slug || ! empty( $category['protected'] ) ? 1 : 0,
                'updated_at' => current_time( 'mysql' ),
            ];
            if ( isset( $current[ $slug ] ) ) {
                $updated = $wpdb->update( $table, $data, [ 'slug' => $slug ], [ '%s', '%d', '%d', '%s' ], [ '%s' ] );
                if ( false === $updated ) {
                    throw new \RuntimeException( $wpdb->last_error ?: "Could not update category '{$slug}'." );
                }
                if ( $updated > 0 ) {
                    $applied++;
                }
            } else {
                $inserted = $wpdb->insert(
                    $table,
                    [
                        'slug'       => $slug,
                        'name'       => $data['name'],
                        'position'   => $data['position'],
                        'protected'  => $data['protected'],
                        'created_at' => current_time( 'mysql' ),
                        'updated_at' => $data['updated_at'],
                    ],
                    [ '%s', '%s', '%d', '%d', '%s', '%s' ]
                );
                if ( false === $inserted ) {
                    throw new \RuntimeException( $wpdb->last_error ?: "Could not create category '{$slug}'." );
                }
                $applied++;
            }
        }
        if ( ! $skip_deletes ) {
            foreach ( $current as $slug => $row ) {
                if ( 'uncategorized' === $slug || isset( $wanted[ $slug ] ) ) {
                    continue;
                }
                if ( false === $wpdb->update( $variables_table, [ 'category_slug' => 'uncategorized' ], [ 'category_slug' => $slug ], [ '%s' ], [ '%s' ] ) ) {
                    throw new \RuntimeException( $wpdb->last_error ?: "Could not release variables from category '{$slug}'." );
                }
                if ( false === $wpdb->delete( $table, [ 'slug' => $slug ], [ '%s' ] ) ) {
                    throw new \RuntimeException( $wpdb->last_error ?: "Could not remove category '{$slug}'." );
                }
                $applied++;
            }
        }
        return $applied;
    }

    private function sync_variable_metadata( array $desired ): int {
        global $wpdb;
        $applied = 0;
        foreach ( $desired as $row ) {
            $variable = $this->variables->get_by_name( (string) ( $row['name'] ?? '' ) );
            if ( ! $variable ) {
                continue;
            }
            $category_slug = sanitize_key( (string) ( $row['category_slug'] ?? 'uncategorized' ) );
            $origin = sanitize_key( (string) ( $row['origin'] ?? '' ) );
            if (
                $category_slug === (string) ( $variable['category_slug'] ?? 'uncategorized' )
                && $origin === (string) ( $variable['origin'] ?? '' )
            ) {
                continue;
            }
            $updated = $wpdb->update(
                Schema::table( 'variables' ),
                [ 'category_slug' => $category_slug, 'origin' => $origin ],
                [ 'id' => (int) $variable['id'] ],
                [ '%s', '%s' ],
                [ '%d' ]
            );
            if ( false === $updated ) {
                throw new \RuntimeException( $wpdb->last_error ?: "Could not restore metadata for '{$row['name']}'." );
            }
            if ( $updated > 0 ) {
                $applied++;
            }
        }
        return $applied;
    }

    private function sync_generators( array $desired, bool $skip_deletes ): int {
        global $wpdb;
        $engine = new GeneratorEngine();
        $current = $wpdb->get_results(
            'SELECT g.*, v.name AS base_name
             FROM ' . Schema::table( 'generators' ) . ' g
             INNER JOIN ' . Schema::table( 'variables' ) . ' v ON v.id = g.variable_id
             WHERE g.active = 1',
            ARRAY_A
        ) ?: [];
        $current_map = [];
        foreach ( $current as $row ) {
            $current_map[ (string) $row['base_name'] . ':' . (string) $row['type'] ] = $row;
        }
        $desired_map = [];
        $applied = 0;
        foreach ( $desired as $row ) {
            $base_name = (string) $row['base_name'];
            $type = (string) $row['type'];
            $key = $base_name . ':' . $type;
            $desired_map[ $key ] = true;
            $existing = $current_map[ $key ] ?? null;
            $existing_config = $existing ? ( json_decode( (string) $existing['config'], true ) ?: [] ) : null;
            if ( $existing && $this->canonical_json( $existing_config ) === $this->canonical_json( $row['config'] ) ) {
                $base = $this->variables->get_by_name( $base_name );
                $result = $base ? $engine->regenerate( (int) $base['id'], false ) : null;
                if ( ! $base || is_wp_error( $result ) ) {
                    throw new \RuntimeException( $base ? $result->get_error_message() : "Generator base '{$base_name}' is missing." );
                }
                continue;
            }
            $base = $this->variables->get_by_name( $base_name );
            if ( ! $base || 'base' !== (string) ( $base['type'] ?? '' ) ) {
                throw new \RuntimeException( "Generator base '{$base_name}' is missing or is not a base variable." );
            }
            $result = $engine->attach( (int) $base['id'], $type, $row['config'], true );
            if ( is_wp_error( $result ) ) {
                throw new \RuntimeException( $result->get_error_message() );
            }
            $applied++;
        }
        if ( ! $skip_deletes ) {
            foreach ( $current_map as $key => $row ) {
                if ( isset( $desired_map[ $key ] ) ) {
                    continue;
                }
                $result = $engine->detach( (int) $row['id'] );
                if ( is_wp_error( $result ) ) {
                    throw new \RuntimeException( $result->get_error_message() );
                }
                $applied++;
            }
        }
        return $applied;
    }

    private function sync_themes( array $desired, bool $skip_deletes ): int {
        $manager = new ThemeManager();
        $current = $manager->snapshot_state();
        $next = $desired;
        if ( $skip_deletes ) {
            $next['items'] = array_replace(
                is_array( $current['items'] ?? null ) ? $current['items'] : [],
                is_array( $desired['items'] ?? null ) ? $desired['items'] : []
            );
        }
        if ( $this->canonical_json( $current ) === $this->canonical_json( $next ) ) {
            return 0;
        }
        $manager->restore_snapshot_state( $next );
        return 1;
    }

    private function sync_palettes( array $desired, bool $skip_deletes ): int {
        global $wpdb;
        $palettes_table = Schema::table( 'color_palettes' );
        $members_table = Schema::table( 'color_palette_members' );
        $current_rows = $wpdb->get_results( "SELECT * FROM {$palettes_table}", ARRAY_A ) ?: [];
        $current = [];
        foreach ( $current_rows as $row ) {
            $current[ (string) $row['slug'] ] = $row;
        }
        $desired_slugs = [];
        $palette_ids = [];
        $applied = 0;
        foreach ( $desired as $palette ) {
            $slug = sanitize_key( (string) $palette['slug'] );
            $desired_slugs[ $slug ] = true;
            if ( isset( $current[ $slug ] ) ) {
                $id = (int) $current[ $slug ]['id'];
                $updated = $wpdb->update(
                    $palettes_table,
                    [
                        'name'       => sanitize_text_field( (string) $palette['name'] ),
                        'position'   => (int) ( $palette['position'] ?? 0 ),
                        'updated_at' => current_time( 'mysql' ),
                    ],
                    [ 'id' => $id ],
                    [ '%s', '%d', '%s' ],
                    [ '%d' ]
                );
                if ( false === $updated ) {
                    throw new \RuntimeException( $wpdb->last_error ?: "Could not update palette '{$slug}'." );
                }
                if ( $updated > 0 ) {
                    $applied++;
                }
            } else {
                $inserted = $wpdb->insert(
                    $palettes_table,
                    [
                        'slug'     => $slug,
                        'name'     => sanitize_text_field( (string) $palette['name'] ),
                        'position' => (int) ( $palette['position'] ?? 0 ),
                    ],
                    [ '%s', '%s', '%d' ]
                );
                if ( false === $inserted ) {
                    throw new \RuntimeException( $wpdb->last_error ?: "Could not create palette '{$slug}'." );
                }
                $id = (int) $wpdb->insert_id;
                $applied++;
            }
            $palette_ids[ $slug ] = $id;
        }

        if ( ! $skip_deletes ) {
            foreach ( $current as $slug => $row ) {
                if ( isset( $desired_slugs[ $slug ] ) ) {
                    continue;
                }
                $wpdb->delete( $members_table, [ 'palette_id' => (int) $row['id'] ], [ '%d' ] );
                if ( false === $wpdb->delete( $palettes_table, [ 'id' => (int) $row['id'] ], [ '%d' ] ) ) {
                    throw new \RuntimeException( $wpdb->last_error ?: "Could not remove palette '{$slug}'." );
                }
                $applied++;
            }
            if ( false === $wpdb->query( "DELETE FROM {$members_table}" ) ) {
                throw new \RuntimeException( $wpdb->last_error ?: 'Could not reset palette memberships.' );
            }
        }

        $assigned_names = [];
        foreach ( $desired as $palette ) {
            $slug = sanitize_key( (string) $palette['slug'] );
            $palette_id = (int) ( $palette_ids[ $slug ] ?? 0 );
            foreach ( $palette['members'] as $position => $name ) {
                $name = (string) $name;
                $variable = $this->variables->get_by_name( $name );
                if ( ! $variable ) {
                    throw new \RuntimeException( "Palette member '{$name}' is missing after variable import." );
                }
                if ( $skip_deletes && ! isset( $assigned_names[ $name ] ) ) {
                    $wpdb->delete( $members_table, [ 'variable_id' => (int) $variable['id'] ], [ '%d' ] );
                }
                $inserted = $wpdb->replace(
                    $members_table,
                    [
                        'palette_id'  => $palette_id,
                        'variable_id' => (int) $variable['id'],
                        'position'    => (int) $position,
                    ],
                    [ '%d', '%d', '%d' ]
                );
                if ( false === $inserted ) {
                    throw new \RuntimeException( $wpdb->last_error ?: "Could not assign '{$name}' to '{$slug}'." );
                }
                $assigned_names[ $name ] = true;
            }
        }
        ( new ColorPaletteManager() )->repair_memberships();
        return $applied;
    }

    private function sync_variable_order( array $desired, bool $skip_deletes ): void {
        $ids = [];
        foreach ( $desired as $row ) {
            $variable = $this->variables->get_by_name( (string) ( $row['name'] ?? '' ) );
            if ( $variable ) {
                $ids[] = (int) $variable['id'];
            }
        }
        if ( $skip_deletes ) {
            foreach ( $this->variables->get_all() as $variable ) {
                $id = (int) ( $variable['id'] ?? 0 );
                if ( $id > 0 && ! in_array( $id, $ids, true ) ) {
                    $ids[] = $id;
                }
            }
        }
        if ( ! empty( $ids ) ) {
            $result = $this->variables->reorder( $ids );
            if ( is_wp_error( $result ) ) {
                throw new \RuntimeException( $result->get_error_message() );
            }
        }
    }

    private function canonical_json( $value ): string {
        if ( is_array( $value ) ) {
            if ( array_keys( $value ) !== range( 0, count( $value ) - 1 ) ) {
                ksort( $value );
            }
            foreach ( $value as $key => $item ) {
                $value[ $key ] = is_array( $item ) ? json_decode( $this->canonical_json( $item ), true ) : $item;
            }
        }
        return (string) wp_json_encode( $value );
    }
}
