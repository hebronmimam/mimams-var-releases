(function(){
'use strict';
if(window.self!==window.top&&document.querySelector('.brx-body'))return;
if(!window.preact||!window.preactHooks){
  const showMissingRuntime=()=>{try{
    if(document.getElementById('ve-boot-fallback'))return;
    const b=document.createElement('button');
    b.id='ve-boot-fallback';
    b.type='button';
    b.textContent='MV';
    b.title='Mimam’s Var runtime did not load. Click to reload.';
    b.style.cssText='position:fixed;right:16px;bottom:16px;z-index:120050;width:38px;height:38px;border-radius:10px;border:1px solid #baf400;background:#1f1f1f;color:#baf400;font:700 11px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;cursor:pointer;box-shadow:0 8px 22px rgba(0,0,0,.35)';
    b.addEventListener('click',()=>window.location.reload());
    document.body.appendChild(b);
    console.error('Mimam’s Var runtime dependency missing', {preact:!!window.preact, hooks:!!window.preactHooks});
  }catch(e){}};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',showMissingRuntime,{once:true});else showMissingRuntime();
  return;
}
const{h,render}=window.preact;const{useState,useEffect,useRef,useMemo,useCallback}=window.preactHooks;
const CFG=window.vePanel||{};const MODE=CFG.mode||'admin';
const NATIVE_MEDIA_REPLACEMENT_ENABLED=false;
const MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED=true;
const apiActivity={count:0,label:'Working…',progress:0,panelId:'variables',failed:false,listeners:new Set(),nextId:1,active:new Map(),timer:null};
function apiActivityLabel(path,method){
  const clean=String(path||'').replace(/^variable-engine\/v1\//,'').split('?')[0];
  if(clean==='migration/preview')return'Scanning external variables…';
  if(clean==='migration/apply')return'Importing external variables…';
  if(clean==='sync/preview')return'Preparing import preview…';
  if(clean==='sync/apply')return'Applying imported variables…';
  if(clean==='sync/preview-bundle')return'Preparing System Bundle preview…';
  if(clean==='sync/apply-bundle')return'Restoring System Bundle…';
  if(/^sync\/rollback\//.test(clean))return'Restoring snapshot…';
  if(clean==='sync/snapshot')return'Creating snapshot…';
  if(/^generators(?:\/|$)/.test(clean)&&String(method||'GET').toUpperCase()!=='GET')return'Generating variables…';
  if(/^color-palettes\/.+\/(?:duplicate|delete-preview)$/.test(clean))return'Updating Color Palettes…';
  if(/^themes\/.+\/duplicate$/.test(clean))return'Updating Themes…';
  if(clean==='update/install')return'Installing Mimam’s Var update…';
  return'';
}
function notifyApiActivity(){
  const state={count:apiActivity.count,label:apiActivity.label,progress:apiActivity.progress,panelId:apiActivity.panelId,failed:apiActivity.failed};
  apiActivity.listeners.forEach(listener=>{try{listener(state);}catch(e){}});
}
function apiActivityPanelId(){
  try{
    const panel=document.activeElement?.closest?.('[data-panel]');
    return panel?.dataset?.panel||'variables';
  }catch(e){return'variables';}
}
function startApiActivityTimer(){
  if(apiActivity.timer)clearInterval(apiActivity.timer);
  apiActivity.timer=setInterval(()=>{
    if(!apiActivity.count)return;
    if(apiActivity.progress<45)apiActivity.progress+=5;
    else if(apiActivity.progress<75)apiActivity.progress+=3;
    else if(apiActivity.progress<92)apiActivity.progress+=1;
    apiActivity.progress=Math.min(apiActivity.progress,92);
    notifyApiActivity();
  },500);
}
function beginApiActivity(path,method){
  const label=apiActivityLabel(path,method);
  if(!label)return 0;
  const id=apiActivity.nextId++;
  apiActivity.active.set(id,label);
  apiActivity.count=apiActivity.active.size;
  if(apiActivity.count===1){
    apiActivity.label=label;
    apiActivity.progress=8;
    apiActivity.failed=false;
    apiActivity.panelId=apiActivityPanelId();
    startApiActivityTimer();
  }
  notifyApiActivity();
  return id;
}
function endApiActivity(id,failed=false){
  if(!id)return;
  if(failed)apiActivity.failed=true;
  apiActivity.active.delete(id);
  apiActivity.count=apiActivity.active.size;
  if(!apiActivity.count){
    if(apiActivity.timer)clearInterval(apiActivity.timer);
    apiActivity.timer=null;
    apiActivity.progress=100;
  }
  notifyApiActivity();
}

const api={
f:async(p,o={})=>{
  const activityId=beginApiActivity(p,o.method||'GET');
  let failed=false;
  try{
    const r=await fetch((CFG.apiRoot||'/wp-json/')+p,{credentials:'same-origin',...o,headers:{'X-WP-Nonce':CFG.nonce||'',...(o.headers||{})}});
    const ct=(r.headers.get('content-type')||'').toLowerCase();
    const txt=await r.text();
    let data=null;
    if(ct.includes('application/json')){
      try{data=txt?JSON.parse(txt):{};}catch(e){data={code:'ve_bad_json',message:'WordPress returned invalid JSON.'};}
    }else{
      data={code:'ve_non_json',message:r.ok?'Unexpected non-JSON response from WordPress.':'WordPress returned an error while previewing impact.',raw:txt};
    }
    if(!r.ok&&!data.code)data.code='ve_http_'+r.status;
    failed=!r.ok||!!data?.code;
    return data;
  }catch(error){
    failed=true;
    return{code:'ve_network_error',message:'WordPress did not finish the request. Check the server error log, then try again.',detail:String(error?.message||error||'Network request failed')};
  }finally{
    endApiActivity(activityId,failed);
  }
},
g:p=>api.f('variable-engine/v1/'+p),
p:async(p,b)=>{
  const d=await api.f('variable-engine/v1/'+p,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
  if(!d?.code){
    if(isVariableMutationPath(p))refreshVariableStylesheets();
    if(p.split('?')[0]==='settings')refreshSettings();
  }
  return d;
},
u:async(p,b)=>{
  const d=await api.f('variable-engine/v1/'+p,{method:'PUT',headers:{'Content-Type':'application/json'},body:JSON.stringify(b)});
  if(!d?.code){
    if(isVariableMutationPath(p))refreshVariableStylesheets();
    if(p.split('?')[0]==='settings')refreshSettings();
  }
  return d;
},
d:async(p,b)=>{
  const opts={method:'DELETE'};
  if(b!==undefined){opts.headers={'Content-Type':'application/json'};opts.body=JSON.stringify(b);}
  const d=await api.f('variable-engine/v1/'+p,opts);
  if(!d?.code&&isVariableMutationPath(p))refreshVariableStylesheets();
  return d;
},
};

function isVariableMutationPath(path){
  const clean=String(path||'').split('?')[0];
  if(/rename-preview$/.test(clean))return false;
  return /^(variables(?:\/|$)|generators(?:\/|$)|palettes(?:\/|$)|themes(?:\/|$)|color-palettes(?:\/|$)|migration\/apply$|sync\/apply(?:-bundle)?$|sync\/import(?:\/|$)|sync\/rollback\/|snapshots\/[^/]+\/rollback$)/.test(clean);
}
const variablePreviewValues=new Map();
function builderRuntimeWindows(){
  const found=[],queue=[];
  const add=runtime=>{
    try{
      if(runtime&&runtime.document&&!found.includes(runtime)){
        found.push(runtime);
        queue.push(runtime);
      }
    }catch(e){}
  };
  add(window);
  try{add(window.parent);}catch(e){}
  try{add(window.top);}catch(e){}
  while(queue.length){
    const runtime=queue.shift();
    try{runtime.document.querySelectorAll('iframe').forEach(frame=>add(frame.contentWindow));}catch(e){}
  }
  return found;
}
function builderRuntimeDocuments(){
  const found=[];
  builderRuntimeWindows().forEach(runtime=>{
    try{if(runtime.document&&!found.includes(runtime.document))found.push(runtime.document);}catch(e){}
  });
  return found;
}
function renderVariablePreviewStyles(){
  const cssText=variablePreviewValues.size
    ? ':root {\n'+Array.from(variablePreviewValues.entries()).map(([name,value])=>`  ${name}: ${value} !important;`).join('\n')+'\n}'
    : '';
  builderRuntimeDocuments().forEach(doc=>{
    try{
      let styleEl=doc.getElementById('ve-variable-preview-runtime');
      if(!cssText){
        styleEl?.remove();
        return;
      }
      if(!styleEl){
        styleEl=doc.createElement('style');
        styleEl.id='ve-variable-preview-runtime';
        (doc.head||doc.documentElement).appendChild(styleEl);
      }
      styleEl.textContent=cssText;
    }catch(e){}
  });
}
function applyVariablePreview(name,value){
  const cssName=cssTokenName(name);
  if(!cssName||!value)return;
  variablePreviewValues.set(cssName,value);
  renderVariablePreviewStyles();
}
function clearVariablePreview(name){
  variablePreviewValues.delete(cssTokenName(name));
  renderVariablePreviewStyles();
}
function refreshVariableStylesheets(){
  const docs=builderRuntimeDocuments();
  let pending=0;
  const announce=()=>{
    syncBricksVariableConsumers();
    builderRuntimeWindows().forEach(win => {
      try {
        win.dispatchEvent(new win.CustomEvent('ve-variables-updated',{detail:{at:Date.now()}}));
        win.document.dispatchEvent(new win.CustomEvent('ve:variables-updated',{detail:{at:Date.now()}}));
      } catch (e) {
        try { win.dispatchEvent(new CustomEvent('ve-variables-updated',{detail:{at:Date.now()}})); } catch (err) {}
      }
    });
  };
  docs.forEach(doc=>{
    Array.from(doc.querySelectorAll('link[rel="stylesheet"]')).filter(link=>{
      const href=link.getAttribute('href')||'';
      return /\/variable-engine\/variables\.css(?:[?#]|$)/.test(href)||/^ve-variables(?:-admin)?-css$/.test(link.id||'');
    }).forEach(link=>{
      let nextUrl;
      try{nextUrl=new URL(link.href,doc.baseURI);nextUrl.searchParams.set('ve-refresh',Date.now().toString());}catch(e){return;}
      const next=link.cloneNode(true);
      next.href=nextUrl.toString();
      next.id=link.id;
      pending++;
      next.addEventListener('load',()=>{link.remove();pending--;if(pending===0)announce();},{once:true});
      next.addEventListener('error',()=>{next.remove();pending--;if(pending===0)announce();},{once:true});
      link.parentNode?.insertBefore(next,link.nextSibling);
    });
  });
  if(pending===0)announce();
}
function refreshSettings(){
  builderRuntimeWindows().forEach(win => {
    try {
      win.dispatchEvent(new win.CustomEvent('ve-settings-updated',{detail:{at:Date.now()}}));
    } catch (e) {
      try { win.dispatchEvent(new CustomEvent('ve-settings-updated',{detail:{at:Date.now()}})); } catch (err) {}
    }
  });
}
let bricksVariableSyncPromise=null;
async function syncBricksVariableConsumers(){
  if(MODE!=='builder')return false;
  if(bricksVariableSyncPromise)return bricksVariableSyncPromise;
  bricksVariableSyncPromise=(async()=>{
  let variables;
  try{variables=await api.g('variables?dedupe=true&_nc='+Date.now());}catch(e){return false;}
  if(!Array.isArray(variables))return false;
  const mirrored=variables.map(v=>({
    id:'mv-'+v.id,
    name:cssTokenName(v.name).replace(/^--/,''),
    value:v.css_value||v.value||'',
    category:'mimams-var'
  })).filter(v=>v.name);
  const signature=mirrored.map(v=>v.name+'\u0000'+v.value).join('\u0001');
  const apply=()=>{
    let providerFound=false;
    builderRuntimeWindows().forEach(runtime=>{
      try{
        const current=Array.isArray(runtime.bricksData?.loadData?.globalVariables)?runtime.bricksData.loadData.globalVariables:[];
        const external=current.filter(v=>v&&v.category!=='mimams-var'&&!String(v.id||'').startsWith('mv-'));
        const externalNames=new Set(external.map(v=>String(v?.name||'').replace(/^--/,'')).filter(Boolean));
        const localMirrored=mirrored.filter(v=>!externalNames.has(v.name));
        const runtimeCssText=':root {\n'+localMirrored.map(v=>`  --${v.name}: ${v.value} !important;`).join('\n')+'\n}';
        const changed=runtime.__veVariableSignature!==signature;
        if(changed&&runtime.bricksData?.loadData)runtime.bricksData.loadData.globalVariables=[...external,...localMirrored];
        const provider=runtime.Code2Bricks?.css?.CssVariableProvider;
        if(provider){
          providerFound=true;
          if(changed){
            if(provider.refresh)provider.refresh();
            const mvNames=localMirrored.map(v=>'--'+v.name);
            const existing=Array.isArray(provider._variables)?provider._variables:[];
            provider._variables=Array.from(new Set([...existing,...mvNames])).sort();
            provider._variablesFormatted=provider._variables.map(name=>`var(${name})`);
            provider._lastRefresh=Date.now();
          }
        }
        if(changed&&runtime.document){
          let styleEl=runtime.document.getElementById('ve-dynamic-variables-runtime');
          if(!styleEl){
            styleEl=runtime.document.createElement('style');
            styleEl.id='ve-dynamic-variables-runtime';
            (runtime.document.head||runtime.document.documentElement).appendChild(styleEl);
          }
          styleEl.textContent=runtimeCssText;
          runtime.document.querySelectorAll('iframe').forEach(frame=>{
            if(frame.__veVariableRuntimeLoadBound)return;
            frame.__veVariableRuntimeLoadBound=true;
            frame.addEventListener('load',()=>setTimeout(apply,0));
          });
        }
        runtime.__veVariableSignature=signature;
      }catch(e){}
    });
    renderVariablePreviewStyles();
    return providerFound;
  };
  const providerFound=apply();
  if(!providerFound)setTimeout(apply,600);
  return providerFound;
  })();
  try{return await bricksVariableSyncPromise;}finally{bricksVariableSyncPromise=null;}
}

const USER_PREF_KEYS=[
  'mimamsBarSettings','ve_skip_update_version','ve_panel_mode','ve_panel_pos','ve_allow_multi_panels',
  've_css_scss','ve_css_source_order','ve_css_disabled_sources',
  've_content_visible_groups','ve_media_layout','ve_media_filter','ve_media_sort','ve_media_collection_sort','ve_media_collections','ve_plugin_directory_view','ve_fab_order',
  've_pos_ve_settings_pos','ve_pos_ve_help_pos','ve_pos_ve_css_studio_pos','ve_pos_ve_css_recipes_pos',
  've_pos_ve_content_pos','ve_pos_ve_media_pos','ve_pos_ve_plugin_pos'
];
const USER_PREF_RAW_STRING_KEYS=['ve_media_collections'];
let userPreferenceTimer=null;
function preferenceStorageValue(value){
  return value&&typeof value==='object'?JSON.stringify(value):String(value??'');
}
function hydrateUserPreferences(){
  const remote=CFG.userPreferences&&typeof CFG.userPreferences==='object'?CFG.userPreferences:{};
  Object.keys(remote).forEach(key=>{
    if(!USER_PREF_KEYS.includes(key))return;
    try{
      if(key==='ve_media_collections'){
        const localRaw=localStorage.getItem(key);
        const remoteRaw=preferenceStorageValue(remote[key]);
        if(localRaw&&remoteRaw){
          try{
            const localObj=JSON.parse(localRaw);
            const remoteObj=JSON.parse(remoteRaw);
            if(localObj&&remoteObj&&typeof localObj==='object'&&typeof remoteObj==='object'&&!Array.isArray(localObj)&&!Array.isArray(remoteObj)){
              const merged={...remoteObj,...localObj};
              localStorage.setItem(key,JSON.stringify(merged));
              return;
            }
          }catch(err){}
        }
      }
      localStorage.setItem(key,preferenceStorageValue(remote[key]));
    }catch(e){}
  });
  return Object.keys(remote).length>0;
}
function collectUserPreferences(){
  const preferences={};
  USER_PREF_KEYS.forEach(key=>{
    let raw='';
    try{raw=localStorage.getItem(key);}catch(e){raw=null;}
    if(raw===null)return;
    if(USER_PREF_RAW_STRING_KEYS.includes(key)){preferences[key]=raw;return;}
    if(/^[\[{]/.test(raw)){
      try{preferences[key]=JSON.parse(raw);return;}catch(e){}
    }
    preferences[key]=raw;
  });
  return preferences;
}
function syncUserPreferences(){
  api.p('user-preferences',{preferences:collectUserPreferences()}).catch(()=>{});
}
function persistUserPreference(key,value){
  try{localStorage.setItem(key,preferenceStorageValue(value));}catch(e){}
  if(!USER_PREF_KEYS.includes(key))return;
  if(userPreferenceTimer)clearTimeout(userPreferenceTimer);
  userPreferenceTimer=setTimeout(syncUserPreferences,280);
}
window.vePersistUserPreference=persistUserPreference;
const hadRemoteUserPreferences=hydrateUserPreferences();
if(!hadRemoteUserPreferences)setTimeout(syncUserPreferences,1200);
else{try{if(localStorage.getItem('ve_media_collections'))setTimeout(syncUserPreferences,1600);}catch(e){}}

function fuzzy(q,tLower){if(tLower.includes(q))return{m:1,s:tLower.indexOf(q)===0?100:80};let i=0,s=0;for(let j=0;j<tLower.length&&i<q.length;j++)if(tLower[j]===q[i]){i++;s+=10;}return{m:i===q.length,s};}
function tokenParts(n){return String(n||'').split('.').filter(Boolean);}
function stripStorageWrapper(n){const p=tokenParts(n);const wrappers=['size','font','typography'];return p.length>1&&wrappers.includes(p[0])?p.slice(1).join('.'):p.join('.');}
function cssTokenName(n){return '--'+stripStorageWrapper(n).replace(/\./g,'-');}
function sn(n){const clean=stripStorageWrapper(n);const p=clean.split('.');return p.length>1?p.slice(1).join('.'):clean;}
function normalizeNameInput(v){return String(v||'').toLowerCase().replace(/[\s._]+/g,'-').replace(/[^a-z0-9-]/g,'').replace(/-+/g,'-').replace(/^-+/,'');}
function publicTokenLabel(n){return cssTokenName(n).replace(/^--/,'');}
function safeFilePart(value,fallback='site'){
  const clean=String(value||'').toLowerCase().trim().replace(/[^a-z0-9]+/g,'-').replace(/^-+|-+$/g,'');
  return clean||fallback;
}
function detectAliasSource(value, vars){
  if (!value || typeof value !== 'string') return null;
  const clean = value.trim();
  let cssName = '';
  const m1 = clean.match(/^var\(\s*(--[a-z0-9.-]+)\s*\)$/i);
  const m2 = clean.match(/^(--[a-z0-9.-]+)$/i);
  if (m1) cssName = m1[1];
  else if (m2) cssName = m2[1];
  if (cssName) {
    const found = (vars || []).find(v => cssTokenName(v.name).toLowerCase() === cssName.toLowerCase());
    return found ? found.id : null;
  }
  return null;
}
function resolvedVariableValue(v, vars, visited = new Set()) {
  const id=String(v?.id??'');
  if (!v || visited.has(id)) return '';
  visited.add(id);
  if (v.type === 'alias' && v.source_id) {
    const parent = (vars || []).find(x => String(x.id) === String(v.source_id));
    return parent ? resolvedVariableValue(parent, vars, visited) : '';
  }
  return v.value || '';
}
function isClr(v){return/^(#|rgb|hsl|oklch)/i.test(v||'');}
function clrToHex(v){if(!v)return'#000000';if(v.charAt(0)==='#'){let h=v.slice(1);if(h.length===3)h=h[0]+h[0]+h[1]+h[1]+h[2]+h[2];return'#'+h.slice(0,6);}
const rm=v.match(/rgba?\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)/);if(rm)return'#'+[rm[1],rm[2],rm[3]].map(x=>('0'+(+x).toString(16)).slice(-2)).join('');
const om=v.match(/oklch\(\s*([\d.]+)\s+([\d.]+)\s+([\d.]+)/);if(om){const L=+om[1],C=+om[2],H=+om[3],hr=H*Math.PI/180,a=C*Math.cos(hr),b=C*Math.sin(hr),l_=L+.3963377774*a+.2158037573*b,m_=L-.1055613458*a-.0638541728*b,s_=L-.0894841775*a-1.291485548*b,l=l_*l_*l_,m=m_*m_*m_,s=s_*s_*s_,rl=4.0767416621*l-3.3077115913*m+.2309699292*s,gl=-1.2684380046*l+2.6097574011*m-.3413193965*s,bl=-.0041960863*l-.7034186147*m+1.707614701*s,gm=x=>x<=.0031308?12.92*x:1.055*Math.pow(Math.max(0,x),1/2.4)-.055,r=Math.round(Math.max(0,Math.min(1,gm(rl)))*255),g=Math.round(Math.max(0,Math.min(1,gm(gl)))*255),bv=Math.round(Math.max(0,Math.min(1,gm(bl)))*255);return'#'+('0'+r.toString(16)).slice(-2)+('0'+g.toString(16)).slice(-2)+('0'+bv.toString(16)).slice(-2);}
const hm=v.match(/hsla?\(\s*([\d.]+)\s*,?\s*([\d.]+)%?\s*,?\s*([\d.]+)%?/);if(hm){const hu=+hm[1]/360,sa=+hm[2]/100,li=+hm[3]/100,q=li<.5?li*(1+sa):li+sa-li*sa,p=2*li-q,h2r=(pp,qq,t)=>{if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return pp+(qq-pp)*6*t;if(t<.5)return qq;if(t<2/3)return pp+(qq-pp)*(2/3-t)*6;return pp;},r=Math.round((sa===0?li:h2r(p,q,hu+1/3))*255),g=Math.round((sa===0?li:h2r(p,q,hu))*255),bv=Math.round((sa===0?li:h2r(p,q,hu-1/3))*255);return'#'+('0'+r.toString(16)).slice(-2)+('0'+g.toString(16)).slice(-2)+('0'+bv.toString(16)).slice(-2);}
return'#000000';}
function pxV(v){const str=(v||'').toString();const cm=str.match(/clamp\([^,]+,[^,]+,\s*([\d.]+)(rem|px)?/i);if(cm){return (cm[2]||'')==='rem'?parseFloat(cm[1])*10:parseFloat(cm[1]);}const m=str.match(/([\d.]+)(rem|px)?/i);if(!m)return 0;return (m[2]||'')==='rem'?parseFloat(m[1])*10:parseFloat(m[1]);}
function pxToRemValue(v){const n=parseFloat((v||'').toString().replace(/[^0-9.]/g,''));if(!isFinite(n))return'';return (Math.round((n/10)*10000)/10000).toString().replace(/\.?0+$/,'')+'rem';}
/* ── Fluid value helpers (mirror core/FluidValue.php) ── */
const FLUID_PREFIX='fluid:';
let _veViewport={vw_min:320,vw_max:1440};
function isFluidVal(v){return (v||'').toString().trim().toLowerCase().indexOf(FLUID_PREFIX)===0;}
function fluidMarker(min,max){const a=parseFloat(min),b=parseFloat(max);if(!isFinite(a)||!isFinite(b))return'';return FLUID_PREFIX+trimNum(a)+','+trimNum(b);}
function parseFluid(v){if(!isFluidVal(v))return null;const body=(v||'').toString().trim().slice(FLUID_PREFIX.length);const p=body.split(',').map(s=>s.trim());if(p.length!==2||!isFinite(parseFloat(p[0]))||!isFinite(parseFloat(p[1])))return null;return[parseFloat(p[0]),parseFloat(p[1])];}
function trimNum(n){let s=(Math.round(n*10000)/10000).toString();return s;}
function fluidClamp(minPx,maxPx,vwMin,vwMax,unit){let a=Math.round(minPx*1000)/1000,b=Math.round(maxPx*1000)/1000;if(a>b){const t=a;a=b;b=t;}let span=vwMax-vwMin;if(span<=0)span=1;const slope=(b-a)/span;const intercept=a-slope*vwMin;const slopeVw=Math.round(slope*100*10000)/10000;if(unit==='px'){return`clamp(${trimNum(a)}px, ${trimNum(Math.round(intercept*1000)/1000)}px + ${slopeVw}vw, ${trimNum(b)}px)`;}return`clamp(${trimNum(Math.round(a/10*10000)/10000)}rem, ${trimNum(Math.round(intercept/10*10000)/10000)}rem + ${slopeVw}vw, ${trimNum(Math.round(b/10*10000)/10000)}rem)`;}
function fluidPreview(min,max){const a=parseFloat(min),b=parseFloat(max);if(!isFinite(a)||!isFinite(b))return'';return fluidClamp(a,b,_veViewport.vw_min,_veViewport.vw_max,'rem');}
function hexOklch(hex){hex=hex.replace('#','');if(hex.length===3)hex=hex[0]+hex[0]+hex[1]+hex[1]+hex[2]+hex[2];const r=parseInt(hex.substr(0,2),16)/255,g=parseInt(hex.substr(2,2),16)/255,b=parseInt(hex.substr(4,2),16)/255;const f=v=>v<=.04045?v/12.92:Math.pow((v+.055)/1.055,2.4);const rl=f(r),gl=f(g),bl=f(b);const l_=.4122214708*rl+.5363325363*gl+.0514459929*bl,m_=.2119034982*rl+.6806995451*gl+.1073969566*bl,s_=.0883024619*rl+.2817188376*gl+.6299787005*bl;const lc=Math.cbrt(Math.max(0,l_)),mc=Math.cbrt(Math.max(0,m_)),sc=Math.cbrt(Math.max(0,s_));const L=.2104542553*lc+.793617785*mc-.0040720468*sc,a=1.9779984951*lc-2.428592205*mc+.4505937099*sc,bv=.0259040371*lc+.7827717662*mc-.808675766*sc;const cc=Math.sqrt(a*a+bv*bv);let H=Math.atan2(bv,a)*180/Math.PI;if(H<0)H+=360;return`oklch(${Math.max(0,Math.min(1,L)).toFixed(4)} ${cc.toFixed(4)} ${H.toFixed(2)})`;}
function fmtD(hex,fmt){if(fmt==='oklch')return hexOklch(hex);const rr=parseInt(hex.replace('#','').substr(0,2),16),gg=parseInt(hex.replace('#','').substr(2,2),16),bb=parseInt(hex.replace('#','').substr(4,2),16);if(fmt==='hex')return hex;if(fmt==='rgb')return`rgb(${rr},${gg},${bb})`;const rn=rr/255,gn=gg/255,bn=bb/255,mx=Math.max(rn,gn,bn),mn=Math.min(rn,gn,bn),l=(mx+mn)/2;let hu=0,s=0;if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);if(mx===rn)hu=((gn-bn)/d+(gn<bn?6:0))/6;else if(mx===gn)hu=((bn-rn)/d+2)/6;else hu=((rn-gn)/d+4)/6;}return`hsl(${Math.round(hu*360)},${Math.round(s*100)}%,${Math.round(l*100)}%)`;}
const ph=(n,props={})=>h('i',{...(props||{}),class:`ph-duotone ph-${n} `+(props.class||''),style:props.style||'font-size:13px;line-height:1'});
const IX_PATHS={
  filter:[['M4 6h16',.9],['M7 12h10',.9],['M10 18h4',.9],['M8 4v4M16 10v4M12 16v4',.35]],
  x:[['M7 7l10 10M17 7L7 17',.9]],
  plus:[['M12 5v14M5 12h14',.9]],
  trash:[['M7 8h10M10 11v6M14 11v6M9 8l1-2h4l1 2M8 8l1 12h6l1-12',.9]],
  'pencil-simple':[['M5 16l-1 4 4-1 10-10-3-3L5 16z',.9],['M13 6l3 3',.35]],
  'tree-structure':[['M7 5h5v5H7zM12 7h5v10M7 17h5',.75],['M5 15h4v4H5zM15 15h4v4h-4z',.9]],
  'folder-open':[['M3 8h7l2 2h9l-2 9H4z',.9],['M3 8v10',.35]],
  folder:[['M3 7h7l2 2h9v10H3z',.9]],
  'folder-dashed':[['M3 8h6l2 2h10v9H3z',.45],['M5 8h2M12 10h3M17 10h2',.9]],
  'download-simple':[['M12 4v11M8 11l4 4 4-4',.9],['M5 20h14',.35]],
  'upload-simple':[['M12 20V9M8 13l4-4 4 4',.9],['M5 20h14',.35]],
  'arrows-merge':[['M7 4v4c0 4 10 4 10 8v4',.75],['M17 4v6M14 7l3 3 3-3M14 17l3 3 3-3',.9]],
  'arrows-clockwise':[['M7 7a7 7 0 0110-1l2 2M17 17a7 7 0 01-10 1l-2-2',.9]],
  'arrows-out-line-vertical':[['M12 4v16M8 8l4-4 4 4M8 16l4 4 4-4',.9]],
  command:[['M8 8h8v8H8z',.35],['M7 4a3 3 0 013 3v10a3 3 0 11-3-3h10a3 3 0 11-3 3V7a3 3 0 113-3',.85]],
  'magic-wand':[['M5 19L19 5',.9],['M14 4l1 2 2 1-2 1-1 2-1-2-2-1 2-1zM6 6l1 1M4 11h2M11 4v2',.65]],
  images:[['M4 6h13v10H4z',.65],['M7 9l3 3 2-2 3 4',.9],['M8 18h12V9',.35]],
  tray:[['M5 5h14v9l-3 5H8l-3-5z',.65],['M8 14h2l1 2h2l1-2h2',.9]],
  'lock-simple':[['M7 10h10v10H7z',.75],['M9 10V8a3 3 0 016 0v2',.9]],
  'lock-open':[['M7 10h10v10H7z',.75],['M9 10V8a3 3 0 015.2-2',.9]],
  'dots-six-vertical':[['M8 5h.1M8 12h.1M8 19h.1M16 5h.1M16 12h.1M16 19h.1',.9]],
  copy:[['M8 8h10v10H8z',.85],['M5 5h10',.35],['M5 5v10',.35]],
  'file-arrow-down':[['M7 4h7l4 4v12H7z',.55],['M14 4v5h4M12 11v6M9 14l3 3 3-3',.9]],
  eye:[['M3 12s3-6 9-6 9 6 9 6-3 6-9 6-9-6-9-6z',.55],['M12 9a3 3 0 100 6 3 3 0 000-6z',.9]],
  'eye-slash':[['M4 4l16 16',.9],['M3 12s3-6 9-6c2 0 3.8.6 5.2 1.4M21 12s-3 6-9 6c-2 0-3.8-.6-5.2-1.4',.45]],
  columns:[['M4 5h16v14H4z',.35],['M10 5v14M15 5v14',.9]],
  table:[['M4 5h16v14H4z',.45],['M4 10h16M4 15h16M10 5v14',.9]],
  'squares-four':[['M4 4h6v6H4zM14 4h6v6h-6zM4 14h6v6H4zM14 14h6v6h-6z',.85]],
  'grid-four':[['M4 5h7v5H4zM13 5h7v8h-7zM4 12h7v7H4zM13 15h7v4h-7z',.85]],
  masonry:[['M4 4h4v7H4zM4 13h4v7H4zM10 4h4v4h-4zM10 10h4v10h-4zM16 4h4v9h-4zM16 15h4v5h-4z',.9]],
  list:[['M8 6h12M8 12h12M8 18h12',.9],['M4 6h1M4 12h1M4 18h1',.9]],
  'text-aa':[['M4 18l4-12 4 12M6 14h4',.9],['M14 18l2-6 2 6M15 16h2',.65]],
  'hard-drive':[['M5 6h14l2 8v4H3v-4z',.65],['M6 15h12M17 16h1',.9]],
  'bounding-box':[['M5 5h5M14 5h5M5 19h5M14 19h5M5 5v5M19 5v5M5 14v5M19 14v5',.9]],
  'image-square':[['M4 5h16v14H4z',.55],['M7 15l3-3 2 2 3-4 3 5',.9]],
  'device-mobile':[['M8 3h8v18H8z',.65],['M11 18h2',.9]],
  square:[['M5 5h14v14H5z',.85]],
  'caret-down':[['M8 10l4 4 4-4',.9]],
  'caret-right':[['M10 8l4 4-4 4',.9]]
};
const ix=(name,props={})=>{
  const paths=IX_PATHS[name]||IX_PATHS.square;
  return h('svg',{...(props||{}),class:'ve-ix ve-ix-'+name+' '+(props.class||''),viewBox:'0 0 24 24','aria-hidden':'true',focusable:'false',style:props.style||{}},
    paths.map((p,i)=>h('path',{key:i,d:p[0],opacity:p[1]||1,fill:'none',stroke:'currentColor','stroke-width':'1.8','stroke-linecap':'round','stroke-linejoin':'round'}))
  );
};
const SPEED_DIAL_TOOLS=[
  {id:'variables',label:'Variable Panel',icon:'sliders-horizontal',module:'variables'},
  {id:'help',label:'Help',icon:'question'},
  {id:'css_studio',label:'CSS Studio',icon:'code',module:'css_studio'},
  {id:'css_recipes',label:'CSS Recipes',icon:'brackets-curly',module:'css_studio'},
  {id:'content_studio',label:'Content Studio',icon:'file-text',module:'content_studio'},
  {id:'media_studio',label:'Media Studio',icon:'image',module:'media_studio'},
  {id:'plugin_studio',label:'Plugin Studio',icon:'plugs',module:'plugin_studio'},
  {id:'mimams_bar',label:"Mimam's Bar (Alt+Q)",icon:'terminal',module:'mimams_bar'}
];
function normalizeFabOrder(order){
  const ids=SPEED_DIAL_TOOLS.map(tool=>tool.id);
  const seen=new Set();
  const clean=(Array.isArray(order)?order:[]).filter(id=>ids.includes(id)&&!seen.has(id)&&(seen.add(id),true));
  return [...clean,...ids.filter(id=>!seen.has(id))];
}
const TSHIRT_UP=['s','m','l','xl','2xl','3xl','4xl','5xl','6xl','7xl','8xl'];
const TSHIRT_DN=['xs','2xs','3xs','4xs','5xs','6xs','7xs','8xs'];
const SCALES=['minor-second','major-second','minor-third','major-third','perfect-fourth','augmented-fourth','perfect-fifth','golden'];
const CSS_PROPS=['align-content','align-items','align-self','animation','animation-delay','animation-duration','animation-name','appearance','aspect-ratio','backdrop-filter','background','background-attachment','background-blend-mode','background-clip','background-color','background-image','background-position','background-repeat','background-size','block-size','border','border-block','border-block-color','border-block-end','border-block-start','border-bottom','border-bottom-color','border-bottom-left-radius','border-bottom-right-radius','border-bottom-width','border-color','border-inline','border-inline-color','border-inline-end','border-inline-start','border-left','border-left-color','border-left-width','border-radius','border-right','border-right-color','border-right-width','border-style','border-top','border-top-color','border-top-left-radius','border-top-right-radius','border-top-width','border-width','bottom','box-shadow','box-sizing','clear','clip-path','color','column-gap','container','container-name','container-type','content','cursor','display','filter','flex','flex-basis','flex-direction','flex-flow','flex-grow','flex-shrink','flex-wrap','font','font-family','font-size','font-style','font-weight','gap','grid','grid-area','grid-auto-columns','grid-auto-flow','grid-auto-rows','grid-column','grid-template','grid-template-areas','grid-template-columns','grid-template-rows','height','inline-size','inset','inset-block','inset-block-end','inset-block-start','inset-inline','inset-inline-end','inset-inline-start','isolation','justify-content','justify-items','justify-self','left','letter-spacing','line-height','list-style','margin','margin-block','margin-block-end','margin-block-start','margin-bottom','margin-inline','margin-inline-end','margin-inline-start','margin-left','margin-right','margin-top','max-block-size','max-height','max-inline-size','max-width','min-block-size','min-height','min-inline-size','min-width','mix-blend-mode','object-fit','object-position','opacity','order','outline','overflow','overflow-block','overflow-inline','overflow-x','overflow-y','padding','padding-block','padding-block-end','padding-block-start','padding-bottom','padding-inline','padding-inline-end','padding-inline-start','padding-left','padding-right','padding-top','place-content','place-items','pointer-events','position','right','row-gap','scroll-margin','scroll-margin-block','scroll-margin-inline','scroll-padding','scroll-padding-block','scroll-padding-inline','text-align','text-decoration','text-transform','top','transform','transform-origin','transition','transition-delay','transition-duration','transition-property','translate','user-select','vertical-align','visibility','white-space','width','will-change','z-index'];
const CSS_VALUES=['auto','block','inline-block','flex','grid','none','relative','absolute','fixed','sticky','hidden','visible','center','space-between','space-around','space-evenly','start','end','stretch','cover','contain','pointer','default','transparent','currentColor','inherit','initial','unset'];
const CSS_LOGICAL_PROPS=['block-size','inline-size','min-block-size','max-block-size','min-inline-size','max-inline-size','margin-block','margin-block-start','margin-block-end','margin-inline-start','margin-inline-end','padding-block','padding-block-start','padding-block-end','padding-inline-start','padding-inline-end','border-block','border-block-color','border-block-start','border-block-start-color','border-block-start-style','border-block-start-width','border-block-end','border-block-end-color','border-block-end-style','border-block-end-width','border-inline','border-inline-color','border-inline-start','border-inline-start-color','border-inline-start-style','border-inline-start-width','border-inline-end','border-inline-end-color','border-inline-end-style','border-inline-end-width','inset-block','inset-block-start','inset-block-end','inset-inline','inset-inline-start','inset-inline-end'];
CSS_PROPS.push(...CSS_LOGICAL_PROPS.filter(x=>!CSS_PROPS.includes(x)));
const CSS_SELECTOR_HINTS=['a','article','aside','body','button','canvas','code','dialog','div','fieldset','figure','footer','form','h1','h2','h3','h4','h5','h6','header','html','iframe','img','input','label','li','main','nav','ol','option','p','picture','section','select','span','svg','table','textarea','ul',':active',':checked',':disabled',':empty',':enabled',':first-child',':first-of-type',':focus',':focus-visible',':hover',':is()',':last-child',':last-of-type',':not()',':nth-child()',':nth-of-type()',':root',':where()','::after','::before','::marker','::placeholder','@container','@font-face','@keyframes','@layer','@media','@supports'];
const CSS_SOURCE_DEFAULTS=["Mimam's Var",'Advanced Themer','Bricks','Core Framework','Automatic.css','CSS Classes','Element IDs'];
const CSS_RECIPES=[
  {name:'Section rhythm',code:'@rhythm',css:'.section {\n  padding-block: var(--space-xl);\n  gap:var(--space-m);\n}'},
  {name:'Fluid card grid',code:'@grid',css:'.card-grid {\n  display: grid;\n  grid-template-columns: repeat(auto-fit, minmax(min(100%, 280px), 1fr));\n  gap:var(--space-m);\n}'},
  {name:'Focus ring',code:'@focus',css:':where(a, button, input, textarea, select):focus-visible {\n  outline: 2px solid var(--color-primary);\n  outline-offset: 3px;\n}'}
];
function loadUserCssRecipes(){try{const r=JSON.parse(localStorage.getItem('ve_css_recipes')||'[]');return Array.isArray(r)?r.filter(x=>x&&x.code&&x.css):[];}catch(e){return[];}}
function saveUserCssRecipes(list){localStorage.setItem('ve_css_recipes',JSON.stringify(list||[]));window.dispatchEvent(new CustomEvent('ve-css-recipes-changed'));}
function getCssRecipes(){const seen={};return [...CSS_RECIPES,...loadUserCssRecipes()].filter(r=>{const k=String(r.code||'').trim();if(!k||seen[k])return false;seen[k]=1;return true;});}
const CSS_HINT_LIMIT=72;
const DEFAULT_CSS_SHEETS=[
  {id:'global',name:'global.css',scope:'global',enabled:true,css:''}
];
const VE_MEDIA_CACHE={items:null,folders:null,at:0};
const NS_CLR={color:'#ef4444',space:'#3b82f6',spacing:'#3b82f6',font:'#a855f7',typography:'#a855f7',heading:'#c084fc',text:'#8b5cf6',weight:'#d946ef',radius:'#f59e0b',size:'#22c55e',scale:'#84cc16',stroke:'#14b8a6','stroke-width':'#14b8a6',shadow:'#6b7280',opacity:'#06b6d4',motion:'#ec4899',grid:'#22c55e',design:'#baf400'};
function variableNamespace(v){
  if(v?.palette_eligible)return'color';
  return v?.category_slug||'uncategorized';
}
function variableOriginKey(v){return String(v?.origin||'mv').toLowerCase();}
function variableOriginLabel(v){return({mv:'MV',wordpress:'MV',at:'AT',cf:'CF',acss:'ACSS',figma:'Figma',file:'FILE',json:'FILE',css:'FILE',dtcg:'FILE',import:'FILE'})[variableOriginKey(v)]||'MV';}
function variableOriginTitle(v){return({mv:"Created in Mimam's Var",wordpress:"Created in Mimam's Var",at:'Imported from Advanced Themer',cf:'Imported from Core Framework',acss:'Imported from Automatic.css',figma:'Imported from Figma',file:'Imported from a file',json:'Imported from a JSON file',css:'Imported from a CSS file',dtcg:'Imported from a DTCG file',import:'Imported from a file'})[variableOriginKey(v)]||"Created in Mimam's Var";}
const VARIABLE_ORIGINS=['mv','file','figma','at','cf','acss'];
function normalizedVariableOrigin(v){
  const key=variableOriginKey(v);
  if(['file','json','css','dtcg','import'].includes(key))return'file';
  if(key==='wordpress')return'mv';
  return VARIABLE_ORIGINS.includes(key)?key:'mv';
}
function OriginPill({variable,onFilter,active=false}){
  const key=normalizedVariableOrigin(variable);
  return h('button',{
    type:'button',
    class:'ve-origin-pill'+(active?' active':''),
    title:variableOriginTitle(variable)+' · Click to filter this source',
    onClick:e=>{e.stopPropagation();onFilter&&onFilter(key);}
  },variableOriginLabel(variable));
}
function stripeColor(v){const p=tokenParts(v?.name);for(const k of [variableNamespace(v),p[0],p[1],p[2],v?.namespace]){if(k&&NS_CLR[k])return NS_CLR[k];}return'#8b949e';}

const SLIDE_MS=200;

const CSS=`
#ve-panel-root{
  --ve-accent:#baf400;
  --ve-accent-hover:#d4ff33;
  --ve-bg:#1f1f1f;
  --ve-surface:#282828;
  --ve-surface-focus:#303030;
  --ve-border:rgba(255,255,255,.10);
  --ve-text:#f1f1f1;
  --ve-muted:#777;
  --ve-danger:#ef4444;
  --ve-control-height:38px;
  --ve-font-xs:11px;
  --ve-font-sm:12px;
  --ve-font-md:13px;
  --ve-font-lg:14px;
  --ve-font-xl:16px;
  --ve-font-2xl:18px;
  --ve-font-3xl:22px;
  --ve-font-4xl:26px;
  --ve-radius-sm:4px;
  --ve-radius-md:6px;
  --ve-radius-lg:8px;
  --ve-radius-xl:10px;
  --ve-radius-2xl:12px;
  --ve-radius-pill:999px;
}
#ve-panel-root *{box-sizing:border-box;}
#ve-panel-root,#ve-panel-root *{scrollbar-width:thin;scrollbar-color:rgba(186,244,0,.46) rgba(255,255,255,.035)}
#ve-panel-root::-webkit-scrollbar,#ve-panel-root *::-webkit-scrollbar{width:6px;height:6px}
#ve-panel-root::-webkit-scrollbar-track,#ve-panel-root *::-webkit-scrollbar-track{background:rgba(255,255,255,.035);border-radius:var(--ve-radius-pill)}
#ve-panel-root::-webkit-scrollbar-thumb,#ve-panel-root *::-webkit-scrollbar-thumb{background:rgba(186,244,0,.46);border-radius:var(--ve-radius-pill);border:1px solid rgba(0,0,0,.22)}
#ve-panel-root::-webkit-scrollbar-thumb:hover,#ve-panel-root *::-webkit-scrollbar-thumb:hover{background:rgba(186,244,0,.62)}
.ve-o{position:fixed;top:0;right:0;width:370px;height:100vh;background:#1f1f1f;border-left:1px solid #2a2a2a;z-index:120000;display:flex;flex-direction:column;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;font-size:var(--ve-font-md);color:#f1f1f1;transform:translateX(100%);transition:transform .18s cubic-bezier(.4,0,.2,1);box-shadow:none;pointer-events:none;}
.ve-o.open{transform:translateX(0);box-shadow:-4px 0 20px rgba(0,0,0,.5);pointer-events:auto;}
.ve-o.ve-dock-left{left:0;right:auto;border-left:0;border-right:1px solid #2a2a2a;transform:translateX(-100%);}
.ve-o.ve-dock-left.open{transform:translateX(0);}
.ve-o.ve-dock-right{right:0;left:auto;}
.ve-o.ve-float{height:min(760px,calc(100vh - 32px));max-height:calc(100vh - 32px);border:1px solid rgba(255,255,255,.10);border-radius:var(--ve-radius-xl);transform:translateY(10px);overflow:visible;}
.ve-o.ve-float.open{transform:translateY(0);box-shadow:0 18px 46px rgba(0,0,0,.40);}
.ve-o.ve-dragging{transition:none!important;}
.ve-o.ve-standalone-panel:not([data-panel="content_studio"]):not([data-panel="media_studio"]):not([data-panel="plugin_studio"]):not([data-panel="css_recipes"]):not([data-panel="css_studio"]){transform:none!important;right:auto!important;bottom:auto!important;transition:opacity .18s ease!important;pointer-events:auto!important;}
.ve-bd{position:fixed;inset:0;background:rgba(0,0,0,.72);z-index:119990;opacity:0;transition:opacity .2s;pointer-events:none;}
.ve-bd.show{opacity:1;pointer-events:auto;}
.ve-fab-wrap{position:fixed;bottom:16px;right:16px;z-index:119990;display:flex;flex-direction:column;align-items:flex-end;gap:8px;}
.ve-fab-wrap.ve-fab-hidden{display:none!important;}
.ve-fab-menu{display:flex;flex-direction:column;gap:8px;opacity:0;pointer-events:none;transform:translateY(10px);transition:all .2s;align-items:flex-end;}
.ve-fab-wrap.ve-fab-tools-open .ve-fab-menu{opacity:1;pointer-events:auto;transform:translateY(0);}
.ve-fab-item{width:32px;height:32px;background:#2a2a2a;border:1px solid #444;border-radius:var(--ve-radius-lg);display:flex;align-items:center;justify-content:center;color:#ddd;cursor:pointer;font-size:var(--ve-font-xl);transition:transform .1s,background .1s;position:relative;}
.ve-fab-item:hover{background:#333;transform:scale(1.08);color:#baf400;border-color:#baf400;}
.ve-fab-tooltip{position:absolute;right:42px;background:#111;padding:4px 8px;border-radius:var(--ve-radius-sm);font-size:var(--ve-font-xs);color:#fff;white-space:nowrap;opacity:0;pointer-events:none;transition:opacity .1s;}
.ve-fab-item:hover .ve-fab-tooltip{opacity:1;}
.ve-fab{width:36px;height:36px;background:#1f1f1f;border:1.5px solid #baf400;border-radius:var(--ve-radius-lg);cursor:pointer;display:flex;align-items:center;justify-content:center;transition:transform .12s;}
.ve-fab:hover{transform:scale(1.06);}
.ve-fab i{color:#baf400;font-size:var(--ve-font-2xl);}
.ve-fab-order-list{display:flex;flex-direction:column;gap:6px;width:100%;margin-top:8px}.ve-fab-order-row{min-height:32px;border:1px solid rgba(255,255,255,.08);border-radius:8px;background:rgba(255,255,255,.025);display:grid;grid-template-columns:22px minmax(0,1fr) auto;gap:8px;align-items:center;padding:5px 7px;color:#ddd;font-size:11px}.ve-fab-order-row i{color:#baf400}.ve-fab-order-actions{display:flex;gap:4px}.ve-fab-order-actions button{width:24px;height:24px;border:1px solid rgba(255,255,255,.08);border-radius:6px;background:#242424;color:#aaa;display:flex;align-items:center;justify-content:center;cursor:pointer}.ve-fab-order-actions button:hover:not(:disabled){border-color:rgba(186,244,0,.32);color:#baf400}.ve-fab-order-actions button:disabled{opacity:.35;cursor:not-allowed}
.ve-hdr{display:flex;align-items:center;padding:10px 14px;border-bottom:1px solid #2a2a2a;gap:8px;flex-shrink:0;background:#1a1a1a;z-index:5;position:relative;}
.ve-hdr-i{width:18px;height:18px;background:transparent;border-radius:var(--ve-radius-sm);flex-shrink:0;object-fit:contain;}
.ve-hdr-t{font-weight:700;font-size:var(--ve-font-xs);letter-spacing:.6px;text-transform:uppercase;color:#baf400;flex:1;}
.ve-hdr-a{display:flex;gap:1px;}
.ve-hdr-a button{background:none;border:none;color:#555;cursor:pointer;width:26px;height:26px;display:flex;align-items:center;justify-content:center;border-radius:var(--ve-radius-sm);padding:0;}
.ve-hdr-a button:hover{background:#2a2a2a;color:#f1f1f1;}
.ve-sr{padding:6px 14px;border-bottom:1px solid #2a2a2a;flex-shrink:0;}
.ve-sr input{width:100%;height:var(--ve-control-height)!important;min-height:var(--ve-control-height)!important;max-height:var(--ve-control-height)!important;padding:0 10px;background:var(--ve-surface);border:1px solid #333;border-radius:5px;color:var(--ve-text);font-size:var(--ve-font-xs);line-height:var(--ve-control-height)!important;outline:none;}
.ve-sr input:focus{border-color:#baf400;}
.ve-sr input::placeholder{color:#444;}
.ve-o input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=file]):not([type=hidden]):not([type=color]),
.ve-o.ve-standalone-panel input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=file]):not([type=hidden]):not([type=color]){
  height:var(--ve-control-height)!important;
  min-height:var(--ve-control-height)!important;
  max-height:var(--ve-control-height)!important;
  line-height:var(--ve-control-height)!important;
}
.ve-color-control{display:flex;flex-direction:column;border-bottom:1px solid #2a2a2a;background:#191919;flex-shrink:0}
.ve-color-kind-switch{display:grid;grid-template-columns:1fr 1fr;gap:2px;padding:3px;background:#141414;border:1px solid #252525;border-radius:var(--ve-radius-lg);margin:8px 14px 4px}
.ve-color-kind-switch button{display:flex!important;align-items:center!important;justify-content:center!important;width:100%!important;height:26px;border:none;border-radius:var(--ve-radius-md);background:transparent;color:#777;font-size:var(--ve-font-xs);font-weight:700;text-transform:uppercase;letter-spacing:.35px;cursor:pointer;transition:all .15s ease}
.ve-color-kind-switch button:hover{color:#ccc}
.ve-color-kind-switch button.on{background:#2a2a2a;color:#baf400;box-shadow:inset 0 1px 0 rgba(255,255,255,.05), 0 2px 4px rgba(0,0,0,.3)}
.ve-color-control-row{display:grid;grid-template-columns:minmax(0,1fr) 24px;align-items:center;gap:8px;padding:8px 14px}
.ve-color-control-label{font-size:var(--ve-font-xs);color:#888;text-transform:uppercase;letter-spacing:.4px;font-weight:600;text-align:left}
.ve-tabs{display:grid;grid-template-columns:minmax(0,1fr) 38px;gap:7px;padding:4px 14px;border-bottom:1px solid #2a2a2a;flex-shrink:0;overflow:hidden;align-items:stretch}
.ve-settings-tabs{display:flex;flex-wrap:wrap;gap:6px;flex-shrink:0;}
/* ── Global MV tooltip ─────────────────────────────────────────────────────
   Add data-ve-tip="Label" to any element to get a branded tooltip with a caret
   pointing at the control. Default placement is above; add .ve-tip-right,
   .ve-tip-left, or .ve-tip-bottom to choose a side that stays inside the panel.
   This is the standard MV tooltip pattern — prefer it over native title=. */
[data-ve-tip]{position:relative}
[data-ve-tip]:hover::after,[data-ve-tip]:focus-visible::after{content:attr(data-ve-tip);position:absolute;z-index:120050;left:50%;bottom:calc(100% + 9px);transform:translateX(-50%);white-space:nowrap;max-width:230px;overflow:hidden;text-overflow:ellipsis;background:#2a2a2e;color:#eaeaea;border:1px solid rgba(255,255,255,.14);padding:5px 9px;border-radius:6px;font-size:var(--ve-font-xs);font-weight:600;line-height:1.3;box-shadow:0 10px 26px rgba(0,0,0,.45);pointer-events:none}
/* Caret is a rotated square whose outer half pokes toward the control; the bubble (::after,
   painted after ::before) covers its inner half, leaving a clean bordered caret point. */
[data-ve-tip]:hover::before,[data-ve-tip]:focus-visible::before{content:'';position:absolute;z-index:120050;left:50%;bottom:calc(100% + 5px);width:9px;height:9px;background:#2a2a2e;border:1px solid rgba(255,255,255,.14);transform:translateX(-50%) rotate(45deg);pointer-events:none}
[data-ve-tip].ve-tip-right:hover::after,[data-ve-tip].ve-tip-right:focus-visible::after{left:calc(100% + 12px);right:auto;bottom:auto;top:50%;transform:translateY(-50%)}
[data-ve-tip].ve-tip-right:hover::before,[data-ve-tip].ve-tip-right:focus-visible::before{left:calc(100% + 8px);right:auto;bottom:auto;top:50%;transform:translateY(-50%) rotate(45deg)}
[data-ve-tip].ve-tip-left:hover::after,[data-ve-tip].ve-tip-left:focus-visible::after{left:auto;right:calc(100% + 12px);bottom:auto;top:50%;transform:translateY(-50%)}
[data-ve-tip].ve-tip-left:hover::before,[data-ve-tip].ve-tip-left:focus-visible::before{left:auto;right:calc(100% + 8px);bottom:auto;top:50%;transform:translateY(-50%) rotate(45deg)}
[data-ve-tip].ve-tip-bottom:hover::after,[data-ve-tip].ve-tip-bottom:focus-visible::after{bottom:auto;top:calc(100% + 9px)}
[data-ve-tip].ve-tip-bottom:hover::before,[data-ve-tip].ve-tip-bottom:focus-visible::before{bottom:auto;top:calc(100% + 5px)}
.ve-settings-main{display:flex;flex:1;min-height:0}
.ve-settings-rail{position:relative;z-index:5;display:flex;flex-direction:column;gap:4px;flex:0 0 auto;width:54px;padding:12px 9px;border-right:1px solid rgba(255,255,255,.08);overflow:visible}
.ve-settings-rail-item{position:relative;display:flex;align-items:center;justify-content:center;width:36px;height:36px;padding:0;margin:0 auto;border:1px solid transparent;border-radius:var(--ve-radius-md);background:transparent;color:#9a9a9a;cursor:pointer;transition:background .12s,color .12s,border-color .12s}
.ve-settings-rail-item i,.ve-settings-rail-item svg{font-size:18px;line-height:0}
.ve-settings-rail-item:hover{background:rgba(255,255,255,.04);color:#e4e4e4}
.ve-settings-rail-item.on{background:rgba(186,244,0,.10);border-color:rgba(186,244,0,.30);color:#baf400}
.ve-settings-content{position:relative;z-index:1;padding:14px 15px 6px}
.ve-settings-footer{border-top:1px solid rgba(255,255,255,.08)}
.ve-settings-version{display:inline-flex;align-items:center;min-height:30px;color:#737373;font-size:var(--ve-font-xs);font-weight:650;white-space:nowrap}
.ve-tabs-scroll{display:flex;align-items:flex-start;gap:2px;min-width:0;overflow-x:auto;padding-bottom:6px;scrollbar-width:thin;scrollbar-color:rgba(186,244,0,.48) rgba(255,255,255,.035);mask-image:linear-gradient(90deg,#000 0,#000 calc(100% - 18px),transparent 100%)}
.ve-tabs-scroll::-webkit-scrollbar{height:5px}.ve-tabs-scroll::-webkit-scrollbar-track{background:rgba(255,255,255,.035);border-radius:var(--ve-radius-pill)}.ve-tabs-scroll::-webkit-scrollbar-thumb{background:rgba(186,244,0,.48);border-radius:var(--ve-radius-pill);border:1px solid rgba(0,0,0,.2)}
.ve-category-manage-wrap{display:flex;align-items:flex-start;justify-content:flex-end;padding:0 0 6px 7px;border-left:1px solid rgba(255,255,255,.07);background:#1f1f1f}
.ve-tabs .ve-category-manage{position:relative;width:30px;height:30px;min-width:30px;align-self:start;background:#242424;flex:0 0 auto;box-shadow:inset 0 1px 0 rgba(255,255,255,.04)}
.ve-origin-pill{appearance:none;display:inline-flex;align-items:center;justify-content:center;min-width:20px;height:14px;padding:0 4px;border:1px solid rgba(255,255,255,.09);border-radius:var(--ve-radius-pill);background:rgba(255,255,255,.025);color:#8f987e;font-family:inherit;font-size:var(--ve-font-xs);font-weight:650;line-height:1;letter-spacing:0;opacity:.78;cursor:pointer;transition:opacity .12s,border-color .12s,color .12s,background .12s}
.ve-origin-pill:hover{opacity:1;color:#b5be9f;border-color:rgba(186,244,0,.16)}
.ve-origin-pill.active{opacity:1;color:#baf400;border-color:rgba(186,244,0,.36);background:rgba(186,244,0,.08)}
.ve-source-filter{display:flex;align-items:center;gap:5px;padding:7px 14px;border-bottom:1px solid #2a2a2a;background:#1b1b1b;overflow-x:auto;flex-shrink:0;scrollbar-width:thin;scrollbar-color:rgba(186,244,0,.42) rgba(255,255,255,.03)}
.ve-source-filter::-webkit-scrollbar{height:4px}.ve-source-filter::-webkit-scrollbar-track{background:rgba(255,255,255,.03);border-radius:var(--ve-radius-pill)}.ve-source-filter::-webkit-scrollbar-thumb{background:rgba(186,244,0,.42);border-radius:var(--ve-radius-pill)}
.ve-source-chip{appearance:none;display:inline-flex;align-items:center;gap:5px;height:24px;padding:0 8px;border:1px solid rgba(255,255,255,.08);border-radius:var(--ve-radius-pill);background:rgba(255,255,255,.025);color:#777;font-family:inherit;font-size:var(--ve-font-xs);font-weight:600;line-height:1;white-space:nowrap;cursor:pointer}
.ve-source-chip:hover{color:#bbb;border-color:rgba(186,244,0,.18)}.ve-source-chip.on{color:#baf400;border-color:rgba(186,244,0,.34);background:rgba(186,244,0,.07)}
.ve-source-count{color:#555;font-weight:600}.ve-source-chip.on .ve-source-count{color:#9dbb46}
.ve-source-select{margin-left:auto;flex:0 0 auto}
.ve-snapshot-create{padding:10px;border:1px solid rgba(255,255,255,.08);border-radius:9px;background:rgba(255,255,255,.025)}
.ve-snapshot-create textarea{min-height:58px;resize:vertical}
.ve-snapshot-card{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:10px;align-items:center;padding:11px 0;border-bottom:1px solid #2a2a2a}
.ve-snapshot-title{color:#e4e4e4;font-size:var(--ve-font-xs);font-weight:650;line-height:1.35}.ve-snapshot-description{color:#858585;font-size:var(--ve-font-xs);line-height:1.5;margin-top:3px}
.ve-snapshot-meta{display:flex;gap:6px;flex-wrap:wrap;color:#5f5f5f;font-size:var(--ve-font-xs);line-height:1.4;margin-top:5px}.ve-snapshot-file{color:#9da58e}
.ve-drift-head{padding:11px;border:1px solid rgba(186,244,0,.18);border-radius:9px;background:rgba(186,244,0,.035);margin-bottom:10px}
.ve-drift-summary{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;margin-top:9px}.ve-drift-stat{padding:7px;border:1px solid rgba(255,255,255,.07);border-radius:7px;background:rgba(0,0,0,.16);text-align:center}.ve-drift-stat b{display:block;color:#ddd;font-size:var(--ve-font-sm)}.ve-drift-stat span{color:#6f6f6f;font-size:var(--ve-font-xs)}
.ve-drift-list{border:1px solid rgba(255,255,255,.08);border-radius:var(--ve-radius-lg);overflow:hidden}.ve-drift-row{display:grid;grid-template-columns:18px minmax(0,1fr) auto;gap:7px;align-items:start;padding:8px;border-bottom:1px solid rgba(255,255,255,.06)}.ve-drift-row:last-child{border-bottom:0}.ve-drift-name{font-size:var(--ve-font-xs);color:#ddd;font-weight:650;word-break:break-word}.ve-drift-values{font-size:var(--ve-font-xs);color:#737373;line-height:1.45;margin-top:2px;word-break:break-word}.ve-drift-status{font-size:var(--ve-font-xs);padding:2px 5px;border-radius:var(--ve-radius-pill);border:1px solid rgba(255,255,255,.09);color:#888}.ve-drift-status.conflict{color:#f59e0b;border-color:rgba(245,158,11,.28)}.ve-drift-status.changed{color:#7ca8ff}.ve-drift-status.missing_mv,.ve-drift-status.missing_source{color:#baf400}
.ve-drift-actions{display:flex;gap:5px;align-items:center;justify-content:flex-end;margin-top:9px;position:sticky;bottom:0;padding:8px 0;background:linear-gradient(180deg,transparent,#1f1f1f 24%)}
.ve-t{padding:4px 8px;font-size:var(--ve-font-xs);font-weight:600;color:#444;cursor:pointer;border-radius:var(--ve-radius-sm);white-space:nowrap;text-transform:uppercase;letter-spacing:.4px;transition:all .1s;}
.ve-t:hover{color:#999;background:#262626;}
.ve-t.on{color:#1f1f1f;background:#baf400;}

/* Sub-panel slide-in/out */
.ve-sub{position:absolute;top:46px;left:0;right:0;bottom:0;background:#1f1f1f;z-index:4;display:flex;flex-direction:column;animation:veSlideIn .2s ease forwards;}
.ve-sub.closing{animation:veSlideOut .2s ease forwards;pointer-events:none;}
@keyframes veSlideIn{from{transform:translateX(100%);opacity:.8}to{transform:translateX(0);opacity:1}}
@keyframes veSlideOut{from{transform:translateX(0);opacity:1}to{transform:translateX(100%);opacity:.8}}
.ve-sub-hdr{display:flex;align-items:center;height:48px;min-height:48px;padding:0 16px;border-bottom:1px solid #2a2a2a;gap:8px;background:#1a1a1a;}
.ve-sub-hdr span{flex:1;font-size:var(--ve-font-xs);font-weight:700;color:#baf400;text-transform:uppercase;letter-spacing:.4px;line-height:1;display:flex;align-items:center;height:100%;}
.ve-sub-body{flex:1;overflow-y:auto;padding:10px 14px;}

.ve-body{flex:1;overflow-y:auto;overflow-x:hidden;position:relative;}
.ve-body,.ve-sub-body,.ve-scroll-custom,.ve-modal,.ve-modal *,.ve-menu-list,.ve-selection-review-list,.ve-migrate-scroll,.ve-migrate-diff-list,.ve-media-studio,.ve-media-studio *,.ve-studio-details-sidebar,.ve-studio-table-container,.ve-icon-grid,.ve-collection-choice-list,.ve-studio-sidebar-scroll{scrollbar-width:thin!important;scrollbar-color:rgba(186,244,0,.48) rgba(255,255,255,.035)!important}
.ve-body::-webkit-scrollbar,.ve-sub-body::-webkit-scrollbar,.ve-scroll-custom::-webkit-scrollbar,.ve-modal::-webkit-scrollbar,.ve-modal *::-webkit-scrollbar,.ve-menu-list::-webkit-scrollbar,.ve-selection-review-list::-webkit-scrollbar,.ve-migrate-scroll::-webkit-scrollbar,.ve-migrate-diff-list::-webkit-scrollbar,.ve-media-studio::-webkit-scrollbar,.ve-media-studio *::-webkit-scrollbar,.ve-studio-details-sidebar::-webkit-scrollbar,.ve-studio-table-container::-webkit-scrollbar,.ve-icon-grid::-webkit-scrollbar,.ve-collection-choice-list::-webkit-scrollbar,.ve-studio-sidebar-scroll::-webkit-scrollbar{width:6px!important;height:6px!important}
.ve-body::-webkit-scrollbar-track,.ve-sub-body::-webkit-scrollbar-track,.ve-scroll-custom::-webkit-scrollbar-track,.ve-modal::-webkit-scrollbar-track,.ve-modal *::-webkit-scrollbar-track,.ve-menu-list::-webkit-scrollbar-track,.ve-selection-review-list::-webkit-scrollbar-track,.ve-migrate-scroll::-webkit-scrollbar-track,.ve-migrate-diff-list::-webkit-scrollbar-track,.ve-media-studio::-webkit-scrollbar-track,.ve-media-studio *::-webkit-scrollbar-track,.ve-studio-details-sidebar::-webkit-scrollbar-track,.ve-studio-table-container::-webkit-scrollbar-track,.ve-icon-grid::-webkit-scrollbar-track,.ve-collection-choice-list::-webkit-scrollbar-track,.ve-studio-sidebar-scroll::-webkit-scrollbar-track{background:rgba(255,255,255,.035)!important;border-radius:var(--ve-radius-pill)!important}
.ve-body::-webkit-scrollbar-thumb,.ve-sub-body::-webkit-scrollbar-thumb,.ve-scroll-custom::-webkit-scrollbar-thumb,.ve-modal::-webkit-scrollbar-thumb,.ve-modal *::-webkit-scrollbar-thumb,.ve-menu-list::-webkit-scrollbar-thumb,.ve-selection-review-list::-webkit-scrollbar-thumb,.ve-migrate-scroll::-webkit-scrollbar-thumb,.ve-migrate-diff-list::-webkit-scrollbar-thumb,.ve-media-studio::-webkit-scrollbar-thumb,.ve-media-studio *::-webkit-scrollbar-thumb,.ve-studio-details-sidebar::-webkit-scrollbar-thumb,.ve-studio-table-container::-webkit-scrollbar-thumb,.ve-icon-grid::-webkit-scrollbar-thumb,.ve-collection-choice-list::-webkit-scrollbar-thumb,.ve-studio-sidebar-scroll::-webkit-scrollbar-thumb{background:rgba(186,244,0,.46)!important;border-radius:var(--ve-radius-pill)!important;border:1px solid rgba(0,0,0,.22)!important}
.ve-body::-webkit-scrollbar-thumb:hover,.ve-sub-body::-webkit-scrollbar-thumb:hover,.ve-scroll-custom::-webkit-scrollbar-thumb:hover,.ve-modal::-webkit-scrollbar-thumb:hover,.ve-modal *::-webkit-scrollbar-thumb:hover,.ve-menu-list::-webkit-scrollbar-thumb:hover,.ve-selection-review-list::-webkit-scrollbar-thumb:hover,.ve-migrate-scroll::-webkit-scrollbar-thumb:hover,.ve-migrate-diff-list::-webkit-scrollbar-thumb:hover,.ve-media-studio::-webkit-scrollbar-thumb:hover,.ve-media-studio *::-webkit-scrollbar-thumb:hover,.ve-studio-details-sidebar::-webkit-scrollbar-thumb:hover,.ve-studio-table-container::-webkit-scrollbar-thumb:hover,.ve-icon-grid::-webkit-scrollbar-thumb:hover,.ve-collection-choice-list::-webkit-scrollbar-thumb:hover,.ve-studio-sidebar-scroll::-webkit-scrollbar-thumb:hover{background:rgba(186,244,0,.62)!important}

.ve-v{padding:5px 14px 5px 0;display:flex;align-items:center;gap:6px;cursor:pointer;transition:background .08s;position:relative;min-height:30px;border-left:0;user-select:none;-webkit-user-select:none;}
.ve-v:before{content:'';position:absolute;left:0;top:0;bottom:0;width:3px;background:var(--ve-ns,#555);border-radius:0;}
.ve-v:hover{background:#262626;}
.ve-v.sel{background:#262626;}
.ve-sw{width:15px;height:15px;border-radius:3px;border:1px solid #333;flex-shrink:0;}
.ve-inf{flex:1;min-width:0;}
.ve-nm{font-size:var(--ve-font-xs);font-weight:500;color:#ddd;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:'SF Mono','Fira Code',monospace;line-height:1.3;display:flex;align-items:center;gap:5px;}
.ve-nm-label{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ve-vl{font-size:var(--ve-font-xs);color:#555;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-family:'SF Mono','Fira Code',monospace;}
.ve-exp{background:none;border:none;color:#555;cursor:pointer;width:18px;height:18px;display:flex;align-items:center;justify-content:center;border-radius:3px;flex-shrink:0;padding:0;}
.ve-exp:hover{background:#2a2a2a;color:#baf400;}
.ve-tree-item{display:block!important;width:100%;min-width:0;}
.ve-sw-trigger{display:flex;align-items:center;justify-content:center;flex-shrink:0;}
.ve-as{display:flex;position:absolute;right:8px;top:50%;transform:translateY(-50%);gap:3px;background:rgba(24,24,24,.96);border:1px solid rgba(255,255,255,.10);border-radius:var(--ve-radius-lg);padding:4px;z-index:3;box-shadow:0 12px 28px rgba(0,0,0,.34);backdrop-filter:blur(14px);opacity:0;visibility:hidden;pointer-events:none;transition:opacity .12s ease,visibility .12s ease;}
.ve-as.open{opacity:1;visibility:visible;pointer-events:auto;}
.ve-a{background:transparent;border:none;color:#777;cursor:pointer;width:24px;height:24px;display:flex;align-items:center;justify-content:center;border-radius:var(--ve-radius-md);padding:0;transition:background .15s,color .15s,box-shadow .15s;}
.ve-a:hover{background:rgba(186,244,0,.11);color:#baf400;box-shadow:none;}
.ve-a i{font-size:var(--ve-font-sm);}
.ve-ch{display:block!important;width:auto!important;clear:both;margin-left:18px;border-left:1px solid #2a2a2a;padding-left:2px;}
.ve-c{padding:3px 10px;display:flex;align-items:center;gap:6px;cursor:pointer;transition:background .08s;user-select:none;-webkit-user-select:none;}
.ve-c:hover{background:#262626;}
.ve-c .ve-nm{font-size:var(--ve-font-xs);color:#888;}.ve-c .ve-vl{font-size:var(--ve-font-xs);}
.ve-sb{height:3px;background:#baf400;border-radius:2px;opacity:.4;margin-top:1px;}
.ve-import-drop{position:relative;border:1px dashed rgba(255,255,255,.16);border-radius:9px;background:rgba(255,255,255,.025);padding:10px;transition:border-color .15s ease,background .15s ease,box-shadow .15s ease;}
.ve-import-drop.active{border-color:#baf400;background:rgba(186,244,0,.075);box-shadow:none;}
.ve-import-drop-content{transition:opacity .12s ease;}
.ve-import-drop.active .ve-import-drop-content{opacity:.12;pointer-events:none;}
.ve-import-drop-overlay{display:none;position:absolute;inset:0;z-index:2;align-items:center;justify-content:center;flex-direction:column;gap:5px;color:#baf400;text-align:center;font-size:var(--ve-font-sm);font-weight:800;letter-spacing:.01em;pointer-events:none;}
.ve-import-drop-overlay small{font-size:var(--ve-font-xs);color:#dfffa3;font-weight:500;}
.ve-import-drop.active .ve-import-drop-overlay{display:flex;}
.ve-import-help{font-size:var(--ve-font-xs);color:#777;line-height:1.5;margin:0 0 8px;}
.ve-import-change{display:grid;grid-template-columns:36px minmax(0,1fr);gap:3px 7px;padding:7px 0;border-bottom:1px solid #2a2a2a;font-size:var(--ve-font-xs)}
.ve-import-change-tag{grid-row:1 / span 2;font-size:var(--ve-font-xs);font-weight:700;text-transform:uppercase;padding-top:1px}
.ve-import-change-name{min-width:0;color:#ddd;font-family:'SF Mono','Fira Code',monospace;overflow-wrap:anywhere;line-height:1.4}
.ve-import-change-detail{grid-column:2;min-width:0;color:#888;font-size:var(--ve-font-xs);font-family:'SF Mono','Fira Code',monospace;overflow-wrap:anywhere;line-height:1.5}
.ve-header-progress{order:3;width:100%;padding-top:7px;border-top:1px solid rgba(255,255,255,.055);pointer-events:none;animation:veHeaderProgressIn .14s ease both}
.ve-header-progress-top{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:6px}
.ve-header-progress-label{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;color:#a5a5a5;font-size:var(--ve-font-xs);font-weight:800;line-height:1.2}
.ve-header-progress-percent{flex:0 0 auto;color:#baf400;font-size:var(--ve-font-xs);font-weight:900;line-height:1}
.ve-header-progress-track{height:7px;overflow:hidden;border:1px solid rgba(255,255,255,.06);border-radius:var(--ve-radius-pill);background:#101010}
.ve-header-progress-bar{height:100%;border-radius:inherit;background:linear-gradient(90deg,#8fbd00,#baf400);box-shadow:none;transition:width .25s ease}
.ve-header-progress.done .ve-header-progress-label,.ve-header-progress.done .ve-header-progress-percent{color:#baf400}
@keyframes veHeaderProgressIn{from{opacity:0;transform:translateY(-3px)}to{opacity:1;transform:translateY(0)}}
.ve-update-refresh-modal{position:fixed!important;inset:0!important;z-index:140000!important}
.ve-palette-current{display:flex;align-items:center;gap:10px;padding:4px 0;margin-bottom:10px;border:none;border-radius:0;background:transparent;}
.ve-palette-dot{width:12px;height:12px;border-radius:var(--ve-radius-sm);background:linear-gradient(135deg,#baf400,#00d1ff 52%,#b15cff);box-shadow:0 0 0 1px rgba(255,255,255,.13);}
.ve-palette-row{display:flex;align-items:center;gap:8px;padding:9px 0;border-bottom:1px solid #2a2a2a;}
.ve-palette-row-info{flex:1;min-width:0;}
.ve-palette-row-name{font-size:var(--ve-font-xs);color:#ddd;font-weight:600;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}
.ve-palette-row-meta{font-size:var(--ve-font-xs);color:#666;margin-top:2px;}
.ve-palette-actions{display:flex;gap:4px;align-items:center;}

/* Drag and Drop & Ordering */
.ve-var-drag-handle{padding:2px;color:#777;cursor:grab;display:flex;align-items:center;}
.ve-var-drag-handle:active{cursor:grabbing;}
.ve-v.dragging{opacity:.4;}
.ve-v.drag-over{border-top:2px solid #baf400!important;}
.ve-palette-row.dragging{opacity:.4;}
.ve-palette-row.drag-over{border-top:2px solid #baf400!important;}
.ve-palette-drag-handle{padding:2px;color:#777;cursor:grab;display:flex;align-items:center;}
.ve-palette-drag-handle:active{cursor:grabbing;}

/* Forms */
.ve-opt{display:flex;align-items:center;justify-content:space-between;padding:4px 0;font-size:var(--ve-font-xs);}
.ve-opt>span{color:#888;}
.ve-opt-toggle{gap:12px;min-height:30px}.ve-opt-toggle>span{line-height:1.45;color:#c8c8c8}.ve-field-toggle{padding:0;margin-top:4px}
.ve-opt label{display:flex;align-items:center;gap:6px;cursor:pointer;color:#bbb;line-height:1.45;}
.ve-opt input[type=checkbox]{accent-color:#baf400;width:13px;height:13px;}
.ve-opt input[type=number],.ve-opt input[type=text]{padding:4px 6px;background:#2a2a2a;border:1px solid #333;border-radius:var(--ve-radius-sm);color:#f1f1f1;font-size:var(--ve-font-xs);outline:none;}
.ve-opt input[type=number]{width:56px;text-align:center;}
.ve-opt input[type=number]::-webkit-outer-spin-button,.ve-opt input[type=number]::-webkit-inner-spin-button{appearance:none;-webkit-appearance:none;margin:0;}
.ve-opt input[type=number]{appearance:textfield;-moz-appearance:textfield;}
.ve-opt input:focus{border-color:#baf400;}
.ve-sub-body input[type=text],.ve-sub-body input[type=number],.ve-sub-body input[type=url],.ve-sub-body input[type=password]{height:var(--ve-control-height)!important;min-height:var(--ve-control-height)!important;max-height:var(--ve-control-height)!important;padding:0 11px;background:var(--ve-surface);border:1px solid var(--ve-border);border-radius:var(--ve-radius-md);color:var(--ve-text);font-size:var(--ve-font-xs);line-height:var(--ve-control-height)!important;outline:none;box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 1px 0 rgba(0,0,0,.24);transition:border-color .16s,background .16s,box-shadow .16s;}
.ve-sub-body textarea{min-height:80px;padding:9px 11px;background:var(--ve-surface);border:1px solid var(--ve-border);border-radius:var(--ve-radius-md);color:var(--ve-text);font-size:var(--ve-font-xs);line-height:1.45;outline:none;box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 1px 0 rgba(0,0,0,.24);transition:border-color .16s,background .16s,box-shadow .16s;resize:vertical;font-family:'SF Mono','Fira Code',monospace;}
.ve-sub-body input[type=text]:focus,.ve-sub-body input[type=number]:focus,.ve-sub-body input[type=url]:focus,.ve-sub-body input[type=password]:focus,.ve-sub-body textarea:focus{border-color:#baf400;background:#303030;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);}
.ve-sub-body input::placeholder,.ve-sub-body textarea::placeholder{color:#666;}
.ve-sub-body input[type=checkbox],.ve-sub-body input[type=radio]{appearance:none;-webkit-appearance:none;width:16px;height:16px;border:1px solid rgba(255,255,255,.18);border-radius:var(--ve-radius-sm);background:#242424;display:inline-grid;place-content:center;flex:0 0 16px;margin:0;cursor:pointer;}
.ve-sub-body input[type=checkbox]:checked,.ve-sub-body input[type=radio]:checked{background:#baf400;border-color:#baf400;box-shadow:none;}
.ve-sub-body input[type=checkbox]:checked:before{content:'';width:8px;height:5px;border-left:2px solid #1f1f1f;border-bottom:2px solid #1f1f1f;transform:translateY(-.5px) rotate(-45deg);}

/* Unified select */
.ve-sel{width:100%;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:var(--ve-radius-sm);color:#f1f1f1;font-size:var(--ve-font-xs);outline:none;appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='8' height='5'%3E%3Cpath d='M0 0l4 5 4-5z' fill='%23666'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 6px center;padding-right:20px;cursor:pointer;transition:border-color .1s;}
.ve-sel:focus{border-color:#baf400;}
.ve-sel:hover{border-color:#555;}
.ve-sel option{background:#2a2a2a;color:#f1f1f1;}
.ve-opt .ve-sel{width:auto;min-width:110px;}
.ve-menu{position:relative;width:100%;min-width:0;}
.ve-menu-btn{width:100%;height:var(--ve-control-height);min-height:var(--ve-control-height);max-height:var(--ve-control-height);padding:0 34px 0 11px;background:#282828;border:1px solid rgba(255,255,255,.10);border-radius:var(--ve-radius-sm);color:#f1f1f1;font-size:var(--ve-font-sm);line-height:1.35;text-align:left;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 1px 0 rgba(0,0,0,.25);transition:border-color .16s,box-shadow .16s,background .16s;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;display:flex;align-items:center;}
.ve-menu-label{display:flex;align-items:center;min-width:0;min-height:100%;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;line-height:1.35;padding-bottom:1px}
.ve-menu-btn:after{content:'';position:absolute;right:12px;top:50%;width:7px;height:7px;border-right:1.5px solid #baf400;border-bottom:1.5px solid #baf400;transform:translateY(-65%) rotate(45deg);pointer-events:none;}
.ve-menu.open .ve-menu-btn{border-color:#baf400;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);background:#303030;border-radius:var(--ve-radius-sm) 4px 0 0;}
.ve-menu-list{position:absolute;left:0;right:0;top:calc(100% - 1px);z-index:30;background:#242424;border:1px solid #baf400;border-top-color:rgba(255,255,255,.10);border-radius:0 0 4px 4px;box-shadow:0 18px 38px rgba(0,0,0,.42);max-height:210px;overflow-y:auto;padding:4px;}
.ve-menu-list{scrollbar-width:thin;scrollbar-color:rgba(186,244,0,.58) rgba(255,255,255,.04)}
.ve-menu-list::-webkit-scrollbar{width:6px}.ve-menu-list::-webkit-scrollbar-track{background:rgba(255,255,255,.04);border-radius:var(--ve-radius-pill)}.ve-menu-list::-webkit-scrollbar-thumb{background:rgba(186,244,0,.58);border-radius:var(--ve-radius-pill);border:1px solid rgba(0,0,0,.24)}.ve-menu-list::-webkit-scrollbar-thumb:hover{background:rgba(186,244,0,.78)}
.ve-menu-item{width:100%;display:block;padding:7px 8px;background:transparent;border:0;border-radius:2px;color:#e7e7e7;text-align:left;font-size:var(--ve-font-sm);line-height:1.35;cursor:pointer;}
.ve-menu-item:hover,.ve-menu-item.on,.ve-menu-item.active{background:#343434;color:#baf400;}
.ve-menu-item:disabled{color:#626262!important;background:transparent!important;cursor:not-allowed;opacity:.72}
.ve-menu-search{width:100%;height:32px;margin:0 0 4px;padding:0 9px;background:#1c1c1c;border:1px solid rgba(255,255,255,.10);border-radius:var(--ve-radius-sm);color:#f1f1f1;font-size:var(--ve-font-xs);line-height:32px;outline:none;box-sizing:border-box}
.ve-menu-search:focus{border-color:#baf400;box-shadow:none}
.ve-menu-empty{padding:10px 8px;color:#777;font-size:var(--ve-font-xs);line-height:1.4;text-align:center}
.ve-menu-portal{position:fixed;z-index:140150;pointer-events:auto}
.ve-menu-portal .ve-menu-list{position:static;left:auto;right:auto;top:auto;width:100%;max-height:min(210px,calc(100vh - 24px))}
.ve-menu-portal.up .ve-menu-list{border-radius:var(--ve-radius-sm) 4px 0 0;border-top-color:#baf400;border-bottom-color:rgba(255,255,255,.10);box-shadow:0 -18px 38px rgba(0,0,0,.42)}
.ve-category-context{position:fixed;z-index:140100;width:142px;min-width:142px;right:auto;top:auto;border-radius:7px;border-top-color:#baf400;box-shadow:0 18px 44px rgba(0,0,0,.56)}
.ve-opt-menu{width:168px;flex:0 0 168px;}

.ve-row{display:flex;gap:5px;margin-bottom:6px;align-items:center;}
.ve-row input{flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:var(--ve-radius-sm);color:#f1f1f1;font-size:var(--ve-font-xs);outline:none;}
.ve-row input:focus{border-color:#baf400;}
.ve-cp{display:grid;grid-template-columns:42px minmax(0,1fr);gap:8px;align-items:stretch;width:100%;min-width:0;max-width:100%;overflow:hidden;}
.ve-color-swatch{width:42px;height:42px;border:1px solid rgba(255,255,255,.16);border-radius:var(--ve-radius-md);cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.20),0 6px 18px rgba(0,0,0,.22)}
.ve-color-panel{grid-column:1/-1;min-width:0;max-width:100%;overflow:hidden;border:1px solid rgba(255,255,255,.10);background:#242424;border-radius:var(--ve-radius-lg);padding:10px;display:grid;gap:9px;animation:veColorIn .16s cubic-bezier(.2,.8,.2,1);transform-origin:top center}
.ve-color-panel.closing{animation:veColorOut .14s cubic-bezier(.4,0,.2,1) forwards;pointer-events:none}
@keyframes veColorIn{from{opacity:0;transform:translateY(-6px) scaleY(.96)}to{opacity:1;transform:translateY(0) scaleY(1)}}
@keyframes veColorOut{from{opacity:1;transform:translateY(0) scaleY(1)}to{opacity:0;transform:translateY(-6px) scaleY(.96)}}
.ve-color-map{position:relative;width:100%;min-width:0;height:132px;border-radius:var(--ve-radius-md);overflow:hidden;cursor:crosshair;background:red;box-shadow:inset 0 0 0 1px rgba(255,255,255,.12)}
.ve-color-map:before{content:'';position:absolute;inset:0;background:linear-gradient(90deg,#fff,rgba(255,255,255,0))}
.ve-color-map:after{content:'';position:absolute;inset:0;background:linear-gradient(0deg,#000,rgba(0,0,0,0))}
.ve-color-dot{position:absolute;width:12px;height:12px;border:2px solid #fff;border-radius:50%;box-shadow:0 0 0 1px #000,0 2px 6px rgba(0,0,0,.45);transform:translate(-50%,-50%);z-index:2;pointer-events:none}
.ve-hue{width:100%;appearance:none;-webkit-appearance:none;height:14px;border-radius:var(--ve-radius-pill);background:linear-gradient(90deg,#f00,#ff0,#0f0,#0ff,#00f,#f0f,#f00);outline:none;border:1px solid rgba(255,255,255,.14);box-shadow:inset 0 1px 1px rgba(0,0,0,.35)}
.ve-hue::-webkit-slider-thumb{appearance:none;-webkit-appearance:none;width:18px;height:18px;border-radius:50%;background:#f1f1f1;border:2px solid #1f1f1f;box-shadow:0 2px 8px rgba(0,0,0,.35);cursor:pointer}
.ve-hue::-moz-range-thumb{width:18px;height:18px;border-radius:50%;background:#f1f1f1;border:2px solid #1f1f1f;box-shadow:0 2px 8px rgba(0,0,0,.35);cursor:pointer}
.ve-color-fields{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:6px;min-width:0}
.ve-color-fields input{width:100%;min-width:0;height:38px!important;min-height:38px!important;max-height:38px!important;padding:0 10px!important;text-align:center;font-family:'SF Mono','Fira Code',monospace;line-height:38px!important}
.ve-cp-v{min-width:0;padding:7px 10px;background:#2a2a2a;border:1px solid #333;border-radius:var(--ve-radius-sm);color:#ddd;font-size:var(--ve-font-xs);font-family:monospace;display:flex;align-items:center;overflow:hidden;line-height:1.45;word-break:break-all;}
.ve-format-tabs{grid-column:1 / -1;display:grid;grid-template-columns:repeat(4,1fr);gap:0;border:1px solid #333;background:#202020;border-radius:var(--ve-radius-sm);overflow:hidden;}
.ve-format-tabs button{min-height:30px;padding:0 10px;border:0;border-right:1px solid #333;background:#252525;color:#888;font-size:var(--ve-font-xs);font-weight:700;letter-spacing:0;text-transform:uppercase;cursor:pointer;border-radius:0;}
.ve-format-tabs button:last-child{border-right:0;}
.ve-format-tabs button:hover{background:#2f2f2f;color:#ddd;}
.ve-format-tabs button.on{background:#baf400;color:#1f1f1f;}
.ve-mode{display:flex;gap:2px;margin-bottom:8px;}
.ve-mode button{flex:1;padding:5px;background:#2a2a2a;border:1px solid #333;border-radius:var(--ve-radius-sm);color:#666;font-size:var(--ve-font-xs);font-weight:600;text-transform:uppercase;cursor:pointer;letter-spacing:.3px;transition:all .1s;}
.ve-mode button.on{background:#baf400;color:#1f1f1f;border-color:#baf400;}
.ve-btn{min-height:38px;padding:8px 14px;background:#baf400;color:#1f1f1f;border:none;border-radius:var(--ve-radius-md);font-size:var(--ve-font-xs);font-weight:700;cursor:pointer;white-space:nowrap;display:inline-flex;align-items:center;justify-content:center;line-height:1.2;gap:6px;}
.ve-btn:hover{background:#d4ff33;}.ve-btn:disabled{opacity:.3;cursor:not-allowed;}
.ve-btn-s{min-height:30px;padding:5px 10px;font-size:var(--ve-font-xs);}
.ve-btn-g{background:#303236;border:1px solid rgba(255,255,255,.14);color:#e4e4e4;font-weight:600;box-shadow:inset 0 1px 0 rgba(255,255,255,.04);}
.ve-btn-g:hover{border-color:rgba(255,255,255,.22);color:#f1f1f1;background:#3a3d42;box-shadow:inset 0 1px 0 rgba(255,255,255,.05);}
.ve-btn-d{background:#991b1b;color:#fff;}.ve-btn-d:hover{background:#7f1d1d;color:#fff;border-color:#ef4444;}
.ve-det{padding:10px 14px;border-top:1px solid #2a2a2a;background:#1a1a1a;flex-shrink:0;max-height:min(390px,48vh);overflow-y:auto;}
.ve-det-t{font-weight:700;font-size:var(--ve-font-sm);margin-bottom:6px;font-family:monospace;color:#baf400;display:flex;justify-content:space-between;align-items:center;}
.ve-det-r{display:flex;justify-content:space-between;padding:2px 0;font-size:var(--ve-font-xs);}
.ve-det-l{color:#555;}.ve-det-v{color:#ddd;font-family:monospace;}
.ve-usage{margin-top:8px;border:1px solid rgba(255,255,255,.08);border-radius:var(--ve-radius-lg);background:rgba(0,0,0,.14);overflow:hidden}.ve-usage-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 9px;border-bottom:1px solid rgba(255,255,255,.06)}.ve-usage-title{display:flex;align-items:center;gap:6px;color:#ddd;font-size:var(--ve-font-xs);font-weight:800}.ve-usage-title i{color:#baf400;font-size:15px}.ve-usage-status{padding:2px 6px;border:1px solid rgba(186,244,0,.22);border-radius:var(--ve-radius-pill);color:#baf400;background:rgba(186,244,0,.07);font-size:var(--ve-font-xs);font-weight:800}.ve-usage-status.unused{border-color:rgba(255,255,255,.1);color:#888;background:rgba(255,255,255,.03)}.ve-usage-body{padding:5px 8px 8px}.ve-usage-group{padding-top:6px}.ve-usage-group-title{color:#666;font-size:var(--ve-font-xs);font-weight:800;text-transform:uppercase;letter-spacing:.04em;margin-bottom:3px}.ve-usage-item{width:100%;display:flex;align-items:center;gap:7px;padding:6px;border:0;border-radius:5px;background:transparent;color:#cfcfcf;text-align:left;font-size:var(--ve-font-xs);line-height:1.35}.ve-usage-item.clickable{cursor:pointer}.ve-usage-item.clickable:hover{background:rgba(186,244,0,.07);color:#eaffbd}.ve-usage-item i{color:#8a8a8a;font-size:var(--ve-font-lg);flex:0 0 auto}.ve-usage-item-main{min-width:0;flex:1}.ve-usage-item-label{display:block;overflow-wrap:anywhere}.ve-usage-item-meta{display:block;color:#666;font-size:var(--ve-font-xs)}.ve-usage-empty,.ve-usage-loading{padding:8px;color:#777;font-size:var(--ve-font-xs);line-height:1.5}.ve-impact-stack{margin-top:10px}.ve-impact-stack>.ve-usage{margin-top:6px}.ve-impact-summary{display:flex;align-items:center;gap:6px;color:#aaa;font-size:var(--ve-font-xs);line-height:1.45}.ve-impact-summary i{color:#baf400;font-size:15px}
.ve-dep-s{margin-top:6px;}
.ve-dep-t{font-size:var(--ve-font-xs);color:#555;text-transform:uppercase;letter-spacing:.4px;margin-bottom:2px;}
.ve-dep{font-size:var(--ve-font-xs);color:#baf400;padding:1px 0;cursor:pointer;font-family:monospace;}
.ve-dep:hover{text-decoration:underline;}
.ve-empty{padding:24px 14px;text-align:center;color:#444;font-size:var(--ve-font-xs);}
.ve-st{padding:4px 14px;font-size:var(--ve-font-xs);color:#444;border-top:1px solid #2a2a2a;display:flex;align-items:center;justify-content:space-between;gap:8px;flex-shrink:0;background:#1a1a1a;margin-top:auto;}
.ve-st-left{display:flex;align-items:center;gap:8px;min-width:0;}
.ve-st .ve-btn{padding:2px 6px;font-size:var(--ve-font-xs);line-height:1.2;white-space:nowrap;}
.ve-toast{position:fixed;bottom:60px;right:16px;background:#baf400;color:#1f1f1f;padding:7px 12px;border-radius:9px;font-size:var(--ve-font-xs);font-weight:600;z-index:120020;opacity:0;transition:opacity .2s;pointer-events:none;display:flex;align-items:center;gap:8px;}
.ve-toast.show{opacity:1;}
@property --ve-toast-angle{syntax:"<angle>";inherits:false;initial-value:360deg}
.ve-toast-ring{--ve-toast-angle:360deg;position:relative;width:16px;height:16px;border-radius:50%;background:conic-gradient(#1f1f1f var(--ve-toast-angle),rgba(31,31,31,.18) 0deg);animation:veToastRing 2.2s linear forwards;flex:0 0 16px}
.ve-toast-ring:after{content:'';position:absolute;inset:4px;border-radius:50%;background:#baf400}
@keyframes veToastRing{to{--ve-toast-angle:0deg}}
.ve-cf{position:absolute;inset:0;background:rgba(0,0,0,.65);z-index:10;display:flex;align-items:center;justify-content:center;}
.ve-cf-b{background:#1f1f1f;border:1px solid #333;border-radius:var(--ve-radius-lg);padding:16px;text-align:center;max-width:240px;}
.ve-cf-b p{margin:0 0 10px;font-size:var(--ve-font-sm);color:#bbb;}
.ve-warn{font-size:var(--ve-font-xs);color:#f59e0b;padding:4px 0;}
.ve-ren{display:flex;gap:4px;align-items:center;padding:8px 0;}
.ve-ren input{flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:var(--ve-radius-sm);color:#f1f1f1;font-size:var(--ve-font-xs);font-family:monospace;outline:none;}
.ve-ren input:focus{border-color:#baf400;}
.ve-tshirt-ctrl{display:flex;align-items:center;justify-content:center;gap:4px;padding:4px 0;}
.ve-tshirt-ctrl button{width:24px;height:24px;background:#2a2a2a;border:1px solid #333;border-radius:var(--ve-radius-sm);color:#baf400;cursor:pointer;display:flex;align-items:center;justify-content:center;font-size:var(--ve-font-lg);font-weight:700;padding:0;}
.ve-tshirt-ctrl button:hover{background:#333;border-color:#baf400;}
.ve-tshirt-ctrl button:disabled{opacity:.2;cursor:not-allowed;}
.ve-tshirt-ctrl span{font-size:var(--ve-font-xs);color:#555;min-width:60px;text-align:center;}

/* Variable reference autocomplete */
.ve-ac{position:absolute;left:0;right:0;top:100%;background:#2a2a2a;border:1px solid #333;border-radius:0 0 4px 4px;max-height:120px;overflow-y:auto;z-index:10;box-shadow:0 4px 12px rgba(0,0,0,.4);}
.ve-ac{scrollbar-width:thin;scrollbar-color:rgba(186,244,0,.48) rgba(255,255,255,.035)}
.ve-ac::-webkit-scrollbar{width:6px;height:6px}.ve-ac::-webkit-scrollbar-track{background:rgba(255,255,255,.035);border-radius:var(--ve-radius-pill)}.ve-ac::-webkit-scrollbar-thumb{background:rgba(186,244,0,.46);border-radius:var(--ve-radius-pill);border:1px solid rgba(0,0,0,.22)}
.ve-ac-i{padding:4px 8px;font-size:var(--ve-font-xs);font-family:'SF Mono','Fira Code',monospace;color:#bbb;cursor:pointer;display:flex;align-items:center;gap:6px;transition:background .08s;}
.ve-ac-i:hover,.ve-ac-i.sel{background:#333;color:#baf400;}
.ve-ac-sw{width:10px;height:10px;border-radius:2px;border:1px solid #444;flex-shrink:0;}
.ve-ac-wrap{position:relative;flex:1;}

/* Premium finish */
.ve-o{width:410px;background:#1f1f1f;border:1px solid rgba(255,255,255,.10);border-radius:var(--ve-radius-xl);box-shadow:none;overflow:visible;}
.ve-o.ve-dock-right{top:8px;right:8px;bottom:8px;height:calc(100vh - 16px);left:auto;transform:translateX(calc(100% + 16px));}
.ve-o.ve-dock-left{top:8px;left:8px;bottom:8px;height:calc(100vh - 16px);right:auto;border-left:1px solid rgba(255,255,255,.10);border-right:1px solid rgba(255,255,255,.10);transform:translateX(calc(-100% - 16px));}
.ve-o.ve-dock-right.open,.ve-o.ve-dock-left.open{transform:translateX(0);}
.ve-o.open{box-shadow:-18px 0 42px rgba(0,0,0,.36);}
.ve-o.ve-float.open{box-shadow:0 18px 46px rgba(0,0,0,.40);}
.ve-o.ve-standalone-panel:not([data-panel="content_studio"]):not([data-panel="media_studio"]):not([data-panel="plugin_studio"]):not([data-panel="css_recipes"]):not([data-panel="css_studio"]){transform:none!important;right:auto!important;bottom:auto!important;transition:opacity .18s ease!important;pointer-events:auto!important;}
.ve-hdr,.ve-sub-hdr,.ve-st,.ve-det{background:#1a1a1a;border-color:rgba(255,255,255,.08);}
.ve-hdr{padding:12px 16px 10px;gap:8px;flex-wrap:wrap}.ve-brand{display:flex;align-items:center;justify-content:space-between;gap:10px;flex:1;min-width:0}.ve-hdr-i{width:24px;height:24px;border-radius:var(--ve-radius-md);background:transparent;object-fit:contain;box-shadow:none;order:2}
.ve-hdr-t{font-size:var(--ve-font-sm);letter-spacing:0;text-transform:none;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-hdr-a{gap:4px}.ve-hdr-a button,.ve-exp,.ve-a{border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.035);border-radius:var(--ve-radius-lg);transition:background .15s,border-color .15s,color .15s,box-shadow .15s}.ve-hdr-a button:hover,.ve-exp:hover,.ve-a:hover{background:rgba(186,244,0,.10);border-color:rgba(186,244,0,.40);color:#baf400;box-shadow:none}
.ve-hdr-a{order:2;width:calc(100% + 32px);margin:2px -16px 0;padding:8px 16px 0 16px;border-top:1px solid rgba(255,255,255,.06);justify-content:flex-start}
.ve-sr{padding:12px 16px;border-color:rgba(255,255,255,.08)}.ve-sr input,.ve-row input,.ve-ren input,.ve-opt input[type=number],.ve-opt input[type=text],.ve-sel,.ve-cp-v{height:var(--ve-control-height)!important;min-height:var(--ve-control-height)!important;max-height:var(--ve-control-height)!important;padding:0 11px;background:var(--ve-surface);border:1px solid var(--ve-border);border-radius:var(--ve-radius-sm);color:var(--ve-text);line-height:var(--ve-control-height)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 1px 0 rgba(0,0,0,.25);transition:border-color .16s,box-shadow .16s,background .16s}.ve-sr input:focus,.ve-row input:focus,.ve-ren input:focus,.ve-opt input:focus,.ve-sel:focus{border-color:var(--ve-accent);box-shadow:inset 0 1px 0 rgba(255,255,255,.04);background:var(--ve-surface-focus)}
.ve-row input.ve-hue,.ve-sub-body input.ve-hue,.ve-hue{min-height:14px!important;height:14px!important;padding:0!important;background:linear-gradient(90deg,#f00 0%,#ff0 16.66%,#0f0 33.33%,#0ff 50%,#00f 66.66%,#f0f 83.33%,#f00 100%)!important;border:1px solid rgba(255,255,255,.14)!important;border-radius:var(--ve-radius-pill)!important;box-shadow:inset 0 1px 1px rgba(0,0,0,.35)!important}
.ve-hue::-webkit-slider-runnable-track{height:14px;border-radius:var(--ve-radius-pill);background:linear-gradient(90deg,#f00 0%,#ff0 16.66%,#0f0 33.33%,#0ff 50%,#00f 66.66%,#f0f 83.33%,#f00 100%)}
.ve-hue::-moz-range-track{height:14px;border-radius:var(--ve-radius-pill);background:linear-gradient(90deg,#f00 0%,#ff0 16.66%,#0f0 33.33%,#0ff 50%,#00f 66.66%,#f0f 83.33%,#f00 100%)}
.ve-opt{align-items:center;padding:8px 0;font-size:var(--ve-font-sm);gap:10px}.ve-opt>span{color:#aaa}.ve-opt label{gap:9px;color:#d4d4d4;line-height:1.5}.ve-opt input[type=checkbox],.ve-opt input[type=radio]{appearance:none;-webkit-appearance:none;width:16px;height:16px;border:1px solid rgba(255,255,255,.18);border-radius:var(--ve-radius-sm);background:#242424;display:inline-grid;place-content:center;flex:0 0 16px;margin:0;cursor:pointer}.ve-opt input[type=checkbox]:checked,.ve-opt input[type=radio]:checked{background:#baf400;border-color:#baf400;box-shadow:none}.ve-opt input[type=checkbox]:checked:before{content:'';width:8px;height:5px;border-left:2px solid #1f1f1f;border-bottom:2px solid #1f1f1f;transform:translateY(-1px) rotate(-45deg)}.ve-opt input[type=number]::-webkit-outer-spin-button,.ve-opt input[type=number]::-webkit-inner-spin-button{appearance:none;-webkit-appearance:none;margin:0}.ve-opt input[type=number]{appearance:textfield;-moz-appearance:textfield;text-align:center;padding-right:11px}.ve-opt-stack{align-items:stretch;flex-direction:column}.ve-opt-stack input{width:100%;font-family:'SF Mono','Fira Code',monospace}
.ve-tabs{padding:8px 12px 4px;gap:7px;border-color:rgba(255,255,255,.08)}.ve-tabs-scroll{gap:5px;padding-bottom:7px}.ve-t{padding:6px 10px;border-radius:var(--ve-radius-lg);letter-spacing:0}.ve-t.on{box-shadow:inset 0 1px 0 rgba(255,255,255,.38)}
.ve-sub{top:86px;background:#1f1f1f}.ve-sub.ve-sidecar{top:0;bottom:0;left:auto;right:calc(100% + 10px);width:410px;border:1px solid rgba(255,255,255,.10);border-radius:var(--ve-radius-xl);overflow:hidden;box-shadow:0 18px 46px rgba(0,0,0,.40);animation:veSideIn .16s ease forwards}.ve-o.ve-dock-left .ve-sub.ve-sidecar{left:calc(100% + 10px);right:auto}.ve-sub.ve-sidecar.closing{animation:veSideOut .16s ease forwards}.ve-sub-body{padding:16px}.ve-sidecar .ve-sub-body{display:flex;flex-direction:column;min-height:0;padding:12px}.ve-row{gap:8px;margin-bottom:10px}.ve-mode{gap:6px;margin-bottom:12px}.ve-mode button{padding:8px;border-radius:var(--ve-radius-lg);background:rgba(255,255,255,.045);border-color:rgba(255,255,255,.10);letter-spacing:0}.ve-mode button.on{box-shadow:inset 0 1px 0 rgba(255,255,255,.42)}
@keyframes veSideIn{from{transform:translateX(14px);opacity:.82}to{transform:translateX(0);opacity:1}}
@keyframes veSideOut{from{transform:translateX(0);opacity:1}to{transform:translateX(14px);opacity:.82}}
.ve-sub-hdr{height:48px;min-height:48px;padding:0 16px;align-items:center}.ve-sub-hdr .ve-exp{width:26px;height:26px;flex:0 0 26px}.ve-sub-hdr span{line-height:1;align-items:center}
.ve-v{margin:3px 10px 3px 0;border-radius:var(--ve-radius-lg);min-height:38px;padding-top:8px!important;padding-bottom:8px!important;overflow:hidden}.ve-v:before{top:0;bottom:0;border-radius:0}.ve-v:hover,.ve-v.sel{background:rgba(255,255,255,.055);box-shadow:inset 0 0 0 1px rgba(255,255,255,.055)}.ve-ch{margin-left:30px;border-color:rgba(255,255,255,.08)}.ve-c{border-radius:7px;margin:2px 8px 2px 0;padding:6px 10px}.ve-sw{width:18px;height:18px;border-radius:var(--ve-radius-md);border-color:rgba(255,255,255,.14)}.ve-nm{font-size:var(--ve-font-sm)}.ve-vl{font-size:var(--ve-font-xs);color:#777}
.ve-btn{position:relative;overflow:hidden;min-height:38px;padding:8px 14px;border-radius:var(--ve-radius-md);background:#baf400;color:#1f1f1f;border:1px solid rgba(186,244,0,.82);box-shadow:0 1px 0 rgba(255,255,255,.12) inset;letter-spacing:0;transition:box-shadow .18s ease,background .18s ease,border-color .18s ease,color .18s ease}.ve-btn:hover{background:#d4ff33;border-color:#d4ff33;color:#1f1f1f;box-shadow:0 1px 0 rgba(255,255,255,.12) inset}.ve-btn-g{background:#303236;color:#e4e4e4;border-color:rgba(255,255,255,.14);box-shadow:inset 0 1px 0 rgba(255,255,255,.04),0 1px 2px rgba(0,0,0,.22)}.ve-btn-g:hover{background:#3a3d42;border-color:rgba(255,255,255,.22);color:#f1f1f1;box-shadow:inset 0 1px 0 rgba(255,255,255,.05),0 2px 8px rgba(0,0,0,.14)}.ve-btn-d{background:#991b1b;color:#fff;border-color:rgba(255,255,255,.14)}.ve-btn-d:hover{background:#7f1d1d;color:#fff;border-color:#ef4444}
.ve-upd{display:flex;align-items:center;gap:8px;margin-top:8px;font-size:var(--ve-font-xs);color:#777;flex-wrap:wrap}.ve-upd .ok{color:#baf400}.ve-upd .muted{color:#888}
.ve-update-help{margin-top:8px;padding:10px 11px;border:1px solid rgba(245,158,11,.28);background:rgba(245,158,11,.075);border-radius:var(--ve-radius-md);color:#f7c777;font-size:var(--ve-font-xs);line-height:1.55}.ve-update-help b{color:#fff}
.ve-release-manager{margin-top:10px;border:1px solid rgba(255,255,255,.10);border-radius:var(--ve-radius-lg);background:rgba(255,255,255,.035);overflow:hidden}.ve-release-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:10px 11px;border-bottom:1px solid rgba(255,255,255,.08);font-size:var(--ve-font-xs);font-weight:800;color:#e7e7e7}.ve-release-channel{color:#baf400;text-transform:uppercase;font-size:var(--ve-font-xxs);letter-spacing:.08em}.ve-release-row{display:grid;grid-template-columns:1fr;gap:8px;align-items:stretch;padding:10px 11px;border-bottom:1px solid rgba(255,255,255,.06);font-size:var(--ve-font-xs)}.ve-release-row:last-child{border-bottom:0}.ve-release-title{display:flex;align-items:center;gap:7px;min-width:0;width:100%;color:#eee;font-weight:700}.ve-release-title span:first-child{overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-release-meta{margin-top:4px;color:#777;line-height:1.45}.ve-release-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));align-items:center;gap:7px;width:100%}.ve-release-actions .ve-btn,.ve-release-actions .ve-release-link{width:100%;justify-content:center;min-height:32px}.ve-release-pill{display:inline-flex;align-items:center;min-height:16px;padding:0 7px;border-radius:999px;background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.08);color:#a8b0b7;font-size:var(--ve-font-xxs);font-weight:500;line-height:16px;text-transform:none;letter-spacing:0}.ve-release-pill-installed{background:rgba(186,244,0,.07);border-color:rgba(186,244,0,.14);color:#baf400}.ve-release-pill-latest{background:rgba(186,244,0,.055);border-color:rgba(186,244,0,.12);color:#c9f66a}.ve-release-pill-rollback{background:rgba(245,158,11,.065);border-color:rgba(245,158,11,.14);color:#d9b977}.ve-release-link{display:inline-flex;align-items:center;min-height:32px;color:#aab2b9;text-decoration:none;border:1px solid rgba(255,255,255,.09);border-radius:var(--ve-radius-md);padding:0 10px;background:rgba(255,255,255,.035);font-size:var(--ve-font-xs);font-weight:700;white-space:nowrap}.ve-release-link:hover{border-color:rgba(186,244,0,.30);color:#e7f8ba;background:rgba(186,244,0,.055)}.ve-release-empty{padding:11px;color:#888;font-size:var(--ve-font-xs);line-height:1.55}.ve-release-confirm{grid-column:1/-1;margin-top:3px;padding:10px;border:1px solid rgba(245,158,11,.30);border-radius:var(--ve-radius-md);background:rgba(245,158,11,.075);color:#f7c777;line-height:1.5}.ve-release-confirm b{display:block;color:#fff;margin-bottom:3px}.ve-release-confirm-actions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:7px;margin-top:9px}.ve-release-confirm-actions .ve-btn{width:100%;justify-content:center}
.ve-viewport-group{display:grid;gap:12px;margin:8px 0 12px;padding:12px 13px 13px;border:1px solid rgba(255,255,255,.07);border-radius:var(--ve-radius-lg);background:rgba(255,255,255,.02)}.ve-viewport-head{display:flex;flex-direction:column;gap:2px}.ve-viewport-head span{font-size:var(--ve-font-xs);font-weight:700;color:#e7e7e7}.ve-viewport-head small{font-size:var(--ve-font-xxs);line-height:1.4;color:#777}.ve-viewport-grid{display:grid;grid-template-columns:1fr 1fr;gap:10px}.ve-viewport-field{display:flex;align-items:center;gap:8px;margin:0;min-width:0;height:var(--ve-control-height,38px);padding:0 11px;background:var(--ve-surface,#282828);border:1px solid var(--ve-border,rgba(255,255,255,.10));border-radius:var(--ve-radius-sm,5px);box-shadow:inset 0 1px 0 rgba(255,255,255,.025);transition:border-color .16s,background .16s}.ve-viewport-field:focus-within{border-color:var(--ve-accent,#baf400);background:var(--ve-surface-focus,#303030)}.ve-viewport-affix{flex:0 0 auto;font-size:var(--ve-font-xxs,10px);font-weight:700;color:#8f8f8f;text-transform:uppercase;letter-spacing:.05em}.ve-viewport-unit{flex:0 0 auto;font-size:var(--ve-font-xxs,10px);color:#6f6f6f}.ve-viewport-field input{flex:1;min-width:0;width:100%;box-sizing:border-box;text-align:right;height:100%!important;padding:0!important;background:transparent!important;border:0!important;border-radius:0!important;color:var(--ve-text,#f1f1f1)!important;font-size:var(--ve-font-xs,11px)!important;box-shadow:none!important;outline:none!important;appearance:none!important;-webkit-appearance:none!important;-moz-appearance:textfield!important}.ve-viewport-field input::-webkit-outer-spin-button,.ve-viewport-field input::-webkit-inner-spin-button{-webkit-appearance:none!important;appearance:none!important;margin:0}@media(max-width:360px){.ve-viewport-grid{grid-template-columns:1fr}}
.ve-o .ve-studio-input,.ve-modal .ve-studio-input,.ve-media-studio .ve-studio-input,.ve-content-studio .ve-studio-input,.ve-plugin-studio .ve-studio-input,.ve-cf-b .ve-studio-input{height:var(--ve-control-height)!important;min-height:var(--ve-control-height)!important;max-height:var(--ve-control-height)!important;padding:0 11px!important;background:var(--ve-surface)!important;border:1px solid var(--ve-border)!important;border-radius:var(--ve-radius-sm)!important;color:var(--ve-text)!important;line-height:var(--ve-control-height)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.025),0 1px 0 rgba(0,0,0,.25)!important;outline:none!important;appearance:none!important;-webkit-appearance:none!important;box-sizing:border-box!important}.ve-o .ve-studio-input::placeholder,.ve-modal .ve-studio-input::placeholder,.ve-media-studio .ve-studio-input::placeholder,.ve-content-studio .ve-studio-input::placeholder,.ve-plugin-studio .ve-studio-input::placeholder,.ve-cf-b .ve-studio-input::placeholder{color:#777!important}.ve-o .ve-studio-input:focus,.ve-modal .ve-studio-input:focus,.ve-media-studio .ve-studio-input:focus,.ve-content-studio .ve-studio-input:focus,.ve-plugin-studio .ve-studio-input:focus,.ve-cf-b .ve-studio-input:focus{border-color:var(--ve-accent)!important;background:var(--ve-surface-focus)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.04)!important}
.ve-update{margin:10px 16px 0;padding:11px 12px;border:1px solid rgba(186,244,0,.26);background:rgba(186,244,0,.075);border-radius:var(--ve-radius-lg);color:#dfffa3;font-size:var(--ve-font-xs);line-height:1.55;display:flex;align-items:center;gap:10px}.ve-update i{color:#baf400;font-size:var(--ve-font-xl)}.ve-update span{flex:1}.ve-update b{color:#f1f1f1}
.ve-clean{margin:10px 16px 0;padding:10px 11px;border:1px solid rgba(245,158,11,.28);background:rgba(245,158,11,.08);border-radius:var(--ve-radius-md);color:#f6c369;font-size:var(--ve-font-xs);line-height:1.55;display:flex;align-items:center;gap:9px}.ve-clean span{flex:1}.ve-clean .ve-btn{min-height:28px;padding:5px 9px;font-size:var(--ve-font-xs)}
.ve-toast{border-radius:9px;box-shadow:0 16px 38px rgba(0,0,0,.35)}.ve-cf-b{border-color:rgba(255,255,255,.10);box-shadow:0 24px 62px rgba(0,0,0,.46)}
.ve-o,.ve-opt,.ve-warn,.ve-empty,.ve-cf-b p,.ve-det-r,.ve-st,.ve-upd{line-height:1.55}
.ve-mode button{line-height:1.35}
.ve-o input[type=checkbox],.ve-o input[type=radio]{appearance:none!important;-webkit-appearance:none!important;width:16px!important;height:16px!important;min-height:16px!important;padding:0!important;border:1px solid rgba(255,255,255,.18)!important;border-radius:var(--ve-radius-sm)!important;background:#242424!important;display:inline-grid!important;place-content:center!important;flex:0 0 16px!important;margin:0!important;cursor:pointer!important;box-shadow:none!important;vertical-align:middle!important}
.ve-o input[type=checkbox]:checked,.ve-o input[type=radio]:checked{background:#baf400!important;border-color:#baf400!important;box-shadow:none!important}
.ve-o input[type=checkbox]:checked:before{content:'';width:8px;height:4px;border-left:2px solid #1f1f1f;border-bottom:2px solid #1f1f1f;transform:translateY(-1px) rotate(-45deg);transform-origin:center}
.ve-o label{display:inline-flex;align-items:center}
.ve-layout-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;width:100%}
.ve-hdr.dragging{cursor:grabbing}
.ve-drag-handle{width:24px;height:24px;display:flex;align-items:center;justify-content:center;border:1px solid rgba(255,255,255,.07);background:rgba(255,255,255,.035);border-radius:var(--ve-radius-lg);color:#777;cursor:grab;flex:0 0 24px}
.ve-drag-handle:hover{background:rgba(186,244,0,.10);border-color:rgba(186,244,0,.40);color:#baf400}
.ve-drag-handle:active{cursor:grabbing}
.ve-snap-zone{position:fixed;top:10px;bottom:10px;width:76px;border:1px dashed rgba(186,244,0,.55);background:rgba(186,244,0,.08);z-index:120010;pointer-events:none;opacity:0;transition:opacity .08s}
.ve-snap-zone.show{opacity:1}
.ve-snap-zone.left{left:10px}.ve-snap-zone.right{right:10px}
.ve-code-shell{border:1px solid rgba(255,255,255,.10);border-radius:7px;overflow:hidden;background:#202020;display:grid;grid-template-columns:38px 1fr;min-height:320px}
.ve-code-wrap{position:relative;min-height:0}
.ve-code-lines{padding:10px 8px;background:#1a1a1a;color:#555;font-family:'SF Mono','Fira Code',monospace;font-size:var(--ve-font-xs);line-height:1.6;text-align:right;user-select:none;border-right:1px solid rgba(255,255,255,.08)}
.ve-code-editor{position:relative;min-width:0;min-height:320px;background:#202020}
.ve-code-highlight{position:absolute;inset:0;margin:0;padding:10px 12px;overflow:hidden;white-space:pre-wrap;word-break:normal;color:#d6d6d6;font-family:'SF Mono','Fira Code',monospace;font-size:var(--ve-font-xs);line-height:1.6;pointer-events:none}
.ve-code-input{position:absolute;inset:0;width:100%;height:100%;min-height:320px!important;padding:10px 12px!important;border:0!important;border-radius:0!important;background:transparent!important;box-shadow:none!important;font-family:'SF Mono','Fira Code',monospace!important;font-size:var(--ve-font-xs)!important;line-height:1.6!important;resize:none;color:transparent!important;-webkit-text-fill-color:transparent!important;caret-color:#f1f1f1!important;white-space:pre-wrap!important;overflow:auto!important}
.ve-code-input::selection{background:rgba(186,244,0,.22);color:transparent}
.ve-code-input::placeholder{color:#6b6b6b!important;-webkit-text-fill-color:#6b6b6b!important}
.tok-comment{color:#666}.tok-string{color:#ffd166}.tok-color{color:#ff6b7a}.tok-var{color:#baf400}.tok-prop{color:#8cc8ff}.tok-num{color:#c5a3ff}.tok-punc{color:#8a8a8a}
.ve-suggest{position:absolute;min-width:170px;max-width:320px;max-height:184px;overflow-y:auto;border:1px solid rgba(186,244,0,.28);background:#252a20;border-radius:7px;box-shadow:0 18px 42px rgba(0,0,0,.55);z-index:120030;pointer-events:auto}
.ve-suggest{scrollbar-width:thin;scrollbar-color:rgba(186,244,0,.48) rgba(255,255,255,.035)}.ve-suggest::-webkit-scrollbar{width:6px;height:6px}.ve-suggest::-webkit-scrollbar-track{background:rgba(255,255,255,.035);border-radius:var(--ve-radius-pill)}.ve-suggest::-webkit-scrollbar-thumb{background:rgba(186,244,0,.46);border-radius:var(--ve-radius-pill);border:1px solid rgba(0,0,0,.22)}
.ve-suggest button{width:100%;display:block;text-align:left;background:transparent;border:0;color:#dfffa3;padding:7px 9px;font-size:var(--ve-font-xs);font-family:'SF Mono','Fira Code',monospace;cursor:pointer}
.ve-suggest button:hover,.ve-suggest button.on{background:rgba(186,244,0,.12);color:#f1f1f1}
.ve-source-list{display:flex;flex-direction:column;gap:6px}
.ve-source-pill{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:8px 9px;border:1px solid rgba(255,255,255,.09);border-radius:7px;background:rgba(255,255,255,.035);font-size:var(--ve-font-xs);color:#ddd}
.ve-source-pill.dragging{opacity:.55;border-color:rgba(186,244,0,.45)}
.ve-source-pill.drop-before{box-shadow:0 -2px 0 #baf400}
.ve-source-pill.drop-after{box-shadow:0 2px 0 #baf400}
.ve-source-grip{display:flex;align-items:center;justify-content:center;width:22px;height:22px;border-radius:var(--ve-radius-md);color:#777;cursor:grab}
.ve-source-grip:hover{background:rgba(186,244,0,.10);color:#baf400}
.ve-source-meta{font-size:var(--ve-font-xs);color:#777;text-transform:uppercase;letter-spacing:.25px}
.ve-source-toggle{width:24px;height:22px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.035);color:#777;border-radius:var(--ve-radius-md);display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0}
.ve-source-toggle.on{color:#baf400;border-color:rgba(186,244,0,.28);background:rgba(186,244,0,.08)}
.ve-source-toggle:hover{color:#f1f1f1;border-color:rgba(255,255,255,.18)}
.ve-css-note{font-size:var(--ve-font-xs);color:#777;line-height:1.55;margin-top:4px}
.ve-css-diag{margin:8px 0;padding:8px 10px;border:1px solid rgba(245,158,11,.24);background:rgba(245,158,11,.06);border-radius:var(--ve-radius-md);color:#f6c369;font-size:var(--ve-font-xs);line-height:1.55}
.ve-scope-label{font-size:var(--ve-font-xs);color:#999;font-weight:700;text-transform:uppercase;margin:0 0 5px}
.ve-studio-top{display:flex;gap:8px;margin-bottom:10px;flex-wrap:wrap}.ve-studio-grid{display:grid;grid-template-columns:115px minmax(0,1fr);gap:10px;min-height:0;flex:1}.ve-studio-main{min-width:0;display:flex;flex-direction:column;min-height:0}.ve-editor-only{display:flex;flex-direction:column;flex:1;min-height:0}.ve-editor-only .ve-code-wrap{flex:1;display:flex;flex-direction:column}.ve-editor-only .ve-code-shell{flex:1;min-height:0;height:100%}.ve-editor-only .ve-code-editor{height:100%;min-height:0}.ve-editor-only .ve-code-input{min-height:0!important;height:100%;resize:none}.ve-editor-actions{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-top:10px;padding-top:10px;border-top:1px solid rgba(255,255,255,.08)}.ve-editor-actions small{color:#777;font-size:var(--ve-font-xs);line-height:1.45}
.ve-modal{position:absolute;inset:0;z-index:20;background:rgba(0,0,0,.72);backdrop-filter:blur(3px);display:flex;align-items:center;justify-content:center;padding:18px}.ve-modal-box{width:min(300px,100%);border:1px solid rgba(255,255,255,.12);background:#1f1f1f;border-radius:var(--ve-radius-xl);padding:14px;box-shadow:0 18px 42px rgba(0,0,0,.46);animation:veColorIn .14s cubic-bezier(.2,.8,.2,1)}.ve-modal-title{font-size:var(--ve-font-sm);font-weight:800;color:#f1f1f1;margin-bottom:6px}.ve-modal-body{font-size:var(--ve-font-xs);color:#bbb;line-height:1.55;margin-bottom:12px}.ve-modal-actions{display:flex;gap:8px;justify-content:flex-end}
.ve-delete-impact-box{width:min(360px,100%);padding:0;overflow:hidden;border-color:rgba(255,90,90,.22);background:linear-gradient(180deg,#222 0%,#1d1d1d 100%)}.ve-delete-impact-head{display:flex;gap:10px;align-items:flex-start;padding:14px;border-bottom:1px solid rgba(255,255,255,.08)}.ve-delete-impact-icon{width:34px;height:34px;display:grid;place-items:center;flex:0 0 34px;border-radius:9px;border:1px solid rgba(239,68,68,.28);background:rgba(239,68,68,.09);color:#ff6b6b;font-size:var(--ve-font-2xl)}.ve-delete-impact-copy{min-width:0;flex:1}.ve-delete-impact-title{font-size:var(--ve-font-sm);font-weight:800;color:#f2f2f2;line-height:1.35}.ve-delete-impact-name{margin-top:3px;color:#baf400;font:10px/1.45 'SF Mono','Fira Code',monospace;overflow-wrap:anywhere}.ve-delete-impact-text{margin-top:6px;color:#8d8d8d;font-size:var(--ve-font-xs);line-height:1.5}.ve-delete-impact-content{padding:12px 14px 4px}.ve-delete-impact-box .ve-usage{margin:0}.ve-delete-impact-box .ve-usage-head{padding:8px 9px}.ve-delete-impact-box .ve-usage-body{max-height:min(230px,34vh);overflow-y:auto;scrollbar-width:thin;scrollbar-color:rgba(186,244,0,.58) rgba(255,255,255,.04)}.ve-delete-impact-box .ve-usage-body::-webkit-scrollbar{width:6px}.ve-delete-impact-box .ve-usage-body::-webkit-scrollbar-track{background:rgba(255,255,255,.04);border-radius:var(--ve-radius-pill)}.ve-delete-impact-box .ve-usage-body::-webkit-scrollbar-thumb{background:rgba(186,244,0,.58);border-radius:var(--ve-radius-pill)}.ve-delete-impact-actions{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:12px 14px 14px}.ve-delete-impact-actions .ve-btn{width:100%}
.ve-family-intro{display:flex;gap:10px;padding:12px;border:1px solid rgba(186,244,0,.18);border-radius:9px;background:linear-gradient(135deg,rgba(186,244,0,.065),rgba(255,255,255,.018));color:#aaa;font-size:var(--ve-font-xs);line-height:1.55;margin-bottom:12px}.ve-family-intro>i{font-size:20px;color:#baf400;flex:0 0 auto}.ve-family-field{display:flex;flex-direction:column;align-items:stretch;width:100%;min-width:0;gap:6px;margin-bottom:11px}.ve-family-field>span{font-size:var(--ve-font-xs);color:#8d8d8d;font-weight:700}.ve-family-root-menu{width:100%;min-width:0}.ve-family-selection{display:flex;flex-wrap:wrap;gap:5px;padding:8px;border:1px solid rgba(255,255,255,.08);border-radius:var(--ve-radius-lg);background:rgba(0,0,0,.16);max-height:112px;overflow:auto}.ve-family-chip{max-width:100%;padding:4px 7px;border:1px solid rgba(255,255,255,.09);border-radius:var(--ve-radius-pill);background:#262626;color:#c9c9c9;font:10px/1.2 monospace;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-family-preview{border:1px solid rgba(186,244,0,.22);border-radius:9px;background:rgba(186,244,0,.035);overflow:hidden;margin-top:12px}.ve-family-preview-h{display:flex;align-items:center;gap:7px;padding:9px 10px;border-bottom:1px solid rgba(186,244,0,.14);color:#dfffa0;font-size:var(--ve-font-xs);font-weight:800}.ve-family-preview-h i{color:#baf400;font-size:var(--ve-font-xl)}.ve-family-change{display:grid;grid-template-columns:minmax(0,1fr);gap:4px;padding:9px 10px;border-bottom:1px solid rgba(255,255,255,.055)}.ve-family-change:last-child{border-bottom:0}.ve-family-change-name{color:#eee;font:10px/1.35 monospace;overflow-wrap:anywhere}.ve-family-change-path{color:#858585;font-size:var(--ve-font-xs);line-height:1.45}.ve-family-change-path b{color:#baf400;font-weight:700}.ve-family-note{font-size:var(--ve-font-xs);color:#777;line-height:1.5;margin-top:9px}.ve-family-actions{display:flex;justify-content:flex-end;gap:6px;margin-top:12px;position:sticky;bottom:-16px;padding:10px 0 0;background:linear-gradient(transparent,#1f1f1f 30%)}
.ve-sheet-tab{display:flex!important;align-items:center;justify-content:space-between!important;gap:6px}.ve-sheet-tab span{min-width:0;overflow:hidden;text-overflow:ellipsis}.ve-sheet-del{width:22px;height:22px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.035);color:#777;border-radius:var(--ve-radius-md);display:flex;align-items:center;justify-content:center;cursor:pointer;padding:0;flex:0 0 22px}.ve-sheet-del:hover{color:#ef4444;border-color:rgba(239,68,68,.38);background:rgba(239,68,68,.10)}
.ve-recipes{display:grid;gap:6px;margin:8px 0;padding:8px;border:1px solid rgba(255,255,255,.08);border-radius:7px;background:rgba(255,255,255,.025)}
.ve-recipe-row{display:grid;grid-template-columns:58px 1fr;gap:8px;align-items:center;font-size:var(--ve-font-xs);line-height:1.45;color:#bbb}
.ve-recipe-code{font-family:'SF Mono','Fira Code',monospace;color:#baf400;background:rgba(186,244,0,.08);border:1px solid rgba(186,244,0,.16);border-radius:var(--ve-radius-sm);padding:3px 5px;text-align:center}
.ve-recipe-studio{display:flex;flex-direction:column;flex:1;min-height:0;background:#151515}
.ve-recipe-studio-main{display:grid;grid-template-columns:minmax(260px,1fr) minmax(360px,460px);gap:18px;padding:20px;flex:1;min-height:0;overflow:hidden}
.ve-recipe-list{display:flex;flex-direction:column;gap:10px;min-height:0;overflow:auto;padding-right:4px}
.ve-recipe-card{border:1px solid rgba(255,255,255,.08);border-radius:var(--ve-radius-lg);background:#1a1a1a;padding:12px;display:grid;grid-template-columns:96px minmax(0,1fr) auto;gap:12px;align-items:center;cursor:pointer;transition:border-color .16s ease,background .16s ease,box-shadow .16s ease}
.ve-recipe-card:hover{border-color:rgba(186,244,0,.34);background:#202020;box-shadow:0 12px 28px rgba(0,0,0,.22)}
.ve-recipe-card strong{color:#fff;font-size:var(--ve-font-sm);line-height:1.35}.ve-recipe-card small{display:block;color:#777;font-size:var(--ve-font-xs);line-height:1.45;margin-top:2px}
.ve-recipe-form{border:1px solid rgba(255,255,255,.08);border-radius:var(--ve-radius-lg);background:#1a1a1a;padding:14px;display:flex;flex-direction:column;gap:14px;min-height:0;height:100%;align-items:stretch;overflow:hidden}.ve-recipe-field{display:flex;flex-direction:column;gap:8px;align-items:stretch}.ve-recipe-field .ve-scope-label{text-align:left;display:block;margin:0;color:#9a9a9a}.ve-recipe-field .ve-studio-input{min-height:38px;height:38px;width:100%;box-sizing:border-box}.ve-recipe-shortcode{display:grid;grid-template-columns:38px minmax(0,1fr);gap:10px;width:100%}.ve-recipe-shortcode .ve-studio-input:first-child{border-radius:var(--ve-radius-lg);display:flex;align-items:center;justify-content:center;color:#baf400;font-weight:800}.ve-recipe-shortcode input.ve-studio-input{border-radius:var(--ve-radius-lg)}.ve-recipe-editor{flex:1 1 auto;min-height:0;display:flex;flex-direction:column;width:100%;align-self:stretch}.ve-recipe-editor .ve-code-wrap{flex:1;display:flex;flex-direction:column;width:100%;min-width:0;min-height:0}.ve-recipe-editor .ve-code-shell{flex:1;min-height:260px;width:100%}.ve-recipe-editor .ve-code-editor,.ve-recipe-editor .ve-code-input,.ve-recipe-editor .ve-code-highlight{height:100%!important;min-height:0!important;resize:none!important}.ve-recipe-form-actions{display:flex;justify-content:space-between;gap:8px;align-items:center;margin-top:0;padding-top:10px;border-top:1px solid rgba(255,255,255,.08)}.ve-content-edit-form{height:100%;max-width:none;overflow:hidden;display:flex;flex-direction:column;gap:14px;background:rgba(255,255,255,.01);border:1px solid rgba(255,255,255,.05);border-radius:var(--ve-radius-xl);padding:20px}.ve-content-edit-scroll{flex:1;min-height:0;overflow:auto;display:flex;flex-direction:column;gap:14px;padding-right:4px}.ve-content-edit-actions{margin-top:auto;padding-top:12px;border-top:1px solid rgba(255,255,255,.08);display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap}.ve-content-field-edit-form{height:100%;max-width:none!important;overflow:hidden;display:flex!important;flex-direction:column!important;gap:14px;background:rgba(255,255,255,.01);border:1px solid rgba(255,255,255,.05);border-radius:var(--ve-radius-xl);padding:20px}.ve-content-field-edit-form .ve-content-field-edit-main{flex:1;min-height:0;overflow:auto;display:grid;grid-template-columns:minmax(260px,520px);align-content:start;gap:14px}.ve-content-field-edit-form .ve-content-field-edit-actions{margin-top:auto;padding-top:12px;border-top:1px solid rgba(255,255,255,.08);display:flex;gap:8px;justify-content:flex-end}.ve-content-advanced,.ve-content-custom-fields{border:1px solid rgba(255,255,255,.08);border-radius:var(--ve-radius-lg);background:rgba(255,255,255,.02);padding:10px}.ve-content-advanced summary,.ve-content-custom-fields summary{cursor:pointer;color:#baf400;font-size:var(--ve-font-xs);font-weight:800;text-transform:uppercase;letter-spacing:.04em}.ve-content-field-help{font-size:var(--ve-font-xs);color:#777;line-height:1.45;margin-top:5px}.ve-content-custom-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px;margin-top:12px}.ve-field-serialized{font-family:'SF Mono','Fira Code',monospace!important;line-height:1.55!important;min-height:118px!important;white-space:pre-wrap}
.ve-rich-editor{border:1px solid rgba(255,255,255,.10);border-radius:9px;background:#202020;overflow:hidden;box-shadow:inset 0 1px 0 rgba(255,255,255,.025)}
.ve-rich-toolbar{display:flex;gap:6px;align-items:center;flex-wrap:wrap;padding:8px;background:#181818;border-bottom:1px solid rgba(255,255,255,.08)}
.ve-rich-toolbar button{min-height:30px;padding:6px 9px;border:1px solid rgba(255,255,255,.10);border-radius:var(--ve-radius-md);background:#2b2d31;color:#e8e8e8;font-size:var(--ve-font-xs);font-weight:800;cursor:pointer}
.ve-rich-toolbar button:hover{border-color:rgba(186,244,0,.4);background:rgba(186,244,0,.10);color:#baf400}
.ve-rich-surface{min-height:min(430px,45vh);padding:18px;background:#202020;color:#f2f2f2;font-size:var(--ve-font-md);line-height:1.75;outline:none;overflow:auto;resize:vertical}
.ve-rich-surface:focus{box-shadow:none}
.ve-rich-surface:empty:before{content:attr(data-placeholder);color:#666}
.ve-rich-surface h1{font-size:var(--ve-font-4xl);line-height:1.2;margin:0 0 14px}.ve-rich-surface h2{font-size:21px;line-height:1.25;margin:0 0 12px}.ve-rich-surface h3{font-size:17px;line-height:1.35;margin:0 0 10px}.ve-rich-surface p{margin:0 0 12px}.ve-rich-surface ul,.ve-rich-surface ol{margin:0 0 12px 22px;padding:0}.ve-rich-surface blockquote{margin:0 0 12px;padding:8px 12px;border-left:3px solid #baf400;background:rgba(186,244,0,.06)}
.ve-standalone-panel[data-panel="css_studio"]{width:min(430px,calc(100vw - 32px))!important;max-width:430px!important;min-width:min(360px,calc(100vw - 32px))!important;overflow:hidden!important}
.ve-standalone-panel[data-panel="css_studio"] .ve-body{overflow:hidden!important}
.ve-css-studio-combined{padding:14px;flex:1;overflow:hidden;display:flex;flex-direction:column;min-height:0}
.ve-css-studio-combined-grid{display:flex;flex-direction:column;gap:12px;flex:1;min-height:0;overflow:hidden}
.ve-css-settings-column{min-width:0;display:flex;flex-direction:column;gap:8px;overflow:visible;padding-right:2px;flex:0 0 auto}
.ve-css-sheet-list{display:flex;flex-direction:column;gap:6px;max-height:132px;overflow:auto;padding-right:2px}
.ve-css-editor-column{min-width:0;display:flex;flex-direction:column;min-height:220px;flex:1 1 auto;border:1px solid rgba(255,255,255,.07);border-radius:var(--ve-radius-xl);background:rgba(255,255,255,.015);padding:10px}
.ve-css-editor-column .ve-editor-only{height:100%;min-height:0}
.ve-css-editor-column .ve-code-shell{min-height:0}
.ve-sub.ve-sidecar{height:100%;max-height:calc(100vh - 16px)}
.ve-sub.ve-sidecar .ve-sub-body{flex:1 1 auto;overflow:hidden;min-height:0;height:calc(100% - 48px)}
.ve-editor-only,.ve-editor-only .ve-code-wrap,.ve-editor-only .ve-code-shell,.ve-editor-only .ve-code-editor{width:100%;min-height:0}
.ve-editor-only .ve-code-wrap{height:100%}
.ve-editor-only .ve-code-shell{height:100%;min-height:0}
.ve-editor-only .ve-code-editor,.ve-editor-only .ve-code-input,.ve-editor-only .ve-code-highlight{height:100%!important;min-height:0!important;resize:none!important}
.ve-code-lines{margin:0}
.ve-cm-host{height:100%;min-height:320px;border:1px solid rgba(255,255,255,.10);border-radius:7px;overflow:hidden;background:#202020}
.ve-editor-only .ve-cm-host{height:100%;min-height:0}
.ve-css-studio-combined .ve-studio-top{margin-bottom:4px}.ve-css-studio-combined .ve-row{margin-bottom:6px}.ve-css-studio-combined .ve-studio-main{gap:4px}
.ve-cm-host .CodeMirror{height:100%;background:#202020;color:#d6d6d6;font-family:'SF Mono','Fira Code',monospace;font-size:var(--ve-font-xs);line-height:1.6}
.ve-cm-host .CodeMirror-gutters{background:#1a1a1a;border-right:1px solid rgba(255,255,255,.08)}
.ve-cm-host .CodeMirror-linenumber{color:#555}
.ve-cm-host .CodeMirror-cursor{border-left-color:#f1f1f1}
.ve-cm-host .CodeMirror-selected{background:rgba(186,244,0,.18)!important}
.ve-cm-host .cm-comment{color:#666}.ve-cm-host .cm-string{color:#ffd166}.ve-cm-host .cm-atom,.ve-cm-host .cm-number{color:#c5a3ff}.ve-cm-host .cm-property{color:#8cc8ff}.ve-cm-host .cm-variable-2,.ve-cm-host .cm-variable-3{color:#baf400}.ve-cm-host .cm-keyword{color:#ff6b7a}.ve-cm-host .cm-def{color:#baf400}
.ve-cm-host .CodeMirror-hints,.ve-cm-hints-root .CodeMirror-hints{z-index:120040!important;background:#252a20!important;border:1px solid rgba(186,244,0,.28)!important;border-radius:7px!important;box-shadow:0 18px 42px rgba(0,0,0,.55)!important;font-family:'SF Mono','Fira Code',monospace!important;font-size:var(--ve-font-xs)!important;max-height:260px!important;min-width:220px!important;overflow:auto!important}
.ve-cm-host .CodeMirror-hints .CodeMirror-hint,.ve-cm-hints-root .CodeMirror-hints .CodeMirror-hint{color:#dfffa3!important;padding:6px 9px!important;border-radius:var(--ve-radius-sm)!important}
.ve-cm-host .CodeMirror-hints .CodeMirror-hint-active,.ve-cm-hints-root .CodeMirror-hints .CodeMirror-hint-active{background:rgba(186,244,0,.16)!important;color:#f1f1f1!important}
.ve-fab-wrap.ve-fab-left-side{align-items:flex-start!important}
.ve-fab-wrap.ve-fab-left-side .ve-fab-tooltip{left:42px!important;right:auto!important}

/* Studio layouts */
.ve-studio-layout { display: flex; height:100%; min-height:0; flex: 1; background: #151515; position: relative; }
.ve-studio-sidebar { width:240px; background: #111; border-right:1px solid rgba(255,255,255,0.06); display: flex; flex-direction: column; padding:16px; gap:16px; flex-shrink: 0; }
.ve-studio-main { flex: 1; display: flex; flex-direction: column; padding:20px; min-width:0; min-height:0; overflow: hidden; position: relative; }
.ve-studio-nav { display: flex; flex-direction: column; gap:4px; }
.ve-studio-nav-item { display: flex; align-items: center; justify-content: space-between; padding:8px 12px; border-radius:var(--ve-radius-md); color: #ccc; cursor: pointer; text-decoration: none; font-size:var(--ve-font-sm); transition: background .15s, color .15s; }
.ve-studio-nav-item:hover { background: rgba(255,255,255,0.04); color: #fff; }
.ve-studio-nav-item.active { background: rgba(186,244,0,0.12); color: #baf400; font-weight: 600; }
.ve-studio-nav-item.drop-before,.ve-studio-nav-item.drop-after,.ve-studio-nav-item.drop-nest,.ve-studio-nav-item.drop-media{position:relative;border-radius:8px!important}
.ve-studio-nav-item.drop-before,.ve-studio-nav-item.drop-after{background:rgba(186,244,0,.03)!important;box-shadow:inset 0 0 0 1px rgba(186,244,0,.28)!important}
.ve-studio-nav-item.drop-before:before,.ve-studio-nav-item.drop-after:before{content:'';position:absolute;left:10px;right:10px;height:2px;background:#baf400;border-radius:0;box-shadow:0 0 12px rgba(186,244,0,.32);pointer-events:none}
.ve-studio-nav-item.drop-before:before{top:-2px}
.ve-studio-nav-item.drop-after:before{bottom:-2px}
.ve-studio-nav-item.drop-before:after,.ve-studio-nav-item.drop-after:after,.ve-studio-nav-item.drop-nest:after,.ve-studio-nav-item.drop-media:after{position:absolute;right:8px;top:50%;transform:translateY(-50%);height:18px;padding:0 7px;border:1px solid rgba(186,244,0,.26);background:#baf400;color:#131313;border-radius:6px;font-size:9px;font-weight:900;text-transform:uppercase;letter-spacing:.04em;display:flex;align-items:center;pointer-events:none}
.ve-studio-nav-item.drop-before:after{content:attr(data-drop-label)}
.ve-studio-nav-item.drop-after:after{content:attr(data-drop-label)}
.ve-studio-nav-item.drop-nest{background:rgba(186,244,0,.045)!important;box-shadow:inset 0 0 0 1px rgba(186,244,0,.38)!important}
.ve-studio-nav-item.drop-nest:before{content:'';position:absolute;left:10px;top:7px;bottom:7px;width:1px;background:rgba(186,244,0,.86);border-radius:1px;box-shadow:0 0 10px rgba(186,244,0,.25);pointer-events:none}
.ve-studio-nav-item.drop-nest:after{content:attr(data-drop-label)}
.ve-studio-nav-item.drop-media{background:rgba(186,244,0,.06)!important;box-shadow:inset 0 0 0 1px rgba(186,244,0,.56)!important}
.ve-studio-nav-item.drop-media:after{content:attr(data-drop-label)}
.ve-studio-nav-item.has-custom-color{box-shadow:inset 3px 0 0 var(--ve-collection-accent, #baf400)}
.ve-studio-nav-item.starred{background:rgba(186,244,0,.035)}
.ve-studio-nav-item.starred.active{background:rgba(186,244,0,.14)}
.ve-collection-star-pill{width:14px;height:14px;display:inline-flex;align-items:center;justify-content:center;color:#baf400;flex:0 0 14px;filter:drop-shadow(0 0 6px rgba(186,244,0,.24))}
.ve-collection-star-pill svg,.ve-collection-star-pill i{font-size:11px}
.ve-collection-choice.disabled{opacity:.54;cursor:not-allowed}
.ve-studio-nav-title { font-size:var(--ve-font-xs); font-weight: 700; text-transform: uppercase; color: #555; letter-spacing:0.8px; margin-top:12px; margin-bottom:6px; }
.ve-studio-badge { background: rgba(255,255,255,0.06); color: #888; font-size:var(--ve-font-xs); padding:2px 6px; border-radius:99px; }
.ve-studio-nav-item.active .ve-studio-badge { background: rgba(186,244,0,0.2); color: #baf400; }
.ve-studio-readonly{opacity:.72!important;cursor:not-allowed!important;background:rgba(255,255,255,.035)!important;color:#a8adb4!important}
.ve-studio-stats { margin-top:auto; padding:12px; background: rgba(255,255,255,0.02); border: 1px solid rgba(255,255,255,0.05); border-radius:var(--ve-radius-lg); font-size:var(--ve-font-xs); display: flex; gap:8px; flex-direction: column; }
.ve-studio-stats-item { display: flex; align-items: center; justify-content: space-between; }
.ve-studio-summary-note{margin-top:auto;padding:10px 12px;border:1px solid rgba(255,255,255,.055);border-radius:var(--ve-radius-lg);background:rgba(255,255,255,.018);color:#858b92;font-size:10px;line-height:1.45;display:flex;align-items:flex-start;gap:6px}.ve-studio-summary-note svg,.ve-studio-summary-note i{color:#baf400;flex:0 0 auto;margin-top:1px}
.ve-plugin-table td{vertical-align:middle}
.ve-plugin-description{color:#b9c0c8;font-size:var(--ve-font-xs);line-height:1.55;max-width:720px}
.ve-plugin-author{color:#858b92;font-size:var(--ve-font-xs);line-height:1.45}
.ve-plugin-directory-bar{display:grid;grid-template-columns:minmax(180px,1fr) auto auto auto;gap:8px;align-items:center;margin:0 0 12px}
.ve-plugin-directory-results{display:grid;grid-template-columns:1fr;align-content:start;gap:10px;margin-bottom:0;flex:1;min-height:0;overflow:auto;padding-right:4px}
.ve-plugin-directory-results.grid{grid-template-columns:repeat(auto-fill,minmax(300px,1fr));align-items:stretch}
.ve-plugin-card{display:grid;grid-template-columns:48px minmax(0,1fr) auto;align-items:center;justify-content:normal;gap:14px;padding:13px 14px;border:1px solid rgba(255,255,255,.08);border-radius:var(--ve-radius-lg);background:#191919;min-width:0}
.ve-plugin-directory-results.grid .ve-plugin-card{grid-template-columns:48px minmax(0,1fr);grid-template-rows:auto 1fr;align-items:start;min-height:176px}
.ve-plugin-directory-results.grid .ve-plugin-card .ve-btn{grid-column:2;align-self:end;justify-self:start}
.ve-plugin-card-icon{width:42px;height:42px;border-radius:9px;border:1px solid rgba(255,255,255,.10);background:#242424;object-fit:cover;display:flex;align-items:center;justify-content:center;color:#baf400;flex:0 0 42px}
.ve-context-menu{position:fixed;z-index:120040;min-width:178px;padding:6px;border:1px solid rgba(255,255,255,.11);border-radius:var(--ve-radius-lg);background:#1b1b1b;box-shadow:0 18px 42px rgba(0,0,0,.55);display:flex;flex-direction:column;gap:3px;max-height:min(330px,calc(100vh - 24px));overflow:auto}
.ve-context-menu-attached:before{content:'';position:absolute;left:var(--ve-context-arrow-left,-5px);top:var(--ve-context-arrow-y,12px);width:9px;height:9px;background:#1b1b1b;border-left:1px solid rgba(255,255,255,.11);border-bottom:1px solid rgba(255,255,255,.11);transform:rotate(var(--ve-context-arrow-rotate,45deg))}
.ve-context-menu button{height:30px;border:0;border-radius:var(--ve-radius-md);background:transparent;color:#ddd;text-align:left;font-size:var(--ve-font-xs);font-weight:600;display:flex;align-items:center;gap:8px;padding:0 9px;cursor:pointer}
.ve-context-menu button:hover{background:rgba(186,244,0,.10);color:#baf400}
.ve-context-menu button.danger:hover{background:rgba(239,68,68,.12);color:#ff6b6b}
.ve-collection-color-modal{width:330px;max-width:calc(100vw - 28px)}
.ve-collection-color-name{display:flex;align-items:center;gap:8px;min-height:34px;margin:10px 0;padding:8px 10px;border:1px solid rgba(255,255,255,.08);border-radius:8px;background:rgba(255,255,255,.025);color:#f1f1f1;font-size:12px;font-weight:800}
.ve-collection-color-name svg,.ve-collection-color-name i{color:#baf400}
.ve-collection-color-grid{display:grid;grid-template-columns:repeat(5,1fr);gap:8px;margin-top:10px}
.ve-collection-color-swatch{position:relative;height:34px;border:1px solid rgba(255,255,255,.11);border-radius:9px;background:#242424;cursor:pointer;display:flex;align-items:center;justify-content:center;padding:0;box-shadow:inset 0 1px 0 rgba(255,255,255,.035);transition:border-color .14s,transform .14s,box-shadow .14s}
.ve-collection-color-swatch span{display:block;width:20px;height:20px;border-radius:99px;background:var(--ve-swatch-color);box-shadow:0 0 0 1px rgba(0,0,0,.22) inset}
.ve-collection-color-swatch:hover{transform:translateY(-1px);border-color:rgba(186,244,0,.42);box-shadow:0 10px 22px rgba(0,0,0,.28)}
.ve-collection-color-swatch.active{border-color:#baf400;box-shadow:0 0 0 1px rgba(186,244,0,.35),0 10px 22px rgba(0,0,0,.28)}
.ve-collection-color-swatch.clear{color:#8f8f8f}
.ve-collection-color-swatch em{position:absolute;right:4px;top:4px;width:13px;height:13px;border-radius:99px;background:#baf400;color:#111;display:flex;align-items:center;justify-content:center;font-style:normal}
.ve-collection-color-swatch em svg,.ve-collection-color-swatch em i{font-size:9px}
.ve-collection-color-custom{display:grid;grid-template-columns:auto 42px minmax(0,1fr);gap:8px;align-items:center;margin-top:12px;padding:9px 10px;border:1px solid rgba(255,255,255,.08);border-radius:9px;background:rgba(255,255,255,.025);color:#bdbdbd;font-size:11px;font-weight:800}
.ve-collection-color-custom input[type=color]{width:38px;height:26px;border:0;border-radius:7px;background:transparent;padding:0;cursor:pointer}
.ve-collection-color-custom code{color:#f1f1f1;font-family:'SF Mono','Fira Code',monospace;font-size:11px;text-align:right}
.ve-collection-drag{width:20px;height:24px;border:0;background:transparent;color:#666;border-radius:var(--ve-radius-md);display:flex;align-items:center;justify-content:center;cursor:grab;padding:0;margin-left:-4px;flex:0 0 20px}
.ve-collection-drag:hover{background:rgba(186,244,0,.10);color:#baf400}
.ve-collection-drag:active{cursor:grabbing}
.ve-collection-drag-disabled{cursor:not-allowed;color:#555;opacity:.65}
.ve-collection-drag-disabled:hover{background:transparent;color:#777}
.ve-collection-drag-disabled svg,.ve-collection-drag-disabled i{font-size:var(--ve-font-sm)}
.ve-collection-branch{width:13px;height:13px;color:#777;display:inline-flex;align-items:center;justify-content:center;flex:0 0 13px}
.ve-collection-badge{font-size:9px;font-weight:650;text-transform:uppercase;letter-spacing:.18px;border-radius:var(--ve-radius-pill);padding:1px 4px;line-height:1;color:rgba(210,214,216,.58);background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.055)}
.ve-collection-badge.local{color:rgba(186,244,0,.44);background:rgba(186,244,0,.018);border-color:rgba(186,244,0,.055)}
.ve-collection-badge.folder{color:rgba(169,177,186,.7);background:rgba(148,163,184,.04);border-color:rgba(148,163,184,.09)}
.ve-media-tree-guides{display:flex;align-items:center;align-self:stretch;flex-shrink:0}
.ve-tree-guide{width:12px;align-self:stretch;display:flex;align-items:stretch;justify-content:center;flex-shrink:0;position:relative}
.ve-tree-guide:before{content:'';position:absolute;left:6px;top:0;bottom:0;width:1px;background:rgba(186,244,0,.14)}
.ve-tree-toggle{width:16px;height:16px;display:inline-flex;align-items:center;justify-content:center;color:#929a8f;padding:0;border:1px solid transparent;background:transparent;border-radius:5px;cursor:pointer;margin-right:2px;flex-shrink:0}
.ve-tree-toggle:hover{color:#baf400;background:rgba(186,244,0,.08);border-color:rgba(186,244,0,.14)}
.ve-tree-spacer{width:16px;height:16px;margin-right:2px;flex-shrink:0}
.ve-media-settings-card{margin-top:10px;background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.07);border-radius:9px;padding:10px;display:flex;flex-direction:column;gap:10px}
.ve-media-settings-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px}
.ve-media-settings-title{font-size:11px;font-weight:800;color:#e8eadf;display:flex;align-items:center;gap:6px;line-height:1.25}
.ve-media-settings-title svg{color:#baf400}
.ve-media-settings-desc{font-size:10px;color:#858585;line-height:1.5;margin-top:3px}
.ve-media-settings-tree{display:flex;flex-direction:column;gap:4px;max-height:190px;overflow:auto;padding:6px;border:1px solid rgba(255,255,255,.055);border-radius:7px;background:rgba(0,0,0,.18)}
.ve-media-settings-row{min-height:30px;display:flex;align-items:center;gap:4px;padding:4px 6px;border-radius:6px;background:rgba(255,255,255,.018);color:#d8ddd1}
.ve-media-settings-row:hover{background:rgba(255,255,255,.038)}
.ve-media-settings-name{display:flex;align-items:center;gap:6px;min-width:0;flex:1}
.ve-media-settings-name span{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10.5px;font-weight:650}
.ve-media-settings-actions{display:grid;gap:7px}
.ve-media-settings-action-row{display:flex;align-items:center;justify-content:space-between;gap:10px;min-height:32px;padding:7px 8px;border:1px solid rgba(255,255,255,.055);border-radius:7px;background:rgba(255,255,255,.018)}
.ve-media-settings-action-row .ve-check-row{min-height:18px}
.ve-media-settings-empty{padding:10px;border:1px dashed rgba(255,255,255,.08);border-radius:7px;color:#777;font-size:10px;line-height:1.45}
.ve-toggle{position:relative;width:44px;min-width:44px;height:22px;border:1px solid rgba(255,255,255,.12);border-radius:var(--ve-radius-pill);background:#242424;color:#9a9a9a;padding:2px;display:inline-flex;align-items:center;justify-content:flex-start;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.035);transition:background .16s,border-color .16s,color .16s}
.ve-toggle-knob{position:relative;z-index:2;width:16px;height:16px;border-radius:50%;background:#f3f3f3;box-shadow:none;display:inline-flex;align-items:center;justify-content:center;color:#202020;transition:transform .16s,background .16s}
.ve-toggle.on{background:rgba(186,244,0,.22);color:#dfffa3;border-color:rgba(186,244,0,.50)}
.ve-toggle.on .ve-toggle-knob{transform:translateX(22px);background:#f1f1f1}
.ve-toggle-label{position:absolute;top:50%;height:16px;display:flex;align-items:center;justify-content:center;transform:translateY(-50%);font-size:9px;font-weight:800;line-height:16px;letter-spacing:-.02em;pointer-events:none}.ve-toggle.off .ve-toggle-label{right:7px;color:#aaa}.ve-toggle.on .ve-toggle-label{left:8px;color:#dfffa3}.ve-toggle:disabled{opacity:.45;cursor:not-allowed}.ve-toggle:hover:not(:disabled){border-color:rgba(186,244,0,.36);color:#f4f4f4}.ve-toggle.on:hover:not(:disabled){color:#dfffa3}
.ve-module-card{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;align-items:center;padding:12px 0;border-bottom:1px solid rgba(255,255,255,.055)}
.ve-module-card-title{font-weight:800;color:#fff;font-size:12px;line-height:1.35}
.ve-module-card-desc{font-size:11px;color:#858585;line-height:1.45;margin-top:3px;max-width:230px}
.ve-module-surface-controls{display:grid;grid-template-columns:repeat(2,58px);gap:8px;align-items:center}
.ve-module-surface-toggle{display:flex!important;flex-direction:column;align-items:center!important;gap:5px!important;color:#9c9c9c!important;font-size:9px!important;text-transform:uppercase;font-weight:850!important;letter-spacing:.04em;line-height:1!important;cursor:pointer}
.ve-module-surface-toggle .ve-toggle{margin:0}
.ve-media-locked{opacity:.62}.ve-media-locked .ve-collection-drag{cursor:not-allowed}
.ve-collection-source-pill{position:relative;width:22px;height:20px;border:1px solid rgba(148,163,184,.16);border-radius:var(--ve-radius-pill);background:rgba(148,163,184,.07);color:#aab2bc;display:inline-flex;align-items:center;justify-content:center;flex:0 0 22px}
.ve-collection-source-pill svg,.ve-collection-source-pill i{font-size:12px}
.ve-tooltip-card{position:fixed;width:200px;max-width:calc(100vw - 24px);padding:10px;border:1px solid rgba(255,255,255,.10);border-radius:9px;background:rgba(24,24,24,.98);box-shadow:0 14px 32px rgba(0,0,0,.48);color:#d8d8d8;font-size:10px;line-height:1.45;pointer-events:none;z-index:160000;text-transform:none;letter-spacing:0;text-align:left}
.ve-tooltip-card strong{display:block;color:#fff;font-size:11px;margin-bottom:3px}.ve-tooltip-card em{display:block;color:#8f8f8f;font-style:normal}

.ve-studio-sidebar{padding-right:10px}.ve-studio-sidebar-scroll{flex:1;min-height:0;overflow:hidden;display:flex;flex-direction:column;gap:10px;padding:0 7px 0 0;margin-right:-4px}
.ve-studio-sidebar-actions{flex:0 0 auto;display:flex;flex-direction:column;gap:10px;padding-top:10px;border-top:1px solid rgba(255,255,255,.06);background:transparent}
.ve-media-studio .ve-studio-sidebar{position:relative;overflow:visible;min-width:320px;max-width:480px;flex:0 0 320px}
.ve-media-studio .ve-studio-nav{flex:1;min-height:0;display:flex;flex-direction:column}
.ve-sidebar-resizer{position:absolute;right:-5px;top:0;width:10px;height:100%;cursor:col-resize;z-index:22}.ve-sidebar-resizer:after{content:'';position:absolute;right:4px;top:14px;bottom:14px;width:1px;background:rgba(186,244,0,.24);opacity:0;transition:opacity .12s}.ve-sidebar-resizer:hover:after{opacity:1}
.ve-sidebar-blurred{filter:blur(3px);opacity:.36;pointer-events:none;transition:filter .14s ease,opacity .14s ease}
.ve-media-collections-head{flex:0 0 auto;background:transparent;padding-bottom:10px;margin-bottom:0}
.ve-media-collection-list{flex:1;min-height:0;overflow-y:auto;overflow-x:hidden;display:flex;flex-direction:column;gap:4px;padding:8px 4px 10px 0;border-top:1px solid rgba(255,255,255,.05);border-bottom:0}
.ve-collection-tools{display:grid;grid-template-columns:32px minmax(0,1fr) 32px;grid-template-areas:"search search shortcuts" "expand sort dynamic";gap:7px;align-items:center;margin-bottom:10px}
.ve-collection-tools .ve-studio-input{grid-area:search}
.ve-collection-tools .ve-collection-tool-btn{grid-area:expand}
.ve-collection-tools .ve-collection-shortcuts{grid-area:shortcuts}
.ve-collection-tools .ve-collection-dynamic{grid-area:dynamic}
.ve-collection-tools .ve-filter-menu{grid-area:sort;min-width:0;width:100%}
.ve-collection-tools .ve-studio-input{height:30px!important;min-height:30px!important;font-size:10.5px!important}
.ve-collection-tool-btn{height:32px;min-width:32px;width:32px;padding:0!important;aspect-ratio:1/1}
.ve-ix{display:inline-flex;align-items:center;justify-content:center;width:15px;height:15px;flex:0 0 15px;color:currentColor}.ve-ix path{vector-effect:non-scaling-stroke}
.ve-media-studio .ve-ix{width:15px;height:15px;filter:none}
.ve-filter-pop-wrap{position:relative;width:38px;min-width:38px}.ve-filter-pop-btn{width:38px!important;min-width:38px!important;height:38px!important;min-height:38px!important;padding:0!important;display:flex!important;align-items:center!important;justify-content:center!important}.ve-filter-pop-btn:after{display:none!important;content:none!important}.ve-filter-pop-btn.active{border-color:rgba(186,244,0,.42)!important;background:rgba(186,244,0,.10)!important;color:#baf400!important}.ve-filter-pop{position:absolute;right:0;top:calc(100% + 6px);z-index:44;width:286px;max-height:370px;overflow:auto;border:1px solid rgba(255,255,255,.10);border-radius:12px;background:#1d1d1d;box-shadow:0 18px 42px rgba(0,0,0,.54);padding:8px;display:flex;flex-direction:column;gap:7px}.ve-filter-pop-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:3px 2px 2px}.ve-filter-pop-head strong{font-size:12px;color:#fff;display:flex;align-items:center;gap:7px}.ve-filter-pop-help{font-size:10px;color:#8d8d8d;line-height:1.45;padding:0 2px}.ve-filter-search{height:32px!important;min-height:32px!important;padding:0 10px!important;background:#202020!important;border:1px solid rgba(255,255,255,.10)!important;border-radius:8px!important;color:#f2f2f2!important;font-size:11px!important;line-height:32px!important}.ve-filter-rulebar{display:flex;align-items:center;gap:6px;padding:2px 0}.ve-filter-rule-pill{height:24px;border:1px solid rgba(186,244,0,.24);border-radius:var(--ve-radius-pill);background:rgba(186,244,0,.08);color:#dfffa3;padding:0 8px;display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:750}.ve-filter-add{border:0;background:transparent;color:#aaa;font-size:10.5px;display:inline-flex;align-items:center;gap:5px;cursor:pointer}.ve-filter-add:hover{color:#baf400}.ve-filter-builder{display:grid;grid-template-columns:auto minmax(0,1fr) minmax(0,86px);gap:6px;align-items:center;padding:8px;border:1px solid rgba(255,255,255,.07);border-radius:10px;background:rgba(255,255,255,.025)}.ve-filter-builder span{font-size:11px;color:#cfcfcf}.ve-filter-builder code{height:28px;border:1px solid rgba(255,255,255,.08);border-radius:7px;background:#242424;color:#f1f1f1;padding:0 8px;display:flex;align-items:center;font:10px/1.2 'SF Mono','Fira Code',monospace;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-filter-choice{min-height:32px;border:1px solid rgba(255,255,255,.06);border-radius:7px;background:#242424;color:#ddd;display:grid;grid-template-columns:18px minmax(0,1fr) auto;gap:7px;align-items:center;padding:6px 8px;text-align:left;cursor:pointer}.ve-filter-choice:hover,.ve-filter-choice.active{border-color:rgba(186,244,0,.28);background:rgba(186,244,0,.075);color:#dfffa3}.ve-filter-choice em{font-style:normal;color:#8a8a8a;font-size:10px;background:rgba(255,255,255,.05);border-radius:var(--ve-radius-pill);padding:2px 6px}
.ve-upload-progress{display:flex;align-items:center;justify-content:center;gap:10px;max-width:360px;margin:0 auto;color:#dfe8d7;font-size:11px;font-weight:700}.ve-upload-progress em{font-style:normal;color:#858b92;font-weight:600;max-width:160px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-upload-bar{width:96px;height:5px;border-radius:var(--ve-radius-pill);background:rgba(255,255,255,.075);overflow:hidden}.ve-upload-bar span{display:block;height:100%;border-radius:inherit;background:#baf400;transition:width .18s ease}
.ve-media-progress-toast{position:fixed;right:28px;bottom:28px;z-index:120035;min-width:250px;max-width:min(360px,calc(100vw - 56px));display:flex;align-items:center;gap:10px;padding:10px 12px;border-radius:var(--ve-radius-md);background:rgba(22,23,22,.94);border:1px solid rgba(186,244,0,.18);box-shadow:0 18px 45px rgba(0,0,0,.38);color:#f3f6ee;font-size:11px;font-weight:750;pointer-events:none}.ve-media-progress-toast svg{color:#baf400;font-size:15px;flex:0 0 auto}.ve-media-progress-copy{display:flex;flex-direction:column;gap:4px;min-width:0;flex:1}.ve-media-progress-copy strong{font-size:11px;line-height:1.2}.ve-media-progress-copy em{font-style:normal;color:#879087;font-weight:650;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ve-media-progress-toast .ve-upload-bar{width:100%}
.ve-collection-inline-pop{position:absolute;left:12px;right:12px;bottom:118px;z-index:18;border:1px solid rgba(186,244,0,.20);border-radius:10px;background:rgba(24,24,24,.98);box-shadow:0 -16px 34px rgba(0,0,0,.48);padding:11px;display:flex;flex-direction:column;gap:9px}
.ve-collection-inline-pop .ve-icon-grid{max-height:168px}
.ve-icon-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(92px,1fr));gap:6px;max-height:168px;overflow:auto;padding:2px 2px 4px}
.ve-icon-pick{min-width:0;height:30px;border:1px solid rgba(255,255,255,.08);border-radius:7px;background:#242424;color:#d8d8d8;display:flex;align-items:center;gap:6px;padding:0 7px;text-align:left;cursor:pointer;overflow:hidden;font-size:10px;line-height:1.2}
.ve-icon-pick svg,.ve-icon-pick .ve-ms-icon{width:14px!important;height:14px!important;min-width:14px!important;color:#baf400;flex:0 0 14px}
.ve-icon-pick span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.ve-icon-pick:hover,.ve-icon-pick.active{border-color:rgba(186,244,0,.38);background:rgba(186,244,0,.08);color:#f5f5f5}
.ve-collection-modal .ve-menu,.ve-collection-modal .ve-filter-menu,.ve-collection-modal .ve-icon-select{width:100%!important;min-width:0!important;max-width:none!important}
.ve-collection-modal .ve-menu-btn,.ve-collection-modal .ve-filter-menu .ve-menu-btn,.ve-collection-modal .ve-icon-select .ve-menu-btn{width:100%!important;min-width:0!important}
.ve-collection-choice-list{max-height:230px;overflow:auto;display:flex;flex-direction:column;gap:5px;padding-right:3px}
.ve-collection-choice{min-height:32px;border:1px solid rgba(255,255,255,.07);border-radius:7px;background:#222;color:#ddd;display:grid;grid-template-columns:18px minmax(0,1fr) auto;align-items:center;gap:7px;padding:6px 8px;text-align:left;cursor:pointer}
.ve-collection-choice:hover{border-color:rgba(186,244,0,.32);background:rgba(186,244,0,.06);color:#f4f4f4}.ve-collection-choice em{font-style:normal;color:#777;font-size:10px}.ve-batch-new-collection{margin-top:10px;padding-top:10px;border-top:1px solid rgba(255,255,255,.07)}
.ve-batch-new-collection-grid{display:grid;grid-template-columns:1fr;gap:7px}.ve-batch-new-collection-grid .ve-menu{width:100%;min-width:0}.ve-batch-new-collection-actions{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:7px}
.ve-media-main-head{display:flex!important;align-items:center!important;justify-content:space-between!important;gap:12px!important;margin-bottom:12px!important;flex-wrap:wrap!important}.ve-media-toolbar{display:flex!important;align-items:center!important;gap:8px!important;flex-wrap:nowrap!important;margin-left:auto!important}.ve-media-toolbar .ve-studio-input{width:clamp(160px,18vw,240px)!important}.ve-media-toolbar .ve-filter-bar{display:flex!important;align-items:center!important;gap:8px!important;flex-wrap:nowrap!important}.ve-media-toolbar .ve-menu,.ve-media-toolbar .ve-menu-btn,.ve-media-toolbar .ve-btn{height:38px!important;min-height:38px!important}.ve-media-toolbar .ve-view-pop-wrap{flex:0 0 auto}.ve-font-file-card,.ve-file-card{width:100%;height:100%;min-height:100%;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:8px;padding:12px;box-sizing:border-box;color:#e7e7e7;text-align:center;overflow:hidden}.ve-font-file-card span{font-size:34px;line-height:1;font-family:Georgia,'Times New Roman',serif;color:#f7f7f7;letter-spacing:-.03em}.ve-font-file-card em,.ve-file-card span{font-size:10px;line-height:1.2;color:#8f9aa3;font-style:normal;text-transform:uppercase;letter-spacing:.06em}.ve-file-card .ve-ms-icon,.ve-file-card svg{width:30px!important;height:30px!important;color:#baf400}.ve-media-masonry .ve-font-file-card,.ve-media-masonry .ve-file-card{height:132px!important;min-height:132px!important}@media (max-width:980px){.ve-media-toolbar{width:100%;justify-content:flex-start!important;flex-wrap:wrap!important;margin-left:0!important}.ve-media-toolbar .ve-studio-input{flex:1 1 180px!important;min-width:180px!important}}
.ve-media-grid{flex:1;min-height:0;overflow:auto;display:grid;grid-template-columns:repeat(auto-fill,minmax(124px,1fr));grid-auto-rows:124px;gap:12px;align-content:start;justify-content:start;padding:0 10px 10px 0}
.ve-media-masonry{flex:1;min-height:0;max-height:100%;overflow:auto;display:block;column-count:var(--ve-masonry-columns,5);column-gap:12px;align-content:start;padding:0 10px 10px 0}
.ve-media-masonry .ve-media-thumb{width:100%!important;display:inline-block!important;break-inside:avoid;page-break-inside:avoid;margin:0 0 12px 0;min-height:96px!important;height:auto!important;aspect-ratio:auto!important;overflow:hidden;vertical-align:top}
.ve-media-masonry .ve-checker-bg{width:100%!important;height:auto!important;min-height:0!important;display:block!important;overflow:visible!important}
.ve-media-masonry .ve-checker-bg img{width:100%!important;height:auto!important;max-width:100%!important;max-height:none!important;display:block!important;object-fit:contain!important}
.ve-media-masonry .ve-font-file-card,.ve-media-masonry .ve-file-card{height:132px;min-height:132px}
.ve-media-studio .ve-ms-icon{display:inline-block;width:15px;height:15px;min-width:15px;min-height:15px;fill:currentColor;stroke:none;color:currentColor;line-height:1;vertical-align:-2px;pointer-events:none}.ve-media-studio .ve-ms-icon .ve-ms-icon-tone{opacity:.25}.ve-media-studio .ve-ms-icon .ve-ms-icon-main{opacity:.92}
.ve-view-pop-wrap{position:relative;display:inline-flex;padding-bottom:8px;margin-bottom:-8px}.ve-view-pop-wrap .ve-view-pop{position:absolute;right:0;top:100%;z-index:45;display:flex;flex-direction:column;gap:6px;padding:6px;border:1px solid rgba(255,255,255,.10);border-radius:10px;background:#1d1d1d;box-shadow:0 16px 34px rgba(0,0,0,.48);opacity:0;visibility:hidden;pointer-events:none;transform:translateY(-3px);transition:opacity .12s,transform .12s,visibility .12s}.ve-view-pop-wrap:hover .ve-view-pop,.ve-view-pop-wrap:focus-within .ve-view-pop,.ve-view-pop-wrap.open .ve-view-pop{opacity:1;visibility:visible;pointer-events:auto;transform:translateY(0)}.ve-view-choice{width:34px;height:32px;border:1px solid rgba(255,255,255,.09);border-radius:8px;background:#262626;color:#ccc;display:flex;align-items:center;justify-content:center;cursor:pointer}.ve-view-choice:hover,.ve-view-choice.active{border-color:rgba(186,244,0,.36);background:rgba(186,244,0,.08);color:#baf400}
.ve-media-thumb{position:relative;overflow:hidden;border-radius:9px;background:#101010;cursor:pointer;box-shadow:inset 0 1px 0 rgba(255,255,255,.035);transition:border-color .14s,background .14s,transform .14s}
.ve-media-thumb:hover{border-color:rgba(186,244,0,.42)!important}
.ve-media-thumb.selected,.ve-media-thumb.checked{background:rgba(186,244,0,.045);box-shadow:inset 0 0 0 1px rgba(186,244,0,.36)}
.ve-media-select{position:absolute!important;top:8px!important;left:8px!important;right:auto!important;bottom:auto!important;z-index:5!important;width:18px!important;height:18px!important;display:block!important;margin:0!important;padding:0!important;line-height:0!important}.ve-media-select .ve-check-row{position:absolute!important;inset:0!important;width:18px!important;height:18px!important;min-width:18px!important;min-height:18px!important;max-width:18px!important;max-height:18px!important;display:block!important;margin:0!important;padding:0!important;line-height:0!important}.ve-media-select .ve-check-box{position:absolute!important;left:0!important;top:0!important;width:16px!important;height:16px!important;min-width:16px!important;min-height:16px!important;max-width:16px!important;max-height:16px!important;display:block!important;margin:0!important;transform:none!important;background-color:rgba(20,20,20,.88);backdrop-filter:blur(6px);background-position:center!important;background-size:11px 11px!important}.ve-media-select .ve-check-row input:checked + .ve-check-box{background-color:#baf400!important}
.ve-media-meta-hover{position:absolute;left:7px;right:7px;bottom:7px;padding:6px 7px;border:1px solid rgba(255,255,255,.08);border-radius:7px;background:rgba(12,12,12,.76);backdrop-filter:blur(10px);opacity:0;transform:translateY(5px);transition:opacity .12s,transform .12s;color:#eee;font-size:10px;line-height:1.35;pointer-events:none}
.ve-media-thumb:hover .ve-media-meta-hover{opacity:1;transform:translateY(0)}
.ve-media-list-preview{width:54px;height:42px;border-radius:6px;overflow:hidden;background:#101010}
.ve-media-detail-preview{height:190px;min-height:190px;border:1px solid rgba(255,255,255,.08);border-radius:9px;background:#101010;overflow:auto;display:flex;align-items:center;justify-content:center;scrollbar-width:thin;scrollbar-color:rgba(186,244,0,.48) rgba(255,255,255,.035)}.ve-media-detail-preview.ve-preview-mode-fit-width,.ve-media-detail-preview.ve-preview-mode-actual,.ve-media-detail-preview.ve-preview-mode-zoom{height:300px;min-height:300px;display:block!important;align-items:flex-start!important;justify-content:flex-start!important;overflow:auto!important;overscroll-behavior:contain;scrollbar-gutter:stable both-edges}.ve-media-detail-preview.ve-preview-mode-zoom{cursor:grab}.ve-media-detail-preview.ve-preview-mode-zoom.panning{cursor:grabbing;user-select:none}.ve-media-detail-preview.ve-preview-mode-zoom .ve-checker-bg,.ve-media-detail-preview.ve-preview-mode-actual .ve-checker-bg,.ve-media-detail-preview.ve-preview-mode-fit-width .ve-checker-bg{width:100%!important;max-width:none!important;height:auto!important;min-width:100%!important;min-height:0!important;display:block!important;overflow:visible!important}.ve-media-detail-preview.ve-preview-mode-fit-width .ve-checker-bg{width:100%!important;max-width:100%!important}.ve-media-detail-preview.ve-preview-mode-zoom img,.ve-media-detail-preview.ve-preview-mode-actual img,.ve-media-detail-preview.ve-preview-mode-fit-width img{display:block!important;max-height:none!important}.ve-preview-fallback{display:none;width:100%;height:100%;min-height:96px;align-items:center;justify-content:center;flex-direction:column;gap:7px;color:#aaa;text-align:center;padding:14px;box-sizing:border-box}.ve-preview-fallback .ve-ms-icon{width:28px!important;height:28px!important;color:#baf400}.ve-preview-fallback span{font-size:11px;font-weight:750;color:#ddd}.ve-preview-fallback em{font-style:normal;font-size:10px;color:#777;text-transform:uppercase;letter-spacing:.06em}.ve-checker-bg.ve-preview-failed img{display:none!important}.ve-checker-bg.ve-preview-failed .ve-preview-fallback,.ve-checker-bg.ve-preview-missing .ve-preview-fallback{display:flex!important}
.ve-native-media-page{position:relative!important;inset:auto!important;z-index:2;margin:18px 20px 26px 18px;box-sizing:border-box;background:transparent;overflow:visible;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;transform:none!important}.ve-native-media-page .ve-native-media-page-shell{width:100%;min-height:calc(100vh - 128px);height:calc(100vh - 128px);display:flex;flex-direction:column;border:1px solid rgba(255,255,255,.09);border-radius:12px;background:#151515;overflow:hidden}.ve-native-media-page .ve-native-media-page-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:12px 14px;border-bottom:1px solid rgba(255,255,255,.07);font-weight:800;color:#fff}.ve-native-media-page .ve-studio-layout{height:auto;flex:1;min-height:0;border:0;border-radius:0}.ve-native-media-page-active.upload-php #wpbody-content{float:none!important;padding-top:0!important;padding-bottom:0!important;margin-top:0!important;min-height:0!important}.ve-native-media-page-active.upload-php #wpbody-content>:not(#ve-panel-root):not(#screen-meta):not(#screen-meta-links){display:none!important}.ve-native-media-page-active.upload-php #wpfooter{display:none!important}.ve-native-media-page-active.upload-php #wpbody-content>#ve-panel-root{display:block!important;position:relative!important;inset:auto!important;z-index:1;clear:both!important;width:100%!important;height:auto!important;max-width:none!important;max-height:none!important;margin:0!important;padding:0!important;pointer-events:auto!important;transform:none!important;background:transparent!important;box-shadow:none!important}.ve-native-media-page-active .ve-native-media-page{display:block!important}.ve-native-media-page-active .ve-fab-wrap{position:fixed!important;z-index:120020!important}.ve-native-media-page-active .ve-bd.show{display:block!important}
.ve-native-media-page-close{width:28px;height:28px;border:1px solid rgba(255,255,255,.10);border-radius:7px;background:rgba(255,255,255,.035);color:#aaa;display:inline-flex;align-items:center;justify-content:center;cursor:pointer}.ve-native-media-page-close:hover{border-color:rgba(186,244,0,.34);color:#baf400;background:rgba(186,244,0,.07)}
.ve-media-batch-overlay{position:sticky!important;left:auto!important;right:auto!important;bottom:12px!important;transform:none!important;width:auto!important;margin:12px 0 0!important;z-index:60!important;border-radius:7px!important}
.ve-media-settings-paused{opacity:.82}.ve-badge.muted{display:inline-flex;align-items:center;height:20px;padding:0 8px;border-radius:999px;background:rgba(255,255,255,.07);color:#aaa;border:1px solid rgba(255,255,255,.08);font-size:10px;font-weight:850;text-transform:uppercase;letter-spacing:.04em}
.ve-help-shell{padding:14px;flex:1;overflow-y:auto;display:flex;flex-direction:column;min-height:0;gap:10px}.ve-help-hero{padding:12px;border:1px solid rgba(186,244,0,.16);border-radius:10px;background:#202020}.ve-help-kicker{font-size:10px;font-weight:900;color:#baf400;letter-spacing:.4px;text-transform:uppercase;margin-bottom:5px}.ve-help-title{font-size:17px;font-weight:900;color:#fff;line-height:1.15;margin-bottom:5px}.ve-help-desc{margin:0;color:#9b9b9b;font-size:11px;line-height:1.55}.ve-help-card{padding:10px;border:1px solid rgba(255,255,255,.075);border-radius:9px;background:#1d1d1d}.ve-help-card-title{display:flex;align-items:center;gap:7px;margin-bottom:8px;color:#fff;font-size:11px;font-weight:850;letter-spacing:.25px}.ve-help-card-title em{font-style:normal;color:#baf400;font-size:10px;font-weight:900}.ve-help-row{display:grid;grid-template-columns:1fr;gap:4px;padding:7px 0;border-top:1px solid rgba(255,255,255,.05)}.ve-help-row:first-of-type{border-top:0}.ve-help-row code{display:block;width:100%;box-sizing:border-box;color:#dfff6b;background:rgba(186,244,0,.07);border:1px solid rgba(186,244,0,.16);border-radius:5px;padding:5px 6px;font:10.5px/1.35 'SF Mono','Fira Code',monospace;white-space:normal;overflow-wrap:anywhere}.ve-help-row span{color:#ababab;font-size:10.8px;line-height:1.45}.ve-help-note{margin:7px 0 0;color:rgba(186,244,0,.74);font-size:10.5px;line-height:1.45}.ve-help-footer{display:flex;justify-content:flex-end;margin-top:auto;border-top:1px solid rgba(255,255,255,.07);padding-top:10px}
.ve-preview-mode-row{display:flex;gap:5px;margin-top:6px;flex-wrap:wrap}.ve-preview-mode-row button{height:24px;min-height:24px;padding:0 8px;border:1px solid rgba(255,255,255,.09);border-radius:7px;background:#242424;color:#aaa;font-size:10px;font-weight:750;cursor:pointer}.ve-preview-mode-row button.active{border-color:rgba(186,244,0,.42);background:rgba(186,244,0,.10);color:#baf400}.ve-preview-zoom-row{display:flex;align-items:center;gap:8px;margin-top:6px;color:#aaa;font-size:10px}.ve-preview-zoom-row input{flex:1;accent-color:#baf400}
.ve-dropzone{transition:border-color .15s,background .15s,color .15s}.ve-studio-main.drag-over,.ve-dropzone.drag-over{border-color:rgba(186,244,0,.46)!important;background:rgba(186,244,0,.045)!important;color:#dfffa3!important}
body.ve-media-studio-open .uploader-window,body.ve-media-studio-open [class*="uploader-window"],body.ve-internal-drag-active .uploader-window,body.ve-internal-drag-active [class*="uploader-window"],body.ve-internal-media-drag .uploader-window,body.ve-internal-media-drag [class*="uploader-window"],body.ve-internal-collection-drag .uploader-window,body.ve-internal-collection-drag [class*="uploader-window"]{display:none!important;visibility:hidden!important;opacity:0!important;pointer-events:none!important;z-index:-1!important}
.ve-url-import-row{display:flex;align-items:center;gap:6px;margin:0;justify-content:flex-start}.ve-url-import-row--toolbar{flex:0 1 330px}.ve-url-import-input.ve-studio-input{width:210px;max-width:210px;height:34px;padding:0 12px;background:rgba(255,255,255,.045)!important;border:1px solid rgba(255,255,255,.10)!important;border-radius:8px!important;color:#d7d7d7!important;font-size:11px!important;font-weight:600!important;box-shadow:none!important;outline:none!important;transition:border-color .15s,background .15s}.ve-url-import-input.ve-studio-input:focus{border-color:rgba(186,244,0,.45)!important;background:rgba(255,255,255,.065)!important;color:#f1f1f1!important}.ve-url-import-input.ve-studio-input::placeholder{color:#6f6f6f!important;font-weight:500}.ve-url-import-btn.ve-btn{height:34px;min-height:34px;padding:0 12px;display:inline-flex;align-items:center;gap:6px;white-space:nowrap}.ve-url-import-btn.ve-btn i{font-size:14px!important}.ve-url-import-btn.ve-btn:disabled{opacity:.55;cursor:not-allowed}.ve-media-toolbar{flex-wrap:wrap}.ve-media-toolbar .ve-filter-bar{flex-wrap:wrap}@media(max-width:1100px){.ve-url-import-row--toolbar{order:3;flex-basis:100%;}.ve-url-import-input.ve-studio-input{width:min(320px,100%);max-width:100%}}.ve-url-preview-grid{display:grid;gap:8px;margin-top:10px}.ve-url-preview-row{display:grid;grid-template-columns:92px minmax(0,1fr);gap:9px;align-items:start;min-height:28px;padding:7px 8px;border:1px solid rgba(255,255,255,.07);border-radius:7px;background:rgba(255,255,255,.025);font-size:11px}.ve-url-preview-row strong{color:#777;text-transform:uppercase;font-size:9.5px;letter-spacing:.05em}.ve-url-preview-row span{color:#ddd;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-url-preview-warning{margin-top:9px;padding:9px 10px;border-radius:7px;border:1px solid rgba(245,158,11,.22);background:rgba(245,158,11,.08);color:#ffd58a;font-size:11px;line-height:1.45}.ve-url-preview-error{margin-top:9px;padding:9px 10px;border-radius:7px;border:1px solid rgba(239,68,68,.24);background:rgba(239,68,68,.08);color:#ffb4b4;font-size:11px;line-height:1.45}
.ve-drop-overlay{position:absolute;inset:0;z-index:80;background:rgba(10,10,10,.72);backdrop-filter:blur(10px);display:flex;align-items:center;justify-content:center;color:#dfffa3;pointer-events:auto}.ve-drop-overlay>div{padding:22px 28px;border:1px dashed rgba(186,244,0,.55);border-radius:12px;background:rgba(20,20,20,.92);box-shadow:0 22px 60px rgba(0,0,0,.48);display:flex;flex-direction:column;align-items:center;gap:8px}.ve-drop-overlay i{font-size:28px!important;color:#baf400}.ve-drop-overlay strong{font-size:20px;letter-spacing:-.02em}
.ve-chip-list{display:flex;align-items:flex-start;gap:7px;flex-wrap:wrap}
.ve-chip-action-row{margin-top:7px}
.ve-chip-row{position:relative;min-height:28px;max-width:100%;border:1px solid rgba(255,255,255,.08);border-radius:var(--ve-radius-pill);background:#242424;color:#ddd;display:inline-flex;align-items:center;justify-content:space-between;gap:8px;padding:5px 10px;overflow:visible}
.ve-chip-row:hover{border-color:rgba(186,244,0,.22);background:rgba(186,244,0,.055)}.ve-chip-row .ve-chip-remove{position:absolute;right:-6px;top:-7px;width:20px;height:20px;border:1px solid rgba(239,68,68,.55);background:#ef4444;color:#fff;border-radius:7px;display:flex;align-items:center;justify-content:center;opacity:0;transform:scale(.86);transition:opacity .12s,transform .12s}.ve-chip-row:hover .ve-chip-remove{opacity:1;transform:scale(1)}
.ve-media-actions-card{display:flex;flex-direction:column;gap:10px}.ve-replace-wide{width:100%;justify-content:center}.ve-convert-card{display:grid;grid-template-columns:104px max-content;column-gap:7px;row-gap:6px;align-items:end;justify-content:start}.ve-convert-card-title{grid-column:1/-1;font-size:10px;color:#777;text-transform:uppercase;font-weight:800;letter-spacing:.04em}.ve-convert-card .ve-menu{min-width:0;width:104px}.ve-convert-card .ve-btn{width:auto;min-width:122px}
.ve-media-batch-overlay{position:absolute;left:20px;right:20px;bottom:18px;z-index:12;border:1px solid rgba(255,255,255,.10);border-radius:8px;background:rgba(24,24,24,.96);box-shadow:0 -12px 30px rgba(0,0,0,.46);backdrop-filter:blur(14px);padding:10px;display:grid;grid-template-columns:auto minmax(0,1fr) auto;gap:10px;align-items:center}
.ve-media-selected-strip{display:flex;gap:6px;min-width:0;overflow:hidden}.ve-media-selected-mini{width:34px;height:34px;border-radius:7px;overflow:hidden;border:1px solid rgba(255,255,255,.08);background:#111;flex:0 0 34px}.ve-media-selected-more{height:34px;border-radius:7px;background:rgba(255,255,255,.06);color:#aaa;padding:0 8px;display:flex;align-items:center;font-size:10px}
.ve-media-usage-card{border:1px solid rgba(255,255,255,.08);border-radius:var(--ve-radius-md);background:rgba(255,255,255,.025);padding:10px;display:flex;flex-direction:column;gap:8px}.ve-media-usage-head{display:flex;align-items:center;justify-content:space-between;gap:8px}.ve-media-usage-title{display:flex;align-items:center;gap:7px;color:#f1f1f1;font-size:11px;font-weight:800}.ve-media-usage-count{border:1px solid rgba(186,244,0,.25);background:rgba(186,244,0,.10);color:#baf400;border-radius:var(--ve-radius-pill);padding:3px 7px;font-size:10px;font-weight:800}.ve-media-usage-list{display:flex;flex-direction:column;gap:6px;max-height:150px;overflow:auto}.ve-media-usage-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center;padding:7px 8px;border-radius:var(--ve-radius-sm);background:rgba(255,255,255,.025);border:1px solid rgba(255,255,255,.055);color:#d8d8d8;text-decoration:none}.ve-media-usage-row:hover{background:rgba(186,244,0,.055);border-color:rgba(186,244,0,.18)}.ve-media-usage-row span{min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px;font-weight:800}.ve-media-usage-row em{font-style:normal;color:#777;font-size:10px;text-align:right}.ve-media-usage-empty{font-size:11px;color:#888;line-height:1.45}
.ve-media-batch-actions{display:flex;gap:7px;align-items:center;justify-content:flex-end}.ve-media-batch-actions .ve-filter-menu{width:104px;min-width:104px}.ve-danger-outline{border-color:rgba(239,68,68,.55)!important;color:#ff6b6b!important;background:rgba(239,68,68,.10)!important}.ve-danger-outline:hover{border-color:#ef4444!important;background:rgba(239,68,68,.16)!important;color:#fff!important}
.ve-media-drag-ghost{position:fixed;top:-1000px;left:-1000px;z-index:160000;pointer-events:none;padding:7px 9px;border:1px solid rgba(186,244,0,.32);border-radius:12px;background:rgba(20,20,20,.96);box-shadow:0 14px 30px rgba(0,0,0,.48);color:#dfffa3;font-size:11px;font-weight:800;display:flex;align-items:center;gap:8px}.ve-media-drag-stack{position:relative;width:54px;height:38px}.ve-media-drag-mini{position:absolute;width:32px;height:32px;border-radius:7px;overflow:hidden;border:1px solid rgba(255,255,255,.13);background:#111}.ve-media-drag-mini:nth-child(1){left:0;top:4px}.ve-media-drag-mini:nth-child(2){left:11px;top:1px}.ve-media-drag-mini:nth-child(3){left:22px;top:6px}.ve-media-drag-count{min-width:24px;height:24px;border-radius:999px;background:#baf400;color:#151515;display:inline-flex;align-items:center;justify-content:center;font-weight:900}
.ve-media-command{position:absolute;inset:18px;z-index:42;border:1px solid rgba(186,244,0,.22);border-radius:14px;background:rgba(22,22,22,.98);box-shadow:0 26px 70px rgba(0,0,0,.62);display:flex;flex-direction:column;overflow:hidden}.ve-media-command-head{padding:12px;border-bottom:1px solid rgba(255,255,255,.08);display:flex;gap:8px;align-items:center}.ve-media-command-body{padding:16px;overflow:auto}.ve-shortcut-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:12px;align-items:center;min-height:34px;border-bottom:1px solid rgba(255,255,255,.055);font-size:12px;color:#ddd}.ve-keycap{min-width:28px;height:24px;border:1px solid rgba(255,255,255,.10);border-radius:6px;background:#303236;display:inline-flex;align-items:center;justify-content:center;color:#e8e8e8;font-size:10px;font-weight:800;margin-left:5px}
.ve-dynamic-folders{border:1px solid rgba(255,255,255,.07);border-radius:9px;background:rgba(255,255,255,.02);padding:8px;display:flex;flex-direction:column;gap:6px;margin-bottom:12px}.ve-dynamic-folder-group{width:100%;border:0;background:transparent;font-size:11px;color:#d7d7d7;display:flex;align-items:center;gap:6px;padding:5px 6px;border-radius:6px;cursor:pointer;text-align:left}.ve-dynamic-folder-group:hover{background:rgba(255,255,255,.04);color:#fff}.ve-dynamic-folder-child{border:0;background:transparent;text-align:left;padding:4px 6px 4px 22px;color:#9a9a9a;border-radius:6px;cursor:pointer;font-size:11px}.ve-dynamic-folder-child:hover,.ve-dynamic-folder-child.active{background:rgba(186,244,0,.08);color:#dfffa3}
.ve-plugin-card-main{display:flex;flex-direction:column;gap:4px;min-width:0}
.ve-plugin-card-main strong{color:#f7f7f7;font-size:var(--ve-font-md);line-height:1.35}
.ve-plugin-card-main span{color:#c8c8c8;font-size:11.5px;line-height:1.55}
.ve-plugin-card-main small{color:#9a9a9a;font-size:var(--ve-font-xs);line-height:1.45}
.ve-plugin-table td{color:#d8d8d8}
.ve-plugin-description{color:#c8c8c8!important;font-size:11.5px!important;line-height:1.55!important;max-width:760px}
.ve-plugin-author{color:#9b9b9b!important;font-size:10.5px!important;line-height:1.45!important}
.ve-plugin-table strong{font-size:12.5px;line-height:1.35}
.ve-content-studio .ve-studio-sidebar{resize:horizontal;overflow:auto;min-width:220px;max-width:420px}
.ve-standalone-panel[data-panel="content_studio"]{resize:both;min-width:920px;min-height:540px}
.ve-status-toggle{background:transparent;border:0;padding:0;margin:0;cursor:pointer}
.ve-studio-table-container { flex: 1; overflow: auto; min-height:0; margin-top:10px; }
.ve-studio-table-container::-webkit-scrollbar { width:6px;height:6px; }
.ve-studio-table-container::-webkit-scrollbar-track { background:rgba(255,255,255,.035);border-radius:var(--ve-radius-pill); }
.ve-studio-table-container::-webkit-scrollbar-thumb { background:rgba(186,244,0,.52); border-radius:var(--ve-radius-pill);border:1px solid rgba(0,0,0,.22); }
.ve-studio-table { width:100%; border-collapse: collapse; text-align: left; font-size:var(--ve-font-sm); }
.ve-media-list-scroller{overflow:auto!important;max-width:100%;min-width:0}.ve-media-list-table{table-layout:fixed;width:max-content!important;min-width:100%}.ve-media-list-table th,.ve-media-list-table td{box-sizing:border-box}.ve-media-list-table .ve-list-name{width:210px;min-width:210px;max-width:210px}.ve-media-list-table .ve-list-alt{width:260px;min-width:260px;max-width:260px}.ve-media-list-table .ve-list-meta{width:132px;min-width:132px;max-width:132px}.ve-media-list-table .ve-list-actions{width:96px;min-width:96px;max-width:96px}.ve-list-meta-pop-wrap{position:relative;display:inline-flex}.ve-list-meta-pop{position:absolute;right:0;top:calc(100% + 6px);z-index:44;width:236px;max-height:320px;overflow:auto;border:1px solid rgba(255,255,255,.10);border-radius:12px;background:#1d1d1d;padding:8px;display:flex;flex-direction:column;gap:6px}.ve-list-meta-pop-head{display:flex;align-items:center;justify-content:space-between;gap:8px;padding:2px 2px 5px;border-bottom:1px solid rgba(255,255,255,.06);font-size:11px;color:#f1f1f1;font-weight:750}.ve-list-meta-row{display:flex;align-items:center;gap:8px;min-height:28px;padding:3px 4px;color:#ddd;font-size:11px}.ve-list-meta-row:hover{background:rgba(255,255,255,.04);border-radius:7px}
.ve-studio-table th { padding:10px; font-size:var(--ve-font-xs); font-weight: 700; text-transform: uppercase; color: #555; letter-spacing:0.8px; border-bottom:1px solid rgba(255,255,255,0.08); }
.ve-studio-table td { padding:12px 10px; border-bottom:1px solid rgba(255,255,255,0.04); color: #ddd; vertical-align: middle; }
.ve-studio-table tr:hover { background: rgba(255,255,255,0.02); }
.ve-studio-details-sidebar { width:320px; background: rgba(0,0,0,0.18); border-left:1px solid rgba(255,255,255,0.06); padding:0 16px 16px; display: flex; flex-direction: column; gap:16px; flex-shrink: 0; overflow-y: auto; }
.ve-details-head{position:sticky;top:0;z-index:8;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid rgba(255,255,255,0.06);padding:16px 0 12px;background:linear-gradient(180deg,#151515 0%,#151515 88%,rgba(21,21,21,.88))}
.ve-o .ve-studio-input,.ve-modal .ve-studio-input,.ve-media-studio .ve-studio-input,.ve-content-studio .ve-studio-input,.ve-plugin-studio .ve-studio-input,.ve-cf-b .ve-studio-input { width:100%; padding:8px 12px; background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius:var(--ve-radius-md); color: #fff; font-size:var(--ve-font-sm); outline: none; transition: border-color .15s, background .15s; }
.ve-o input.ve-studio-input,.ve-modal input.ve-studio-input,.ve-media-studio input.ve-studio-input,.ve-content-studio input.ve-studio-input,.ve-plugin-studio input.ve-studio-input,.ve-cf-b input.ve-studio-input,.ve-o select.ve-studio-input,.ve-modal select.ve-studio-input,.ve-media-studio select.ve-studio-input,.ve-content-studio select.ve-studio-input,.ve-plugin-studio select.ve-studio-input,.ve-cf-b select.ve-studio-input{height:var(--ve-control-height)!important;min-height:var(--ve-control-height)!important;max-height:var(--ve-control-height)!important;padding:0 12px;line-height:var(--ve-control-height)!important}
.ve-o .ve-studio-input:focus,.ve-modal .ve-studio-input:focus,.ve-media-studio .ve-studio-input:focus,.ve-content-studio .ve-studio-input:focus,.ve-plugin-studio .ve-studio-input:focus,.ve-cf-b .ve-studio-input:focus { outline:none!important; border-color: #baf400; background: rgba(255,255,255,0.05); box-shadow:none; }
.ve-o .ve-studio-textarea,.ve-modal .ve-studio-textarea,.ve-media-studio .ve-studio-textarea,.ve-content-studio .ve-studio-textarea,.ve-plugin-studio .ve-studio-textarea,.ve-cf-b .ve-studio-textarea { min-height:80px; resize: vertical; }
.ve-o select.ve-studio-input option,.ve-modal select.ve-studio-input option,.ve-media-studio select.ve-studio-input option,.ve-content-studio select.ve-studio-input option,.ve-plugin-studio select.ve-studio-input option,.ve-cf-b select.ve-studio-input option { background: #151515; color: #fff; }
/* Foreign-editor (e.g. Code2Bricks) background bleed is handled at the source by neutralizing
   MV's globally enqueued CodeMirror defaults in the PHP adapters (wp_add_inline_style on
   ve-codemirror). MV's own editors are skinned via the .ve-cm-host rules above. */
.ve-o :is(input,textarea,button,select,a):focus{outline:none!important}
.ve-o :is(input,textarea,button,select,a):focus-visible{outline:none!important;box-shadow:none!important;border-color:#baf400!important}
.ve-studio-batch-overlay { position: absolute; bottom:20px; left:50%; transform: translateX(-50%); background: #1b1b1b; border: 1px solid rgba(255, 255, 255, 0.08); border-radius:var(--ve-radius-lg); padding:10px 20px; display: flex; align-items: center; gap:16px; box-shadow: 0 16px 36px rgba(0,0,0,0.45); z-index: 10; backdrop-filter: blur(10px); }
.ve-var-check,#ve-panel-root .ve-o input[type=checkbox],#ve-panel-root .ve-modal input[type=checkbox]{-webkit-appearance:none!important;appearance:none!important;position:relative!important;box-sizing:border-box!important;width:15px!important;height:15px!important;min-width:15px!important;min-height:15px!important;max-width:15px!important;max-height:15px!important;margin:0!important;padding:0!important;border:1px solid rgba(255,255,255,.20)!important;border-radius:var(--ve-radius-sm)!important;background-color:#202020!important;background-image:none!important;background-repeat:no-repeat!important;background-position:center!important;background-size:11px 11px!important;box-shadow:inset 0 1px 2px rgba(0,0,0,.38)!important;display:inline-block!important;line-height:0!important;cursor:pointer!important;flex:0 0 15px!important;transition:background-color .12s ease,border-color .12s ease,box-shadow .12s ease;vertical-align:middle!important}
.ve-var-check:before,#ve-panel-root .ve-o input[type=checkbox]:before,#ve-panel-root .ve-modal input[type=checkbox]:before{content:none!important;display:none!important}
.ve-var-check:checked,#ve-panel-root .ve-o input[type=checkbox]:checked,#ve-panel-root .ve-modal input[type=checkbox]:checked{border-color:#baf400!important;background-color:#baf400!important;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath d='M2.2 6.2 4.8 8.8 9.8 3.2' fill='none' stroke='%23151515' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E")!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.30)!important}
.ve-var-check:checked:before,#ve-panel-root .ve-o input[type=checkbox]:checked:before,#ve-panel-root .ve-modal input[type=checkbox]:checked:before{content:none!important;display:none!important}
.ve-var-check:hover,#ve-panel-root .ve-o input[type=checkbox]:hover,#ve-panel-root .ve-modal input[type=checkbox]:hover{border-color:rgba(186,244,0,.60)!important}
.ve-var-check:focus-visible,#ve-panel-root .ve-o input[type=checkbox]:focus-visible,#ve-panel-root .ve-modal input[type=checkbox]:focus-visible{border-color:#baf400!important;box-shadow:none!important}
#ve-panel-root .ve-o input[type=radio],#ve-panel-root .ve-modal input[type=radio]{-webkit-appearance:none!important;appearance:none!important;position:relative!important;width:15px!important;height:15px!important;min-width:15px!important;min-height:15px!important;margin:0!important;padding:0!important;border:1px solid rgba(255,255,255,.20)!important;border-radius:var(--ve-radius-pill)!important;background:#202020!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;flex:0 0 15px!important;box-shadow:inset 0 1px 2px rgba(0,0,0,.38)!important;cursor:pointer!important}
#ve-panel-root .ve-o input[type=radio]:before,#ve-panel-root .ve-modal input[type=radio]:before{content:''!important;position:absolute!important;left:50%!important;top:50%!important;width:6px!important;height:6px!important;border-radius:var(--ve-radius-pill)!important;background:#151515!important;transform:translate(-50%,-50%) scale(0)!important;transition:transform .1s ease!important}
#ve-panel-root .ve-o input[type=radio]:checked,#ve-panel-root .ve-modal input[type=radio]:checked{border-color:#baf400!important;background:#baf400!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.30)!important}
#ve-panel-root .ve-o input[type=radio]:checked:before,#ve-panel-root .ve-modal input[type=radio]:checked:before{transform:translate(-50%,-50%) scale(1)!important}
.ve-check-row{position:relative;display:inline-flex;align-items:center;gap:6px;min-height:20px;cursor:pointer;color:#aaa;font-size:10px;line-height:1.2;user-select:none}.ve-check-row input[type=checkbox]{position:absolute!important;left:0!important;top:0!important;opacity:0!important;pointer-events:none!important;width:1px!important;height:1px!important;min-width:1px!important;min-height:1px!important;max-width:1px!important;max-height:1px!important;margin:0!important;padding:0!important}.ve-check-box{box-sizing:border-box;width:15px;height:15px;border:1px solid rgba(255,255,255,.16);border-radius:4px;background-color:#232323;background-image:none;background-repeat:no-repeat;background-position:center;background-size:11px 11px;display:block;flex:0 0 15px;color:#151515;transition:background-color .12s,border-color .12s}.ve-check-box svg,.ve-check-box i{display:none!important}.ve-check-box:after{content:none!important;display:none!important}.ve-check-row input:checked + .ve-check-box{background-color:#baf400;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath d='M2.2 6.2 4.8 8.8 9.8 3.2' fill='none' stroke='%23151515' stroke-width='2' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");border-color:#baf400;box-shadow:none}.ve-check-row input:checked + .ve-check-box:after{content:none!important;display:none!important}.ve-check-row.disabled{opacity:.5;cursor:not-allowed}.ve-check-label{min-width:0}
.ve-v.checked,.ve-c.checked{background:rgba(186,244,0,.075)!important;box-shadow:inset 0 0 0 1px rgba(186,244,0,.24)!important}
.ve-v.checked:before{background:#baf400!important;box-shadow:none}
.ve-c.checked{color:#f3f7e9}
.ve-batch-selection-slot{position:absolute;left:0;bottom:calc(100% + 7px);display:flex;align-items:center}
.ve-batch-actions{display:flex;align-items:center;justify-content:space-between;gap:6px;width:100%;min-width:0}
.ve-selection-review-toggle{height:28px;border:1px solid rgba(186,244,0,.24);border-radius:var(--ve-radius-md);background:rgba(186,244,0,.07);color:#f4f4f4;padding:0 8px;display:inline-flex;align-items:center;gap:6px;cursor:pointer;font-size:var(--ve-font-xs);font-weight:800;text-transform:uppercase;letter-spacing:.3px;white-space:nowrap}
.ve-selection-review-toggle:hover,.ve-selection-review-toggle.open{border-color:rgba(186,244,0,.55);background:rgba(186,244,0,.12);color:#baf400}
.ve-selection-review{position:absolute;left:0;right:0;bottom:calc(100% + 43px);max-height:min(280px,45vh);display:flex;flex-direction:column;overflow:hidden;border:1px solid rgba(186,244,0,.25);border-radius:9px;background:rgba(24,24,24,.98);box-shadow:0 -18px 42px rgba(0,0,0,.5);backdrop-filter:blur(14px)}
.ve-selection-review-head{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:10px 11px;border-bottom:1px solid rgba(255,255,255,.075)}
.ve-selection-review-title{display:flex;flex-direction:column;gap:2px;min-width:0}.ve-selection-review-title strong{font-size:var(--ve-font-xs);color:#f1f1f1}.ve-selection-review-title span{font-size:var(--ve-font-xs);color:#858585;line-height:1.35}
.ve-selection-review-clear{height:26px;border:0;border-radius:5px;background:transparent;color:#baf400;font-size:var(--ve-font-xs);font-weight:750;padding:0 7px;cursor:pointer}.ve-selection-review-clear:hover{background:rgba(186,244,0,.10)}
.ve-selection-review-list{min-height:0;overflow-y:auto;padding:5px}.ve-selection-review-list::-webkit-scrollbar{width:4px}.ve-selection-review-list::-webkit-scrollbar-track{background:#171717}.ve-selection-review-list::-webkit-scrollbar-thumb{background:rgba(186,244,0,.38);border-radius:var(--ve-radius-pill)}
.ve-selection-review-item{display:flex;align-items:center;gap:7px;min-height:32px;padding:5px 6px;border-radius:var(--ve-radius-md)}.ve-selection-review-item:hover{background:rgba(255,255,255,.045)}
.ve-selection-review-item-name{min-width:0;flex:1;color:#ddd;font:10px/1.35 'SF Mono','Fira Code',monospace;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ve-selection-review-item-badge{padding:2px 5px;border:1px solid rgba(255,255,255,.09);border-radius:var(--ve-radius-pill);background:rgba(255,255,255,.035);color:#858585;font-size:var(--ve-font-xs);line-height:1;white-space:nowrap}.ve-selection-review-item-badge.hidden{border-color:rgba(245,158,11,.22);color:#e7b55d;background:rgba(245,158,11,.06)}
.ve-selection-review-remove{width:24px;height:24px;border:1px solid rgba(255,255,255,.08);border-radius:5px;background:#222;color:#888;display:flex;align-items:center;justify-content:center;cursor:pointer;flex:0 0 24px}.ve-selection-review-remove:hover{border-color:rgba(239,68,68,.35);background:rgba(239,68,68,.08);color:#ff6b6b}
.ve-batch-select { width:110px!important; flex: 0 0 110px!important; }
.ve-batch-select .ve-menu-btn { padding:0 20px 0 8px!important; font-size:var(--ve-font-xs)!important; text-align: left; }
.ve-batch-select .ve-menu-btn:after { right:8px!important; }
.ve-batch-select .ve-menu-list { top:auto!important; bottom:calc(100% - 1px)!important; border-radius:var(--ve-radius-sm) 4px 0 0!important; border-bottom-color: rgba(255,255,255,.10)!important; border-top-color: #baf400!important; box-shadow: 0 -18px 38px rgba(0,0,0,.42)!important; }
.ve-batch-select.open .ve-menu-btn { border-radius: 0 0 4px 4px!important; }
.ve-sub-body.ve-migrate-sub-body{overflow:hidden;padding:0}
.ve-migrate-shell{display:flex;flex-direction:column;height:100%;min-height:0}
.ve-migrate-scroll{display:flex;flex:1;min-height:0;flex-direction:column;gap:12px;overflow-y:auto;padding:12px}
.ve-migrate-scroll::-webkit-scrollbar{width:4px}.ve-migrate-scroll::-webkit-scrollbar-thumb{background:rgba(186,244,0,.34);border-radius:var(--ve-radius-pill)}
.ve-migrate-callout{display:block;padding:13px;border:1px solid rgba(255,255,255,.09);border-radius:var(--ve-radius-xl);background:rgba(255,255,255,.025);box-shadow:inset 0 1px 0 rgba(255,255,255,.035),0 12px 28px rgba(0,0,0,.12)}
.ve-migrate-desc{font-size:var(--ve-font-xs);color:#aaa;line-height:1.7}
.ve-migrate-field{display:flex;flex-direction:column;gap:7px}.ve-migrate-field-label{color:#aaa;font-size:var(--ve-font-xs);font-weight:750}
.ve-migrate-sources{display:flex;flex-direction:column;gap:8px}
.ve-migrate-card{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:11px;align-items:center;padding:12px;border:1px solid rgba(255,255,255,.09);border-radius:var(--ve-radius-xl);background:rgba(255,255,255,.025);box-shadow:inset 0 1px 0 rgba(255,255,255,.03);transition:border-color .15s ease,background .15s ease}
.ve-migrate-card:hover{border-color:rgba(186,244,0,.23);background:rgba(186,244,0,.035)}
.ve-migrate-card-copy{min-width:0}.ve-migrate-card-title{font-size:var(--ve-font-xs);font-weight:800;color:#eee;line-height:1.3;margin-bottom:3px}.ve-migrate-card-desc{font-size:var(--ve-font-xs);color:#818181;line-height:1.55}
.ve-migrate-badge{display:inline-flex;align-items:center;justify-content:center;gap:4px;min-width:68px;padding:5px 7px;border-radius:5px;font-size:var(--ve-font-xs);font-weight:850;line-height:1;text-transform:uppercase;white-space:nowrap}
.ve-migrate-badge.ok{color:#baf400;background:rgba(186,244,0,.075);border:1px solid rgba(186,244,0,.22)}.ve-migrate-badge.muted{color:#858585;background:rgba(255,255,255,.03);border:1px solid rgba(255,255,255,.09)}
.ve-migrate-sticky{position:relative;z-index:24;display:flex;flex:0 0 auto;flex-direction:column;gap:8px;padding:10px 12px 11px;background:linear-gradient(180deg,rgba(22,22,22,.96),#171717 24%);border-top:1px solid rgba(186,244,0,.18);box-shadow:0 -16px 30px rgba(0,0,0,.34);backdrop-filter:blur(14px)}
.ve-migrate-actions{display:flex;gap:7px;align-items:center}.ve-migrate-actions .ve-btn{display:inline-flex;align-items:center;justify-content:center;min-height:36px}.ve-migrate-actions .ve-btn.ve-btn-g{background:#202020;border-color:rgba(255,255,255,.12);color:#d7d7d7}.ve-migrate-actions .ve-btn.ve-btn-g:hover{color:#baf400;border-color:rgba(186,244,0,.32)}
.ve-migrate-result{display:block;padding:12px;border-radius:9px}
.ve-migrate-result.success{border:1px solid rgba(186,244,0,.25);background:linear-gradient(145deg,rgba(186,244,0,.07),rgba(186,244,0,.025))}.ve-migrate-result.warning{border:1px solid rgba(245,158,11,.34);background:linear-gradient(145deg,rgba(245,158,11,.075),rgba(245,158,11,.025))}
.ve-migrate-summary-title,.ve-migrate-warnings-title{font-size:var(--ve-font-xs);color:#eee;font-weight:800;line-height:1.25;margin-bottom:4px}.ve-migrate-warnings-title{color:#ffc86b}
.ve-migrate-summary-details{font-size:var(--ve-font-xs);color:#aaa;line-height:1.55}.ve-migrate-count-ready{color:#baf400;font-weight:800}.ve-migrate-count-skipped{color:#f2bd63;font-weight:750}
.ve-migrate-families{display:flex;flex-direction:column;gap:8px;padding:11px;border:1px solid rgba(186,244,0,.18);border-radius:9px;background:rgba(186,244,0,.025)}
.ve-migrate-families-title{font-size:var(--ve-font-xs);color:#eee;font-weight:800}.ve-migrate-families-help{font-size:var(--ve-font-xs);color:#858585;line-height:1.5}
.ve-migrate-family-list{display:flex;flex-direction:column;gap:8px}
.ve-migrate-family-row{display:grid;grid-template-columns:minmax(0,42%) minmax(0,58%);align-items:center;gap:9px;padding-top:8px;border-top:1px solid rgba(255,255,255,.055)}
.ve-migrate-family-name{min-width:0;color:#d8d8d8;font:10px/1.4 'SF Mono','Fira Code',monospace;overflow-wrap:anywhere}.ve-migrate-family-meta{display:block;color:#666;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',sans-serif;margin-top:2px}
.ve-migrate-warning-list{display:flex;flex-direction:column;gap:5px;color:#d6a958;font-size:var(--ve-font-xs);line-height:1.45}
.ve-migrate-diff-list{max-height:210px;overflow-y:auto;border:1px solid rgba(255,255,255,.08);border-radius:9px;background:rgba(0,0,0,.16);padding:6px 11px;box-shadow:inset 0 1px 0 rgba(255,255,255,.02)}
.ve-migrate-diff-list::-webkit-scrollbar {
  width:4px;
}
.ve-migrate-diff-list::-webkit-scrollbar-thumb {
  background: #333;
  border-radius:2px;
}
.ve-migrate-diff-row{display:flex;gap:10px;padding:8px 0;border-bottom:1px solid rgba(255,255,255,.045);font-size:var(--ve-font-xs);align-items:center}
.ve-migrate-diff-row:last-child {
  border-bottom:none;
}
.ve-migrate-diff-action{font-weight:850;font-size:var(--ve-font-xs);padding:4px 6px;border-radius:var(--ve-radius-sm);text-transform:uppercase;width:42px;text-align:center;line-height:1.1}
.ve-migrate-diff-action.add {
  background: rgba(34, 197, 94, 0.1);
  color: #4ade80;
  border: 1px solid rgba(34, 197, 94, 0.15);
}
.ve-migrate-diff-action.update {
  background: rgba(59, 130, 246, 0.1);
  color: #60a5fa;
  border: 1px solid rgba(59, 130, 246, 0.15);
}
.ve-migrate-diff-action.other {
  background: rgba(255, 255, 255, 0.05);
  color: #aaa;
  border: 1px solid rgba(255, 255, 255, 0.08);
}

.ve-floating-scrim{position:fixed;inset:0;z-index:120080;background:transparent!important;pointer-events:auto}.ve-collection-color-popover{position:fixed;width:min(334px,calc(100vw - 28px));max-height:min(560px,calc(100vh - 28px));overflow:auto;padding:12px;border:1px solid rgba(255,255,255,.13);border-radius:var(--ve-radius-xl);background:#1f1f1f;box-shadow:0 18px 60px rgba(0,0,0,.5);pointer-events:auto}.ve-collection-color-popover .ve-modal-title{margin-bottom:4px}.ve-collection-inline-color-panel{margin-top:10px;background:#242424!important}.ve-collection-inline-color-panel .ve-color-map{height:118px}.ve-collection-color-popover .ve-collection-color-grid{grid-template-columns:repeat(5,minmax(0,1fr));margin-top:9px}.ve-collection-color-popover .ve-modal-actions{position:sticky;bottom:0;padding-top:10px;background:linear-gradient(180deg,rgba(31,31,31,0),#1f1f1f 35%)}
.ve-media-workflow-card{display:flex;align-items:center;justify-content:space-between;gap:12px;margin:-2px 0 12px;padding:10px 12px;border:1px solid rgba(186,244,0,.18);border-radius:var(--ve-radius-lg);background:rgba(186,244,0,.045)}.ve-media-workflow-card>div:first-child{display:grid;gap:3px;min-width:0}.ve-media-workflow-card strong{color:#fff;font-size:12px}.ve-media-workflow-card span{color:#8f8f8f;font-size:11px;line-height:1.4}.ve-media-workflow-card>div:last-child{display:flex;align-items:center;gap:7px;flex-wrap:wrap;justify-content:flex-end}
.ve-media-meta-card{display:grid;gap:10px;padding:10px;border:1px solid rgba(255,255,255,.08);border-radius:var(--ve-radius-lg);background:rgba(255,255,255,.025)}.ve-media-meta-head{display:flex;align-items:center;justify-content:space-between;gap:8px}.ve-media-meta-head span{font-size:12px;font-weight:800;color:#fff}.ve-media-meta-head em{font-style:normal;font-size:10px;color:#8f8f8f}.ve-media-meta-field{display:grid;gap:5px}.ve-media-meta-field>span{font-size:10px;color:#777;text-transform:uppercase;letter-spacing:.35px;font-weight:800}.ve-media-meta-row{display:grid;grid-template-columns:minmax(0,1fr) 34px;gap:6px}.ve-studio-textarea-small{min-height:62px!important}.ve-media-copy-grid{display:grid;grid-template-columns:1fr 1fr 1.2fr;gap:6px}.ve-media-copy-grid .ve-btn{justify-content:center;gap:5px}.ve-replace-history-card{border:1px solid rgba(255,255,255,.08);border-radius:var(--ve-radius-lg);background:rgba(255,255,255,.024);overflow:hidden}.ve-replace-history-list{display:grid;max-height:126px;overflow:auto}.ve-replace-history-row{display:grid;gap:2px;padding:8px 10px;border-top:1px solid rgba(255,255,255,.055);font-size:11px}.ve-replace-history-row span{color:#ddd;font-weight:700}.ve-replace-history-row em{color:#858585;font-style:normal;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}

.ve-media-studio .ve-media-meta-card{gap:12px!important;padding:12px!important;border-color:rgba(255,255,255,.10)!important;background:rgba(255,255,255,.026)!important}.ve-media-studio .ve-media-meta-field{display:flex!important;flex-direction:column!important;align-items:stretch!important;gap:6px!important;margin:0!important}.ve-media-studio .ve-media-meta-field>span{display:block!important;width:100%!important;line-height:1.25!important;color:#8a8a8a!important;letter-spacing:.05em!important}.ve-media-studio .ve-media-meta-row{display:grid!important;grid-template-columns:minmax(0,1fr) 36px!important;gap:6px!important;align-items:stretch!important}.ve-media-studio .ve-media-meta-card .ve-studio-input,.ve-media-studio .ve-collection-shortcode-row .ve-studio-input{width:100%!important;box-sizing:border-box!important;background:rgba(255,255,255,.045)!important;border:1px solid rgba(255,255,255,.10)!important;color:#f5f5f5!important;border-radius:var(--ve-radius-md)!important;box-shadow:none!important}.ve-media-studio .ve-media-meta-card textarea.ve-studio-input{min-height:72px!important;height:auto!important;max-height:none!important;line-height:1.5!important;resize:vertical!important;padding:9px 10px!important}.ve-media-studio .ve-media-meta-card textarea.ve-studio-textarea-small{min-height:62px!important}.ve-media-studio .ve-media-meta-card input.ve-studio-input{height:38px!important;min-height:38px!important;max-height:38px!important;line-height:38px!important}.ve-media-studio .ve-media-copy-grid{grid-template-columns:1fr 1fr!important;gap:7px!important}.ve-media-studio .ve-media-copy-grid .ve-btn:last-child{grid-column:1/-1!important}.ve-media-studio .ve-replace-history-card .ve-media-usage-head{padding:10px 10px 0!important}.ve-media-studio .ve-replace-history-card .ve-replace-history-list{padding:4px 0 2px!important}.ve-media-studio .ve-replace-history-row:first-child{border-top:0!important}.ve-media-studio .ve-media-progress-toast.busy .ve-upload-bar span{width:44%!important;animation:veBusyBar 1.1s ease-in-out infinite}.ve-media-progress-toast.busy .ve-media-progress-spinner{width:16px;height:16px;border-radius:50%;border:2px solid rgba(186,244,0,.22);border-top-color:#baf400;animation:veSpin .75s linear infinite;flex:0 0 16px}.ve-media-progress-toast.busy>svg{display:none}@keyframes veBusyBar{0%{transform:translateX(-130%)}55%{transform:translateX(70%)}100%{transform:translateX(220%)}}@keyframes veSpin{to{transform:rotate(360deg)}}.ve-media-studio .ve-filter-pop-head-actions{display:flex;align-items:center;gap:8px}.ve-media-studio .ve-filter-clear-top{color:#ff7777!important}.ve-media-studio .ve-filter-clear-top:hover{color:#ffb1b1!important}.ve-media-studio .ve-collection-shortcode-block{display:grid!important;gap:7px!important}.ve-media-studio .ve-collection-shortcode-label{display:flex;align-items:center;gap:7px;font-size:10px;color:#777;text-transform:uppercase;letter-spacing:.04em;font-weight:800}.ve-media-studio .ve-collection-shortcode-row{display:grid!important;grid-template-columns:minmax(0,1fr) 36px!important;gap:7px!important}.ve-media-studio .ve-collection-shortcode-row input{height:38px!important;min-height:38px!important;max-height:38px!important;line-height:38px!important;background:rgba(255,255,255,.045)!important;color:#f2f2f2!important}.ve-media-studio .ve-collection-status-grid{grid-template-columns:repeat(3,minmax(0,1fr))!important}.ve-media-studio .ve-collection-color-popover{z-index:120090!important}.ve-media-studio .ve-collection-inline-color-panel .ve-color-map{min-height:118px}.ve-media-studio .ve-collection-inline-color-panel .ve-hue{height:16px!important;accent-color:#baf400}.ve-media-studio .ve-media-usage-list{padding-top:2px}.ve-media-studio .ve-media-usage-help{font-size:10.5px;color:#858585;line-height:1.45;margin-top:-2px}
.ve-collection-details-sidebar{gap:12px}.ve-collection-detail-hero{--ve-collection-accent:#baf400;display:flex;gap:10px;align-items:center;padding:12px;border:1px solid color-mix(in srgb,var(--ve-collection-accent) 28%,transparent);border-radius:var(--ve-radius-lg);background:color-mix(in srgb,var(--ve-collection-accent) 8%,transparent)}.ve-collection-detail-icon{width:36px;height:36px;display:grid;place-items:center;border-radius:var(--ve-radius-md);background:rgba(255,255,255,.07);color:var(--ve-collection-accent);font-size:18px;flex:0 0 36px}.ve-collection-detail-title{min-width:0;display:grid;gap:3px}.ve-collection-detail-title strong{font-size:13px;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-collection-detail-title span{font-size:11px;color:#8b8b8b}.ve-collection-status-grid{display:grid;grid-template-columns:1fr 1fr;gap:8px}.ve-collection-status-grid>span{display:grid;grid-template-columns:16px minmax(0,1fr);align-items:center;gap:5px;padding:8px;border:1px solid rgba(255,255,255,.07);border-radius:var(--ve-radius-md);background:rgba(255,255,255,.025);font-size:10px;color:#777;text-transform:uppercase;font-weight:800}.ve-collection-status-grid b{grid-column:1/-1;color:#e6e6e6;font-size:11px;text-transform:none;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-collection-shortcode-row{display:grid;grid-template-columns:minmax(0,1fr) 34px;gap:6px}.ve-collection-action-grid{display:grid;grid-template-columns:1fr 1fr;gap:7px}.ve-collection-action-grid .ve-btn{justify-content:center;gap:5px}.ve-collection-preview-list{display:grid;gap:6px}.ve-collection-preview-list button{display:grid;grid-template-columns:34px minmax(0,1fr);align-items:center;gap:8px;width:100%;border:1px solid rgba(255,255,255,.06);border-radius:var(--ve-radius-md);background:rgba(255,255,255,.025);color:#ddd;padding:6px;text-align:left;cursor:pointer}.ve-collection-preview-list button:hover{border-color:rgba(186,244,0,.25);background:rgba(186,244,0,.045)}.ve-collection-preview-list button>span{font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-collection-preview-list .ve-media-list-preview{width:34px;height:34px}

.ve-media-studio .ve-collection-color-popover{width:min(320px,calc(100vw - 28px))!important;padding:14px!important;background:linear-gradient(180deg,#242424 0%,#1d1d1d 100%)!important;border:1px solid rgba(255,255,255,.12)!important;border-radius:16px!important;box-shadow:0 24px 70px rgba(0,0,0,.58),inset 0 1px 0 rgba(255,255,255,.04)!important}.ve-media-studio .ve-collection-color-popover .ve-modal-title{font-size:12px!important;letter-spacing:-.01em!important}.ve-media-studio .ve-collection-color-popover .ve-modal-body{color:#a2a2a2!important;margin-bottom:10px!important}.ve-media-studio .ve-collection-color-name{min-height:38px!important;border-radius:10px!important;background:rgba(255,255,255,.035)!important;border-color:rgba(255,255,255,.09)!important}.ve-media-studio .ve-collection-color-grid{grid-template-columns:repeat(5,minmax(0,1fr))!important;gap:8px!important}.ve-media-studio .ve-collection-color-swatch{height:34px!important;border-radius:9px!important;background:rgba(255,255,255,.045)!important}.ve-media-studio .ve-collection-color-swatch span{width:20px!important;height:20px!important}.ve-media-studio .ve-collection-color-swatch.active{border-color:#baf400!important;background:rgba(186,244,0,.075)!important;box-shadow:0 0 0 1px rgba(186,244,0,.28),0 10px 24px rgba(0,0,0,.24)!important}.ve-media-studio .ve-collection-color-swatch em{right:5px!important;top:5px!important}.ve-media-studio .ve-collection-inline-color-panel{padding:10px!important;background:#202020!important;border-color:rgba(255,255,255,.10)!important;border-radius:13px!important}.ve-media-studio .ve-collection-inline-color-panel .ve-color-map{height:122px!important;border-radius:10px!important}.ve-media-studio .ve-collection-inline-color-panel .ve-color-fields{gap:6px!important}.ve-media-studio .ve-collection-inline-color-panel .ve-color-fields input{background:#f8f8f8!important;color:#151515!important;border:0!important;border-radius:3px!important;font-weight:800!important}.ve-media-studio .ve-collection-inline-color-panel .ve-format-tabs{border-color:rgba(255,255,255,.08)!important;border-radius:8px!important}.ve-media-studio .ve-collection-inline-color-panel .ve-format-tabs button{background:#232323!important;border-color:rgba(255,255,255,.08)!important}.ve-media-studio .ve-collection-inline-color-panel .ve-format-tabs button.on{background:#baf400!important;color:#101010!important}.ve-media-studio .ve-filter-builder-list{display:grid;gap:6px}.ve-media-studio .ve-filter-builder{grid-template-columns:auto minmax(0,1fr) 28px!important}.ve-media-studio .ve-filter-rule-remove{width:28px;height:28px;border:1px solid rgba(255,255,255,.08);background:#242424;color:#8d8d8d;border-radius:7px;display:flex;align-items:center;justify-content:center;cursor:pointer}.ve-media-studio .ve-filter-rule-remove:hover{color:#ff7777;border-color:rgba(255,119,119,.34);background:rgba(255,119,119,.08)}.ve-media-studio .ve-filter-choice.active em{background:rgba(186,244,0,.15);color:#baf400}.ve-media-studio .ve-media-progress-toast{min-width:280px!important;border-radius:14px!important;background:linear-gradient(180deg,rgba(33,34,33,.97),rgba(22,23,22,.97))!important}.ve-media-studio .ve-media-progress-toast .ve-upload-bar{height:6px!important;background:rgba(255,255,255,.10)!important}.ve-media-studio .ve-media-usage-row,.ve-media-studio a.ve-media-usage-row{color:#d8d8d8!important;text-decoration:none!important}.ve-media-studio .ve-media-usage-row:hover{background:rgba(186,244,0,.085)!important;border-color:rgba(186,244,0,.28)!important;color:#dfffa3!important}.ve-media-studio .ve-media-usage-row:hover span{color:#dfffa3!important}.ve-media-studio .ve-media-usage-row:hover em{color:#a5a5a5!important}.ve-media-studio .ve-media-usage-row span{display:flex;align-items:center;gap:6px}.ve-media-studio .ve-media-usage-row span:after{content:'Open';font-size:9px;font-weight:800;color:#111;background:#baf400;border-radius:999px;padding:2px 5px;opacity:0;transform:translateX(-3px);transition:opacity .12s,transform .12s}.ve-media-studio .ve-media-usage-row:hover span:after{opacity:1;transform:translateX(0)}
.ve-media-studio .ve-collection-inline-color-panel .ve-color-fields input{background:#2a2a2a!important;color:#f3f6ee!important;border:1px solid rgba(255,255,255,.10)!important;border-radius:8px!important;min-height:34px!important;height:34px!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.035)!important;font-weight:800!important;text-align:center!important}.ve-media-studio .ve-collection-inline-color-panel .ve-color-fields input:focus{border-color:rgba(186,244,0,.48)!important;outline:0!important;box-shadow:0 0 0 2px rgba(186,244,0,.10)!important}.ve-media-studio .ve-collection-inline-color-panel .ve-hue{height:14px!important;border-radius:999px!important}.ve-media-studio .ve-collection-color-swatch.active{border-color:#baf400!important;background:rgba(186,244,0,.055)!important;box-shadow:0 0 0 1px rgba(186,244,0,.35),inset 0 1px 0 rgba(255,255,255,.04)!important}.ve-media-studio .ve-collection-color-swatch.active:after{content:'';position:absolute;inset:4px;border:1px solid rgba(186,244,0,.55);border-radius:7px;pointer-events:none}.ve-media-studio .ve-collection-color-swatch.active span{box-shadow:0 0 0 3px rgba(186,244,0,.12),0 0 0 1px rgba(0,0,0,.30) inset!important}.ve-media-studio .ve-collection-color-swatch em{display:none!important}.ve-media-studio .ve-collection-color-popover .ve-modal-actions{gap:8px!important}.ve-media-studio .ve-collection-color-popover .ve-modal-actions .ve-btn{height:34px!important;border-radius:8px!important}.ve-media-studio .ve-context-menu{max-height:min(330px,calc(100vh - 24px))!important;overflow:auto!important}

.ve-media-studio .ve-collection-color-popover{max-height:min(520px,calc(100vh - 72px))!important;overflow:auto!important;overscroll-behavior:contain!important}.ve-media-studio .ve-collection-inline-color-panel{gap:10px!important}.ve-media-studio .ve-collection-inline-color-panel .ve-color-fields input{background:#252525!important;color:#f3f6ee!important;border:1px solid rgba(255,255,255,.10)!important;border-radius:9px!important;min-height:34px!important;height:34px!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.04)!important;font-weight:800!important;text-align:center!important}.ve-media-studio .ve-collection-color-swatch{position:relative!important}.ve-media-studio .ve-collection-color-swatch.active{border-color:#baf400!important;background:rgba(186,244,0,.06)!important;box-shadow:0 0 0 1px rgba(186,244,0,.32),inset 0 1px 0 rgba(255,255,255,.05)!important}.ve-media-studio .ve-collection-color-swatch.active:after{content:''!important;position:absolute!important;inset:5px!important;border:1px solid rgba(186,244,0,.62)!important;border-radius:7px!important;pointer-events:none!important}.ve-media-studio .ve-context-menu.ve-context-menu-attached{overflow:visible!important;margin-bottom:18px!important}.ve-media-studio .ve-context-menu.ve-context-menu-attached:before{display:block!important}.ve-media-studio .ve-context-menu.ve-context-menu-attached button{flex:0 0 auto}.ve-media-studio .ve-media-workflow-card .ve-btn[disabled]{opacity:.55!important}



/* v1.3.153 Media Studio overview, saved filters, list, and bulk polish */
.ve-media-overview{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin:0 0 12px}
.ve-media-overview-card{min-width:0;border:1px solid rgba(255,255,255,.07);border-radius:12px;background:linear-gradient(180deg,rgba(255,255,255,.035),rgba(255,255,255,.018));padding:10px 10px;display:flex;align-items:center;gap:9px;text-align:left;color:#d8d8d8;cursor:pointer;transition:border-color .14s,background .14s,transform .14s,box-shadow .14s}
.ve-media-overview-card:hover{border-color:rgba(186,244,0,.24);background:rgba(186,244,0,.045);transform:translateY(-1px)}
.ve-media-overview-card.active{border-color:rgba(186,244,0,.42);background:rgba(186,244,0,.075);box-shadow:inset 0 1px 0 rgba(255,255,255,.04)}
.ve-media-overview-icon{width:28px;height:28px;min-width:28px;border:1px solid rgba(255,255,255,.08);border-radius:9px;background:rgba(0,0,0,.18);display:flex;align-items:center;justify-content:center;color:#baf400;font-size:15px}
.ve-media-overview-copy{min-width:0;display:grid;gap:1px}.ve-media-overview-copy strong{font-size:16px;line-height:1;color:#fff}.ve-media-overview-copy em{font-style:normal;font-size:10.5px;font-weight:800;color:#d8d8d8;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.ve-media-overview-copy small{font-size:9.5px;color:#7f7f7f;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.ve-active-filter-strip{display:flex;align-items:center;gap:6px;flex-wrap:wrap;margin:-2px 0 12px;padding:7px 8px;border:1px solid rgba(186,244,0,.13);border-radius:10px;background:rgba(186,244,0,.035);font-size:10.5px;color:#9c9c9c}.ve-active-filter-strip>span{display:flex;align-items:center;gap:5px;color:#d7e7aa;font-weight:800}.ve-active-filter-strip button{height:24px;border:1px solid rgba(255,255,255,.08);border-radius:999px;background:#252525;color:#ddd;padding:0 8px;display:inline-flex;align-items:center;gap:5px;font-size:10px;font-weight:750;cursor:pointer}.ve-active-filter-strip button:hover{border-color:rgba(186,244,0,.28);color:#baf400}.ve-active-filter-strip button.clear{margin-left:auto;color:#ff8b8b;border-color:rgba(255,139,139,.18);background:rgba(255,139,139,.055)}
.ve-filter-save-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:7px;align-items:center}.ve-filter-save-row .ve-btn{height:32px!important;border-radius:8px!important;color:#101010!important;background:#baf400!important;font-weight:850!important}.ve-filter-save-link{margin-left:auto;border:0;background:transparent;color:#baf400;font-size:10.5px;font-weight:800;display:inline-flex;align-items:center;gap:5px;cursor:pointer}.ve-filter-save-link:hover{color:#dfff72}.ve-saved-filter-list{display:grid;gap:5px;padding:7px;border:1px solid rgba(255,255,255,.07);border-radius:10px;background:rgba(255,255,255,.02)}.ve-saved-filter-title{display:flex;align-items:center;gap:5px;color:#aaa;font-size:10px;font-weight:850;text-transform:uppercase;letter-spacing:.04em}.ve-saved-filter-row{display:grid;grid-template-columns:minmax(0,1fr) 26px;gap:5px;align-items:center}.ve-saved-filter-row>button:first-child{min-width:0;text-align:left;border:1px solid rgba(255,255,255,.07);border-radius:8px;background:#242424;color:#e8e8e8;padding:6px 8px;display:grid;gap:1px;cursor:pointer}.ve-saved-filter-row>button:first-child:hover{border-color:rgba(186,244,0,.24);background:rgba(186,244,0,.055)}.ve-saved-filter-row strong{overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px}.ve-saved-filter-row em{font-size:9.5px;color:#858585;font-style:normal}.ve-saved-filter-remove{height:26px;width:26px;border:1px solid rgba(255,255,255,.08);border-radius:8px;background:#242424;color:#9a9a9a;display:flex;align-items:center;justify-content:center;cursor:pointer}.ve-saved-filter-remove:hover{color:#ff7676;border-color:rgba(255,118,118,.3);background:rgba(255,118,118,.08)}
.ve-media-list-scroller{border:1px solid rgba(255,255,255,.065);border-radius:12px;background:rgba(255,255,255,.012);overflow:auto!important}.ve-media-list-table{border-collapse:separate!important;border-spacing:0!important}.ve-media-list-table thead th{position:sticky;top:0;z-index:4;background:#191919!important;border-bottom:1px solid rgba(255,255,255,.08)!important}.ve-media-list-table tbody tr{transition:background .14s,box-shadow .14s}.ve-media-list-table tbody tr.checked{background:rgba(186,244,0,.035)}.ve-media-list-table tbody tr.selected{box-shadow:inset 2px 0 0 #baf400;background:rgba(186,244,0,.055)}.ve-media-list-table tbody tr:hover{background:rgba(255,255,255,.035)!important}.ve-media-list-preview{width:48px!important;height:48px!important;border:1px solid rgba(255,255,255,.07);border-radius:9px;overflow:hidden;background:#111}.ve-list-title-cell{display:grid;gap:3px;min-width:0}.ve-list-title-cell strong{font-size:12px;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-list-title-cell em{font-size:10px;color:#777;font-style:normal}.ve-media-list-table .ve-list-alt .ve-studio-input{height:32px!important;min-height:32px!important;border-radius:8px!important;background:#222!important}.ve-media-list-table .ve-list-actions .ve-btn{height:30px!important;min-height:30px!important;width:30px!important;padding:0!important;display:inline-flex!important;align-items:center!important;justify-content:center!important}
.ve-bulk-polished{grid-template-columns:auto minmax(96px,1fr) auto!important;gap:12px!important;padding:9px 10px!important;border-radius:12px!important;background:linear-gradient(180deg,rgba(30,31,30,.97),rgba(20,21,20,.97))!important;box-shadow:0 -16px 40px rgba(0,0,0,.44),inset 0 1px 0 rgba(255,255,255,.04)!important}.ve-bulk-summary{display:flex;align-items:center;gap:8px;min-width:0}.ve-bulk-close{width:28px;height:28px;border:1px solid rgba(255,255,255,.08);border-radius:8px;background:#292929;color:#ddd;display:flex;align-items:center;justify-content:center;cursor:pointer}.ve-bulk-close:hover{color:#baf400;border-color:rgba(186,244,0,.28)}.ve-bulk-count{width:26px;height:26px;border-radius:999px;background:rgba(186,244,0,.16);border:1px solid rgba(186,244,0,.25);color:#dfffa3;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:900}.ve-bulk-summary strong{font-size:12px;color:#f2f2f2}.ve-bulk-summary em{font-size:10px;color:#858585;font-style:normal}.ve-bulk-convert-group{display:inline-flex;align-items:center;gap:6px;padding:3px;border:1px solid rgba(255,255,255,.065);border-radius:9px;background:rgba(255,255,255,.02)}.ve-bulk-convert-group .ve-filter-menu{min-width:88px!important}.ve-media-batch-actions .ve-btn{height:32px!important;border-radius:8px!important;display:inline-flex!important;align-items:center!important;gap:5px!important}.ve-media-batch-actions .ve-btn:disabled{opacity:.45!important;cursor:not-allowed!important}
@media(max-width:1120px){.ve-media-overview{grid-template-columns:repeat(3,minmax(0,1fr))}.ve-bulk-polished{grid-template-columns:1fr}.ve-media-batch-actions{justify-content:flex-start!important}.ve-active-filter-strip button.clear{margin-left:0}}

/* v1.3.152 collection color picker compact polish */
.ve-media-studio .ve-collection-color-popover{width:min(318px,calc(100vw - 28px))!important;max-height:none!important;overflow:visible!important;overscroll-behavior:auto!important;padding:12px!important;border-radius:15px!important}
.ve-media-studio .ve-collection-color-popover .ve-modal-body{margin-bottom:8px!important;line-height:1.45!important}
.ve-media-studio .ve-collection-color-popover .ve-modal-actions{position:relative!important;bottom:auto!important;background:transparent!important;padding-top:8px!important;margin-top:8px!important}
.ve-media-studio .ve-collection-color-grid{gap:7px!important;margin-top:8px!important}
.ve-media-studio .ve-collection-color-swatch{height:32px!important;border-radius:9px!important;transition:border-color .14s ease,background .14s ease,box-shadow .14s ease,transform .14s ease!important}
.ve-media-studio .ve-collection-color-swatch:hover{border-color:rgba(186,244,0,.28)!important;background:rgba(255,255,255,.065)!important}
.ve-media-studio .ve-collection-color-swatch span{width:19px!important;height:19px!important;border-radius:999px!important;transition:transform .14s ease,box-shadow .14s ease!important}
.ve-media-studio .ve-collection-color-swatch.active{border-color:rgba(186,244,0,.65)!important;background:rgba(186,244,0,.08)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.05),0 0 0 1px rgba(186,244,0,.26)!important}
.ve-media-studio .ve-collection-color-swatch.active:after{display:none!important;content:none!important}
.ve-media-studio .ve-collection-color-swatch.active span{transform:scale(.86)!important;box-shadow:0 0 0 2px #242424,0 0 0 4px #baf400!important}
.ve-media-studio .ve-collection-inline-color-panel{margin-top:8px!important;padding:9px!important;gap:8px!important;border-radius:12px!important}
.ve-media-studio .ve-collection-inline-color-panel .ve-color-map{height:108px!important;border-radius:10px!important}
.ve-media-studio .ve-collection-inline-color-panel .ve-color-fields{gap:6px!important}
.ve-media-studio .ve-collection-inline-color-panel .ve-color-fields input{height:32px!important;min-height:32px!important;max-height:32px!important;border-radius:8px!important;font-size:11px!important}
.ve-media-studio .ve-collection-inline-color-panel .ve-format-tabs button{min-height:28px!important;height:28px!important}


/* v1.3.154 Media Studio feedback polish */
.ve-media-studio .ve-media-empty-state{min-height:0;padding:18px 12px;color:#888;text-align:center;border:1px dashed rgba(255,255,255,.06);border-radius:12px;background:rgba(255,255,255,.012);font-size:12px}
.ve-media-studio .ve-media-overview{grid-template-columns:repeat(4,minmax(0,1fr))!important}
.ve-media-studio .ve-context-menu{padding:8px 8px 9px!important;gap:4px!important;overflow:auto!important;scrollbar-gutter:stable;border-radius:12px!important}
.ve-media-studio .ve-context-menu.ve-context-menu-attached{overflow:visible!important;padding-bottom:9px!important}
.ve-media-studio .ve-context-menu button{height:31px!important;border-radius:8px!important}
.ve-media-studio .ve-collection-color-popover{max-height:none!important;overflow:visible!important;overscroll-behavior:auto!important}
.ve-media-studio .ve-collection-color-popover .ve-modal-actions{position:relative!important;bottom:auto!important;background:transparent!important;padding-top:8px!important;margin-top:8px!important}
.ve-media-studio .ve-collection-color-swatch.active{border-color:#baf400!important;background:rgba(186,244,0,.075)!important;box-shadow:0 0 0 1px rgba(186,244,0,.34),inset 0 1px 0 rgba(255,255,255,.05)!important}
.ve-media-studio .ve-collection-color-swatch.active:after{display:none!important;content:none!important}
.ve-media-studio .ve-collection-color-swatch.active span{transform:none!important;box-shadow:0 0 0 2px #242424,0 0 0 3px rgba(186,244,0,.92)!important}
.ve-media-studio .ve-media-progress-toast{pointer-events:none!important}
@media(max-width:1120px){.ve-media-studio .ve-media-overview{grid-template-columns:repeat(2,minmax(0,1fr))!important}}

@media(max-width:840px){.ve-media-workflow-card{align-items:flex-start;flex-direction:column}.ve-media-copy-grid,.ve-collection-action-grid,.ve-collection-status-grid{grid-template-columns:1fr}}

@media(max-width:430px){.ve-migrate-card{grid-template-columns:minmax(0,1fr)}.ve-migrate-badge{justify-self:start}.ve-migrate-actions{flex-wrap:wrap}.ve-migrate-actions .ve-btn{flex:1 1 140px}.ve-migrate-family-row{grid-template-columns:minmax(0,1fr)}}

/* v1.3.156 — media safety/export diagnostics */
.ve-media-studio .ve-media-overview{grid-template-columns:repeat(5,minmax(0,1fr))!important}
@media(max-width:1260px){.ve-media-studio .ve-media-overview{grid-template-columns:repeat(3,minmax(0,1fr))!important}}
.ve-media-studio .ve-context-menu.ve-context-menu-attached{padding-bottom:8px!important;overflow:visible!important;max-height:none!important}
.ve-media-studio .ve-context-menu.ve-context-menu-attached button:last-child{margin-bottom:0!important}
.ve-safety-modal-body{display:flex;flex-direction:column;gap:10px;color:#d8d8d8;font-size:12px;line-height:1.45}.ve-safety-modal-body p{margin:0;color:#f2f2f2;font-weight:700}.ve-safety-note,.ve-safety-ok,.ve-safety-warning{border:1px solid rgba(255,255,255,.09);background:#202020;border-radius:10px;padding:10px;display:flex;flex-direction:column;gap:5px}.ve-safety-note{flex-direction:row;align-items:center;color:#b9b9b9}.ve-safety-ok{border-color:rgba(186,244,0,.22);background:rgba(186,244,0,.065);color:#eaffb0}.ve-safety-warning{border-color:rgba(245,158,11,.35);background:rgba(245,158,11,.08);color:#ffd88b}.ve-safety-warning strong,.ve-safety-ok strong{color:#fff}.ve-safety-warning em,.ve-safety-ok em{font-style:normal;color:#b8b8b8}.ve-safety-usage-list{display:flex;flex-direction:column;gap:5px;margin-top:4px}.ve-safety-usage-row{display:flex;justify-content:space-between;gap:10px;border:1px solid rgba(255,255,255,.06);background:rgba(0,0,0,.18);border-radius:8px;padding:6px 7px}.ve-safety-usage-row span{font-weight:800;color:#fff;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-safety-usage-row small,.ve-safety-warning small{color:#b8b8b8;font-size:10px}.ve-url-history-mini{margin-top:10px;padding:10px;border:1px solid rgba(255,255,255,.08);border-radius:11px;background:rgba(255,255,255,.035)}.ve-url-history-head{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:7px}.ve-url-history-head strong{font-size:11px;color:#fff}.ve-url-history-row{display:grid;grid-template-columns:minmax(0,1fr) auto;gap:8px;padding:6px 0;border-top:1px solid rgba(255,255,255,.06)}.ve-url-history-row span{font-size:11px;color:#fff;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-url-history-row em{font-style:normal;color:#8c8c8c;font-size:10px;white-space:nowrap}.ve-diagnostics-mini{margin:9px 0;border:1px solid rgba(186,244,0,.16);background:rgba(186,244,0,.045);border-radius:11px;padding:9px}.ve-diagnostics-mini-head{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:8px}.ve-diagnostics-mini-head strong{color:#fff;font-size:11px}.ve-diagnostics-mini-grid{display:grid;grid-template-columns:1fr;gap:6px}.ve-diagnostics-mini-grid span{display:flex;align-items:center;justify-content:space-between;border:1px solid rgba(255,255,255,.06);border-radius:8px;padding:6px 7px;font-size:10px;color:#b8b8b8}.ve-diagnostics-mini-grid b{color:#fff}.ve-replace-history-row{align-items:flex-start!important;gap:6px!important}.ve-history-restore-btn{margin-top:4px;border:1px solid rgba(186,244,0,.26);background:rgba(186,244,0,.08);color:#baf400;border-radius:8px;font-size:10px;font-weight:800;padding:5px 7px;display:inline-flex;align-items:center;gap:5px;cursor:pointer}.ve-history-restore-btn:hover{background:#baf400;color:#111}

/* v1.3.158 — filter panel cleanup, masonry view, persistent tree UX */
.ve-filter-pop{max-height:min(560px,calc(100vh - 150px))!important;overflow:hidden!important;padding:10px!important;gap:8px!important}
.ve-filter-choice-list{display:grid;gap:6px;min-height:72px;max-height:190px;overflow:auto;padding:1px 2px 3px}
.ve-filter-pop .ve-saved-filter-list,.ve-filter-pop .ve-filter-builder-list{flex:0 0 auto}
.ve-diagnostics-mini{margin:4px 0 0!important;padding:9px!important;flex:0 0 auto}
.ve-diagnostics-mini-head{margin-bottom:7px!important}.ve-filter-rescan{height:26px;min-height:26px;border:1px solid rgba(186,244,0,.22);border-radius:8px;background:rgba(186,244,0,.075);color:#dfffa3;font-size:10px;font-weight:850;display:inline-flex;align-items:center;gap:5px;padding:0 8px;cursor:pointer}.ve-filter-rescan:hover:not(:disabled){background:rgba(186,244,0,.14);border-color:rgba(186,244,0,.38);color:#f4ffd9}.ve-filter-rescan:disabled{opacity:.55;cursor:not-allowed}.ve-filter-rescan svg{width:12px!important;height:12px!important}
.ve-view-pop{min-width:122px}.ve-view-choice{justify-content:flex-start!important;gap:7px!important;padding:0 9px!important;width:100%!important}.ve-view-choice svg{width:14px!important;height:14px!important}.ve-view-choice:after{content:attr(title);font-size:10px;font-weight:800;white-space:nowrap;color:inherit}
.ve-media-masonry{--ve-masonry-columns:6}.ve-media-masonry .ve-media-thumb:nth-child(5n+1) .ve-checker-bg img{max-height:220px}.ve-media-masonry .ve-media-thumb:nth-child(5n+2) .ve-checker-bg img{max-height:156px}.ve-media-masonry .ve-media-thumb:nth-child(5n+3) .ve-checker-bg img{max-height:188px}.ve-media-masonry .ve-media-thumb:nth-child(5n+4) .ve-checker-bg img{max-height:132px}.ve-media-masonry .ve-media-thumb:nth-child(5n) .ve-checker-bg img{max-height:176px}
@media(max-width:1400px){.ve-media-masonry{--ve-masonry-columns:5}}@media(max-width:1120px){.ve-media-masonry{--ve-masonry-columns:4}}@media(max-width:820px){.ve-media-masonry{--ve-masonry-columns:2}}

/* v1.3.159 — view menu, masonry scroll + Content Studio CRUD polish */
.ve-view-pop-wrap{position:relative!important;display:inline-flex!important;padding-bottom:10px!important;margin-bottom:-10px!important;overflow:visible!important}
.ve-view-pop-wrap .ve-view-pop{right:0!important;top:calc(100% + 2px)!important;min-width:158px!important;width:158px!important;max-width:180px!important;padding:6px!important;gap:5px!important;border-radius:12px!important;background:#1f1f1f!important;box-shadow:0 18px 42px rgba(0,0,0,.52)!important;overflow:visible!important}
.ve-view-choice{width:100%!important;height:34px!important;justify-content:flex-start!important;gap:8px!important;padding:0 10px!important;border-radius:9px!important;background:rgba(255,255,255,.035)!important}
.ve-view-choice:after{content:none!important;display:none!important}.ve-view-choice svg{width:14px!important;height:14px!important;flex:0 0 14px!important}.ve-view-choice span{min-width:0;display:block;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:10.5px;font-weight:850;color:inherit;line-height:1}.ve-view-choice.active{background:rgba(186,244,0,.095)!important;border-color:rgba(186,244,0,.42)!important;color:#baf400!important}.ve-view-choice:hover{border-color:rgba(186,244,0,.30)!important;background:rgba(186,244,0,.06)!important;color:#dfff97!important}
.ve-media-masonry{flex:1!important;min-height:0!important;max-height:100%!important;overflow-y:auto!important;overflow-x:hidden!important;display:block!important;column-count:6!important;column-gap:12px!important;padding:0 10px 12px 0!important;grid-template-columns:none!important;grid-auto-rows:auto!important;grid-auto-flow:row!important;gap:0!important;align-content:start!important;justify-content:start!important}
.ve-media-masonry .ve-media-thumb{width:100%!important;display:inline-block!important;margin:0 0 12px 0!important;min-height:0!important;height:auto!important;break-inside:avoid!important;page-break-inside:avoid!important;vertical-align:top!important;overflow:hidden!important}
.ve-media-masonry .ve-checker-bg{width:100%!important;height:auto!important;min-height:0!important;display:block!important;overflow:hidden!important}.ve-media-masonry .ve-checker-bg img{width:100%!important;height:auto!important;max-width:100%!important;max-height:none!important;display:block!important;object-fit:contain!important}.ve-media-masonry .ve-font-file-card,.ve-media-masonry .ve-file-card{height:132px!important;min-height:132px!important}.ve-media-masonry .ve-media-meta-hover{left:8px!important;right:8px!important;bottom:8px!important}.ve-media-masonry .ve-preview-fallback{min-height:120px!important}
@media(max-width:1400px){.ve-media-masonry{column-count:5!important}}@media(max-width:1120px){.ve-media-masonry{column-count:4!important}}@media(max-width:820px){.ve-media-masonry{column-count:2!important}}
.ve-content-studio .ve-studio-main{min-width:0;overflow:hidden}.ve-content-dashboard{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;margin:0 0 12px}.ve-content-stat-card{border:1px solid rgba(255,255,255,.07);border-radius:12px;background:linear-gradient(180deg,rgba(255,255,255,.035),rgba(255,255,255,.016));padding:10px 12px;display:grid;gap:4px;min-width:0;text-align:left;cursor:pointer;color:#ddd}.ve-content-stat-card strong{font-size:18px;line-height:1;color:#fff}.ve-content-stat-card span{font-size:10px;color:#888;text-transform:uppercase;font-weight:850;letter-spacing:.04em}.ve-content-stat-card.active{border-color:rgba(186,244,0,.38);background:rgba(186,244,0,.065)}.ve-content-status-tabs{display:flex;align-items:center;gap:5px;flex-wrap:wrap;margin:0 0 12px}.ve-content-status-tabs button{height:28px;border:1px solid rgba(255,255,255,.075);border-radius:999px;background:rgba(255,255,255,.025);color:#aaa;padding:0 9px;font-size:10px;font-weight:850;cursor:pointer}.ve-content-status-tabs button:hover{border-color:rgba(186,244,0,.24);color:#dfff97}.ve-content-status-tabs button.active{border-color:rgba(186,244,0,.42);background:rgba(186,244,0,.095);color:#baf400}.ve-content-create-form,.ve-content-cpt-form{max-width:760px;display:grid;gap:14px;background:rgba(255,255,255,.015);border:1px solid rgba(255,255,255,.07);border-radius:12px;padding:18px}.ve-content-create-grid{display:grid;grid-template-columns:minmax(0,1fr) 170px;gap:12px}.ve-content-create-actions{display:flex;gap:8px;justify-content:flex-end;align-items:center}.ve-content-table-wrap{border:1px solid rgba(255,255,255,.065);border-radius:12px;background:rgba(255,255,255,.012);overflow:auto;min-height:0}.ve-content-title-cell{display:grid;gap:3px;min-width:0}.ve-content-title-cell strong{font-size:12px;color:#fff;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-content-title-cell em{font-size:10px;color:#777;font-style:normal;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-content-actions{display:flex;gap:6px;justify-content:flex-end;align-items:center}.ve-content-actions .ve-btn{height:30px!important;min-height:30px!important}.ve-content-danger{color:#ff6262!important}.ve-content-warning{color:#ffbd4a!important}.ve-content-edit-form{border:1px solid rgba(255,255,255,.07);border-radius:12px;background:rgba(255,255,255,.012);overflow:hidden}.ve-content-edit-scroll{padding:18px;display:grid;gap:14px;max-height:min(60vh,620px);overflow:auto}.ve-content-edit-actions{padding:12px 18px;border-top:1px solid rgba(255,255,255,.065);display:flex;gap:8px;justify-content:flex-end;flex-wrap:wrap;background:rgba(0,0,0,.18)}
@media(max-width:1120px){.ve-content-dashboard{grid-template-columns:repeat(2,minmax(0,1fr))}.ve-content-create-grid{grid-template-columns:1fr}}


/* v1.3.160 — default content type polish, real masonry ratio, Rank Math summary */
.ve-content-studio .ve-studio-sidebar{background:#111!important;border-right:1px solid rgba(255,255,255,.065)!important;overflow:hidden!important;resize:none!important}.ve-content-studio .ve-studio-sidebar>div{padding:12px!important;gap:14px!important}.ve-content-studio .ve-studio-nav{gap:5px!important}.ve-studio-section-title{height:32px!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:8px!important;margin:0 0 6px!important;padding:0!important;color:#818181!important}.ve-section-toggle{height:30px!important;min-width:0!important;flex:1!important;border:1px solid rgba(255,255,255,.075)!important;border-radius:9px!important;background:rgba(255,255,255,.035)!important;color:#f2f2f2!important;display:flex!important;align-items:center!important;gap:7px!important;padding:0 9px!important;font-size:10.5px!important;font-weight:850!important;text-transform:none!important;letter-spacing:0!important;cursor:pointer!important}.ve-section-toggle:hover{border-color:rgba(186,244,0,.28)!important;color:#dfff97!important;background:rgba(186,244,0,.055)!important}.ve-section-toggle svg{width:12px!important;height:12px!important;color:#baf400!important}.ve-studio-section-title .ve-a-inline{width:30px!important;height:30px!important;min-width:30px!important;border:1px solid rgba(186,244,0,.28)!important;border-radius:9px!important;background:rgba(186,244,0,.08)!important;color:#baf400!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;margin:0!important;padding:0!important}.ve-studio-section-title .ve-a-inline:hover{background:#baf400!important;color:#111!important}.ve-studio-section-title .ve-a-inline svg{width:14px!important;height:14px!important}.ve-content-studio .ve-studio-nav-item{min-height:34px!important;border:1px solid transparent!important;border-radius:10px!important;padding:0 9px!important;background:transparent!important;color:#d8d8d8!important}.ve-content-studio .ve-studio-nav-item:hover{background:rgba(255,255,255,.035)!important;border-color:rgba(255,255,255,.06)!important}.ve-content-studio .ve-studio-nav-item.active{background:rgba(186,244,0,.14)!important;border-color:rgba(186,244,0,.22)!important;color:#baf400!important}.ve-content-studio .ve-studio-main{padding:18px!important;background:#111!important}.ve-content-studio .ve-studio-main h2{font-size:16px!important;font-weight:850!important;letter-spacing:-.02em!important}.ve-content-dashboard{gap:10px!important;margin-bottom:12px!important}.ve-content-stat-card{height:64px!important;border-radius:13px!important;padding:12px!important;background:linear-gradient(180deg,rgba(255,255,255,.04),rgba(255,255,255,.018))!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.035)!important}.ve-content-stat-card:hover{border-color:rgba(186,244,0,.25)!important;background:rgba(186,244,0,.045)!important}.ve-content-stat-card.active{border-color:rgba(186,244,0,.52)!important;background:rgba(186,244,0,.10)!important}.ve-content-status-tabs{margin-bottom:14px!important}.ve-content-status-tabs button{height:30px!important;border-radius:10px!important;padding:0 11px!important}.ve-content-table-wrap{border-radius:15px!important;border-color:rgba(255,255,255,.075)!important;background:#141414!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.03)!important}.ve-content-studio .ve-studio-table{border-collapse:separate!important;border-spacing:0!important;min-width:980px!important}.ve-content-studio .ve-studio-table th{height:38px!important;padding:0 12px!important;color:#707070!important;background:rgba(255,255,255,.018)!important;border-bottom:1px solid rgba(255,255,255,.065)!important;font-size:10px!important}.ve-content-studio .ve-studio-table td{padding:11px 12px!important;border-bottom:1px solid rgba(255,255,255,.045)!important}.ve-content-row{transition:background .14s,border-color .14s!important}.ve-content-row:hover{background:rgba(255,255,255,.025)!important}.ve-content-actions{opacity:.35!important;transform:translateY(1px)!important;transition:opacity .14s,transform .14s!important;flex-wrap:wrap!important;min-width:220px!important}.ve-content-row:hover .ve-content-actions{opacity:1!important;transform:translateY(0)!important}.ve-content-actions .ve-btn{border-radius:8px!important;font-size:10px!important;font-weight:850!important}.ve-content-title-cell strong{font-size:12px!important;font-weight:850!important}.ve-content-title-cell em{font-size:10px!important;color:#777!important}.ve-status-toggle{appearance:none!important;border:0!important;background:transparent!important;padding:0!important;cursor:pointer!important}.ve-content-seo-cell{display:grid!important;gap:5px!important;min-width:190px!important}.ve-content-seo-top{display:flex!important;gap:6px!important;align-items:center!important}.ve-seo-score{height:20px!important;min-width:34px!important;border-radius:999px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;font-size:10px!important;font-weight:900!important;border:1px solid rgba(255,255,255,.08)!important;background:rgba(255,255,255,.045)!important;color:#a8a8a8!important}.ve-seo-score.good{background:rgba(186,244,0,.12)!important;color:#baf400!important;border-color:rgba(186,244,0,.24)!important}.ve-seo-score.warn{background:rgba(255,184,0,.12)!important;color:#ffbd4a!important;border-color:rgba(255,184,0,.24)!important}.ve-seo-score.bad{background:rgba(255,77,77,.10)!important;color:#ff6868!important;border-color:rgba(255,77,77,.22)!important}.ve-seo-mini{font-size:10px!important;font-weight:800!important;color:#aaa!important}.ve-seo-mini.ok{color:#dfff97!important}.ve-seo-mini.missing{color:#ffb8b8!important}.ve-content-seo-lines{display:flex!important;gap:6px!important;flex-wrap:wrap!important;color:#777!important;font-size:9.5px!important;line-height:1.25!important}.ve-content-seo-lines span{background:rgba(255,255,255,.035)!important;border:1px solid rgba(255,255,255,.055)!important;border-radius:7px!important;padding:3px 5px!important}.ve-content-studio input.ve-studio-input,.ve-content-studio textarea.ve-studio-input,.ve-content-studio select.ve-studio-input{background:#202020!important;color:#f5f5f5!important;border:1px solid rgba(255,255,255,.10)!important;border-radius:10px!important;box-shadow:none!important}.ve-content-studio input.ve-studio-input:focus,.ve-content-studio textarea.ve-studio-input:focus{border-color:rgba(186,244,0,.55)!important;outline:none!important;box-shadow:0 0 0 2px rgba(186,244,0,.09)!important}.ve-content-edit-form,.ve-content-create-form,.ve-content-cpt-form,.ve-content-field-edit-form{border-radius:15px!important;background:#141414!important;border-color:rgba(255,255,255,.075)!important}.ve-content-edit-scroll{max-height:none!important;padding:16px!important}.ve-content-advanced,.ve-content-custom-fields{border-radius:13px!important;background:rgba(255,255,255,.018)!important;border-color:rgba(255,255,255,.07)!important}.ve-content-advanced summary,.ve-content-custom-fields summary{padding:4px 0!important}.ve-content-edit-actions{border-top:1px solid rgba(255,255,255,.065)!important;background:rgba(0,0,0,.20)!important}.ve-media-masonry .ve-media-thumb{border-radius:10px!important}.ve-media-masonry .ve-checker-bg{background:rgba(255,255,255,.025)!important}.ve-media-masonry .ve-checker-bg img{border-radius:9px!important}

/* v1.3.161 — Content Studio clarity + stable JS masonry */
.ve-media-masonry{display:grid!important;grid-template-columns:repeat(var(--ve-masonry-columns,5),minmax(0,1fr))!important;gap:12px!important;column-count:auto!important;column-gap:normal!important;overflow:auto!important;align-content:start!important;align-items:start!important;padding:0 10px 10px 0!important}
.ve-media-masonry-col{display:flex!important;flex-direction:column!important;gap:12px!important;min-width:0!important;align-items:stretch!important}
.ve-media-masonry .ve-media-thumb{width:100%!important;display:block!important;break-inside:auto!important;page-break-inside:auto!important;margin:0!important;min-height:96px!important;height:auto!important;aspect-ratio:auto!important;overflow:hidden!important;vertical-align:top!important}
.ve-media-masonry .ve-checker-bg{width:100%!important;height:auto!important;min-height:0!important;display:block!important;overflow:visible!important}
.ve-media-masonry .ve-checker-bg img{width:100%!important;height:auto!important;max-width:100%!important;max-height:none!important;display:block!important;object-fit:contain!important}
.ve-view-pop-wrap{padding-bottom:16px!important;margin-bottom:-16px!important}.ve-view-pop-wrap .ve-view-pop{top:calc(100% - 1px)!important}.ve-view-pop-wrap.open .ve-view-pop{pointer-events:auto!important}.ve-view-choice{min-height:34px!important}.ve-view-choice span{pointer-events:none!important}
.ve-content-studio .ve-studio-sidebar{min-width:320px!important;max-width:480px!important;flex:0 0 320px!important;width:320px!important}.ve-content-studio .ve-studio-main{min-width:0!important}.ve-content-studio .ve-studio-sidebar>div{padding:14px!important}.ve-content-editor-note{font-size:11px;color:#858585;line-height:1.55;border:1px solid rgba(255,255,255,.06);background:rgba(255,255,255,.018);border-radius:10px;padding:10px 11px}.ve-rich-surface,.ve-rich-surface p,.ve-rich-surface li,.ve-rich-surface blockquote{color:#f2f2f2!important}.ve-rich-surface h1,.ve-rich-surface h2,.ve-rich-surface h3,.ve-rich-surface h4,.ve-rich-surface h5,.ve-rich-surface h6{color:#f7f7f7!important}.ve-rich-surface a{color:#baf400!important}.ve-content-action-stack{display:grid!important;grid-template-columns:1fr!important;gap:6px!important;justify-items:end!important;min-width:240px!important}.ve-content-action-primary,.ve-content-action-secondary{display:flex!important;justify-content:flex-end!important;align-items:center!important;gap:6px!important;flex-wrap:nowrap!important}.ve-content-action-main{height:28px!important;min-height:28px!important;padding:0 9px!important;border-radius:8px!important;font-size:10px!important}.ve-content-icon-action{width:28px!important;height:28px!important;border:1px solid rgba(255,255,255,.09)!important;border-radius:8px!important;background:rgba(255,255,255,.035)!important;color:#b8b8b8!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;text-decoration:none!important;padding:0!important;cursor:pointer!important}.ve-content-icon-action:hover{border-color:rgba(186,244,0,.32)!important;background:rgba(186,244,0,.075)!important;color:#baf400!important}.ve-content-icon-action.warning:hover{border-color:rgba(255,184,0,.28)!important;color:#ffbd4a!important}.ve-content-icon-action.danger:hover{border-color:rgba(255,80,80,.30)!important;color:#ff6262!important}.ve-content-icon-action svg{width:14px!important;height:14px!important}


/* v1.3.162 — Content Studio pills, SEO editor, content columns, media masonry persistence */
.ve-media-masonry{row-gap:12px!important;gap:12px!important}.ve-media-masonry-col{gap:12px!important;row-gap:12px!important}.ve-media-masonry-col>.ve-media-thumb+ .ve-media-thumb{margin-top:12px!important}.ve-media-masonry .ve-checker-bg{overflow:hidden!important}.ve-media-masonry .ve-checker-bg img{background:rgba(255,255,255,.018)!important}
.ve-content-dashboard{display:none!important}.ve-content-status-tabs{margin:0 0 14px!important;padding:4px!important;border:1px solid rgba(255,255,255,.06)!important;border-radius:13px!important;background:rgba(255,255,255,.018)!important;width:max-content!important;max-width:100%!important}.ve-content-status-tabs button{display:inline-flex!important;align-items:center!important;gap:6px!important;height:30px!important;padding:0 10px!important}.ve-content-status-tabs button em{min-width:18px;height:18px;border-radius:999px;background:rgba(255,255,255,.065);color:#d8d8d8;display:inline-flex;align-items:center;justify-content:center;font-style:normal;font-size:10px;font-weight:900}.ve-content-status-tabs button.active em{background:#baf400!important;color:#111!important}.ve-content-tools{display:flex;align-items:center;gap:8px}.ve-content-column-pop-wrap{position:relative}.ve-content-column-pop{position:absolute;right:0;top:calc(100% + 8px);z-index:30;width:220px;border:1px solid rgba(255,255,255,.10);border-radius:12px;background:#202020;box-shadow:0 18px 60px rgba(0,0,0,.5);padding:10px;display:grid;gap:6px}.ve-content-column-pop-head{display:flex;align-items:center;justify-content:space-between;color:#eee;font-size:11px;font-weight:850;margin-bottom:2px}.ve-content-column-pop-row{display:flex;align-items:center;gap:8px;padding:6px 6px;border-radius:8px;color:#cfcfcf;font-size:11px;font-weight:700}.ve-content-column-pop-row:hover{background:rgba(255,255,255,.04)}.ve-content-column-actions{display:flex;gap:6px;border-top:1px solid rgba(255,255,255,.06);padding-top:8px;margin-top:4px}.ve-content-column-actions button{height:28px;border:1px solid rgba(255,255,255,.08);background:rgba(255,255,255,.035);color:#bdbdbd;border-radius:8px;font-size:10px;font-weight:850;cursor:pointer;padding:0 8px}.ve-content-column-actions button:hover{border-color:rgba(186,244,0,.28);color:#baf400}
.ve-content-icon-action i{display:inline-flex!important;align-items:center!important;justify-content:center!important;font-size:14px!important;line-height:1!important;color:currentColor!important}.ve-content-icon-action svg,.ve-content-icon-action .ve-ms-icon{display:block!important;color:currentColor!important;fill:currentColor!important;stroke:currentColor!important}.ve-content-icon-action:empty:before{content:'•';color:#baf400;font-size:14px;line-height:1}
.ve-content-edit-form{display:flex!important;flex-direction:column!important;min-height:0!important}.ve-content-edit-scroll{display:grid!important;gap:16px!important}.ve-content-form-grid{display:grid;grid-template-columns:minmax(0,1fr) 180px;gap:12px}.ve-content-editor-shell{border:1px solid rgba(255,255,255,.075);border-radius:14px;background:rgba(255,255,255,.015);overflow:hidden}.ve-content-editor-shell>label{display:flex!important;align-items:center;justify-content:space-between;margin:0!important;padding:11px 12px!important;border-bottom:1px solid rgba(255,255,255,.065);font-size:11px!important;color:#aaa!important}.ve-rich-editor{border:0!important;border-radius:0!important;background:#1b1b1b!important}.ve-rich-toolbar{display:flex!important;align-items:center!important;gap:5px!important;flex-wrap:wrap!important;padding:8px!important;background:#171717!important;border-bottom:1px solid rgba(255,255,255,.07)!important}.ve-rich-toolbar button{height:28px!important;min-width:28px!important;border-radius:8px!important;border:1px solid rgba(255,255,255,.10)!important;background:rgba(255,255,255,.045)!important;color:#e5e5e5!important;font-size:10px!important;font-weight:850!important;cursor:pointer!important}.ve-rich-toolbar button:hover{border-color:rgba(186,244,0,.32)!important;color:#baf400!important;background:rgba(186,244,0,.07)!important}.ve-rich-toolbar .ve-rich-tool-wide{padding:0 9px!important}.ve-rich-toolbar .ve-rich-sep{width:1px;height:22px;background:rgba(255,255,255,.08);margin:0 2px}.ve-rich-surface{min-height:320px!important;padding:18px!important;font-size:14px!important;line-height:1.78!important;background:#1e1e1e!important;color:#f2f2f2!important;outline:none!important}.ve-rich-surface:empty:before{content:attr(data-placeholder);color:#666}.ve-rich-surface h1{font-size:30px!important;line-height:1.15!important}.ve-rich-surface h2{font-size:24px!important;line-height:1.22!important}.ve-rich-surface h3{font-size:20px!important;line-height:1.28!important}.ve-rich-surface h4{font-size:17px!important;line-height:1.35!important}.ve-rich-surface blockquote{border-left:3px solid #baf400!important;margin:12px 0!important;padding:8px 12px!important;background:rgba(186,244,0,.055)!important;border-radius:0 10px 10px 0!important}.ve-content-seo-editor{border:1px solid rgba(186,244,0,.13)!important;border-radius:14px!important;background:rgba(186,244,0,.025)!important;padding:12px!important;display:grid!important;gap:12px!important}.ve-content-seo-editor summary{cursor:pointer;color:#dfff9b;font-size:11px;font-weight:900;letter-spacing:.02em;text-transform:uppercase}.ve-content-seo-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}.ve-content-seo-grid .wide{grid-column:1/-1}.ve-content-seo-preview{border:1px solid rgba(255,255,255,.07);border-radius:11px;background:rgba(0,0,0,.22);padding:10px;display:grid;gap:4px}.ve-content-seo-preview strong{color:#b7d7ff;font-size:14px;line-height:1.35}.ve-content-seo-preview span{color:#8cd58c;font-size:11px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}.ve-content-seo-preview em{font-style:normal;color:#cfcfcf;font-size:11px;line-height:1.45}.ve-content-field-help-muted{font-size:10px;color:#777;line-height:1.45;margin-top:5px}@media(max-width:980px){.ve-content-form-grid,.ve-content-seo-grid{grid-template-columns:1fr}.ve-content-status-tabs{width:100%!important}.ve-content-studio .ve-studio-table{min-width:760px!important}}


/* v1.3.163 — restore real masonry, writing surface, and Rank Math-style SEO workspace */
.ve-media-masonry{display:grid!important;grid-template-columns:repeat(var(--ve-masonry-columns,5),minmax(0,1fr))!important;gap:12px!important;column-count:auto!important;column-gap:normal!important;overflow:auto!important;align-content:start!important;align-items:start!important;padding:0 10px 10px 0!important}
.ve-media-masonry-col{display:flex!important;flex-direction:column!important;gap:12px!important;min-width:0!important;align-items:stretch!important}
.ve-media-masonry-col>.ve-media-thumb+.ve-media-thumb{margin-top:0!important}.ve-media-masonry .ve-media-thumb{display:block!important;width:100%!important;margin:0!important;height:auto!important;min-height:96px!important;aspect-ratio:auto!important;break-inside:auto!important;overflow:hidden!important}.ve-media-masonry .ve-checker-bg{display:block!important;width:100%!important;height:auto!important;min-height:0!important;overflow:hidden!important}.ve-media-masonry .ve-checker-bg img{display:block!important;width:100%!important;height:auto!important;max-height:none!important;object-fit:contain!important}
.ve-content-edit-form{min-height:0!important;overflow:hidden!important}.ve-content-edit-scroll{overflow:auto!important;min-height:0!important;max-height:none!important}.ve-content-editor-shell{display:block!important;order:20}.ve-content-seo-editor{order:10}.ve-content-custom-fields{order:35}.ve-content-editor-note{order:45}.ve-content-edit-actions{flex-shrink:0!important}.ve-rich-editor{display:block!important}.ve-rich-surface{display:block!important;white-space:normal!important}.ve-rich-surface img{max-width:100%;height:auto}.ve-content-studio .ve-content-edit-scroll>.ve-content-editor-shell{display:block!important}

/* v1.3.164 — masonry row gap + spacious Content Studio edit layout */
.ve-media-masonry{gap:16px!important;column-gap:16px!important;row-gap:16px!important;padding:0 12px 18px 0!important}
.ve-media-masonry-col{display:flex!important;flex-direction:column!important;gap:16px!important;row-gap:16px!important;align-items:stretch!important;min-width:0!important}
.ve-media-masonry-col>.ve-media-thumb{margin:0 0 16px 0!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.035),0 0 0 1px rgba(255,255,255,.045)!important}
.ve-media-masonry-col>.ve-media-thumb:last-child{margin-bottom:0!important}
.ve-media-masonry .ve-checker-bg img{border-radius:10px!important}
.ve-content-studio .ve-studio-main{padding:22px 24px!important}
.ve-content-edit-form{border-radius:18px!important;background:#131313!important;border-color:rgba(255,255,255,.08)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.025)!important}
.ve-content-edit-scroll{padding:24px 28px!important;gap:24px!important;display:flex!important;flex-direction:column!important;max-height:calc(100vh - 230px)!important;min-height:0!important;overflow:auto!important}
.ve-content-meta-panel{order:1;display:grid!important;gap:16px!important;padding:18px!important;border:1px solid rgba(255,255,255,.075)!important;border-radius:16px!important;background:rgba(255,255,255,.018)!important}
.ve-content-field-block{display:grid!important;gap:7px!important;min-width:0!important}
.ve-content-field-block>label{display:block!important;font-size:11px!important;line-height:1.2!important;color:#9a9a9a!important;font-weight:800!important;margin:0!important}
.ve-content-form-grid{grid-template-columns:minmax(0,1fr) 180px!important;gap:16px!important}
.ve-content-editor-shell{order:10!important;border-radius:16px!important;background:#151515!important;border-color:rgba(255,255,255,.085)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.025)!important;overflow:hidden!important}
.ve-content-editor-shell>label{padding:14px 16px!important;background:rgba(255,255,255,.018)!important;border-bottom:1px solid rgba(255,255,255,.065)!important}
.ve-rich-toolbar{padding:10px 12px!important;gap:7px!important;background:#181818!important}
.ve-rich-toolbar button{height:30px!important;min-width:30px!important}
.ve-rich-surface{min-height:440px!important;padding:22px!important;font-size:15px!important;line-height:1.8!important;background:#1d1d1d!important}
.ve-content-seo-editor{order:20!important;border-radius:16px!important;background:rgba(255,255,255,.014)!important;border-color:rgba(255,255,255,.08)!important}
.ve-content-seo-editor summary{padding:15px 17px!important;background:rgba(255,255,255,.02)!important}
.ve-seo-workspace{grid-template-columns:minmax(430px,1fr) minmax(360px,440px)!important;gap:20px!important;padding:18px!important;align-items:start!important}
.ve-seo-fields{gap:14px!important;min-width:0!important}
.ve-seo-side{gap:14px!important;top:12px!important;min-width:0!important}
.ve-seo-tabs{gap:7px!important;padding:4px!important;border:1px solid rgba(255,255,255,.06)!important;border-radius:12px!important;background:rgba(0,0,0,.16)!important;width:max-content!important;max-width:100%!important}
.ve-seo-tabs button{height:32px!important;padding:0 12px!important;border-radius:9px!important}
.ve-seo-fieldset{gap:14px!important;padding:16px!important;border-radius:14px!important;background:rgba(0,0,0,.16)!important}
.ve-seo-field-row{gap:8px!important}
.ve-seo-field-row label{font-size:11px!important}
.ve-seo-keywords{min-height:44px!important;padding:9px!important}
.ve-seo-snippet,.ve-seo-social-card,.ve-seo-analysis{border-radius:15px!important}
.ve-seo-analysis-row{padding:9px 12px!important;font-size:11.5px!important;line-height:1.45!important}
.ve-content-custom-fields{order:30!important;border-radius:15px!important;padding:14px!important}
.ve-content-editor-note{order:40!important;padding:12px 14px!important;border-radius:12px!important;background:rgba(255,255,255,.015)!important;border:1px solid rgba(255,255,255,.06)!important}
.ve-content-edit-actions{padding:15px 24px!important;gap:10px!important;background:rgba(0,0,0,.26)!important}
@media(max-width:1180px){.ve-seo-workspace{grid-template-columns:1fr!important}.ve-seo-side{position:static!important}.ve-content-edit-scroll{padding:18px!important}.ve-content-form-grid{grid-template-columns:1fr!important}}
.ve-content-seo-editor{background:rgba(255,255,255,.016)!important;border-color:rgba(255,255,255,.075)!important;padding:0!important;overflow:hidden!important}.ve-content-seo-editor summary{padding:12px 14px!important;background:rgba(255,255,255,.018)!important;border-bottom:1px solid rgba(255,255,255,.06)!important}.ve-seo-workspace{display:grid!important;grid-template-columns:minmax(0,1.15fr) minmax(300px,.85fr)!important;gap:14px!important;padding:14px!important}.ve-seo-fields{display:grid!important;gap:12px!important}.ve-seo-side{display:grid!important;gap:12px!important;align-content:start!important;position:sticky!important;top:0!important;align-self:start!important}.ve-seo-tabs{display:flex!important;gap:6px!important;flex-wrap:wrap!important}.ve-seo-tabs button{height:30px!important;border:1px solid rgba(255,255,255,.09)!important;border-radius:9px!important;background:rgba(255,255,255,.035)!important;color:#cfcfcf!important;font-size:10px!important;font-weight:850!important;cursor:pointer!important;padding:0 10px!important}.ve-seo-tabs button.active{background:#baf400!important;border-color:#baf400!important;color:#111!important}.ve-seo-fieldset{display:grid!important;gap:10px!important;border:1px solid rgba(255,255,255,.065)!important;border-radius:12px!important;padding:11px!important;background:rgba(0,0,0,.12)!important}.ve-seo-fieldset-title{font-size:10px!important;font-weight:950!important;text-transform:uppercase!important;letter-spacing:.04em!important;color:#dfff9b!important}.ve-seo-field-row{display:grid!important;gap:6px!important}.ve-seo-field-row label{display:flex!important;align-items:center!important;justify-content:space-between!important;font-size:10.5px!important;color:#aaa!important;font-weight:750!important}.ve-seo-count{font-size:10px!important;color:#777!important;font-weight:800!important}.ve-seo-two{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:10px!important}.ve-seo-check-grid{display:grid!important;grid-template-columns:repeat(2,minmax(0,1fr))!important;gap:8px!important}.ve-seo-check-grid label,.ve-seo-checkbox-row{display:flex!important;align-items:center!important;gap:7px!important;font-size:11px!important;color:#d6d6d6!important}.ve-seo-check-grid input,.ve-seo-checkbox-row input{accent-color:#baf400}.ve-seo-keywords{display:flex!important;flex-wrap:wrap!important;gap:6px!important;padding:7px!important;border:1px solid rgba(255,255,255,.10)!important;border-radius:10px!important;background:#202020!important;min-height:38px!important}.ve-seo-keyword-pill{display:inline-flex!important;align-items:center!important;gap:5px!important;height:24px!important;border-radius:999px!important;background:rgba(255,145,145,.18)!important;color:#ffd1d1!important;padding:0 8px!important;font-size:10px!important;font-weight:850!important}.ve-seo-keyword-pill button{border:0!important;background:transparent!important;color:inherit!important;cursor:pointer!important;padding:0!important}.ve-seo-keywords input{flex:1!important;min-width:120px!important;border:0!important;background:transparent!important;color:#f5f5f5!important;outline:none!important;height:24px!important}.ve-seo-snippet{border:1px solid rgba(255,255,255,.075)!important;border-radius:14px!important;background:#101010!important;overflow:hidden!important}.ve-seo-google-search{padding:12px!important;border-bottom:1px solid rgba(255,255,255,.055)!important}.ve-seo-google-bar{height:36px;border-radius:999px;background:#f8f9fa;color:#222;display:flex;align-items:center;padding:0 14px;font-size:13px;box-shadow:0 2px 10px rgba(0,0,0,.20)}.ve-seo-result{padding:13px 14px!important;background:#fff!important;color:#202124!important}.ve-seo-result-url{font-size:12px!important;color:#3c4043!important;margin-bottom:5px!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important}.ve-seo-result-title{font-size:19px!important;line-height:1.25!important;color:#1a0dab!important;margin-bottom:5px!important}.ve-seo-result-desc{font-size:13px!important;line-height:1.45!important;color:#4d5156!important}.ve-seo-social-card{border:1px solid rgba(255,255,255,.08)!important;border-radius:14px!important;background:#181818!important;overflow:hidden!important}.ve-seo-social-head{display:flex!important;align-items:center!important;gap:8px!important;padding:10px 12px!important;border-bottom:1px solid rgba(255,255,255,.06)!important;color:#eaeaea!important;font-weight:850!important}.ve-seo-social-img{aspect-ratio:1.91/1!important;background:#0f0f0f!important;display:flex!important;align-items:center!important;justify-content:center!important;color:#777!important;overflow:hidden!important}.ve-seo-social-img img{width:100%!important;height:100%!important;object-fit:cover!important;display:block!important}.ve-seo-social-body{padding:10px 12px!important;background:#f0f2f5!important;color:#1c1e21!important}.ve-seo-social-domain{font-size:10px!important;text-transform:uppercase!important;color:#65676b!important;margin-bottom:3px!important}.ve-seo-social-title{font-size:14px!important;font-weight:700!important;line-height:1.3!important}.ve-seo-social-desc{font-size:12px!important;color:#65676b!important;line-height:1.35!important;margin-top:3px!important}.ve-seo-analysis{border:1px solid rgba(255,255,255,.075)!important;border-radius:12px!important;background:rgba(255,255,255,.018)!important;overflow:hidden!important}.ve-seo-analysis-title{display:flex!important;align-items:center!important;justify-content:space-between!important;padding:10px 11px!important;border-bottom:1px solid rgba(255,255,255,.055)!important;color:#eee!important;font-size:11px!important;font-weight:900!important}.ve-seo-error-pill{height:20px;border-radius:999px;background:rgba(255,140,140,.23);color:#ffc9c9;display:inline-flex;align-items:center;padding:0 8px;font-size:10px;font-weight:900}.ve-seo-analysis-list{display:grid!important;gap:0!important}.ve-seo-analysis-row{display:grid!important;grid-template-columns:18px 1fr!important;gap:8px!important;padding:8px 11px!important;color:#d8d8d8!important;font-size:11px!important;line-height:1.38!important}.ve-seo-analysis-row.fail i{background:#ff8e8e;color:#311}.ve-seo-analysis-row.pass i{background:#baf400;color:#111}.ve-seo-analysis-row i{width:16px;height:16px;border-radius:50%;display:inline-flex;align-items:center;justify-content:center;font-style:normal;font-size:10px;font-weight:900}.ve-seo-muted-note{font-size:10px!important;color:#777!important;line-height:1.45!important}.ve-seo-premium-lock{opacity:.6;filter:saturate(.7)}.ve-seo-media-actions{display:flex!important;gap:6px!important;align-items:center!important}.ve-seo-media-actions .ve-btn{height:30px!important;min-height:30px!important;font-size:10px!important}@media(max-width:1100px){.ve-seo-workspace{grid-template-columns:1fr!important}.ve-seo-side{position:static!important}.ve-seo-two,.ve-seo-check-grid{grid-template-columns:1fr!important}}

/* v1.3.164 final overrides — keep spacious layout after SEO block */
.ve-media-masonry{gap:16px!important;column-gap:16px!important;row-gap:16px!important;padding:0 12px 18px 0!important}
.ve-media-masonry-col{display:flex!important;flex-direction:column!important;gap:16px!important;row-gap:16px!important;align-items:stretch!important;min-width:0!important}
.ve-media-masonry-col>.ve-media-thumb{margin:0 0 16px 0!important}
.ve-media-masonry-col>.ve-media-thumb:last-child{margin-bottom:0!important}
.ve-content-edit-scroll{padding:24px 28px!important;gap:24px!important;display:flex!important;flex-direction:column!important;max-height:calc(100vh - 230px)!important;min-height:0!important;overflow:auto!important}
.ve-content-meta-panel{order:1!important;display:grid!important;gap:16px!important;padding:18px!important;border:1px solid rgba(255,255,255,.075)!important;border-radius:16px!important;background:rgba(255,255,255,.018)!important}
.ve-content-field-block{display:grid!important;gap:7px!important;min-width:0!important}.ve-content-field-block>label{display:block!important;font-size:11px!important;line-height:1.2!important;color:#9a9a9a!important;font-weight:800!important;margin:0!important}
.ve-content-form-grid{grid-template-columns:minmax(0,1fr) 180px!important;gap:16px!important}
.ve-content-editor-shell{order:10!important;border-radius:16px!important;background:#151515!important;border-color:rgba(255,255,255,.085)!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.025)!important;overflow:hidden!important}.ve-content-editor-shell>label{padding:14px 16px!important;background:rgba(255,255,255,.018)!important;border-bottom:1px solid rgba(255,255,255,.065)!important}.ve-rich-toolbar{padding:10px 12px!important;gap:7px!important;background:#181818!important}.ve-rich-toolbar button{height:30px!important;min-width:30px!important}.ve-rich-surface{min-height:440px!important;padding:22px!important;font-size:15px!important;line-height:1.8!important;background:#1d1d1d!important}
.ve-content-seo-editor{order:20!important;border-radius:16px!important;background:rgba(255,255,255,.014)!important;border-color:rgba(255,255,255,.08)!important;padding:0!important}.ve-content-seo-editor summary{padding:15px 17px!important;background:rgba(255,255,255,.02)!important}
.ve-seo-workspace{grid-template-columns:minmax(430px,1fr) minmax(360px,440px)!important;gap:20px!important;padding:18px!important;align-items:start!important}.ve-seo-fields{gap:14px!important;min-width:0!important}.ve-seo-side{gap:14px!important;top:12px!important;min-width:0!important}.ve-seo-tabs{gap:7px!important;padding:4px!important;border:1px solid rgba(255,255,255,.06)!important;border-radius:12px!important;background:rgba(0,0,0,.16)!important;width:max-content!important;max-width:100%!important}.ve-seo-tabs button{height:32px!important;padding:0 12px!important;border-radius:9px!important}.ve-seo-fieldset{gap:14px!important;padding:16px!important;border-radius:14px!important;background:rgba(0,0,0,.16)!important}.ve-seo-field-row{gap:8px!important}.ve-seo-field-row label{font-size:11px!important}.ve-seo-keywords{min-height:44px!important;padding:9px!important}.ve-seo-analysis-row{padding:9px 12px!important;font-size:11.5px!important;line-height:1.45!important}
.ve-content-custom-fields{order:30!important;border-radius:15px!important;padding:14px!important}.ve-content-editor-note{order:40!important;padding:12px 14px!important;border-radius:12px!important;background:rgba(255,255,255,.015)!important;border:1px solid rgba(255,255,255,.06)!important}.ve-content-edit-actions{padding:15px 24px!important;gap:10px!important;background:rgba(0,0,0,.26)!important}
@media(max-width:1180px){.ve-seo-workspace{grid-template-columns:1fr!important}.ve-seo-side{position:static!important}.ve-content-edit-scroll{padding:18px!important}.ve-content-form-grid{grid-template-columns:1fr!important}}

/* v1.3.165 — equal masonry gaps + true Content Studio edit scroll */
.ve-media-masonry{
  --ve-media-masonry-gap:18px!important;
  gap:var(--ve-media-masonry-gap)!important;
  column-gap:var(--ve-media-masonry-gap)!important;
  row-gap:var(--ve-media-masonry-gap)!important;
  padding:0 12px 18px 0!important;
  align-items:start!important;
}
.ve-media-masonry-col{
  display:flex!important;
  flex-direction:column!important;
  gap:var(--ve-media-masonry-gap)!important;
  row-gap:var(--ve-media-masonry-gap)!important;
  align-items:stretch!important;
  min-width:0!important;
}
.ve-media-masonry-col>.ve-media-thumb,
.ve-media-masonry-col>.ve-media-thumb:last-child{
  margin:0!important;
}
.ve-media-masonry .ve-media-thumb{
  border-radius:12px!important;
}
.ve-media-masonry .ve-checker-bg,
.ve-media-masonry .ve-checker-bg img{
  border-radius:11px!important;
}
.ve-content-studio.ve-studio-layout,
.ve-content-studio .ve-studio-main{
  min-height:0!important;
  height:100%!important;
  overflow:hidden!important;
}
.ve-content-studio .ve-studio-main{
  gap:14px!important;
}
.ve-content-edit-form{
  display:flex!important;
  flex-direction:column!important;
  flex:1 1 auto!important;
  min-height:0!important;
  height:100%!important;
  max-height:100%!important;
  overflow:hidden!important;
}
.ve-content-edit-scroll{
  flex:1 1 auto!important;
  min-height:0!important;
  max-height:none!important;
  height:auto!important;
  overflow-y:auto!important;
  overflow-x:hidden!important;
  padding:22px 26px 28px!important;
  gap:22px!important;
  display:flex!important;
  flex-direction:column!important;
}
.ve-content-edit-actions{
  flex:0 0 auto!important;
  position:relative!important;
  bottom:auto!important;
  z-index:2!important;
}
.ve-content-meta-panel,
.ve-content-editor-shell,
.ve-content-seo-editor,
.ve-content-custom-fields,
.ve-content-editor-note{
  flex:0 0 auto!important;
}
.ve-content-editor-shell{
  min-height:auto!important;
}
.ve-rich-editor{
  display:flex!important;
  flex-direction:column!important;
}
.ve-rich-surface{
  min-height:360px!important;
  max-height:none!important;
}
.ve-content-seo-editor[open] .ve-seo-workspace{
  min-height:360px!important;
}
.ve-content-editor-note{
  margin-bottom:4px!important;
}
@media(max-width:1180px){
  .ve-content-edit-scroll{padding:18px!important;gap:18px!important}
  .ve-content-studio .ve-studio-main{gap:12px!important}
}


/* v1.3.166 — Content Studio split editor, MV media picker, rich editor polish, SVG previews */
.ve-media-masonry{
  --ve-media-masonry-gap:16px!important;
  display:grid!important;
  grid-template-columns:repeat(var(--ve-masonry-columns,5),minmax(0,1fr))!important;
  gap:var(--ve-media-masonry-gap)!important;
  column-gap:var(--ve-media-masonry-gap)!important;
  row-gap:var(--ve-media-masonry-gap)!important;
  padding:0 14px 18px 0!important;
}
.ve-media-masonry-col{gap:var(--ve-media-masonry-gap)!important;row-gap:var(--ve-media-masonry-gap)!important}
.ve-media-masonry-col>.ve-media-thumb{margin:0!important}
.ve-media-masonry .ve-media-thumb{background:transparent!important;box-shadow:none!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-checker-bg,
.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-svg-preview-bg,
.ve-content-media-choice.ve-media-is-svg .ve-content-media-choice-img{background:transparent!important;box-shadow:none!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-checker-bg{overflow:hidden!important;border:1px solid rgba(255,255,255,.055)!important;border-radius:12px!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg img.ve-svg-preview-img{display:block!important;width:100%!important;height:auto!important;background:transparent!important;object-fit:contain!important}
.ve-content-studio .ve-content-edit-scroll{
  display:grid!important;
  grid-template-columns:minmax(300px,420px) minmax(0,1fr)!important;
  grid-auto-rows:max-content!important;
  align-content:start!important;
  gap:22px!important;
  overflow-y:auto!important;
  padding:24px 28px 30px!important;
}
.ve-content-studio .ve-content-meta-panel{grid-column:1!important;grid-row:1!important;position:sticky!important;top:0!important;z-index:3!important;align-self:start!important;max-height:calc(100vh - 260px)!important;overflow:auto!important}
.ve-content-studio .ve-content-editor-shell{grid-column:2!important;grid-row:1!important;min-height:560px!important;display:flex!important;flex-direction:column!important}
.ve-content-studio .ve-content-seo-editor,
.ve-content-studio .ve-content-custom-fields,
.ve-content-studio .ve-content-editor-note{grid-column:1 / -1!important}
.ve-content-studio .ve-content-form-grid{grid-template-columns:1fr!important;gap:14px!important}
.ve-content-studio .ve-content-meta-panel textarea{min-height:170px!important}
.ve-rich-editor{position:relative!important;min-height:0!important;flex:1 1 auto!important;border-radius:0 0 16px 16px!important;overflow:hidden!important}
.ve-rich-toolbar{display:flex!important;align-items:center!important;gap:7px!important;flex-wrap:wrap!important}
.ve-rich-spacer{flex:1 1 auto!important;min-width:20px!important}
.ve-rich-toolbar .ve-rich-theme-toggle{height:30px!important;min-width:46px!important;border:1px solid rgba(186,244,0,.25)!important;border-radius:9px!important;background:rgba(186,244,0,.08)!important;color:#dfff9b!important;font-size:10px!important;font-weight:900!important;padding:0 10px!important;cursor:pointer!important}
.ve-rich-toolbar .ve-rich-theme-toggle:hover{background:#baf400!important;color:#111!important}
.ve-rich-editor-light .ve-rich-surface{background:#f6f6f3!important;color:#171717!important;text-shadow:none!important}
.ve-rich-editor-light .ve-rich-surface,
.ve-rich-editor-light .ve-rich-surface p,
.ve-rich-editor-light .ve-rich-surface li,
.ve-rich-editor-light .ve-rich-surface blockquote{color:#171717!important}
.ve-rich-editor-light .ve-rich-surface h1,
.ve-rich-editor-light .ve-rich-surface h2,
.ve-rich-editor-light .ve-rich-surface h3,
.ve-rich-editor-light .ve-rich-surface h4,
.ve-rich-editor-light .ve-rich-surface h5,
.ve-rich-editor-light .ve-rich-surface h6{color:#090909!important}
.ve-rich-editor-light .ve-rich-surface:empty:before{color:#777!important}
.ve-rich-inline-dialog{position:absolute!important;inset:0!important;z-index:8!important;display:flex!important;align-items:center!important;justify-content:center!important;background:rgba(0,0,0,.54)!important;backdrop-filter:blur(2px)!important}
.ve-rich-inline-dialog-card{width:min(360px,calc(100% - 40px))!important;border:1px solid rgba(255,255,255,.12)!important;border-radius:14px!important;background:#242428!important;box-shadow:0 24px 70px rgba(0,0,0,.55)!important;padding:16px!important;display:grid!important;gap:12px!important;color:#fff!important}
.ve-rich-inline-dialog-card strong{font-size:12px!important;color:#fff!important}
.ve-rich-inline-dialog-actions{display:flex!important;justify-content:flex-end!important;gap:8px!important}.ve-rich-inline-dialog-actions .ve-btn{height:32px!important;min-height:32px!important}
.ve-content-media-picker{position:absolute!important;inset:0!important;z-index:80!important;display:flex!important;align-items:center!important;justify-content:center!important;background:rgba(0,0,0,.55)!important;backdrop-filter:blur(3px)!important}
.ve-content-media-picker-card{width:min(980px,calc(100% - 72px))!important;height:min(720px,calc(100% - 70px))!important;border:1px solid rgba(255,255,255,.11)!important;border-radius:18px!important;background:#151515!important;box-shadow:0 30px 90px rgba(0,0,0,.62)!important;display:flex!important;flex-direction:column!important;overflow:hidden!important;color:#f2f2f2!important}
.ve-content-media-picker-head{height:54px!important;display:flex!important;align-items:center!important;justify-content:space-between!important;gap:12px!important;padding:0 16px!important;border-bottom:1px solid rgba(255,255,255,.075)!important}.ve-content-media-picker-head strong{display:block!important;font-size:13px!important}.ve-content-media-picker-head span{display:block!important;font-size:10px!important;color:#8a8a8a!important;margin-top:2px!important}
.ve-content-media-picker-toolbar{padding:12px 16px!important;display:flex!important;gap:10px!important;border-bottom:1px solid rgba(255,255,255,.06)!important}.ve-content-media-picker-toolbar .ve-studio-input{height:36px!important;min-height:36px!important;flex:1!important}
.ve-content-media-picker-grid{flex:1!important;min-height:0!important;overflow:auto!important;padding:16px!important;display:grid!important;grid-template-columns:repeat(auto-fill,minmax(130px,1fr))!important;gap:12px!important;align-content:start!important}
.ve-content-media-choice{border:1px solid rgba(255,255,255,.075)!important;border-radius:13px!important;background:#1d1d1d!important;color:#eee!important;padding:0!important;overflow:hidden!important;text-align:left!important;cursor:pointer!important;display:grid!important;grid-template-rows:120px auto!important}.ve-content-media-choice:hover{border-color:rgba(186,244,0,.45)!important;box-shadow:0 0 0 1px rgba(186,244,0,.20)!important}.ve-content-media-choice-img{display:flex!important;align-items:center!important;justify-content:center!important;background:#101010!important;overflow:hidden!important}.ve-content-media-choice-img img{width:100%!important;height:100%!important;object-fit:contain!important;display:block!important}.ve-content-media-choice-title{font-size:10.5px!important;font-weight:750!important;padding:9px!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important}.ve-content-media-picker-empty{grid-column:1/-1!important;min-height:220px!important;display:flex!important;align-items:center!important;justify-content:center!important;color:#888!important;border:1px dashed rgba(255,255,255,.09)!important;border-radius:14px!important}
.ve-seo-keywords{min-height:36px!important;padding:5px 7px!important;gap:5px!important;border-radius:10px!important}.ve-seo-keywords input{height:26px!important;min-height:26px!important;line-height:26px!important;padding:0 4px!important}.ve-seo-keyword-pill{height:24px!important;font-size:10px!important}.ve-seo-media-actions .ve-studio-input{height:36px!important;min-height:36px!important}.ve-seo-media-actions .ve-btn{height:36px!important;min-height:36px!important}
@media(max-width:1180px){.ve-content-studio .ve-content-edit-scroll{grid-template-columns:1fr!important}.ve-content-studio .ve-content-meta-panel,.ve-content-studio .ve-content-editor-shell,.ve-content-studio .ve-content-seo-editor,.ve-content-studio .ve-content-custom-fields,.ve-content-studio .ve-content-editor-note{grid-column:1!important;grid-row:auto!important;position:static!important;max-height:none!important}.ve-content-media-picker-card{width:calc(100% - 32px)!important;height:calc(100% - 40px)!important}.ve-content-media-picker-grid{grid-template-columns:repeat(auto-fill,minmax(110px,1fr))!important}}


/* v1.3.167 — Content Studio layout cleanup, SVG masonry sizing, picker/editor polish */
.ve-content-studio{--ve-cs-radius:12px;--ve-cs-radius-lg:14px;--ve-cs-gap:18px}
.ve-content-studio .ve-studio-input,
.ve-content-studio .ve-studio-select,
.ve-content-studio .ve-btn,
.ve-content-studio .ve-content-meta-panel,
.ve-content-studio .ve-content-editor-shell,
.ve-content-studio .ve-content-seo-editor,
.ve-content-studio .ve-content-custom-fields,
.ve-content-studio .ve-content-editor-note,
.ve-content-media-picker-card,
.ve-content-media-choice,
.ve-content-media-choice-img{border-radius:var(--ve-cs-radius)!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg{
  width:auto!important;
  max-width:100%!important;
  min-width:0!important;
  min-height:0!important;
  height:auto!important;
  align-self:flex-start!important;
  justify-self:start!important;
  display:inline-block!important;
  line-height:0!important;
  padding:0!important;
  background:transparent!important;
  overflow:visible!important;
  aspect-ratio:auto!important;
}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-checker-bg,
.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-svg-preview-bg{
  width:auto!important;
  max-width:100%!important;
  min-width:0!important;
  height:auto!important;
  min-height:0!important;
  display:inline-flex!important;
  line-height:0!important;
  background:transparent!important;
  border-radius:12px!important;
  overflow:hidden!important;
}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg img.ve-svg-preview-img{
  width:auto!important;
  max-width:100%!important;
  height:auto!important;
  max-height:none!important;
  display:block!important;
  object-fit:contain!important;
  background:transparent!important;
}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-media-meta-hover{line-height:1.25!important}
.ve-content-studio .ve-content-edit-form{
  padding:0!important;
  border-radius:16px!important;
  background:#141414!important;
  border:1px solid rgba(255,255,255,.075)!important;
  overflow:hidden!important;
}
.ve-content-studio .ve-content-edit-scroll{
  display:grid!important;
  grid-template-columns:minmax(0,1fr) minmax(320px,400px)!important;
  grid-auto-rows:max-content!important;
  align-items:start!important;
  align-content:start!important;
  gap:24px!important;
  padding:24px 28px 28px!important;
  overflow-y:auto!important;
  overflow-x:hidden!important;
  max-height:none!important;
  height:auto!important;
}
.ve-content-studio .ve-content-editor-shell{
  grid-column:1!important;
  grid-row:1!important;
  min-height:520px!important;
  display:flex!important;
  flex-direction:column!important;
  position:relative!important;
  z-index:1!important;
  overflow:hidden!important;
}
.ve-content-studio .ve-content-meta-panel{
  grid-column:2!important;
  grid-row:1!important;
  position:static!important;
  top:auto!important;
  z-index:1!important;
  align-self:start!important;
  max-height:none!important;
  overflow:visible!important;
  padding:16px!important;
  gap:14px!important;
}
.ve-content-studio .ve-content-seo-editor,
.ve-content-studio .ve-content-custom-fields,
.ve-content-studio .ve-content-editor-note{
  grid-column:1 / -1!important;
  grid-row:auto!important;
  position:relative!important;
}
.ve-content-studio .ve-content-form-grid{grid-template-columns:1fr!important;gap:14px!important}
.ve-content-studio .ve-content-meta-panel textarea{min-height:150px!important}
.ve-content-studio .ve-content-editor-shell>label{
  height:46px!important;
  padding:0 16px!important;
  display:flex!important;
  align-items:center!important;
  justify-content:space-between!important;
  border-bottom:1px solid rgba(255,255,255,.065)!important;
  background:rgba(255,255,255,.018)!important;
}
.ve-rich-editor{
  flex:1 1 auto!important;
  display:flex!important;
  flex-direction:column!important;
  border-radius:0!important;
  min-height:0!important;
  overflow:hidden!important;
}
.ve-rich-toolbar{
  min-height:52px!important;
  padding:10px 14px!important;
  display:grid!important;
  grid-template-columns:minmax(0,1fr) auto minmax(0,1fr)!important;
  align-items:center!important;
  gap:12px!important;
  background:#171717!important;
  border-bottom:1px solid rgba(255,255,255,.07)!important;
}
.ve-rich-tool-group{display:flex!important;align-items:center!important;gap:6px!important;min-width:0!important;flex-wrap:wrap!important}
.ve-rich-tool-group-left{justify-content:flex-start!important}
.ve-rich-tool-group-center{justify-content:center!important;flex-wrap:nowrap!important}
.ve-rich-tool-group-right{justify-content:flex-end!important;flex-wrap:nowrap!important}
.ve-rich-toolbar .ve-rich-spacer{display:none!important}
.ve-rich-toolbar .ve-rich-sep{flex:0 0 1px!important;width:1px!important;height:22px!important;background:rgba(255,255,255,.09)!important;margin:0 2px!important}
.ve-rich-toolbar button{border-radius:10px!important;height:32px!important;min-height:32px!important}
.ve-rich-theme-toggle{display:none!important}
.ve-rich-theme-switch{
  width:70px!important;
  min-width:70px!important;
  height:32px!important;
  padding:0 8px!important;
  border-radius:999px!important;
  display:inline-flex!important;
  align-items:center!important;
  justify-content:space-between!important;
  gap:6px!important;
  background:rgba(255,255,255,.05)!important;
  color:#cfcfcf!important;
  border:1px solid rgba(255,255,255,.11)!important;
}
.ve-rich-theme-switch[aria-checked="true"]{background:rgba(186,244,0,.12)!important;border-color:rgba(186,244,0,.34)!important;color:#dfff9b!important}
.ve-rich-theme-track{width:28px!important;height:16px!important;border-radius:999px!important;background:rgba(255,255,255,.14)!important;display:inline-flex!important;align-items:center!important;padding:2px!important;box-sizing:border-box!important;transition:background .14s!important}
.ve-rich-theme-track i{width:12px!important;height:12px!important;border-radius:999px!important;background:#aaa!important;display:block!important;transition:transform .14s,background .14s!important}
.ve-rich-theme-switch[aria-checked="true"] .ve-rich-theme-track{background:#baf400!important}
.ve-rich-theme-switch[aria-checked="true"] .ve-rich-theme-track i{background:#111!important;transform:translateX(12px)!important}
.ve-rich-theme-switch em{font-style:normal!important;font-size:10px!important;font-weight:900!important;line-height:1!important}
.ve-rich-surface{
  flex:1 1 auto!important;
  min-height:420px!important;
  max-height:none!important;
  padding:24px!important;
  border-radius:0!important;
  overflow:auto!important;
}
.ve-seo-keywords{
  min-height:42px!important;
  padding:5px 8px!important;
  gap:6px!important;
  align-items:center!important;
  border-radius:12px!important;
}
.ve-seo-keyword-pill{
  height:32px!important;
  min-height:32px!important;
  display:inline-flex!important;
  align-items:center!important;
  border-radius:999px!important;
  padding:0 10px!important;
  line-height:1!important;
}
.ve-seo-keyword-pill button{height:20px!important;width:20px!important;min-width:20px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important}
.ve-seo-keywords input{
  height:32px!important;
  min-height:32px!important;
  line-height:32px!important;
  padding:0 4px!important;
}
.ve-content-media-picker{z-index:180!important;background:rgba(0,0,0,.68)!important;backdrop-filter:blur(4px)!important}
.ve-content-media-picker-card{
  width:min(1120px,calc(100% - 70px))!important;
  height:min(760px,calc(100% - 70px))!important;
  border-radius:16px!important;
  background:#131313!important;
}
.ve-content-media-picker-head{height:58px!important;padding:0 18px!important;background:#111!important}
.ve-content-media-picker-toolbar{padding:14px 18px!important;background:#151515!important}
.ve-content-media-picker-grid{
  padding:18px!important;
  grid-template-columns:repeat(auto-fill,minmax(148px,1fr))!important;
  gap:14px!important;
}
.ve-content-media-choice{
  min-height:168px!important;
  height:auto!important;
  display:flex!important;
  flex-direction:column!important;
  border-radius:13px!important;
  background:#191919!important;
  overflow:hidden!important;
}
.ve-content-media-choice-img{
  flex:0 0 126px!important;
  height:126px!important;
  min-height:126px!important;
  border-radius:12px 12px 0 0!important;
  background:#101010!important;
}
.ve-content-media-choice-img img{width:100%!important;height:100%!important;object-fit:contain!important;display:block!important}
.ve-content-media-choice-title{min-height:36px!important;display:flex!important;align-items:center!important;padding:0 10px!important;background:rgba(255,255,255,.018)!important}
.ve-content-edit-actions{
  background:#141414!important;
  border-top:1px solid rgba(255,255,255,.07)!important;
  box-shadow:inset 0 1px 0 rgba(255,255,255,.025)!important;
  padding:14px 24px!important;
  gap:10px!important;
}
.ve-content-edit-actions .ve-btn{border-radius:10px!important}
@media(max-width:1180px){
  .ve-content-studio .ve-content-edit-scroll{grid-template-columns:1fr!important;padding:18px!important;gap:18px!important}
  .ve-content-studio .ve-content-meta-panel,
  .ve-content-studio .ve-content-editor-shell,
  .ve-content-studio .ve-content-seo-editor,
  .ve-content-studio .ve-content-custom-fields,
  .ve-content-studio .ve-content-editor-note{grid-column:1!important;grid-row:auto!important;position:static!important;max-height:none!important}
  .ve-rich-toolbar{grid-template-columns:1fr!important}
  .ve-rich-tool-group,.ve-rich-tool-group-left,.ve-rich-tool-group-center,.ve-rich-tool-group-right{justify-content:flex-start!important;flex-wrap:wrap!important}
}


/* v1.3.169 — picker collections, SEO checks, editor/masonry cleanup */
.ve-media-masonry{--ve-masonry-gap:12px!important;column-gap:var(--ve-masonry-gap)!important;gap:var(--ve-masonry-gap)!important}
.ve-media-masonry .ve-media-masonry-col{gap:var(--ve-masonry-gap)!important}
.ve-media-masonry .ve-media-thumb{margin:0 0 var(--ve-masonry-gap) 0!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg{width:100%!important;max-width:100%!important;display:block!important;overflow:hidden!important;background:transparent!important;line-height:0!important;border-radius:12px!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-checker-bg,.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-svg-preview-bg{width:100%!important;max-width:100%!important;display:block!important;height:auto!important;min-height:0!important;background:transparent!important;overflow:hidden!important;line-height:0!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg img.ve-svg-preview-img{width:100%!important;height:auto!important;max-width:100%!important;display:block!important;object-fit:contain!important;background:transparent!important}
.ve-content-studio .ve-content-edit-scroll{grid-template-columns:minmax(560px,1fr) minmax(300px,390px)!important;grid-auto-rows:auto!important;position:relative!important;isolation:isolate!important;overflow-y:auto!important;overflow-x:hidden!important}
.ve-content-studio .ve-content-editor-shell{grid-column:1!important;grid-row:1!important;z-index:1!important;min-width:0!important;contain:layout paint!important}
.ve-content-studio .ve-content-meta-panel{grid-column:2!important;grid-row:1!important;z-index:1!important;min-width:0!important;contain:layout paint!important;overflow:visible!important}
.ve-content-studio .ve-content-seo-editor{grid-column:1 / -1!important;grid-row:2!important;z-index:1!important;contain:layout paint!important;background:#171717!important;border-color:rgba(255,255,255,.085)!important}
.ve-content-studio .ve-content-custom-fields{grid-column:1 / -1!important;grid-row:auto!important}.ve-content-studio .ve-content-editor-note{grid-column:1 / -1!important;grid-row:auto!important}
.ve-rich-toolbar{grid-template-columns:minmax(0,1fr) auto minmax(0,1fr)!important;align-items:start!important}
.ve-rich-tool-group-left{justify-content:flex-start!important}.ve-rich-tool-group-center{justify-content:center!important;align-self:start!important;flex-wrap:nowrap!important}.ve-rich-tool-group-right{justify-content:flex-end!important;align-self:start!important;flex-wrap:nowrap!important}
.ve-rich-toolbar .ve-rich-theme-switch{width:46px!important;min-width:46px!important;height:28px!important;padding:2px!important;border-radius:999px!important;background:#242424!important;border:1px solid rgba(255,255,255,.12)!important;color:#aaa!important;display:inline-flex!important;align-items:center!important;justify-content:space-between!important;gap:2px!important}
.ve-rich-toolbar .ve-rich-theme-switch>i{font-size:12px!important;line-height:1!important;width:14px!important;height:14px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;opacity:.76!important}
.ve-rich-theme-track{width:20px!important;height:14px!important;background:rgba(255,255,255,.14)!important;padding:2px!important}.ve-rich-theme-track i{width:10px!important;height:10px!important}.ve-rich-theme-switch[aria-checked="true"]{background:rgba(186,244,0,.16)!important;border-color:rgba(186,244,0,.44)!important;color:#baf400!important}.ve-rich-theme-switch[aria-checked="true"] .ve-rich-theme-track i{transform:translateX(6px)!important}
.ve-rich-surface pre{display:block!important;margin:14px 0!important;padding:14px 16px!important;border-radius:12px!important;border:1px solid rgba(186,244,0,.18)!important;background:#101010!important;color:#e8e8e8!important;font:12px/1.7 'SF Mono','Fira Code','JetBrains Mono',Consolas,monospace!important;white-space:pre-wrap!important;overflow:auto!important}.ve-rich-surface code{border-radius:6px!important;background:rgba(186,244,0,.12)!important;color:#dfff9b!important;padding:.12em .35em!important;font-family:'SF Mono','Fira Code',Consolas,monospace!important}.ve-rich-editor-light .ve-rich-surface pre{background:#ededeb!important;color:#171717!important;border-color:#d8d8d2!important}.ve-rich-editor-light .ve-rich-surface code{background:#e9f5c5!important;color:#222!important}
.ve-seo-fieldset{background:#1a1a1a!important;border-color:rgba(255,255,255,.085)!important}.ve-seo-snippet{background:#181818!important}.ve-seo-keywords{min-height:42px!important;padding:5px 7px!important;align-items:center!important;background:#1f1f1f!important}.ve-seo-keyword-pill{height:32px!important;min-height:32px!important;display:inline-flex!important;align-items:center!important;gap:7px!important;padding:0 11px!important;border-radius:999px!important;background:rgba(255,151,151,.22)!important;color:#fff!important;font-size:10.5px!important;font-weight:900!important;line-height:1!important;text-shadow:0 1px 1px rgba(0,0,0,.2)!important}.ve-seo-keyword-pill button{width:18px!important;height:18px!important;min-width:18px!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;border-radius:999px!important;color:#fff!important;opacity:.92!important}.ve-seo-keyword-pill em{color:#fff!important;opacity:.96!important}.ve-seo-keywords input{height:32px!important;line-height:32px!important;padding:0 4px!important;align-self:center!important}
.ve-seo-analysis-row.pass{color:#dfff9b!important}.ve-seo-analysis-row.fail{color:#e7e7e7!important}.ve-seo-analysis-row.pass i{background:#baf400!important;color:#111!important}.ve-seo-analysis-row.fail i{background:#ff8e8e!important;color:#311!important}
.ve-content-media-picker-card-studio{width:min(1180px,calc(100% - 64px))!important;height:min(780px,calc(100% - 64px))!important}.ve-content-media-picker-body{flex:1!important;min-height:0!important;display:grid!important;grid-template-columns:230px minmax(0,1fr)!important;overflow:hidden!important}.ve-content-media-picker-sidebar{border-right:1px solid rgba(255,255,255,.075)!important;background:#111!important;padding:12px!important;display:flex!important;flex-direction:column!important;gap:5px!important;overflow:auto!important}.ve-content-picker-collection{width:100%!important;min-height:34px!important;border:1px solid transparent!important;border-radius:10px!important;background:transparent!important;color:#d8d8d8!important;display:grid!important;grid-template-columns:18px minmax(0,1fr) auto!important;align-items:center!important;gap:7px!important;padding:6px 8px!important;text-align:left!important;cursor:pointer!important}.ve-content-picker-collection:hover{background:rgba(255,255,255,.035)!important}.ve-content-picker-collection.active{background:rgba(186,244,0,.14)!important;border-color:rgba(186,244,0,.32)!important;color:#dfff9b!important}.ve-content-picker-collection svg,.ve-content-picker-collection i{width:15px!important;height:15px!important;color:#baf400!important}.ve-content-picker-collection span{overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important}.ve-content-picker-collection em{font-style:normal!important;color:#999!important;font-size:10px!important;background:rgba(255,255,255,.06)!important;border-radius:999px!important;padding:2px 6px!important}.ve-content-media-picker-main{display:flex!important;flex-direction:column!important;min-width:0!important;min-height:0!important}.ve-content-media-picker-toolbar{flex:0 0 auto!important;align-items:center!important}.ve-content-picker-viewbar{display:flex!important;align-items:center!important;gap:4px!important;padding:3px!important;border:1px solid rgba(255,255,255,.08)!important;border-radius:10px!important;background:rgba(0,0,0,.16)!important}.ve-content-picker-viewbar button{width:30px!important;height:30px!important;border:0!important;border-radius:8px!important;background:transparent!important;color:#aaa!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;cursor:pointer!important}.ve-content-picker-viewbar button.active{background:#baf400!important;color:#111!important}.ve-content-media-picker-masonry{display:flex!important;align-items:flex-start!important;gap:12px!important}.ve-content-picker-masonry-col{flex:1 1 0!important;min-width:0!important;display:flex!important;flex-direction:column!important;gap:12px!important}.ve-content-media-picker-masonry .ve-content-media-choice{min-height:0!important;height:auto!important;display:block!important}.ve-content-media-picker-masonry .ve-content-media-choice-img{height:auto!important;min-height:0!important;flex:0 0 auto!important;display:block!important;background:#101010!important}.ve-content-media-picker-masonry .ve-content-media-choice-img img{width:100%!important;height:auto!important;display:block!important;object-fit:contain!important}.ve-content-media-picker-list{flex:1!important;min-height:0!important;overflow:auto!important;padding:12px 18px!important;display:flex!important;flex-direction:column!important;gap:6px!important}.ve-content-media-list-row{min-height:48px!important;border:1px solid rgba(255,255,255,.075)!important;border-radius:12px!important;background:#1a1a1a!important;color:#eee!important;display:grid!important;grid-template-columns:42px minmax(0,1fr) auto!important;gap:10px!important;align-items:center!important;padding:5px 10px!important;text-align:left!important;cursor:pointer!important}.ve-content-media-list-row:hover{border-color:rgba(186,244,0,.38)!important}.ve-content-media-list-row img{width:42px!important;height:38px!important;object-fit:contain!important;border-radius:8px!important;background:#101010!important}.ve-content-media-list-row strong{overflow:hidden!important;text-overflow:ellipsis!important;white-space:nowrap!important;font-size:11px!important}.ve-content-media-list-row em{font-style:normal!important;color:#888!important;font-size:10px!important}
@media(max-width:1180px){.ve-rich-toolbar{grid-template-columns:minmax(0,1fr) auto minmax(0,1fr)!important}.ve-rich-tool-group-left{justify-content:flex-start!important}.ve-rich-tool-group-center{justify-content:center!important;flex-wrap:nowrap!important}.ve-rich-tool-group-right{justify-content:flex-end!important;flex-wrap:nowrap!important}.ve-content-studio .ve-content-edit-scroll{grid-template-columns:1fr!important}.ve-content-studio .ve-content-editor-shell{grid-column:1!important;grid-row:1!important}.ve-content-studio .ve-content-meta-panel{grid-column:1!important;grid-row:2!important}.ve-content-studio .ve-content-seo-editor{grid-column:1!important;grid-row:3!important}.ve-content-media-picker-body{grid-template-columns:1fr!important}.ve-content-media-picker-sidebar{max-height:120px!important;border-right:0!important;border-bottom:1px solid rgba(255,255,255,.075)!important;flex-direction:row!important;overflow:auto!important}.ve-content-picker-collection{min-width:160px!important}}

/* v1.3.169 visual regression cleanup */
.ve-media-masonry{--ve-media-masonry-gap:12px!important;column-gap:var(--ve-media-masonry-gap)!important;padding-right:10px!important}
.ve-media-masonry .ve-media-thumb{margin:0 0 var(--ve-media-masonry-gap) 0!important;min-height:0!important;padding:0!important;box-sizing:border-box!important}
.ve-media-masonry .ve-media-thumb .ve-checker-bg{min-height:0!important;height:auto!important;padding:0!important;background:transparent!important;border-radius:12px!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg{min-height:0!important;background:transparent!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-checker-bg{background:transparent!important;border:0!important;box-shadow:none!important;display:flex!important;align-items:flex-start!important;justify-content:center!important;width:100%!important;height:auto!important;overflow:hidden!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg img{width:100%!important;height:auto!important;display:block!important;object-fit:contain!important;background:transparent!important}
.ve-media-masonry .ve-media-thumb .ve-font-file-card,.ve-media-masonry .ve-media-thumb .ve-file-card{min-height:112px!important;height:auto!important}
.ve-content-studio .ve-content-edit-scroll{display:grid!important;grid-template-columns:minmax(0,1fr) minmax(280px,360px)!important;align-content:start!important;gap:16px!important;padding:18px 18px 24px!important;overflow-y:auto!important;overflow-x:hidden!important}
.ve-content-studio .ve-content-editor-shell{grid-column:1!important;grid-row:1!important;min-width:0!important;border-radius:16px!important;align-self:start!important}
.ve-content-studio .ve-content-meta-panel{grid-column:2!important;grid-row:1!important;min-width:0!important;position:static!important;align-self:start!important;max-height:none!important;overflow:visible!important;border-radius:16px!important}
.ve-content-studio .ve-content-seo-editor{grid-column:1 / -1!important;grid-row:2!important;margin-top:0!important;border-radius:16px!important;align-self:start!important;overflow:hidden!important;background:rgba(255,255,255,.014)!important}
.ve-rich-toolbar{position:relative!important;display:grid!important;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr)!important;gap:10px!important;align-items:center!important;padding:12px 14px!important}
.ve-rich-tool-group-left{grid-column:1!important;justify-content:flex-start!important;flex-wrap:wrap!important;padding-right:92px!important}
.ve-rich-tool-group-center{grid-column:2!important;position:absolute!important;left:50%!important;top:50%!important;transform:translate(-50%,-50%)!important;justify-content:center!important;flex-wrap:nowrap!important;z-index:2!important;background:#181818!important;border:1px solid rgba(255,255,255,.06)!important;border-radius:12px!important;padding:3px!important}
.ve-rich-tool-group-right{grid-column:3!important;justify-content:flex-end!important;flex-wrap:nowrap!important}
.ve-rich-surface{min-height:360px!important;max-height:none!important;padding:24px!important;background:#1c1c1c!important}
.ve-content-editor-shell>label{border-radius:16px 16px 0 0!important}
.ve-content-edit-actions{background:rgba(255,255,255,.018)!important;border-top:1px solid rgba(255,255,255,.075)!important;padding:14px 22px!important;border-radius:0 0 16px 16px!important}
.ve-seo-fieldset{background:rgba(255,255,255,.018)!important;border-color:rgba(255,255,255,.085)!important;border-radius:16px!important;padding:16px!important}
.ve-seo-workspace{grid-template-columns:minmax(0,1fr) minmax(330px,430px)!important;gap:18px!important;padding:18px!important}
.ve-seo-keywords{min-height:46px!important;padding:6px 8px!important;border-radius:14px!important;align-items:center!important;gap:7px!important;background:#1d1d1d!important}
.ve-seo-keyword-pill{height:34px!important;min-height:34px!important;border-radius:999px!important;background:linear-gradient(180deg,rgba(117,74,74,.96),rgba(89,57,57,.96))!important;border:1px solid rgba(255,190,190,.16)!important;color:#fff!important;padding:0 12px!important;gap:8px!important;font-size:11px!important;font-weight:850!important;line-height:1!important;text-shadow:none!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.08)!important}
.ve-seo-keyword-pill button{width:16px!important;height:16px!important;min-width:16px!important;opacity:.9!important}
.ve-seo-keywords input{height:34px!important;line-height:34px!important;align-self:center!important;padding:0 4px!important}
.ve-seo-analysis-row.pass span{color:#dfff9b!important}.ve-seo-analysis-row.fail span{color:#efefef!important}.ve-seo-analysis-row.pass i{background:#baf400!important;color:#111!important}.ve-seo-analysis-row.fail i{background:#ff8e8e!important;color:#311!important}
.ve-rich-theme-switch{font-size:0!important;width:44px!important;height:24px!important;min-width:44px!important;border-radius:999px!important;background:#252525!important;border:1px solid rgba(255,255,255,.14)!important;padding:2px!important;display:inline-flex!important;align-items:center!important;justify-content:flex-start!important;position:relative!important;color:transparent!important}
.ve-rich-theme-switch>i{display:none!important}.ve-rich-theme-track{width:100%!important;height:100%!important;background:transparent!important;padding:0!important;display:block!important;position:relative!important}.ve-rich-theme-track i{position:absolute!important;left:2px!important;top:50%!important;transform:translateY(-50%)!important;width:18px!important;height:18px!important;border-radius:999px!important;background:#8d8d8d!important;transition:transform .16s ease,background .16s ease!important}.ve-rich-theme-switch[aria-checked="true"]{background:rgba(186,244,0,.18)!important;border-color:rgba(186,244,0,.5)!important}.ve-rich-theme-switch[aria-checked="true"] .ve-rich-theme-track i{transform:translate(18px,-50%)!important;background:#baf400!important}
.ve-content-media-picker-sidebar{display:flex!important;visibility:visible!important;opacity:1!important;min-width:230px!important}
.ve-content-media-picker-card-studio{height:min(800px,calc(100% - 64px))!important}.ve-content-media-picker-main{position:relative!important}.ve-content-media-picker-main:after{content:'Drag and drop images here to upload';position:absolute;left:18px;right:18px;bottom:12px;height:28px;border:1px dashed rgba(186,244,0,.18);border-radius:12px;color:#777;display:flex;align-items:center;justify-content:center;font-size:10px;font-weight:800;pointer-events:none;background:rgba(0,0,0,.14)}
.ve-content-media-picker-grid,.ve-content-media-picker-list{padding-bottom:50px!important}
@media(max-width:1180px){.ve-rich-tool-group-center{position:static!important;transform:none!important;grid-column:1 / -1!important;justify-self:center!important}.ve-rich-tool-group-left{padding-right:0!important}.ve-content-studio .ve-content-edit-scroll{grid-template-columns:1fr!important}.ve-content-studio .ve-content-editor-shell,.ve-content-studio .ve-content-meta-panel,.ve-content-studio .ve-content-seo-editor{grid-column:1!important;grid-row:auto!important}.ve-content-media-picker-body{grid-template-columns:1fr!important}.ve-content-media-picker-sidebar{min-width:0!important;max-height:120px!important;flex-direction:row!important}}


/* v1.3.170 — Content Studio containment, picker tree, editor image fix */
.ve-content-studio .ve-content-edit-scroll{
  grid-template-columns:minmax(0,1fr) minmax(270px,350px)!important;
  gap:18px!important;
  padding:18px 18px 112px!important;
  scroll-padding-bottom:120px!important;
}
.ve-content-studio .ve-content-editor-shell{overflow:hidden!important;min-height:520px!important}
.ve-content-studio .ve-content-meta-panel{overflow:visible!important}
.ve-content-studio .ve-content-editor-note{display:none!important}
.ve-content-studio .ve-content-seo-editor{grid-column:1 / -1!important;position:relative!important;z-index:1!important;margin-top:0!important}
.ve-rich-editor{border-radius:14px!important;background:#181818!important;contain:layout paint!important}
.ve-rich-toolbar{display:grid!important;grid-template-columns:minmax(0,1fr) auto minmax(0,1fr)!important;align-items:center!important;gap:10px!important;padding:12px!important;min-height:68px!important}
.ve-rich-tool-group-left{grid-column:1!important;padding-right:0!important;display:flex!important;align-items:center!important;justify-content:flex-start!important;gap:6px!important;flex-wrap:wrap!important}
.ve-rich-tool-group-center{grid-column:2!important;position:static!important;left:auto!important;top:auto!important;transform:none!important;justify-self:center!important;display:flex!important;align-items:center!important;justify-content:center!important;gap:5px!important;background:rgba(255,255,255,.025)!important;border:1px solid rgba(255,255,255,.065)!important;border-radius:12px!important;padding:4px!important;z-index:1!important}
.ve-rich-tool-group-right{grid-column:3!important;display:flex!important;align-items:center!important;justify-content:flex-end!important;gap:6px!important;flex-wrap:nowrap!important}
.ve-rich-surface{box-sizing:border-box!important;overflow:auto!important;min-height:390px!important;max-height:680px!important;padding:24px!important;background:#1c1c1c!important;color:#efefef!important}
.ve-rich-surface img{display:block!important;max-width:100%!important;width:auto!important;height:auto!important;max-height:440px!important;object-fit:contain!important;border-radius:12px!important;margin:14px auto!important;box-sizing:border-box!important}
.ve-rich-surface figure{max-width:100%!important;margin:14px 0!important}.ve-rich-surface figure img{margin:0 auto!important}
.ve-rich-surface pre{display:block!important;max-width:100%!important;white-space:pre-wrap!important;overflow:auto!important;background:#111!important;border:1px solid rgba(186,244,0,.18)!important;border-radius:12px!important;color:#e8ffd0!important;font-family:'SF Mono','Fira Code',Consolas,monospace!important;font-size:13px!important;line-height:1.65!important;padding:14px 16px!important;margin:14px 0!important}
.ve-rich-editor-light .ve-rich-surface{background:#f7f7f5!important;color:#171717!important}.ve-rich-editor-light .ve-rich-surface pre{background:#f0f0ee!important;color:#111!important;border-color:rgba(0,0,0,.14)!important}
.ve-rich-theme-toggle{height:30px!important;min-width:62px!important;border:1px solid rgba(255,255,255,.11)!important;border-radius:10px!important;background:#262626!important;color:#ddd!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;gap:6px!important;font-size:10px!important;font-weight:900!important;padding:0 10px!important;cursor:pointer!important;text-transform:none!important}
.ve-rich-theme-toggle[aria-checked="true"]{border-color:rgba(186,244,0,.42)!important;background:rgba(186,244,0,.12)!important;color:#dfff9b!important}.ve-rich-theme-toggle:hover{border-color:rgba(186,244,0,.38)!important;color:#fff!important}
.ve-content-edit-actions{background:#151515!important;border-top:1px solid rgba(255,255,255,.075)!important;padding:14px 22px!important;position:relative!important;z-index:5!important;border-radius:0 0 14px 14px!important}
.ve-content-media-picker-sidebar{min-width:230px!important}.ve-content-picker-collection{padding-left:calc(8px + (var(--ve-picker-depth,0) * 16px))!important;position:relative!important}.ve-content-picker-collection.child:before{content:'';position:absolute;left:calc(12px + ((var(--ve-picker-depth,0) - 1) * 16px));top:-6px;bottom:-6px;width:1px;background:rgba(186,244,0,.12)}.ve-content-picker-collection.child span:before{content:'↳';color:#777;margin-right:5px;font-weight:800}
.ve-content-media-picker-card-studio{height:min(820px,calc(100% - 64px))!important}.ve-content-media-picker-main:after{bottom:10px!important}.ve-content-media-picker-grid,.ve-content-media-picker-list{padding-bottom:56px!important}
.ve-content-media-picker-masonry .ve-content-media-choice-img{background:#111!important}.ve-content-media-picker-masonry .ve-content-media-choice-img img{max-height:420px!important;object-fit:contain!important}

/* v1.3.171 — Media Studio QA: URL history clear, stable masonry cards, scoped CSS Studio hints */
.ve-url-history-head .ve-url-history-clear{appearance:none!important;height:24px!important;min-width:48px!important;width:auto!important;padding:0 8px!important;border:1px solid rgba(255,255,255,.075)!important;border-radius:999px!important;background:rgba(255,255,255,.04)!important;color:#9a9a9a!important;font-size:10px!important;font-weight:800!important;line-height:1!important;display:inline-flex!important;align-items:center!important;justify-content:center!important;cursor:pointer!important;box-shadow:none!important;white-space:nowrap!important}
.ve-url-history-head .ve-url-history-clear:hover{border-color:rgba(255,139,139,.32)!important;background:rgba(255,139,139,.08)!important;color:#ffb0b0!important}
.ve-media-masonry{display:grid!important;grid-template-columns:repeat(var(--ve-masonry-columns,5),minmax(0,1fr))!important;align-items:start!important;align-content:start!important;overflow:auto!important;gap:12px!important;column-count:auto!important;column-gap:12px!important}
.ve-media-masonry .ve-media-masonry-col{display:flex!important;flex-direction:column!important;gap:12px!important;min-width:0!important;align-items:stretch!important}
.ve-media-masonry .ve-media-thumb{display:block!important;width:100%!important;min-height:112px!important;height:auto!important;line-height:normal!important;background:#101010!important;overflow:hidden!important;margin:0!important;border-radius:12px!important}
.ve-media-masonry .ve-media-thumb .ve-checker-bg{width:100%!important;min-height:112px!important;height:auto!important;aspect-ratio:var(--ve-media-aspect,4/3)!important;display:flex!important;align-items:center!important;justify-content:center!important;overflow:hidden!important;background:rgba(255,255,255,.025)!important;border-radius:12px!important}
.ve-media-masonry .ve-media-thumb .ve-checker-bg img{display:block!important;width:100%!important;height:100%!important;max-width:100%!important;max-height:none!important;object-fit:contain!important;background:transparent!important;border-radius:inherit!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-checker-bg,.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-svg-preview-bg{min-height:112px!important;aspect-ratio:var(--ve-media-aspect,4/3)!important;display:flex!important;align-items:center!important;justify-content:center!important;width:100%!important;background:transparent!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg img.ve-svg-preview-img{width:100%!important;height:100%!important;max-width:100%!important;object-fit:contain!important}

/* v1.3.173 — builder-safe masonry: no SVG/nested-overlay collapse */
.ve-media-masonry{display:grid!important;grid-template-columns:repeat(var(--ve-masonry-columns,5),minmax(0,1fr))!important;gap:12px!important;align-items:start!important;align-content:start!important;overflow:auto!important;column-count:auto!important;column-gap:12px!important}
.ve-media-masonry .ve-media-masonry-col{display:flex!important;flex-direction:column!important;gap:12px!important;min-width:0!important;align-items:stretch!important}
.ve-media-masonry .ve-media-thumb{display:block!important;width:100%!important;min-width:0!important;min-height:118px!important;height:auto!important;aspect-ratio:var(--ve-media-aspect,4/3)!important;line-height:normal!important;background:#101010!important;overflow:hidden!important;margin:0!important;border-radius:12px!important}
.ve-media-masonry .ve-media-thumb .ve-checker-bg,.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-checker-bg,.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-svg-preview-bg{display:flex!important;width:100%!important;height:100%!important;min-width:0!important;min-height:118px!important;aspect-ratio:inherit!important;align-items:center!important;justify-content:center!important;overflow:hidden!important;background:rgba(255,255,255,.025)!important;border-radius:12px!important;line-height:normal!important}
.ve-media-masonry .ve-media-thumb .ve-checker-bg img,.ve-media-masonry .ve-media-thumb.ve-media-is-svg img.ve-svg-preview-img{display:block!important;width:100%!important;height:100%!important;max-width:100%!important;max-height:100%!important;object-fit:contain!important;background:transparent!important;border-radius:inherit!important}
.ve-media-masonry .ve-preview-fallback{display:none;width:100%!important;height:100%!important;min-height:118px!important}

/* v1.3.174 — polished picker masonry: larger cards, no drag interference, image-first builder picker */
.ve-media-masonry{gap:14px!important;grid-template-columns:repeat(var(--ve-masonry-columns,5),minmax(150px,1fr))!important}
.ve-media-masonry .ve-media-masonry-col{gap:14px!important}
.ve-media-masonry .ve-media-thumb{min-height:120px!important;box-shadow:inset 0 1px 0 rgba(255,255,255,.035)!important}
.ve-media-masonry .ve-media-thumb .ve-checker-bg{min-height:120px!important;background:#101010!important}
.ve-media-masonry .ve-media-thumb .ve-checker-bg img:not(.ve-svg-preview-img){object-fit:cover!important}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-checker-bg img,.ve-media-masonry .ve-media-thumb.ve-media-is-svg img.ve-svg-preview-img{object-fit:contain!important}
.ve-media-masonry .ve-font-file-card,.ve-media-masonry .ve-file-card{min-height:120px!important;height:120px!important}
.ve-code-wrap .ve-suggest{z-index:120041!important}

/* v1.3.175 — real SVG previews in Media Studio masonry */
.ve-media-masonry .ve-media-thumb.ve-media-is-svg{
  background:#101010!important;
  min-height:120px!important;
  aspect-ratio:var(--ve-media-aspect,4/3)!important;
}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-checker-bg,
.ve-media-masonry .ve-media-thumb.ve-media-is-svg .ve-svg-preview-bg{
  background:#101010!important;
  border:1px solid rgba(255,255,255,.055)!important;
  min-height:120px!important;
  height:100%!important;
  width:100%!important;
  display:flex!important;
  align-items:center!important;
  justify-content:center!important;
  padding:10px!important;
  box-sizing:border-box!important;
  overflow:hidden!important;
}
.ve-media-masonry .ve-media-thumb.ve-media-is-svg img.ve-svg-preview-img{
  display:block!important;
  width:100%!important;
  height:100%!important;
  max-width:100%!important;
  max-height:100%!important;
  object-fit:contain!important;
  object-position:center!important;
  background:transparent!important;
}
@media(max-width:1180px){.ve-content-studio .ve-content-edit-scroll{grid-template-columns:1fr!important;padding-bottom:120px!important}.ve-rich-toolbar{grid-template-columns:1fr!important}.ve-rich-tool-group-left,.ve-rich-tool-group-center,.ve-rich-tool-group-right{grid-column:1!important;justify-content:center!important;flex-wrap:wrap!important}.ve-content-media-picker-sidebar{min-width:0!important}}

`;

function wireGsapHover(root){
  if(!root)return;
}

function Sw({v}){return h('div',{class:'ve-sw',style:isClr(v)?`background:${v}`:'background:repeating-conic-gradient(#333 0% 25%,#2a2a2a 0% 50%) 50%/8px 8px'});}

/* ── Sub-panel wrapper with slide-out animation ── */
function Sub({title,onClose,onBack,children,exiting,sidecar,bodyClass}){
  const[closing,sC]=useState(false);
  const isOut=closing||exiting;
  const doClose=useCallback(()=>{sC(true);setTimeout(onClose,SLIDE_MS);},[onClose]);
  const handleBack=onBack||doClose;
  const icon=sidecar&&!onBack?'x':'arrow-left';
  return h('div',{class:'ve-sub'+(sidecar?' ve-sidecar':'')+(isOut?' closing':'')},
    h('div',{class:'ve-sub-hdr'},h('button',{class:'ve-exp',onClick:handleBack,title:onBack?'Back':'Close'},ph(icon)),h('span',null,title)),
    h('div',{class:'ve-sub-body'+(bodyClass?' '+bodyClass:'')},typeof children==='function'?children(doClose):children));
}

function searchableOptionScore(option,query,index){
  const label=String(option?.label||'').toLowerCase();
  const value=String(option?.value||'').toLowerCase();
  const q=String(query||'').trim().toLowerCase();
  if(!q)return[index,label];
  const tokens=label.split(/[\s._-]+/).filter(Boolean);
  let score=1000;
  if(label===q||value===q)score=0;
  else if(label.startsWith(q)||value.startsWith(q))score=10;
  else if(tokens.some(token=>token===q))score=20;
  else if(tokens.some(token=>token.startsWith(q)))score=30;
  else{
    const labelAt=label.indexOf(q);
    const valueAt=value.indexOf(q);
    const at=Math.min(labelAt<0?999:valueAt<0?999:valueAt,labelAt<0?999:labelAt);
    if(at<999)score=40+at;
  }
  return[score,label.length,index,label];
}
function SelectMenu({value,onChange,options,className,disabled,searchable,searchPlaceholder}){
  const[open,sOpen]=useState(false);
  const[query,sQuery]=useState('');
  const[activeIndex,sActiveIndex]=useState(0);
  const ref=useRef();
  const buttonRef=useRef();
  const portalRef=useRef();
  const opts=(options||[]).map(o=>typeof o==='string'?{value:o,label:o}:o);
  const normalizedQuery=String(query||'').trim().toLowerCase();
  const filteredOpts=searchable&&normalizedQuery
    ?opts.map((o,index)=>({o,rank:searchableOptionScore(o,normalizedQuery,index)}))
      .filter(item=>item.rank[0]<1000)
      .sort((a,b)=>{for(let i=0;i<Math.max(a.rank.length,b.rank.length);i++){if(a.rank[i]<b.rank[i])return-1;if(a.rank[i]>b.rank[i])return 1;}return 0;})
      .map(item=>item.o)
    :opts;
  const cur=opts.find(o=>String(o.value)===String(value))||opts[0]||{value:'',label:''};
  const choose=o=>{if(!o)return;onChange&&onChange(o.value);sOpen(false);sQuery('');sActiveIndex(0);};
  const onMenuKey=e=>{
    if(e.key==='Escape'){e.preventDefault();e.stopPropagation();sOpen(false);return;}
    if(e.key==='ArrowDown'||e.key==='ArrowUp'){
      e.preventDefault();e.stopPropagation();
      if(!filteredOpts.length)return;
      sActiveIndex(current=>(current+(e.key==='ArrowDown'?1:-1)+filteredOpts.length)%filteredOpts.length);
      return;
    }
    if(e.key==='Home'||e.key==='End'){
      e.preventDefault();e.stopPropagation();sActiveIndex(e.key==='Home'?0:Math.max(0,filteredOpts.length-1));return;
    }
    if(e.key==='Enter'){
      e.preventDefault();e.stopPropagation();choose(filteredOpts[Math.min(activeIndex,Math.max(0,filteredOpts.length-1))]);}
  };
  useEffect(()=>{sActiveIndex(0);},[query,open]);
  useEffect(()=>{
    if(!open)return;
    const close=e=>{if(ref.current&&!ref.current.contains(e.target)&&(!portalRef.current||!portalRef.current.contains(e.target)))sOpen(false);};
    document.addEventListener('mousedown',close);
    return()=>document.removeEventListener('mousedown',close);
  },[open]);
  useEffect(()=>{
    if(!open)return;
    const portal=document.createElement('div');
    portal.className='ve-menu-portal';
    document.body.appendChild(portal);
    portalRef.current=portal;
    return()=>{
      render(null,portal);
      portal.remove();
      if(portalRef.current===portal)portalRef.current=null;
    };
  },[open]);
  useEffect(()=>{
    if(!open||!buttonRef.current||!portalRef.current)return;
    const portal=portalRef.current;
    const place=()=>{
      if(!buttonRef.current)return;
      const rect=buttonRef.current.getBoundingClientRect();
      const wanted=Math.min(250,Math.max(44,filteredOpts.length*34+8+(searchable?36:0)));
      const roomBelow=window.innerHeight-rect.bottom-10;
      const openUp=roomBelow<wanted&&rect.top>wanted;
      portal.className='ve-menu-portal'+(openUp?' up':'');
      portal.style.left=Math.max(8,Math.min(rect.left,window.innerWidth-rect.width-8))+'px';
      portal.style.width=rect.width+'px';
      portal.style.top=(openUp?Math.max(8,rect.top-wanted):rect.bottom-1)+'px';
      render(h('div',{class:'ve-menu-list'},
        searchable&&h('input',{class:'ve-menu-search',value:query,placeholder:searchPlaceholder||'Search variables…',autoComplete:'off',role:'combobox','aria-expanded':'true','aria-controls':'ve-menu-options',onInput:e=>sQuery(e.target.value),onKeyDown:onMenuKey}),
        filteredOpts.length
          ?filteredOpts.map((o,index)=>h('button',{type:'button',class:'ve-menu-item'+(String(o.value)===String(value)?' on':'')+(index===activeIndex?' active':''),key:o.value,role:'option','aria-selected':index===activeIndex,onMouseEnter:()=>sActiveIndex(index),onMouseDown:e=>{e.preventDefault();choose(o);}},o.label))
          :h('div',{class:'ve-menu-empty'},'No matching variables')
      ),portal);
      if(searchable){
        const input=portal.querySelector('.ve-menu-search');
        if(input&&document.activeElement!==input){
          input.focus();
          input.setSelectionRange(input.value.length,input.value.length);
        }
      }
      const activeItem=portal.querySelector('.ve-menu-item.active');
      if(activeItem)activeItem.scrollIntoView({block:'nearest'});
    };
    place();
    const reposition=e=>{if(e?.target&&portal.contains(e.target))return;place();};
    window.addEventListener('resize',place);
    window.addEventListener('scroll',reposition,true);
    return()=>{
      window.removeEventListener('resize',place);
      window.removeEventListener('scroll',reposition,true);
    };
  },[open,value,options,query,searchable,searchPlaceholder,activeIndex]);
  return h('div',{ref,class:'ve-menu '+(open?'open ':'')+(disabled?'disabled ':'')+(className||'')},
    h('button',{ref:buttonRef,type:'button',class:'ve-menu-btn',disabled:!!disabled,onClick:()=>{if(!disabled){sQuery('');sOpen(v=>!v);}},onKeyDown:e=>{
      if(disabled)return;
      if(e.key==='Escape')sOpen(false);
      if(e.key==='ArrowDown'||e.key==='ArrowUp'){e.preventDefault();sQuery('');sActiveIndex(0);sOpen(true);}
      if(e.key==='Enter'||e.key===' '){e.preventDefault();sQuery('');sActiveIndex(0);sOpen(v=>!v);}
    }},h('span',{class:'ve-menu-label'},cur.label)));
}

function ConfirmModal({title,body,confirmText,onCancel,onConfirm,danger}){
  return h('div',{class:'ve-modal'},
    h('div',{class:'ve-modal-box'},
      h('div',{class:'ve-modal-title'},title||'Confirm action'),
      h('div',{class:'ve-modal-body'},body||'Are you sure?'),
      h('div',{class:'ve-modal-actions'},
        h('button',{class:'ve-btn ve-btn-g ve-btn-s',type:'button',onClick:onCancel},'Cancel'),
        h('button',{class:'ve-btn '+(danger?'ve-btn-d':'')+' ve-btn-s',type:'button',onClick:onConfirm},confirmText||'Confirm'))));
}

function CheckControl({checked,onChange,label,title,className,disabled,onShiftClick}){
  const shiftRef=useRef(false);
  const rememberShift=e=>{
    const held=!!(e?.shiftKey||e?.nativeEvent?.shiftKey||shiftRef.current||((typeof window!=='undefined')&&window.__veLastShiftCheckUntil>Date.now()));
    shiftRef.current=held;
    if(held&&typeof window!=='undefined')window.__veLastShiftCheckUntil=Date.now()+700;
    if(e?.currentTarget){
      const input=e.currentTarget.querySelector&&e.currentTarget.querySelector('input');
      const currentHeld=!!(e.shiftKey||e.nativeEvent?.shiftKey||e.currentTarget.__veShiftKey||input?.__veShiftKey||shiftRef.current||((typeof window!=='undefined')&&window.__veLastShiftCheckUntil>Date.now()));
      e.currentTarget.__veShiftKey=currentHeld;
      if(input)input.__veShiftKey=currentHeld;
    }
  };
  const interceptShiftClick=e=>{
    const held=!!(e.shiftKey||e.nativeEvent?.shiftKey||e.target?.__veShiftKey||e.target?.parentNode?.__veShiftKey||e.currentTarget?.__veShiftKey||e.currentTarget?.parentNode?.__veShiftKey||shiftRef.current||((typeof window!=='undefined')&&window.__veLastShiftCheckUntil>Date.now()));
    if(held&&onShiftClick){
      e.preventDefault();
      e.stopPropagation();
      onShiftClick(e, held);
      shiftRef.current=false;
      if(e.target)e.target.__veShiftKey=false;
      if(e.target?.parentNode)e.target.parentNode.__veShiftKey=false;
      if(e.currentTarget)e.currentTarget.__veShiftKey=false;
      if(e.currentTarget?.parentNode)e.currentTarget.parentNode.__veShiftKey=false;
      if(typeof window!=='undefined')window.__veLastShiftCheckUntil=0;
      return true;
    }
    rememberShift(e);
    return false;
  };
  const consumeShift=e=>{
    const held=!!(e.shiftKey||e.nativeEvent?.shiftKey||e.target?.__veShiftKey||e.target?.parentNode?.__veShiftKey||e.currentTarget.__veShiftKey||e.currentTarget.parentNode?.__veShiftKey||shiftRef.current||((typeof window!=='undefined')&&window.__veLastShiftCheckUntil>Date.now()));
    e.__veShiftKey=held;
    if(e.nativeEvent)e.nativeEvent.__veShiftKey=held;
    onChange&&onChange(e.target.checked,e,held);
    shiftRef.current=false;
    if(e.target)e.target.__veShiftKey=false;
    if(e.target?.parentNode)e.target.parentNode.__veShiftKey=false;
    e.currentTarget.__veShiftKey=false;
    if(e.currentTarget.parentNode)e.currentTarget.parentNode.__veShiftKey=false;
  };
  return h('label',{class:'ve-check-row '+(className||'')+(disabled?' disabled':''),'aria-label':title||label||'',onPointerDown:rememberShift,onPointerDownCapture:rememberShift,onMouseDown:rememberShift,onMouseDownCapture:rememberShift,onClick:interceptShiftClick,onClickCapture:interceptShiftClick},
    h('input',{type:'checkbox',checked:!!checked,disabled:!!disabled,onPointerDown:rememberShift,onPointerDownCapture:rememberShift,onMouseDown:rememberShift,onMouseDownCapture:rememberShift,onClick:interceptShiftClick,onClickCapture:interceptShiftClick,onChange:consumeShift}),
    h('span',{class:'ve-check-box'},ph('check')),
    label!==undefined&&h('span',{class:'ve-check-label'},label));
}

function ToggleControl({checked,onChange,label,title,disabled,className}){
  return h('button',{
    type:'button',
    class:'ve-toggle '+(checked?'on':'off')+' '+(className||''),
    'aria-label':title||label||'',
    disabled:!!disabled,
    'aria-pressed':!!checked,
    onClick:()=>!disabled&&onChange&&onChange(!checked)
  },
    h('span',{class:'ve-toggle-label'},checked?'On':'Off'),
    h('span',{class:'ve-toggle-knob'})
  );
}

function ActivityProgress({panelId='variables'}){
  const[state,setState]=useState({count:apiActivity.count,label:apiActivity.label,progress:apiActivity.progress,panelId:apiActivity.panelId,failed:apiActivity.failed});
  const[visible,setVisible]=useState(false);
  const[done,setDone]=useState(false);
  const visibleRef=useRef(false);
  const showTimer=useRef(null);
  const hideTimer=useRef(null);
  useEffect(()=>{
    const listener=next=>setState(next);
    apiActivity.listeners.add(listener);
    return()=>apiActivity.listeners.delete(listener);
  },[]);
  useEffect(()=>{
    if(showTimer.current)clearTimeout(showTimer.current);
    if(hideTimer.current)clearTimeout(hideTimer.current);
    if(state.count>0){
      setDone(false);
      if(!visibleRef.current){
        showTimer.current=setTimeout(()=>{visibleRef.current=true;setVisible(true);},220);
      }
      return;
    }
    if(visibleRef.current){
      setDone(true);
      hideTimer.current=setTimeout(()=>{visibleRef.current=false;setVisible(false);setDone(false);},220);
    }
  },[state.count]);
  useEffect(()=>()=>{if(showTimer.current)clearTimeout(showTimer.current);if(hideTimer.current)clearTimeout(hideTimer.current);},[]);
  if(!visible||state.panelId!==panelId)return null;
  const percent=done?100:Math.max(8,Math.min(92,state.progress||8));
  const finalLabel=state.failed?'Failed':'Complete';
  return h('div',{class:'ve-header-progress'+(done?' done':'')+(done&&state.failed?' failed':''),role:'progressbar','aria-label':state.label,'aria-valuemin':'0','aria-valuemax':'100','aria-valuenow':String(percent),'aria-valuetext':done?finalLabel:state.label},
    h('div',{class:'ve-header-progress-top'},
      h('span',{class:'ve-header-progress-label'},done?finalLabel:state.label),
      h('strong',{class:'ve-header-progress-percent'},percent+'%')),
    h('div',{class:'ve-header-progress-track'},h('div',{class:'ve-header-progress-bar',style:{width:percent+'%'}})));
}

function hexToRgb(hex){
  hex=clrToHex(hex).replace('#','');
  return{r:parseInt(hex.slice(0,2),16),g:parseInt(hex.slice(2,4),16),b:parseInt(hex.slice(4,6),16)};
}
function rgbToHex(r,g,b){return'#'+[r,g,b].map(v=>('0'+Math.max(0,Math.min(255,Math.round(v))).toString(16)).slice(-2)).join('');}
function hexToHsv(hex){
  const{r,g,b}=hexToRgb(hex);const rn=r/255,gn=g/255,bn=b/255,mx=Math.max(rn,gn,bn),mn=Math.min(rn,gn,bn),d=mx-mn;
  let h=0;if(d){if(mx===rn)h=((gn-bn)/d+(gn<bn?6:0))*60;else if(mx===gn)h=((bn-rn)/d+2)*60;else h=((rn-gn)/d+4)*60;}
  return{h:Math.round(h),s:mx?d/mx:0,v:mx};
}
function hsvToHex(h,s,v){
  const c=v*s,x=c*(1-Math.abs((h/60)%2-1)),m=v-c;let r=0,g=0,b=0;
  if(h<60){r=c;g=x;}else if(h<120){r=x;g=c;}else if(h<180){g=c;b=x;}else if(h<240){g=x;b=c;}else if(h<300){r=x;b=c;}else{r=c;b=x;}
  return rgbToHex((r+m)*255,(g+m)*255,(b+m)*255);
}
function hexToHslObj(hex){
  const{r,g,b}=hexToRgb(hex);const rn=r/255,gn=g/255,bn=b/255,mx=Math.max(rn,gn,bn),mn=Math.min(rn,gn,bn),l=(mx+mn)/2;let h=0,s=0;
  if(mx!==mn){const d=mx-mn;s=l>.5?d/(2-mx-mn):d/(mx+mn);if(mx===rn)h=((gn-bn)/d+(gn<bn?6:0))/6;else if(mx===gn)h=((bn-rn)/d+2)/6;else h=((rn-gn)/d+4)/6;}
  return{h:Math.round(h*360),s:Math.round(s*100),l:Math.round(l*100)};
}
function hslToHexObj(h,s,l){
  h=((+h||0)%360+360)%360/360;s=Math.max(0,Math.min(100,+s||0))/100;l=Math.max(0,Math.min(100,+l||0))/100;
  const q=l<.5?l*(1+s):l+s-l*s,p=2*l-q,h2r=(pp,qq,t)=>{if(t<0)t+=1;if(t>1)t-=1;if(t<1/6)return pp+(qq-pp)*6*t;if(t<.5)return qq;if(t<2/3)return pp+(qq-pp)*(2/3-t)*6;return pp;};
  const r=s===0?l:h2r(p,q,h+1/3),g=s===0?l:h2r(p,q,h),b=s===0?l:h2r(p,q,h-1/3);return rgbToHex(r*255,g*255,b*255);
}
function hexToOklchObj(hex){
  const m=hexOklch(hex).match(/oklch\(([\d.]+)\s+([\d.]+)\s+([\d.]+)\)/);return{l:m?+m[1]:0,c:m?+m[2]:0,h:m?+m[3]:0};
}
function MVColorPicker({hex,onChange,fmt,setFmt}){
  const[open,sOpen]=useState(false);
  const[shown,sShown]=useState(false);
  const[closing,sClosing]=useState(false);
  const hsv=hexToHsv(hex);
  const mapRef=useRef();
  const toggleOpen=()=>{
    if(shown&&!closing){sClosing(true);setTimeout(()=>{sShown(false);sOpen(false);sClosing(false);},140);return;}
    sOpen(true);sShown(true);sClosing(false);
  };
  const setFromEvent=e=>{
    const r=mapRef.current?.getBoundingClientRect();if(!r)return;
    const s=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width));
    const v=1-Math.max(0,Math.min(1,(e.clientY-r.top)/r.height));
    onChange(hsvToHex(hsv.h,s,v));
  };
  const down=e=>{
    setFromEvent(e);
    const move=ev=>setFromEvent(ev);
    const up=()=>{window.removeEventListener('mousemove',move);window.removeEventListener('mouseup',up);};
    window.addEventListener('mousemove',move);window.addEventListener('mouseup',up);
  };
  const rgb=hexToRgb(hex);
  const setRgb=(k,v)=>{const next={...rgb,[k]:Math.max(0,Math.min(255,parseInt(v||0,10)||0))};onChange(rgbToHex(next.r,next.g,next.b));};
  const hsl=hexToHslObj(hex);
  const ok=hexToOklchObj(hex);
  const setHsl=(k,v)=>{const next={...hsl,[k]:parseFloat(v||0)||0};onChange(hslToHexObj(next.h,next.s,next.l));};
  const setOk=(k,v)=>{const next={...ok,[k]:parseFloat(v||0)||0};onChange(clrToHex(`oklch(${next.l} ${next.c} ${next.h})`));};
  const controls=fmt==='hsl'
    ?[{v:hsl.h,set:v=>setHsl('h',v),label:'H'},{v:hsl.s,set:v=>setHsl('s',v),label:'S'},{v:hsl.l,set:v=>setHsl('l',v),label:'L'}]
    :fmt==='oklch'
      ?[{v:ok.l.toFixed(4),set:v=>setOk('l',v),label:'L'},{v:ok.c.toFixed(4),set:v=>setOk('c',v),label:'C'},{v:ok.h.toFixed(2),set:v=>setOk('h',v),label:'H'}]
      :[{v:rgb.r,set:v=>setRgb('r',v),label:'R'},{v:rgb.g,set:v=>setRgb('g',v),label:'G'},{v:rgb.b,set:v=>setRgb('b',v),label:'B'}];
  return h('div',{class:'ve-cp',style:'flex:1'},
    h('button',{type:'button',class:'ve-color-swatch',style:'background:'+hex,title:shown?'Close color picker':'Open color picker',onClick:toggleOpen}),
    h('div',{class:'ve-cp-v'},fmtD(hex,fmt)),
    shown&&h('div',{class:'ve-color-panel'+(closing?' closing':'')},
      h('div',{ref:mapRef,class:'ve-color-map',style:'background:hsl('+hsv.h+',100%,50%)',onMouseDown:down},
        h('span',{class:'ve-color-dot',style:{left:(hsv.s*100)+'%',top:((1-hsv.v)*100)+'%'}})),
      h('input',{class:'ve-hue',type:'range',min:0,max:359,value:hsv.h,onInput:e=>onChange(hsvToHex(+e.target.value,hsv.s,hsv.v))}),
      h('div',{class:'ve-color-fields'},
        h('input',{value:hex,onInput:e=>/^#?[0-9a-f]{0,6}$/i.test(e.target.value)&&onChange(clrToHex(e.target.value.charAt(0)==='#'?e.target.value:'#'+e.target.value)),onBlur:e=>onChange(clrToHex(e.target.value))}),
        controls.map(c=>h('input',{value:c.v,title:c.label,onInput:e=>c.set(e.target.value)}))),
      h('div',{class:'ve-format-tabs'},['hex','rgb','hsl','oklch'].map(f=>h('button',{class:fmt===f?'on':'',type:'button',onClick:()=>setFmt(f)},f.toUpperCase())))));
}


function MVInlineColorPicker({hex,onChange,fmt,setFmt}){
  hex=clrToHex(hex||'#baf400');
  const hsv=hexToHsv(hex);
  const mapRef=useRef();
  const setFromEvent=e=>{
    const r=mapRef.current?.getBoundingClientRect();if(!r)return;
    const sat=Math.max(0,Math.min(1,(e.clientX-r.left)/r.width));
    const val=1-Math.max(0,Math.min(1,(e.clientY-r.top)/r.height));
    onChange(hsvToHex(hsv.h,sat,val));
  };
  const down=e=>{
    e.preventDefault();
    setFromEvent(e);
    const move=ev=>setFromEvent(ev);
    const up=()=>{window.removeEventListener('mousemove',move);window.removeEventListener('mouseup',up);};
    window.addEventListener('mousemove',move);window.addEventListener('mouseup',up);
  };
  const rgb=hexToRgb(hex);
  const setRgb=(k,v)=>{const next={...rgb,[k]:Math.max(0,Math.min(255,parseInt(v||0,10)||0))};onChange(rgbToHex(next.r,next.g,next.b));};
  const hsl=hexToHslObj(hex);
  const ok=hexToOklchObj(hex);
  const setHsl=(k,v)=>{const next={...hsl,[k]:parseFloat(v||0)||0};onChange(hslToHexObj(next.h,next.s,next.l));};
  const setOk=(k,v)=>{const next={...ok,[k]:parseFloat(v||0)||0};onChange(clrToHex(`oklch(${next.l} ${next.c} ${next.h})`));};
  const controls=fmt==='hsl'
    ?[{v:hsl.h,set:v=>setHsl('h',v),label:'H'},{v:hsl.s,set:v=>setHsl('s',v),label:'S'},{v:hsl.l,set:v=>setHsl('l',v),label:'L'}]
    :fmt==='oklch'
      ?[{v:ok.l.toFixed(4),set:v=>setOk('l',v),label:'L'},{v:ok.c.toFixed(4),set:v=>setOk('c',v),label:'C'},{v:ok.h.toFixed(2),set:v=>setOk('h',v),label:'H'}]
      :[{v:rgb.r,set:v=>setRgb('r',v),label:'R'},{v:rgb.g,set:v=>setRgb('g',v),label:'G'},{v:rgb.b,set:v=>setRgb('b',v),label:'B'}];
  return h('div',{class:'ve-color-panel ve-collection-inline-color-panel'},
    h('div',{ref:mapRef,class:'ve-color-map',style:'background:hsl('+hsv.h+',100%,50%)',onMouseDown:down},
      h('span',{class:'ve-color-dot',style:{left:(hsv.s*100)+'%',top:((1-hsv.v)*100)+'%'}})),
    h('input',{class:'ve-hue',type:'range',min:0,max:359,value:hsv.h,onInput:e=>onChange(hsvToHex(+e.target.value,hsv.s,hsv.v))}),
    h('div',{class:'ve-color-fields'},
      h('input',{value:hex,onInput:e=>/^#?[0-9a-f]{0,6}$/i.test(e.target.value)&&onChange(clrToHex(e.target.value.charAt(0)==='#'?e.target.value:'#'+e.target.value)),onBlur:e=>onChange(clrToHex(e.target.value))}),
      controls.map(c=>h('input',{value:c.v,title:c.label,onInput:e=>c.set(e.target.value)}))),
    h('div',{class:'ve-format-tabs'},['hex','rgb','hsl','oklch'].map(f=>h('button',{class:fmt===f?'on':'',type:'button',onClick:()=>setFmt(f)},f.toUpperCase()))));
}

/* ── Settings sub-panel ───────────────── */
/* ── Standalone draggable panel wrapper ── */
async function installPanelUpdate(version){
  const payload=version?{version}:{};
  const result=await api.p('update/install',payload);
  if(result?.code)throw new Error(result.message||'Update failed.');
  window.dispatchEvent(new CustomEvent('ve-update-installed',{detail:result||{}}));
  return result;
}

function UpdateNotice({info,skipped,onSkip}){
  const[updating,setUpdating]=useState(false);
  const[error,setError]=useState('');
  const[installed,setInstalled]=useState(false);
  if(!info?.update_available||info.latest_version===skipped)return null;
  const run=async()=>{
    setUpdating(true);setError('');
    try{await installPanelUpdate();setInstalled(true);}
    catch(e){setError(e?.message||'Update failed.');}
    finally{setUpdating(false);}
  };
  return h('div',{class:'ve-update'},
    ph('arrow-circle-up'),
    h('span',null,
      h('b',null,installed?'Update installed: ':'Update available: '),'v'+info.latest_version,
      error&&h('small',{style:'display:block;color:#ff7777;margin-top:2px'},error)),
    h('button',{class:'ve-btn ve-btn-s',disabled:updating||installed,onClick:run},updating?'Updating…':installed?'Installed':'Update'),
    !installed&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',disabled:updating,onClick:()=>onSkip(info.latest_version)},'Skip'));
}

function syncMimamsBarUpdateNotice(info,skipped,onSkip){
  const slot=document.querySelector('.baqa-panel .baqa-update-slot');
  if(!slot)return false;
  slot.innerHTML='';
  if(!info?.update_available||info.latest_version===skipped)return true;
  const notice=document.createElement('div');
  notice.className='ve-update ve-update-shared';
  notice.innerHTML='<i class="ph-duotone ph-arrow-circle-up" aria-hidden="true"></i><span><b>Update available: </b>v'+String(info.latest_version)+'</span>';
  if(info.update_admin_url){
    const update=document.createElement('button');
    update.type='button';
    update.className='ve-btn ve-btn-s';
    update.textContent='Update';
    update.addEventListener('click',async()=>{
      update.disabled=true;
      update.textContent='Updating…';
      try{
        await installPanelUpdate();
        update.textContent='Installed';
      }catch(error){
        update.disabled=false;
        update.textContent='Try Again';
        notice.title=error?.message||'Update failed.';
      }
    });
    notice.appendChild(update);
  }
  const skip=document.createElement('button');
  skip.type='button';
  skip.className='ve-btn ve-btn-g ve-btn-s';
  skip.textContent='Skip';
  skip.addEventListener('click',()=>onSkip(info.latest_version));
  notice.appendChild(skip);
  slot.appendChild(notice);
  return true;
}

function StandalonePanel({ title, onClose, children, width = 340, height = 'min(760px, calc(100vh - 32px))', defaultLeft, defaultTop, persistKey, panelId, open, panelMode, updateNotice, hasUpdate }) {
  const isWideStudio = panelId === 'content_studio' || panelId === 'media_studio' || panelId === 'plugin_studio' || panelId === 'css_recipes';
  const isStudio = isWideStudio || panelId === 'css_studio';
  const isRecipeStudio = panelId === 'css_recipes';
  const isCssStudio = panelId === 'css_studio';
  
  const [pos, setPos] = useState(() => {
    if (persistKey && !isCssStudio) {
      try {
        const saved = localStorage.getItem('ve_pos_' + persistKey);
        if (saved) return JSON.parse(saved);
      } catch (e) {}
    }
    return {
      left:defaultLeft !== undefined ? defaultLeft : Math.max(16, window.innerWidth - width - 16),
      top:defaultTop !== undefined ? defaultTop : 100
    };
  });
  
  const [dragging, setDragging] = useState(false);
  const panelRef = useRef();
  const dragRef = useRef(null);

  useEffect(() => {
    const shouldLockBackgroundScroll = isWideStudio || panelId === 'settings';
    if (!open || !shouldLockBackgroundScroll || MODE === 'builder') return;
    const body = document.body;
    const html = document.documentElement;
    const prevBodyOverflow = body.style.overflow;
    const prevHtmlOverflow = html.style.overflow;
    body.style.overflow = 'hidden';
    html.style.overflow = 'hidden';
    return () => {
      body.style.overflow = prevBodyOverflow;
      html.style.overflow = prevHtmlOverflow;
    };
  }, [open, isWideStudio, panelId]);

  const startDrag = e => {
    if (isStudio) return;
    // Disable dragging for now
    return;
  };

  useEffect(() => {
    if (isStudio || !dragging) return;
    const move = e => {
      const d = dragRef.current;
      if (!d) return;
      const el = panelRef.current;
      const w = el ? el.offsetWidth : width;
      const hgt = el ? el.offsetHeight : (typeof height === 'number' ? height : 760);
      const maxLeft = Math.max(8, window.innerWidth - w - 8);
      const maxTop = Math.max(8, window.innerHeight - hgt - 8);
      const next = {
        left:Math.max(8, Math.min(maxLeft, d.left + (e.clientX - d.x))),
        top:Math.max(8, Math.min(maxTop, d.top + (e.clientY - d.y)))
      };
      setPos(next);
      if (persistKey) {
        persistUserPreference('ve_pos_' + persistKey, next);
      }
    };
    const up = () => {
      setDragging(false);
      dragRef.current = null;
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', up);
    return () => {
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', up);
    };
  }, [dragging, pos, persistKey, width, height, isStudio]);

  const isDocked = !isStudio && (panelMode === 'left' || panelMode === 'right');
  const toolWidth = isCssStudio ? 430 : width;
  const displayTop = isWideStudio ? '50%' : (isCssStudio ? '16px' : (isDocked ? '8px' : pos.top + 'px'));
  const displayLeft = isWideStudio ? '50%' : (isCssStudio ? Math.max(16, window.innerWidth - toolWidth - 16) + 'px' : (isDocked 
    ? (panelMode === 'left' ? '16px' : Math.max(16, window.innerWidth - width - 16) + 'px')
    : pos.left + 'px'));
  const displayHeight = isWideStudio ? '88dvh' : (isCssStudio ? 'calc(100vh - 32px)' : (isDocked ? 'calc(100vh - 16px)' : (typeof height === 'number' ? height + 'px' : height)));
  const displayTransform = isWideStudio ? 'translate(-50%, -50%)' : 'none';
  const displayWidth = isWideStudio ? (isRecipeStudio ? 'min(calc(100vw - 96px), 1120px)' : 'calc(100vw - 96px)') : (isCssStudio ? 'min(430px, calc(100vw - 32px))' : width + 'px');

  const style = {
    position: 'fixed',
    left:displayLeft,
    top:displayTop,
    transform: displayTransform,
    width: displayWidth,
    maxWidth: isWideStudio ? (isRecipeStudio ? '1120px' : '1920px') : (isCssStudio ? '430px' : 'none'),
    height: displayHeight,
    maxHeight: isWideStudio ? '88dvh' : (isCssStudio ? 'calc(100vh - 32px)' : (isDocked ? 'calc(100vh - 16px)' : (typeof height === 'string' && height.indexOf('16px') !== -1 ? 'calc(100vh - 16px)' : 'calc(100vh - 32px)'))),
    background: isStudio || isCssStudio ? '#151515' : '#1f1f1f',
    border: '1px solid rgba(255, 255, 255, 0.08)',
    borderRadius: isStudio || isCssStudio ? '12px' : '10px',
    boxShadow: isStudio || isCssStudio ? '0 24px 70px rgba(0, 0, 0, 0.55)' : '0 18px 46px rgba(0, 0, 0, 0.40)',
    zIndex: 120000,
    display: 'flex',
    flexDirection: 'column',
    fontFamily: '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif',
    fontSize: '13px',
    color: '#f1f1f1',
    userSelect: 'none',
    overflow: 'hidden'
  };

  if (!open) return null;

  return h('div', { ref: panelRef, 'data-panel': panelId, class: 've-o ve-standalone-panel' + (open ? ' open' : '') + (dragging ? ' ve-dragging' : '') + (hasUpdate ? ' has-update' : ''), style },
    h('div', { class: 've-hdr', style: { cursor: isStudio ? 'default' : 'grab', background: '#171717', borderBottom: '1px solid rgba(255,255,255,0.06)' }, onMouseDown: isStudio ? undefined : startDrag },
      !isStudio && h('span', { class: 've-drag-handle', style: { marginRight: '8px' } }, ph('dots-six-vertical')),
      h('span', { class: 've-hdr-t', style: isStudio ? 'font-size:12px;color:#fff' : '' }, title),
      h('div', { style: 'display:flex;gap:4px;margin-left:auto' },
        h('button', { type: 'button', class: 've-a', style: 'width:26px;height:26px;display:flex;align-items:center;justify-content:center', onClick: e => { e.preventDefault(); e.stopPropagation(); onClose && onClose(); }, title: 'Close' }, ph('x'))
      ),
      h(ActivityProgress,{panelId})
    ),
    updateNotice,
    children
  );
}

/* ── Help panel component ── */
function HelpPanel({ onClose }) {
  const sections = [
    ['01', 'Direct Mode', [
      ['data-anim="fade-up"', 'Set or update an attribute on the selected element.'],
      ['.hero-card', 'Add a global/manual class to the selected element.'],
      ['#hero-title', 'Set the selected element CSS ID.'],
      ['-.hero-card', 'Remove a class from the selected element.'],
      ['delete data-anim', 'Remove an attribute from the selected element.']
    ]],
    ['02', 'Bulk targets', [
      ['all li => data-anim="fade-up"', 'Target every matching <li> element on the current page/template.'],
      ['all h2 => data-anim="text-lines"', 'Target every matching heading tag.'],
      ['.service-card => data-anim="fade-up"', 'Target every element with that class.'],
      ['#hero-title => data-anim="text-lines"', 'Target one element by CSS ID.']
    ], 'Bulk preview can be disabled in Settings → Mimam’s Bar. Safety matching still stops above the limit.'],
    ['03', 'Combined selectors', [
      ['all li.service-list__item => data-anim="fade-up"', 'Only <li> elements that also have .service-list__item.'],
      ['.card.is-featured => .is-animated', 'Target elements that have both classes.'],
      ['all h2, all p => data-anim="fade-up"', 'Target more than one group in one command.'],
      ['.card,.panel-card => data-anim="fade-up"', 'Target either class group at once.']
    ]],
    ['04', 'Modes and helpers', [
      ['1', 'Switch to Direct Mode.'],
      ['2', 'Search page elements.'],
      ['3', 'Add Bricks elements.'],
      ['section>container', 'Emmet-style add pattern.'],
      ['--', 'Show Mimam’s Var variable autocomplete.']
    ]]
  ];
  return h('div', { class: 've-body ve-help-shell' },
    h('div', { class: 've-help-hero' },
      h('div', { class: 've-help-kicker' }, 'Quick Help'),
      h('div', { class: 've-help-title' }, 'Mimam’s Bar commands'),
      h('p', { class: 've-help-desc' }, 'Compact command reference for direct edits, bulk targets, combined selectors, and mode switching.')
    ),
    sections.map(section => h('section', { class: 've-help-card', key: section[0] },
      h('div', { class: 've-help-card-title' }, h('em', null, section[0]), h('span', null, section[1])),
      section[2].map(row => h('div', { class: 've-help-row', key: row[0] }, h('code', null, row[0]), h('span', null, row[1]))),
      section[3] && h('p', { class: 've-help-note' }, section[3])
    )),
    h('div', { class: 've-help-footer' },
      h('button', { class: 've-btn ve-btn-s', onClick: onClose }, 'Close')
    )
  );
}

function RichContentEditor({ value, onChange, onChooseImage }) {
  const ref = useRef(null);
  const savedRangeRef = useRef(null);
  const lastHtml = useRef('');
  const [dialog, setDialog] = useState(null);
  const [editorTheme, setEditorTheme] = useState(() => localStorage.getItem('ve_content_editor_theme') || 'dark');

  useEffect(() => {
    const html = value || '';
    if (ref.current && document.activeElement === ref.current) return;
    if (ref.current && html !== lastHtml.current && ref.current.innerHTML !== html) {
      ref.current.innerHTML = html;
      lastHtml.current = html;
    }
  }, [value]);

  const commit = () => {
    if (!ref.current) return;
    const html = ref.current.innerHTML || '';
    lastHtml.current = html;
    onChange(html);
  };

  const saveSelection = () => {
    try {
      const sel = window.getSelection && window.getSelection();
      if (!sel || !sel.rangeCount || !ref.current) return;
      const node = sel.anchorNode;
      if (node && (node === ref.current || ref.current.contains(node))) {
        savedRangeRef.current = sel.getRangeAt(0).cloneRange();
      }
    } catch (e) {}
  };

  const restoreSelection = () => {
    if (!ref.current) return;
    ref.current.focus();
    try {
      const range = savedRangeRef.current;
      const sel = window.getSelection && window.getSelection();
      if (range && sel) {
        sel.removeAllRanges();
        sel.addRange(range);
      }
    } catch (e) {}
  };

  const exec = (cmd, arg) => {
    if (!ref.current) return;
    restoreSelection();
    try { document.execCommand(cmd, false, arg); } catch (e) {}
    commit();
  };

  const openInlineDialog = type => {
    saveSelection();
    setDialog({ type, value: '' });
  };

  const applyInlineDialog = () => {
    const next = String(dialog?.value || '').trim();
    if (!next) { setDialog(null); return; }
    if (dialog.type === 'link') exec('createLink', next);
    if (dialog.type === 'image') exec('insertImage', next);
    setDialog(null);
  };

  const promptLink = () => openInlineDialog('link');
  const promptImage = () => {
    saveSelection();
    if (typeof onChooseImage === 'function') {
      onChooseImage(url => {
        const next = String(url || '').trim();
        if (!next) return;
        exec('insertImage', next);
      });
      return;
    }
    openInlineDialog('image');
  };
  const insertHr = () => exec('insertHorizontalRule');
  const toggleTheme = () => {
    const next = editorTheme === 'light' ? 'dark' : 'light';
    setEditorTheme(next);
    persistUserPreference('ve_content_editor_theme', next);
  };

  const tool = (label, cmd, arg, title, className) => h('button', {
    type: 'button',
    title: title || label,
    class: className || '',
    onMouseDown: e => { e.preventDefault(); saveSelection(); },
    onClick: () => exec(cmd, arg)
  }, label);
  const actionTool = (label, fn, title, className) => h('button', {
    type: 'button',
    title: title || label,
    class: className || '',
    onMouseDown: e => { e.preventDefault(); saveSelection(); },
    onClick: fn
  }, label);
  const sep = key => h('span', { class: 've-rich-sep', key });

  return h('div', { class: 've-rich-editor ve-rich-editor-' + editorTheme },
    h('div', { class: 've-rich-toolbar' },
      h('div', { class: 've-rich-tool-group ve-rich-tool-group-left' },
        tool('P', 'formatBlock', 'p', 'Paragraph'),
        tool('H1', 'formatBlock', 'h1', 'Heading 1'),
        tool('H2', 'formatBlock', 'h2', 'Heading 2'),
        tool('H3', 'formatBlock', 'h3', 'Heading 3'),
        tool('H4', 'formatBlock', 'h4', 'Heading 4'),
        sep('format-sep'),
        tool('B', 'bold', null, 'Bold'),
        tool('I', 'italic', null, 'Italic'),
        tool('U', 'underline', null, 'Underline'),
        tool('S', 'strikeThrough', null, 'Strikethrough'),
        sep('text-sep'),
        tool('UL', 'insertUnorderedList', null, 'Bullet list'),
        tool('OL', 'insertOrderedList', null, 'Numbered list'),
        tool('Quote', 'formatBlock', 'blockquote', 'Quote', 've-rich-tool-wide'),
        tool('Code', 'formatBlock', 'pre', 'Code block', 've-rich-tool-wide')
      ),
      h('div', { class: 've-rich-tool-group ve-rich-tool-group-center' },
        tool('Clear', 'removeFormat', null, 'Remove formatting', 've-rich-tool-wide'),
        tool('Undo', 'undo', null, 'Undo', 've-rich-tool-wide'),
        tool('Redo', 'redo', null, 'Redo', 've-rich-tool-wide')
      ),
      h('div', { class: 've-rich-tool-group ve-rich-tool-group-right' },
        actionTool('Link', promptLink, 'Add link', 've-rich-tool-wide'),
        actionTool('Image', promptImage, 'Choose image from Media Studio', 've-rich-tool-wide'),
        actionTool('HR', insertHr, 'Insert divider'),
        h('button', { type: 'button', class: 've-rich-theme-toggle', role: 'switch', 'aria-checked': editorTheme === 'light' ? 'true' : 'false', title: editorTheme === 'light' ? 'Switch editor to dark mode' : 'Switch editor to light mode', onMouseDown: e => e.preventDefault(), onClick: toggleTheme }, editorTheme === 'light' ? 'Light' : 'Dark')
      )
    ),
    h('div', {
      ref,
      class: 've-rich-surface ve-scroll-custom',
      contentEditable: true,
      role: 'textbox',
      'aria-label': 'Post content',
      'data-placeholder': 'Write content here...',
      onFocus: saveSelection,
      onKeyUp: saveSelection,
      onMouseUp: saveSelection,
      onInput: commit,
      onBlur: commit,
      onPaste: () => setTimeout(commit, 0)
    }),
    dialog && h('div', { class: 've-rich-inline-dialog', onMouseDown: e => e.stopPropagation() },
      h('div', { class: 've-rich-inline-dialog-card' },
        h('strong', null, dialog.type === 'image' ? 'Insert image by URL' : 'Add link'),
        h('input', { class: 've-studio-input', autoFocus: true, placeholder: dialog.type === 'image' ? 'https://image-url...' : 'https://link-url...', value: dialog.value || '', onInput: e => setDialog(d => ({ ...(d || {}), value: e.target.value })), onKeyDown: e => { if (e.key === 'Enter') { e.preventDefault(); applyInlineDialog(); } if (e.key === 'Escape') setDialog(null); } }),
        h('div', { class: 've-rich-inline-dialog-actions' },
          h('button', { type: 'button', class: 've-btn ve-btn-primary', onClick: applyInlineDialog }, 'Apply'),
          h('button', { type: 'button', class: 've-btn ve-btn-g', onClick: () => setDialog(null) }, 'Cancel')
        )
      )
    )
  );
}

function ContentMediaPicker({ title, onSelect, onClose }) {
  const [mediaItems, setMediaItems] = useState(() => Array.isArray(VE_MEDIA_CACHE.items) ? VE_MEDIA_CACHE.items.filter(x => (x.mime_type || '').indexOf('image/') === 0).slice(0, 100) : []);
  const [mediaSearch, setMediaSearch] = useState('');
  const [mediaLoading, setMediaLoading] = useState(false);
  const [collections, setCollections] = useState([]);
  const [activeCollection, setActiveCollection] = useState('all');
  const [pickerView, setPickerView] = useState(() => localStorage.getItem('ve_content_media_picker_view') || 'masonry');
  const [uploading, setUploading] = useState(false);
  const fileRef = useRef(null);
  const pickerItemsCacheRef = useRef({});

  const preview = item => {
    const sizes = item?.media_details?.sizes || {};
    return sizes.medium_large?.source_url || sizes.medium_large?.url || sizes.medium?.source_url || sizes.medium?.url || sizes.thumbnail?.source_url || sizes.thumbnail?.url || item?.source_url || item?.url || item?.guid?.rendered || '';
  };
  const collectionValue = coll => String(coll?.id || coll?.term_id || coll?.key || coll?.slug || coll?.label || coll?.name || '');
  const collectionLabel = coll => coll?.label || coll?.name || coll?.slug || 'Collection';
  const collectionCount = coll => Number(coll?.count ?? coll?.items_count ?? (Array.isArray(coll?.ids) ? coll.ids.length : 0)) || 0;
  const filteredPickerItems = useMemo(() => {
    const q = mediaSearch.trim().toLowerCase();
    if (!q) return mediaItems;
    return mediaItems.filter(item => String(item?.title?.rendered || item?.filename || item?.slug || '').toLowerCase().includes(q));
  }, [mediaItems, mediaSearch]);
  const pickerCollectionRows = useMemo(() => {
    const list = (collections || []).filter(Boolean).map((coll, index) => {
      const id = String(coll.id || coll.term_id || collectionValue(coll) || '');
      const label = collectionLabel(coll);
      const pathParts = String(label || '').split('/').map(x => x.trim()).filter(Boolean);
      return {
        ...coll,
        __id: id,
        __value: collectionValue(coll),
        __label: label,
        __leaf: pathParts.length ? pathParts[pathParts.length - 1] : label,
        __parent: String(coll.parent || coll.parent_id || 0),
        __order: Number(coll.order ?? index) || index,
        __index: index
      };
    });
    const byId = new Map(list.map(coll => [String(coll.__id), coll]));
    const children = new Map();
    list.forEach(coll => {
      const parent = coll.__parent && byId.has(String(coll.__parent)) ? String(coll.__parent) : '0';
      if (!children.has(parent)) children.set(parent, []);
      children.get(parent).push(coll);
    });
    children.forEach(items => items.sort((a, b) => (a.__order - b.__order) || a.__label.localeCompare(b.__label) || (a.__index - b.__index)));
    const rows = [];
    const seen = new Set();
    const walk = (parentId, depth) => {
      (children.get(parentId) || []).forEach(coll => {
        if (!coll.__id || seen.has(coll.__id)) return;
        seen.add(coll.__id);
        rows.push({ ...coll, __depth: depth });
        walk(coll.__id, depth + 1);
      });
    };
    walk('0', 0);
    list.forEach(coll => { if (!seen.has(coll.__id)) rows.push({ ...coll, __depth: 0 }); });
    return rows;
  }, [collections]);
  const pickerMasonryColumns = useMemo(() => {
    const count = 5;
    const cols = Array.from({ length: count }, () => ({ height: 0, items: [] }));
    const estimateHeight = item => {
      const w = Number(item?.media_details?.width || 0);
      const ht = Number(item?.media_details?.height || 0);
      const ratio = w && ht ? Math.max(.35, Math.min(3.2, w / ht)) : 1;
      return Math.max(112, Math.min(260, 150 / ratio));
    };
    filteredPickerItems.forEach((item, idx) => {
      let target = 0;
      for (let i = 1; i < cols.length; i++) if (cols[i].height < cols[target].height) target = i;
      cols[target].items.push({ item, idx });
      cols[target].height += estimateHeight(item) + 12;
    });
    return cols.map(col => col.items);
  }, [filteredPickerItems]);

  const loadCollections = useCallback(async () => {
    try {
      const res = await api.f('variable-engine/v1/media-studio/collections');
      const raw = res?.collections;
      const list = Array.isArray(raw) ? raw : (raw && typeof raw === 'object' ? Object.entries(raw).map(([key, value]) => ({ ...(value || {}), key, path_key: key })) : []);
      setCollections(list);
    } catch (e) { setCollections([]); }
  }, []);

  const loadPickerMedia = useCallback(async (q = mediaSearch, coll = activeCollection) => {
    const cacheKey = String(coll || 'all') + '::' + String(q || '').trim().toLowerCase();
    const query = String(q || '').trim();
    const cached = pickerItemsCacheRef.current[cacheKey];
    if (Array.isArray(cached)) {
      setMediaItems(cached);
      setMediaLoading(false);
      return;
    }

    // For MV collections, prepaint immediately from the global media cache when the collection already exposes attachment ids.
    if (coll && coll !== 'all' && !query && Array.isArray(VE_MEDIA_CACHE.items)) {
      const active = (collections || []).find(c => String(collectionValue(c)) === String(coll));
      const ids = Array.isArray(active?.ids) ? active.ids.map(Number) : [];
      if (ids.length) {
        const byId = new Map(VE_MEDIA_CACHE.items.map(item => [Number(item.id), item]));
        const immediate = ids.map(id => byId.get(Number(id))).filter(item => item && (item.mime_type || '').indexOf('image/') === 0);
        if (immediate.length) setMediaItems(immediate);
      }
    }

    setMediaLoading(true);
    try {
      let list = [];
      if (coll && coll !== 'all') {
        const res = await api.f('variable-engine/v1/media-studio/collections/' + encodeURIComponent(coll) + '/items?limit=160&mime=image');
        list = Array.isArray(res?.items) ? res.items : [];
      } else {
        let endpoint = 'wp/v2/media?per_page=100&media_type=image&_embed=author';
        if (query) endpoint += '&search=' + encodeURIComponent(query);
        const res = await api.f(endpoint);
        list = Array.isArray(res) ? res : [];
        if (!query) {
          VE_MEDIA_CACHE.items = Array.isArray(VE_MEDIA_CACHE.items) && VE_MEDIA_CACHE.items.length ? VE_MEDIA_CACHE.items : list;
        }
      }
      const nextItems = list.filter(x => (x.mime_type || '').indexOf('image/') === 0);
      pickerItemsCacheRef.current[cacheKey] = nextItems;
      setMediaItems(nextItems);
    } catch (e) {
      if (!Array.isArray(pickerItemsCacheRef.current[cacheKey])) setMediaItems([]);
    }
    setMediaLoading(false);
  }, [activeCollection, mediaSearch, collections]);

  useEffect(() => { loadCollections(); loadPickerMedia('', 'all'); }, []);
  useEffect(() => {
    const t = setTimeout(() => loadPickerMedia(mediaSearch, activeCollection), mediaSearch ? 180 : 0);
    return () => clearTimeout(t);
  }, [mediaSearch, activeCollection, loadPickerMedia]);

  const setView = view => {
    setPickerView(view);
    try { localStorage.setItem('ve_content_media_picker_view', view); } catch (e) {}
  };
  const choose = item => {
    const url = item?.source_url || item?.url || item?.guid?.rendered || preview(item);
    if (url && typeof onSelect === 'function') onSelect(url, item);
  };
  const assignToActiveCollection = async item => {
    if (!item?.id || !activeCollection || activeCollection === 'all') return;
    try { await api.p('media-studio/collections/assign', { attachment_id: item.id, collection: activeCollection, checked: true }); } catch(e) {}
  };
  const uploadFiles = async files => {
    const list = Array.from(files || []).filter(Boolean);
    if (!list.length) return;
    setUploading(true);
    for (const file of list) {
      try {
        const res = await api.f('wp/v2/media', {
          method: 'POST',
          headers: {
            'Content-Disposition': 'attachment; filename="' + encodeURIComponent(file.name || 'upload') + '"',
            'Content-Type': file.type || 'application/octet-stream'
          },
          body: file
        });
        if (res && res.id) {
          await assignToActiveCollection(res);
          setMediaItems(prev => [res, ...prev.filter(x => Number(x.id) !== Number(res.id))]);
          VE_MEDIA_CACHE.items = [res, ...(Array.isArray(VE_MEDIA_CACHE.items) ? VE_MEDIA_CACHE.items.filter(x => Number(x.id) !== Number(res.id)) : [])];
        }
      } catch (e) {}
    }
    pickerItemsCacheRef.current = {};
    if (fileRef.current) fileRef.current.value = '';
    setUploading(false);
    loadCollections();
  };

  const mediaCard = item => h('button', { type: 'button', key: 'pick-media-' + item.id, class: 've-content-media-choice' + ((item.mime_type || '').includes('svg') ? ' ve-media-is-svg' : ''), onClick: () => choose(item) },
    h('span', { class: 've-content-media-choice-img' }, preview(item) ? h('img', { src: preview(item), loading: 'lazy', decoding: 'async' }) : ph('image-square')),
    h('span', { class: 've-content-media-choice-title' }, item?.title?.rendered || item?.filename || 'Untitled')
  );

  return h('div', { class: 've-content-media-picker', onMouseDown: e => e.stopPropagation(), onClick: e => e.stopPropagation() },
    h('div', { class: 've-content-media-picker-card ve-content-media-picker-card-studio', onDragOver: e => { e.preventDefault(); e.dataTransfer.dropEffect = 'copy'; }, onDrop: e => { e.preventDefault(); uploadFiles(e.dataTransfer.files); } },
      h('div', { class: 've-content-media-picker-head' },
        h('div', null, h('strong', null, title || 'Choose image'), h('span', null, 'Media Studio picker')),
        h('button', { type: 'button', class: 've-a', onClick: onClose, title: 'Close picker' }, ph('x'))
      ),
      h('div', { class: 've-content-media-picker-body' },
        h('aside', { class: 've-content-media-picker-sidebar ve-scroll-custom' },
          h('button', { type: 'button', class: 've-content-picker-collection ' + (activeCollection === 'all' ? 'active' : ''), onClick: () => setActiveCollection('all') }, ph('squares-four'), h('span', null, 'All media'), h('em', null, String(VE_MEDIA_CACHE.items?.length || mediaItems.length || ''))),
          pickerCollectionRows.map(coll => {
            const val = coll.__value;
            return h('button', {
              type: 'button',
              key: 'picker-coll-' + val,
              class: 've-content-picker-collection ' + (activeCollection === val ? 'active' : '') + (coll.__depth ? ' child' : ''),
              style: { '--ve-picker-depth': String(Math.min(5, coll.__depth || 0)) },
              onClick: () => setActiveCollection(val)
            }, ph(coll.icon || 'folder'), h('span', null, coll.__leaf || collectionLabel(coll)), h('em', null, String(collectionCount(coll))));
          })
        ),
        h('section', { class: 've-content-media-picker-main' },
          h('div', { class: 've-content-media-picker-toolbar' },
            h('input', { class: 've-studio-input', value: mediaSearch, placeholder: 'Search images...', onInput: e => setMediaSearch(e.target.value) }),
            h('input', { ref: fileRef, type: 'file', accept: 'image/*', multiple: true, style: 'display:none', onChange: e => uploadFiles(e.currentTarget.files) }),
            h('button', { type: 'button', class: 've-btn ve-btn-g', onClick: () => fileRef.current && fileRef.current.click() }, uploading ? 'Uploading...' : 'Upload'),
            h('button', { type: 'button', class: 've-btn ve-btn-g', onClick: () => loadPickerMedia(mediaSearch, activeCollection) }, mediaLoading ? 'Loading...' : 'Refresh'),
            h('div', { class: 've-content-picker-viewbar' },
              ['masonry','grid','list'].map(view => h('button', { type: 'button', class: pickerView === view ? 'active' : '', title: view[0].toUpperCase() + view.slice(1), onClick: () => setView(view), key: 'picker-view-' + view }, ph(view === 'list' ? 'list' : view === 'grid' ? 'squares-four' : 'grid-four')))
            )
          ),
          pickerView === 'masonry' ? h('div', { class: 've-content-media-picker-grid ve-content-media-picker-masonry ve-scroll-custom' },
            mediaLoading && !filteredPickerItems.length ? h('div', { class: 've-content-media-picker-empty' }, 'Loading images...') :
            !filteredPickerItems.length ? h('div', { class: 've-content-media-picker-empty' }, 'No images found. Upload or choose another collection.') :
            pickerMasonryColumns.map((col, i) => h('div', { class: 've-content-picker-masonry-col', key: 'picker-col-' + i }, col.map(({ item }) => mediaCard(item))))
          ) : pickerView === 'list' ? h('div', { class: 've-content-media-picker-list ve-scroll-custom' },
            mediaLoading && !filteredPickerItems.length ? h('div', { class: 've-content-media-picker-empty' }, 'Loading images...') :
            !filteredPickerItems.length ? h('div', { class: 've-content-media-picker-empty' }, 'No images found. Upload or choose another collection.') :
            filteredPickerItems.map(item => h('button', { type: 'button', key: 'picker-list-' + item.id, class: 've-content-media-list-row', onClick: () => choose(item) }, h('span', null, preview(item) ? h('img', { src: preview(item), loading: 'lazy', decoding: 'async' }) : ph('image-square')), h('strong', null, item?.title?.rendered || item?.filename || 'Untitled'), h('em', null, item?.mime_type || 'image')))
          ) : h('div', { class: 've-content-media-picker-grid ve-scroll-custom' },
            mediaLoading && !filteredPickerItems.length ? h('div', { class: 've-content-media-picker-empty' }, 'Loading images...') :
            !filteredPickerItems.length ? h('div', { class: 've-content-media-picker-empty' }, 'No images found. Upload or choose another collection.') : filteredPickerItems.map(mediaCard)
          )
        )
      )
    )
  );
}

/* ── Content Studio sub-panel ────────────────── */
function ContentStudioSub({ onClose, flash }) {
  const [meta, setMeta] = useState({ cpts: [], field_groups: [], option_pages: [], acf_active: false, jet_active: false });
  const [activeNav, setActiveNav] = useState('page');
  const [loading, setLoading] = useState(false);
  const [items, setItems] = useState([]);
  const [search, setSearch] = useState('');
  const [contentStatusFilter, setContentStatusFilter] = useState(() => localStorage.getItem('ve_content_status_filter') || 'active');
  const [createDraft, setCreateDraft] = useState({ title: '', slug: '', status: 'draft', content: '', excerpt: '' });
  const [visibleContentGroups, setVisibleContentGroups] = useState(() => {
    const defaults = { default: true, custom: true, options: true, system: false, fields: true };
    try {
      const parsed = JSON.parse(localStorage.getItem('ve_content_visible_groups_v2') || 'null');
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? { ...defaults, ...parsed } : defaults;
    } catch (e) { return defaults; }
  });
  const [contentColumnPanelOpen, setContentColumnPanelOpen] = useState(false);
  const [contentColumns, setContentColumns] = useState(() => {
    const defaults = { id: true, slug: true, status: true, created: true, modified: true, seo: true, actions: true };
    try {
      const parsed = JSON.parse(localStorage.getItem('ve_content_table_columns') || 'null');
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? { ...defaults, ...parsed } : defaults;
    } catch (e) { return defaults; }
  });
  const [editingPost, setEditingPost] = useState(null);
  const [contentMediaPicker, setContentMediaPicker] = useState(null);
  const openContentMediaPicker = useCallback((title, onSelect) => {
    setContentMediaPicker({ title: title || 'Choose image', onSelect });
  }, []);


  // Post form state
  const [title, setTitle] = useState('');
  const [status, setStatus] = useState('draft');
  const [newPost, setNewPost] = useState(null);
  const [showCreateForm, setShowCreateForm] = useState(false);

  // CPT form state
  const [showCptForm, setShowCptForm] = useState(false);
  const [cptName, setCptName] = useState('');
  const [editingCptName, setEditingCptName] = useState('');
  const [cptSingular, setCptSingular] = useState('');
  const [cptPlural, setCptPlural] = useState('');
  const [cptSource, setCptSource] = useState('acf');

  // Field Group form state
  const [showFieldGroupForm, setShowFieldGroupForm] = useState(false);
  const [groupTitle, setGroupTitle] = useState('');
  const [groupSource, setGroupSource] = useState('acf');
  const [groupTargets, setGroupTargets] = useState([]);

  // Field form state
  const [showFieldForm, setShowFieldForm] = useState(false);
  const [editingFieldName, setEditingFieldName] = useState('');
  const [fieldName, setFieldName] = useState('');
  const [fieldLabel, setFieldLabel] = useState('');
  const [fieldType, setFieldType] = useState('text');

  const [optionDraft, setOptionDraft] = useState({});
  const [optionSaveState, setOptionSaveState] = useState('');
  const [pendingDeleteCS, setPendingDeleteCS] = useState(null);
  const [pendingDeleteCptCS, setPendingDeleteCptCS] = useState(null);
  const [pendingDeleteFgCS, setPendingDeleteFgCS] = useState(null);
  const [pendingDeleteFieldCS, setPendingDeleteFieldCS] = useState(null);
  const loadItemsSeq = useRef(0);

  const loadMeta = useCallback(async () => {
    try {
      const res = await api.g('content-studio/meta');
      if (res && (res.cpts || res.field_groups)) {
        setMeta(res);
      }
    } catch (e) {}
  }, []);

  useEffect(() => {
    loadMeta();
  }, [loadMeta]);

  useEffect(() => {
    if (meta.acf_active) {
      setCptSource('acf');
      setGroupSource('acf');
    } else if (meta.jet_active) {
      setCptSource('jet');
      setGroupSource('jet');
    }
  }, [meta.acf_active, meta.jet_active]);

  const loadItems = useCallback(async () => {
    const seq = ++loadItemsSeq.current;
    setLoading(true);
    try {
      const navKey = String(activeNav || '');
      const isFieldGroup = navKey.startsWith('acf-') || navKey.startsWith('jet-');
      const isOptionPage = navKey.startsWith('option-');
      if (isOptionPage) {
        const page = (meta.option_pages || []).find(x => x.id === navKey);
        if (seq !== loadItemsSeq.current) return;
        const fields = page ? (page.fields || []) : [];
        setItems(fields);
        const draft = {};
        fields.forEach(field => { if (field && field.name) draft[field.name] = field.value == null ? '' : field.value; });
        setOptionDraft(draft);
      } else if (isFieldGroup) {
        const group = meta.field_groups.find(g => g.id === navKey);
        if (seq !== loadItemsSeq.current) return;
        if (group) {
          setItems(group.fields || []);
        } else {
          setItems([]);
        }
      } else {
        const res = await api.g('content-studio/posts?post_type=' + encodeURIComponent(navKey));
        if (seq !== loadItemsSeq.current) return;
        if (Array.isArray(res)) {
          setItems(res);
        } else {
          setItems([]);
        }
      }
    } catch (e) {
      if (seq !== loadItemsSeq.current) return;
      setItems([]);
    }
    if (seq === loadItemsSeq.current) setLoading(false);
  }, [activeNav, meta.field_groups, meta.option_pages]);

  useEffect(() => {
    loadItems();
    setShowCreateForm(false);
    setShowFieldForm(false);
    setEditingFieldName('');
    setEditingCptName('');
    setNewPost(null);
    setOptionSaveState('');
  }, [activeNav, loadItems]);

  const currentItems = useMemo(() => {
    return items;
  }, [items]);

  const filtered = useMemo(() => {
    const q = search.toLowerCase().trim();
    const navKey = String(activeNav || '');
    const isFieldGroup = navKey.startsWith('acf-') || navKey.startsWith('jet-');
    const isOptionPage = navKey.startsWith('option-');
    if (isOptionPage) {
      return currentItems.filter(x => !q || (x.label || '').toLowerCase().includes(q) || (x.name || '').toLowerCase().includes(q));
    }
    if (isFieldGroup) {
      return currentItems.filter(x => !q || (x.label || '').toLowerCase().includes(q) || (x.name || '').toLowerCase().includes(q));
    }
    const statusFiltered = currentItems.filter(x => {
      if (contentStatusFilter === 'active') return x.status !== 'trash';
      if (contentStatusFilter === 'all') return true;
      return x.status === contentStatusFilter;
    });
    return statusFiltered.filter(x => !q || (x.title?.rendered || '').toLowerCase().includes(q) || (x.slug || '').toLowerCase().includes(q));
  }, [activeNav, currentItems, search, contentStatusFilter]);

  const contentStatusCounts = useMemo(() => {
    const counts = { all: currentItems.length, publish: 0, draft: 0, pending: 0, private: 0, trash: 0 };
    currentItems.forEach(item => { const st = item.status || 'draft'; counts[st] = (counts[st] || 0) + 1; });
    counts.active = currentItems.filter(item => item.status !== 'trash').length;
    return counts;
  }, [currentItems]);

  const contentDashboardCards = useMemo(() => ([
    { key: 'active', label: 'Active', value: contentStatusCounts.active || 0 },
    { key: 'publish', label: 'Published', value: contentStatusCounts.publish || 0 },
    { key: 'draft', label: 'Drafts', value: contentStatusCounts.draft || 0 },
    { key: 'trash', label: 'Trash', value: contentStatusCounts.trash || 0 }
  ]), [contentStatusCounts]);

  const getAdminBase = () => {
    const pathParts = window.location.pathname.split('/');
    const adminIndex = pathParts.findIndex(x => x.includes('admin') || x === 'wp-admin');
    if (adminIndex !== -1) {
      return pathParts.slice(0, adminIndex + 1).join('/') + '/';
    }
    return '/wp-admin/';
  };

  const getEditUrl = (id) => {
    if (id && typeof id === 'object') {
      return id.bricks_link || id.edit_link || id.link || getEditUrl(id.id);
    }
    return getAdminBase() + 'post.php?post=' + id + '&action=edit';
  };

  const setContentStatus = value => {
    const next = value || 'active';
    setContentStatusFilter(next);
    persistUserPreference('ve_content_status_filter', next);
  };

  const selectContentNav = key => {
    const nextKey = String(key || 'page');
    loadItemsSeq.current++;
    setItems([]);
    setLoading(true);
    setActiveNav(nextKey);
    setSearch('');
    setShowCptForm(false);
    setShowFieldGroupForm(false);
    setShowCreateForm(false);
    setShowFieldForm(false);
    setEditingPost(null);
    setEditingFieldName('');
    setEditingCptName('');
    setNewPost(null);
  };

  const startStudioEdit = (item, e) => {
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setShowCreateForm(false);
    setShowCptForm(false);
    setShowFieldGroupForm(false);
    setShowFieldForm(false);
    const postType = item.type || activeNav;
    const postTypeMeta = getPostTypeMeta(postType) || {};
    setEditingPost({
      id: item.id,
      post_type: postType,
      supports_editor: item.supports_editor !== undefined ? !!item.supports_editor : postTypeMeta.supports_editor !== false,
      titleText: item.title?.rendered || '',
      slug: item.slug || '',
      status: item.status || 'draft',
      content: item.content?.raw || '',
      excerpt: item.excerpt?.raw || '',
      parent: item.parent || 0,
      menu_order: item.menu_order || 0,
      featured_media: item.featured_media || 0,
      comment_status: item.comment_status || 'closed',
      ping_status: item.ping_status || 'closed',
      template: item.template || '',
      custom_fields: item.custom_fields || {},
      edit_link: item.edit_link,
      bricks_link: item.bricks_link,
      bricks_editable: !!item.bricks_editable,
      seo_details: item.seo_details || {},
      link: item.link
    });
  };

  const saveContentEdit = async (e) => {
    e.preventDefault();
    if (!editingPost) return;
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts/' + editingPost.id, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: editingPost.titleText,
          slug: editingPost.slug,
          status: editingPost.status,
          content: editingPost.content || '',
          excerpt: editingPost.excerpt || '',
          parent: parseInt(editingPost.parent || 0, 10) || 0,
          menu_order: parseInt(editingPost.menu_order || 0, 10) || 0,
          featured_media: parseInt(editingPost.featured_media || 0, 10) || 0,
          comment_status: editingPost.comment_status === 'open',
          ping_status: editingPost.ping_status === 'open',
          template: editingPost.template || '',
          custom_fields: editingPost.custom_fields || {},
          seo_details: editingPost.seo_details || {}
        })
      });
      if (res && res.id) {
        setItems(prev => prev.map(x => x.id === res.id ? res : x));
        setEditingPost(null);
        flash('Content updated.');
        await loadMeta();
      } else {
        flash(res?.message || 'Update failed.');
      }
    } catch (err) {
      flash('Update failed.');
    }
    setLoading(false);
  };

  const handleToggleStatus = async (item) => {
    const nextStatus = item.status === 'publish' ? 'draft' : 'publish';
    setItems(prev => prev.map(x => x.id === item.id ? { ...x, status: nextStatus } : x));
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts/' + item.id, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: nextStatus })
      });
      if (res && res.code) {
        flash('Status update failed');
        loadItems();
      } else {
        flash('Status updated to ' + nextStatus);
      }
    } catch (e) {
      flash('Status update failed');
      loadItems();
    }
  };

  const handleDelete = (item) => {
    setPendingDeleteCS(item);
  };

  const confirmDeleteCS = async () => {
    const item = pendingDeleteCS;
    if (!item) return;
    setPendingDeleteCS(null);
    setLoading(true);
    try {
      const force = item.__trashOnly ? 'false' : 'true';
      const res = await api.f('variable-engine/v1/content-studio/posts/' + item.id + '?force=' + force, { method: 'DELETE' });
      if (res && res.id) {
        setItems(prev => prev.filter(x => x.id !== item.id));
        flash(item.__trashOnly ? 'Moved to Trash.' : 'Deleted permanently.');
        loadMeta();
      } else {
        flash('Delete failed');
      }
    } catch (e) {
      flash('Delete failed');
    }
    setLoading(false);
  };

  const handleTrashContent = (item) => {
    setPendingDeleteCS({ ...item, __trashOnly: item.status !== 'trash' });
  };

  const restoreContentItem = async (item) => {
    if (!item) return;
    setItems(prev => prev.map(x => x.id === item.id ? { ...x, status: 'draft' } : x));
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts/' + item.id, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'draft' })
      });
      if (res && res.id) {
        flash('Content restored to Draft.');
        loadItems();
        loadMeta();
      } else {
        flash(res?.message || 'Restore failed.');
        loadItems();
      }
    } catch (e) {
      flash('Restore failed.');
      loadItems();
    }
  };

  const duplicateContentItem = async (item) => {
    if (!item) return;
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts/' + item.id + '/duplicate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'draft' })
      });
      if (res && res.id) {
        flash('Duplicated as draft.');
        setItems(prev => [res, ...prev]);
        loadMeta();
      } else {
        flash(res?.message || 'Duplicate failed.');
      }
    } catch (e) {
      flash('Duplicate failed.');
    }
    setLoading(false);
  };

  const handleCreate = async (e) => {
    e.preventDefault();
    const draft = createDraft || {};
    if (!String(draft.title || '').trim()) return;
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/posts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          post_type: activeNav,
          title: draft.title,
          slug: draft.slug,
          status: draft.status || 'draft',
          content: draft.content || '',
          excerpt: draft.excerpt || ''
        })
      });
      if (res && res.id) {
        setNewPost(res);
        setCreateDraft({ title: '', slug: '', status: 'draft', content: '', excerpt: '' });
        flash('Content created.');
        loadItems();
        loadMeta();
      } else {
        flash(res?.message || 'Creation failed');
      }
    } catch (err) {
      flash('Creation failed');
    }
    setLoading(false);
  };

  const handleCopyLink = (url) => {
    if (url === '#') {
      flash('Cannot copy link');
      return;
    }
    navigator.clipboard.writeText(url);
    flash('Copied Link');
  };

  const startEditCpt = (e, cpt) => {
    if (e) e.stopPropagation();
    if (!cpt || cpt.source === 'wp') return;
    setEditingCptName(cpt.name || '');
    setCptName(cpt.name || '');
    setCptSingular(cpt.singular || cpt.label || cpt.name || '');
    setCptPlural(cpt.label || cpt.singular || cpt.name || '');
    setCptSource(cpt.source || (meta.acf_active ? 'acf' : 'jet'));
    setShowCptForm(true);
    setShowFieldGroupForm(false);
    setShowCreateForm(false);
    setShowFieldForm(false);
    setEditingPost(null);
  };

  const handleCreateCpt = async (e) => {
    e.preventDefault();
    if (!cptName.trim() || !cptSingular.trim() || !cptPlural.trim()) return;
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/cpts', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name: cptName, singular: cptSingular, plural: cptPlural, source: cptSource })
      });
      if (res && res.success) {
        flash(editingCptName ? 'CPT updated successfully.' : 'CPT registered successfully.');
        setCptName('');
        setEditingCptName('');
        setCptSingular('');
        setCptPlural('');
        setShowCptForm(false);
        await loadMeta();
      } else {
        flash('CPT registration failed');
      }
    } catch (e) {
      flash('CPT registration failed');
    }
    setLoading(false);
  };

  const handleDeleteCpt = (e, name) => {
    e.stopPropagation();
    setPendingDeleteCptCS(name);
  };

  const confirmDeleteCptCS = async () => {
    const name = pendingDeleteCptCS;
    if (!name) return;
    setPendingDeleteCptCS(null);
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/cpts/' + name, { method: 'DELETE' });
      if (res && res.success) {
        flash(`CPT "${name}" deleted.`);
        if (activeNav === name) setActiveNav('page');
        await loadMeta();
      } else {
        flash('Failed to delete CPT.');
      }
    } catch (e) {
      flash('Failed to delete CPT.');
    }
    setLoading(false);
  };

  const handleCreateFieldGroup = async (e) => {
    e.preventDefault();
    if (!groupTitle.trim()) return;
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/fields', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ title: groupTitle, post_types: groupTargets, fields: [], source: groupSource })
      });
      if (res && res.success) {
        flash('Field Group created successfully!');
        setGroupTitle('');
        setGroupTargets([]);
        setShowFieldGroupForm(false);
        await loadMeta();
      } else {
        flash('Field Group creation failed');
      }
    } catch (e) {
      flash('Field Group creation failed');
    }
    setLoading(false);
  };

  const handleDeleteFieldGroup = (e, id) => {
    e.stopPropagation();
    setPendingDeleteFgCS(id);
  };

  const confirmDeleteFgCS = async () => {
    const id = pendingDeleteFgCS;
    if (!id) return;
    setPendingDeleteFgCS(null);
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/fields/' + id, { method: 'DELETE' });
      if (res && res.success) {
        flash('Field Group deleted.');
        if (activeNav === id) setActiveNav('page');
        await loadMeta();
      } else {
        flash('Failed to delete Field Group.');
      }
    } catch (e) {
      flash('Failed to delete Field Group.');
    }
    setLoading(false);
  };

  const handleCreateField = async (e) => {
    e.preventDefault();
    if (!fieldName.trim() || !fieldLabel.trim()) return;
    setLoading(true);
    try {
      const group = meta.field_groups.find(g => g.id === activeNav);
      if (!group) return;
      
      const newField = { name: fieldName, label: fieldLabel, type: fieldType };
      const existingFields = group.fields || [];
      const updatedFields = editingFieldName
        ? existingFields.map(f => f.name === editingFieldName ? newField : f)
        : [...existingFields.filter(f => f.name !== fieldName), newField];
      
      const res = await api.f('variable-engine/v1/content-studio/fields', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: group.title,
          post_types: group.post_types || [],
          fields: updatedFields,
          source: group.source || 'acf'
        })
      });
      if (res && res.success) {
        flash(editingFieldName ? 'Custom field updated!' : 'Custom field added!');
        setFieldName('');
        setFieldLabel('');
        setEditingFieldName('');
        setShowFieldForm(false);
        await loadMeta();
      } else {
        flash('Failed to add field.');
      }
    } catch (e) {
      flash('Failed to add field.');
    }
    setLoading(false);
  };

  const handleDeleteField = (fName) => {
    setPendingDeleteFieldCS(fName);
  };

  const handleEditField = (field) => {
    setEditingFieldName(field.name || '');
    setFieldName(field.name || '');
    setFieldLabel(field.label || '');
    setFieldType(field.type || 'text');
    setShowFieldForm(true);
  };

  const confirmDeleteFieldCS = async () => {
    const fName = pendingDeleteFieldCS;
    if (!fName) return;
    setPendingDeleteFieldCS(null);
    setLoading(true);
    try {
      const group = meta.field_groups.find(g => g.id === activeNav);
      if (!group) return;
      
      const updatedFields = (group.fields || []).filter(f => f.name !== fName);
      
      const res = await api.f('variable-engine/v1/content-studio/fields', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: group.title,
          post_types: group.post_types || [],
          fields: updatedFields,
          source: group.source || 'acf'
        })
      });
      if (res && res.success) {
        flash('Field deleted.');
        await loadMeta();
      } else {
        flash('Failed to delete field.');
      }
    } catch (e) {
      flash('Failed to delete field.');
    }
    setLoading(false);
  };

  const formatNavLabel = (key) => {
    if (key === 'page') return 'Pages';
    if (key === 'post') return 'Posts';
    const cpt = meta.cpts.find(pt => pt.name === key);
    if (cpt) return cpt.label;
    const group = meta.field_groups.find(g => g.id === key);
    if (group) return group.title;
    return key;
  };

  const getPostTypeMeta = key => meta.cpts.find(pt => pt.name === key) || null;
  const canEditWithBricks = item => !!(item && item.bricks_editable && item.bricks_link);
  const hasRankMathSeo = item => !!(item && item.seo_details && (item.seo_details.has_plugin || item.seo_details.score !== null || item.seo_details.focus_keyword || item.seo_details.title || item.seo_details.description));
  const renderSeoDetailsCell = item => {
    const seo = item?.seo_details || {};
    const hasScore = seo.score !== null && seo.score !== undefined && seo.score !== '';
    const score = hasScore ? Number(seo.score) : null;
    const scoreClass = score === null ? 'empty' : (score >= 80 ? 'good' : (score >= 50 ? 'warn' : 'bad'));
    const keyword = (seo.focus_keyword || '').trim();
    const desc = (seo.description || '').trim();
    const schema = (seo.schema || '').trim();
    return h('div', { class: 've-content-seo-cell' },
      h('div', { class: 've-content-seo-top' },
        h('span', { class: 've-seo-score ' + scoreClass }, score === null ? 'N/A' : String(score)),
        h('span', { class: 've-seo-mini ' + (keyword ? 'ok' : 'missing') }, keyword ? 'Keyword set' : 'Keyword: not set')
      ),
      h('div', { class: 've-content-seo-lines' },
        h('span', null, 'Meta: ', desc ? 'set' : 'missing'),
        h('span', null, 'Schema: ', schema || 'Article'),
        seo.robots && h('span', null, 'Robots: ', seo.robots)
      )
    );
  };
  const getFieldGroupsForPostType = key => {
    const pt = String(key || '');
    if (!pt) return [];
    return (meta.field_groups || []).filter(group => {
      const targets = Array.isArray(group.post_types) ? group.post_types.map(String) : [];
      return targets.includes(pt);
    });
  };
  const getEditableCustomFields = post => {
    const groups = getFieldGroupsForPostType(post?.post_type);
    const fields = [];
    const seen = new Set();
    groups.forEach(group => (group.fields || []).forEach(field => {
      const key = field.name || field.label;
      if (!key || seen.has(key)) return;
      seen.add(key);
      fields.push({ ...field, groupTitle: group.title || 'Field group' });
    }));
    Object.keys(post?.custom_fields || {}).forEach(key => {
      if (!key || seen.has(key)) return;
      seen.add(key);
      fields.push({ name: key, label: key.replace(/[_-]+/g, ' ').replace(/\b\w/g, m => m.toUpperCase()), type: 'text', groupTitle: 'Custom meta' });
    });
    return fields;
  };
  const isRankMathField = key => /^rank[_-]?math/i.test(String(key || '')) || String(key || '').indexOf('rank_math') !== -1;
  const isContentNoiseMetaField = key => {
    const k = String(key || '').toLowerCase();
    return isRankMathField(k) || /(^|_)(views?|view_count|total_views|hits|hit_count|impressions|clicks|analytics|visits|visit_count|read_count|share_count|like_count)(_|$)/i.test(k) || /^(lawp|rankmath|rank_math|wpseo|yoast|aioseo|monsterinsights|analytify|jetpack)_/i.test(k);
  };
  const isReadOnlyRankMathField = key => {
    const k = String(key || '').toLowerCase();
    return k === 'rank_math_internal_links_processed' || k === 'rank_math_analytic_object_id' || k === 'rank_math_seo_score';
  };
  const isSerializedMetaValue = value => {
    const s = String(value == null ? '' : value).trim();
    return /^(a|O|s|i|b|d):\d+[:;]/.test(s) || (s.length > 120 && /[{}";:]/.test(s));
  };
  const getCustomFieldSections = post => {
    const sections = [];
    const custom = [];
    getEditableCustomFields(post).forEach(field => {
      const key = field.name || field.label;
      if (isContentNoiseMetaField(key)) return; // Keep SEO/plugin counters out of normal content fields.
      custom.push(field);
    });
    if (custom.length) sections.push({ title: 'Custom fields', help: 'Fields detected from ACF, JetEngine, or regular WordPress meta for this post type. Values save with the content item.', fields: custom });
    return sections;
  };
  const fieldInput = (field, value, onValue) => {
    const type = String(field.type || 'text').toLowerCase();
    const common = { class: 've-studio-input', value: value == null ? '' : value, onInput: e => onValue(e.target.value), placeholder: field.label || field.name };
    if (isReadOnlyRankMathField(field.name || field.label)) {
      return h('input', { class: 've-studio-input ve-studio-readonly', value: value == null ? '' : value, readOnly: true, disabled: true, title: 'Read-only Rank Math internal field' });
    }
    if (isSerializedMetaValue(value)) return h('textarea', { ...common, class: 've-studio-input ve-studio-textarea ve-field-serialized', style: 'line-height:1.55;resize:vertical' });
    if (type === 'textarea' || type === 'wysiwyg') return h('textarea', { ...common, class: 've-studio-input ve-studio-textarea', style: 'min-height:92px;line-height:1.6;resize:vertical' });
    if (type === 'number' || type === 'range') return h('input', { ...common, type: 'number' });
    if (type === 'true_false' || type === 'boolean' || type === 'checkbox') return h('div', { class: 've-opt ve-opt-toggle ve-field-toggle' },
      h('span', null, field.label || field.name),
      h(ToggleControl, { checked: !!value && value !== '0' && value !== 'false', label: field.label || field.name, onChange: checked => onValue(checked ? '1' : '0') })
    );
    return h('input', { ...common, type: 'text' });
  };

  const saveOptionPage = async e => {
    e.preventDefault();
    if (!activeOptionPage) return;
    setOptionSaveState('Saving...');
    setLoading(true);
    try {
      const res = await api.f('variable-engine/v1/content-studio/options/' + encodeURIComponent(activeOptionPage.id), {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ post_id: activeOptionPage.post_id || 'options', fields: optionDraft || {} })
      });
      if (res && res.success) {
        setOptionSaveState('Saved');
        flash('Option page saved.');
        await loadMeta();
      } else {
        setOptionSaveState('Save failed');
        flash(res?.message || 'Option page save failed.');
      }
    } catch (err) {
      setOptionSaveState('Save failed');
      flash('Option page save failed.');
    }
    setLoading(false);
  };

  const contentColumnOptions = [
    { key: 'id', label: 'ID' },
    { key: 'slug', label: 'Slug' },
    { key: 'status', label: 'Status' },
    { key: 'created', label: 'Created' },
    { key: 'modified', label: 'Last Edited' },
    { key: 'seo', label: 'SEO Details' },
    { key: 'actions', label: 'Actions' }
  ];
  const setContentColumnSelection = next => {
    const merged = { ...contentColumns, ...next };
    setContentColumns(merged);
    persistUserPreference('ve_content_table_columns', merged);
  };
  const toggleContentColumn = key => setContentColumnSelection({ [key]: !contentColumns[key] });
  const showAllContentColumns = () => setContentColumnSelection(contentColumnOptions.reduce((acc, opt) => ({ ...acc, [opt.key]: true }), {}));
  const hideMetaContentColumns = () => setContentColumnSelection({ id: false, slug: false, created: false, modified: false, seo: false, status: true, actions: true });
  const toPlainText = html => String(html || '').replace(/<style[\s\S]*?<\/style>/gi, ' ').replace(/<script[\s\S]*?<\/script>/gi, ' ').replace(/<[^>]+>/g, ' ').replace(/&nbsp;/g, ' ').replace(/\s+/g, ' ').trim();
  const postWordCount = post => toPlainText(post?.content || '').split(/\s+/).filter(Boolean).length;
  const normalizeKeywords = value => String(value || '').split(',').map(x => x.trim()).filter(Boolean).slice(0, 5);
  const keywordText = keywords => (keywords || []).slice(0, 5).join(', ');
  const primaryKeyword = post => normalizeKeywords(post?.seo_details?.focus_keyword || '')[0] || '';
  const seoSet = (key, value) => setEditingPost(v => ({ ...v, seo_details: { ...(v.seo_details || {}), [key]: value } }));
  const resolveSeoTitle = post => {
    const seo = post?.seo_details || {};
    const raw = String(seo.title || '').trim() || String(post?.titleText || '').trim() || 'Untitled';
    const site = seo.site_name || (document?.title ? document.title.split('‹').pop().trim() : '') || window.location.hostname;
    return raw.replace(/%title%/gi, post?.titleText || 'Untitled').replace(/%sitename%/gi, site).replace(/%sep%/gi, '•').replace(/%excerpt%/gi, toPlainText(post?.excerpt || '').slice(0, 160)).trim();
  };
  const resolveSeoDesc = post => {
    const seo = post?.seo_details || {};
    const raw = String(seo.description || '').trim() || String(post?.excerpt || '').trim() || toPlainText(post?.content || '').slice(0, 160);
    return raw.replace(/%excerpt%/gi, toPlainText(post?.excerpt || '').slice(0, 160)).replace(/%title%/gi, post?.titleText || '').trim();
  };
  const permalinkForPreview = post => {
    const link = String(post?.link || window.location.origin || '').split('?')[0];
    const slug = String(post?.slug || '').trim();
    if (!slug) return link || window.location.origin;
    try {
      const u = new URL(link || window.location.origin);
      const parts = u.pathname.split('/').filter(Boolean);
      if (parts.length) parts[parts.length - 1] = slug; else parts.push(slug);
      u.pathname = '/' + parts.join('/') + '/';
      return u.toString();
    } catch (e) {
      return (window.location.origin || '').replace(/\/$/, '') + '/' + slug + '/';
    }
  };
  const socialTitle = (post, network) => String(post?.seo_details?.[network + '_title'] || '').trim() || (network === 'twitter' ? String(post?.seo_details?.facebook_title || '').trim() : '') || resolveSeoTitle(post);
  const socialDescription = (post, network) => String(post?.seo_details?.[network + '_description'] || '').trim() || (network === 'twitter' ? String(post?.seo_details?.facebook_description || '').trim() : '') || resolveSeoDesc(post);
  const socialImage = (post, network) => String(post?.seo_details?.[network + '_image'] || (network === 'twitter' ? post?.seo_details?.facebook_image : '') || post?.seo_details?.opengraph_image || '').trim();
  const useWpMediaForSeoImage = key => {
    openContentMediaPicker('Choose Open Graph image', url => seoSet(key, url));
  };
  const addFocusKeyword = raw => {
    const next = String(raw || '').split(',').map(x => x.trim()).filter(Boolean);
    if (!next.length) return;
    const current = normalizeKeywords(editingPost?.seo_details?.focus_keyword || '');
    next.forEach(k => { if (current.length < 5 && !current.some(x => x.toLowerCase() === k.toLowerCase())) current.push(k); });
    seoSet('focus_keyword', keywordText(current));
  };
  const removeFocusKeyword = index => { const current = normalizeKeywords(editingPost?.seo_details?.focus_keyword || ''); current.splice(index, 1); seoSet('focus_keyword', keywordText(current)); };
  const toggleRobot = value => {
    const seo = editingPost?.seo_details || {};
    const current = Array.isArray(seo.robots) ? seo.robots.slice() : String(seo.robots || '').split(',').map(x => x.trim()).filter(Boolean);
    const next = current.includes(value) ? current.filter(x => x !== value) : [...current, value];
    seoSet('robots', next);
  };
  const seoInput = (label, key, placeholder = '', opts = {}) => {
    const value = editingPost?.seo_details?.[key] || '';
    const max = opts.max || 0;
    const props = { class: 've-studio-input', value, placeholder, onInput: e => seoSet(key, e.target.value), disabled: !!opts.disabled };
    return h('div', { class: 've-seo-field-row ' + (opts.className || '') },
      h('label', null, h('span', null, label), max ? h('span', { class: 've-seo-count' }, String(value || '').length + ' / ' + max) : null),
      opts.textarea ? h('textarea', { ...props, class: 've-studio-input ve-studio-textarea', style: 'min-height:' + (opts.height || 74) + 'px;line-height:1.55;resize:vertical' }) : h('input', props)
    );
  };
  const renderFocusKeywordEditor = () => {
    const kws = normalizeKeywords(editingPost?.seo_details?.focus_keyword || '');
    return h('div', { class: 've-seo-field-row' },
      h('label', null, h('span', null, 'Focus keywords'), h('span', { class: 've-seo-count' }, kws.length + ' / 5 free')),
      h('div', { class: 've-seo-keywords' },
        kws.map((kw, i) => h('span', { class: 've-seo-keyword-pill', key: 'kw-' + kw + i }, h('button', { type: 'button', onClick: () => removeFocusKeyword(i), title: 'Remove keyword' }, '×'), kw, i === 0 && h('em', { style: 'font-style:normal;color:#fff;font-size:9px' }, '★'))),
        h('input', { placeholder: kws.length >= 5 ? 'Free limit reached' : 'Type keyword, press Enter', disabled: kws.length >= 5, onKeyDown: e => { if (e.key === 'Enter' || e.key === ',') { e.preventDefault(); addFocusKeyword(e.currentTarget.value); e.currentTarget.value = ''; } }, onBlur: e => { addFocusKeyword(e.currentTarget.value); e.currentTarget.value = ''; } })
      ),
      h('div', { class: 've-seo-muted-note' }, 'Rank Math free allows up to 5 focus keywords. Content Studio respects that limit for now.')
    );
  };
  const check = (pass, goodText, badText) => ({ pass: !!pass, text: pass ? goodText : (badText || goodText) });
  const buildSeoChecks = post => {
    const keywords = normalizeKeywords(post?.seo_details?.focus_keyword || '').map(x => x.toLowerCase().trim()).filter(Boolean);
    const primary = keywords[0] || '';
    const keywordSlugs = keywords.map(k => k.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')).filter(Boolean);
    const title = resolveSeoTitle(post);
    const titleLower = title.toLowerCase();
    const desc = resolveSeoDesc(post);
    const descLower = desc.toLowerCase();
    const slug = String(post?.slug || '').toLowerCase();
    const contentRaw = String(post?.content || '');
    const content = toPlainText(contentRaw).toLowerCase();
    const wc = postWordCount(post);
    const hasMedia = /<img|<video|<figure|wp:image|wp:video/i.test(contentRaw);
    const paragraphs = contentRaw.split(/<\/p>|\n\n/).map(x => toPlainText(x)).filter(Boolean);
    const hasLongPara = paragraphs.some(p => p.split(/\s+/).filter(Boolean).length > 120);
    const hasToc = /table of contents|rank-math-toc|toc/i.test(contentRaw);
    const positiveNegative = /(best|top|easy|simple|powerful|complete|proven|dangerous|beautiful|avoid|mistakes|worst|fail|secret|ultimate)/i.test(title);
    const powerWord = /(ultimate|proven|powerful|dangerous|secret|complete|beautiful|fast|clean|premium|advanced|essential)/i.test(title);
    const hasKw = !!keywords.length;
    const anyKeywordIn = text => hasKw && keywords.some(k => String(text || '').toLowerCase().includes(k));
    const anyKeywordStarts = text => hasKw && keywords.some(k => String(text || '').toLowerCase().trim().startsWith(k));
    const anyKeywordInUrl = () => hasKw && keywords.some((k, i) => slug.includes(k) || (keywordSlugs[i] && slug.includes(keywordSlugs[i])));
    return [
      ['Basic SEO', [
        check(anyKeywordIn(titleLower), 'Focus keyword found in the SEO title.', hasKw ? 'Focus keyword does not appear in the SEO title.' : 'Add a focus keyword first.'),
        check(anyKeywordIn(descLower), 'Focus keyword found in the SEO description.', hasKw ? 'Add Focus Keyword to your SEO Meta Description.' : 'Add Focus Keyword to your SEO Meta Description.'),
        check(anyKeywordInUrl(), 'Focus keyword found in the URL.', hasKw ? 'Focus keyword not found in the URL.' : 'Add a focus keyword to test the URL.'),
        check(anyKeywordStarts(content), 'Content starts with the focus keyword.', hasKw ? 'Use Focus Keyword at the beginning of your content.' : 'Add a focus keyword to test the content opening.'),
        check(anyKeywordIn(content), 'Focus keyword found in the content.', hasKw ? 'Use Focus Keyword in the content.' : 'Add a focus keyword to test the content.'),
        check(wc >= 600 && wc <= 2500, 'Content length is within the 600–2500 word range.', 'Content should be 600–2500 words long.')
      ]],
      ['Title Readability', [
        check(anyKeywordStarts(titleLower), 'Focus keyword is at the beginning of the SEO title.', hasKw ? 'Focus keyword doesn’t appear at the beginning of SEO title.' : 'Add a focus keyword first.'),
        check(positiveNegative, 'Your title contains a positive or negative sentiment word.', 'Your title doesn’t contain a positive or negative sentiment word.'),
        check(powerWord, 'Your title contains a power word.', 'Your title doesn’t contain a power word. Add at least one.'),
        check(/\d/.test(title), 'Your SEO title contains a number.', 'Your SEO title doesn’t contain a number.')
      ]],
      ['Content Readability', [
        check(hasToc, 'Table of Contents detected.', 'Use Table of Contents to break down your text.'),
        check(!hasLongPara && paragraphs.length > 1, 'Paragraph length looks readable.', 'Add short and concise paragraphs for better readability and UX.'),
        check(hasMedia, 'Media is included in the content.', 'Add a few images and/or videos to make your content appealing.')
      ]]
    ];
  };
  const renderAnalysisPanel = (title, rows) => {
    const errors = rows.filter(r => !r.pass).length;
    return h('div', { class: 've-seo-analysis' },
      h('div', { class: 've-seo-analysis-title' }, h('span', null, title), errors ? h('span', { class: 've-seo-error-pill' }, errors + ' Error' + (errors === 1 ? '' : 's')) : h('span', { class: 've-seo-error-pill', style: 'background:rgba(186,244,0,.16);color:#dfff9b' }, 'Good')),
      h('div', { class: 've-seo-analysis-list' }, rows.map((r, i) => h('div', { class: 've-seo-analysis-row ' + (r.pass ? 'pass' : 'fail'), key: title + i }, h('i', null, r.pass ? '✓' : '×'), h('span', null, r.text))))
    );
  };
  const renderSerpPreview = post => h('div', { class: 've-seo-snippet' }, h('div', { class: 've-seo-google-search' }, h('div', { class: 've-seo-google-bar' }, primaryKeyword(post) || post?.titleText || 'Search preview')), h('div', { class: 've-seo-result' }, h('div', { class: 've-seo-result-url' }, permalinkForPreview(post)), h('div', { class: 've-seo-result-title' }, resolveSeoTitle(post)), h('div', { class: 've-seo-result-desc' }, resolveSeoDesc(post) || 'Meta description preview will appear here.')));
  const renderSocialPreview = (post, network = 'facebook') => { const img = socialImage(post, network); return h('div', { class: 've-seo-social-card' }, h('div', { class: 've-seo-social-head' }, network === 'twitter' ? 'X / Twitter Preview' : 'Facebook Preview'), h('div', { class: 've-seo-social-img' }, img ? h('img', { src: img, loading: 'lazy', decoding: 'async' }) : h('span', null, 'Open Graph image preview')), h('div', { class: 've-seo-social-body' }, h('div', { class: 've-seo-social-domain' }, window.location.hostname), h('div', { class: 've-seo-social-title' }, socialTitle(post, network)), h('div', { class: 've-seo-social-desc' }, socialDescription(post, network) || 'Social description preview will appear here.'))); };
  const renderSeoEditor = post => {
    if (!post) return null;
    const seo = post.seo_details || {};
    const robots = Array.isArray(seo.robots) ? seo.robots : String(seo.robots || 'index').split(',').map(x => x.trim()).filter(Boolean);
    const tab = seo._tab || 'general';
    const checks = buildSeoChecks(post);
    const robotsChoices = ['index','noindex','nofollow','noarchive','noimageindex','nosnippet'];
    const setTab = next => seoSet('_tab', next);
    return h('details', { class: 've-content-seo-editor', open: true },
      h('summary', null, 'Rank Math SEO + Open Graph'),
      h('div', { class: 've-seo-workspace' },
        h('div', { class: 've-seo-fields' },
          h('div', { class: 've-seo-tabs' }, ['general','social','advanced','schema'].map(t => h('button', { type: 'button', class: tab === t ? 'active' : '', onClick: () => setTab(t), key: 'seo-tab-' + t }, t[0].toUpperCase() + t.slice(1)))),
          tab === 'general' && h('div', { class: 've-seo-fieldset' }, h('div', { class: 've-seo-fieldset-title' }, 'Preview Snippet Editor'), renderFocusKeywordEditor(), seoInput('SEO title', 'title', '%title% %sep% %sitename%', { max: 60 }), seoInput('Meta description', 'description', 'Write the search result description...', { textarea: true, max: 160, height: 92 }), seoInput('Canonical URL', 'canonical_url', 'Optional canonical URL')),
          tab === 'social' && h('div', { class: 've-seo-fieldset' }, h('div', { class: 've-seo-fieldset-title' }, 'Facebook / Open Graph'), seoInput('Facebook title', 'facebook_title', 'Falls back to SEO title'), seoInput('Facebook description', 'facebook_description', 'Falls back to SEO description', { textarea: true, height: 72 }), h('div', { class: 've-seo-field-row' }, h('label', null, h('span', null, 'Facebook image'), h('span', { class: 've-seo-count' }, '1200×630 recommended')), h('div', { class: 've-seo-media-actions' }, h('input', { class: 've-studio-input', value: seo.facebook_image || '', placeholder: 'https://...', onInput: e => seoSet('facebook_image', e.target.value) }), h('button', { type: 'button', class: 've-btn ve-btn-g', onClick: () => useWpMediaForSeoImage('facebook_image') }, 'Choose'))), h('div', { class: 've-seo-fieldset-title', style: 'margin-top:8px' }, 'Twitter / X'), seoInput('Twitter title', 'twitter_title', 'Falls back to Facebook or SEO title'), seoInput('Twitter description', 'twitter_description', 'Falls back to Facebook or SEO description', { textarea: true, height: 72 }), h('div', { class: 've-seo-field-row' }, h('label', null, h('span', null, 'Twitter image'), h('span', { class: 've-seo-count' }, '1200×630 recommended')), h('div', { class: 've-seo-media-actions' }, h('input', { class: 've-studio-input', value: seo.twitter_image || '', placeholder: 'https://...', onInput: e => seoSet('twitter_image', e.target.value) }), h('button', { type: 'button', class: 've-btn ve-btn-g', onClick: () => useWpMediaForSeoImage('twitter_image') }, 'Choose'))), h('label', { class: 've-seo-checkbox-row' }, h('input', { type: 'checkbox', checked: !!seo.facebook_enable_image_overlay, onChange: e => seoSet('facebook_enable_image_overlay', e.target.checked ? 'on' : '') }), 'Add icon overlay to thumbnail')),
          tab === 'advanced' && h('div', { class: 've-seo-fieldset' }, h('div', { class: 've-seo-fieldset-title' }, 'Robots Meta'), h('div', { class: 've-seo-check-grid' }, robotsChoices.map(r => h('label', { key: 'robot-' + r }, h('input', { type: 'checkbox', checked: robots.includes(r), onChange: () => toggleRobot(r) }), r.replace(/^no/i, 'No ')))), h('div', { class: 've-seo-fieldset-title' }, 'Advanced Robots Meta'), h('div', { class: 've-seo-two' }, seoInput('Max snippet', 'max_snippet', '-1'), seoInput('Max video preview', 'max_video_preview', '-1'), h('div', { class: 've-seo-field-row' }, h('label', null, 'Max image preview'), h(SelectMenu, { className: 've-studio-select', value: seo.max_image_preview || 'large', onChange: value => seoSet('max_image_preview', value), options: [{value:'large',label:'Large'}, {value:'standard',label:'Standard'}, {value:'none',label:'None'}] })), seoInput('Redirect destination URL', 'redirect_url', 'https://...')), h('label', { class: 've-seo-checkbox-row' }, h('input', { type: 'checkbox', checked: !!seo.redirect_enabled, onChange: e => seoSet('redirect_enabled', e.target.checked ? '1' : '') }), 'Redirect'), seo.redirect_enabled && h('div', { class: 've-seo-field-row' }, h('label', null, 'Redirection type'), h(SelectMenu, { className: 've-studio-select', value: seo.redirect_type || '301', onChange: value => seoSet('redirect_type', value), options: [{value:'301',label:'301 Permanent Move'}, {value:'302',label:'302 Temporary Move'}, {value:'307',label:'307 Temporary Redirect'}, {value:'410',label:'410 Content Deleted'}, {value:'451',label:'451 Content Unavailable'}] })), h('div', { class: 've-seo-muted-note' }, 'Redirect UI is stored as Rank Math-style metadata for now. Full redirection module integration can come later.')),
          tab === 'schema' && h('div', { class: 've-seo-fieldset' }, h('div', { class: 've-seo-fieldset-title' }, 'Schema'), h('div', { class: 've-seo-field-row' }, h('label', null, 'Schema type'), h(SelectMenu, { className: 've-studio-select', value: seo.schema || 'Article', onChange: value => seoSet('schema', value), options: ['Article','Book','Course','Event','FAQ','HowTo','JobPosting','Movie','Music','Person','Product','Recipe','Restaurant','Service','Software','Video'].map(x => ({ value: x, label: x })) })), h('div', { class: 've-seo-fieldset ve-seo-premium-lock' }, h('div', { class: 've-seo-fieldset-title' }, 'Custom Schema Builder'), h('div', { class: 've-seo-muted-note' }, 'Multiple schemas and advanced custom schema builder are Rank Math Pro-level flows. Content Studio shows the lock for now instead of pretending the free version can edit them.')))
        ),
        h('div', { class: 've-seo-side' }, tab === 'social' ? renderSocialPreview(post, 'facebook') : renderSerpPreview(post), tab === 'social' && renderSocialPreview(post, 'twitter'), checks.map(([title, rows]) => renderAnalysisPanel(title, rows)))
      )
    );
  };

  const activeNavKey = String(activeNav || '');
  const isFieldGroup = activeNavKey.startsWith('acf-') || activeNavKey.startsWith('jet-');
  const isOptionPage = activeNavKey.startsWith('option-');
  const activeOptionPage = isOptionPage ? (meta.option_pages || []).find(page => page.id === activeNavKey) : null;
  const defaultNames = ['page', 'post'];
  const defaultLabelPattern = /^(pages?|posts?)$/i;
  const systemNamePattern = /^(acf-|acf_|wp_|nav_|custom_css|customize_changeset|oembed_cache|user_request|bricks_|ct_|frm_|wpcf7_|jet-|elementor_|revision$)/i;
  const systemLabelPattern = /(taxonom|option pages?|custom fonts?|rm content editor|field groups?|template parts?|navigation)/i;
  const isDefaultish = pt => defaultNames.includes(pt.name) || defaultLabelPattern.test(pt.label || '');
  const defaultCpts = meta.cpts.filter(pt => defaultNames.includes(pt.name));
  const systemCpts = meta.cpts.filter(pt => !isDefaultish(pt) && (pt.is_content === false || systemNamePattern.test(pt.name || '') || systemLabelPattern.test(pt.label || '')));
  const contentCpts = meta.cpts.filter(pt => !isDefaultish(pt) && !systemCpts.some(sys => sys.name === pt.name));
  const toggleContentGroup = key => {
    const next = { ...visibleContentGroups, [key]: !visibleContentGroups[key] };
    setVisibleContentGroups(next);
    persistUserPreference('ve_content_visible_groups_v2', next);
  };
  const sectionTitle = (key, label, canAdd, onAdd) => h('div', { class: 've-studio-nav-title ve-studio-section-title' },
    h('button', { type: 'button', class: 've-section-toggle', onClick: () => toggleContentGroup(key), title: visibleContentGroups[key] ? 'Hide group' : 'Show group' }, ph(visibleContentGroups[key] ? 'caret-down' : 'caret-right'), h('span', null, label)),
    canAdd && h('button', { type: 'button', class: 've-a ve-a-inline', title: 'Create', onClick: onAdd }, ph('plus'))
  );

  return h('div', { class: 've-studio-layout ve-content-studio' },
    contentMediaPicker && h(ContentMediaPicker, {
      title: contentMediaPicker.title,
      onClose: () => setContentMediaPicker(null),
      onSelect: (url, item) => {
        const fn = contentMediaPicker && contentMediaPicker.onSelect;
        setContentMediaPicker(null);
        if (typeof fn === 'function') fn(url, item);
      }
    }),
    pendingDeleteCS && h(ConfirmModal, { title: pendingDeleteCS.__trashOnly ? 'Move to Trash' : 'Delete Content', body: pendingDeleteCS.__trashOnly ? 'Move this content item to Trash? You can restore it from the Trash filter.' : 'Are you sure you want to permanently delete this content?', confirmText: pendingDeleteCS.__trashOnly ? 'Move to Trash' : 'Delete', danger: true, onCancel: () => setPendingDeleteCS(null), onConfirm: confirmDeleteCS }),
    pendingDeleteCptCS && h(ConfirmModal, { title: 'Delete Post Type', body: 'Are you sure you want to permanently delete CPT "' + pendingDeleteCptCS + '"?', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteCptCS(null), onConfirm: confirmDeleteCptCS }),
    pendingDeleteFgCS && h(ConfirmModal, { title: 'Delete Field Group', body: 'Are you sure you want to delete this custom field group?', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteFgCS(null), onConfirm: confirmDeleteFgCS }),
    pendingDeleteFieldCS && h(ConfirmModal, { title: 'Delete Field', body: 'Are you sure you want to delete field "' + pendingDeleteFieldCS + '"?', confirmText: 'Delete', danger: true, onCancel: () => setPendingDeleteFieldCS(null), onConfirm: confirmDeleteFieldCS }),
    // 1. Sidebar
    h('div', { class: 've-studio-sidebar' },
      h('div', { style: 'flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:16px;padding-right:2px' },
        // Default Content Types
        h('div', { class: 've-studio-nav' },
          sectionTitle('default', 'Default Content Types'),
          visibleContentGroups.default && ['page', 'post'].map(k => {
            const cpt = meta.cpts.find(pt => pt.name === k);
            return h('div', {
              key: k,
              class: 've-studio-nav-item' + (activeNav === k && !showCptForm && !showFieldGroupForm ? ' active' : ''),
              onClick: () => selectContentNav(k)
            },
              h('span', { style: 'display:flex;align-items:center;gap:8px' },
                ph(k === 'page' ? 'file' : 'article'),
                formatNavLabel(k)
              ),
              h('span', { class: 've-studio-badge' }, (activeNav === k && loading) ? '...' : (cpt ? cpt.count : '0'))
            );
          })
        ),
        // Custom Post Types
        h('div', { class: 've-studio-nav' },
          sectionTitle('custom', 'Custom Post Types', (meta.acf_active || meta.jet_active), () => {
            setShowCptForm(true);
            setShowFieldGroupForm(false);
          }),
          visibleContentGroups.custom && (contentCpts.length ? contentCpts.map(cpt => h('div', {
            key: cpt.name,
            class: 've-studio-nav-item ve-nav-item-cpt' + (activeNav === cpt.name && !showCptForm && !showFieldGroupForm ? ' active' : ''),
            onClick: () => selectContentNav(cpt.name)
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' },
              ph('circles-three-plus'),
              h('span', { style: 'overflow:hidden;text-overflow:ellipsis' }, cpt.label),
              cpt.source !== 'wp' && h('span', {
                style: 'font-size:11px;padding:1px 4px;border-radius:4px;background:' + (cpt.source === 'acf' ? 'rgba(57,112,245,0.15)' : 'rgba(186,244,0,0.15)') + ';color:' + (cpt.source === 'acf' ? '#4f8bff' : '#baf400') + ';font-weight:700;margin-left:4px'
              }, cpt.source.toUpperCase())
            ),
            h('div', { style: 'display:flex;align-items:center;gap:6px' },
              h('span', { class: 've-studio-badge' }, cpt.count),
              cpt.source !== 'wp' && h('button', {
                class: 've-nav-delete-btn',
                title: 'Edit post type labels',
                style: 'border:none;background:none;padding:0;cursor:pointer;color:#baf400;opacity:0;transition:opacity 0.2s;display:flex;align-items:center',
                onClick: (e) => startEditCpt(e, cpt)
              }, ph('pencil-simple')),
              cpt.source !== 'wp' && h('button', {
                class: 've-nav-delete-btn',
                title: 'Delete post type',
                style: 'border:none;background:none;padding:0;cursor:pointer;color:#ff4d4d;opacity:0;transition:opacity 0.2s;display:flex;align-items:center',
                onClick: (e) => handleDeleteCpt(e, cpt.name)
              }, ph('trash'))
            )
          )) : h('div', { class: 've-empty ve-empty-inline' }, 'No custom content types detected.'))
        ),
        meta.acf_active && h('div', { class: 've-studio-nav' },
          sectionTitle('options', 'Options Pages'),
          visibleContentGroups.options && ((meta.option_pages || []).length ? (meta.option_pages || []).map(page => h('div', {
            key: page.id,
            class: 've-studio-nav-item ve-nav-item-cpt' + (activeNav === page.id ? ' active' : ''),
            onClick: () => selectContentNav(page.id)
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' },
              ph('sliders-horizontal'),
              h('span', { style: 'overflow:hidden;text-overflow:ellipsis' }, page.label || page.slug),
              h('span', { style: 'font-size:11px;padding:1px 4px;border-radius:4px;background:rgba(57,112,245,0.15);color:#4f8bff;font-weight:700;margin-left:4px' }, 'ACF')
            ),
            h('span', { class: 've-studio-badge' }, (page.fields || []).length)
          )) : h('div', { class: 've-empty ve-empty-inline' }, 'No ACF option pages detected.'))
        ),
        /* Plugin/System Types intentionally hidden for now. Content Studio should stay focused on real content records and custom fields. */
        // Custom Field Groups
        h('div', { class: 've-studio-nav' },
          sectionTitle('fields', 'Custom Field Groups', (meta.acf_active || meta.jet_active), () => {
            setShowFieldGroupForm(true);
            setShowCptForm(false);
          }),
          visibleContentGroups.fields && meta.field_groups.map(group => h('div', {
            key: group.id,
            class: 've-studio-nav-item ve-nav-item-cpt' + (activeNav === group.id && !showCptForm && !showFieldGroupForm ? ' active' : ''),
            onClick: () => selectContentNav(group.id)
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' },
              ph('gear'),
              h('span', { style: 'overflow:hidden;text-overflow:ellipsis' }, group.title),
              h('span', {
                style: 'font-size:11px;padding:1px 4px;border-radius:4px;background:' + (group.source === 'acf' ? 'rgba(57,112,245,0.15)' : 'rgba(186,244,0,0.15)') + ';color:' + (group.source === 'acf' ? '#4f8bff' : '#baf400') + ';font-weight:700;margin-left:4px'
              }, group.source.toUpperCase())
            ),
            h('div', { style: 'display:flex;align-items:center;gap:6px' },
              h('span', { class: 've-studio-badge' }, (group.fields || []).length),
              h('button', {
                class: 've-nav-delete-btn',
                title: 'Delete field group',
                style: 'border:none;background:none;padding:0;cursor:pointer;color:#ff4d4d;opacity:0;transition:opacity 0.2s;display:flex;align-items:center',
                onClick: (e) => handleDeleteFieldGroup(e, group.id)
              }, ph('trash'))
            )
          ))
        )
      )
    ),
    // 2. Main Area
    h('div', { class: 've-studio-main' },
      h('div', { style: 'display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;gap:12px' },
        h('div', null,
          h('h2', { style: 'margin:0;font-size:16px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px' },
            showCptForm ? (editingCptName ? 'Edit Custom Post Type' : 'Register Custom Post Type') : (showFieldGroupForm ? 'Create Custom Field Group' : formatNavLabel(activeNav)),
            !showCptForm && !showFieldGroupForm && h('span', { style: 'font-size:11px;font-weight:400;color:#888;background:rgba(255,255,255,0.04);padding:2px 8px;border-radius:10px' }, `${filtered.length} items`)
          )
        ),
        h('div', { class: 've-content-tools' },
          !showCreateForm && !showCptForm && !showFieldGroupForm && !showFieldForm && h('input', {
            class: 've-studio-input',
            style: 'width:220px',
            placeholder: 'Search...',
            value: search,
            onInput: e => setSearch(e.target.value)
          }),
          !isFieldGroup && !isOptionPage && !showCreateForm && !showCptForm && !showFieldGroupForm && !showFieldForm && !editingPost && h('div', { class: 've-content-column-pop-wrap' },
            h('button', { type: 'button', class: 've-btn ve-btn-g ve-btn-s', style: 'padding:4px 8px;display:flex;align-items:center', title: 'Choose table columns', onClick: () => setContentColumnPanelOpen(v => !v) }, ph('columns')),
            contentColumnPanelOpen && h('div', { class: 've-content-column-pop' },
              h('div', { class: 've-content-column-pop-head' }, h('span', null, 'Table columns'), h('button', { type: 'button', class: 've-a', onClick: () => setContentColumnPanelOpen(false) }, ph('x'))),
              contentColumnOptions.map(opt => h('label', { class: 've-content-column-pop-row', key: opt.key },
                h(CheckControl, { checked: !!contentColumns[opt.key], onChange: () => toggleContentColumn(opt.key), title: opt.label }),
                h('span', null, opt.label)
              )),
              h('div', { class: 've-content-column-actions' },
                h('button', { type: 'button', onClick: showAllContentColumns }, 'Show all'),
                h('button', { type: 'button', onClick: hideMetaContentColumns }, 'Compact')
              )
            )
          ),
          // Actions for CPTs
          !isFieldGroup && !isOptionPage && !showCptForm && !showFieldGroupForm && h('button', {
            class: 've-btn ve-btn-s ' + (showCreateForm ? 've-btn-g' : ''),
            onClick: () => { setShowCreateForm(prev => !prev); setNewPost(null); }
          }, showCreateForm ? 'Back to List' : '+ Add New'),
          // Actions for Field Groups
          isFieldGroup && !showCptForm && !showFieldGroupForm && h('button', {
            class: 've-btn ve-btn-s ' + (showFieldForm ? 've-btn-g' : ''),
            onClick: () => setShowFieldForm(prev => {
              if (prev) {
                setEditingFieldName('');
                setFieldName('');
                setFieldLabel('');
                setFieldType('text');
              }
              return !prev;
            })
          }, showFieldForm ? 'Back to List' : '+ Add Field')
        )
      ),
      !isFieldGroup && !isOptionPage && !showCptForm && !showFieldGroupForm && !showCreateForm && !showFieldForm && !editingPost && h('div', { class: 've-content-dashboard' },
        contentDashboardCards.map(card => h('button', { key: card.key, type: 'button', class: 've-content-stat-card' + (contentStatusFilter === card.key ? ' active' : ''), onClick: () => setContentStatus(card.key), title: 'Show ' + card.label.toLowerCase() },
          h('strong', null, card.value), h('span', null, card.label)
        ))
      ),
      !isFieldGroup && !isOptionPage && !showCptForm && !showFieldGroupForm && !showCreateForm && !showFieldForm && !editingPost && h('div', { class: 've-content-status-tabs' },
        [
          { value: 'active', label: 'Active' },
          { value: 'all', label: 'All' },
          { value: 'publish', label: 'Published' },
          { value: 'draft', label: 'Drafts' },
          { value: 'pending', label: 'Pending' },
          { value: 'private', label: 'Private' },
          { value: 'trash', label: 'Trash' }
        ].map(opt => h('button', { key: opt.value, type: 'button', class: contentStatusFilter === opt.value ? 'active' : '', onClick: () => setContentStatus(opt.value) }, h('span', null, opt.label), h('em', null, String(contentStatusCounts[opt.value] || 0))))
      ),

      // ── Form: Register CPT ──
      showCptForm ? h('form', { onSubmit: handleCreateCpt, class: 've-content-cpt-form' },
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Post Type Key (Slug)'),
          h('input', {
            class: 've-studio-input',
            required: true,
            readOnly: !!editingCptName,
            value: cptName,
            onInput: e => setCptName(e.target.value.toLowerCase().replace(/[^a-z0-9_\-]/g, '')),
            placeholder: 'e.g. portfolio'
          })
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Singular Label'),
          h('input', {
            class: 've-studio-input',
            required: true,
            value: cptSingular,
            onInput: e => setCptSingular(e.target.value),
            placeholder: 'e.g. Portfolio Item'
          })
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Plural Label'),
          h('input', {
            class: 've-studio-input',
            required: true,
            value: cptPlural,
            onInput: e => setCptPlural(e.target.value),
            placeholder: 'e.g. Portfolios'
          })
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Provider'),
          h(SelectMenu, { className: 've-studio-select', value: cptSource, onChange: setCptSource, options: [
            meta.acf_active && { value: 'acf', label: 'Advanced Custom Fields (ACF)' },
            meta.jet_active && { value: 'jet', label: 'JetEngine' }
          ].filter(Boolean) })
        ),
        h('div', { style: 'display:flex;gap:8px;margin-top:8px' },
          h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:600;flex:1' }, loading ? 'Saving...' : (editingCptName ? 'Save CPT' : 'Register CPT')),
          h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => { setShowCptForm(false); setEditingCptName(''); setCptName(''); setCptSingular(''); setCptPlural(''); } }, 'Cancel')
        )
      ) :

      // ── Form: Create Field Group ──
      showFieldGroupForm ? h('form', { onSubmit: handleCreateFieldGroup, style: 'max-width:500px;display:flex;flex-direction:column;gap:14px;background:rgba(255,255,255,0.01);border:1px solid rgba(255,255,255,0.05);border-radius:10px;padding:20px' },
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Group Title'),
          h('input', {
            class: 've-studio-input',
            required: true,
            value: groupTitle,
            onInput: e => setGroupTitle(e.target.value),
            placeholder: 'e.g. Project Specs'
          })
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Assign to Post Types (CPTs)'),
          h('div', { class: 've-check-list ve-scroll-custom' },
            [...defaultCpts, ...contentCpts].map(pt => h(CheckControl, {
              key: pt.name,
              checked: groupTargets.includes(pt.name),
              label: pt.label + ' (' + pt.name + ')',
              onChange: checked => {
                if (checked) setGroupTargets([...groupTargets, pt.name]);
                else setGroupTargets(groupTargets.filter(x => x !== pt.name));
              }
            }))
          )
        ),
        h('div', null,
          h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Provider'),
          h(SelectMenu, { className: 've-studio-select', value: groupSource, onChange: setGroupSource, options: [
            meta.acf_active && { value: 'acf', label: 'Advanced Custom Fields (ACF)' },
            meta.jet_active && { value: 'jet', label: 'JetEngine' }
          ].filter(Boolean) })
        ),
        h('div', { style: 'display:flex;gap:8px;margin-top:8px' },
          h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:600;flex:1' }, loading ? 'Creating...' : 'Create Field Group'),
          h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => setShowFieldGroupForm(false) }, 'Cancel')
        )
      ) :

      // ── Form: Create Post inside CPT ──
      !isFieldGroup && !isOptionPage && showCreateForm ? h('form', { onSubmit: handleCreate, class: 've-content-create-form' },
        newPost ? h('div', { style: 'background:rgba(186,244,0,0.1);border:1px solid #baf400;border-radius:10px;padding:16px;text-align:center' },
          h('div', { style: 'color:#baf400;font-weight:800;margin-bottom:8px;font-size:13px' }, 'Content created'),
          h('div', { style: 'color:#fff;font-size:12px;margin-bottom:12px;font-weight:700' }, newPost.title?.rendered),
          h('div', { style: 'display:flex;gap:8px;justify-content:center;flex-wrap:wrap' },
            h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:34px', onClick: () => { setNewPost(null); setShowCreateForm(false); } }, 'Back to list'),
            h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:34px', onClick: () => startStudioEdit(newPost) }, 'Edit in Studio'),
            canEditWithBricks(newPost) && h('a', { class: 've-btn ve-btn-primary', style: 'height:34px;text-decoration:none;display:inline-flex;align-items:center;color:#1f1f1f;font-weight:700', href: newPost.bricks_link, target: '_blank' }, 'Open in Bricks'),
            newPost.edit_link && h('a', { class: 've-btn ve-btn-g', style: 'height:34px;text-decoration:none;display:inline-flex;align-items:center', href: newPost.edit_link, target: '_blank' }, 'Open WP editor')
          )
        ) : [
          h('div', { class: 've-content-create-grid' },
            h('div', null,
              h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Title'),
              h('input', { class: 've-studio-input', required: true, value: createDraft.title, onInput: e => setCreateDraft(v => ({ ...v, title: e.target.value })), placeholder: 'e.g. New ' + formatNavLabel(activeNav) })
            ),
            h('div', null,
              h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Status'),
              h(SelectMenu, { className: 've-studio-select', value: createDraft.status || 'draft', onChange: value => setCreateDraft(v => ({ ...v, status: value })), options: [{ value: 'draft', label: 'Draft' }, { value: 'publish', label: 'Publish' }, { value: 'pending', label: 'Pending' }, { value: 'private', label: 'Private' }] })
            )
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Slug (optional)'),
            h('input', { class: 've-studio-input', value: createDraft.slug || '', onInput: e => setCreateDraft(v => ({ ...v, slug: e.target.value.toLowerCase().replace(/[^a-z0-9_\-]/g, '-') })), placeholder: 'auto-generated from title' })
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Excerpt'),
            h('textarea', { class: 've-studio-input ve-studio-textarea', value: createDraft.excerpt || '', onInput: e => setCreateDraft(v => ({ ...v, excerpt: e.target.value })), placeholder: 'Optional short summary...', style: 'min-height:76px;line-height:1.55;resize:vertical' })
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Content'),
            h(RichContentEditor, { value: createDraft.content || '', onChange: html => setCreateDraft(v => ({ ...v, content: html })), onChooseImage: cb => openContentMediaPicker('Choose content image', cb) })
          ),
          h('div', { class: 've-content-create-actions' },
            h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => { setShowCreateForm(false); setNewPost(null); } }, 'Cancel'),
            h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:800;min-width:150px' }, loading ? 'Creating...' : 'Create Content')
          )
        ]
      ) :

      // ── Form: Create Custom Field inside Field Group ──
      isFieldGroup && showFieldForm ? h('form', { onSubmit: handleCreateField, class: 've-content-field-edit-form' },
        h('div', { class: 've-content-field-edit-main ve-scroll-custom' },
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Field Name (Key/Slug)'),
            h('input', {
              class: 've-studio-input',
              required: true,
              value: fieldName,
              onInput: e => setFieldName(e.target.value.toLowerCase().replace(/[^a-z0-9_]/g, '')),
              placeholder: 'e.g. project_cost'
            })
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Field Label'),
            h('input', {
              class: 've-studio-input',
              required: true,
              value: fieldLabel,
              onInput: e => setFieldLabel(e.target.value),
              placeholder: 'e.g. Project Cost'
            })
          ),
          h('div', null,
            h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, 'Field Type'),
            h(SelectMenu, { className: 've-studio-select', value: fieldType, onChange: setFieldType, options: [
              { value: 'text', label: 'Text' },
              { value: 'textarea', label: 'Text Area' },
              { value: 'number', label: 'Number' },
              { value: 'image', label: 'Image' },
              { value: 'select', label: 'Select / Dropdown' },
              { value: 'boolean', label: 'True / False' }
            ] })
          )
        ),
        h('div', { class: 've-content-field-edit-actions' },
          h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:38px;color:#1f1f1f;font-weight:600;flex:1' }, loading ? 'Saving...' : (editingFieldName ? 'Save Field' : 'Add Field')),
          h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:38px', onClick: () => { setEditingFieldName(''); setShowFieldForm(false); } }, 'Cancel')
        )
      ) :

      isOptionPage && activeOptionPage ? h('form', { onSubmit: saveOptionPage, class: 've-content-edit-form' },
        h('div', { class: 've-content-edit-scroll ve-scroll-custom' },
          h('div', { class: 've-content-editor-note' }, 'ACF Options Pages store global site settings, not normal posts. Edit them here when they are content-related; use ACF when changing field structure.'),
          h('div', { class: 've-content-custom-grid' },
            (filtered || []).map(field => h('div', { key: 'option-field-' + field.name },
              h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, field.label || field.name),
              fieldInput(field, optionDraft[field.name], next => setOptionDraft(v => ({ ...(v || {}), [field.name]: next }))),
              h('div', { class: 've-content-field-help' }, 'ACF option · ' + (field.type || 'text'))
            ))
          ),
          optionSaveState && h('div', { class: 've-content-field-help-muted' }, optionSaveState)
        ),
        h('div', { class: 've-content-edit-actions' },
          h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:700;min-width:150px' }, loading ? 'Saving...' : 'Save Options')
        )
      ) :

      editingPost ? h('form', { onSubmit: saveContentEdit, class: 've-content-edit-form' },
        h('div', { class: 've-content-edit-scroll ve-scroll-custom' },
          h('div', { class: 've-content-meta-panel' },
            h('div', { class: 've-content-form-grid' },
              h('div', { class: 've-content-field-block' },
                h('label', null, 'Title'),
                h('input', { class: 've-studio-input', required: true, value: editingPost.titleText, onInput: e => setEditingPost(v => ({ ...v, titleText: e.target.value })) })
              ),
              h('div', { class: 've-content-field-block' },
                h('label', null, 'Status'),
                h(SelectMenu, { className: 've-studio-select', value: editingPost.status || 'draft', onChange: value => setEditingPost(v => ({ ...v, status: value })), options: [
                  { value: 'draft', label: 'Draft' },
                  { value: 'publish', label: 'Published' },
                  { value: 'pending', label: 'Pending' },
                  { value: 'private', label: 'Private' }
                ] })
              )
            ),
            h('div', { class: 've-content-field-block' },
              h('label', null, 'Slug'),
              h('input', { class: 've-studio-input', value: editingPost.slug || '', onInput: e => setEditingPost(v => ({ ...v, slug: e.target.value.toLowerCase().replace(/[^a-z0-9_\-]/g, '-') })) })
            ),
            h('div', { class: 've-content-field-block' },
              h('label', null, 'Excerpt'),
              h('textarea', { class: 've-studio-input ve-studio-textarea', value: editingPost.excerpt || '', onInput: e => setEditingPost(v => ({ ...v, excerpt: e.target.value })), style: 'min-height:120px;line-height:1.65;resize:vertical' })
            )
          ),
          h('div', { class: 've-content-editor-shell' },
            h('label', null, h('span', null, 'Content'), h('small', { style: 'color:#777;font-size:10px;font-weight:800' }, 'Rich writing layer')),
            h(RichContentEditor, {
              value: editingPost.content || '',
              onChange: html => setEditingPost(v => ({ ...v, content: html })),
              onChooseImage: cb => openContentMediaPicker('Choose content image', cb)
            })
          ),
          renderSeoEditor(editingPost),
          editingPost.supports_editor === false && h('div', { class: 've-content-field-help' }, 'This post type reports the WordPress editor as disabled. Content Studio still shows a writing surface, but use the WP editor/Bricks for plugin-specific block or builder data.'),
          getCustomFieldSections(editingPost).map(section => h('details', { class: 've-content-custom-fields', open: true, key: 'custom-section-' + section.title },
            h('summary', null, section.title),
            h('div', { class: 've-content-field-help' }, section.help),
            h('div', { class: 've-content-custom-grid' },
              section.fields.map(field => {
                const key = field.name || field.label;
                if (!key) return null;
                const val = (editingPost.custom_fields || {})[key];
                return h('div', { key: 'field-' + key },
                  h('label', { style: 'display:block;margin-bottom:6px;font-size:11px;color:#888;font-weight:600' }, field.label || key),
                  fieldInput(field, val, next => setEditingPost(v => ({ ...v, custom_fields: { ...(v.custom_fields || {}), [key]: next } }))),
                  h('div', { class: 've-content-field-help' }, (field.groupTitle || 'Custom field') + ' · ' + (field.type || 'text') + (isSerializedMetaValue(val) ? ' · serialized/plugin data' : ''))
                );
              })
            )
          )),
          h('div', { class: 've-content-editor-note' }, 'Studio handles the clean content layer here. Open Bricks or the WordPress editor when you need builder canvas, blocks, plugin metaboxes, or advanced WordPress-only controls.')
        ),
        h('div', { class: 've-content-edit-actions' },
          h('button', { type: 'submit', class: 've-btn ve-btn-primary', disabled: loading, style: 'height:36px;color:#1f1f1f;font-weight:600;min-width:150px' }, loading ? 'Saving...' : 'Save in Studio'),
          canEditWithBricks(editingPost) && h('a', { class: 've-btn ve-btn-g', style: 'height:36px;text-decoration:none;display:inline-flex;align-items:center', href: editingPost.bricks_link, target: '_blank' }, 'Edit in Bricks'),
          editingPost.edit_link && h('a', { class: 've-btn ve-btn-g', style: 'height:36px;text-decoration:none;display:inline-flex;align-items:center', href: editingPost.edit_link, target: '_blank' }, 'Open WP editor'),
          h('button', { type: 'button', class: 've-btn ve-btn-g', style: 'height:36px', onClick: () => setEditingPost(null) }, 'Cancel')
        )
      ) :

      // ── Main Content Lists (CPT Posts or Field Group Fields) ──
      h('div', { class: 've-studio-table-container ve-content-table-wrap' },
        loading ? h('div', { style: 'text-align:center;padding:60px;color:#888' }, 'Loading...') :
        filtered.length === 0 ? h('div', { style: 'text-align:center;padding:60px;color:#888' }, 'No items found.') :
        
        (!isFieldGroup ? (
          h('table', { class: 've-studio-table' },
            h('thead', null,
              h('tr', null,
                contentColumns.id && h('th', { style: 'width:60px' }, 'ID'),
                h('th', null, 'Title'),
                contentColumns.slug && h('th', null, 'Slug'),
                contentColumns.status && h('th', { style: 'width:100px' }, 'Status'),
                contentColumns.created && h('th', { style: 'width:120px' }, 'Created'),
                contentColumns.modified && h('th', { style: 'width:120px' }, 'Last Edited'),
                contentColumns.seo && h('th', { style: 'width:210px' }, 'SEO Details'),
                contentColumns.actions && h('th', { style: 'width:260px;text-align:right' }, 'Actions')
              )
            ),
            h('tbody', null, filtered.map(item =>
              h('tr', { key: item.id, class: 've-content-row' },
                contentColumns.id && h('td', { style: 'color:#666' }, `#${item.id}`),
                h('td', null, h('div', { class: 've-content-title-cell' }, h('strong', null, item.title?.rendered || 'Untitled'), h('em', null, item.type || activeNav))),
                contentColumns.slug && h('td', { style: 'color:#888;font-family:monospace;font-size:11px' }, item.slug || '-'),
                contentColumns.status && h('td', null,
                  h('button', {
                    onClick: () => handleToggleStatus(item),
                    class: 've-status-toggle',
                    title: item.status === 'publish' ? 'Click to move this item to Draft' : 'Click to publish this item'
                  },
                    h('span', {
                      class: 've-studio-badge',
                      style: item.status === 'publish'
                        ? 'background:rgba(186,244,0,0.1);color:#baf400;border:1px solid rgba(186,244,0,0.2)'
                        : 'background:rgba(255,184,0,0.1);color:#ffb800;border:1px solid rgba(255,184,0,0.2)'
                    }, item.status === 'publish' ? 'Published' : 'Draft')
                  )
                ),
                contentColumns.created && h('td', { style: 'color:#888;font-size:11px' }, item.date ? new Date(item.date).toLocaleDateString() : '-'),
                contentColumns.modified && h('td', { style: 'color:#888;font-size:11px' }, item.modified ? new Date(item.modified).toLocaleDateString() : '-'),
                contentColumns.seo && h('td', null, renderSeoDetailsCell(item)),
                contentColumns.actions && h('td', { style: 'text-align:right' },
                  h('div', { class: 've-content-actions ve-content-action-stack' },
                    h('div', { class: 've-content-action-primary' },
                      h('button', {
                        type: 'button',
                        class: 've-btn ve-btn-g ve-btn-s ve-content-action-main',
                        onPointerDown: e => startStudioEdit(item, e),
                        onMouseDown: e => e.stopPropagation(),
                        onClick: e => startStudioEdit(item, e),
                        title: 'Edit clean content fields in Content Studio'
                      }, 'Studio'),
                      canEditWithBricks(item) && h('a', {
                        class: 've-btn ve-btn-primary ve-btn-s ve-content-action-main',
                        style: 'text-decoration:none;display:inline-flex;align-items:center;color:#1f1f1f;font-weight:800',
                        href: item.bricks_link,
                        title: 'Edit design/layout in Bricks'
                      }, 'Bricks')
                    ),
                    h('div', { class: 've-content-action-secondary' },
                      item.edit_link && h('a', {
                        class: 've-content-icon-action',
                        href: item.edit_link,
                        target: '_blank',
                        title: 'Open WordPress editor'
                      }, ph('file-text')),
                      item.link !== '#' && item.status !== 'trash' && h('a', {
                        class: 've-content-icon-action',
                        href: item.link,
                        target: '_blank',
                        title: 'View page'
                      }, ph('eye')),
                      h('button', {
                        class: 've-content-icon-action',
                        onClick: () => duplicateContentItem(item),
                        title: 'Duplicate as draft'
                      }, ph('copy')),
                      item.status === 'trash' && h('button', {
                        class: 've-content-icon-action',
                        onClick: () => restoreContentItem(item),
                        title: 'Restore to Draft'
                      }, ph('arrow-counter-clockwise')),
                      h('button', {
                        class: 've-content-icon-action',
                        onClick: () => handleCopyLink(item.link),
                        title: 'Copy link'
                      }, ph('link')),
                      h('button', {
                        class: 've-content-icon-action ' + (item.status === 'trash' ? 'danger' : 'warning'),
                        onClick: () => item.status === 'trash' ? handleDelete(item) : handleTrashContent(item),
                        title: item.status === 'trash' ? 'Delete permanently' : 'Move to Trash'
                      }, ph('trash'))
                    )
                  )
                )
              )
            ))
          )
        ) : (
          // Custom Fields Table
          h('table', { class: 've-studio-table' },
            h('thead', null,
              h('tr', null,
                h('th', null, 'Field Label'),
                h('th', null, 'Field Name (Key)'),
                h('th', { style: 'width:150px' }, 'Type'),
                h('th', { style: 'width:100px;text-align:right' }, 'Actions')
              )
            ),
            h('tbody', null, filtered.map(field =>
              h('tr', { key: field.name },
                h('td', { style: 'font-weight:600;color:#fff' }, field.label),
                h('td', { style: 'color:#888;font-family:monospace;font-size:11px' }, field.name),
                h('td', null,
                  h('span', {
                    class: 've-studio-badge',
                    style: 'background:rgba(255,255,255,0.05);color:#ccc;border:1px solid rgba(255,255,255,0.1)'
                  }, field.type.toUpperCase())
                ),
                h('td', { style: 'text-align:right' },
                  h('div', { style: 'display:flex;gap:6px;justify-content:flex-end' },
                    h('button', {
                      type: 'button',
                      class: 've-btn ve-btn-g ve-btn-s',
                      onClick: () => handleEditField(field),
                      title: 'Edit field'
                    }, ph('pencil-simple')),
                    h('button', {
                      class: 've-btn ve-btn-g ve-btn-s',
                      style: 'color:#ff4d4d',
                      onClick: () => handleDeleteField(field.name),
                      title: 'Delete field'
                    }, ph('trash'))
                  )
                )
              )
            ))
          )
        ))
      )
    )
  );
}

/* ── Media Studio sub-panel ──────────────────── */
const COLL_ICONS = ['folder','folders','images','image','file','file-image','file-video','file-audio','file-text','file-pdf','font-aa','star','heart','bookmark','tag','tags','flag','lightning','globe','camera','music-notes','video','paint-brush','palette','code','brackets-curly','book','books','trophy','gift','diamond','rocket','puzzle-piece','shield-check','house','buildings','tree','sun','moon','fire','drop','leaf','smiley','archive','box-arrow-down','calendar','users','user','briefcase','browser','app-window','database','cloud','download','upload','link','paperclip','paint-bucket','swatches','sparkle','magic-wand','target','tray','stack','squares-four','grid-four'];
const VE_MEDIA_COLLAPSED_PATHS_KEY = 've_media_collapsed_paths';
function loadMediaCollapsedPaths(){
  try {
    const parsed = JSON.parse(localStorage.getItem(VE_MEDIA_COLLAPSED_PATHS_KEY) || '{}');
    return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
  } catch(e) {
    return {};
  }
}
function persistMediaCollapsedPaths(next){
  try { localStorage.setItem(VE_MEDIA_COLLAPSED_PATHS_KEY, JSON.stringify(next || {})); } catch(e) {}
}
function collectFolderDescendantIds(folders, folderId){
  const ids = new Set([String(folderId)]);
  let changed = true;
  let guard = 0;
  while (changed && guard < 1000) {
    changed = false;
    guard++;
    (folders || []).forEach(folder => {
      const id = String(folder.id);
      const parent = String(folder.parent || '0');
      if (!ids.has(id) && ids.has(parent)) {
        ids.add(id);
        changed = true;
      }
    });
  }
  return Array.from(ids);
}
function collectFolderMediaIds(folderData, folderId){
  const wantedFolders = new Set(collectFolderDescendantIds(folderData?.folders || [], folderId));
  const map = folderData?.map || {};
  return Object.keys(map)
    .filter(id => (map[id] || []).map(String).some(fid => wantedFolders.has(fid)))
    .map(id => parseInt(id, 10));
}
function MediaStudioSub({ onClose, flash, onInsertMedia, picking, initialFilter, pageMode }) {
  const mediaIconPaths = {
    'arrows-clockwise': ['M128 40a88 88 0 0 1 83.3 59.5a8 8 0 0 1-15.2 5A72 72 0 0 0 64.9 82.9L80 98a8 8 0 0 1-5.7 13.7H32a8 8 0 0 1-8-8V61.4A8 8 0 0 1 37.7 55.8l15.8 15.8A88 88 0 0 1 128 40Zm-83.3 116.5a8 8 0 1 1 15.2-5A72 72 0 0 0 191.1 173.1L176 158a8 8 0 0 1 5.7-13.7H224a8 8 0 0 1 8 8v42.3a8 8 0 0 1-13.7 5.6l-15.8-15.8A88 88 0 0 1 44.7 156.5Z'],
    'arrows-merge': ['M48 40h56a8 8 0 0 1 8 8v38.1a40 40 0 0 0 11.7 28.3L128 118.7l4.3-4.3A40 40 0 0 0 144 86.1V48a8 8 0 0 1 8-8h56a8 8 0 0 1 5.7 13.7l-24 24a8 8 0 0 1-11.4-11.2L188.7 56H160v30.1a56 56 0 0 1-16.4 39.6L139.3 130l39 39-10.6 10.6-39-39-4.4 4.4A56 56 0 0 1 108.1 184H80v28.7l10.3-10.4a8 8 0 0 1 11.4 11.4l-24 24A8 8 0 0 1 64 232v-56a8 8 0 0 1 8-8h36.1a40 40 0 0 0 28.3-11.7l4.4-4.3-4.4-4.4A56 56 0 0 1 96 86.1V56H67.3l10.4 10.3a8 8 0 0 1-11.4 11.4l-24-24A8 8 0 0 1 48 40Z'],
    'arrows-out-line-vertical': ['M56 40h144a8 8 0 0 1 0 16H56a8 8 0 0 1 0-16Zm72 32a8 8 0 0 1 8 8v68.7l18.3-18.4a8 8 0 1 1 11.4 11.4l-32 32a8 8 0 0 1-11.4 0l-32-32a8 8 0 1 1 11.4-11.4l18.3 18.4V80a8 8 0 0 1 8-8ZM56 200h144a8 8 0 0 1 0 16H56a8 8 0 0 1 0-16Z'],
    'calendar': ['M80 24a8 8 0 0 1 8 8v8h80v-8a8 8 0 0 1 16 0v8h16a24 24 0 0 1 24 24v136a24 24 0 0 1-24 24H56a24 24 0 0 1-24-24V64a24 24 0 0 1 24-24h16v-8a8 8 0 0 1 8-8Zm128 88H48v88a8 8 0 0 0 8 8h144a8 8 0 0 0 8-8V112Z'],
    'caret-down': ['M50.3 88.6a8 8 0 0 1 11.4 0L128 154.9l66.3-66.3a8 8 0 1 1 11.4 11.4l-72 72a8 8 0 0 1-11.4 0l-72-72a8 8 0 0 1 0-11.4Z'],
    'caret-right': ['M96.6 42.3a8 8 0 0 1 11.4 0l72 72a8 8 0 0 1 0 11.4l-72 72a8 8 0 1 1-11.4-11.4L162.9 120 96.6 53.7a8 8 0 0 1 0-11.4Z'],
    'columns': ['M40 48a16 16 0 0 1 16-16h144a16 16 0 0 1 16 16v160a16 16 0 0 1-16 16H56a16 16 0 0 1-16-16V48Zm72 0H56v160h56V48Zm16 0v160h72V48h-72Z'],
    'command': ['M88 40a32 32 0 0 1 32 32v8h16v-8a32 32 0 1 1 32 32h-16v48h16a32 32 0 1 1-32 32v-16h-16v16a32 32 0 1 1-32-32h16v-48H88a32 32 0 1 1 0-64Zm0 16a16 16 0 1 0 0 32h16V72a16 16 0 0 0-16-16Zm80 0a16 16 0 0 0-16 16v16h16a16 16 0 1 0 0-32ZM88 168a16 16 0 1 0 16 16v-16H88Zm64 0v16a16 16 0 1 0 16-16h-16Zm-32-64v48h16v-48h-16Z'],
    'copy': ['M88 64h96a24 24 0 0 1 24 24v96a24 24 0 0 1-24 24H88a24 24 0 0 1-24-24V88a24 24 0 0 1 24-24Zm-32 24v96a32 32 0 0 0 32 32h96a8 8 0 0 1-8 8H72a40 40 0 0 1-40-40V80a8 8 0 0 1 8-8h8a8 8 0 0 1 8 8v8Z'],
    'copy-simple': ['M72 48h104a16 16 0 0 1 16 16v128a16 16 0 0 1-16 16H72a16 16 0 0 1-16-16V64a16 16 0 0 1 16-16Zm24-24h96a40 40 0 0 1 40 40v104a8 8 0 0 1-16 0V64a24 24 0 0 0-24-24H96a8 8 0 0 1 0-16Z'],
    'dots-six-vertical': ['M92 60a12 12 0 1 1-12-12 12 12 0 0 1 12 12Zm84 12a12 12 0 1 0-12-12 12 12 0 0 0 12 12ZM80 116a12 12 0 1 0 12 12 12 12 0 0 0-12-12Zm96 0a12 12 0 1 0 12 12 12 12 0 0 0-12-12ZM80 184a12 12 0 1 0 12 12 12 12 0 0 0-12-12Zm96 0a12 12 0 1 0 12 12 12 12 0 0 0-12-12Z'],
    'download-simple': ['M128 24a8 8 0 0 1 8 8v102.7l34.3-34.4a8 8 0 0 1 11.4 11.4l-48 48a8 8 0 0 1-11.4 0l-48-48a8 8 0 1 1 11.4-11.4L120 134.7V32a8 8 0 0 1 8-8Zm-88 144a8 8 0 0 1 8 8v24h160v-24a8 8 0 0 1 16 0v24a16 16 0 0 1-16 16H48a16 16 0 0 1-16-16v-24a8 8 0 0 1 8-8Z'],
    'file': ['M56 24h96l48 48v136a24 24 0 0 1-24 24H56a24 24 0 0 1-24-24V48a24 24 0 0 1 24-24Zm88 16v40h40l-40-40Z'],
    'file-arrow-down': ['M56 24h96l48 48v136a24 24 0 0 1-24 24H56a24 24 0 0 1-24-24V48a24 24 0 0 1 24-24Zm72 72a8 8 0 0 0-8 8v48.7l-18.3-18.4a8 8 0 0 0-11.4 11.4l32 32a8 8 0 0 0 11.4 0l32-32a8 8 0 0 0-11.4-11.4L136 152.7V104a8 8 0 0 0-8-8Z'],
    'filter': ['M32 56a16 16 0 0 1 16-16h160a16 16 0 0 1 12.5 26l-60.5 75.6V200a8 8 0 0 1-3.6 6.7l-40 26.7A8 8 0 0 1 104 226.7v-85.1L43.5 66A16 16 0 0 1 32 56Z'],
    'folder': ['M24 72a24 24 0 0 1 24-24h48l24 24h88a24 24 0 0 1 24 24v88a24 24 0 0 1-24 24H48a24 24 0 0 1-24-24V72Z'],
    'folder-dashed': ['M48 56h48l24 24h40a8 8 0 0 1 0 16h-43.3a8 8 0 0 1-5.7-2.3L89.4 72H48a8 8 0 0 0-8 8v16a8 8 0 0 1-16 0V80a24 24 0 0 1 24-24Zm152 40a24 24 0 0 1 24 24v64a24 24 0 0 1-24 24h-24a8 8 0 0 1 0-16h24a8 8 0 0 0 8-8v-64a8 8 0 0 0-8-8h-8a8 8 0 0 1 0-16h8ZM32 120a8 8 0 0 1 8 8v16a8 8 0 0 1-16 0v-16a8 8 0 0 1 8-8Zm0 48a8 8 0 0 1 8 8v8a8 8 0 0 0 8 8h16a8 8 0 0 1 0 16H48a24 24 0 0 1-24-24v-8a8 8 0 0 1 8-8Zm56 32a8 8 0 0 1 8-8h48a8 8 0 0 1 0 16H96a8 8 0 0 1-8-8Z'],
    'folder-open': ['M24 88a24 24 0 0 1 24-24h52.7l21.6 21.7a8 8 0 0 0 5.7 2.3h88a16 16 0 0 1 15.3 20.6l-28.8 96A24 24 0 0 1 179.5 224H52.5A24 24 0 0 1 29.6 207L8.7 137.3A24 24 0 0 1 31.7 106H208l.6-2H128a24 24 0 0 1-17-7L93.4 80H48a8 8 0 0 0-8 8v18H31.7a24.6 24.6 0 0 0-7.7 1.3V88Z'],
    'grid-four': ['M40 40h72v72H40V40Zm104 0h72v72h-72V40ZM40 144h72v72H40v-72Zm104 0h72v72h-72v-72Z'],
    'hard-drives': ['M56 32h144a24 24 0 0 1 24 24v48a24 24 0 0 1-24 24H56a24 24 0 0 1-24-24V56a24 24 0 0 1 24-24Zm0 112h144a24 24 0 0 1 24 24v32a24 24 0 0 1-24 24H56a24 24 0 0 1-24-24v-32a24 24 0 0 1 24-24Zm112 40a12 12 0 1 0 12-12 12 12 0 0 0-12 12Z'],
    'image-square': ['M48 32h160a16 16 0 0 1 16 16v160a16 16 0 0 1-16 16H48a16 16 0 0 1-16-16V48a16 16 0 0 1 16-16Zm32 56a24 24 0 1 0 24-24 24 24 0 0 0-24 24Zm128 104v-34.7l-34.3-34.3a8 8 0 0 0-11.4 0L120 165.3l-18.3-18.3a8 8 0 0 0-11.4 0L48 189.3V208h160v-16Z'],
    'images': ['M48 40h128a24 24 0 0 1 24 24v112a24 24 0 0 1-24 24H48a24 24 0 0 1-24-24V64a24 24 0 0 1 24-24Zm176 32a8 8 0 0 1 8 8v128a24 24 0 0 1-24 24H72a8 8 0 0 1 0-16h136a8 8 0 0 0 8-8V80a8 8 0 0 1 8-8Z'],
    'list': ['M88 64h128a8 8 0 0 1 0 16H88a8 8 0 0 1 0-16Zm0 56h128a8 8 0 0 1 0 16H88a8 8 0 0 1 0-16Zm0 56h128a8 8 0 0 1 0 16H88a8 8 0 0 1 0-16ZM40 72a12 12 0 1 1 12 12A12 12 0 0 1 40 72Zm0 56a12 12 0 1 1 12 12 12 12 0 0 1-12-12Zm0 56a12 12 0 1 1 12 12 12 12 0 0 1-12-12Z'],
    'lock-open': ['M80 104V80a48 48 0 0 1 91.5-20.2 8 8 0 1 1-14.5 6.7A32 32 0 0 0 96 80v24h88a16 16 0 0 1 16 16v80a16 16 0 0 1-16 16H72a16 16 0 0 1-16-16v-80a16 16 0 0 1 16-16h8Z'],
    'lock-simple': ['M80 104V80a48 48 0 0 1 96 0v24h8a16 16 0 0 1 16 16v80a16 16 0 0 1-16 16H72a16 16 0 0 1-16-16v-80a16 16 0 0 1 16-16h8Zm16 0h64V80a32 32 0 0 0-64 0v24Z'],
    'magic-wand': ['M200 24l12 28 28 12-28 12-12 28-12-28-28-12 28-12 12-28ZM80 40l9.5 22.5L112 72l-22.5 9.5L80 104l-9.5-22.5L48 72l22.5-9.5L80 40Zm79.4 60.6 24 24a8 8 0 0 1 0 11.4l-93.4 93.4a24 24 0 0 1-34 0l-29.4-29.4a24 24 0 0 1 0-34l93.4-93.4a8 8 0 0 1 11.4 0l28 28ZM128 89.4 89.4 128 128 166.6l38.6-38.6L128 89.4Z'],
    'pencil-simple': ['M204.3 73.7 182.3 51.7a24 24 0 0 0-34 0L45.7 154.3a8 8 0 0 0-2.1 3.8l-16 64a8 8 0 0 0 9.7 9.7l64-16a8 8 0 0 0 3.8-2.1L207.7 107.7a24 24 0 0 0-3.4-34Z'],
    'palette': ['M128 24a104 104 0 0 0 0 208h16a24 24 0 0 0 0-48h-12a12 12 0 0 1 0-24h44a56 56 0 0 0 0-112A103.6 103.6 0 0 0 128 24ZM80 104a16 16 0 1 1 16-16 16 16 0 0 1-16 16Zm40-32a16 16 0 1 1 16 16 16 16 0 0 1-16-16Zm56 32a16 16 0 1 1 16-16 16 16 0 0 1-16 16ZM88 152a16 16 0 1 1 16-16 16 16 0 0 1-16 16Z'],
    'star': ['M128 24l30.9 62.6 69.1 10-50 48.8 11.8 68.8L128 181.7 66.2 214.2 78 145.4 28 96.6l69.1-10L128 24Z'],
    'plus': ['M128 40a8 8 0 0 1 8 8v72h72a8 8 0 0 1 0 16h-72v72a8 8 0 0 1-16 0v-72H48a8 8 0 0 1 0-16h72V48a8 8 0 0 1 8-8Z'],
    'squares-four': ['M48 40h64v64H48V40Zm96 0h64v64h-64V40ZM48 152h64v64H48v-64Zm96 0h64v64h-64v-64Z'],
    'tray': ['M40 40h176a16 16 0 0 1 16 16v144a16 16 0 0 1-16 16H40a16 16 0 0 1-16-16V56a16 16 0 0 1 16-16Zm0 112h43.1a8 8 0 0 1 6.7 3.6L101.3 176h53.4l11.5-20.4a8 8 0 0 1 6.7-3.6H216V56H40v96Z'],
    'trash': ['M216 56h-40V40a16 16 0 0 0-16-16H96a16 16 0 0 0-16 16v16H40a8 8 0 0 0 0 16h8v136a16 16 0 0 0 16 16h128a16 16 0 0 0 16-16V72h8a8 8 0 0 0 0-16ZM96 40h64v16H96V40Z'],
    'tree-structure': ['M120 32h16v48h56a16 16 0 0 1 16 16v32h-16V96h-56v32h-16V96H64v32H48V96a16 16 0 0 1 16-16h56V32Zm-88 112h48v48H32v-48Zm72 0h48v48h-48v-48Zm72 0h48v48h-48v-48Z'],
    'text-aa': ['M73 48h22l45 136h-22l-10-32H59l-10 32H27L73 48Zm-8 84h37L83.5 73 65 132Zm106-15h18l31 67h-20l-6-14h-29l-6 14h-19l31-67Zm0 38h18l-9-21-9 21Z'],
    'eye-slash': ['M39 35a8 8 0 0 1 11.3 0l171 171a8 8 0 0 1-11.3 11.3l-28.8-28.8A126.7 126.7 0 0 1 128 200C64 200 26 132 24.4 129.1a8 8 0 0 1 0-7.8 149.8 149.8 0 0 1 43.3-48.4L27.7 46.3A8 8 0 0 1 39 35Zm89 21c64 0 102 68 103.6 70.9a8 8 0 0 1 0 7.8 143.5 143.5 0 0 1-28 36.5l-28.5-28.5A48 48 0 0 0 113.3 80.9L92.7 60.3A126.3 126.3 0 0 1 128 56Z'],
    'bounding-box': ['M48 32h48v16H56a8 8 0 0 0-8 8v40H32V48a16 16 0 0 1 16-16Zm112 0h48a16 16 0 0 1 16 16v48h-16V56a8 8 0 0 0-8-8h-40V32ZM32 160h16v40a8 8 0 0 0 8 8h40v16H48a16 16 0 0 1-16-16v-48Zm176 0h16v48a16 16 0 0 1-16 16h-48v-16h40a8 8 0 0 0 8-8v-40Z'],
    'device-mobile': ['M88 24h80a24 24 0 0 1 24 24v160a24 24 0 0 1-24 24H88a24 24 0 0 1-24-24V48a24 24 0 0 1 24-24Zm0 16a8 8 0 0 0-8 8v160a8 8 0 0 0 8 8h80a8 8 0 0 0 8-8V48a8 8 0 0 0-8-8h-80Zm24 144h32v16h-32v-16Z'],
    'square': ['M56 48h144a8 8 0 0 1 8 8v144a8 8 0 0 1-8 8H56a8 8 0 0 1-8-8V56a8 8 0 0 1 8-8Zm8 16v128h128V64H64Z'],
    'upload-simple': ['M128 24a8 8 0 0 1 5.7 2.3l48 48a8 8 0 1 1-11.4 11.4L136 51.3V152a8 8 0 0 1-16 0V51.3L85.7 85.7a8 8 0 0 1-11.4-11.4l48-48A8 8 0 0 1 128 24Zm-88 144a8 8 0 0 1 8 8v24h160v-24a8 8 0 0 1 16 0v24a16 16 0 0 1-16 16H48a16 16 0 0 1-16-16v-24a8 8 0 0 1 8-8Z'],
    'user': ['M128 128a48 48 0 1 0-48-48 48 48 0 0 0 48 48Zm0 16c-44.2 0-80 22.4-80 50v6a16 16 0 0 0 16 16h128a16 16 0 0 0 16-16v-6c0-27.6-35.8-50-80-50Z'],
    'x': ['M205.7 61.7a8 8 0 0 0-11.4-11.4L128 116.7 61.7 50.3a8 8 0 0 0-11.4 11.4L116.7 128l-66.4 66.3a8 8 0 0 0 11.4 11.4L128 139.3l66.3 66.4a8 8 0 0 0 11.4-11.4L139.3 128l66.4-66.3Z']
  };
  const mediaIconAliases = { 'brackets-curly':'file', 'folder-simple-plus':'folder', 'hard-drive':'hard-drives' };
  const ph = (n, props={})=>{
    const name = mediaIconAliases[n] || n || 'file';
    const paths = mediaIconPaths[name] || mediaIconPaths.file;
    const cls = 've-ms-icon ' + (props.class || '');
    const style = props.style || '';
    return h('svg', { ...(props||{}), class: cls, style, viewBox:'0 0 256 256', width:'1em', height:'1em', fill:'currentColor', stroke:'none', 'aria-hidden':'true', focusable:'false' }, paths.map((d,i)=>h('path',{key:'tone-'+i,d,class:'ve-ms-icon-tone'})).concat(paths.map((d,i)=>h('path',{key:'main-'+i,d,class:'ve-ms-icon-main'}))));
  };
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [collectionSearch, setCollectionSearch] = useState('');
  const [collectionSort, setCollectionSort] = useState(() => localStorage.getItem('ve_media_collection_sort') || 'az');
  const [selected, setSelected] = useState(null);
  const insertLockRef = useRef(false);
  const [mediaUsage, setMediaUsage] = useState(null);
  const [mediaUsageLoading, setMediaUsageLoading] = useState(false);
  const [mediaUsageError, setMediaUsageError] = useState('');
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(null);
  const [mediaBusyMessage, setMediaBusyMessage] = useState('');
  useEffect(() => {
    if (!uploadProgress) return;
    const state = String(uploadProgress.state || '');
    const shouldAutoDismiss = !!uploadProgress.dismissMs || /(complete|failed|finished|saved|filled|converted|compressed|deleted|uploaded|imported)/i.test(state);
    if (!shouldAutoDismiss) return;
    const delay = Math.max(5000, Number(uploadProgress.dismissMs || 5000) || 5000);
    const current = uploadProgress;
    const timer = setTimeout(() => {
      setUploadProgress(prev => prev === current ? null : prev);
    }, delay);
    return () => clearTimeout(timer);
  }, [uploadProgress]);
  const [urlImportBusy, setUrlImportBusy] = useState(false);
  const [pendingUrlImport, setPendingUrlImport] = useState(null);
  const urlImportRef = useRef(null);
  const normalizeMediaLayout = mode => (mode === 'list' || mode === 'masonry' ? mode : 'grid');
  const [layoutMode, setLayoutMode] = useState(() => normalizeMediaLayout(localStorage.getItem('ve_media_layout') || 'grid'));
  const defaultListMetaFields = ['mime','size','dimensions','uploaded'];
  const [listMetaFields, setListMetaFields] = useState(() => {
    try {
      const saved = JSON.parse(localStorage.getItem('ve_media_list_meta_fields') || 'null');
      if (Array.isArray(saved)) return saved.filter(Boolean);
    } catch(e) {}
    return localStorage.getItem('ve_media_list_meta') === '0' ? [] : defaultListMetaFields;
  });
  const showListMeta = listMetaFields.length > 0;
  const [listMetaPanelOpen, setListMetaPanelOpen] = useState(false);
  const [selectedColl, setSelectedColl] = useState('all');
  const [checkedItems, setCheckedItems] = useState([]);
  const fileInputRef = useRef(null);
  const zipImportRef = useRef(null);
  const zipImportTargetRef = useRef('');
  const [zipImportBusy, setZipImportBusy] = useState(false);
  const [filterType, setFilterType] = useState(() => localStorage.getItem('ve_media_filter') || 'all');
  const parseStoredQualityFilters = raw => {
    if (!raw) return [];
    try {
      const parsed = String(raw).trim().charAt(0) === '[' ? JSON.parse(raw) : null;
      if (Array.isArray(parsed)) return [...new Set(parsed.map(String).filter(x => x && x !== 'all'))];
    } catch(e) {}
    return [...new Set(String(raw).split(',').map(x => x.trim()).filter(x => x && x !== 'all'))];
  };
  const [qualityFilter, setQualityFilter] = useState(() => localStorage.getItem('ve_media_quality_filter') || 'all');
  const [qualityFilters, setQualityFilters] = useState(() => parseStoredQualityFilters(localStorage.getItem('ve_media_quality_filters') || localStorage.getItem('ve_media_quality_filter') || ''));
  const [qualityPanelOpen, setQualityPanelOpen] = useState(false);
  const [qualityQuery, setQualityQuery] = useState('');
  const readSavedQualityPresets = () => {
    try {
      const parsed = JSON.parse(localStorage.getItem('ve_media_saved_filters') || '[]');
      return Array.isArray(parsed) ? parsed.filter(x => x && x.name && Array.isArray(x.qualityFilters)).slice(0, 12) : [];
    } catch(e) {
      return [];
    }
  };
  const [savedQualityPresets, setSavedQualityPresets] = useState(readSavedQualityPresets);
  const [qualityPresetName, setQualityPresetName] = useState('');
  const [unusedScan, setUnusedScan] = useState({ key: '', ids: null, loading: false, scanned: 0, limited: false, message: '' });
  const unusedScanRunRef = useRef(0);
  const unusedScanTimeoutRef = useRef(null);
  const [viewPanelOpen, setViewPanelOpen] = useState(false);
  const viewPanelCloseTimerRef = useRef(null);
  const viewPanelRef = useRef(null);
  const [masonryColumnCount, setMasonryColumnCount] = useState(5);
  const [sortBy, setSortBy] = useState(() => localStorage.getItem('ve_media_sort') || 'date');
  const [showNewCollForm, setShowNewCollForm] = useState(false);
  const [newCollName, setNewCollName] = useState('');
  const newCollInputRef = useRef(null);
  const [newCollIcon, setNewCollIcon] = useState('folder');
  const [iconSearch, setIconSearch] = useState('');
  const [iconCatalog, setIconCatalog] = useState(COLL_ICONS);
  const [folderData, setFolderData] = useState({ folders: [], map: {} });
  const [dragActive, setDragActive] = useState(false);
  const [lastMediaIndex, setLastMediaIndex] = useState(null);
  const [pendingBatchCollection, setPendingBatchCollection] = useState(false);
  const [convertFormat, setConvertFormat] = useState('webp');
  const [convertingId, setConvertingId] = useState(null);
  const [pendingDeleteMedia, setPendingDeleteMedia] = useState(null);
  const [pendingBatchDelete, setPendingBatchDelete] = useState(false);
  const [pendingReplaceRequest, setPendingReplaceRequest] = useState(null);
  const [urlImportHistory, setUrlImportHistory] = useState([]);
  const [diagnostics, setDiagnostics] = useState(null);
  const [diagnosticsLoading, setDiagnosticsLoading] = useState(false);
  const [pendingDeleteCollection, setPendingDeleteCollection] = useState(null);
  const [batchNewCollName, setBatchNewCollName] = useState('');
  const [batchNewCollIcon, setBatchNewCollIcon] = useState('folder');
  const [filenameDraft, setFilenameDraft] = useState('');
  const [altDraft, setAltDraft] = useState('');
  const [captionDraft, setCaptionDraft] = useState('');
  const [descriptionDraft, setDescriptionDraft] = useState('');
  const [mediaSaveState, setMediaSaveState] = useState('');
  const [pendingRename, setPendingRename] = useState(null);
  const replaceInputRef = useRef(null);
  const [collectionMenu, setCollectionMenu] = useState(null);
  const [collectionColorPicker, setCollectionColorPicker] = useState(null);
  const [collectionColorFmt, setCollectionColorFmt] = useState('hex');
  const [renameCollectionKey, setRenameCollectionKey] = useState(null);
  const [renameCollectionName, setRenameCollectionName] = useState('');
  const [dragCollection, setDragCollection] = useState(null);
  const [dropCollection, setDropCollection] = useState(null);
  const [dropMode, setDropMode] = useState('');
  const [collectionCreateModal, setCollectionCreateModal] = useState(null);
  const [externalFolderTip, setExternalFolderTip] = useState(null);
  const [detailPreviewMode, setDetailPreviewMode] = useState(() => localStorage.getItem('ve_media_detail_preview_mode') || 'fit');
  const [detailPreviewZoom, setDetailPreviewZoom] = useState(() => Math.max(1, Math.min(4, parseFloat(localStorage.getItem('ve_media_detail_preview_zoom') || '1') || 1)));
  const [mediaDragIds, setMediaDragIds] = useState([]);
  const [showCommandPanel, setShowCommandPanel] = useState(false);
  const [showDynamicFolders, setShowDynamicFolders] = useState(false);
  const [dynamicCollapsed, setDynamicCollapsed] = useState(() => {
    try {
      const parsed = JSON.parse(localStorage.getItem('ve_media_dynamic_collapsed') || '{}');
      return parsed && typeof parsed === 'object' && !Array.isArray(parsed) ? parsed : {};
    } catch(e) {
      return {};
    }
  });
  const [dynamicFilter, setDynamicFilter] = useState(null);
  const [sidebarWidth, setSidebarWidth] = useState(() => Math.max(320, Math.min(480, parseInt(localStorage.getItem('ve_media_sidebar_width') || '320', 10) || 320)));
  const [viewPanelSuppressed, setViewPanelSuppressed] = useState(false);
  const selectedMediaRef = useRef(null);
  const pickerClickRef = useRef({ id: null, at: 0 });
  const mediaLayoutRef = useRef(null);
  const mediaMainRef = useRef(null);
  const detailPreviewRef = useRef(null);
  const qualityPanelRef = useRef(null);
  useEffect(() => {
    if (!showNewCollForm && !collectionCreateModal) return;
    const timer = setTimeout(() => {
      try { newCollInputRef.current?.focus?.(); newCollInputRef.current?.select?.(); } catch(e) {}
    }, 30);
    return () => clearTimeout(timer);
  }, [showNewCollForm, collectionCreateModal]);
  const listMetaPanelRef = useRef(null);
  useEffect(() => () => {
    if (viewPanelCloseTimerRef.current) clearTimeout(viewPanelCloseTimerRef.current);
  }, []);
  useEffect(() => {
    const updateColumns = () => {
      const width = mediaMainRef.current?.clientWidth || mediaLayoutRef.current?.clientWidth || window.innerWidth || 900;
      const next = Math.max(2, Math.min(6, Math.floor(width / 205)));
      setMasonryColumnCount(next || 5);
    };
    updateColumns();
    let observer = null;
    if (typeof ResizeObserver !== 'undefined' && mediaMainRef.current) {
      observer = new ResizeObserver(updateColumns);
      observer.observe(mediaMainRef.current);
    }
    window.addEventListener('resize', updateColumns);
    return () => {
      window.removeEventListener('resize', updateColumns);
      if (observer) observer.disconnect();
    };
  }, []);
  const mediaDropDepthRef = useRef(0);
  const mediaDragActiveRef = useRef(false);
  const mediaDragCandidateRef = useRef(false);
  const collectionDragActiveRef = useRef(false);
  const internalDragBlockUntilRef = useRef(0);
  const fileDragClearTimerRef = useRef(null);
  const [showMigrationModal, setShowMigrationModal] = useState(false);
  const [selectedMigrateFolders, setSelectedMigrateFolders] = useState([]);
  const [migrateHideFolders, setMigrateHideFolders] = useState(false);
  const [hideFolders, setHideFolders] = useState(() => localStorage.getItem('ve_media_hide_folders') === 'true');
  const [collapsedPaths, setCollapsedPaths] = useState(loadMediaCollapsedPaths);

  // Collections are WordPress-backed via MV Media Collections taxonomy.
  // localStorage remains a fast cache and migration bridge for older local-only maps.
  const readLocalCollections = () => {
    try {
      const saved = localStorage.getItem('ve_media_collections');
      if (!saved) return {};
      const parsed = JSON.parse(saved);
      const migrated = {};
      for (const k of Object.keys(parsed || {})) {
        if (String(k).indexOf('folder:') === 0) continue;
        if (Array.isArray(parsed[k])) {
          migrated[k] = { ids: parsed[k], icon: 'folder' };
        } else if (parsed[k] && typeof parsed[k] === 'object') {
          migrated[k] = parsed[k];
        }
      }
      return migrated;
    } catch (e) {
      return {};
    }
  };

  const [collectionMap, setCollectionMap] = useState(readLocalCollections);
  const [collectionsHydrated, setCollectionsHydrated] = useState(false);

  const cacheCollections = (next) => {
    const safe = next && typeof next === 'object' && !Array.isArray(next) ? next : {};
    setCollectionMap(safe);
    localStorage.setItem('ve_media_collections', JSON.stringify(safe));
    persistUserPreference('ve_media_collections', JSON.stringify(safe));
    try { window.dispatchEvent(new CustomEvent('ve-media-collections-changed', { detail: safe })); } catch(e) {}
  };

  const applyServerCollections = (res) => {
    if (!res || res.code || !res.collections || typeof res.collections !== 'object') return false;
    cacheCollections(res.collections);
    if (res.map) {
      setFolderData(prev => ({ ...(prev || {}), mvMap: res.map }));
    }
    return true;
  };

  const persistCollections = (next, options = {}) => {
    cacheCollections(next);
    api.p('media-studio/collections/sync', {
      collections: next,
      delete_missing: options.deleteMissing !== false
    }).then(res => {
      if (res && res.success) applyServerCollections(res);
    }).catch(() => {});
  };

  const loadMvCollections = useCallback(async () => {
    try {
      const res = await api.g('media-studio/collections');
      const serverCollections = res && res.collections && typeof res.collections === 'object' ? res.collections : {};
      if (Object.keys(serverCollections).length) {
        applyServerCollections(res);
      } else {
        const local = readLocalCollections();
        if (Object.keys(local).length) {
          const migrated = await api.p('media-studio/collections/sync', { collections: local, delete_missing: false });
          if (!applyServerCollections(migrated)) cacheCollections(local);
        }
      }
    } catch (e) {}
    setCollectionsHydrated(true);
  }, []);

  const makeCollectionKey = label => (label || '').trim().toLowerCase().replace(/\s*\/\s*/g, '/').replace(/[^a-z0-9/]+/g, '_').replace(/^_+|_+$/g, '');
  const isFolderCollection = key => String(key || '').indexOf('folder:') === 0;
  const folderIdFromKey = key => String(key || '').replace(/^folder:/, '');
  const folderKey = id => 'folder:' + id;
  const folderByKey = key => (folderData.folders || []).find(f => String(f.id) === folderIdFromKey(key));
  const isLockedCollection = key => !!(!isFolderCollection(key) && collectionMap[key] && collectionMap[key].locked);
  const isStarredCollection = key => !!(!isFolderCollection(key) && collectionMap[key] && collectionMap[key].starred);
  const COLLECTION_COLOR_PRESETS = ['#baf400', '#8ddcff', '#8b5cf6', '#f97316', '#ef4444', '#22c55e', '#f59e0b', '#ec4899', '#94a3b8'];
  const normalizeCollectionColor = value => {
    const raw = String(value || '').trim();
    return /^#[0-9a-f]{6}$/i.test(raw) ? raw : '';
  };
  const collectionColor = key => normalizeCollectionColor(!isFolderCollection(key) && collectionMap[key] && collectionMap[key].color ? collectionMap[key].color : '');

  const buildFolderPath = (folder) => {
    if (!folder) return '';
    const parts = [folder.name];
    let current = folder;
    while (current && current.parent && current.parent !== '0') {
      const parentFolder = (folderData.folders || []).find(f => String(f.id) === String(current.parent));
      if (parentFolder) {
        parts.unshift(parentFolder.name);
        current = parentFolder;
      } else {
        break;
      }
    }
    return parts.join(' / ');
  };

  const collLabel = (key) => {
    if (isFolderCollection(key)) {
      const folder = folderByKey(key);
      return folder ? buildFolderPath(folder) : folderIdFromKey(key);
    }
    const entry = collectionMap[key];
    return (entry && entry.label) || key.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase());
  };

  const treeAwareCollectionOrder = keys => {
    const sourceOrder = new Map(keys.map((key, index) => [key, index]));
    const byParent = new Map();
    const labelByKey = new Map(keys.map(key => [key, collLabel(key)]));
    keys.forEach(key => {
      const label = labelByKey.get(key) || '';
      const parts = label.split('/').map(x => x.trim()).filter(Boolean);
      const parent = parts.slice(0, -1).join(' / ');
      if (!byParent.has(parent)) byParent.set(parent, []);
      byParent.get(parent).push(key);
    });
    byParent.forEach(list => list.sort((a, b) => (sourceOrder.get(a) || 0) - (sourceOrder.get(b) || 0)));
    const out = [];
    const seen = new Set();
    const walk = parent => {
      (byParent.get(parent) || []).forEach(key => {
        if (seen.has(key)) return;
        seen.add(key);
        out.push(key);
        walk(labelByKey.get(key) || '');
      });
    };
    walk('');
    keys.forEach(key => { if (!seen.has(key)) out.push(key); });
    return out;
  };

  const compareCollectionKeys = (a, b) => {
    const aStar = isStarredCollection(a) ? 1 : 0;
    const bStar = isStarredCollection(b) ? 1 : 0;
    if (aStar !== bStar) return bStar - aStar;
    if (collectionSort === 'za') return collLabel(b).localeCompare(collLabel(a));
    if (collectionSort === 'old' || collectionSort === 'manual') return 0;
    return collLabel(a).localeCompare(collLabel(b));
  };

  let localCollKeys = Object.keys(collectionMap);
  localCollKeys.sort(compareCollectionKeys);
  localCollKeys = treeAwareCollectionOrder(localCollKeys);

  let folderCollKeys = (hideFolders || !folderData.folders) ? [] : (folderData.folders || []).map(f => folderKey(f.id));
  folderCollKeys.sort(compareCollectionKeys);
  folderCollKeys = treeAwareCollectionOrder(folderCollKeys);

  const collKeys = [...folderCollKeys, ...localCollKeys];
  const collectionSearchTerm = collectionSearch.trim().toLowerCase();
  const visibleCollKeys = collKeys.filter(key => !collectionSearchTerm || collLabel(key).toLowerCase().includes(collectionSearchTerm));
  const collectionLabelToKey = useMemo(() => {
    const map = {};
    collKeys.forEach(key => { const label = collLabel(key); if (label) map[label] = key; });
    return map;
  }, [collKeys.join('|'), folderData.folders, collectionMap]);
  const collectionCollapseId = (key, label) => key ? ('key:' + String(key)) : ('path:' + String(label || ''));
  const isCollectionBranchCollapsed = (key, label) => {
    const id = collectionCollapseId(key, label);
    if (Object.prototype.hasOwnProperty.call(collapsedPaths, id)) return !!collapsedPaths[id];
    if (!key && label && Object.prototype.hasOwnProperty.call(collapsedPaths, String(label))) return !!collapsedPaths[String(label)];
    return false;
  };
  const setCollectionBranchCollapsed = (key, label, collapsed) => {
    const id = collectionCollapseId(key, label);
    const next = { ...collapsedPaths, [id]: !!collapsed };
    if (!key && label) next[String(label)] = !!collapsed; // legacy label fallback only when no stable key exists.
    setCollapsedPaths(next);
    persistMediaCollapsedPaths(next);
    window.dispatchEvent(new CustomEvent('ve-media-collapsed-paths-changed', { detail: next }));
  };
  const collectionBranchLabels = useMemo(() => {
    const labels = collKeys.map(key => collLabel(key)).filter(Boolean);
    return labels.filter(label => labels.some(other => other !== label && other.indexOf(label + ' / ') === 0));
  }, [collKeys.join('|'), folderData.folders, collectionMap]);
  const hasCollapsedCollectionBranches = collectionBranchLabels.some(label => isCollectionBranchCollapsed(collectionLabelToKey[label], label));
  const collectionBranchesAllExpanded = collectionBranchLabels.length > 0 && !hasCollapsedCollectionBranches;
  const toggleAllCollectionBranches = () => {
    const next = {};
    if (collectionBranchesAllExpanded) {
      collectionBranchLabels.forEach(label => {
        const key = collectionLabelToKey[label];
        next[collectionCollapseId(key, label)] = true;
        next[label] = true;
      });
    }
    setCollapsedPaths(next);
    persistMediaCollapsedPaths(next);
    window.dispatchEvent(new CustomEvent('ve-media-collapsed-paths-changed', { detail: next }));
  };
  const persistCollectionSort = value => {
    setCollectionSort(value);
    persistUserPreference('ve_media_collection_sort', value);
  };

  const openMediaCollection = key => {
    if (selectedColl === key) return;
    // Keep the selection tray alive across collections so users can collect media
    // from multiple collections before running a batch action.
    if (checkedItems.length) {
      flash('Kept ' + checkedItems.length + ' selected across collections. Use Deselect when you are done.');
    }
    setPendingBatchCollection(false);
    setSelected(null);
    setLastMediaIndex(null);
    setSelectedColl(key);
  };

  const toggleCollectionItem = (coll, id, checked) => {
    if (isFolderCollection(coll)) {
      const folderId = folderIdFromKey(coll);
      api.p('media-studio/folders/assign', { attachment_id: id, folder_id: folderId, checked: checked }).then(r => {
        if (r && r.success) {
          setFolderData(prev => {
            const nextMap = { ...(prev.map || {}) };
            const list = (nextMap[id] || []).map(String);
            const nextList = checked ? [...new Set([...list, String(folderId)])] : list.filter(x => x !== String(folderId));
            nextMap[id] = nextList;
            return { ...prev, map: nextMap };
          });
          flash(checked ? `Added to "${collLabel(coll)}"` : `Removed from "${collLabel(coll)}"`);
        } else {
          flash('Folder update failed.');
        }
      }).catch(() => flash('Folder update failed.'));
      return;
    }
    const entry = collectionMap[coll] || { ids: [], icon: 'folder' };
    if (entry.locked) {
      flash('Unlock this collection before changing its media.');
      return;
    }
    const ids = entry.ids || [];
    const nextIds = checked ? [...ids, id] : ids.filter(x => x !== id);
    persistCollections({ ...collectionMap, [coll]: { ...entry, ids: nextIds } });
    flash(checked ? `Added to "${coll}"` : `Removed from "${coll}"`);
  };

  const createCollection = () => {
    const label = newCollName.trim();
    if (!label) { flash('Enter a collection name.'); return; }
    const key = makeCollectionKey(label);
    if (!key || collectionMap[key]) { flash('Collection already exists or name is invalid.'); return; }
    persistCollections({ ...collectionMap, [key]: { ids: [], icon: newCollIcon, label: label } });
    setNewCollName('');
    setNewCollIcon('folder');
    setShowNewCollForm(false);
    setCollectionCreateModal(null);
    flash(`Collection "${label}" created!`);
  };

  const requestDeleteCollection = (key) => {
    if (!key || isFolderCollection(key) || !collectionMap[key]) return;
    if (isLockedCollection(key)) { flash('Unlock this collection before deleting it.'); return; }
    setPendingDeleteCollection({ key, label: collLabel(key), count: collCounts[key] || 0 });
  };

  const confirmDeleteCollection = () => {
    const key = pendingDeleteCollection?.key;
    if (!key || isFolderCollection(key) || !collectionMap[key]) {
      setPendingDeleteCollection(null);
      return;
    }
    const next = { ...collectionMap };
    delete next[key];
    persistCollections(next);
    if (selectedColl === key) setSelectedColl('all');
    setPendingDeleteCollection(null);
    flash('Collection removed.');
  };

  const renameLocalCollection = (oldKey, nextLabel) => {
    if (!oldKey || isFolderCollection(oldKey)) return;
    if (isLockedCollection(oldKey)) { flash('Unlock this collection before renaming it.'); return; }
    const label = (nextLabel || '').trim();
    const nextKey = makeCollectionKey(label);
    if (!label || !nextKey) { flash('Enter a valid collection name.'); return; }
    if (nextKey !== oldKey && collectionMap[nextKey]) { flash('Collection already exists.'); return; }
    const next = {};
    Object.keys(collectionMap).forEach(key => {
      if (key === oldKey) {
        next[nextKey] = { ...(collectionMap[oldKey] || {}), label };
      } else {
        next[key] = collectionMap[key];
      }
    });
    persistCollections(next);
    if (selectedColl === oldKey) setSelectedColl(nextKey);
    setRenameCollectionKey(null);
    setRenameCollectionName('');
    flash('Collection renamed.');
  };

  const collectionLabelPartsForMove = key => collLabel(key).split('/').map(x => x.trim()).filter(Boolean);
  const collectionParentLabel = key => collectionLabelPartsForMove(key).slice(0, -1).join(' / ');

  const moveCollectionTree = (sourceKey, nextRootLabel, targetKey, message, insertMode = 'before') => {
    if (!sourceKey || !nextRootLabel || isFolderCollection(sourceKey)) return false;
    if (isLockedCollection(sourceKey)) { flash('Unlock this collection before moving it.'); return false; }
    const sourceEntry = collectionMap[sourceKey];
    if (!sourceEntry) return false;
    const oldRootLabel = collLabel(sourceKey);
    const allKeys = Object.keys(collectionMap);
    const subtreeKeys = allKeys.filter(key => key === sourceKey || collLabel(key).startsWith(oldRootLabel + ' / '));
    const subtreeSet = new Set(subtreeKeys);
    if (targetKey && subtreeSet.has(targetKey)) {
      flash('Move this collection outside itself first.');
      return false;
    }

    const mapped = {};
    const movedEntries = [];
    for (const oldKey of subtreeKeys) {
      const oldLabel = collLabel(oldKey);
      const suffix = oldLabel === oldRootLabel ? '' : oldLabel.slice(oldRootLabel.length + 3);
      const newLabel = suffix ? nextRootLabel + ' / ' + suffix : nextRootLabel;
      const newKey = makeCollectionKey(newLabel);
      if (!newKey) { flash('Collection move failed. Invalid collection name.'); return false; }
      if (!subtreeSet.has(newKey) && collectionMap[newKey]) {
        flash('A collection with that name already exists.');
        return false;
      }
      mapped[oldKey] = newKey;
      movedEntries.push([newKey, { ...(collectionMap[oldKey] || {}), label: newLabel }]);
    }

    const next = {};
    const remaining = allKeys.filter(key => !subtreeSet.has(key));
    const targetLabel = targetKey ? collLabel(targetKey) : '';
    const targetSubtree = targetLabel ? new Set(remaining.filter(key => key === targetKey || collLabel(key).startsWith(targetLabel + ' / '))) : new Set();
    let inserted = false;
    const insertMoved = () => {
      if (inserted) return;
      movedEntries.forEach(([nextKey, value]) => { next[nextKey] = value; });
      inserted = true;
    };
    remaining.forEach((key, index) => {
      if (targetKey && key === targetKey && insertMode === 'before') insertMoved();
      next[key] = collectionMap[key];
      if (targetKey && key === targetKey && insertMode === 'after') insertMoved();
      if (targetKey && insertMode === 'afterSubtree' && targetSubtree.has(key)) {
        const nextKey = remaining[index + 1];
        if (!nextKey || !targetSubtree.has(nextKey)) insertMoved();
      }
    });
    if (!inserted) insertMoved();

    persistCollections(next);
    persistCollectionSort('manual');
    if (mapped[selectedColl]) setSelectedColl(mapped[selectedColl]);
    flash(message || 'Collection moved.');
    return true;
  };

  const nestCollectionUnder = (childKey, parentKey) => {
    if (!childKey || !parentKey || childKey === parentKey || isFolderCollection(childKey) || isFolderCollection(parentKey)) return;
    const childLeaf = collectionLeafLabel(childKey);
    const parentLabel = collLabel(parentKey);
    moveCollectionTree(childKey, parentLabel + ' / ' + childLeaf, parentKey, 'Collection nested.', 'afterSubtree');
  };

  const reorderCollectionBefore = (fromKey, toKey) => {
    if (!fromKey || !toKey || fromKey === toKey || isFolderCollection(fromKey) || isFolderCollection(toKey)) return;
    const targetParent = collectionParentLabel(toKey);
    const nextLabel = targetParent ? targetParent + ' / ' + collectionLeafLabel(fromKey) : collectionLeafLabel(fromKey);
    moveCollectionTree(fromKey, nextLabel, toKey, 'Collection reordered.', 'before');
  };

  const reorderCollectionAfter = (fromKey, toKey) => {
    if (!fromKey || !toKey || fromKey === toKey || isFolderCollection(fromKey) || isFolderCollection(toKey)) return;
    const targetParent = collectionParentLabel(toKey);
    const nextLabel = targetParent ? targetParent + ' / ' + collectionLeafLabel(fromKey) : collectionLeafLabel(fromKey);
    moveCollectionTree(fromKey, nextLabel, toKey, 'Collection reordered.', 'afterSubtree');
  };


  const runFoldersMigration = () => {
    if (!selectedMigrateFolders.length) {
      flash('Select at least one folder to migrate.');
      return;
    }
    const nextMap = { ...collectionMap };
    let migratedCount = 0;
    
    selectedMigrateFolders.forEach(folderId => {
      const folder = (folderData.folders || []).find(f => String(f.id) === String(folderId));
      if (!folder) return;
      
      const pathLabel = buildFolderPath(folder);
      const key = makeCollectionKey(pathLabel);
      if (!key) return;
      
      const newIds = collIds('folder:' + folderId) || [];
      const existing = nextMap[key] || { ids: [], icon: 'folder', label: pathLabel };
      const nextIds = [...new Set([...(existing.ids || []), ...newIds])];
      
      nextMap[key] = {
        ids: nextIds,
        icon: existing.icon || 'folder',
        label: pathLabel
      };
      migratedCount++;
    });
    
    persistCollections(nextMap);
    
    localStorage.setItem('ve_media_hide_folders', migrateHideFolders ? 'true' : 'false');
    setHideFolders(migrateHideFolders);
    
    // Dispatch custom events for real-time synchronization
    window.dispatchEvent(new CustomEvent('ve-media-collections-migrated'));
    window.dispatchEvent(new CustomEvent('ve-media-hide-folders-changed', { detail: migrateHideFolders }));
    
    setShowMigrationModal(false);
    flash(`Successfully migrated ${migratedCount} folder(s) to MV collections!`);
  };

  const beginRenameCollection = key => {
    if (isFolderCollection(key)) {
      flash('Detected folder-plugin folders are read-only here.');
      return;
    }
    if (isLockedCollection(key)) {
      flash('Unlock this collection before renaming it.');
      setCollectionMenu(null);
      return;
    }
    setRenameCollectionKey(key);
    setRenameCollectionName(collLabel(key));
    setCollectionMenu(null);
  };

  const beginChildCollection = key => {
    if (isFolderCollection(key)) {
      flash('Folder-plugin folders are detected here, but hierarchy editing stays inside that plugin for now.');
      setCollectionMenu(null);
      return;
    }
    if (isLockedCollection(key)) {
      flash('Unlock this collection before creating a sub-collection.');
      setCollectionMenu(null);
      return;
    }
    setNewCollName(collLabel(key) + ' / ');
    setNewCollIcon('folder');
    setCollectionCreateModal({ parentKey: key });
    setCollectionMenu(null);
  };


  const createCollectionForSelection = () => {
    const label = batchNewCollName.trim();
    if (!label) { flash('Enter a collection name.'); return; }
    const key = makeCollectionKey(label);
    if (!key || collectionMap[key]) { flash('Collection already exists or name is invalid.'); return; }
    const next = { ...collectionMap, [key]: { ids: [...new Set(checkedItems)], icon: batchNewCollIcon, label } };
    persistCollections(next);
    setBatchNewCollName('');
    setBatchNewCollIcon('folder');
    setPendingBatchCollection(false);
    setCheckedItems([]);
    flash(`Created "${label}" and added selected media.`);
  };

  const collIcon = (key) => {
    if (isFolderCollection(key)) return 'folder';
    const entry = collectionMap[key] || {};
    return entry.icon || 'folder';
  };

  const collIds = (key) => {
    if (key === 'uncollected') {
      const assigned = new Set();
      collKeys.forEach(coll => collIds(coll).forEach(id => assigned.add(id)));
      return items.filter(item => !assigned.has(item.id)).map(item => item.id);
    }
    if (isFolderCollection(key)) {
      const fid = folderIdFromKey(key);
      return collectFolderMediaIds(folderData, fid);
    }
    const entry = collectionMap[key] || {};
    return entry.ids || [];
  };

  const isLocalCollectionOpen = () => selectedColl && selectedColl !== 'all' && selectedColl !== 'uncollected' && !isFolderCollection(selectedColl) && !!collectionMap[selectedColl];

  const checkedItemsInCurrentCollection = () => {
    if (!isLocalCollectionOpen()) return [];
    const currentIds = new Set((collIds(selectedColl) || []).map(id => Number(id)));
    return checkedItems.map(id => Number(id)).filter(id => currentIds.has(id));
  };

  const removeCheckedFromCurrentCollection = () => {
    if (!isLocalCollectionOpen()) {
      flash('Open an MV collection before removing media from a collection.');
      return;
    }
    if (isLockedCollection(selectedColl)) {
      flash('Unlock this collection before removing media.');
      return;
    }
    const removeIds = checkedItemsInCurrentCollection();
    if (!removeIds.length) {
      flash('None of the selected media are in "' + collLabel(selectedColl) + '".');
      return;
    }
    const removeSet = new Set(removeIds.map(Number));
    const entry = collectionMap[selectedColl] || { ids: [], icon: 'folder', label: collLabel(selectedColl) };
    const nextIds = (entry.ids || []).map(id => Number(id)).filter(id => !removeSet.has(id));
    persistCollections({ ...collectionMap, [selectedColl]: { ...entry, ids: nextIds } });
    setCheckedItems(prev => prev.map(id => Number(id)).filter(id => !removeSet.has(id)));
    const kept = checkedItems.length - removeIds.length;
    flash('Removed ' + removeIds.length + ' from "' + collLabel(selectedColl) + '"' + (kept > 0 ? '. Kept ' + kept + ' selected from other collections.' : '.'));
  };

  const addUploadedToOpenCollection = (uploadedIds) => {
    const ids = (uploadedIds || []).map(id => Number(id)).filter(Boolean);
    if (!ids.length || !isLocalCollectionOpen()) return;
    const entry = collectionMap[selectedColl] || { ids: [], icon: 'folder', label: collLabel(selectedColl) };
    const nextIds = [...new Set([...(entry.ids || []).map(id => Number(id)).filter(Boolean), ...ids])];
    persistCollections({ ...collectionMap, [selectedColl]: { ...entry, ids: nextIds } });
  };

  const uploadWithProgress = (endpoint, body, headers, onProgress) => new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open('POST', (CFG.apiRoot || '/wp-json/') + endpoint, true);
    xhr.withCredentials = true;
    xhr.setRequestHeader('X-WP-Nonce', CFG.nonce || '');
    Object.entries(headers || {}).forEach(([key, value]) => {
      if (value !== undefined && value !== null && value !== '') xhr.setRequestHeader(key, value);
    });
    xhr.upload.onprogress = event => {
      if (!event.lengthComputable) return;
      const percent = Math.max(1, Math.min(99, Math.round((event.loaded / event.total) * 100)));
      onProgress && onProgress(percent, event.loaded, event.total);
    };
    xhr.onload = () => {
      let data = null;
      try { data = xhr.responseText ? JSON.parse(xhr.responseText) : {}; } catch(e) { data = { code: 've_bad_json', message: 'WordPress returned invalid upload data.' }; }
      if (xhr.status >= 200 && xhr.status < 300 && !data?.code) {
        resolve(data);
      } else {
        reject(new Error(data?.message || data?.code || 'Upload failed.'));
      }
    };
    xhr.onerror = () => reject(new Error('Upload failed. Check your connection, then try again.'));
    xhr.send(body);
  });

  const loadMedia = useCallback(async (q = '') => {
    const hasSearch = !!q.trim();
    if (!hasSearch && Array.isArray(VE_MEDIA_CACHE.items)) {
      setItems(VE_MEDIA_CACHE.items);
      setLoading(false);
    } else {
      setLoading(true);
    }
    try {
      const all = [];
      for (let page = 1; page <= 100; page++) {
        let endpoint = 'wp/v2/media?per_page=100&_embed=author&page=' + page;
        if (q.trim()) endpoint += '&search=' + encodeURIComponent(q.trim());
        const res = await api.f(endpoint);
        if (!Array.isArray(res) || !res.length) break;
        all.push(...res);
        if (res.length < 100) break;
      }
      setItems(all);
      if (!hasSearch) {
        VE_MEDIA_CACHE.items = all;
        VE_MEDIA_CACHE.at = Date.now();
      }
      setLoading(false);
      return all;
    } catch (e) {
      if (!Array.isArray(VE_MEDIA_CACHE.items) || hasSearch) setItems([]);
    }
    setLoading(false);
    return hasSearch ? [] : (VE_MEDIA_CACHE.items || []);
  }, []);

  const loadFolders = useCallback(async () => {
    if (VE_MEDIA_CACHE.folders) {
      setFolderData(VE_MEDIA_CACHE.folders);
    }
    try {
      const res = await api.g('media-studio/folders');
      if (res && !res.code) {
        VE_MEDIA_CACHE.folders = { folders: res.folders || [], map: res.map || {} };
        setFolderData(VE_MEDIA_CACHE.folders);
      }
    } catch (e) {}
  }, []);

  const syncExternalFolders = useCallback(async () => {
    VE_MEDIA_CACHE.folders = null;
    VE_MEDIA_CACHE.items = null;
    try {
      const res = await api.g('media-studio/folders');
      if (res && !res.code) {
        const next = { folders: res.folders || [], map: res.map || {} };
        VE_MEDIA_CACHE.folders = next;
        setFolderData(next);
        loadMedia(search || '');
        flash('External folder plugin synced.');
      } else {
        flash(res?.message || 'External folder sync found no readable folders.');
      }
    } catch (e) {
      flash('External folder sync failed.');
    }
  }, [flash, loadMedia, search]);

  const refreshUrlImportHistory = useCallback(async () => {
    try {
      const res = await api.g('media-studio/url-history');
      if (res && Array.isArray(res.history)) setUrlImportHistory(res.history);
    } catch (e) {}
  }, []);

  const refreshDiagnostics = useCallback(async () => {
    setDiagnosticsLoading(true);
    try {
      const res = await api.g('media-studio/diagnostics');
      if (res && res.success) setDiagnostics(res);
    } catch (e) {}
    setDiagnosticsLoading(false);
  }, []);

  useEffect(() => {
    loadMedia();
    loadFolders();
    loadMvCollections();
    refreshUrlImportHistory();
    refreshDiagnostics();
  }, [loadMedia, loadFolders, loadMvCollections, refreshUrlImportHistory, refreshDiagnostics]);

  useEffect(() => {
    const sync = () => syncExternalFolders();
    window.addEventListener('ve-media-sync-external-folders', sync);
    return () => window.removeEventListener('ve-media-sync-external-folders', sync);
  }, [syncExternalFolders]);

  useEffect(() => {
    const resetDrop = (event) => {
      // Firefox/Chromium can fire pointercancel as soon as native HTML5 dragging starts.
      // Do not clear MV's internal drag markers on pointercancel, otherwise collection/media drags
      // can be mistaken for OS file uploads. A normal pointerup must still clear click-only candidates.
      if (event?.type === 'pointercancel' && (mediaDragActiveRef.current || mediaDragCandidateRef.current || collectionDragActiveRef.current || (Date.now() < internalDragBlockUntilRef.current))) {
        mediaDropDepthRef.current = 0;
        setDragActive(false);
        return;
      }
      mediaDropDepthRef.current = 0;
      mediaDragCandidateRef.current = false;
      mediaDragActiveRef.current = false;
      collectionDragActiveRef.current = false;
      setDragActive(false);
      setMediaDragIds([]);
      setDragCollection(null);
      setDropCollection(null);
      setDropMode('');
      clearInternalDragMarker()
    };
    window.addEventListener('drop', resetDrop);
    window.addEventListener('dragend', resetDrop);
    window.addEventListener('pointerup', resetDrop);
    window.addEventListener('pointercancel', resetDrop);
    window.addEventListener('blur', resetDrop);
    return () => {
      window.removeEventListener('drop', resetDrop);
      window.removeEventListener('dragend', resetDrop);
      window.removeEventListener('pointerup', resetDrop);
      window.removeEventListener('pointercancel', resetDrop);
      window.removeEventListener('blur', resetDrop);
      if (fileDragClearTimerRef.current) clearTimeout(fileDragClearTimerRef.current);
    };
  }, []);

  useEffect(() => {
    try { document.body.classList.add('ve-media-studio-open'); } catch(e) {}
    return () => {
      try { document.body.classList.remove('ve-media-studio-open'); } catch(e) {}
    };
  }, []);

  useEffect(() => {
    if (!picking) return;
    const allowed = ['all','image','svg','video','audio','application','font'];
    const nextFilter = allowed.includes(initialFilter) ? initialFilter : 'image';
    setFilterType(nextFilter);
  }, [picking, initialFilter]);

  useEffect(() => {
    const handleCollectionsMigrated = () => {
      try {
        const saved = localStorage.getItem('ve_media_collections');
        if (saved) setCollectionMap(JSON.parse(saved));
      } catch (e) {}
    };
    const handleHideFoldersChanged = (e) => {
      setHideFolders(e.detail);
    };
    window.addEventListener('ve-media-collections-migrated', handleCollectionsMigrated);
    window.addEventListener('ve-media-hide-folders-changed', handleHideFoldersChanged);
    return () => {
      window.removeEventListener('ve-media-collections-migrated', handleCollectionsMigrated);
      window.removeEventListener('ve-media-hide-folders-changed', handleHideFoldersChanged);
    };
  }, []);

  const mediaTextValue = (item, key) => {
    const value = item && item[key];
    if (!value) return '';
    if (typeof value === 'string') return value;
    if (typeof value === 'object') {
      if (typeof value.raw === 'string') return value.raw;
      if (typeof value.rendered === 'string') return value.rendered.replace(/<[^>]*>/g, '').trim();
    }
    return '';
  };

  const mergeMediaItem = nextItem => {
    if (!nextItem || !nextItem.id) return;
    setItems(prev => prev.map(x => Number(x.id) === Number(nextItem.id) ? nextItem : x));
    if (Array.isArray(VE_MEDIA_CACHE.items)) {
      VE_MEDIA_CACHE.items = VE_MEDIA_CACHE.items.map(x => Number(x.id) === Number(nextItem.id) ? nextItem : x);
    }
    if (selectedMediaRef.current && Number(selectedMediaRef.current.id) === Number(nextItem.id)) {
      setSelected(nextItem);
    }
  };

  const broadcastMediaItemUpdate = nextItem => {
    if (!nextItem || !nextItem.id) return;
    const payload = { at: Date.now(), item: nextItem };
    try { localStorage.setItem('ve_media_item_update', JSON.stringify(payload)); } catch(e) {}
    try { window.dispatchEvent(new CustomEvent('ve-media-item-updated', { detail: nextItem })); } catch(e) {}
  };

  useEffect(() => {
    const apply = item => {
      if (item && item.id) mergeMediaItem(item);
    };
    const onLocal = e => apply(e.detail);
    const onStorage = e => {
      if (e.key !== 've_media_item_update' || !e.newValue) return;
      try { apply(JSON.parse(e.newValue).item); } catch(err) {}
    };
    window.addEventListener('ve-media-item-updated', onLocal);
    window.addEventListener('storage', onStorage);
    return () => {
      window.removeEventListener('ve-media-item-updated', onLocal);
      window.removeEventListener('storage', onStorage);
    };
  }, []);

  useEffect(() => {
    setFilenameDraft(selected?.title?.raw || selected?.title?.rendered || '');
    setAltDraft(selected?.alt_text || '');
    setCaptionDraft(mediaTextValue(selected, 'caption'));
    setDescriptionDraft(mediaTextValue(selected, 'description'));
    setMediaSaveState('');
  }, [selected?.id, selected?.title?.rendered, selected?.title?.raw]);

  useEffect(() => {
    selectedMediaRef.current = selected;
  }, [selected]);

  useEffect(() => {
    let alive = true;
    const id = selected?.id;
    setMediaUsage(null);
    setMediaUsageError('');
    if (!id) {
      setMediaUsageLoading(false);
      return () => { alive = false; };
    }
    setMediaUsageLoading(true);
    api.g('media-studio/usage/' + encodeURIComponent(id))
      .then(res => {
        if (!alive) return;
        if (!res || res.code || res.success === false) {
          setMediaUsageError(res?.message || 'Usage scan failed.');
          setMediaUsage(null);
        } else {
          setMediaUsage(res);
        }
      })
      .catch(() => {
        if (!alive) return;
        setMediaUsageError('Usage scan failed.');
        setMediaUsage(null);
      })
      .finally(() => {
        if (alive) setMediaUsageLoading(false);
      });
    return () => { alive = false; };
  }, [selected?.id]);

  useEffect(() => {
    if (!qualityPanelOpen && !listMetaPanelOpen && !viewPanelOpen) return;
    const closeOpenPopovers = e => {
      if (qualityPanelOpen && qualityPanelRef.current && !qualityPanelRef.current.contains(e.target)) {
        setQualityPanelOpen(false);
      }
      if (listMetaPanelOpen && listMetaPanelRef.current && !listMetaPanelRef.current.contains(e.target)) {
        setListMetaPanelOpen(false);
      }
      if (viewPanelOpen && viewPanelRef.current && !viewPanelRef.current.contains(e.target)) {
        setViewPanelOpen(false);
        setViewPanelSuppressed(false);
      }
    };
    document.addEventListener('pointerdown', closeOpenPopovers, true);
    return () => document.removeEventListener('pointerdown', closeOpenPopovers, true);
  }, [qualityPanelOpen, listMetaPanelOpen, viewPanelOpen]);

  useEffect(() => {
    const base = CFG.assetUrl || '';
    if (!base) return;
    fetch(base + 'phosphor-icons.json', { credentials: 'same-origin' })
      .then(r => r.ok ? r.json() : null)
      .then(list => {
        if (Array.isArray(list) && list.length) setIconCatalog(list.filter(Boolean));
      })
      .catch(() => {});
  }, []);

  const handleSearch = (e) => {
    const val = e.target.value;
    setSearch(val);
  };

  const dataTransferTypes = e => Array.from(e?.dataTransfer?.types || []);
  const hasFileDrag = e => dataTransferTypes(e).includes('Files');
  const hasInternalDragType = e => dataTransferTypes(e).includes('application/x-ve-internal-drag');
  const markInternalDrag = type => {
    internalDragBlockUntilRef.current = Date.now() + 1400;
    try {
      document.body.classList.add('ve-internal-drag-active');
      if (type === 'collection') document.body.classList.add('ve-internal-collection-drag');
      if (type === 'media') document.body.classList.add('ve-internal-media-drag');
    } catch(e) {}
    setDragActive(false);
    mediaDropDepthRef.current = 0;
  };
  const isInternalDragBlocked = () => {
    if (Date.now() < internalDragBlockUntilRef.current) return true;
    try {
      return !!(document.body?.classList?.contains('ve-internal-drag-active') || document.body?.classList?.contains('ve-internal-media-drag') || document.body?.classList?.contains('ve-internal-collection-drag'));
    } catch(e) {
      return false;
    }
  };
  const clearInternalDragMarker = () => {
    internalDragBlockUntilRef.current = Date.now() + 250;
    try {
      document.body.classList.remove('ve-internal-drag-active');
      document.body.classList.remove('ve-internal-media-drag');
      document.body.classList.remove('ve-internal-collection-drag');
    } catch(e) {}
  };
  const hasMediaDrag = e => {
    const types = dataTransferTypes(e);
    const isCollection = collectionDragActiveRef.current || !!dragCollection || types.includes('application/x-ve-collection-key') || (typeof document !== 'undefined' && document.body?.classList?.contains('ve-internal-collection-drag'));
    if (isCollection) return false;
    return mediaDragActiveRef.current || mediaDragCandidateRef.current || types.includes('application/x-ve-media-ids') || mediaDragIds.length > 0 || (typeof document !== 'undefined' && document.body?.classList?.contains('ve-internal-media-drag'));
  };
  const hasCollectionDrag = e => {
    const types = dataTransferTypes(e);
    return collectionDragActiveRef.current || !!dragCollection || types.includes('application/x-ve-collection-key') || (typeof document !== 'undefined' && document.body?.classList?.contains('ve-internal-collection-drag'));
  };
  const isInternalDragSource = e => !!e?.target?.closest?.('.ve-studio-nav-item,.ve-collection-drag,.ve-tree-toggle,.ve-media-thumb,.ve-media-selected-strip,.ve-media-batch-overlay');
  const isUploadFileDrag = e => !isInternalDragBlocked() && hasFileDrag(e) && !hasInternalDragType(e) && !hasMediaDrag(e) && !hasCollectionDrag(e) && !isInternalDragSource(e);
  const dragIsStillInside = (e, el) => {
    if (!el) return false;
    if (e?.relatedTarget && el.contains(e.relatedTarget)) return true;
    const rect = el.getBoundingClientRect();
    const x = e?.clientX || -1;
    const y = e?.clientY || -1;
    return x >= rect.left && x <= rect.right && y >= rect.top && y <= rect.bottom;
  };
  const showFileDrop = e => {
    if (isInternalDragBlocked() || isInternalDragSource(e) || hasCollectionDrag(e)) {
      mediaDropDepthRef.current = 0;
      setDragActive(false);
      return false;
    }
    if (hasMediaDrag(e)) {
      mediaDropDepthRef.current = 0;
      mediaDragCandidateRef.current = true;
      setDragActive(false);
      return false;
    }
    if (!isUploadFileDrag(e)) {
      if (dragActive) setDragActive(false);
      mediaDropDepthRef.current = 0;
      return false;
    }
    if (fileDragClearTimerRef.current) clearTimeout(fileDragClearTimerRef.current);
    e.preventDefault();
    e.stopPropagation();
    mediaDragCandidateRef.current = false;
    if (!dragActive) setDragActive(true);
    return true;
  };
  const clearFileDrop = (delay = 90) => {
    if (fileDragClearTimerRef.current) clearTimeout(fileDragClearTimerRef.current);
    fileDragClearTimerRef.current = setTimeout(() => {
      mediaDropDepthRef.current = 0;
      mediaDragCandidateRef.current = false;
      setDragActive(false);
    }, delay);
  };
  useEffect(() => {
    const hideWordPressUploaderOverlay = () => {
      try {
        if (!document.body?.classList?.contains('ve-media-studio-open')) return;
        document.querySelectorAll('.uploader-window,[class*="uploader-window"]').forEach(node => {
          if (!node || node.closest?.('.ve-media-studio')) return;
          node.style.setProperty('display', 'none', 'important');
          node.style.setProperty('visibility', 'hidden', 'important');
          node.style.setProperty('opacity', '0', 'important');
          node.style.setProperty('pointer-events', 'none', 'important');
          node.style.setProperty('z-index', '-1', 'important');
        });
      } catch(err) {}
    };
    hideWordPressUploaderOverlay();
    const observer = new MutationObserver(hideWordPressUploaderOverlay);
    try { observer.observe(document.body, { childList: true, subtree: true, attributes: true, attributeFilter: ['class','style'] }); } catch(err) {}
    const onDragActivity = () => hideWordPressUploaderOverlay();
    ['dragenter','dragover','dragleave','drop'].forEach(type => window.addEventListener(type, onDragActivity, true));
    return () => {
      try { observer.disconnect(); } catch(err) {}
      ['dragenter','dragover','dragleave','drop'].forEach(type => window.removeEventListener(type, onDragActivity, true));
    };
  }, []);

  const showExternalFolderTip = (label, e) => {
    const rect = e?.currentTarget?.getBoundingClientRect ? e.currentTarget.getBoundingClientRect() : null;
    if (!rect) return;
    const w = 200;
    const hgt = 104;
    const offset = 8;
    const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
    let left = rect.left - w - offset;
    if (left < 8) left = rect.right + offset;
    left = clamp(left, 8, window.innerWidth - w - 8);
    const top = clamp(rect.top + rect.height / 2 - hgt / 2, 8, window.innerHeight - hgt - 8);
    setExternalFolderTip({ label, left, top });
  };

  const toggleDynamicGroup = key => {
    setDynamicCollapsed(prev => {
      const currentlyCollapsed = prev[key] !== false;
      const next = { ...prev, [key]: !currentlyCollapsed };
      try { localStorage.setItem('ve_media_dynamic_collapsed', JSON.stringify(next)); } catch(e) {}
      return next;
    });
  };

  const beginSidebarResize = e => {
    e.preventDefault();
    e.stopPropagation();
    const startX = e.clientX;
    const startWidth = sidebarWidth;
    const move = ev => {
      const next = Math.max(320, Math.min(480, startWidth + (ev.clientX - startX)));
      setSidebarWidth(next);
      try { localStorage.setItem('ve_media_sidebar_width', String(next)); } catch(err) {}
    };
    const up = () => {
      document.removeEventListener('mousemove', move);
      document.removeEventListener('mouseup', up);
    };
    document.addEventListener('mousemove', move);
    document.addEventListener('mouseup', up);
  };

  const handleUploadFiles = async (files) => {
    const fileList = Array.from(files || []);
    if (!fileList.length) return;
    setUploading(true);
    setMediaBusyMessage('');
    const uploadedIds = [];
    setUploadProgress({ done: 0, total: fileList.length, name: fileList[0]?.name || '', state: 'Uploading', percent: 1 });
    for (let i = 0; i < fileList.length; i++) {
      const file = fileList[i];
      setUploadProgress({ done: i, total: fileList.length, name: file.name || '', state: 'Uploading', percent: Math.max(1, Math.round((i / fileList.length) * 100)) });
      try {
        const item = await uploadWithProgress('wp/v2/media', file, {
          'Content-Disposition': `attachment; filename="${encodeURIComponent(file.name)}"`,
          'Content-Type': file.type || 'application/octet-stream'
        }, percent => {
          const overall = Math.max(1, Math.min(99, Math.round(((i + percent / 100) / fileList.length) * 100)));
          setUploadProgress({ done: i, total: fileList.length, name: file.name || '', state: 'Uploading', percent: overall });
        });
        if (item && item.id) {
          uploadedIds.push(Number(item.id));
          setItems(prev => [item, ...prev]);
          flash('Uploaded ' + file.name);
        } else {
          flash('Upload failed: ' + file.name);
        }
      } catch (err) {
        flash((err && err.message) || ('Upload error: ' + file.name));
      }
      setUploadProgress({ done: i + 1, total: fileList.length, name: file.name || '', state: i + 1 === fileList.length ? 'Upload complete' : 'Uploading', percent: Math.round(((i + 1) / fileList.length) * 100) });
    }
    addUploadedToOpenCollection(uploadedIds);
    setUploading(false);
    setTimeout(() => setUploadProgress(null), 5000);
  };

  const doUrlImport = async (url) => {
    setPendingUrlImport(null);
    setUrlImportBusy(true);
    setUploading(true);
    setUploadProgress({ done: 0, total: 1, name: url.split('/').pop() || 'URL', state: 'Importing', percent: 30 });
    try {
      const res = await api.p('media-studio/import-url', { url, collection: isLocalCollectionOpen() ? selectedColl : '' });
      if (res && res.success && res.item) {
        setItems(prev => [res.item, ...prev]);
        addUploadedToOpenCollection([Number(res.item.id)]);
        refreshUrlImportHistory();
        refreshDiagnostics();
        flash('Imported ' + (res.item.title?.rendered || url.split('/').pop() || 'media'));
      } else {
        refreshUrlImportHistory();
        flash(res?.message || 'Import failed.');
      }
    } catch (err) {
      refreshUrlImportHistory();
      flash((err && err.message) || 'URL import failed.');
    }
    setUrlImportBusy(false);
    setUploading(false);
    setUploadProgress(null);
    if (urlImportRef.current) urlImportRef.current.value = '';
  };

  const handleUrlImport = async (rawUrl) => {
    const url = (rawUrl || '').trim();
    if (!url) return;
    if (!/^https?:\/\//i.test(url)) { flash('Enter a valid HTTP or HTTPS URL.'); return; }
    setUrlImportBusy(true);
    try {
      const res = await api.p('media-studio/import-url/preview', { url });
      if (res && res.success) {
        setPendingUrlImport(res);
      } else {
        flash(res?.message || 'Could not preview that URL.');
      }
    } catch (err) {
      flash((err && err.message) || 'URL preview failed.');
    }
    setUrlImportBusy(false);
  };

  const handleDrop = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (fileDragClearTimerRef.current) clearTimeout(fileDragClearTimerRef.current);
    mediaDropDepthRef.current = 0;
    setDragActive(false);
    if (hasMediaDrag(e) || hasCollectionDrag(e)) return;
    if (e.dataTransfer?.files && e.dataTransfer.files.length) {
      handleUploadFiles(e.dataTransfer.files);
    }
  };

  const handleSelect = (item) => {
    setSelected(prev => prev && prev.id === item.id ? { ...item } : item);
  };

  const handleMediaClick = (item, e, idx) => {
    const hasModifier = !!(e && (e.shiftKey || e.ctrlKey || e.metaKey));
    if (picking && e && !hasModifier) {
      const now = Date.now();
      const prev = pickerClickRef.current || { id: null, at: 0 };
      if ((Number(e.detail || 0) >= 2) || (String(prev.id) === String(item.id) && now - Number(prev.at || 0) < 520)) {
        pickerClickRef.current = { id: null, at: 0 };
        handleMediaDoubleClick(item, e, idx);
        return;
      }
      pickerClickRef.current = { id: item.id, at: now };
    }
    if (e && hasModifier) {
      e.preventDefault();
      if (e.shiftKey && lastMediaIndex !== null) {
        const start = Math.min(lastMediaIndex, idx);
        const end = Math.max(lastMediaIndex, idx);
        const range = filtered.slice(start, end + 1).map(x => x.id);
        setCheckedItems(prev => prev.includes(item.id) ? prev.filter(id => !range.includes(id)) : [...new Set([...prev, ...range])]);
      } else {
        toggleCheckItem(item.id, e, idx);
        setLastMediaIndex(idx);
      }
      setSelected(item);
      return;
    }
    handleSelect(item);
    setLastMediaIndex(idx);
  };

  const handleCopyLink = (url) => {
    navigator.clipboard.writeText(url);
    flash('Copied URL');
  };

  const handleCopyTag = (item) => {
    const tag = `<img src="${item.source_url}" alt="${item.alt_text || ''}" />`;
    navigator.clipboard.writeText(tag);
    flash('Copied HTML Tag');
  };

  const fetchMediaUsageSafe = async (id) => {
    try {
      const res = await api.g('media-studio/usage/' + id);
      return res && res.success ? res : { success: false, total: 0, groups: {} };
    } catch (e) {
      return { success: false, total: 0, groups: {}, message: (e && e.message) || 'Usage check failed.' };
    }
  };

  const usageRowsFromReport = usage => Object.entries(usage?.groups || {}).flatMap(([group, rows]) => (Array.isArray(rows) ? rows : []).map(row => ({ ...row, group })));

  const renderUsageSafetySummary = (usage, fallback) => {
    if (!usage) return h('div', { class: 've-safety-note' }, h('span', { class: 've-media-progress-spinner' }), 'Checking usage…');
    const rows = usageRowsFromReport(usage);
    if (!rows.length) return h('div', { class: 've-safety-ok' }, ph('shield-check'), fallback || 'No safe usage detected. Custom code or CDN references may still exist.');
    return h('div', { class: 've-safety-warning' },
      h('strong', null, rows.length + ' detected use' + (rows.length === 1 ? '' : 's')),
      h('em', null, 'Review these before replacing or deleting this file.'),
      h('div', { class: 've-safety-usage-list' }, rows.slice(0, 5).map((row, idx) => h('div', { class: 've-safety-usage-row', key: idx },
        h('span', null, row.label || row.id || row.group),
        h('small', null, (row.source || row.group) + (row.detail ? ' · ' + row.detail : ''))
      ))),
      rows.length > 5 && h('small', null, '+' + (rows.length - 5) + ' more detected references')
    );
  };

  const handleDelete = async (item) => {
    if (!item) return;
    setPendingDeleteMedia({ item, usage: null, loading: true });
    const usage = await fetchMediaUsageSafe(item.id);
    setPendingDeleteMedia(prev => prev && Number(prev.item?.id) === Number(item.id) ? { ...prev, usage, loading: false } : prev);
  };

  const confirmDeleteMedia = async () => {
    const item = pendingDeleteMedia?.item || pendingDeleteMedia;
    if (!item) return;
    setPendingDeleteMedia(null);
    setMediaBusyMessage('Deleting media…');
    setLoading(true);
    try {
      const res = await api.f('wp/v2/media/' + item.id + '?force=true', { method: 'DELETE' });
      if (res && res.deleted) {
        setItems(prev => prev.filter(x => x.id !== item.id));
        if (selected && selected.id === item.id) setSelected(null);
        setCheckedItems(prev => prev.filter(id => id !== item.id));
        refreshDiagnostics();
        flash('Deleted media');
      } else {
        flash('Delete failed');
      }
    } catch (e) {
      flash('Delete failed');
    }
    setLoading(false);
    setMediaBusyMessage('');
  };

  const handleAltTextSave = async (id, value) => {
    setItems(prev => prev.map(x => x.id === id ? { ...x, alt_text: value } : x));
    if (selected && selected.id === id) {
      setSelected(prev => ({ ...prev, alt_text: value }));
    }
    if (selected && selected.id === id) { setAltDraft(value); setMediaSaveState('Saving alt text…'); }
    try {
      const res = await api.p('media-studio/metadata', { attachment_id: id, alt_text: value });
      if (res && res.item) {
        mergeMediaItem(res.item);
        broadcastMediaItemUpdate(res.item);
        if (selected && selected.id === id) setMediaSaveState('Saved');
        flash('Alt text saved.');
      } else {
        if (selected && selected.id === id) setMediaSaveState('Save failed');
        flash(res?.message || 'Failed to save alt text on WordPress.');
      }
    } catch (e) {
      if (selected && selected.id === id) setMediaSaveState('Save failed');
      flash('Failed to save alt text on WordPress.');
    }
  };

  const titleToAltText = item => {
    const title = (item?.title?.raw || item?.title?.rendered || item?.filename || '').replace(/\.[a-z0-9]+$/i, '');
    return title.replace(/[-_]+/g, ' ').replace(/\s+/g, ' ').trim();
  };

  const saveSelectedMetadata = async () => {
    if (!selected) return;
    setMediaSaveState('Saving metadata…');
    try {
      const res = await api.p('media-studio/metadata', {
        attachment_id: selected.id,
        title: filenameDraft,
        alt_text: altDraft,
        caption: captionDraft,
        description: descriptionDraft
      });
      if (res && res.item) {
        mergeMediaItem(res.item);
        broadcastMediaItemUpdate(res.item);
        setMediaSaveState('Saved');
        flash('Media metadata saved.');
      } else {
        setMediaSaveState('Save failed');
        flash(res?.message || 'Metadata save failed.');
      }
    } catch (e) {
      setMediaSaveState('Save failed');
      flash('Metadata save failed.');
    }
  };

  const bulkFillMissingAltFromFilename = async () => {
    const source = checkedItems.length ? checkedItems.map(id => items.find(x => Number(x.id) === Number(id))).filter(Boolean) : filtered;
    const targets = source.filter(item => isImageFile(item) && !(item.alt_text || '').trim());
    if (!targets.length) { flash('No selected or visible images are missing alt text.'); return; }
    setMediaBusyMessage('');
    setUploadProgress({ done: 0, total: targets.length, name: 'Missing alt text', state: 'Filling alt text', percent: 1 });
    let saved = 0;
    for (let i = 0; i < targets.length; i++) {
      const item = targets[i];
      const alt = titleToAltText(item);
      setUploadProgress({ done: i, total: targets.length, name: item.title?.rendered || item.filename || 'image', state: 'Filling alt text', percent: Math.max(1, Math.round((i / targets.length) * 100)) });
      if (!alt) continue;
      try {
        const res = await api.p('media-studio/metadata', { attachment_id: item.id, alt_text: alt });
        if (res && res.item) {
          saved++;
          mergeMediaItem(res.item);
          broadcastMediaItemUpdate(res.item);
        }
      } catch(e) {}
    }
    setUploadProgress({ done: targets.length, total: targets.length, name: 'Missing alt text', state: 'Alt text filled', percent: 100 });
    setMediaBusyMessage('');
    setTimeout(() => setUploadProgress(null), 5000);
    flash('Filled alt text for ' + saved + ' image' + (saved === 1 ? '' : 's') + '.');
  };

  const toggleCheckItem = (id, event, idx) => {
    const shouldCheck = !checkedItems.includes(id);
    const shiftHeld = !!(
      event?.shiftKey ||
      event?.__veShiftKey ||
      event?.nativeEvent?.shiftKey ||
      event?.currentTarget?.__veShiftKey ||
      event?.currentTarget?.parentNode?.__veShiftKey ||
      (typeof window !== 'undefined' && window.__veLastShiftCheckUntil && window.__veLastShiftCheckUntil > Date.now())
    );
    if (shiftHeld && lastMediaIndex !== null && typeof idx === 'number') {
      const start = Math.min(lastMediaIndex, idx);
      const end = Math.max(lastMediaIndex, idx);
      const range = filtered.slice(start, end + 1).map(x => x.id);
      setCheckedItems(prev => shouldCheck ? [...new Set([...prev, ...range])] : prev.filter(x => !range.includes(x)));
      setLastMediaIndex(idx);
      return;
    }
    setCheckedItems(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
    if (typeof idx === 'number') setLastMediaIndex(idx);
  };

  const toggleCheckRange = (id, idx) => {
    if (lastMediaIndex === null || typeof idx !== 'number') {
      toggleCheckItem(id, { __veShiftKey: false }, idx);
      return;
    }
    const shouldCheck = !checkedItems.includes(id);
    const start = Math.min(lastMediaIndex, idx);
    const end = Math.max(lastMediaIndex, idx);
    const range = filtered.slice(start, end + 1).map(x => x.id);
    setCheckedItems(prev => shouldCheck ? [...new Set([...prev, ...range])] : prev.filter(x => !range.includes(x)));
    setLastMediaIndex(idx);
  };

  const toggleCheckAll = () => {
    const currentList = filtered.map(x => x.id);
    if (checkedItems.length === currentList.length) {
      setCheckedItems([]);
    } else {
      setCheckedItems(currentList);
    }
  };

  const handleBatchAddToCollection = () => {
    setPendingBatchCollection(true);
  };

  const applyBatchCollection = (targetColl) => {
    if (!targetColl) return;
    if (isFolderCollection(targetColl)) {
      checkedItems.forEach(id => toggleCollectionItem(targetColl, id, true));
    } else {
      const entry = collectionMap[targetColl] || { ids: [], icon: 'folder' };
      if (entry.locked) {
        flash('Unlock "' + collLabel(targetColl) + '" before adding media.');
        return;
      }
      const currentIds = entry.ids || [];
      const newIds = [...new Set([...currentIds, ...checkedItems])];
      persistCollections({ ...collectionMap, [targetColl]: { ...entry, ids: newIds } });
    }
    flash(`Added ${checkedItems.length} items to "${collLabel(targetColl)}"!`);
    setCheckedItems([]);
    setPendingBatchCollection(false);
  };

  const addMediaIdsToCollection = (targetColl, ids) => {
    const cleanIds = [...new Set((ids || []).map(id => parseInt(id, 10)).filter(Boolean))];
    if (!targetColl || !cleanIds.length) return;
    if (targetColl === 'all' || targetColl === 'uncollected') {
      flash('Choose a real collection to add media.');
      return;
    }
    if (isFolderCollection(targetColl)) {
      cleanIds.forEach(id => toggleCollectionItem(targetColl, id, true));
    } else {
      const entry = collectionMap[targetColl] || { ids: [], icon: 'folder' };
      if (entry.locked) {
        flash('Unlock "' + collLabel(targetColl) + '" before adding media.');
        return;
      }
      const newIds = [...new Set([...(entry.ids || []), ...cleanIds])];
      persistCollections({ ...collectionMap, [targetColl]: { ...entry, ids: newIds } });
    }
    flash(`Added ${cleanIds.length} item${cleanIds.length === 1 ? '' : 's'} to "${collLabel(targetColl)}".`);
  };

  const downloadMediaUrl = item => {
    if (!item?.source_url) return;
    const a = document.createElement('a');
    a.href = item.source_url;
    a.download = (item.title?.rendered || item.slug || 'media') + '.' + fileExt(item).toLowerCase();
    document.body.appendChild(a);
    a.click();
    a.remove();
  };

  const downloadCollectionZip = async key => {
    const ids = collIds(key);
    if (!ids.length) { flash('This collection has no files to download.'); return; }
    try {
      const res = await api.p('media-studio/collection-zip', { collection: collLabel(key), attachment_ids: ids });
      if (res?.url) {
        window.open(res.url, '_blank');
        flash('Collection ZIP is ready.');
      } else {
        flash(res?.message || 'Could not create collection ZIP.');
      }
    } catch (e) {
      flash('Could not create collection ZIP.');
    }
  };

  const downloadSelectedZip = async () => {
    const ids = [...new Set(checkedItems.map(id => Number(id)).filter(Boolean))];
    if (!ids.length) { flash('Select media to export first.'); return; }
    setUploadProgress({ done: 0, total: 1, name: ids.length + ' selected media', state: 'Building export ZIP', busy: true, percent: 40 });
    try {
      const res = await api.p('media-studio/collection-zip', { collection: 'selected-media', attachment_ids: ids });
      if (res?.url) {
        window.open(res.url, '_blank');
        setUploadProgress({ done: 1, total: 1, name: (res.count || ids.length) + ' files', state: 'Export ZIP ready', percent: 100 });
        flash('Selected media ZIP is ready.');
      } else {
        setUploadProgress({ done: 0, total: 1, name: ids.length + ' selected media', state: 'Export ZIP failed', percent: 0 });
        flash(res?.message || 'Could not create selected media ZIP.');
      }
    } catch (e) {
      setUploadProgress({ done: 0, total: 1, name: ids.length + ' selected media', state: 'Export ZIP failed', percent: 0 });
      flash('Could not create selected media ZIP.');
    }
    setTimeout(() => setUploadProgress(null), 5000);
  };

  const chooseZipForCollection = key => {
    if (!key || isFolderCollection(key)) return;
    if (isLockedCollection(key)) { flash('Unlock this collection before importing ZIP media.'); return; }
    zipImportTargetRef.current = key;
    setCollectionMenu(null);
    setTimeout(() => zipImportRef.current?.click(), 0);
  };

  const importZipToCollection = async file => {
    const key = zipImportTargetRef.current;
    if (!file || !key) return;
    const fd = new FormData();
    fd.append('collection', key);
    fd.append('zip_file', file);
    setZipImportBusy(true);
    setUploadProgress({ done: 0, total: 1, name: file.name || 'collection.zip', state: 'Uploading ZIP', percent: 1 });
    let zipSuccess = false;
    try {
      const res = await uploadWithProgress('variable-engine/v1/media-studio/import-zip', fd, {}, percent => {
        const rawPct = Math.max(1, Math.min(100, Math.round(Number(percent) || 1)));
        const uploadPct = rawPct >= 99 ? 90 : Math.max(2, Math.min(90, Math.round(rawPct * 0.9)));
        setUploadProgress({ done: 0, total: 1, name: file.name || 'collection.zip', state: rawPct >= 99 ? 'Extracting ZIP' : 'Uploading ZIP', percent: uploadPct, busy: rawPct >= 99 });
      });
      if (res && res.success) {
        zipSuccess = true;
        if (Array.isArray(res.items) && res.items.length) {
          setItems(prev => {
            const existing = new Set(prev.map(x => Number(x.id)));
            return [...res.items.filter(x => !existing.has(Number(x.id))), ...prev];
          });
          if (Array.isArray(VE_MEDIA_CACHE.items)) {
            const existing = new Set(VE_MEDIA_CACHE.items.map(x => Number(x.id)));
            VE_MEDIA_CACHE.items = [...res.items.filter(x => !existing.has(Number(x.id))), ...VE_MEDIA_CACHE.items];
          }
        }
        if (res.collections) applyServerCollections(res);
        refreshDiagnostics();
        setSelectedColl(key);
        flash('Imported ' + (res.count || 0) + ' media file' + ((res.count || 0) === 1 ? '' : 's') + ' into "' + collLabel(key) + '".');
      } else {
        flash(res?.message || 'ZIP import failed.');
      }
    } catch (e) {
      flash((e && e.message) || 'ZIP import failed.');
    }
    setUploadProgress({ done: zipSuccess ? 1 : 0, total: 1, name: file.name || 'collection.zip', state: zipSuccess ? 'ZIP import complete' : 'ZIP import failed', percent: zipSuccess ? 100 : 0 });
    setTimeout(() => setUploadProgress(null), 5000);
    setZipImportBusy(false);
    zipImportTargetRef.current = '';
    if (zipImportRef.current) zipImportRef.current.value = '';
  };

  const requestFilenameSave = () => {
    if (!selected) return;
    const next = filenameDraft.trim();
    const current = selected.title?.rendered || '';
    if (!next || next === current) return;
    setPendingRename({ item: selected, title: next });
  };

  const applyFilenameSave = async (renameFile) => {
    const pending = pendingRename;
    if (!pending) return;
    setPendingRename(null);
    setLoading(true);
    const res = await api.p('media-studio/rename', { attachment_id: pending.item.id, title: pending.title, rename_file: !!renameFile });
    setLoading(false);
    if (res && res.item) {
      setItems(prev => prev.map(x => x.id === pending.item.id ? res.item : x));
      setSelected(res.item);
      flash(renameFile ? 'Filename and media title updated.' : 'Media title updated.');
    } else {
      flash(res?.message || 'Rename failed.');
      setFilenameDraft(pending.item.title?.rendered || '');
    }
  };

  const handleBatchDelete = async () => {
    const ids = [...checkedItems];
    if (!ids.length) return;
    setPendingBatchDelete({ ids, loading: true, usages: [], usedCount: 0, sampled: Math.min(ids.length, 12) });
    const sample = ids.slice(0, 12);
    const usages = [];
    let usedCount = 0;
    for (const id of sample) {
      const usage = await fetchMediaUsageSafe(id);
      if ((usage?.total || 0) > 0) usedCount++;
      usages.push({ id, item: items.find(x => Number(x.id) === Number(id)), usage });
    }
    setPendingBatchDelete(prev => prev ? { ...prev, usages, usedCount, loading: false } : prev);
  };

  const confirmBatchDelete = async () => {
    const ids = pendingBatchDelete?.ids ? [...pendingBatchDelete.ids] : [...checkedItems];
    const total = ids.length;
    setPendingBatchDelete(false);
    if (!total) return;
    setUploadProgress({ done: 0, total, name: total + ' selected media', state: 'Deleting selected media', percent: 1 });
    const deleted = [];
    for (let i = 0; i < ids.length; i++) {
      const id = ids[i];
      const item = items.find(x => Number(x.id) === Number(id));
      setUploadProgress({ done: i, total, name: item?.title?.rendered || ('Media #' + id), state: 'Deleting selected media', percent: Math.max(1, Math.round((i / total) * 100)) });
      try {
        const res = await api.f('wp/v2/media/' + id + '?force=true', { method: 'DELETE' });
        if (!res || res.deleted !== false) deleted.push(id);
      } catch (e) {}
    }
    setItems(prev => prev.filter(x => !deleted.includes(x.id)));
    if (selected && deleted.includes(selected.id)) setSelected(null);
    setCheckedItems(prev => prev.filter(id => !deleted.includes(id)));
    refreshDiagnostics();
    setUploadProgress({ done: total, total, name: deleted.length + ' deleted', state: 'Delete complete', percent: 100 });
    setTimeout(() => setUploadProgress(null), 5000);
    flash(deleted.length === 1 ? 'Media deleted.' : `Deleted ${deleted.length} media file${deleted.length === 1 ? '' : 's'}.`);
  };

  const getFileSize = (item) => {
    if (item?.file_size) return Number(item.file_size) || 0;
    if (item?.media_details?.filesize) return item.media_details.filesize;
    if (item?.media_details?.sizes?.full?.file_size) return item.media_details.sizes.full.file_size;
    return (item?.id % 200 + 45) * 1024;
  };

  const fileExt = item => {
    const src = item?.source_url || '';
    const clean = src.split('?')[0].split('#')[0];
    const ext = clean.indexOf('.') !== -1 ? clean.split('.').pop() : '';
    return (ext || (item?.mime_type || '').split('/').pop() || 'file').toUpperCase();
  };
  const authorLabel = item => item?.author_name || item?._embedded?.author?.[0]?.name || item?._embedded?.['wp:author']?.[0]?.name || (item?.author ? 'Author #' + item.author : 'Unknown');
  const collectionLeafLabel = key => (collLabel(key) || '').split('/').map(x => x.trim()).filter(Boolean).pop() || collLabel(key);
  const collectionDepth = key => (collLabel(key) || '').split('/').filter(Boolean).length;
  const setMediaDynamicFilter = (type, value, label) => {
    setDynamicFilter({ type, value, label });
    setSelectedColl('all');
  };

  const mediaSizeBuckets = [
    { label: '0-1 MB', value: '0-1' },
    { label: '1-10 MB', value: '1-10' },
    { label: '10-100 MB', value: '10-100' },
    { label: 'Over 100 MB', value: '100+' }
  ];

  const isFontFile = item => /font|woff|ttf|otf|eot/i.test((item?.mime_type || '') + ' ' + (item?.source_url || ''));
  const isImageFile = item => (item?.mime_type || '').indexOf('image/') === 0;
  const isSvgMedia = item => /image\/svg\+xml|\.svg(\?|#|$)/i.test(String((item?.mime_type || '') + ' ' + (item?.source_url || '') + ' ' + (item?.filename || '')));
  const cleanMediaUrl = value => {
    if (typeof value !== 'string') return '';
    const next = value.trim();
    return next && next !== 'false' && next !== 'undefined' && next !== 'null' ? next : '';
  };
  const mediaUrlWithBust = (url, bust) => {
    const clean = cleanMediaUrl(url);
    if (!clean || !bust) return clean;
    const split = clean.split('#');
    return split[0] + (split[0].includes('?') ? '&' : '?') + 've_preview=' + encodeURIComponent(String(bust)) + (split[1] ? '#' + split[1] : '');
  };
  const mediaPreviewUrl = (item, preferFull) => {
    const sizes = item?.media_details?.sizes || {};
    // SVGs must render from their original attachment URL. Some WordPress/SVG
    // helper plugins expose generated "sizes" thumbnails that are only
    // placeholder stripes, which made masonry cards show lines instead of
    // the actual vector preview inside Bricks.
    if (isSvgMedia(item)) {
      const candidates = [
        item?.source_url,
        item?.url,
        item?.guid?.rendered,
        sizes.full?.source_url,
        sizes.full?.url,
        sizes.large?.source_url,
        sizes.large?.url,
        sizes.medium_large?.source_url,
        sizes.medium_large?.url,
        sizes.medium?.source_url,
        sizes.medium?.url,
        sizes.thumbnail?.source_url,
        sizes.thumbnail?.url
      ];
      return mediaUrlWithBust(candidates.map(cleanMediaUrl).find(Boolean) || '', item?._vePreviewBust);
    }
    const isMasonryPreview = preferFull === 'masonry';
    const candidates = isMasonryPreview
      ? [
          sizes.medium_large?.source_url,
          sizes.medium_large?.url,
          sizes.large?.source_url,
          sizes.large?.url,
          sizes.medium?.source_url,
          sizes.medium?.url,
          sizes.full?.source_url,
          sizes.full?.url,
          item?.source_url,
          item?.url,
          item?.guid?.rendered,
          sizes.thumbnail?.source_url,
          sizes.thumbnail?.url
        ]
      : preferFull
      ? [
          item?.source_url,
          item?.url,
          item?.guid?.rendered,
          sizes.full?.source_url,
          sizes.full?.url,
          sizes.large?.source_url,
          sizes.large?.url,
          sizes.medium_large?.source_url,
          sizes.medium_large?.url,
          sizes.medium?.source_url,
          sizes.medium?.url,
          sizes.thumbnail?.source_url,
          sizes.thumbnail?.url
        ]
      : [
          sizes.thumbnail?.source_url,
          sizes.thumbnail?.url,
          sizes.medium?.source_url,
          sizes.medium?.url,
          item?.source_url,
          item?.url,
          item?.guid?.rendered
        ];
    return mediaUrlWithBust(candidates.map(cleanMediaUrl).find(Boolean) || '', item?._vePreviewBust);
  };

  const renderFilePreview = (item, mode) => {
    const modeName = String(mode || '');
    const modeParts = modeName.split(':');
    const detailMode = modeName.startsWith('detail:') ? modeParts[1] : '';
    const detailZoom = Math.max(1, Math.min(4, parseFloat(modeParts[2] || '1') || 1));
    const isFullPreview = modeName === 'detail' || modeName === 'hover' || modeName === 'bento' || modeName.startsWith('detail:');
    const thumb = mediaPreviewUrl(item, modeName === 'masonry' ? 'masonry' : isFullPreview);
    if (isImageFile(item)) {
      const zoomWidth = Math.round(detailZoom * 100);
      const masonryLike = modeName === 'masonry' || modeName === 'bento';
      const resetDetailScroll = () => {
        if (!modeName.startsWith('detail:')) return;
        requestAnimationFrame(() => {
          const el = detailPreviewRef.current;
          if (!el) return;
          el.scrollLeft = 0;
          el.scrollTop = 0;
        });
      };
      const svgPreview = isSvgMedia(item);
      let imgStyle = masonryLike
        ? 'width:100%;height:auto;max-width:100%;max-height:none;object-fit:contain;display:block'
        : detailMode === 'fit-width'
        ? 'width:100%;height:auto;max-width:100%;max-height:none;object-fit:contain;display:block'
        : detailMode === 'actual'
          ? 'width:auto;height:auto;max-width:none;max-height:none;object-fit:contain;display:block'
          : detailMode === 'zoom'
            ? `width:${zoomWidth}%;height:auto;max-width:none;max-height:none;object-fit:contain;display:block;transform-origin:top left`
          : 'width:100%;height:100%;object-fit:' + (isFullPreview || modeName === 'masonry' || modeName === 'bento' ? 'contain' : 'cover');
      let wrapStyle = masonryLike
        ? 'width:100%;height:auto;display:block;min-height:0'
        : detailMode === 'fit-width'
        ? 'width:100%;height:auto;display:block;min-height:0;overflow:visible'
        : detailMode === 'actual'
          ? 'width:100%;min-width:100%;height:auto;display:block;min-height:0;overflow:visible'
        : detailMode === 'zoom'
        ? 'width:100%;min-width:100%;min-height:0;display:block;overflow:visible'
        : 'width:100%;height:100%;display:flex;align-items:center;justify-content:center';
      if (svgPreview && masonryLike) {
        imgStyle = 'display:block;width:auto;max-width:100%;height:auto;max-height:none;object-fit:contain;background:transparent;min-width:48px;min-height:48px';
        wrapStyle = 'width:auto;max-width:100%;height:auto;display:inline-flex;align-items:flex-start;justify-content:flex-start;min-height:48px;background:transparent;line-height:0';
      }
      const fallback = h('div', { class: 've-preview-fallback' }, ph('image-square'), h('span', null, 'Preview unavailable'), h('em', null, fileExt(item)));
      if (!thumb) return h('div', { class: 've-checker-bg ve-preview-missing', style: wrapStyle }, fallback);
      const markPreviewFailed = event => {
        const wrap = event?.currentTarget?.closest?.('.ve-checker-bg');
        if (wrap) wrap.classList.add('ve-preview-failed');
      };
      return h('div', { class: 've-checker-bg' + (svgPreview ? ' ve-svg-preview-bg' : ''), style: wrapStyle },
        h('img', { class: svgPreview ? 've-svg-preview-img' : '', src: thumb, style: imgStyle, loading: (modeName === 'masonry' || modeName.startsWith('detail')) ? 'eager' : 'lazy', decoding: 'async', onLoad: resetDetailScroll, onError: markPreviewFailed }),
        fallback
      );
    }
    if (isFontFile(item)) return h('div', { class: 've-font-file-card' }, h('span', null, 'Aa'), h('em', null, fileExt(item)));
    return h('div', { class: 've-file-card' }, ph((item.mime_type || '').startsWith('video/') ? 'image-square' : (item.mime_type || '').startsWith('audio/') ? 'file-arrow-down' : 'file-arrow-down'), h('span', null, fileExt(item)));
  };

  const performReplaceFile = async (item, file) => {
    if (!item || !file) return;
    const selectedId = item.id;
    const fd = new FormData();
    fd.append('attachment_id', selectedId);
    fd.append('file', file);
    setMediaBusyMessage('');
    setUploadProgress({ done: 0, total: 1, name: file.name || item.title?.rendered || 'media', state: 'Uploading replacement', percent: 1 });
    try {
      const data = await uploadWithProgress('variable-engine/v1/media-studio/replace', fd, {}, percent => {
        if (percent >= 99) {
          setUploadProgress({ done: 0, total: 1, name: file.name || item.title?.rendered || 'media', state: 'Processing replacement', busy: true });
        } else {
          setUploadProgress({ done: 0, total: 1, name: file.name || item.title?.rendered || 'media', state: 'Uploading replacement', percent });
        }
      });
      if (data && data.item) {
        const bust = Date.now();
        const nextItem = { ...data.item, _vePreviewBust: bust };
        setItems(prev => prev.map(x => Number(x.id) === Number(selectedId) ? nextItem : x));
        if (Array.isArray(VE_MEDIA_CACHE.items)) {
          VE_MEDIA_CACHE.items = VE_MEDIA_CACHE.items.map(x => Number(x.id) === Number(selectedId) ? nextItem : x);
        }
        setSelected(nextItem);
        broadcastMediaItemUpdate(nextItem);
        setUploadProgress({ done: 1, total: 1, name: file.name || data.item.title?.rendered || 'media', state: 'Replace complete', percent: 100 });
        flash('Asset file replaced. Rollback point saved.');
      } else {
        flash(data?.message || 'Replace failed.');
      }
    } catch (e) {
      flash((e && e.message) || 'Replace failed.');
    }
    setMediaBusyMessage('');
    setTimeout(() => setUploadProgress(null), 5000);
  };

  const handleReplaceFile = async (files) => {
    if (!selected || !files || !files[0]) return;
    const item = selected;
    const file = files[0];
    setPendingReplaceRequest({ item, file, usage: null, loading: true });
    const usage = await fetchMediaUsageSafe(item.id);
    setPendingReplaceRequest(prev => prev && Number(prev.item?.id) === Number(item.id) ? { ...prev, usage, loading: false } : prev);
  };

  const confirmReplaceFile = async () => {
    const pending = pendingReplaceRequest;
    setPendingReplaceRequest(null);
    if (replaceInputRef.current) replaceInputRef.current.value = '';
    if (!pending) return;
    await performReplaceFile(pending.item, pending.file);
  };

  const rollbackMediaAction = async (row) => {
    if (!selected || !row?.rollback_id) return;
    setUploadProgress({ done: 0, total: 1, name: selected.title?.rendered || selected.filename || 'media', state: 'Restoring rollback point', busy: true });
    try {
      const res = await api.p('media-studio/rollback', { attachment_id: selected.id, rollback_id: row.rollback_id });
      if (res && res.item) {
        const nextItem = { ...res.item, _vePreviewBust: Date.now() };
        mergeMediaItem(nextItem);
        setSelected(nextItem);
        broadcastMediaItemUpdate(nextItem);
        setUploadProgress({ done: 1, total: 1, name: nextItem.title?.rendered || nextItem.filename || 'media', state: 'Rollback restored', percent: 100 });
        flash('Rollback restored.');
      } else {
        setUploadProgress({ done: 0, total: 1, name: 'Rollback failed', state: 'Rollback failed', percent: 0 });
        flash(res?.message || 'Rollback failed.');
      }
    } catch (e) {
      setUploadProgress({ done: 0, total: 1, name: 'Rollback failed', state: 'Rollback failed', percent: 0 });
      flash((e && e.message) || 'Rollback failed.');
    }
    setTimeout(() => setUploadProgress(null), 5000);
  };

  const convertSelected = async () => {
    if (!selected || !isImageFile(selected)) return;
    const item = selected;
    const format = convertFormat;
    setConvertingId(item.id);
    flash('Converting ' + (item.title?.rendered || 'asset') + ' to ' + format.toUpperCase() + '...');
    let res = null;
    try {
      res = await api.p('media-studio/convert', { attachment_id: item.id, format });
    } catch (e) {
      res = { message: 'Conversion failed.' };
    }
    setConvertingId(prev => prev === item.id ? null : prev);
    if (res && res.item) {
      setItems(prev => prev.map(x => x.id === item.id ? res.item : x));
      if (selectedMediaRef.current && selectedMediaRef.current.id === item.id) setSelected(res.item);
      flash('Converted ' + (item.title?.rendered || 'asset') + ' to ' + format.toUpperCase() + '.');
    } else {
      flash(res?.message || 'Conversion failed.');
    }
  };

  const convertCheckedImages = async () => {
    const targets = selectedImageItems;
    if (!targets.length) { flash('No selected images can be converted.'); return; }
    let converted = 0;
    setUploadProgress({ done: 0, total: targets.length, name: convertFormat.toUpperCase(), state: 'Converting selected images', percent: 1 });
    for (let i = 0; i < targets.length; i++) {
      const item = targets[i];
      setUploadProgress({ done: i, total: targets.length, name: item.title?.rendered || item.filename || 'image', state: 'Converting to ' + convertFormat.toUpperCase(), percent: Math.max(1, Math.round((i / targets.length) * 100)) });
      try {
        const res = await api.p('media-studio/convert', { attachment_id: item.id, format: convertFormat });
        if (res && res.item) {
          converted++;
          mergeMediaItem(res.item);
          broadcastMediaItemUpdate(res.item);
        }
      } catch(e) {}
    }
    setUploadProgress({ done: targets.length, total: targets.length, name: converted + ' converted', state: 'Convert complete', percent: 100 });
    setTimeout(() => setUploadProgress(null), 5000);
    flash(`Converted ${converted} image${converted === 1 ? '' : 's'} to ${convertFormat.toUpperCase()}.`);
  };

  const compressCheckedImages = async () => {
    const targets = selectedImageItems;
    if (!targets.length) { flash('No selected images can be compressed.'); return; }
    let compressed = 0;
    setUploadProgress({ done: 0, total: targets.length, name: targets.length + ' images', state: 'Compressing selected images', percent: 1 });
    for (let i = 0; i < targets.length; i++) {
      const item = targets[i];
      setUploadProgress({ done: i, total: targets.length, name: item.title?.rendered || item.filename || 'image', state: 'Compressing images', percent: Math.max(1, Math.round((i / targets.length) * 100)) });
      try {
        const res = await api.p('media-studio/compress', { attachment_id: item.id });
        if (res && res.item) {
          compressed++;
          mergeMediaItem(res.item);
          broadcastMediaItemUpdate(res.item);
        }
      } catch(e) {}
    }
    setUploadProgress({ done: targets.length, total: targets.length, name: compressed + ' compressed', state: 'Compression complete', percent: 100 });
    setTimeout(() => setUploadProgress(null), 5000);
    flash(`Compressed ${compressed} image${compressed === 1 ? '' : 's'}.`);
  };

  const startPreviewPan = (event) => {
    if (detailPreviewMode !== 'zoom' || !event || event.button !== 0) return;
    const el = event.currentTarget;
    if (!el) return;
    event.preventDefault();
    const startX = event.clientX;
    const startY = event.clientY;
    const startLeft = el.scrollLeft;
    const startTop = el.scrollTop;
    el.classList.add('panning');
    const move = ev => {
      el.scrollLeft = startLeft - (ev.clientX - startX);
      el.scrollTop = startTop - (ev.clientY - startY);
    };
    const stop = () => {
      el.classList.remove('panning');
      window.removeEventListener('mousemove', move);
      window.removeEventListener('mouseup', stop);
      window.removeEventListener('mouseleave', stop);
    };
    window.addEventListener('mousemove', move);
    window.addEventListener('mouseup', stop);
    window.addEventListener('mouseleave', stop);
  };

  useEffect(() => {
    const el = detailPreviewRef.current;
    if (!el) return;
    el.scrollTop = 0;
    el.scrollLeft = 0;
  }, [selected?.id, detailPreviewMode, detailPreviewZoom]);

  const insertSelectedMedia = (itemOverride) => {
    if (insertLockRef.current) return false;
    insertLockRef.current = true;
    setTimeout(() => { insertLockRef.current = false; }, 650);
    const target = itemOverride && itemOverride.source_url ? itemOverride : selected;
    if (!target) { insertLockRef.current = false; return false; }
    if (typeof onInsertMedia === 'function') {
      const inserted = onInsertMedia(target);
      if (inserted) {
        setSelected(null);
        if (picking && typeof onClose === 'function') onClose();
        return true;
      }
      if (picking) {
        flash && flash('Media selected, but Bricks did not accept the insert from this control yet.');
        return false;
      }
    }
    handleCopyLink(target.source_url);
    setSelected(null);
    if (picking && typeof onClose === 'function') onClose();
    return true;
  };

  const handleMediaDoubleClick = (item, e, idx) => {
    if (!picking) return;
    if (e) {
      e.preventDefault();
      e.stopPropagation();
    }
    setSelected(item);
    setLastMediaIndex(idx);
    insertSelectedMedia(item);
  };

  const masonryAspect = item => {
    if (isFontFile(item) || !isImageFile(item)) return '4 / 3';
    const w = Number(item?.media_details?.width || 0);
    const ht = Number(item?.media_details?.height || 0);
    if (w > 0 && ht > 0) {
      const ratio = Math.max(0.62, Math.min(2.05, w / ht));
      const safeW = Math.round(ratio * 100);
      return safeW + ' / 100';
    }
    return '4 / 3';
  };

  const formatSize = (bytes) => {
    if (!bytes) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  };

  const persistFilter = (val) => { setFilterType(val); persistUserPreference('ve_media_filter', val); };
  const persistSort = (val) => { setSortBy(val); persistUserPreference('ve_media_sort', val); };
  const qualityOptions = [
    { value: 'all', label: 'All media', icon: 'filter' },
    { value: 'missing-alt', label: 'Missing Alt Text', icon: 'text-aa' },
    { value: 'unused', label: 'Unused Images', icon: 'eye-slash' },
    { value: 'recent', label: 'Recent Uploads', icon: 'calendar' },
    { value: 'large', label: 'Large Files', icon: 'hard-drive' },
    { value: 'tiny', label: 'Small Images', icon: 'bounding-box' },
    { value: 'landscape', label: 'Landscape', icon: 'image-square' },
    { value: 'portrait', label: 'Portrait', icon: 'device-mobile' },
    { value: 'square', label: 'Square', icon: 'square' }
  ];
  const validQualityValues = qualityOptions.map(x => x.value);
  const activeQualityFilters = qualityFilters.filter(x => validQualityValues.includes(x) && x !== 'all');
  const activeQualityKey = activeQualityFilters.join('|');
  const persistQualityFilters = (vals, closePanel = false) => {
    const clean = [...new Set((Array.isArray(vals) ? vals : [vals]).map(String).filter(x => validQualityValues.includes(x) && x !== 'all'))];
    setQualityFilters(clean);
    setQualityFilter(clean[0] || 'all');
    persistUserPreference('ve_media_quality_filters', JSON.stringify(clean));
    persistUserPreference('ve_media_quality_filter', clean[0] || 'all');
    if (closePanel) setQualityPanelOpen(false);
  };
  const persistQualityFilter = (val) => persistQualityFilters(val === 'all' ? [] : [val], true);
  const toggleQualityFilter = (val) => {
    if (val === 'all') { persistQualityFilters([]); return; }
    const next = activeQualityFilters.includes(val) ? activeQualityFilters.filter(x => x !== val) : [...activeQualityFilters, val];
    persistQualityFilters(next);
  };
  const removeQualityRule = val => persistQualityFilters(activeQualityFilters.filter(x => x !== val));
  const persistSavedQualityPresets = presets => {
    const clean = (Array.isArray(presets) ? presets : []).filter(x => x && x.name && Array.isArray(x.qualityFilters)).slice(0, 12);
    setSavedQualityPresets(clean);
    try { localStorage.setItem('ve_media_saved_filters', JSON.stringify(clean)); } catch(e) {}
  };
  const saveCurrentQualityPreset = () => {
    if (!activeQualityFilters.length && filterType === 'all' && sortBy === 'date' && !dynamicFilter) { flash('Choose at least one filter before saving.'); return; }
    const name = (qualityPresetName || (activeQualityFilters.length ? activeQualityFilters.map(v => (qualityOptions.find(x => x.value === v) || { label: v }).label).join(' + ') : 'Custom filter')).trim();
    if (!name) { flash('Name this filter first.'); return; }
    const preset = { id: 'preset-' + Date.now(), name: name.slice(0, 36), qualityFilters: activeQualityFilters, filterType, sortBy, dynamicFilter: dynamicFilter || null };
    persistSavedQualityPresets([preset, ...savedQualityPresets.filter(x => x.name.toLowerCase() !== name.toLowerCase())]);
    setQualityPresetName('');
    flash('Saved filter: ' + preset.name);
  };
  const applySavedQualityPreset = preset => {
    if (!preset) return;
    if (preset.filterType) persistFilter(preset.filterType);
    if (preset.sortBy) persistSort(preset.sortBy);
    setDynamicFilter(preset.dynamicFilter || null);
    persistQualityFilters(preset.qualityFilters || []);
    flash('Applied filter: ' + preset.name);
  };
  const removeSavedQualityPreset = id => persistSavedQualityPresets(savedQualityPresets.filter(x => x.id !== id));
  const currentQuality = activeQualityFilters.length > 1
    ? { value: 'multi', label: activeQualityFilters.length + ' filters', icon: 'filter' }
    : (qualityOptions.find(x => x.value === (activeQualityFilters[0] || 'all')) || qualityOptions[0]);
  const shownQualityOptions = qualityOptions.filter(opt => {
    const q = qualityQuery.trim().toLowerCase();
    if (!q) return true;
    return opt.label.toLowerCase().includes(q) || opt.value.toLowerCase().includes(q);
  });

  // Filter items based on selected collection
  const filteredByCollection = useMemo(() => {
    if (selectedColl === 'all') return items;
      const ids = collIds(selectedColl);
      return items.filter(x => ids.includes(x.id));
  }, [items, selectedColl, collectionMap, folderData]);

  // Filter by type
  const filteredByType = useMemo(() => {
    if (filterType === 'all') return filteredByCollection;
    if (filterType === 'font') return filteredByCollection.filter(x => isFontFile(x));
    if (filterType === 'svg') return filteredByCollection.filter(x => /svg/i.test((x.mime_type || '') + ' ' + (x.source_url || '')));
    return filteredByCollection.filter(x => (x.mime_type || '').startsWith(filterType + '/'));
  }, [filteredByCollection, filterType]);

  const filteredByDynamic = useMemo(() => {
    if (!dynamicFilter) return filteredByType;
    if (dynamicFilter.type === 'year') return filteredByType.filter(x => String((x.date || '').slice(0, 4)) === String(dynamicFilter.value));
    if (dynamicFilter.type === 'ext') return filteredByType.filter(x => fileExt(x).toLowerCase() === String(dynamicFilter.value).toLowerCase());
    if (dynamicFilter.type === 'author') return filteredByType.filter(x => String(authorLabel(x)) === String(dynamicFilter.value));
    if (dynamicFilter.type === 'size') {
      return filteredByType.filter(item => {
        const bytes = getFileSize(item);
        if (dynamicFilter.value === '0-1') return bytes < 1024 * 1024;
        if (dynamicFilter.value === '1-10') return bytes >= 1024 * 1024 && bytes < 10 * 1024 * 1024;
        if (dynamicFilter.value === '10-100') return bytes >= 10 * 1024 * 1024 && bytes < 100 * 1024 * 1024;
        return bytes >= 100 * 1024 * 1024;
      });
    }
    return filteredByType;
  }, [filteredByType, dynamicFilter]);

  const unusedImageIdsForScan = useMemo(() => filteredByDynamic.filter(isImageFile).map(item => item.id), [filteredByDynamic]);
  const unusedImageScanKey = unusedImageIdsForScan.join(',');

  useEffect(() => {
    if (activeQualityFilters.includes('unused')) return;
    unusedScanRunRef.current += 1;
    if (unusedScanTimeoutRef.current) { clearTimeout(unusedScanTimeoutRef.current); unusedScanTimeoutRef.current = null; }
    setUnusedScan(prev => prev.loading ? { ...prev, loading: false, message: '' } : prev);
    setUploadProgress(prev => prev && String(prev.state || '').indexOf('Scanning unused') === 0 ? null : prev);
  }, [activeQualityKey]);

  useEffect(() => {
    if (!activeQualityFilters.includes('unused')) return;
    if (!unusedImageIdsForScan.length) {
      setUnusedScan({ key: unusedImageScanKey, ids: [], loading: false, scanned: 0, limited: false, message: '' });
      return;
    }
    if (unusedScan.key === unusedImageScanKey && (Array.isArray(unusedScan.ids) || unusedScan.loading)) return;
    let alive = true;
    const runId = ++unusedScanRunRef.current;
    setUnusedScan(prev => ({ ...prev, key: unusedImageScanKey, ids: null, loading: true, scanned: 0, message: 'Scanning media references…' }));
    setUploadProgress({ done: 0, total: unusedImageIdsForScan.length, name: unusedImageIdsForScan.length + ' images', state: 'Scanning unused images', busy: true });
    if (unusedScanTimeoutRef.current) clearTimeout(unusedScanTimeoutRef.current);
    unusedScanTimeoutRef.current = setTimeout(() => {
      if (!alive || runId !== unusedScanRunRef.current) return;
      unusedScanRunRef.current += 1;
      const message = 'Unused scan stopped after 35 seconds. Narrow the collection, search, or type filter and rescan.';
      setUnusedScan({ key: unusedImageScanKey, ids: [], loading: false, scanned: 0, limited: true, message });
      setUploadProgress(null);
      flash(message);
      unusedScanTimeoutRef.current = null;
    }, 35000);
    api.p('media-studio/unused-scan', { attachment_ids: unusedImageIdsForScan }).then(res => {
      if (!alive || runId !== unusedScanRunRef.current) return;
      if (unusedScanTimeoutRef.current) { clearTimeout(unusedScanTimeoutRef.current); unusedScanTimeoutRef.current = null; }
      if (res && res.success) {
        setUnusedScan({ key: unusedImageScanKey, ids: Array.isArray(res.unused_ids) ? res.unused_ids.map(Number) : [], loading: false, scanned: Number(res.scanned || 0), limited: !!res.limited, message: res.message || '' });
        setUploadProgress({ done: Number(res.scanned || 0), total: unusedImageIdsForScan.length, name: (Array.isArray(res.unused_ids) ? res.unused_ids.length : 0) + ' unused found', state: 'Unused scan complete', percent: 100 });
        setTimeout(() => { if (runId === unusedScanRunRef.current) setUploadProgress(null); }, 5000);
      } else {
        setUnusedScan({ key: unusedImageScanKey, ids: [], loading: false, scanned: 0, limited: false, message: res?.message || 'Unused image scan failed.' });
        setUploadProgress(null);
        flash(res?.message || 'Unused image scan failed.');
      }
    }).catch(err => {
      if (!alive || runId !== unusedScanRunRef.current) return;
      if (unusedScanTimeoutRef.current) { clearTimeout(unusedScanTimeoutRef.current); unusedScanTimeoutRef.current = null; }
      const message = err?.message || 'Unused image scan failed.';
      setUnusedScan({ key: unusedImageScanKey, ids: [], loading: false, scanned: 0, limited: false, message });
      setUploadProgress(null);
      flash(message);
    });
    return () => { alive = false; if (unusedScanTimeoutRef.current) { clearTimeout(unusedScanTimeoutRef.current); unusedScanTimeoutRef.current = null; } };
  }, [activeQualityKey, unusedImageScanKey]);

  const filteredByQuality = useMemo(() => {
    if (!activeQualityFilters.length) return filteredByDynamic;
    const ratioOf = item => {
      const w = Number(item?.media_details?.width || 0);
      const hgt = Number(item?.media_details?.height || 0);
      if (!w || !hgt || isFontFile(item)) return 1;
      return Math.max(.38, Math.min(3.2, w / hgt));
    };
    const unusedSet = Array.isArray(unusedScan.ids) ? new Set(unusedScan.ids.map(Number)) : null;
    const match = (item, filter) => {
      if (filter === 'missing-alt') return isImageFile(item) && !(item.alt_text || '').trim();
      if (filter === 'unused') return unusedSet ? (isImageFile(item) && unusedSet.has(Number(item.id))) : (unusedScan.loading ? isImageFile(item) : false);
      if (filter === 'recent') {
        const cutoff = Date.now() - (1000 * 60 * 60 * 24 * 14);
        const t = Date.parse(item.date || item.modified || '');
        return !!(t && t >= cutoff);
      }
      if (filter === 'large') return getFileSize(item) >= 1024 * 1024;
      if (filter === 'tiny') return isImageFile(item) && ((Number(item?.media_details?.width || 0) < 800) || (Number(item?.media_details?.height || 0) < 800));
      if (filter === 'landscape') return isImageFile(item) && ratioOf(item) > 1.15;
      if (filter === 'portrait') return isImageFile(item) && ratioOf(item) < .87;
      if (filter === 'square') return isImageFile(item) && Math.abs(ratioOf(item) - 1) <= .13;
      return true;
    };
    return filteredByDynamic.filter(item => activeQualityFilters.every(filter => match(item, filter)));
  }, [filteredByDynamic, activeQualityKey, unusedScan.ids, unusedScan.loading]);


  const qualityCounts = useMemo(() => {
    const ratioOf = item => {
      const w = Number(item?.media_details?.width || 0);
      const hgt = Number(item?.media_details?.height || 0);
      if (!w || !hgt || isFontFile(item)) return 1;
      return Math.max(.38, Math.min(3.2, w / hgt));
    };
    return {
      all: filteredByDynamic.length,
      'missing-alt': filteredByDynamic.filter(item => isImageFile(item) && !(item.alt_text || '').trim()).length,
      unused: Array.isArray(unusedScan.ids) ? unusedScan.ids.length : 0,
      recent: filteredByDynamic.filter(item => { const t = Date.parse(item.date || item.modified || ''); return t && t >= Date.now() - (1000 * 60 * 60 * 24 * 14); }).length,
      large: filteredByDynamic.filter(item => getFileSize(item) >= 1024 * 1024).length,
      tiny: filteredByDynamic.filter(item => isImageFile(item) && ((Number(item?.media_details?.width || 0) < 800) || (Number(item?.media_details?.height || 0) < 800))).length,
      landscape: filteredByDynamic.filter(item => isImageFile(item) && ratioOf(item) > 1.15).length,
      portrait: filteredByDynamic.filter(item => isImageFile(item) && ratioOf(item) < .87).length,
      square: filteredByDynamic.filter(item => isImageFile(item) && Math.abs(ratioOf(item) - 1) <= .13).length
    };
  }, [filteredByDynamic, unusedScan.ids]);

  // Filter by search
  const filteredBySearch = useMemo(() => {
    const q = search.toLowerCase().trim();
    if (!q) return filteredByQuality;
    return filteredByQuality.filter(x =>
      (x.title?.rendered || '').toLowerCase().includes(q) ||
      (x.slug || '').toLowerCase().includes(q) ||
      (x.mime_type || '').toLowerCase().includes(q) ||
      (x.source_url || '').toLowerCase().includes(q)
    );
  }, [filteredByQuality, search]);

  // Sort
  const filtered = useMemo(() => {
    const list = [...filteredBySearch];
    if (sortBy === 'name') list.sort((a, b) => (a.title?.rendered || '').localeCompare(b.title?.rendered || ''));
    else if (sortBy === 'size') list.sort((a, b) => getFileSize(b) - getFileSize(a));
    else list.sort((a, b) => new Date(b.date || 0) - new Date(a.date || 0));
    return list;
  }, [filteredBySearch, sortBy]);

  const masonryColumns = useMemo(() => {
    const count = Math.max(2, Math.min(7, Number(masonryColumnCount) || 5));
    const cols = Array.from({ length: count }, () => ({ height: 0, items: [] }));
    const estimateHeight = item => {
      if (isFontFile(item) || !isImageFile(item)) return 118;
      const w = Number(item?.media_details?.width || 0);
      const ht = Number(item?.media_details?.height || 0);
      const ratio = w && ht ? Math.max(.62, Math.min(2.05, w / ht)) : 1.33;
      return Math.max(96, Math.min(270, 180 / ratio));
    };
    filtered.forEach((item, idx) => {
      let target = 0;
      for (let i = 1; i < cols.length; i++) {
        if (cols[i].height < cols[target].height) target = i;
      }
      cols[target].items.push({ item, idx });
      cols[target].height += estimateHeight(item) + 12;
    });
    return cols.map(col => col.items);
  }, [filtered, masonryColumnCount]);

  const totalStorageSize = useMemo(() => {
    return items.reduce((acc, x) => acc + getFileSize(x), 0);
  }, [items]);

  const selectedMediaItems = useMemo(() => checkedItems.map(id => items.find(x => Number(x.id) === Number(id))).filter(Boolean), [checkedItems, items]);
  const selectedImageItems = useMemo(() => selectedMediaItems.filter(isImageFile), [selectedMediaItems]);

  // Dynamic collection counts
  const collCounts = useMemo(() => {
    const counts = {};
    for (const key of collKeys) {
      const ids = collIds(key);
      counts[key] = items.filter(x => ids.includes(x.id)).length;
    }
    return counts;
  }, [items, collectionMap, folderData]);

  const overviewStats = useMemo(() => {
    const diag = diagnostics || {};
    const valueOr = (key, fallback) => Number.isFinite(Number(diag[key])) ? Number(diag[key]) : fallback;
    return [
      { key: 'all', label: 'Total media', value: valueOr('total', qualityCounts.all || items.length || 0), helper: diagnosticsLoading ? 'Checking library' : (diag.total_size_human || formatSize(totalStorageSize)), icon: 'hard-drives' },
      { key: 'missing-alt', label: 'Missing alt', value: valueOr('missing_alt', qualityCounts['missing-alt'] || 0), helper: 'Needs text', icon: 'text-aa' },
      { key: 'unused', label: 'Unused', value: unusedScan.loading ? 'Scanning' : (qualityCounts.unused || 0), helper: unusedScan.loading ? 'Running scan' : 'Safe scan result', icon: 'eye-slash' },
      { key: 'large', label: 'Large files', value: valueOr('large_files', qualityCounts.large || 0), helper: '1 MB+', icon: 'hard-drives' },
      { key: 'recent', label: 'Recent uploads', value: valueOr('recent_uploads', qualityCounts.recent || 0), helper: 'Last 14 days', icon: 'calendar' }
    ];
  }, [diagnostics, diagnosticsLoading, qualityCounts, unusedScan.loading, items.length, totalStorageSize]);

  const activateOverviewFilter = key => {
    if (key === 'all') { persistQualityFilters([]); return; }
    persistQualityFilters([key]);
  };

  const persistLayoutMode = (mode) => {
    const normalized = normalizeMediaLayout(mode);
    setLayoutMode(normalized);
    persistUserPreference('ve_media_layout', normalized);
  };
  const openViewPanel = () => {
    if (viewPanelCloseTimerRef.current) clearTimeout(viewPanelCloseTimerRef.current);
    setViewPanelSuppressed(false);
    setViewPanelOpen(true);
  };
  const scheduleViewPanelClose = () => {
    if (viewPanelCloseTimerRef.current) clearTimeout(viewPanelCloseTimerRef.current);
    viewPanelCloseTimerRef.current = setTimeout(() => {
      setViewPanelOpen(false);
      setViewPanelSuppressed(false);
    }, 280);
  };
  const toggleViewPanel = () => {
    if (viewPanelCloseTimerRef.current) clearTimeout(viewPanelCloseTimerRef.current);
    setViewPanelSuppressed(false);
    setViewPanelOpen(prev => !prev);
  };
  const listMetaOptions = [
    { key: 'mime', label: 'MIME Type' },
    { key: 'size', label: 'File Size' },
    { key: 'dimensions', label: 'Dimensions' },
    { key: 'uploaded', label: 'Uploaded On' },
    { key: 'uploaded_by', label: 'Uploaded By' }
  ];
  const setListMetaSelection = (next) => {
    const clean = listMetaOptions.map(x => x.key).filter(key => next.includes(key));
    setListMetaFields(clean);
    persistUserPreference('ve_media_list_meta_fields', JSON.stringify(clean));
    persistUserPreference('ve_media_list_meta', clean.length ? '1' : '0');
  };
  const toggleListMetaField = (key) => {
    setListMetaSelection(listMetaFields.includes(key)
      ? listMetaFields.filter(x => x !== key)
      : [...listMetaFields, key]);
  };

  const openCollectionColorPicker = (key, event) => {
    if (!key || isFolderCollection(key)) return;
    event?.preventDefault?.();
    event?.stopPropagation?.();
    const current = collectionColor(key) || '#baf400';
    const rect = event?.currentTarget?.getBoundingClientRect ? event.currentTarget.getBoundingClientRect() : null;
    const panelRect = mediaLayoutRef.current?.getBoundingClientRect ? mediaLayoutRef.current.getBoundingClientRect() : null;
    const pad = 16;
    const bounds = panelRect || { left: 0, top: 0, right: window.innerWidth || 900, bottom: window.innerHeight || 700, width: window.innerWidth || 900, height: window.innerHeight || 700 };
    const popW = Math.min(320, Math.max(292, Math.min(window.innerWidth || 900, bounds.width) - (pad * 2)));
    // The picker is intentionally compact now, so position the whole popover instead of making it scroll internally.
    const popH = Math.min(462, Math.max(416, bounds.height - (pad * 2)));
    const anchorX = rect ? (rect.left + rect.width / 2) : (Number.isFinite(event?.clientX) ? event.clientX : bounds.left + bounds.width / 2);
    const anchorY = rect ? (rect.top + rect.height / 2) : (Number.isFinite(event?.clientY) ? event.clientY : bounds.top + bounds.height / 2);
    let left = rect ? rect.right + 12 : anchorX + 12;
    if (left + popW > bounds.right - pad) left = (rect ? rect.left : anchorX) - popW - 12;
    if (left < bounds.left + pad) left = Math.min(Math.max(bounds.left + pad, anchorX - popW / 2), bounds.right - popW - pad);
    let top = anchorY - (popH / 2);
    top = Math.max(bounds.top + pad, Math.min(top, bounds.bottom - popH - pad));
    if (bounds.bottom - bounds.top < popH + (pad * 2)) top = bounds.top + pad;
    setCollectionColorPicker({ key, color: current, left: Math.round(left), top: Math.round(top) });
    setCollectionMenu(null);
  };

  const setDraftCollectionColor = color => {
    setCollectionColorPicker(prev => prev ? { ...prev, color: normalizeCollectionColor(color) || '' } : prev);
  };

  const applyCollectionColor = (key, color) => {
    if (!key || isFolderCollection(key) || !collectionMap[key]) return;
    const clean = normalizeCollectionColor(color);
    persistCollections({ ...collectionMap, [key]: { ...(collectionMap[key] || {}), color: clean } });
    setCollectionColorPicker(null);
    flash(clean ? 'Collection color updated.' : 'Collection color cleared.');
  };

  const createMediaDragGhost = ids => {
    const ghost = document.createElement('div');
    ghost.className = 've-media-drag-ghost';
    const stack = document.createElement('div');
    stack.className = 've-media-drag-stack';
    (ids || []).slice(0, 3).forEach(id => {
      const item = items.find(x => String(x.id) === String(id));
      const mini = document.createElement('div');
      mini.className = 've-media-drag-mini';
      if (item?.source_url && !isFontFile(item)) {
        const img = document.createElement('img');
        img.src = item.media_details?.sizes?.thumbnail?.source_url || item.source_url;
        img.alt = '';
        img.style.width = '100%';
        img.style.height = '100%';
        img.style.objectFit = 'cover';
        mini.appendChild(img);
      } else {
        mini.textContent = (fileExt(item || {}) || 'FILE').slice(0, 4).toUpperCase();
        mini.style.display = 'flex';
        mini.style.alignItems = 'center';
        mini.style.justifyContent = 'center';
        mini.style.fontSize = '8px';
        mini.style.color = '#dfffa3';
      }
      stack.appendChild(mini);
    });
    const count = document.createElement('span');
    count.className = 've-media-drag-count';
    count.textContent = String((ids || []).length || 1);
    const label = document.createElement('span');
    label.textContent = ((ids || []).length === 1 ? 'media' : 'media files');
    ghost.appendChild(stack);
    ghost.appendChild(count);
    ghost.appendChild(label);
    document.body.appendChild(ghost);
    return ghost;
  };

  const visibleIcons = iconCatalog.filter(icon => !iconSearch.trim() || icon.indexOf(iconSearch.toLowerCase().trim()) !== -1);
  const renderMediaCard = (item, idx, mode = 'grid', extraStyle = {}) => {
    const isChecked = checkedItems.includes(item.id);
    const isSel = selected && selected.id === item.id;
    const masonryStyle = mode === 'masonry' ? { '--ve-media-aspect': masonryAspect(item) } : {};
    return h('div', {
      key: item.id,
      onClick: e => handleMediaClick(item, e, idx),
      onDoubleClick: e => handleMediaDoubleClick(item, e, idx),
      onDblClick: e => handleMediaDoubleClick(item, e, idx),
      ondblclick: e => handleMediaDoubleClick(item, e, idx),
      onPointerDown: e => {
        if (picking || e.button !== 0) return;
        mediaDragCandidateRef.current = true;
        markInternalDrag('media');
      },
      draggable: !picking,
      onDragStart: e => {
        if (picking) { e.preventDefault(); return false; }
        const ids = checkedItems.includes(item.id) ? checkedItems : [item.id];
        mediaDragActiveRef.current = true;
        mediaDragCandidateRef.current = true;
        mediaDropDepthRef.current = 0;
        setDragActive(false);
        setDropCollection(null);
        setDropMode('');
        setDragCollection(null);
        setMediaDragIds(ids);
        markInternalDrag('media');
        e.dataTransfer.effectAllowed = 'copy';
        e.dataTransfer.setData('application/x-ve-media-ids', JSON.stringify(ids));
        e.dataTransfer.setData('application/x-ve-internal-drag', 'media');
        e.dataTransfer.setData('text/plain', ids.join(','));
        const ghost = createMediaDragGhost(ids);
        e.dataTransfer.setDragImage(ghost, 10, 10);
        setTimeout(() => ghost.remove(), 0);
      },
      onDragEnd: () => { mediaDragActiveRef.current = false; mediaDragCandidateRef.current = false; clearInternalDragMarker(); setMediaDragIds([]); setDropCollection(null); setDropMode(''); setDragActive(false); },
      class: 've-media-thumb' + (isSvgMedia(item) ? ' ve-media-is-svg' : '') + (isSel ? ' selected' : '') + (isChecked ? ' checked' : ''),
      'data-mime': item.mime_type || '',
      style: {
        border: '1px solid ' + (isSel ? '#baf400' : 'rgba(255,255,255,0.05)'),
        ...masonryStyle,
        ...extraStyle
      }
    }, [
      renderFilePreview(item, mode),
      h('div', { class: 've-media-meta-hover' },
        h('div', { style: 'font-weight:800;white-space:nowrap;overflow:hidden;text-overflow:ellipsis' }, item.title?.rendered || 'Untitled'),
        h('div', null, fileExt(item), ' · ', formatSize(getFileSize(item)))
      ),
      h('div', { class: 've-media-select', onClick: e => e.stopPropagation() },
        h(CheckControl, { checked: isChecked, onShiftClick: () => toggleCheckRange(item.id, idx), onChange: (_, e, held) => toggleCheckItem(item.id, Object.assign(e || {}, { __veShiftKey: !!held }), idx), title: isChecked ? 'Deselect asset' : 'Select asset' })
      )
    ]);
  };

  const contextMenuStyle = collectionMenu ? (() => {
    const menuWidth = 188;
    const actionRows = 10;
    const requestedHeight = 18 + (actionRows * 31) + ((actionRows - 1) * 4);
    const bounds = collectionMenu.bounds || { width: 900, height: 620 };
    const pad = 14;
    const menuHeight = Math.max(180, Math.min(requestedHeight, bounds.height - (pad * 2)));
    const rowHeight = collectionMenu.rowHeight || 32;
    const rowTop = typeof collectionMenu.rowTop === 'number' ? collectionMenu.rowTop : Math.max(pad, (collectionMenu.y || 0) - (rowHeight / 2));
    const rowCenter = rowTop + (rowHeight / 2);
    let top = rowTop;
    top = Math.max(pad, Math.min(top, bounds.height - menuHeight - pad));
    let left = collectionMenu.x || 0;
    let placement = 'right';
    if (left + menuWidth > bounds.width - pad) {
      left = (collectionMenu.fallbackX || 0);
      placement = 'left';
    }
    left = Math.max(pad, Math.min(left, bounds.width - menuWidth - pad));
    const arrowY = Math.max(14, Math.min(rowCenter - top - 5, menuHeight - 22));
    const style = {
      position: 'absolute',
      left:left + 'px',
      top:top + 'px',
      transform: 'none',
      '--ve-context-arrow-y': arrowY + 'px',
      '--ve-context-arrow-left': placement === 'right' ? '-5px' : 'calc(100% - 4px)',
      '--ve-context-arrow-rotate': placement === 'right' ? '45deg' : '225deg'
    };
    if (menuHeight < requestedHeight) {
      style.maxHeight = menuHeight + 'px';
      style.overflowY = 'auto';
    }
    return style;
  })() : {};

  const renderDynamicGroup = (key, icon, label, children) => {
    const collapsed = dynamicCollapsed[key] !== false;
    return [
      h('button', {
        type: 'button',
        class: 've-dynamic-folder-group',
        key: key + '-head',
        onClick: () => toggleDynamicGroup(key),
        title: collapsed ? 'Expand ' + label : 'Collapse ' + label
      }, ph(collapsed ? 'caret-right' : 'caret-down'), ph(icon), label),
      !collapsed && children
    ];
  };

  const renderDynamicFoldersPanel = () => h('div', { class: 've-dynamic-folders' },
    h('div', { class: 've-studio-nav-title', style: 'margin:0 0 3px' }, 'Dynamic folders'),
    dynamicFilter && h('button', { type: 'button', class: 've-dynamic-folder-child active', onClick: () => setDynamicFilter(null) }, ph('x'), 'Clear dynamic filter'),
    renderDynamicGroup('authors', 'user', 'All Authors',
      [...new Set(items.map(authorLabel).filter(Boolean))].slice(0, 8).map(author => h('button', { type: 'button', class: 've-dynamic-folder-child' + (dynamicFilter?.type === 'author' && dynamicFilter.value === author ? ' active' : ''), key: 'author-' + author, onClick: () => setMediaDynamicFilter('author', author, author) }, author))
    ),
    renderDynamicGroup('dates', 'calendar', 'All Dates',
      [...new Set(items.map(x => String((x.date || '').slice(0,4))).filter(Boolean))].slice(0,6).map(year => h('button', { type: 'button', class: 've-dynamic-folder-child' + (dynamicFilter?.type === 'year' && String(dynamicFilter.value) === String(year) ? ' active' : ''), key: year, onClick: () => setMediaDynamicFilter('year', year, year) }, year))
    ),
    renderDynamicGroup('extensions', 'file', 'All Extensions',
      [...new Set(items.map(fileExt))].sort().slice(0,8).map(ext => h('button', { type: 'button', class: 've-dynamic-folder-child' + (dynamicFilter?.type === 'ext' && String(dynamicFilter.value).toLowerCase() === ext.toLowerCase() ? ' active' : ''), key: ext, onClick: () => setMediaDynamicFilter('ext', ext.toLowerCase(), '.' + ext.toLowerCase()) }, '.' + ext.toLowerCase()))
    ),
    renderDynamicGroup('sizes', 'hard-drives', 'All Sizes',
      mediaSizeBuckets.map(bucket => h('button', { type: 'button', class: 've-dynamic-folder-child' + (dynamicFilter?.type === 'size' && dynamicFilter.value === bucket.value ? ' active' : ''), key: bucket.value, onClick: () => setMediaDynamicFilter('size', bucket.value, bucket.label) }, bucket.label))
    )
  );

  return h('div', {
    class: 've-studio-layout ve-media-studio' + (pageMode ? ' ve-media-studio-page-mode' : ''),
    ref: mediaLayoutRef,
    onClick: () => collectionMenu && setCollectionMenu(null),
    onDragStartCapture: e => {
      if (e.target?.closest?.('.ve-studio-nav-item,.ve-collection-drag')) {
        collectionDragActiveRef.current = true;
        markInternalDrag('collection');
        setDragActive(false);
      }
      if (e.target?.closest?.('.ve-media-thumb,.ve-media-selected-strip,.ve-media-batch-overlay')) {
        mediaDragActiveRef.current = true;
        mediaDragCandidateRef.current = true;
        markInternalDrag('media');
        setDragActive(false);
      }
    },
    onDragEnter: e => { showFileDrop(e); },
    onDragOver: e => { showFileDrop(e); },
    onDragLeave: e => { if (MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED && isUploadFileDrag(e) && !dragIsStillInside(e, e.currentTarget)) clearFileDrop(); },
    onDrop: e => { if (MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED && isUploadFileDrag(e)) handleDrop(e); }
  },
    // ConfirmModals
    !uploadProgress && loading && h('div', { class: 've-media-progress-toast busy', role: 'status', 'aria-live': 'polite' },
      h('span', { class: 've-media-progress-spinner' }),
      h('div', { class: 've-media-progress-copy' },
        h('strong', null, mediaBusyMessage || 'Loading media'),
        h('em', null, 'Media Studio stays usable while this loads'),
        h('div', { class: 've-upload-bar' }, h('span', null))
      )
    ),
    uploadProgress && h('div', { class: 've-media-progress-toast' + (uploadProgress.busy ? ' busy' : ''), role: 'status', 'aria-live': 'polite' },
      uploadProgress.busy ? h('span', { class: 've-media-progress-spinner' }) : ph(uploadProgress.state && uploadProgress.state.indexOf('Replac') === 0 ? 'arrows-clockwise' : uploadProgress.state && uploadProgress.state.indexOf('Scann') === 0 ? 'magnifying-glass' : 'upload-simple'),
      h('div', { class: 've-media-progress-copy' },
        h('strong', null,
          uploadProgress.state || 'Working',
          uploadProgress.total > 1 && !uploadProgress.busy ? ` ${Math.min(uploadProgress.done || 0, uploadProgress.total)} of ${uploadProgress.total}` : '',
          uploadProgress.total <= 1 && !uploadProgress.busy && Number.isFinite(Number(uploadProgress.percent)) ? ` · ${Math.round(uploadProgress.percent)}%` : ''
        ),
        h('em', null, uploadProgress.name || 'media'),
        h('div', { class: 've-upload-bar' }, h('span', { style: uploadProgress.busy ? '' : `width:${Math.max(8, Math.min(100, Math.round(uploadProgress.percent ?? (((uploadProgress.done || 0) / (uploadProgress.total || 1)) * 100))))}%` }))
      )
    ),
    pendingDeleteMedia && h(ConfirmModal, {
      title: 'Delete Media',
      body: h('div', { class: 've-safety-modal-body' },
        h('p', null, 'Permanently delete "' + ((pendingDeleteMedia.item || pendingDeleteMedia)?.title?.rendered || (pendingDeleteMedia.item || pendingDeleteMedia)?.filename || 'this media file') + '"?'),
        pendingDeleteMedia.loading ? h('div', { class: 've-safety-note' }, h('span', { class: 've-media-progress-spinner' }), 'Checking usage…') : renderUsageSafetySummary(pendingDeleteMedia.usage)
      ),
      confirmText: 'Delete',
      danger: true,
      onCancel: () => setPendingDeleteMedia(null),
      onConfirm: confirmDeleteMedia
    }),
    pendingBatchDelete && h(ConfirmModal, {
      title: (pendingBatchDelete.ids || checkedItems).length === 1 ? 'Delete Media' : 'Batch Delete',
      body: h('div', { class: 've-safety-modal-body' },
        h('p', null, 'Permanently delete ' + (pendingBatchDelete.ids || checkedItems).length + ' media file' + ((pendingBatchDelete.ids || checkedItems).length === 1 ? '' : 's') + '?'),
        pendingBatchDelete.loading
          ? h('div', { class: 've-safety-note' }, h('span', { class: 've-media-progress-spinner' }), 'Checking selected media usage…')
          : h('div', { class: pendingBatchDelete.usedCount ? 've-safety-warning' : 've-safety-ok' },
              pendingBatchDelete.usedCount ? ph('warning') : ph('shield-check'),
              h('strong', null, pendingBatchDelete.usedCount ? (pendingBatchDelete.usedCount + ' selected file' + (pendingBatchDelete.usedCount === 1 ? '' : 's') + ' have detected usage') : 'No usage detected in sampled files'),
              h('em', null, 'Checked ' + (pendingBatchDelete.sampled || 0) + ' of ' + (pendingBatchDelete.ids || checkedItems).length + ' selected files before deleting.'),
              Array.isArray(pendingBatchDelete.usages) && pendingBatchDelete.usages.filter(x => (x.usage?.total || 0) > 0).slice(0, 4).map(x => h('small', { key: x.id }, (x.item?.title?.rendered || 'Media #' + x.id) + ' · ' + x.usage.total + ' use' + (x.usage.total === 1 ? '' : 's')))
            )
      ),
      confirmText: (pendingBatchDelete.ids || checkedItems).length === 1 ? 'Delete Media' : 'Delete Selected',
      danger: true,
      onCancel: () => setPendingBatchDelete(false),
      onConfirm: confirmBatchDelete
    }),
    pendingReplaceRequest && h(ConfirmModal, {
      title: 'Replace Media File',
      body: h('div', { class: 've-safety-modal-body' },
        h('p', null, 'Replace "' + (pendingReplaceRequest.item?.title?.rendered || pendingReplaceRequest.item?.filename || 'this media file') + '" with "' + (pendingReplaceRequest.file?.name || 'new file') + '"?'),
        pendingReplaceRequest.loading ? h('div', { class: 've-safety-note' }, h('span', { class: 've-media-progress-spinner' }), 'Checking usage…') : renderUsageSafetySummary(pendingReplaceRequest.usage, 'No detected usage. MV will still save a rollback point before replacing the file.')
      ),
      confirmText: 'Replace File',
      danger: !!(pendingReplaceRequest.usage?.total),
      onCancel: () => { setPendingReplaceRequest(null); if (replaceInputRef.current) replaceInputRef.current.value = ''; },
      onConfirm: confirmReplaceFile
    }),
    pendingDeleteCollection && h(ConfirmModal, {
      title: 'Remove Collection',
      body: `Remove "${pendingDeleteCollection.label}" from Media Studio? Media files will not be deleted, but ${pendingDeleteCollection.count || 0} collection assignment(s) will be removed.`,
      confirmText: 'Remove Collection',
      danger: true,
      onCancel: () => setPendingDeleteCollection(null),
      onConfirm: confirmDeleteCollection
    }),
    pendingUrlImport && h('div', { class: 've-modal', onMouseDown: () => setPendingUrlImport(null) },
      h('div', { class: 've-modal-box', onMouseDown: e => e.stopPropagation() },
        h('div', { class: 've-modal-title' }, 'Preview URL import'),
        h('div', { class: 've-modal-body' }, 'Review the remote file before Media Studio downloads it into WordPress.'),
        h('div', { class: 've-url-preview-grid' },
          h('div', { class: 've-url-preview-row' }, h('strong', null, 'File'), h('span', { title: pendingUrlImport.filename || pendingUrlImport.url }, pendingUrlImport.filename || pendingUrlImport.url)),
          h('div', { class: 've-url-preview-row' }, h('strong', null, 'Type'), h('span', null, pendingUrlImport.content_type || 'Unknown')),
          h('div', { class: 've-url-preview-row' }, h('strong', null, 'Size'), h('span', null, pendingUrlImport.size_human || 'Unknown')),
          h('div', { class: 've-url-preview-row' }, h('strong', null, 'Source'), h('span', { title: pendingUrlImport.url }, pendingUrlImport.host || pendingUrlImport.url))
        ),
        pendingUrlImport.over_limit && h('div', { class: 've-url-preview-error' }, 'This file is larger than the current 50 MB server import limit. Download it manually or raise the limit later.'),
        !pendingUrlImport.over_limit && !pendingUrlImport.size && h('div', { class: 've-url-preview-warning' }, 'The server could not confirm the file size before download. Import may still fail if the source blocks downloads or the file is above the limit.'),
        pendingUrlImport.looks_like_page && h('div', { class: 've-url-preview-warning' }, 'This looks like a webpage, not a direct media file. A direct .jpg, .png, .mp4, .pdf, or similar file URL works best.'),
        urlImportHistory.length > 0 && h('div', { class: 've-url-history-mini' },
          h('div', { class: 've-url-history-head' },
            h('strong', null, 'Recent URL imports'),
            h('button', { class: 've-url-history-clear', type: 'button', onClick: async () => { try { await api.f('variable-engine/v1/media-studio/url-history', { method: 'DELETE' }); setUrlImportHistory([]); } catch(e) {} } }, 'Clear')
          ),
          urlImportHistory.slice(0, 4).map(row => h('div', { class: 've-url-history-row', key: row.id || row.at || row.url },
            h('span', null, row.title || row.url || 'URL import'),
            h('em', null, (row.status || 'complete') + (row.mime_type ? ' · ' + row.mime_type : '') + (row.size ? ' · ' + formatSize(row.size) : ''))
          ))
        ),
        h('div', { class: 've-modal-actions', style: 'margin-top:12px' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => setPendingUrlImport(null) }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-s', type: 'button', disabled: !!pendingUrlImport.over_limit, onClick: () => doUrlImport(pendingUrlImport.url) }, 'Import media')
        )
      )
    ),
    collectionMenu && h('div', {
      class: 've-context-menu ve-context-menu-attached',
      style: contextMenuStyle,
      onClick: e => e.stopPropagation()
    },
      (() => {
        const menuKey = collectionMenu.key;
        const menuEntry = collectionMap[menuKey] || {};
        const lockedMenu = !!menuEntry.locked;
        const shortcode = '[mv_media_collection collection="' + menuKey + '"]';
        const updateCollectionMeta = patch => {
          persistCollections({ ...collectionMap, [menuKey]: { ...menuEntry, ...patch } });
          setCollectionMenu(null);
        };
        return [
          h('button', { type: 'button', onClick: () => beginRenameCollection(menuKey), disabled: lockedMenu }, ph('pencil-simple'), 'Rename'),
          h('button', { type: 'button', onClick: () => beginChildCollection(menuKey), disabled: lockedMenu }, ph('tree-structure'), 'New subfolder'),
          !isFolderCollection(menuKey) && h('button', { type: 'button', onClick: () => { updateCollectionMeta({ starred: !menuEntry.starred }); flash(menuEntry.starred ? 'Removed from Starred.' : 'Pinned to Starred.'); } }, ph('star'), menuEntry.starred ? 'Unstar collection' : 'Star collection'),
          !isFolderCollection(menuKey) && h('button', { type: 'button', onClick: event => openCollectionColorPicker(menuKey, event) }, ph('palette'), collectionColor(menuKey) ? 'Change color' : 'Set color'),
          h('button', { type: 'button', onClick: () => { setSelectedColl(menuKey); setCollectionMenu(null); } }, ph('folder-open'), 'View collection'),
          h('button', { type: 'button', onClick: () => { downloadCollectionZip(menuKey); setCollectionMenu(null); } }, ph('download-simple'), 'Download all'),
          !isFolderCollection(menuKey) && h('button', { type: 'button', onClick: () => chooseZipForCollection(menuKey), disabled: lockedMenu }, ph('file-arrow-down'), 'Import ZIP to collection'),
          !isFolderCollection(menuKey) && h('button', { type: 'button', onClick: () => { navigator.clipboard?.writeText(shortcode); flash('Copied collection shortcode.'); setCollectionMenu(null); } }, ph('brackets-curly'), 'Copy gallery shortcode'),
          !isFolderCollection(menuKey) && h('button', { type: 'button', onClick: () => {
            updateCollectionMeta({ locked: !lockedMenu });
            flash(lockedMenu ? 'Collection unlocked.' : 'Collection locked.');
          } }, ph(lockedMenu ? 'lock-open' : 'lock-simple'), lockedMenu ? 'Unlock folder' : 'Lock folder'),
          !isFolderCollection(menuKey) && h('button', { type: 'button', class: 'danger', disabled: lockedMenu, onClick: () => { requestDeleteCollection(menuKey); setCollectionMenu(null); } }, ph('trash'), 'Delete')
        ];
      })()
    ),
    collectionColorPicker && h('div', { class: 've-floating-scrim ve-collection-color-scrim', onMouseDown: () => setCollectionColorPicker(null) },
      h('div', {
        class: 've-collection-color-popover',
        style: { left: (collectionColorPicker.left || 16) + 'px', top: (collectionColorPicker.top || 16) + 'px' },
        onMouseDown: e => e.stopPropagation()
      },
        h('div', { class: 've-modal-title' }, 'Choose collection color'),
        h('div', { class: 've-modal-body' }, 'This only changes the collection accent in Media Studio. Starred collections are pinned above normal collections.'),
        h('div', { class: 've-collection-color-name' }, ph(collIcon(collectionColorPicker.key)), h('span', null, collLabel(collectionColorPicker.key))),
        h('div', { class: 've-collection-color-grid' },
          COLLECTION_COLOR_PRESETS.map(color => {
            const active = (collectionColorPicker.color || '') === color;
            return h('button', {
              key: color,
              type: 'button',
              class: 've-collection-color-swatch' + (active ? ' active' : ''),
              style: { '--ve-swatch-color': color },
              onClick: () => setDraftCollectionColor(color),
              title: color
            }, h('span', null));
          })
        ),
        h(MVInlineColorPicker, {
          hex: collectionColorPicker.color || '#baf400',
          onChange: setDraftCollectionColor,
          fmt: collectionColorFmt,
          setFmt: setCollectionColorFmt
        }),
        h('div', { class: 've-modal-actions', style: 'margin-top:12px' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => setCollectionColorPicker(null) }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => setDraftCollectionColor('') }, 'Clear'),
          h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: () => applyCollectionColor(collectionColorPicker.key, collectionColorPicker.color || '') }, 'Apply color')
        )
      )
    ),
    externalFolderTip && h('span', {
      class: 've-tooltip-card',
      style: { left: externalFolderTip.left + 'px', top: externalFolderTip.top + 'px' }
    },
      h('strong', null, 'External folder'),
      h('em', null, externalFolderTip.label),
      'Detected from a folder plugin. MV can read counts and assign files, but hierarchy ownership stays external until migrated.'
    ),
    renameCollectionKey && h('div', { class: 've-modal', onMouseDown: () => { setRenameCollectionKey(null); setRenameCollectionName(''); } },
      h('div', { class: 've-modal-box', onMouseDown: e => e.stopPropagation() },
        h('div', { class: 've-modal-title' }, 'Rename collection'),
        h('div', { class: 've-modal-body' }, 'Use slashes to make sub-collections, e.g. Brand / Portraits.'),
        h('input', { class: 've-studio-input', value: renameCollectionName, onInput: e => setRenameCollectionName(e.target.value), onKeyDown: e => { if (e.key === 'Enter') renameLocalCollection(renameCollectionKey, renameCollectionName); if (e.key === 'Escape') setRenameCollectionKey(null); }, autoFocus: true }),
        h('div', { class: 've-modal-actions', style: 'margin-top:12px' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { setRenameCollectionKey(null); setRenameCollectionName(''); } }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: () => renameLocalCollection(renameCollectionKey, renameCollectionName) }, 'Save')
        )
      )
    ),
    showMigrationModal && h('div', { class: 've-modal', onMouseDown: () => setShowMigrationModal(false) },
      h('div', { class: 've-modal-box ve-migration-modal', onMouseDown: e => e.stopPropagation(), style: 'width: 460px; max-width: 90vw; background: #161616; border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); display: flex; flex-direction: column; overflow: hidden;' },
        h('div', { class: 've-modal-title', style: 'padding: 16px; border-bottom: 1px solid rgba(255,255,255,0.06); margin: 0; font-size: 14px; font-weight: 700; color: #fff; display: flex; align-items: center; gap: 8px' },
          ph('arrows-merge', { style: 'color: #baf400; font-size: 18px' }),
          'Migrate Folder-Plugin Folders'
        ),
        h('div', { class: 've-modal-body ve-scroll-custom', style: 'padding: 16px; flex: 1; overflow-y: auto; display: flex; flex-direction: column; gap: 14px; max-height: 380px;' },
          h('div', { style: 'font-size: 12px; color: #aaa; line-height: 1.5' },
            'Migrate detected folder structures and media assignments into Mimam\'s Var local collections. This will copy assignments without deleting the original folders.'
          ),
          h('div', { style: 'display: flex; flex-direction: column; gap: 6px' },
            h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:10px' },
              h('div', { style: 'font-size: 11px; font-weight: 600; color: #888; text-transform: uppercase; letter-spacing: 0.5px' }, 'Select folders to migrate:'),
              (folderData.folders || []).length > 0 && h('div', { style: 'display:flex;align-items:center;gap:6px;flex-shrink:0' },
                h('button', {
                  type: 'button',
                  class: 've-btn ve-btn-g ve-btn-s',
                  style: 'min-height:24px;height:24px;padding:0 8px;font-size:10px',
                  onClick: () => setSelectedMigrateFolders((folderData.folders || []).map(f => String(f.id)))
                }, 'Select all'),
                h('button', {
                  type: 'button',
                  class: 've-btn ve-btn-g ve-btn-s',
                  style: 'min-height:24px;height:24px;padding:0 8px;font-size:10px;color:#aaa',
                  onClick: () => setSelectedMigrateFolders([])
                }, 'Clear')
              )
            ),
            h('div', { class: 've-scroll-custom', style: 'max-height: 180px; overflow-y: auto; background: rgba(0,0,0,0.2); border: 1px solid rgba(255,255,255,0.04); border-radius: 6px; padding: 6px; display: flex; flex-direction: column; gap: 4px;' },
              (folderData.folders || []).length === 0 ? h('div', { style: 'padding: 12px; font-size: 11px; color: #666; text-align: center' }, 'No folders found.') :
              (folderData.folders || []).map(f => {
                const folderId = String(f.id);
                const pathLabel = buildFolderPath(f);
                const isSelected = selectedMigrateFolders.includes(folderId);
                const count = collCounts['folder:' + folderId] || 0;
                return h('label', {
                  key: folderId,
                  style: 'display: flex; align-items: center; gap: 8px; padding: 6px; border-radius: 4px; cursor: pointer; user-select: none; transition: background 0.2s;',
                  class: 've-migration-row'
                },
                  h('input', {
                    type: 'checkbox',
                    class: 've-var-check',
                    checked: isSelected,
                    onChange: (e) => {
                      setSelectedMigrateFolders(prev => {
                        if (e.target.checked) return [...prev, folderId];
                        return prev.filter(x => x !== folderId);
                      });
                    }
                  }),
                  h('span', { style: 'font-size: 11px; color: #ddd; flex: 1; display: flex; align-items: center; gap: 6px' },
                    ph('folder', { style: 'color: #baf400; opacity: 0.7' }),
                    pathLabel
                  ),
                  h('span', { class: 've-studio-badge', style: 'opacity: 0.68' }, `${count} item${count === 1 ? '' : 's'}`)
                );
              })
            )
          ),
          h('div', { style: 'margin-top: 4px; border-top: 1px solid rgba(255,255,255,0.04); padding-top: 12px; display: flex; flex-direction: column; gap: 8px' },
            h('label', { style: 'display: flex; align-items: center; gap: 8px; cursor: pointer' },
              h('input', {
                type: 'checkbox',
                class: 've-var-check',
                checked: migrateHideFolders,
                onChange: (e) => setMigrateHideFolders(e.target.checked)
              }),
              h('span', { style: 'font-size: 11px; color: #ccc' }, 'Hide external folders sidebar after migration')
            )
          )
        ),
        h('div', { class: 've-modal-actions', style: 'padding: 12px 16px; border-top: 1px solid rgba(255,255,255,0.06); display: flex; justify-content: flex-end; gap: 8px; margin: 0; background: rgba(0,0,0,0.1)' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => setShowMigrationModal(false) }, 'Cancel'),
          h('button', {
            class: 've-btn ve-btn-s',
            type: 'button',
            style: 'background: #baf400; color: #111; font-weight: 600',
            disabled: !selectedMigrateFolders.length,
            onClick: runFoldersMigration
          }, 'Confirm Migration')
        )
      )
    ),
    collectionCreateModal && h('div', { class: 've-modal', onMouseDown: () => setCollectionCreateModal(null) },
      h('div', { class: 've-modal-box ve-collection-modal', onMouseDown: e => e.stopPropagation() },
        h('div', { class: 've-modal-title' }, 'New sub-collection'),
        h('div', { class: 've-modal-body' }, 'Create this under "' + collLabel(collectionCreateModal.parentKey) + '". Use a clear name so sub-folders stay readable.'),
        h('input', { ref: newCollInputRef, class: 've-studio-input', value: newCollName, onInput: e => setNewCollName(e.target.value), onKeyDown: e => { if (e.key === 'Enter') createCollection(); if (e.key === 'Escape') setCollectionCreateModal(null); }, autoFocus: true }),
        h('div', { class: 've-modal-actions', style: 'margin-top:12px' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { setCollectionCreateModal(null); setNewCollName(''); } }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: createCollection, disabled: !newCollName.trim() }, 'Create')
        )
      )
    ),
    pendingRename && h('div', { class: 've-modal', onMouseDown: () => { setPendingRename(null); setFilenameDraft(pendingRename.item.title?.rendered || ''); } },
      h('div', { class: 've-modal-box', onMouseDown: e => e.stopPropagation() },
        h('div', { class: 've-modal-title' }, 'Update media filename?'),
        h('div', { class: 've-modal-body' }, 'Save the new name as the attachment title only, or also rename the physical file URL where WordPress allows it.'),
        h('div', { class: 've-modal-actions' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { setPendingRename(null); setFilenameDraft(pendingRename.item.title?.rendered || ''); } }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => applyFilenameSave(false) }, 'Title only'),
          h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: () => applyFilenameSave(true) }, 'Rename file URL')
        )
      )
    ),
    pendingBatchCollection && h('div', { class: 've-modal', onMouseDown: () => setPendingBatchCollection(false) },
      h('div', { class: 've-modal-box ve-collection-modal', onMouseDown: e => e.stopPropagation() },
        h('div', { class: 've-modal-title' }, 'Add to Collection'),
        h('div', { class: 've-modal-body' }, 'Choose where to place the selected media, or create a new collection first.'),
        h('div', { class: 've-collection-choice-list ve-scroll-custom' },
          collKeys.length ? collKeys.map(key => { const lockedChoice = isLockedCollection(key); return h('button', { type: 'button', key, class: 've-collection-choice' + (lockedChoice ? ' disabled' : ''), disabled: lockedChoice, onClick: () => applyBatchCollection(key), title: lockedChoice ? 'Unlock this collection before adding media.' : '' }, ph(lockedChoice ? 'lock-simple' : collIcon(key)), h('span', null, collLabel(key)), h('em', null, lockedChoice ? 'Locked' : (collCounts[key] || 0) + ' items')); }) : h('div', { class: 've-empty', style: 'padding:12px' }, 'No collections yet.')
        ),
        h('div', { class: 've-batch-new-collection' },
          h('div', { class: 've-studio-nav-title', style: 'margin:0 0 6px' }, 'Create new collection'),
          h('div', { class: 've-batch-new-collection-grid' },
            h('input', { class: 've-studio-input', placeholder: 'Collection name...', value: batchNewCollName, onInput: e => setBatchNewCollName(e.target.value), autoFocus: true }),
            h(SelectMenu, { className: 've-filter-menu ve-icon-select', value: batchNewCollIcon, onChange: setBatchNewCollIcon, options: visibleIcons.slice(0, 80).map(icon => ({ value: icon, label: icon })) }),
            h('div', { class: 've-batch-new-collection-actions' },
              h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { setBatchNewCollName(''); setBatchNewCollIcon('folder'); setPendingBatchCollection(false); } }, 'Cancel'),
              h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: createCollectionForSelection, disabled: !batchNewCollName.trim() }, 'Create')
            )
          )
        )
      )
    ),
    MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED && dragActive && !isInternalDragBlocked() && !hasMediaDrag(null) && !hasCollectionDrag(null) && h('div', { class: 've-drop-overlay', onDragOver: e => { if (isUploadFileDrag(e)) { e.preventDefault(); e.stopPropagation(); } }, onDragLeave: e => { e.preventDefault(); e.stopPropagation(); if (!dragIsStillInside(e, mediaLayoutRef.current)) clearFileDrop(); }, onDrop: handleDrop }, h('div', null, ph('upload-simple'), h('strong', null, 'Drop files to upload'))),
    // 1. Sidebar Left
    h('div', { class: 've-studio-sidebar', style: { position: 'relative', width: sidebarWidth + 'px', flexBasis: sidebarWidth + 'px' } },
      h('div', { class: 've-sidebar-resizer', onMouseDown: beginSidebarResize, title: 'Drag to resize sidebar' }),
      showNewCollForm && h('div', { class: 've-collection-inline-pop' },
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:8px' },
          h('div', { class: 've-studio-nav-title', style: 'margin:0' }, 'Create collection'),
          h('button', { class: 've-a', type: 'button', style: 'width:24px;height:24px;display:flex;align-items:center;justify-content:center', onClick: () => { setShowNewCollForm(false); setNewCollName(''); } }, ph('x'))
        ),
        h('input', { ref: newCollInputRef, class: 've-studio-input', placeholder: 'Collection name...', value: newCollName, onInput: e => setNewCollName(e.target.value), onKeyDown: e => { if (e.key === 'Enter') createCollection(); if (e.key === 'Escape') setShowNewCollForm(false); } }),
        h('div', { style: 'font-size:10px;color:#777;line-height:1.45' }, 'Use slashes for sub collections, e.g. Brand / Portraits. One media item can belong to many collections.'),
        h('input', { class: 've-studio-input', placeholder: 'Search Phosphor icons...', value: iconSearch, onInput: e => setIconSearch(e.target.value), style: 'font-size:11px' }),
        h('div', { class: 've-icon-grid ve-scroll-custom' },
          visibleIcons.map(icon => h('button', { type: 'button', key: icon, class: 've-icon-pick' + (newCollIcon === icon ? ' active' : ''), onClick: () => setNewCollIcon(icon), title: icon }, ph(icon), h('span', null, icon)))
        ),
        h('div', { style: 'display:flex;gap:7px' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', style: 'flex:1', onClick: () => { setShowNewCollForm(false); setNewCollName(''); } }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-s', style: 'flex:1;background:#baf400;color:#111;font-weight:600', onClick: createCollection, disabled: !newCollName.trim() }, 'Create')
        )
      ),
      h('div', { class: 've-studio-sidebar-scroll ve-scroll-custom' + (showNewCollForm ? ' ve-sidebar-blurred' : '') },
        h('div', { class: 've-studio-nav' },
          h('div', { class: 've-media-collections-head' },
            h('div', { class: 've-studio-nav-title', style: 'display:flex;align-items:center;justify-content:space-between;width:100%' }, 
              h('span', null, 'Collections'),
              folderData.folders && folderData.folders.length > 0 && h('button', {
                type: 'button',
                class: 've-a',
                style: 'color:#baf400;font-size:12px;display:flex;align-items:center;gap:4px',
                title: 'Migrate Folder-Plugin Folders',
                onClick: (e) => {
                  e.stopPropagation();
                  setSelectedMigrateFolders((folderData.folders || []).map(f => String(f.id)));
                  setShowMigrationModal(true);
                }
              }, ph('arrows-merge'))
            ),
            h('div', { class: 've-collection-tools' },
              h('input', { class: 've-studio-input', placeholder: 'Search collections...', value: collectionSearch, onInput: e => setCollectionSearch(e.target.value) }),
              h('button', { class: 've-btn ve-btn-g ve-btn-s ve-collection-tool-btn ve-collection-shortcuts', type: 'button', title: 'Shortcuts', onClick: () => setShowCommandPanel(true) }, ph('command')),
              h('button', {
                key: collectionBranchesAllExpanded ? 'collapse-folders' : 'expand-folders',
                class: 've-btn ve-btn-g ve-btn-s ve-collection-tool-btn',
                title: collectionBranchesAllExpanded ? 'Collapse all folders' : 'Expand all folders',
                'aria-label': collectionBranchesAllExpanded ? 'Collapse all folders' : 'Expand all folders',
                onClick: toggleAllCollectionBranches
              }, ph(collectionBranchesAllExpanded ? 'arrows-in-line-vertical' : 'arrows-out-line-vertical')),
              h(SelectMenu, { className: 've-filter-menu', value: collectionSort, onChange: persistCollectionSort, options: [
                { value: 'az', label: 'A-Z' },
                { value: 'za', label: 'Z-A' },
                { value: 'manual', label: 'Manual' },
                { value: 'old', label: 'Old-New' }
              ] }),
              h('button', { class: 've-btn ve-btn-g ve-btn-s ve-collection-tool-btn ve-collection-dynamic', type: 'button', title: showDynamicFolders ? 'Hide dynamic folders' : 'Show dynamic folders', onClick: () => setShowDynamicFolders(v => !v) }, ph('magic-wand'))
            ),
            showDynamicFolders && renderDynamicFoldersPanel(),
            h('div', { class: 've-studio-nav-item' + (selectedColl === 'all' ? ' active' : ''), onClick: () => openMediaCollection('all') },
              h('span', { style: 'display:flex;align-items:center;gap:8px' }, ph('images'), 'All media'),
              h('span', { class: 've-studio-badge' }, items.length)
            ),
            h('div', { class: 've-studio-nav-item' + (selectedColl === 'uncollected' ? ' active' : ''), onClick: () => openMediaCollection('uncollected') },
              h('span', { style: 'display:flex;align-items:center;gap:8px' }, ph('tray'), 'Uncollected'),
              h('span', { class: 've-studio-badge' }, collIds('uncollected').length)
            )
          ),
          // Dynamic collection items
          h('div', { class: 've-media-collection-list ve-scroll-custom' },
          visibleCollKeys.map(key => {
            const entry = collectionMap[key] || {};
            const canDrag = !isFolderCollection(key);
            const locked = !!entry.locked;
            const label = collLabel(key);
            
            const isPathHidden = (lbl) => {
              const parts = lbl.split(' / ');
              for (let i = 1; i < parts.length; i++) {
                const ancestor = parts.slice(0, i).join(' / ');
                if (isCollectionBranchCollapsed(collectionLabelToKey[ancestor], ancestor)) return true;
              }
              return false;
            };
            if (isPathHidden(label)) return null;

            const depth = label.split('/').length - 1;
            const leafLabel = label.split('/').pop().trim();

            const hasChildren = collKeys.some(otherKey => {
              if (otherKey === key) return false;
              const otherLabel = collLabel(otherKey);
              return otherLabel.startsWith(label + ' / ');
            });

            const guides = [];
            for (let i = 0; i < depth; i++) {
              guides.push(h('div', { class: 've-tree-guide', key: i }));
            }

            const dropClass = dropCollection === key ? (dropMode === 'nest' ? ' drop-nest' : (dropMode === 'media' ? ' drop-media' : (dropMode === 'after' ? ' drop-after' : ' drop-before'))) : '';
            const dropLabel = dropCollection === key
              ? (dropMode === 'nest' ? ('Make child of ' + leafLabel) : (dropMode === 'media' ? 'Add media' : (dropMode === 'after' ? ('After ' + leafLabel) : ('Before ' + leafLabel))))
              : '';
            return h('div', {
              key,
              class: 've-studio-nav-item' + (selectedColl === key ? ' active' : '') + dropClass + (locked ? ' ve-media-locked' : '') + (isStarredCollection(key) ? ' starred' : '') + (collectionColor(key) ? ' has-custom-color' : ''),
              'data-drop-label': dropLabel,
              style: collectionColor(key) ? { '--ve-collection-accent': collectionColor(key) } : undefined,
              'aria-label': canDrag ? 'MV collection. Drag the handle to reorder. Shift-drop onto another MV collection to nest.' : 'Detected folder-plugin collection. Selectable here; hierarchy stays owned by the folder plugin.',
              title: '',
              draggable: canDrag && !locked,
              onPointerDown: e => {
                if (e.button !== 0 || !canDrag || locked) return;
                collectionDragActiveRef.current = true;
                mediaDragActiveRef.current = false;
                mediaDragCandidateRef.current = false;
                setMediaDragIds([]);
                markInternalDrag('collection');
              },
              onClick: () => openMediaCollection(key),
              onContextMenu: e => {
                e.preventDefault();
                e.stopPropagation();
                const hostRect = mediaLayoutRef.current ? mediaLayoutRef.current.getBoundingClientRect() : null;
                const rowRect = e.currentTarget.getBoundingClientRect();
                if (hostRect) {
                  const menuWidth = 188;
                  const gap = 10;
                  setCollectionMenu({
                    key,
                    x: rowRect.right - hostRect.left + gap,
                    fallbackX: rowRect.left - hostRect.left - menuWidth - gap,
                    y: rowRect.top + (rowRect.height / 2) - hostRect.top,
                    rowTop: rowRect.top - hostRect.top,
                    rowHeight: rowRect.height || 32,
                    bounds: { width: hostRect.width, height: hostRect.height }
                  });
                } else {
                  setCollectionMenu({
                    key,
                    x: e.clientX + 10,
                    fallbackX: e.clientX - 198,
                    y: e.clientY,
                    rowTop: e.clientY - 16,
                    rowHeight: rowRect.height || 32,
                    bounds: { width: window.innerWidth || 900, height: window.innerHeight || 620 }
                  });
                }
              },
              onDragStart: e => {
                if (!canDrag || locked) return;
                collectionDragActiveRef.current = true;
                mediaDragActiveRef.current = false;
                mediaDragCandidateRef.current = false;
                setMediaDragIds([]);
                markInternalDrag('collection');
                setDragCollection(key);
                setDragActive(false);
                e.dataTransfer.effectAllowed = 'move';
                e.dataTransfer.setData('application/x-ve-collection-key', key);
                e.dataTransfer.setData('application/x-ve-internal-drag', 'collection');
                e.dataTransfer.setData('text/plain', key);
              },
              onDragOver: e => {
                const collectionPayload = e?.dataTransfer?.getData ? e.dataTransfer.getData('application/x-ve-collection-key') : '';
                const isCollectionMove = !!dragCollection || !!collectionPayload || collectionDragActiveRef.current;
                if (isCollectionMove) {
                  if (!dragCollection && collectionPayload) setDragCollection(collectionPayload);
                  if ((dragCollection || collectionPayload) === key || locked) return;
                  e.preventDefault();
                  e.stopPropagation();
                  mediaDropDepthRef.current = 0;
                  setDragActive(false);
                  setDropCollection(key);
                  const rowRect = e.currentTarget.getBoundingClientRect();
                  const yRatio = rowRect.height ? (e.clientY - rowRect.top) / rowRect.height : 0.5;
                  const xNestPoint = rowRect.left + Math.min(rowRect.width * 0.30, 82);
                  const sourceKey = dragCollection || collectionPayload;
                  const sourceLabel = sourceKey ? collLabel(sourceKey) : '';
                  const targetLabel = collLabel(key);
                  const targetIsInsideSource = sourceLabel && (targetLabel === sourceLabel || targetLabel.startsWith(sourceLabel + ' / '));
                  const wantsNest = !targetIsInsideSource && (e.shiftKey || e.altKey || (yRatio > 0.26 && yRatio < 0.74 && e.clientX > xNestPoint));
                  const mode = wantsNest ? 'nest' : (yRatio > 0.68 ? 'after' : 'before');
                  setDropMode(mode);
                  return;
                }
                if (hasMediaDrag(e)) {
                  if (locked) {
                    e.preventDefault();
                    e.stopPropagation();
                    setDropCollection(null);
                    setDropMode('');
                    return;
                  }
                  e.preventDefault();
                  e.stopPropagation();
                  mediaDropDepthRef.current = 0;
                  setDragActive(false);
                  setDropCollection(key);
                  setDropMode('media');
                  return;
                }
              },
              onDragLeave: () => {
                if (dropCollection === key) {
                  setDropCollection(null);
                  setDropMode('');
                }
              },
              onDrop: e => {
                e.preventDefault();
                e.stopPropagation();
                const mediaPayload = e.dataTransfer.getData('application/x-ve-media-ids');
                let droppedMediaIds = [];
                if (mediaPayload) {
                  try { droppedMediaIds = JSON.parse(mediaPayload); } catch(err) { droppedMediaIds = []; }
                }
                if (!droppedMediaIds.length && mediaDragIds.length) droppedMediaIds = mediaDragIds;
                if (droppedMediaIds.length) {
                  if (locked) {
                    flash('Unlock "' + collLabel(key) + '" before adding media.');
                    mediaDragActiveRef.current = false;
                    mediaDragCandidateRef.current = false;
                    mediaDropDepthRef.current = 0;
                    setDragActive(false);
                    setMediaDragIds([]);
                    clearInternalDragMarker();
                    setDropCollection(null);
                    setDropMode('');
                    return;
                  }
                  addMediaIdsToCollection(key, droppedMediaIds);
                  mediaDragActiveRef.current = false;
                  mediaDragCandidateRef.current = false;
                  mediaDropDepthRef.current = 0;
                  setDragActive(false);
                  setMediaDragIds([]);
                  clearInternalDragMarker()
                  setDropCollection(null);
                  setDropMode('');
                  return;
                }
                const from = dragCollection || e.dataTransfer.getData('application/x-ve-collection-key') || e.dataTransfer.getData('text/plain');
                if (dropMode === 'nest' || e.shiftKey || e.altKey) nestCollectionUnder(from, key);
                else if (dropMode === 'after') reorderCollectionAfter(from, key);
                else reorderCollectionBefore(from, key);
                collectionDragActiveRef.current = false;
                clearInternalDragMarker()
                setDragCollection(null);
                setDropCollection(null);
                setDropMode('');
                setDragActive(false);
              },
              onDragEnd: () => {
                collectionDragActiveRef.current = false;
                clearInternalDragMarker()
                setDragCollection(null);
                setDropCollection(null);
                setDropMode('');
                setDragActive(false);
              }
            },
              canDrag
                ? (locked
                  ? h('span', {
                    class: 've-collection-drag ve-collection-drag-disabled ve-collection-lock-static',
                    'aria-label': 'Locked collection. Use the right-click menu to unlock before moving.',
                    title: '',
                    onClick: e => { e.preventDefault(); e.stopPropagation(); },
                    onPointerDown: e => { e.preventDefault(); e.stopPropagation(); }
                  }, ph('lock-simple'))
                  : h('button', {
                    type: 'button',
                    class: 've-collection-drag',
                    draggable: true,
                    'aria-label': 'Drag to reorder. Move slightly right or hold Shift while dropping to nest.',
                    title: '',
                    onPointerDown: e => {
                      if (e.button !== 0) return;
                      e.stopPropagation();
                      collectionDragActiveRef.current = true;
                      mediaDragActiveRef.current = false;
                      mediaDragCandidateRef.current = false;
                      setMediaDragIds([]);
                      markInternalDrag('collection');
                    },
                    onClick: e => e.stopPropagation(),
                    onDragStart: e => {
                      e.stopPropagation();
                      collectionDragActiveRef.current = true;
                      mediaDragActiveRef.current = false;
                      mediaDragCandidateRef.current = false;
                      setMediaDragIds([]);
                      markInternalDrag('collection');
                      setDragCollection(key);
                      setDragActive(false);
                      e.dataTransfer.effectAllowed = 'move';
                      e.dataTransfer.setData('application/x-ve-collection-key', key);
                      e.dataTransfer.setData('application/x-ve-internal-drag', 'collection');
                      e.dataTransfer.setData('text/plain', key);
                    },
                    onDragEnd: () => {
                      collectionDragActiveRef.current = false;
                      clearInternalDragMarker()
                      setDragCollection(null);
                      setDropCollection(null);
                      setDropMode('');
                      setDragActive(false);
                    }
                  }, ph('dots-six-vertical')))
                : h('span', {
                  class: 've-collection-drag ve-collection-drag-disabled',
                  'aria-label': 'Detected folder-plugin folder. MV can view and assign it, but cannot safely reorder or nest it yet.'
                }, ph('lock-simple')),
              h('div', { class: 've-media-tree-guides' }, guides),
              h('div', { style: 'display: flex; align-items: center; gap: 4px; flex: 1; min-width: 0;' },
                hasChildren ? h('button', {
                  key: 'tree-toggle-' + key + '-' + (isCollectionBranchCollapsed(key, label) ? 'collapsed' : 'open'),
                  type: 'button',
                  class: 've-tree-toggle',
                  onClick: (e) => {
                    e.stopPropagation();
                    setCollectionBranchCollapsed(key, label, !isCollectionBranchCollapsed(key, label));
                  },
                  'aria-label': isCollectionBranchCollapsed(key, label) ? 'Expand children' : 'Collapse children',
                  title: isCollectionBranchCollapsed(key, label) ? 'Expand children' : 'Collapse children'
                }, ph(isCollectionBranchCollapsed(key, label) ? 'caret-right' : 'caret-down')) : h('div', { class: 've-tree-spacer' }),
                ph(collIcon(key), { style: 'flex-shrink: 0;' }),
                isStarredCollection(key) && h('span', { class: 've-collection-star-pill', title: 'Starred collection: pinned above normal collections' }, ph('star')),
                h('span', { style: 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-size:11px' }, leafLabel)
              ),
              h('span', { style: 'display:flex;align-items:center;gap:4px;flex-shrink:0' },
                canDrag && h('span', {
                  class: 've-collection-badge local',
                  'aria-label': 'Mimam’s Var collection'
                }, 'MV'),
                h('span', { class: 've-studio-badge' }, collCounts[key] || 0),
                !canDrag && h('span', {
                  class: 've-collection-source-pill',
                  onMouseEnter: e => showExternalFolderTip(collLabel(key), e),
                  onMouseMove: e => showExternalFolderTip(collLabel(key), e),
                  onMouseLeave: () => setExternalFolderTip(null),
                  title: ''
                },
                  ph('folder-dashed')
                ),
                !isFolderCollection(key) && h('button', { class: 've-a', style: 'width:16px;height:16px;display:flex;align-items:center;justify-content:center;opacity:0.4;font-size:11px', title: 'Remove collection', onClick: (e) => { e.stopPropagation(); requestDeleteCollection(key); } }, ph('x'))
              )
            );
          }),
          collectionSearchTerm && !visibleCollKeys.length && h('div', { class: 've-empty', style: 'padding:10px;text-align:left' }, 'No matching collections.')
          )
        )
      ),
      h('div', { class: 've-studio-sidebar-actions' + (showNewCollForm ? ' ve-sidebar-blurred' : '') },
        h('button', {
          class: 've-btn ve-btn-g ve-btn-s',
          style: 'display:flex;align-items:center;justify-content:center;gap:6px',
          onClick: () => { setNewCollName(''); setShowNewCollForm(true); }
        }, ph('plus'), 'New Collection'),
        folderData.folders && folderData.folders.length > 0 && h('div', {
          class: 've-folder-migration-promo',
          style: 'margin-top:12px;background:rgba(186,244,0,0.04);border:1px dashed rgba(186,244,0,0.25);padding:10px;border-radius:6px;display:flex;flex-direction:column;gap:6px'
        },
          h('div', { style: 'font-size:11px;color:#fff;font-weight:600;display:flex;align-items:center;gap:4px' }, ph('arrows-merge'), 'Folder Plugin Migration'),
          h('div', { style: 'font-size:10px;color:#bbb;line-height:1.45' }, 'Copy your external folders into MV local collections in bulk, or sync while the old folder plugin stays installed.'),
          h('button', {
            type: 'button',
            class: 've-btn ve-btn-g ve-btn-s',
            style: 'font-size:10px;padding:4px 8px;width:100%',
            onClick: syncExternalFolders
          }, ph('arrows-clockwise'), 'Sync external folders'),
          h('button', {
            type: 'button',
            class: 've-btn ve-btn-s',
            style: 'background:#baf400;color:#111;font-weight:600;font-size:10px;padding:4px 8px;margin-top:2px;width:100%',
            onClick: () => {
              setSelectedMigrateFolders((folderData.folders || []).map(f => String(f.id)));
              setShowMigrationModal(true);
            }
          }, 'Migrate to MV')
        )
      )
    ),
    // 2. Main Middle Gallery
    h('div', {
      class: 've-studio-main' + (MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED && dragActive && !isInternalDragBlocked() && !hasCollectionDrag(null) && !hasMediaDrag(null) ? ' drag-over' : ''),
      ref: mediaMainRef,
      onDragEnter: e => {
        if (showFileDrop(e)) return;
      },
      onDragOver: e => {
        if (hasMediaDrag(e) || hasCollectionDrag(e) || isInternalDragBlocked()) { e.preventDefault(); e.stopPropagation(); return; }
        showFileDrop(e);
      },
      onDragLeave: e => {
        if (MEDIA_STUDIO_FULLSCREEN_FILE_DROP_ENABLED && isUploadFileDrag(e) && !dragIsStillInside(e, e.currentTarget)) clearFileDrop();
      },
      onDrop: handleDrop
    },
      h('div', { class: 've-media-main-head', style: 'display:flex;align-items:center;justify-content:space-between;margin-bottom:12px;gap:12px' },
        h('div', null,
          h('h2', { style: 'margin:0;font-size:16px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px' },
            selectedColl === 'all' ? 'All Media' : selectedColl === 'uncollected' ? 'Uncollected Media' : collLabel(selectedColl) + ' Collection',
            h('span', { style: 'font-size:11px;font-weight:400;color:#888;background:rgba(255,255,255,0.04);padding:2px 8px;border-radius:10px' }, `${filtered.length} items`),
            dynamicFilter && h('button', { class: 've-btn ve-btn-g ve-btn-s', style: 'min-height:24px;height:24px;padding:0 7px', type: 'button', onClick: () => setDynamicFilter(null), title: 'Clear dynamic filter' }, ph('x'), dynamicFilter.label || 'Dynamic')
          )
        ),
        h('div', { class: 've-media-toolbar', style: 'display:flex;gap:8px;align-items:center' },
          h('input', {
            class: 've-studio-input',
            style: 'width:160px',
            placeholder: 'Search media...',
            value: search,
            onInput: handleSearch
          }),
          h('div', { class: 've-url-import-row ve-url-import-row--toolbar', onClick: e => e.stopPropagation() },
            h('input', {
              ref: urlImportRef,
              class: 've-studio-input ve-url-import-input',
              type: 'text',
              placeholder: 'Paste media URL…',
              disabled: urlImportBusy,
              onKeyDown: e => { if (e.key === 'Enter') { e.preventDefault(); handleUrlImport(e.target.value); } },
              onPaste: e => { setTimeout(() => { const v = e.target.value.trim(); if (/^https?:\/\//i.test(v)) handleUrlImport(v); }, 0); }
            }),
            h('button', {
              type: 'button',
              class: 've-btn ve-btn-g ve-btn-s ve-url-import-btn',
              disabled: urlImportBusy,
              title: 'Import media from URL',
              onClick: () => handleUrlImport(urlImportRef.current?.value)
            }, ph('cloud-arrow-up'), urlImportBusy ? 'Importing…' : 'Import')
          ),
          h('div', { class: 've-filter-bar' },
            h(SelectMenu, { className: 've-filter-menu', value: filterType, onChange: persistFilter, options: [
              { value: 'all', label: 'All Types' },
              { value: 'image', label: 'Images' },
              { value: 'svg', label: 'SVG' },
              { value: 'video', label: 'Videos' },
              { value: 'audio', label: 'Audio' },
              { value: 'application', label: 'Documents' },
              { value: 'font', label: 'Fonts' }
            ] }),
            h('div', { class: 've-filter-pop-wrap', ref: qualityPanelRef },
              h('button', {
                type: 'button',
                class: 've-menu-btn ve-filter-pop-btn' + (activeQualityFilters.length || qualityPanelOpen ? ' active' : ''),
                onClick: () => setQualityPanelOpen(v => !v),
                'aria-label': activeQualityFilters.length ? 'Open media filters: ' + currentQuality.label : 'Open media filters',
                title: activeQualityFilters.length ? 'Filter: ' + currentQuality.label : 'Filter'
              },
                ph('filter')
              ),
              qualityPanelOpen && h('div', { class: 've-filter-pop ve-scroll-custom' },
                h('div', { class: 've-filter-pop-head' },
                  h('strong', null, ph('filter'), 'Filters'),
                  h('div', { class: 've-filter-pop-head-actions' },
                    activeQualityFilters.length > 0 && h('button', { type: 'button', class: 've-filter-add ve-filter-clear-top', onClick: () => { persistQualityFilters([], false); } }, ph('trash'), 'Delete filter'),
                    h('button', { type: 'button', class: 've-a', onClick: () => setQualityPanelOpen(false) }, ph('x'))
                  )
                ),
                h('input', { class: 've-filter-search', value: qualityQuery, placeholder: 'Filter by…', autoFocus: true, onInput: e => setQualityQuery(e.target.value), onKeyDown: e => { if (e.key === 'Escape') setQualityPanelOpen(false); } }),
                h('div', { class: 've-filter-rulebar' },
                  activeQualityFilters.length ? h('span', { class: 've-filter-rule-pill' }, activeQualityFilters.length + ' rule' + (activeQualityFilters.length === 1 ? '' : 's'), ph('caret-down')) : h('button', { type: 'button', class: 've-filter-add', onClick: () => persistQualityFilters(['missing-alt']) }, ph('plus'), 'Add filter'),
                  h('button', { type: 'button', class: 've-filter-save-link', onClick: saveCurrentQualityPreset }, ph('star'), 'Save current')
                ),
                h('div', { class: 've-filter-save-row' },
                  h('input', { class: 've-filter-search', value: qualityPresetName, placeholder: 'Saved filter name…', onInput: e => setQualityPresetName(e.target.value), onKeyDown: e => { if (e.key === 'Enter') saveCurrentQualityPreset(); } }),
                  h('button', { type: 'button', class: 've-btn ve-btn-s', onClick: saveCurrentQualityPreset }, 'Save')
                ),
                savedQualityPresets.length > 0 && h('div', { class: 've-saved-filter-list' },
                  h('div', { class: 've-saved-filter-title' }, ph('star'), 'Saved filters'),
                  savedQualityPresets.map(preset => h('div', { class: 've-saved-filter-row', key: preset.id },
                    h('button', { type: 'button', onClick: () => applySavedQualityPreset(preset) }, h('strong', null, preset.name), h('em', null, (preset.qualityFilters || []).length + ' rule' + ((preset.qualityFilters || []).length === 1 ? '' : 's'))),
                    h('button', { type: 'button', class: 've-saved-filter-remove', title: 'Delete saved filter', onClick: () => removeSavedQualityPreset(preset.id) }, ph('x'))
                  ))
                ),
                activeQualityFilters.length > 0 && h('div', { class: 've-filter-builder-list' },
                  activeQualityFilters.map(val => {
                    const rule = qualityOptions.find(x => x.value === val) || { label: val };
                    return h('div', { class: 've-filter-builder', key: val },
                      h('span', null, 'Where'),
                      h('code', null, rule.label),
                      h('button', { type: 'button', class: 've-filter-rule-remove', onClick: () => removeQualityRule(val), title: 'Remove this rule' }, ph('x'))
                    );
                  })
                ),
                h('div', { class: 've-filter-pop-help' }, 'Combines with collection, dynamic folders, type, search, and sort.'),
                h('div', { class: 've-filter-choice-list ve-scroll-custom' },
                  shownQualityOptions.length ? shownQualityOptions.map(opt => h('button', {
                    type: 'button',
                    key: opt.value,
                    class: 've-filter-choice' + ((opt.value === 'all' ? activeQualityFilters.length === 0 : activeQualityFilters.includes(opt.value)) ? ' active' : ''),
                    onClick: () => toggleQualityFilter(opt.value)
                  }, ph(opt.icon), h('span', null, opt.label), h('em', null, opt.value === 'all' ? qualityCounts.all : (qualityCounts[opt.value] || 0)))) : h('div', { class: 've-menu-empty' }, 'No matching filters')
                ),
                diagnostics && !String(qualityQuery || '').trim() && h('div', { class: 've-diagnostics-mini' },
                  h('div', { class: 've-diagnostics-mini-head' }, h('strong', null, 'Diagnostics'), h('button', { type: 'button', class: 've-filter-rescan', disabled: diagnosticsLoading, onClick: refreshDiagnostics, title: diagnosticsLoading ? 'Checking diagnostics…' : 'Rescan diagnostics' }, diagnosticsLoading ? ph('arrows-clockwise') : ph('arrows-clockwise'), h('span', null, diagnosticsLoading ? 'Checking' : 'Rescan'))),
                  h('div', { class: 've-diagnostics-mini-grid' },
                    h('span', null, 'Missing files', h('b', null, diagnostics.missing_files || 0)),
                    h('span', null, 'Empty titles', h('b', null, diagnostics.empty_title || 0)),
                    h('span', null, 'Duplicate names', h('b', null, diagnostics.duplicate_filenames || 0))
                  )
                )
              )
            ),
            h(SelectMenu, { className: 've-filter-menu', value: sortBy, onChange: persistSort, options: [
              { value: 'date', label: 'Newest' },
              { value: 'name', label: 'Name A-Z' },
              { value: 'size', label: 'Largest' }
            ] })
          ),
          h('input', { type: 'file', ref: fileInputRef, multiple: true, style: 'display:none', onChange: e => { handleUploadFiles(e.target.files); e.target.value = ''; } }),
          h('input', { type: 'file', ref: zipImportRef, accept: '.zip,application/zip,application/x-zip-compressed', style: 'display:none', onChange: e => { importZipToCollection(e.target.files && e.target.files[0]); } }),
          h('div', { ref: viewPanelRef, class: 've-view-pop-wrap' + (viewPanelOpen && !viewPanelSuppressed ? ' open' : ''), onMouseEnter: openViewPanel, onMouseLeave: scheduleViewPanelClose },
            h('button', {
              class: 've-btn ve-btn-g ve-btn-s',
              style: 'padding:4px 8px;display:flex;align-items:center',
              type: 'button',
              onClick: e => { e.preventDefault(); e.stopPropagation(); toggleViewPanel(); },
              onFocus: openViewPanel,
              'aria-label': 'Choose media view',
              'aria-expanded': viewPanelOpen && !viewPanelSuppressed ? 'true' : 'false'
            }, ph(layoutMode === 'grid' ? 'squares-four' : layoutMode === 'masonry' ? 'columns' : 'list')),
            h('div', { class: 've-view-pop', onMouseEnter: openViewPanel, onMouseLeave: scheduleViewPanelClose },
              [
                { value: 'grid', label: 'Grid View', icon: 'squares-four' },
                { value: 'masonry', label: 'Masonry View', icon: 'columns' },
                { value: 'list', label: 'List View', icon: 'list' }
              ].map(opt => h('button', {
                key: opt.value,
                type: 'button',
                class: 've-view-choice' + (layoutMode === opt.value ? ' active' : ''),
                title: 'Switch to ' + opt.label,
                onClick: e => {
                  persistLayoutMode(opt.value);
                  setViewPanelOpen(false);
                  setViewPanelSuppressed(true);
                  if (e && e.currentTarget && e.currentTarget.blur) e.currentTarget.blur();
                  setTimeout(() => setViewPanelSuppressed(false), 160);
                }
              }, ph(opt.icon), h('span', null, opt.label)))
            )
          ),
          layoutMode === 'list' && h('div', { class: 've-list-meta-pop-wrap', ref: listMetaPanelRef },
            h('button', {
              class: 've-btn ve-btn-g ve-btn-s',
              style: 'padding:4px 8px;display:flex;align-items:center',
              onClick: () => setListMetaPanelOpen(v => !v),
              title: 'Choose list metadata columns',
              'aria-label': 'Choose list metadata columns'
            }, ph('columns')),
            listMetaPanelOpen && h('div', { class: 've-list-meta-pop ve-scroll-custom' },
              h('div', { class: 've-list-meta-pop-head' }, h('span', null, 'Metadata columns'), h('button', { type: 'button', class: 've-a', onClick: () => setListMetaPanelOpen(false) }, ph('x'))),
              listMetaOptions.map(opt => h('label', { class: 've-list-meta-row', key: opt.key },
                h(CheckControl, { checked: listMetaFields.includes(opt.key), onChange: () => toggleListMetaField(opt.key), title: opt.label }),
                h('span', null, opt.label)
              )),
              h('div', { class: 've-filter-rulebar' },
                h('button', { type: 'button', class: 've-filter-add', onClick: () => setListMetaSelection(listMetaOptions.map(x => x.key)) }, ph('plus'), 'Show all'),
                h('button', { type: 'button', class: 've-filter-add', onClick: () => setListMetaSelection([]) }, ph('trash'), 'Hide all')
              )
            )
          )
        )
      ),
      h('div', {
        class: 've-dropzone' + (dragActive && !isInternalDragBlocked() && !hasCollectionDrag(null) && !hasMediaDrag(null) ? ' drag-over' : ''),
        onDragEnter: showFileDrop,
        onDragOver: showFileDrop,
        onDragLeave: e => { if (isUploadFileDrag(e) && !dragIsStillInside(e, e.currentTarget)) clearFileDrop(); },
        onDrop: handleDrop,
        style: 'border:1px dashed rgba(255,255,255,0.1);border-radius:8px;padding:12px;text-align:center;color:#666;font-size:11px;margin-bottom:12px;background:rgba(255,255,255,0.005)'
      }, uploading ? h('div', { class: 've-upload-progress' },
        ph('upload-simple'),
        h('span', null, `${uploadProgress?.state || 'Uploading'} ${Math.min(uploadProgress?.done || 0, uploadProgress?.total || 1)} of ${uploadProgress?.total || 1}`),
        h('em', null, uploadProgress?.name || 'media'),
        h('div', { class: 've-upload-bar' }, h('span', { style: `width:${Math.max(6, Math.min(100, Math.round(uploadProgress?.percent ?? (((uploadProgress?.done || 0) / (uploadProgress?.total || 1)) * 100))))}%` }))
      ) : [
        h('span', { onClick: () => fileInputRef.current?.click(), style: 'cursor:pointer' }, ph('upload-simple'), ' Drag & drop files here, or click to browse')
      ]),
      h('div', { class: 've-media-overview' },
        overviewStats.map(card => h('button', {
          key: card.key,
          type: 'button',
          class: 've-media-overview-card' + (activeQualityFilters.includes(card.key) ? ' active' : ''),
          onClick: () => activateOverviewFilter(card.key),
          title: 'Filter by ' + card.label
        },
          h('span', { class: 've-media-overview-icon' }, ph(card.icon)),
          h('span', { class: 've-media-overview-copy' }, h('strong', null, card.value), h('em', null, card.label), h('small', null, card.helper))
        ))
      ),
      activeQualityFilters.length > 0 && h('div', { class: 've-active-filter-strip' },
        h('span', null, ph('filter'), 'Active filters'),
        activeQualityFilters.map(val => { const rule = qualityOptions.find(x => x.value === val) || { label: val }; return h('button', { key: val, type: 'button', onClick: () => removeQualityRule(val) }, rule.label, ph('x')); }),
        h('button', { type: 'button', class: 'clear', onClick: () => persistQualityFilters([]) }, 'Clear all')
      ),
      activeQualityFilters.includes('missing-alt') && h('div', { class: 've-media-workflow-card' },
        h('div', null, h('strong', null, 'Missing Alt Text workflow'), h('span', null, 'Edit inline, save on blur, or bulk-fill from clean filenames/titles.')),
        h('div', null,
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: bulkFillMissingAltFromFilename }, ph('text-aa'), 'Bulk fill visible'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', disabled: true, title: 'Reserved for later AI alt suggestions.' }, ph('sparkle'), 'AI suggestions later')
        )
      ),
      activeQualityFilters.includes('unused') && h('div', { class: 've-media-workflow-card' },
        h('div', null, h('strong', null, 'True Unused Images scan'), h('span', null, unusedScan.loading ? 'Scanning in the background. You can keep using the library.' : (unusedScan.message ? unusedScan.message : (unusedScan.scanned ? 'Scanned ' + unusedScan.scanned + ' images. ' + (unusedScan.limited ? 'Result was limited for safety.' : '') : 'Select this filter to scan image references.')))),
        h('div', null,
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', disabled: unusedScan.loading, onClick: () => { unusedScanRunRef.current += 1; setUnusedScan({ key: '', ids: null, loading: false, scanned: 0, limited: false, message: '' }); } }, ph('arrows-clockwise'), unusedScan.loading ? 'Scanning…' : 'Rescan')
        )
      ),
      (!loading && filtered.length === 0) ? h('div', { class: 've-media-empty-state' }, activeQualityFilters.includes('unused') ? (unusedScan.loading ? 'Scanning unused images in the background…' : 'No unused images found in the places MV can scan.') : 'No media files found.') :
      showCommandPanel && h('div', { class: 've-media-command' },
        h('div', { class: 've-media-command-head' },
          ph('command'),
          h('input', { class: 've-studio-input', placeholder: 'Search commands and settings', autoFocus: true, onKeyDown: e => { if (e.key === 'Escape') setShowCommandPanel(false); } }),
          h('button', { class: 've-a', style: 'width:28px;height:28px;display:flex;align-items:center;justify-content:center', onClick: () => setShowCommandPanel(false) }, ph('x'))
        ),
        h('div', { class: 've-media-command-body ve-scroll-custom' },
          [
            ['Create New Collection', 'Alt', 'N'],
            ['Rename Collection', 'F2'],
            ['Download Collection ZIP', 'Ctrl', 'D'],
            ['Expand All Folders', '→'],
            ['Collapse Folder', '←'],
            ['Next Collection', '↓'],
            ['Previous Collection', '↑'],
            ['Select range', 'Shift', 'Click'],
            ['Open Media Studio', 'Alt', 'Z']
          ].map((row, index) => h('div', { class: 've-shortcut-row', key: index },
            h('span', null, row[0]),
            h('span', null, row.slice(1).map(key => h('span', { class: 've-keycap', key }, key)))
          ))
        )
      ),
      filtered.length > 0 && (layoutMode === 'grid' ? (
        h('div', { class: 've-media-grid ve-scroll-custom' }, filtered.map((item, idx) => renderMediaCard(item, idx, 'grid')))
      ) : layoutMode === 'masonry' ? (
        h('div', { class: 've-media-masonry ve-scroll-custom', style: { '--ve-masonry-columns': masonryColumnCount } },
          masonryColumns.map((col, colIndex) => h('div', { class: 've-media-masonry-col', key: 'masonry-col-' + colIndex },
            col.map(({ item, idx }) => renderMediaCard(item, idx, 'masonry'))
          ))
        )
      ) : (
        h('div', { class: 've-studio-table-container ve-media-list-scroller ve-scroll-custom', style: 'margin:0;flex:1' },
          h('table', { class: 've-studio-table ve-media-list-table ' + (showListMeta ? 'meta-open' : 'meta-closed'), style: { minWidth: 'max(100%, ' + (720 + (listMetaFields.length * 132)) + 'px)' } },
            h('thead', null,
              h('tr', null,
                h('th', { style: 'width:40px' },
                  h(CheckControl, { checked: checkedItems.length === filtered.length && filtered.length > 0, onChange: toggleCheckAll, title: checkedItems.length === filtered.length ? 'Deselect all' : 'Select all' })
                ),
                h('th', { style: 'width:80px' }, 'Preview'),
                h('th', { class: 've-list-name' }, 'Filename'),
                h('th', { class: 've-list-alt' }, 'Alt Text (Auto-saves on blur)'),
                listMetaFields.includes('mime') && h('th', { class: 've-list-meta' }, 'MIME Type'),
                listMetaFields.includes('size') && h('th', { class: 've-list-meta' }, 'File Size'),
                listMetaFields.includes('dimensions') && h('th', { class: 've-list-meta' }, 'Dimensions'),
                listMetaFields.includes('uploaded') && h('th', { class: 've-list-meta' }, 'Uploaded'),
                listMetaFields.includes('uploaded_by') && h('th', { class: 've-list-meta' }, 'Uploaded By'),
                h('th', { class: 've-list-actions', style: 'text-align:right' }, 'Actions')
              )
            ),
            h('tbody', null, filtered.map((item, idx) => {
              const isChecked = checkedItems.includes(item.id);
              const isSel = selected && Number(selected.id) === Number(item.id);
              return h('tr', {
                key: item.id,
                class: (isSel ? 'selected ' : '') + (isChecked ? 'checked' : ''),
                onClick: e => handleMediaClick(item, e, idx),
                onDoubleClick: e => handleMediaDoubleClick(item, e, idx),
                onDblClick: e => handleMediaDoubleClick(item, e, idx),
                ondblclick: e => handleMediaDoubleClick(item, e, idx),
                draggable: !picking,
                onDragStart: e => {
                  if (picking) { e.preventDefault(); return false; }
                  const ids = checkedItems.includes(item.id) ? checkedItems : [item.id];
                  mediaDragActiveRef.current = true;
                  mediaDragCandidateRef.current = true;
                  setMediaDragIds(ids);
                  markInternalDrag('media');
                  e.dataTransfer.effectAllowed = 'copy';
                  e.dataTransfer.setData('application/x-ve-media-ids', JSON.stringify(ids));
                  e.dataTransfer.setData('application/x-ve-internal-drag', 'media');
                  e.dataTransfer.setData('text/plain', ids.join(','));
                  const ghost = createMediaDragGhost(ids);
                  e.dataTransfer.setDragImage(ghost, 10, 10);
                  setTimeout(() => ghost.remove(), 0);
                },
                onDragEnd: () => { mediaDragActiveRef.current = false; mediaDragCandidateRef.current = false; clearInternalDragMarker(); setMediaDragIds([]); setDropCollection(null); setDropMode(''); setDragActive(false); }
              },
                h('td', { onClick: e => e.stopPropagation() },
                  h(CheckControl, { checked: isChecked, onShiftClick: () => toggleCheckRange(item.id, idx), onChange: (_, e, held) => toggleCheckItem(item.id, Object.assign(e || {}, { __veShiftKey: !!held }), idx), title: isChecked ? 'Deselect asset' : 'Select asset' })
                ),
                h('td', null,
                  h('div', { class: 've-media-list-preview' }, renderFilePreview(item, 'list'))
                ),
                h('td', { class: 've-list-name' },
                  h('div', { class: 've-list-title-cell' },
                    h('strong', null, item.title?.rendered || 'Untitled'),
                    h('em', null, fileExt(item) + ' · ' + formatSize(getFileSize(item)))
                  )
                ),
                h('td', { class: 've-list-alt', onClick: e => e.stopPropagation() },
                  h('input', {
                    class: 've-studio-input',
                    value: item.alt_text || '',
                    placeholder: 'Add alt text...',
                    onInput: e => setItems(prev => prev.map(x => Number(x.id) === Number(item.id) ? { ...x, alt_text: e.target.value } : x)),
                    onBlur: e => handleAltTextSave(item.id, e.target.value)
                  })
                ),
                listMetaFields.includes('mime') && h('td', { class: 've-list-meta', style: 'color:#888;white-space:nowrap' }, item.mime_type),
                listMetaFields.includes('size') && h('td', { class: 've-list-meta', style: 'color:#888;white-space:nowrap' }, formatSize(getFileSize(item))),
                listMetaFields.includes('dimensions') && h('td', { class: 've-list-meta', style: 'color:#888;white-space:nowrap' }, item.media_details ? `${item.media_details.width}x${item.media_details.height}` : 'N/A'),
                listMetaFields.includes('uploaded') && h('td', { class: 've-list-meta', style: 'color:#888;white-space:nowrap' }, item.date ? new Date(item.date).toLocaleDateString() : 'Unknown'),
                listMetaFields.includes('uploaded_by') && h('td', { class: 've-list-meta', style: 'color:#888;white-space:nowrap;overflow:hidden;text-overflow:ellipsis' }, authorLabel(item)),
                h('td', { class: 've-list-actions', style: 'text-align:right', onClick: e => e.stopPropagation() },
                  h('div', { style: 'display:flex;gap:6px;justify-content:flex-end' },
                    h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => handleCopyLink(item.source_url), title: 'Copy URL' }, ph('copy')),
                    h('button', { class: 've-btn ve-btn-g ve-btn-s', style: 'color:#ff4d4d', onClick: () => handleDelete(item), title: 'Delete Permanently' }, ph('trash'))
                  )
                )
              );
            }))
          )
        )
      )),
      // Batch action overlay
      checkedItems.length > 0 && h('div', { class: 've-media-batch-overlay ve-bulk-polished' },
        h('div', { class: 've-bulk-summary' },
          h('button', { type: 'button', class: 've-bulk-close', onClick: () => setCheckedItems([]), title: 'Deselect all' }, ph('x')),
          h('span', { class: 've-bulk-count' }, checkedItems.length),
          h('strong', null, 'Selected'),
          selectedImageItems.length > 0 && h('em', null, selectedImageItems.length + ' image' + (selectedImageItems.length === 1 ? '' : 's'))
        ),
        h('div', { class: 've-media-selected-strip' },
          checkedItems.slice(0, 8).map(id => {
            const item = items.find(x => x.id === id);
            return item ? h('div', { class: 've-media-selected-mini', key: id, title: item.title?.rendered || '' }, renderFilePreview(item, 'grid')) : null;
          }),
          checkedItems.length > 8 && h('span', { class: 've-media-selected-more' }, '+' + (checkedItems.length - 8))
        ),
        h('div', { class: 've-media-batch-actions' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => handleBatchAddToCollection() }, ph('folder'), 'Add to collection'),
          isLocalCollectionOpen() && h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: removeCheckedFromCurrentCollection, title: 'Remove selected media that belong to this open collection' }, ph('x'), 'Remove'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: downloadSelectedZip, title: 'Download selected media as a ZIP export' }, ph('download-simple'), 'Export ZIP'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', disabled: !selectedImageItems.length, onClick: compressCheckedImages, title: selectedImageItems.length ? 'Compress selected images in place. MV rewrites supported image files through the WordPress image editor to reduce file size, then refreshes metadata.' : 'Only images can be compressed' }, ph('hard-drives'), 'Compress'),
          h('span', { class: 've-bulk-convert-group' },
            h(SelectMenu, { className: 've-filter-menu', value: convertFormat, onChange: setConvertFormat, options: [
              { value: 'webp', label: 'WEBP' },
              { value: 'avif', label: 'AVIF' },
              { value: 'jpeg', label: 'JPEG' },
              { value: 'png', label: 'PNG' }
            ] }),
            h('button', { class: 've-btn ve-btn-g ve-btn-s', disabled: !selectedImageItems.length, onClick: convertCheckedImages }, ph('file-arrow-down'), 'Convert')
          ),
          h('button', { class: 've-btn ve-btn-s ve-danger-outline', onClick: handleBatchDelete }, ph('trash'), 'Delete')
        )
      )
    ),
    // 3. Right Sidebar Details Panel — keyed on selected.id for instant switching
    selected && h('div', { key: 'sidecar-' + selected.id, class: 've-studio-details-sidebar ve-scroll-custom' },
      h('div', { class: 've-details-head' },
        h('span', { style: 'font-weight:700;color:#fff' }, 'Attachment Details'),
        h('button', { class: 've-a', style: 'width:24px;height:24px;display:flex;align-items:center;justify-content:center', onClick: () => setSelected(null), title: 'Close Sidebar' }, ph('x'))
      ),
      h('div', { ref: detailPreviewRef, class: 've-media-detail-preview ve-scroll-custom ve-preview-mode-' + detailPreviewMode, onMouseDown: startPreviewPan }, renderFilePreview(selected, 'detail:' + detailPreviewMode + ':' + detailPreviewZoom)),
      isImageFile(selected) && h('div', { class: 've-preview-mode-row' },
        [
          { value: 'fit', label: 'Fit' },
          { value: 'fit-width', label: 'Fit width' },
          { value: 'actual', label: 'Actual size' },
          { value: 'zoom', label: 'Pan/zoom' }
        ].map(opt => h('button', {
          key: opt.value,
          type: 'button',
          class: detailPreviewMode === opt.value ? 'active' : '',
          onClick: () => { setDetailPreviewMode(opt.value); persistUserPreference('ve_media_detail_preview_mode', opt.value); }
        }, opt.label))
      ),
      isImageFile(selected) && detailPreviewMode === 'zoom' && h('label', { class: 've-preview-zoom-row' },
        h('span', null, Math.round(detailPreviewZoom * 100) + '%'),
        h('input', {
          type: 'range',
          min: '1',
          max: '4',
          step: '.1',
          value: detailPreviewZoom,
          onInput: e => {
            const next = Math.max(1, Math.min(4, parseFloat(e.target.value || '1') || 1));
            setDetailPreviewZoom(next);
            persistUserPreference('ve_media_detail_preview_zoom', String(next));
          }
        })
      ),
      isImageFile(selected) && detailPreviewMode === 'zoom' && h('div', { style: 'font-size:10px;color:#777;line-height:1.35;margin-top:-2px' }, 'Drag inside the preview or use the scrollbars to pan the enlarged image.'),
      h('div', { style: 'display:flex;flex-direction:column;gap:12px' },
        h('div', { class: 've-media-meta-card' },
          h('div', { class: 've-media-meta-head' },
            h('span', null, 'Metadata'),
            h('em', null, mediaSaveState || 'Ready')
          ),
          h('label', { class: 've-media-meta-field' },
            h('span', null, 'File name / Title'),
            h('div', { class: 've-media-meta-row' },
              h('input', { class: 've-studio-input ve-studio-input-filename', value: filenameDraft, onInput: e => setFilenameDraft(e.target.value), onBlur: requestFilenameSave }),
              h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => handleCopyLink(selected.filename || filenameDraft), title: 'Copy filename' }, ph('copy'))
            )
          ),
          h('label', { class: 've-media-meta-field' },
            h('span', null, 'Alt Text'),
            h('textarea', {
              class: 've-studio-input ve-studio-textarea',
              value: altDraft,
              placeholder: 'Describe this image...',
              onInput: e => setAltDraft(e.target.value),
              onBlur: e => handleAltTextSave(selected.id, e.target.value)
            })
          ),
          h('label', { class: 've-media-meta-field' },
            h('span', null, 'Caption'),
            h('textarea', { class: 've-studio-input ve-studio-textarea ve-studio-textarea-small', value: captionDraft, placeholder: 'Optional visible caption...', onInput: e => setCaptionDraft(e.target.value) })
          ),
          h('label', { class: 've-media-meta-field' },
            h('span', null, 'Description'),
            h('textarea', { class: 've-studio-input ve-studio-textarea ve-studio-textarea-small', value: descriptionDraft, placeholder: 'Optional attachment description...', onInput: e => setDescriptionDraft(e.target.value) })
          ),
          h('div', { class: 've-media-copy-grid' },
            h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => handleCopyLink(selected.source_url) }, ph('copy'), 'Copy URL'),
            h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => handleCopyTag(selected) }, ph('brackets-curly'), 'Copy tag'),
            h('button', { class: 've-btn ve-btn-s', type: 'button', onClick: saveSelectedMetadata }, ph('check'), mediaSaveState === 'Saving metadata…' ? 'Saving…' : 'Save metadata')
          )
        ),
        h('div', { style: 'display:flex;gap:12px;font-size:11px;color:#888' },
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:11px;text-transform:uppercase;margin-bottom:2px' }, 'Dimensions'),
            h('div', { style: 'color:#ccc' }, selected.media_details ? `${selected.media_details.width}x${selected.media_details.height}` : 'N/A')
          ),
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:11px;text-transform:uppercase;margin-bottom:2px' }, 'Size'),
            h('div', { style: 'color:#ccc' }, formatSize(getFileSize(selected)))
          ),
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:11px;text-transform:uppercase;margin-bottom:2px' }, 'File type'),
            h('div', { style: 'color:#ccc' }, fileExt(selected))
          )
        ),
        h('div', { style: 'display:grid;grid-template-columns:1fr 1fr;gap:8px;font-size:11px;color:#888' },
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:11px;text-transform:uppercase;margin-bottom:2px' }, 'Uploaded by'),
            h('div', { style: 'color:#ccc;overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, authorLabel(selected))
          ),
          h('div', null,
            h('div', { style: 'color:#555;font-weight:700;font-size:11px;text-transform:uppercase;margin-bottom:2px' }, 'Uploaded on'),
            h('div', { style: 'color:#ccc' }, selected.date ? new Date(selected.date).toLocaleDateString() : 'Unknown')
          )
        ),
        h('div', { class: 've-media-usage-card' },
          h('div', { class: 've-media-usage-head' },
            h('div', { class: 've-media-usage-title' }, ph('tree-structure'), 'Usage & replace impact'),
            h('span', { class: 've-media-usage-count' }, mediaUsageLoading ? 'Scanning' : `${mediaUsage?.total || 0} use${(mediaUsage?.total || 0) === 1 ? '' : 's'}`)
          ),
          mediaUsageError
            ? h('div', { class: 've-media-usage-empty' }, mediaUsageError)
            : mediaUsageLoading
              ? h('div', { class: 've-media-usage-empty' }, 'Checking featured images, post content, saved builder data, post meta, and options…')
              : mediaUsage?.unused
                ? h('div', { class: 've-media-usage-empty' }, 'Unused in the places MV can scan. Replace is low impact, but custom code or remote CSS may still reference the file URL.')
                : h('div', { class: 've-media-usage-list ve-scroll-custom' },
                  Object.keys(mediaUsage?.groups || {}).reduce((rows, group) => rows.concat((mediaUsage.groups[group] || []).map((row, idx) => {
                    const content = [
                      h('span', { key: 'label' }, row.label || row.id || group),
                      h('em', { key: 'meta' }, (row.source || group) + (row.detail ? ' · ' + row.detail : ''))
                    ];
                    return row.edit
                      ? h('a', { key: group + '-' + idx, class: 've-media-usage-row', href: row.edit, target: '_blank', rel: 'noreferrer' }, content)
                      : h('div', { key: group + '-' + idx, class: 've-media-usage-row' }, content);
                  })), [])
                ),
          mediaUsage?.limited && h('div', { class: 've-media-usage-empty' }, 'Usage list is capped for performance. Counts show the visible scan result.'),
          !mediaUsageLoading && !mediaUsageError && h('div', { class: 've-media-usage-help' }, (mediaUsage?.total || 0) ? 'Use this before replacing or deleting. MV shows the places it can safely detect, so used assets are easier to review first.' : 'No safe usage detected. Custom PHP/CSS/CDN references may still exist.')
        ),
        collKeys.length > 0 && h('div', null,
          h('div', { style: 'font-size:11px;color:#555;text-transform:uppercase;font-weight:700;margin-bottom:6px' }, 'Collections'),
          h('div', { class: 've-chip-list', style: 'font-size:11px' },
            collKeys.filter(key => collIds(key).includes(selected.id)).sort((a, b) => collectionDepth(b) - collectionDepth(a)).map(key => {
              const ids = collIds(key);
              return h('div', { key, class: 've-chip-row' },
                h('span', { style: 'display:flex;align-items:center;gap:6px;min-width:0' }, h('span', { style: 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap' }, collectionLeafLabel(key))),
                h('button', { class: 've-chip-remove', title: 'Remove from collection', onClick: () => toggleCollectionItem(key, selected.id, false) }, ph('x'))
              );
            }),
            !collKeys.some(key => collIds(key).includes(selected.id)) && h('div', { class: 've-empty', style: 'padding:8px 0;text-align:left' }, 'Not in any collection yet.')
          ),
          h('div', { class: 've-chip-action-row' },
            h('button', { class: 've-btn ve-btn-g ve-btn-s ve-replace-wide', type: 'button', onClick: () => { setCheckedItems([selected.id]); setPendingBatchCollection(true); } }, ph('plus'), 'Add to collection')
          )
        ),
        (() => {
          const historyRows = Array.isArray(selected.action_history) && selected.action_history.length ? selected.action_history : (Array.isArray(selected.replace_history) ? selected.replace_history : []);
          return historyRows.length > 0 && h('div', { class: 've-replace-history-card' },
            h('div', { class: 've-media-usage-head' },
              h('div', { class: 've-media-usage-title' }, ph('arrows-clockwise'), 'Change history'),
              h('span', { class: 've-media-usage-count' }, historyRows.length + ' event' + (historyRows.length === 1 ? '' : 's'))
            ),
            h('div', { class: 've-replace-history-list ve-scroll-custom' }, historyRows.map((row, idx) => {
              const action = row.action ? String(row.action) : 'replace';
              const before = row.old_file || row.old_title || 'Previous';
              const after = row.new_file || row.new_title || 'Current';
              return h('div', { class: 've-replace-history-row', key: row.rollback_id || idx },
                h('span', null, action.charAt(0).toUpperCase() + action.slice(1) + ' · ' + (row.at || 'Unknown time')),
                h('em', null, before + ' → ' + after),
                row.rollback_id && action !== 'rollback' && h('button', { type: 'button', class: 've-history-restore-btn', onClick: () => rollbackMediaAction(row), title: 'Restore this version' }, ph('arrows-counter-clockwise'), 'Restore')
              );
            }))
          );
        })(),
        h('div', null,
          h('div', { style: 'font-size:11px;color:#555;text-transform:uppercase;font-weight:700;margin-bottom:6px' }, 'Asset Actions'),
          h('input', { type: 'file', ref: replaceInputRef, style: 'display:none', onChange: e => handleReplaceFile(e.target.files) }),
          h('div', { class: 've-media-actions-card' },
            h('button', { class: 've-btn ve-btn-g ve-btn-s ve-replace-wide', onClick: () => replaceInputRef.current?.click(), title: 'Upload a new file while keeping this attachment ID, alt text, title, and references.' }, ph('arrows-clockwise'), 'Replace File'),
            isImageFile(selected) && h('div', { class: 've-convert-card' },
              h('div', { class: 've-convert-card-title' }, 'Convert file type'),
              h(SelectMenu, { className: 've-filter-menu ve-convert-menu', value: convertFormat, onChange: setConvertFormat, options: [
                { value: 'webp', label: 'WEBP' },
                { value: 'avif', label: 'AVIF' },
                { value: 'jpeg', label: 'JPEG' },
                { value: 'png', label: 'PNG' }
              ] }),
              h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: convertSelected, disabled: convertingId === selected.id, title: 'Create a converted copy in the selected format and keep this asset selected.' }, ph('file-arrow-down'), convertingId === selected.id ? 'Converting...' : 'Convert to ' + convertFormat.toUpperCase())
            ),
            h('button', { class: 've-btn ve-btn-g ve-btn-s ve-replace-wide', type: 'button', onClick: () => downloadMediaUrl(selected) }, ph('download-simple'), 'Download file')
          )
        )
      ),
      h('div', { style: 'display:flex;flex-direction:column;gap:8px;margin-top:auto;border-top:1px solid rgba(255,255,255,0.06);padding-top:12px' },
        h('button', {
          class: 've-btn ve-btn-primary',
          style: 'color:#1f1f1f;font-weight:600;display:flex;align-items:center;justify-content:center;gap:6px',
          onClick: () => insertSelectedMedia()
        }, ph('check'), picking ? 'Use Selected Media' : 'Insert Media URL'),
        h('button', {
          class: 've-btn ve-btn-g',
          style: 'display:flex;align-items:center;justify-content:center;gap:6px',
          onClick: () => handleCopyTag(selected)
        }, ph('copy'), 'Copy HTML Tag'),
        h('button', {
          class: 've-btn',
          style: 'background:rgba(255,77,77,0.1);color:#ff4d4d;border:1px solid rgba(239,68,68,0.55);display:flex;align-items:center;justify-content:center;gap:6px',
          onClick: () => handleDelete(selected)
        }, ph('trash'), 'Delete Permanently')
      )
    ),
    !selected && isLocalCollectionOpen() && (() => {
      const key = selectedColl;
      const entry = collectionMap[key] || {};
      const ids = collIds(key).map(Number);
      const collectionItems = items.filter(item => ids.includes(Number(item.id)));
      const size = collectionItems.reduce((sum, item) => sum + getFileSize(item), 0);
      const shortcode = '[mv_media_collection collection="' + key + '"]';
      const locked = !!entry.locked;
      const starred = !!entry.starred;
      const color = collectionColor(key);
      return h('div', { key: 'collection-sidecar-' + key, class: 've-studio-details-sidebar ve-collection-details-sidebar ve-scroll-custom' },
        h('div', { class: 've-details-head' },
          h('span', { style: 'font-weight:700;color:#fff' }, 'Collection Details'),
          h('button', { class: 've-a', style: 'width:24px;height:24px;display:flex;align-items:center;justify-content:center', onClick: () => setSelectedColl('all'), title: 'Close collection details' }, ph('x'))
        ),
        h('div', { class: 've-collection-detail-hero', style: color ? { '--ve-collection-accent': color } : undefined },
          h('div', { class: 've-collection-detail-icon' }, ph(collIcon(key))),
          h('div', { class: 've-collection-detail-title' },
            h('strong', null, collLabel(key)),
            h('span', null, collectionItems.length + ' media file' + (collectionItems.length === 1 ? '' : 's') + ' · ' + formatSize(size))
          )
        ),
        h('div', { class: 've-collection-status-grid' },
          h('span', null, ph(starred ? 'star' : 'star'), 'Starred', h('b', null, starred ? 'Yes' : 'No')),
          h('span', null, ph(locked ? 'lock-simple' : 'lock-open'), 'Lock', h('b', null, locked ? 'Locked' : 'Open')),
          h('span', null, ph('palette'), 'Color', h('b', null, color || 'Default'))
        ),
        h('div', { class: 've-collection-shortcode-block' },
          h('div', { class: 've-collection-shortcode-label' }, ph('brackets-curly'), 'Shortcode'),
          h('div', { class: 've-collection-shortcode-row' },
            h('input', { class: 've-studio-input', value: shortcode, readOnly: true, onFocus: e => e.target.select() }),
            h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { navigator.clipboard?.writeText(shortcode); flash('Copied collection shortcode.'); } }, ph('copy'))
          )
        ),
        h('div', { class: 've-collection-action-grid' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', disabled: locked, onClick: () => beginRenameCollection(key) }, ph('pencil-simple'), 'Rename'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', disabled: locked, onClick: () => beginChildCollection(key) }, ph('tree-structure'), 'Subfolder'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => { persistCollections({ ...collectionMap, [key]: { ...entry, starred: !starred } }); flash(starred ? 'Removed from Starred.' : 'Pinned to Starred.'); } }, ph('star'), starred ? 'Unstar' : 'Star'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: event => openCollectionColorPicker(key, event) }, ph('palette'), color ? 'Color' : 'Set color'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => downloadCollectionZip(key) }, ph('download-simple'), 'Download ZIP'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', disabled: locked, onClick: () => chooseZipForCollection(key) }, ph('file-arrow-down'), 'Import ZIP')
        ),
        h('div', { class: 've-collection-preview-list' },
          collectionItems.slice(0, 6).map(item => h('button', { type: 'button', key: item.id, onClick: () => setSelected(item) }, renderFilePreview(item, 'list'), h('span', null, item.title?.rendered || item.filename || 'Untitled'))),
          !collectionItems.length && h('div', { class: 've-empty', style: 'padding:12px;text-align:left' }, 'No media in this collection yet.')
        )
      );
    })()
  );
}

/* ── Plugin Studio sub-panel ─────────────────── */
function PluginStudioSub({ flash }) {
  const [plugins, setPlugins] = useState([]);
  const [loading, setLoading] = useState(false);
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('all');
  const [pending, setPending] = useState(null);
  const [directoryQuery, setDirectoryQuery] = useState('');
  const [directoryResults, setDirectoryResults] = useState([]);
  const [directoryLoading, setDirectoryLoading] = useState(false);
  const [directoryMode, setDirectoryMode] = useState(false);
  const [directoryView, setDirectoryView] = useState(() => localStorage.getItem('ve_plugin_directory_view') || 'list');
  const uploadRef = useRef(null);

  const loadPlugins = useCallback(async () => {
    setLoading(true);
    try {
      const res = await api.g('plugin-studio/plugins');
      setPlugins(Array.isArray(res?.plugins) ? res.plugins : []);
    } catch (e) {
      setPlugins([]);
    }
    setLoading(false);
  }, []);

  useEffect(() => { loadPlugins(); }, [loadPlugins]);

  const runPluginAction = async (plugin, action) => {
    setPending(plugin.slug + ':' + action);
    try {
      const res = await api.p('plugin-studio/action', { plugin: plugin.file, action });
      if (res && res.success) {
        flash(res.message || 'Plugin updated.');
        await loadPlugins();
      } else {
        flash(res?.message || 'Plugin action failed.');
      }
    } catch (e) {
      flash('Plugin action failed.');
    }
    setPending(null);
  };

  const searchDirectory = async (query) => {
    const q = (typeof query === 'string' ? query : directoryQuery).trim();
    setDirectoryMode(true);
    setDirectoryLoading(true);
    try {
      const res = await api.g('plugin-studio/directory?search=' + encodeURIComponent(q));
      setDirectoryResults(Array.isArray(res?.plugins) ? res.plugins : []);
    } catch (e) {
      setDirectoryResults([]);
      flash('Directory search failed.');
    }
    setDirectoryLoading(false);
  };

  useEffect(() => {
    if (!directoryMode) return;
    const t = setTimeout(() => searchDirectory(directoryQuery), 320);
    return () => clearTimeout(t);
  }, [directoryMode, directoryQuery]);

  const installDirectoryPlugin = async slug => {
    setPending(slug + ':install');
    try {
      const res = await api.p('plugin-studio/install', { slug });
      flash(res?.message || (res?.success ? 'Plugin installed.' : 'Install failed.'));
      if (res?.success) await loadPlugins();
    } catch (e) {
      flash('Install failed.');
    }
    setPending(null);
  };

  const uploadPluginZip = async file => {
    if (!file) return;
    const fd = new FormData();
    fd.append('plugin_zip', file);
    setPending('upload:plugin');
    try {
      const res = await api.f('variable-engine/v1/plugin-studio/upload', { method: 'POST', body: fd });
      flash(res?.message || (res?.success ? 'Plugin uploaded.' : 'Upload failed.'));
      if (res?.success) await loadPlugins();
    } catch (e) {
      flash('Plugin upload failed.');
    }
    if (uploadRef.current) uploadRef.current.value = '';
    setPending(null);
  };

  const filteredPlugins = useMemo(() => {
    const q = search.toLowerCase().trim();
    return plugins.filter(p => {
      if (status === 'active' && !p.active) return false;
      if (status === 'inactive' && p.active) return false;
      if (status === 'updates' && !p.update_available) return false;
      if (!q) return true;
      return (p.name || '').toLowerCase().includes(q) || (p.description || '').toLowerCase().includes(q) || (p.author || '').toLowerCase().includes(q);
    });
  }, [plugins, search, status]);

  const counts = useMemo(() => ({
    all: plugins.length,
    active: plugins.filter(p => p.active).length,
    inactive: plugins.filter(p => !p.active).length,
    updates: plugins.filter(p => p.update_available).length
  }), [plugins]);

  const directoryIcon = item => {
    const icons = item.icons || {};
    return icons['2x'] || icons['1x'] || icons.svg || icons.default || '';
  };

  const setPluginDirectoryView = view => {
    setDirectoryView(view);
    persistUserPreference('ve_plugin_directory_view', view);
  };

  return h('div', { class: 've-studio-layout ve-plugin-studio' },
    h('div', { class: 've-studio-sidebar' },
      h('div', { class: 've-studio-nav' },
        h('div', { class: 've-studio-nav-title' }, 'Installed Plugins'),
        [
          ['all', 'All plugins', 'plugs'],
          ['active', 'Active', 'toggle-right'],
          ['inactive', 'Inactive', 'toggle-left'],
          ['updates', 'Updates', 'arrow-circle-up']
        ].map(row => h('div', { class: 've-studio-nav-item' + (!directoryMode && status === row[0] ? ' active' : ''), onClick: () => { setDirectoryMode(false); setStatus(row[0]); } },
          h('span', { style: 'display:flex;align-items:center;gap:8px' }, ph(row[2]), row[1]),
          h('span', { class: 've-studio-badge' }, counts[row[0]])
        ))
      ),
      h('div', { class: 've-studio-nav' },
        h('div', { class: 've-studio-nav-title' }, 'Plugin Directory'),
        h('div', { class: 've-studio-nav-item' + (directoryMode ? ' active' : ''), onClick: () => { setDirectoryMode(true); if (!directoryResults.length) searchDirectory(''); } },
          h('span', { style: 'display:flex;align-items:center;gap:8px' }, ph('download-simple'), 'Browse plugins'),
          h('span', { class: 've-studio-badge' }, directoryResults.length || 'WP')
        )
      ),
      h('div', { class: 've-studio-stats' },
        h('div', { class: 've-studio-stats-item' }, h('span', null, 'Active'), h('b', null, counts.active)),
        h('div', { class: 've-studio-stats-item' }, h('span', null, 'Updates'), h('b', null, counts.updates))
      )
    ),
    h('div', { class: 've-studio-main' },
      h('div', { class: 've-studio-topbar' },
        h('div', null,
          h('h2', { style: 'margin:0;font-size:16px;font-weight:700;color:#fff;display:flex;align-items:center;gap:8px' }, directoryMode ? 'Plugin Directory' : 'Plugin Studio', h('span', { class: 've-studio-badge' }, directoryMode ? ((directoryLoading ? '...' : directoryResults.length) + ' found') : (filteredPlugins.length + ' shown'))),
          h('div', { class: 've-studio-help' }, directoryMode ? 'Search and install plugins from the WordPress.org directory.' : 'Manage activation, updates, auto-updates, and cleanup without leaving Mimam\'s Var.')
        ),
        h('div', { style: 'display:flex;gap:8px;align-items:center;flex-wrap:wrap;justify-content:flex-end' },
          !directoryMode && h('input', { class: 've-studio-input', style: 'width:220px', placeholder: 'Search installed plugins...', value: search, onInput: e => setSearch(e.target.value) }),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: loadPlugins, disabled: loading }, ph('arrows-clockwise'), loading ? 'Refreshing' : 'Refresh'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: () => uploadRef.current && uploadRef.current.click(), disabled: pending === 'upload:plugin' }, ph('upload-simple'), pending === 'upload:plugin' ? 'Uploading' : 'Upload ZIP'),
          h('input', { ref: uploadRef, type: 'file', accept: '.zip,application/zip,application/x-zip-compressed', style: 'display:none', onChange: e => uploadPluginZip(e.target.files && e.target.files[0]) })
        )
      ),
      directoryMode && h('div', { class: 've-plugin-directory-bar' },
        h('input', { class: 've-studio-input', placeholder: 'Ajax search WordPress plugin directory...', value: directoryQuery, onInput: e => setDirectoryQuery(e.target.value), onKeyDown: e => { if (e.key === 'Enter') searchDirectory(); } }),
        h('button', { class: 've-btn ve-btn-s', onClick: () => searchDirectory(), disabled: directoryLoading }, ph('magnifying-glass'), directoryLoading ? 'Searching' : 'Search'),
        h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => setPluginDirectoryView(directoryView === 'grid' ? 'list' : 'grid'), title: directoryView === 'grid' ? 'List view' : 'Grid view' }, ph(directoryView === 'grid' ? 'list' : 'squares-four')),
        directoryMode && h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: () => setDirectoryMode(false) }, 'Installed')
      ),
      directoryMode && h('div', { class: 've-plugin-directory-results ' + directoryView },
        directoryLoading ? h('div', { class: 've-empty' }, 'Searching WordPress.org...') :
        directoryResults.length === 0 ? h('div', { class: 've-empty' }, 'No directory results yet.') :
        directoryResults.map(item => h('div', { class: 've-plugin-card', key: item.slug },
          directoryIcon(item)
            ? h('img', { class: 've-plugin-card-icon', src: directoryIcon(item), alt: '' })
            : h('div', { class: 've-plugin-card-icon' }, ph('plug')),
          h('div', { class: 've-plugin-card-main' },
            h('strong', null, item.name || item.slug),
            h('span', null, item.short_description || 'No description provided.'),
            h('small', null, (item.version ? 'v' + item.version : ''), item.author ? ' · ' + item.author.replace(/<[^>]*>/g, '') : '', item.active_installs ? ' · ' + item.active_installs.toLocaleString() + '+ installs' : '')
          ),
          h('button', { class: 've-btn ve-btn-s', disabled: pending === item.slug + ':install', onClick: () => installDirectoryPlugin(item.slug) }, pending === item.slug + ':install' ? 'Installing' : 'Install')
        ))
      ),
      !directoryMode &&
      h('div', { class: 've-studio-table-container' },
        loading ? h('div', { class: 've-empty' }, 'Loading plugins...') :
        filteredPlugins.length === 0 ? h('div', { class: 've-empty' }, 'No plugins match this filter.') :
        h('table', { class: 've-studio-table ve-plugin-table' },
          h('thead', null, h('tr', null,
            h('th', null, 'Plugin'),
            h('th', { style: 'width:100px' }, 'Version'),
            h('th', { style: 'width:110px' }, 'Status'),
            h('th', { style: 'width:120px' }, 'Auto-update'),
            contentColumns.actions && h('th', { style: 'width:260px;text-align:right' }, 'Actions')
          )),
          h('tbody', null, filteredPlugins.map(plugin => {
            const busy = pending && pending.indexOf(plugin.slug + ':') === 0;
            return h('tr', { key: plugin.file },
              h('td', null,
                h('div', { style: 'display:flex;flex-direction:column;gap:3px' },
                  h('strong', { style: 'color:#fff' }, plugin.name),
                  h('span', { class: 've-plugin-description' }, plugin.description || plugin.file),
                  h('span', { class: 've-plugin-author' }, plugin.author || '')
                )
              ),
              h('td', null, h('span', { style: 'font-family:"SF Mono","Fira Code",monospace;color:#ccc' }, plugin.version || '-')),
              h('td', null, h('span', { class: 've-studio-badge ' + (plugin.active ? 'ok' : '') }, plugin.active ? 'Active' : 'Inactive')),
              h('td', null, h(ToggleControl, { checked: !!plugin.auto_update, disabled: busy, onChange: () => runPluginAction(plugin, plugin.auto_update ? 'auto_update_off' : 'auto_update_on'), title: plugin.auto_update ? 'Auto-update on' : 'Auto-update off' })),
              h('td', { style: 'text-align:right' },
                h('div', { style: 'display:flex;gap:6px;justify-content:flex-end;flex-wrap:wrap' },
                  plugin.update_available && h('a', { class: 've-btn ve-btn-s', href: plugin.update_url || 'update-core.php', style: 'text-decoration:none;display:inline-flex;align-items:center' }, ph('arrow-circle-up'), 'Update'),
                  h('button', { class: 've-btn ve-btn-g ve-btn-s', disabled: busy, onClick: () => runPluginAction(plugin, plugin.active ? 'deactivate' : 'activate') }, plugin.active ? 'Deactivate' : 'Activate'),
                  !plugin.active && h('button', { class: 've-btn ve-btn-g ve-btn-s ve-danger-soft', disabled: busy, onClick: () => runPluginAction(plugin, 'delete') }, ph('trash'), 'Delete')
                )
              )
            );
          }))
        )
      )
    )
  );
}

/* ── Unified Settings sub-panel ───────────────── */
function UnifiedSettingsPanel({ onClose, panelMode, setPanelMode }) {
  const [activeTab, setActiveTab] = useState('general');
  const [s, sS] = useState({ vw_min: 320, vw_max: 1440, delete_on_uninstall: false, update_url: '', update_channel: 'stable', auto_update: false, license_server_url: '', license: {}, deactivated_tools: [], deactivated_tool_surfaces: { admin: [], builder: [] }, allow_multi_panels: false, show_all_tab: true, media_replace_wp_library: false, media_auto_sync_external_folders: false });
  const [lk, sLk] = useState('');
  const [upd, sUpd] = useState(null);
  const [ck, sCk] = useState(false);
  const [updateBusy, setUpdateBusy] = useState(false);
  const [updateBusyVersion, setUpdateBusyVersion] = useState('');
  const [rollbackConfirm, setRollbackConfirm] = useState('');
  const [updateError, setUpdateError] = useState('');
  const [licBusy, sLicBusy] = useState('');
  const [ld, sLd] = useState(true);

  const surfaceKey = MODE === 'builder' ? 'builder' : 'admin';
  const normalizeSurfaceSettings = value => ({
    admin: Array.isArray(value?.admin) ? value.admin : [],
    builder: Array.isArray(value?.builder) ? value.builder : []
  });
  const hasSurfaceChoiceFor = (id, surfaces) => !!((surfaces.admin || []).includes(id) || (surfaces.builder || []).includes(id));
  const normalizeModuleSettings = value => {
    const next = { ...(value || {}) };
    const surfaces = normalizeSurfaceSettings(next.deactivated_tool_surfaces);
    const legacy = Array.isArray(next.deactivated_tools) ? next.deactivated_tools : [];
    const legacyWithoutSurfaceChoice = legacy.filter(id => !hasSurfaceChoiceFor(id, surfaces));
    next.deactivated_tool_surfaces = {
      admin: [...new Set([...surfaces.admin, ...legacyWithoutSurfaceChoice])],
      builder: [...new Set([...surfaces.builder, ...legacyWithoutSurfaceChoice])]
    };
    next.deactivated_tools = [];
    return next;
  };
  const legacyDeactivated = id => Array.isArray(s.deactivated_tools) && s.deactivated_tools.includes(id);
  const isDeactivatedOn = (id, side = surfaceKey) => {
    const surfaces = normalizeSurfaceSettings(s.deactivated_tool_surfaces);
    return (!hasSurfaceChoiceFor(id, surfaces) && legacyDeactivated(id)) || surfaces[side]?.includes(id);
  };
  const isDeactivated = id => isDeactivatedOn(id, surfaceKey);
  const activeDisabledListForSide = (side, settings = s) => {
    const legacy = Array.isArray(settings.deactivated_tools) ? settings.deactivated_tools : [];
    const surfaces = normalizeSurfaceSettings(settings.deactivated_tool_surfaces);
    const legacyWithoutSurfaceChoice = legacy.filter(id => !hasSurfaceChoiceFor(id, surfaces));
    return [...new Set([...legacyWithoutSurfaceChoice, ...(surfaces[side] || [])])];
  };

  const toggleDeactivated = (id, side = surfaceKey) => {
    const surfaces = normalizeSurfaceSettings(s.deactivated_tool_surfaces);
    const legacy = Array.isArray(s.deactivated_tools) ? s.deactivated_tools : [];
    const wasLegacy = legacy.includes(id);
    const currentlyOff = wasLegacy || surfaces[side].includes(id);
    const nextLegacy = wasLegacy ? legacy.filter(x => x !== id) : legacy;
    const otherSide = side === 'admin' ? 'builder' : 'admin';
    const nextSurfaces = {
      admin: [...surfaces.admin],
      builder: [...surfaces.builder]
    };
    if (currentlyOff) {
      nextSurfaces[side] = nextSurfaces[side].filter(x => x !== id);
      if (wasLegacy) {
        nextSurfaces[otherSide] = [...new Set([...nextSurfaces[otherSide], id])];
      }
    } else {
      nextSurfaces[side] = [...new Set([...nextSurfaces[side], id])];
    }
    sS(prev => {
      const updated = { ...prev, deactivated_tools: nextLegacy, deactivated_tool_surfaces: nextSurfaces };
      api.p('settings', updated);
      const activeList = activeDisabledListForSide(surfaceKey, updated);
      persistUserPreference('ve_deactivated_tools', activeList);
      persistUserPreference('ve_deactivated_tool_surfaces', nextSurfaces);
      builderRuntimeWindows().forEach(win => {
        try {
          const builderList = activeDisabledListForSide('builder', updated);
          win.dispatchEvent(new win.CustomEvent('ve-deactivated-tools-changed', { detail: builderList }));
        } catch(e) {
          try { win.dispatchEvent(new CustomEvent('ve-deactivated-tools-changed', { detail: activeDisabledListForSide('builder', updated) })); } catch(err) {}
        }
      });
      try { window.dispatchEvent(new CustomEvent('ve-deactivated-tools-changed', { detail: activeList })); } catch(e) {}
      return updated;
    });
  };

  const updateSetting = (key, value, eventName) => {
    sS(prev => {
      const next = { ...prev, [key]: value };
      api.p('settings', { [key]: value });
      if (eventName) {
        try { window.dispatchEvent(new CustomEvent(eventName, { detail: value })); } catch(e) {}
        builderRuntimeWindows().forEach(win => {
          try { win.dispatchEvent(new win.CustomEvent(eventName, { detail: value })); } catch(e) {}
        });
      }
      return next;
    });
  };

  // CSS Studio settings states
  const [cssScss, setCssScss] = useState(() => localStorage.getItem('ve_css_scss') === '1');
  const [cssSourceOrder, setCssSourceOrder] = useState(() => {
    try {
      return normalizeSourceOrder(JSON.parse(localStorage.getItem('ve_css_source_order') || '[]'), []);
    } catch (e) {
      return CSS_SOURCE_DEFAULTS;
    }
  });
  const [cssDisabledSources, setCssDisabledSources] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('ve_css_disabled_sources') || '[]');
    } catch (e) {
      return [];
    }
  });
  const [cssSourceMeta, setCssSourceMeta] = useState({});
  const [cssDragSource, setCssDragSource] = useState('');
  const [cssDropHint, setCssDropHint] = useState(null);
  const [cssRemoteSuggestions, setCssRemoteSuggestions] = useState({ variables: [], classes: [], ids: [], sources: [] });
  const [cssIndexMsg, setCssIndexMsg] = useState('');
  const [cssIndexBusy, setCssIndexBusy] = useState(false);

  // Mimam's Bar settings state (mirrored from window.MimamsBarSettings)
  const [barSettings, setBarSettings] = useState(() => {
    if (window.MimamsBarSettings) {
      return window.MimamsBarSettings.load();
    }
    return {};
  });

  const [folderData, setFolderData] = useState({ folders: [], map: {} });
  const [localCollections, setLocalCollections] = useState(() => {
    try {
      return JSON.parse(localStorage.getItem('ve_media_collections') || '{}');
    } catch(e) {
      return {};
    }
  });
  const [hideFolders, setHideFoldersState] = useState(() => localStorage.getItem('ve_media_hide_folders') === 'true');
  const [settingsCollapsedPaths, setSettingsCollapsedPaths] = useState(loadMediaCollapsedPaths);
  const [fabOrder, setFabOrder] = useState(() => {
    try { return normalizeFabOrder(JSON.parse(localStorage.getItem('ve_fab_order') || '[]')); } catch(e) { return normalizeFabOrder([]); }
  });
  const [showMigrateConfirm, setShowMigrateConfirm] = useState(false);
  const [migrationStatus, setMigrationStatus] = useState('');

  const settingToggleRow = (key, label, checked, onChange) => h('div', { class: 've-opt ve-opt-toggle', key },
    h('span', null, label),
    h(ToggleControl, { checked: !!checked, label, onChange })
  );

  useEffect(() => {
    api.g('settings').then(d => {
      if (d && !d.code) sS(v => ({ ...v, ...normalizeModuleSettings(d) }));
      sLd(false);
    }).catch(() => sLd(false));

    api.g('media-studio/folders').then(d => {
      if (d && !d.code) {
        setFolderData({ folders: d.folders || [], map: d.map || {} });
      }
    }).catch(() => {});

    api.g('advanced-css/suggestions').then(d => {
      if (d && !d.code) {
        setCssRemoteSuggestions(d);
        const next = normalizeSourceOrder(cssSourceOrder, d.sources || []);
        setCssSourceOrder(next);
        persistUserPreference('ve_css_source_order', next);
        const m = {};
        (d.sources || []).forEach(x => {
          m[x] = x === "Mimam's Var" ? 'Active' : 'Detected';
        });
        setCssSourceMeta(prev => ({ ...prev, ...m }));
        if (d.counts) {
          setCssIndexMsg('Index: ' + d.counts.variables + ' variables · ' + d.counts.classes + ' classes · ' + d.counts.ids + ' IDs · ' + (d.counts.selectors || 0) + ' selectors' + (d.cached ? ' (cached)' : ''));
        }
      }
    }).catch(() => {});

    api.g('migration/sources').then(d => {
      if (Array.isArray(d)) {
        const m = {};
        d.forEach(x => {
          m[x.name] = x.available ? 'Detected' : 'Not found';
          if (x.name === 'Bricks / Advanced Themer') {
            m.Bricks = x.available ? 'Detected' : 'Not found';
            m['Advanced Themer'] = x.available ? 'Detected' : 'Not found';
          }
        });
        setCssSourceMeta(prev => ({ ...prev, ...m }));
      }
    }).catch(() => {});

    const handleMediaCollectionsMigrated = () => {
      try {
        const saved = localStorage.getItem('ve_media_collections');
        setLocalCollections(saved ? JSON.parse(saved) : {});
      } catch (e) {}
    };
    const handleMediaCollectionsChanged = e => {
      if (e && e.detail && typeof e.detail === 'object') {
        setLocalCollections(e.detail);
        return;
      }
      handleMediaCollectionsMigrated();
    };
    const handleMediaCollapsedPathsChanged = e => {
      if (e && e.detail && typeof e.detail === 'object') {
        setSettingsCollapsedPaths(e.detail);
      } else {
        setSettingsCollapsedPaths(loadMediaCollapsedPaths());
      }
    };
    window.addEventListener('ve-media-collections-migrated', handleMediaCollectionsMigrated);
    window.addEventListener('ve-media-collections-changed', handleMediaCollectionsChanged);
    window.addEventListener('ve-media-collapsed-paths-changed', handleMediaCollapsedPathsChanged);
    return () => {
      window.removeEventListener('ve-media-collections-migrated', handleMediaCollectionsMigrated);
      window.removeEventListener('ve-media-collections-changed', handleMediaCollectionsChanged);
      window.removeEventListener('ve-media-collapsed-paths-changed', handleMediaCollapsedPathsChanged);
    };
  }, []);

  const setScss = v => {
    setCssScss(v);
    persistUserPreference('ve_css_scss', v ? '1' : '0');
    window.dispatchEvent(new CustomEvent('ve-css-settings-changed'));
  };

  const toggleSource = x => {
    setCssDisabledSources(a => {
      const n = a.includes(x) ? a.filter(y => y !== x) : [...a, x];
      persistUserPreference('ve_css_disabled_sources', n);
      window.dispatchEvent(new CustomEvent('ve-css-settings-changed'));
      return n;
    });
  };

  const persistSources = (a, validSources) => {
    const next = normalizeSourceOrder(a, validSources || cssRemoteSuggestions.sources || []);
    setCssSourceOrder(next);
    persistUserPreference('ve_css_source_order', next);
    window.dispatchEvent(new CustomEvent('ve-css-settings-changed'));
  };

  const refreshIndex = async () => {
    setCssIndexBusy(true);
    setCssIndexMsg('Rebuilding index...');
    const d = await api.g('advanced-css/suggestions?refresh=1');
    setCssIndexBusy(false);
    if (!d || d.code) {
      setCssIndexMsg(d?.message || 'Index refresh failed');
      return;
    }
    setCssRemoteSuggestions(d);
    const next = normalizeSourceOrder(cssSourceOrder, d.sources || []);
    setCssSourceOrder(next);
    persistUserPreference('ve_css_source_order', next);
    const m = {};
    (d.sources || []).forEach(x => {
      m[x] = x === "Mimam's Var" ? 'Active' : 'Detected';
    });
    setCssSourceMeta(prev => ({ ...prev, ...m }));
    setCssIndexMsg('Index refreshed: ' + (d.counts?.variables || 0) + ' variables · ' + (d.counts?.classes || 0) + ' classes · ' + (d.counts?.ids || 0) + ' IDs · ' + (d.counts?.selectors || 0) + ' selectors');
  };

  const dropSource = () => {
    if (!cssDragSource || !cssDropHint) return;
    const drag = cssDragSource;
    setCssDragSource('');
    const a = cssSourceOrder.filter(x => x !== drag);
    let idx = a.indexOf(cssDropHint.target);
    if (idx < 0) idx = a.length;
    if (cssDropHint.pos === 'after') idx++;
    a.splice(idx, 0, drag);
    persistSources(a);
    setCssDropHint(null);
  };

  const updateBarSetting = (key, value) => {
    const next = { ...(barSettings || {}), [key]: value };
    if (window.MimamsBarSettings) {
      window.MimamsBarSettings.set(key, value);
      setBarSettings({ ...window.MimamsBarSettings.data });
      return;
    }
    try {
      if (window.localStorage) {
        window.localStorage.setItem('mimamsBarSettings', JSON.stringify(next));
        window.localStorage.setItem('mimamsBarSettingsBackup', JSON.stringify(next));
      }
    } catch (e) {}
    try {
      if (window.vePersistUserPreference) window.vePersistUserPreference('mimamsBarSettings', next);
    } catch (e) {}
    setBarSettings(next);
  };

  const check = async () => {
    sCk(true);
    try {
      const r = await api.p('update/check', {});
      sUpd(r);
    } catch (error) {
      const currentVersion = CFG.version || '';
      sUpd({ configured:false, code:'ve_update_check_failed', message:error?.message||'Update check failed.', update_channel:s.update_channel||'stable', current_version:currentVersion, latest_version:currentVersion, update_available:false });
    } finally {
      sCk(false);
    }
  };
  useEffect(() => {
    let active = true;
    sCk(true);
    api.p('update/check', {}).then(result => {
      if (active) sUpd(result);
    }).catch(error => {
      if (!active) return;
      const currentVersion = CFG.version || '';
      sUpd({ configured:false, code:'ve_update_check_failed', message:error?.message||'Update check failed.', update_channel:s.update_channel||'stable', current_version:currentVersion, latest_version:currentVersion, update_available:false });
    }).finally(() => {
      if (active) sCk(false);
    });
    return () => { active = false; };
  }, []);
  const installUpdate = async (version) => {
    const targetVersion = version || '';
    setUpdateBusy(true);
    setUpdateBusyVersion(targetVersion);
    setUpdateError('');
    try {
      const result = await installPanelUpdate(targetVersion);
      setRollbackConfirm('');
      sUpd(previous => {
        if (!previous) return previous;
        const nextVersion = result.version || previous.current_version || previous.latest_version || CFG.version || '';
        const latestVersion = previous.latest_version || nextVersion;
        const canUpdateAgain = !!result.rollback && !!latestVersion && latestVersion !== nextVersion;
        return { ...previous, update_available: canUpdateAgain, current_version: nextVersion, message: result.message || (result.rollback ? 'Rollback installed. Refresh required.' : 'Update installed. Refresh required.') };
      });
    } catch (error) {
      setUpdateError(error?.message || 'Update failed.');
    } finally {
      setUpdateBusy(false);
      setUpdateBusyVersion('');
    }
  };
  const setLicense = r => sS(v => ({ ...v, license: r || {} }));
  const saveSettingsOnly = async () => {
    const r = await api.p('settings', s);
    sS(v => ({ ...v, ...r }));
    return r;
  };
  const activateLic = async () => {
    sLicBusy('activate');
    await saveSettingsOnly();
    const r = await api.p('license/activate', { license_key: lk });
    setLicense(r);
    sLk('');
    sLicBusy('');
  };
  const checkLic = async () => {
    sLicBusy('check');
    await saveSettingsOnly();
    const r = await api.p('license/check', {});
    setLicense(r);
    sLicBusy('');
  };
  const deactivateLic = async () => {
    sLicBusy('deactivate');
    const r = await api.p('license/deactivate', {});
    setLicense(r);
    sLicBusy('');
  };

  if (ld) return h('div', { class: 've-empty' }, 'Loading...');

  const lic = s.license || {};
  const licLabel = (lic.status || 'inactive').replace(/^\w/, m => m.toUpperCase());
  const releaseHistory = Array.isArray(upd?.release_history) ? upd.release_history : (Array.isArray(upd?.releases) ? upd.releases : []);
  const updateHosts = Array.isArray(upd?.error_details?.hosts) ? upd.error_details.hosts : [];
  const updateBlocked = !!upd?.code && (/feed|http|blocked|unreachable/i).test(String(upd.code || upd.message || ''));
  const compareVersions = (a, b) => {
    const pa = String(a || '0').split('.').map(n => parseInt(n, 10) || 0);
    const pb = String(b || '0').split('.').map(n => parseInt(n, 10) || 0);
    const max = Math.max(pa.length, pb.length);
    for (let i = 0; i < max; i++) {
      const diff = (pa[i] || 0) - (pb[i] || 0);
      if (diff) return diff;
    }
    return 0;
  };
  const renderReleaseManager = () => {
    const current = upd?.current_version || CFG.version || '';
    const latest = upd?.latest_version || (releaseHistory[0] && releaseHistory[0].version) || current;
    let rollbackRows = 0;
    const visibleReleaseHistory = releaseHistory.filter(release => {
      const version = release.version || '';
      const isRollback = version && compareVersions(version, current) < 0;
      if (!isRollback) return true;
      rollbackRows += 1;
      return rollbackRows <= 4;
    });
    return h('div', { class: 've-release-manager', key: 'release-manager' },
      h('div', { class: 've-release-head' },
        h('span', null, 'Release manager'),
        h('span', { class: 've-release-channel' }, upd?.update_channel || s.update_channel || 'stable')
      ),
      !releaseHistory.length && h('div', { class: 've-release-empty' }, ck ? 'Loading releases for the selected channel...' : 'No release history is available for this channel.'),
      releaseHistory.length > 0 && visibleReleaseHistory.map(release => {
        const version = release.version || '';
        const isCurrent = version && !compareVersions(version, current);
        const isLatest = version && !compareVersions(version, latest);
        const isRollback = version && compareVersions(version, current) < 0;
        const isBusy = updateBusy && updateBusyVersion === version;
        return h('div', { class: 've-release-row', key: 'rel-' + version },
          h('div', { style: 'min-width:0' },
            h('div', { class: 've-release-title' },
              h('span', null, release.label || ('v' + version)),
              isCurrent && h('span', { class: 've-release-pill ve-release-pill-installed' }, 'Installed'),
              !isCurrent && isLatest && h('span', { class: 've-release-pill ve-release-pill-latest' }, 'Latest'),
              isRollback && h('span', { class: 've-release-pill ve-release-pill-rollback' }, 'Rollback')
            ),
            h('div', { class: 've-release-meta' }, version, release.created_at ? ' · ' + release.created_at : '', isRollback ? ' · confirm before installing this older package' : '')
          ),
          h('div', { class: 've-release-actions' },
            release.download_url && h('a', { class: 've-release-link', href: release.download_url, target: '_blank', rel: 'noopener noreferrer', title: 'Download the ZIP package for this release' }, 'Download ZIP'),
            !isCurrent && !isRollback && h('button', { class: 've-btn ve-btn-s', disabled: updateBusy, onClick: () => installUpdate(version) }, isBusy ? 'Updating…' : 'Update'),
            !isCurrent && isRollback && h('button', { class: 've-btn ve-btn-s', disabled: updateBusy, onClick: () => setRollbackConfirm(version) }, rollbackConfirm === version ? 'Reviewing…' : 'Rollback')
          ),
          rollbackConfirm === version && h('div', { class: 've-release-confirm' },
            h('b', null, 'Rollback to v' + version + '?'),
            h('span', null, 'MV will install this selected-channel package through WordPress, restore activation, and ask you to refresh. Use this only when you intentionally want to return to an older tested release.'),
            h('div', { class: 've-release-confirm-actions' },
              h('button', { class: 've-btn', disabled: updateBusy, onClick: () => setRollbackConfirm('') }, 'Cancel'),
              h('button', { class: 've-btn ve-btn-g', disabled: updateBusy, onClick: () => installUpdate(version) }, isBusy ? 'Rolling back…' : 'Confirm rollback')
            )
          )
        );
      })
    );
  };
  const moduleSurfaceCard = (id, label, description, extra) => h('div', { class: 've-module-card', key: 'mod-' + id },
      h('div', null,
        h('div', { class: 've-module-card-title' }, label),
        h('div', { class: 've-module-card-desc' }, description)
      ),
      h('div', { class: 've-module-surface-controls' },
        ['admin', 'builder'].map(side => h('label', { key: id + '-' + side, class: 've-module-surface-toggle' },
          h(ToggleControl, { checked: !isDeactivatedOn(id, side), onChange: () => toggleDeactivated(id, side), title: (isDeactivatedOn(id, side) ? 'Enable ' : 'Disable ') + label + ' on ' + side }),
          side
        ))
      ),
    extra
  );
  const settingsBuildFolderPath = folder => {
    if (!folder) return '';
    const parts = [folder.name];
    let current = folder;
    while (current && current.parent && current.parent !== '0') {
      const parent = (folderData.folders || []).find(f => String(f.id) === String(current.parent));
      if (!parent) break;
      parts.unshift(parent.name);
      current = parent;
    }
    return parts.join(' / ');
  };
  const settingsFolderCount = folderId => {
    return collectFolderMediaIds(folderData, folderId).length;
  };
  const settingsFolderRows = (folderData.folders || [])
    .map(folder => ({ folder, label: settingsBuildFolderPath(folder) }))
    .sort((a, b) => a.label.localeCompare(b.label));
  const settingsPathHidden = label => {
    const parts = label.split(' / ');
    for (let i = 1; i < parts.length; i++) {
      if (settingsCollapsedPaths[parts.slice(0, i).join(' / ')]) return true;
    }
    return false;
  };
  const toggleSettingsFolderPath = label => {
    const next = { ...settingsCollapsedPaths, [label]: !settingsCollapsedPaths[label] };
    setSettingsCollapsedPaths(next);
    persistMediaCollapsedPaths(next);
    window.dispatchEvent(new CustomEvent('ve-media-collapsed-paths-changed', { detail: next }));
  };
  const moveFabTool = (id, dir) => {
    const order = normalizeFabOrder(fabOrder);
    const idx = order.indexOf(id);
    const nextIdx = idx + dir;
    if (idx < 0 || nextIdx < 0 || nextIdx >= order.length) return;
    const next = order.slice();
    [next[idx], next[nextIdx]] = [next[nextIdx], next[idx]];
    setFabOrder(next);
    persistUserPreference('ve_fab_order', next);
    window.dispatchEvent(new CustomEvent('ve-fab-order-changed', { detail: next }));
  };

  const settingsNav = [
    { id: 'general', label: 'General', icon: 'sliders-horizontal' },
    { id: 'updates', label: 'Updates & License', icon: 'arrows-clockwise' },
    { id: 'bar', label: "Mimam's Bar", icon: 'terminal-window' },
    { id: 'studio', label: 'CSS Studio', icon: 'brackets-curly' },
    { id: 'modules', label: 'Modules', icon: 'squares-four' },
    { id: 'media', label: 'Media Studio', icon: 'image' }
  ];

  return h('div', { style: 'display:flex;flex-direction:column;flex:1;min-height:0;box-sizing:border-box' },
    h('div', { class: 've-settings-main' },
      // Left icon rail
      h('div', { class: 've-settings-rail' },
        settingsNav.map(t => h('button', {
          type: 'button',
          key: t.id,
          class: 've-settings-rail-item ve-tip-right' + (activeTab === t.id ? ' on' : ''),
          'aria-label': t.label,
          'data-ve-tip': t.label,
          onClick: () => setActiveTab(t.id)
        }, ph(t.icon)))
      ),

    h('div', { class: 've-body ve-settings-content', style: 'flex:1;overflow-y:auto' },
      activeTab === 'general' ? [
        h('div', { class: 've-viewport-group', key: 'viewport' },
          h('div', { class: 've-viewport-head' },
            h('span', null, 'Viewport range'),
            h('small', null, 'Used by fluid values and generator previews')
          ),
          h('div', { class: 've-viewport-grid' },
            h('label', { class: 've-viewport-field' },
              h('span', { class: 've-viewport-affix' }, 'Min'),
              h('input', { type: 'number', value: s.vw_min, onInput: e => { const val = +e.target.value; sS(v => ({ ...v, vw_min: val })); api.p('settings', { ...s, vw_min: val }); } }),
              h('span', { class: 've-viewport-unit' }, 'px')
            ),
            h('label', { class: 've-viewport-field' },
              h('span', { class: 've-viewport-affix' }, 'Max'),
              h('input', { type: 'number', value: s.vw_max, onInput: e => { const val = +e.target.value; sS(v => ({ ...v, vw_max: val })); api.p('settings', { ...s, vw_max: val }); } }),
              h('span', { class: 've-viewport-unit' }, 'px')
            )
          )
        ),
        h('div', { class: 've-opt', key: 'del', style: 'margin-top:12px' }, h('span', null, 'Delete all data on uninstall'), h(ToggleControl, { checked: s.delete_on_uninstall, onChange: val => { sS(v => ({ ...v, delete_on_uninstall: val })); api.p('settings', { ...s, delete_on_uninstall: val }); } })),
        h('div', { class: 've-opt', key: 'show-all-tab', style: 'margin-top:12px' }, h('span', null, 'Show "All" tab in variables list'), h(ToggleControl, { checked: typeof s.show_all_tab === 'undefined' ? true : !!s.show_all_tab, onChange: val => { const next = { ...s, show_all_tab: val }; sS(next); api.p('settings', next); builderRuntimeWindows().forEach(win => { try { win.dispatchEvent(new win.CustomEvent('ve-show-all-tab-changed', { detail: val })); } catch(e) { try { win.dispatchEvent(new CustomEvent('ve-show-all-tab-changed', { detail: val })); } catch(err) {} } }); } })),
        h('div', { class: 've-opt ve-opt-stack', key: 'layout', style: 'margin-top:12px' },
          h('span', null, 'Panel layout'),
          h('div', { class: 've-layout-grid' },
            ['right', 'left', 'float'].map(m => h('button', { type: 'button', class: 've-btn ' + (panelMode === m ? '' : 've-btn-g') + ' ve-btn-s', onClick: () => setPanelMode(m) }, m === 'right' ? 'Dock Right' : m === 'left' ? 'Dock Left' : 'Float'))
          ),
          h('div', { style: 'font-size:11px;color:#666;line-height:1.55;margin-top:4px' }, 'Floating panels can be dragged from the header. Layout is saved on this browser.')
        ),
        h('div', { class: 've-opt ve-opt-stack', key: 'multi-panels' },
          h('span', null, 'Panel behavior (single/multiple)'),
          h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:10px;width:100%' }, h('span', { style: 'color:#d4d4d4' }, 'Allow more than one MV panel open at once'), h(ToggleControl, { checked: !!s.allow_multi_panels, onChange: val => { const next = { ...s, allow_multi_panels: val }; sS(next); persistUserPreference('ve_allow_multi_panels', val ? '1' : '0'); builderRuntimeWindows().forEach(win => { try { win.dispatchEvent(new win.CustomEvent('ve-panel-concurrency-changed', { detail: val })); } catch(e) { try { win.dispatchEvent(new CustomEvent('ve-panel-concurrency-changed', { detail: val })); } catch(err) {} } }); api.p('settings', next); } })),
          h('div', { style: 'font-size:11px;color:#777;line-height:1.55;margin-top:4px' }, 'Off keeps one major panel open at a time. On lets Studio panels share the viewport.')
        ),
        h('div', { class: 've-opt ve-opt-stack', key: 'fab-order' },
          h('span', null, 'Speed dial icon order'),
          h('div', { style: 'font-size:11px;color:#777;line-height:1.55' }, 'Move tools up or down in the bottom floating hover menu. Module visibility is still controlled in Modules.'),
          h('div', { class: 've-fab-order-list' },
            normalizeFabOrder(fabOrder).map((id, index, arr) => {
              const tool = SPEED_DIAL_TOOLS.find(item => item.id === id);
              if (!tool) return null;
              return h('div', { class: 've-fab-order-row', key: id },
                ph(tool.icon),
                h('span', null, tool.label),
                h('span', { class: 've-fab-order-actions' },
                  h('button', { type: 'button', disabled: index === 0, onClick: () => moveFabTool(id, -1), title: 'Move up' }, ph('caret-up')),
                  h('button', { type: 'button', disabled: index === arr.length - 1, onClick: () => moveFabTool(id, 1), title: 'Move down' }, ph('caret-down'))
                )
              );
            })
          )
        )
      ] : activeTab === 'updates' ? [
        h('div', { class: 've-opt ve-opt-stack', key: 'url' },
          h('span', null, 'Update feed URL'),
          h('input', { class: 've-studio-input', type: 'text', value: s.update_url || '', placeholder: 'https://.../manifest.json', onInput: e => { const val = e.target.value; sS(v => ({ ...v, update_url: val })); api.p('settings', { ...s, update_url: val }); } })
        ),
        h('div', { class: 've-opt ve-opt-stack', key: 'channel' },
          h('span', null, 'Update channel'),
          h(SelectMenu, { value: s.update_channel || 'stable', onChange: async v => { const next = { ...s, update_channel: v, update_url: '' }; sS(next); setRollbackConfirm(''); await api.p('settings', next); await check(); }, options: [{ value: 'stable', label: 'Stable' }, { value: 'beta', label: 'Beta' }, { value: 'dev', label: 'Dev' }] })
        ),
        h('div', { class: 've-opt', key: 'auto' }, h('span', null, 'Auto-update this plugin'), h(ToggleControl, { checked: !!s.auto_update, onChange: val => { sS(v => ({ ...v, auto_update: val })); api.p('settings', { ...s, auto_update: val }); } })),
        h('div', { class: 've-upd', key: 'upd-row' },
          h('button', { class: 've-btn ve-btn-g', onClick: check, disabled: ck }, ck ? 'Checking...' : 'Check update'),
          upd && h('span', { class: upd.update_available ? 'ok' : 'muted' }, upd.message || 'Checked', upd.latest_version ? ' · ' + upd.latest_version : ''),
          upd?.update_available && h('button', { class: 've-btn ve-btn-s', disabled:updateBusy, onClick:()=>installUpdate() }, updateBusy?'Updating…':'Update'),
          updateError&&h('span',{style:'color:#ff7777;font-size:11px'},updateError)
        ),
        updateBlocked && h('div', { class: 've-update-help', key: 'upd-help' },
          h('b', null, 'Update feed blocked. '),
          'Allow ', updateHosts.length ? updateHosts.join(' and ') : 'the selected update feed host',
          ' in your hosting, firewall, or security-plugin HTTP rules, then run Check update again.'
        ),
        renderReleaseManager(),
        h('div', { class: 've-opt ve-opt-stack', key: 'lic-url', style: 'margin-top:14px' }, h('span', null, 'License server URL'), h('input', { class: 've-studio-input', type: 'text', value: s.license_server_url || '', placeholder: 'https://lic.hebronmimam.com', onInput: e => { const val = e.target.value; sS(v => ({ ...v, license_server_url: val })); api.p('settings', { ...s, license_server_url: val }); } })),
        h('div', { key: 'lic-box', style: 'margin-top:8px;padding:11px;border:1px solid rgba(255,255,255,.10);border-radius:8px;background:rgba(255,255,255,.035)' },
          h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:8px;margin-bottom:8px' },
            h('span', { style: 'font-size:11px;font-weight:700;color:#ddd' }, 'License'),
            h('span', { class: lic.active ? 'ok' : 'muted', style: 'font-size:11px' }, licLabel)
          ),
          h('div', { style: 'font-size:11px;color:#888;line-height:1.55;margin-bottom:8px' }, lic.message || 'No license key saved.', lic.key_masked ? ' · ' + lic.key_masked : ''),
          h('div', { style: 'display:flex;gap:6px;align-items:center' },
            h('input', { class: 've-studio-input', type: 'text', value: lk, placeholder: 'License key', onInput: e => sLk(e.target.value), style: 'flex:1;min-width:0;font-size:11px;' }),
            h('button', { class: 've-btn', onClick: activateLic, disabled: !!licBusy || !lk.trim() }, licBusy === 'activate' ? 'Saving...' : 'Activate')
          ),
          h('div', { style: 'display:flex;gap:6px;margin-top:8px' },
            h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: checkLic, disabled: !!licBusy }, licBusy === 'check' ? 'Checking...' : 'Check license'),
            lic.configured && h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: deactivateLic, disabled: !!licBusy }, licBusy === 'deactivate' ? 'Removing...' : 'Deactivate')
)
)

] : activeTab === 'bar' ? [
        // Mimam's Bar settings
        settingToggleRow('bar-autoClose', 'Auto-close after apply', !!barSettings.autoClose, val => updateBarSetting('autoClose', val)),
        settingToggleRow('bar-skipBulkPreview', 'Skip bulk preview confirmation', !!barSettings.skipBulkPreview, val => updateBarSetting('skipBulkPreview', val)),
        h('div', { class: 've-css-note', key: 'bar-skipBulkPreview-note', style: 'margin:-4px 0 8px' }, 'When this is on, commands like all li => data-anim="fade-up" apply immediately after matching safely. Keep it off when testing risky selectors.'),
        settingToggleRow('bar-undocked', 'Undock Mimam\'s Bar and remember position', !!barSettings.undocked, val => updateBarSetting('undocked', val)),
        settingToggleRow('bar-hideStructure', 'Hide Bricks structure panel', !!barSettings.hideStructure, val => updateBarSetting('hideStructure', val)),
        settingToggleRow('bar-hideElements', 'Hide Bricks elements panel', !!barSettings.hideElements, val => updateBarSetting('hideElements', val)),
        settingToggleRow('bar-floatElements', 'Float Bricks elements panel', !!barSettings.floatElements, val => updateBarSetting('floatElements', val)),
        settingToggleRow('bar-floatStructure', 'Float Bricks structure panel', !!barSettings.floatStructure, val => updateBarSetting('floatStructure', val)),
        h('div', { class: 've-opt', key: 'bar-floatOpacity' },
          h('span', null, 'Floating panels opacity'),
          h(SelectMenu, { value: barSettings.floatOpacity || '0.78', onChange: v => updateBarSetting('floatOpacity', v), options: [
            { value: '1', label: '100%' },
            { value: '0.9', label: '90%' },
            { value: '0.78', label: '78%' },
            { value: '0.65', label: '65%' },
            { value: '0.5', label: '50%' }
          ] })
        ),
        h('div', { class: 've-opt', key: 'bar-shortcut' },
          h('span', null, 'Shortcut'),
          h(SelectMenu, { value: barSettings.shortcut || 'alt-q', onChange: v => updateBarSetting('shortcut', v), options: [
            { value: 'alt-q', label: 'Alt + Q' },
            { value: 'ctrl-k', label: 'Ctrl + K' },
            { value: 'ctrl-alt-a', label: 'Ctrl + Alt + A' }
          ] })
        ),
        h('div', { class: 've-opt', key: 'bar-deselectShortcut' },
          h('span', null, 'Deselect Shortcut'),
          h(SelectMenu, { value: barSettings.deselectShortcut || 'escape', onChange: v => updateBarSetting('deselectShortcut', v), options: [
            { value: 'escape', label: 'Escape' },
            { value: 'shift-d', label: 'Shift + D' },
            { value: 'alt-d', label: 'Alt + D' },
            { value: 'none', label: 'None' }
          ] })
        ),
        settingToggleRow('bar-showTopBarIcon', 'Show Mimam\'s Bar in Top Toolbar', barSettings.showTopBarIcon !== false, val => updateBarSetting('showTopBarIcon', val)),
        settingToggleRow('bar-showVengineTopBarIcon', 'Show Vengine in Top Toolbar', barSettings.showVengineTopBarIcon !== false, val => updateBarSetting('showVengineTopBarIcon', val)),
        h('div', { class: 've-opt', key: 'bar-density' },
          h('span', null, 'Density'),
          h(SelectMenu, { value: barSettings.density || 'compact', onChange: v => updateBarSetting('density', v), options: [
            { value: 'compact', label: 'Compact' },
            { value: 'comfortable', label: 'Comfortable' }
          ] })
        )
      ] : activeTab === 'studio' ? [
        // CSS Studio settings
        h('div', { class: 've-css-note', style: 'margin-bottom:8px' }, 'Live auto-format is off so typing never moves your cursor unexpectedly.'),
        settingToggleRow('studio-scss', 'SCSS mode foundation', cssScss, setScss),
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:8px;margin:' + (cssSourceOrder.length ? '10px 0 6px' : '0'), key: 'studio-sug-hdr' },
          h('div', { style: 'font-size:11px;color:#888;text-transform:uppercase;font-weight:700' }, 'Suggestion Priority'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: refreshIndex, disabled: cssIndexBusy }, cssIndexBusy ? 'Indexing...' : 'Refresh Index')),
        cssIndexMsg && h('div', { class: 've-css-note', style: 'margin-bottom:6px', key: 'studio-idx-msg' }, cssIndexMsg),
        h('div', { class: 've-source-list', key: 'studio-src-list' },
          normalizeSourceOrder(cssSourceOrder, cssRemoteSuggestions.sources || []).map(x => h('div', {
            class: 've-source-pill' + (cssDragSource === x ? ' dragging' : '') + (cssDropHint?.target === x ? ' drop-' + cssDropHint.pos : ''),
            key: x,
            draggable: true,
            onDragStart: e => { setCssDragSource(x); e.dataTransfer.effectAllowed = 'move'; },
            onDragOver: e => { e.preventDefault(); const r = e.currentTarget.getBoundingClientRect(); setCssDropHint({ target: x, pos: e.clientY < r.top + r.height/2 ? 'before' : 'after' }); e.dataTransfer.dropEffect = 'move'; },
            onDrop: e => { e.preventDefault(); dropSource(); },
            onDragEnd: () => { setCssDragSource(''); setCssDropHint(null); }
          },
            h('span', { style: 'display:flex;align-items:center;gap:8px' }, h('span', { class: 've-source-grip' }, ph('dots-six-vertical')), h('span', null, x)),
            h('span', { style: 'display:flex;align-items:center;gap:6px' },
              h('span', { class: 've-source-meta' }, cssDisabledSources.includes(x) ? 'Off' : (cssSourceMeta[x] || 'Source')),
              h('button', { type: 'button', class: 've-source-toggle ' + (!cssDisabledSources.includes(x) ? 'on' : ''), title: cssDisabledSources.includes(x) ? 'Enable source' : 'Disable source', onMouseDown: e => e.preventDefault(), onClick: e => { e.preventDefault(); toggleSource(x); } }, ph(cssDisabledSources.includes(x) ? 'eye-slash' : 'eye')))))
        ),
        h('div', { class: 've-css-note', style: 'margin-top:10px', key: 'studio-src-note' }, 'Suggestions use this order when sources overlap. MV variables, detected builder classes, IDs, and supported plugin sources are scanned from WordPress.')
      ] : activeTab === 'modules' ? [
        // Modules settings tab
        h('div', { style: 'font-size:11px;color:#888;margin-bottom:14px;line-height:1.5', key: 'mod-intro' }, 'Choose where each module is active. Turn a module off in Admin without disabling it in Builder, or vice versa. Older global module settings are still respected.'),
        
        moduleSurfaceCard('variables', 'Variable Panel', 'Core variables grid, color palette manager, fluid scale builder, and Figma sync workspace.'),
        moduleSurfaceCard('css_studio', 'CSS Studio', 'Standalone SCSS/CSS workspace with auto-complete and live page injections.'),
        moduleSurfaceCard('mimams_bar', "Mimam's Bar", 'Power-user command line interface for lightning-fast attribute and design operations.'),
        moduleSurfaceCard('content_studio', 'Content Studio', 'Central hub for managing pages, posts, and CPTs with status toggles.'),
        moduleSurfaceCard('media_studio', 'Media Studio', 'Premium glassmorphic media library replacement with collections and alt-text helpers.'),
        moduleSurfaceCard('plugin_studio', 'Plugin Studio', 'Manage activation, updates, auto-updates, and inactive plugin cleanup.')
      ] : activeTab === 'media' ? [
        h('div', { class: 've-css-note', style: 'margin-bottom:8px' }, 'Runtime behavior and folder-plugin integration for Media Studio. Enable or disable the module itself from the Modules tab.'),
              h('div', { class: 've-media-settings-card', key: 'media-runtime-options' },
                h('div', { class: 've-media-settings-head' },
                  h('div', null,
                    h('div', { class: 've-media-settings-title' }, ph('sliders-horizontal'), 'Media Studio Runtime'),
                    h('div', { class: 've-media-settings-desc' }, 'Control how Media Studio opens and how it stays in sync with detected folder plugins.')
                  )
                ),
                h('div', { class: 've-media-settings-actions' },
                  h('div', { class: 've-media-settings-action-row ve-media-settings-paused' },
                    h('span', null, 'Replace native WordPress Media Library page'),
                    h('span', { class: 've-badge muted', title: 'Paused until this flow is rebuilt safely' }, 'Paused')
                  ),
                  h('div', { class: 've-media-settings-desc', style: 'margin:-4px 0 2px' }, 'Paused for now. Media → Library stays on the default WordPress Media Library while we rebuild this safely later.'),
                  folderData.folders && folderData.folders.length > 0 && h('div', { class: 've-media-settings-action-row' },
                    h('span', null, 'Auto-sync external folders when Media Studio opens'),
                    h(ToggleControl, {
                      checked: !!s.media_auto_sync_external_folders,
                      label: 'Auto-sync external folders when Media Studio opens',
                      onChange: val => updateSetting('media_auto_sync_external_folders', val, 've-media-auto-sync-external-folders-changed')
                    })
                  )
                )
              ),
              !isDeactivated('media_studio') && folderData.folders && folderData.folders.length > 0 && h('div', { class: 've-media-settings-card' },
                h('div', { class: 've-media-settings-head' },
                  h('div', null,
                    h('div', { class: 've-media-settings-title' }, ph('arrows-merge'), 'Folder-Plugin Integration'),
                    h('div', { class: 've-media-settings-desc' }, `Detected ${folderData.folders.length} folder(s). Tree state is shared with Media Studio.`)
                  )
                ),
                h('div', { class: 've-media-settings-tree ve-scroll-custom' },
                  settingsFolderRows.length === 0 ? h('div', { class: 've-media-settings-empty' }, 'No folder-plugin folders were detected.') :
                  settingsFolderRows.map(({ folder, label }) => {
                    if (settingsPathHidden(label)) return null;
                    const depth = label.split(' / ').length - 1;
                    const leaf = label.split(' / ').pop().trim();
                    const hasChildren = settingsFolderRows.some(row => row.label !== label && row.label.startsWith(label + ' / '));
                    const guides = [];
                    for (let i = 0; i < depth; i++) guides.push(h('div', { class: 've-tree-guide', key: i }));
                    const count = settingsFolderCount(folder.id);
                    return h('div', { class: 've-media-settings-row', key: String(folder.id), title: label },
                      h('div', { class: 've-media-tree-guides' }, guides),
                      h('div', { class: 've-media-settings-name' },
                        hasChildren ? h('button', {
                          type: 'button',
                          class: 've-tree-toggle',
                          title: 'Toggle children',
                          onClick: e => {
                            e.preventDefault();
                            e.stopPropagation();
                            toggleSettingsFolderPath(label);
                          }
                        }, ph(settingsCollapsedPaths[label] ? 'caret-right' : 'caret-down')) : h('span', { class: 've-tree-spacer' }),
                        ph('folder', { style: 'color:#baf400;opacity:.8;flex-shrink:0' }),
                        h('span', null, leaf)
                      ),
                      h('span', { class: 've-studio-badge' }, count)
                    );
                  })
                ),
                h('div', { class: 've-media-settings-actions' },
                  h('div', { class: 've-media-settings-action-row' },
                    h('span', null, 'Hide external folders in Media Studio sidebar'),
                    h(ToggleControl, {
                      checked: hideFolders,
                      label: 'Hide external folders in Media Studio sidebar',
                      onChange: val => {
                        setHideFoldersState(val);
                        localStorage.setItem('ve_media_hide_folders', val ? 'true' : 'false');
                        window.dispatchEvent(new CustomEvent('ve-media-hide-folders-changed', { detail: val }));
                      }
                    })
                  ),
                  h('button', {
                    type: 'button',
                    class: 've-btn ve-btn-s',
                    style: 'background:rgba(186,244,0,0.1);color:#baf400;border:1px solid rgba(186,244,0,0.25);font-size:10px;padding:0 10px;font-weight:700;align-self:flex-start;min-height:30px',
                    onClick: () => setShowMigrateConfirm(true)
                  }, ph('copy-simple'), 'Migrate folders to MV Collections')
                ),
                
                showMigrateConfirm && h('div', { class: 've-modal' },
                  h('div', {
                    class: 've-modal-box ve-migration-modal',
                    style: 'width: 420px; max-width: 90vw; background: #161616; border: 1px solid rgba(255,255,255,0.08); border-radius: 8px; box-shadow: 0 10px 30px rgba(0,0,0,0.5); display: flex; flex-direction: column; overflow: hidden;'
                  },
                    h('div', {
                      class: 've-modal-title',
                      style: 'padding: 16px; border-bottom: 1px solid rgba(255,255,255,0.06); margin: 0; font-size: 14px; font-weight: 700; color: #fff; display: flex; align-items: center; gap: 8px'
                    },
                      ph('arrows-merge', { style: 'color: #baf400; font-size: 18px' }),
                      'Migrate Folders'
                    ),
                    h('div', {
                      class: 've-modal-body',
                      style: 'padding: 16px; font-size: 12px; color: #aaa; line-height: 1.55; display: flex; flex-direction: column; gap: 12px;'
                    },
                      h('p', { style: 'margin: 0; color: #ffc86b; font-weight: 600' }, 'Warning: This action will duplicate your folder structures.'),
                      h('p', { style: 'margin: 0' }, 'This will copy all detected external folder structures and their media assignments into Mimam\'s Var local collections. The original folders in your external folder plugin will not be modified or deleted.')
                    ),
                    h('div', {
                      class: 've-modal-actions',
                      style: 'padding: 12px 16px; border-top: 1px solid rgba(255,255,255,0.06); display: flex; justify-content: flex-end; gap: 8px; margin: 0; background: rgba(0,0,0,0.1)'
                    },
                      h('button', {
                        type: 'button',
                        class: 've-btn ve-btn-g ve-btn-s',
                        onClick: () => setShowMigrateConfirm(false)
                      }, 'Cancel'),
                      h('button', {
                        type: 'button',
                        class: 've-btn ve-btn-s',
                        style: 'background: #baf400; color: #111; font-weight: 600',
                        onClick: () => {
                          const nextMap = { ...localCollections };
                          let migratedCount = 0;
                          const buildPath = (folder) => {
                            const parts = [folder.name];
                            let cur = folder;
                            while (cur && cur.parent && cur.parent !== '0') {
                              const parent = (folderData.folders || []).find(f => String(f.id) === String(cur.parent));
                              if (parent) {
                                parts.unshift(parent.name);
                                cur = parent;
                              } else break;
                            }
                            return parts.join(' / ');
                          };
                          const makeKey = label => (label || '').trim().toLowerCase().replace(/\s*\/\s*/g, '/').replace(/[^a-z0-9/]+/g, '_').replace(/^_+|_+$/g, '');
                          const folderMap = folderData.map || {};
                          (folderData.folders || []).forEach(folder => {
                            const pathLabel = buildPath(folder);
                            const key = makeKey(pathLabel);
                            if (!key) return;
                            const newIds = Object.keys(folderMap).filter(id => (folderMap[id] || []).map(String).includes(String(folder.id))).map(id => parseInt(id, 10));
                            const existing = nextMap[key] || { ids: [], icon: 'folder', label: pathLabel };
                            const nextIds = [...new Set([...(existing.ids || []), ...newIds])];
                            nextMap[key] = {
                              ids: nextIds,
                              icon: existing.icon || 'folder',
                              label: pathLabel
                            };
                            migratedCount++;
                          });
                          localStorage.setItem('ve_media_collections', JSON.stringify(nextMap));
                          persistUserPreference('ve_media_collections', JSON.stringify(nextMap));
                          setLocalCollections(nextMap);
                          setShowMigrateConfirm(false);
                          setMigrationStatus(`Successfully migrated ${migratedCount} folder(s)!`);
                          window.dispatchEvent(new CustomEvent('ve-media-collections-migrated'));
                          window.dispatchEvent(new CustomEvent('ve-media-collections-changed', { detail: nextMap }));
                          window.dispatchEvent(new CustomEvent('ve-toast-request', { detail: `Successfully migrated ${migratedCount} folder(s) to MV collections!` }));
                          setTimeout(() => setMigrationStatus(''), 4000);
                        }
                      }, 'Confirm Migration')
                    )
                  )
                ),
                migrationStatus && h('div', { style: 'font-size:10px;color:#baf400;font-weight:600;margin-top:4px' }, migrationStatus)
              )
      ] : []
    )
    ),
    h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:12px;padding:12px 14px', class: 've-settings-footer' },
      h('span', { class: 've-settings-version' }, "Mimam's Var v" + (CFG.version || '')),
      h('button', { class: 've-btn', onClick: onClose }, 'Close')
    )
  );
}

/* ── External source migration ─────────── */
function MigrationSub({onClose,exiting,onDone}){
  const[sources,sSources]=useState([]);
  const[source,sSource]=useState('all');
  const[previewBusy,setPreviewBusy]=useState(false);
  const[applyBusy,setApplyBusy]=useState(false);
  const[diff,sDiff]=useState([]);
  const[summary,sSummary]=useState(null);
  const[count,sCount]=useState(0);
  const[counts,setCounts]=useState(null);
  const[previewRows,setPreviewRows]=useState([]);
  const[err,sErr]=useState('');
  const[warnings,sWarnings]=useState([]);
  useEffect(()=>{api.g('migration/sources').then(d=>{if(Array.isArray(d))sSources(d);});},[]);
  const chooseSource=value=>{sSource(value);sDiff([]);sSummary(null);setCounts(null);setPreviewRows([]);sWarnings([]);sErr('');};
  const acceptPreview=r=>{
    if(r?.code){sErr(r.message||'Migration preview failed');return false;}
    sDiff(r.changes||[]);sSummary(r.summary||{});sCount(r.variable_count||0);setCounts(r.migration_counts||null);setPreviewRows(r.migration_payload||r.variables||[]);sWarnings(r.warnings||[]);
    return true;
  };
  const preview=async()=>{
    setPreviewBusy(true);sErr('');sWarnings([]);
    try{
      const r=await api.p('migration/preview',{source});
      acceptPreview(r);
    }finally{setPreviewBusy(false);}
  };
  const familyGroups=useMemo(()=>{
    const roots=new Map(),children=new Map();
    previewRows.forEach(row=>{
      const name=String(row?.name||'');
      if(!name)return;
      if(String(row?.type||'')==='generated'&&String(row?.generator_type||'')==='imported'&&row?.source_name){
        const source=String(row.source_name);
        if(!children.has(source))children.set(source,[]);
        children.get(source).push(row);
      }else roots.set(name,row);
    });
    return Array.from(children.entries()).map(([rootName,items])=>{
      const root=roots.get(rootName);
      if(!root||!root.family_synthetic)return null;
      const sorted=items.slice().sort((a,b)=>String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true}));
      const selected=String(root.family_base_source||'')||String((sorted.find(item=>String(item.value||'')===String(root.value||''))||sorted[0]||{}).name||'');
      return{root,children:sorted,selected};
    }).filter(Boolean);
  },[previewRows]);
  const chooseFamilyBase=async(group,childName)=>{
    const child=group.children.find(item=>String(item.name||'')===String(childName||''));
    if(!child)return;
    const next=previewRows.map(row=>String(row?.name||'')===String(group.root.name||'')?{...row,value:child.value,family_base_source:child.name}:row);
    setPreviewBusy(true);sErr('');
    try{
      const r=await api.p('migration/preview',{source,variables:next});
      acceptPreview(r);
    }finally{setPreviewBusy(false);}
  };
  const apply=async()=>{
    if(!(counts?.apply||diff.filter(c=>c.action!=='delete').length))return;
    setApplyBusy(true);sErr('');
    try{
      const r=await api.p('migration/apply',{source,variables:previewRows});
      if(r?.code||r?.errors?.length){
        const details=(r?.verification_issues||r?.errors||[]).slice(0,8);
        sErr((r?.message||'Migration failed')+(details.length?' '+details.join(' '):''));
        return;
      }
      if(!(Number(r?.applied)>0)){sErr('No variables were written. Run Preview Migration again before applying.');return;}
      if(onDone)await onDone(r);
    }catch(error){
      sErr(error?.message||'WordPress did not finish the migration. Nothing has been confirmed as imported.');
    }finally{setApplyBusy(false);}
  };
  const opts=[{value:'all',label:'All available sources'},...sources.map(x=>({value:x.id,label:x.name+(x.available?'':' (not detected)')}))];
  const changedCount = summary ? ((summary.updated||0) + (summary.type_changed||0) + (summary.relationship_changed||0) + (summary.repaired||0)) : 0;
  const migrationCounts=counts||{detected:count,new:summary?.added||0,changed:changedCount,skipped:warnings.length,unchanged:0,apply:diff.filter(c=>c.action!=='delete').length};
  const applicableDiff=diff.filter(c=>c.action!=='delete');
  const actionClass=action=>action==='add'?'add':action==='update'?'update':'other';
  const actionLabel=action=>action==='relationship_change'?'LINK':action==='repair_generated'?'FIX':String(action||'').toUpperCase().slice(0,4);
  return h(Sub,{title:'Migrate Variables',onClose,exiting,bodyClass:'ve-migrate-sub-body'},
    h('div',{class:'ve-migrate-shell'},
      h('div',{class:'ve-migrate-scroll'},
       h('div',{class:'ve-migrate-callout'},
        h('div',{class:'ve-migrate-desc'},"Preview variables from Core Framework, Advanced Themer/Bricks, and ACSS before adding anything to Mimam's Var. Deletions are never applied. Reviewed colors enter the reusable source-named Color Palette, while imported families keep every original child value.")),
      h('div',{class:'ve-migrate-field'},
        h('div',{class:'ve-migrate-field-label'},'Source'),
        h(SelectMenu,{value:source,onChange:chooseSource,options:opts})),
      sources.length>0&&h('div',{class:'ve-migrate-sources'},sources.map(x=>h('div',{key:x.id,class:'ve-migrate-card'},
        h('div',{class:'ve-migrate-card-copy'},
          h('div',{class:'ve-migrate-card-title'},x.name),
          h('div',{class:'ve-migrate-card-desc'},x.description)),
        h('span',{class:'ve-migrate-badge '+(x.available?'ok':'muted')},x.available?'Detected':'Not found')))),
      familyGroups.length>0&&h('div',{class:'ve-migrate-families'},
        h('div',{class:'ve-migrate-families-title'},'Imported family base values'),
        h('div',{class:'ve-migrate-families-help'},'The clean root has no “base” suffix. The 500 step is selected automatically when available; choose another child here if it should supply the root value. Every child token and imported value remains unchanged.'),
        h('div',{class:'ve-migrate-family-list'},familyGroups.map(group=>h('div',{key:group.root.name,class:'ve-migrate-family-row'},
          h('div',{class:'ve-migrate-family-name'},publicTokenLabel(group.root.name),h('span',{class:'ve-migrate-family-meta'},group.children.length+' imported children')),
          h(SelectMenu,{
            value:group.selected,
            onChange:value=>chooseFamilyBase(group,value),
            disabled:previewBusy||applyBusy,
            options:group.children.map(child=>({value:child.name,label:publicTokenLabel(child.name)}))
          }))))),
      warnings.length>0&&h('div',{class:'ve-migrate-result warning'},
        h('div',null,
          h('div',{class:'ve-migrate-warnings-title'},migrationCounts.skipped+' item'+(migrationCounts.skipped===1?'':'s')+' skipped'),
          h('div',{class:'ve-migrate-warning-list'},
            warnings.slice(0,4).map((warning,index)=>h('div',{key:index},warning)),
            warnings.length>4&&h('div',{style:'font-weight:750;color:#f59e0b'},'+'+(warnings.length-4)+' more')))),
      applicableDiff.length>0&&h('div',{class:'ve-migrate-diff-list'},applicableDiff.slice(0,60).map((c,i)=>h('div',{key:i,class:'ve-migrate-diff-row'},
        h('span',{class:'ve-migrate-diff-action '+actionClass(c.action)},actionLabel(c.action)),
        h('span',{style:'flex:1;min-width:0;overflow-wrap:anywhere;font-family:"SF Mono","Fira Code",monospace;color:#ddd'},c.name)))),
      err&&h('div',{class:'ve-migrate-result warning'},
        h('div',null,h('div',{class:'ve-migrate-warnings-title'},'Migration could not continue'),h('div',{class:'ve-migrate-warning-list'},err)))),
      h('div',{class:'ve-migrate-sticky'},
        h('div',{class:'ve-migrate-actions'},
          h('button',{class:'ve-btn',onClick:preview,disabled:previewBusy||applyBusy},previewBusy?'Scanning...':'Preview Migration'),
          summary&&h('button',{class:'ve-btn ve-btn-g',onClick:apply,disabled:previewBusy||applyBusy||migrationCounts.apply<1},applyBusy?'Applying...':(migrationCounts.apply>0?'Apply '+migrationCounts.apply:'No changes to apply'))),
        summary&&h('div',{class:'ve-migrate-result success'},
          h('div',null,
            h('div',{class:'ve-migrate-summary-title'},migrationCounts.detected+' variables detected'),
            h('div',{class:'ve-migrate-summary-details'},
              h('span',{class:'ve-migrate-count-ready'},migrationCounts.apply+' changes ready'),
              ' · '+migrationCounts.new+' new · '+migrationCounts.changed+' changed · ',
              h('span',{class:'ve-migrate-count-skipped'},migrationCounts.skipped+' skipped'),
              ' · '+migrationCounts.unchanged+' unchanged'))))));
}

function usageTokenCount(content,token){
  const text=String(content||'');
  if(!text||!token)return 0;
  const escaped=String(token).replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
  const matches=text.match(new RegExp('(^|[^A-Za-z0-9_-])'+escaped+'(?![A-Za-z0-9_-])','g'));
  return matches?matches.length:0;
}
function scanClientVariableUsages(variables){
  const list=(variables||[]).filter(Boolean);
  const result={};
  list.forEach(variable=>{result[String(variable.id)]={css_recipes:[],bricks:[]};});
  const recipes=loadUserCssRecipes();
  const adapter=window.MimamsBarBricksAdapter;
  let elements=[];
  if(adapter&&typeof adapter.getAllElements==='function'){
    try{elements=adapter.getAllElements({fresh:false})||[];}catch(e){elements=[];}
  }
  list.forEach(variable=>{
    const key=String(variable.id);
    const token=cssTokenName(variable.name);
    recipes.forEach(recipe=>{
      const matches=usageTokenCount(recipe.css,token);
      if(matches)result[key].css_recipes.push({type:'css_recipe',id:String(recipe.code||''),label:String(recipe.name||recipe.code||'CSS Recipe'),name:String(recipe.name||recipe.code||'CSS Recipe'),matches});
    });
    elements.forEach(element=>{
      let raw='';
      try{raw=JSON.stringify(element?.settings||{});}catch(e){raw='';}
      const matches=usageTokenCount(raw,token);
      if(!matches)return;
      let label=String(element?.label||element?.name||element?.id||'Bricks element');
      try{if(adapter&&typeof adapter.getElementFullLabel==='function')label=adapter.getElementFullLabel(element)||label;}catch(e){}
      result[key].bricks.push({type:'bricks',id:String(element?.id||''),label,name:label,matches,element});
    });
  });
  return result;
}
function mergeVariableUsage(server,client){
  const groups={...(server?.groups||{})};
  groups.css_recipes=client?.css_recipes||[];
  groups.bricks=client?.bricks||[];
  let total=0;
  Object.values(groups).forEach(items=>(items||[]).forEach(item=>{total+=Math.max(1,Number(item.matches||1));}));
  return{...(server||{}),groups,total,unused:total===0};
}
const USAGE_GROUPS=[
  ['aliases','Aliases','link'],
  ['themes','Themes','palette'],
  ['css_studio','CSS Studio','code'],
  ['css_recipes','CSS Recipes','brackets-curly'],
  ['bricks','Current Bricks document','cube'],
  ['bricks_saved','Saved Bricks content','floppy-disk'],
  ['wordpress','Other WordPress storage','database']
];
function VariableUsagePanel({variable,onNavigate,title='Usage & impact',compact=false,onLoaded}){
  const[report,sReport]=useState(null);
  const[loading,sLoading]=useState(true);
  const[error,sError]=useState('');
  const loadUsage=useCallback(async()=>{
    if(!variable)return;
    sLoading(true);sError('');
    try{
      const server=await api.g('variables/'+variable.id+'/usage');
      if(server?.code)throw new Error(server.message||'Usage scan failed');
      const client=scanClientVariableUsages([variable])[String(variable.id)]||{};
      const merged=mergeVariableUsage(server,client);
      sReport(merged);onLoaded&&onLoaded(merged);
    }catch(e){sError(e.message||'Usage scan failed');}
    finally{sLoading(false);}
  },[variable?.id,variable?.name]);
  useEffect(()=>{sReport(null);loadUsage();},[loadUsage]);
  const groups=report?.groups||{};
  return h('div',{class:'ve-usage'+(compact?' compact':'')},
    h('div',{class:'ve-usage-head'},
      h('div',{class:'ve-usage-title'},ph('git-branch'),title),
      report&&h('span',{class:'ve-usage-status'+(report.unused?' unused':'')},report.unused?'Unused':report.total+' ref'+(report.total===1?'':'s'))),
    loading?h('div',{class:'ve-usage-loading'},'Checking aliases, Themes, CSS Studio and Bricks…')
    :error?h('div',{class:'ve-usage-empty'},error,h('button',{class:'ve-btn ve-btn-s',style:'margin-left:7px',onClick:loadUsage},'Retry'))
    :h('div',{class:'ve-usage-body'},
      report?.unused&&h('div',{class:'ve-usage-empty'},'No consumers were found. This variable is currently safe to review as unused.'),
      USAGE_GROUPS.map(([key,label,icon])=>{
        const items=groups[key]||[];
        if(!items.length)return null;
        return h('div',{class:'ve-usage-group',key},
          h('div',{class:'ve-usage-group-title'},label+' · '+items.length),
          items.map((item,index)=>{
            const clickable=!!onNavigate&&['variable','theme','css_studio','css_recipe','bricks'].includes(item.type);
            return h('button',{type:'button',class:'ve-usage-item'+(clickable?' clickable':''),key:String(item.id)+'-'+index,disabled:!clickable,onClick:()=>clickable&&onNavigate(item,variable)},
              ph(icon),h('span',{class:'ve-usage-item-main'},h('span',{class:'ve-usage-item-label'},item.label||item.name),h('span',{class:'ve-usage-item-meta'},Number(item.matches||1)+' reference'+(Number(item.matches||1)===1?'':'s'))));
          }));
      })
    ));
}
function VariableImpactStack({variables,onNavigate}){
  const list=(variables||[]).filter(Boolean).slice(0,12);
  if(!list.length)return null;
  return h('div',{class:'ve-impact-stack'},
    h('div',{class:'ve-impact-summary'},ph('warning-circle'),'Consumers of the affected variables are shown before Apply. Token names and values remain unchanged.'),
    list.map(variable=>h(VariableUsagePanel,{key:variable.id,variable,onNavigate,title:publicTokenLabel(variable.name),compact:true})),
    (variables||[]).length>list.length&&h('div',{class:'ve-family-note'},'Plus '+((variables||[]).length-list.length)+' more affected variables.'));
}

function cssLineCount(text){const s=String(text||'');return Math.max(1,(s.match(/\n/g)||[]).length+1);}
const DOM_SUGGEST_CACHE={class:{at:0,items:[]},id:{at:0,items:[]},var:{at:0,items:[]}};
const CSSOM_SUGGEST_CACHE={class:{at:0,items:[]},id:{at:0,items:[]},var:{at:0,items:[]}};
function domSuggestionDocuments(){
  const docs=[];const seen=[];
  const add=doc=>{if(!doc||seen.includes(doc))return;seen.push(doc);docs.push(doc);};
  add(document);
  try{
    Array.from(window.frames||[]).forEach(frame=>{try{add(frame.document);}catch(e){}});
  }catch(e){}
  try{
    document.querySelectorAll('iframe').forEach(frame=>{try{add(frame.contentDocument||frame.contentWindow?.document);}catch(e){}});
  }catch(e){}
  return docs.slice(0,8);
}
function domClassName(el){
  const raw=el?.className;
  if(!raw)return'';
  if(typeof raw==='string')return raw;
  if(typeof raw.baseVal==='string')return raw.baseVal;
  return String(raw||'');
}
function collectDomSuggestions(kind){
  const now=Date.now();
  const cached=DOM_SUGGEST_CACHE[kind];
  if(cached&&now-cached.at<5000)return cached.items;
  const found={};
  let count=0;
  domSuggestionDocuments().forEach(doc=>{
    if(count>=3000)return;
    try{
      doc.querySelectorAll(kind==='class'?'[class]':'[id]').forEach(el=>{
        if(count>=3000)return;
        if(kind==='class')domClassName(el).split(/\s+/).forEach(c=>{if(c&&!c.startsWith('ve-')){found['.'+c]=true;count++;}});
        else if(el.id&&!String(el.id).startsWith('ve-')){found['#'+el.id]=true;count++;}
      });
    }catch(e){}
  });
  const items=Object.keys(found).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).slice(0,2000);
  DOM_SUGGEST_CACHE[kind]={at:now,items};
  return items;
}
function cssomExtractSelector(selector,found,kind){
  if(!selector)return 0;
  let count=0;
  const text=String(selector);
  if(kind==='class'){
    const re=/(?<![A-Za-z0-9_-])\.((?:\\.|[A-Za-z_][A-Za-z0-9_-]*|[\\/:\\].-]){1,120})/g;
    let m;while((m=re.exec(text))){const name='.'+m[1].replace(/\\/g,'');if(!name.startsWith('.ve-')){found[name]=true;count++;}}
  }else if(kind==='id'){
    const re=/(?<![A-Za-z0-9_-])#([A-Za-z_][A-Za-z0-9_-]{0,119})/g;
    let m;while((m=re.exec(text))){const name='#'+m[1];if(!name.startsWith('#ve-')){found[name]=true;count++;}}
  }
  return count;
}
function cssomExtractVars(text,found){
  let count=0;const s=String(text||'');
  let m;const add=name=>{name=String(name||'').trim();if(!name||name.indexOf('--ve-')===0)return;found[name]=true;count++;};
  const decl=/--([A-Za-z][A-Za-z0-9_-]*)\s*:/g;while((m=decl.exec(s)))add('--'+m[1]);
  const usage=/var\(\s*(--[A-Za-z][A-Za-z0-9_-]*)/g;while((m=usage.exec(s)))add(m[1]);
  return count;
}
function collectDomVariableSuggestions(){
  const now=Date.now();
  const cached=DOM_SUGGEST_CACHE.var;
  if(cached&&now-cached.at<8000)return cached.items;
  const found={};let count=0;
  const scanText=text=>{if(count>=2200)return;count+=cssomExtractVars(text,found);};
  const scanComputed=(win,el)=>{
    if(!win||!el||count>=2200)return;
    try{
      const st=win.getComputedStyle&&win.getComputedStyle(el);
      if(!st)return;
      const len=Math.min(st.length||0,900);
      for(let i=0;i<len&&count<2200;i++){
        const name=st.item?st.item(i):st[i];
        if(name&&String(name).indexOf('--')===0&&String(name).indexOf('--ve-')!==0){found[String(name)]=true;count++;}
      }
    }catch(e){}
  };
  domSuggestionDocuments().forEach(doc=>{
    if(count>=2200)return;
    try{
      scanText(doc.documentElement?.getAttribute?.('style')||'');
      scanText(doc.body?.getAttribute?.('style')||'');
      scanComputed(doc.defaultView||window,doc.documentElement);
      scanComputed(doc.defaultView||window,doc.body);
      const els=doc.querySelectorAll('[style]');
      for(let i=0;i<els.length&&i<1600&&count<2200;i++){
        scanText(els[i].getAttribute('style')||'');
      }
    }catch(e){}
  });
  const items=Object.keys(found).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).slice(0,1500);
  DOM_SUGGEST_CACHE.var={at:now,items};
  return items;
}
function cssomWalkRules(rules,found,kind,state){
  if(!rules||state.count>=2500)return;
  try{
    Array.from(rules).forEach(rule=>{
      if(state.count>=2500)return;
      try{
        if(kind==='var')state.count+=cssomExtractVars(rule.cssText||'',found);
        else if(rule.selectorText)state.count+=cssomExtractSelector(rule.selectorText,found,kind);
        if(rule.cssRules)cssomWalkRules(rule.cssRules,found,kind,state);
      }catch(e){}
    });
  }catch(e){}
}
function collectCssomSuggestions(kind){
  const now=Date.now();
  const cached=CSSOM_SUGGEST_CACHE[kind];
  if(cached&&now-cached.at<8000)return cached.items;
  const found={};const state={count:0};
  domSuggestionDocuments().forEach(doc=>{
    if(state.count>=2500)return;
    try{
      Array.from(doc.styleSheets||[]).forEach(sheet=>{
        if(state.count>=2500)return;
        try{cssomWalkRules(sheet.cssRules,found,kind,state);}catch(e){}
      });
    }catch(e){}
  });
  const items=Object.keys(found).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).slice(0,1500);
  CSSOM_SUGGEST_CACHE[kind]={at:now,items};
  return items;
}
function normalizeSourceOrder(saved,serverSources){
  const valid=[...new Set(serverSources&&serverSources.length?serverSources:["Mimam's Var"])];
  const incoming=Array.isArray(saved)?saved:[];
  const kept=incoming.filter(x=>valid.includes(x));
  return [...new Set([...kept,...valid])];
}
function cssValidation(text){
  const warnings=[];
  const s=String(text||'').slice(0,60000);
  const open=(s.match(/\{/g)||[]).length, close=(s.match(/\}/g)||[]).length;
  if(open!==close)warnings.push('Brace count is off: '+open+' opening, '+close+' closing.');
  const props=[...new Set(CSS_PROPS)];
  s.split('\n').slice(0,900).forEach((line,i)=>{
    const m=line.match(/^\s*([a-z-]+)\s*:/i);
    if(m&&!props.includes(m[1].toLowerCase())&&!m[1].startsWith('--'))warnings.push('Line '+(i+1)+': unknown property "'+m[1]+'".');
  });
  return warnings.slice(0,5);
}
function cssContext(text,pos){
  const before=String(text||'').slice(0,pos);
  const line=before.split('\n').pop()||'';
  const inValue=/:\s*[^;{}]*$/.test(line);
  let depth=0,quote='',comment=false;
  for(let i=0;i<before.length;i++){
    const c=before[i],n=before[i+1]||'';
    if(comment){if(c==='*'&&n==='/'){comment=false;i++;}continue;}
    if(quote){if(c==='\\'){i++;continue;}if(c===quote)quote='';continue;}
    if(c==='/'&&n==='*'){comment=true;i++;continue;}
    if(c==='"'||c==="'"){quote=c;continue;}
    if(c==='{')depth++;
    else if(c==='}')depth=Math.max(0,depth-1);
  }
  return{line,inValue,inBlock:depth>0};
}
function cssSuggestionMatch(before){
  const raw=String(before||'');
  const varMatch=raw.match(/var\(\s*(--[a-z0-9-]*)?$/i);
  if(varMatch)return{token:varMatch[1]||'--',kind:'var',replaceLength:varMatch[1]?varMatch[1].length:0,inVar:true};
  const pseudoMatch=raw.match(/(::?[a-z0-9_-]*)$/i);
  if(pseudoMatch)return{token:pseudoMatch[1],kind:'selector',replaceLength:pseudoMatch[1].length};
  const tokenMatch=raw.match(/(@[a-z0-9_-]*|--[a-z0-9-]*|\.[a-z0-9_:/[\].-]*|#[a-z0-9_-]*|[a-z-]{1,})$/i);
  if(!tokenMatch)return null;
  const token=tokenMatch[1];
  return{token,replaceLength:token.length,kind:token.startsWith('@')?'atrule':token.startsWith('--')?'var':token.startsWith('.')?'class':token.startsWith('#')?'id':'css',inVar:false};
}
function cssIndex(list){
  const out=[];const seen={};
  (list||[]).forEach(x=>{const label=String(x||'').trim();if(!label||seen[label])return;seen[label]=true;out.push({label,lower:label.toLowerCase()});});
  return out;
}
function cssLookup(index,query,limit){
  const q=String(query||'').toLowerCase();
  const res=[];
  if(!q){
    for(let i=0;i<index.length&&res.length<limit;i++)res.push(index[i].label);
    return res;
  }
  const bare=q.replace(/^(--|[.#])/,'');
  const add=label=>{if(res.length<limit&&!res.includes(label))res.push(label);};
  const itemBare=item=>item.lower.replace(/^(--|[.#])/,'');
  const segmentHit=(hay,needle)=>needle&&hay.split(/[-_.:/\s]+/).some(part=>part.indexOf(needle)===0);
  for(let i=0;i<index.length&&res.length<limit;i++)if(index[i].lower.indexOf(q)===0)add(index[i].label);
  if(bare!==q)for(let i=0;i<index.length&&res.length<limit;i++)if(itemBare(index[i]).indexOf(bare)===0)add(index[i].label);
  for(let i=0;i<index.length&&res.length<limit;i++)if(segmentHit(itemBare(index[i]),bare||q))add(index[i].label);
  for(let i=0;i<index.length&&res.length<limit;i++)if((index[i].lower.indexOf(q)>0||itemBare(index[i]).indexOf(bare)>0))add(index[i].label);
  return res;
}
function cssSuggestionPools(vars,remoteSuggestions){
  const orderVars=a=>{
    const priority=['--color','--space','--spacing','--typography','--font','--text','--heading','--radius','--size','--scale','--stroke','--shadow','--opacity','--motion'];
    const seen={};const arr=[];
    (a||[]).forEach(x=>{const label=String(x||'').trim();if(!label||seen[label])return;seen[label]=true;arr.push(label);});
    arr.sort((x,y)=>{
      const lx=x.toLowerCase(),ly=y.toLowerCase();
      const ix=priority.findIndex(p=>lx.startsWith(p)),iy=priority.findIndex(p=>ly.startsWith(p));
      return (ix<0?99:ix)-(iy<0?99:iy)||lx.length-ly.length||lx.localeCompare(ly,undefined,{numeric:true,sensitivity:'base'});
    });
    return cssIndex(arr);
  };
  return{
    vars:orderVars([...(remoteSuggestions?.variables||[]),...(vars||[]).map(v=>cssTokenName(v.name)).filter(Boolean),...collectCssomSuggestions('var'),...collectDomVariableSuggestions()]),
    classes:cssIndex([...(remoteSuggestions?.classes||[]),...collectDomSuggestions('class'),...collectCssomSuggestions('class')]),
    ids:cssIndex([...(remoteSuggestions?.ids||[]),...collectDomSuggestions('id'),...collectCssomSuggestions('id')]),
    selectors:cssIndex([...(remoteSuggestions?.selectors||[]),...CSS_SELECTOR_HINTS]),
    props:cssIndex(CSS_PROPS),
    values:cssIndex(CSS_VALUES)
  };
}
function cssSuggestions(text,pos,pools,disabledSources){
  const before=String(text||'').slice(0,pos);
  const m=cssSuggestionMatch(before);
  if(!m)return[];
  const q=m.token.toLowerCase();
  const ctx=cssContext(text,pos);
  const off=name=>(disabledSources||[]).includes(name);
  const cleanQ=(m.kind==='var'&&q==='--')||(m.kind==='class'&&q==='.')||(m.kind==='id'&&q==='#')||(m.kind==='atrule'&&q==='@')?'':q;
  if(m.kind==='atrule'){
    return cssLookup(pools?.selectors||[],cleanQ,CSS_HINT_LIMIT).filter(x=>String(x).startsWith('@'));
  }
  if(m.kind==='var'){
    if(off("Mimam's Var"))return[];
    return cssLookup(pools?.vars||[],cleanQ,CSS_HINT_LIMIT);
  }
  if(m.kind==='class')return off('CSS Classes')?[]:cssLookup(pools?.classes||[],cleanQ,CSS_HINT_LIMIT);
  if(m.kind==='id')return off('Element IDs')?[]:cssLookup(pools?.ids||[],cleanQ,CSS_HINT_LIMIT);
  if(m.kind==='selector')return cssLookup(pools?.selectors||[],cleanQ,CSS_HINT_LIMIT);
  if(ctx.inValue&&q.length>1){
    const varHits=off("Mimam's Var")?[]:cssLookup(pools?.vars||[],'--'+q.replace(/^--/,''),Math.floor(CSS_HINT_LIMIT*.6));
    const valueHits=cssLookup(pools?.values||[],q,Math.floor(CSS_HINT_LIMIT*.4));
    return [...varHits,...valueHits].slice(0,CSS_HINT_LIMIT);
  }
  if(ctx.inBlock)return cssLookup(pools?.props,q,CSS_HINT_LIMIT);
  return cssLookup(pools?.selectors,q,CSS_HINT_LIMIT);
}
function cssCommitSuggestion(item,match){
  const label=typeof item==='string'?item:String(item?.value||item?.label||'');
  if(!label)return{insert:'',cursor:null};
  if(match&&match.kind==='css'&&CSS_PROPS.includes(label))return{insert:label+':  ;',cursor:label.length+3};
  if(label.indexOf('--')===0&&(!match||!match.inVar)){
    const insert='var('+label+')';
    return{insert,cursor:insert.length};
  }
  return{insert:label,cursor:label.length};
}
function cssNextIndent(text,pos){
  const before=String(text||'').slice(0,pos);
  const line=before.split('\n').pop()||'';
  const base=(line.match(/^\s*/)||[''])[0];
  const trimmed=line.trim();
  if(!trimmed)return base;
  if(trimmed.endsWith('{'))return base+'  ';
  return trimmed.endsWith(';')?base:base+'  ';
}
function cssEnterInsert(text,pos){
  const s=String(text||'');
  const before=s.slice(0,pos);
  const after=s.slice(pos);
  const line=before.split('\n').pop()||'';
  const base=(line.match(/^\s*/)||[''])[0];
  const trimmed=line.trim();
  const ind=cssNextIndent(s,pos);
  if(trimmed.endsWith('{')&&after.trimStart().startsWith('}')){
    return{text:'\n'+ind+'\n'+base,cursor:1+ind.length};
  }
  return{text:'\n'+ind,cursor:1+ind.length};
}
function autoFormatCss(text){
  return String(text||'').replace(/;\s*/g,';\n  ').replace(/\{\s*/g,'{\n  ').replace(/\s*\}/g,'\n}\n').replace(/\n\s*\n\s*\n/g,'\n\n');
}
function cssEsc(s){return String(s||'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function cssHighlight(text){
  const s=String(text||'');
  const re=/\/\*[\s\S]*?\*\/|"(?:\\.|[^"\\])*"|'(?:\\.|[^'\\])*'|#[0-9a-f]{3,8}\b|--[a-z0-9-]+|\b[a-z-]+(?=\s*:)|\b\d+(?:\.\d+)?(?:px|rem|em|%|vw|vh)?\b|[{}:;(),]/gi;
  let out='',last=0,m;
  while((m=re.exec(s))){
    out+=cssEsc(s.slice(last,m.index));
    const t=m[0];let cls='tok-punc';
    if(t.startsWith('/*'))cls='tok-comment';
    else if(t[0]==='"'||t[0]==="'")cls='tok-string';
    else if(t[0]==='#')cls='tok-color';
    else if(t.startsWith('--'))cls='tok-var';
    else if(/^\d/.test(t))cls='tok-num';
    else if(/^[a-z-]+$/i.test(t))cls='tok-prop';
    out+='<span class="'+cls+'">'+cssEsc(t)+'</span>';
    last=re.lastIndex;
  }
  out+=cssEsc(s.slice(last));
  return out||' ';
}
function cssCaretPos(el){
  if(!el)return{left:46,top:34};
  const text=el.value.slice(0,el.selectionStart||0);
  const lines=text.split('\n');
  const line=lines.length-1;
  const col=(lines[lines.length-1]||'').length;
  const left=38+10+Math.min(col*6.7,Math.max(80,el.clientWidth-190));
  const top=10+(line*17.6)-el.scrollTop+24;
  const maxTop=Math.max(32,el.clientHeight-145);
  return{left,top:Math.max(12,Math.min(top,maxTop))};
}
function cmHintFactory(poolsRef,disabledRef){
  return function(cm){
    const cur=cm.getCursor();
    const pos=cm.indexFromPos(cur);
    const text=cm.getValue();
    const before=text.slice(0,pos);
    const m=cssSuggestionMatch(before);
    if(!m)return{list:[],from:cur,to:cur};
    const list=cssSuggestions(text,pos,poolsRef.current,disabledRef.current).map(item=>{
      const label=typeof item==='string'?item:item.label;
      return{
        text:label,
        displayText:label,
        hint:function(editor){
          const packed=cssCommitSuggestion(item,m);
          const from=editor.posFromIndex(pos-(m.replaceLength||0));
          const to=editor.posFromIndex(pos);
          editor.replaceRange(packed.insert,from,to,'complete');
          const nextIndex=pos-(m.replaceLength||0)+(packed.cursor==null?packed.insert.length:packed.cursor);
          editor.setCursor(editor.posFromIndex(nextIndex));
        }
      };
    });
    return{list,from:cm.posFromIndex(pos-(m.replaceLength||0)),to:cur};
  };
}
function cmShouldHint(editor,typed){
  const cur=editor.getCursor();
  const pos=editor.indexFromPos(cur);
  const before=editor.getValue().slice(0,pos);
  const m=cssSuggestionMatch(before);
  if(!m)return false;
  if(m.kind==='atrule')return m.token.length>=1;
  if(m.kind==='var')return m.token.length>=2;
  if(m.kind==='class'||m.kind==='id')return m.token.length>=1;
  return /^[a-z-]$/i.test(typed||'')&&m.token.length>=2;
}
function CssCodeMirrorEditor({value,onChange,vars,remoteSuggestions,scss,disabledSources}){
  const hostRef=useRef();
  const cmRef=useRef(null);
  const onChangeRef=useRef(onChange);
  const commitTimerRef=useRef(null);
  const poolsRef=useRef(cssSuggestionPools(vars,remoteSuggestions));
  const disabledRef=useRef(disabledSources||[]);
  useEffect(()=>{onChangeRef.current=onChange;},[onChange]);
  useEffect(()=>{poolsRef.current=cssSuggestionPools(vars,remoteSuggestions);},[vars,remoteSuggestions]);
  useEffect(()=>{disabledRef.current=disabledSources||[];},[disabledSources]);
  useEffect(()=>{
    if(!hostRef.current||!window.CodeMirror)return;
    const CM=window.CodeMirror;
    let hintContainer=document.getElementById('ve-cm-hints-root');
    if(!hintContainer){
      hintContainer=document.createElement('div');
      hintContainer.id='ve-cm-hints-root';
      hintContainer.className='ve-cm-hints-root';
      document.body.appendChild(hintContainer);
    }
    const cm=CM(hostRef.current,{
      value:value||'',
      mode:scss?'text/x-scss':'css',
      lineNumbers:true,
      lineWrapping:true,
      indentUnit:2,
      tabSize:2,
      theme:'default',
      autoCloseBrackets:false,
      hintOptions:{hint:cmHintFactory(poolsRef,disabledRef),completeSingle:false,container:hintContainer,extraKeys:{}},
      extraKeys:{
        'Ctrl-Space':editor=>editor.showHint({hint:cmHintFactory(poolsRef,disabledRef),completeSingle:false,container:hintContainer}),
        'Cmd-Space':editor=>editor.showHint({hint:cmHintFactory(poolsRef,disabledRef),completeSingle:false,container:hintContainer}),
        'Tab':editor=>{
          if(editor.state.completionActive){editor.state.completionActive.pick();return;}
          const cur=editor.getCursor();
          const before=editor.getRange({line:cur.line,ch:0},cur);
          const m=before.match(/(\d+(?:\.\d+)?(?:px|rem|em|%)?)\s*([-+*/])\s*(\d+(?:\.\d+)?(?:px|rem|em|%)?)$/);
          if(m){
            const from={line:cur.line,ch:cur.ch-m[0].length};
            editor.replaceRange('calc('+m[0]+')',from,cur,'input');
            editor.setCursor({line:cur.line,ch:from.ch+6+m[0].length});
            return;
          }
          editor.showHint({hint:cmHintFactory(poolsRef,disabledRef),completeSingle:false,container:hintContainer});
        },
        'Enter':editor=>{
          const cur=editor.getCursor();
          const pos=editor.indexFromPos(cur);
          const packed=cssEnterInsert(editor.getValue(),pos);
          editor.replaceSelection(packed.text,'end','input');
          editor.setCursor(editor.posFromIndex(pos+packed.cursor));
        }
      }
    });
    cmRef.current=cm;
    const scheduleCommit=editor=>{
      if(commitTimerRef.current)clearTimeout(commitTimerRef.current);
      commitTimerRef.current=setTimeout(()=>{
        commitTimerRef.current=null;
        onChangeRef.current(editor.getValue());
      },140);
    };
    const flushCommit=editor=>{
      if(commitTimerRef.current)clearTimeout(commitTimerRef.current);
      commitTimerRef.current=null;
      onChangeRef.current(editor.getValue());
    };
    cm.on('beforeChange',(editor,change)=>{
      if(change.origin!=='+input'||!change.text||change.text.length!==1||change.text[0]!=='{')return;
      const selected=editor.getRange(change.from,change.to);
      change.update(change.from,change.to,[selected?'{'+selected+'}':'{}']);
      editor.state.veBraceCursor={line:change.from.line,ch:change.from.ch+1};
    });
    cm.on('changes',scheduleCommit);
    cm.on('changes',editor=>{
      if(!editor.state.veBraceCursor)return;
      const cur=editor.state.veBraceCursor;
      editor.state.veBraceCursor=null;
      editor.setCursor(cur);
    });
    cm.on('blur',flushCommit);
    cm.on('inputRead',(editor,change)=>{
      const t=(change.text||[]).join('');
      if(cmShouldHint(editor,t)){
        clearTimeout(editor.state.veHintTimer);
        editor.state.veHintTimer=setTimeout(()=>editor.showHint({hint:cmHintFactory(poolsRef,disabledRef),completeSingle:false,container:hintContainer}),90);
      }
    });
    setTimeout(()=>cm.refresh(),40);
    return()=>{
      if(commitTimerRef.current)clearTimeout(commitTimerRef.current);
      if(cm.state.veHintTimer)clearTimeout(cm.state.veHintTimer);
      try { cm.closeHint && cm.closeHint(); } catch(e) {}
      cm.toTextArea?cm.toTextArea():cm.getWrapperElement().remove();
      try { hintContainer && hintContainer.querySelectorAll('.CodeMirror-hints').forEach(el => el.remove()); } catch(e) {}
      cmRef.current=null;
    };
  },[]);
  useEffect(()=>{const cm=cmRef.current;if(cm&&value!==cm.getValue()&&!cm.hasFocus())cm.setValue(value||'');},[value]);
  return h('div',{class:'ve-cm-host',ref:hostRef});
}
function hasSafeCodeMirrorRuntime(){
  if(!(window.CodeMirror && window.CodeMirror.prototype && typeof window.CodeMirror.prototype.showHint === 'function')) return false;
  try{
    return Array.from(document.querySelectorAll('link[rel="stylesheet"]')).some(link=>{
      const href=String(link.href||'').toLowerCase();
      if(!href || href.includes('code2bricks')) return false;
      return href.includes('codemirror') && (href.includes('codemirror.css') || href.includes('codemirror.min.css') || href.includes('/lib/codemirror'));
    });
  }catch(e){return false;}
}
function CssEditor({value,onChange,vars,sourceOrder,remoteSuggestions,scss,disabledSources}){
  if(hasSafeCodeMirrorRuntime())return h(CssCodeMirrorEditor,{value,onChange,vars,remoteSuggestions,scss,disabledSources});
  const[draft,sDraft]=useState(value||'');
  const[sel,sSel]=useState([]);
  const[active,sActive]=useState(0);
  const[suggestPos,sSuggestPos]=useState({left:46,top:34});
  const ref=useRef();
  const hiRef=useRef();
  const commitRef=useRef(null);
  const suggestRef=useRef(null);
  const editingRef=useRef(false);
  const pools=useMemo(()=>cssSuggestionPools(vars,remoteSuggestions),[vars,remoteSuggestions]);
  useEffect(()=>{if(!editingRef.current)sDraft(value||'');},[value]);
  useEffect(()=>()=>{if(commitRef.current)clearTimeout(commitRef.current);if(suggestRef.current)cancelAnimationFrame(suggestRef.current);},[]);
  const commit=v=>{if(commitRef.current)clearTimeout(commitRef.current);commitRef.current=setTimeout(()=>onChange(v),120);};
  const commitNow=v=>{if(commitRef.current)clearTimeout(commitRef.current);commitRef.current=null;onChange(v);};
  const updateSuggest=()=>{const el=ref.current;if(!el){sSel([]);return;}sSel(cssSuggestions(el.value,el.selectionStart||0,pools,disabledSources));sSuggestPos(cssCaretPos(el));sActive(0);};
  const queueSuggest=()=>{if(suggestRef.current)cancelAnimationFrame(suggestRef.current);suggestRef.current=requestAnimationFrame(updateSuggest);};
  useEffect(()=>{const el=ref.current;if(el&&document.activeElement===el)queueSuggest();},[pools,disabledSources]);
  const setEditorValue=(next,pos)=>{
    sDraft(next);commit(next);sSel([]);
    setTimeout(()=>{const el=ref.current;if(!el)return;el.focus();if(pos!=null)el.setSelectionRange(pos,pos);},0);
  };
  const applySuggestion=(item)=>{
    const el=ref.current;if(!el)return;
    const start=el.selectionStart||0;const before=el.value.slice(0,start);const after=el.value.slice(el.selectionEnd||start);
    const m=cssSuggestionMatch(before);
    if(!m)return;
    const packed=cssCommitSuggestion(item,m);
    const insert=packed.insert;
    const cut=m.replaceLength||0;
    const next=before.slice(0,before.length-cut)+insert+after;
    const p=before.length-cut+(packed.cursor==null?insert.length:packed.cursor);
    setEditorValue(next,p);
  };
  const onKey=e=>{
    if((e.ctrlKey||e.metaKey)&&e.key===' '){e.preventDefault();updateSuggest();return;}
    if(e.key==='Tab'&&sel.length){e.preventDefault();applySuggestion(sel[active]||sel[0]);return;}
    if(e.key==='ArrowDown'&&sel.length){e.preventDefault();sActive(i=>Math.min(sel.length-1,i+1));return;}
    if(e.key==='ArrowUp'&&sel.length){e.preventDefault();sActive(i=>Math.max(0,i-1));return;}
    if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='d'){
      e.preventDefault();
      const el=e.currentTarget;const start=el.selectionStart||0;const end=el.selectionEnd||start;
      const lineStart=el.value.lastIndexOf('\n',start-1)+1;
      let lineEnd=el.value.indexOf('\n',end);if(lineEnd<0)lineEnd=el.value.length;
      const line=el.value.slice(lineStart,lineEnd);
      const next=el.value.slice(0,lineEnd)+'\n'+line+el.value.slice(lineEnd);
      setEditorValue(next,lineEnd+1+line.length);return;
    }
    if(e.key==='{'){
      e.preventDefault();
      const el=e.currentTarget;const p=el.selectionStart||0;const end=el.selectionEnd||p;
      const before=el.value.slice(0,p),selected=el.value.slice(p,end),after=el.value.slice(end);
      const insert=selected?'{'+selected+'}':'{\n  \n}';
      const next=before+insert+after;
      setEditorValue(next,before.length+(selected?insert.length:4));return;
    }
    if(e.key==='}'&&e.currentTarget.value[e.currentTarget.selectionStart||0]==='}'){
      e.preventDefault();const p=(e.currentTarget.selectionStart||0)+1;e.currentTarget.setSelectionRange(p,p);return;
    }
    if(e.key==='Tab'){
      const el=e.currentTarget;const p=el.selectionStart||0;const m=el.value.slice(0,p).match(/(\d+(?:\.\d+)?(?:px|rem|em|%)?)\s*([-+*/])\s*(\d+(?:\.\d+)?(?:px|rem|em|%)?)$/);
      if(m){e.preventDefault();const before=el.value.slice(0,p-m[0].length);const after=el.value.slice(el.selectionEnd||p);const next=before+'calc('+m[0]+')'+after;setEditorValue(next,before.length+6+m[0].length);}
    }
    if(e.key==='Enter'){
      e.preventDefault();
      const el=e.currentTarget;const p=el.selectionStart||0;const end=el.selectionEnd||p;
      const packed=cssEnterInsert(el.value,p);
      const next=el.value.slice(0,p)+packed.text+el.value.slice(end);
      setEditorValue(next,p+packed.cursor);return;
    }
  };
  const onInput=e=>{
    const v=e.target.value;
    sDraft(v);
    commit(v);
    queueSuggest();
  };
  const lines=useMemo(()=>Array.from({length:cssLineCount(draft)},(_,i)=>i+1).join('\n'),[draft]);
  const highlighted=useMemo(()=>cssHighlight(draft),[draft]);
  const syncScroll=e=>{if(hiRef.current){hiRef.current.scrollTop=e.currentTarget.scrollTop;hiRef.current.scrollLeft=e.currentTarget.scrollLeft;}queueSuggest();};
  return h('div',{class:'ve-code-wrap'},
    h('div',{class:'ve-code-shell'},
      h('pre',{class:'ve-code-lines'},lines),
      h('div',{class:'ve-code-editor'},
        h('pre',{ref:hiRef,class:'ve-code-highlight',dangerouslySetInnerHTML:{__html:highlighted}}),
        h('textarea',{ref,class:'ve-code-input',value:draft,onInput,onKeyDown:onKey,onClick:queueSuggest,onKeyUp:queueSuggest,onFocus:()=>{editingRef.current=true;queueSuggest();},onBlur:()=>{editingRef.current=false;commitNow(ref.current?ref.current.value:draft);},onSelect:queueSuggest,onScroll:syncScroll,placeholder:'/* Type . for classes, # for IDs, or -- for variables */\n.selector {\n  color: var(--color-primary);\n}'}))),
    sel.length>0&&h('div',{class:'ve-suggest',style:{left:suggestPos.left+'px',top:suggestPos.top+'px'}},sel.map((x,i)=>h('button',{type:'button',class:i===active?'on':'',onMouseDown:e=>{e.preventDefault();applySuggestion(x);}},typeof x==='string'?x:x.label))),
    h('div',{style:'font-size:11px;color:#666;line-height:1.55;margin-top:6px'},'Tab completes suggestions. Ctrl+D duplicates the current line/selection. After a small math expression like 100% - 20px, Tab wraps it in calc().',scss?' SCSS mode keeps nested syntax while compile support remains plain CSS-safe.':''));
}

/* ── CSS Studio sub-panel ─────────────── */
function AdvancedCssSub({onClose,exiting,vars,initialSheetId}){
  const[sheets,sSheets]=useState(DEFAULT_CSS_SHEETS);
  const[sel,sSel]=useState('global');
  const[ld,sLd]=useState(false);
  const[msg,sMsg]=useState('');
  const[scss,sScss]=useState(()=>localStorage.getItem('ve_css_scss')==='1');
  const[sourceOrder,sSourceOrder]=useState(()=>{try{return normalizeSourceOrder(JSON.parse(localStorage.getItem('ve_css_source_order')||'[]'),[]);}catch(e){return CSS_SOURCE_DEFAULTS;}});
  const[remoteSuggestions,sRemoteSuggestions]=useState({variables:[],classes:[],ids:[],sources:[]});
  const[disabledSources,sDisabledSources]=useState(()=>{try{return JSON.parse(localStorage.getItem('ve_css_disabled_sources')||'[]');}catch(e){return[];}});
  const[pendingDelete,sPendingDelete]=useState(null);

  useEffect(() => {
    const handler = () => {
      sScss(localStorage.getItem('ve_css_scss') === '1');
      try {
        sSourceOrder(normalizeSourceOrder(JSON.parse(localStorage.getItem('ve_css_source_order') || '[]'), []));
      } catch(e) {}
      try {
        sDisabledSources(JSON.parse(localStorage.getItem('ve_css_disabled_sources') || '[]'));
      } catch(e) {}
    };
    window.addEventListener('ve-css-settings-changed', handler);
    return () => {
      window.removeEventListener('ve-css-settings-changed', handler);
    };
  }, []);

  useEffect(()=>{
    api.g('advanced-css').then(d=>{let a=d?.stylesheets||[];if(a.length){const legacy=a.length===3&&a.every(x=>['page','global','child'].includes(x.id))&&a.every(x=>!String(x.css||'').trim());if(legacy)a=DEFAULT_CSS_SHEETS;sSheets(a);sSel((a.find(x=>String(x.id)===String(initialSheetId))||a.find(x=>x.id==='global')||a[0])?.id||'global');}}).catch(()=>{});
    api.g('advanced-css/suggestions').then(d=>{if(d&&!d.code){sRemoteSuggestions(d);}}).catch(()=>{});
  },[initialSheetId]);

  const cur=sheets.find(x=>x.id===sel)||sheets[0]||null;
  const upd=(patch)=>sSheets(arr=>arr.map(x=>x.id===(cur?.id)?{...x,...patch}:x));
  const add=()=>{const id='custom_'+Date.now();const next={id,name:'custom.css',scope:'custom',enabled:true,css:''};sSheets(a=>[...a,next]);sSel(id);};
  const delSheet=(sheet,e)=>{e&&e.stopPropagation();if(sheets.length<=1)return;sPendingDelete(sheet);};
  const confirmDelSheet=()=>{const sheet=pendingDelete;if(!sheet)return;const next=sheets.filter(x=>x.id!==sheet.id);sSheets(next);if(sel===sheet.id)sSel((next.find(x=>x.id==='global')||next[0])?.id||'global');sPendingDelete(null);};
  const save=async()=>{sLd(true);sMsg('');const r=await api.p('advanced-css',{stylesheets:sheets});sLd(false);if(r?.code){sMsg(r.message||'Save failed');return;}sSheets(r.stylesheets||sheets);sMsg('Saved and compiled.');};
  const scopeHelp={page:'Scope: renders only where page-level targeting is supported. Use for CSS that should stay narrow.',global:'Scope: renders site-wide. Use for CSS that should work everywhere.',child:'Scope: renders as a child-theme-style layer for broad theme overrides.',custom:'Scope: custom named stylesheet. Use when you want a separate editable layer.'};
  const warnings=useMemo(()=>cssValidation(cur?.css||''),[cur?.id,cur?.css]);

  return h('div',{class:'ve-body ve-css-studio-combined'},
      pendingDelete&&h(ConfirmModal,{title:'Delete stylesheet',body:'Delete stylesheet "'+pendingDelete.name+'"? This will be removed when you save and compile.',confirmText:'Delete',danger:true,onCancel:()=>sPendingDelete(null),onConfirm:confirmDelSheet}),
      h('div',{class:'ve-css-studio-combined-grid'},
        h('div',{class:'ve-css-settings-column ve-scroll-custom'},
          h('div',{class:'ve-studio-top'},
            h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:add},'+ New Stylesheet')),
          h('div',{style:'display:grid;grid-template-columns:'+(sheets.length>1?'115px minmax(0,1fr)':'1fr')+';gap:10px;min-height:0'},
            sheets.length>1&&h('div',{class:'ve-css-sheet-list ve-scroll-custom'},sheets.map(x=>h('button',{key:x.id,type:'button',class:'ve-btn '+(x.id===sel?'':'ve-btn-g')+' ve-btn-s ve-sheet-tab',onClick:()=>sSel(x.id)},h('span',null,x.name),sheets.length>1&&h('span',{class:'ve-sheet-del',title:'Delete stylesheet',onClick:e=>delSheet(x,e)},ph('trash'))))),
            cur&&h('div',{class:'ve-studio-main',style:'padding:0;overflow:visible'},
              h('div',{class:'ve-row'},h('input',{class:'ve-studio-input',value:cur.name,onInput:e=>upd({name:e.target.value}),placeholder:'stylesheet name'})),
              h('div',{class:'ve-scope-label'},'Stylesheet Scope'),
              h('div',{class:'ve-row'},
                h(SelectMenu,{value:cur.scope,onChange:v=>upd({scope:v}),options:['page','global','child','custom']}),
                h('label',{style:'display:flex;align-items:center;gap:7px;font-size:11px;color:#bbb;min-height:38px'},h('input',{type:'checkbox',checked:!!cur.enabled,onChange:e=>upd({enabled:e.target.checked})}),'Enabled')),
              h('div',{style:'font-size:11px;color:#777;line-height:1.55;margin:0 0 8px'},(scopeHelp[cur.scope]||scopeHelp.custom)+' This dropdown determines where and how widely this stylesheet renders/works.'),
              warnings.length>0&&h('div',{class:'ve-css-diag'},warnings.map(w=>h('div',null,w))))),
          h('div',{style:'font-size:11px;color:#666;line-height:1.6;margin-top:auto'},"CSS Studio compiles after Mimam's Var variables on the frontend and in admin/builder screens.")),
        cur&&h('div',{class:'ve-css-editor-column'},
          h('div',{class:'ve-editor-only'},
            h(CssEditor,{value:cur.css,onChange:v=>upd({css:v}),vars,sourceOrder,remoteSuggestions,scss,disabledSources}),
            h('div',{class:'ve-editor-actions'},
              h('small',null,msg || "Compile after editing this stylesheet."),
              h('button',{class:'ve-btn ve-btn-s',onClick:save,disabled:ld},ld?'Saving...':'Save & Compile')))))
    );
}

function CssRecipesStudioSub({ flash, vars, initialCode }) {
  const [userRecipes, setUserRecipes] = useState(() => loadUserCssRecipes());
  const [code, setCode] = useState('custom');
  const [name, setName] = useState('');
  const [css, setCss] = useState('');
  const [editingCode, setEditingCode] = useState(null);
  const [editingBuiltin, setEditingBuiltin] = useState(false);
  const [scss, setScss] = useState(() => localStorage.getItem('ve_css_scss') === '1');
  const [sourceOrder, setSourceOrder] = useState(() => { try { return normalizeSourceOrder(JSON.parse(localStorage.getItem('ve_css_source_order') || '[]'), []); } catch (e) { return CSS_SOURCE_DEFAULTS; } });
  const [remoteSuggestions, setRemoteSuggestions] = useState({ variables: [], classes: [], ids: [], sources: [] });
  const [disabledSources, setDisabledSources] = useState(() => { try { return JSON.parse(localStorage.getItem('ve_css_disabled_sources') || '[]'); } catch (e) { return []; } });
  const builtins = CSS_RECIPES;

  useEffect(() => {
    api.g('advanced-css/suggestions').then(d => { if (d && !d.code) setRemoteSuggestions(d); }).catch(() => {});
    const handler = () => {
      setScss(localStorage.getItem('ve_css_scss') === '1');
      try { setSourceOrder(normalizeSourceOrder(JSON.parse(localStorage.getItem('ve_css_source_order') || '[]'), [])); } catch (e) {}
      try { setDisabledSources(JSON.parse(localStorage.getItem('ve_css_disabled_sources') || '[]')); } catch (e) {}
    };
    window.addEventListener('ve-css-settings-changed', handler);
    return () => window.removeEventListener('ve-css-settings-changed', handler);
  }, []);

  const persistUserRecipes = next => {
    setUserRecipes(next);
    saveUserCssRecipes(next);
  };

  const resetRecipeForm = () => {
    setCode('custom');
    setName('');
    setCss('');
    setEditingCode(null);
    setEditingBuiltin(false);
  };

  const saveRecipe = e => {
    e && e.preventDefault();
    const cleanCode = (code || '').trim().replace(/^@+/, '').replace(/[^a-z0-9_-]/gi, '-').replace(/-+/g, '-').replace(/^-|-$/g, '').toLowerCase();
    const finalCode = '@' + cleanCode;
    if (!finalCode || finalCode === '@' || !css.trim()) {
      flash('Add a shortcode and CSS first.');
      return;
    }
    const nextRecipe = { code: finalCode, name: (name || finalCode.replace(/^@/, '')).trim(), css: css.trim() };
    const next = [...userRecipes.filter(r => r.code !== finalCode), nextRecipe].sort((a,b)=>a.code.localeCompare(b.code));
    persistUserRecipes(next);
    resetRecipeForm();
    flash('Recipe saved. Type ' + finalCode + ' then press Tab in CSS Studio.');
  };

  const removeRecipe = recipe => {
    persistUserRecipes(userRecipes.filter(r => r.code !== recipe.code));
    flash('Recipe removed.');
  };

  const loadRecipe = (recipe, builtin) => {
    setCode(String(recipe.code || '').replace(/^@/, ''));
    setName(recipe.name || '');
    setCss(recipe.css || '');
    setEditingCode(recipe.code || null);
    setEditingBuiltin(!!builtin);
    flash('Loaded ' + recipe.code + ' into the recipe editor.');
  };
  useEffect(()=>{
    if(!initialCode)return;
    const recipe=[...builtins,...userRecipes].find(item=>String(item.code)===String(initialCode));
    if(recipe)loadRecipe(recipe,builtins.includes(recipe));
  },[initialCode]);

  const recipeTitle = editingCode ? (editingBuiltin ? 'Built-in Recipe Preview' : 'Edit Recipe') : 'New Recipe';

  const recipeCard = (recipe, builtin) => h('div', { class: 've-recipe-card', key: (builtin ? 'b-' : 'u-') + recipe.code, role: 'button', tabIndex: 0, onClick: () => loadRecipe(recipe, builtin), onKeyDown: e => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); loadRecipe(recipe, builtin); } } },
    h('span', { class: 've-recipe-code' }, recipe.code),
    h('div', null,
      h('strong', null, recipe.name || recipe.code),
      h('small', null, 'Click to load this recipe output')
    ),
    builtin ? h('span', { style: 'font-size:11px;color:#777;text-transform:uppercase;font-weight:700' }, 'Built in') :
      h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: e => { e.stopPropagation(); removeRecipe(recipe); }, title: 'Delete recipe' }, ph('trash'))
  );

  return h('div', { class: 've-recipe-studio' },
    h('div', { class: 've-recipe-studio-main' },
      h('div', { class: 've-recipe-list ve-scroll-custom' },
        h('div', { class: 've-studio-nav-title', style: 'margin-bottom:2px' }, 'Recipe Shortcodes'),
        builtins.map(r => recipeCard(r, true)),
        userRecipes.length ? userRecipes.map(r => recipeCard(r, false)) : h('div', { class: 've-empty', style: 'padding:16px;text-align:left' }, 'No custom recipes yet.')
      ),
      h('form', { class: 've-recipe-form', onSubmit: saveRecipe },
        h('div', { style: 'display:flex;align-items:center;justify-content:space-between;gap:10px' },
          h('div', { class: 've-studio-nav-title', style: 'margin:0' }, recipeTitle),
          editingCode && h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: resetRecipeForm }, '+ New Recipe')
        ),
        h('label', { class: 've-recipe-field' }, h('span', { class: 've-scope-label' }, 'Shortcode'), h('div', { class: 've-recipe-shortcode' },
          h('span', { class: 've-studio-input' }, '@'),
          h('input', {
            class: 've-studio-input',
            name: 've_recipe_shortcode',
            value: code,
            autoComplete: 'off',
            'data-1p-ignore': 'true',
            'data-lpignore': 'true',
            onInput: e => setCode(String(e.target.value || '').replace(/^@+/, '')),
            placeholder: 'section'
          })
        )),
        h('label', { class: 've-recipe-field' }, h('span', { class: 've-scope-label' }, 'Name'), h('input', {
          class: 've-studio-input',
          name: 've_recipe_title',
          value: name,
          autoComplete: 'off',
          'data-1p-ignore': 'true',
          'data-lpignore': 'true',
          onInput: e => setName(e.target.value),
          placeholder: 'Section rhythm'
        })),
        h('label', { class: 've-recipe-field', style: 'min-height:0;flex:0 0 auto' },
          h('span', { class: 've-scope-label' }, 'CSS'),
          h('div', { class: 've-recipe-editor' },
            h(CssEditor, { value: css, onChange: setCss, vars, sourceOrder, remoteSuggestions, scss, disabledSources })
          )
        ),
        h('div', { class: 've-recipe-form-actions' },
          h('button', { class: 've-btn ve-btn-g ve-btn-s', type: 'button', onClick: resetRecipeForm }, editingCode ? 'Cancel Edit' : 'Clear'),
          h('button', { class: 've-btn ve-btn-s', type: 'submit' }, editingBuiltin ? 'Save as Custom Recipe' : 'Save Recipe')
        ),
        h('div', { style: 'font-size:11px;color:#777;line-height:1.55' }, 'Click any shortcode to load its output into this editor, then save it as a custom recipe when needed.')
      )
    )
  );
}

/* ── Manual family relationships ──────── */
function FamilyRelationshipSub({initialIds,initialOperation,initialRootId,initialNewRootId,lockRoot,vars,onDone,onClose,onNavigateUsage,exiting}){
  const selected=(initialIds||[]).map(id=>vars.find(v=>Number(v.id)===Number(id))).filter(Boolean);
  const selectedGenerated=selected.filter(v=>v.type==='generated');
  const selectedBases=selected.filter(v=>v.type==='base');
  const familyRoots=vars.filter(v=>v.type==='base'&&vars.some(c=>c.type==='generated'&&Number(c.source_id)===Number(v.id)));
  const selectedGeneratedRootIds=[...new Set(selectedGenerated.map(v=>Number(v.source_id)).filter(id=>id>0))];
  const selectedFamilyRootId=selectedGeneratedRootIds.length===1?selectedGeneratedRootIds[0]:'';
  const selectedFamilyRoot=vars.find(v=>Number(v.id)===Number(selectedFamilyRootId));
  const selectedBaseFamilyRoot=selectedBases.find(v=>familyRoots.some(root=>Number(root.id)===Number(v.id)));
  const inferredOperation=initialOperation||(selected.length>0&&selectedGenerated.length===selected.length?'ungroup':'group');
  const inferredRootId=initialRootId||selectedBaseFamilyRoot?.id||selectedFamilyRoot?.id||selectedBases[0]?.id||familyRoots[0]?.id||'';
  const inferredNewRootId=initialNewRootId||'';
  const[operation,sOperation]=useState(inferredOperation);
  const[rootId,sRootId]=useState(String(inferredRootId));
  const[newRootId,sNewRootId]=useState(String(inferredNewRootId));
  const[preview,sPreview]=useState(null);
  const[loading,sLoading]=useState(false);
  const[error,sError]=useState('');

  const contextRoot=vars.find(v=>Number(v.id)===Number(initialRootId));
  const contextChildren=contextRoot?vars.filter(v=>v.type==='generated'&&Number(v.source_id)===Number(contextRoot.id)):[];
  const currentRoot=vars.find(v=>String(v.id)===String(rootId));
  const rootChildren=currentRoot?vars.filter(v=>v.type==='generated'&&Number(v.source_id)===Number(currentRoot.id)):[];
  const eligibleRoots=operation==='change_root'?familyRoots:vars.filter(v=>v.type==='base');
  const operationOptions=(lockRoot?[
    {value:'change_root',label:'Change this family’s root'},
    {value:'reparent',label:'Move this family’s children to another root'},
    {value:'ungroup',label:'Ungroup this family’s children'}
  ]:[
    {value:'group',label:'Group selected variables'},
    {value:'reparent',label:'Move selected children to another root'},
    {value:'ungroup',label:'Ungroup selected children'},
    {value:'change_root',label:'Change a family root'}
  ]);
  const descriptions={
    group:'Choose one standalone variable as the root. Every other selected variable becomes its child.',
    reparent:'Move the selected imported or manually grouped children beneath another standalone root.',
    ungroup:'Promote the selected imported or manually grouped children back to standalone variables.',
    change_root:'Promote one existing child to root. The old root and its siblings move beneath it.'
  };

  useEffect(()=>{
    sPreview(null);sError('');
    if(operation==='change_root'){
      const preferred=vars.find(v=>Number(v.id)===Number(inferredRootId))||familyRoots[0];
      sRootId(String(preferred?.id||''));
      const preferredChild=vars.find(v=>Number(v.id)===Number(initialNewRootId)&&Number(v.source_id)===Number(preferred?.id));
      const child=preferredChild||vars.find(v=>v.type==='generated'&&Number(v.source_id)===Number(preferred?.id));
      sNewRootId(String(child?.id||''));
    }else if(operation==='group'){
      sRootId(String(selectedBases[0]?.id||''));
      sNewRootId('');
    }else if(operation==='reparent'){
      const selectedRootIds=new Set(selected.map(v=>Number(v.id)));
      const destination=vars.find(v=>v.type==='base'&&!selectedRootIds.has(Number(v.id))&&Number(v.id)!==Number(initialRootId));
      sRootId(String(destination?.id||''));
      sNewRootId('');
    }else{
      sRootId(lockRoot?String(initialRootId||''):'');sNewRootId('');
    }
  },[operation]);

  useEffect(()=>{
    if(operation!=='change_root')return;
    const children=vars.filter(v=>v.type==='generated'&&Number(v.source_id)===Number(rootId));
    if(!children.some(v=>String(v.id)===String(newRootId)))sNewRootId(String(children[0]?.id||''));
    sPreview(null);sError('');
  },[rootId]);

  const operationSelection=lockRoot&&['reparent','ungroup'].includes(operation)?contextChildren:selected;
  const payload=()=>({
    operation,
    variable_ids:operationSelection.map(v=>Number(v.id)),
    root_id:Number(rootId||0),
    new_root_id:Number(newRootId||0)
  });
  const runPreview=async()=>{
    sLoading(true);sError('');sPreview(null);
    const result=await api.p('variable-families/preview',payload());
    sLoading(false);
    if(result?.code){sError(result.message||'Could not preview this family change.');return;}
    sPreview(result);
  };
  const apply=async()=>{
    if(!preview)return;
    sLoading(true);sError('');
    const result=await api.p('variable-families/apply',{...payload(),fingerprint:preview.fingerprint});
    sLoading(false);
    if(result?.code){sError(result.message||'Could not apply this family change.');return;}
    onDone(result);
  };
  const parentLabel=(name,type)=>name?publicTokenLabel(name):(type==='base'?'Standalone':'No parent');

  return h(Sub,{title:'Manage variable family',onClose,exiting},
    h('div',{class:'ve-family-intro'},ph('tree-structure'),h('div',null,'Relationships change how variables are grouped in Mimam’s Var. Token names, exact values, aliases, generated CSS names, and source tags are preserved.')),
    h('label',{class:'ve-family-field'},h('span',null,'Action'),h(SelectMenu,{value:operation,onChange:sOperation,options:operationOptions})),
    h('div',{class:'ve-family-note',style:'margin:-4px 0 12px'},descriptions[operation]),
    operation!=='change_root'&&h('div',{class:'ve-family-field'},
      h('span',null,(lockRoot?'Family children':'Selected variables')+' ('+operationSelection.length+')'),
      h('div',{class:'ve-family-selection'},operationSelection.length?operationSelection.map(v=>h('span',{class:'ve-family-chip',key:v.id},publicTokenLabel(v.name))):h('span',{style:'color:#777;font-size:11px'},'Select variables from the main list first.'))
    ),
    (operation==='group'||operation==='reparent'||operation==='change_root')&&h('label',{class:'ve-family-field'},
      h('span',null,operation==='change_root'?'Current family root':'Destination root'),
      operation==='change_root'&&lockRoot
        ?h('div',{class:'ve-family-selection'},h('span',{class:'ve-family-chip'},currentRoot?publicTokenLabel(currentRoot.name):'Family root unavailable'))
        :h(SelectMenu,{className:'ve-family-root-menu',searchable:true,searchPlaceholder:'Search destination roots…',value:rootId,onChange:value=>{sRootId(value);sPreview(null);},options:[{value:'',label:'Choose root'},...eligibleRoots.map(v=>({value:String(v.id),label:publicTokenLabel(v.name)}))]})
    ),
    operation==='change_root'&&h('label',{class:'ve-family-field'},
      h('span',null,'New root'),
      h(SelectMenu,{className:'ve-family-root-menu',searchable:true,searchPlaceholder:'Search family children…',value:newRootId,onChange:value=>{sNewRootId(value);sPreview(null);sError('');},options:[{value:'',label:'Choose child'},...rootChildren.map(v=>({value:String(v.id),label:publicTokenLabel(v.name)}))]})
    ),
    error&&h('div',{class:'ve-warn',style:'margin-top:10px'},error),
    preview&&h('div',{class:'ve-family-preview'},
      h('div',{class:'ve-family-preview-h'},ph('check-circle'),'Preview · '+preview.count+' relationship change'+(preview.count===1?'':'s')),
      preview.changes.map(change=>h('div',{class:'ve-family-change',key:change.id},
        h('div',{class:'ve-family-change-name'},publicTokenLabel(change.name)),
        h('div',{class:'ve-family-change-path'},
          parentLabel(change.from_parent_name,change.from_type),' → ',h('b',null,parentLabel(change.to_parent_name,change.to_type)),
          change.from_category!==change.to_category&&h('span',null,' · Category ',change.from_category,' → ',change.to_category)
        )
      ))
    ),
    preview&&h('div',{class:'ve-family-note'},'A complete safety snapshot will be created before Apply. Calculated generator families stay protected.'),
    preview&&h(VariableImpactStack,{variables:preview.changes.map(change=>vars.find(variable=>Number(variable.id)===Number(change.id))).filter(Boolean),onNavigate:onNavigateUsage}),
    h('div',{class:'ve-family-actions'},
      h('button',{class:'ve-btn ve-btn-g',onClick:onClose,disabled:loading},'Cancel'),
      h('button',{class:'ve-btn',onClick:runPreview,disabled:loading||(!operationSelection.length&&operation!=='change_root')},loading&&!preview?'Previewing...':'Preview changes'),
      preview&&h('button',{class:'ve-btn',onClick:apply,disabled:loading},loading?'Applying...':'Apply '+preview.count+' changes')
    )
  );
}

/* ── Color generate sub-panel ─────────── */
function GenColorSub({variable,childMap,onDone,onClose,exiting}){
  const has=(childMap[variable.id]||[]).length>0;
  const[ok,sOk]=useState(!has);
  const[tints,sT]=useState(true);const[shades,sS]=useState(true);const[alpha,sA]=useState(true);
  const[tN,sTN]=useState(8);const[sN,sSN]=useState(8);const[aN,sAN]=useState(8);const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const run=async()=>{sLd(true);sErr('');
    const r=await api.p(`variables/${variable.id}/generators`,{type:'color',replace:has,config:{tint_count:tints?tN:0,shade_count:shades?sN:0,include_alpha:alpha,alpha_count:alpha?aN:0}});
    sLd(false);if(r?.code){sErr(r.message||'Could not generate color variants.');return;}onDone();};
  return h(Sub,{title:'Generate: '+publicTokenLabel(variable.name),onClose,exiting},
    has&&!ok?h('div',null,h('div',{class:'ve-warn'},'This color already has variants. Continuing replaces them.'),
      h('div',{style:'display:flex;gap:5px;margin-top:8px'},h('button',{class:'ve-btn',onClick:()=>sOk(true)},'Continue')))
    :h('div',null,
      h('div',{class:'ve-opt'},h('label',null,h('input',{type:'checkbox',checked:tints,onChange:e=>sT(e.target.checked)}),'Tints'),h('input',{type:'number',min:0,max:20,value:tN,onInput:e=>sTN(+e.target.value),disabled:!tints})),
      h('div',{class:'ve-opt'},h('label',null,h('input',{type:'checkbox',checked:shades,onChange:e=>sS(e.target.checked)}),'Shades'),h('input',{type:'number',min:0,max:20,value:sN,onInput:e=>sSN(+e.target.value),disabled:!shades})),
      h('div',{class:'ve-opt'},h('label',null,h('input',{type:'checkbox',checked:alpha,onChange:e=>sA(e.target.checked)}),'Alpha'),h('input',{type:'number',min:0,max:20,value:aN,onInput:e=>sAN(+e.target.value),disabled:!alpha})),
      err&&h('div',{style:'font-size:11px;color:#ef4444;padding:6px 0 0'},err),
      h('div',{style:'display:flex;gap:5px;margin-top:10px;justify-content:flex-end'},h('button',{class:'ve-btn',onClick:run,disabled:ld},ld?'Generating...':'Generate'))));
}

/* ── Scale generate sub-panel (reads viewport from settings) ── */
function GenScaleSub({variable,onDone,onClose,exiting}){
  const bv=pxV(variable.value)||16;
  const[bMin,sBM]=useState(bv);const[bMax,sBX]=useState(Math.round(bv*1.125));
  const[scMin,sSM]=useState('major-third');const[scMax,sSX]=useState('major-third');
  const[up,sUp]=useState(3);const[dn,sDn]=useState(2);const[ld,sLd]=useState(false);
  const[vwMin,sVWM]=useState(320);const[vwMax,sVWX]=useState(1440);
  const[err,sErr]=useState('');

  useEffect(()=>{api.g('settings').then(d=>{if(d&&d.vw_min)sVWM(d.vw_min);if(d&&d.vw_max)sVWX(d.vw_max);});},[]);

  const run=async()=>{sLd(true);sErr('');
    const ns=variable.namespace;const tp=(ns==='font'||ns==='heading'||ns==='text')?'typography':ns==='space'?'spacing':ns==='radius'?'radius':ns==='size'?'size':'spacing';
    const r=await api.p(`variables/${variable.id}/generators`,{type:tp,replace:true,config:{base_min:bMin,base_max:bMax,scale_min:scMin,scale_max:scMax,steps_up:up,steps_down:dn,vw_min:vwMin,vw_max:vwMax,naming:'numeric'}});
    sLd(false);if(r?.code){sErr(r.message||'Could not generate the fluid scale.');return;}onDone();};
  return h(Sub,{title:'Fluid scale: '+publicTokenLabel(variable.name),onClose,exiting},
    h('div',{class:'ve-opt'},h('span',null,'Base min (mobile)'),h('input',{type:'number',value:bMin,onInput:e=>sBM(+e.target.value),step:'0.1'})),
    h('div',{class:'ve-opt'},h('span',null,'Base max (desktop)'),h('input',{type:'number',value:bMax,onInput:e=>sBX(+e.target.value),step:'0.1'})),
    h('div',{class:'ve-opt'},h('span',null,'Scale min'),h(SelectMenu,{className:'ve-opt-menu',value:scMin,onChange:sSM,options:SCALES})),
    h('div',{class:'ve-opt'},h('span',null,'Scale max'),h(SelectMenu,{className:'ve-opt-menu',value:scMax,onChange:sSX,options:SCALES})),
    h('div',{class:'ve-opt'},h('span',null,'Steps up'),h('input',{type:'number',min:0,max:8,value:up,onInput:e=>sUp(+e.target.value)})),
    h('div',{class:'ve-opt'},h('span',null,'Steps down'),h('input',{type:'number',min:0,max:8,value:dn,onInput:e=>sDn(+e.target.value)})),
    h('div',{style:'font-size:11px;color:#444;padding:4px 0;border-top:1px solid #2a2a2a;margin-top:6px'},'Viewport: '+vwMin+'px → '+vwMax+'px (from Settings)'),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:6px 0 0'},err),
    h('div',{style:'display:flex;gap:5px;margin-top:10px;justify-content:flex-end'},h('button',{class:'ve-btn',onClick:run,disabled:ld},ld?'Generating...':'Generate')));
}

function cssVarToTokenName(name){
  let n=String(name||'').trim().toLowerCase().replace(/^--/,'').replace(/[^a-z0-9-]/g,'-').replace(/-+/g,'-').replace(/^-|-$/g,'');
  if(!n)return'';
  return n.replace(/-/g,'.');
}
function parseCssVariables(text){
  const clean=String(text||'').replace(/\/\*[\s\S]*?\*\//g,'');
  const re=/--([a-zA-Z0-9_-]+)\s*:\s*([^;]+);/g;
  const out=[];const seen={};let m;
  while((m=re.exec(clean))){
    const publicCssName='--'+String(m[1]||'').toLowerCase();
    const name=cssVarToTokenName('--'+m[1]);
    const value=String(m[2]||'').trim();
    if(!name||!value)continue;
    const aliasMatch=value.match(/^var\(\s*(--[a-zA-Z0-9_-]+)\s*(?:,\s*[^)]+)?\)$/);
    seen[name]={name,value,namespace:name.split('.')[0],type:aliasMatch?'alias':'base',public_css_name:publicCssName,source_css_name:aliasMatch?String(aliasMatch[1]).toLowerCase():''};
  }
  Object.keys(seen).sort((a,b)=>a.localeCompare(b,undefined,{numeric:true,sensitivity:'base'})).forEach(k=>out.push(seen[k]));
  return out;
}

function ThemePanel({onClose,exiting,onChanged}){
  const[data,sData]=useState({active:'default',palettes:[]});
  const[name,sName]=useState('');
  const[editing,sEditing]=useState(null);
  const[editName,sEditName]=useState('');
  const[ld,sLd]=useState(false);
  const[err,sErr]=useState('');
  const[confirmDelete,sConfirmDelete]=useState(null);
  const load=async()=>{const r=await api.g('themes');if(r&&!r.code)sData(r);};
  useEffect(()=>{load();},[]);
  const finish=async message=>{await load();onChanged&&onChanged();if(message)window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:message}));};
  const create=async()=>{if(!name.trim())return;sLd(true);sErr('');const r=await api.p('themes',{name:name.trim(),source_slug:data.active});sLd(false);if(r?.code){sErr(r.message||'Could not create theme.');return;}sName('');await finish('Theme created');};
  const activate=async slug=>{sLd(true);sErr('');const r=await api.p('themes/'+slug+'/activate',{});sLd(false);if(r?.code){sErr(r.message||'Could not switch theme.');return;}await finish('Theme switched');};
  const duplicate=async p=>{sLd(true);sErr('');const r=await api.p('themes/'+p.slug+'/duplicate',{name:p.name+' Copy'});sLd(false);if(r?.code){sErr(r.message||'Could not duplicate theme.');return;}await finish('Theme duplicated');};
  const rename=async()=>{if(!editing||!editName.trim())return;sLd(true);sErr('');const r=await api.u('themes/'+editing,{name:editName.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not rename theme.');return;}sEditing(null);sEditName('');await finish('Theme renamed');};
  const remove=async()=>{if(!confirmDelete)return;const slug=confirmDelete.slug;sConfirmDelete(null);sLd(true);sErr('');const r=await api.d('themes/'+slug);sLd(false);if(r?.code){sErr(r.message||'Could not delete theme.');return;}await finish('Theme deleted');};
  const active=data.palettes.find(p=>p.slug===data.active);
  const rows=data.palettes.map(p=>{
    const info=editing===p.slug
      ? h('div',{style:'display:flex;gap:4px'},h('input',{class:'ve-studio-input',type:'text',value:editName,onInput:e=>sEditName(e.target.value),onKeyDown:e=>{if(e.key==='Enter')rename();if(e.key==='Escape')sEditing(null);},style:'flex:1;min-width:0;font-size:11px;'}),h('button',{class:'ve-btn',onClick:rename,disabled:ld},'Save'))
      : h('div',{class:'ve-palette-row-name'},p.name);
    return h('div',{class:'ve-palette-row',key:p.slug},
      h('button',{class:'ve-a',title:p.active?'Active theme':'Activate '+p.name,onClick:()=>!p.active&&activate(p.slug),disabled:ld},ph(p.active?'check-circle':'circle')),
      h('div',{class:'ve-palette-row-info'},info,h('div',{class:'ve-palette-row-meta'},p.active?'Active · ':'',p.slug==='default'?'Uses base variable values':(p.value_count||0)+' color values')),
      h('div',{class:'ve-palette-actions'},
        h('button',{class:'ve-a',title:'Duplicate theme',onClick:()=>duplicate(p),disabled:ld},ph('copy')),
        !p.protected&&h('button',{class:'ve-a',title:'Rename theme',onClick:()=>{sEditing(p.slug);sEditName(p.name);},disabled:ld},ph('pencil-simple')),
        !p.protected&&h('button',{class:'ve-a',title:'Delete theme',onClick:()=>sConfirmDelete(p),disabled:ld},ph('trash'))));
  });
  return h(Sub,{title:'Color Themes',onClose,exiting},
    confirmDelete&&h(ConfirmModal,{title:'Delete theme',body:'Delete “'+confirmDelete.name+'”? Its alternate color values will be removed. The underlying variables remain safe.',confirmText:'Delete Theme',danger:true,onCancel:()=>sConfirmDelete(null),onConfirm:remove}),
    h('div',{class:'ve-palette-current'},h('i',{class:'ph-duotone ph-palette',style:'font-size:18px;color:#baf400;line-height:1'}),h('div',null,h('div',{style:'font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;font-weight:600'},'Active theme'),h('div',{style:'font-size:13px;color:#e8e8e8;font-weight:700;margin-top:1px'},active?.name||'Default'))),
    h('div',{class:'ve-import-help'},'Themes change color values without changing token names. Create one from the active values, switch it on, then edit Color variables normally.'),
    h('div',{style:'display:flex;gap:5px;margin-bottom:10px'},h('input',{class:'ve-studio-input',type:'text',value:name,onInput:e=>sName(e.target.value),placeholder:'New theme name',onKeyDown:e=>e.key==='Enter'&&create(),style:'flex:1;font-size:11px;'}),h('button',{class:'ve-btn',onClick:create,disabled:ld||!name.trim()},'Create')),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:0 0 8px'},err),
    h('div',{style:'flex:1;min-height:0;overflow-y:auto'},rows));
}

function ColorPalettePanel({onClose,exiting,onChanged,inline=false,selectedPaletteId='all'}){
  const[data,sData]=useState({palettes:[]});
  const [draggingPaletteId, sDraggingPaletteId] = useState(null);
  const [dragOverPaletteId, sDragOverPaletteId] = useState(null);
  const handlePaletteDrop = async (e, targetPalette) => {
    e.preventDefault();
    const sourceId = draggingPaletteId;
    sDraggingPaletteId(null);
    sDragOverPaletteId(null);
    if (!sourceId || sourceId === targetPalette.id) return;

    const currentList = [...data.palettes];
    const sourceIdx = currentList.findIndex(x => x.id === sourceId);
    const targetIdx = currentList.findIndex(x => x.id === targetPalette.id);
    if (sourceIdx === -1 || targetIdx === -1) return;

    const [removed] = currentList.splice(sourceIdx, 1);
    currentList.splice(targetIdx, 0, removed);

    const orderedIds = currentList.map(x => x.id);

    sData(prev => ({
      ...prev,
      palettes: currentList.map((x, idx) => ({ ...x, position: idx }))
    }));

    try {
      const res = await api.p('color-palettes/reorder', { ids: orderedIds });
      if (res && !res.code) {
        window.dispatchEvent(new CustomEvent('ve-toast-request', { detail: 'Palettes reordered' }));
      } else {
        window.dispatchEvent(new CustomEvent('ve-toast-request', { detail: res?.message || 'Failed to reorder' }));
      }
      await load();
    } catch(err) {
      window.dispatchEvent(new CustomEvent('ve-toast-request', { detail: 'Failed to reorder' }));
      await load();
    }
  };
  const[name,sName]=useState('');
  const[editing,sEditing]=useState(null);
  const[editName,sEditName]=useState('');
  const[ld,sLd]=useState(false);
  const[err,sErr]=useState('');
  const[confirmDuplicate,sConfirmDuplicate]=useState(null);
  const[deleteState,sDeleteState]=useState(null);
  const[deleteDestination,sDeleteDestination]=useState('');
  const load=async()=>{const r=await api.g('color-palettes');if(r&&!r.code)sData(r);};
  useEffect(()=>{load();},[]);
  const finish=async message=>{await load();onChanged&&onChanged();if(message)window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:message}));};
  const create=async()=>{if(!name.trim())return;sLd(true);sErr('');const r=await api.p('color-palettes',{name:name.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not create palette.');return;}sName('');await finish('Empty palette created');};
  const duplicate=async()=>{if(!confirmDuplicate)return;const p=confirmDuplicate;sConfirmDuplicate(null);sLd(true);sErr('');const r=await api.p('color-palettes/'+p.id+'/duplicate',{name:p.name+' Copy'});sLd(false);if(r?.code){sErr(r.message||'Could not duplicate palette.');return;}await finish('Palette and its colors duplicated');};
  const rename=async()=>{if(!editing||!editName.trim())return;sLd(true);sErr('');const r=await api.u('color-palettes/'+editing,{name:editName.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not rename palette.');return;}sEditing(null);sEditName('');await finish('Palette renamed');};
  const askDelete=async p=>{sLd(true);sErr('');const preview=await api.g('color-palettes/'+p.id+'/delete-preview');sLd(false);if(preview?.code){sErr(preview.message||'Could not inspect palette.');return;}sDeleteDestination('');sDeleteState({palette:p,preview});};
  const remove=async(strategy='empty')=>{if(!deleteState)return;const p=deleteState.palette;const destinationId=Number(deleteDestination)||0;sDeleteState(null);sLd(true);sErr('');const r=await api.d('color-palettes/'+p.id,{strategy,destination_id:destinationId});sLd(false);if(r?.code){sErr(r.message||'Could not delete palette.');return;}await finish(strategy==='move'?'Palette removed and colors moved':'Palette deleted');};
  const destinationOptions=data.palettes.filter(p=>p.id!==deleteState?.palette?.id).map(p=>({value:String(p.id),label:p.name}));
  const rows=data.palettes.map(p=>{
    const info=editing===p.id
      ? h('div',{style:'display:flex;gap:4px'},h('input',{class:'ve-studio-input',type:'text',value:editName,onInput:e=>sEditName(e.target.value),onKeyDown:e=>{if(e.key==='Enter')rename();if(e.key==='Escape')sEditing(null);},style:'flex:1;min-width:0;font-size:11px;'}),h('button',{class:'ve-btn',onClick:rename,disabled:ld},'Save'))
      : h('div',{class:'ve-palette-row-name'},p.name);
    return h('div',{
      class:'ve-palette-row'+(draggingPaletteId===p.id?' dragging':'')+(dragOverPaletteId===p.id?' drag-over':''),
      key:p.id,
      draggable:true,
      onDragStart:e=>{
        sDraggingPaletteId(p.id);
        e.dataTransfer.effectAllowed='move';
        e.dataTransfer.setData('text/plain',String(p.id));
      },
      onDragOver:e=>{
        e.preventDefault();
        if(p.id!==draggingPaletteId)sDragOverPaletteId(p.id);
      },
      onDragLeave:()=>sDragOverPaletteId(null),
      onDragEnd:()=>{sDraggingPaletteId(null);sDragOverPaletteId(null);},
      onDrop:e=>handlePaletteDrop(e,p)
    },
      h('span',{class:'ve-palette-drag-handle',style:'cursor:grab;margin-right:4px;display:flex;align-items:center;opacity:0.3;'},ph('dots-six-vertical')),
      h('div',{class:'ve-sw-trigger',style:'width:24px;color:#baf400'},ph('palette')),
      h('div',{class:'ve-palette-row-info'},info,h('div',{class:'ve-palette-row-meta'},p.color_count+' color'+(p.color_count===1?'':'s'))),
      h('div',{class:'ve-palette-actions'},
        h('button',{class:'ve-a',title:'Duplicate palette and colors',onClick:()=>sConfirmDuplicate(p),disabled:ld},ph('copy')),
        h('button',{class:'ve-a',title:'Rename palette',onClick:()=>{sEditing(p.id);sEditName(p.name);},disabled:ld},ph('pencil-simple')),
        h('button',{class:'ve-a',title:'Delete palette',onClick:()=>askDelete(p),disabled:ld},ph('trash'))));
  });
  const selected=data.palettes.find(p=>String(p.id)===String(selectedPaletteId));
  const content=[
    confirmDuplicate&&h(ConfirmModal,{title:'Duplicate palette',body:'Duplicate “'+confirmDuplicate.name+'” and create independent copies of its '+confirmDuplicate.color_count+' color'+(confirmDuplicate.color_count===1?'':'s')+'?',confirmText:'Duplicate Palette',onCancel:()=>sConfirmDuplicate(null),onConfirm:duplicate}),
    deleteState&&(deleteState.preview.color_count===0
      ? h(ConfirmModal,{title:'Delete empty palette',body:'Delete “'+deleteState.palette.name+'”?',confirmText:'Delete Palette',danger:true,onCancel:()=>sDeleteState(null),onConfirm:()=>remove('empty')})
      : h('div',{class:'ve-modal'},h('div',{class:'ve-modal-box'},
          h('div',{class:'ve-modal-title'},'Delete populated palette'),
          h('div',{class:'ve-modal-body'},
            h('div',null,'“'+deleteState.palette.name+'” contains '+deleteState.preview.color_count+' color'+(deleteState.preview.color_count===1?'':'s')+' and '+deleteState.preview.generated_count+' generated child'+(deleteState.preview.generated_count===1?'':'ren')+'.'),
            deleteState.preview.dependent_alias_count>0&&h('div',{style:'color:#f6c369;margin-top:6px'},deleteState.preview.dependent_alias_count+' alias relationship'+(deleteState.preview.dependent_alias_count===1?'':'s')+' may also be removed if the colors are deleted.'),
            destinationOptions.length>0&&h('div',{style:'margin-top:10px'},h('div',{style:'font-size:11px;color:#888;margin-bottom:5px'},'Move colors before deleting'),h(SelectMenu,{value:deleteDestination,onChange:sDeleteDestination,options:[{value:'',label:'Choose destination palette'},...destinationOptions]}))),
          h('div',{class:'ve-modal-actions',style:'flex-wrap:wrap'},
            h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sDeleteState(null)},'Cancel'),
            destinationOptions.length>0&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',disabled:!deleteDestination,onClick:()=>remove('move')},'Move & Delete'),
            h('button',{class:'ve-btn ve-btn-d ve-btn-s',onClick:()=>remove('delete_colors')},'Delete Palette & Colors'))))),
    h('div',{class:'ve-palette-current'},h('i',{class:'ph-duotone ph-palette',style:'font-size:18px;color:#baf400;line-height:1'}),h('div',null,h('div',{style:'font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;font-weight:600'},selected?'Selected palette':'Color organization'),h('div',{style:'font-size:13px;color:#e8e8e8;font-weight:700;margin-top:1px'},selected?.name||(data.palettes.length+' palette'+(data.palettes.length===1?'':'s'))))),
    h('div',{class:'ve-import-help'},'Palettes are user-created containers for actual Color variables. They do not change the active theme or website values. New palettes start empty; colors can be moved or copied between them.'),
    h('div',{style:'display:flex;gap:5px;margin-bottom:10px'},h('input',{class:'ve-studio-input',type:'text',value:name,onInput:e=>sName(e.target.value),placeholder:'New palette name',onKeyDown:e=>e.key==='Enter'&&create(),style:'flex:1;font-size:11px;'}),h('button',{class:'ve-btn',onClick:create,disabled:ld||!name.trim()},'Create')),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:0 0 8px'},err),
    h('div',{style:inline?'max-height:190px;overflow-y:auto':'flex:1;min-height:0;overflow-y:auto'},rows.length?rows:h('div',{class:'ve-empty'},'No palettes yet. Create one to begin grouping colors.'))
  ];
  return inline
    ? h('div',{style:'padding:10px 14px 12px;border-top:1px solid #2a2a2a;display:flex;flex-direction:column;gap:8px;background:rgba(0,0,0,.12)'},...content)
    : h(Sub,{title:'Color Palettes',onClose,exiting},...content);
}

/* ── User-managed non-color categories ── */
function VariableCategoryPanel({onClose,exiting,onChanged,categories=[]}){
  const[name,sName]=useState('');
  const[editing,sEditing]=useState(null);
  const[editName,sEditName]=useState('');
  const[confirmDelete,sConfirmDelete]=useState(null);
  const[ld,sLd]=useState(false);
  const[err,sErr]=useState('');
  const finish=async message=>{if(onChanged)await onChanged();sErr('');window.dispatchEvent(new CustomEvent('ve-toast-request',{detail:message}));};
  const create=async()=>{if(!name.trim())return;sLd(true);sErr('');const r=await api.p('variable-categories',{name:name.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not create category.');return;}sName('');await finish('Category created');};
  const rename=async()=>{if(!editing||!editName.trim())return;sLd(true);sErr('');const r=await api.p('variable-categories/'+editing.slug+'/rename',{name:editName.trim()});sLd(false);if(r?.code){sErr(r.message||'Could not rename category.');return;}sEditing(null);await finish('Category renamed');};
  const remove=async()=>{if(!confirmDelete)return;const category=confirmDelete;sConfirmDelete(null);sLd(true);sErr('');const r=await api.p('variable-categories/'+category.slug+'/remove',{});sLd(false);if(r?.code){sErr(r.message||'Could not delete category.');return;}await finish('Category deleted · variables moved to Uncategorized');};
  return h(Sub,{title:'Categories',onClose,exiting},
    h('div',{class:'ve-import-help',style:'margin-bottom:10px'},'Categories organize non-color variables without changing their token names, aliases, CSS, or website output. Imported variables receive a category named after their source.'),
    h('div',{style:'display:flex;gap:5px;margin-bottom:10px'},
      h('input',{class:'ve-studio-input',value:name,onInput:e=>sName(e.target.value),onKeyDown:e=>e.key==='Enter'&&create(),placeholder:'New category name',style:'flex:1'}),
      h('button',{class:'ve-btn',onClick:create,disabled:ld||!name.trim()},'Create')),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:0 0 8px'},err),
    h('div',{style:'display:flex;flex-direction:column'},
      categories.map(category=>h('div',{key:category.slug,style:'display:flex;align-items:center;gap:7px;padding:8px 0;border-bottom:1px solid #2a2a2a'},
        h('div',{style:'flex:1;min-width:0'},
          editing?.slug===category.slug
            ? h('input',{class:'ve-studio-input',value:editName,onInput:e=>sEditName(e.target.value),onKeyDown:e=>{if(e.key==='Enter')rename();if(e.key==='Escape')sEditing(null);}})
            : h('div',{style:'font-size:11px;color:#ddd;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis'},category.name),
          h('div',{style:'font-size:11px;color:#666;margin-top:2px'},Number(category.variable_count||0)+' variables')),
        editing?.slug===category.slug
          ? h('button',{class:'ve-btn ve-btn-s',onClick:rename,disabled:ld||!editName.trim()},'Save')
          : !Number(category.protected)&&[
              h('button',{class:'ve-a',title:'Rename category',onClick:()=>{sEditing(category);sEditName(category.name);}},ph('pencil-simple')),
              h('button',{class:'ve-a',title:'Delete category',onClick:()=>sConfirmDelete(category)},ph('trash'))
            ])),
      categories.length===0&&h('div',{class:'ve-empty'},'No categories available.')),
    confirmDelete&&h(ConfirmModal,{title:'Delete category',body:'Delete “'+confirmDelete.name+'”? Its variables and generated children will move to Uncategorized. Token names and CSS will not change.',confirmText:'Delete Category',danger:true,onCancel:()=>sConfirmDelete(null),onConfirm:remove}));
}

/* ── Sync sub-panel (includes Figma connection + pairing) ── */
function SyncPanel({onClose,exiting,onDone,onReload,initialView='main',snapshotsOnly=false}){
  const[view,sView]=useState(initialView);
  const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const[diff,sDiff]=useState(null);const[summary,sSummary]=useState(null);
  const[snaps,sSnaps]=useState([]);const[skipDel,sSD]=useState(true);
  const[snapshotTitle,sSnapshotTitle]=useState('');
  const[snapshotDescription,sSnapshotDescription]=useState('');
  const[showCreateModal,sShowCreateModal]=useState(false);
  const[pair,sPair]=useState(null);const[stats,sStats]=useState(null);const[cleaning,sCleaning]=useState(false);
  const[pCode,sPC]=useState('');const[pKey,sPK]=useState('');const[figCode,sFC]=useState('');const[pMsg,sPM]=useState('');
  const[diag,sDiag]=useState(null);
  const[confirmClean,sConfirmClean]=useState(false);
  const[confirmImportDeletes,sConfirmImportDeletes]=useState(false);
  const fileRef=useRef();const cssFileRef=useRef();
  const dropDepthRef=useRef(0);
  const[dropActive,sDropActive]=useState(false);
  const[importFileName,sImportFileName]=useState('');
  const[importFormat,sImportFormat]=useState('json');
  const[importMode,sImportMode]=useState('tokens');
  const[bundlePayload,sBundlePayload]=useState(null);
  const[cssText,sCssText]=useState('');const[cssCount,sCssCount]=useState(0);
  const[driftSource,sDriftSource]=useState('figma');
  const[driftData,sDriftData]=useState(null);
  const[driftKeys,sDriftKeys]=useState([]);
  const[driftPlan,sDriftPlan]=useState(null);
  const[driftMsg,sDriftMsg]=useState('');

  const loadPair=useCallback(()=>api.g('sync/pair/status').then(d=>{if(d)sPair(d);return d;}),[]);
  const loadStats=useCallback(()=>api.g('variables/stats').then(d=>{if(d&&!d.code)sStats(d);return d;}).catch(()=>null),[]);
  useEffect(()=>{loadPair();loadStats();const t=setInterval(()=>{loadPair();loadStats();},2500);return()=>clearInterval(t);},[loadPair,loadStats]);

  const genCode=async()=>{const r=await api.p('sync/pair/generate',{});if(r?.code){sPC(r.code);sPK(r.api_key||'');}};
  const submitFigCode=async()=>{if(figCode.length!==6){sPM('Enter the 6-character code');return;}const r=await api.p('sync/pair/complete-figma',{code:figCode});if(r?.api_key){sPM('Paired!');api.g('sync/pair/status').then(d=>{if(d)sPair(d);});}else sPM(r?.message||'Invalid code');};
  const disc=async()=>{await api.p('sync/pair/disconnect',{});sPair({paired:false,source:'',figma_name:'',collection_name:''});sPC('');sPK('');};
  const cleanDb=async()=>{sConfirmClean(false);sCleaning(true);sErr('');const r=await api.p('variables/cleanup',{});sCleaning(false);if(r?.after){sStats(r.after);onReload&&onReload();}else{sErr(r?.message||'Cleanup failed');}};
  const loadDiagnostics=async()=>{if(diag){sDiag(null);return;}const r=await api.g('diagnostics/logs?lines=12');if(r?.code){sErr(r.message||'Could not load diagnostics');return;}sDiag(r);};
  const cleanableStatIssues=stats?[(stats.stale_generated?stats.stale_generated+' stale':''),(stats.orphan_generated?stats.orphan_generated+' orphan generated':''),(stats.missing_dependencies?stats.missing_dependencies+' missing dependency links':''),(stats.orphan_dependencies?stats.orphan_dependencies+' orphan dependency rows':''),(stats.duplicate_count?stats.duplicate_count+' duplicate names':''),(stats.older_generators?stats.older_generators+' old generators':'')].filter(Boolean):[];
  const manualStatIssues=stats?[(stats.public_name_conflict_count?stats.public_name_conflict_count+' CSS name conflicts require manual rename':''),(stats.broken_aliases?stats.broken_aliases+' aliases have missing sources':''),(stats.blocked_orphan_generated?stats.blocked_orphan_generated+' orphan generated variables still have dependents':'')].filter(Boolean):[];
  const statIssues=[...cleanableStatIssues,...manualStatIssues];
  const exportBaseName=()=>`mimams-var-${safeFilePart(CFG.siteTitle,'wordpress')}`;
  const doExport=async(fmt)=>{sLd(true);sErr('');const d=await api.g('sync/export?format='+fmt);const blob=new Blob([JSON.stringify(d,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=exportBaseName()+'-'+fmt+'-'+(new Date).toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);sLd(false);};
  const doExportBundle=async()=>{sLd(true);sErr('');const d=await api.g('sync/export-bundle');if(d?.code||!d?.bundle){sErr(d?.message||'System Bundle export failed');sLd(false);return;}const blob=new Blob([JSON.stringify(d.bundle,null,2)],{type:'application/json'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=d.filename||exportBaseName()+'-system-'+(new Date).toISOString().slice(0,10)+'.json';document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);sLd(false);};
  const doExportCss=async()=>{sLd(true);sErr('');const d=await api.g('sync/export-css');if(d?.code){sErr(d.message||'CSS export failed');sLd(false);return;}const blob=new Blob([d.css||''],{type:'text/css'});const url=URL.createObjectURL(blob);const a=document.createElement('a');a.href=url;a.download=d.filename||('mimams-var-'+(new Date).toISOString().slice(0,10)+'.css');document.body.appendChild(a);a.click();document.body.removeChild(a);URL.revokeObjectURL(url);sLd(false);};
  const importJsonFile=async file=>{sLd(true);sErr('');sImportFileName(file.name||'JSON file');try{const text=await file.text();const json=JSON.parse(text);const isBundle=json?.format==='mimams-var-system';const detectedFormat=isBundle?'system':json?.format==='mimams-var-figma-handoff'?'figma':Array.isArray(json)?'flat':(json?.collections?'figma':'dtcg');sImportFormat(detectedFormat);const res=await api.p(isBundle?'sync/preview-bundle':'sync/preview',json);if(res?.code){sErr(res.message||'Parse error');sLd(false);return;}sImportMode(isBundle?'system':'tokens');sBundlePayload(isBundle?json:null);sDiff(res.changes||[]);sSummary(res.summary||{});sView('preview');}catch(ex){sErr('Invalid JSON: '+ex.message);}sLd(false);};
  const importCssFile=async file=>{sErr('');sImportFileName(file.name||'CSS file');sImportFormat('css');const text=await file.text();sCssText(text);sCssCount(parseCssVariables(text).length);};
  const importDroppedFile=async file=>{
    if(!file)return;
    const name=String(file.name||'').toLowerCase();
    if(name.endsWith('.json')||file.type==='application/json'){await importJsonFile(file);return;}
    if(name.endsWith('.css')||file.type==='text/css'){await importCssFile(file);return;}
    sErr('Unsupported file. Drop an MV System Bundle, JSON token export, or CSS file.');
  };
  const doImport=async e=>{const file=e.target.files?.[0];if(file)await importJsonFile(file);e.target.value='';};
  const readCssFile=async e=>{const file=e.target.files?.[0];if(file)await importCssFile(file);e.target.value='';};
  const dragEnter=e=>{if(!Array.from(e.dataTransfer?.types||[]).includes('Files'))return;e.preventDefault();dropDepthRef.current++;sDropActive(true);};
  const dragOver=e=>{if(!Array.from(e.dataTransfer?.types||[]).includes('Files'))return;e.preventDefault();e.dataTransfer.dropEffect='copy';sDropActive(true);};
  const dragLeave=e=>{e.preventDefault();dropDepthRef.current=Math.max(0,dropDepthRef.current-1);if(dropDepthRef.current===0)sDropActive(false);};
  const dropFile=async e=>{e.preventDefault();dropDepthRef.current=0;sDropActive(false);await importDroppedFile(e.dataTransfer?.files?.[0]);};
  const previewCssImport=async()=>{const vars=parseCssVariables(cssText);sCssCount(vars.length);if(!vars.length){sErr('No CSS custom properties found. Use declarations like --color-primary: #baf400;');return;}sImportFormat('css');sLd(true);sErr('');const res=await api.p('sync/preview',vars);if(res?.code){sErr(res.message||'CSS import preview failed');sLd(false);return;}sImportMode('tokens');sBundlePayload(null);sDiff(res.changes||[]);sSummary(res.summary||{});sView('preview');sLd(false);};
  const isDeleteAction=action=>action==='delete'||String(action||'').endsWith('_delete');
  const isExecutableImportChange=c=>c?.action!=='protected_update'&&(!skipDel||!isDeleteAction(c?.action));
  const executableImportCount=(diff||[]).filter(isExecutableImportChange).length;
  const applyImport=async()=>{if(!diff)return;sConfirmImportDeletes(false);sLd(true);sErr('');let res;if(importMode==='system'){res=await api.p('sync/apply-bundle',{bundle:bundlePayload,skip_deletes:skipDel});}else{const filtered=diff.filter(isExecutableImportChange);res=await api.p('sync/apply',{changes:filtered,skip_deletes:skipDel,file_name:importFileName||'Pasted token import',import_format:importFormat||'json',import_source:'file',snapshot_title:'Before importing '+(importFileName||'pasted variables'),snapshot_description:'Recovery point created before applying '+filtered.length+' reviewed '+String(importFormat||'file').toUpperCase()+' change'+(filtered.length===1?'':'s')+'.'});}sLd(false);if(res?.errors?.length){sErr((res.rolled_back?'No changes were kept. ':'')+res.errors.join('; '));return;}if(res?.applied>0){if(res.snapshot_id)sPM('Imported safely · snapshot #'+res.snapshot_id+' is ready to restore.');onDone();}else sView('main');};
  const doApply=()=>{if(!diff)return;const deleteCount=diff.filter(c=>isDeleteAction(c.action)).length;if(!skipDel&&deleteCount){sConfirmImportDeletes(true);return;}applyImport();};
  const doSnap=async()=>{sLd(true);sErr('');const res=await api.p('sync/snapshot',{title:snapshotTitle.trim()||'Manual backup',description:snapshotDescription.trim()});sLd(false);if(res?.code){sErr(res.message||'Snapshot could not be created');return false;}else{sSnapshotTitle('');sSnapshotDescription('');await loadSnaps();return true;}};
  const loadSnaps=async()=>{const s=await api.g('sync/snapshots');if(Array.isArray(s))sSnaps(s);};
  const doRollback=async(id)=>{sLd(true);sErr('');const res=await api.p('sync/rollback/'+id,{});sLd(false);if(res?.restored)onDone();else sErr(res?.message||'Rollback failed');};
  useEffect(()=>{if(view==='snapshots')loadSnaps();},[view]);
  const loadDrift=async source=>{
    const next=source||driftSource;
    sLd(true);sErr('');sDriftMsg('');sDriftPlan(null);
    const data=await api.g('sync/drift?source='+encodeURIComponent(next));
    sLd(false);
    if(data?.code){sErr(data.message||'Could not inspect Sync Drift');return;}
    sDriftData(data);
    sDriftKeys((data.rows||[]).filter(row=>row.status!=='in_sync').map(row=>String(row.key)));
  };
  const chooseDriftSource=source=>{sDriftSource(source);loadDrift(source);};
  const toggleDriftKey=key=>sDriftKeys(previous=>previous.includes(String(key))?previous.filter(item=>item!==String(key)):[...previous,String(key)]);
  const previewDrift=async direction=>{
    sLd(true);sErr('');sDriftMsg('');
    const plan=await api.p('sync/drift/preview',{source:driftSource,direction,keys:driftKeys});
    sLd(false);
    if(plan?.code){sErr(plan.message||'Could not prepare Sync Drift');return;}
    sDriftPlan(plan);
  };
  const applyDrift=async()=>{
    if(!driftPlan)return;
    sLd(true);sErr('');
    const result=await api.p('sync/drift/apply',{source:driftSource,direction:driftPlan.direction,keys:driftKeys});
    sLd(false);
    if(result?.errors?.length){sErr(result.errors.join('; '));return;}
    const message=result?.queued?(result.message||'Push queued. Open the paired Figma plugin to finish it.'):(result?.applied||0)+' drift change'+(Number(result?.applied||0)===1?'':'s')+' applied.';
    sDriftPlan(null);
    await loadDrift(driftSource);
    sDriftMsg(message);
    onReload&&onReload();
  };
  useEffect(()=>{if(view==='drift')loadDrift(driftSource);},[view]);

  const AC={add:'#22c55e',update:'#3b82f6',protected_update:'#d6a34a',delete:'#ef4444',type_change:'#f59e0b',relationship_change:'#f59e0b',repair_generated:'#a78bfa',generator_add:'#22c55e',generator_update:'#3b82f6',generator_delete:'#ef4444',themes_update:'#a78bfa',palette_add:'#22c55e',palette_update:'#3b82f6',palette_delete:'#ef4444',category_add:'#22c55e',category_update:'#3b82f6',category_delete:'#ef4444'};
  const AL={add:'ADD',update:'UPD',protected_update:'LOCK',delete:'DEL',type_change:'TYPE',relationship_change:'LINK',repair_generated:'FIX',generator_add:'GEN+',generator_update:'GEN',generator_delete:'GEN-',themes_update:'THEME',palette_add:'PAL+',palette_update:'PAL',palette_delete:'PAL-',category_add:'CAT+',category_update:'CAT',category_delete:'CAT-'};
  const blockedImportCount=(diff||[]).filter(c=>c.action==='type_change').length;
  const changeDetail=c=>{
    if(c.action==='update')return 'value: '+String(c.old_value??'')+' → '+String(c.new_value??'');
    if(c.action==='protected_update')return 'calculated family: edit its base variable or generator settings';
    if(c.action==='relationship_change')return String(c.old_source_name||'none')+' → '+String(c.source_name||'none');
    if(c.action==='type_change')return String(c.old_type||'base')+' → '+String(c.new_type||'base');
    if(c.action==='repair_generated')return 'source: '+String(c.source_name||c.base_name||'generated base');
    if(c.action.indexOf('generator_')===0)return 'generator configuration';
    if(c.action.indexOf('palette_')===0)return 'Color Palette definition or membership';
    if(c.action.indexOf('category_')===0)return 'Variable category definition or membership';
    if(c.action==='themes_update')return 'Theme values or active Theme';
    return '';
  };

  if(view==='preview')return h(Sub,{title:importMode==='system'?'System Bundle Preview':'Import Preview',onClose,exiting},
    importMode==='system'&&h('div',{class:'ve-warn',style:'margin-bottom:8px;color:#baf400'},'Portable system update: variables, generated children, aliases, Themes, Color Palettes, memberships, ordering, and CSS are recovered together if any phase fails.'),
    summary&&h('div',{style:'display:flex;gap:8px;margin-bottom:8px;flex-wrap:wrap'},summary.added>0&&h('span',{style:'font-size:11px;color:#22c55e'},'+'+summary.added+' new'),summary.updated>0&&h('span',{style:'font-size:11px;color:#3b82f6'},'~'+summary.updated+' changed'),summary.protected>0&&h('span',{style:'font-size:11px;color:#d6a34a'},summary.protected+' calculated values protected'),summary.deleted>0&&h('span',{style:'font-size:11px;color:#ef4444'},'-'+summary.deleted+' removed'),summary.repaired>0&&h('span',{style:'font-size:11px;color:#a78bfa'},summary.repaired+' relationship repairs'),summary.type_changed>0&&h('span',{style:'font-size:11px;color:#f59e0b'},summary.type_changed+' type reviews'),summary.relationship_changed>0&&h('span',{style:'font-size:11px;color:#f59e0b'},summary.relationship_changed+' source reviews'),summary.system_changed>0&&h('span',{style:'font-size:11px;color:#a78bfa'},summary.system_changed+' system changes')),
    h('div',{style:'max-height:260px;overflow-y:auto;margin-bottom:8px;padding-right:4px'},(diff||[]).map((c,i)=>h('div',{key:i,class:'ve-import-change'},h('span',{class:'ve-import-change-tag',style:`color:${AC[c.action]||'#888'}`},AL[c.action]||c.action),h('span',{class:'ve-import-change-name'},c.name),changeDetail(c)&&h('span',{class:'ve-import-change-detail',style:c.action==='relationship_change'?'color:#d6a34a':''},changeDetail(c))))),
    (diff||[]).some(c=>c.action==='relationship_change')&&h('div',{class:'ve-warn',style:'margin-bottom:8px;color:#d6a34a'},'Alias and generated source changes are shown as LINK and will be applied transactionally with the rest of the import.'),
    (diff||[]).some(c=>c.action==='protected_update')&&h('div',{class:'ve-warn',style:'margin-bottom:8px;color:#d6a34a'},'LOCK rows belong to calculated MV generator families. They are shown for transparency and safely skipped; change their base variable or generator settings instead.'),
    blockedImportCount>0&&h('div',{class:'ve-warn',style:'margin-bottom:8px'},blockedImportCount+' variable type change'+(blockedImportCount===1?' requires':'s require')+' manual review before this import can be applied.'),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:4px 0'},err),
    h('div',{class:'ve-opt',style:'margin-top:4px'},h('label',null,h('input',{type:'checkbox',checked:skipDel,onChange:e=>sSD(e.target.checked)}),'Skip deletions')),
    h('div',{style:'display:flex;gap:5px;margin-top:8px;justify-content:flex-end'},h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sView('main')},'Back'),h('button',{class:'ve-btn ve-btn-s',onClick:doApply,disabled:ld||executableImportCount<1||blockedImportCount>0},ld?'Applying...':(executableImportCount>0?'Apply '+executableImportCount+' changes':'No changes to apply'))),
    confirmImportDeletes&&h(ConfirmModal,{title:'Apply destructive import',body:'This import will remove '+(diff||[]).filter(c=>isDeleteAction(c.action)).length+' destination items. A complete safety snapshot will be created first. Continue?',confirmText:'Apply & Delete',danger:true,onCancel:()=>sConfirmImportDeletes(false),onConfirm:applyImport}));

  if(view==='snapshots')return h(Sub,{title:'Snapshots',onClose,onBack:snapshotsOnly?onClose:()=>sView('main'),exiting},
    h('div',{style:'display:flex;flex-direction:column;min-height:100%;gap:12px'},
      h('button',{class:'ve-btn ve-btn-s',style:'margin-bottom:4px;width:100%',onClick:()=>sShowCreateModal(true)},'+ New Snapshot'),
      snaps.length===0?h('div',{class:'ve-empty',style:'flex:1'},'No snapshots yet'):h('div',{style:'flex:1;min-height:0;overflow-y:auto;padding-right:4px'},snaps.map(s=>h('div',{key:s.id,class:'ve-snapshot-card'},
        h('div',{style:'min-width:0'},
          h('div',{class:'ve-snapshot-title'},s.title||s.trigger_label||s.trigger_type||'Snapshot'),
          h('div',{class:'ve-snapshot-description'},s.description||'Complete variable-system recovery point.'),
          h('div',{class:'ve-snapshot-meta'},
            h('span',null,'Snapshot #'+s.id),
            h('span',null,s.created_at),
            s.file_name&&h('span',{class:'ve-snapshot-file',title:s.file_name},s.file_name),
            s.change_count>0&&h('span',null,s.change_count+' reviewed changes')),
          s.restorable===false&&h('div',{style:'color:#d6a34a;font-size:11px;line-height:1.45;margin-top:4px'},s.restore_warning||'Legacy snapshot cannot be restored safely.')),
        h('button',{class:'ve-btn '+(s.restorable===false?'ve-btn-g':'')+' ve-btn-s',title:s.restorable===false?(s.restore_warning||'Legacy snapshot cannot be restored safely.'):'Restore this complete variable state',onClick:()=>doRollback(s.id),disabled:ld||s.restorable===false},s.restorable===false?'Unavailable':'Restore')))),
      err&&h('div',{style:'font-size:11px;color:#ef4444;padding:4px 0'},err),
      h('div',{style:'display:flex;gap:5px;margin-top:auto'},h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:snapshotsOnly?onClose:()=>sView('main')},'Back'))),
    showCreateModal&&h('div',{class:'ve-modal'},
      h('div',{class:'ve-modal-box'},
        h('div',{class:'ve-modal-title',style:'display:flex;align-items:center;gap:7px'},ph('clock-counter-clockwise'),'Create recovery point'),
        h('div',{class:'ve-modal-body',style:'margin:12px 0 0 0'},
          h('input',{class:'ve-studio-input',value:snapshotTitle,onInput:e=>sSnapshotTitle(e.target.value),placeholder:'Snapshot title, e.g. Before homepage redesign',style:'width:100%;margin-bottom:8px'}),
          h('textarea',{class:'ve-studio-input',value:snapshotDescription,onInput:e=>sSnapshotDescription(e.target.value),placeholder:'Optional note about what this snapshot protects',style:'width:100%;margin-bottom:8px;min-height:58px;resize:vertical'})
        ),
        h('div',{class:'ve-modal-actions'},
          h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>{sShowCreateModal(false);sSnapshotTitle('');sSnapshotDescription('');},disabled:ld},'Cancel'),
          h('button',{class:'ve-btn ve-btn-s',onClick:async()=>{const ok=await doSnap();if(ok)sShowCreateModal(false);},disabled:ld},ld?'Creating...':'Create')
        )
      )
    )
  );



  if(view==='drift')return h(Sub,{title:'Sync Drift',onClose,onBack:()=>sView('main'),exiting},
    h('div',{class:'ve-drift-head'},
      h('div',{style:'display:flex;align-items:center;gap:8px'},h('span',{style:'color:#baf400'},ph('arrows-left-right')),h('div',null,
        h('div',{style:'font-size:11px;color:#ddd;font-weight:650'},'Compare MV with a connected consumer'),
        h('div',{style:'font-size:11px;color:#777;line-height:1.45;margin-top:2px'},'Pull uses Import Preview and a safety snapshot. Push uses the paired Figma companion or the Bricks adapter.'))),
      h('div',{style:'display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:10px'},
        h('button',{class:'ve-btn '+(driftSource==='figma'?'':'ve-btn-g'),onClick:()=>chooseDriftSource('figma')},'Figma'),
        h('button',{class:'ve-btn '+(driftSource==='bricks'?'':'ve-btn-g'),onClick:()=>chooseDriftSource('bricks')},'Bricks')),
      driftData&&h('div',{class:'ve-drift-summary'},
        h('div',{class:'ve-drift-stat'},h('b',null,driftData.summary?.in_sync||0),h('span',null,'In sync')),
        h('div',{class:'ve-drift-stat'},h('b',null,(driftData.summary?.changed||0)+(driftData.summary?.missing_mv||0)+(driftData.summary?.missing_source||0)),h('span',null,'Different')),
        h('div',{class:'ve-drift-stat'},h('b',null,driftData.summary?.conflict||0),h('span',null,'Conflicts'))),
      driftData?.reported_at&&h('div',{style:'font-size:11px;color:#5f5f5f;margin-top:7px'},driftSource==='figma'?'Last Figma report: '+driftData.reported_at:'Live Bricks registry comparison'),
      driftSource==='figma'&&Number(driftData?.age_seconds||0)>60&&h('div',{style:'font-size:11px;color:#d6a34a;line-height:1.45;margin-top:4px'},'This Figma report is older than one minute. Open the paired companion or Check again before resolving conflicts.')),
    !ld&&driftData&&!driftData.available&&h('div',{class:'ve-warn',style:'margin-bottom:9px'},driftSource==='figma'?'Open the paired Figma plugin and select a collection so it can publish a current variable report.':'Bricks global variables are not available on this site.'),
    driftData&&h('div',{style:'display:flex;align-items:center;justify-content:space-between;margin-bottom:7px'},
      h('label',{style:'display:flex;align-items:center;gap:6px;font-size:11px;color:#888'},h('input',{class:'ve-var-check',type:'checkbox',checked:(driftData.rows||[]).filter(row=>row.status!=='in_sync').length>0&&(driftData.rows||[]).filter(row=>row.status!=='in_sync').every(row=>driftKeys.includes(String(row.key))),onChange:e=>sDriftKeys(e.target.checked?(driftData.rows||[]).filter(row=>row.status!=='in_sync').map(row=>String(row.key)):[])}),'Select all differences'),
      h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>loadDrift(driftSource),disabled:ld},ld?'Checking...':'Check again')),
    driftData&&h('div',{class:'ve-drift-list'},(driftData.rows||[]).filter(row=>row.status!=='in_sync').length===0
      ?h('div',{class:'ve-empty'},'No drift detected.')
      :(driftData.rows||[]).filter(row=>row.status!=='in_sync').map(row=>h('div',{class:'ve-drift-row',key:row.key},
        h('input',{class:'ve-var-check',type:'checkbox',checked:driftKeys.includes(String(row.key)),onChange:()=>toggleDriftKey(row.key)}),
        h('div',null,h('div',{class:'ve-drift-name'},'--'+row.public_name),h('div',{class:'ve-drift-values'},'MV: '+(row.mv?.value??'Missing'),h('br'),(driftData.source_label||'Source')+': '+(row.source?.value??'Missing'))),
        h('span',{class:'ve-drift-status '+row.status},String(row.status||'changed').replace(/_/g,' '))))),
    driftPlan&&h('div',{class:'ve-warn',style:'margin-top:9px;color:#ddd'},
      h('div',{style:'font-weight:650;color:#baf400;margin-bottom:4px'},(driftPlan.direction==='pull'?'Pull into MV':'Push to '+(driftData?.source_label||driftSource))+' · '+(driftPlan.count||0)+' change'+(Number(driftPlan.count||0)===1?'':'s')),
      h('div',{style:'line-height:1.5;color:#888'},driftPlan.direction==='pull'?'Values from the selected source will enter the normal import transaction. A named snapshot is created before Apply.':(driftSource==='figma'?'The push is queued for the paired Figma companion and applies when that plugin is open.':'The Bricks adapter will refresh its MV-owned variable mirror.'))),
    driftMsg&&h('div',{class:'ve-warn',style:'margin-top:9px;color:#baf400'},driftMsg),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:8px 0'},err),
    h('div',{class:'ve-drift-actions'},
      h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sView('main')},'Back'),
      !driftPlan&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',disabled:ld||driftKeys.length<1,onClick:()=>previewDrift('pull')},'Preview Pull'),
      !driftPlan&&h('button',{class:'ve-btn ve-btn-s',disabled:ld||driftKeys.length<1,onClick:()=>previewDrift('push')},'Preview Push'),
      driftPlan&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sDriftPlan(null),disabled:ld},'Change plan'),
      driftPlan&&h('button',{class:'ve-btn ve-btn-s',onClick:applyDrift,disabled:ld||driftPlan.count<1},ld?'Applying...':'Apply resolution')));

  return h(Sub,{title:'Sync',onClose,exiting},
    /* Figma Connection */
    h('div',{style:'margin-bottom:12px'},
      h('div',{style:'font-size:11px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Figma Connection'),
      pair?.paired?h('div',null,
        h('div',{style:'font-size:11px;color:#baf400;margin-bottom:4px'},'✓ Connected'),
        h('div',{style:'display:flex;align-items:flex-start;gap:6px;font-size:11px;color:#ddd;margin-bottom:4px;font-family:monospace'},ph('file'),h('span',null,pair.figma_name||'Figma file not captured yet — open the Figma plugin once to update this.')),
        pair.collection_name&&h('div',{style:'display:flex;align-items:flex-start;gap:6px;font-size:11px;color:#888;margin-bottom:4px;font-family:monospace'},ph('stack'),h('span',null,'Collection: '+pair.collection_name)),
        h('div',{style:'font-size:11px;color:#555;margin-bottom:6px'},'Source: '+(pair.source==='figma'?'Figma':'WordPress')),
        h('button',{class:'ve-btn ve-btn-d ve-btn-s',onClick:disc},'Disconnect'))
      :h('div',null,
        h('div',{style:'font-size:11px;color:#555;margin-bottom:6px'},'Generate credentials for your Figma plugin:'),
        h('button',{class:'ve-btn ve-btn-s',onClick:genCode,style:'margin-bottom:6px'},'Generate Pairing Credentials'),
        pCode&&h('div',{style:'background:#2a2a2a;border-radius:6px;padding:10px;margin:6px 0'},
          h('div',{style:'font-size:11px;color:#555;text-transform:uppercase;margin-bottom:2px'},'Pairing Code'),
          h('div',{style:'font-size:22px;font-weight:800;letter-spacing:4px;text-align:center;font-family:monospace;color:#baf400'},pCode),
          pKey&&h('div',null,
            h('div',{style:'font-size:11px;color:#555;text-transform:uppercase;margin-top:8px;margin-bottom:2px'},'API Key'),
            h('div',{style:'font-size:11px;font-family:monospace;color:#888;word-break:break-all;cursor:pointer;padding:4px;background:#1f1f1f;border-radius:3px',onClick:()=>{navigator.clipboard?.writeText(pKey);sPM('Copied!');}},pKey),
            h('div',{style:'font-size:11px;color:#555;text-align:center;margin-top:4px'},'Click key to copy. Enter both in Figma plugin.'))),
        h('div',{style:'font-size:11px;color:#555;margin:8px 0 4px'},'Or enter a code from Figma:'),
        h('div',{style:'display:flex;gap:4px'},
          h('input',{style:'flex:1;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:13px;font-family:monospace;text-align:center;letter-spacing:2px;text-transform:uppercase;outline:none',maxLength:6,value:figCode,onInput:e=>sFC(e.target.value.toUpperCase()),placeholder:'ABC123'}),
          h('button',{class:'ve-btn ve-btn-s',onClick:submitFigCode},'Pair')),
        pMsg&&h('div',{style:'font-size:11px;color:'+(pMsg.includes('Paired')||pMsg.includes('Copied')?'#baf400':'#ef4444')+';padding:4px 0'},pMsg))),
    /* Database Cleanup */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'display:flex;align-items:center;justify-content:space-between;gap:8px'},
        h('div',null,h('div',{style:'font-size:11px;color:#ddd;font-weight:650'},'Sync Drift'),h('div',{style:'font-size:11px;color:#666;line-height:1.45;margin-top:2px'},'Compare MV with Figma or Bricks, then preview Pull or Push before resolving differences.')),
        h('button',{class:'ve-btn ve-btn-s',onClick:()=>sView('drift')},ph('arrows-left-right'),'Open'))),
    /* Database Cleanup & Languages */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:11px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'WordPress Database'),
      stats?h('div',null,
        h('div',{style:'font-size:11px;color:#ddd;margin-bottom:4px'},(stats.base||0)+' base · '+(stats.generated||0)+' generated · '+(stats.total||0)+' raw'),
        statIssues.length?h('div',{style:'font-size:11px;color:#f59e0b;margin-bottom:6px'},statIssues.join(', ')):h('div',{style:'font-size:11px;color:#555;margin-bottom:6px'},'No cleanup issues detected'),
        h('div',{style:'display:flex;gap:4px;flex-wrap:wrap'},h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sConfirmClean(true),disabled:cleaning},cleaning?'Cleaning...':'Clean WP DB'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:loadDiagnostics},diag?'Hide Diagnostics':'View Diagnostic Logs')),
        diag&&h('div',{style:'margin-top:8px;padding:8px;background:rgba(255,255,255,.035);border:1px solid rgba(255,255,255,.08);border-radius:8px;font-size:11px;color:#aaa;line-height:1.5;max-height:120px;overflow:auto;font-family:"SF Mono","Fira Code",monospace;white-space:pre-wrap'},(diag.entries||[]).length?(diag.entries||[]).map(x=>(x.time||'')+' '+(x.level||'')+' '+(x.event||x.raw||'')).join('\n'):'No diagnostic entries yet',h('div',{style:'color:#555;margin-top:4px;word-break:break-all'},diag.path||'')))
      :h('div',{style:'font-size:11px;color:#555'},'Loading stats...'),
      ),
    /* Export */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:11px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Export'),
      h('div',{style:'display:flex;gap:4px;flex-wrap:wrap'},h('button',{class:'ve-btn ve-btn-s',onClick:doExportBundle,disabled:ld},'System Bundle'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>doExport('dtcg'),disabled:ld},'DTCG'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>doExport('flat'),disabled:ld},'Flat'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>doExport('figma'),disabled:ld},'Figma'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:doExportCss,disabled:ld},'CSS')),
      h('div',{style:'font-size:11px;color:#555;padding:4px 0;line-height:1.5'},'System Bundle is the complete portable backup/update format. DTCG, Flat, Figma, and CSS remain interoperability exports.')),
    /* Import */
    h('div',{style:'margin-bottom:12px;padding-top:10px;border-top:1px solid #2a2a2a'},
      h('div',{style:'font-size:11px;color:#888;margin-bottom:6px;text-transform:uppercase;letter-spacing:.4px;font-weight:600'},'Import'),
      h('input',{ref:fileRef,type:'file',accept:'.json',style:'display:none',onChange:doImport}),
      h('input',{ref:cssFileRef,type:'file',accept:'.css,text/css',style:'display:none',onChange:readCssFile}),
      h('div',{class:'ve-import-help'},'Upload an MV System Bundle for a complete site-to-site update, or import DTCG, Flat, Figma, and CSS token files. Every import opens a preview before anything changes.'),
      h('div',{class:'ve-import-drop'+(dropActive?' active':''),onDragEnter:dragEnter,onDragOver:dragOver,onDragLeave:dragLeave,onDrop:dropFile},
        h('div',{class:'ve-import-drop-overlay'},ph('upload-simple'),h('span',null,'Drop file here'),h('small',null,'MV System Bundle, token JSON, or CSS variables')),
        h('div',{class:'ve-import-drop-content'},
          h('div',{style:'display:flex;gap:4px;flex-wrap:wrap;margin-bottom:8px'},h('button',{class:'ve-btn ve-btn-s',onClick:()=>fileRef.current?.click(),disabled:ld},ld?'Reading...':'Upload JSON'),h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>cssFileRef.current?.click(),disabled:ld},'Upload CSS')),
          h('textarea',{value:cssText,onInput:e=>{sCssText(e.target.value);sCssCount(parseCssVariables(e.target.value).length);sImportFileName('');},placeholder:'Or paste CSS variables here, e.g. :root { --color-primary: #baf400; --space-20: 20px; }',style:'width:100%;min-height:96px;padding:9px 11px;background:rgba(255,255,255,.055);border:1px solid rgba(255,255,255,.10);border-radius:8px;color:#f1f1f1;font-size:11px;font-family:"SF Mono","Fira Code",monospace;outline:none;resize:vertical;line-height:1.55;margin-bottom:6px'}),
          h('div',{style:'display:flex;align-items:center;justify-content:space-between;gap:8px'},h('span',{style:'font-size:11px;color:#777;overflow:hidden;text-overflow:ellipsis;white-space:nowrap'},importFileName?(importFileName+(cssCount?' · '+cssCount+' variables':'')):(cssCount?cssCount+' CSS variables detected':'Drag a compatible file here')),h('button',{class:'ve-btn ve-btn-s',onClick:previewCssImport,disabled:ld||!cssText.trim()},'Preview CSS Import'))))),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:8px 0'},err),
    confirmClean&&h(ConfirmModal,{title:'Clean WordPress DB',body:'Clean duplicate, stale, and orphan generated variables from WordPress? This keeps base variables and rebuilds recoverable generated variants.',confirmText:'Clean',onCancel:()=>sConfirmClean(false),onConfirm:cleanDb}));
}

/* ── Variable reference autocomplete ──── */
function VarRefInput({value,onInput,vars,placeholder,onKeyDown}){
  const[show,sShow]=useState(false);
  const[q,sQ]=useState('');
  const[idx,sIdx]=useState(0);
  const ref=useRef();

  const matches=useMemo(()=>{
    if(show){
      if(!q)return vars.slice(0,10);
      const qLower=q.toLowerCase();
      return vars.filter(v=>{
        const dotName=(v.name||'').toLowerCase();
        const cssName=cssTokenName(v.name).toLowerCase();
        return dotName.includes(qLower)||cssName.includes(qLower);
      }).slice(0,10);
    }
    return [];
  },[show,q,vars]);

  const handleInput=e=>{
    const val=e.target.value;
    onInput(e);
    const cur=val.slice(0,e.target.selectionStart||val.length);
    const m=cur.match(/(?:var\(--|var\(|--)([a-z0-9.-]*)$/i);
    if(m){
      sQ(m[1].replace(/-/g,'.'));
      sShow(true);
      sIdx(0);
    }
    else{sShow(false);sQ('');}
  };

  const insert=(v)=>{
    const el=ref.current;if(!el)return;
    const val=el.value;
    const pos=el.selectionStart||val.length;
    const before=val.slice(0,pos);
    const after=val.slice(pos);
    const m=before.match(/(?:var\(--|var\(|--)[a-z0-9.-]*$/i);
    if(m){
      const cssName=cssTokenName(v.name);
      const newBefore=before.slice(0,before.length-m[0].length)+'var('+cssName+')';
      const nv=newBefore+after;
      onInput({target:{value:nv}});
      sShow(false);sQ('');
      setTimeout(()=>{el.focus();el.selectionStart=el.selectionEnd=newBefore.length;},10);
    }
  };

  const handleKey=e=>{
    if(show&&matches.length){
      if(e.key==='ArrowDown'){e.preventDefault();sIdx(i=>(i+1)%matches.length);}
      else if(e.key==='ArrowUp'){e.preventDefault();sIdx(i=>(i-1+matches.length)%matches.length);}
      else if(e.key==='Enter'&&matches[idx]){e.preventDefault();insert(matches[idx]);}
      else if(e.key==='Tab'&&matches[idx]){e.preventDefault();insert(matches[idx]);}
      else if(e.key==='Escape'){sShow(false);}
    }
    if(onKeyDown)onKeyDown(e);
  };

  return h('div',{class:'ve-ac-wrap'},
    h('input',{ref,placeholder,value,onInput:handleInput,onKeyDown:handleKey,onBlur:()=>setTimeout(()=>sShow(false),150),style:'width:100%;padding:5px 8px;background:#2a2a2a;border:1px solid #333;border-radius:4px;color:#f1f1f1;font-size:11px;outline:none;font-family:monospace'}),
    show&&matches.length>0&&h('div',{class:'ve-ac'},
      matches.map((v,i)=>{
        const resVal = resolvedVariableValue(v, vars);
        return h('div',{class:'ve-ac-i'+(i===idx?' sel':''),onMouseDown:e=>{e.preventDefault();insert(v);},key:v.id},
          h('div',{class:'ve-ac-sw',style:isClr(resVal)?`background:${resVal};border-color:transparent`:''}),
          h('span',null,cssTokenName(v.name)),
          h('span',{style:'color:#444;margin-left:auto;font-size:11px'},v.type==='alias'?v.css_value:v.value));
      })));
}

/* ── Create sub-panel ─────────────────── */
function CreateSub({onCreated,onClose,categories,vars,exiting,palettes,paletteId,initialCategory}){
  const[mode,sMode]=useState('color');
  const[cat,sCat]=useState(initialCategory&&initialCategory!=='color'&&initialCategory!=='all'?initialCategory:'uncategorized');
  const[nm,sNm]=useState('');const[val,sVal]=useState('');
  const[fMin,sFMin]=useState('');const[fMax,sFMax]=useState('');
  const[hex,sHex]=useState('#baf400');const[fmt,sFmt]=useState('oklch');
  const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const[selectedPalette,sSelectedPalette]=useState(paletteId&&paletteId!=='all'?String(paletteId):((palettes||[]).length===1?String(palettes[0].id):''));
  const fullNm=nm;

  const create=async()=>{
    if(!nm)return;sLd(true);sErr('');
    let fv;
    if(mode==='color')fv=hexOklch(hex);
    else if(mode==='fluid')fv=fluidMarker(fMin,fMax);
    else if(mode==='clamp')fv=val?(val.match(/\d/)?pxToRemValue(val):val):'10px';
    else fv=val;
    if(!fv){sLd(false);sErr(mode==='fluid'?'Enter both a min and max value.':'');return;}
    const payload={name:fullNm,value:fv,category_slug:mode==='color'?'uncategorized':cat};
    if(mode==='color'){
      if(!selectedPalette){sLd(false);sErr('Choose a palette for this color.');return;}
      payload.palette_id=Number(selectedPalette);
    }
    if(mode==='static'){
      const sourceId = detectAliasSource(fv, vars);
      if(sourceId){
        payload.type='alias';
        payload.source_id=Number(sourceId);
      }
    }
    const r=await api.p('variables',payload);
    sLd(false);
    if(r?.code==='ve_duplicate'){sErr(r.message||'A variable with this name already exists.');return;}
    if(r?.code){sErr(r.message||'Failed to create variable.');return;}
    if(r?.id)onCreated(r);
  };

  const catOpts=(categories||[]).map(c=>({value:c.slug,label:c.name}));

  return h(Sub,{title:'New Variable',onClose,exiting},
    h('div',{class:'ve-mode'},
      h('button',{class:mode==='color'?'on':'',onClick:()=>sMode('color')},'Color'),
      h('button',{class:mode==='clamp'?'on':'',onClick:()=>sMode('clamp')},'Fixed'),
      h('button',{class:mode==='fluid'?'on':'',onClick:()=>sMode('fluid')},'Fluid'),
      h('button',{class:mode==='static'?'on':'',onClick:()=>sMode('static')},'Static')),
    mode==='color'&&h('div',{class:'ve-opt ve-opt-stack',style:'padding-top:0'},
      h('span',null,'Palette'),
      (palettes||[]).length
        ? h(SelectMenu,{value:selectedPalette,onChange:sSelectedPalette,options:[{value:'',label:'Choose palette'},...(palettes||[]).map(p=>({value:String(p.id),label:p.name}))]})
        : h('div',{class:'ve-warn',style:'margin:0;font-size:11px'},'Create a palette before creating Color variables.')),
    mode!=='color'&&h('div',{class:'ve-opt ve-opt-stack',style:'padding-top:0'},
      h('span',null,'Category'),
      h(SelectMenu,{value:cat,onChange:sCat,options:catOpts})),
    h('div',{class:'ve-row'},h('input',{placeholder:mode==='color'?'e.g. accent, free-test':'e.g. 20, heading-58, gap-20',value:nm,onInput:e=>{sNm(normalizeNameInput(e.target.value));if(err)sErr('');},onKeyDown:e=>e.key==='Enter'&&create(),style:'flex:1'})),
    nm&&h('div',{style:'font-size:11px;color:#444;padding:0 0 6px;font-family:monospace'},publicTokenLabel(fullNm)),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:2px 0 6px'},err),
    mode==='color'&&h('div',{class:'ve-row'},h(MVColorPicker,{hex,onChange:sHex,fmt,setFmt:sFmt})),
    mode==='clamp'&&h('div',null,
      h('div',{class:'ve-row'},h('input',{placeholder:'Base value (number, stored as rem)',value:val,onInput:e=>{const v=e.target.value.replace(/[^0-9.]/g,'');sVal(v);},style:'flex:1'})),
      h('div',{style:'font-size:11px;color:#555;padding:0 0 6px'},'Numbers are px references — stored as rem using 10px = 10px. Example: 20 → 20px.')),
    mode==='fluid'&&h('div',null,
      h('div',{class:'ve-row',style:'gap:6px'},
        h('input',{placeholder:'Min px',value:fMin,onInput:e=>{sFMin(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'}),
        h('input',{placeholder:'Max px',value:fMax,onInput:e=>{sFMax(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'})),
      fMin&&fMax&&h('div',{style:'font-size:11px;color:#baf400;padding:0 0 4px;font-family:monospace;word-break:break-all'},fluidPreview(fMin,fMax)),
      h('div',{style:'font-size:11px;color:#555;padding:0 0 6px'},'Scales smoothly between the page min and max viewport widths (set in Settings). Min/max are px values.')),
    mode==='static'&&h('div',{class:'ve-row'},
      h(VarRefInput,{placeholder:'e.g. 0 4px 12px rgba(0,0,0,.1) or var(--...',value:val,onInput:e=>sVal(typeof e.target==='object'?e.target.value:e),vars:vars||[],onKeyDown:e=>e.key==='Enter'&&create()})),
    h('div',{style:'display:flex;gap:5px;justify-content:flex-end;margin-top:4px'},
      h('button',{class:'ve-btn',onClick:create,disabled:ld||!nm||(mode==='color'&&!selectedPalette)||(mode==='clamp'&&!val)||(mode==='static'&&!val)||(mode==='fluid'&&(!fMin||!fMax))},ld?'...':'Create')));
}

/* ── Edit sub-panel (same as create, pre-filled) ── */
function EditSub({variable,onDone,onClose,categories,vars,onNavigateUsage,exiting}){
  const resolvedVal=resolvedVariableValue(variable, vars);
  const isClrV=isClr(resolvedVal);
  const isFluidV=isFluidVal(variable.value);
  const initMode=variable.type==='alias'?'static':(isClrV?'color':(isFluidV?'fluid':((variable.value||'').includes('clamp')?'clamp':'static')));
  const initCat=variable.category_slug||'uncategorized';
  const initNm=normalizeNameInput(variable.name);
  const initFluid=isFluidV?parseFluid(variable.value):null;

  const[mode,sMode]=useState(initMode);
  const[cat,sCat]=useState(initCat);
  const[nm,sNm]=useState(initNm);const[val,sVal]=useState(variable.type==='alias'?variable.css_value:(variable.value||''));
  const[fMin,sFMin]=useState(initFluid?String(initFluid[0]):'');const[fMax,sFMax]=useState(initFluid?String(initFluid[1]):'');
  const[hex,sHex]=useState(isClrV?clrToHex(resolvedVal):'#baf400');const[fmt,sFmt]=useState('oklch');
  const[ld,sLd]=useState(false);const[err,sErr]=useState('');
  const[prop,sProp]=useState(false);const[impact,sImpact]=useState(null);const[checking,sChecking]=useState(false);

  useEffect(()=>{
    if(mode!=='color'||!hex)return;
    applyVariablePreview(variable.name,hexOklch(hex));
    return()=>clearVariablePreview(variable.name);
  },[mode,hex,variable.name]);
  const fullNm=nm;
  const nameChanged=fullNm&&cssTokenName(fullNm)!==cssTokenName(variable.name);
  const proposedSourceId=mode==='static'?detectAliasSource(val,vars):null;
  const proposedType=mode==='static'&&proposedSourceId?'alias':'base';
  const typeChanged=proposedType!==String(variable.type||'base');
  const previewRename=async()=>{if(!nameChanged)return;sChecking(true);sErr('');try{const r=await api.p('variables/'+variable.id+'/rename-preview',{new_name:fullNm});if(r?.code){sErr(r.message||'Preview failed');return;}sImpact(r.impact||null);}catch(e){sErr('Preview failed. Check WordPress error logs for details.');}finally{sChecking(false);}};

  const save=async()=>{
    if(!nm)return;sLd(true);sErr('');
    let fv;
    if(mode==='color')fv=hexOklch(hex);
    else if(mode==='fluid')fv=fluidMarker(fMin,fMax);
    else if(mode==='clamp')fv=val?(val.match(/\d/)?pxToRemValue(val):val):'10px';
    else fv=val;
    if(!fv){sLd(false);sErr(mode==='fluid'?'Enter both a min and max value.':'');return;}
    const updates={};
    if(nameChanged){updates.name=fullNm;if(prop)updates.propagate_usages=true;}
    if(cat!==(variable.category_slug||'uncategorized'))updates.category_slug=cat;
    // For colors, compare hex values to detect change (avoids oklch rounding issues)
    if(mode==='color'){
      if(hex!==clrToHex(variable.value)){updates.value=fv;updates.palette_value=true;}
    } else {
      if(fv!==variable.value)updates.value=fv;
    }
    if(mode==='static'){
      const sourceId = detectAliasSource(fv, vars);
      if(sourceId){
        if(variable.type!=='alias'||Number(variable.source_id)!==Number(sourceId)){
          updates.type='alias';
          updates.source_id=Number(sourceId);
          updates.value=''; // database stores empty value for alias type
        }
      } else {
        if(variable.type!=='base'){
          updates.type='base';
          updates.source_id=null;
          updates.value=fv;
        }
      }
    } else {
      if(variable.type!=='base'){
        updates.type='base';
        updates.source_id=null;
      }
    }
    if(Object.keys(updates).length===0){sLd(false);onDone();return;}
    const r=await api.u('variables/'+variable.id,updates);
    sLd(false);
    if(r?.code==='ve_duplicate'){sErr(r.message||'Name already exists.');return;}
    if(r?.code){sErr(r.message||'Failed to update.');return;}
    onDone(r);
  };

  const catOpts=(categories||[]).map(c=>({value:c.slug,label:c.name}));

  return h(Sub,{title:'Edit: '+publicTokenLabel(variable.name),onClose,exiting},
    h('div',{class:'ve-mode'},
      h('button',{class:mode==='color'?'on':'',onClick:()=>sMode('color')},'Color'),
      h('button',{class:mode==='clamp'?'on':'',onClick:()=>sMode('clamp')},'Fixed'),
      h('button',{class:mode==='fluid'?'on':'',onClick:()=>sMode('fluid')},'Fluid'),
      h('button',{class:mode==='static'?'on':'',onClick:()=>sMode('static')},'Static')),
    !isClrV&&h('div',{class:'ve-opt ve-opt-stack',style:'padding-top:0'},
      h('span',null,'Category'),
      h(SelectMenu,{value:cat,onChange:sCat,options:catOpts})),
    h('div',{class:'ve-row'},h('input',{placeholder:'name',value:nm,onInput:e=>{sNm(normalizeNameInput(e.target.value));sImpact(null);if(err)sErr('');},onKeyDown:e=>e.key==='Enter'&&save(),style:'flex:1'})),
    nm&&h('div',{style:'font-size:11px;color:#444;padding:0 0 6px;font-family:monospace'},publicTokenLabel(fullNm)),
    nameChanged&&h('div',{class:'ve-warn',style:'margin:0 0 8px'},
      h('div',{style:'font-size:11px;margin-bottom:5px'},'Rename detected. You can update existing var() references in WordPress/Bricks storage too.'),
      h('label',{style:'display:flex;gap:6px;align-items:center;font-size:11px;color:#ccc;margin-bottom:5px'},h('input',{type:'checkbox',checked:prop,onChange:e=>sProp(e.target.checked)}),'Update usages in WordPress storage'),
      h('button',{class:'ve-btn ve-btn-s',style:'font-size:11px;padding:3px 7px',onClick:previewRename,disabled:checking},checking?'Checking...':'Preview impact'),
      impact&&h('div',{style:'font-size:11px;color:#777;margin-top:4px'},(impact.total_matches||0)+' matches in '+((impact.locations||[]).length)+' records')
    ),
    (nameChanged||typeChanged)&&h(VariableUsagePanel,{variable,onNavigate:onNavigateUsage,title:(nameChanged?'Rename':'Type change')+' impact'}),
    err&&h('div',{style:'font-size:11px;color:#ef4444;padding:2px 0 6px'},err),
    mode==='color'&&h('div',{class:'ve-row'},h(MVColorPicker,{hex,onChange:sHex,fmt,setFmt:sFmt})),
    mode==='clamp'&&h('div',null,
      h('div',{class:'ve-row'},h('input',{placeholder:'Base value (number, stored as rem)',value:val,onInput:e=>sVal(e.target.value),style:'flex:1'})),
      h('div',{style:'font-size:11px;color:#555;padding:0 0 6px'},'Current: '+variable.value)),
    mode==='fluid'&&h('div',null,
      h('div',{class:'ve-row',style:'gap:6px'},
        h('input',{placeholder:'Min px',value:fMin,onInput:e=>{sFMin(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'}),
        h('input',{placeholder:'Max px',value:fMax,onInput:e=>{sFMax(e.target.value.replace(/[^0-9.]/g,''));if(err)sErr('');},style:'flex:1'})),
      fMin&&fMax&&h('div',{style:'font-size:11px;color:#baf400;padding:0 0 4px;font-family:monospace;word-break:break-all'},fluidPreview(fMin,fMax)),
      h('div',{style:'font-size:11px;color:#555;padding:0 0 6px'},'Scales between the page min/max viewport widths. Min/max are px values.')),
    mode==='static'&&h('div',{class:'ve-row'},
      h(VarRefInput,{placeholder:'value',value:val,onInput:e=>sVal(typeof e.target==='object'?e.target.value:e),vars:vars||[],onKeyDown:e=>e.key==='Enter'&&save()})),
    h('div',{style:'display:flex;gap:5px;justify-content:flex-end;margin-top:4px'},
      h('button',{class:'ve-btn',onClick:save,disabled:ld||!nm||(mode==='fluid'&&(!fMin||!fMax))},ld?'...':'Save Changes')));
}

/* ── Detail (with inline value editing) ── */
function Detail({variable,vars,onNav,onNavigateUsage,onClose,onUpdate,onEditFull}){
  const[d,sD]=useState(null);
  const[editing,sEditing]=useState(false);
  const[editVal,sEV]=useState('');
  const[saving,sSaving]=useState(false);
  useEffect(()=>{sD(null);if(variable){api.g('variables/'+variable.id).then(sD);sEditing(false);}},[variable?.id]);
  if(!variable)return null;
  const css=cssTokenName(variable.name);
  const isGen=variable.type==='generated';
  const isFluidV=isFluidVal(variable.value);
  const fluidPair=isFluidV?parseFluid(variable.value):null;
  const fluidLabel=fluidPair?(trimNum(fluidPair[0])+' → '+trimNum(fluidPair[1])+'px fluid'):'';
  const resolvedVal=resolvedVariableValue(variable, vars);
  const displayVal=variable.type==='alias'
    ? (variable.css_value ? `${variable.css_value}${resolvedVal ? ` (${resolvedVal})` : ''}` : resolvedVal)
    : (isFluidV ? fluidLabel : variable.value);
  // Fluid variables can't be edited with the single-field inline editor — send to full edit panel.
  const startEdit=()=>{if(isGen)return;if(isFluidV){onEditFull&&onEditFull(variable);return;}sEV(variable.type==='alias'?variable.css_value:variable.value);sEditing(true);};
  const saveVal=async()=>{
    const currentVal=variable.type==='alias'?variable.css_value:variable.value;
    if(!editVal||editVal===currentVal){sEditing(false);return;}
    sSaving(true);
    const updates={value:editVal};
    if(isClr(resolvedVal))updates.palette_value=true;
    const sourceId = detectAliasSource(editVal, vars);
    if(sourceId){
      updates.type='alias';
      updates.source_id=Number(sourceId);
      updates.value='';
    } else {
      updates.type='base';
      updates.source_id=null;
    }
    const r=await api.u('variables/'+variable.id,updates);
    sSaving(false);sEditing(false);
    if(r&&!r.code&&onUpdate)onUpdate();
  };
  return h('div',{class:'ve-det'},
    h('div',{class:'ve-det-t'},h('span',null,publicTokenLabel(variable.name)),h('button',{class:'ve-exp',onClick:onClose},ph('x'))),
    h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'Value'),
      editing?h('div',{style:'display:flex;gap:3px;flex:1'},
        h('input',{style:'flex:1;padding:2px 4px;background:#2a2a2a;border:1px solid #baf400;border-radius:3px;color:#f1f1f1;font-size:11px;font-family:monospace;outline:none',value:editVal,onInput:e=>sEV(e.target.value),onKeyDown:e=>{if(e.key==='Enter')saveVal();if(e.key==='Escape')sEditing(false);}}),
        h('button',{class:'ve-btn ve-btn-s',style:'padding:1px 6px;font-size:11px',onClick:saveVal,disabled:saving},saving?'...':'✓'))
      :h('span',{class:'ve-det-v',style:isGen?'':'cursor:pointer',onClick:startEdit,title:isGen?'Generated — edit base variable':(isFluidV?'Fluid — click to edit min/max':'Click to edit')},displayVal)),
    isFluidV&&h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'Fluid'),h('span',{class:'ve-det-v',style:'font-size:11px;color:#baf400;word-break:break-all'},variable.css_value||d?.css_value||'')),
    h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'CSS'),h('span',{class:'ve-det-v'},'var('+css+')')),
    h('div',{class:'ve-det-r'},h('span',{class:'ve-det-l'},'Type'),h('span',{class:'ve-det-v'},variable.type||'base')),
    d?.dependents?.length>0&&h('div',{class:'ve-dep-s'},h('div',{class:'ve-dep-t'},'Dependents ('+d.dependents.length+')'),
      d.dependents.slice(0,6).map(x=>h('div',{class:'ve-dep',onClick:()=>onNav(x)},x.name))),
    d?.depends_on?.length>0&&h('div',{class:'ve-dep-s'},h('div',{class:'ve-dep-t'},'Source'),
      d.depends_on.map(x=>h('div',{class:'ve-dep',onClick:()=>onNav(x)},x.name))),
    h(VariableUsagePanel,{variable,onNavigate:onNavigateUsage}));
}

/* ── Main ──────────────────────────────── */
function Panel(){
  const[open,sO]=useState(false);const[vars,sV]=useState([]);const[stats,sStats]=useState(null);const[sr,sSr]=useState('');
  const[sel,sSel]=useState(null);const[nsTab,sNT]=useState('all');
  const[sourceFilter,sSourceFilter]=useState('all');
  const[palettesData,sPalettesData]=useState({active:'default',palettes:[]});
  const[colorPalettesData,sColorPalettesData]=useState({palettes:[]});
  const[variableCategoriesData,sVariableCategoriesData]=useState({categories:[]});
  const[selectedColorPalette,sSelectedColorPalette]=useState('all');
  const[colorControlMode,sColorControlMode]=useState(()=>localStorage.getItem('ve_color_control_mode')||'theme');
  const[colorPaletteManagerOpen,sColorPaletteManagerOpen]=useState(()=>localStorage.getItem('ve_color_palette_mgr_open')==='1');
  const[showAllTab,sShowAllTab]=useState(true);
  const[exp,sExp]=useState({});const[toast,sToast]=useState('');const[toastTick,sToastTick]=useState(0);const[cfm,sCfm]=useState(null);
  const[mvTip,sMvTip]=useState(null);
  const toastTimerRef=useRef(null);
  const flash=useCallback(m=>{
    if(toastTimerRef.current)clearTimeout(toastTimerRef.current);
    sToastTick(v=>v+1);
    sToast(m);
    toastTimerRef.current=setTimeout(()=>{sToast('');toastTimerRef.current=null;},5000);
  },[]);
  const[rowActions,sRowActions]=useState(null);
  const rowActionsTimerRef=useRef(null);
  const[sub,sSub]=useState(null);const[autoGen,sAG]=useState(null);
  const [editingCategory, sEditingCategory] = useState(null);
  const [categoryEditName, sCategoryEditName] = useState('');
  const [confirmCategoryDelete, sConfirmCategoryDelete] = useState(null);
  const [categoryMenu, sCategoryMenu] = useState(null);

  const renameCategory = async () => {
    if (!editingCategory || !categoryEditName.trim()) return;
    const r = await api.p('variable-categories/' + editingCategory.slug + '/rename', { name: categoryEditName.trim() });
    if (r?.code) {
      flash(r.message || 'Could not rename category');
      return;
    }
    sEditingCategory(null);
    await load();
    flash('Category renamed');
  };

  const deleteCategory = async () => {
    if (!confirmCategoryDelete) return;
    const category = confirmCategoryDelete;
    sConfirmCategoryDelete(null);
    const r = await api.p('variable-categories/' + category.slug + '/remove', {});
    if (r?.code) {
      flash(r.message || 'Could not delete category');
      return;
    }
    if (nsTab === category.slug) {
      sNT('all');
    }
    await load();
    flash('Category deleted · variables moved to Uncategorized');
  };
  const hSel = v => sSel(current => current?.id === v.id ? null : v);
  const [draggingVarId, sDraggingVarId] = useState(null);
  const [dragOverVarId, sDragOverVarId] = useState(null);
  const [checkedVars, sCheckedVars] = useState([]);
  const checkedVarSet = useMemo(()=>new Set(checkedVars.map(Number)),[checkedVars]);
  const [selectionReviewOpen, sSelectionReviewOpen] = useState(false);
  const lastAutoOpenedHiddenSelectionRef = useRef('');
  const lastCheckedVarRef = useRef(null);
  const [confirmBatchDelete, sConfirmBatchDelete] = useState(false);
  const [batchTargetPaletteId, sBatchTargetPaletteId] = useState('');
  const [batchTargetCategorySlug, sBatchTargetCategorySlug] = useState('');

  const handleVarDragStart = (e, v) => {
    sDraggingVarId(v.id);
    e.dataTransfer.effectAllowed = 'move';
    e.dataTransfer.setData('text/plain', String(v.id));
  };
  const handleVarDragOver = (e, v) => {
    e.preventDefault();
    if (v.id !== draggingVarId) {
      sDragOverVarId(v.id);
    }
  };
  const handleVarDragEnd = () => {
    sDraggingVarId(null);
    sDragOverVarId(null);
  };
  const handleVarDrop = async (e, targetVar) => {
    e.preventDefault();
    const sourceId = draggingVarId;
    sDraggingVarId(null);
    sDragOverVarId(null);
    if (!sourceId || sourceId === targetVar.id) return;

    const currentList = [...filtered];
    const sourceIdx = currentList.findIndex(x => x.id === sourceId);
    const targetIdx = currentList.findIndex(x => x.id === targetVar.id);
    if (sourceIdx === -1 || targetIdx === -1) return;

    const [removed] = currentList.splice(sourceIdx, 1);
    currentList.splice(targetIdx, 0, removed);

    const allVars = [...vars];
    const idsToReorder = currentList.map(x => x.id);
    const reorderedIds = [];
    reorderedIds.push(...idsToReorder);
    const otherIds = allVars.filter(x => !idsToReorder.includes(x.id)).map(x => x.id);
    reorderedIds.push(...otherIds);

    sV(allVars.map(x => {
      if (idsToReorder.includes(x.id)) {
        const idx = idsToReorder.indexOf(x.id);
        return { ...x, position: idx };
      }
      return x;
    }));

    try {
      const res = await api.p('variables/reorder', { ids: reorderedIds });
      if (res && !res.code) {
        flash('Order saved');
      } else {
        flash(res?.message || 'Failed to save order');
      }
      load();
    } catch(err) {
      flash('Failed to save order');
      load();
    }
  };

  const toggleVarChecked = (id, event) => {
    id=Number(id);
    const shiftHeld=!!(event?.shiftKey||event?.nativeEvent?.shiftKey||event?.currentTarget?.__veShiftKey);
    const shouldCheck=!checkedVarSet.has(id);
    const anchor=Number(lastCheckedVarRef.current||0);
    if(shiftHeld&&anchor&&visibleSelectionIds.includes(anchor)&&visibleSelectionIds.includes(id)){
      const start=visibleSelectionIds.indexOf(anchor);
      const end=visibleSelectionIds.indexOf(id);
      const range=visibleSelectionIds.slice(Math.min(start,end),Math.max(start,end)+1);
      sCheckedVars(prev=>{
        const normalized=prev.map(Number);
        return shouldCheck?[...new Set([...normalized,...range])]:normalized.filter(value=>!range.includes(value));
      });
    }else{
      sCheckedVars(prev=>{
        const normalized=prev.map(Number);
        return normalized.includes(id)?normalized.filter(value=>value!==id):[...normalized,id];
      });
    }
    lastCheckedVarRef.current=id;
  };
  const toggleAllVarsChecked = () => {
    const visibleIds = visibleSelectionIds;
    const allChecked = visibleIds.every(id => checkedVarSet.has(Number(id)));
    if (allChecked) {
      sCheckedVars(prev => prev.map(Number).filter(id => !visibleIds.includes(id)));
    } else {
      sCheckedVars(prev => [...new Set([...prev.map(Number), ...visibleIds])]);
    }
  };
  const removeCheckedVar = id => {
    id=Number(id);
    if(Number(lastCheckedVarRef.current||0)===id)lastCheckedVarRef.current=null;
    sCheckedVars(prev=>prev.filter(value=>Number(value)!==id));
  };
  const clearCheckedVars = () => {
    lastCheckedVarRef.current=null;
    sSelectionReviewOpen(false);
    sCheckedVars([]);
  };
  const deleteCheckedVars = async () => {
    if (checkedVars.length === 0) return;
    try {
      const res = await api.p('variables/batch-delete', { ids: checkedVars, force: true });
      if (res && !res.code) {
        flash(checkedVars.length + ' variables deleted');
        clearCheckedVars();
        load();
      } else {
        flash(res?.message || 'Failed to delete variables');
      }
    } catch(e) {
      flash('Failed to delete variables');
    }
  };
  const moveCheckedVarsToPalette = async (paletteId) => {
    if (checkedVars.length === 0 || !paletteId) return;
    try {
      const res = await api.p('color-palettes/variables/batch-move', { ids: checkedVars, palette_id: Number(paletteId) });
      if (res && !res.code) {
        flash(checkedVars.length + ' colors assigned to palette');
        clearCheckedVars();
        load();
      } else {
        flash(res?.message || 'Failed to assign colors');
      }
    } catch(e) {
      flash('Failed to assign colors');
    }
  };
  const moveCheckedVarsToCategory = async (categorySlug) => {
    if (checkedVars.length === 0 || !categorySlug) return;
    try {
      const res = await api.p('variable-categories/variables/move', { variable_ids: checkedVars, category_slug: categorySlug });
      if (res && !res.code) {
        flash((res.moved || checkedVars.length) + ' variables moved');
        clearCheckedVars();
        sBatchTargetCategorySlug('');
        load();
      } else {
        flash(res?.message || 'Failed to move variables');
      }
    } catch(e) {
      flash('Failed to move variables');
    }
  };
  const activatePalette = async (slug) => {
    try {
      const res = await api.p('themes/' + slug + '/activate', {});
      if (res && !res.code) {
        sPalettesData(prev => ({ ...prev, active: slug }));
        load();
        flash('Theme activated');
      } else {
        flash(res?.message || 'Activation failed');
      }
    } catch (e) {
      flash('Activation failed');
    }
  };
  const[updateInfo,sUpdateInfo]=useState(null);const[skipUpdate,sSkipUpdate]=useState(()=>localStorage.getItem('ve_skip_update_version')||'');
  const[updateComplete,sUpdateComplete]=useState(null);
  const[panelMode,sPanelMode]=useState(()=>localStorage.getItem('ve_panel_mode')||'right');
  const[panelPos,sPanelPos]=useState(()=>{try{return JSON.parse(localStorage.getItem('ve_panel_pos')||'{}')}catch(e){return{}}});
  const[allowMultiPanels,sAllowMultiPanels]=useState(()=>localStorage.getItem('ve_allow_multi_panels')==='1');
  const[snapSide,sSnapSide]=useState('');
  const[confirmCleanFooter,sConfirmCleanFooter]=useState(false);
  
  // Standalone panel states
  const [settingsOpen, sSettingsOpen] = useState(false);
  const [helpOpen, sHelpOpen] = useState(false);
  const [cssStudioOpen, sCssStudioOpen] = useState(false);
  const [usageCssSheet, sUsageCssSheet] = useState('');
  const [usageRecipeCode, sUsageRecipeCode] = useState('');
  const [contentStudioOpen, sContentStudioOpen] = useState(false);
  const [mediaStudioOpen, sMediaStudioOpen] = useState(false);
  const [mediaStudioInitialFilter, setMediaStudioInitialFilter] = useState('');
  const [pluginStudioOpen, sPluginStudioOpen] = useState(false);
  const [cssRecipesOpen, sCssRecipesOpen] = useState(false);
  const [fabToolsOpen, setFabToolsOpen] = useState(false);
  const [fabOrder, setFabOrder] = useState(() => {
    try { return normalizeFabOrder(JSON.parse(localStorage.getItem('ve_fab_order') || '[]')); } catch(e) { return normalizeFabOrder([]); }
  });

  // Lazy-mount states for exit animations
  const [settingsHasOpened, setSettingsHasOpened] = useState(false);
  const [helpHasOpened, setHelpHasOpened] = useState(false);
  const [cssStudioHasOpened, setCssStudioHasOpened] = useState(false);
  const [contentStudioHasOpened, setContentStudioHasOpened] = useState(false);
  const [mediaStudioHasOpened, setMediaStudioHasOpened] = useState(false);
  const [pluginStudioHasOpened, setPluginStudioHasOpened] = useState(false);
  const [cssRecipesHasOpened, setCssRecipesHasOpened] = useState(false);

  const [deactivatedTools, setDeactivatedTools] = useState(() => {
    try {
      const saved = localStorage.getItem('ve_deactivated_tools');
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });
  const disabledToolsForCurrentSurface = settings => {
    const legacy = Array.isArray(settings?.deactivated_tools) ? settings.deactivated_tools : [];
    const surfaces = settings?.deactivated_tool_surfaces && typeof settings.deactivated_tool_surfaces === 'object' ? settings.deactivated_tool_surfaces : {};
    const side = MODE === 'builder' ? 'builder' : 'admin';
    const sideList = Array.isArray(surfaces[side]) ? surfaces[side] : [];
    const adminList = Array.isArray(surfaces.admin) ? surfaces.admin : [];
    const builderList = Array.isArray(surfaces.builder) ? surfaces.builder : [];
    const legacyWithoutSurfaceChoice = legacy.filter(id => !adminList.includes(id) && !builderList.includes(id));
    return [...new Set([...legacyWithoutSurfaceChoice, ...sideList])];
  };
  const readDisabledToolsForSurface = surface => {
    try {
      const side = surface || (MODE === 'builder' ? 'builder' : 'admin');
      const legacy = JSON.parse(localStorage.getItem('ve_deactivated_tools') || '[]');
      const surfaces = JSON.parse(localStorage.getItem('ve_deactivated_tool_surfaces') || '{}');
      const adminList = Array.isArray(surfaces.admin) ? surfaces.admin : [];
      const builderList = Array.isArray(surfaces.builder) ? surfaces.builder : [];
      const sideList = Array.isArray(surfaces[side]) ? surfaces[side] : [];
      const legacyList = Array.isArray(legacy) ? legacy : [];
      const legacyWithoutSurfaceChoice = legacyList.filter(id => !adminList.includes(id) && !builderList.includes(id));
      return [...new Set([...legacyWithoutSurfaceChoice, ...sideList])];
    } catch (e) {
      return [];
    }
  };
  const broadcastDisabledTools = (settings, resolved) => {
    const list = Array.isArray(resolved) ? resolved : disabledToolsForCurrentSurface(settings || {});
    if (settings && settings.deactivated_tool_surfaces && typeof settings.deactivated_tool_surfaces === 'object') {
      persistUserPreference('ve_deactivated_tool_surfaces', settings.deactivated_tool_surfaces);
    }
    persistUserPreference('ve_deactivated_tools', list);
    try {
      const event = new CustomEvent('ve-deactivated-tools-changed', { detail: list });
      window.dispatchEvent(event);
      if (window.top && window.top !== window) window.top.dispatchEvent(new CustomEvent('ve-deactivated-tools-changed', { detail: list }));
    } catch (e) {}
    return list;
  };
  const deactivatedToolsRef = useRef(deactivatedTools);
  useEffect(() => { deactivatedToolsRef.current = deactivatedTools; }, [deactivatedTools]);
  const moduleLabel = id => ({
    variables: 'Variable Panel',
    css_studio: 'CSS Studio',
    css_recipes: 'CSS Recipes',
    content_studio: 'Content Studio',
    media_studio: 'Media Studio',
    plugin_studio: 'Plugin Studio',
    mimams_bar: "Mimam's Bar"
  }[id] || 'This module');
  const isToolDisabledNow = useCallback(id => {
    const key = id === 'css_recipes' ? 'css_studio' : id;
    const latest = readDisabledToolsForSurface();
    return latest.includes(key);
  }, []);
  const openModuleIfEnabled = useCallback((id, opener) => {
    if (isToolDisabledNow(id)) {
      flash(moduleLabel(id) + ' is disabled for this surface in Settings → Modules.');
      return false;
    }
    opener && opener();
    return true;
  }, [flash, isToolDisabledNow]);
  const closeDisabledModulesNow = useCallback(() => {
    if (isToolDisabledNow('variables') && open) sO(false);
    if (isToolDisabledNow('css_studio')) {
      if (cssStudioOpen) sCssStudioOpen(false);
      if (cssRecipesOpen) sCssRecipesOpen(false);
    }
    if (isToolDisabledNow('content_studio') && contentStudioOpen) sContentStudioOpen(false);
    if (isToolDisabledNow('media_studio')) {
      if (mediaStudioOpen) sMediaStudioOpen(false);
      if (mediaTargetRef.current) mediaTargetRef.current = null;
      if (pendingMediaFrameRef.current) pendingMediaFrameRef.current = null;
    }
    if (isToolDisabledNow('plugin_studio') && pluginStudioOpen) sPluginStudioOpen(false);
  }, [open, cssStudioOpen, cssRecipesOpen, contentStudioOpen, mediaStudioOpen, pluginStudioOpen, isToolDisabledNow]);
  const [mediaReplaceLibrary, setMediaReplaceLibrary] = useState(false);
  const [mediaAutoSyncExternalFolders, setMediaAutoSyncExternalFolders] = useState(() => localStorage.getItem('ve_media_auto_sync_external_folders') === '1');
  const isNativeMediaLibraryPage = MODE === 'admin' && /\/wp-admin\/upload\.php$/i.test(window.location.pathname || '');
  const nativeMediaPageActive = NATIVE_MEDIA_REPLACEMENT_ENABLED && isNativeMediaLibraryPage && mediaReplaceLibrary && !isToolDisabledNow('media_studio');
  const mediaStudioStandaloneOpen = mediaStudioOpen && !nativeMediaPageActive && !isToolDisabledNow('media_studio');
  const closeNativeMediaReplacement = useCallback(() => {
    setMediaReplaceLibrary(false);
    persistUserPreference('ve_media_replace_wp_library', '0');
    try { document.body.classList.remove('ve-native-media-page-active'); } catch(e) {}
    api.g('settings').then(curr => api.p('settings', { ...(curr || {}), media_replace_wp_library: false })).catch(() => {});
    try { window.dispatchEvent(new CustomEvent('ve-media-replace-library-changed', { detail: false })); } catch(e) {}
    // On the native upload.php screen, reloading is safer than leaving WordPress'
    // original Media Library in a hidden/blank intermediate state after replacement.
    if (isNativeMediaLibraryPage) {
      setTimeout(() => { try { window.location.reload(); } catch(e) {} }, 80);
    }
  }, [isNativeMediaLibraryPage]);

  useEffect(() => {
    closeDisabledModulesNow();
  }, [deactivatedTools, closeDisabledModulesNow]);
  useEffect(() => {
    if (nativeMediaPageActive && mediaStudioOpen) {
      sMediaStudioOpen(false);
    }
  }, [nativeMediaPageActive, mediaStudioOpen]);

  useEffect(() => { if (settingsOpen) setSettingsHasOpened(true); }, [settingsOpen]);
  useEffect(() => { if (helpOpen) setHelpHasOpened(true); }, [helpOpen]);
  useEffect(() => { if (cssStudioOpen) setCssStudioHasOpened(true); }, [cssStudioOpen]);
  useEffect(() => { if (contentStudioOpen) setContentStudioHasOpened(true); }, [contentStudioOpen]);
  useEffect(() => { if (mediaStudioOpen) setMediaStudioHasOpened(true); }, [mediaStudioOpen]);
  useEffect(() => { if (pluginStudioOpen) setPluginStudioHasOpened(true); }, [pluginStudioOpen]);
  useEffect(() => { if (cssRecipesOpen) setCssRecipesHasOpened(true); }, [cssRecipesOpen]);
  useEffect(() => {
    const changed = e => setFabOrder(normalizeFabOrder(e?.detail));
    window.addEventListener('ve-fab-order-changed', changed);
    return () => window.removeEventListener('ve-fab-order-changed', changed);
  }, []);

  useEffect(() => {
    const openMedia = e => {
      openModuleIfEnabled('media_studio', () => {
        setMediaStudioInitialFilter(e?.detail?.filter || '');
        sMediaStudioOpen(true);
      });
    };
    window.addEventListener('ve-open-media-studio', openMedia);
    return () => window.removeEventListener('ve-open-media-studio', openMedia);
  }, [openModuleIfEnabled]);
  useEffect(()=>{const fn=e=>flash(String(e.detail||''));window.addEventListener('ve-toast-request',fn);return()=>window.removeEventListener('ve-toast-request',fn);},[]);
  useEffect(()=>{
    const installed=event=>{
      const detail=event?.detail||{};
      sUpdateComplete(detail);
      sUpdateInfo(previous=>previous?{...previous,update_available:false,current_version:detail.version||previous.latest_version}:previous);
    };
    window.addEventListener('ve-update-installed',installed);
    return()=>window.removeEventListener('ve-update-installed',installed);
  },[]);

  useEffect(() => {
    if (MODE !== 'builder') return;
    const listeners=[];
    const wrappers=[];
    const normalizeAttachment=item=>{
      const url=item?.source_url||item?.url||'';
      const mime=item?.mime_type||item?.mime||'image/jpeg';
      const filename=decodeURIComponent(String(url).split('/').pop()||item?.slug||'media');
      const sizes={};
      const rawSizes=item?.media_details?.sizes||{};
      Object.keys(rawSizes).forEach(key=>{
        const size=rawSizes[key]||{};
        sizes[key]={...size,url:size.source_url||size.url||url};
      });
      if(!sizes.full)sizes.full={url,width:item?.media_details?.width||0,height:item?.media_details?.height||0};
      return {
        id:Number(item?.id||0),url,filename,mime,
        type:String(mime).split('/')[0]||'image',
        subtype:String(mime).split('/')[1]||'',
        title:item?.title?.rendered||item?.title||filename,
        caption:item?.caption?.rendered||item?.caption||'',
        description:item?.description?.rendered||item?.description||'',
        alt:item?.alt_text||item?.alt||'',
        sizes
      };
    };
    const createFrame=(runtime,options,intent)=>{
      const callbacks={};
      let selected=[];
      const collection={
        toJSON:()=>selected.slice(),
        first:()=>selected.length?{toJSON:()=>selected[0]}:null,
        add:attachment=>{try{selected.push(attachment?.toJSON?attachment.toJSON():attachment);}catch(e){}},
        reset:()=>{selected=[];}
      };
      const emit=event=>(callbacks[event]||[]).slice().forEach(callback=>{try{callback.call(frame, frame);}catch(e){}});
      const frame={
        options:options||{},
        on(events,callback){String(events||'').split(/\s+/).filter(Boolean).forEach(event=>{(callbacks[event]||(callbacks[event]=[])).push(callback);});return frame;},
        off(events,callback){String(events||'').split(/\s+/).filter(Boolean).forEach(event=>{if(!callbacks[event])return;callbacks[event]=callback?callbacks[event].filter(cb=>cb!==callback):[];});return frame;},
        open(){
          if(isToolDisabledNow('media_studio')){
            flash('Media Studio is disabled for this surface in Settings → Modules.');
            return frame;
          }
          const frameFilter = inferMediaFilterFromFrameOptions(options);
          mediaTargetRef.current=intent?.scope||intent?.target||null;
          setMediaStudioInitialFilter(intent?.filter || frameFilter || inferMediaFilterFromScope(intent?.scope||intent?.target) || 'image');
          pendingMediaFrameRef.current=frame;
          sMediaStudioOpen(true);
          emit('open');
          flash('Media Studio opened for asset selection.');
          return frame;
        },
        close(){emit('close');return frame;},
        state:()=>({get:key=>key==='selection'?collection:null}),
        content:{get:()=>null},
        __select(item){
          const attachment=normalizeAttachment(item);
          if(!attachment.url)return false;
          selected=[attachment];
          emit('select');
          return true;
        }
      };
      return frame;
    };
    const install=runtime=>{
      try{
        if(!runtime||runtime.__veWpHooked)return;
        runtime.__veWpHooked=true;
        const wrapMedia=media=>{
          if(typeof media!=='function'||media.__veMediaStudioBridge)return media;
          const original=media;
          const wrapped=function(...args){
            const intent=mediaIntentRef.current;
            if(intent&&Date.now()-intent.at<1800){
              mediaIntentRef.current=null;
              if(isToolDisabledNow('media_studio'))return original.apply(this,args);
              return createFrame(runtime,args[0],intent);
            }
            return original.apply(this,args);
          };
          Object.getOwnPropertyNames(original).forEach(key=>{
            try{if(!['length','name','prototype'].includes(key))Object.defineProperty(wrapped,key,Object.getOwnPropertyDescriptor(original,key));}catch(e){}
          });
          wrapped.__veMediaStudioBridge=true;
          wrapped.__veOriginal=original;
          return wrapped;
        };
        let currentWp=runtime.wp;
        let originalWpDesc=Object.getOwnPropertyDescriptor(runtime,'wp');
        let originalMediaDesc=null;
        let wpObjForCleanup=null;
        const hookMediaOnWp=wpObj=>{
          if(!wpObj||wpObj.__veMediaHooked)return;
          wpObj.__veMediaHooked=true;
          wpObjForCleanup=wpObj;
          let currentMedia=wpObj.media;
          originalMediaDesc=Object.getOwnPropertyDescriptor(wpObj,'media');
          if(currentMedia){currentMedia=wrapMedia(currentMedia);}
          try{
            Object.defineProperty(wpObj,'media',{
              get(){return currentMedia;},
              set(newMedia){currentMedia=wrapMedia(newMedia);},
              configurable:true,
              enumerable:true
            });
          }catch(e){
            wpObj.media=wrapMedia(currentMedia);
          }
        };
        if(currentWp){hookMediaOnWp(currentWp);}
        try{
          Object.defineProperty(runtime,'wp',{
            get(){return currentWp;},
            set(newWp){
              currentWp=newWp;
              if(newWp){hookMediaOnWp(newWp);}
            },
            configurable:true,
            enumerable:true
          });
        }catch(e){
          if(runtime.wp){hookMediaOnWp(runtime.wp);}
        }
        wrappers.push({
          runtime,
          restore:()=>{
            try{
              delete runtime.__veWpHooked;
              if(originalWpDesc){Object.defineProperty(runtime,'wp',originalWpDesc);}
              else{delete runtime.wp;runtime.wp=currentWp;}
            }catch(e){try{runtime.wp=currentWp;}catch(_){}}
            try{
              if(wpObjForCleanup){
                delete wpObjForCleanup.__veMediaHooked;
                if(originalMediaDesc){Object.defineProperty(wpObjForCleanup,'media',originalMediaDesc);}
                else{
                  const orig=wpObjForCleanup.media?.__veOriginal;
                  delete wpObjForCleanup.media;
                  wpObjForCleanup.media=orig||wpObjForCleanup.media;
                }
              }
            }catch(e){}
          }
        });
      }catch(e){}
    };
    const track=e=>{
      const target=e.target;
      if(!target||!target.closest||isToolDisabledNow('media_studio')||target.closest('#ve-panel-root,.media-modal,.media-frame'))return;
      const scope=findMediaWriteScope(target);
      mediaIntentRef.current={at:Date.now(),target,scope,filter:inferMediaFilterFromScope(scope||target)};
    };
    const installAll=()=>{
      builderRuntimeWindows().forEach(runtime=>{
        install(runtime);
        try{
          const doc=runtime.document;
          if(listeners.some(entry=>entry.doc===doc))return;
          doc.addEventListener('pointerdown',track,true);
          listeners.push({doc});
        }catch(e){}
      });
    };
    installAll();
    const retry=setInterval(installAll,300);
    return () => {
      clearInterval(retry);
      listeners.forEach(({doc})=>{try{doc.removeEventListener('pointerdown',track,true);}catch(e){}});
      wrappers.forEach(w=>{try{w.restore();}catch(e){}});
    };
  }, []);

  // Mutual exclusion: by default, one major MV panel is open at a time.
  useEffect(() => {
    if (!allowMultiPanels && open) { sSettingsOpen(false); sHelpOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false); }
  }, [open, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && settingsOpen) { sO(false); sHelpOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false); }
  }, [settingsOpen, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && helpOpen) { sO(false); sSettingsOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false); }
  }, [helpOpen, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && cssStudioOpen) { sO(false); sSettingsOpen(false); sHelpOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false); }
  }, [cssStudioOpen, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && contentStudioOpen) { sO(false); sSettingsOpen(false); sHelpOpen(false); sCssStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false); }
  }, [contentStudioOpen, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && mediaStudioOpen) { sO(false); sSettingsOpen(false); sHelpOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false); }
  }, [mediaStudioOpen, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && pluginStudioOpen) { sO(false); sSettingsOpen(false); sHelpOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sCssRecipesOpen(false); }
  }, [pluginStudioOpen, allowMultiPanels]);

  useEffect(() => {
    if (!allowMultiPanels && cssRecipesOpen) { sO(false); sSettingsOpen(false); sHelpOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); }
  }, [cssRecipesOpen, allowMultiPanels]);

  const sRef=useRef();
  const panelRef=useRef();
  const fabRef=useRef();
  const mediaTargetRef=useRef(null);
  const mediaIntentRef=useRef(null);
  const pendingMediaFrameRef=useRef(null);

  const findMediaWriteScope = target => {
    if (!target || !target.closest) return null;
    return target.closest('.bricks-control-image, .bricks-control-media, .bricks-control-background, .brx-control, .bricks-control, .control, .control-inner, [data-control], [data-control-key], [data-setting]') || target;
  };

  const inferMediaFilterFromFrameOptions = options => {
    const library = options && options.library;
    const type = Array.isArray(library?.type) ? library.type.join(' ') : (library?.type || options?.type || '');
    const text = String(type || '').toLowerCase();
    if (/svg/.test(text)) return 'svg';
    if (/video/.test(text)) return 'video';
    if (/audio/.test(text)) return 'audio';
    if (/font|woff|ttf|otf/.test(text)) return 'font';
    if (/application|pdf|document/.test(text)) return 'application';
    if (/image/.test(text)) return 'image';
    return '';
  };

  const inferMediaFilterFromScope = scope => {
    if (!scope) return '';
    const text = [
      scope.getAttribute && scope.getAttribute('data-control'),
      scope.getAttribute && scope.getAttribute('data-control-key'),
      scope.getAttribute && scope.getAttribute('data-setting'),
      scope.getAttribute && scope.getAttribute('aria-label'),
      scope.className,
      scope.textContent
    ].map(x => String(x || '').toLowerCase()).join(' ');
    if (/svg|icon|vector/.test(text)) return 'svg';
    if (/video|mp4|webm/.test(text)) return 'video';
    if (/audio|mp3|wav/.test(text)) return 'audio';
    if (/image|img|picture|photo|logo|media|background|bg/.test(text)) return 'image';
    return '';
  };

  const setNativeValue = (el, value) => {
    if (!el) return false;
    try {
      const proto = Object.getPrototypeOf(el);
      const desc = proto && Object.getOwnPropertyDescriptor(proto, 'value');
      if (desc && desc.set) desc.set.call(el, value);
      else el.value = value;
      el.dispatchEvent(new Event('input', { bubbles: true }));
      el.dispatchEvent(new Event('change', { bubbles: true }));
      el.dispatchEvent(new Event('blur', { bubbles: true }));
      return true;
    } catch (e) {
      try {
        el.value = value;
        el.dispatchEvent(new Event('input', { bubbles: true }));
        el.dispatchEvent(new Event('change', { bubbles: true }));
        return true;
      } catch (e2) {
        return false;
      }
    }
  };

  const insertMediaIntoRememberedControl = item => {
    const url = item?.source_url || '';
    if (!url) return false;
    const pendingFrame=pendingMediaFrameRef.current;
    if(pendingFrame?.__select&&pendingFrame.__select(item)){
      pendingMediaFrameRef.current=null;
      mediaTargetRef.current=null;
      flash('Inserted media into the Bricks control.');
      sMediaStudioOpen(false);
      return true;
    }
    const target = mediaTargetRef.current;
    const scope = findMediaWriteScope(target);
    let inserted = false;
    if (scope) {
      const writable = Array.from(scope.querySelectorAll('input:not([type="hidden"]), textarea, [contenteditable="true"]')).filter(el => {
        const t = ((el.getAttribute('type') || '') + ' ' + (el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + (el.getAttribute('data-setting') || '') + ' ' + String(el.className || '')).toLowerCase();
        return !el.disabled && !el.readOnly && (el.tagName === 'TEXTAREA' || el.isContentEditable || /url|image|media|svg|background|source|custom/.test(t) || el.value);
      });
      const field = writable.find(el => /url|source|custom/i.test((el.getAttribute('placeholder') || '') + ' ' + (el.getAttribute('aria-label') || '') + ' ' + String(el.className || ''))) || writable[0];
      if (field) {
        if (field.isContentEditable) {
          field.textContent = url;
          field.dispatchEvent(new Event('input', { bubbles: true }));
          field.dispatchEvent(new Event('change', { bubbles: true }));
          inserted = true;
        } else {
          inserted = setNativeValue(field, url);
        }
      }
      scope.querySelectorAll('img').forEach(img => {
        try { img.src = url; inserted = true; } catch (e) {}
      });
      scope.dispatchEvent(new CustomEvent('ve-media-selected', { bubbles: true, detail: { id: item.id, url, item } }));
    }
    if (inserted) {
      flash('Inserted media into Bricks control.');
      mediaTargetRef.current = null;
      sMediaStudioOpen(false);
      return true;
    }
    navigator.clipboard?.writeText(url);
    flash('Copied media URL. Bricks did not expose a writable field here.');
    return false;
  };

  // Toggle FAB visibility and reset position when panels open/close
  useEffect(() => {
    const fab = fabRef.current;
    if (!fab) return;

    const hasOpenPanel = open || settingsOpen || helpOpen || cssStudioOpen || contentStudioOpen || mediaStudioStandaloneOpen || pluginStudioOpen || cssRecipesOpen;
    if (hasOpenPanel) {
      fab.classList.add('ve-fab-hidden');
    } else {
      fab.classList.remove('ve-fab-hidden');
      fab.style.left = '';
      fab.style.right = '';
      fab.classList.remove('ve-fab-left-side');
    }
  }, [open, settingsOpen, helpOpen, cssStudioOpen, contentStudioOpen, mediaStudioStandaloneOpen, pluginStudioOpen, cssRecipesOpen]);

  const dragRef=useRef(null);
  const snapRef=useRef('');

  const loadSeqRef=useRef(0);
  const load=useCallback(async()=>{
    const seq=++loadSeqRef.current;
    const stamp=Date.now();
    const [v,statsData,themesData,colorPalettes,variableCategories]=await Promise.all([
      api.g('variables?dedupe=true&_nc='+stamp).catch(()=>null),
      api.g('variables/stats?_nc='+stamp).catch(()=>null),
      api.g('themes?_nc='+stamp).catch(()=>null),
      api.g('color-palettes?_nc='+stamp).catch(()=>null),
      api.g('variable-categories?_nc='+stamp).catch(()=>null)
    ]);
    if(seq!==loadSeqRef.current)return null;
    if(Array.isArray(v)){
      sV(v);
      sSel(current=>current?(v.find(item=>item.id===current.id)||null):current);
    }
    if(statsData&&!statsData.code)sStats(statsData);
    if(themesData&&!themesData.code)sPalettesData(themesData);
    if(colorPalettes&&!colorPalettes.code)sColorPalettesData(colorPalettes);
    if(variableCategories&&!variableCategories.code)sVariableCategoriesData(variableCategories);
    return Array.isArray(v)?v:null;
  },[]);
  useEffect(()=>{load();},[]);
  useEffect(()=>{
    api.g('settings').then(d=>{
      if(d) {
        if(d.vw_min)_veViewport={vw_min:+d.vw_min||320,vw_max:+d.vw_max||1440};
        if(typeof d.allow_multi_panels !== 'undefined') {
          sAllowMultiPanels(!!d.allow_multi_panels);
          persistUserPreference('ve_allow_multi_panels', d.allow_multi_panels ? '1' : '0');
        }
        if(typeof d.show_all_tab !== 'undefined') {
          sShowAllTab(!!d.show_all_tab);
        }
        if(typeof d.media_replace_wp_library !== 'undefined') {
          setMediaReplaceLibrary(false);
          persistUserPreference('ve_media_replace_wp_library', '0');
        }
        if(typeof d.media_auto_sync_external_folders !== 'undefined') {
          setMediaAutoSyncExternalFolders(!!d.media_auto_sync_external_folders);
          persistUserPreference('ve_media_auto_sync_external_folders', d.media_auto_sync_external_folders ? '1' : '0');
        }
        const disabled = disabledToolsForCurrentSurface(d);
        setDeactivatedTools(disabled);
        deactivatedToolsRef.current = disabled;
        broadcastDisabledTools(d, disabled);
      }
    }).catch(()=>{});
  },[]);
  useEffect(() => {
    const handleShowAllTabChanged = (e) => {
      if (typeof e.detail !== 'undefined') {
        sShowAllTab(!!e.detail);
      }
    };
    window.addEventListener('ve-show-all-tab-changed', handleShowAllTabChanged);
    return () => window.removeEventListener('ve-show-all-tab-changed', handleShowAllTabChanged);
  }, []);
  useEffect(() => {
    const handleChanged = (e) => {
      const fresh = e.detail && Array.isArray(e.detail) ? e.detail : readDisabledToolsForSurface();
      setDeactivatedTools(fresh);
      deactivatedToolsRef.current = fresh;
      requestAnimationFrame(closeDisabledModulesNow);
    };
    window.addEventListener('ve-deactivated-tools-changed', handleChanged);
    window.addEventListener('storage', handleChanged);
    return () => {
      window.removeEventListener('ve-deactivated-tools-changed', handleChanged);
      window.removeEventListener('storage', handleChanged);
    };
  }, [closeDisabledModulesNow]);
  useEffect(()=>{if(!open)return;const t=setInterval(load,30000);const f=()=>{if(!document.hidden)load();};window.addEventListener('focus',f);document.addEventListener('visibilitychange',f);return()=>{clearInterval(t);window.removeEventListener('focus',f);document.removeEventListener('visibilitychange',f);};},[open,load]);
  useEffect(()=>{let alive=true;const check=()=>api.p('update/check',{}).then(r=>{if(alive&&r&&!r.code)sUpdateInfo(r);}).catch(()=>{});check();const t=setInterval(check,10*60*1000);return()=>{alive=false;clearInterval(t);};},[]);
  const skipUpdateVersion=useCallback(version=>{persistUserPreference('ve_skip_update_version',version);sSkipUpdate(version);},[]);
  useEffect(()=>{
    const sync=()=>syncMimamsBarUpdateNotice(updateInfo,skipUpdate,skipUpdateVersion);
    sync();
    const timers=[setTimeout(sync,250),setTimeout(sync,1000)];
    return()=>timers.forEach(clearTimeout);
  },[updateInfo,skipUpdate,skipUpdateVersion]);
  useEffect(()=>{const fn=e=>sAllowMultiPanels(!!e.detail);window.addEventListener('ve-panel-concurrency-changed',fn);return()=>window.removeEventListener('ve-panel-concurrency-changed',fn);},[]);
  useEffect(() => {
    let timer=null;
    const handleVarsUpdated = () => {
      if(timer)clearTimeout(timer);
      timer=setTimeout(load,80);
    };
    window.addEventListener('ve-variables-updated', handleVarsUpdated);
    window.addEventListener('ve:variables-updated', handleVarsUpdated);
    return () => {
      if(timer)clearTimeout(timer);
      window.removeEventListener('ve-variables-updated', handleVarsUpdated);
      window.removeEventListener('ve:variables-updated', handleVarsUpdated);
    };
  }, [load]);
  useEffect(() => {
    const handleSettingsUpdated = () => {
      api.g('settings').then(d => {
        if(d) {
          if(d.vw_min)_veViewport={vw_min:+d.vw_min||320,vw_max:+d.vw_max||1440};
          if(typeof d.allow_multi_panels !== 'undefined') sAllowMultiPanels(!!d.allow_multi_panels);
          if(typeof d.show_all_tab !== 'undefined') sShowAllTab(!!d.show_all_tab);
          if(typeof d.media_replace_wp_library !== 'undefined') {
            setMediaReplaceLibrary(!!d.media_replace_wp_library);
            persistUserPreference('ve_media_replace_wp_library', d.media_replace_wp_library ? '1' : '0');
          }
          if(typeof d.media_auto_sync_external_folders !== 'undefined') {
            setMediaAutoSyncExternalFolders(!!d.media_auto_sync_external_folders);
            persistUserPreference('ve_media_auto_sync_external_folders', d.media_auto_sync_external_folders ? '1' : '0');
          }
          const freshDisabled = disabledToolsForCurrentSurface(d);
          setDeactivatedTools(freshDisabled);
          deactivatedToolsRef.current = freshDisabled;
          broadcastDisabledTools(d, freshDisabled);
          requestAnimationFrame(closeDisabledModulesNow);
        }
      }).catch(()=>{});
    };
    window.addEventListener('ve-settings-updated', handleSettingsUpdated);
    return () => window.removeEventListener('ve-settings-updated', handleSettingsUpdated);
  }, [closeDisabledModulesNow]);
  useEffect(()=>{if(autoGen){const v=vars.find(x=>x.id===autoGen.id||x.name===autoGen.name);if(v){sSub({type:'genScale',v});sAG(null);}};},[vars,autoGen]);
  
  // Shortcuts and custom toggle triggers
  const toggleVariablePanel = useCallback(() => {
    if (isToolDisabledNow('variables')) {
      flash(moduleLabel('variables') + ' is disabled for this surface in Settings → Modules.');
      return;
    }
    sO(p=>!p);
    setTimeout(()=>sRef.current?.focus(),80);
  }, [isToolDisabledNow, flash]);
  useEffect(() => {
    window.veToggleVariables = toggleVariablePanel;
    window.veOpenSettings = () => sSettingsOpen(true);
    window.veCloseAllPanels = () => {
      sO(false); sSettingsOpen(false); sHelpOpen(false); sCssStudioOpen(false); sContentStudioOpen(false); sMediaStudioOpen(false); sPluginStudioOpen(false); sCssRecipesOpen(false);
    };
    return () => {
      if (window.veToggleVariables === toggleVariablePanel) delete window.veToggleVariables;
      delete window.veOpenSettings;
      delete window.veCloseAllPanels;
    };
  }, [toggleVariablePanel]);
  useEffect(()=>{const fn=e=>{const active=document.activeElement;if(active&&(active.tagName==='INPUT'||active.tagName==='TEXTAREA'||active.isContentEditable||active.closest('input,textarea,select,[contenteditable="true"]')))return;if(e.altKey&&(e.key==='z'||e.key==='Z')){e.preventDefault();toggleVariablePanel();}};document.addEventListener('keydown',fn);return()=>document.removeEventListener('keydown',fn);},[toggleVariablePanel]);
  useEffect(()=>{window.addEventListener('ve-toggle-panel',toggleVariablePanel);return()=>window.removeEventListener('ve-toggle-panel',toggleVariablePanel);},[toggleVariablePanel]);
  
  // Standalone panel toggle events (for Alt+Q / Speed Dial / Global messaging delegation)
  useEffect(() => {
    const toggleSettings = () => sSettingsOpen(prev => !prev);
    const toggleHelp = () => sHelpOpen(prev => !prev);
    const toggleCss = () => openModuleIfEnabled('css_studio', () => sCssStudioOpen(prev => !prev));
    const toggleRecipes = () => openModuleIfEnabled('css_recipes', () => sCssRecipesOpen(prev => !prev));
    const toggleContent = () => openModuleIfEnabled('content_studio', () => sContentStudioOpen(prev => !prev));
    const toggleMedia = () => openModuleIfEnabled('media_studio', () => sMediaStudioOpen(prev => !prev));
    const togglePlugin = () => openModuleIfEnabled('plugin_studio', () => sPluginStudioOpen(prev => !prev));
    const requestMimamsBar = () => {
      window.dispatchEvent(new CustomEvent('ve-mimams-bar-toggle-request'));
    };
    const toggleMimamsBar = () => openModuleIfEnabled('mimams_bar', requestMimamsBar);
    window.addEventListener('ve-toggle-settings', toggleSettings);
    window.addEventListener('ve-toggle-help', toggleHelp);
    window.addEventListener('ve-toggle-css', toggleCss);
    window.addEventListener('ve-toggle-css-recipes', toggleRecipes);
    window.addEventListener('ve-toggle-content', toggleContent);
    window.addEventListener('ve-toggle-media', toggleMedia);
    window.addEventListener('ve-toggle-plugin', togglePlugin);
    window.addEventListener('ve-toggle-plugin-studio', togglePlugin);
    window.addEventListener('ve-toggle-mimams-bar', toggleMimamsBar);
    return () => {
      window.removeEventListener('ve-toggle-settings', toggleSettings);
      window.removeEventListener('ve-toggle-help', toggleHelp);
      window.removeEventListener('ve-toggle-css', toggleCss);
      window.removeEventListener('ve-toggle-css-recipes', toggleRecipes);
      window.removeEventListener('ve-toggle-content', toggleContent);
      window.removeEventListener('ve-toggle-media', toggleMedia);
      window.removeEventListener('ve-toggle-plugin', togglePlugin);
      window.removeEventListener('ve-toggle-plugin-studio', togglePlugin);
      window.removeEventListener('ve-toggle-mimams-bar', toggleMimamsBar);
    };
  }, [openModuleIfEnabled]);
  useEffect(() => {
    const onReplace = e => {
      const value = !!e.detail;
      setMediaReplaceLibrary(value);
      persistUserPreference('ve_media_replace_wp_library', value ? '1' : '0');
      if (isNativeMediaLibraryPage) {
        setTimeout(() => { try { window.location.reload(); } catch(err) {} }, 100);
      }

    };
    const onAutoSync = e => {
      const value = !!e.detail;
      setMediaAutoSyncExternalFolders(value);
      persistUserPreference('ve_media_auto_sync_external_folders', value ? '1' : '0');
    };
    window.addEventListener('ve-media-replace-library-changed', onReplace);
    window.addEventListener('ve-media-auto-sync-external-folders-changed', onAutoSync);
    return () => {
      window.removeEventListener('ve-media-replace-library-changed', onReplace);
      window.removeEventListener('ve-media-auto-sync-external-folders-changed', onAutoSync);
    };
  }, []);
  useEffect(() => {
    if (MODE !== 'admin') return;
    document.body.classList.toggle('ve-native-media-page-active', !!nativeMediaPageActive);
    return () => document.body.classList.remove('ve-native-media-page-active');
  }, [nativeMediaPageActive]);
  useEffect(() => {
    if (MODE !== 'admin') return;
    if (!nativeMediaPageActive) return;
    const root = document.getElementById('ve-panel-root');
    const host = document.getElementById('wpbody-content');
    if (!root || !host) return;
    const originalParent = root.parentNode || document.body;
    const originalNext = root.nextSibling;
    if (root.parentNode !== host || root !== host.firstChild) {
      host.insertBefore(root, host.firstChild);
    }
    try { host.style.paddingTop = '0'; host.style.marginTop = '0'; window.scrollTo({ top: 0, left: 0, behavior: 'auto' }); } catch(e) {}
    const scrollTimer = setTimeout(() => { try { window.scrollTo(0, 0); } catch(e) {} }, 60);
    return () => {
      clearTimeout(scrollTimer);
      if (!root || !root.parentNode) return;
      if (originalParent && originalParent.isConnected) {
        if (originalNext && originalNext.parentNode === originalParent) originalParent.insertBefore(root, originalNext);
        else originalParent.appendChild(root);
      } else {
        document.body.appendChild(root);
      }
    };
  }, [nativeMediaPageActive]);
  useEffect(() => {
    if ((!mediaStudioOpen && !nativeMediaPageActive) || !mediaAutoSyncExternalFolders || isToolDisabledNow('media_studio')) return;
    try { window.dispatchEvent(new CustomEvent('ve-media-sync-external-folders')); } catch(e) {}
  }, [mediaStudioOpen, nativeMediaPageActive, mediaAutoSyncExternalFolders, deactivatedTools]);

  // Global PointerDown outside click checks
  useEffect(() => {
    const handleOutsideClick = e => {
      const target = e.target;
      if (!target) return;

      if (target.closest('.ve-category-context')) {
        return;
      }
      if (categoryMenu) {
        sCategoryMenu(null);
      }

      if (target.closest('.CodeMirror-hints') || target.closest('.ve-suggest') || target.closest('.ve-ac') || target.closest('.ve-menu-list')) {
        return;
      }
      
      if (target.closest('.ve-fab-wrap') || target.closest('.ve-fab-menu') || target.closest('.ve-fab') || target.closest('#wp-admin-bar-ve-toggle')) {
        return;
      }

      const clickedAnyPanel = target.closest('.ve-o') || target.closest('.ve-o.ve-sidecar') || target.closest('.ve-standalone-panel');

      if (nativeMediaPageActive && !target.closest('.ve-native-media-page-shell') && !target.closest('.ve-modal') && !target.closest('.ve-menu-list') && !target.closest('.ve-fab-wrap') && !target.closest('#wpadminbar')) {
        closeNativeMediaReplacement();
        return;
      }

      if (!clickedAnyPanel) {
        if (open) {
          const panelEl = panelRef.current;
          if (panelEl && !panelEl.contains(target) && !target.closest('.ve-cf-b') && !target.closest('.ve-modal')) {
            sO(false);
          }
        }

        if (settingsOpen) {
          const settingsEl = document.querySelector('.ve-standalone-panel[data-panel="settings"]');
          if (settingsEl && !settingsEl.contains(target)) {
            sSettingsOpen(false);
          }
        }

        if (helpOpen) {
          const helpEl = document.querySelector('.ve-standalone-panel[data-panel="help"]');
          if (helpEl && !helpEl.contains(target)) {
            sHelpOpen(false);
          }
        }

        if (cssStudioOpen) {
          const cssEl = document.querySelector('.ve-standalone-panel[data-panel="css_studio"]');
          if (cssEl && !cssEl.contains(target) && !target.closest('.CodeMirror-dialog') && !target.closest('.ve-o.ve-sidecar')) {
            sCssStudioOpen(false);
          }
        }

        if (contentStudioOpen) {
          const contentEl = document.querySelector('.ve-standalone-panel[data-panel="content_studio"]');
          if (contentEl && !contentEl.contains(target) && !target.closest('.ve-modal')) {
            sContentStudioOpen(false);
          }
        }

        if (mediaStudioOpen) {
          const mediaEl = document.querySelector('.ve-standalone-panel[data-panel="media_studio"]');
          if (mediaEl && !mediaEl.contains(target) && !target.closest('.ve-modal')) {
            mediaTargetRef.current = null;
            sMediaStudioOpen(false);
          }
        }

        if (pluginStudioOpen) {
          const pluginEl = document.querySelector('.ve-standalone-panel[data-panel="plugin_studio"]');
          if (pluginEl && !pluginEl.contains(target) && !target.closest('.ve-modal')) {
            sPluginStudioOpen(false);
          }
        }

        if (cssRecipesOpen) {
          const recipesEl = document.querySelector('.ve-standalone-panel[data-panel="css_recipes"]');
          if (recipesEl && !recipesEl.contains(target) && !target.closest('.ve-modal')) {
            sCssRecipesOpen(false);
          }
        }
      }
    };

    document.addEventListener('pointerdown', handleOutsideClick, true);
    return () => {
      document.removeEventListener('pointerdown', handleOutsideClick, true);
    };
  }, [open, settingsOpen, helpOpen, cssStudioOpen, contentStudioOpen, mediaStudioOpen, pluginStudioOpen, cssRecipesOpen, categoryMenu, nativeMediaPageActive, closeNativeMediaReplacement]);

  const genSort=useCallback((a,b)=>{
    if(String(a?.generator_type||'')==='imported'&&String(b?.generator_type||'')==='imported'){
      const tshirtRank=name=>{
        const match=String(name||'').toLowerCase().match(/(?:-|\.)(8xs|7xs|6xs|5xs|4xs|3xs|2xs|xs|s|m|l|xl|2xl|3xl|4xl|5xl|6xl|7xl|8xl)$/);
        if(!match)return null;
        return ['8xs','7xs','6xs','5xs','4xs','3xs','2xs','xs','s','m','l','xl','2xl','3xl','4xl','5xl','6xl','7xl','8xl'].indexOf(match[1]);
      };
      const ar=tshirtRank(a.name),br=tshirtRank(b.name);
      if(ar!==null&&br!==null&&ar!==br)return ar-br;
      const an=String(a.name||'').match(/(?:-|\.)(\d+)$/),bn=String(b.name||'').match(/(?:-|\.)(\d+)$/);
      if(an&&bn&&Number(an[1])!==Number(bn[1]))return Number(an[1])-Number(bn[1]);
      if((ar!==null)!==(br!==null)){
        const av=pxV(a.value),bv=pxV(b.value);
        if(av!==bv)return av-bv;
      }
      return String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true,sensitivity:'base'});
    }
    const av=pxV(a.value), bv=pxV(b.value);
    if(av!==bv)return av-bv;
    return String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true,sensitivity:'base'});
  },[]);

  const{bases,childMap,namespaces}=useMemo(()=>{
    const cm={};const bs=[];
    vars.forEach(v=>{if(v.type==='generated'&&v.source_id){if(!cm[v.source_id])cm[v.source_id]=[];cm[v.source_id].push(v);}});
    Object.keys(cm).forEach(k=>cm[k].sort(genSort));
    vars.forEach(v=>{if(v.type!=='generated')bs.push(v);});
    bs.sort((a,b)=>{const ap=a.position!==undefined?a.position:0;const bp=b.position!==undefined?b.position:0;if(ap!==bp)return ap-bp;return String(a.name||'').localeCompare(String(b.name||''),undefined,{numeric:true,sensitivity:'base'});});
    const list=['color',...(variableCategoriesData.categories||[]).map(category=>category.slug)];
    return{bases:bs,childMap:cm,namespaces:showAllTab?['all',...list]:list};
  },[vars,genSort,showAllTab,variableCategoriesData]);

  const allCats=useMemo(()=>variableCategoriesData.categories||[],[variableCategoriesData]);
  const categoryNames=useMemo(()=>{
    const map={all:'All',color:'Color'};
    allCats.forEach(category=>{map[category.slug]=category.name;});
    return map;
  },[allCats]);

  useEffect(() => {
    if (!showAllTab && nsTab === 'all') {
      const list = namespaces.filter(n => n !== 'all');
      if (list.length) sNT(list[0]);
    }
  }, [showAllTab, nsTab, namespaces]);
  useEffect(()=>{
    if(selectedColorPalette!=='all'&&!(colorPalettesData.palettes||[]).some(p=>String(p.id)===String(selectedColorPalette))){
      sSelectedColorPalette('all');
    }
  },[colorPalettesData,selectedColorPalette]);

  const maxSp=useMemo(()=>{let mx=0;vars.forEach(v=>{if(v.namespace==='space'){const n=pxV(v.value);if(n>mx)mx=n;}});return mx||1;},[vars]);
  const scopedBases=useMemo(()=>{
    let list=nsTab==='all'?bases:bases.filter(v=>variableNamespace(v)===nsTab);
    if(nsTab==='color'&&selectedColorPalette!=='all'){
      list=list.filter(v=>String(v.palette_id||0)===String(selectedColorPalette));
    }
    return list;
  },[bases,nsTab,selectedColorPalette]);
  const sourceCounts=useMemo(()=>{
    const counts={all:0,mv:0,file:0,figma:0,at:0,cf:0,acss:0};
    scopedBases.forEach(root=>{
      [root,...(childMap[root.id]||[])].forEach(variable=>{
        const key=normalizedVariableOrigin(variable);
        counts.all++;
        counts[key]=(counts[key]||0)+1;
      });
    });
    return counts;
  },[scopedBases,childMap]);
  const filteredChildMap=useMemo(()=>{
    if(sourceFilter==='all')return childMap;
    const map={};
    scopedBases.forEach(root=>{
      map[root.id]=(childMap[root.id]||[]).filter(child=>normalizedVariableOrigin(child)===sourceFilter);
    });
    return map;
  },[childMap,scopedBases,sourceFilter]);
  const filtered=useMemo(()=>{
    let list=scopedBases;
    if(sourceFilter!=='all'){
      list=list.filter(v=>normalizedVariableOrigin(v)===sourceFilter||(filteredChildMap[v.id]||[]).length>0);
    }
    if(sr){
      const q=sr.toLowerCase();
      const mp=new Set();
      vars.forEach(v=>{
        if(v.type==='generated'&&v.source_id&&(sourceFilter==='all'||normalizedVariableOrigin(v)===sourceFilter)&&fuzzy(q,v.nameLower||(v.nameLower=v.name.toLowerCase())).m)mp.add(String(v.source_id));
      });
      list=list.map(v=>({
        ...v,
        ...fuzzy(q,v.nameLower||(v.nameLower=v.name.toLowerCase())),
        cm:mp.has(String(v.id))
      })).filter(v=>v.m||v.cm).sort((a,b)=>(b.s||0)-(a.s||0));
    }
    return list;
  },[scopedBases,filteredChildMap,vars,sr,sourceFilter]);
  const[visibleVariableLimit,sVisibleVariableLimit]=useState(100);
  useEffect(()=>{sVisibleVariableLimit(100);},[nsTab,sr,selectedColorPalette,sourceFilter]);
  const visibleFiltered=useMemo(
    ()=>filtered.slice(0,visibleVariableLimit),
    [filtered,visibleVariableLimit]
  );
  const visibleSelectionIds=useMemo(()=>{
    const ids=[];
    visibleFiltered.forEach(variable=>{
      ids.push(Number(variable.id));
      const expKey=String(variable.id);
      const expanded=sr?true:(Object.prototype.hasOwnProperty.call(exp,expKey)?!!exp[expKey]:false);
      if(expanded)(filteredChildMap[variable.id]||[]).forEach(child=>ids.push(Number(child.id)));
    });
    return ids;
  },[visibleFiltered,filteredChildMap,exp,sr]);
  const sourceSelectionIds=useMemo(()=>{
    const ids=[];
    filtered.forEach(root=>{
      if(sourceFilter==='all'||normalizedVariableOrigin(root)===sourceFilter)ids.push(Number(root.id));
      (filteredChildMap[root.id]||[]).forEach(child=>{
        if(sourceFilter==='all'||normalizedVariableOrigin(child)===sourceFilter)ids.push(Number(child.id));
      });
    });
    return [...new Set(ids)];
  },[filtered,filteredChildMap,sourceFilter]);
  const selectCurrentSource=()=>{
    if(!sourceSelectionIds.length)return;
    sCheckedVars(previous=>[...new Set([...previous.map(Number),...sourceSelectionIds])]);
  };
  const selectedVariables=useMemo(
    ()=>checkedVars.map(id=>vars.find(variable=>Number(variable.id)===Number(id))).filter(Boolean),
    [checkedVars,vars]
  );
  const visibleSelectionSet=useMemo(()=>new Set(visibleSelectionIds.map(Number)),[visibleSelectionIds]);
  const hiddenSelectedCount=useMemo(
    ()=>selectedVariables.filter(variable=>!visibleSelectionSet.has(Number(variable.id))).length,
    [selectedVariables,visibleSelectionSet]
  );
  const hiddenSelectionKey=useMemo(
    ()=>selectedVariables.filter(variable=>!visibleSelectionSet.has(Number(variable.id))).map(variable=>Number(variable.id)).sort((a,b)=>a-b).join(','),
    [selectedVariables,visibleSelectionSet]
  );
  useEffect(()=>{
    if(!vars.length)return;
    const validIds=new Set(vars.map(variable=>Number(variable.id)));
    sCheckedVars(previous=>{
      const next=previous.filter(id=>validIds.has(Number(id)));
      return next.length===previous.length?previous:next;
    });
  },[vars]);
  useEffect(()=>{
    if(!checkedVars.length)sSelectionReviewOpen(false);
  },[checkedVars.length]);
  useEffect(()=>{
    if(!hiddenSelectionKey){
      lastAutoOpenedHiddenSelectionRef.current='';
      return;
    }
    if(hiddenSelectionKey!==lastAutoOpenedHiddenSelectionRef.current){
      lastAutoOpenedHiddenSelectionRef.current=hiddenSelectionKey;
      sSelectionReviewOpen(true);
    }
  },[hiddenSelectionKey]);
  const cleanupIssues=useMemo(()=>stats?[(stats.stale_generated?stats.stale_generated+' stale generated':''),(stats.orphan_generated?stats.orphan_generated+' orphan generated':''),(stats.missing_dependencies?stats.missing_dependencies+' missing dependency links':''),(stats.orphan_dependencies?stats.orphan_dependencies+' orphan dependency rows':''),(stats.duplicate_count?stats.duplicate_count+' duplicate names':''),(stats.older_generators?stats.older_generators+' older generators':'')].filter(Boolean):[],[stats]);
  const manualIntegrityNotices=useMemo(()=>stats?[(stats.public_name_conflict_count?stats.public_name_conflict_count+' CSS name conflicts require manual rename':''),(stats.broken_aliases?stats.broken_aliases+' aliases have missing sources and require manual relinking':''),(stats.blocked_orphan_generated?stats.blocked_orphan_generated+' orphan generated variables still have dependents and require review':'')].filter(Boolean):[],[stats]);
  const hasAvailableUpdate=!!(updateInfo?.update_available&&updateInfo.latest_version!==skipUpdate);

  const setPanelMode=m=>{sPanelMode(m);persistUserPreference('ve_panel_mode',m);};
  const startPanelDrag=e=>{
    if(e.button!==0)return;
    const currentLeft=panelMode==='left'?0:(panelMode==='right'?Math.max(16,window.innerWidth-430):(panelPos.left||Math.max(16,window.innerWidth-430)));
    const currentTop=panelMode==='float'?(panelPos.top||16):16;
    const startLeft=Math.max(8,Math.min(window.innerWidth-120,currentLeft));
    const startTop=Math.max(8,Math.min(window.innerHeight-90,currentTop));
    dragRef.current={x:e.clientX,y:e.clientY,left:startLeft,top:startTop};
    sPanelMode('float');
    persistUserPreference('ve_panel_mode','float');
    sPanelPos({left:startLeft,top:startTop});
    const el=panelRef.current;
    if(el){el.classList.add('ve-dragging');el.style.left=startLeft+'px';el.style.top=startTop+'px';el.style.right='auto';}
    document.querySelector('#ve-panel-root .ve-hdr')?.classList.add('dragging');
    e.preventDefault();
  };
  useEffect(()=>{
    const move=e=>{
      const d=dragRef.current;if(!d)return;
      const el=panelRef.current;
      const w=el?el.offsetWidth:410;
      const hgt=el?el.offsetHeight:760;
      const maxLeft=Math.max(8,window.innerWidth-w-8);
      const maxTop=Math.max(8,window.innerHeight-hgt-8);
      const next={left:Math.max(8,Math.min(maxLeft,d.left+(e.clientX-d.x))),top:Math.max(8,Math.min(maxTop,d.top+(e.clientY-d.y)))};
      d.last=next;
      if(el){el.style.left=next.left+'px';el.style.top=next.top+'px';el.style.right='auto';}
      const cur=snapRef.current;
      let side='';
      if(cur==='left')side=next.left<190?'left':'';
      else if(cur==='right')side=next.left>maxLeft-190?'right':'';
      else side=next.left<72?'left':(next.left>maxLeft-72?'right':'');
      if(side!==snapRef.current){snapRef.current=side;sSnapSide(side);}
    };
    const up=()=>{
      if(!dragRef.current)return;
      const side=snapRef.current;
      const last=dragRef.current.last||panelPos;
      if(side==='left'||side==='right'){
        sPanelMode(side);
        persistUserPreference('ve_panel_mode',side);
      }else{
        sPanelPos(last);
        persistUserPreference('ve_panel_pos',last);
      }
      panelRef.current?.classList.remove('ve-dragging');
      dragRef.current=null;
      snapRef.current='';
      sSnapSide('');
      document.querySelector('#ve-panel-root .ve-hdr')?.classList.remove('dragging');
    };
    window.addEventListener('mousemove',move);window.addEventListener('mouseup',up);
    return()=>{window.removeEventListener('mousemove',move);window.removeEventListener('mouseup',up);};
  },[panelPos]);
  const cpVar=n=>{navigator.clipboard?.writeText('var('+cssTokenName(n)+')');flash('Copied!');};
  const openRowActions=id=>{if(rowActionsTimerRef.current)clearTimeout(rowActionsTimerRef.current);rowActionsTimerRef.current=null;sRowActions(String(id));};
  const scheduleRowActionsClose=id=>{
    if(rowActionsTimerRef.current)clearTimeout(rowActionsTimerRef.current);
    rowActionsTimerRef.current=setTimeout(()=>{
      const row=document.querySelector('[data-ve-variable-row="'+String(id)+'"]');
      if(!row?.matches(':hover')&&!row?.matches(':focus-within'))sRowActions(current=>current===String(id)?null:current);
    },220);
  };

  const tgExp=(id,defaultOpen=false)=>sExp(p=>{const k=String(id);const has=Object.prototype.hasOwnProperty.call(p,k);return {...p,[k]:has?!p[k]:!defaultOpen};});
  const cleanDbFooter=async()=>{
    sConfirmCleanFooter(false);
    try{flash('Cleaning...');const r=await api.p('variables/cleanup',{});await load();flash(r?.message||'Cleaned');}
    catch(e){flash('Cleanup failed');}
  };
  const [confirmDuplicate, sConfirmDuplicate] = useState(null);
  const [paletteTransfer, sPaletteTransfer] = useState(null);
  const hDup = v => {
    sConfirmDuplicate(v);
  };
  const cfmDup = async () => {
    if (!confirmDuplicate) return;
    const v = confirmDuplicate;
    sConfirmDuplicate(null);
    try {
      const res = v.palette_eligible&&v.palette_id
        ? await api.p('color-palettes/variables/'+v.id+'/copy',{palette_id:Number(v.palette_id),name:sn(v.name)+'-copy',include_generated:true})
        : await api.p('variables', { name: v.name + '.copy', value: v.value });
      if (res && res.code) {
        flash(res.message || 'Duplication failed');
      } else {
        load();
        flash('Duplicated');
      }
    } catch(e) {
      flash('Duplication failed');
    }
  };
  const openPaletteTransfer=(mode,v)=>{
    const destinations=(colorPalettesData.palettes||[]).filter(p=>mode==='copy'||String(p.id)!==String(v.palette_id||0));
    sPaletteTransfer({
      mode,
      variable:v,
      paletteId:destinations[0]?String(destinations[0].id):'',
      name:mode==='copy'?sn(v.name)+'-copy':sn(v.name),
      includeGenerated:true
    });
  };
  const runPaletteTransfer=async()=>{
    if(!paletteTransfer||!paletteTransfer.paletteId)return;
    const t=paletteTransfer;
    sPaletteTransfer(null);
    try{
      const path='color-palettes/variables/'+t.variable.id+'/'+t.mode;
      const body={palette_id:Number(t.paletteId)};
      if(t.mode==='copy'){body.name=t.name;body.include_generated=!!t.includeGenerated;}
      const res=await api.p(path,body);
      if(res?.code){flash(res.message||('Could not '+t.mode+' color'));return;}
      await load();
      flash(t.mode==='copy'?'Color copied to palette':'Color moved to palette');
    }catch(e){flash('Palette operation failed');}
  };
  const hDel = v => {
    sCfm(v);
  };
  const cfmDel = async () => {
    if (!cfm) return;
    try {
      const res = await api.d('variables/' + cfm.id + '?force=true');
      if (res && res.code) {
        flash(res.message || 'Delete failed');
      } else {
        load();
        flash('Deleted');
        sSel(null);
        sCfm(null);
      }
    } catch(e) {
      flash('Delete failed');
    }
  };
  const hCreated=(nv,isClamp)=>{load();sSub(null);flash('Created');if(isClamp)sAG(nv);};

  // Theme value-layer management states
  const [paletteManagerOpen, sPaletteManagerOpen] = useState(() => localStorage.getItem('ve_palette_mgr_open') === '1');
  const [paletteName, sPaletteName] = useState('');
  const [editingPalette, sEditingPalette] = useState(null);
  const [editPaletteName, sEditPaletteName] = useState('');
  const [paletteLd, sPaletteLd] = useState(false);
  const [paletteErr, sPaletteErr] = useState('');
  const [confirmDeletePalette, sConfirmDeletePalette] = useState(null);

  const togglePaletteManager = (val) => {
    sPaletteManagerOpen(val);
    localStorage.setItem('ve_palette_mgr_open', val ? '1' : '0');
  };
  const toggleColorPaletteManager = val => {
    sColorPaletteManagerOpen(val);
    localStorage.setItem('ve_color_palette_mgr_open',val?'1':'0');
  };
  const chooseColorControlMode = mode => {
    const next=mode==='palette'?'palette':'theme';
    sColorControlMode(next);
    localStorage.setItem('ve_color_control_mode',next);
    if(next==='theme')toggleColorPaletteManager(false);
    else togglePaletteManager(false);
  };
  const navigateVariableUsage=(item)=>{
    if(!item)return;
    sCfm(null);
    sConfirmBatchDelete(false);
    if(item.type==='variable'){
      const target=vars.find(variable=>Number(variable.id)===Number(item.id)||String(variable.name)===String(item.name));
      if(target){sSub(null);sSel(target);}
      return;
    }
    if(item.type==='theme'){
      sSub(null);sNT('color');chooseColorControlMode('theme');togglePaletteManager(true);return;
    }
    if(item.type==='css_studio'){
      sUsageCssSheet(String(item.id||''));sCssStudioOpen(true);return;
    }
    if(item.type==='css_recipe'){
      sUsageRecipeCode(String(item.id||''));sCssRecipesOpen(true);return;
    }
    if(item.type==='bricks'&&item.element&&window.MimamsBarBricksAdapter){
      try{window.MimamsBarBricksAdapter.selectElement(item.element,{focusStructure:true});}catch(e){flash('Could not open that Bricks element');}
    }
  };

  // Theme actions
  const createPalette = async () => {
    if (!paletteName.trim()) return;
    sPaletteLd(true);
    sPaletteErr('');
    try {
      const res = await api.p('themes', { name: paletteName.trim(), source_slug: palettesData.active });
      sPaletteLd(false);
      if (res?.code) {
        sPaletteErr(res.message || 'Could not create theme.');
      } else {
        sPaletteName('');
        await load();
        flash('Theme created');
      }
    } catch(e) {
      sPaletteLd(false);
      sPaletteErr('Could not create theme.');
    }
  };

  const duplicatePalette = async (p) => {
    sPaletteLd(true);
    sPaletteErr('');
    try {
      const res = await api.p('themes/' + p.slug + '/duplicate', { name: p.name + ' Copy' });
      sPaletteLd(false);
      if (res?.code) {
        sPaletteErr(res.message || 'Could not duplicate theme.');
      } else {
        await load();
        flash('Theme duplicated');
      }
    } catch(e) {
      sPaletteLd(false);
      sPaletteErr('Could not duplicate theme.');
    }
  };

  const renamePalette = async () => {
    if (!editingPalette || !editPaletteName.trim()) return;
    sPaletteLd(true);
    sPaletteErr('');
    try {
      const res = await api.u('themes/' + editingPalette, { name: editPaletteName.trim() });
      sPaletteLd(false);
      if (res?.code) {
        sPaletteErr(res.message || 'Could not rename theme.');
      } else {
        sEditingPalette(null);
        sEditPaletteName('');
        await load();
        flash('Theme renamed');
      }
    } catch(e) {
      sPaletteLd(false);
      sPaletteErr('Could not rename theme.');
    }
  };

  const deletePalette = async () => {
    if (!confirmDeletePalette) return;
    const slug = confirmDeletePalette.slug;
    sConfirmDeletePalette(null);
    sPaletteLd(true);
    sPaletteErr('');
    try {
      const res = await api.d('themes/' + slug);
      sPaletteLd(false);
      if (res?.code) {
        sPaletteErr(res.message || 'Could not delete theme.');
      } else {
        await load();
        flash('Theme deleted');
      }
    } catch(e) {
      sPaletteLd(false);
      sPaletteErr('Could not delete theme.');
    }
  };

  const[subExit,sSE]=useState(false);
  const closeSub=useCallback(()=>{sSE(true);setTimeout(()=>{sSub(null);sSE(false);},SLIDE_MS);},[]);

  useEffect(()=>{
    const root=document.getElementById('ve-panel-root');
    const clamp=(value,min,max)=>Math.max(min,Math.min(max,value));
    const show=e=>{
      const el=e.target?.closest&&e.target.closest('[title],[data-ve-title]');
      if(!el||!root||!root.contains(el))return;
      let text=el.getAttribute('data-ve-title')||el.getAttribute('title')||'';
      if(!text)return;
      if(el.hasAttribute('title')){
        el.setAttribute('data-ve-title',text);
        el.removeAttribute('title');
      }
      const rect=el.getBoundingClientRect();
      const w=Math.min(260,Math.max(140,text.length*6+28));
      const estimatedLines=Math.max(1,Math.ceil(text.length/38));
      const estimatedHeight=Math.min(170,Math.max(34,20+(estimatedLines*16)));
      let left=rect.left+(rect.width/2)-(w/2);
      let top=rect.top-estimatedHeight-12;

      // Keep the tooltip completely off the hovered control/cursor.
      // Native title bubbles often sit on the pointer; MV tips should live
      // outside the target rectangle, then fall back to a side placement.
      if(top<8){
        top=rect.bottom+12;
        if(top+estimatedHeight>window.innerHeight-8){
          const sideSpaceRight=window.innerWidth-rect.right;
          const sideSpaceLeft=rect.left;
          if(sideSpaceRight>=w+16){
            left=rect.right+12;
          }else if(sideSpaceLeft>=w+16){
            left=rect.left-w-12;
          }
          top=rect.top+(rect.height/2)-(estimatedHeight/2);
        }
      }
      left=clamp(left,8,window.innerWidth-w-8);
      top=clamp(top,8,window.innerHeight-estimatedHeight-8);
      sMvTip({text,left,top,width:w});
    };
    const hide=e=>{
      if(e?.relatedTarget&&e.target?.contains&&e.target.contains(e.relatedTarget))return;
      sMvTip(null);
    };
    document.addEventListener('mouseover',show,true);
    document.addEventListener('mouseout',hide,true);
    return()=>{
      document.removeEventListener('mouseover',show,true);
      document.removeEventListener('mouseout',hide,true);
    };
  },[]);
  const fabActions={
    variables:()=>sO(prev=>!prev),
    help:()=>sHelpOpen(prev=>!prev),
    css_studio:()=>openModuleIfEnabled('css_studio',()=>sCssStudioOpen(prev=>!prev)),
    css_recipes:()=>openModuleIfEnabled('css_recipes',()=>sCssRecipesOpen(prev=>!prev)),
    content_studio:()=>openModuleIfEnabled('content_studio',()=>sContentStudioOpen(prev=>!prev)),
    media_studio:()=>openModuleIfEnabled('media_studio',()=>sMediaStudioOpen(prev=>!prev)),
    plugin_studio:()=>openModuleIfEnabled('plugin_studio',()=>sPluginStudioOpen(prev=>!prev)),
    mimams_bar:()=>openModuleIfEnabled('mimams_bar',()=>{
      window.dispatchEvent(new CustomEvent('ve-mimams-bar-toggle-request'));
    })
  };

  return h('div',null,
    updateComplete&&h('div',{class:'ve-modal ve-update-refresh-modal'},
      h('div',{class:'ve-modal-box'},
        h('div',{class:'ve-modal-title'},'Update installed'),
        h('div',{class:'ve-modal-body'},(updateComplete.message||"Mimam's Var was updated successfully.")+' Refresh this page now to load the updated panel and runtime files.'),
        h('div',{class:'ve-modal-actions'},
          h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sUpdateComplete(null)},'Later'),
          h('button',{class:'ve-btn ve-btn-s',onClick:()=>window.location.reload()},'Refresh Now')))),
    h('div',{class:'ve-toast'+(toast?' show':'')},toast&&h('span',{class:'ve-toast-ring',key:toastTick}),toast),
    mvTip&&h('div',{class:'ve-tooltip-card ve-global-tip',style:{left:mvTip.left+'px',top:mvTip.top+'px',width:mvTip.width+'px'}},mvTip.text),
    nativeMediaPageActive && h('div',{class:'ve-native-media-page'},
      h('div',{class:'ve-native-media-page-shell'},
        h('div',{class:'ve-native-media-page-head'},
          h('span',null,ph('images'),' Media Studio'),
          h('div',{style:'display:flex;align-items:center;gap:8px'},
            h('span',{style:'font-size:11px;color:#888;font-weight:600'},'Native Media Library replacement'),
            h('button',{type:'button',class:'ve-btn ve-btn-g ve-btn-s',onClick:closeNativeMediaReplacement},'Use legacy library'),
            h('button',{type:'button',class:'ve-native-media-page-close',onClick:closeNativeMediaReplacement,title:'Close Media Studio'},ph('x'))
          )
        ),
        h(MediaStudioSub,{
          onClose: closeNativeMediaReplacement,
          flash,
          picking:false,
          initialFilter:'',
          pageMode:true
        })
      )
    ),
    categoryMenu&&h('div',{
      class:'ve-menu-list ve-category-context',
      style:{left:categoryMenu.x+'px',top:categoryMenu.y+'px'}
    },
      h('button',{
        type:'button',
        class:'ve-menu-item',
        disabled:categoryMenu.protected,
        title:categoryMenu.protected?'System categories cannot be renamed':'Rename category',
        onClick:()=>{if(categoryMenu.protected)return;sEditingCategory(categoryMenu.category);sCategoryEditName(categoryMenu.category.name);sCategoryMenu(null);}
      },ph('pencil-simple'),' Rename'),
      h('button',{
        type:'button',
        class:'ve-menu-item danger',
        disabled:categoryMenu.protected,
        title:categoryMenu.protected?'System categories cannot be removed':'Remove category',
        style:categoryMenu.protected?'':'color:#ef4444',
        onClick:()=>{if(categoryMenu.protected)return;sConfirmCategoryDelete(categoryMenu.category);sCategoryMenu(null);}
      },ph('trash'),' Remove')
    ),
      h('div',{ref:fabRef,class:'ve-fab-wrap' + (fabToolsOpen ? ' ve-fab-tools-open' : '') + (open || settingsOpen || helpOpen || cssStudioOpen || contentStudioOpen || mediaStudioStandaloneOpen || pluginStudioOpen || cssRecipesOpen ? ' ve-fab-hidden' : ''),onMouseLeave:()=>setFabToolsOpen(false)},
      h('div',{class:'ve-fab-menu'},
        normalizeFabOrder(fabOrder).map(id=>{
          const tool=SPEED_DIAL_TOOLS.find(item=>item.id===id);
          if(!tool)return null;
          if(tool.module&&isToolDisabledNow(tool.module))return null;
          return h('div',{class:'ve-fab-item',key:id,onClick:fabActions[id]},ph(tool.icon),h('div',{class:'ve-fab-tooltip'},tool.label));
        })
      ),
      h('div',{class:'ve-fab',onMouseEnter:()=>setFabToolsOpen(true),onFocus:()=>setFabToolsOpen(true),onClick:()=>sSettingsOpen(prev=>!prev),'aria-label':"Mimam's Var settings"},ph('gear'))
    ),
    open&&snapSide&&h('div',{class:'ve-snap-zone '+snapSide+' show'}),
    open&&panelMode!=='float'&&h('div',{class:'ve-bd show',onClick:()=>sO(false)}),
    h('div',{ref:panelRef,'data-panel':'variables',class:'ve-o '+(panelMode==='float'?'ve-float':'ve-dock-'+panelMode)+(open?' open':'')+(hasAvailableUpdate?' has-update':''),style:panelMode==='float'?{left:(panelPos.left||Math.max(16,window.innerWidth-430))+'px',top:(panelPos.top||16)+'px',right:'auto'}:null},
      cfm&&h('div',{class:'ve-modal ve-delete-impact-modal'},h('div',{class:'ve-modal-box ve-delete-impact-box'},
        h('div',{class:'ve-delete-impact-head'},
          h('div',{class:'ve-delete-impact-icon'},ph('warning')),
          h('div',{class:'ve-delete-impact-copy'},
            h('div',{class:'ve-delete-impact-title'},'Delete variable?'),
            h('div',{class:'ve-delete-impact-name'},publicTokenLabel(cfm.name)),
            h('div',{class:'ve-delete-impact-text'},'This permanently removes the variable and its generated variants. Review every detected consumer first.'))),
        h('div',{class:'ve-delete-impact-content'},h(VariableUsagePanel,{variable:cfm,onNavigate:navigateVariableUsage,title:'Affected consumers'})),
        h('div',{class:'ve-delete-impact-actions'},h('button',{class:'ve-btn ve-btn-g',onClick:()=>sCfm(null)},'Keep Variable'),h('button',{class:'ve-btn ve-btn-d',onClick:cfmDel},ph('trash'),'Delete Variable')))),
      confirmCategoryDelete&&h(ConfirmModal,{
        title:'Delete Category',
        body:'Delete “'+confirmCategoryDelete.name+'”? Its variables and generated children will move to Uncategorized. Token names and CSS will not change.',
        confirmText:'Delete Category',
        danger:true,
        onCancel:()=>sConfirmCategoryDelete(null),
        onConfirm:deleteCategory
      }),
      editingCategory&&h('div',{class:'ve-modal'},h('div',{class:'ve-modal-box'},
        h('div',{class:'ve-modal-title'},'Rename Category'),
        h('div',{class:'ve-modal-body'},
          h('input',{
            class:'ve-studio-input',
            value:categoryEditName,
            onInput:e=>sCategoryEditName(e.target.value),
            onKeyDown:e=>{if(e.key==='Enter')renameCategory();if(e.key==='Escape')sEditingCategory(null);},
            style:'width:100%'
          })
        ),
        h('div',{class:'ve-modal-actions'},
          h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sEditingCategory(null)},'Cancel'),
          h('button',{class:'ve-btn ve-btn-s',disabled:!categoryEditName.trim()||categoryEditName.trim()===editingCategory.name,onClick:renameCategory},'Save')
        )
      )),
      confirmCleanFooter&&h(ConfirmModal,{title:'Clean WordPress DB',body:'Clean duplicate, stale, and orphan generated variables from WordPress? This keeps base variables and rebuilds recoverable generated variants.',confirmText:'Clean',onCancel:()=>sConfirmCleanFooter(false),onConfirm:cleanDbFooter}),
      confirmDeletePalette&&h(ConfirmModal,{title:'Delete theme',body:'Delete \''+confirmDeletePalette.name+'\'? Its alternate color values will be removed. The underlying variables remain safe.',confirmText:'Delete Theme',danger:true,onCancel:()=>sConfirmDeletePalette(null),onConfirm:deletePalette}),
      confirmDuplicate&&h(ConfirmModal,{title:'Duplicate variable',body:'Are you sure you want to duplicate variable \''+confirmDuplicate.name+'\'?',confirmText:'Duplicate',onCancel:()=>sConfirmDuplicate(null),onConfirm:cfmDup}),
      confirmBatchDelete&&h('div',{class:'ve-modal ve-delete-impact-modal'},h('div',{class:'ve-modal-box ve-delete-impact-box'},
        h('div',{class:'ve-delete-impact-head'},
          h('div',{class:'ve-delete-impact-icon'},ph('warning')),
          h('div',{class:'ve-delete-impact-copy'},
            h('div',{class:'ve-delete-impact-title'},'Delete '+checkedVars.length+' variables?'),
            h('div',{class:'ve-delete-impact-text'},'This permanently removes the selected variables and their generated variants. Review every detected consumer first.'))),
        h('div',{class:'ve-delete-impact-content'},h(VariableImpactStack,{variables:selectedVariables,onNavigate:navigateVariableUsage})),
        h('div',{class:'ve-delete-impact-actions'},h('button',{class:'ve-btn ve-btn-g',onClick:()=>sConfirmBatchDelete(false)},'Keep Variables'),h('button',{class:'ve-btn ve-btn-d',onClick:()=>{sConfirmBatchDelete(false);deleteCheckedVars();}},ph('trash'),'Delete Selected')))),
      paletteTransfer&&h('div',{class:'ve-modal'},h('div',{class:'ve-modal-box'},
        h('div',{class:'ve-modal-title'},paletteTransfer.mode==='copy'?'Copy color to palette':'Move color to palette'),
        h('div',{class:'ve-modal-body'},
          h('div',{style:'margin-bottom:8px'},paletteTransfer.mode==='copy'?'Create an independent copy of “'+paletteTransfer.variable.name+'”.':'Move “'+paletteTransfer.variable.name+'” without changing its token, value, aliases, or website output.'),
          h('div',{style:'font-size:11px;color:#888;margin-bottom:5px'},'Destination palette'),
          h(SelectMenu,{
            value:paletteTransfer.paletteId,
            onChange:value=>sPaletteTransfer(prev=>({...prev,paletteId:value})),
            options:[{value:'',label:'Choose palette'},...(colorPalettesData.palettes||[]).filter(p=>paletteTransfer.mode==='copy'||String(p.id)!==String(paletteTransfer.variable.palette_id||0)).map(p=>({value:String(p.id),label:p.name}))]
          }),
          paletteTransfer.mode==='copy'&&h('div',{style:'margin-top:10px'},
            h('div',{style:'font-size:11px;color:#888;margin-bottom:5px'},'New variable name'),
            h('input',{class:'ve-studio-input',value:paletteTransfer.name,onInput:e=>sPaletteTransfer(prev=>({...prev,name:normalizeNameInput(e.target.value)})),style:'width:100%'}),
            paletteTransfer.variable.type==='base'&&h(CheckControl,{checked:paletteTransfer.includeGenerated,onChange:value=>sPaletteTransfer(prev=>({...prev,includeGenerated:value})),label:'Copy generated children'}))),
        h('div',{class:'ve-modal-actions'},
          h('button',{class:'ve-btn ve-btn-g ve-btn-s',onClick:()=>sPaletteTransfer(null)},'Cancel'),
          h('button',{class:'ve-btn ve-btn-s',disabled:!paletteTransfer.paletteId||(paletteTransfer.mode==='copy'&&!paletteTransfer.name),onClick:runPaletteTransfer},paletteTransfer.mode==='copy'?'Copy Color':'Move Color')))),

      h('div',{class:'ve-hdr'},h('span',{class:'ve-drag-handle',title:'Drag panel',onMouseDown:startPanelDrag},ph('dots-six-vertical')),
        h('div',{class:'ve-brand'},h('span',{class:'ve-hdr-t'},"Mimam's Var - WP"),CFG.logoUrl?h('img',{class:'ve-hdr-i',src:CFG.logoUrl,alt:''}):h('div',{class:'ve-hdr-i'})),
        h('div',{class:'ve-hdr-a'},

          h('button',{onClick:()=>{if(sub==='sync')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('sync'),sub?SLIDE_MS+10:0);}},title:'Sync'},ph('cloud-arrow-up')),
          h('button',{onClick:()=>{if(sub==='snapshots')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('snapshots'),sub?SLIDE_MS+10:0);}},title:'Snapshots'},ph('clock-counter-clockwise')),
          h('button',{onClick:()=>{if(sub==='migration')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('migration'),sub?SLIDE_MS+10:0);}},title:'Migrate variables'},ph('database')),
          h('button',{onClick:()=>{if(sub==='create')closeSub();else{if(sub)closeSub();setTimeout(()=>sSub('create'),sub?SLIDE_MS+10:0);}},title:sub==='create'?'Close new variable':'New variable'},ph(sub==='create'?'x':'plus')),
          h('button',{onClick:load,title:'Refresh'},ph('arrows-clockwise')),
          h('button',{onClick:()=>sO(false),title:'Close'},ph('x'))),
        h(ActivityProgress,{panelId:'variables'})),

      h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
      sub==='sync'&&h(SyncPanel,{onClose:closeSub,exiting:subExit,onReload:load,onDone:()=>{sSub(null);load();flash('Sync complete');}}),
      sub==='snapshots'&&h(SyncPanel,{onClose:closeSub,exiting:subExit,onReload:load,initialView:'snapshots',snapshotsOnly:true,onDone:()=>{sSub(null);load();flash('Snapshot restored');}}),
      sub==='migration'&&h(MigrationSub,{onClose:closeSub,exiting:subExit,onDone:async result=>{sSub(null);const fresh=await load();const affected=new Set((result?.affected_names||[]).map(String));const firstAffected=Array.isArray(fresh)?fresh.find(v=>affected.has(String(v.name))):null;if(firstAffected)sNT(variableNamespace(firstAffected));const applied=Number(result?.applied||0);const skipped=Number(result?.skipped_aliases||0);flash('Migration complete · '+applied+' change'+(applied===1?'':'s')+' applied'+(skipped?' · '+skipped+' skipped':''));}}),
      sub==='categories'&&h(VariableCategoryPanel,{onClose:closeSub,exiting:subExit,categories:allCats,onChanged:load}),
      sub==='create'&&h(CreateSub,{onCreated:hCreated,onClose:closeSub,categories:allCats,vars,exiting:subExit,palettes:colorPalettesData.palettes,paletteId:selectedColorPalette,initialCategory:nsTab}),
      sub?.type==='edit'&&h(EditSub,{variable:sub.v,categories:allCats,vars,onNavigateUsage:navigateVariableUsage,onDone:r=>{sSub(null);load();const warnings=r?.rename_impact?.warnings||[];flash(warnings.length?'Updated with '+warnings.length+' propagation warning'+(warnings.length===1?'':'s'):'Updated');},onClose:closeSub,exiting:subExit}),
      sub?.type==='genColor'&&h(GenColorSub,{variable:sub.v,childMap,onDone:()=>{sSub(null);load();flash('Generated');},onClose:closeSub,exiting:subExit}),
      sub?.type==='genScale'&&h(GenScaleSub,{variable:sub.v,onDone:()=>{sSub(null);load();flash('Generated');},onClose:closeSub,exiting:subExit}),
      sub?.type==='family'&&h(FamilyRelationshipSub,{initialIds:sub.ids||[],initialOperation:sub.operation,initialRootId:sub.rootId,initialNewRootId:sub.newRootId,lockRoot:!!sub.lockRoot,vars,onNavigateUsage:navigateVariableUsage,onDone:result=>{sSub(null);clearCheckedVars();load();flash((result?.applied||0)+' family relationship'+(Number(result?.applied)===1?'':'s')+' updated');},onClose:closeSub,exiting:subExit}),

      !sub&&h('div',{style:'display:flex;flex-direction:column;flex:1;min-height:0'},
        h('div',{class:'ve-sr'},h('input',{ref:sRef,placeholder:'Search... (Alt+Z)',value:sr,onInput:e=>sSr(e.target.value)})),
        h('div',{class:'ve-tabs'},
          h('div',{class:'ve-tabs-scroll'},namespaces.map(ns=>{
            const catObj = allCats.find(c => c.slug === ns);
            const menuCategory = ns==='color'
              ? {slug:'color',name:'Color',protected:1}
              : catObj;
            return h('div',{
              class:'ve-t'+(nsTab===ns?' on':''),
              title:ns==='all'?'Show every variable':ns==='color'?'Color variables':'Category: '+(categoryNames[ns]||ns),
              onClick:()=>sNT(ns),
              onContextMenu: e => {
                if (menuCategory) {
                  e.preventDefault();
                  const menuWidth=142;
                  const menuHeight=82;
                  sCategoryMenu({
                    x:Math.max(8,Math.min(e.clientX,window.innerWidth-menuWidth-8)),
                    y:Math.max(8,Math.min(e.clientY,window.innerHeight-menuHeight-8)),
                    category:menuCategory,
                    protected:!!Number(menuCategory.protected)
                  });
                }
              }
            },categoryNames[ns]||ns);
          })),
          h('div',{class:'ve-category-manage-wrap'},
            h('button',{class:'ve-a ve-category-manage',title:'Create and manage categories',onClick:()=>sSub('categories')},ph('folder-simple-plus')))),
        nsTab==='color'&&h('div',{class:'ve-color-control'},
          h('div',{class:'ve-color-kind-switch'},
            h('button',{class:colorControlMode==='theme'?'on':'',onClick:()=>chooseColorControlMode('theme')},'Theme'),
            h('button',{class:colorControlMode==='palette'?'on':'',onClick:()=>chooseColorControlMode('palette')},'Palette')
          ),
          colorControlMode==='theme'&&h('div',{class:'ve-color-control-row'},
            
            h(SelectMenu,{
              value:palettesData?.active,
              onChange:activatePalette,
              options:(palettesData?.palettes||[]).map(p=>({value:p.slug,label:p.name}))
            }),
            h('button',{
              class:'ve-a' + (paletteManagerOpen ? ' on' : ''),
              title: paletteManagerOpen ? 'Close Theme Manager' : 'Manage Themes',
              onClick:()=>togglePaletteManager(!paletteManagerOpen)
            }, ph(paletteManagerOpen ? 'caret-up' : 'sliders-horizontal'))
          ),
          colorControlMode==='theme'&&paletteManagerOpen && h('div',{style:'padding:0 14px 12px;border-top:1px solid #2a2a2a;display:flex;flex-direction:column;gap:8px;background:rgba(0,0,0,.12)'},
            h('div',{class:'ve-palette-current',style:'margin-top:10px;margin-bottom:6px;padding:4px 0;display:flex;align-items:center;gap:10px'},
              h('i',{class:'ph-duotone ph-palette',style:'font-size:18px;color:#baf400;line-height:1'}),
              h('div',null,
                h('div',{style:'font-size:11px;color:#666;text-transform:uppercase;letter-spacing:.5px;font-weight:600'},'Active Theme'),
                h('div',{style:'font-size:13px;color:#e8e8e8;font-weight:700;margin-top:1px'},(palettesData.palettes.find(p=>p.slug===palettesData.active)?.name)||'Default')
              )
            ),
            h('div',{style:'font-size:11px;color:#888;line-height:1.4;margin-bottom:2px'},'Themes change color values without changing token names. Create one from the currently active colors, switch it on, then edit Color variables normally to customize that theme. Generated color children follow their base color.'),
            h('div',{style:'display:flex;gap:5px'},
              h('input',{
                class:'ve-studio-input',
                type:'text',
                value:paletteName,
                onInput:e=>sPaletteName(e.target.value),
                placeholder:'New theme name',
                onKeyDown:e=>e.key==='Enter'&&createPalette(),
                style:'flex:1;font-size:11px;'
              }),
              h('button',{class:'ve-btn',onClick:createPalette,disabled:paletteLd||!paletteName.trim()},'Create')
            ),
            paletteErr&&h('div',{style:'font-size:11px;color:#ef4444'},paletteErr),
            h('div',{style:'max-height:160px;overflow-y:auto;margin-top:4px'},
              palettesData.palettes.map(p=>{
                const info=editingPalette===p.slug
                  ? h('div',{style:'display:flex;gap:4px'},
                      h('input',{
                        class:'ve-studio-input',
                        type:'text',
                        value:editPaletteName,
                        onInput:e=>sEditPaletteName(e.target.value),
                        onKeyDown:e=>{if(e.key==='Enter')renamePalette();if(e.key==='Escape')sEditingPalette(null);},
                        style:'flex:1;min-width:0;font-size:11px;'
                      }),
                      h('button',{class:'ve-btn',onClick:renamePalette,disabled:paletteLd},'Save')
                    )
                  : h('div',{class:'ve-palette-row-name',style:'font-size:11px;color:#ddd;font-weight:600'},p.name);
                return h('div',{class:'ve-palette-row',key:p.slug,style:'display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid #222'},
                  h('button',{
                    class:'ve-a',
                    style:'opacity:'+(p.active?'1':'.4')+';padding:2px',
                    title:p.active?'Active theme':'Activate '+p.name,
                    onClick:()=>!p.active&&activatePalette(p.slug),
                    disabled:paletteLd
                  }, ph(p.active?'check-circle':'circle')),
                  h('div',{class:'ve-palette-row-info',style:'flex:1;min-width:0'},
                    info,
                    h('div',{class:'ve-palette-row-meta',style:'font-size:11px;color:#666;margin-top:2px'},
                      p.active?'Active · ':'',
                      p.slug==='default'?'Uses base variable values':(p.value_count||0)+' color values'
                    )
                  ),
                  h('div',{class:'ve-palette-actions',style:'display:flex;gap:4px;align-items:center'},
                    h('button',{class:'ve-a',style:'padding:2px',title:'Duplicate theme',onClick:()=>duplicatePalette(p),disabled:paletteLd}, ph('copy')),
                    !p.protected&&h('button',{class:'ve-a',style:'padding:2px',title:'Rename theme',onClick:()=>{sEditingPalette(p.slug);sEditPaletteName(p.name);},disabled:paletteLd}, ph('pencil-simple')),
                    !p.protected&&h('button',{class:'ve-a',style:'padding:2px',title:'Delete theme',onClick:()=>sConfirmDeletePalette(p),disabled:paletteLd}, ph('trash'))
                  )
                );
              })
            )
          ),
          colorControlMode==='palette'&&h('div',{class:'ve-color-control-row'},
            
            h(SelectMenu,{
              value:selectedColorPalette,
              onChange:sSelectedColorPalette,
              options:[{value:'all',label:'All Colors'},...(colorPalettesData.palettes||[]).map(p=>({value:String(p.id),label:p.name+' ('+p.color_count+')'}))]
            }),
            h('button',{class:'ve-a'+(colorPaletteManagerOpen?' on':''),title:colorPaletteManagerOpen?'Close Color Palette Manager':'Manage Color Palettes',onClick:()=>toggleColorPaletteManager(!colorPaletteManagerOpen)},ph(colorPaletteManagerOpen?'caret-up':'sliders-horizontal'))),
          colorControlMode==='palette'&&colorPaletteManagerOpen&&h(ColorPalettePanel,{inline:true,onChanged:load,selectedPaletteId:selectedColorPalette})
        ),
        h('div',{class:'ve-source-filter'},
          h('button',{
            type:'button',
            class:'ve-source-chip'+(sourceFilter==='all'?' on':''),
            onClick:()=>sSourceFilter('all')
          },'All sources',h('span',{class:'ve-source-count'},sourceCounts.all||0)),
          VARIABLE_ORIGINS.filter(key=>(sourceCounts[key]||0)>0).map(key=>h('button',{
            type:'button',
            class:'ve-source-chip'+(sourceFilter===key?' on':''),
            onClick:()=>sSourceFilter(sourceFilter===key?'all':key),
            title:'Filter '+({mv:"Mimam's Var",file:'file imports',figma:'Figma',at:'Advanced Themer',cf:'Core Framework',acss:'Automatic.css'}[key]||key)
          },({mv:'MV',file:'FILE',figma:'Figma',at:'AT',cf:'CF',acss:'ACSS'}[key]||key),h('span',{class:'ve-source-count'},sourceCounts[key]||0))),
          sourceFilter!=='all'&&h('button',{class:'ve-btn ve-btn-g ve-btn-s ve-source-select',onClick:selectCurrentSource,disabled:sourceSelectionIds.length<1},'Select source')
        ),
        cleanupIssues.length>0&&h('div',{class:'ve-clean'},
          h('span',null,'WP cleanup available: '+cleanupIssues.join(', ')),
          h('button',{class:'ve-btn ve-btn-g',onClick:()=>sConfirmCleanFooter(true)},'Clean')),
        manualIntegrityNotices.length>0&&h('div',{class:'ve-warn',style:'margin:0 10px 8px;font-size:11px;line-height:1.5'},manualIntegrityNotices.join('. ')+'. Cleanup will not guess the intended source or public token.'),
        h('div',{style:'display:flex;justify-content:space-between;align-items:center;padding:6px 14px;border-bottom:1px solid #2a2a2a;background:#1a1a1a;flex-shrink:0'},
          h('label',{style:'display:flex;align-items:center;gap:6px;font-size:11px;color:#888;cursor:pointer;'},
            h('input',{class:'ve-var-check',type:'checkbox',checked:visibleSelectionIds.length>0&&visibleSelectionIds.every(id=>checkedVarSet.has(Number(id))),onChange:toggleAllVarsChecked}),
            'Select All'
          ),
          h('span',{style:'font-size:11px;color:#555;'},'Shift-click selects a range'),
          h('span',{style:'font-size:11px;color:#666;'},filtered.length+' variables')
        ),
        h('div',{class:'ve-body'},
          filtered.length===0?h('div',{class:'ve-empty'},sr?'No matches':'No variables'):
          [
          visibleFiltered.map(v=>{
            const kids=filteredChildMap[v.id]||[];const allKids=childMap[v.id]||[];const expKey=String(v.id);const hasExp=Object.prototype.hasOwnProperty.call(exp,expKey);const iE=(sr||sourceFilter!=='all')?true:(hasExp?!!exp[expKey]:false);
            const resolvedVal=resolvedVariableValue(v, vars);
            const displayNs=variableNamespace(v);const isSp=displayNs==='space';const spW=isSp?Math.max(4,pxV(resolvedVal)/maxSp*100):0;
            const bc=stripeColor(v);
            const row=h('div',{
              class:'ve-v'+(sel?.id===v.id?' sel':'')+(checkedVarSet.has(Number(v.id))?' checked':'')+(draggingVarId===v.id?' dragging':'')+(dragOverVarId===v.id?' drag-over':''),
              style:`--ve-ns:${bc};padding-left:4px`,
              title:(categoryNames[displayNs]||displayNs)+' · '+variableOriginTitle(v),
              'data-ve-variable-row':String(v.id),
              draggable:true,
              onDragStart:e=>handleVarDragStart(e,v),
              onDragOver:e=>handleVarDragOver(e,v),
              onDragLeave:()=>sDragOverVarId(null),
              onDragEnd:handleVarDragEnd,
              onDrop:e=>handleVarDrop(e,v),
              onMouseEnter:()=>openRowActions(v.id),
              onMouseLeave:()=>scheduleRowActionsClose(v.id),
              onFocus:()=>openRowActions(v.id),
              onBlur:()=>scheduleRowActionsClose(v.id),
              onClick:()=>hSel(v)
            },
              h('span',{class:'ve-var-drag-handle',style:'cursor:grab;margin-right:2px;display:flex;align-items:center;opacity:0.3;'},ph('dots-six-vertical')),
              h('input',{class:'ve-var-check',type:'checkbox',checked:checkedVarSet.has(Number(v.id)),onChange:e=>{e.stopPropagation();toggleVarChecked(v.id,e);},onClick:e=>{e.stopPropagation();e.currentTarget.__veShiftKey=!!e.shiftKey;},title:'Shift-click to select a visible range'}),
              allKids.length>0?h('button',{class:'ve-exp',onClick:e=>{e.stopPropagation();tgExp(v.id,false);}},ph(iE?'minus':'plus')):h('div',{style:'width:18px'}),
              h('div',{class:'ve-sw-trigger'},h(Sw,{v:resolvedVal})),
              h('div',{class:'ve-inf'},h('div',{class:'ve-nm'},h('span',{class:'ve-nm-label'},publicTokenLabel(v.name)),h(OriginPill,{variable:v,active:sourceFilter===normalizedVariableOrigin(v),onFilter:key=>sSourceFilter(sourceFilter===key?'all':key)})),h('div',{class:'ve-vl'},v.type==='alias'?(v.css_value||''):v.value,isSp&&h('div',{class:'ve-sb',style:`width:${spW}%`}))),
              h('div',{class:'ve-as'+(rowActions===String(v.id)?' open':'')},
                h('button',{class:'ve-a',title:'Edit',onClick:e=>{e.stopPropagation();sSub({type:'edit',v});}},ph('pencil-simple')),
                h('button',{class:'ve-a',title:'Generate',onClick:e=>{e.stopPropagation();sSub(isClr(resolvedVal)?{type:'genColor',v}:{type:'genScale',v});}},ph('sun')),
                h('button',{class:'ve-a',title:'Duplicate',onClick:e=>{e.stopPropagation();hDup(v);}},ph('copy')),
                allKids.length>0&&h('button',{class:'ve-a',title:'Manage this family',onClick:e=>{e.stopPropagation();const rootId=Number(v.id);const ids=[rootId,...allKids.map(child=>Number(child.id))];sSub({type:'family',ids,operation:'change_root',rootId,lockRoot:true});}},ph('tree-structure')),
                v.palette_eligible&&h('button',{class:'ve-a',title:'Copy to palette',onClick:e=>{e.stopPropagation();openPaletteTransfer('copy',v);}},ph('copy-simple')),
                v.palette_eligible&&h('button',{class:'ve-a',title:'Move to palette',onClick:e=>{e.stopPropagation();openPaletteTransfer('move',v);}},ph('arrows-left-right')),
                h('button',{class:'ve-a',title:'Copy var()',onClick:e=>{e.stopPropagation();cpVar(v.name);}},ph('clipboard-text')),
                h('button',{class:'ve-a',title:'Delete',onClick:e=>{e.stopPropagation();hDel(v);}},ph('trash'))));
            const children=kids.length>0&&iE&&h('div',{class:'ve-ch'},kids.map(c=>{
              const resolvedCVal=resolvedVariableValue(c, vars);
              return h('div',{class:'ve-c'+(checkedVarSet.has(Number(c.id))?' checked':''),key:c.id,onClick:()=>hSel(c)},
                h('input',{class:'ve-var-check',type:'checkbox',checked:checkedVarSet.has(Number(c.id)),onChange:e=>{e.stopPropagation();toggleVarChecked(c.id,e);},onClick:e=>{e.stopPropagation();e.currentTarget.__veShiftKey=!!e.shiftKey;},title:'Shift-click to select a visible range'}),
                h(Sw,{v:resolvedCVal}),
                h('div',{class:'ve-inf'},h('div',{class:'ve-nm'},h('span',{class:'ve-nm-label'},publicTokenLabel(c.name)),h(OriginPill,{variable:c,active:sourceFilter===normalizedVariableOrigin(c),onFilter:key=>sSourceFilter(sourceFilter===key?'all':key)})),h('div',{class:'ve-vl'},c.type==='alias'?c.css_value:c.value)),
                h('button',{class:'ve-a',style:'opacity:.6',title:'Manage this family',onClick:e=>{e.stopPropagation();const rootId=Number(c.source_id);const familyChildren=childMap[rootId]||[];sSub({type:'family',ids:[rootId,...familyChildren.map(child=>Number(child.id))],operation:'change_root',rootId,newRootId:Number(c.id),lockRoot:true});}},ph('tree-structure')),
                h('button',{class:'ve-a',style:'opacity:.6',title:'Copy var()',onClick:e=>{e.stopPropagation();cpVar(c.name);}},ph('clipboard-text')));
            }));
            return h('div',{class:'ve-tree-item',key:v.id},row,children);
          }),
          filtered.length>visibleFiltered.length&&h('div',{style:'padding:12px 14px;text-align:center'},
            h('button',{
              class:'ve-btn ve-btn-g',
              onClick:()=>sVisibleVariableLimit(limit=>limit+100)
            },ph('plus-circle'),'Load '+Math.min(100,filtered.length-visibleFiltered.length)+' more')
          )
          ]),
        sel&&h(Detail,{variable:sel,vars,onNav:d=>{const f=vars.find(v=>v.id===d.id||v.name===d.name);if(f)sSel(f);},onNavigateUsage:navigateVariableUsage,onClose:()=>sSel(null),onUpdate:()=>{load();flash('Updated');},onEditFull:v=>sSub({type:'edit',v})}),
      ),
      h('div',{class:'ve-st'},
        h('div',{class:'ve-st-left'},
          h('span',null,(stats?(stats.base||0)+' base · '+(stats.generated||0)+' generated':vars.length+' variables')),
          cleanupIssues.length>0&&h('button',{class:'ve-btn ve-btn-g ve-btn-s',title:'Clean WordPress variable database',onClick:()=>sConfirmCleanFooter(true)},'Clean WP DB')
        ),
        h('span',null,'v'+(CFG.version||'1.1.16'))),
      !sub && checkedVars.length > 0 && h('div', { class: 've-studio-batch-overlay', style: 'left:14px;right:14px;bottom:56px;transform:none!important;box-sizing:border-box;display:flex;justify-content:space-between;align-items:center;padding:8px 12px;gap:8px;' },
        selectionReviewOpen&&h('div',{class:'ve-selection-review'},
          h('div',{class:'ve-selection-review-head'},
            h('div',{class:'ve-selection-review-title'},
              h('strong',null,'Selected variables'),
              h('span',null,hiddenSelectedCount?`${selectedVariables.length-hiddenSelectedCount} visible · ${hiddenSelectedCount} outside this view`:`${selectedVariables.length} visible in this view`)
            ),
            h('button',{class:'ve-selection-review-clear',onClick:clearCheckedVars},'Clear all')
          ),
          h('div',{class:'ve-selection-review-list'},
            selectedVariables.map(variable=>{
              const isVisible=visibleSelectionSet.has(Number(variable.id));
              return h('div',{class:'ve-selection-review-item',key:variable.id},
                h('span',{class:'ve-selection-review-item-name',title:publicTokenLabel(variable.name)},publicTokenLabel(variable.name)),
                h(OriginPill,{variable,active:sourceFilter===normalizedVariableOrigin(variable),onFilter:key=>sSourceFilter(sourceFilter===key?'all':key)}),
                !isVisible&&h('span',{class:'ve-selection-review-item-badge hidden'},'Off-screen'),
                h('button',{class:'ve-selection-review-remove',title:'Remove from selection',onClick:()=>removeCheckedVar(variable.id)},ph('x'))
              );
            })
          )
        ),
        h('div', { class:'ve-batch-selection-slot' },
          h('button',{
            class:'ve-selection-review-toggle'+(selectionReviewOpen?' open':''),
            title:'Review selected variables',
            'aria-expanded':selectionReviewOpen?'true':'false',
            onClick:()=>sSelectionReviewOpen(open=>!open)
          },ph('check-square'),`Review ${selectedVariables.length} selected`,hiddenSelectedCount>0&&h('span',{class:'ve-selection-review-item-badge hidden'},`${hiddenSelectedCount} hidden`),ph(selectionReviewOpen?'caret-down':'caret-up'))
        ),
        h('div', { class:'ve-batch-actions' },
          nsTab === 'color' && h('div', { style: 'display:flex;align-items:center;gap:4px;flex-shrink:1;min-width:0;' },
            h(SelectMenu, {
              value: batchTargetPaletteId,
              onChange: sBatchTargetPaletteId,
              className: 've-batch-select',
              options: [{ value: '', label: 'Move to...' }, ...(colorPalettesData.palettes || []).map(p => ({ value: String(p.id), label: p.name }))]
            }),
            h('button', {
              class: 've-btn ve-btn-g ve-btn-s',
              disabled: !batchTargetPaletteId,
              onClick: () => moveCheckedVarsToPalette(batchTargetPaletteId)
            }, 'Move')
          ),
          nsTab !== 'color' && h('div', { style: 'display:flex;align-items:center;gap:4px;flex-shrink:1;min-width:0;' },
            h(SelectMenu, {
              value: batchTargetCategorySlug,
              onChange: sBatchTargetCategorySlug,
              className: 've-batch-select',
              options: [{ value: '', label: 'Move to...' }, ...allCats.map(category => ({ value: category.slug, label: category.name }))]
            }),
            h('button', {
              class: 've-btn ve-btn-g ve-btn-s',
              disabled: !batchTargetCategorySlug,
              onClick: () => moveCheckedVarsToCategory(batchTargetCategorySlug)
            }, 'Move')
          ),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', title:'Group, ungroup, reparent, or change a family root', onClick: () => sSub({type:'family',ids:[...checkedVars]}) }, ph('tree-structure'),'Family'),
          h('button', { class: 've-btn ve-btn-g ve-btn-s', onClick: clearCheckedVars }, 'Cancel'),
          h('button', { class: 've-btn ve-btn-s', style: 'background:#ef4444;color:#fff;', onClick: () => sConfirmBatchDelete(true) }, 'Delete')
        )
      )
    ),
        
      (settingsOpen || settingsHasOpened) && h(StandalonePanel, {
        title: 'Settings',
        panelId: 'settings',
        open: settingsOpen,
        panelMode,
        width: 468,
        persistKey: 've_settings_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => sSettingsOpen(false),
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(UnifiedSettingsPanel, {
        onClose: () => sSettingsOpen(false),
        panelMode,
        setPanelMode
      })),

      (helpOpen || helpHasOpened) && h(StandalonePanel, {
        title: 'Quick Help',
        panelId: 'help',
        open: helpOpen,
        panelMode,
        width: 380,
        persistKey: 've_help_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => sHelpOpen(false),
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(HelpPanel, {
        onClose: () => sHelpOpen(false)
      })),

      (cssStudioOpen || cssStudioHasOpened) && h(StandalonePanel, {
        title: 'CSS Studio',
        panelId: 'css_studio',
        open: cssStudioOpen,
        panelMode,
        width: 430,
        persistKey: 've_css_studio_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => sCssStudioOpen(false),
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(AdvancedCssSub, {
        onClose: () => sCssStudioOpen(false),
        exiting: false,
        vars,
        initialSheetId: usageCssSheet
      })),

      (cssRecipesOpen || cssRecipesHasOpened) && h(StandalonePanel, {
        title: 'CSS Recipes',
        panelId: 'css_recipes',
        open: cssRecipesOpen,
        panelMode,
        width: 420,
        persistKey: 've_css_recipes_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => sCssRecipesOpen(false),
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(CssRecipesStudioSub, {
        flash,
        vars,
        initialCode: usageRecipeCode
      })),

      (contentStudioOpen || contentStudioHasOpened) && h(StandalonePanel, {
        title: 'Content Studio',
        panelId: 'content_studio',
        open: contentStudioOpen,
        panelMode,
        width: 380,
        persistKey: 've_content_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => sContentStudioOpen(false),
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(ContentStudioSub, {
        onClose: () => sContentStudioOpen(false),
        flash
      })),

      !nativeMediaPageActive && (mediaStudioOpen || mediaStudioHasOpened) && h(StandalonePanel, {
        title: 'Media Studio',
        panelId: 'media_studio',
        open: mediaStudioOpen,
        panelMode,
        width: 420,
        persistKey: 've_media_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => { pendingMediaFrameRef.current = null; mediaTargetRef.current = null; sMediaStudioOpen(false); },
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(MediaStudioSub, {
        onClose: () => { pendingMediaFrameRef.current = null; mediaTargetRef.current = null; sMediaStudioOpen(false); },
        flash,
        picking: !!mediaTargetRef.current,
        onInsertMedia: insertMediaIntoRememberedControl,
        initialFilter: mediaStudioInitialFilter
      })),

      (pluginStudioOpen || pluginStudioHasOpened) && h(StandalonePanel, {
        title: 'Plugin Studio',
        panelId: 'plugin_studio',
        open: pluginStudioOpen,
        panelMode,
        width: 420,
        persistKey: 've_plugin_pos',
        height: panelMode === 'float' ? 'min(760px, calc(100vh - 32px))' : 'calc(100vh - 16px)',
        onClose: () => sPluginStudioOpen(false),
        updateNotice: h(UpdateNotice,{info:updateInfo,skipped:skipUpdate,onSkip:skipUpdateVersion}),
        hasUpdate: hasAvailableUpdate
      }, h(PluginStudioSub, {
        flash
      }))
  );
}

function showBootFallback(err){
  try{
    if(document.getElementById('ve-boot-fallback'))return;
    const b=document.createElement('button');
    b.id='ve-boot-fallback';
    b.type='button';
    b.textContent='MV';
    b.title=err?'Mimam’s Var could not fully load. Click to retry/open.':'Open Mimam’s Var';
    b.style.cssText='position:fixed;right:16px;bottom:16px;z-index:120050;width:38px;height:38px;border-radius:10px;border:1px solid #baf400;background:#1f1f1f;color:#baf400;font:700 11px/1 -apple-system,BlinkMacSystemFont,Segoe UI,sans-serif;cursor:pointer;box-shadow:0 8px 22px rgba(0,0,0,.35)';
    b.addEventListener('click',()=>{if(window.veToggleVariables)window.veToggleVariables();else window.location.reload();});
    document.body.appendChild(b);
    if(err)console.error('Mimam’s Var failed to boot',err);
  }catch(e){}
}
function mt(){
  try{
    const s=document.createElement('style');s.textContent=CSS;document.head.appendChild(s);
    const r=document.createElement('div');r.id='ve-panel-root';document.body.appendChild(r);render(h(Panel),r);wireGsapHover(r);if(MODE==='builder')setTimeout(syncBricksVariableConsumers,0);
    setTimeout(()=>{if(!document.querySelector('#ve-panel-root .ve-fab-wrap')&&!window.veToggleVariables)showBootFallback();},1200);
  }catch(e){showBootFallback(e);}
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',mt);else mt();
})();
