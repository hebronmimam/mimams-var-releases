<?php

namespace VE\API;

use VE\Core\ThemeManager;

defined( 'ABSPATH' ) || exit;

class ThemeController {

    private ThemeManager $manager;

    public function __construct() {
        $this->manager = new ThemeManager();
    }

    public function list_themes(): \WP_REST_Response {
        return new \WP_REST_Response( $this->manager->list(), 200 );
    }

    public function create_theme( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $result = $this->manager->create( (string) ( $data['name'] ?? '' ), isset( $data['source_slug'] ) ? (string) $data['source_slug'] : null );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 201 );
    }

    public function update_theme( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $result = $this->manager->rename( sanitize_key( (string) $request->get_param( 'slug' ) ), (string) ( $data['name'] ?? '' ) );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 200 );
    }

    public function delete_theme( \WP_REST_Request $request ) {
        $result = $this->manager->delete( sanitize_key( (string) $request->get_param( 'slug' ) ) );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( [ 'deleted' => true ], 200 );
    }

    public function activate_theme( \WP_REST_Request $request ) {
        $result = $this->manager->activate( sanitize_key( (string) $request->get_param( 'slug' ) ) );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 200 );
    }

    public function duplicate_theme( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $result = $this->manager->duplicate(
            sanitize_key( (string) $request->get_param( 'slug' ) ),
            (string) ( $data['name'] ?? '' )
        );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 201 );
    }
}
