<?php

namespace VE\API;

use VE\Core\ColorPaletteManager;

defined( 'ABSPATH' ) || exit;

class ColorPaletteController {

    private ColorPaletteManager $manager;

    public function __construct() {
        $this->manager = new ColorPaletteManager();
    }

    public function list_palettes(): \WP_REST_Response {
        return new \WP_REST_Response( $this->manager->list(), 200 );
    }

    public function create_palette( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $result = $this->manager->create( (string) ( $data['name'] ?? '' ) );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 201 );
    }

    public function update_palette( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $result = $this->manager->rename( (int) $request->get_param( 'id' ), (string) ( $data['name'] ?? '' ) );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 200 );
    }

    public function duplicate_palette( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $result = $this->manager->duplicate( (int) $request->get_param( 'id' ), (string) ( $data['name'] ?? '' ) );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 201 );
    }

    public function preview_delete( \WP_REST_Request $request ) {
        $result = $this->manager->preview_delete( (int) $request->get_param( 'id' ) );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 200 );
    }

    public function delete_palette( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $result = $this->manager->delete(
            (int) $request->get_param( 'id' ),
            sanitize_key( (string) ( $data['strategy'] ?? 'empty' ) ),
            (int) ( $data['destination_id'] ?? 0 )
        );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( [ 'deleted' => true ], 200 );
    }

    public function move_variable( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $result = $this->manager->move_variable(
            (int) $request->get_param( 'variable_id' ),
            (int) ( $data['palette_id'] ?? 0 )
        );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 200 );
    }

    public function copy_variable( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $result = $this->manager->copy_variable(
            (int) $request->get_param( 'variable_id' ),
            (int) ( $data['palette_id'] ?? 0 ),
            (string) ( $data['name'] ?? '' ),
            ! isset( $data['include_generated'] ) || ! empty( $data['include_generated'] )
        );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( $result, 201 );
    }

    public function reorder_palettes( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $ids = isset( $data['ids'] ) && is_array( $data['ids'] ) ? array_map( 'intval', $data['ids'] ) : [];
        if ( empty( $ids ) ) {
            return new \WP_Error( 've_reorder_palettes_missing_ids', 'No IDs provided.', [ 'status' => 400 ] );
        }
        $result = $this->manager->reorder_palettes( $ids );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function batch_move_variables( \WP_REST_Request $request ) {
        $data = $request->get_json_params();
        $variable_ids = isset( $data['ids'] ) && is_array( $data['ids'] ) ? array_map( 'intval', $data['ids'] ) : [];
        $palette_id = (int) ( $data['palette_id'] ?? 0 );
        if ( empty( $variable_ids ) ) {
            return new \WP_Error( 've_batch_move_missing_ids', 'No IDs provided.', [ 'status' => 400 ] );
        }
        if ( $palette_id <= 0 ) {
            return new \WP_Error( 've_batch_move_missing_palette', 'No destination palette provided.', [ 'status' => 400 ] );
        }

        $result = $this->manager->batch_assign( $variable_ids, $palette_id );
        return is_wp_error( $result ) ? $result : new \WP_REST_Response( [ 'success' => true ], 200 );
    }
}
