<?php

namespace VE\API;

use VE\Core\VariableCategoryManager;

defined( 'ABSPATH' ) || exit;

class VariableCategoryController {
    private VariableCategoryManager $manager;

    public function __construct() {
        $this->manager = new VariableCategoryManager();
    }

    public function list_categories(): \WP_REST_Response {
        return new \WP_REST_Response( [ 'categories' => $this->manager->list() ], 200 );
    }

    public function create_category( \WP_REST_Request $request ): \WP_REST_Response {
        return $this->response( $this->manager->create( (string) $request->get_param( 'name' ) ), 201 );
    }

    public function update_category( \WP_REST_Request $request ): \WP_REST_Response {
        return $this->response(
            $this->manager->rename( (string) $request->get_param( 'slug' ), (string) $request->get_param( 'name' ) )
        );
    }

    public function delete_category( \WP_REST_Request $request ): \WP_REST_Response {
        return $this->response( $this->manager->delete( (string) $request->get_param( 'slug' ) ) );
    }

    public function move_variables( \WP_REST_Request $request ): \WP_REST_Response {
        $ids = $request->get_param( 'variable_ids' );
        return $this->response(
            $this->manager->move_variables( is_array( $ids ) ? $ids : [], (string) $request->get_param( 'category_slug' ) )
        );
    }

    private function response( $result, int $success = 200 ): \WP_REST_Response {
        if ( is_wp_error( $result ) ) {
            return new \WP_REST_Response(
                [ 'code' => $result->get_error_code(), 'message' => $result->get_error_message() ],
                (int) ( $result->get_error_data()['status'] ?? 500 )
            );
        }
        return new \WP_REST_Response( $result, $success );
    }
}
