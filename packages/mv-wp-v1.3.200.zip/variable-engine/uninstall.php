<?php
/**
 * Variable Engine Uninstall
 * Runs when the plugin is deleted from WordPress.
 */
defined('WP_UNINSTALL_PLUGIN') || exit;

// Check if user wants data deleted on uninstall.
$delete_data = get_option('ve_delete_on_uninstall', false);

if ($delete_data) {
    global $wpdb;
    $p = $wpdb->prefix;

    // Drop all VE tables.
    $wpdb->query("DROP TABLE IF EXISTS {$p}ve_dependencies");
    $wpdb->query("DROP TABLE IF EXISTS {$p}ve_generators");
    $wpdb->query("DROP TABLE IF EXISTS {$p}ve_sync_logs");
    $wpdb->query("DROP TABLE IF EXISTS {$p}ve_snapshots");
    $wpdb->query("DROP TABLE IF EXISTS {$p}ve_color_palette_members");
    $wpdb->query("DROP TABLE IF EXISTS {$p}ve_color_palettes");
    $wpdb->query("DROP TABLE IF EXISTS {$p}ve_variables");

    // Remove options.
    delete_option('ve_db_version');
    delete_option('ve_delete_on_uninstall');
    delete_option('ve_settings');
    delete_option('ve_license');
    delete_option('ve_advanced_css');
    delete_option('ve_color_palettes');
    delete_option('ve_active_color_palette');

    // Remove generated CSS file.
    $upload_dir = wp_upload_dir();
    $ve_dir = $upload_dir['basedir'] . '/variable-engine/';
    if (is_dir($ve_dir)) {
        array_map('unlink', glob($ve_dir . '*'));
        rmdir($ve_dir);
    }
}
