<?php
namespace VE\Core\Generators;
defined('ABSPATH') || exit;

/**
 * FluidScaleGenerator — generates fluid clamp() values using type scales.
 *
 * Used for spacing, typography, radius, and size.
 * Uses base min/max (mobile/desktop) and type scale ratios.
 * Steps are added up/down from the base using the scale multiplier.
 */
class FluidScaleGenerator implements GeneratorInterface {

    /**
     * Named type scale ratios.
     */
    private const SCALES = [
        'minor-second'     => 1.067,
        'major-second'     => 1.125,
        'minor-third'      => 1.200,
        'major-third'      => 1.250,
        'perfect-fourth'   => 1.333,
        'augmented-fourth' => 1.414,
        'perfect-fifth'    => 1.500,
        'golden'           => 1.618,
    ];

    /**
     * Config:
     *   base_min     — base value at min viewport (px number)
     *   base_max     — base value at max viewport (px number)
     *   scale_min    — type scale name or ratio for min viewport
     *   scale_max    — type scale name or ratio for max viewport
     *   vw_min       — min viewport width (default 320)
     *   vw_max       — max viewport width (default 1440)
     *   steps_up     — number of steps above base (default 0)
     *   steps_down   — number of steps below base (default 0)
     *   step_labels  — optional array of labels for steps (auto-generated if empty)
     *   unit         — output unit for min/max: 'px' or 'rem' (default 'rem')
     */
    public function generate(array $base_variable, array $config): array {
        $base_name = $base_variable['name'];
        $prefix    = explode('.', $base_name)[0];

        $base_min  = (float)($config['base_min'] ?? 16);
        $base_max  = (float)($config['base_max'] ?? 18);
        $scale_min = $this->resolve_scale($config['scale_min'] ?? 'major-third');
        $scale_max = $this->resolve_scale($config['scale_max'] ?? 'major-third');
        $vw_min    = (int)($config['vw_min'] ?? 320);
        $vw_max    = (int)($config['vw_max'] ?? 1440);
        $steps_up  = (int)($config['steps_up'] ?? 0);
        $steps_down = (int)($config['steps_down'] ?? 0);
        $unit      = $config['unit'] ?? 'rem';
        $naming    = $config['naming'] ?? 'numeric';

        $results = [];
        $used_names = [ $base_name => true ];

        // Steps down (smaller): step -N to -1
        for ($i = $steps_down; $i >= 1; $i--) {
            $min_val = $base_min / pow($scale_min, $i);
            $max_val = $base_max / pow($scale_max, $i);
            if ( $naming === 'numeric' ) {
                $name = $this->build_unique_numeric_name( $base_name, $prefix, $max_val, -1, $used_names );
            } else {
                $label = $this->step_label(-$i, $steps_down, $steps_up);
                $name  = $this->build_name( $base_name, $prefix, $label, $naming );
            }

            if ($name === $base_name) continue;
            $used_names[ $name ] = true;

            $results[] = [
                'name'  => $name,
                'value' => $this->make_clamp($min_val, $max_val, $vw_min, $vw_max, $unit),
            ];
        }

        // Steps up (larger): step 1 to N
        for ($i = 1; $i <= $steps_up; $i++) {
            $min_val = $base_min * pow($scale_min, $i);
            $max_val = $base_max * pow($scale_max, $i);
            if ( $naming === 'numeric' ) {
                $name = $this->build_unique_numeric_name( $base_name, $prefix, $max_val, 1, $used_names );
            } else {
                $label = $this->step_label($i, $steps_down, $steps_up);
                $name  = $this->build_name( $base_name, $prefix, $label, $naming );
            }

            if ($name === $base_name) continue;
            $used_names[ $name ] = true;

            $results[] = [
                'name'  => $name,
                'value' => $this->make_clamp($min_val, $max_val, $vw_min, $vw_max, $unit),
            ];
        }

        return $results;
    }

    /* ── Helpers ──────────────────────────────────────────────────── */


    private function numeric_label(float $px): string {
        // Token names should stay human-readable and map to the user's px system.
        // Example: 107.28px becomes token suffix `107`, not `107-28`.
        // The precise value remains inside the clamp() value itself.
        return (string) max( 0, (int) round( $px ) );
    }

    private function build_unique_numeric_name(
        string $base_name,
        string $prefix,
        float $px,
        int $direction,
        array $used_names
    ): string {
        $preferred = (int) $this->numeric_label( $px );

        for ( $offset = 0; $offset <= 1000; $offset++ ) {
            $labels = 0 === $offset
                ? [ $preferred ]
                : ( $direction < 0
                    ? [ $preferred - $offset, $preferred + $offset ]
                    : [ $preferred + $offset, $preferred - $offset ] );

            foreach ( $labels as $label ) {
                if ( $label < 0 ) {
                    continue;
                }
                $name = $this->build_name( $base_name, $prefix, (string) $label, 'numeric' );
                if ( ! isset( $used_names[ $name ] ) ) {
                    return $name;
                }
            }
        }

        return $this->build_name( $base_name, $prefix, (string) max( 0, $preferred ), 'numeric' );
    }

    private function build_name(string $base_name, string $prefix, string $label, string $naming): string {
        if ($naming !== 'numeric') {
            return "{$prefix}.{$label}";
        }

        $parts = array_values(array_filter(explode('.', $base_name), static fn($p) => $p !== ''));

        // Numeric dimension tokens should be named from the token family/name,
        // not from the storage category. Examples:
        //   size.space      -> space.20      -> --space-20
        //   size.heading    -> heading.58    -> --heading-58
        //   size.text       -> text.46       -> --text-46
        //   size.grid.gap   -> grid.gap.20   -> --grid-gap-20
        //   grid.gap        -> grid.gap.20   -> --grid-gap-20
        $category_wrappers = [ 'size', 'font', 'spacing', 'space', 'radius', 'typography' ];

        if (count($parts) >= 2 && in_array($parts[0], $category_wrappers, true)) {
            $family_parts = array_slice($parts, 1);
        } else {
            $family_parts = $parts;
        }

        // If the base token itself ends in a number, replace that number.
        // Otherwise append the generated numeric label.
        if (!empty($family_parts) && preg_match('/^\d+(?:-\d+)?$/', (string) end($family_parts))) {
            array_pop($family_parts);
        }

        if (empty($family_parts)) {
            $family_parts = [ $prefix ?: 'size' ];
        }

        return implode('.', $family_parts) . '.' . $label;
    }

    private function resolve_scale($scale): float {
        if (is_numeric($scale)) return (float)$scale;
        return self::SCALES[$scale] ?? 1.250;
    }

    /**
     * Generate t-shirt style labels based on step position.
     * Negative steps: 3xs, 2xs, xs, sm
     * Positive steps: lg, xl, 2xl, 3xl, 4xl...
     */
    private function step_label(int $step, int $total_down, int $total_up): string {
        if ($step < 0) {
            $abs = abs($step);
            if ($abs === 1) return 'sm';
            if ($abs === 2) return 'xs';
            if ($abs === 3) return '2xs';
            return ($abs - 1) . 'xs';
        }
        if ($step === 1) return 'lg';
        if ($step === 2) return 'xl';
        if ($step === 3) return '2xl';
        return ($step - 1) . 'xl';
    }

    private function make_clamp(float $min_px, float $max_px, int $vw_min, int $vw_max, string $unit): string {
        // Delegates to the shared FluidValue helper so the slope/intercept
        // formula has a single source of truth across the plugin.
        return \VE\Core\FluidValue::clamp( $min_px, $max_px, $vw_min, $vw_max, $unit );
    }
}
