<?php

namespace VE\Core\Generators;

defined( 'ABSPATH' ) || exit;

interface GeneratorInterface {

    /**
     * Generate scale variables from a base variable.
     *
     * @param array $base_variable The base variable row from DB.
     * @param array $config        Generator-specific configuration.
     * @return array Array of [ 'name' => '...', 'value' => '...' ] items.
     */
    public function generate( array $base_variable, array $config ): array;
}
