<?php
namespace VE\Core\Generators;
defined('ABSPATH') || exit;

class ColorGenerator implements GeneratorInterface {

    /**
     * Generate palette from base color. ALL output in oklch.
     *
     * Naming: shades = {name}.d.1-N, tints = {name}.l.1-N, alpha = {name}.t.1-N
     *
     * Config: stops (array), include_alpha (bool), alpha_stops (array),
     *         base_stop (int), tint_count (int), shade_count (int), alpha_count (int)
     */
    public function generate(array $base_variable, array $config): array {
        $base_name  = $base_variable['name'];
        $base_value = trim($base_variable['value']);

        $tint_count  = $config['tint_count'] ?? $config['tints'] ?? 8;
        $shade_count = $config['shade_count'] ?? $config['shades'] ?? 8;
        $inc_alpha   = $config['include_alpha'] ?? true;
        $alpha_count = $config['alpha_count'] ?? $config['alphas'] ?? 8;

        // Parse to oklch components
        $oklch = $this->parse_to_oklch($base_value);
        $results = [];

        // Tints (lighter) — {name}.l.1 (closest to base) through {name}.l.N (lightest)
        for ($i = 1; $i <= $tint_count; $i++) {
            $factor = $i / ($tint_count + 1);
            $l = $oklch['l'] + (0.97 - $oklch['l']) * $factor;
            $c = $oklch['c'] * max(0.2, 1 - $factor * 0.7);
            $results[] = [
                'name'  => "{$base_name}.l.{$i}",
                'value' => $this->fmt_oklch($l, $c, $oklch['h']),
            ];
        }

        // Shades (darker) — {name}.d.1 (closest to base) through {name}.d.N (darkest)
        for ($i = 1; $i <= $shade_count; $i++) {
            $factor = $i / ($shade_count + 1);
            $l = $oklch['l'] - ($oklch['l'] - 0.1) * $factor;
            $c = $oklch['c'] * max(0.25, 1 - $factor * 0.5);
            $results[] = [
                'name'  => "{$base_name}.d.{$i}",
                'value' => $this->fmt_oklch($l, $c, $oklch['h']),
            ];
        }

        // Alpha variants — {name}.t.1 (most transparent) through {name}.t.N (least)
        if ($inc_alpha) {
            for ($i = 1; $i <= $alpha_count; $i++) {
                $alpha = round($i / ($alpha_count + 1), 3);
                $results[] = [
                    'name'  => "{$base_name}.t.{$i}",
                    'value' => "oklch({$oklch['l']} {$oklch['c']} {$oklch['h']} / {$alpha})",
                ];
            }
        }

        return $results;
    }

    /* ── Parse any color format to oklch components ───────────────── */

    private function parse_to_oklch(string $color): array {
        $color = trim($color);

        // Already oklch
        if (preg_match('/oklch\(\s*([\d.]+)(%?)\s+([\d.]+)\s+([\d.]+)/i', $color, $m)) {
            $l = (float)$m[1];
            if ($m[2] === '%') $l /= 100;
            return ['l' => $l, 'c' => (float)$m[3], 'h' => (float)$m[4]];
        }

        // Hex or RGB → convert via HSL intermediary
        $rgb = $this->parse_to_rgb($color);
        if ($rgb) {
            return $this->rgb_to_oklch_approx($rgb['r'], $rgb['g'], $rgb['b']);
        }

        // HSL
        if (preg_match('/hsl\(\s*([\d.]+)\s*,?\s*([\d.]+)%?\s*,?\s*([\d.]+)%?\s*\)/i', $color, $m)) {
            $rgb = $this->hsl_to_rgb((float)$m[1], (float)$m[2], (float)$m[3]);
            return $this->rgb_to_oklch_approx($rgb['r'], $rgb['g'], $rgb['b']);
        }

        // Fallback
        return ['l' => 0.6, 'c' => 0.15, 'h' => 250];
    }

    private function parse_to_rgb(string $color): ?array {
        if (preg_match('/^#([0-9a-f]{3}|[0-9a-f]{6})$/i', $color, $m)) {
            $hex = $m[1];
            if (strlen($hex) === 3) $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
            return ['r' => hexdec(substr($hex,0,2)), 'g' => hexdec(substr($hex,2,2)), 'b' => hexdec(substr($hex,4,2))];
        }
        if (preg_match('/^rgb\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*\)$/i', $color, $m)) {
            return ['r' => (int)$m[1], 'g' => (int)$m[2], 'b' => (int)$m[3]];
        }
        return null;
    }

    /**
     * Approximate RGB→OKLCH conversion.
     * Uses linearized sRGB → OKLab → OKLCH pipeline.
     */
    private function rgb_to_oklch_approx(int $r, int $g, int $b): array {
        // sRGB to linear
        $rl = $this->srgb_to_linear($r / 255);
        $gl = $this->srgb_to_linear($g / 255);
        $bl = $this->srgb_to_linear($b / 255);

        // Linear RGB to OKLab (Björn Ottosson's matrix)
        $l_ = 0.4122214708 * $rl + 0.5363325363 * $gl + 0.0514459929 * $bl;
        $m_ = 0.2119034982 * $rl + 0.6806995451 * $gl + 0.1073969566 * $bl;
        $s_ = 0.0883024619 * $rl + 0.2817188376 * $gl + 0.6299787005 * $bl;

        $l_c = pow(max(0, $l_), 1/3);
        $m_c = pow(max(0, $m_), 1/3);
        $s_c = pow(max(0, $s_), 1/3);

        $L = 0.2104542553 * $l_c + 0.7936177850 * $m_c - 0.0040720468 * $s_c;
        $a = 1.9779984951 * $l_c - 2.4285922050 * $m_c + 0.4505937099 * $s_c;
        $bv = 0.0259040371 * $l_c + 0.7827717662 * $m_c - 0.8086757660 * $s_c;

        // OKLab to OKLCH
        $C = sqrt($a * $a + $bv * $bv);
        $H = atan2($bv, $a) * 180 / M_PI;
        if ($H < 0) $H += 360;

        return [
            'l' => round(max(0, min(1, $L)), 4),
            'c' => round(max(0, $C), 4),
            'h' => round($H, 2),
        ];
    }

    private function srgb_to_linear(float $v): float {
        return $v <= 0.04045 ? $v / 12.92 : pow(($v + 0.055) / 1.055, 2.4);
    }

    private function hsl_to_rgb(float $h, float $s, float $l): array {
        $s /= 100; $l /= 100;
        $c = (1 - abs(2 * $l - 1)) * $s;
        $x = $c * (1 - abs(fmod($h / 60, 2) - 1));
        $m = $l - $c / 2;
        if ($h < 60) { $r=$c; $g=$x; $b=0; }
        elseif ($h < 120) { $r=$x; $g=$c; $b=0; }
        elseif ($h < 180) { $r=0; $g=$c; $b=$x; }
        elseif ($h < 240) { $r=0; $g=$x; $b=$c; }
        elseif ($h < 300) { $r=$x; $g=0; $b=$c; }
        else { $r=$c; $g=0; $b=$x; }
        return ['r' => (int)round(($r+$m)*255), 'g' => (int)round(($g+$m)*255), 'b' => (int)round(($b+$m)*255)];
    }

    private function fmt_oklch(float $l, float $c, float $h): string {
        $l = round(max(0, min(1, $l)), 4);
        $c = round(max(0, $c), 4);
        $h = round($h, 2);
        return "oklch({$l} {$c} {$h})";
    }
}
