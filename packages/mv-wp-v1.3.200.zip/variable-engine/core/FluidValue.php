<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * FluidValue — single source of truth for fluid clamp() math.
 *
 * A "fluid" variable stores a compact marker in its `value` field:
 *
 *     fluid:16,24
 *
 * meaning the value scales from 16px at the min viewport to 24px at the max
 * viewport. The computed clamp() string lives in `css_value`.
 *
 * This helper is intentionally tiny and dependency-free so it can be reused
 * by VariableManager (single fluid variables) and FluidScaleGenerator
 * (generated fluid scales) without duplicating the slope/intercept formula.
 */
class FluidValue {

	/** Marker prefix that identifies a fluid value in the `value` column. */
	public const PREFIX = 'fluid:';

	/**
	 * Is this stored value a fluid marker?
	 */
	public static function is_fluid( string $value ): bool {
		return stripos( trim( $value ), self::PREFIX ) === 0;
	}

	/**
	 * Build the compact stored marker from a min/max pair.
	 * Both values are plain px numbers.
	 */
	public static function make_marker( float $min_px, float $max_px ): string {
		return self::PREFIX . self::trim_num( $min_px ) . ',' . self::trim_num( $max_px );
	}

	/**
	 * Parse a fluid marker into [min_px, max_px], or null if not a fluid marker.
	 */
	public static function parse_marker( string $value ): ?array {
		$value = trim( $value );
		if ( ! self::is_fluid( $value ) ) {
			return null;
		}
		$body  = substr( $value, strlen( self::PREFIX ) );
		$parts = array_map( 'trim', explode( ',', $body ) );
		if ( count( $parts ) !== 2 || ! is_numeric( $parts[0] ) || ! is_numeric( $parts[1] ) ) {
			return null;
		}
		return [ (float) $parts[0], (float) $parts[1] ];
	}

	/**
	 * Read the global fluid viewport settings (vw_min / vw_max) from ve_settings.
	 */
	public static function viewport(): array {
		$defaults = [ 'vw_min' => 320, 'vw_max' => 1440 ];
		$settings = get_option( 've_settings', $defaults );
		$vw_min   = (int) ( $settings['vw_min'] ?? 320 );
		$vw_max   = (int) ( $settings['vw_max'] ?? 1440 );
		// Guard against a zero / inverted range that would divide by zero below.
		if ( $vw_max <= $vw_min ) {
			$vw_min = 320;
			$vw_max = 1440;
		}
		return [ $vw_min, $vw_max ];
	}

	/**
	 * Build a CSS clamp() string from a min/max px pair and a viewport range.
	 *
	 * @param float  $min_px Value at the min viewport.
	 * @param float  $max_px Value at the max viewport.
	 * @param int    $vw_min Min viewport width in px.
	 * @param int    $vw_max Max viewport width in px.
	 * @param string $unit   'rem' or 'px' (1rem = 10px in this project).
	 */
	public static function clamp( float $min_px, float $max_px, int $vw_min, int $vw_max, string $unit = 'rem' ): string {
		$min_px = round( $min_px, 3 );
		$max_px = round( $max_px, 3 );

		// Ensure min <= max so clamp() is always valid.
		if ( $min_px > $max_px ) {
			$tmp    = $min_px;
			$min_px = $max_px;
			$max_px = $tmp;
		}

		$span = ( $vw_max - $vw_min );
		if ( $span <= 0 ) {
			$span = 1;
		}

		$slope     = ( $max_px - $min_px ) / $span;
		$intercept = $min_px - $slope * $vw_min;
		$slope_vw  = round( $slope * 100, 4 );

		if ( 'rem' === $unit ) {
			$min_rem = self::trim_num( round( $min_px / 10, 4 ) );
			$max_rem = self::trim_num( round( $max_px / 10, 4 ) );
			$int_rem = self::trim_num( round( $intercept / 10, 4 ) );
			return "clamp({$min_rem}rem, {$int_rem}rem + {$slope_vw}vw, {$max_rem}rem)";
		}

		$int_px = self::trim_num( round( $intercept, 3 ) );
		$min_px = self::trim_num( $min_px );
		$max_px = self::trim_num( $max_px );
		return "clamp({$min_px}px, {$int_px}px + {$slope_vw}vw, {$max_px}px)";
	}

	/**
	 * Convenience: compile a stored fluid marker straight into a clamp() string
	 * using the global viewport settings. Returns the original value untouched
	 * if it is not a fluid marker.
	 */
	public static function compile( string $value, string $unit = 'rem' ): string {
		$pair = self::parse_marker( $value );
		if ( null === $pair ) {
			return $value;
		}
		[ $vw_min, $vw_max ] = self::viewport();
		return self::clamp( $pair[0], $pair[1], $vw_min, $vw_max, $unit );
	}

	/**
	 * Format a float without trailing zeros (e.g. 16.0 → "16", 1.2500 → "1.25").
	 */
	private static function trim_num( float $n ): string {
		$s = rtrim( rtrim( sprintf( '%.4f', $n ), '0' ), '.' );
		return $s === '' || $s === '-0' ? '0' : $s;
	}
}
