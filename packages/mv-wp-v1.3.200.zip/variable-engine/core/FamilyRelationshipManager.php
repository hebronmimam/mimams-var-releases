<?php

namespace VE\Core;

use VE\Database\Schema;
use VE\Sync\SnapshotManager;

defined( 'ABSPATH' ) || exit;

/**
 * Transactional editor for organizational variable-family relationships.
 *
 * This manager never renames variables or recalculates their values. It only
 * changes the stored generated/source relationship, its dependency edge, and
 * the organizational Category/Color Palette ownership required by that edge.
 */
class FamilyRelationshipManager {

    private VariableManager $variables;

    public function __construct() {
        $this->variables = new VariableManager();
    }

    public function preview( array $request ) {
        global $wpdb;

        $variables = $this->variables->get_all();
        $generator_roots = array_map( 'intval', $wpdb->get_col(
            'SELECT DISTINCT variable_id FROM ' . Schema::table( 'generators' )
        ) ?: [] );

        $plan = self::build_plan( $variables, $generator_roots, $request );
        if ( is_wp_error( $plan ) ) {
            return $plan;
        }

        $by_id = [];
        foreach ( $variables as $variable ) {
            $by_id[ (int) $variable['id'] ] = $variable;
        }
        $palette_manager = new ColorPaletteManager();
        foreach ( $plan['changes'] as $change ) {
            if ( 'generated' !== (string) $change['to_type'] || (int) $change['to_parent_id'] <= 0 ) {
                continue;
            }
            $child = $by_id[ (int) $change['id'] ] ?? null;
            $parent = $by_id[ (int) $change['to_parent_id'] ] ?? null;
            if (
                $child
                && $parent
                && $palette_manager->is_color_variable( $child ) !== $palette_manager->is_color_variable( $parent )
            ) {
                return new \WP_Error(
                    've_family_mixed_value_kind',
                    'Color and non-color variables cannot share one family root.',
                    [ 'status' => 409 ]
                );
            }
        }

        return $plan;
    }

    /**
     * Pure relationship planner, kept public so the complete safety contract
     * can be covered without a live WordPress database.
     */
    public static function build_plan( array $variables, array $generator_roots, array $request ) {
        $operation = sanitize_key( (string) ( $request['operation'] ?? '' ) );
        if ( ! in_array( $operation, [ 'group', 'reparent', 'ungroup', 'change_root' ], true ) ) {
            return new \WP_Error( 've_family_invalid_operation', 'Choose a valid family action.', [ 'status' => 400 ] );
        }

        $by_id = [];
        foreach ( $variables as $variable ) {
            $id = (int) ( $variable['id'] ?? 0 );
            if ( $id > 0 ) {
                $by_id[ $id ] = $variable;
            }
        }
        $generator_lookup = array_fill_keys( array_map( 'intval', $generator_roots ), true );
        $selected_ids = array_values( array_unique( array_filter( array_map( 'intval', (array) ( $request['variable_ids'] ?? [] ) ) ) ) );
        $root_id = (int) ( $request['root_id'] ?? 0 );
        $new_root_id = (int) ( $request['new_root_id'] ?? 0 );
        $changes = [];

        if ( in_array( $operation, [ 'group', 'reparent' ], true ) ) {
            $root = $by_id[ $root_id ] ?? null;
            if ( ! $root || 'base' !== (string) ( $root['type'] ?? '' ) ) {
                return new \WP_Error( 've_family_invalid_root', 'Choose a standalone base variable as the family root.', [ 'status' => 400 ] );
            }
            if ( isset( $generator_lookup[ $root_id ] ) ) {
                return new \WP_Error( 've_family_calculated_root', 'Calculated generator families cannot be reorganized manually.', [ 'status' => 409 ] );
            }

            $child_ids = array_values( array_filter( $selected_ids, static fn( int $id ): bool => $id !== $root_id ) );
            if ( empty( $child_ids ) ) {
                return new \WP_Error( 've_family_children_required', 'Select at least one variable to place beneath the root.', [ 'status' => 400 ] );
            }
            foreach ( $child_ids as $child_id ) {
                $child = $by_id[ $child_id ] ?? null;
                $valid_child = $child && in_array( (string) ( $child['type'] ?? '' ), [ 'base', 'generated' ], true );
                if ( ! $valid_child || 'alias' === (string) ( $child['type'] ?? '' ) ) {
                    return new \WP_Error( 've_family_invalid_child', 'Aliases cannot become generated family children.', [ 'status' => 409 ] );
                }
                if ( isset( $generator_lookup[ $child_id ] ) || ! self::is_manual_child( $child ) ) {
                    return new \WP_Error( 've_family_calculated_child', 'Calculated generated variables cannot be regrouped manually.', [ 'status' => 409 ] );
                }
                if ( self::has_generated_children( $child_id, $variables ) ) {
                    return new \WP_Error( 've_family_nested_child', 'A current family root cannot become a child. Use Change root for that family first.', [ 'status' => 409 ] );
                }
                $changes[] = self::change_row(
                    $child,
                    'generated',
                    $root_id,
                    'manual',
                    (string) ( $root['category_slug'] ?? 'uncategorized' ),
                    $root
                );
            }
        } elseif ( 'ungroup' === $operation ) {
            if ( empty( $selected_ids ) ) {
                return new \WP_Error( 've_family_children_required', 'Select at least one family child to ungroup.', [ 'status' => 400 ] );
            }
            foreach ( $selected_ids as $child_id ) {
                $child = $by_id[ $child_id ] ?? null;
                if ( ! $child || 'generated' !== (string) ( $child['type'] ?? '' ) || ! self::is_manual_child( $child ) ) {
                    return new \WP_Error( 've_family_invalid_ungroup', 'Only imported or manually grouped children can be ungrouped.', [ 'status' => 409 ] );
                }
                $parent = $by_id[ (int) ( $child['source_id'] ?? 0 ) ] ?? null;
                $changes[] = self::change_row(
                    $child,
                    'base',
                    0,
                    '',
                    (string) ( $child['category_slug'] ?? 'uncategorized' ),
                    $parent
                );
            }
        } else {
            $root = $by_id[ $root_id ] ?? null;
            $new_root = $by_id[ $new_root_id ] ?? null;
            if ( ! $root || 'base' !== (string) ( $root['type'] ?? '' ) ) {
                return new \WP_Error( 've_family_invalid_root', 'Choose the current family root.', [ 'status' => 400 ] );
            }
            if ( isset( $generator_lookup[ $root_id ] ) ) {
                return new \WP_Error( 've_family_calculated_root', 'Calculated generator families cannot change root manually.', [ 'status' => 409 ] );
            }
            if ( ! $new_root || 'generated' !== (string) ( $new_root['type'] ?? '' ) || (int) ( $new_root['source_id'] ?? 0 ) !== $root_id || ! self::is_manual_child( $new_root ) ) {
                return new \WP_Error( 've_family_invalid_new_root', 'Choose one of this family’s imported or manually grouped children as the new root.', [ 'status' => 400 ] );
            }

            $category = (string) ( $root['category_slug'] ?? 'uncategorized' );
            $changes[] = self::change_row( $new_root, 'base', 0, '', $category, $root );
            $changes[] = self::change_row( $root, 'generated', $new_root_id, 'manual', $category, $new_root );
            foreach ( $variables as $sibling ) {
                if (
                    'generated' === (string) ( $sibling['type'] ?? '' )
                    && (int) ( $sibling['source_id'] ?? 0 ) === $root_id
                    && (int) ( $sibling['id'] ?? 0 ) !== $new_root_id
                ) {
                    if ( ! self::is_manual_child( $sibling ) ) {
                        return new \WP_Error( 've_family_mixed_generator', 'This family contains calculated children and cannot change root manually.', [ 'status' => 409 ] );
                    }
                    $changes[] = self::change_row( $sibling, 'generated', $new_root_id, (string) ( $sibling['generator_type'] ?: 'manual' ), $category, $new_root );
                }
            }
        }

        $changes = array_values( array_filter( $changes, static function ( array $change ): bool {
            return $change['from_type'] !== $change['to_type']
                || $change['from_parent_id'] !== $change['to_parent_id']
                || $change['from_category'] !== $change['to_category'];
        } ) );
        if ( empty( $changes ) ) {
            return new \WP_Error( 've_family_no_changes', 'The selected variables already have these family relationships.', [ 'status' => 409 ] );
        }
        foreach ( $changes as &$change ) {
            $from_parent = $by_id[ (int) $change['from_parent_id'] ] ?? null;
            $to_parent = $by_id[ (int) $change['to_parent_id'] ] ?? null;
            $change['from_parent_name'] = $from_parent ? (string) ( $from_parent['name'] ?? '' ) : '';
            $change['to_parent_name'] = $to_parent ? (string) ( $to_parent['name'] ?? '' ) : (string) $change['to_parent_name'];
        }
        unset( $change );

        $fingerprint_data = [
            'operation' => $operation,
            'root_id' => $root_id,
            'new_root_id' => $new_root_id,
            'changes' => array_map( static function ( array $change ): array {
                return [
                    $change['id'],
                    $change['name'],
                    $change['from_type'],
                    $change['from_parent_id'],
                    $change['from_generator_type'],
                    $change['to_type'],
                    $change['to_parent_id'],
                    $change['to_generator_type'],
                    $change['from_category'],
                    $change['to_category'],
                ];
            }, $changes ),
        ];

        return [
            'operation' => $operation,
            'root_id' => $root_id,
            'new_root_id' => $new_root_id,
            'changes' => $changes,
            'count' => count( $changes ),
            'fingerprint' => hash( 'sha256', wp_json_encode( $fingerprint_data ) ),
            'preserves' => [ 'names', 'values', 'css_names', 'aliases', 'origins' ],
        ];
    }

    public function apply( array $request ) {
        global $wpdb;

        $plan = $this->preview( $request );
        if ( is_wp_error( $plan ) ) {
            return $plan;
        }
        $expected = sanitize_text_field( (string) ( $request['fingerprint'] ?? '' ) );
        if ( '' === $expected || ! hash_equals( (string) $plan['fingerprint'], $expected ) ) {
            return new \WP_Error( 've_family_preview_changed', 'The family state changed after Preview. Review it again before applying.', [ 'status' => 409 ] );
        }

        $snapshot_id = ( new SnapshotManager() )->create( 'pre_relationship' );
        if ( is_wp_error( $snapshot_id ) ) {
            return $snapshot_id;
        }
        if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
            return new \WP_Error( 've_family_transaction_failed', $wpdb->last_error ?: 'Could not start the family transaction.', [ 'status' => 500, 'snapshot_id' => $snapshot_id ] );
        }

        $variables_table = Schema::table( 'variables' );
        $dependencies_table = Schema::table( 'dependencies' );
        $palette_manager = new ColorPaletteManager();
        $palette_state = $this->palette_state_for_plan( $plan, $palette_manager );

        try {
            foreach ( $plan['changes'] as $change ) {
                $id = (int) $change['id'];
                $data = [
                    'type' => (string) $change['to_type'],
                    'source_id' => $change['to_parent_id'] > 0 ? (int) $change['to_parent_id'] : null,
                    'generator_type' => '' !== (string) $change['to_generator_type'] ? (string) $change['to_generator_type'] : null,
                    'category_slug' => (string) $change['to_category'],
                ];
                if ( false === $wpdb->update( $variables_table, $data, [ 'id' => $id ], [ '%s', '%d', '%s', '%s' ], [ '%d' ] ) ) {
                    throw new \RuntimeException( $wpdb->last_error ?: 'Could not update a family relationship.' );
                }
                if ( false === $wpdb->delete( $dependencies_table, [ 'child_id' => $id, 'relation' => 'generated' ] ) ) {
                    throw new \RuntimeException( $wpdb->last_error ?: 'Could not replace a family dependency.' );
                }
                if ( $change['to_parent_id'] > 0 && ! ( new DependencyGraph() )->register( (int) $change['to_parent_id'], $id, 'generated' ) ) {
                    throw new \RuntimeException( 'Could not register a family dependency.' );
                }
            }

            $this->apply_palette_state( $plan, $palette_state, $palette_manager );
            if ( ! ( new CssExporter() )->export() ) {
                throw new \RuntimeException( 'Could not write generated CSS after the family change.' );
            }
            if ( false === $wpdb->query( 'COMMIT' ) ) {
                throw new \RuntimeException( $wpdb->last_error ?: 'Could not commit the family changes.' );
            }
        } catch ( \Throwable $error ) {
            $wpdb->query( 'ROLLBACK' );
            ( new CssExporter() )->export();
            return new \WP_Error(
                've_family_apply_failed',
                'Family changes were rolled back. ' . $error->getMessage(),
                [ 'status' => 500, 'snapshot_id' => (int) $snapshot_id ]
            );
        }

        return [
            'applied' => count( $plan['changes'] ),
            'snapshot_id' => (int) $snapshot_id,
            'operation' => (string) $plan['operation'],
            'changes' => $plan['changes'],
        ];
    }

    private static function is_manual_child( array $variable ): bool {
        if ( 'generated' !== (string) ( $variable['type'] ?? '' ) ) {
            return true;
        }
        return in_array( (string) ( $variable['generator_type'] ?? '' ), [ '', 'manual', 'imported' ], true );
    }

    private static function has_generated_children( int $id, array $variables ): bool {
        foreach ( $variables as $variable ) {
            if ( 'generated' === (string) ( $variable['type'] ?? '' ) && (int) ( $variable['source_id'] ?? 0 ) === $id ) {
                return true;
            }
        }
        return false;
    }

    private static function change_row( array $variable, string $type, int $parent_id, string $generator_type, string $category, ?array $parent ): array {
        return [
            'id' => (int) $variable['id'],
            'name' => (string) $variable['name'],
            'from_type' => (string) $variable['type'],
            'to_type' => $type,
            'from_parent_id' => (int) ( $variable['source_id'] ?? 0 ),
            'to_parent_id' => $parent_id,
            'from_parent_name' => '',
            'to_parent_name' => $parent_id > 0 && $parent ? (string) ( $parent['name'] ?? '' ) : '',
            'from_generator_type' => (string) ( $variable['generator_type'] ?? '' ),
            'to_generator_type' => $generator_type,
            'from_category' => (string) ( $variable['category_slug'] ?? 'uncategorized' ),
            'to_category' => $category ?: 'uncategorized',
        ];
    }

    private function palette_state_for_plan( array $plan, ColorPaletteManager $palette_manager ): array {
        $state = [];
        foreach ( $plan['changes'] as $change ) {
            $id = (int) $change['id'];
            $state[ $id ] = $palette_manager->palette_id_for_variable( $id );
            $parent_id = (int) $change['from_parent_id'];
            if ( $parent_id > 0 && ! isset( $state[ $parent_id ] ) ) {
                $state[ $parent_id ] = $palette_manager->palette_id_for_variable( $parent_id );
            }
        }
        return $state;
    }

    private function apply_palette_state( array $plan, array $palette_state, ColorPaletteManager $palette_manager ): void {
        $operation = (string) $plan['operation'];
        $root_id = (int) $plan['root_id'];
        $new_root_id = (int) $plan['new_root_id'];

        foreach ( $plan['changes'] as $change ) {
            if ( 'generated' === (string) $change['to_type'] ) {
                $palette_manager->remove_variable( (int) $change['id'] );
            }
        }

        if ( 'ungroup' === $operation ) {
            foreach ( $plan['changes'] as $change ) {
                $parent_palette = (int) ( $palette_state[ (int) $change['from_parent_id'] ] ?? 0 );
                $variable = $this->variables->get( (int) $change['id'] );
                if ( $parent_palette > 0 && $variable && $palette_manager->is_color_variable( $variable ) ) {
                    $assigned = $palette_manager->assign( (int) $change['id'], $parent_palette );
                    if ( is_wp_error( $assigned ) ) {
                        throw new \RuntimeException( $assigned->get_error_message() );
                    }
                }
            }
        } elseif ( 'change_root' === $operation ) {
            $root_palette = (int) ( $palette_state[ $root_id ] ?? 0 );
            $palette_manager->remove_variable( $root_id );
            $new_root = $this->variables->get( $new_root_id );
            if ( $root_palette > 0 && $new_root && $palette_manager->is_color_variable( $new_root ) ) {
                $assigned = $palette_manager->assign( $new_root_id, $root_palette );
                if ( is_wp_error( $assigned ) ) {
                    throw new \RuntimeException( $assigned->get_error_message() );
                }
            }
        }
    }
}
