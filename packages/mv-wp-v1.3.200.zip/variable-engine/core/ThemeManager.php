<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Theme value layers.
 *
 * PaletteManager remains the compatibility implementation for the options
 * introduced in v1.3.05. This correctly named facade lets new code describe
 * the product behavior without migrating or duplicating existing theme data.
 */
class ThemeManager extends PaletteManager {

    /**
     * Copy a variable's custom-theme values to a newly duplicated variable.
     */
    public function copy_variable( string $source_name, string $target_name ): void {
        $themes = get_option( 've_color_palettes', [] );
        if ( ! is_array( $themes ) ) {
            return;
        }

        $changed = false;
        foreach ( $themes as &$theme ) {
            $theme_changed = false;
            $values = isset( $theme['values'] ) && is_array( $theme['values'] ) ? $theme['values'] : [];
            foreach ( $values as $stored_name => $stored_value ) {
                if ( $stored_name !== $source_name && 0 !== strpos( $stored_name, $source_name . '.' ) ) {
                    continue;
                }
                $copied_name = $target_name . substr( $stored_name, strlen( $source_name ) );
                $theme['values'][ $copied_name ] = $stored_value;
                $theme_changed = true;
                $changed = true;
            }
            if ( $theme_changed ) {
                $theme['updated_at'] = current_time( 'mysql' );
            }
        }
        unset( $theme );

        if ( $changed ) {
            update_option( 've_color_palettes', $themes, false );
        }
    }

    public function snapshot_state(): array {
        $themes = get_option( 've_color_palettes', [] );
        return [
            'items'  => is_array( $themes ) ? $themes : [],
            'active' => $this->active_slug(),
        ];
    }

    public function restore_snapshot_state( array $state ): bool {
        $items = isset( $state['items'] ) && is_array( $state['items'] ) ? $state['items'] : [];
        $active = sanitize_key( (string) ( $state['active'] ?? self::DEFAULT_SLUG ) );
        update_option( 've_color_palettes', $items, false );
        update_option( 've_active_color_palette', $active ?: self::DEFAULT_SLUG, false );
        return true;
    }
}
