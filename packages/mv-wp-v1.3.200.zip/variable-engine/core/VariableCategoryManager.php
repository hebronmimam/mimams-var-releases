<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

class VariableCategoryManager {

    public function list(): array {
        global $wpdb;
        $categories = Schema::table( 'variable_categories' );
        $variables = Schema::table( 'variables' );
        return $wpdb->get_results(
            "SELECT c.*, COUNT(v.id) AS variable_count
             FROM {$categories} c
             LEFT JOIN {$variables} v ON v.category_slug = c.slug
             GROUP BY c.id
             ORDER BY c.position ASC, c.id ASC",
            ARRAY_A
        ) ?: [];
    }

    public function get_by_slug( string $slug ): ?array {
        global $wpdb;
        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . Schema::table( 'variable_categories' ) . ' WHERE slug = %s',
                sanitize_key( $slug )
            ),
            ARRAY_A
        );
        return $row ?: null;
    }

    public function create( string $name ) {
        global $wpdb;
        $name = trim( sanitize_text_field( $name ) );
        if ( '' === $name ) {
            return new \WP_Error( 've_category_name_required', 'Enter a category name.', [ 'status' => 400 ] );
        }
        $slug = $this->unique_slug( $name );
        $position = (int) $wpdb->get_var(
            'SELECT COALESCE(MAX(position), -1) + 1 FROM ' . Schema::table( 'variable_categories' )
        );
        $inserted = $wpdb->insert(
            Schema::table( 'variable_categories' ),
            [
                'slug'      => $slug,
                'name'      => $name,
                'position'  => $position,
                'protected' => 0,
            ],
            [ '%s', '%s', '%d', '%d' ]
        );
        if ( false === $inserted ) {
            return new \WP_Error( 've_category_create_failed', $wpdb->last_error ?: 'Could not create the category.', [ 'status' => 500 ] );
        }
        return $this->get_by_slug( $slug );
    }

    public function get_or_create( string $name ) {
        $slug = sanitize_title( $name );
        $existing = $this->get_by_slug( $slug );
        return $existing ?: $this->create( $name );
    }

    public function rename( string $slug, string $name ) {
        global $wpdb;
        $category = $this->get_by_slug( $slug );
        if ( ! $category ) {
            return new \WP_Error( 've_category_not_found', 'Category not found.', [ 'status' => 404 ] );
        }
        if ( ! empty( $category['protected'] ) ) {
            return new \WP_Error( 've_category_protected', 'System categories cannot be renamed.', [ 'status' => 409 ] );
        }
        $name = trim( sanitize_text_field( $name ) );
        if ( '' === $name ) {
            return new \WP_Error( 've_category_name_required', 'Enter a category name.', [ 'status' => 400 ] );
        }
        $updated = $wpdb->update(
            Schema::table( 'variable_categories' ),
            [ 'name' => $name ],
            [ 'slug' => $category['slug'] ],
            [ '%s' ],
            [ '%s' ]
        );
        if ( false === $updated ) {
            return new \WP_Error( 've_category_rename_failed', $wpdb->last_error ?: 'Could not rename the category.', [ 'status' => 500 ] );
        }
        return $this->get_by_slug( (string) $category['slug'] );
    }

    public function delete( string $slug ) {
        global $wpdb;
        $category = $this->get_by_slug( $slug );
        if ( ! $category ) {
            return new \WP_Error( 've_category_not_found', 'Category not found.', [ 'status' => 404 ] );
        }
        if ( ! empty( $category['protected'] ) ) {
            return new \WP_Error( 've_category_protected', 'Uncategorized cannot be deleted.', [ 'status' => 409 ] );
        }
        $transaction = $wpdb->query( 'START TRANSACTION' );
        if ( false === $transaction ) {
            return new \WP_Error( 've_category_transaction_failed', $wpdb->last_error ?: 'Could not start the category update.', [ 'status' => 500 ] );
        }
        $moved = $wpdb->update(
            Schema::table( 'variables' ),
            [ 'category_slug' => 'uncategorized' ],
            [ 'category_slug' => $category['slug'] ],
            [ '%s' ],
            [ '%s' ]
        );
        $deleted = $wpdb->delete(
            Schema::table( 'variable_categories' ),
            [ 'slug' => $category['slug'] ],
            [ '%s' ]
        );
        if ( false === $moved || false === $deleted || false === $wpdb->query( 'COMMIT' ) ) {
            $wpdb->query( 'ROLLBACK' );
            return new \WP_Error( 've_category_delete_failed', $wpdb->last_error ?: 'Could not delete the category.', [ 'status' => 500 ] );
        }
        return [ 'deleted' => true, 'moved' => (int) $moved ];
    }

    public function move_variables( array $ids, string $slug ) {
        global $wpdb;
        $category = $this->get_by_slug( $slug );
        if ( ! $category ) {
            return new \WP_Error( 've_category_not_found', 'Destination category not found.', [ 'status' => 404 ] );
        }
        $ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
        if ( empty( $ids ) ) {
            return new \WP_Error( 've_category_variables_required', 'Choose at least one variable.', [ 'status' => 400 ] );
        }
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
        $all_ids = $wpdb->get_col(
            $wpdb->prepare(
                "SELECT id FROM " . Schema::table( 'variables' ) . "
                 WHERE id IN ({$placeholders})
                    OR (type = 'generated' AND source_id IN ({$placeholders}))",
                ...array_merge( $ids, $ids )
            )
        ) ?: [];
        $all_ids = array_values( array_unique( array_map( 'intval', $all_ids ) ) );
        if ( empty( $all_ids ) ) {
            return new \WP_Error( 've_category_variables_missing', 'No matching variables were found.', [ 'status' => 404 ] );
        }
        $target_placeholders = implode( ',', array_fill( 0, count( $all_ids ), '%d' ) );
        $params = array_merge( [ (string) $category['slug'] ], $all_ids );
        $updated = $wpdb->query(
            $wpdb->prepare(
                "UPDATE " . Schema::table( 'variables' ) . "
                 SET category_slug = %s
                 WHERE id IN ({$target_placeholders})",
                ...$params
            )
        );
        if ( false === $updated ) {
            return new \WP_Error( 've_category_move_failed', $wpdb->last_error ?: 'Could not move the variables.', [ 'status' => 500 ] );
        }
        return [ 'moved' => count( $all_ids ), 'category' => $category ];
    }

    public function set_origin( array $ids, string $origin ): bool {
        global $wpdb;
        $ids = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
        if ( empty( $ids ) ) {
            return true;
        }
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
        $params = array_merge( [ sanitize_key( $origin ) ], $ids );
        return false !== $wpdb->query(
            $wpdb->prepare(
                "UPDATE " . Schema::table( 'variables' ) . "
                 SET origin = %s
                 WHERE id IN ({$placeholders})",
                ...$params
            )
        );
    }

    private function unique_slug( string $name ): string {
        $base = sanitize_title( $name );
        if ( '' === $base || 'color' === $base || 'all' === $base ) {
            $base = 'category';
        }
        $slug = $base;
        $suffix = 2;
        while ( $this->get_by_slug( $slug ) ) {
            $slug = $base . '-' . $suffix;
            $suffix++;
        }
        return $slug;
    }
}
