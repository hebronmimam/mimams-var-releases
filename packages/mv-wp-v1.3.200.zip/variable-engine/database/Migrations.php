<?php

namespace VE\Database;

defined( 'ABSPATH' ) || exit;

class Migrations {

    /**
     * Run on plugin activation.
     * Uses dbDelta for safe, idempotent table creation / updates.
     */
    public static function run(): void {
        require_once ABSPATH . 'wp-admin/includes/upgrade.php';

        $sql = Schema::get_sql();
        dbDelta( $sql );

        self::ensure_default_category();

        // Store the schema version so future migrations can diff.
        update_option( 've_db_version', VE_VERSION );

        ( new \VE\Core\ColorPaletteManager() )->repair_memberships();
    }

    private static function ensure_default_category(): void {
        global $wpdb;

        $categories = Schema::table( 'variable_categories' );
        $variables = Schema::table( 'variables' );
        $exists = (int) $wpdb->get_var(
            $wpdb->prepare( "SELECT id FROM {$categories} WHERE slug = %s", 'uncategorized' )
        );
        if ( $exists <= 0 ) {
            $wpdb->insert(
                $categories,
                [
                    'slug'      => 'uncategorized',
                    'name'      => 'Uncategorized',
                    'position'  => 0,
                    'protected' => 1,
                ],
                [ '%s', '%s', '%d', '%d' ]
            );
        }
        $wpdb->query(
            "UPDATE {$variables}
             SET category_slug = 'uncategorized'
             WHERE category_slug IS NULL OR category_slug = ''"
        );
    }

    public static function maybe_run(): void {
        if ( (string) get_option( 've_db_version', '' ) !== (string) VE_VERSION ) {
            self::run();
        }
    }
}
