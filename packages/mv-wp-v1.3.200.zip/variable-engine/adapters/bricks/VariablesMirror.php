<?php

namespace VE\Adapters\Bricks;

use VE\Core\VariableManager;

defined( 'ABSPATH' ) || exit;

class VariablesMirror {

    private const CATEGORY_ID = 'mimams-var';
    private const ID_PREFIX   = 'mv-';

    public function sync( ?array $variables = null ): bool {
        if ( ! $this->bricks_available() ) {
            return true;
        }

        if ( null === $variables ) {
            $variables = ( new VariableManager() )->get_all();
        }

        $current = get_option( 'bricks_global_variables', [] );
        $current = is_array( $current ) ? $current : [];
        $merged  = self::merge_variables( $current, $variables );

        if ( $merged !== $current && ! update_option( 'bricks_global_variables', $merged, false ) ) {
            return false;
        }

        $categories = get_option( 'bricks_global_variables_categories', [] );
        $categories = is_array( $categories ) ? $categories : [];
        $has_category = false;
        foreach ( $categories as $category ) {
            if ( is_array( $category ) && ( $category['id'] ?? '' ) === self::CATEGORY_ID ) {
                $has_category = true;
                break;
            }
        }
        if ( ! $has_category ) {
            $categories[] = [
                'id'   => self::CATEGORY_ID,
                'name' => "Mimam's Var",
            ];
            if ( ! update_option( 'bricks_global_variables_categories', array_values( $categories ), false ) ) {
                return false;
            }
        }

        return true;
    }

    public static function merge_variables( array $current, array $variables ): array {
        $manager = new VariableManager();
        $external = [];
        $external_names = [];

        foreach ( $current as $variable ) {
            if ( ! is_array( $variable ) ) {
                continue;
            }
            $id = (string) ( $variable['id'] ?? '' );
            $category = (string) ( $variable['category'] ?? '' );
            if ( self::CATEGORY_ID === $category || 0 === strpos( $id, self::ID_PREFIX ) ) {
                continue;
            }
            $name = ltrim( (string) ( $variable['name'] ?? '' ), '-' );
            if ( '' !== $name ) {
                $external_names[ $name ] = true;
            }
            $external[] = $variable;
        }

        $mirrored = [];
        foreach ( $variables as $variable ) {
            if ( ! is_array( $variable ) || empty( $variable['id'] ) || empty( $variable['name'] ) ) {
                continue;
            }
            $name = ltrim( $manager->to_css_name( (string) $variable['name'] ), '-' );
            if ( '' === $name || isset( $external_names[ $name ] ) ) {
                continue;
            }
            $mirrored[] = [
                'id'       => self::ID_PREFIX . (int) $variable['id'],
                'name'     => $name,
                'value'    => (string) ( $variable['css_value'] ?? $variable['value'] ?? '' ),
                'category' => self::CATEGORY_ID,
            ];
        }

        usort( $mirrored, static function ( array $a, array $b ): int {
            return strnatcasecmp( $a['name'], $b['name'] );
        } );

        return array_values( array_merge( $external, $mirrored ) );
    }

    private function bricks_available(): bool {
        return defined( 'BRICKS_VERSION' )
            || function_exists( 'bricks_is_builder' )
            || false !== get_option( 'bricks_global_variables', false );
    }
}
