(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;



  var Toast = {
    node: null,
    timer: null,
    ensure: function () {
      if (!this.node) {
        this.node = document.createElement('div');
        this.node.className = 'baqa-toast';
        document.body.appendChild(this.node);
      }
      return this.node;
    },
    place: function (node) {
      var panel = document.querySelector('.baqa-panel.is-open');
      if (panel) {
        var rect = panel.getBoundingClientRect();
        node.classList.add('is-under-bar');
        node.style.setProperty('inset-block-start', Math.round(rect.bottom + 42) + 'px', 'important');
        node.style.setProperty('inset-block-end', 'auto', 'important');
        node.style.setProperty('inset-inline-start', Math.round(rect.left + rect.width / 2) + 'px', 'important');
        node.style.setProperty('inset-inline-end', 'auto', 'important');
        return;
      }
      node.classList.remove('is-under-bar');
      node.style.setProperty('inset-block-start', 'auto', 'important');
      node.style.setProperty('inset-block-end', '22px', 'important');
      node.style.setProperty('inset-inline-start', '50%', 'important');
      node.style.setProperty('inset-inline-end', 'auto', 'important');
    },
    show: function (message, type) {
      var node = this.ensure();
      window.clearTimeout(this.timer);
      node.textContent = message;
      this.place(node);
      node.classList.toggle('is-error', type === 'error');
      node.classList.toggle('is-warning', type === 'warning');
      node.classList.add('is-visible');
      this.timer = window.setTimeout(function () {
        node.classList.remove('is-visible');
      }, 3000);
    }
  };


  window.MimamsBarToast = Toast;
})();
