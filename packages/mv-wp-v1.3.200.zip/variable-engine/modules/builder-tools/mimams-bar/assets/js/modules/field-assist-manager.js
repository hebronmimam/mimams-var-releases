(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;

  var FieldAssist = {
    getValue: function (input) {
      return input ? String(input.value || '') : '';
    },

    getCursor: function (input) {
      var value = this.getValue(input);
      var start = input && input.selectionStart != null ? input.selectionStart : value.length;
      var end = input && input.selectionEnd != null ? input.selectionEnd : start;
      return { value: value, start: start, end: end };
    },

    insertAtSelection: function (input, text, cursorOffset) {
      if (!input) return;
      var cursor = this.getCursor(input);
      input.value = cursor.value.slice(0, cursor.start) + text + cursor.value.slice(cursor.end);
      var next = cursor.start + (typeof cursorOffset === 'number' ? cursorOffset : text.length);
      input.setSelectionRange(next, next);
    },

    getDeleteCompletionInfo: function (input) {
      if (!input) return null;
      var cursor = this.getCursor(input);
      if (cursor.start !== cursor.end) return null;

      var before = cursor.value.slice(0, cursor.start);
      var after = cursor.value.slice(cursor.start);
      var match = before.match(/(^|\s)(d|de|del|dele|delet|delete)$/i);
      if (!match) return null;

      // Only complete while the cursor is still in the command keyword.
      if (after && !/^\s/.test(after)) return null;

      var prefixStart = before.length - match[2].length;
      return { value: cursor.value, after: after, prefixStart: prefixStart };
    },

    completeDeleteCommand: function (input) {
      var info = this.getDeleteCompletionInfo(input);
      if (!info || !input) return false;

      input.value = info.value.slice(0, info.prefixStart) + 'delete ' + info.after.replace(/^\s+/, '');
      var next = info.prefixStart + 7;
      input.setSelectionRange(next, next);
      return true;
    },

    getTabAssistMessage: function (input, mode) {
      if (mode === 'elements' || mode === 'add-elements') return '';

      if (!input) return '';
      var cursor = this.getCursor(input);

      if (this.getDeleteCompletionInfo(input)) return 'Tab → complete “delete”';
      if (cursor.start !== cursor.end) return '';
      if (this.findActiveClosingQuote(cursor.value, cursor.start) !== -1) return 'Tab → jump after quotes';
      if (this.findPreviousQuotedValueBeforeSpace(cursor.value, cursor.start)) return 'Shift+Tab → jump back into value';
      return '';
    },

    jumpOutOfQuotesForNextAttribute: function (input) {
      if (!input) return;
      var cursor = this.getCursor(input);
      if (cursor.start !== cursor.end) return;

      var closingQuote = this.findActiveClosingQuote(cursor.value, cursor.start);
      if (closingQuote === -1) return;

      var nextPosition = closingQuote + 1;
      if (cursor.value.charAt(nextPosition) !== ' ') {
        input.value = cursor.value.slice(0, nextPosition) + ' ' + cursor.value.slice(nextPosition);
        nextPosition += 1;
      } else {
        while (input.value.charAt(nextPosition) === ' ') nextPosition += 1;
      }

      input.setSelectionRange(nextPosition, nextPosition);
    },

    jumpBackIntoPreviousQuotedValue: function (input) {
      if (!input) return;
      var cursor = this.getCursor(input);
      if (cursor.start !== cursor.end) return;

      var previousQuote = this.findPreviousQuotedValueBeforeSpace(cursor.value, cursor.start);
      if (!previousQuote) return;
      input.setSelectionRange(previousQuote.close, previousQuote.close);
    },

    findPreviousQuotedValueBeforeSpace: function (value, position) {
      var previous = null;
      this.forEachQuotedValue(value, function (range) {
        if (position >= range.close + 1) previous = range;
      });

      if (!previous) return null;
      return /^\s*$/.test(value.slice(previous.close + 1, position)) ? previous : null;
    },

    findActiveClosingQuote: function (value, position) {
      var activeClose = -1;
      this.forEachQuotedValue(value, function (range) {
        if (position > range.open && position <= range.close) activeClose = range.close;
      });
      return activeClose;
    },

    forEachQuotedValue: function (value, callback) {
      var i = 0;
      var length = value.length;

      while (i < length) {
        if (value.charAt(i) !== '=') {
          i++;
          continue;
        }

        i++;
        while (i < length && /\s/.test(value.charAt(i))) i++;

        var quote = value.charAt(i);
        if (quote !== '"' && quote !== "'") {
          while (i < length && !/\s/.test(value.charAt(i))) i++;
          continue;
        }

        var open = i;
        i++;

        while (i < length) {
          var char = value.charAt(i);
          if (char === '\\') {
            i += 2;
            continue;
          }
          if (char === quote) {
            callback({ open: open, close: i, quote: quote });
            i++;
            break;
          }
          i++;
        }
      }
    }
  };

  window.MimamsBarFieldAssist = FieldAssist;
})();
