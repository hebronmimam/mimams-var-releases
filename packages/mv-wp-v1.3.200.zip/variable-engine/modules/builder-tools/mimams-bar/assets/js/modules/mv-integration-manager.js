(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarMVIntegration) return;

  var cache = null;
  var loading = false;
  var loaded = false;

  function config() {
    return window.baqaConfig || {};
  }

  function apiUrl(path) {
    var cfg = config();
    var root = String(cfg.apiRoot || window.vePanel && window.vePanel.apiRoot || '').replace(/\/$/, '/');
    if (!root) return '';
    return root + 'variable-engine/v1/' + String(path || '').replace(/^\//, '');
  }

  function cssTokenName(name) {
    name = String(name || '').trim();
    if (!name) return '';
    if (name.indexOf('--') === 0) return name;
    return '--' + name.replace(/^var\(|\)$/g, '').replace(/^--/, '').replace(/\./g, '-');
  }

  function normalizeVariable(item) {
    if (!item) return null;
    var name = String(item.name || item.key || item.variable || '').trim();
    if (!name) return null;
    var css = cssTokenName(name);
    return {
      name: name,
      css: css,
      value: item.value == null ? '' : String(item.value),
      type: item.type || item.category || ''
    };
  }

  function load(app) {
    if (loaded || loading) return;
    var url = apiUrl('variables?dedupe=true');
    if (!url || !window.fetch) return;
    loading = true;
    var headers = {};
    var nonce = config().nonce || window.vePanel && window.vePanel.nonce || '';
    if (nonce) headers['X-WP-Nonce'] = nonce;

    window.fetch(url, { headers: headers, credentials: 'same-origin' })
      .then(function (res) { return res && res.ok ? res.json() : []; })
      .then(function (data) {
        var list = Array.isArray(data) ? data : (data && Array.isArray(data.variables) ? data.variables : []);
        cache = list.map(normalizeVariable).filter(Boolean);
        loaded = true;
        loading = false;
        if (app && app.commandSuggestionsManager && app.mode === 'default') {
          app.commandSuggestionsManager.render(app);
        }
      })
      .catch(function () {
        cache = [];
        loaded = true;
        loading = false;
      });
  }

  function variables(app) {
    if (!loaded && !loading) load(app);
    return Array.isArray(cache) ? cache : [];
  }

  function escapeRegExp(value) {
    return String(value || '').replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  }

  function getTrigger(value, caret) {
    value = String(value || '');
    caret = typeof caret === 'number' ? caret : value.length;
    var before = value.slice(0, caret);

    var patterns = [
      { type: 'var', regex: /(?:^|[\s"'=])var\(?(--)?([a-z0-9_.-]*)$/i },
      { type: 'token', regex: /(?:^|\s)token\s+([a-z0-9_.-]*)$/i },
      { type: 'raw', regex: /(?:^|[\s"'=])(--[a-z0-9_.-]*)$/i }
    ];

    for (var i = 0; i < patterns.length; i++) {
      var match = before.match(patterns[i].regex);
      if (!match) continue;
      var matched = match[0];
      var start = before.length - matched.length;
      var leading = matched.match(/^[\s"'=]/) ? matched.charAt(0) : '';
      if (leading) start += 1;
      var query = patterns[i].type === 'raw'
        ? String(match[1] || '').replace(/^--/, '')
        : String(match[patterns[i].type === 'var' ? 2 : 1] || '').replace(/^--/, '');
      return { type: patterns[i].type, start: start, end: caret, query: query };
    }

    return null;
  }

  function score(item, query) {
    query = String(query || '').toLowerCase().replace(/^--/, '');
    var css = String(item.css || '').toLowerCase().replace(/^--/, '');
    var name = String(item.name || '').toLowerCase();
    var haystack = [css, name, item.value, item.type].join(' ').toLowerCase();
    if (!query) return 10;
    if (css === query || name === query) return 120;
    if (css.indexOf(query) === 0 || name.indexOf(query) === 0) return 90 - Math.min(css.length, 60);
    if (haystack.indexOf(query) !== -1) return 30;
    return -1;
  }

  function replacementFor(trigger, variable) {
    if (!trigger || !variable) return '';
    if (trigger.type === 'raw') return variable.css;
    return 'var(' + variable.css + ')';
  }

  function getSuggestions(app, value, caret) {
    if (!app || !app.input) return [];
    value = String(value == null ? app.input.value : value || '');
    caret = typeof caret === 'number' ? caret : (typeof app.input.selectionStart === 'number' ? app.input.selectionStart : value.length);
    var trigger = getTrigger(value, caret);
    if (!trigger) return [];

    var vars = variables(app);
    return vars.map(function (item) {
      return { item: item, score: score(item, trigger.query) };
    }).filter(function (entry) {
      return entry.score >= 0;
    }).sort(function (a, b) {
      return b.score - a.score || String(a.item.css).localeCompare(String(b.item.css));
    }).slice(0, 8).map(function (entry) {
      var variable = entry.item;
      var nextValue = value.slice(0, trigger.start) + replacementFor(trigger, variable) + value.slice(trigger.end);
      var caretPos = trigger.start + replacementFor(trigger, variable).length;
      return {
        type: 'mv-variable',
        key: variable.css,
        label: replacementFor(trigger, variable),
        detail: 'Mimam\'s Var token' + (variable.value ? ' · ' + variable.value : ''),
        command: nextValue,
        caret: caretPos,
        nextValue: nextValue
      };
    });
  }

  function hasTrigger(app) {
    if (!app || !app.input) return false;
    return !!getTrigger(app.input.value, app.input.selectionStart);
  }

  var MVIntegration = {
    init: load,
    loadVariables: load,
    getSuggestions: getSuggestions,
    hasTrigger: hasTrigger,
    cssTokenName: cssTokenName
  };

  window.MimamsBarMVIntegration = MVIntegration;
  window.MimamsBar = window.MimamsBar || {};
  window.MimamsBar.MVIntegration = MVIntegration;
})();
