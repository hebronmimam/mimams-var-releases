(function () {
  'use strict';

  var Core = window.MimamsBarCore || {};
  var MAX_BULK_TARGETS = Core.MAX_BULK_TARGETS || 40;

  function isBulkOp(op) {
    return !!(op && op.type === 'bulk-apply');
  }

  function needsConfirmation(ops) {
    return (ops || []).some(function (op) {
      return isBulkOp(op) && !op.confirmed;
    });
  }

  function cloneOp(op) {
    var copy = {};
    Object.keys(op || {}).forEach(function (key) { copy[key] = op[key]; });
    return copy;
  }

  function withConfirmedBulkOps(ops) {
    return (ops || []).map(function (op) {
      if (!isBulkOp(op)) return op;
      var copy = cloneOp(op);
      copy.confirmed = true;
      return copy;
    });
  }

  function quoteValue(value) {
    return '"' + String(value == null ? '' : value).replace(/"/g, '\\"') + '"';
  }

  function formatSelectorTarget(target) {
    if (!target) return 'unknown target';
    var pieces = [];
    if (target.tag) pieces.push('all <' + target.tag + '> elements');
    else pieces.push('elements');

    if (target.id) pieces.push('with #' + target.id);
    if (target.classes && target.classes.length) {
      pieces.push('with ' + target.classes.map(function (name) { return '.' + name; }).join(' and '));
    }

    return pieces.join(' ');
  }

  function formatTarget(target, adapter) {
    if (!target) return 'unknown target';

    if ((target.mode === 'selector' || target.mode === 'group') && adapter && typeof adapter.describeBulkTarget === 'function') {
      return adapter.describeBulkTarget(target);
    }

    var value = String(target.value || '').trim();
    if (target.mode === 'tag') return 'all <' + value + '> elements';
    if (target.mode === 'class') return 'elements with .' + value;
    if (target.mode === 'id') return 'element with #' + value;
    if (target.mode === 'type') return 'Bricks element type: ' + value;
    if (target.mode === 'selector') return formatSelectorTarget(target);
    if (target.mode === 'group') {
      return (target.targets || []).map(function (item) { return formatTarget(item, adapter); }).join(', ');
    }

    if (adapter && typeof adapter.describeBulkTarget === 'function') {
      return adapter.describeBulkTarget(target);
    }

    return String(target.mode || 'target') + ':' + value;
  }

  function formatAction(op) {
    if (!op) return '';

    if (op.type === 'set') {
      return 'set ' + op.name + '=' + quoteValue(op.value);
    }

    if (op.type === 'rename') {
      var text = 'rename ' + op.from + ' to ' + op.to;
      if (op.hasValue) text += ' and set value to ' + quoteValue(op.value);
      return text;
    }

    if (op.type === 'delete-attribute') {
      return 'remove ' + (op.names || []).join(', ');
    }

    if (op.type === 'set-id') {
      return 'set CSS ID to #' + op.value;
    }

    if (op.type === 'add-class') {
      return 'add class .' + op.name;
    }

    if (op.type === 'remove-class') {
      return 'remove class .' + op.name;
    }

    if (op.type === 'rename-class') {
      return 'rename class .' + op.from + ' to .' + op.to;
    }

    return op.type || 'apply command';
  }

  function formatActions(ops) {
    var actions = (ops || []).map(formatAction).filter(Boolean);
    if (!actions.length) return 'no safe action found';
    return actions.join(' + ');
  }

  function buildSummaries(ops, adapter, maxTargets) {
    var summaries = [];
    var items = [];
    var blocked = false;
    var limit = maxTargets || MAX_BULK_TARGETS;

    (ops || []).forEach(function (op) {
      if (!isBulkOp(op)) return;

      // Do not scan Bricks/Vue/iframe trees while opening the confirmation
      // dialog. The old preview count was enough to trigger Firefox/Bricks
      // memory blowups on commands like `all li => data-anim="fade-up"`.
      // Count and breadth checks now happen in the guarded apply path only.
      var targetText = formatTarget(op.target, adapter);
      var actionText = formatActions(op.ops || []);

      items.push({
        target: targetText,
        action: actionText,
        scope: 'current Bricks page/template',
        safety: 'checks matches safely, then stops above ' + limit + ' elements',
        limit: limit
      });

      summaries.push('Target: ' + targetText + ' | Action: ' + actionText + ' | Limit: ' + limit);
    });

    return {
      blocked: blocked,
      items: items,
      summaries: summaries,
      text: summaries.join('  |  ')
    };
  }

  function appendRow(parent, label, value) {
    var row = document.createElement('div');
    row.className = 'baqa-bulk-row';

    var labelNode = document.createElement('div');
    labelNode.className = 'baqa-bulk-row-label';
    labelNode.textContent = label;

    var valueNode = document.createElement('div');
    valueNode.className = 'baqa-bulk-row-value';
    valueNode.textContent = value;

    row.appendChild(labelNode);
    row.appendChild(valueNode);
    parent.appendChild(row);
  }

  function renderSummary(container, summary) {
    if (!container) return;
    container.innerHTML = '';

    var items = summary && summary.items ? summary.items : [];
    if (!items.length) {
      container.textContent = summary && summary.text ? summary.text : 'No bulk target found.';
      return;
    }

    var wrap = document.createElement('div');
    wrap.className = 'baqa-bulk-summary';

    items.forEach(function (item) {
      var card = document.createElement('div');
      card.className = 'baqa-bulk-summary-card';

      appendRow(card, 'Target', item.target);
      appendRow(card, 'Action', item.action);
      appendRow(card, 'Scope', item.scope);
      appendRow(card, 'Safety', item.safety);

      wrap.appendChild(card);
    });

    container.appendChild(wrap);
  }

  window.MimamsBarBulk = {
    isBulkOp: isBulkOp,
    needsConfirmation: needsConfirmation,
    withConfirmedBulkOps: withConfirmedBulkOps,
    buildSummaries: buildSummaries,
    renderSummary: renderSummary
  };
})();
