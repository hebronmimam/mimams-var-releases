(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;

  var Core = window.MimamsBarCore || {};
  var labels = Core.labels || {};

  var Parser = {
    isNameStart: function (char) {
      return /[A-Za-z_:@]/.test(char || '');
    },
    isNameChar: function (char) {
      return /[A-Za-z0-9_:\-@.]/.test(char || '');
    },
    parse: function (input) {
      var source = String(input || '').trim();
      var index = 0;
      var length = source.length;
      var operations = [];

      function skipSpaces() {
        while (index < length && /\s/.test(source[index])) index++;
      }

      function fail(message) {
        return { ok: false, error: message || labels.invalid || 'Invalid attribute syntax.' };
      }

      function parseTokenUntilSpaceOrArrow() {
        var start = index;
        while (index < length && !/\s/.test(source[index])) {
          if (source.slice(index, index + 2) === '->') break;
          index++;
        }
        return source.slice(start, index);
      }

      function normalizeClassName(value) {
        return String(value || '').replace(/^\./, '').trim();
      }

      function normalizeIdValue(value) {
        return String(value || '').replace(/^#/, '').trim();
      }

      function parseBulkCommand() {
        var arrowIndex = source.indexOf('=>');
        if (arrowIndex < 0) return null;

        var left = source.slice(0, arrowIndex).trim();
        var right = source.slice(arrowIndex + 2).trim();
        if (!left || !right) return fail('Bulk command needs a target and a command. Example: all h2 => data-anim="text-lines"');

        function unique(list) {
          var out = [];
          (list || []).forEach(function (item) {
            item = String(item || '').trim();
            if (item && out.indexOf(item) === -1) out.push(item);
          });
          return out;
        }

        function splitTargets(value) {
          return String(value || '').split(',').map(function (part) {
            return part.trim();
          }).filter(Boolean);
        }

        function parseSafeSelector(raw) {
          raw = String(raw || '').trim();
          if (!raw) return null;

          // Keep bulk selectors intentionally small and predictable. This is
          // not querySelectorAll(); it is a safe Bricks-data matcher for one
          // element identity at a time: tag + class(es) + optional id.
          if (/\s|[>+~\[\]=:*]/.test(raw)) return null;

          var rest = raw;
          var tag = '';
          var id = '';
          var classes = [];
          var tagMatch = rest.match(/^[a-z][a-z0-9-]*/i);

          if (tagMatch) {
            tag = tagMatch[0].toLowerCase();
            rest = rest.slice(tag.length);
          }

          while (rest.length) {
            var prefix = rest.charAt(0);
            if (prefix !== '.' && prefix !== '#') return null;
            rest = rest.slice(1);

            var nameMatch = rest.match(/^[A-Za-z0-9_-]+/);
            if (!nameMatch) return null;

            var name = nameMatch[0];
            rest = rest.slice(name.length);

            if (prefix === '#') {
              if (id) return null;
              id = name;
            } else if (classes.indexOf(name) === -1) {
              classes.push(name);
            }
          }

          classes = unique(classes);
          if (!tag && !id && !classes.length) return null;

          if (tag && !id && !classes.length) return { mode: 'tag', value: tag };
          if (!tag && id && !classes.length) return { mode: 'id', value: id };
          if (!tag && !id && classes.length === 1) return { mode: 'class', value: classes[0] };

          return {
            mode: 'selector',
            value: raw,
            tag: tag,
            id: id,
            classes: classes
          };
        }

        function parseOneTarget(raw) {
          raw = String(raw || '').trim();
          if (!raw) return null;

          var match = null;
          if (/^all\s+/i.test(raw)) {
            return parseSafeSelector(raw.replace(/^all\s+/i, '').trim());
          }

          if ((match = raw.match(/^tag\s*:\s*([a-z][a-z0-9-]*)$/i))) {
            return { mode: 'tag', value: match[1].toLowerCase() };
          }

          if ((match = raw.match(/^class\s*:\s*\.?(?:([A-Za-z0-9_-]+))$/i))) {
            return { mode: 'class', value: match[1] };
          }

          if ((match = raw.match(/^type\s*:\s*([a-z0-9_-]+)$/i))) {
            return { mode: 'type', value: match[1].toLowerCase() };
          }

          return parseSafeSelector(raw);
        }

        var parts = splitTargets(left);
        var targets = [];

        for (var targetIndex = 0; targetIndex < parts.length; targetIndex++) {
          var parsedTarget = parseOneTarget(parts[targetIndex]);
          if (!parsedTarget || !parsedTarget.value) {
            return fail('Unsupported bulk target. Use all h2, all li.card-item, .class-name, .card.featured, #id, tag:h2, class:name, type:heading, or comma groups like all h2, all p.');
          }
          targets.push(parsedTarget);
        }

        if (!targets.length) {
          return fail('Unsupported bulk target. Use all h2, .class-name, or all li.card-item.');
        }

        var target = targets.length === 1 ? targets[0] : { mode: 'group', value: parts.join(', '), targets: targets };

        var parsed = Parser.parse(right);
        if (!parsed.ok) return fail(parsed.error);
        var innerOps = parsed.ops || parsed.attrs || [];
        if (!innerOps.length) return fail('Bulk command has nothing to apply.');

        if (innerOps.some(function (op) { return op && op.type === 'bulk-apply'; })) {
          return fail('Nested bulk commands are not supported.');
        }

        if (innerOps.some(function (op) { return op && op.type === 'delete-global-class'; })) {
          return fail('Global class delete is not allowed inside bulk mode.');
        }

        return { ok: true, op: { type: 'bulk-apply', target: target, ops: innerOps, confirmed: false } };
      }

      function parseDeleteCommand() {
        skipSpaces();
        if (source.slice(index, index + 6).toLowerCase() !== 'delete') return null;

        var afterKeyword = source.charAt(index + 6);
        if (afterKeyword && !/\s/.test(afterKeyword)) return null;

        index += 6;
        skipSpaces();

        var explicitGlobal = false;
        var explicitAttr = false;

        if (source.slice(index, index + 6).toLowerCase() === 'global') {
          explicitGlobal = true;
          index += 6;
          skipSpaces();
        }

        if (source.slice(index, index + 5).toLowerCase() === 'class') {
          explicitGlobal = true;
          index += 5;
          skipSpaces();
        }

        if (source.slice(index, index + 4).toLowerCase() === 'attr') {
          explicitAttr = true;
          index += 4;
          skipSpaces();
        } else if (source.slice(index, index + 9).toLowerCase() === 'attribute') {
          explicitAttr = true;
          index += 9;
          skipSpaces();
        }

        var classNames = [];
        var attrNames = [];

        while (index < length) {
          skipSpaces();
          if (index >= length) break;

          var raw = parseTokenUntilSpaceOrArrow().replace(/,+$/g, '');
          if (!raw) break;

          // Allow users to delete from a clicked/loaded attribute command such as:
          // delete data-anim="fade-up". Only the attribute label matters for delete.
          var deleteName = raw;
          var equalsIndex = deleteName.indexOf('=');
          if (equalsIndex > -1) {
            deleteName = deleteName.slice(0, equalsIndex);
          }
          deleteName = deleteName.replace(/^['"]|['"]$/g, '').trim();

          if (explicitGlobal || deleteName.charAt(0) === '.') {
            var className = normalizeClassName(deleteName);
            if (!className) return fail('Missing global class name to delete.');
            if (classNames.indexOf(className) === -1) classNames.push(className);
          } else {
            var attrName = deleteName.trim();
            if (!explicitAttr && attrName.charAt(0) === '#') {
              return fail('Use #id-name to set an ID. ID delete is not supported yet.');
            }
            if (!attrName) return fail('Missing attribute name to delete.');
            if (attrNames.indexOf(attrName) === -1) attrNames.push(attrName);
          }

          skipSpaces();
        }

        if (!classNames.length && !attrNames.length) return fail('Missing name to delete.');

        if (classNames.length && attrNames.length) {
          return { ok: true, ops: [
            { type: 'delete-attribute', names: attrNames },
            { type: 'delete-global-class', name: classNames[0], names: classNames, confirmed: false }
          ] };
        }

        if (classNames.length) {
          return { ok: true, op: { type: 'delete-global-class', name: classNames[0], names: classNames, confirmed: false } };
        }

        return { ok: true, op: { type: 'delete-attribute', names: attrNames } };
      }

      function parseQuickClassOrIdCommand() {
        skipSpaces();
        var prefix = source[index];
        if (prefix !== '#' && prefix !== '.' && prefix !== '+' && prefix !== '-') return null;

        index++;
        var raw = parseTokenUntilSpaceOrArrow();
        var name = prefix === '#' ? normalizeIdValue(raw) : normalizeClassName(raw);

        if (!name) {
          return fail(prefix === '#' ? 'Missing CSS ID value.' : 'Missing class name.');
        }

        skipSpaces();

        if (source.slice(index, index + 2) === '->') {
          index += 2;
          skipSpaces();
          var nextPrefix = source[index];
          if ((prefix === '#' && nextPrefix === '#') || (prefix !== '#' && nextPrefix === '.')) {
            index++;
          }
          var rawTarget = parseTokenUntilSpaceOrArrow();
          var target = prefix === '#' ? normalizeIdValue(rawTarget) : normalizeClassName(rawTarget);

          if (!target) {
            return fail(prefix === '#' ? 'Missing new CSS ID value.' : 'Missing new class name.');
          }

          if (prefix === '#') {
            return { ok: true, op: { type: 'set-id', value: target } };
          }

          return { ok: true, op: { type: 'rename-class', from: name, to: target } };
        }

        if (prefix === '#') {
          return { ok: true, op: { type: 'set-id', value: name } };
        }

        if (prefix === '-') {
          return { ok: true, op: { type: 'remove-class', name: name } };
        }

        return { ok: true, op: { type: 'add-class', name: name } };
      }

      function parseName(label) {
        skipSpaces();

        if (index >= length) {
          return { ok: false, error: 'Missing ' + (label || 'attribute name') + '.' };
        }

        var nameStart = index;
        if (!Parser.isNameStart(source[index])) {
          return { ok: false, error: 'Attribute names must start with a letter, underscore, colon, or @.' };
        }

        index++;
        while (index < length && Parser.isNameChar(source[index])) index++;

        return { ok: true, name: source.slice(nameStart, index) };
      }

      function parseValue(name) {
        skipSpaces();

        if (source[index] !== '=') {
          return { ok: true, hasValue: false, value: '' };
        }

        index++;
        skipSpaces();

        if (index >= length) {
          return { ok: false, error: 'Missing value for ' + name + '.' };
        }

        var quote = source[index];
        var value = '';

        if (quote === '"' || quote === "'") {
          index++;
          var buffer = '';
          var closed = false;

          while (index < length) {
            var char = source[index];
            if (char === '\\' && index + 1 < length) {
              buffer += source[index + 1];
              index += 2;
              continue;
            }
            if (char === quote) {
              closed = true;
              index++;
              break;
            }
            buffer += char;
            index++;
          }

          if (!closed) return { ok: false, error: 'Missing closing quote for ' + name + '.' };
          value = buffer;
        } else {
          var unquotedStart = index;
          while (index < length && !/\s/.test(source[index])) index++;
          value = source.slice(unquotedStart, index);
          if (!value) return { ok: false, error: 'Missing value for ' + name + '.' };
          if (/["'=<>`]/.test(value)) return { ok: false, error: 'Invalid unquoted value for ' + name + '. Use quotes.' };
        }

        return { ok: true, hasValue: true, value: value };
      }

      while (index < length) {
        skipSpaces();
        if (index >= length) break;

        var bulkCommand = parseBulkCommand();
        if (bulkCommand) {
          if (!bulkCommand.ok) return fail(bulkCommand.error);
          operations.push(bulkCommand.op);

          // A bulk command owns the whole input: "target => command".
          // Do not continue the outer parse loop from index 0, otherwise the
          // same bulk command is parsed forever and the browser runs out of
          // memory before the confirmation dialog/apply step can happen.
          index = length;
          break;
        }

        var deleteCommand = parseDeleteCommand();
        if (deleteCommand) {
          if (!deleteCommand.ok) return fail(deleteCommand.error);
          if (deleteCommand.ops) {
            operations = operations.concat(deleteCommand.ops);
          } else {
            operations.push(deleteCommand.op);
          }
          skipSpaces();
          continue;
        }

        var quickCommand = parseQuickClassOrIdCommand();
        if (quickCommand) {
          if (!quickCommand.ok) return fail(quickCommand.error);
          operations.push(quickCommand.op);
          skipSpaces();
          continue;
        }

        var sourceName = parseName('attribute name');
        if (!sourceName.ok) return fail(sourceName.error);

        skipSpaces();

        if (source.slice(index, index + 2) === '->') {
          index += 2;
          skipSpaces();

          var targetName = parseName('new attribute name');
          if (!targetName.ok) return fail(targetName.error);

          var targetValue = parseValue(targetName.name);
          if (!targetValue.ok) return fail(targetValue.error);

          operations.push({
            type: 'rename',
            from: sourceName.name,
            to: targetName.name,
            hasValue: targetValue.hasValue,
            value: targetValue.value
          });
        } else {
          var attrValue = parseValue(sourceName.name);
          if (!attrValue.ok) return fail(attrValue.error);

          operations.push({
            type: 'set',
            name: sourceName.name,
            value: attrValue.hasValue ? attrValue.value : ''
          });
        }

        skipSpaces();
      }

      if (!operations.length) return fail('Type at least one attribute.');

      return { ok: true, ops: operations, attrs: operations.filter(function (op) { return op.type === 'set'; }) };
    }
  };


  window.MimamsBarParser = Parser;
})();
