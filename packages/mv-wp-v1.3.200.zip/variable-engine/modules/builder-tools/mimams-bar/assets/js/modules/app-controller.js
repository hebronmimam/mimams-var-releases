(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarAppController) return;

  function isBulkLikeCommandValue(value) {
    value = String(value || '');
    return value.indexOf('=>') !== -1 || /^\s*(all\s+|tag\s*:|class\s*:|type\s*:|[#.][^\s]+\s*=>)/i.test(value);
  }

  function suspendElementSearchForBulk(app) {
    if (!app || !isBulkLikeCommandValue(app.input && app.input.value)) return false;

    if (app._elementRenderTimer) {
      window.clearTimeout(app._elementRenderTimer);
      app._elementRenderTimer = null;
    }

    app.pageElementsCache = null;
    app.latestElementMatches = [];
    app.activeElementResultIndex = 0;

    if (app.elementResults) {
      app.elementResults.hidden = true;
      app.elementResults.innerHTML = '';
    }

    if (app.commandSuggestionsManager) app.commandSuggestionsManager.clear(app);

    if (app.mode !== 'default') {
      app.mode = 'default';
      if (app.elementModeLabel) app.elementModeLabel.textContent = 'Direct mode';
    }

    return true;
  }

  function create(deps) {
    deps = deps || {};

    var app = {
      core: deps.Core,
      parser: deps.Parser,
      adapter: deps.BricksAdapter,
      settings: deps.Settings,
      toast: deps.Toast,
      fieldAssist: deps.FieldAssist,
      elementSearch: deps.ElementSearch,
      emmet: deps.Emmet,
      mvIntegration: deps.MVIntegration,
      commandSuggestionsManager: deps.CommandSuggestions,
      activeCommandSuggestions: [],
      bulk: deps.Bulk,
      dialogs: deps.Dialogs,
      renderer: deps.UIRenderer,
      operationManager: deps.OperationManager,
      panelManager: deps.PanelManager,
      modeManager: deps.ModeManager,
      shell: deps.AppShell,
      inputManager: deps.InputManager,
      targetManager: deps.TargetManager,
      events: deps.GlobalEvents,
      labels: deps.labels || {},
      maxBulkTargets: deps.maxBulkTargets || 40,
      log: deps.log || function () {},
      matchesConfiguredShortcut: deps.matchesConfiguredShortcut || function () { return false; },

      panel: null,
      input: null,
      error: null,
      tabHint: null,
      target: null,
      attrList: null,
      identityList: null,
      frameDocs: [],
      lastCanvasPointerAt: 0,
      confirmOverlay: null,
      confirmInput: null,
      pendingDeleteOps: null,
      bulkOverlay: null,
      pendingBulkOps: null,
      settingsPanel: null,
      attrsExpanded: false,
      mode: 'default',
      elementResults: null,
      elementModeLabel: null,
      activeElementResultIndex: 0,
      latestElementMatches: [],
      pageElementsCache: null,
      pendingAddElementName: '',
      isAddingElement: false,
      _targetRefreshTimer: null,
      _elementRenderTimer: null,
      _lastElementSearchKey: '',
      _lastFrameBindAt: 0,
      _lastKnownTargetId: '',
      _globalEventsBound: false,

      init: function () {
        this.settings.load();
        this.panel = this.shell.create(this.labels);
        this.createConfirmDialog();
        this.createBulkDialog();
        this.cacheRefs(this.shell.refs(this.panel));
        this.bindShellEvents();
        this.settings.applyUiState();
        if (this.mvIntegration && typeof this.mvIntegration.init === 'function') this.mvIntegration.init(this);
        this.events.bind(this);
      },

      cacheRefs: function (refs) {
        refs = refs || {};
        for (var key in refs) {
          if (Object.prototype.hasOwnProperty.call(refs, key)) this[key] = refs[key];
        }
      },

      bindShellEvents: function () {
        if (this.attrsToggle) this.attrsToggle.addEventListener('click', this.toggleAttributesPanel.bind(this));
        
        var app = this;

        if (this.head) this.head.addEventListener('pointerdown', this.onPanelDragStart.bind(this));
        if (this.closeButton) this.closeButton.addEventListener('click', this.closePanel.bind(this));
        if (this.cancelButton) this.cancelButton.addEventListener('click', this.closePanel.bind(this));
        if (this.applyButton) this.applyButton.addEventListener('click', this.applyCommand.bind(this));
        if (this.scopeChips) {
          Array.prototype.forEach.call(this.scopeChips, function (chip) {
            chip.addEventListener('click', function () {
              var mode = chip.getAttribute('data-mode');
              if (mode === 'elements') app.enterPageSearchMode();
              else if (mode === 'add-elements') app.enterAddElementMode();
              else app.enterDefaultMode();
              app.closeModeMenu();
              app.syncScopeChips();
              if (app.input) app.input.focus();
            });
          });
        }
        if (this.modeTrigger) {
          this.modeTrigger.addEventListener('click', function (event) {
            event.stopPropagation();
            app.toggleModeMenu();
          });
        }
        document.addEventListener('click', function (event) {
          if (app.modeDropdown && !app.modeDropdown.contains(event.target)) app.closeModeMenu();
        });
        this.syncScopeChips();
        this.inputManager.bind(this);
      },

      openModeMenu: function () {
        if (!this.modeMenu || !this.modeTrigger) return;
        this.modeMenu.hidden = false;
        this.modeTrigger.setAttribute('aria-expanded', 'true');
        if (this.modeDropdown) this.modeDropdown.classList.add('is-open');
        if (this.panel) this.panel.classList.add('is-mode-menu-open');
      },

      closeModeMenu: function () {
        if (!this.modeMenu || !this.modeTrigger) return;
        this.modeMenu.hidden = true;
        this.modeTrigger.setAttribute('aria-expanded', 'false');
        if (this.modeDropdown) this.modeDropdown.classList.remove('is-open');
        if (this.panel) this.panel.classList.remove('is-mode-menu-open');
      },

      toggleModeMenu: function () {
        if (this.modeMenu && this.modeMenu.hidden) this.openModeMenu();
        else this.closeModeMenu();
      },

      // Keep the mode dropdown trigger + menu state in sync with the current mode (menu, chips, or 1/2/3 keys).
      syncScopeChips: function () {
        var mode = this.mode || 'default';
        if (this.panel) this.panel.setAttribute('data-mode', mode);
        if (this.applyButton) {
          this.applyButton.textContent = mode === 'elements' ? 'Select' : (mode === 'add-elements' ? 'Insert' : 'Apply');
        }
        var meta = mode === 'elements'
          ? { label: 'Search page', icon: 'magnifying-glass' }
          : (mode === 'add-elements' ? { label: 'Add element', icon: 'plus' } : { label: 'Direct', icon: 'sliders-horizontal' });
        if (this.modeTriggerLabel) this.modeTriggerLabel.textContent = meta.label;
        if (this.modeTriggerIcon) this.modeTriggerIcon.innerHTML = '<i class="ph-duotone ph-' + meta.icon + '"></i>';
        if (this.scopeChips) {
          Array.prototype.forEach.call(this.scopeChips, function (chip) {
            chip.classList.toggle('is-on', chip.getAttribute('data-mode') === mode);
          });
        }
      },

      afterModeChange: function () {
        this.syncScopeChips();
      },

      toggleHelpPanel: function () {
        window.dispatchEvent(new CustomEvent('ve-toggle-help'));
      },

      // Compatibility alias used by old bound handlers if a stale object calls close().
      close: function () {
        this.closePanel();
      },

      handleModeKeys: function (event) {
        return this.modeManager.handleModeKeys(this, event);
      },

      enterElementMode: function () {
        this.modeManager.enterPageSearch(this);
      },

      enterAddElementMode: function () {
        this.modeManager.enterAddElement(this);
      },

      enterDefaultMode: function () {
        this.modeManager.enterDefault(this);
      },

      getElementSearchMatches: function () {
        var query = this.input ? String(this.input.value || '').trim() : '';
        if (!query) return [];
        if (isBulkLikeCommandValue(query)) {
          this.pageElementsCache = null;
          this.latestElementMatches = [];
          return [];
        }
        if (!this.pageElementsCache) this.pageElementsCache = this.adapter.getAllElements();
        return this.elementSearch.getPageMatches(this.adapter, query, 8, this.pageElementsCache);
      },

      getElementLibraryMatches: function () {
        var query = this.input ? String(this.input.value || '').trim() : '';
        if (!query) return [];
        return this.elementSearch.getLibraryMatches(this.adapter, query, 10);
      },

      getElementModeMatches: function () {
        if (this.mode === 'add-elements') return this.getElementLibraryMatches();
        if (this.mode === 'elements') return this.getElementSearchMatches();
        return [];
      },

      renderElementResults: function () {
        if (!this.elementResults || (this.mode !== 'elements' && this.mode !== 'add-elements')) return;
        if (isBulkLikeCommandValue(this.input ? this.input.value : '')) {
          this.pageElementsCache = null;
          this.latestElementMatches = [];
          this.elementResults.hidden = true;
          this.elementResults.innerHTML = '';
          return;
        }
        var nextKey = this.mode + '::' + (this.input ? String(this.input.value || '').trim() : '');
        if (nextKey !== this._lastElementSearchKey) this.activeElementResultIndex = 0;
        var matches = this.getElementModeMatches();
        this.latestElementMatches = matches || [];
        this._lastElementSearchKey = nextKey;
        if (this.activeElementResultIndex < 0) this.activeElementResultIndex = 0;
        if (this.latestElementMatches.length && this.activeElementResultIndex >= this.latestElementMatches.length) {
          this.activeElementResultIndex = this.latestElementMatches.length - 1;
        }

        this.elementSearch.renderResults(this.elementResults, this.mode, this.latestElementMatches, {
          activeIndex: this.activeElementResultIndex,
          activate: this.setActiveElementResult.bind(this),
          add: this.requestAddElementResult.bind(this),
          select: this.selectElementResult.bind(this),
          label: this.adapter.getElementLabel.bind(this.adapter)
        });
      },

      refreshElementMatchesNow: function () {
        if (this._elementRenderTimer) {
          window.clearTimeout(this._elementRenderTimer);
          this._elementRenderTimer = null;
        }
        this.renderElementResults();
        return this.latestElementMatches || [];
      },

      requestRenderElementResults: function (delay) {
        var self = this;
        delay = typeof delay === 'number' ? delay : 420;
        if (this._elementRenderTimer) window.clearTimeout(this._elementRenderTimer);
        this._elementRenderTimer = window.setTimeout(function () {
          self._elementRenderTimer = null;
          self.renderElementResults();
        }, delay);
      },

      setActiveElementResult: function (index) {
        this.activeElementResultIndex = Math.max(0, Number(index) || 0);
      },

      moveElementResult: function (delta) {
        // v1.2.48: use the already rendered/cached result list so arrow keys
        // do not rescan the whole Bricks tree on every key press.
        if (!this.latestElementMatches || !this.latestElementMatches.length) {
          this.renderElementResults();
        }
        if (!this.latestElementMatches || !this.latestElementMatches.length) return;
        var next = this.activeElementResultIndex + delta;
        if (next < 0) next = this.latestElementMatches.length - 1;
        if (next >= this.latestElementMatches.length) next = 0;
        this.activeElementResultIndex = next;
        this.elementSearch.renderResults(this.elementResults, this.mode, this.latestElementMatches, {
          activeIndex: this.activeElementResultIndex,
          activate: this.setActiveElementResult.bind(this),
          add: this.requestAddElementResult.bind(this),
          select: this.selectElementResult.bind(this),
          label: this.adapter.getElementLabel.bind(this.adapter)
        });
      },

      selectActiveElementResult: function () {
        var matches = this.refreshElementMatchesNow ? this.refreshElementMatchesNow() : (this.latestElementMatches || []);
        if (!matches.length) {
          this.renderElementResults();
          matches = this.latestElementMatches || [];
        }
        if (!matches || !matches.length) return;
        var index = this.activeElementResultIndex;
        if (index < 0 || index >= matches.length) index = 0;
        var item = matches[index];
        if (this.mode === 'add-elements') {
          if (item && item.config) this.requestAddElementResult(item.config);
          return;
        }
        if (item && item.element) this.selectElementResult(item.element);
      },

      selectFirstElementResult: function () {
        this.selectActiveElementResult();
      },

      requestAddElementResult: function (config) {
        config = config || {};

        // v1.2.54: resolve against the current rendered/highlighted result at
        // the moment of action. This prevents stale labels after a previous
        // blocked add attempt.
        if (this.mode === 'add-elements') {
          var currentMatches = this.refreshElementMatchesNow ? this.refreshElementMatchesNow() : (this.latestElementMatches || []);
          var activeIndex = this.activeElementResultIndex;
          if (activeIndex < 0 || activeIndex >= currentMatches.length) activeIndex = 0;
          var activeItem = currentMatches && currentMatches[activeIndex] ? currentMatches[activeIndex] : null;
          if (activeItem && activeItem.config) config = activeItem.config;
        }

        var name = String(config.name || '').trim();
        if (!name) return;
        var label = config.label || name;

        if (config.emmet) {
          this.requestEmmetAdd(config.emmet);
          return;
        }

        var isCore = this.elementSearch && this.elementSearch.isCoreElementName && this.elementSearch.isCoreElementName(name);
        var source = isCore ? 'core Bricks element' : 'custom/third-party element';

        if (!isCore) {
          var customMessage = 'Custom/third-party elements are paused in Safe Add for now: "' + label + '" (' + name + '). Test core Bricks elements first.';
          this.pendingAddElementName = '';
          this.hideError();
          if (this.toast && typeof this.toast.show === 'function') this.toast.show(customMessage, 'error');
          return;
        }

        if (name !== 'section' && !this.adapter.getSelectedElement()) {
          var targetMessage = 'Select a target first before adding "' + label + '". Only Section can be added with no selected element.';
          this.pendingAddElementName = '';
          this.hideError();
          if (this.toast && typeof this.toast.show === 'function') this.toast.show(targetMessage, 'error');
          return;
        }

        this.pendingAddElementName = '';
        this.hideError();
        this.addElementResult(config);
      },

      requestEmmetAdd: function (plan) {
        plan = plan || {};
        var chain = Array.isArray(plan.chain) ? plan.chain : [];
        var elements = Array.isArray(plan.elements) ? plan.elements : chain.map(function (name) { return { name: name, label: name, settings: {} }; });
        if (!plan.ok) {
          this.hideError();
          this.toast.show(plan.reason === 'too-many' ? 'Emmet pattern has too many elements for one add.' : 'An Emmet branch is too deep for Safe Add.', 'warning');
          return;
        }
        if (!chain.length) return;

        for (var i = 0; i < elements.length; i++) {
          if (!elements[i] || !this.elementSearch.isCoreElementName(elements[i].name)) {
            this.hideError();
            this.toast.show('Unsupported Emmet element: ' + (chain[i] || ''), 'warning');
            return;
          }
        }

        if (!this.adapter.getSelectedElement()) {
          var rootSafe = { section: true, container: true, block: true, div: true };
          for (var rootIndex = 0; rootIndex < elements.length; rootIndex++) {
            if (elements[rootIndex].groupStart && !rootSafe[elements[rootIndex].name]) {
              this.hideError();
              this.toast.show('Select a target first, or start each sibling branch with a layout element.', 'warning');
              return;
            }
          }
        }

        this.pendingAddElementName = '';
        this.hideError();
        this.addEmmetPlan(plan);
      },

      addEmmetPlan: function (plan) {
        var self = this;
        plan = plan || {};
        var chain = Array.isArray(plan.chain) ? plan.chain.slice(0, 12) : [];
        var elements = Array.isArray(plan.elements) ? plan.elements.slice(0, 12) : chain.map(function (name) { return { name: name, label: name, settings: {} }; });
        if (!chain.length) return;
        if (this.isAddingElement) {
          this.hideError();
          if (this.toast && typeof this.toast.show === 'function') this.toast.show('Bricks is still processing the previous add action. Wait a moment and try again.', 'warning');
          return;
        }

        this.isAddingElement = true;
        var baseSelection = this.adapter.getSelectedElement();
        var index = 0;
        var addedCount = 0;

        function next() {
          if (index >= chain.length) {
            self.isAddingElement = false;
            self.pendingAddElementName = '';
            self.pageElementsCache = null;
            self.refreshTarget();
            if (self.input) self.input.value = '';
            if (typeof self.renderElementResults === 'function') self.renderElementResults();
            var emmetLabel = self.emmet && typeof self.emmet.label === 'function' ? self.emmet.label(plan) : chain.join(' > ');
            self.toast.show('Added Emmet structure: ' + emmetLabel);
            return;
          }

          var spec = elements[index++] || {};
          var name = spec.name || '';
          if (spec.groupStart) {
            if (baseSelection) self.adapter.selectElement(baseSelection, { focusStructure: false });
            else self.adapter.deselectElement();
          }
          var result = self.adapter.addBricksElement(name, { config: { name: name, label: spec.label || name }, settings: spec.settings || {}, keepLabel: !!(spec.settings && spec.settings.tag) });
          if (!result || !result.ok) {
            self.isAddingElement = false;
            self.hideError();
            self.toast.show('Could not complete Emmet add at ' + (spec.label || name) + '.', 'error');
            return;
          }
          addedCount++;
          window.setTimeout(next, 180);
        }

        next();
      },

      addElementResult: function (config) {
        var self = this;
        config = config || {};

        if (this.isAddingElement) {
          var busyMessage = 'Bricks is still processing the previous add action. Wait a moment and try again.';
          this.hideError();
          if (this.toast && typeof this.toast.show === 'function') this.toast.show(busyMessage, 'warning');
          return;
        }

        this.isAddingElement = true;
        window.setTimeout(function () { self.isAddingElement = false; }, 2500);

        if (window.console && typeof window.console.info === 'function') {
          window.console.info('[Mimam\'s Bar] Safe Add attempt', { name: config.name, label: config.label, category: config.category || '' });
        }

        var result = this.adapter.addBricksElement(config.name, { config: config });
        if (!result.ok) {
          this.isAddingElement = false;
          var message = result.reason === 'add-helper-missing'
            ? 'Could not access Bricks add-element helper on this site.'
            : result.reason === 'missing-target'
              ? 'Select a target before adding this element.'
              : 'Could not add Bricks element: ' + (config.label || config.name || 'unknown') + '.';
          this.hideError();
          this.toast.show(message, 'error');
          return;
        }

        this.pendingAddElementName = '';
        window.setTimeout(function () {
          self.isAddingElement = false;
          self.refreshTarget();
          if (self.input) self.input.value = '';
          if (typeof self.renderElementResults === 'function') self.renderElementResults();
          self.toast.show('Added ' + (config.label || config.name || 'element') + '. Save in Bricks to persist.');
        }, 250);
      },

      selectElementResult: function (element) {
        if (!element) return;
        var ok = this.adapter.selectElement(element, { focusStructure: true });
        this.pageElementsCache = null;
        this.refreshTarget();
        var self = this;
        window.setTimeout(function () { self.adapter.focusElementInStructure(element, { click: false }); self.refreshTarget(); }, 180);
        if (ok) this.toast.show('Target selected.');
        else this.showError('Could not select that element. Try selecting it from the Structure panel.');
      },

      createConfirmDialog: function () {
        var dialog = this.dialogs.createGlobalDeleteDialog(this);
        this.confirmOverlay = dialog.overlay;
        this.confirmInput = dialog.input;
      },

      createBulkDialog: function () {
        var dialog = this.dialogs.createBulkDialog(this);
        this.bulkOverlay = dialog.overlay;
      },

      openBulkDialog: function (ops) {
        suspendElementSearchForBulk(this);
        var summary = this.bulk.buildSummaries(ops, this.adapter, this.maxBulkTargets);
        this.pendingBulkOps = summary.blocked ? null : this.bulk.withConfirmedBulkOps(ops);

        var bulkTarget = this.bulkOverlay.querySelector('.baqa-bulk-target');
        if (this.bulk && typeof this.bulk.renderSummary === 'function') {
          this.bulk.renderSummary(bulkTarget, summary);
        } else if (bulkTarget) {
          bulkTarget.textContent = summary.text;
        }
        this.bulkOverlay.classList.toggle('is-blocked', summary.blocked);
        this.bulkOverlay.querySelector('.baqa-bulk-apply').disabled = summary.blocked;
        this.bulkOverlay.classList.add('is-open');
        window.setTimeout(function () {
          var button = app.bulkOverlay.querySelector(summary.blocked ? '.baqa-bulk-cancel' : '.baqa-bulk-apply');
          if (button) button.focus();
        }, 20);
      },

      closeBulkDialog: function () {
        if (!this.bulkOverlay) return;
        this.bulkOverlay.classList.remove('is-open');
        this.pendingBulkOps = null;
        if (this.input) this.input.focus();
      },

      confirmBulkApply: function () {
        if (!this.pendingBulkOps) return;
        suspendElementSearchForBulk(this);
        var ops = this.pendingBulkOps;
        this.bulkOverlay.classList.remove('is-open');
        this.pendingBulkOps = null;
        this.applyOperations(ops);
      },

      openConfirmDialog: function (ops) {
        this.pendingDeleteOps = this.dialogs.cloneConfirmedGlobalDeleteOps(ops);
        var names = this.dialogs.getGlobalDeleteNames(ops);

        this.confirmOverlay.querySelector('.baqa-confirm-target').textContent = names.map(function (name) { return '.' + name; }).join('  ');
        this.confirmInput.value = '';
        this.confirmOverlay.querySelector('.baqa-confirm-delete').disabled = true;
        this.confirmOverlay.classList.add('is-open');
        window.setTimeout(function () { app.confirmInput.focus(); }, 20);
      },

      closeConfirmDialog: function () {
        if (!this.confirmOverlay) return;
        this.confirmOverlay.classList.remove('is-open');
        this.pendingDeleteOps = null;
        if (this.input) this.input.focus();
      },

      confirmGlobalDelete: function () {
        if (!this.pendingDeleteOps || this.confirmInput.value !== 'DELETE') return;
        var ops = this.pendingDeleteOps;
        this.confirmOverlay.classList.remove('is-open');
        this.pendingDeleteOps = null;
        this.applyOperations(ops);
      },

      isOpen: function () {
        return this.panel && this.panel.classList.contains('is-open');
      },

      toggle: function () {
        this.isOpen() ? this.closePanel() : this.open();
      },

      open: function () {
        var self = this;
        var hasTarget = !!this.adapter.getSelectedElement();
        this.hideError();
        this.pageElementsCache = null;

        // Do not pre-scan the full Bricks tree when the bar opens. Page search
        // mode loads its own cache lazily. This keeps Direct/bulk commands from
        // paying the cost of a tree walk before they need it.

        this.refreshTarget();
        this.updateAttributesPanelState();
        this.panel.classList.add('is-open');
        this.input.value = '';

        if (hasTarget) {
          this.enterDefaultMode();
        } else {
          this.enterElementMode();
          this.hideError();
        }

        if (this.events && typeof this.events.bindCanvasIframeEvents === 'function') {
          this.events.bindCanvasIframeEvents(this);
        }

        this.updateTabHint();
        window.setTimeout(function () { app.input.focus(); app.updateTabHint(); }, 20);
      },

      closePanel: function () {
        this.closeModeMenu();
        if (this._elementRenderTimer) { window.clearTimeout(this._elementRenderTimer); this._elementRenderTimer = null; }
        if (this._targetRefreshTimer) { window.clearTimeout(this._targetRefreshTimer); this._targetRefreshTimer = null; }
        if (this._commandSuggestionTimer) { window.clearTimeout(this._commandSuggestionTimer); this._commandSuggestionTimer = null; }
        if (this._tabHintTimer) { window.clearTimeout(this._tabHintTimer); this._tabHintTimer = null; }
        this.pageElementsCache = null;
        this.latestElementMatches = [];
        if (this.commandSuggestionsManager) this.commandSuggestionsManager.clear(this);
        this.panel.classList.remove('is-open', 'is-settings-open', 'is-help-open');
        if (this.settingsPanel) { this.settingsPanel.style.display = 'none'; this.settingsPanel.classList.remove('is-open'); }
        if (this.helpPanel) { this.helpPanel.style.display = 'none'; this.helpPanel.classList.remove('is-open'); }

        if (this.events && typeof this.events.unbindCanvasIframeEvents === 'function') {
          this.events.unbindCanvasIframeEvents();
        }

        this.hideError();
        this.updateTabHint();
      },

      refreshTarget: function () {
        this.targetManager.refresh(this);
      },

      toggleAttributesPanel: function () {
        this.targetManager.toggleAttributesPanel(this);
      },

      updateAttributesPanelState: function () {
        this.targetManager.updateAttributesPanelState(this);
      },

      renderExistingAttributes: function (element) {
        this.targetManager.renderExistingAttributes(this, element);
      },

      loadAttributeCommand: function (attr, mode, selectAll) {
        this.renderer.loadAttributeCommand(this.input, attr, mode, selectAll, this.hideError.bind(this));
      },

      loadTextCommand: function (command, selectStart, selectEnd) {
        this.renderer.loadTextCommand(this.input, command, selectStart, selectEnd, this.hideError.bind(this));
      },

      toggleSettingsPanel: function () {
        window.dispatchEvent(new CustomEvent('ve-toggle-settings'));
      },

      bindSettingsControls: function () {
        this.panelManager.bindSettingsControls(this.settingsPanel, this.settings, this.syncSettingsControls.bind(this));
      },

      syncSettingsControls: function () {
        this.panelManager.syncSettingsControls(this.settingsPanel, this.settings);
      },

      onPanelDragStart: function (event) {
        this.panelManager.startDrag(event, this.panel, this.settings);
      },

      matchesShortcut: function (event) {
        return this.matchesConfiguredShortcut(event);
      },

      updateTabHint: function () {
        this.inputManager.updateTabHint(this);
      },

      showError: function (message) {
        if (!this.error) return;
        this.error.textContent = message;
        this.error.classList.add('is-visible');
      },

      hideError: function () {
        if (!this.error) return;
        this.error.textContent = '';
        this.error.classList.remove('is-visible');
      },

      handleApplyFailure: function (applied, ops) {
        var failure = this.operationManager.getApplyFailure(applied, this.labels);
        if (!failure) return false;

        if (failure.refreshTarget) this.refreshTarget();

        if (failure.type === 'confirm-global-delete') {
          this.openConfirmDialog(ops);
          return true;
        }

        if (failure.type === 'confirm-bulk') {
          this.openBulkDialog(ops);
          return true;
        }

        if (failure.message) {
          this.showError(failure.message);
          this.toast.show(failure.message, 'error');
        }

        return true;
      },

      apply: function () {
        this.applyCommand();
      },

      applyCommand: function () {
        suspendElementSearchForBulk(this);
        var commandValue = this.input ? String(this.input.value || '') : '';
        if (!isBulkLikeCommandValue(commandValue) && this.adapter && !this.adapter.getSelectedElement()) {
          var selectMessage = 'Select an element before applying Direct mode commands. Use an all command for bulk changes.';
          this.showError(selectMessage);
          if (this.toast && typeof this.toast.show === 'function') this.toast.show(selectMessage, 'warning');
          return;
        }

        var result = this.parser.parse(commandValue);
        if (!result.ok) {
          this.showError(result.error);
          this.toast.show(result.error, 'error');
          return;
        }

        var ops = result.ops || result.attrs;
        var needsBulkDialog = this.bulk.needsConfirmation(ops);

        if (this.operationManager.needsGlobalDeleteDialog(ops)) {
          this.openConfirmDialog(ops);
          return;
        }

        if (needsBulkDialog) {
          if (this.settings && typeof this.settings.shouldSkipBulkPreview === 'function' && this.settings.shouldSkipBulkPreview()) {
            suspendElementSearchForBulk(this);
            ops = this.bulk.withConfirmedBulkOps(ops);
          } else {
            this.openBulkDialog(ops);
            return;
          }
        }

        this.applyOperations(ops);
      },

      applyOperations: function (ops) {
        var self = this;
        // Escape active Vue reactive context to prevent dependency tracking
        window.setTimeout(function () {
          var applied = self.adapter.applyAttributes(ops);
          if (!applied.ok && self.handleApplyFailure(applied, ops)) return;

          if (self.settings.isAutoClose()) self.closePanel();
          else {
            self.hideError();
            self.pageElementsCache = null;
            if (!(applied && applied.bulkCount)) self.refreshTarget();
            if (self.input) {
              self.input.value = '';
              self.input.focus();
            }
            if (self.commandSuggestionsManager) self.commandSuggestionsManager.clear(self);
            self.updateTabHint();
          }

          self.toast.show(self.operationManager.getApplySuccessMessage(ops, applied, self.labels));
        }, 0);
      }
    };

    return app;
  }

  window.MimamsBarAppController = { create: create };
})();
