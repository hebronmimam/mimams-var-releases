(function () {
  'use strict';

  function unique(list) {
    return (list || []).filter(Boolean).filter(function (item, index, items) {
      return items.indexOf(item) === index;
    });
  }

  function cloneConfirmedGlobalDeleteOps(ops) {
    return (ops || []).map(function (op) {
      if (!op || op.type !== 'delete-global-class') return op;
      var copy = {};
      Object.keys(op).forEach(function (key) { copy[key] = op[key]; });
      copy.confirmed = true;
      return copy;
    });
  }

  function getGlobalDeleteNames(ops) {
    var names = [];
    (ops || []).forEach(function (op) {
      if (op && op.type === 'delete-global-class') {
        names = names.concat(op.names || [op.name]);
      }
    });
    return unique(names);
  }

  function createGlobalDeleteDialog(owner) {
    var overlay = document.createElement('div');
    overlay.className = 'baqa-confirm';
    overlay.innerHTML = '' +
      '<div class="baqa-confirm-card" role="dialog" aria-modal="true" aria-label="Confirm global class delete">' +
        '<div class="baqa-confirm-title">Delete global classes?</div>' +
        '<div class="baqa-confirm-copy">This removes the class from Bricks global classes and detaches matching current-page references where possible.</div>' +
        '<div class="baqa-confirm-target"></div>' +
        '<label class="baqa-confirm-label">Type <strong>DELETE</strong> to enable delete</label>' +
        '<input class="baqa-confirm-input" type="text" autocomplete="off" spellcheck="false">' +
        '<div class="baqa-confirm-actions">' +
          '<button type="button" class="baqa-btn baqa-confirm-cancel">Cancel</button>' +
          '<button type="button" class="baqa-btn baqa-btn-danger baqa-confirm-delete" disabled>Delete</button>' +
        '</div>' +
      '</div>';

    document.body.appendChild(overlay);
    var input = overlay.querySelector('.baqa-confirm-input');
    var deleteButton = overlay.querySelector('.baqa-confirm-delete');

    overlay.querySelector('.baqa-confirm-cancel').addEventListener('click', function () { owner.closeConfirmDialog(); });
    deleteButton.addEventListener('click', function () { owner.confirmGlobalDelete(); });
    input.addEventListener('input', function () { deleteButton.disabled = input.value !== 'DELETE'; });
    input.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        event.preventDefault();
        owner.closeConfirmDialog();
      }
      if (event.key === 'Enter' && input.value === 'DELETE') {
        event.preventDefault();
        owner.confirmGlobalDelete();
      }
    });

    return { overlay: overlay, input: input };
  }

  function createBulkDialog(owner) {
    var overlay = document.createElement('div');
    overlay.className = 'baqa-confirm baqa-bulk-confirm';
    overlay.innerHTML = '' +
      '<div class="baqa-confirm-card baqa-bulk-card" role="dialog" aria-modal="true" aria-label="Confirm bulk apply">' +
        '<div class="baqa-bulk-top">' +
          '<div class="baqa-bulk-icon" aria-hidden="true">↯</div>' +
          '<div class="baqa-bulk-heading">' +
            '<div class="baqa-confirm-title">Bulk apply preview</div>' +
            '<div class="baqa-confirm-copy">Review exactly what will change before Mimam’s Bar applies it to matching Bricks elements.</div>' +
          '</div>' +
        '</div>' +
        '<div class="baqa-confirm-target baqa-bulk-target" aria-live="polite"></div>' +
        '<div class="baqa-bulk-note">Mimam’s Bar checks the matches safely after you confirm. Save in Bricks after applying.</div>' +
        '<div class="baqa-confirm-actions">' +
          '<button type="button" class="baqa-btn baqa-bulk-cancel">Cancel</button>' +
          '<button type="button" class="baqa-btn baqa-btn-primary baqa-bulk-apply">Apply to matching elements</button>' +
        '</div>' +
      '</div>';

    document.body.appendChild(overlay);
    overlay.querySelector('.baqa-bulk-cancel').addEventListener('click', function () { owner.closeBulkDialog(); });
    overlay.querySelector('.baqa-bulk-apply').addEventListener('click', function () { owner.confirmBulkApply(); });

    return { overlay: overlay };
  }

  function isOpen(overlay) {
    return !!(overlay && overlay.classList.contains('is-open'));
  }

  function clickInside(overlay, event, path) {
    if (!overlay) return false;
    return path ? path.indexOf(overlay) !== -1 : overlay.contains(event.target);
  }

  window.MimamsBarDialogs = {
    createGlobalDeleteDialog: createGlobalDeleteDialog,
    createBulkDialog: createBulkDialog,
    cloneConfirmedGlobalDeleteOps: cloneConfirmedGlobalDeleteOps,
    getGlobalDeleteNames: getGlobalDeleteNames,
    isOpen: isOpen,
    clickInside: clickInside
  };
})();
