(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarTargetManager) return;

  function refresh(app, options) {
    if (!app || !app.target) return;
    options = options || {};
    var element = app.adapter.getSelectedElement();
    var nextId = element && element.id ? String(element.id) : '';

    if (options.light && nextId === app._lastKnownTargetId) return;
    app._lastKnownTargetId = nextId;

    app.target.textContent = app.adapter.getElementLabel(element);
    app.target.setAttribute('title', app.adapter.getElementFullLabel(element));
    app.target.classList.toggle('is-empty', !element);
    renderIdentity(app, element);
    renderExistingAttributes(app, element);
  }

  function renderIdentity(app, element) {
    app.renderer.renderIdentity(app.identityList, element, app.adapter, {
      loadTextCommand: app.loadTextCommand.bind(app),
      deleteClass: function (className) {
        var parseResult = app.parser.parse('-' + className);
        if (parseResult.ok) {
          app.applyOperations(parseResult.ops || parseResult.attrs);
        }
      },
      renameClass: function (oldName, newName) {
        if (!newName || newName === oldName) return;
        var parseResult = app.parser.parse('.' + oldName + ' -> .' + newName);
        if (parseResult.ok) {
          app.applyOperations(parseResult.ops || parseResult.attrs);
        }
      },
      setId: function (newId) {
        if (!newId) return;
        var parseResult = app.parser.parse('#' + newId);
        if (parseResult.ok) {
          app.applyOperations(parseResult.ops || parseResult.attrs);
        }
      }
    });
  }

  function toggleAttributesPanel(app) {
    app.attrsExpanded = !app.attrsExpanded;
    updateAttributesPanelState(app);
  }

  function updateAttributesPanelState(app) {
    if (!app.existingBox) return;
    app.existingBox.classList.toggle('is-collapsed', !app.attrsExpanded);
    if (app.attrToggleLabel) app.attrToggleLabel.textContent = app.attrsExpanded ? 'Hide' : 'Show';
  }

  function renderExistingAttributes(app, element) {
    if (!app.attrList) return;

    var result = app.renderer.renderExistingAttributes({
      list: app.attrList,
      element: element,
      adapter: app.adapter,
      callbacks: {
        loadAttributeCommand: app.loadAttributeCommand.bind(app),
        deleteAttribute: function (attr) {
          var command = 'delete ' + attr.name;
          var parseResult = app.parser.parse(command);
          if (parseResult.ok) {
            app.applyOperations(parseResult.ops || parseResult.attrs);
          }
        },
        editAttribute: function (attr, newValue) {
          var esc = String(newValue == null ? '' : newValue).replace(/\\/g, '\\\\').replace(/"/g, '\\"');
          var command = attr.name + '="' + esc + '"';
          var parseResult = app.parser.parse(command);
          if (parseResult.ok) {
            app.applyOperations(parseResult.ops || parseResult.attrs);
          }
        }
      }
    });

    if (app.attrCount) app.attrCount.textContent = String((result && result.count) || 0);
    if (result && result.collapse) app.attrsExpanded = false;
    updateAttributesPanelState(app);
  }

  function scheduleRefresh(app) {
    if (!app) return;

    // v1.2.48: keep refreshes light while the bar is open. The old flow
    // scheduled three separate refresh passes for every canvas click, which
    // could stack up in Bricks and make the builder feel frozen.
    if (app._targetRefreshTimer) {
      window.clearTimeout(app._targetRefreshTimer);
    }

    app._targetRefreshTimer = window.setTimeout(function () {
      app._targetRefreshTimer = null;
      refresh(app, { light: true });
    }, 260);
  }

  window.MimamsBarTargetManager = {
    refresh: refresh,
    renderIdentity: renderIdentity,
    renderExistingAttributes: renderExistingAttributes,
    toggleAttributesPanel: toggleAttributesPanel,
    updateAttributesPanelState: updateAttributesPanelState,
    scheduleRefresh: scheduleRefresh
  };
})();
