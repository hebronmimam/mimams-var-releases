(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarAppShell) return;

  function create(labels) {
    labels = labels || {};
    var panel = document.createElement('div');
    panel.className = 'baqa-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', labels.title || "Mimam's Bar");
    panel.innerHTML = '' +
      '<div class="baqa-head">' +
        '<span class="baqa-mark">M</span>' +
        '<div class="baqa-title">' + (labels.title || "Mimam's Bar") + '</div>' +
        '<button type="button" class="baqa-close" aria-label="Close">×</button>' +
      '</div>' +
      '<div class="baqa-update-slot"></div>' +
      '<div class="baqa-body">' +
        '<div class="baqa-inputrow">' +
          '<div class="baqa-mode-dropdown">' +
            '<button type="button" class="baqa-mode-trigger" aria-haspopup="true" aria-expanded="false">' +
              '<span class="baqa-mode-trigger-icon" aria-hidden="true"><i class="ph-duotone ph-sliders-horizontal"></i></span>' +
              '<span class="baqa-mode-trigger-label">Direct</span>' +
              '<i class="ph-duotone ph-caret-down baqa-mode-caret" aria-hidden="true"></i>' +
            '</button>' +
            '<div class="baqa-mode-menu" role="menu" hidden>' +
              '<button type="button" class="baqa-scope-chip is-on" data-mode="default" role="menuitem"><span class="baqa-scope-icon" aria-hidden="true"><i class="ph-duotone ph-sliders-horizontal"></i></span><span>Direct</span><span class="baqa-scope-key">1</span></button>' +
              '<button type="button" class="baqa-scope-chip" data-mode="elements" role="menuitem"><span class="baqa-scope-icon" aria-hidden="true"><i class="ph-duotone ph-magnifying-glass"></i></span><span>Search page</span><span class="baqa-scope-key">2</span></button>' +
              '<button type="button" class="baqa-scope-chip" data-mode="add-elements" role="menuitem"><span class="baqa-scope-icon" aria-hidden="true"><i class="ph-duotone ph-plus"></i></span><span>Add element</span><span class="baqa-scope-key">3</span></button>' +
              '<span class="baqa-mode-label" hidden></span>' +
            '</div>' +
          '</div>' +
          '<span class="baqa-cmd-divider" aria-hidden="true"></span>' +
          '<div class="baqa-command-main">' +
            '<div class="baqa-existing" aria-live="polite"><button type="button" class="baqa-existing-toggle" hidden><span>Attributes</span><strong class="baqa-existing-count">0</strong><em>Show</em></button><div class="baqa-existing-meta" hidden></div><div class="baqa-identity-list"></div><div class="baqa-existing-list"><div class="baqa-existing-empty">No custom attributes on this element yet.</div></div></div>' +
            '<div class="baqa-field-wrap">' +
              '<div class="baqa-field-highlight" aria-hidden="true"></div>' +
              '<input class="baqa-field" type="text" autocomplete="off" spellcheck="false" placeholder="' + (labels.placeholder || 'data-anim=&quot;fade-up&quot;') + '">' +
            '</div>' +
            '<span class="baqa-target"><strong class="baqa-target-name">No element selected</strong></span>' +
          '</div>' +
        '</div>' +
        '<div class="baqa-results">' +
          '<div class="baqa-command-suggestions" hidden></div>' +
          '<div class="baqa-element-results" hidden></div>' +
        '</div>' +
        '<div class="baqa-tab-hint" aria-live="polite"></div>' +
        '<div class="baqa-error"></div>' +
      '</div>' +
      '<div class="baqa-foot">' +
        '<div class="baqa-hints"><span>↑↓ navigate</span><span>↵ apply</span><span>1·2·3 modes</span></div>' +
        '<div class="baqa-actions">' +
          '<button type="button" class="baqa-btn baqa-cancel">Close</button>' +
          '<button type="button" class="baqa-btn baqa-btn-primary baqa-apply">Apply</button>' +
        '</div>' +
      '</div>';

    document.body.appendChild(panel);
    return panel;
  }

  function refs(panel) {
    return {
      input: panel.querySelector('.baqa-field'),
      error: panel.querySelector('.baqa-error'),
      tabHint: panel.querySelector('.baqa-tab-hint'),
      target: panel.querySelector('.baqa-target-name'),
      attrList: panel.querySelector('.baqa-existing-list'),
      existingBox: panel.querySelector('.baqa-existing'),
      attrCount: panel.querySelector('.baqa-existing-count'),
      attrToggleLabel: panel.querySelector('.baqa-existing-toggle em'),
      identityList: panel.querySelector('.baqa-identity-list'),
      elementResults: panel.querySelector('.baqa-element-results'),
      commandSuggestions: panel.querySelector('.baqa-command-suggestions'),
      elementModeLabel: panel.querySelector('.baqa-mode-label'),
      scopeChips: panel.querySelectorAll('.baqa-scope-chip'),
      modeDropdown: panel.querySelector('.baqa-mode-dropdown'),
      modeTrigger: panel.querySelector('.baqa-mode-trigger'),
      modeTriggerLabel: panel.querySelector('.baqa-mode-trigger-label'),
      modeTriggerIcon: panel.querySelector('.baqa-mode-trigger-icon'),
      modeMenu: panel.querySelector('.baqa-mode-menu'),
      head: panel.querySelector('.baqa-head'),
      closeButton: panel.querySelector('.baqa-close'),
      cancelButton: panel.querySelector('.baqa-cancel'),
      applyButton: panel.querySelector('.baqa-apply'),
      attrsToggle: panel.querySelector('.baqa-existing-toggle')
    };
  }

  // ── Live token syntax highlighting for the command field ──────────────────
  // A read-only overlay mirrors the input text with color-coded tokens (#id,
  // .class, attr="value", operators, keywords). The input text is made
  // transparent while its caret stays visible, so nothing about the field's
  // behavior changes — this is purely presentational.
  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>]/g, function (char) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' })[char];
    });
  }

  function tokenizeCommand(value) {
    value = String(value == null ? '' : value);
    var re = /("(?:[^"\\]|\\.)*"?)|(=>|->)|(#[A-Za-z0-9_-]+)|(\.[A-Za-z0-9_-]+)|([+\-]\.?[A-Za-z0-9_-]+)|\b(all|delete)\b|([A-Za-z_][A-Za-z0-9_-]*)|(=)/g;
    var out = '';
    var last = 0;
    var match;
    while ((match = re.exec(value))) {
      if (match.index > last) out += escapeHtml(value.slice(last, match.index));
      var cls = 'baqa-tok-attr';
      if (match[1] != null) cls = 'baqa-tok-val';
      else if (match[2] != null) cls = 'baqa-tok-op';
      else if (match[3] != null) cls = 'baqa-tok-id';
      else if (match[4] != null) cls = 'baqa-tok-class';
      else if (match[5] != null) cls = 'baqa-tok-op';
      else if (match[6] != null) cls = 'baqa-tok-kw';
      else if (match[7] != null) cls = 'baqa-tok-attr';
      else if (match[8] != null) cls = 'baqa-tok-op';
      out += '<span class="' + cls + '">' + escapeHtml(match[0]) + '</span>';
      last = re.lastIndex;
      if (re.lastIndex === match.index) re.lastIndex++;
    }
    if (last < value.length) out += escapeHtml(value.slice(last));
    return out;
  }

  function highlightFor(input) {
    if (!input || !input.classList || !input.classList.contains('baqa-field')) return null;
    var wrap = input.closest ? input.closest('.baqa-field-wrap') : input.parentNode;
    return wrap ? wrap.querySelector('.baqa-field-highlight') : null;
  }

  function syncHighlight(input) {
    var hl = highlightFor(input);
    if (!hl) return;
    var value = input.value || '';
    hl.innerHTML = tokenizeCommand(value);
    hl.scrollLeft = input.scrollLeft;
    input.classList.toggle('is-highlighted', value.length > 0);
  }

  function scheduleSync(input) {
    syncHighlight(input);
    if (typeof requestAnimationFrame === 'function') {
      requestAnimationFrame(function () {
        var hl = highlightFor(input);
        if (hl) hl.scrollLeft = input.scrollLeft;
      });
    }
  }

  document.addEventListener('input', function (event) {
    if (event.target && event.target.classList && event.target.classList.contains('baqa-field')) scheduleSync(event.target);
  });
  ['keyup', 'click', 'scroll'].forEach(function (type) {
    document.addEventListener(type, function (event) {
      if (event.target && event.target.classList && event.target.classList.contains('baqa-field')) scheduleSync(event.target);
    }, true);
  });

  window.MimamsBarHighlight = { update: syncHighlight, tokenize: tokenizeCommand };

  window.MimamsBarAppShell = {
    create: create,
    refs: refs
  };
})();
