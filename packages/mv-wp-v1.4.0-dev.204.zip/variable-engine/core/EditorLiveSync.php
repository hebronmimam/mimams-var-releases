<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * C3, the owner: "build it." - two-way live sync between the WordPress editor
 * and Content Studio, no refresh.
 *
 * What travels is a SAVE, not keystrokes: when either side saves a post, the
 * other shows it. Tabs in the same browser hear it at once (BroadcastChannel);
 * anything else - another browser, another person - is found by a small check
 * of the post's modified time when the tab is focused and every 20 seconds.
 * Unsaved edits are never overwritten: the side with unsaved edits is told,
 * and chooses.
 *
 * This class puts the listening half into the block editor.
 */
class EditorLiveSync {

    public static function register(): void {
        add_action( 'enqueue_block_editor_assets', [ self::class, 'enqueue' ] );
    }

    public static function enqueue(): void {
        if ( ! current_user_can( 'edit_posts' ) ) {
            return;
        }
        $file = VE_DIR . 'assets/js/editor-live-sync.js';
        wp_enqueue_script(
            've-editor-live-sync',
            VE_URL . 'assets/js/editor-live-sync.js',
            [ 'wp-data', 'wp-api-fetch', 'wp-notices', 'wp-core-data', 'wp-editor', 'wp-blocks', 'wp-block-editor' ],
            VE_VERSION . '.' . ( file_exists( $file ) ? filemtime( $file ) : 0 ),
            true
        );
        wp_add_inline_script( 've-editor-live-sync', 'window.veEditorLiveSync=' . wp_json_encode( [ 'ns' => VE_API_NAMESPACE ] ) . ';', 'before' );
    }
}
