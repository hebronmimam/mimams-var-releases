(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarInputManager) return;


  function closeTransientPanels(app) {
    if (!app) return;
    var changed = false;
    if (app.settingsPanel && !app.settingsPanel.hidden) {
      app.settingsPanel.hidden = true;
      changed = true;
    }
    if (app.helpPanel && !app.helpPanel.hidden) {
      app.helpPanel.hidden = true;
      changed = true;
    }
    if (app.settingsToggle) app.settingsToggle.classList.remove('is-active');
    if (app.helpToggle) app.helpToggle.classList.remove('is-active');
    if (app.panel && changed) app.panel.classList.remove('is-settings-open', 'is-help-open');
  }

  function bind(app) {
    if (!app || !app.input) return;

    app.input.addEventListener('keydown', function (event) {
      if (app.handleModeKeys(event)) {
        window.setTimeout(function () { app.updateTabHint(); }, 0);
        return;
      }

      if (handleHelpMode(app, event)) {
        return;
      }

      if (event.key && event.key.length === 1 && !event.ctrlKey && !event.metaKey && !event.altKey) closeTransientPanels(app);

      if (app.mode === 'elements' || app.mode === 'add-elements') {
        if (app.mode === 'add-elements' && event.key === 'Tab' && !event.shiftKey && !event.ctrlKey && !event.metaKey && !event.altKey) {
          if (completeFromHighlightedElementSuggestion(app) || completeEmmetAlias(app)) {
            event.preventDefault();
            window.setTimeout(function () {
              if (typeof app.requestRenderElementResults === 'function') app.requestRenderElementResults(620);
              else if (typeof app.renderElementResults === 'function') app.renderElementResults();
              app.updateTabHint();
            }, 0);
            return;
          }
        }
        if (event.key === 'ArrowDown') {
          event.preventDefault();
          if (typeof app.moveElementResult === 'function') app.moveElementResult(1);
          return;
        }
        if (event.key === 'ArrowUp') {
          event.preventDefault();
          if (typeof app.moveElementResult === 'function') app.moveElementResult(-1);
          return;
        }
        if (event.key === 'Enter') {
          event.preventDefault();
          if (typeof app.selectActiveElementResult === 'function') app.selectActiveElementResult();
          else app.selectFirstElementResult();
          return;
        }
        window.setTimeout(function () { app.updateTabHint(); }, 0);
        return;
      }

      if (handleCommandSuggestionNavigation(app, event)) {
        window.setTimeout(function () { app.updateTabHint(); }, 0);
        return;
      }

      if (handleCommandSuggestions(app, event)) {
        requestCommandSuggestions(app, 720);
        return;
      }

      if (handleFieldAssist(app, event)) {
        requestCommandSuggestions(app, 720);
        return;
      }

      if (event.key === 'Enter') {
        event.preventDefault();
        app.apply();
        requestCommandSuggestions(app, 720);
        return;
      }

      requestCommandSuggestions(app, 720);
    });

    app.input.addEventListener('input', function () {
      closeTransientPanels(app);
      app.activeCommandSuggestionIndex = 0;
      if (app.mode === 'default') {
        requestCommandSuggestions(app, 760);
      }
      if (app.mode === 'elements' || app.mode === 'add-elements') {
        app.activeElementResultIndex = 0;
        app.pendingAddElementName = '';
        if (typeof app.requestRenderElementResults === 'function') app.requestRenderElementResults(760);
        else app.renderElementResults();
      }
      if (typeof app.updateTabHint === 'function') app.updateTabHint();
    });
    function requestTabHint() {
      if (app._tabHintTimer) window.clearTimeout(app._tabHintTimer);
      app._tabHintTimer = window.setTimeout(function () {
        app._tabHintTimer = null;
        if (typeof app.updateTabHint === 'function') app.updateTabHint();
      }, 120);
    }
    app.input.addEventListener('keyup', requestTabHint);
    app.input.addEventListener('click', requestTabHint);
    app.input.addEventListener('mouseup', requestTabHint);
    app.input.addEventListener('focus', requestTabHint);
  }



  function handleHelpMode(app, event) {
    if (!app || !app.input || !event) return false;
    if (event.ctrlKey || event.metaKey || event.altKey || event.shiftKey) return false;
    var value = String(app.input.value || '').trim().toLowerCase();

    if (event.key === '?' && !value) {
      event.preventDefault();
      if (typeof app.toggleHelpPanel === 'function') app.toggleHelpPanel();
      return true;
    }

    if (event.key === 'Enter' && (value === '?' || value === 'help')) {
      event.preventDefault();
      app.input.value = '';
      if (typeof app.toggleHelpPanel === 'function') app.toggleHelpPanel();
      if (typeof app.updateTabHint === 'function') app.updateTabHint();
      return true;
    }

    return false;
  }

  function renderCommandSuggestions(app) {
    if (app && app.commandSuggestionsManager && app.mode === 'default') {
      app.commandSuggestionsManager.render(app);
    } else if (app && app.commandSuggestionsManager) {
      app.commandSuggestionsManager.clear(app);
    }
  }

  function requestCommandSuggestions(app, delay) {
    if (!app) return;
    delay = typeof delay === 'number' ? delay : 130;
    if (app._commandSuggestionTimer) window.clearTimeout(app._commandSuggestionTimer);
    app._commandSuggestionTimer = window.setTimeout(function () {
      app._commandSuggestionTimer = null;
      renderCommandSuggestions(app);
      if (typeof app.updateTabHint === 'function') app.updateTabHint();
    }, delay);
  }

  function handleCommandSuggestionNavigation(app, event) {
    if (!app || !app.commandSuggestionsManager || app.mode !== 'default') return false;
    if (event.ctrlKey || event.metaKey || event.altKey || event.shiftKey) return false;
    if (event.key !== 'ArrowDown' && event.key !== 'ArrowUp') return false;

    app.commandSuggestionsManager.render(app);
    if (!app.commandSuggestionsManager.hasSuggestions(app)) return false;

    event.preventDefault();
    app.commandSuggestionsManager.move(app, event.key === 'ArrowDown' ? 1 : -1);
    return true;
  }

  function handleCommandSuggestions(app, event) {
    if (!app || !app.commandSuggestionsManager || app.mode !== 'default') return false;
    var key = event && event.key;
    var canAccept = key === 'Tab' || key === 'Enter';
    if (!canAccept || event.shiftKey || event.ctrlKey || event.metaKey || event.altKey) return false;

    app.commandSuggestionsManager.render(app);
    if (!app.commandSuggestionsManager.hasSuggestions(app)) return false;

    event.preventDefault();
    app.commandSuggestionsManager.accept(app);
    return true;
  }

  function handleFieldAssist(app, event) {
    if (!app.input) return false;

    if (event.ctrlKey || event.metaKey || event.altKey) return false;

    if (event.key === 'Tab' && !event.shiftKey && app.fieldAssist.completeDeleteCommand(app.input)) {
      event.preventDefault();
      return true;
    }

    if (event.key === '=') {
      event.preventDefault();
      app.fieldAssist.insertAtSelection(app.input, '=""', 2);
      return true;
    }

    if (event.key === 'Tab') {
      event.preventDefault();
      if (event.shiftKey) {
        app.fieldAssist.jumpBackIntoPreviousQuotedValue(app.input);
      } else {
        app.fieldAssist.jumpOutOfQuotesForNextAttribute(app.input);
      }
      return true;
    }

    return false;
  }




  function getLastElementTokenRange(value, caret) {
    value = String(value || '');
    caret = typeof caret === 'number' ? caret : value.length;
    if (caret < 0) caret = 0;
    if (caret > value.length) caret = value.length;

    var start = caret;
    while (start > 0 && !/[>+\s]/.test(value.charAt(start - 1))) start--;

    var end = caret;
    while (end < value.length && !/[>+\s]/.test(value.charAt(end))) end++;

    return { start: start, end: end, token: value.slice(start, end) };
  }

  function completeFromHighlightedElementSuggestion(app) {
    if (!app || !app.input || app.mode !== 'add-elements') return false;

    var matches = typeof app.refreshElementMatchesNow === 'function'
      ? app.refreshElementMatchesNow()
      : (app.latestElementMatches || []);

    if (!matches || !matches.length) return false;
    var index = app.activeElementResultIndex;
    if (index < 0 || index >= matches.length) index = 0;
    var item = matches[index] || {};
    var config = item.config || {};
    var name = String(config.name || '').trim();
    if (!name || name === '__emmet__') return false;

    var input = app.input;
    var current = String(input.value || '');
    var caret = typeof input.selectionStart === 'number' ? input.selectionStart : current.length;
    var range = getLastElementTokenRange(current, caret);
    if (!range.token && current.trim()) return false;

    var nextValue = current.slice(0, range.start) + name + current.slice(range.end);
    var nextCaret = range.start + name.length;
    if (nextValue === current) return false;

    input.value = nextValue;
    try { input.setSelectionRange(nextCaret, nextCaret); } catch (e) {}
    app.pendingAddElementName = '';
    return true;
  }

  function canCompleteEmmetAlias(app) {
    if (!app || !app.input) return false;
    if (app.mode === 'add-elements') {
      var matches = app.latestElementMatches || [];
      if (matches.length) {
        var index = app.activeElementResultIndex;
        if (index < 0 || index >= matches.length) index = 0;
        var item = matches[index] || {};
        var cfg = item.config || {};
        var name = String(cfg.name || '').trim();
        if (name && name !== '__emmet__') {
          var currentValue = String(app.input.value || '');
          var caretPos = typeof app.input.selectionStart === 'number' ? app.input.selectionStart : currentValue.length;
          var range = getLastElementTokenRange(currentValue, caretPos);
          if (range.token && name !== range.token) return true;
        }
      }
    }
    var emmet = app.emmet || window.MimamsBarEmmet;
    if (!emmet || typeof emmet.completeAt !== 'function') return false;
    var current = String(app.input.value || '');
    var caret = typeof app.input.selectionStart === 'number' ? app.input.selectionStart : current.length;
    var result = emmet.completeAt(current, caret);
    return !!(result && result.changed);
  }

  function completeEmmetAlias(app) {
    if (!app || !app.input) return false;
    var emmet = app.emmet || window.MimamsBarEmmet;
    if (!emmet || typeof emmet.completeAt !== 'function') return false;

    var input = app.input;
    var current = String(input.value || '');
    var caret = typeof input.selectionStart === 'number' ? input.selectionStart : current.length;
    var result = emmet.completeAt(current, caret);
    if (!result || !result.changed) return false;

    input.value = result.value;
    try {
      input.setSelectionRange(result.caret, result.caret);
    } catch (e) {}
    app.pendingAddElementName = '';
    return true;
}

  function updateTabHint(app) {
    if (!app.tabHint || !app.input) return;
    var message = '';
    if (app.commandSuggestionsManager && app.commandSuggestionsManager.hasSuggestions(app)) {
      message = 'Tab / Enter → use suggestion';
    } else if (app.mode === 'add-elements' && canCompleteEmmetAlias(app)) {
      message = 'Tab → complete Emmet token';
    } else {
      message = app.fieldAssist.getTabAssistMessage(app.input, app.mode);
    }
    app.tabHint.textContent = message;
    app.tabHint.classList.toggle('is-visible', !!message);
  }

  window.MimamsBarInputManager = {
    bind: bind,
    handleFieldAssist: handleFieldAssist,
    renderCommandSuggestions: renderCommandSuggestions,
    requestCommandSuggestions: requestCommandSuggestions,
    handleCommandSuggestions: handleCommandSuggestions,
    handleCommandSuggestionNavigation: handleCommandSuggestionNavigation,
    handleHelpMode: handleHelpMode,
    completeFromHighlightedElementSuggestion: completeFromHighlightedElementSuggestion,
    completeEmmetAlias: completeEmmetAlias,
    canCompleteEmmetAlias: canCompleteEmmetAlias,
    updateTabHint: updateTabHint
  };
})();
