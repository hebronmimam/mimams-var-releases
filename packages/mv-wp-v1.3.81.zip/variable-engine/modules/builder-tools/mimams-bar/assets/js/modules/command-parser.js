(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;

  var Core = window.MimamsBarCore || {};
  var labels = Core.labels || {};

  var Parser = {
    isNameStart: function (char) {
      return /[A-Za-z_:@]/.test(char || '');
    },
    isNameChar: function (char) {
      return /[A-Za-z0-9_:\-@.]/.test(char || '');
    },
    parse: function (input) {
      var source = String(input || '').trim();
      var index = 0;
      var length = source.length;
      var operations = [];

      function skipSpaces() {
        while (index < length && /\s/.test(source[index])) index++;
      }

      function fail(message) {
        return { ok: false, error: message || labels.invalid || 'Invalid attribute syntax.' };
      }

      function parseTokenUntilSpaceOrArrow() {
        var start = index;
        while (index < length && !/\s/.test(source[index])) {
          if (source.slice(index, index + 2) === '->') break;
          index++;
        }
        return source.slice(start, index);
      }

      function normalizeClassName(value) {
        return String(value || '').replace(/^\./, '').trim();
      }

      function normalizeIdValue(value) {
        return String(value || '').replace(/^#/, '').trim();
      }

      function parseBulkCommand() {
        var arrowIndex = source.indexOf('=>');
        if (arrowIndex < 0) return null;

        var left = source.slice(0, arrowIndex).trim();
        var right = source.slice(arrowIndex + 2).trim();
        if (!left || !right) return fail('Bulk command needs a target and a command. Example: all h2 => data-anim="text-lines"');

        var target = null;
        var match = null;

        if (/^all\s+/i.test(left)) {
          target = { mode: 'tag', value: left.replace(/^all\s+/i, '').trim().toLowerCase() };
        } else if ((match = left.match(/^tag\s*:\s*([a-z0-9_-]+)$/i))) {
          target = { mode: 'tag', value: match[1].toLowerCase() };
        } else if ((match = left.match(/^class\s*:\s*\.?([a-z0-9_-]+)$/i))) {
          target = { mode: 'class', value: match[1] };
        } else if ((match = left.match(/^type\s*:\s*([a-z0-9_-]+)$/i))) {
          target = { mode: 'type', value: match[1].toLowerCase() };
        } else if (left.charAt(0) === '.') {
          target = { mode: 'class', value: left.slice(1).trim() };
        } else if (left.charAt(0) === '#') {
          target = { mode: 'id', value: left.slice(1).trim() };
        }

        if (!target || !target.value) {
          return fail('Unsupported bulk target. Use all h2, all figure, tag:h2, .class-name, class:name, or #id.');
        }

        var parsed = Parser.parse(right);
        if (!parsed.ok) return fail(parsed.error);
        var innerOps = parsed.ops || parsed.attrs || [];
        if (!innerOps.length) return fail('Bulk command has nothing to apply.');

        if (innerOps.some(function (op) { return op && op.type === 'bulk-apply'; })) {
          return fail('Nested bulk commands are not supported.');
        }

        if (innerOps.some(function (op) { return op && op.type === 'delete-global-class'; })) {
          return fail('Global class delete is not allowed inside bulk mode.');
        }

        return { ok: true, op: { type: 'bulk-apply', target: target, ops: innerOps, confirmed: false } };
      }

      function parseDeleteCommand() {
        skipSpaces();
        if (source.slice(index, index + 6).toLowerCase() !== 'delete') return null;

        var afterKeyword = source.charAt(index + 6);
        if (afterKeyword && !/\s/.test(afterKeyword)) return null;

        index += 6;
        skipSpaces();

        var explicitGlobal = false;
        var explicitAttr = false;

        if (source.slice(index, index + 6).toLowerCase() === 'global') {
          explicitGlobal = true;
          index += 6;
          skipSpaces();
        }

        if (source.slice(index, index + 5).toLowerCase() === 'class') {
          explicitGlobal = true;
          index += 5;
          skipSpaces();
        }

        if (source.slice(index, index + 4).toLowerCase() === 'attr') {
          explicitAttr = true;
          index += 4;
          skipSpaces();
        } else if (source.slice(index, index + 9).toLowerCase() === 'attribute') {
          explicitAttr = true;
          index += 9;
          skipSpaces();
        }

        var classNames = [];
        var attrNames = [];

        while (index < length) {
          skipSpaces();
          if (index >= length) break;

          var raw = parseTokenUntilSpaceOrArrow().replace(/,+$/g, '');
          if (!raw) break;

          // Allow users to delete from a clicked/loaded attribute command such as:
          // delete data-anim="fade-up". Only the attribute label matters for delete.
          var deleteName = raw;
          var equalsIndex = deleteName.indexOf('=');
          if (equalsIndex > -1) {
            deleteName = deleteName.slice(0, equalsIndex);
          }
          deleteName = deleteName.replace(/^['"]|['"]$/g, '').trim();

          if (explicitGlobal || deleteName.charAt(0) === '.') {
            var className = normalizeClassName(deleteName);
            if (!className) return fail('Missing global class name to delete.');
            if (classNames.indexOf(className) === -1) classNames.push(className);
          } else {
            var attrName = deleteName.trim();
            if (!explicitAttr && attrName.charAt(0) === '#') {
              return fail('Use #id-name to set an ID. ID delete is not supported yet.');
            }
            if (!attrName) return fail('Missing attribute name to delete.');
            if (attrNames.indexOf(attrName) === -1) attrNames.push(attrName);
          }

          skipSpaces();
        }

        if (!classNames.length && !attrNames.length) return fail('Missing name to delete.');

        if (classNames.length && attrNames.length) {
          return { ok: true, ops: [
            { type: 'delete-attribute', names: attrNames },
            { type: 'delete-global-class', name: classNames[0], names: classNames, confirmed: false }
          ] };
        }

        if (classNames.length) {
          return { ok: true, op: { type: 'delete-global-class', name: classNames[0], names: classNames, confirmed: false } };
        }

        return { ok: true, op: { type: 'delete-attribute', names: attrNames } };
      }

      function parseQuickClassOrIdCommand() {
        skipSpaces();
        var prefix = source[index];
        if (prefix !== '#' && prefix !== '.' && prefix !== '+' && prefix !== '-') return null;

        index++;
        var raw = parseTokenUntilSpaceOrArrow();
        var name = prefix === '#' ? normalizeIdValue(raw) : normalizeClassName(raw);

        if (!name) {
          return fail(prefix === '#' ? 'Missing CSS ID value.' : 'Missing class name.');
        }

        skipSpaces();

        if (source.slice(index, index + 2) === '->') {
          index += 2;
          skipSpaces();
          var nextPrefix = source[index];
          if ((prefix === '#' && nextPrefix === '#') || (prefix !== '#' && nextPrefix === '.')) {
            index++;
          }
          var rawTarget = parseTokenUntilSpaceOrArrow();
          var target = prefix === '#' ? normalizeIdValue(rawTarget) : normalizeClassName(rawTarget);

          if (!target) {
            return fail(prefix === '#' ? 'Missing new CSS ID value.' : 'Missing new class name.');
          }

          if (prefix === '#') {
            return { ok: true, op: { type: 'set-id', value: target } };
          }

          return { ok: true, op: { type: 'rename-class', from: name, to: target } };
        }

        if (prefix === '#') {
          return { ok: true, op: { type: 'set-id', value: name } };
        }

        if (prefix === '-') {
          return { ok: true, op: { type: 'remove-class', name: name } };
        }

        return { ok: true, op: { type: 'add-class', name: name } };
      }

      function parseName(label) {
        skipSpaces();

        if (index >= length) {
          return { ok: false, error: 'Missing ' + (label || 'attribute name') + '.' };
        }

        var nameStart = index;
        if (!Parser.isNameStart(source[index])) {
          return { ok: false, error: 'Attribute names must start with a letter, underscore, colon, or @.' };
        }

        index++;
        while (index < length && Parser.isNameChar(source[index])) index++;

        return { ok: true, name: source.slice(nameStart, index) };
      }

      function parseValue(name) {
        skipSpaces();

        if (source[index] !== '=') {
          return { ok: true, hasValue: false, value: '' };
        }

        index++;
        skipSpaces();

        if (index >= length) {
          return { ok: false, error: 'Missing value for ' + name + '.' };
        }

        var quote = source[index];
        var value = '';

        if (quote === '"' || quote === "'") {
          index++;
          var buffer = '';
          var closed = false;

          while (index < length) {
            var char = source[index];
            if (char === '\\' && index + 1 < length) {
              buffer += source[index + 1];
              index += 2;
              continue;
            }
            if (char === quote) {
              closed = true;
              index++;
              break;
            }
            buffer += char;
            index++;
          }

          if (!closed) return { ok: false, error: 'Missing closing quote for ' + name + '.' };
          value = buffer;
        } else {
          var unquotedStart = index;
          while (index < length && !/\s/.test(source[index])) index++;
          value = source.slice(unquotedStart, index);
          if (!value) return { ok: false, error: 'Missing value for ' + name + '.' };
          if (/["'=<>`]/.test(value)) return { ok: false, error: 'Invalid unquoted value for ' + name + '. Use quotes.' };
        }

        return { ok: true, hasValue: true, value: value };
      }

      while (index < length) {
        skipSpaces();
        if (index >= length) break;

        var bulkCommand = parseBulkCommand();
        if (bulkCommand) {
          if (!bulkCommand.ok) return fail(bulkCommand.error);
          operations.push(bulkCommand.op);
          skipSpaces();
          continue;
        }

        var deleteCommand = parseDeleteCommand();
        if (deleteCommand) {
          if (!deleteCommand.ok) return fail(deleteCommand.error);
          if (deleteCommand.ops) {
            operations = operations.concat(deleteCommand.ops);
          } else {
            operations.push(deleteCommand.op);
          }
          skipSpaces();
          continue;
        }

        var quickCommand = parseQuickClassOrIdCommand();
        if (quickCommand) {
          if (!quickCommand.ok) return fail(quickCommand.error);
          operations.push(quickCommand.op);
          skipSpaces();
          continue;
        }

        var sourceName = parseName('attribute name');
        if (!sourceName.ok) return fail(sourceName.error);

        skipSpaces();

        if (source.slice(index, index + 2) === '->') {
          index += 2;
          skipSpaces();

          var targetName = parseName('new attribute name');
          if (!targetName.ok) return fail(targetName.error);

          var targetValue = parseValue(targetName.name);
          if (!targetValue.ok) return fail(targetValue.error);

          operations.push({
            type: 'rename',
            from: sourceName.name,
            to: targetName.name,
            hasValue: targetValue.hasValue,
            value: targetValue.value
          });
        } else {
          var attrValue = parseValue(sourceName.name);
          if (!attrValue.ok) return fail(attrValue.error);

          operations.push({
            type: 'set',
            name: sourceName.name,
            value: attrValue.hasValue ? attrValue.value : ''
          });
        }

        skipSpaces();
      }

      if (!operations.length) return fail('Type at least one attribute.');

      return { ok: true, ops: operations, attrs: operations.filter(function (op) { return op.type === 'set'; }) };
    }
  };


  window.MimamsBarParser = Parser;
})();
