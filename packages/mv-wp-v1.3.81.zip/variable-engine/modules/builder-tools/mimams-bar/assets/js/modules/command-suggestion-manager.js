(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarCommandSuggestions) return;

  function escapeHtml(value) {
    return String(value == null ? '' : value).replace(/[&<>"']/g, function (char) {
      return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' })[char];
    });
  }

  function unique(values) {
    var out = [];
    (values || []).forEach(function (value) {
      value = String(value || '').trim();
      if (value && out.indexOf(value) === -1) out.push(value);
    });
    return out;
  }

  function scoreByPrefix(value, query) {
    value = String(value || '').toLowerCase();
    query = String(query || '').toLowerCase();
    if (!query) return 1;
    if (value === query) return 100;
    if (value.indexOf(query) === 0) return 80 - value.length;
    if (value.indexOf(query) !== -1) return 40 - value.length;
    return -1;
  }

  function sortMatches(items, query) {
    return items.map(function (item) {
      item._score = scoreByPrefix(item.key || item.label || item.command, query);
      return item;
    }).filter(function (item) {
      return item._score >= 0;
    }).sort(function (a, b) {
      return b._score - a._score || String(a.label).localeCompare(String(b.label));
    });
  }

  function getElement(app) {
    return app && app.adapter && typeof app.adapter.getSelectedElement === 'function'
      ? app.adapter.getSelectedElement()
      : null;
  }

  function getClasses(app, element) {
    if (!app || !app.adapter || !element) return [];
    return unique(app.adapter.getElementClasses(element));
  }

  function getAttributes(app, element) {
    if (!app || !app.adapter || !element) return [];
    return (app.adapter.getElementAttributes(element) || []).filter(function (attr) {
      return attr && attr.name;
    });
  }

  function buildRemoveClassSuggestions(app, value) {
    var match = String(value || '').match(/^\s*-\.?([^\s]*)$/);
    if (!match) return [];

    var element = getElement(app);
    if (!element) return [];

    var query = match[1] || '';
    return sortMatches(getClasses(app, element).map(function (name) {
      return {
        type: 'remove-class',
        key: name,
        label: '-' + name,
        detail: 'remove .' + name + ' from selected element',
        command: '-' + name
      };
    }), query).slice(0, 6);
  }

  function buildDeleteSuggestions(app, value) {
    var raw = String(value || '');
    var match = raw.match(/^\s*delete(?:\s+(.+))?$/i);
    if (!match) return [];

    var element = getElement(app);
    if (!element) return [];

    var remainder = String(match[1] || '');
    var tokens = remainder.split(/\s+/).filter(Boolean);
    var last = tokens.length ? tokens[tokens.length - 1] : '';
    var prefix = last;
    var isClassDelete = prefix.charAt(0) === '.';
    var query = isClassDelete ? prefix.slice(1) : prefix;

    var suggestions = [];

    if (isClassDelete) {
      suggestions = sortMatches(getClasses(app, element).map(function (name) {
        return {
          type: 'delete-global-class',
          key: name,
          label: 'delete .' + name,
          detail: 'open guarded global class cleanup dialog',
          command: 'delete .' + name
        };
      }), query);
    } else {
      suggestions = sortMatches(getAttributes(app, element).map(function (attr) {
        return {
          type: 'delete-attribute',
          key: attr.name,
          label: 'delete ' + attr.name,
          detail: attr.value === '' ? 'remove boolean/empty attribute' : 'remove attribute currently set to “' + attr.value + '”',
          command: 'delete ' + attr.name
        };
      }), query);
    }

    return suggestions.slice(0, 6);
  }

  function getSuggestions(app) {
    if (!app || app.mode !== 'default' || !app.input) return [];
    var value = String(app.input.value || '');
    if (!value.trim()) return [];

    if (app.mvIntegration && typeof app.mvIntegration.getSuggestions === 'function') {
      var mvSuggestions = app.mvIntegration.getSuggestions(app, value);
      if (mvSuggestions && mvSuggestions.length) return mvSuggestions;
    }

    var removeSuggestions = buildRemoveClassSuggestions(app, value);
    if (removeSuggestions.length) return removeSuggestions;

    var deleteSuggestions = buildDeleteSuggestions(app, value);
    if (deleteSuggestions.length) return deleteSuggestions;

    return [];
  }

  function render(app) {
    var container = app && app.commandSuggestions;
    if (!container) return [];

    var suggestions = getSuggestions(app);
    container.innerHTML = '';

    if (!suggestions.length) {
      container.hidden = true;
      app.activeCommandSuggestions = [];
      return suggestions;
    }

    if (typeof app.activeCommandSuggestionIndex !== 'number') app.activeCommandSuggestionIndex = 0;
    if (app.activeCommandSuggestionIndex < 0) app.activeCommandSuggestionIndex = 0;
    if (app.activeCommandSuggestionIndex >= suggestions.length) app.activeCommandSuggestionIndex = suggestions.length - 1;

    suggestions.forEach(function (item, index) {
      var button = document.createElement('button');
      button.type = 'button';
      button.className = 'baqa-command-suggestion' + (index === app.activeCommandSuggestionIndex ? ' is-active' : '');
      button.setAttribute('data-type', item.type || '');
      button.innerHTML = '<span>' + escapeHtml(item.label) + '</span><em>' + escapeHtml(item.detail) + '</em>';
      button.addEventListener('mouseenter', function () {
        app.activeCommandSuggestionIndex = index;
        render(app);
      });
      button.addEventListener('click', function (event) {
        event.preventDefault();
        app.activeCommandSuggestionIndex = index;
        accept(app, item);
      });
      container.appendChild(button);
    });

    container.hidden = false;
    app.activeCommandSuggestions = suggestions;
    return suggestions;
  }

  function clear(app) {
    if (!app) return;
    app.activeCommandSuggestions = [];
    app.activeCommandSuggestionIndex = 0;
    if (app.commandSuggestions) {
      app.commandSuggestions.hidden = true;
      app.commandSuggestions.innerHTML = '';
    }
  }

  function accept(app, item) {
    item = item || (app && app.activeCommandSuggestions && app.activeCommandSuggestions[typeof app.activeCommandSuggestionIndex === 'number' ? app.activeCommandSuggestionIndex : 0]) || (app && app.activeCommandSuggestions && app.activeCommandSuggestions[0]);
    if (!app || !app.input || !item || !item.command) return false;
    var value = item.nextValue || item.command;
    var caret = typeof item.caret === 'number' ? item.caret : value.length;
    app.input.value = value;
    app.input.focus();
    try { app.input.setSelectionRange(caret, caret); } catch (e) { app.input.setSelectionRange(value.length, value.length); }
    clear(app);
    if (typeof app.updateTabHint === 'function') app.updateTabHint();
    return true;
  }

  function move(app, delta) {
    if (!app) return false;
    var list = app.activeCommandSuggestions || render(app) || [];
    if (!list.length) return false;
    var index = typeof app.activeCommandSuggestionIndex === 'number' ? app.activeCommandSuggestionIndex : 0;
    index += delta;
    if (index < 0) index = list.length - 1;
    if (index >= list.length) index = 0;
    app.activeCommandSuggestionIndex = index;
    render(app);
    return true;
  }

  function hasSuggestions(app) {
    return !!(app && app.activeCommandSuggestions && app.activeCommandSuggestions.length);
  }

  var CommandSuggestions = {
    getSuggestions: getSuggestions,
    render: render,
    clear: clear,
    accept: accept,
    move: move,
    hasSuggestions: hasSuggestions
  };

  window.MimamsBarCommandSuggestions = CommandSuggestions;
  window.MimamsBar = window.MimamsBar || {};
  window.MimamsBar.CommandSuggestions = CommandSuggestions;
})();
