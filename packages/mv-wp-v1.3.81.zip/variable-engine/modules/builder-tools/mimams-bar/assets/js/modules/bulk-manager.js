(function () {
  'use strict';

  var Core = window.MimamsBarCore || {};
  var MAX_BULK_TARGETS = Core.MAX_BULK_TARGETS || 40;

  function isBulkOp(op) {
    return !!(op && op.type === 'bulk-apply');
  }

  function needsConfirmation(ops) {
    return (ops || []).some(function (op) {
      return isBulkOp(op) && !op.confirmed;
    });
  }

  function cloneOp(op) {
    var copy = {};
    Object.keys(op || {}).forEach(function (key) { copy[key] = op[key]; });
    return copy;
  }

  function withConfirmedBulkOps(ops) {
    return (ops || []).map(function (op) {
      if (!isBulkOp(op)) return op;
      var copy = cloneOp(op);
      copy.confirmed = true;
      return copy;
    });
  }

  function buildSummaries(ops, adapter, maxTargets) {
    var summaries = [];
    var blocked = false;
    var limit = maxTargets || MAX_BULK_TARGETS;

    (ops || []).forEach(function (op) {
      if (!isBulkOp(op)) return;
      var targets = adapter.findBulkTargets(op.target);
      var count = targets.length;
      var text = adapter.describeBulkTarget(op.target) + ' · ' + count + ' match' + (count === 1 ? '' : 'es');
      if (count > limit) {
        blocked = true;
        text += ' · too broad, max ' + limit;
      }
      summaries.push(text);
    });

    return {
      blocked: blocked,
      summaries: summaries,
      text: summaries.join('  |  ')
    };
  }

  window.MimamsBarBulk = {
    isBulkOp: isBulkOp,
    needsConfirmation: needsConfirmation,
    withConfirmedBulkOps: withConfirmedBulkOps,
    buildSummaries: buildSummaries
  };
})();
