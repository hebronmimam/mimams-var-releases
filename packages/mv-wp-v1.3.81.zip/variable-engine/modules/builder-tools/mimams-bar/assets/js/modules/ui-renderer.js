(function () {
  'use strict';

  if (window.MimamsBarUIRenderer) return;

  function escapeCommandValue(value) {
    return String(value == null ? '' : value)
      .replace(/\\/g, '\\\\')
      .replace(/"/g, '\\"');
  }

  function attributeToSetCommand(attr) {
    if (!attr || !attr.name) return '';
    if (attr.value === '') return attr.name;
    return attr.name + '="' + escapeCommandValue(attr.value) + '"';
  }

  function attributeToRenameCommand(attr) {
    if (!attr || !attr.name) return '';
    return attr.name + ' -> ' + attr.name;
  }

  function loadTextCommand(input, command, selectStart, selectEnd, hideError) {
    if (!input) return;
    input.value = command || '';
    if (typeof hideError === 'function') hideError();
    input.focus();
    if (typeof selectStart === 'number' && typeof selectEnd === 'number') {
      input.setSelectionRange(selectStart, selectEnd);
    } else {
      input.setSelectionRange(input.value.length, input.value.length);
    }
  }

  function loadAttributeCommand(input, attr, mode, selectAll, hideError) {
    if (!input || !attr) return;

    var command = mode === 'rename'
      ? attributeToRenameCommand(attr)
      : attributeToSetCommand(attr);

    input.value = command;
    if (typeof hideError === 'function') hideError();
    input.focus();

    if (selectAll) {
      input.setSelectionRange(0, input.value.length);
      return;
    }

    if (mode === 'rename') {
      var arrowIndex = command.indexOf('->');
      var start = arrowIndex >= 0 ? arrowIndex + 3 : command.length;
      input.setSelectionRange(start, command.length);
      return;
    }

    if (attr.value !== '') {
      var closingQuote = command.length - 1;
      input.setSelectionRange(closingQuote, closingQuote);
      return;
    }

    input.setSelectionRange(command.length, command.length);
  }

  function renderIdentity(container, element, adapter, callbacks) {
    if (!container || !adapter) return;
    callbacks = callbacks || {};
    container.textContent = '';

    if (!element) {
      var none = document.createElement('div');
      none.className = 'baqa-existing-empty';
      none.textContent = 'Select an element to view ID and classes.';
      container.appendChild(none);
      return;
    }

    var identity = adapter.getElementIdentity(element);

    var idRow = document.createElement('button');
    idRow.type = 'button';
    idRow.className = 'baqa-existing-row baqa-identity-row';
    idRow.setAttribute('title', 'Click to set/edit CSS ID.');

    var idName = document.createElement('code');
    idName.className = 'baqa-existing-name';
    idName.textContent = 'CSS ID';

    var idValue = document.createElement('span');
    idValue.className = 'baqa-existing-value';
    idValue.textContent = identity.id ? '#' + identity.id : 'none';
    idValue.classList.toggle('is-empty-value', !identity.id);

    idRow.appendChild(idName);
    idRow.appendChild(idValue);
    idRow.addEventListener('click', function (event) {
      event.preventDefault();
      var command = '#' + (identity.id || '');
      if (typeof callbacks.loadTextCommand === 'function') callbacks.loadTextCommand(command, 1, command.length);
    });
    container.appendChild(idRow);

    if (!identity.classes.length) {
      var noClasses = document.createElement('div');
      noClasses.className = 'baqa-existing-empty';
      noClasses.textContent = 'No manual/global classes detected.';
      container.appendChild(noClasses);
      return;
    }

    identity.classes.forEach(function (className) {
      var row = document.createElement('button');
      row.type = 'button';
      row.className = 'baqa-existing-row baqa-identity-row';
      row.setAttribute('title', 'Click to add/load class. Shift+click to rename class on this element.');

      var name = document.createElement('code');
      name.className = 'baqa-existing-name';
      name.textContent = 'class';

      var value = document.createElement('span');
      value.className = 'baqa-existing-value';
      value.textContent = '.' + className;

      row.appendChild(name);
      row.appendChild(value);

      row.addEventListener('click', function (event) {
        event.preventDefault();
        if (event.shiftKey) {
          var renameCommand = '.' + className + ' -> .' + className;
          var start = renameCommand.lastIndexOf('.') + 1;
          if (typeof callbacks.loadTextCommand === 'function') callbacks.loadTextCommand(renameCommand, start, renameCommand.length);
          return;
        }
        if (typeof callbacks.loadTextCommand === 'function') callbacks.loadTextCommand('+' + className);
      });

      row.addEventListener('dblclick', function (event) {
        event.preventDefault();
        var command = '-' + className;
        if (typeof callbacks.loadTextCommand === 'function') callbacks.loadTextCommand(command, 0, command.length);
      });

      container.appendChild(row);
    });
  }

  function renderExistingAttributes(options) {
    options = options || {};
    var list = options.list;
    var adapter = options.adapter;
    var element = options.element;
    var callbacks = options.callbacks || {};

    if (!list || !adapter) return { count: 0, collapse: true };

    var attrs = adapter.getElementAttributes(element);
    list.textContent = '';

    if (!attrs.length) {
      var empty = document.createElement('div');
      empty.className = 'baqa-existing-empty';
      empty.textContent = element ? 'No custom attributes on this element yet.' : 'Select an element to view its attributes.';
      list.appendChild(empty);
      return { count: 0, collapse: true };
    }

    attrs.forEach(function (attr) {
      var row = document.createElement('button');
      row.type = 'button';
      row.className = 'baqa-existing-row';
      row.setAttribute('title', 'Click to edit value. Shift+click to rename.');

      var name = document.createElement('code');
      name.className = 'baqa-existing-name';
      name.textContent = attr.name;

      var value = document.createElement('span');
      value.className = 'baqa-existing-value';
      value.textContent = attr.value === '' ? 'boolean / empty' : attr.value;
      value.classList.toggle('is-empty-value', attr.value === '');

      row.appendChild(name);
      row.appendChild(value);

      row.addEventListener('click', function (event) {
        event.preventDefault();
        if (typeof callbacks.loadAttributeCommand === 'function') {
          callbacks.loadAttributeCommand(attr, event.shiftKey ? 'rename' : 'set', false);
        }
      });

      row.addEventListener('dblclick', function (event) {
        event.preventDefault();
        if (typeof callbacks.loadAttributeCommand === 'function') callbacks.loadAttributeCommand(attr, 'set', true);
      });

      list.appendChild(row);
    });

    return { count: attrs.length, collapse: false };
  }

  window.MimamsBarUIRenderer = {
    escapeCommandValue: escapeCommandValue,
    attributeToSetCommand: attributeToSetCommand,
    attributeToRenameCommand: attributeToRenameCommand,
    loadTextCommand: loadTextCommand,
    loadAttributeCommand: loadAttributeCommand,
    renderIdentity: renderIdentity,
    renderExistingAttributes: renderExistingAttributes
  };
})();
