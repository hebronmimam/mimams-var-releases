<?php

namespace VE\Core;

use VE\Database\Schema;

defined( 'ABSPATH' ) || exit;

class AdvancedCssManager {

    private const OPTION = 've_advanced_css';

    public function get(): array {
        $data = get_option( self::OPTION, [] );
        if ( ! is_array( $data ) ) {
            $data = [];
        }

        $sheets = $data['stylesheets'] ?? [];
        if ( ! is_array( $sheets ) || empty( $sheets ) ) {
            $sheets = $this->default_sheets();
        }

        return [
            'stylesheets' => array_values( array_map( [ $this, 'normalize_sheet' ], $sheets ) ),
            'file_url'    => $this->file_url(),
            'file_path'   => $this->file_path(),
        ];
    }

    /**
     * How many versions of one stylesheet are kept. Enough to walk back through
     * an afternoon's work; few enough that a busy sheet cannot fill the table.
     */
    public const VERSION_LIMIT = 25;

    public function save( array $sheets ): array {
        $clean = [];
        foreach ( $sheets as $sheet ) {
            if ( ! is_array( $sheet ) ) {
                continue;
            }
            $clean[] = $this->normalize_sheet( $sheet );
        }

        if ( empty( $clean ) ) {
            $clean = $this->default_sheets();
        }

        // Recorded before the write, so a version exists to go back to even if
        // the save itself is the thing that went wrong.
        $this->record_versions( $clean, 'save' );

        update_option( self::OPTION, [ 'stylesheets' => $clean ], false );
        $this->compile();

        return $this->get();
    }

    /**
     * Keep a copy of every sheet whose CSS changed.
     *
     * The first time a sheet is touched its PREVIOUS content is stored too —
     * otherwise the first edit after installing would have nothing behind it,
     * which is exactly the edit people want back.
     *
     * @param array<int,array<string,mixed>> $sheets Normalised sheets about to be saved.
     */
    public function record_versions( array $sheets, string $note = 'save' ): int {
        global $wpdb;

        $existing = [];
        foreach ( $this->get()['stylesheets'] as $sheet ) {
            $existing[ (string) $sheet['id'] ] = $sheet;
        }

        $written = 0;
        foreach ( $sheets as $sheet ) {
            $id  = (string) ( $sheet['id'] ?? '' );
            $css = (string) ( $sheet['css'] ?? '' );
            if ( '' === $id ) {
                continue;
            }

            $before = isset( $existing[ $id ] ) ? (string) $existing[ $id ]['css'] : null;
            if ( null !== $before && $before === $css ) {
                continue;   // nothing changed in this sheet; no version to write
            }

            if ( null !== $before && ! $this->has_versions( $id ) && '' !== trim( $before ) ) {
                $this->insert_version( $id, $existing[ $id ], $before, 'before first tracked edit' );
                $written++;
            }

            $this->insert_version( $id, $sheet, $css, $note );
            $written++;
            $this->prune_versions( $id );
        }

        return $written;
    }

    private function has_versions( string $sheet_id ): bool {
        global $wpdb;
        $table = Schema::table( 'css_versions' );
        return (bool) $wpdb->get_var( $wpdb->prepare( "SELECT 1 FROM {$table} WHERE sheet_id = %s LIMIT 1", $sheet_id ) );
    }

    private function insert_version( string $sheet_id, array $sheet, string $css, string $note ): void {
        global $wpdb;
        $wpdb->insert(
            Schema::table( 'css_versions' ),
            [
                'sheet_id'   => $sheet_id,
                'sheet_name' => (string) ( $sheet['name'] ?? '' ),
                'scope'      => (string) ( $sheet['scope'] ?? 'custom' ),
                'css'        => $css,
                'bytes'      => strlen( $css ),
                'note'       => $note,
                'created_by' => get_current_user_id(),
                'created_at' => current_time( 'mysql' ),
            ]
        );
    }

    /** Drop everything past the limit for this sheet, oldest first. */
    private function prune_versions( string $sheet_id ): void {
        global $wpdb;
        $table = Schema::table( 'css_versions' );
        $keep  = $wpdb->get_col(
            $wpdb->prepare( "SELECT id FROM {$table} WHERE sheet_id = %s ORDER BY id DESC LIMIT %d", $sheet_id, self::VERSION_LIMIT )
        );
        if ( empty( $keep ) ) {
            return;
        }
        $ids = implode( ',', array_map( 'absint', $keep ) );
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE sheet_id = %s AND id NOT IN ({$ids})", $sheet_id ) );
    }

    /**
     * The list for the History panel: everything except the CSS itself, because
     * a list of twenty-five stylesheets is a lot of bytes to send to draw dates.
     *
     * @return array<int,array<string,mixed>>
     */
    public function versions( string $sheet_id = '' ): array {
        global $wpdb;
        $table = Schema::table( 'css_versions' );
        $sql   = "SELECT id, sheet_id, sheet_name, scope, bytes, note, created_by, created_at FROM {$table}";
        $rows  = '' !== $sheet_id
            ? $wpdb->get_results( $wpdb->prepare( $sql . ' WHERE sheet_id = %s ORDER BY id DESC LIMIT %d', $sheet_id, self::VERSION_LIMIT ), ARRAY_A )
            : $wpdb->get_results( $sql . ' ORDER BY id DESC LIMIT 100', ARRAY_A );

        return array_map(
            static function ( $row ) {
                $user            = $row['created_by'] ? get_userdata( (int) $row['created_by'] ) : null;
                $row['id']       = (int) $row['id'];
                $row['bytes']    = (int) $row['bytes'];
                $row['author']   = $user ? $user->display_name : '';
                return $row;
            },
            is_array( $rows ) ? $rows : []
        );
    }

    /** One version, CSS included. */
    public function version( int $id ): ?array {
        global $wpdb;
        $table = Schema::table( 'css_versions' );
        $row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A );
        return is_array( $row ) ? $row : null;
    }

    /**
     * Put a version back. The current content is recorded first, so restoring is
     * itself undoable — the one thing that makes a restore button safe to press.
     *
     * @return array<string,mixed>
     */
    public function restore_version( int $id ): array {
        $version = $this->version( $id );
        if ( ! $version ) {
            return [ 'restored' => false, 'message' => 'That version no longer exists.' ];
        }

        $sheet_id = (string) $version['sheet_id'];
        $data     = $this->get();
        $sheets   = $data['stylesheets'];
        $found    = false;

        foreach ( $sheets as $index => $sheet ) {
            if ( (string) $sheet['id'] !== $sheet_id ) {
                continue;
            }
            $found = true;
            $sheets[ $index ]['css'] = (string) $version['css'];
        }

        if ( ! $found ) {
            return [ 'restored' => false, 'message' => 'That stylesheet no longer exists.' ];
        }

        $this->record_versions( $sheets, 'restored version ' . (int) $id );
        update_option( self::OPTION, [ 'stylesheets' => $sheets ], false );
        $this->compile();

        return [
            'restored'    => true,
            'sheet_id'    => $sheet_id,
            'stylesheets' => $this->get()['stylesheets'],
            'message'     => 'Restored the version from ' . (string) $version['created_at'] . '.',
        ];
    }

    /* R13. "mv 1419ms" on a cold Themes screen - MV's own callback, not
       WordPress booting, for autocomplete nothing on that screen was going to
       use. Two causes, both here.

       This method BUILT THE INDEX INSIDE THE REQUEST: up to 2,000 post_content
       rows and 5,000 postmeta rows, unserialized, JSON-decoded and put through
       eight preg_match_all passes at up to 250KB each. And the result was kept
       for five minutes, so on any site being worked on it was cold most of the
       time and paid again, and again.

       Now: a warm index is returned as before. A cold one returns the half that
       costs one indexed query - the variables, which are what autocomplete
       needs first - and the scan is scheduled to run out of band. `?refresh=1`
       still builds inline, because that is a person pressing Rescan and
       waiting for it. */
    public const INDEX_KEY   = 've_advanced_css_suggestions_scan_v19';
    public const BUILD_HOOK  = 've_build_css_suggestion_index';
    /* Literal seconds, not 12 * HOUR_IN_SECONDS: a class constant is evaluated
       when the class is defined, and this file is loaded by guards that have no
       WordPress constants. 12 hours. */
    public const INDEX_LIFE  = 43200;

    public function suggestions( bool $refresh = false ): array {
        global $wpdb;

        $classes = [];
        $ids     = [];
        $vars    = [];
        $variable_meta = [];
        $selectors = [];
        $class_map = $this->global_class_map();
        $cached  = get_transient( self::INDEX_KEY );

        $var_table = Schema::table( 'variables' );
        $rows = $wpdb->get_results( "SELECT name, value, css_value FROM {$var_table} ORDER BY name ASC", ARRAY_A ) ?: [];
        $manager = new VariableManager();
        foreach ( $rows as $row ) {
            $name = (string) ( $row['name'] ?? '' );
            if ( '' !== $name ) {
                $css_name = $manager->to_css_name( $name );
                $vars[] = $css_name;
                $variable_meta[ $css_name ] = [
                    'value'  => (string) ( $row['css_value'] ?: $row['value'] ?: '' ),
                    'source' => "Mimam's Var",
                ];
            }
        }

        if ( $refresh ) {
            delete_transient( 've_advanced_css_suggestions_scan_v12' );
            delete_transient( 've_advanced_css_suggestions_scan_v13' );
            delete_transient( 've_advanced_css_suggestions_scan_v14' );
            delete_transient( 've_advanced_css_suggestions_scan_v15' );
            delete_transient( 've_advanced_css_suggestions_scan_v16' );
            delete_transient( 've_advanced_css_suggestions_scan_v17' );
            delete_transient( 've_advanced_css_suggestions_scan_v18' );
            delete_transient( self::INDEX_KEY );
            $cached = false;
        }

        if ( is_array( $cached ) ) {
            $variables = $this->sorted_keys( array_merge( $vars, $cached['variables'] ?? [] ) );
            $variable_meta = array_merge( $cached['variable_meta'] ?? [], $variable_meta );
            return [
                'variables'  => $variables,
                'variable_meta' => $variable_meta,
                'classes'    => $cached['classes'] ?? [],
                'ids'        => $cached['ids'] ?? [],
                'selectors'  => $cached['selectors'] ?? [],
                'sources'    => $cached['sources'] ?? [ "Mimam's Var" ],
                'counts'     => [
                    'variables' => count( $variables ),
                    'classes'   => count( $cached['classes'] ?? [] ),
                    'ids'       => count( $cached['ids'] ?? [] ),
                    'selectors' => count( $cached['selectors'] ?? [] ),
                ],
                'cached'     => true,
                'scanned_at' => $cached['scanned_at'] ?? 0,
            ];
        }

        /* R13. Cold cache, and nobody asked for a rescan. Answer with what is
           already in hand and let the scan happen out of band - the caller gets
           its variables in milliseconds and the full index on the next open,
           instead of one visitor paying 1.4 seconds for everyone. */
        if ( ! $refresh ) {
            $this->schedule_index_build();
            $variables = $this->sorted_keys( $vars );
            return [
                'variables'  => $variables,
                'variable_meta' => $variable_meta,
                'classes'    => [],
                'ids'        => [],
                'selectors'  => [],
                'sources'    => [ "Mimam's Var" ],
                'counts'     => [
                    'variables' => count( $variables ),
                    'classes'   => 0,
                    'ids'       => 0,
                    'selectors' => 0,
                ],
                'cached'     => false,
                'building'   => true,
                'scanned_at' => 0,
            ];
        }

        $scan_text = [];
        $posts = $wpdb->get_col(
             "SELECT post_content FROM {$wpdb->posts}
             WHERE post_status NOT IN ('trash','auto-draft')
             ORDER BY post_modified_gmt DESC
             LIMIT 2000"
        ) ?: [];
        $scan_text = array_merge( $scan_text, $posts );

        $meta_rows = $wpdb->get_col(
            "SELECT meta_value FROM {$wpdb->postmeta}
             WHERE meta_key LIKE '_bricks_%'
                OR meta_key LIKE 'bricks_%'
                OR meta_key LIKE '%global%class%'
             ORDER BY meta_id DESC
             LIMIT 5000"
        ) ?: [];
        $scan_text = array_merge( $scan_text, $meta_rows );

        $authored_css = [];
        foreach ( $this->get()['stylesheets'] as $sheet ) {
            $css = (string) ( $sheet['css'] ?? '' );
            if ( '' === trim( $css ) ) {
                continue;
            }
            $authored_css[] = $css;
            $scan_text[] = $css;
        }
        // Autocomplete indexes authored site data only. Generated CSS, theme
        // and plugin source files, templates and third-party snippet tables
        // contain implementation selectors that are not meaningful choices
        // for the site author.
        $this->collect_scan_class_map( $scan_text, $class_map );
        foreach ( $class_map as $class_name ) {
            $this->add_identifier( $classes, (string) $class_name, '.' );
        }

        foreach ( $scan_text as $text ) {
            $ignored_vars = [];
            $text = maybe_unserialize( $text );
            if ( is_array( $text ) || is_object( $text ) ) {
                $this->extract_identifiers_from_data( $text, $classes, $ids, $ignored_vars, $class_map );
                $text = wp_json_encode( $text );
            }
            $text = substr( (string) $text, 0, 250000 );
            if ( '' === $text ) {
                continue;
            }

            $decoded = json_decode( $text, true );
            if ( is_array( $decoded ) ) {
                $this->extract_identifiers_from_data( $decoded, $classes, $ids, $ignored_vars, $class_map );
            }

            $this->extract_bricks_class_records( $text, $classes );
            $this->extract_css_selectors( $text, $classes, $ids, $selectors );

            if ( preg_match_all( '/class(?:Name)?=["\']([^"\']+)["\']/i', $text, $matches ) ) {
                foreach ( $matches[1] as $match ) {
                    foreach ( preg_split( '/\s+/', $match ) as $class ) {
                        $this->add_identifier( $classes, $class, '.' );
                    }
                }
            }

            if ( preg_match_all( '/"class(?:Name)?"\s*:\s*"([^"]+)"/i', $text, $matches ) ) {
                foreach ( $matches[1] as $match ) {
                    foreach ( preg_split( '/\s+/', $match ) as $class ) {
                        $this->add_identifier( $classes, $class, '.' );
                    }
                }
            }

            if ( preg_match_all( '/id=["\']([A-Za-z][A-Za-z0-9_-]*)["\']/i', $text, $matches ) ) {
                foreach ( $matches[1] as $id ) {
                    $this->add_identifier( $ids, $id, '#' );
                }
            }

            if ( preg_match_all( '/"id"\s*:\s*"([A-Za-z][A-Za-z0-9_-]*)"/i', $text, $matches ) ) {
                foreach ( $matches[1] as $id ) {
                    $this->add_identifier( $ids, $id, '#' );
                }
            }

            if ( preg_match_all( '/\.([A-Za-z_][A-Za-z0-9_-]*)/', $text, $matches ) ) {
                foreach ( $matches[1] as $class ) {
                    $this->add_identifier( $classes, $class, '.' );
                }
            }

            if ( preg_match_all( '/#([A-Za-z_][A-Za-z0-9_-]*)/', $text, $matches ) ) {
                foreach ( $matches[1] as $id ) {
                    $this->add_identifier( $ids, $id, '#' );
                }
            }
        }

        foreach ( $authored_css as $css ) {
            $this->extract_css_custom_property_meta( $css, $vars, $variable_meta, 'CSS Studio' );
        }

        $provider_sources = [];
        $migration_scanner = new MigrationScanner();
        foreach ( $migration_scanner->suggestion_variables() as $provider_var ) {
            $css_name = strtolower( trim( (string) ( $provider_var['suggestion_css_name'] ?? '' ) ) );
            if ( ! preg_match( '/^--[a-z][a-z0-9_-]{1,120}$/', $css_name ) ) {
                continue;
            }

            $value = trim( (string) ( $provider_var['value'] ?? '' ) );
            if ( '' === $value && ! empty( $provider_var['source_css_name'] ) ) {
                $value = 'var(' . trim( (string) $provider_var['source_css_name'] ) . ')';
            }
            if ( '' === $value ) {
                continue;
            }

            $category = (string) ( $provider_var['category_slug'] ?? '' );
            if ( 'core-framework' === $category ) {
                $source = 'Core Framework';
            } elseif ( 'automatic-css' === $category ) {
                $source = 'Automatic.css';
            } else {
                $source = 'Bricks / Advanced Themer';
            }
            $vars[] = $css_name;
            $provider_sources[] = $source;
            $variable_meta[ $css_name ] = [
                'value'  => $value,
                'source' => $source,
            ];
        }

        /* Automatic.css may store settings rather than literal declarations,
           and its compiled stylesheet is not loaded on ordinary wp-admin
           screens. Read only ACSS-owned compiled CSS locations so its public
           custom properties remain available without indexing arbitrary
           plugin/theme implementation styles. Registered provider data above
           wins when both sources contain the same token. */
        foreach ( $this->automatic_css_compiled_chunks() as $css ) {
            $compiled_vars = [];
            $compiled_meta = [];
            $this->extract_css_custom_property_meta( $css, $compiled_vars, $compiled_meta, 'Automatic.css' );
            foreach ( $compiled_vars as $compiled_var ) {
                $compiled_var = strtolower( (string) $compiled_var );
                if ( $this->is_internal_css_variable( $compiled_var ) ) {
                    continue;
                }
                $vars[] = $compiled_var;
                if ( ! isset( $variable_meta[ $compiled_var ] ) && isset( $compiled_meta[ $compiled_var ] ) ) {
                    $variable_meta[ $compiled_var ] = $compiled_meta[ $compiled_var ];
                }
            }
            if ( ! empty( $compiled_vars ) ) {
                $provider_sources[] = 'Automatic.css';
            }
        }

        $source_labels = [ "Mimam's Var" ];
        if ( ! empty( $authored_css ) ) {
            $source_labels[] = 'CSS Studio';
        }
        $source_labels = array_merge( $source_labels, array_values( array_unique( $provider_sources ) ) );
        if ( ! empty( $classes ) ) {
            $source_labels[] = 'CSS Classes';
        }
        if ( ! empty( $ids ) ) {
            $source_labels[] = 'Element IDs';
        }
        if ( ! empty( $selectors ) ) {
            $source_labels[] = 'CSS Selectors';
        }

        $scan = [
            'variables' => $this->sorted_keys( $vars ),
            'variable_meta' => $variable_meta,
            'classes' => $this->sorted_keys( array_keys( $classes ) ),
            'ids'     => $this->sorted_keys( array_keys( $ids ) ),
            'selectors' => $this->sorted_keys( array_keys( $selectors ) ),
            'sources' => array_values( array_unique( $source_labels ) ),
            'scanned_at' => time(),
        ];
        set_transient( self::INDEX_KEY, $scan, self::INDEX_LIFE );

        return [
            'variables'  => $scan['variables'],
            'variable_meta' => $variable_meta,
            'classes'    => $scan['classes'],
            'ids'        => $scan['ids'],
            'selectors'  => $scan['selectors'],
            'sources'    => $scan['sources'],
            'counts'     => [
                'variables' => count( $scan['variables'] ),
                'classes'   => count( $scan['classes'] ),
                'ids'       => count( $scan['ids'] ),
                'selectors' => count( $scan['selectors'] ),
            ],
            'cached'     => false,
            'scanned_at' => $scan['scanned_at'],
        ];
    }

    /* R13. Ask for the scan to happen somewhere that is not this request. One
       at a time: a queued build already covers every caller waiting for it. */
    public function schedule_index_build(): void {
        if ( wp_next_scheduled( self::BUILD_HOOK ) ) {
            return;
        }
        wp_schedule_single_event( time() + 1, self::BUILD_HOOK );
        /* Without this the event waits for the next page load to spawn cron,
           which on a quiet admin screen can be a long time to have no classes. */
        if ( function_exists( 'spawn_cron' ) ) {
            spawn_cron();
        }
    }

    /* R13. The heavy scan, run by cron rather than by whoever opened a panel.
       It is `suggestions( true )` with its return value thrown away: the point
       is the transient it leaves behind. */
    public function build_index(): void {
        $this->suggestions( true );
    }

    public function compile(): array {
        $data   = $this->get();
        $sheets = $data['stylesheets'];
        $lines  = [
            '/*',
            " * Mimam's Var - CSS Studio",
            ' * Version: ' . VE_VERSION,
            ' * Compiled: ' . gmdate( 'Y-m-d H:i:s' ) . ' UTC',
            ' */',
            '',
        ];

        foreach ( $sheets as $sheet ) {
            if ( empty( $sheet['enabled'] ) || '' === trim( (string) $sheet['css'] ) ) {
                continue;
            }
            $lines[] = '/* === ' . $sheet['name'] . ' (' . $sheet['scope'] . ') === */';
            $lines[] = rtrim( (string) $sheet['css'] );
            $lines[] = '';
        }

        if ( ! is_dir( VE_CSS_OUTPUT_DIR ) ) {
            wp_mkdir_p( VE_CSS_OUTPUT_DIR );
        }

        $written = file_put_contents( $this->file_path(), implode( "\n", $lines ) );

        return [
            'compiled'  => false !== $written,
            'file_url'  => $this->file_url(),
            'file_path' => $this->file_path(),
        ];
    }

    private function normalize_sheet( array $sheet ): array {
        $id = sanitize_key( (string) ( $sheet['id'] ?? '' ) );
        if ( '' === $id ) {
            $id = 'sheet_' . substr( md5( wp_json_encode( $sheet ) . microtime( true ) ), 0, 8 );
        }

        $scope = sanitize_key( (string) ( $sheet['scope'] ?? 'global' ) );
        if ( ! in_array( $scope, [ 'page', 'global', 'child', 'custom', 'recipe' ], true ) ) {
            $scope = 'custom';
        }

        return [
            'id'      => $id,
            'name'    => sanitize_text_field( (string) ( $sheet['name'] ?? 'custom.css' ) ),
            'scope'   => $scope,
            'enabled' => ! isset( $sheet['enabled'] ) || ! empty( $sheet['enabled'] ),
            'css'     => wp_kses_post( (string) ( $sheet['css'] ?? '' ) ),
        ];
    }

    private function default_sheets(): array {
        return [
            [ 'id' => 'global', 'name' => 'global.css', 'scope' => 'global', 'enabled' => true, 'css' => '' ],
        ];
    }

    private function add_identifier( array &$bucket, string $value, string $prefix ): void {
        $value = trim( html_entity_decode( $value, ENT_QUOTES, 'UTF-8' ) );
        $value = trim( $value, ".# \t\n\r\0\x0B" );
        $value = str_replace( [ '\\:', '\\/', '\\[', '\\]', '\\.' ], [ ':', '/', '[', ']', '.' ], $value );
        if ( '.' === $prefix ) {
            $value = preg_replace( '/[^A-Za-z0-9_:\\/\\[\\].-]/', '', $value );
        } else {
            $value = preg_replace( '/[^A-Za-z0-9_-]/', '', $value );
        }
        if ( ! is_string( $value ) || '' === $value || is_numeric( $value[0] ) ) {
            return;
        }
        if ( 80 < strlen( $value ) ) {
            return;
        }
        if ( '#' === $prefix && preg_match( '/^[A-Fa-f0-9]{3,8}$/', $value ) ) {
            return;
        }
        if ( '.' === $prefix ) {
            $value = str_replace( [ '\\', ':', '/', '[', ']', '.' ], [ '', '\\:', '\\/', '\\[', '\\]', '\\.' ], $value );
        }
        $bucket[ $prefix . $value ] = true;
    }

    private function add_css_variable( array &$vars, string $value ): void {
        $value = trim( html_entity_decode( $value, ENT_QUOTES, 'UTF-8' ) );
        if ( '' === $value ) {
            return;
        }
        if ( 0 !== strpos( $value, '--' ) ) {
            $value = '--' . ltrim( $value, '-' );
        }
        $body = strtolower( preg_replace( '/[^a-zA-Z0-9_-]/', '-', substr( $value, 2 ) ) );
        $body = preg_replace( '/-+/', '-', $body );
        $value = '--' . trim( $body, '-' );
        if ( ! preg_match( '/^--[a-z][a-z0-9_-]{1,120}$/', $value ) ) {
            return;
        }
        $vars[] = $value;
    }

    private function extract_css_custom_properties( string $text, array &$vars ): void {
        if ( preg_match_all( '/--([a-zA-Z][a-zA-Z0-9_-]*)\s*:/', $text, $matches ) ) {
            foreach ( $matches[1] as $name ) {
                $this->add_css_variable( $vars, '--' . $name );
            }
        }
    }

    private function extract_css_custom_property_meta( string $text, array &$vars, array &$variable_meta, string $source ): void {
        if ( ! preg_match_all( '/--([a-zA-Z][a-zA-Z0-9_-]*)\s*:\s*([^;}]+)/', $text, $matches, PREG_SET_ORDER ) ) {
            return;
        }

        foreach ( $matches as $match ) {
            $name = '--' . (string) $match[1];
            $this->add_css_variable( $vars, $name );
            $value = trim( (string) $match[2] );
            if ( '' !== $value ) {
                $variable_meta[ strtolower( $name ) ] = [
                    'value'  => $value,
                    'source' => $source,
                ];
            }
        }
    }

    private function add_selector( array &$selectors, string $value ): void {
        $value = trim( html_entity_decode( $value, ENT_QUOTES, 'UTF-8' ) );
        if ( '' === $value || 60 < strlen( $value ) ) {
            return;
        }
        if ( preg_match( '/^@(?:container|font-face|keyframes|layer|media|property|supports)$/i', $value )
            || preg_match( '/^::?[a-z][a-z0-9-]*(?:\(\))?$/i', $value )
            || preg_match( '/^[a-z][a-z0-9-]*$/i', $value )
        ) {
            $selectors[ strtolower( $value ) ] = true;
        }
    }

    private function extract_css_selectors( string $text, array &$classes, array &$ids, ?array &$selectors = null ): void {
        if ( preg_match_all( '/\\.((?:\\\\.|[A-Za-z_][A-Za-z0-9_-]*|[\\/:\\[\\].-]){1,120})/', $text, $matches ) ) {
            foreach ( $matches[1] as $class ) {
                $class = preg_replace( '/(?<!\\\\)::?[A-Za-z-].*$/', '', (string) $class );
                $this->add_identifier( $classes, (string) $class, '.' );
            }
        }
        if ( preg_match_all( '/#([A-Za-z_][A-Za-z0-9_-]{0,119})/', $text, $matches ) ) {
            foreach ( $matches[1] as $id ) {
                $this->add_identifier( $ids, (string) $id, '#' );
            }
        }
        if ( null === $selectors ) {
            return;
        }
        if ( preg_match_all( '/@(?:container|font-face|keyframes|layer|media|property|supports)\b/i', $text, $matches ) ) {
            foreach ( $matches[0] as $at_rule ) {
                $this->add_selector( $selectors, (string) $at_rule );
            }
        }
        if ( preg_match_all( '/(?<!\\\\)::?[a-z][a-z0-9-]*(?:\s*\([^)]{0,80}\))?/i', $text, $matches ) ) {
            foreach ( $matches[0] as $pseudo ) {
                $pseudo = preg_replace( '/\s*\([^)]*\)$/', '()', (string) $pseudo );
                $this->add_selector( $selectors, $pseudo );
            }
        }
        if ( preg_match_all( '/([^{};]{1,700})\{/', $text, $blocks ) ) {
            $skip = [
                'and' => true, 'from' => true, 'media' => true, 'min-width' => true,
                'max-width' => true, 'not' => true, 'only' => true, 'or' => true,
                'screen' => true, 'to' => true, 'var' => true, 'where' => true,
            ];
            foreach ( $blocks[1] as $prelude ) {
                if ( preg_match_all( '/(?<![.#:a-zA-Z0-9_-])([a-z][a-z0-9-]*)(?=[\s.#:\[>~,+{]|$)/i', (string) $prelude, $tags ) ) {
                    foreach ( $tags[1] as $tag ) {
                        $tag = strtolower( (string) $tag );
                        if ( ! isset( $skip[ $tag ] ) ) {
                            $this->add_selector( $selectors, $tag );
                        }
                    }
                }
            }
        }
    }

    private function extract_markup_identifiers( string $text, array &$classes, array &$ids, array &$vars ): void {
        if ( preg_match_all( "/\\bclass(?:Name)?\\s*=\\s*[\"']([^\"']{1,2000})[\"']/i", $text, $matches ) ) {
            foreach ( $matches[1] as $class_list ) {
                $this->extract_class_list( (string) $class_list, $classes );
            }
        }
        if ( preg_match_all( "/\\bclass(?:Name)?\\s*[:=]\\s*\\{?\\s*[`\"']([^`\"']{1,3000})[`\"']/i", $text, $matches ) ) {
            foreach ( $matches[1] as $class_list ) {
                $this->extract_class_list( (string) $class_list, $classes );
            }
        }
        if ( preg_match_all( "/\\b(?:class|className|class_name)\\s*[:=]\\s*\\[([^\\]]{1,4000})\\]/i", $text, $matches ) ) {
            foreach ( $matches[1] as $class_block ) {
                if ( preg_match_all( "/[`\"']([^`\"']{1,400})[`\"']/", (string) $class_block, $parts ) ) {
                    foreach ( $parts[1] as $class_list ) {
                        $this->extract_class_list( (string) $class_list, $classes );
                    }
                }
            }
        }
        if ( preg_match_all( "/classList\\.(?:add|remove|toggle|contains)\\s*\\(([^)]{1,2000})\\)/i", $text, $matches ) ) {
            foreach ( $matches[1] as $class_block ) {
                if ( preg_match_all( "/[`\"']([^`\"']{1,200})[`\"']/", (string) $class_block, $parts ) ) {
                    foreach ( $parts[1] as $class_list ) {
                        $this->extract_class_list( (string) $class_list, $classes );
                    }
                }
            }
        }
        if ( preg_match_all( "/(?:querySelector(?:All)?|closest|matches)\\s*\\(\\s*[`\"']([^`\"']{1,1000})[`\"']/i", $text, $matches ) ) {
            foreach ( $matches[1] as $selector ) {
                $this->extract_css_selectors( (string) $selector, $classes, $ids );
            }
        }
        if ( preg_match_all( "/\\bid\\s*=\\s*[\"']([A-Za-z][A-Za-z0-9_-]{0,119})[\"']/i", $text, $matches ) ) {
            foreach ( $matches[1] as $id ) {
                $this->add_identifier( $ids, (string) $id, '#' );
            }
        }
        if ( preg_match_all( "/\\bid\\s*[:=]\\s*[`\"']([A-Za-z][A-Za-z0-9_-]{0,119})[`\"']/i", $text, $matches ) ) {
            foreach ( $matches[1] as $id ) {
                $this->add_identifier( $ids, (string) $id, '#' );
            }
        }
        $this->extract_css_custom_properties( $text, $vars );
    }

    private function extract_class_list( string $class_list, array &$classes ): void {
        $class_list = preg_replace( '/\\$\\{[^}]*\\}/', ' ', $class_list );
        $class_list = preg_replace( '/[{}()\\[\\],+?:;]/', ' ', (string) $class_list );
        foreach ( preg_split( '/\\s+/', (string) $class_list ) ?: [] as $class ) {
            $this->add_identifier( $classes, $class, '.' );
        }
    }

    private function extract_bricks_class_records( string $text, array &$classes ): void {
        if ( false === stripos( $text, 'globalClassesNamesIds' )
            && false === stripos( $text, 'global_classes' )
            && false === stripos( $text, 'globalClasses' )
        ) {
            return;
        }

        if ( preg_match_all( '/["\']name["\']\s*:\s*["\']([^"\']{1,120})["\']/i', $text, $matches ) ) {
            foreach ( $matches[1] as $name ) {
                $this->add_identifier( $classes, ltrim( (string) $name, '.' ), '.' );
            }
        }

        if ( preg_match_all( '/["\']selector["\']\s*:\s*["\']\.([^"\']{1,120})["\']/i', $text, $matches ) ) {
            foreach ( $matches[1] as $name ) {
                $this->add_identifier( $classes, (string) $name, '.' );
            }
        }
    }

    private function global_class_map(): array {
        $map = [];
        foreach ( [ 'bricks_global_classes', 'bricks_global_classes_names_ids', 'bricks_global_classes_namesIds' ] as $option ) {
            $data = get_option( $option, [] );
            $this->collect_global_class_map( $data, $map );
        }
        return $map;
    }

    private function collect_global_class_map( $data, array &$map ): void {
        if ( is_string( $data ) ) {
            $decoded = json_decode( $data, true );
            if ( is_array( $decoded ) ) {
                $data = $decoded;
            } else {
                return;
            }
        }
        if ( is_object( $data ) ) {
            $data = (array) $data;
        }
        if ( ! is_array( $data ) ) {
            return;
        }

        if ( $this->is_tool_owned_global_class( $data ) ) {
            return;
        }

        if ( isset( $data['id'], $data['name'] ) && is_scalar( $data['id'] ) && is_scalar( $data['name'] ) ) {
            $id = trim( (string) $data['id'] );
            $name = trim( (string) $data['name'] );
            if ( '' !== $id && '' !== $name ) {
                $map[ $id ] = $name;
            }
        }

        foreach ( $data as $value ) {
            $this->collect_global_class_map( $value, $map );
        }
    }

    private function is_tool_owned_global_class( array $data ): bool {
        if ( ! empty( $data['at_framework'] ) ) {
            return true;
        }

        $settings = $data['settings'] ?? null;
        return is_array( $settings ) && ! empty( $settings['at_framework'] );
    }

    private function collect_scan_class_map( array $scan_text, array &$map ): void {
        foreach ( $scan_text as $text ) {
            $data = maybe_unserialize( $text );
            if ( is_array( $data ) || is_object( $data ) ) {
                $this->collect_contextual_class_map( $data, $map );
                $text = wp_json_encode( $data );
            }

            $text = substr( (string) $text, 0, 250000 );
            if ( '' === $text ) {
                continue;
            }

            if ( false !== stripos( $text, 'globalClasses' )
                || false !== stripos( $text, 'global_classes' )
                || false !== stripos( $text, 'bricks' )
            ) {
                $this->collect_class_map_from_text( $text, $map );
            }

            $decoded = json_decode( $text, true );
            if ( is_array( $decoded ) ) {
                $this->collect_contextual_class_map( $decoded, $map );
            }
        }
    }

    private function collect_contextual_class_map( $data, array &$map, string $context = '', int $depth = 0 ): void {
        if ( 8 < $depth ) {
            return;
        }
        if ( is_object( $data ) ) {
            $data = (array) $data;
        }
        if ( ! is_array( $data ) ) {
            return;
        }

        $context_l = strtolower( $context );
        $class_context = false !== strpos( $context_l, 'class' )
            || false !== strpos( $context_l, 'globalclasses' )
            || false !== strpos( $context_l, 'bricks' );

        if ( $class_context && isset( $data['id'], $data['name'] ) && is_scalar( $data['id'] ) && is_scalar( $data['name'] ) ) {
            $id = trim( (string) $data['id'] );
            $name = trim( (string) $data['name'] );
            if ( '' !== $id && '' !== $name ) {
                $map[ $id ] = $name;
            }
        }

        foreach ( $data as $key => $value ) {
            $next_context = is_string( $key ) && '' !== $key ? $key : $context;
            $this->collect_contextual_class_map( $value, $map, $next_context, $depth + 1 );
        }
    }

    private function collect_class_map_from_text( string $text, array &$map ): void {
        if ( preg_match_all( '/["\']id["\']\s*:\s*["\']([^"\']{1,120})["\'][^{}]{0,240}["\']name["\']\s*:\s*["\']([^"\']{1,120})["\']/i', $text, $matches, PREG_SET_ORDER ) ) {
            foreach ( $matches as $match ) {
                $map[ trim( (string) $match[1] ) ] = trim( (string) $match[2] );
            }
        }
        if ( preg_match_all( '/["\']name["\']\s*:\s*["\']([^"\']{1,120})["\'][^{}]{0,240}["\']id["\']\s*:\s*["\']([^"\']{1,120})["\']/i', $text, $matches, PREG_SET_ORDER ) ) {
            foreach ( $matches as $match ) {
                $map[ trim( (string) $match[2] ) ] = trim( (string) $match[1] );
            }
        }
    }

    private function generated_css_chunks(): array {
        $upload = wp_upload_dir();
        $root   = (string) ( $upload['basedir'] ?? '' );
        if ( '' === $root || ! is_dir( $root ) ) {
            return [];
        }

        $chunks = [];
        $files  = 0;
        $bytes  = 0;

        try {
            $iterator = new \RecursiveIteratorIterator(
                new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS )
            );

            foreach ( $iterator as $file ) {
                if ( 80 <= $files || 3000000 <= $bytes ) {
                    break;
                }
                if ( ! $file->isFile() || 'css' !== strtolower( $file->getExtension() ) ) {
                    continue;
                }

                $path = strtolower( str_replace( '\\', '/', $file->getPathname() ) );
                if ( false === strpos( $path, '/bricks/' )
                    && false === strpos( $path, '/automatic' )
                    && false === strpos( $path, '/acss' )
                    && false === strpos( $path, '/core-framework' )
                    && false === strpos( $path, '/advanced-themer' )
                    && false === strpos( $path, '/variable-engine' )
                ) {
                    continue;
                }

                $size = (int) $file->getSize();
                if ( 0 >= $size || 500000 < $size ) {
                    continue;
                }

                $content = file_get_contents( $file->getPathname() );
                if ( false === $content || '' === $content ) {
                    continue;
                }

                $chunks[] = substr( $content, 0, 250000 );
                $files++;
                $bytes += $size;
            }
        } catch ( \Throwable $e ) {
            return $chunks;
        }

        return $chunks;
    }

    /**
     * Read Automatic.css's compiled public CSS without scanning unrelated
     * plugin/theme sources. ACSS commonly writes under uploads/automatic-css;
     * some versions serve the compiled public/css/automatic*.css file from the
     * plugin itself. Both locations are provider-owned output, not source SCSS.
     */
    private function automatic_css_compiled_chunks(): array {
        $roots = [];
        $upload = wp_upload_dir();
        $upload_root = (string) ( $upload['basedir'] ?? '' );
        if ( '' !== $upload_root && is_dir( $upload_root ) ) {
            $roots[] = [ 'root' => $upload_root, 'kind' => 'uploads' ];
        }

        if ( defined( 'WP_PLUGIN_DIR' ) && is_dir( WP_PLUGIN_DIR ) ) {
            try {
                foreach ( new \DirectoryIterator( WP_PLUGIN_DIR ) as $plugin ) {
                    if ( ! $plugin->isDir() || $plugin->isDot() ) {
                        continue;
                    }
                    if ( preg_match( '/(?:automatic[-_]?css|automaticcss|^acss$)/i', $plugin->getFilename() ) ) {
                        $roots[] = [ 'root' => $plugin->getPathname(), 'kind' => 'plugin' ];
                    }
                }
            } catch ( \Throwable $e ) {
                // Registered settings still provide suggestions when unreadable.
            }
        }

        $chunks = [];
        $files = 0;
        $bytes = 0;
        foreach ( $roots as $record ) {
            if ( 40 <= $files || 2500000 <= $bytes ) {
                break;
            }
            try {
                $iterator = new \RecursiveIteratorIterator(
                    new \RecursiveDirectoryIterator( $record['root'], \FilesystemIterator::SKIP_DOTS )
                );
                foreach ( $iterator as $file ) {
                    if ( 40 <= $files || 2500000 <= $bytes ) {
                        break 2;
                    }
                    if ( ! $file->isFile() || 'css' !== strtolower( $file->getExtension() ) ) {
                        continue;
                    }
                    $path = strtolower( str_replace( '\\', '/', $file->getPathname() ) );
                    if ( 'uploads' === $record['kind'] ) {
                        if ( false === strpos( $path, '/automatic-css/' )
                            && false === strpos( $path, '/automatic_css/' )
                            && false === strpos( $path, '/acss/' )
                        ) {
                            continue;
                        }
                    } elseif ( false === strpos( $path, '/public/css/' )
                        || ! preg_match( '/\/automatic(?:-[a-z0-9_-]+)?(?:\.min)?\.css$/', $path )
                    ) {
                        continue;
                    }
                    $size = (int) $file->getSize();
                    if ( 0 >= $size || 750000 < $size ) {
                        continue;
                    }
                    $content = file_get_contents( $file->getPathname() );
                    if ( false === $content || '' === trim( $content ) ) {
                        continue;
                    }
                    $chunks[] = substr( $content, 0, 500000 );
                    $files++;
                    $bytes += $size;
                }
            } catch ( \Throwable $e ) {
                continue;
            }
        }
        return $chunks;
    }

    private function is_internal_css_variable( string $name ): bool {
        foreach ( [ '--wp-', '--wp--', '--gutenberg-', '--bricks-', '--ve-', '--baqa-', '--gform-' ] as $prefix ) {
            if ( 0 === strpos( $name, $prefix ) ) {
                return true;
            }
        }
        return false;
    }

    private function custom_table_chunks(): array {
        global $wpdb;

        $chunks = [];
        $tables = $wpdb->get_col( 'SHOW TABLES' ) ?: [];
        $files  = 0;
        $bytes  = 0;

        foreach ( $tables as $table ) {
            if ( 10 <= $files || 3000000 <= $bytes ) {
                break;
            }

            $table = (string) $table;
            if ( ! preg_match( '/^[A-Za-z0-9_]+$/', $table ) ) {
                continue;
            }

            $lower = strtolower( $table );
            if ( ! preg_match( '/(wpcodebox|code_snippets|codesnippets|snippet|bricks|advanced[-_]?themer|automatic[-_]?css|automaticcss|acss|core[-_]?framework|code2bricks|etch|wpcb)/', $lower ) ) {
                continue;
            }

            try {
                $columns = $wpdb->get_results( 'DESCRIBE ' . $this->quote_identifier( $table ), ARRAY_A ) ?: [];
                $text_columns = [];

                foreach ( $columns as $column ) {
                    $field = (string) ( $column['Field'] ?? '' );
                    $type  = strtolower( (string) ( $column['Type'] ?? '' ) );
                    if ( '' === $field || ! preg_match( '/^[A-Za-z0-9_]+$/', $field ) ) {
                        continue;
                    }
                    if ( preg_match( '/(char|text|json)/', $type ) ) {
                        $text_columns[] = $field;
                    }
                    if ( 8 <= count( $text_columns ) ) {
                        break;
                    }
                }

                if ( empty( $text_columns ) ) {
                    continue;
                }

                $quoted_columns = array_map( [ $this, 'quote_identifier' ], $text_columns );
                $rows = $wpdb->get_results(
                    'SELECT ' . implode( ', ', $quoted_columns ) . ' FROM ' . $this->quote_identifier( $table ) . ' LIMIT 80',
                    ARRAY_A
                ) ?: [];

                foreach ( $rows as $row ) {
                    foreach ( $text_columns as $column ) {
                        if ( 3000000 <= $bytes ) {
                            break 3;
                        }
                        $value = $row[ $column ] ?? '';
                        if ( ! is_scalar( $value ) ) {
                            continue;
                        }
                        $value = trim( (string) $value );
                        if ( '' === $value ) {
                            continue;
                        }
                        if ( ! preg_match( '/(--[A-Za-z0-9_-]+|class(?:Name)?|selector|custom[_-]?css|[.#][A-Za-z_][A-Za-z0-9_-]*)/i', $value ) ) {
                            continue;
                        }

                        $size = strlen( $value );
                        if ( 500000 < $size ) {
                            $value = substr( $value, 0, 250000 );
                            $size  = strlen( $value );
                        }

                        $chunks[] = $value;
                        $bytes += $size;
                    }
                }

                $files++;
            } catch ( \Throwable $e ) {
                continue;
            }
        }

        return $chunks;
    }

    private function scan_template_files( array &$classes, array &$ids, array &$vars ): void {
        $roots = [];
        if ( function_exists( 'get_stylesheet_directory' ) ) {
            $roots[] = get_stylesheet_directory();
        }
        if ( function_exists( 'get_template_directory' ) ) {
            $roots[] = get_template_directory();
        }

        $roots = array_values( array_unique( array_filter( $roots ) ) );
        $files = 0;
        $bytes = 0;
        $exts  = [ 'php' => true, 'html' => true, 'htm' => true, 'twig' => true, 'mustache' => true ];

        foreach ( $roots as $root ) {
            if ( 100 <= $files || 3000000 <= $bytes || ! is_string( $root ) || ! is_dir( $root ) ) {
                continue;
            }
            try {
                $iterator = new \RecursiveIteratorIterator(
                    new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS )
                );
                foreach ( $iterator as $file ) {
                    if ( 100 <= $files || 3000000 <= $bytes ) {
                        break 2;
                    }
                    if ( ! $file->isFile() ) {
                        continue;
                    }
                    $ext = strtolower( $file->getExtension() );
                    if ( ! isset( $exts[ $ext ] ) ) {
                        continue;
                    }
                    $path = strtolower( str_replace( '\\', '/', $file->getPathname() ) );
                    if ( false !== strpos( $path, '/vendor/' ) || false !== strpos( $path, '/node_modules/' ) ) {
                        continue;
                    }
                    $size = (int) $file->getSize();
                    if ( 0 >= $size || 350000 < $size ) {
                        continue;
                    }
                    $content = file_get_contents( $file->getPathname() );
                    if ( false === $content || '' === $content ) {
                        continue;
                    }
                    $this->extract_markup_identifiers( substr( $content, 0, 250000 ), $classes, $ids, $vars );
                    $files++;
                    $bytes += $size;
                }
            } catch ( \Throwable $e ) {
                continue;
            }
        }
    }

    private function source_file_chunks(): array {
        $roots = [];
        if ( function_exists( 'get_stylesheet_directory' ) ) {
            $roots[] = get_stylesheet_directory();
        }
        if ( function_exists( 'get_template_directory' ) ) {
            $roots[] = get_template_directory();
        }

        if ( defined( 'WP_PLUGIN_DIR' ) && is_dir( WP_PLUGIN_DIR ) ) {
            try {
                foreach ( new \DirectoryIterator( WP_PLUGIN_DIR ) as $plugin ) {
                    if ( ! $plugin->isDir() || $plugin->isDot() ) {
                        continue;
                    }
                    $name = strtolower( $plugin->getFilename() );
                    if ( preg_match( '/(bricks|automatic|acss|advanced[-_]?themer|core[-_]?framework|wpcodebox|code2bricks|etch)/', $name ) ) {
                        $roots[] = $plugin->getPathname();
                    }
                }
            } catch ( \Throwable $e ) {
                // Keep suggestions available even if a plugin folder cannot be read.
            }
        }

        return $this->read_source_chunks( array_values( array_unique( array_filter( $roots ) ) ) );
    }

    private function source_template_chunks(): array {
        $roots = [];
        if ( function_exists( 'get_stylesheet_directory' ) ) {
            $roots[] = get_stylesheet_directory();
        }
        if ( function_exists( 'get_template_directory' ) ) {
            $roots[] = get_template_directory();
        }

        if ( defined( 'WP_PLUGIN_DIR' ) && is_dir( WP_PLUGIN_DIR ) ) {
            try {
                foreach ( new \DirectoryIterator( WP_PLUGIN_DIR ) as $plugin ) {
                    if ( ! $plugin->isDir() || $plugin->isDot() ) {
                        continue;
                    }
                    $name = strtolower( $plugin->getFilename() );
                    if ( preg_match( '/(bricks|automatic|acss|advanced[-_]?themer|core[-_]?framework|wpcodebox|code2bricks|etch|wpcode)/', $name ) ) {
                        $roots[] = $plugin->getPathname();
                    }
                }
            } catch ( \Throwable $e ) {
                // Keep suggestions available even if optional plugin folders cannot be read.
            }
        }

        return $this->read_template_chunks( array_values( array_unique( array_filter( $roots ) ) ) );
    }

    private function read_source_chunks( array $roots ): array {
        $chunks = [];
        $files  = 0;
        $bytes  = 0;
        $exts   = [ 'css' => true, 'scss' => true, 'less' => true, 'json' => true ];

        foreach ( $roots as $root ) {
            if ( 120 <= $files || 4000000 <= $bytes || ! is_string( $root ) || ! is_dir( $root ) ) {
                continue;
            }

            try {
                $iterator = new \RecursiveIteratorIterator(
                    new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS )
                );

                foreach ( $iterator as $file ) {
                    if ( 120 <= $files || 4000000 <= $bytes ) {
                        break 2;
                    }
                    if ( ! $file->isFile() ) {
                        continue;
                    }

                    $ext = strtolower( $file->getExtension() );
                    if ( ! isset( $exts[ $ext ] ) ) {
                        continue;
                    }

                    $path = strtolower( str_replace( '\\', '/', $file->getPathname() ) );
                    if ( false !== strpos( $path, '/vendor/' )
                        || false !== strpos( $path, '/node_modules/' )
                        || false !== strpos( $path, '/acf-pro/' )
                        || false !== strpos( $path, '/codemirror/' )
                        || false !== strpos( $path, '.min.css' )
                        || false !== strpos( $path, '.min.js' )
                    ) {
                        continue;
                    }

                    $size = (int) $file->getSize();
                    if ( 0 >= $size || 400000 < $size ) {
                        continue;
                    }

                    $content = file_get_contents( $file->getPathname() );
                    if ( false === $content || '' === $content ) {
                        continue;
                    }

                    $chunks[] = substr( $content, 0, 250000 );
                    $files++;
                    $bytes += $size;
                }
            } catch ( \Throwable $e ) {
                continue;
            }
        }

        return $chunks;
    }

    private function read_template_chunks( array $roots ): array {
        $chunks = [];
        $files  = 0;
        $bytes  = 0;
        $exts   = [
            'php' => true,
            'html' => true,
            'htm' => true,
            'twig' => true,
            'mustache' => true,
            'js' => true,
            'jsx' => true,
            'ts' => true,
            'tsx' => true,
            'vue' => true,
            'svelte' => true,
        ];

        foreach ( $roots as $root ) {
            if ( 100 <= $files || 3000000 <= $bytes || ! is_string( $root ) || ! is_dir( $root ) ) {
                continue;
            }

            try {
                $iterator = new \RecursiveIteratorIterator(
                    new \RecursiveDirectoryIterator( $root, \FilesystemIterator::SKIP_DOTS )
                );

                foreach ( $iterator as $file ) {
                    if ( 100 <= $files || 3000000 <= $bytes ) {
                        break 2;
                    }
                    if ( ! $file->isFile() ) {
                        continue;
                    }

                    $ext = strtolower( $file->getExtension() );
                    if ( ! isset( $exts[ $ext ] ) ) {
                        continue;
                    }

                    $path = strtolower( str_replace( '\\', '/', $file->getPathname() ) );
                    if ( false !== strpos( $path, '/vendor/' )
                        || false !== strpos( $path, '/node_modules/' )
                        || false !== strpos( $path, '/acf-pro/' )
                        || false !== strpos( $path, '/codemirror/' )
                        || false !== strpos( $path, '/dist/' )
                        || false !== strpos( $path, '/build/' )
                        || false !== strpos( $path, '/cache/' )
                        || false !== strpos( $path, '.min.js' )
                    ) {
                        continue;
                    }

                    $size = (int) $file->getSize();
                    if ( 0 >= $size || 300000 < $size ) {
                        continue;
                    }

                    $content = file_get_contents( $file->getPathname() );
                    if ( false === $content || '' === $content ) {
                        continue;
                    }

                    if ( ! preg_match( '/(class(?:Name)?|classList|querySelector|closest|matches|\\bid\\s*[:=]|--[A-Za-z][A-Za-z0-9_-]*|var\\s*\\()/i', $content ) ) {
                        continue;
                    }

                    $chunks[] = substr( $content, 0, 220000 );
                    $files++;
                    $bytes += $size;
                }
            } catch ( \Throwable $e ) {
                continue;
            }
        }

        return $chunks;
    }

    private function quote_identifier( string $identifier ): string {
        return '`' . str_replace( '`', '``', $identifier ) . '`';
    }

    private function extract_identifiers_from_data( $data, array &$classes, array &$ids, array &$vars, array $class_map = [], string $parent_key = '', int $depth = 0 ): void {
        if ( 8 < $depth ) {
            return;
        }

        if ( is_object( $data ) ) {
            $data = (array) $data;
        }

        if ( ! is_array( $data ) ) {
            if ( '' !== $parent_key ) {
                $this->extract_identifier_value( $parent_key, $data, $classes, $ids, $vars, $class_map );
            }
            return;
        }

        foreach ( $data as $key => $value ) {
            $key_string = is_string( $key ) ? $key : $parent_key;
            if ( '' !== $key_string ) {
                $this->extract_identifier_value( $key_string, $value, $classes, $ids, $vars, $class_map, $parent_key );
            }

            if ( is_array( $value ) || is_object( $value ) ) {
                $this->extract_structured_item( $value, $classes, $ids, $vars, $class_map, $key_string );
                $this->extract_identifiers_from_data( $value, $classes, $ids, $vars, $class_map, $key_string, $depth + 1 );
            }
        }
    }

    private function extract_structured_item( $value, array &$classes, array &$ids, array &$vars, array $class_map, string $context ): void {
        if ( is_object( $value ) ) {
            $value = (array) $value;
        }
        if ( ! is_array( $value ) ) {
            return;
        }

        $context = strtolower( $context );
        $class_context = false !== strpos( $context, 'class' ) || false !== strpos( $context, 'globalclasses' );
        $var_context   = false !== strpos( $context, 'variable' ) || false !== strpos( $context, 'token' ) || false !== strpos( $context, 'cssvar' );

        foreach ( [ 'name', 'label', 'title', 'selector', 'class', 'className', 'class_name', 'slug' ] as $field ) {
            if ( isset( $value[ $field ] ) && ( $class_context || in_array( $field, [ 'selector', 'class', 'className', 'class_name' ], true ) ) ) {
                $raw = (string) $value[ $field ];
                foreach ( preg_split( '/[\s,]+/', $raw ) ?: [] as $part ) {
                    $part = ltrim( trim( $part ), '.' );
                    $this->add_identifier( $classes, $class_map[ $part ] ?? $part, '.' );
                }
            }
        }

        foreach ( [ 'id', '_id', 'elementId', 'anchor', 'cssId' ] as $field ) {
            if ( isset( $value[ $field ] ) && false !== strpos( strtolower( $field ), 'id' ) ) {
                $this->add_identifier( $ids, ltrim( (string) $value[ $field ], '#' ), '#' );
            }
        }

        foreach ( [ 'var', 'variable', 'cssVar', 'css_var', 'token', 'name', 'id' ] as $field ) {
            if ( isset( $value[ $field ] ) && $var_context ) {
                $this->add_css_variable( $vars, (string) $value[ $field ] );
            }
        }
    }

    private function extract_identifier_value( string $key, $value, array &$classes, array &$ids, array &$vars, array $class_map = [], string $parent_key = '' ): void {
        $key_l = strtolower( $key );
        $parent_l = strtolower( $parent_key );
        $is_class_key = false !== strpos( $key_l, 'class' ) || false !== strpos( $parent_l, 'class' );
        $is_id_key    = 'id' === $key_l || false !== strpos( $key_l, '_id' ) || false !== strpos( $key_l, '-id' ) || false !== strpos( $key_l, 'id_' );
        $is_var_key   = false !== strpos( $key_l, 'variable' ) || false !== strpos( $key_l, 'cssvar' ) || false !== strpos( $key_l, 'css_var' ) || false !== strpos( $key_l, 'token' ) || false !== strpos( $parent_l, 'variable' ) || false !== strpos( $parent_l, 'token' );

        if ( ! $is_class_key && ! $is_id_key && ! $is_var_key ) {
            return;
        }

        if ( is_array( $value ) || is_object( $value ) ) {
            $value = wp_json_encode( $value );
        }

        $value = trim( (string) $value );
        if ( '' === $value || 2000 < strlen( $value ) ) {
            return;
        }

        $tokens = preg_split( '/[\s,"\':;\[\]\{\}]+/', $value ) ?: [];
        foreach ( $tokens as $token ) {
            $token = trim( $token );
            if ( '' === $token ) {
                continue;
            }
            if ( $is_class_key ) {
                $token = ltrim( $token, '.' );
                $this->add_identifier( $classes, $class_map[ $token ] ?? $token, '.' );
            }
            if ( $is_id_key ) {
                $this->add_identifier( $ids, ltrim( $token, '#' ), '#' );
            }
            if ( $is_var_key || 0 === strpos( $token, '--' ) ) {
                $this->add_css_variable( $vars, $token );
            }
        }
    }

    private function sorted_keys( array $items ): array {
        $items = array_values( array_unique( array_filter( $items ) ) );
        natcasesort( $items );
        return array_values( array_slice( $items, 0, 10000 ) );
    }

    private function file_path(): string {
        return VE_CSS_OUTPUT_DIR . 'advanced.css';
    }

    private function file_url(): string {
        return VE_CSS_OUTPUT_URL . 'advanced.css';
    }
}
