<?php

namespace VE\Modules\Recovery\Backup;

use VE\Modules\Recovery\Restore\SelfProtection;

defined( 'ABSPATH' ) || exit;

final class DatabaseExporter {
    private int $rows_per_batch;

    public function __construct( int $rows_per_batch = 100 ) {
        $this->rows_per_batch = max( 25, min( 500, absint( $rows_per_batch ) ) );
    }

    public function export( string $path ): array {
        global $wpdb;

        if ( function_exists( 'set_time_limit' ) ) {
            @set_time_limit( 0 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        }

        $dir = dirname( $path );
        if ( ! is_dir( $dir ) ) {
            wp_mkdir_p( $dir );
        }

        // Fast path: native mysqldump. Toggled from the Backup options UI (stored
        // option), still overridable by filter; silently falls back to the PHP
        // exporter below on any failure.
        if ( apply_filters( 'restorebase_enable_mysqldump', (bool) get_option( 'restorebase_enable_mysqldump', true ) ) ) {
            $fast = $this->try_mysqldump( $path );
            if ( ! empty( $fast['ok'] ) ) {
                return $fast;
            }
        }

        $handle = fopen( $path, 'wb' ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fopen
        if ( false === $handle ) {
            return [
                'ok'      => false,
                'message' => 'Database export file could not be opened.',
                'path'    => '',
                'hash'    => '',
                'size'    => 0,
                'tables'  => 0,
                'rows'    => 0,
            ];
        }

        $tables = $this->tables();
        $row_total = 0;

        /* C78. mysqldump above is called with `--single-transaction`; this path
           had no transaction at all, so on a site that was being used during the
           export the dump was consistent with no moment in time - orders without
           their items, posts without their meta. One repeatable-read snapshot
           gives the fallback the same guarantee the fast path already had. It
           only ever reads, so the close is a commit either way. */
        $snapshot = false !== $wpdb->query( 'SET SESSION TRANSACTION ISOLATION LEVEL REPEATABLE READ' ) // phpcs:ignore WordPress.DB.DirectDatabaseQuery
            && false !== $wpdb->query( 'START TRANSACTION WITH CONSISTENT SNAPSHOT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery

        $this->write( $handle, "-- RestoreBase database export\n" );
        $this->write( $handle, "-- Generated: " . gmdate( 'c' ) . "\n" );
        $this->write( $handle, "-- Site: " . site_url() . "\n\n" );
        $this->write( $handle, "SET SQL_MODE = \"NO_AUTO_VALUE_ON_ZERO\";\n" );
        $this->write( $handle, "SET time_zone = \"+00:00\";\n\n" );

        foreach ( $tables as $table ) {
            $table = (string) $table;
            $quoted = $this->quote_identifier( $table );
            $create = $wpdb->get_row( 'SHOW CREATE TABLE ' . $quoted, ARRAY_N ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

            if ( ! is_array( $create ) || empty( $create[1] ) ) {
                continue;
            }

            $this->write( $handle, "\n-- Table: {$table}\n" );
            $this->write( $handle, "DROP TABLE IF EXISTS {$quoted};\n" );
            $this->write( $handle, $create[1] . ";\n\n" );

            /* C78. `LIMIT n OFFSET m` makes the database count past every row it
               has already handed over, so the last page of a large table costs
               far more than the first - and a row inserted or deleted mid-export
               shifts the window, which is how a paged read skips or repeats rows.
               Walking the primary key does neither: each page starts exactly
               where the last one ended. Tables without a single-column key still
               use OFFSET, because there is nothing better to walk. */
            $key = $this->paging_key( $table );

            if ( '' !== $key ) {
                $quoted_key = $this->quote_identifier( $key );
                $last       = null;
                while ( true ) {
                    $sql = null === $last
                        ? $wpdb->prepare( 'SELECT * FROM ' . $quoted . ' ORDER BY ' . $quoted_key . ' ASC LIMIT %d', $this->rows_per_batch ) // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                        : $wpdb->prepare( 'SELECT * FROM ' . $quoted . ' WHERE ' . $quoted_key . ' > %s ORDER BY ' . $quoted_key . ' ASC LIMIT %d', $last, $this->rows_per_batch ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                    $rows = $wpdb->get_results( $sql, ARRAY_A );
                    if ( ! is_array( $rows ) || [] === $rows ) {
                        break;
                    }
                    $row_total += $this->write_rows( $handle, $quoted, $rows );
                    $tail = end( $rows );
                    if ( ! is_array( $tail ) || ! array_key_exists( $key, $tail ) ) {
                        break;   // the key vanished from the result: stop rather than loop
                    }
                    $last = $tail[ $key ];
                }
            } else {
                $count = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $quoted ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared

                for ( $offset = 0; $offset < $count; $offset += $this->rows_per_batch ) {
                    $rows = $wpdb->get_results(
                        $wpdb->prepare( 'SELECT * FROM ' . $quoted . ' LIMIT %d OFFSET %d', $this->rows_per_batch, $offset ), // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
                        ARRAY_A
                    );

                    if ( ! is_array( $rows ) || [] === $rows ) {
                        continue;
                    }

                    $row_total += $this->write_rows( $handle, $quoted, $rows );
                }
            }
        }

        if ( $snapshot ) {
            $wpdb->query( 'COMMIT' ); // phpcs:ignore WordPress.DB.DirectDatabaseQuery
        }

        fclose( $handle ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose

        return [
            'ok'      => true,
            'message' => 'Database exported.',
            'method'  => 'php',
            // Said out loud: a dump taken without a snapshot is still a dump, and
            // whoever restores it should be able to know which kind it was.
            'consistent' => $snapshot,
            'path'    => $path,
            'hash'    => is_readable( $path ) ? (string) hash_file( 'sha256', $path ) : '',
            'size'    => file_exists( $path ) ? (int) filesize( $path ) : 0,
            'tables'  => count( $tables ),
            'rows'    => $row_total,
        ];
    }

    /**
     * One page of rows, written. Returns how many.
     *
     * Shared by both paging strategies so the two can never write rows in
     * different shapes.
     */
    private function write_rows( $handle, string $quoted, array $rows ): int {
        $written = 0;
        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }
            $columns = array_map( [ $this, 'quote_identifier' ], array_keys( $row ) );
            $values  = array_map( [ $this, 'sql_value' ], array_values( $row ) );
            $this->write( $handle, 'INSERT INTO ' . $quoted . ' (' . implode( ',', $columns ) . ') VALUES (' . implode( ',', $values ) . ");\n" );
            $written++;
        }
        return $written;
    }

    /**
     * A column this table can be walked by, or '' if there is not one.
     *
     * A single-column PRIMARY KEY only. A composite key cannot be walked with a
     * single `>` comparison, and walking it wrongly would silently skip rows -
     * which is worse than the OFFSET paging it would be replacing.
     */
    private function paging_key( string $table ): string {
        global $wpdb;

        $keys = $wpdb->get_results( 'SHOW KEYS FROM ' . $this->quote_identifier( $table ) . " WHERE Key_name = 'PRIMARY'", ARRAY_A ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        if ( ! is_array( $keys ) || 1 !== count( $keys ) ) {
            return '';
        }
        $column = (string) ( $keys[0]['Column_name'] ?? '' );
        return '' !== $column ? $column : '';
    }

    /**
     * Native mysqldump fast path. Returns ['ok'=>false] on any problem so the
     * caller transparently falls back to the PHP exporter.
     *
     * Safety: credentials go in a 0600 --defaults-extra-file, never on argv; the
     * command is passed to proc_open as an array (no shell), and only prefixed,
     * non-RestoreBase tables are dumped. --skip-extended-insert keeps the output
     * shape compatible with the SQL importer.
     */
    private function try_mysqldump( string $path ): array {
        global $wpdb;

        if ( ! function_exists( 'proc_open' ) ) {
            return [ 'ok' => false ];
        }
        $disabled = array_map( 'trim', explode( ',', (string) ini_get( 'disable_functions' ) ) );
        if ( in_array( 'proc_open', $disabled, true ) ) {
            return [ 'ok' => false ];
        }
        if ( ! defined( 'DB_NAME' ) || ! defined( 'DB_USER' ) || ! defined( 'DB_HOST' ) ) {
            return [ 'ok' => false ];
        }

        $tables = $this->tables();
        if ( [] === $tables ) {
            return [ 'ok' => false ];
        }

        $binary = (string) apply_filters( 'restorebase_mysqldump_binary', 'mysqldump' );
        [ $host, $port, $socket ] = $this->parse_db_host( (string) DB_HOST );

        // Credentials via a temporary 0600 defaults file (not argv / not env).
        $cnf = dirname( $path ) . '/.rb-mysqldump-' . wp_generate_password( 8, false, false ) . '.cnf';
        $cnf_body = "[client]\n"
            . 'user=' . (string) DB_USER . "\n"
            . 'password=' . ( defined( 'DB_PASSWORD' ) ? (string) DB_PASSWORD : '' ) . "\n"
            . 'host=' . $host . "\n"
            . ( $port ? 'port=' . $port . "\n" : '' )
            . ( $socket ? 'socket=' . $socket . "\n" : '' );
        if ( false === file_put_contents( $cnf, $cnf_body ) ) { // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_put_contents
            return [ 'ok' => false ];
        }
        @chmod( $cnf, 0600 ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

        $charset = $wpdb->charset ? (string) $wpdb->charset : 'utf8mb4';
        $cmd = array_merge(
            [
                $binary,
                '--defaults-extra-file=' . $cnf,
                '--single-transaction',
                '--quick',
                '--skip-extended-insert',
                '--skip-comments',
                '--skip-lock-tables',
                '--no-tablespaces',
                '--add-drop-table',
                '--hex-blob',
                '--default-character-set=' . $charset,
                (string) DB_NAME,
            ],
            array_map( 'strval', $tables )
        );

        $descriptors = [ 0 => [ 'pipe', 'r' ], 1 => [ 'file', $path, 'w' ], 2 => [ 'pipe', 'w' ] ];
        $pipes = [];
        $proc = @proc_open( $cmd, $descriptors, $pipes ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        if ( ! is_resource( $proc ) ) {
            @unlink( $cnf ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink
            return [ 'ok' => false ];
        }
        $stderr = is_resource( $pipes[2] ) ? (string) stream_get_contents( $pipes[2] ) : '';
        if ( is_resource( $pipes[2] ) ) { fclose( $pipes[2] ); }
        $exit = proc_close( $proc );
        @unlink( $cnf ); // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged, WordPress.WP.AlternativeFunctions.unlink_unlink

        // Validate: clean exit, non-trivial file, and it actually contains DDL.
        $size = file_exists( $path ) ? (int) filesize( $path ) : 0;
        if ( 0 !== $exit || $size < 128 ) {
            \VE\Modules\Recovery\Utils\Logger::warning( 'mysqldump_fallback', 'mysqldump failed; using PHP exporter.', [ 'exit' => $exit, 'stderr' => substr( $stderr, 0, 300 ) ] );
            return [ 'ok' => false ];
        }
        $head = (string) file_get_contents( $path, false, null, 0, 65536 ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_file_get_contents
        if ( false === stripos( $head, 'CREATE TABLE' ) ) {
            return [ 'ok' => false ];
        }

        $row_total = 0;
        foreach ( $tables as $table ) {
            $row_total += (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $this->quote_identifier( (string) $table ) ); // phpcs:ignore WordPress.DB.PreparedSQL.NotPrepared
        }

        return [
            'ok'      => true,
            'message' => 'Database exported (mysqldump).',
            'method'  => 'mysqldump',
            'path'    => $path,
            'hash'    => is_readable( $path ) ? (string) hash_file( 'sha256', $path ) : '',
            'size'    => $size,
            'tables'  => count( $tables ),
            'rows'    => $row_total,
        ];
    }

    /** @return array{0:string,1:string,2:string} [host, port, socket] */
    private function parse_db_host( string $db_host ): array {
        $host = $db_host;
        $port = '';
        $socket = '';
        if ( false !== strpos( $db_host, ':' ) ) {
            [ $host, $tail ] = explode( ':', $db_host, 2 );
            if ( ctype_digit( $tail ) ) {
                $port = $tail;
            } else {
                $socket = $tail;
            }
        }
        return [ $host !== '' ? $host : 'localhost', $port, $socket ];
    }

    private function tables(): array {
        global $wpdb;

        $like = $wpdb->esc_like( $wpdb->prefix ) . '%';
        $tables = $wpdb->get_col( $wpdb->prepare( 'SHOW TABLES LIKE %s', $like ) );
        if ( ! is_array( $tables ) ) {
            return [];
        }

        return array_values( array_filter( $tables, static function ( $table ) {
            return ! SelfProtection::is_restorebase_table( (string) $table );
        } ) );
    }

    private function quote_identifier( string $identifier ): string {
        return '`' . str_replace( '`', '``', $identifier ) . '`';
    }

    private function sql_value( $value ): string {
        if ( null === $value ) {
            return 'NULL';
        }

        return "'" . esc_sql( (string) $value ) . "'";
    }

    private function write( $handle, string $contents ): void {
        fwrite( $handle, $contents ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite
    }
}
