<?php
namespace VE\Sync;

use VE\Database\Schema;
use VE\Core\VariableManager;
use VE\Core\CssExporter;
use VE\Core\ThemeManager;
use VE\Core\ColorPaletteManager;

defined('ABSPATH') || exit;

/**
 * SnapshotManager — captures full variable state before sync operations.
 * Enables rollback if a sync goes wrong.
 */
class SnapshotManager {

    private const STATE_VERSION = 4;

    /** Recovery points retained; older ones are auto-pruned after each create. */
    private const MAX_SNAPSHOTS = 20;

    /**
     * Create a snapshot of all current variables.
     *
     * @param string $trigger 'manual' | 'pre_import' | 'pre_export'
     * @param array  $context Optional human-readable snapshot context.
     * @return int|\WP_Error Snapshot ID or an error when the state could not be captured
     */
    public function create( string $trigger = 'manual', array $context = [] ) {
        global $wpdb;

        $variables = $wpdb->get_results(
            'SELECT * FROM ' . Schema::table('variables') . ' ORDER BY id ASC',
            ARRAY_A
        );
        $dependencies = $wpdb->get_results(
            'SELECT * FROM ' . Schema::table('dependencies') . ' ORDER BY id ASC',
            ARRAY_A
        );
        $generators = $wpdb->get_results(
            'SELECT * FROM ' . Schema::table('generators') . ' ORDER BY id ASC',
            ARRAY_A
        );
        $color_palettes = $wpdb->get_results(
            'SELECT * FROM ' . Schema::table('color_palettes') . ' ORDER BY position ASC, id ASC',
            ARRAY_A
        );
        $color_palette_members = $wpdb->get_results(
            'SELECT * FROM ' . Schema::table('color_palette_members') . ' ORDER BY palette_id ASC, position ASC, id ASC',
            ARRAY_A
        );
        $variable_categories = $wpdb->get_results(
            'SELECT * FROM ' . Schema::table('variable_categories') . ' ORDER BY position ASC, id ASC',
            ARRAY_A
        );

        if ( null === $variables || null === $dependencies || null === $generators || null === $color_palettes || null === $color_palette_members || null === $variable_categories ) {
            return new \WP_Error(
                've_snapshot_read_failed',
                'Could not read the complete variable state for the snapshot.',
                [ 'status' => 500, 'database_error' => $wpdb->last_error ]
            );
        }

        $state = [
            'version'      => self::STATE_VERSION,
            'meta'         => $this->sanitize_context( $context ),
            'variables'    => $variables,
            'dependencies' => $dependencies,
            'generators'   => $generators,
            'themes'       => ( new ThemeManager() )->snapshot_state(),
            'color_palettes' => $color_palettes,
            'color_palette_members' => $color_palette_members,
            'variable_categories' => $variable_categories,
        ];
        $encoded = wp_json_encode( $state );
        if ( false === $encoded || '' === $encoded ) {
            return new \WP_Error(
                've_snapshot_encode_failed',
                'Could not encode the complete variable state for the snapshot.',
                [ 'status' => 500 ]
            );
        }

        // De-dupe: if the most recent snapshot already captures this exact
        // state, reuse it instead of stacking an identical recovery point.
        // This safely collapses back-to-back "Before import" snapshots created
        // moments apart (same state = same rollback target) without ever
        // reusing a snapshot whose state differs.
        $latest = $wpdb->get_row(
            'SELECT id, variables_state FROM ' . Schema::table('snapshots') . ' ORDER BY id DESC LIMIT 1',
            ARRAY_A
        );
        if ( $latest && (string) ( $latest['variables_state'] ?? '' ) === (string) $encoded ) {
            return (int) $latest['id'];
        }

        $inserted = $wpdb->insert(
            Schema::table('snapshots'),
            [
                'variables_state' => $encoded,
                'trigger_type'    => $trigger,
            ],
            ['%s', '%s']
        );

        if ( false === $inserted ) {
            return new \WP_Error(
                've_snapshot_create_failed',
                'Could not create the safety snapshot.',
                [ 'status' => 500, 'database_error' => $wpdb->last_error ]
            );
        }

        $new_id = (int) $wpdb->insert_id;
        $this->prune();
        return $new_id;
    }

    /**
     * Delete a single snapshot by id.
     */
    public function delete( int $snapshot_id ): bool {
        global $wpdb;
        if ( $snapshot_id <= 0 ) {
            return false;
        }
        $deleted = $wpdb->delete( Schema::table('snapshots'), [ 'id' => $snapshot_id ], [ '%d' ] );
        return false !== $deleted && $deleted > 0;
    }

    /**
     * Keep only the most recent $keep snapshots; delete anything older.
     * Runs automatically after each create so recovery points stay bounded.
     */
    public function prune( int $keep = self::MAX_SNAPSHOTS ): int {
        global $wpdb;
        $keep  = max( 1, $keep );
        $table = Schema::table('snapshots');
        // Everything past the newest $keep rows (LIMIT offset, big-count).
        $ids = $wpdb->get_col( $wpdb->prepare(
            "SELECT id FROM {$table} ORDER BY id DESC LIMIT %d, 18446744073709551615",
            $keep
        ) );
        $ids = array_values( array_filter( array_map( 'intval', (array) $ids ) ) );
        if ( empty( $ids ) ) {
            return 0;
        }
        $placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE id IN ({$placeholders})", $ids ) );
        return count( $ids );
    }

    /**
     * Restore variables from a snapshot.
     * Deletes all current variables and recreates from snapshot state.
     *
     * @param int $snapshot_id
     * @return array|\WP_Error Restored state or an error on failure
     */
    public function rollback( int $snapshot_id ) {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . Schema::table('snapshots') . ' WHERE id = %d',
                $snapshot_id
            ),
            ARRAY_A
        );

        if ( ! $row ) {
            return new \WP_Error( 've_snapshot_not_found', 'Snapshot not found.', [ 'status' => 404 ] );
        }

        $state = $this->decode_state( (string) $row['variables_state'] );
        if ( is_wp_error( $state ) ) {
            return $state;
        }

        // Create a pre-rollback snapshot for safety.
        $safety_snapshot = $this->create( 'pre_rollback', [
            'title'       => 'Before restoring snapshot #' . $snapshot_id,
            'description' => 'Automatic recovery point created before restoring an older variable state.',
            'source'      => 'snapshot',
        ] );
        if ( is_wp_error( $safety_snapshot ) ) {
            return $safety_snapshot;
        }

        $vars_table = Schema::table('variables');
        $deps_table = Schema::table('dependencies');
        $gens_table = Schema::table('generators');
        $palettes_table = Schema::table('color_palettes');
        $members_table = Schema::table('color_palette_members');
        $categories_table = Schema::table('variable_categories');

        if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
            return new \WP_Error(
                've_snapshot_transaction_failed',
                'Snapshot restore could not start a database transaction, so no variables were changed.',
                [
                    'status'             => 500,
                    'database_error'     => $wpdb->last_error,
                    'safety_snapshot_id' => (int) $safety_snapshot,
                ]
            );
        }

        try {
            $this->must_query( "DELETE FROM {$deps_table}" );
            $this->must_query( "DELETE FROM {$gens_table}" );
            $this->must_query( "DELETE FROM {$members_table}" );
            $this->must_query( "DELETE FROM {$palettes_table}" );
            $this->must_query( "DELETE FROM {$categories_table}" );
            $this->must_query( "DELETE FROM {$vars_table}" );

            foreach ( $state['variable_categories'] as $category ) {
                $this->restore_variable_category( $categories_table, $category );
            }
            foreach ( $state['variables'] as $variable ) {
                $this->restore_variable( $vars_table, $variable );
            }
            foreach ( $state['generators'] as $generator ) {
                $this->restore_generator( $gens_table, $generator );
            }
            foreach ( $state['dependencies'] as $dependency ) {
                $this->restore_dependency( $deps_table, $dependency );
            }
            foreach ( $state['color_palettes'] as $palette ) {
                $this->restore_color_palette( $palettes_table, $palette );
            }
            foreach ( $state['color_palette_members'] as $member ) {
                $this->restore_color_palette_member( $members_table, $member );
            }
            if ( isset( $state['themes'] ) && is_array( $state['themes'] ) ) {
                ( new ThemeManager() )->restore_snapshot_state( $state['themes'] );
            }
            ( new ColorPaletteManager() )->repair_memberships();

            if ( ! ( new CssExporter() )->export() ) {
                throw new \RuntimeException( 'The restored CSS file could not be written.' );
            }

            $this->must_query( 'COMMIT' );
        } catch ( \Throwable $e ) {
            $wpdb->query( 'ROLLBACK' );
            ( new CssExporter() )->export();
            return new \WP_Error(
                've_snapshot_restore_failed',
                'Snapshot restore failed and the database changes were rolled back.',
                [
                    'status'         => 500,
                    'detail'         => $e->getMessage(),
                    'database_error' => $wpdb->last_error,
                    'safety_snapshot_id' => (int) $safety_snapshot,
                ]
            );
        }

        return [
            'variables'          => $state['variables'],
            'dependencies'       => $state['dependencies'],
            'generators'         => $state['generators'],
            'themes'             => $state['themes'],
            'color_palettes'     => $state['color_palettes'],
            'color_palette_members' => $state['color_palette_members'],
            'variable_categories' => $state['variable_categories'],
            'safety_snapshot_id' => (int) $safety_snapshot,
            'state_version'      => (int) $state['version'],
        ];
    }

    private function decode_state( string $json ) {
        $decoded = json_decode( $json, true );
        if ( ! is_array( $decoded ) ) {
            return new \WP_Error( 've_snapshot_invalid', 'Snapshot data is invalid.', [ 'status' => 422 ] );
        }

        // Version 1 snapshots stored only the variable array. They are safe to
        // restore only when no generated/alias relationships need reconstructing.
        if ( ! isset( $decoded['version'] ) ) {
            foreach ( $decoded as $variable ) {
                if ( ! is_array( $variable ) || 'base' !== ( $variable['type'] ?? 'base' ) ) {
                    return new \WP_Error(
                        've_snapshot_legacy_incomplete',
                        'This legacy snapshot does not contain dependency and generator state, so it cannot be restored safely.',
                        [ 'status' => 409 ]
                    );
                }
            }

            $legacy_state = [
                'version'      => 1,
                'variables'    => $decoded,
                'dependencies' => [],
                'generators'   => [],
                'themes'       => null,
                'color_palettes' => [],
                'color_palette_members' => [],
                'variable_categories' => $this->default_category_state(),
            ];
            $integrity_error = $this->validate_state( $legacy_state );
            return $integrity_error ?: $legacy_state;
        }

        $version = (int) $decoded['version'];
        if (
            ! in_array( $version, [ 2, 3, self::STATE_VERSION ], true )
            || ! isset( $decoded['variables'], $decoded['dependencies'], $decoded['generators'] )
            || ! is_array( $decoded['variables'] )
            || ! is_array( $decoded['dependencies'] )
            || ! is_array( $decoded['generators'] )
        ) {
            return new \WP_Error( 've_snapshot_unsupported', 'Snapshot format is incomplete or unsupported.', [ 'status' => 422 ] );
        }

        if ( 2 === $version ) {
            $decoded['themes'] = null;
            $decoded['color_palettes'] = [];
            $decoded['color_palette_members'] = [];
            $decoded['variable_categories'] = $this->default_category_state();
        } elseif ( 3 === $version ) {
            $decoded['variable_categories'] = $this->default_category_state();
            foreach ( $decoded['variables'] as &$variable ) {
                $variable['category_slug'] = 'uncategorized';
                $variable['origin'] = (string) ( $variable['origin'] ?? '' );
            }
            unset( $variable );
        } elseif (
            ! isset( $decoded['themes'], $decoded['color_palettes'], $decoded['color_palette_members'], $decoded['variable_categories'] )
            || ! is_array( $decoded['themes'] )
            || ! is_array( $decoded['color_palettes'] )
            || ! is_array( $decoded['color_palette_members'] )
            || ! is_array( $decoded['variable_categories'] )
        ) {
            return new \WP_Error( 've_snapshot_unsupported', 'Snapshot palette or theme state is incomplete.', [ 'status' => 422 ] );
        }

        $integrity_error = $this->validate_state( $decoded );
        return $integrity_error ?: $decoded;
    }

    private function validate_state( array $state ): ?\WP_Error {
        $ids = [];
        $names = [];
        $variables_by_id = [];
        $category_slugs = [];
        foreach ( $state['variable_categories'] as $category ) {
            $slug = sanitize_key( (string) ( $category['slug'] ?? '' ) );
            if ( '' === $slug || isset( $category_slugs[ $slug ] ) ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains an invalid variable category.', [ 'status' => 422 ] );
            }
            $category_slugs[ $slug ] = true;
        }
        if ( ! isset( $category_slugs['uncategorized'] ) ) {
            return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot is missing the Uncategorized variable category.', [ 'status' => 422 ] );
        }

        foreach ( $state['variables'] as $variable ) {
            $id = (int) ( $variable['id'] ?? 0 );
            $name = (string) ( $variable['name'] ?? '' );
            $type = (string) ( $variable['type'] ?? 'base' );
            if (
                $id <= 0
                || '' === $name
                || ! in_array( $type, [ 'base', 'generated', 'alias' ], true )
                || isset( $ids[ $id ] )
                || isset( $names[ $name ] )
                || ! isset( $category_slugs[ sanitize_key( (string) ( $variable['category_slug'] ?? 'uncategorized' ) ) ] )
            ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains duplicate or invalid variable identity.', [ 'status' => 422 ] );
            }
            $ids[ $id ] = true;
            $names[ $name ] = true;
            $variables_by_id[ $id ] = $variable;
        }

        foreach ( $variables_by_id as $id => $variable ) {
            $type = (string) ( $variable['type'] ?? 'base' );
            $source_id = (int) ( $variable['source_id'] ?? 0 );
            if ( in_array( $type, [ 'generated', 'alias' ], true ) ) {
                if ( $source_id <= 0 || $source_id === $id || ! isset( $variables_by_id[ $source_id ] ) ) {
                    return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains a variable with an invalid source reference.', [ 'status' => 422 ] );
                }
            } elseif ( $source_id > 0 ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains a base variable with an unexpected source reference.', [ 'status' => 422 ] );
            }
        }

        $dependency_pairs = [];
        $dependency_ids = [];
        $dependency_children = [];
        foreach ( $state['dependencies'] as $dependency ) {
            $dependency_id = (int) ( $dependency['id'] ?? 0 );
            $parent_id = (int) ( $dependency['parent_id'] ?? 0 );
            $child_id = (int) ( $dependency['child_id'] ?? 0 );
            $relation = (string) ( $dependency['relation'] ?? '' );
            $pair = $parent_id . ':' . $child_id;
            if (
                $dependency_id <= 0
                || isset( $dependency_ids[ $dependency_id ] )
                || $parent_id <= 0
                || $child_id <= 0
                || $parent_id === $child_id
                || ! isset( $variables_by_id[ $parent_id ], $variables_by_id[ $child_id ] )
                || ! in_array( $relation, [ 'generated', 'alias' ], true )
                || isset( $dependency_pairs[ $pair ] )
                || isset( $dependency_children[ $child_id ] )
                || (int) ( $variables_by_id[ $child_id ]['source_id'] ?? 0 ) !== $parent_id
                || (string) ( $variables_by_id[ $child_id ]['type'] ?? '' ) !== $relation
            ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains an invalid variable dependency.', [ 'status' => 422 ] );
            }
            $dependency_ids[ $dependency_id ] = true;
            $dependency_pairs[ $pair ] = true;
            $dependency_children[ $child_id ] = true;
        }

        foreach ( $variables_by_id as $id => $variable ) {
            if ( in_array( (string) ( $variable['type'] ?? '' ), [ 'generated', 'alias' ], true ) && ! isset( $dependency_children[ $id ] ) ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot is missing a required variable dependency.', [ 'status' => 422 ] );
            }
        }

        $generator_ids = [];
        $generator_keys = [];
        foreach ( $state['generators'] as $generator ) {
            $generator_id = (int) ( $generator['id'] ?? 0 );
            $variable_id = (int) ( $generator['variable_id'] ?? 0 );
            $type = (string) ( $generator['type'] ?? '' );
            $key = $variable_id . ':' . $type;
            $config = json_decode( (string) ( $generator['config'] ?? '' ), true );
            if (
                $generator_id <= 0
                || isset( $generator_ids[ $generator_id ] )
                || $variable_id <= 0
                || ! isset( $variables_by_id[ $variable_id ] )
                || 'base' !== (string) ( $variables_by_id[ $variable_id ]['type'] ?? '' )
                || ! in_array( $type, [ 'color', 'spacing', 'typography', 'radius', 'size' ], true )
                || isset( $generator_keys[ $key ] )
                || ! is_array( $config )
            ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains an invalid generator row.', [ 'status' => 422 ] );
            }
            $generator_ids[ $generator_id ] = true;
            $generator_keys[ $key ] = true;
        }

        $palette_ids = [];
        foreach ( $state['color_palettes'] as $palette ) {
            $palette_id = (int) ( $palette['id'] ?? 0 );
            $slug = (string) ( $palette['slug'] ?? '' );
            if ( $palette_id <= 0 || '' === $slug || isset( $palette_ids[ $palette_id ] ) ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains an invalid color palette.', [ 'status' => 422 ] );
            }
            $palette_ids[ $palette_id ] = true;
        }

        $member_variables = [];
        foreach ( $state['color_palette_members'] as $member ) {
            $palette_id = (int) ( $member['palette_id'] ?? 0 );
            $variable_id = (int) ( $member['variable_id'] ?? 0 );
            if (
                ! isset( $palette_ids[ $palette_id ], $variables_by_id[ $variable_id ] )
                || isset( $member_variables[ $variable_id ] )
                || ! $this->state_variable_is_color( $variable_id, $variables_by_id )
                || 'generated' === (string) ( $variables_by_id[ $variable_id ]['type'] ?? '' )
            ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains invalid color-palette membership.', [ 'status' => 422 ] );
            }
            $member_variables[ $variable_id ] = true;
        }

        if ( null !== $state['themes'] ) {
            if ( ! isset( $state['themes']['items'], $state['themes']['active'] ) || ! is_array( $state['themes']['items'] ) ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot contains invalid theme state.', [ 'status' => 422 ] );
            }
            $active_theme = sanitize_key( (string) $state['themes']['active'] );
            if ( 'default' !== $active_theme && ! isset( $state['themes']['items'][ $active_theme ] ) ) {
                return new \WP_Error( 've_snapshot_integrity_failed', 'Snapshot active theme is missing from its theme state.', [ 'status' => 422 ] );
            }
        }

        return null;
    }

    private function state_variable_is_color( int $variable_id, array $variables_by_id, array $seen = [] ): bool {
        if ( $variable_id <= 0 || ! isset( $variables_by_id[ $variable_id ] ) || isset( $seen[ $variable_id ] ) ) {
            return false;
        }
        $variable = $variables_by_id[ $variable_id ];
        if ( 'color' === (string) ( $variable['namespace'] ?? '' ) ) {
            return true;
        }
        if ( 'alias' !== (string) ( $variable['type'] ?? '' ) ) {
            return false;
        }
        $seen[ $variable_id ] = true;
        return $this->state_variable_is_color( (int) ( $variable['source_id'] ?? 0 ), $variables_by_id, $seen );
    }

    private function restore_variable( string $table, array $row ): void {
        global $wpdb;

        if ( empty( $row['id'] ) || empty( $row['name'] ) ) {
            throw new \RuntimeException( 'Snapshot contains an invalid variable row.' );
        }

        $inserted = $wpdb->insert(
            $table,
            [
                'id'             => (int) $row['id'],
                'name'           => (string) $row['name'],
                'type'           => (string) ( $row['type'] ?? 'base' ),
                'namespace'      => (string) ( $row['namespace'] ?? '' ),
                'category_slug'  => sanitize_key( (string) ( $row['category_slug'] ?? 'uncategorized' ) ),
                'origin'         => sanitize_key( (string) ( $row['origin'] ?? '' ) ),
                'value'          => (string) ( $row['value'] ?? '' ),
                'css_value'      => (string) ( $row['css_value'] ?? '' ),
                'source_id'      => empty( $row['source_id'] ) ? null : (int) $row['source_id'],
                'generator_type' => empty( $row['generator_type'] ) ? null : (string) $row['generator_type'],
                'created_at'     => (string) ( $row['created_at'] ?? current_time( 'mysql', true ) ),
                'updated_at'     => (string) ( $row['updated_at'] ?? current_time( 'mysql', true ) ),
            ],
            [ '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s', '%s' ]
        );

        if ( false === $inserted ) {
            throw new \RuntimeException( 'Could not restore variable #' . (int) $row['id'] . ': ' . $wpdb->last_error );
        }
    }

    private function restore_generator( string $table, array $row ): void {
        global $wpdb;

        if ( empty( $row['id'] ) || empty( $row['variable_id'] ) || empty( $row['type'] ) ) {
            throw new \RuntimeException( 'Snapshot contains an invalid generator row.' );
        }

        $inserted = $wpdb->insert(
            $table,
            [
                'id'          => (int) $row['id'],
                'variable_id' => (int) $row['variable_id'],
                'type'        => (string) $row['type'],
                'config'      => (string) ( $row['config'] ?? '{}' ),
                'active'      => empty( $row['active'] ) ? 0 : 1,
                'created_at'  => (string) ( $row['created_at'] ?? current_time( 'mysql', true ) ),
            ],
            [ '%d', '%d', '%s', '%s', '%d', '%s' ]
        );

        if ( false === $inserted ) {
            throw new \RuntimeException( 'Could not restore generator #' . (int) $row['id'] . ': ' . $wpdb->last_error );
        }
    }

    private function restore_dependency( string $table, array $row ): void {
        global $wpdb;

        if ( empty( $row['id'] ) || empty( $row['parent_id'] ) || empty( $row['child_id'] ) ) {
            throw new \RuntimeException( 'Snapshot contains an invalid dependency row.' );
        }

        $inserted = $wpdb->insert(
            $table,
            [
                'id'         => (int) $row['id'],
                'parent_id'  => (int) $row['parent_id'],
                'child_id'   => (int) $row['child_id'],
                'relation'   => (string) ( $row['relation'] ?? 'generated' ),
                'created_at' => (string) ( $row['created_at'] ?? current_time( 'mysql', true ) ),
            ],
            [ '%d', '%d', '%d', '%s', '%s' ]
        );

        if ( false === $inserted ) {
            throw new \RuntimeException( 'Could not restore dependency #' . (int) $row['id'] . ': ' . $wpdb->last_error );
        }
    }

    private function restore_color_palette( string $table, array $row ): void {
        global $wpdb;
        $inserted = $wpdb->insert(
            $table,
            [
                'id' => (int) $row['id'],
                'slug' => (string) $row['slug'],
                'name' => (string) $row['name'],
                'position' => (int) ( $row['position'] ?? 0 ),
                'created_at' => (string) ( $row['created_at'] ?? current_time( 'mysql', true ) ),
                'updated_at' => (string) ( $row['updated_at'] ?? current_time( 'mysql', true ) ),
            ],
            [ '%d', '%s', '%s', '%d', '%s', '%s' ]
        );
        if ( false === $inserted ) {
            throw new \RuntimeException( 'Could not restore color palette #' . (int) $row['id'] . ': ' . $wpdb->last_error );
        }
    }

    private function restore_variable_category( string $table, array $row ): void {
        global $wpdb;
        $inserted = $wpdb->insert(
            $table,
            [
                'id' => (int) ( $row['id'] ?? 0 ),
                'slug' => sanitize_key( (string) ( $row['slug'] ?? '' ) ),
                'name' => (string) ( $row['name'] ?? '' ),
                'position' => (int) ( $row['position'] ?? 0 ),
                'protected' => empty( $row['protected'] ) ? 0 : 1,
                'created_at' => (string) ( $row['created_at'] ?? current_time( 'mysql', true ) ),
                'updated_at' => (string) ( $row['updated_at'] ?? current_time( 'mysql', true ) ),
            ],
            [ '%d', '%s', '%s', '%d', '%d', '%s', '%s' ]
        );
        if ( false === $inserted ) {
            throw new \RuntimeException( 'Could not restore variable category: ' . $wpdb->last_error );
        }
    }

    private function default_category_state(): array {
        return [
            [
                'id' => 1,
                'slug' => 'uncategorized',
                'name' => 'Uncategorized',
                'position' => 0,
                'protected' => 1,
            ],
        ];
    }

    private function restore_color_palette_member( string $table, array $row ): void {
        global $wpdb;
        $inserted = $wpdb->insert(
            $table,
            [
                'id' => (int) $row['id'],
                'palette_id' => (int) $row['palette_id'],
                'variable_id' => (int) $row['variable_id'],
                'position' => (int) ( $row['position'] ?? 0 ),
                'created_at' => (string) ( $row['created_at'] ?? current_time( 'mysql', true ) ),
            ],
            [ '%d', '%d', '%d', '%d', '%s' ]
        );
        if ( false === $inserted ) {
            throw new \RuntimeException( 'Could not restore color-palette membership #' . (int) $row['id'] . ': ' . $wpdb->last_error );
        }
    }

    private function must_query( string $sql ): void {
        global $wpdb;
        if ( false === $wpdb->query( $sql ) ) {
            throw new \RuntimeException( $wpdb->last_error ?: 'Database operation failed.' );
        }
    }

    /**
     * List all snapshots (newest first).
     *
     * @param int $limit
     * @return array
     */
    public function list( int $limit = 20 ): array {
        global $wpdb;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, trigger_type, created_at, variables_state FROM ' . Schema::table('snapshots') .
                ' ORDER BY id DESC LIMIT %d',
                $limit
            ),
            ARRAY_A
        ) ?: [];

        foreach ( $rows as &$row ) {
            $state = $this->decode_state( (string) ( $row['variables_state'] ?? '' ) );
            $row['restorable'] = ! is_wp_error( $state );
            $row['state_version'] = is_wp_error( $state ) ? 1 : (int) $state['version'];
            $row['restore_warning'] = is_wp_error( $state ) ? $state->get_error_message() : '';
            $row['trigger_label'] = $this->trigger_label( (string) ( $row['trigger_type'] ?? '' ) );
            $decoded_json = json_decode( (string) ( $row['variables_state'] ?? '' ), true );
            $meta = is_array( $decoded_json ) && isset( $decoded_json['meta'] ) && is_array( $decoded_json['meta'] )
                ? $decoded_json['meta']
                : [];
            $counts = is_array( $decoded_json ) ? [
                'variables'    => count( $decoded_json['variables'] ?? [] ),
                'dependencies' => count( $decoded_json['dependencies'] ?? [] ),
                'generators'   => count( $decoded_json['generators'] ?? [] ),
                'palettes'     => count( $decoded_json['color_palettes'] ?? [] ),
                'categories'   => count( $decoded_json['variable_categories'] ?? [] ),
            ] : [];
            $row['title'] = (string) ( $meta['title'] ?? $row['trigger_label'] );
            $row['description'] = (string) ( $meta['description'] ?? $this->trigger_description( (string) ( $row['trigger_type'] ?? '' ), $counts ) );
            $row['source'] = (string) ( $meta['source'] ?? '' );
            $row['file_name'] = (string) ( $meta['file_name'] ?? '' );
            $row['format'] = (string) ( $meta['format'] ?? '' );
            $row['change_count'] = (int) ( $meta['change_count'] ?? 0 );
            $row['counts'] = $counts;
            unset( $row['variables_state'] );
        }
        unset( $row );

        return $rows;
    }

    private function trigger_label( string $trigger ): string {
        $labels = [
            'manual'       => 'Manual backup',
            'pre_import'   => 'Before import',
            'pre_export'   => 'Before export',
            'pre_cleanup'  => 'Before database cleanup',
            'pre_rollback' => 'Before snapshot restore',
            'pre_relationship' => 'Before family relationship change',
        ];

        if ( isset( $labels[ $trigger ] ) ) {
            return $labels[ $trigger ];
        }

        $label = trim( str_replace( [ '_', '-' ], ' ', $trigger ) );
        return '' !== $label ? ucwords( $label ) : 'Snapshot';
    }

    private function trigger_description( string $trigger, array $counts = [] ): string {
        $variable_count = (int) ( $counts['variables'] ?? 0 );
        $summary = $variable_count > 0
            ? $variable_count . ' variable' . ( 1 === $variable_count ? '' : 's' ) . ' plus relationships, Themes, Palettes, and Categories.'
            : 'Complete variable-system recovery point.';
        $descriptions = [
            'manual'           => 'Manual recovery point. ' . $summary,
            'pre_import'       => 'Created automatically before imported changes were applied. ' . $summary,
            'pre_export'       => 'Created before exporting the variable system. ' . $summary,
            'pre_cleanup'      => 'Created before database cleanup. ' . $summary,
            'pre_rollback'     => 'Created before restoring another snapshot, so the newer state can still be recovered.',
            'pre_relationship' => 'Created before changing family relationships. Token names and values are included.',
        ];
        return $descriptions[ $trigger ] ?? $summary;
    }

    private function sanitize_context( array $context ): array {
        $clean = [];
        foreach ( [ 'title', 'description', 'source', 'file_name', 'format' ] as $key ) {
            if ( isset( $context[ $key ] ) && '' !== trim( (string) $context[ $key ] ) ) {
                $clean[ $key ] = sanitize_text_field( (string) $context[ $key ] );
            }
        }
        if ( isset( $context['change_count'] ) ) {
            $clean['change_count'] = max( 0, (int) $context['change_count'] );
        }
        return $clean;
    }

    /**
     * Get a single snapshot by ID.
     */
    public function get( int $id ): ?array {
        global $wpdb;

        $row = $wpdb->get_row(
            $wpdb->prepare(
                'SELECT * FROM ' . Schema::table('snapshots') . ' WHERE id = %d',
                $id
            ),
            ARRAY_A
        );

        return $row ?: null;
    }
}
