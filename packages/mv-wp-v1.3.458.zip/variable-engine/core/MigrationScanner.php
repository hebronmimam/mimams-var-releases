<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

class MigrationScanner {

    public function sources(): array {
        return [
            [
                'id'          => 'bricks',
                'name'        => 'Bricks / Advanced Themer',
                'available'   => (bool) get_option( 'bricks_global_variables', false ),
                'description' => 'Reads registered Bricks and Advanced Themer variables without re-importing mirrors owned by other detected variable engines.',
            ],
            [
                'id'          => 'core-framework',
                'name'        => 'Core Framework',
                'available'   => $this->core_framework_available(),
                'description' => 'Scans Core Framework options, colors, selected preset backup, and preset table CSS.',
            ],
            [
                'id'          => 'acss',
                'name'        => 'Automatic.css',
                'available'   => (bool) get_option( 'automatic_css_settings', false ),
                'description' => 'Scans Automatic.css settings for token-like scalar values and CSS custom properties.',
            ],
        ];
    }

    public function scan( string $source = 'all' ): array {
        $vars = [];

        if ( 'all' === $source || 'bricks' === $source || 'advanced-themer' === $source ) {
            $vars = array_merge( $vars, $this->annotate_source( $this->scan_bricks(), 'at', 'advanced-themer' ) );
            $vars = array_merge( $vars, $this->annotate_source( $this->scan_bricks_theme_colors(), 'at', 'advanced-themer' ) );
        }
        if ( 'all' === $source || 'core-framework' === $source ) {
            $vars = array_merge( $vars, $this->annotate_source( $this->scan_core_framework(), 'cf', 'core-framework' ) );
        }
        if ( 'all' === $source || 'acss' === $source ) {
            $vars = array_merge( $vars, $this->annotate_source( $this->scan_acss(), 'acss', 'automatic-css' ) );
        }

        return $this->group_imported_families( $this->dedupe( $vars ) );
    }

    public function source_name( string $source ): string {
        foreach ( $this->sources() as $candidate ) {
            if ( (string) $candidate['id'] === $source ) {
                return (string) $candidate['name'];
            }
        }
        return 'External Sources';
    }

    private function scan_bricks(): array {
        $variables = $this->decode_array( get_option( 'bricks_global_variables', [] ) );
        $categories = $this->decode_array( get_option( 'bricks_global_variables_categories', [] ) );
        $category_map = [];

        foreach ( $categories as $category ) {
            if ( ! is_array( $category ) ) {
                continue;
            }
            $id = strtolower( trim( (string) ( $category['id'] ?? '' ) ) );
            if ( '' !== $id ) {
                $category_map[ $id ] = $category;
            }
        }

        $filtered = [];
        foreach ( $variables as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }
            $category_id = strtolower( trim( (string) ( $item['category'] ?? '' ) ) );
            $category = $category_map[ $category_id ] ?? [];
            if ( $this->is_external_bricks_mirror( $item, $category ) ) {
                continue;
            }
            $filtered[] = $item;
        }

        return $this->parse_variable_list( $filtered, 'bricks' );
    }

    /**
     * Scan the palette stored by Bricks theme styles (Advanced Themer's Color
     * Manager writes here). Each color is keyed by an internal slot name
     * (colorPrimary, colorDanger, …) but the portable identity lives in `raw`
     * as `var(--color-*)`, and the resolved value lives in `rawValue.light`.
     * These never appear in `bricks_global_variables`, so without this reader
     * the migration detects zero colors even though the palette is populated.
     * Only the defined base colors are imported; `shadeChildren` are generated
     * shade IDs with no stored value, and dark-mode entries are unset
     * placeholders (`#000000`) on this install shape, so light is authoritative.
     */
    private function scan_bricks_theme_colors(): array {
        // Two options can hold the palette in the same `raw`/`rawValue` shape:
        // `bricks_color_palette` is the full Color Manager palette (base colors
        // plus every auto-generated light/dark/transparent shade), while
        // `bricks_theme_styles` carries the smaller theme-level set. Read both
        // and let dedupe() collapse the overlap. Shade entries are skipped in
        // the collector, so only the defined base colors are imported.
        $entries = [];
        foreach ( [ 'bricks_color_palette', 'bricks_theme_styles' ] as $option_name ) {
            $data = get_option( $option_name, [] );
            if ( is_string( $data ) ) {
                $data = maybe_unserialize( $data );
            }
            if ( is_array( $data ) ) {
                $this->collect_theme_color_entries( $data, $entries );
            }
        }

        return $this->parse_variable_list( $entries, 'bricks' );
    }

    /**
     * Walk a Bricks theme-styles tree and pull every color entry that names a
     * CSS custom property in `raw` and carries a resolvable value. Recurses so
     * it works regardless of how many styles exist or how deeply the `colors`
     * group is nested inside a style's settings.
     *
     * @param mixed $node
     * @param array $out  Collected [ 'name' => css-token, 'value' => color ] rows.
     */
    private function collect_theme_color_entries( $node, array &$out ): void {
        if ( ! is_array( $node ) ) {
            return;
        }

        foreach ( $node as $key => $value ) {
            if ( 'colors' === $key && is_array( $value ) ) {
                foreach ( $value as $color ) {
                    if ( ! is_array( $color ) ) {
                        continue;
                    }
                    // Base colors AND their generated shade variants (…-l-1,
                    // …-d-2, …-t-3) are both imported: the shade names resolve
                    // to their base via the family grouping, so shades come in
                    // as generated children of each color, mirroring the Color
                    // Manager. Each shade keeps its own stored value.
                    $raw = (string) ( $color['raw'] ?? '' );
                    if ( ! preg_match( '/var\(\s*(--[a-z0-9_-]+)/i', $raw, $matches ) ) {
                        continue;
                    }
                    $name = ltrim( strtolower( (string) $matches[1] ), '-' );

                    $resolved = '';
                    $raw_value = $color['rawValue'] ?? '';
                    if ( is_array( $raw_value ) ) {
                        $resolved = (string) ( $raw_value['light'] ?? reset( $raw_value ) );
                    } elseif ( is_string( $raw_value ) ) {
                        $resolved = $raw_value;
                    }
                    $resolved = trim( $resolved );

                    if ( '' !== $name && '' !== $resolved && $this->looks_like_color( $resolved ) ) {
                        $out[] = [ 'name' => $name, 'value' => $resolved ];
                    }
                }
            }

            if ( is_array( $value ) ) {
                $this->collect_theme_color_entries( $value, $out );
            }
        }
    }

    private function annotate_source( array $variables, string $origin, string $category_slug ): array {
        foreach ( $variables as &$variable ) {
            $variable['origin'] = $origin;
            $variable['category_slug'] = $category_slug;
        }
        unset( $variable );
        return $variables;
    }

    private function decode_array( $data ): array {
        if ( is_string( $data ) ) {
            $decoded = json_decode( $data, true );
            return is_array( $decoded ) ? $decoded : [];
        }
        return is_array( $data ) ? $data : [];
    }

    private function is_external_bricks_mirror( array $item, array $category = [] ): bool {
        $item_id = strtolower( trim( (string) ( $item['id'] ?? '' ) ) );
        $category_id = strtolower( trim( (string) ( $item['category'] ?? $category['id'] ?? '' ) ) );
        $category_name = strtolower( trim( (string) ( $category['name'] ?? '' ) ) );
        $owner = $category_id . ' ' . $category_name;

        // Mimam's Var always mirrors its own rows into Bricks. Feeding those
        // rows back into migration duplicates the current source of truth.
        if ( 0 === strpos( $item_id, 'mv-' )
            || 'mimams-var' === $category_id
            || false !== strpos( $owner, 'mimam' ) ) {
            return true;
        }

        // Framework connectors may also publish their rows into the same
        // Bricks registry. When that engine is active, its dedicated scanner
        // owns those variables. If it is absent (or uninstalled, leaving only
        // orphaned options), retain the registry copy as the import source so
        // the tokens are not filtered out and then lost.
        $core_detected = $this->core_framework_plugin_active();
        if ( $core_detected
            && ( false !== strpos( $owner, 'core-framework' )
                || false !== strpos( $owner, 'core framework' ) ) ) {
            return true;
        }

        $acss_detected = (bool) get_option( 'automatic_css_settings', false );
        if ( $acss_detected
            && ( false !== strpos( $owner, 'automatic.css' )
                || false !== strpos( $owner, 'automatic css' )
                || preg_match( '/(?:^|[\s_-])acss(?:$|[\s_-])/', $owner ) ) ) {
            return true;
        }

        return false;
    }

    private function scan_core_framework(): array {
        // Ignore leftover Core Framework options/tables when the plugin is no
        // longer active — those tokens now belong to whatever framework is
        // actually installed (they are read from Bricks/AT instead).
        if ( ! $this->core_framework_plugin_active() ) {
            return [];
        }

        global $wpdb;

        $vars = [];
        foreach ( [ 'core_framework_main', 'core_framework_colors', 'core_framework_selected_preset_backup', 'core_framework_editor_prefixed_css' ] as $option ) {
            $vars = array_merge( $vars, $this->parse_any( get_option( $option, [] ), 'core' ) );
        }

        $table = $wpdb->prefix . 'core_framework_presets';
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
            $rows = $wpdb->get_results( "SELECT * FROM {$table} LIMIT 20", ARRAY_A ) ?: [];
            foreach ( $rows as $row ) {
                $vars = array_merge( $vars, $this->parse_any( $row, 'core' ) );
            }
        }

        return $vars;
    }

    private function scan_acss(): array {
        return $this->parse_any( get_option( 'automatic_css_settings', [] ), 'acss' );
    }

    private function parse_variable_list( $data, string $fallback_ns ): array {
        if ( is_string( $data ) ) {
            $decoded = json_decode( $data, true );
            if ( is_array( $decoded ) ) {
                $data = $decoded;
            }
        }
        if ( ! is_array( $data ) ) {
            return [];
        }

        $out = [];
        foreach ( $data as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }

            $name  = (string) ( $item['name'] ?? $item['label'] ?? $item['id'] ?? '' );
            $value = (string) ( $item['value'] ?? $item['raw'] ?? $item['color'] ?? '' );
            if ( '' === $name || '' === $value ) {
                $out = array_merge( $out, $this->parse_any( $item, $fallback_ns ) );
                continue;
            }
            $token = $this->token_name( $name, $fallback_ns );
            if ( '' !== $token && $this->looks_like_value( $value ) ) {
                $out[] = $this->variable( $token, $value );
            }
        }

        return $out;
    }

    private function parse_any( $data, string $fallback_ns, string $path = '' ): array {
        if ( is_string( $data ) ) {
            $vars = $this->parse_css_vars( $data, $fallback_ns );
            $decoded = json_decode( $data, true );
            if ( is_array( $decoded ) ) {
                $vars = array_merge( $vars, $this->parse_any( $decoded, $fallback_ns, $path ) );
            }
            return $vars;
        }

        if ( ! is_array( $data ) ) {
            return [];
        }

        $out = [];
        foreach ( $data as $key => $value ) {
            $key = is_string( $key ) ? $key : '';
            $next_path = '' === $path ? $key : $path . '.' . $key;

            if ( is_array( $value ) ) {
                if ( isset( $value['name'] ) && ( isset( $value['value'] ) || isset( $value['color'] ) ) ) {
                    $name = $this->token_name( (string) $value['name'], $fallback_ns );
                    $val  = (string) ( $value['value'] ?? $value['color'] ?? '' );
                    if ( '' !== $name && $this->looks_like_value( $val ) ) {
                        $out[] = $this->variable( $name, $val );
                    }
                }
                $out = array_merge( $out, $this->parse_any( $value, $fallback_ns, $next_path ) );
                continue;
            }

            $str = (string) $value;
            $out = array_merge( $out, $this->parse_css_vars( $str, $fallback_ns ) );
            if ( '' !== $key && $this->looks_like_value( $str ) ) {
                $name = $this->token_name( $next_path, $fallback_ns );
                if ( '' !== $name ) {
                    $out[] = $this->variable( $name, $str );
                }
            }
        }

        return $out;
    }

    private function parse_css_vars( string $text, string $fallback_ns ): array {
        $out = [];
        if ( ! preg_match_all( '/--([a-zA-Z0-9_-]+)\s*:\s*([^;}{]+);/', $text, $matches, PREG_SET_ORDER ) ) {
            return $out;
        }

        foreach ( $matches as $match ) {
            $name = $this->token_name( '--' . $match[1], $fallback_ns );
            $val  = trim( (string) $match[2] );
            if ( '' !== $name && '' !== $val ) {
                $out[] = $this->variable( $name, $val );
            }
        }

        return $out;
    }

    private function variable( string $name, string $value ): array {
        $manager = new VariableManager();
        $external_css_name = strtolower( $manager->to_css_name( $name ) );
        $name = $this->semantic_name( $name, $value );
        $variable = [
            'name'            => $name,
            'value'           => sanitize_text_field( $value ),
            'namespace'       => explode( '.', $name )[0],
            'type'            => 'base',
            'public_css_name' => strtolower( $manager->to_css_name( $name ) ),
            'external_css_name' => $external_css_name,
        ];
        $source_css_name = VariableManager::alias_css_name_from_value( $value );
        if ( '' !== $source_css_name ) {
            $source_name = $this->token_name( $source_css_name, explode( '.', $name )[0] );
            $source_name = $this->semantic_name( $source_name, '' );
            if ( '' !== $source_name && $source_name !== $name ) {
                $variable['value'] = '';
                $variable['type'] = 'alias';
                $variable['source_name'] = $source_name;
                $variable['source_css_name'] = strtolower( $source_css_name );
            }
        }
        return $variable;
    }

    private function semantic_name( string $name, string $value ): string {
        $parts = array_values( array_filter( explode( '.', strtolower( trim( $name ) ) ), static function ( string $part ): bool {
            return '' !== $part;
        } ) );
        $source_wrappers = [ 'base', 'bricks', 'brickstheme', 'advanced-themer', 'advancedthemer', 'core', 'acss', 'automatic-css', 'automaticcss' ];
        while ( count( $parts ) > 1 && in_array( $parts[0], $source_wrappers, true ) ) {
            array_shift( $parts );
        }
        if ( empty( $parts ) ) {
            return $name;
        }
        if ( count( $parts ) > 1 && 'base' === (string) end( $parts ) ) {
            array_pop( $parts );
        }

        $families = [
            'color', 'background', 'bg', 'border', 'stroke', 'shadow',
            'font', 'typography', 'heading', 'text', 'weight',
            'space', 'spacing', 'gap', 'radius', 'size', 'grid',
            'opacity', 'motion', 'breakpoint', 'layout', 'container', 'z',
            'design', 'status',
        ];
        $looks_color = $this->looks_like_color( $value );
        if ( ! in_array( (string) $parts[0], $families, true ) && $looks_color ) {
            array_unshift( $parts, 'color' );
        }

        // Color is the only automatic top-level category. External non-color
        // paths are flattened into one portable token; users can add their own
        // category later without inheriting framework storage structure.
        $semantic = 'color' === (string) $parts[0] ? implode( '.', $parts ) : implode( '-', $parts );
        return preg_match( VariableManager::NAME_PATTERN, $semantic ) ? $semantic : $name;
    }

    private function looks_like_color( string $value ): bool {
        return ColorPaletteManager::is_css_color_value( $value );
    }

    private function token_name( string $name, string $fallback_ns ): string {
        $name = strtolower( trim( $name ) );
        $name = preg_replace( '/^--/', '', $name );
        $name = preg_replace( '/[^a-z0-9._-]+/', '.', $name );
        $name = str_replace( [ '_', '-' ], '.', $name );
        $name = preg_replace( '/\.+/', '.', $name );
        $name = trim( (string) $name, '.' );

        if ( '' === $name ) {
            return '';
        }

        $first = explode( '.', $name )[0];
        if ( ! in_array( $first, [ 'color', 'space', 'spacing', 'font', 'typography', 'heading', 'text', 'radius', 'size', 'shadow', 'opacity', 'motion', 'grid', 'stroke', 'weight', 'design', 'base', 'status' ], true ) ) {
            $name = sanitize_key( $fallback_ns ) . '.' . $name;
        }

        return preg_match( VariableManager::NAME_PATTERN, $name ) ? $name : '';
    }

    private function looks_like_value( string $value ): bool {
        $value = trim( $value );
        // Guard against treating a whole CSS blob as one token, but keep the
        // ceiling well above a single fluid formula. Advanced Themer's clamp()
        // scale values expand to ~400–450 chars (full min-viewport/base-font
        // math), so the old 220 cap silently dropped every base scale step
        // (font-size-s, radius-s, space-*), which then orphaned the aliases
        // that referenced them ("source not found"). One custom-property value
        // is comfortably under 2000 chars.
        if ( '' === $value || strlen( $value ) > 2000 ) {
            return false;
        }
        if ( ColorPaletteManager::is_css_color_value( $value ) ) {
            return true;
        }
        return (bool) preg_match( '/^(#|rgb|hsl|oklch|var\(|clamp\(|calc\(|-?\d+(?:\.\d+)?(?:px|rem|em|%|vh|vw)?$)/i', $value );
    }

    private function dedupe( array $vars ): array {
        $seen = [];
        foreach ( $vars as $var ) {
            $name = (string) ( $var['name'] ?? '' );
            $type = (string) ( $var['type'] ?? 'base' );
            $has_value = '' !== (string) ( $var['value'] ?? '' );
            $has_source = 'alias' === $type && '' !== (string) ( $var['source_name'] ?? '' );
            if ( '' === $name || ( ! $has_value && ! $has_source ) ) {
                continue;
            }
            $identity = strtolower( (string) ( $var['public_css_name'] ?? '' ) );
            if ( '' === $identity ) {
                $identity = $name;
            }
            $seen[ $identity ] = $var;
        }
        $deduped = array_values( $seen );
        usort( $deduped, static function ( array $a, array $b ): int {
            return strnatcasecmp( (string) ( $a['name'] ?? '' ), (string) ( $b['name'] ?? '' ) );
        } );
        return $deduped;
    }

    private function group_imported_families( array $vars ): array {
        $names = [];
        foreach ( $vars as $index => $variable ) {
            $name = strtolower( trim( (string) ( $variable['name'] ?? '' ) ) );
            if ( '' !== $name ) {
                $names[ $name ] = $index;
            }
        }

        $families = [];
        foreach ( $vars as $index => $variable ) {
            if ( 'base' !== (string) ( $variable['type'] ?? 'base' ) ) {
                continue;
            }
            $name = strtolower( trim( (string) ( $variable['name'] ?? '' ) ) );
            $base_name = $this->imported_family_candidate_name( $name );
            if ( '' === $base_name || $base_name === $name ) {
                continue;
            }
            $families[ $base_name ][] = $index;
        }

        foreach ( $families as $base_name => $child_indexes ) {
            $base_index = $names[ $base_name ] ?? null;
            if ( null === $base_index && count( $child_indexes ) < 2 ) {
                continue;
            }
            $preferred_index = $this->preferred_family_child_index( $base_name, $vars, $child_indexes );
            if ( null === $base_index ) {
                $preferred = $vars[ $preferred_index ];
                $synthetic = $preferred;
                $synthetic['name'] = $base_name;
                $synthetic['namespace'] = explode( '.', $base_name )[0];
                $synthetic['type'] = 'base';
                $synthetic['source_name'] = '';
                $synthetic['generator_type'] = '';
                $synthetic['public_css_name'] = strtolower( ( new VariableManager() )->to_css_name( $base_name ) );
                $synthetic['external_css_name'] = '';
                $synthetic['family_base_source'] = (string) ( $preferred['name'] ?? '' );
                $synthetic['family_synthetic'] = true;
                $vars[] = $synthetic;
                $base_index = count( $vars ) - 1;
                $names[ $base_name ] = $base_index;
            }

            foreach ( $child_indexes as $index ) {
                // This relationship is organizational only. The imported
                // child keeps its exact source value and is never regenerated.
                $vars[ $index ]['type'] = 'generated';
                $vars[ $index ]['source_name'] = $base_name;
                $vars[ $index ]['generator_type'] = 'imported';
            }
        }

        usort( $vars, static function ( array $a, array $b ): int {
            return strnatcasecmp( (string) ( $a['name'] ?? '' ), (string) ( $b['name'] ?? '' ) );
        } );
        return $vars;
    }

    private function imported_family_candidate_name( string $name ): string {
        $candidate = '';
        if ( preg_match( '/^(.*)-(?:d|l|t)-\d+$/', $name, $matches ) ) {
            $candidate = (string) $matches[1];
        } elseif ( preg_match( '/^(.*)-\d+$/', $name, $matches ) ) {
            $candidate = (string) $matches[1];
        } elseif ( preg_match( '/^(.*)-(?:[2-8]xl|xl|l|m|s|xs|[2-8]xs)$/', $name, $matches ) ) {
            $candidate = (string) $matches[1];
        } elseif ( preg_match( '/^(.*)\.(?:d|l|t)\.\d+$/', $name, $matches ) ) {
            $candidate = (string) $matches[1];
        } elseif ( preg_match( '/^(.*)\.\d+$/', $name, $matches ) ) {
            $candidate = (string) $matches[1];
        } elseif ( preg_match( '/^(.*)\.(?:[2-8]xl|xl|l|m|s|xs|[2-8]xs)$/', $name, $matches ) ) {
            $candidate = (string) $matches[1];
        }

        return $candidate;
    }

    private function preferred_family_child_index( string $base_name, array $vars, array $indexes ): int {
        $first = $vars[ (int) reset( $indexes ) ] ?? [];
        $choice_key = $this->family_choice_key( $base_name, $first );
        $saved_choices = get_option( 've_import_family_bases', [] );
        $saved_name = is_array( $saved_choices ) ? (string) ( $saved_choices[ $choice_key ] ?? '' ) : '';
        if ( '' !== $saved_name ) {
            foreach ( $indexes as $index ) {
                if ( $saved_name === (string) ( $vars[ $index ]['name'] ?? '' ) ) {
                    return (int) $index;
                }
            }
        }

        $ranked = $indexes;
        usort( $ranked, static function ( int $left, int $right ) use ( $vars ): int {
            $score = static function ( string $name ): array {
                if ( preg_match( '/(?:-|\.)([2-8]?x[sl]|[sml])$/', $name, $match ) ) {
                    $step = strtolower( (string) $match[1] );
                    if ( 'm' === $step ) {
                        return [ 0, 0, 0 ];
                    }
                    $tshirt_order = [
                        '8xs', '7xs', '6xs', '5xs', '4xs', '3xs', '2xs', 'xs',
                        's', 'm', 'l', 'xl', '2xl', '3xl', '4xl', '5xl', '6xl', '7xl', '8xl',
                    ];
                    $position = array_search( $step, $tshirt_order, true );
                    return [ 1, false === $position ? PHP_INT_MAX : abs( 9 - (int) $position ), (int) $position ];
                }
                if ( preg_match( '/(?:-|\.)(\d+)$/', $name, $match ) ) {
                    $number = (int) $match[1];
                    return [ 500 === $number ? 0 : 1, abs( 500 - $number ), $number ];
                }
                return [ 2, PHP_INT_MAX, PHP_INT_MAX ];
            };
            $left_score = $score( (string) ( $vars[ $left ]['name'] ?? '' ) );
            $right_score = $score( (string) ( $vars[ $right ]['name'] ?? '' ) );
            return $left_score <=> $right_score;
        } );
        return (int) reset( $ranked );
    }

    public function remember_family_base_choices( array $variables ): bool {
        $saved = get_option( 've_import_family_bases', [] );
        $saved = is_array( $saved ) ? $saved : [];
        $changed = false;
        foreach ( $variables as $variable ) {
            if ( empty( $variable['family_synthetic'] ) || empty( $variable['family_base_source'] ) || empty( $variable['name'] ) ) {
                continue;
            }
            $key = $this->family_choice_key( (string) $variable['name'], $variable );
            $choice = strtolower( trim( (string) $variable['family_base_source'] ) );
            if ( '' !== $choice && ( $saved[ $key ] ?? '' ) !== $choice ) {
                $saved[ $key ] = $choice;
                $changed = true;
            }
        }
        return ! $changed || update_option( 've_import_family_bases', $saved, false );
    }

    private function family_choice_key( string $base_name, array $variable ): string {
        $source = sanitize_key( (string) ( $variable['origin'] ?? $variable['category_slug'] ?? 'external' ) );
        return ( $source ?: 'external' ) . ':' . strtolower( trim( $base_name ) );
    }

    private function core_framework_available(): bool {
        // A framework only counts as a live source when its plugin is actually
        // active. Uninstalling Core Framework leaves its options and the
        // `core_framework_presets` table behind, which used to make MV keep
        // listing Core Framework as a migration source (a "ghost") and pull
        // orphaned tokens. Gate on the active plugin so a removed framework
        // stops appearing and its leftovers are ignored.
        if ( ! $this->core_framework_plugin_active() ) {
            return false;
        }

        global $wpdb;
        $table = $wpdb->prefix . 'core_framework_presets';
        return (bool) get_option( 'core_framework_main', false )
            || (bool) get_option( 'core_framework_colors', false )
            || ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
    }

    /**
     * Whether the Core Framework plugin is actually installed and active.
     *
     * Checks the active-plugins list (single site and network) for a
     * core-framework entry, with a class/constant fallback for cases where the
     * plugin loads without a conventional path. Leftover options/tables from an
     * uninstalled copy deliberately do NOT count.
     */
    private function core_framework_plugin_active(): bool {
        $matches = static function ( $plugin ): bool {
            return is_string( $plugin ) && preg_match( '/core[-_]?framework/i', $plugin );
        };

        foreach ( (array) get_option( 'active_plugins', [] ) as $plugin ) {
            if ( $matches( $plugin ) ) {
                return true;
            }
        }

        if ( function_exists( 'is_multisite' ) && is_multisite() ) {
            foreach ( array_keys( (array) get_site_option( 'active_sitewide_plugins', [] ) ) as $plugin ) {
                if ( $matches( $plugin ) ) {
                    return true;
                }
            }
        }

        return defined( 'CORE_FRAMEWORK_VERSION' )
            || class_exists( 'CoreFramework' )
            || class_exists( '\\CoreFramework\\Plugin' );
    }
}
