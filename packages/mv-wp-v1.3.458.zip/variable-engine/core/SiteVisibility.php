<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

final class SiteVisibility {

    private const OPTION_KEY  = 've_site_visibility';
    private const COOKIE_NAME = 'bricks_preview_key';

    public function register(): void {
        add_filter( 'bricks/maintenance/should_apply', [ $this, 'maybe_bypass_maintenance' ], 10, 2 );
    }

    public static function get_preview_key(): string {
        $settings = get_option( self::OPTION_KEY, [] );
        $key      = is_array( $settings ) ? (string) ( $settings['preview_key'] ?? 'bypass' ) : 'bypass';

        return $key !== '' ? $key : 'bypass';
    }

    public static function is_preview_enabled(): bool {
        $settings = get_option( self::OPTION_KEY, [] );

        return is_array( $settings ) && ! empty( $settings['preview_enabled'] );
    }

    public static function save_preview_key( string $key ): bool {
        return self::save_preview_settings( self::is_preview_enabled(), $key );
    }

    public static function save_preview_settings( bool $enabled, string $key ): bool {
        return update_option( self::OPTION_KEY, [
            'preview_enabled' => $enabled,
            'preview_key'     => $key,
        ], false );
    }

    public function maybe_bypass_maintenance( $apply_maintenance, $mode ) {
        if ( ! self::is_preview_enabled() ) {
            return $apply_maintenance;
        }

        $valid_key = self::get_preview_key();

        if ( isset( $_GET['preview_key'] ) ) {
            $provided = sanitize_text_field( wp_unslash( $_GET['preview_key'] ) );
            if ( hash_equals( $valid_key, $provided ) ) {
                setcookie(
                    self::COOKIE_NAME,
                    $valid_key,
                    time() + HOUR_IN_SECONDS,
                    defined( 'COOKIEPATH' ) && COOKIEPATH ? COOKIEPATH : '/',
                    defined( 'COOKIE_DOMAIN' ) ? COOKIE_DOMAIN : '',
                    is_ssl(),
                    true
                );
                $_COOKIE[ self::COOKIE_NAME ] = $valid_key;
                return false;
            }
        }

        if ( isset( $_COOKIE[ self::COOKIE_NAME ] ) ) {
            $cookie_key = sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE_NAME ] ) );
            if ( hash_equals( $valid_key, $cookie_key ) ) {
                return false;
            }
        }

        return $apply_maintenance;
    }
}
