<?php
namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * Loads Rank Math's own browser analyzer for Content Studio.
 *
 * Rank Math calculates its editor score in JavaScript. This bridge exposes the
 * same analyzer, configured tests, locale data, and language helpers without
 * mounting or imitating Rank Math's editor UI.
 */
class RankMathAnalysisBridge {
    private const DEFAULT_TESTS = [
        'contentHasTOC',
        'contentHasShortParagraphs',
        'contentHasAssets',
        'keywordInTitle',
        'keywordInMetaDescription',
        'keywordInPermalink',
        'keywordIn10Percent',
        'keywordInContent',
        'keywordInSubheadings',
        'keywordInImageAlt',
        'keywordDensity',
        'keywordNotUsed',
        'lengthContent',
        'lengthPermalink',
        'linksHasInternal',
        'linksHasExternals',
        'linksNotAllExternals',
        'titleStartWithKeyword',
        'titleSentiment',
        'titleHasPowerWords',
        'titleHasNumber',
        'hasContentAI',
    ];

    /**
     * Enqueue Rank Math's analyzer and return the optional VE app dependency.
     *
     * @return array<int,string>
     */
    public static function enqueue(): array {
        // Detect Rank Math loosely. Earlier this required a top-level \RankMath class
        // AND a plugin_url() method on its instance; some Rank Math builds satisfy
        // neither, so the analyzer never enqueued and the live score fell back to N/A.
        if ( ! function_exists( 'rank_math' ) && ! defined( 'RANK_MATH_VERSION' ) && ! class_exists( 'RankMath' ) ) {
            return [];
        }

        $rank_math = function_exists( 'rank_math' ) ? rank_math() : null;
        $version   = defined( 'RANK_MATH_VERSION' ) ? RANK_MATH_VERSION : ( is_object( $rank_math ) && isset( $rank_math->version ) ? $rank_math->version : null );

        // Resolve Rank Math's plugin dir + URL without depending on plugin_url():
        // constants first, then instance methods, then the standard install path.
        $dir = '';
        if ( defined( 'RANK_MATH_PATH' ) ) {
            $dir = RANK_MATH_PATH;
        } elseif ( defined( 'RANK_MATH_FILE' ) ) {
            $dir = plugin_dir_path( RANK_MATH_FILE );
        } elseif ( is_object( $rank_math ) && method_exists( $rank_math, 'plugin_dir' ) ) {
            $dir = $rank_math->plugin_dir();
        }
        if ( ! $dir && defined( 'WP_PLUGIN_DIR' ) && file_exists( WP_PLUGIN_DIR . '/seo-by-rank-math/rank-math.php' ) ) {
            $dir = WP_PLUGIN_DIR . '/seo-by-rank-math/';
        }
        $url = '';
        if ( defined( 'RANK_MATH_FILE' ) ) {
            $url = plugin_dir_url( RANK_MATH_FILE );
        } elseif ( is_object( $rank_math ) && method_exists( $rank_math, 'plugin_url' ) ) {
            $url = $rank_math->plugin_url();
        } elseif ( $dir ) {
            $url = plugins_url( '/', trailingslashit( $dir ) . 'rank-math.php' );
        }

        $analyzer_file = $dir ? trailingslashit( $dir ) . 'assets/admin/js/analyzer.js' : '';
        $analyzer_url  = $url ? trailingslashit( $url ) . 'assets/admin/js/analyzer.js' : '';

        // If the analyzer can't be located on disk, expose a config flag so the panel
        // reports "unavailable" immediately instead of hanging for 2s then showing N/A.
        if ( ! $analyzer_file || ! file_exists( $analyzer_file ) || ! $analyzer_url ) {
            $reason = ! $dir ? 'rank-math-path-unresolved' : 'analyzer-js-missing';
            wp_register_script( 've-rank-math-config', '', [], $version ?: null, true );
            wp_enqueue_script( 've-rank-math-config' );
            wp_add_inline_script( 've-rank-math-config', 'window.veRankMathAnalysis={available:false,reason:' . wp_json_encode( $reason ) . '};', 'before' );
            return [];
        }

        if ( ! wp_script_is( 'rank-math-analyzer', 'registered' ) ) {
            wp_register_script(
                'rank-math-analyzer',
                $analyzer_url,
                [ 'lodash', 'wp-autop', 'wp-wordcount', 'wp-url', 'wp-hooks', 'wp-i18n' ],
                $version,
                true
            );
        } else {
            global $wp_scripts;
            if ( isset( $wp_scripts->registered['rank-math-analyzer'] ) ) {
                $required = [ 'lodash', 'wp-autop', 'wp-wordcount', 'wp-url', 'wp-hooks', 'wp-i18n' ];
                $wp_scripts->registered['rank-math-analyzer']->deps = array_values(
                    array_unique( array_merge( $wp_scripts->registered['rank-math-analyzer']->deps, $required ) )
                );
            }
        }

        $config = self::configuration( $dir );
        $json   = wp_json_encode( $config );
        if ( $json ) {
            // Fill gaps only — never clobber Rank Math's own data. Previously this merged
            // MV's values OVER window.rankMath.assessor, so when Rank Math had already
            // published its real researchesTests we replaced them with our guess and the
            // live score diverged from the score Rank Math's own editor shows.
            wp_add_inline_script(
                'rank-math-analyzer',
                'window.veRankMathAnalysis=' . $json . ';'
                . 'window.rankMath=window.rankMath||{};'
                . 'window.rankMath.localeFull=window.rankMath.localeFull||window.veRankMathAnalysis.localeFull;'
                . 'window.rankMath.assessor=Object.assign({},window.veRankMathAnalysis.assessor,window.rankMath.assessor||{});',
                'before'
            );
        }

        wp_enqueue_script( 'rank-math-analyzer' );
        if ( function_exists( 'wp_set_script_translations' ) && $dir ) {
            wp_set_script_translations( 'rank-math-analyzer', 'seo-by-rank-math', trailingslashit( $dir ) . 'languages/' );
        }

        return [ 'rank-math-analyzer' ];
    }

    /**
     * @param string $plugin_dir Absolute path to the Rank Math plugin directory.
     * @return array<string,mixed>
     */
    private static function configuration( string $plugin_dir ): array {
        $locale       = get_locale();
        $short_locale = strtolower( substr( str_replace( '-', '_', $locale ), 0, 2 ) );
        $plugin_dir   = $plugin_dir ? trailingslashit( $plugin_dir ) : '';

        $power_words = self::include_array( $plugin_dir . 'assets/vendor/powerwords/' . $short_locale . '.php' );
        $diacritics_locale = in_array( $short_locale, [ 'en', 'de', 'ru' ], true ) ? $short_locale : 'en';
        $diacritics = self::include_array( $plugin_dir . 'assets/vendor/diacritics/' . $diacritics_locale . '.php' );

        $tests    = self::DEFAULT_TESTS;
        $resolved = false;
        if ( class_exists( '\RankMath\Admin\Metabox\Post_Screen' ) ) {
            try {
                $screen     = new \RankMath\Admin\Metabox\Post_Screen();
                $configured = apply_filters( 'rank_math/researches/tests', $screen->get_analysis(), 'post' );
                if ( is_array( $configured ) && $configured ) {
                    $tests    = array_values( array_keys( array_filter( $configured ) ) );
                    $resolved = true;
                }
            } catch ( \Throwable $error ) {
                // Keep the Rank Math default post test list when its screen helper is unavailable.
            }
        }

        // Some researches cannot produce a truthful result outside Rank Math's own editor:
        // `keywordNotUsed` needs its server lookup of keywords already in use, and
        // `hasContentAI` needs the Content AI subscription data. Left in, they simply score
        // zero every time and pull the total below the score Rank Math itself reports.
        $unrunnable = [ 'keywordNotUsed', 'hasContentAI' ];
        $runnable   = array_values( array_diff( $tests, $unrunnable ) );
        $excluded   = array_values( array_intersect( $tests, $unrunnable ) );

        return [
            'available'    => true,
            'localeFull'   => $locale ?: 'en_US',
            'tests'        => $runnable,
            // Diagnostics: lets the panel report where the list came from and what we
            // deliberately skipped, so a score gap can be explained instead of guessed at.
            'testsSource'  => $resolved ? 'rank-math-post-screen' : 'mv-default-list',
            'testsExcluded' => $excluded,
            'assessor'     => [
                'researchesTests' => $runnable,
                'powerWords'      => array_values( array_map( 'strtolower', $power_words ) ),
                'diacritics'      => $diacritics,
            ],
        ];
    }

    /**
     * @return array<mixed>
     */
    private static function include_array( string $path ): array {
        if ( ! $path || ! is_readable( $path ) ) {
            return [];
        }

        $value = include $path;
        return is_array( $value ) ? $value : [];
    }
}
