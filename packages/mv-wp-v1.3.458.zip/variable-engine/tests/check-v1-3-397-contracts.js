'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const panel = fs.readFileSync(path.join(root, 'assets/js/builder-panel.js'), 'utf8');
const routes = fs.readFileSync(path.join(root, 'api/Routes.php'), 'utf8');
const everything = fs.readFileSync(path.join(root, 'modules/builder-tools/mimams-bar/assets/js/modules/everything-manager.js'), 'utf8');
const assert = (condition, message) => {
  if (!condition) {
    console.error('FAIL:', message);
    process.exitCode = 1;
  }
};

assert(everything.includes('openSelectedTarget'), 'Everything selections should use the feedback-aware open helper.');
assert(everything.includes("'this tab'") && everything.includes('announce(app, \'Selected'), 'Everything selections should announce same-tab navigation.');
assert(panel.includes("class:'ve-video-player-stage'"), 'Video media and controls should use separate layout rows.');
assert(panel.includes("portrait?' is-portrait':''"), 'Portrait video previews should adapt to intrinsic dimensions.');
assert(panel.includes("ph-speaker-slash':'ph-speaker-high"), 'Video sound controls should use icons.');
assert(panel.includes("playing?'ph-pause':'ph-play'"), 'Video playback controls should use icons.');
assert(panel.includes("class: 've-media-video-detail-card'"), 'Video detail previews should use a dedicated video wrapper instead of the fixed image preview height.');
assert(panel.includes('ve-media-caption-textarea'), 'Caption should have its own taller field.');
assert(panel.includes('ve-media-description-textarea'), 'Description should have its own taller field.');
assert(panel.includes("classList.toggle('ve-media-progress-active'"), 'Media progress should reserve global toast space.');
assert(panel.includes('textarea.ve-content-rail-textarea{height:120px!important'), 'Content rail textareas should escape the single-line height clamp.');
assert(panel.includes('.ve-seo-keyword-pill{width:100%!important'), 'Focus keywords should render in full-width rows without shrinking.');
assert(panel.includes('const savedResponse=res;'), 'Saved content should retain the authoritative API response.');
assert(routes.includes("'ve_content_seo_score'"), 'The Content Studio score should persist under an MV-owned post meta key.');
assert(panel.includes('Default for new tokens'), 'Output units should clearly identify the new-token default.');
assert(panel.includes('Convert existing tokens (optional)'), 'Existing-token conversion should be a separate optional step.');
assert(panel.includes('reconvertReview &&'), 'Existing-token conversion should require an inline review step.');

if (!process.exitCode) console.log('v1.3.397 acceptance and approved output-unit contracts passed.');
