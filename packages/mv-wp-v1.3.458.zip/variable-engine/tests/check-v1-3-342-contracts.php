<?php

$root   = dirname( __DIR__ );
$routes = file_get_contents( $root . '/api/Routes.php' );
$panel  = file_get_contents( $root . '/assets/js/builder-panel.js' );
$bar    = file_get_contents( $root . '/modules/builder-tools/mimams-bar/assets/css/builder.css' );

$failures = [];
$expect = static function ( $condition, $message ) use ( &$failures ) {
    if ( ! $condition ) {
        $failures[] = $message;
    }
};

$expect( false !== strpos( $panel, "font_manager:()=>openStudioToolDirect('font_manager')" ), 'The speed-dial Font Manager action must use the shared Studio opener.' );
$expect( false !== strpos( $panel, "panelId:'font_manager',width:468" ), 'Font Manager must match the Settings panel width.' );
$expect( false !== strpos( $panel, "'Back to library'" ) && false !== strpos( $panel, 'const returnToLibrary=' ), 'Font import and Add variant need an explicit return path.' );
$expect( false === strpos( $panel, "class:'ve-font-toolbar'},\n        h('input'" ) || false === strpos( $panel, "}},'Import')\n      )," ), 'The Library toolbar must not duplicate the Import tab action.' );
$expect( false !== strpos( $panel, "kind:'variant'" ) && false !== strpos( $panel, "'Remove variant'" ), 'Variant removal must use the custom confirmation surface.' );
$expect( false !== strpos( $panel, "'@font-face{font-family:'+fontPreviewFamily(family)" ), 'Font previews must use isolated Bricks-family aliases.' );
$expect( false !== strpos( $routes, 'font_manager_file_payload' ) && false !== strpos( $routes, 'attachment_url_to_postid' ), 'Bricks font sources must resolve IDs, URLs, and legacy source shapes.' );
$expect( false !== strpos( $routes, "'missing'       => \$url === ''" ), 'Unresolved files must be reported explicitly instead of silently discarded.' );
$expect( false !== strpos( $bar, 'display:contents!important' ) && false !== strpos( $bar, 'later rows start at the panel edge' ), 'Wrapped Direct tokens must use the space below the mode control.' );
$expect( false !== strpos( $bar, 'box-shadow:none!important' ) && false !== strpos( $bar, 'scrollbar-gutter:stable!important' ), 'Class and attribute result focus must be quiet and spaced away from the scrollbar.' );

if ( $failures ) {
    fwrite( STDERR, "v1.3.342 contract failures:\n- " . implode( "\n- ", $failures ) . "\n" );
    exit( 1 );
}

echo "v1.3.342 Font Manager and Bar contracts passed.\n";
