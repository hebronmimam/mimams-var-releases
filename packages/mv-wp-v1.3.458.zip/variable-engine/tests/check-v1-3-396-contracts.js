'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const panel = fs.readFileSync(path.join(root, 'assets/js/builder-panel.js'), 'utf8');
const assert = (condition, message) => {
  if (!condition) {
    console.error('FAIL:', message);
    process.exitCode = 1;
  }
};

assert(panel.includes("const VE_MEDIA_CACHE_KEY='ve_media_library_cache_v2'"), 'Media Studio should hydrate a session cache.');
assert(panel.includes('prefetchMediaLibrary().catch'), 'The admin surface should warm Media Studio before it opens.');
assert(panel.includes("wp/v2/media?per_page=100&page="), 'Media pages should load without the expensive author embed.');
assert(!panel.includes("wp/v2/media?per_page=100&_embed=author&page="), 'The old sequential embedded-author media request should be removed.');
assert(panel.includes('publishMediaCache(all.slice()'), 'The first media page should paint progressively.');
assert(panel.includes('function MediaVideoThumbnail'), 'Video files should render a lazy real-frame thumbnail.');
assert(panel.includes('function MediaVideoPlayer'), 'Selected videos should render an interactive player.');
assert(panel.includes("muted?'Turn sound on':'Turn sound off'"), 'The video player should expose an accessible sound toggle.');
assert(panel.includes("'aria-label':'Video volume'"), 'The video player should expose an accessible volume control.');

if (!process.exitCode) console.log('v1.3.396 Media Studio loading and video preview contracts passed.');
