const assert = require('assert');
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const pluginRoot = path.resolve(__dirname, '..');
const moduleRoot = path.join(
  pluginRoot,
  'modules',
  'builder-tools',
  'mimams-bar',
  'assets',
  'js',
  'modules'
);

const dispatched = [];
const context = {
  console,
  Date,
  Math,
  JSON,
  Array,
  Object,
  String,
  Number,
  Boolean,
  RegExp,
  setTimeout,
  clearTimeout,
  CustomEvent: function CustomEvent(type, options) {
    this.type = type;
    this.detail = options && options.detail;
  },
  document: {
    querySelector: function () { return null; },
    querySelectorAll: function () { return []; }
  },
  window: {
    console,
    MimamsBarCore: {
      makeId: function () { return 'generated'; },
      log: function () {}
    },
    bricksData: {
      elements: {
        section: { label: 'Section', category: 'layout' },
        image: { label: 'Image', category: 'media' }
      },
      components: [
        {
          id: 'card01',
          category: 'Marketing',
          elements: [
            {
              id: 'card01',
              name: 'div',
              parent: 0,
              children: [],
              settings: {},
              label: 'Feature Card'
            }
          ],
          properties: []
        }
      ]
    },
    requestAnimationFrame: function (callback) { callback(); },
    dispatchEvent: function (event) { dispatched.push(event); }
  }
};
context.window.window = context.window;
context.window.document = context.document;
context.window.CustomEvent = context.CustomEvent;
vm.createContext(context);

function loadModule(file) {
  const source = fs.readFileSync(path.join(moduleRoot, file), 'utf8');
  vm.runInContext(source, context, { filename: file });
}

loadModule('bricks-adapter.js');
loadModule('element-search-manager.js');

const adapter = context.window.MimamsBarBricksAdapter;
const search = context.window.MimamsBarElementSearch;
assert(adapter, 'Bricks adapter should load.');
assert(search, 'Element search manager should load.');

const components = adapter.getBricksComponents();
assert.strictEqual(components.length, 1, 'One Bricks component should be indexed.');
assert.strictEqual(components[0].componentId, 'card01');
assert.strictEqual(components[0].label, 'Feature Card');
assert.strictEqual(components[0].kind, 'component');

const matches = search.getLibraryMatches(adapter, 'feature card', 10);
assert(matches.some(function (match) {
  return match.config && match.config.kind === 'component' && match.config.componentId === 'card01';
}), 'Component search should return the matching component.');

let addPayload = null;
const addedElement = { id: 'instance01', name: 'div', cid: 'card01', settings: {} };
adapter._globalsCache = {
  $_state: {},
  $_addNewElement: function (payload) {
    addPayload = payload;
    return addedElement;
  }
};
adapter._globalsCacheAt = Date.now();
adapter.selectElement = function () { return true; };

const addResult = adapter.addBricksComponent(components[0]);
assert.strictEqual(addResult.ok, true, 'Component add should return success.');
assert(addPayload, 'Component add should call the Bricks add helper.');
assert.strictEqual(addPayload.element.cid, 'card01', 'Component instance must reference the component ID.');
assert.strictEqual(addPayload.element.name, 'div');
assert.strictEqual(Object.keys(addPayload.element.settings).length, 0);

let deselected = 0;
let reselected = 0;
let c2bReferencesRefreshed = 0;
let c2bSelectorRendered = 0;
let c2bEditorReloaded = 0;
adapter._globalsCache = { $_state: {} };
adapter._globalsCacheAt = Date.now();
adapter.deselectElement = function () { deselected += 1; return true; };
adapter.selectElement = function (element) {
  if (element && element.id === 'instance01') reselected += 1;
  return true;
};
context.window.Code2Bricks = {
  css: {
    SelectorState: {
      refreshGlobalClassReferences: function () { c2bReferencesRefreshed += 1; },
      getActive: function () { return { type: 'globalClass', id: 'class01' }; }
    },
    SelectorUI: { render: function () { c2bSelectorRendered += 1; } },
    CssEditorController: { loadCssForSelector: function () { c2bEditorReloaded += 1; } }
  },
  runtime: { State: { activeElementId: 'instance01' } },
  bridge: { BricksBridge: { getElementObject: function () { return addedElement; } } }
};
adapter.refreshSelectedElementConsumers(addedElement, { from: 'old-class', to: 'new-class' });
assert.strictEqual(deselected, 1, 'Class rename refresh should replay deselection.');
assert.strictEqual(reselected, 1, 'Class rename refresh should reselect the current element.');
assert.strictEqual(c2bReferencesRefreshed, 1, 'Code2Bricks class references should refresh.');
assert.strictEqual(c2bSelectorRendered, 1, 'Code2Bricks selector UI should render.');
assert.strictEqual(c2bEditorReloaded, 1, 'Code2Bricks editor buffer should reload.');
assert(dispatched.some(function (event) {
  return event.type === 'baqa:class-renamed' &&
    event.detail.from === 'old-class' &&
    event.detail.to === 'new-class';
}), 'Class rename refresh should dispatch the compatibility event.');

const globalClass = {
  settings: {
    _cssCustom: '.old-class { color: red; } .old-class:hover, .old-class.is-active { color: blue; }',
    '_cssCustom:tablet_portrait': '.wrapper > .old-class[data-state="on"] { display: block; }',
    color: '#fff'
  }
};
assert.strictEqual(
  adapter.rewriteGlobalClassCustomCss(globalClass, 'old-class', 'new-class'),
  true,
  'Global class custom CSS should be rewritten.'
);
assert(globalClass.settings._cssCustom.includes('.new-class {'), 'Base selector should use the renamed class.');
assert(globalClass.settings._cssCustom.includes('.new-class:hover'), 'Pseudo selector should use the renamed class.');
assert(globalClass.settings._cssCustom.includes('.new-class.is-active'), 'Chained selector should use the renamed class.');
assert(globalClass.settings['_cssCustom:tablet_portrait'].includes('.new-class[data-state'), 'Breakpoint selector should use the renamed class.');
assert.strictEqual(globalClass.settings.color, '#fff', 'Unrelated class settings should remain unchanged.');

console.log("Mimam's Bar component and class-refresh contracts passed.");
