<?php
/**
 * Recovery contract guard.
 *
 * Run: php tests/check-restore-contracts.php
 */

declare( strict_types = 1 );

$root = dirname( __DIR__ );
$files = [
	'portability' => $root . '/modules/recovery/app/Restore/MVSettingsPortability.php',
	'production'  => $root . '/modules/recovery/app/Restore/ProductionRestoreExecutor.php',
	'staging'     => $root . '/modules/recovery/app/Restore/StagingRestoreExecutor.php',
	'routes'      => $root . '/api/Routes.php',
	'browser'     => $root . '/assets/js/builder-panel.js',
];

$source = [];
foreach ( $files as $name => $path ) {
	$source[ $name ] = (string) file_get_contents( $path );
}

$checks = [
	'MV verification mismatches fail the portability step' =>
		false !== strpos( $source['portability'], "'verified'          => false" )
		&& false !== strpos( $source['portability'], "'ok'                => false" ),
	'Production restore continues after an MV settings warning' =>
		false !== strpos( $source['production'], "TaskResponse::ok( (string) ( \$result['message']" )
		&& false !== strpos( $source['production'], 'Never abort the restore here' ),
	'Staging restore continues after an MV settings warning' =>
		false !== strpos( $source['staging'], "TaskResponse::ok( (string) ( \$result['message']" )
		&& false !== strpos( $source['staging'], 'Never abort the restore here' ),
	'WordPress exposes a same-session REST nonce refresh' =>
		false !== strpos( $source['routes'], 'wp_ajax_ve_refresh_rest_nonce' )
		&& false !== strpos( $source['routes'], "wp_create_nonce( 'wp_rest' )" ),
	'The shared browser API retries a rejected REST nonce' =>
		false !== strpos( $source['browser'], 'isRestNonceError(data,r.status)' )
		&& false !== strpos( $source['browser'], 'await refreshRestNonce()' ),
	'Studio loaders do not replace API failures with empty data' =>
		false === strpos( $source['browser'], "catch (e) {\n      if (seq !== loadItemsSeq.current) return;\n      setItems([]);" )
		&& false !== strpos( $source['browser'], 'Media Studio could not read the media library.' ),
];

$failed = array_keys( array_filter( $checks, static function ( bool $passed ): bool {
	return ! $passed;
} ) );

if ( $failed ) {
	echo "FAILED - recovery contracts:\n";
	foreach ( $failed as $label ) {
		echo '  - ' . $label . "\n";
	}
	exit( 1 );
}

echo "OK: MV settings restore and Studio data-read contracts are guarded.\n";
exit( 0 );
