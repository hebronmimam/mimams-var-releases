'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const panel = fs.readFileSync(path.join(root, 'assets/js/builder-panel.js'), 'utf8');
const bridge = fs.readFileSync(path.join(root, 'core/RankMathAnalysisBridge.php'), 'utf8');
const admin = fs.readFileSync(path.join(root, 'adapters/AdminAdapter.php'), 'utf8');
const bricks = fs.readFileSync(path.join(root, 'adapters/bricks/BricksAdapter.php'), 'utf8');
const routes = fs.readFileSync(path.join(root, 'api/Routes.php'), 'utf8');
const assert = (condition, message) => {
  if (!condition) {
    console.error('FAIL:', message);
    process.exitCode = 1;
  }
};

assert(panel.includes('resizeObserver=new ResizeObserver(syncGeometry)'), 'CodeMirror should remeasure when its inline or pop-out host changes size.');
assert(panel.includes("cm.setSize('100%',nextHeight)"), 'CodeMirror should receive the measured host height instead of keeping its mount-time height.');
assert(panel.includes('.ve-bricks-cm-inline .CodeMirror-lines,.ve-bricks-cm-full .CodeMirror-lines{padding-bottom:18px!important}'), 'Both Bricks code editors should preserve reachable space below the final line.');
assert(panel.includes('.ve-bricks-cm-full .ve-cm-host{width:100%!important;height:100%!important'), 'The pop-out CodeMirror host should own all bounded editor height.');
assert(panel.includes("panelId:'bricks_settings',width:468"), 'Bricks Settings should use the same 468px width as Settings.');

assert(bridge.includes("class RankMathAnalysisBridge"), 'Rank Math live analysis should have a dedicated integration bridge.');
assert(bridge.includes("'assets/admin/js/analyzer.js'"), 'The bridge should load Rank Math’s own browser analyzer.');
assert(bridge.includes("'rank_math/researches/tests'"), 'The bridge should respect Rank Math’s configured post analysis tests.');
assert(bridge.includes("'wp-hooks', 'wp-i18n'"), 'Rank Math analyzer WordPress runtime dependencies should be explicit.');
assert(admin.includes('\\VE\\Core\\RankMathAnalysisBridge::enqueue()'), 'The admin Content Studio should load the Rank Math analyzer bridge.');
assert(bricks.includes('\\VE\\Core\\RankMathAnalysisBridge::enqueue()'), 'The Bricks Content Studio should load the Rank Math analyzer bridge.');
assert(panel.includes('new runtime.Analyzer({ analyses: tests })'), 'Content Studio should calculate with Rank Math’s analyzer implementation.');
assert(panel.includes("status: 'analyzing'") && panel.includes("status: 'ready'"), 'Content Studio should expose live Rank Math recalculation state.');
assert(panel.includes("Its saved score remains Rank Math-owned"), 'The UI should distinguish live analysis from Rank Math-owned saved metadata.');
assert(!routes.includes("update_post_meta( $post_id, 'rank_math_seo_score', $score )"), 'Content Studio must never overwrite Rank Math score meta.');

if (!process.exitCode) console.log('v1.3.402 CodeMirror, panel width, and live Rank Math analyzer contracts passed.');
