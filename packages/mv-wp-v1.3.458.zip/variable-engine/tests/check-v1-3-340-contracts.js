const assert = require('assert');
const fs = require('fs');
const path = require('path');

const pluginRoot = path.resolve(__dirname, '..');
const projectRoot = path.resolve(pluginRoot, '..', '..');

function read(relativePath) {
  return fs.readFileSync(path.join(projectRoot, relativePath), 'utf8');
}

const inputManager = read('.var_engine_review/variable-engine/modules/builder-tools/mimams-bar/assets/js/modules/input-manager.js');
const renderer = read('.var_engine_review/variable-engine/modules/builder-tools/mimams-bar/assets/js/modules/ui-renderer.js');
const controller = read('.var_engine_review/variable-engine/modules/builder-tools/mimams-bar/assets/js/modules/app-controller.js');
const panel = read('.var_engine_review/variable-engine/assets/js/builder-panel.js');
const visibility = read('.var_engine_review/variable-engine/core/SiteVisibility.php');
const routes = read('.var_engine_review/variable-engine/api/Routes.php');
const acfMock = read('docs/mocks/archive/2026-07-26-content-studio-acf-crud.html');

assert(inputManager.includes("event.key === 'ArrowUp'") && inputManager.includes("event.key === 'ArrowDown'"), 'Direct tokens should support vertical navigation.');
assert(inputManager.includes("event.key === 'Backspace'") && inputManager.includes("event.key === 'Delete'"), 'Focused Direct tokens should support keyboard deletion.');
assert(inputManager.includes("closest('.baqa-chip-edit')"), 'Inline editors must retain native text-editing keys.');
assert(renderer.includes('clicker._baqaDelete') && renderer.includes('idClicker._baqaDelete'), 'Rendered ID, class, and attribute tokens should expose deletion handlers.');
assert(controller.includes("'ve-settings-focus-section'") && controller.includes("'bar-saved-attributes'"), 'The Bar library star should deep-link to saved attributes.');

assert(panel.includes('ve-settings-focus-section') && panel.includes("scrollIntoView({behavior:'smooth'"), 'Unified Settings should scroll and focus the requested section.');
assert(panel.includes('media-modal ve-media-context-guard') && panel.includes('ve-bricks-media-bridge'), 'The Media Studio picker should preserve Bricks transient property context.');
assert(panel.includes('preview_enabled') && panel.includes('bypass_roles'), 'Site Visibility should expose preview opt-in and bypass roles.');
assert(visibility.includes('is_preview_enabled') && visibility.includes("if ( ! self::is_preview_enabled() )"), 'Preview-key bypass must be disabled unless explicitly enabled.');
assert(routes.includes("'bypassMaintenanceUserRoles'] = $selected_roles") && routes.includes("'preview_enabled'"), 'Bricks role settings and preview state should persist through the REST route.');

assert(acfMock.includes('data-model-action="edit|') && acfMock.includes('data-model-action="duplicate|') && acfMock.includes('data-model-action="delete|'), 'ACF list actions should be icon-only edit, duplicate, and delete controls.');

console.log('v1.3.340 Bar, Site Visibility, media bridge, and ACF prototype contracts passed.');
