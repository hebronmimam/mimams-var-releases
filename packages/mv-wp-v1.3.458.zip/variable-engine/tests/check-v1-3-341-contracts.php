<?php

$root = dirname( __DIR__ );
$routes = file_get_contents( $root . '/api/Routes.php' );
$panel = file_get_contents( $root . '/assets/js/builder-panel.js' );
$bar_controller = file_get_contents( $root . '/modules/builder-tools/mimams-bar/assets/js/modules/app-controller.js' );
$bar_css = file_get_contents( $root . '/modules/builder-tools/mimams-bar/assets/css/builder.css' );
$admin_adapter = file_get_contents( $root . '/adapters/AdminAdapter.php' );
$bricks_adapter = file_get_contents( $root . '/adapters/bricks/BricksAdapter.php' );

$failures = [];
$expect = static function ( $condition, $message ) use ( &$failures ) {
    if ( ! $condition ) {
        $failures[] = $message;
    }
};

$expect( false !== strpos( $routes, "BRICKS_DB_CUSTOM_FONTS" ), 'Font Manager must use Bricks custom-font posts.' );
$expect( false !== strpos( $routes, "BRICKS_DB_CUSTOM_FONT_FACES" ), 'Font Manager must use Bricks font-face metadata.' );
$expect( false !== strpos( $routes, "BRICKS_DB_CUSTOM_FONT_FACE_RULES" ), 'Font Manager must refresh Bricks font-face rules.' );
$expect( false !== strpos( $routes, "wp_insert_attachment" ), 'Converted WOFF2 files must become WordPress media attachments.' );
$expect( false !== strpos( $routes, "wp_trash_post" ), 'Family deletion must be recoverable through WordPress Trash.' );
$expect( false !== strpos( $panel, "id:'font_manager'" ), 'Font Manager must be registered as an MV Studio tool.' );
$expect( false !== strpos( $panel, "function FontManagerStudio" ), 'Font Manager Studio UI must be present.' );
$expect( false !== strpos( $panel, "font.write({type:'woff2',toBuffer:false})" ), 'Desktop font conversion must write WOFF2.' );
$expect( false !== strpos( $routes, "Imported into Bricks Font Manager." ), 'Import completion must name the Bricks destination.' );
$expect( false !== strpos( $admin_adapter, "'fontToolsScript'" ) && false !== strpos( $bricks_adapter, "'fontToolsScript'" ), 'Both surfaces must expose the lazy font runtime.' );
$expect( is_file( $root . '/assets/vendor/fonteditor-core/fonteditor-core.iife.js' ), 'Bundled font conversion runtime is missing.' );
$expect( is_file( $root . '/assets/vendor/fonteditor-core/woff2.wasm' ), 'WOFF2 WASM runtime is missing.' );
$expect( false !== strpos( $bar_controller, "ve_settings_focus_section" ), 'Saved Attributes navigation must persist its focus target.' );
$expect( false !== strpos( $bar_css, "flex-wrap: nowrap" ) && false !== strpos( $bar_css, "padding-inline-end: 36px" ), 'Direct must stay at top-left while wrapped token rows align under the token rail.' );
$expect( false !== strpos( $panel, "'aria-label':'Unstar '" ) && false !== strpos( $panel, "ph('star')" ), 'Saved attribute removal must be expressed as Unstar.' );

if ( $failures ) {
    fwrite( STDERR, "v1.3.341 contract failures:\n- " . implode( "\n- ", $failures ) . "\n" );
    exit( 1 );
}

echo "v1.3.341 contracts passed.\n";
