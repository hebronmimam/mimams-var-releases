(function () {
  'use strict';

  var root = window.MimamsBar || {};

  function normalizeOps(ops) {
    return Array.isArray(ops) ? ops : [];
  }

  function needsGlobalDeleteDialog(ops) {
    return normalizeOps(ops).some(function (op) {
      return op && op.type === 'delete-global-class' && !op.confirmed;
    });
  }

  function getApplySuccessMessage(ops, result, labels) {
    ops = normalizeOps(ops);
    labels = labels || {};

    var hasAttribute = ops.some(function (op) { return op && (op.type === 'set' || op.type === 'rename'); });
    var hasAttributeDelete = ops.some(function (op) { return op && op.type === 'delete-attribute'; });
    var hasClass = ops.some(function (op) { return op && (op.type === 'add-class' || op.type === 'remove-class' || op.type === 'rename-class'); });
    var hasGlobalDelete = ops.some(function (op) { return op && op.type === 'delete-global-class'; });
    var hasId = ops.some(function (op) { return op && op.type === 'set-id'; });
    var hasBulk = ops.some(function (op) { return op && op.type === 'bulk-apply'; });

    if (hasBulk) return 'Bulk changes applied to ' + ((result && result.bulkCount) || 0) + ' element(s). Save in Bricks to persist.';

    var count = (hasAttribute ? 1 : 0) + (hasAttributeDelete ? 1 : 0) + (hasClass ? 1 : 0) + (hasGlobalDelete ? 1 : 0) + (hasId ? 1 : 0);

    if (count > 1) return 'Changes applied. Save in Bricks to persist.';
    if (hasGlobalDelete) return 'Global classes deleted. Save in Bricks to persist.';
    if (hasAttributeDelete) return 'Attribute removed. Save in Bricks to persist.';
    if (hasId) return 'CSS ID updated. Save in Bricks to persist.';
    if (hasClass) return 'Class updated. Save in Bricks to persist.';

    return labels.applied || 'Attribute applied. Save in Bricks to persist.';
  }

  function getApplyFailure(applied, labels) {
    labels = labels || {};
    applied = applied || {};

    if (applied.ok) return null;

    switch (applied.reason) {
      case 'no-selection':
        return { type: 'message', message: labels.selectFirst || 'Select a Bricks element first.', refreshTarget: true };

      case 'missing-rename-source':
        return { type: 'message', message: 'Could not find existing attribute: ' + applied.name + '.' };

      case 'missing-delete-attribute':
        return { type: 'message', message: 'Could not find existing attribute: ' + applied.name + '.' };

      case 'missing-class-source':
        return { type: 'message', message: 'Could not find class on this element: .' + applied.name + '.' };

      case 'class-name-conflict':
        return { type: 'message', message: 'A global class named .' + applied.name + ' already exists. Choose a different name.' };

      case 'global-delete-needs-confirmation':
        return { type: 'confirm-global-delete' };

      case 'bulk-needs-confirmation':
        return { type: 'confirm-bulk' };

      case 'no-bulk-targets':
        return { type: 'message', message: 'No elements matched bulk target: ' + applied.target + '.' };

      case 'empty-bulk-command':
        return { type: 'message', message: 'Bulk command has nothing safe to apply.' };

      case 'too-many-bulk-targets':
        return { type: 'message', message: 'Bulk target ' + applied.target + ' matched ' + applied.count + ' elements. Limit is ' + applied.max + '. Use a class or narrower selector.' };

      case 'missing-global-class':
        return { type: 'message', message: 'Could not find global class: .' + applied.name + '.' };

      default:
        return { type: 'message', message: 'Could not apply command. Please check the target and try again.' };
    }
  }

  var OperationManager = {
    normalizeOps: normalizeOps,
    needsGlobalDeleteDialog: needsGlobalDeleteDialog,
    getApplySuccessMessage: getApplySuccessMessage,
    getApplyFailure: getApplyFailure
  };

  window.MimamsBarOperationManager = OperationManager;
  root.OperationManager = OperationManager;
  window.MimamsBar = root;
})();
