(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;



  var Toast = {
    node: null,
    timer: null,
    ensure: function () {
      if (!this.node) {
        this.node = document.createElement('div');
        this.node.className = 'baqa-toast';
        document.body.appendChild(this.node);
      }
      return this.node;
    },
    place: function (node) {
      var panel = document.querySelector('.baqa-panel.is-open');
      if (panel) {
        var rect = panel.getBoundingClientRect();
        var viewportWidth = Math.max(document.documentElement.clientWidth || 0, window.innerWidth || 0);
        var viewportHeight = Math.max(document.documentElement.clientHeight || 0, window.innerHeight || 0);
        var nodeRect = node.getBoundingClientRect();
        var toastWidth = Math.max(180, nodeRect.width || node.offsetWidth || 180);
        var toastHeight = Math.max(38, nodeRect.height || node.offsetHeight || 38);
        var center = rect.left + rect.width / 2;
        var top = rect.bottom + 12;
        if (top + toastHeight + 16 > viewportHeight) {
          top = rect.top - toastHeight - 12;
        }
        top = Math.max(16, Math.min(top, viewportHeight - toastHeight - 16));
        center = Math.max(toastWidth / 2 + 16, Math.min(center, viewportWidth - toastWidth / 2 - 16));
        node.classList.add('is-under-bar');
        node.style.setProperty('inset-block-start', Math.round(top) + 'px', 'important');
        node.style.setProperty('inset-block-end', 'auto', 'important');
        node.style.setProperty('inset-inline-start', Math.round(center) + 'px', 'important');
        node.style.setProperty('inset-inline-end', 'auto', 'important');
        return;
      }
      node.classList.remove('is-under-bar');
      node.style.setProperty('inset-block-start', 'auto', 'important');
      node.style.setProperty('inset-block-end', '22px', 'important');
      node.style.setProperty('inset-inline-start', '50%', 'important');
      node.style.setProperty('inset-inline-end', 'auto', 'important');
    },
    show: function (message, type) {
      var node = this.ensure();
      window.clearTimeout(this.timer);
      node.textContent = message;
      node.classList.toggle('is-error', type === 'error');
      node.classList.toggle('is-warning', type === 'warning');
      node.classList.add('is-visible');
      this.place(node);
      window.requestAnimationFrame(function () {
        Toast.place(node);
      });
      this.timer = window.setTimeout(function () {
        node.classList.remove('is-visible');
      }, 3000);
    }
  };


  window.MimamsBarToast = Toast;
})();
