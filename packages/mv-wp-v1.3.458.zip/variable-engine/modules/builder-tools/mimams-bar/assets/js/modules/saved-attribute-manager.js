(function () {
  'use strict';

  if (window.MimamsBarFrameBridge || window.MimamsBarSavedAttributes) return;

  var config = window.baqaConfig || (window.MimamsBarCore && window.MimamsBarCore.config) || {};
  var items = normalizeList(config.savedAttributes || []);
  var writeChain = Promise.resolve();

  function normalizeName(value) {
    value = String(value == null ? '' : value).trim();
    return /^[A-Za-z_:][A-Za-z0-9:._-]*$/.test(value) ? value : '';
  }

  function normalizeItem(item) {
    if (!item || typeof item !== 'object') return null;
    var name = normalizeName(item.name);
    if (!name) return null;
    return {
      name: name,
      value: String(item.value == null ? '' : item.value).trim().slice(0, 500)
    };
  }

  function normalizeList(list) {
    var next = [];
    (Array.isArray(list) ? list : []).forEach(function (item) {
      var clean = normalizeItem(item);
      if (!clean) return;
      var existing = next.findIndex(function (saved) { return saved.name === clean.name; });
      if (existing >= 0) next[existing] = clean;
      else if (next.length < 100) next.push(clean);
    });
    return next;
  }

  function copyItems() {
    return items.map(function (item) { return { name: item.name, value: item.value }; });
  }

  function emit() {
    var detail = copyItems();
    try {
      window.dispatchEvent(new CustomEvent('ve-saved-attributes-changed', { detail: detail }));
    } catch (e) {}
  }

  function endpoint() {
    var root = String(config.apiRoot || (window.vePanel && window.vePanel.apiRoot) || '').replace(/\/?$/, '/');
    return root ? root + 'variable-engine/v1/settings' : '';
  }

  function persist(next) {
    var url = endpoint();
    if (!url || !window.fetch) return Promise.resolve(copyItems());
    var nonce = config.nonce || (window.vePanel && window.vePanel.nonce) || '';
    writeChain = writeChain.catch(function () {}).then(function () {
      return window.fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
          'Content-Type': 'application/json',
          'X-WP-Nonce': nonce
        },
        body: JSON.stringify({ saved_attributes: next })
      }).then(function (response) {
        if (!response || !response.ok) throw new Error('Saved attributes could not be updated.');
        return response.json();
      }).then(function (response) {
        if (response && Array.isArray(response.saved_attributes)) {
          items = normalizeList(response.saved_attributes);
          config.savedAttributes = copyItems();
          emit();
        }
        return copyItems();
      });
    });
    return writeChain;
  }

  function setAll(list, shouldPersist) {
    var previous = copyItems();
    items = normalizeList(list);
    config.savedAttributes = copyItems();
    emit();
    if (shouldPersist === false) return Promise.resolve(copyItems());
    return persist(copyItems()).catch(function (error) {
      items = previous;
      config.savedAttributes = copyItems();
      emit();
      throw error;
    });
  }

  function find(name) {
    name = normalizeName(name);
    if (!name) return null;
    return items.find(function (item) { return item.name === name; }) || null;
  }

  function save(name, value) {
    var clean = normalizeItem({ name: name, value: value });
    if (!clean) return Promise.reject(new Error('Use a valid attribute name.'));
    var next = copyItems();
    var index = next.findIndex(function (item) { return item.name === clean.name; });
    if (index >= 0) next[index] = clean;
    else next.push(clean);
    return setAll(next);
  }

  function remove(name) {
    name = normalizeName(name);
    if (!name) return Promise.resolve(copyItems());
    return setAll(items.filter(function (item) { return item.name !== name; }));
  }

  function toggle(name, value) {
    return find(name) ? remove(name) : save(name, value);
  }

  window.addEventListener('ve-saved-attributes-changed', function (event) {
    if (!event || !Array.isArray(event.detail)) return;
    var next = normalizeList(event.detail);
    if (JSON.stringify(next) === JSON.stringify(items)) return;
    items = next;
    config.savedAttributes = copyItems();
  });

  window.MimamsBarSavedAttributes = {
    getAll: copyItems,
    find: find,
    isSaved: function (name) { return !!find(name); },
    save: save,
    remove: remove,
    toggle: toggle,
    setAll: setAll,
    normalizeList: normalizeList
  };
})();
