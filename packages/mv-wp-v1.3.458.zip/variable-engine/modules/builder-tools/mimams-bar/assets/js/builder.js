(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;

  var Core = window.MimamsBarCore || {};
  var config = Core.config || window.baqaConfig || {};
  var labels = Core.labels || config.labels || {};
  var MAX_BULK_TARGETS = Core.MAX_BULK_TARGETS || 40;
  var log = Core.log || function () {};
  var matchesConfiguredShortcut = Core.matchesConfiguredShortcut || function () { return false; };

  var modules = {
    Core: Core,
    Parser: window.MimamsBarParser,
    BricksAdapter: window.MimamsBarBricksAdapter,
    Settings: window.MimamsBarSettings,
    Toast: window.MimamsBarToast,
    FieldAssist: window.MimamsBarFieldAssist,
    ElementSearch: window.MimamsBarElementSearch,
    EverythingManager: window.MimamsBarEverythingManager,
    Emmet: window.MimamsBarEmmet,
    MVIntegration: window.MimamsBarMVIntegration,
    SavedAttributes: window.MimamsBarSavedAttributes,
    CommandSuggestions: window.MimamsBarCommandSuggestions,
    Bulk: window.MimamsBarBulk,
    Dialogs: window.MimamsBarDialogs,
    UIRenderer: window.MimamsBarUIRenderer,
    OperationManager: window.MimamsBarOperationManager,
    PanelManager: window.MimamsBarPanelManager,
    ModeManager: window.MimamsBarModeManager,
    AppShell: window.MimamsBarAppShell,
    InputManager: window.MimamsBarInputManager,
    TargetManager: window.MimamsBarTargetManager,
    GlobalEvents: window.MimamsBarGlobalEvents,
    AppController: window.MimamsBarAppController
  };

  var required = [
    'Parser', 'BricksAdapter', 'Settings', 'Toast', 'FieldAssist', 'ElementSearch',
    'Emmet', 'MVIntegration', 'SavedAttributes', 'CommandSuggestions', 'Bulk', 'Dialogs', 'UIRenderer', 'OperationManager', 'PanelManager', 'ModeManager',
    'AppShell', 'InputManager', 'TargetManager', 'GlobalEvents', 'AppController'
  ];

  var missing = required.filter(function (key) { return !modules[key]; });
  if (missing.length) {
    if (window.console) window.console.warn("Mimam's Bar could not boot because these modules failed to load:", missing.join(', '));
    return;
  }

  var UI = modules.AppController.create({
    Core: Core,
    Parser: modules.Parser,
    BricksAdapter: modules.BricksAdapter,
    Settings: modules.Settings,
    Toast: modules.Toast,
    FieldAssist: modules.FieldAssist,
    ElementSearch: modules.ElementSearch,
    Emmet: modules.Emmet,
    MVIntegration: modules.MVIntegration,
    SavedAttributes: modules.SavedAttributes,
    CommandSuggestions: modules.CommandSuggestions,
    Bulk: modules.Bulk,
    Dialogs: modules.Dialogs,
    UIRenderer: modules.UIRenderer,
    OperationManager: modules.OperationManager,
    PanelManager: modules.PanelManager,
    ModeManager: modules.ModeManager,
    AppShell: modules.AppShell,
    InputManager: modules.InputManager,
    TargetManager: modules.TargetManager,
    GlobalEvents: modules.GlobalEvents,
    labels: labels,
    maxBulkTargets: MAX_BULK_TARGETS,
    log: log,
    matchesConfiguredShortcut: matchesConfiguredShortcut
  });

  function boot() {
    UI.init();
    window.MimamsBar = {
      Core: Core,
      Parser: modules.Parser,
      BricksAdapter: modules.BricksAdapter,
      UI: UI,
      Settings: modules.Settings,
      Toast: modules.Toast,
      FieldAssist: modules.FieldAssist,
      ElementSearch: modules.ElementSearch,
      Emmet: modules.Emmet,
      MVIntegration: modules.MVIntegration,
      SavedAttributes: modules.SavedAttributes,
      CommandSuggestions: modules.CommandSuggestions,
      Bulk: modules.Bulk,
      Dialogs: modules.Dialogs,
      UIRenderer: modules.UIRenderer,
      OperationManager: modules.OperationManager,
      PanelManager: modules.PanelManager,
      ModeManager: modules.ModeManager,
      AppShell: modules.AppShell,
      InputManager: modules.InputManager,
      TargetManager: modules.TargetManager,
      GlobalEvents: modules.GlobalEvents,
      AppController: modules.AppController
    };
    window.BAQA = window.MimamsBar;
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }
})();
