(function () {
  'use strict';

  // Runs only in the top builder window that hosts the Bar (not canvas frames).
  if (window.MimamsBarFrameBridge || window.MimamsBarRenameManager) return;

  var overlay = null;
  var input = null;
  var currentApp = null;
  var currentElement = null;

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  function adapterOf(app) {
    return app && (app.adapter || (app.Core && app.Core.adapter)) || null;
  }

  function notify(app, message, type) {
    if (app && app.toast && typeof app.toast.show === 'function') app.toast.show(message, type);
  }

  function buildPills(adapter, element) {
    var out = [];
    var cssId = adapter.getElementCssId ? adapter.getElementCssId(element) : '';
    var idText = cssId ? '#' + cssId : '#brxe-' + element.id;
    out.push('<span class="baqa-rename-pill baqa-rename-pill-id">' + esc(idText) + '</span>');
    (adapter.getElementClasses ? adapter.getElementClasses(element) : []).forEach(function (c) {
      out.push('<span class="baqa-rename-pill">.' + esc(c) + '</span>');
    });
    (adapter.getElementAttributes ? adapter.getElementAttributes(element) : []).forEach(function (a) {
      out.push('<span class="baqa-rename-pill baqa-rename-pill-attr"><span class="k">' + esc(a.name) + '</span>' +
        (a.value ? '<span class="v">' + esc(a.value) + '</span>' : '') + '</span>');
    });
    return out.join('');
  }

  function tryOpen(app) {
    var adapter = adapterOf(app);
    if (!adapter || typeof adapter.getSelectedElement !== 'function') return false;
    var element = adapter.getSelectedElement();
    if (!element || !element.id) {
      notify(app, 'Select an element first to rename it', 'warning');
      return false;
    }

    currentApp = app;
    currentElement = element;
    close();

    var label = (adapter.getElementCustomLabel && adapter.getElementCustomLabel(element)) ||
      (adapter.getElementDisplayType && adapter.getElementDisplayType(element)) || '';

    overlay = document.createElement('div');
    overlay.className = 'baqa-rename-overlay';
    overlay.innerHTML =
      '<div class="baqa-rename-bar" role="dialog" aria-label="Rename element label">' +
        '<div class="baqa-rename-top">' +
          '<span class="baqa-rename-mode"><i class="ph-duotone ph-pencil-simple" aria-hidden="true"></i>Rename</span>' +
          '<span class="baqa-rename-divider" aria-hidden="true"></span>' +
          '<span class="baqa-rename-field">' +
            '<input type="text" class="baqa-rename-input" autocomplete="off" spellcheck="false" aria-label="Element label">' +
            '<span class="baqa-rename-affix">element label</span>' +
          '</span>' +
        '</div>' +
        '<div class="baqa-rename-pills"><span class="baqa-rename-pills-label">On element</span>' + buildPills(adapter, element) + '</div>' +
        '<div class="baqa-rename-foot">' +
          '<div class="baqa-rename-hints"><span><kbd>↵</kbd> rename</span><span><kbd>esc</kbd> cancel</span></div>' +
          '<div class="baqa-rename-btns"><button type="button" class="baqa-rename-cancel">Cancel</button><button type="button" class="baqa-rename-save">Rename</button></div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(overlay);

    input = overlay.querySelector('.baqa-rename-input');
    input.value = label;

    overlay.querySelector('.baqa-rename-save').addEventListener('click', commit);
    overlay.querySelector('.baqa-rename-cancel').addEventListener('click', close);
    overlay.addEventListener('mousedown', function (e) { if (e.target === overlay) close(); });
    input.addEventListener('keydown', function (e) {
      if (e.key === 'Enter') { e.preventDefault(); e.stopPropagation(); commit(); }
      else if (e.key === 'Escape') { e.preventDefault(); e.stopPropagation(); close(); }
    });

    if (window.requestAnimationFrame) window.requestAnimationFrame(function () { if (overlay) overlay.classList.add('is-open'); });
    else if (overlay) overlay.classList.add('is-open');
    window.setTimeout(function () { try { input.focus(); input.select(); } catch (e) {} }, 40);
    return true;
  }

  function commit() {
    if (!input || !currentApp || !currentElement) { close(); return; }
    var adapter = adapterOf(currentApp);
    var value = String(input.value || '').trim();
    var ok = adapter && typeof adapter.renameElement === 'function' && adapter.renameElement(currentElement, value);
    if (ok) {
      notify(currentApp, value ? 'Renamed to “' + value + '”' : 'Label cleared');
      try {
        if (currentApp.targetManager && typeof currentApp.targetManager.scheduleRefresh === 'function') {
          currentApp.targetManager.scheduleRefresh(currentApp);
        }
      } catch (e) {}
    } else {
      notify(currentApp, 'Could not rename this element', 'error');
    }
    close();
  }

  function close() {
    if (overlay && overlay.parentNode) overlay.parentNode.removeChild(overlay);
    overlay = null;
    input = null;
  }

  window.MimamsBarRenameManager = {
    tryOpen: tryOpen,
    close: close,
    isOpen: function () { return !!overlay; }
  };
})();
