<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Backup\PackageValidator;
use VE\Modules\Recovery\Backup\SiteScanner;
use VE\Modules\Recovery\Utils\Logger;

defined( 'ABSPATH' ) || exit;

final class RestoreDryRun {
    public function run( string $snapshot_key = '', string $passphrase = '', bool $for_production = false ): array {
        $validation = ( new PackageValidator() )->validate_snapshot( $snapshot_key, $passphrase );
        $preview = ( new RestorePreview() )->preview_snapshot( $snapshot_key );
        $site = ( new SiteScanner() )->scan();
        $environment_type = function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'production';
        $staging_like = $this->is_staging_like( $site, $environment_type );

        $blockers = [];
        if ( empty( $validation['ok'] ) ) {
            $blockers[] = 'Package validation has blockers.';
        }
        // The staging heuristic only guards the automatic/staging restore ladder.
        // A deliberate production restore ($for_production, reached only after the
        // typed "RESTORE PRODUCTION" confirmation) intentionally targets a live
        // site, so "this is production" must NOT count as a blocker there — that
        // would make the production path circularly block itself. Every other
        // blocker below (package validation, danger-preview, WooCommerce) still
        // applies to production.
        if ( ! $staging_like && ! $for_production ) {
            $blockers[] = 'This site does not look like a staging/development site. Real restore remains locked.';
        }
        if ( ! empty( $preview['risk']['danger'] ) ) {
            $blockers[] = 'Restore preview has danger-level checks.';
        }
        if ( ! empty( $preview['current_site']['woocommerce'] ) || ! empty( $preview['backup_site']['woocommerce'] ) ) {
            $blockers[] = 'WooCommerce-safe merge strategy is required before real restore.';
        }

        $plan = [
            [ 'status' => 'planned', 'title' => 'Pre-restore snapshot', 'message' => 'Create a RestoreBase package before touching files or database.' ],
            [ 'status' => 'planned', 'title' => 'Maintenance mode', 'message' => 'Enable maintenance mode only during a real guarded restore.' ],
            [ 'status' => 'planned', 'title' => 'Package validation', 'message' => 'Confirm ZIP, manifest, checksums, database dump, file inventory, and files archive.' ],
            [ 'status' => 'planned', 'title' => 'Temporary extraction', 'message' => 'Extract package into a temporary restore workspace, not directly over the site.' ],
            [ 'status' => 'planned', 'title' => 'Database temporary import', 'message' => 'Import SQL into temporary tables first, never directly over live tables.' ],
            [ 'status' => 'planned', 'title' => 'Table prefix mapping', 'message' => 'Map backup prefix to destination prefix deliberately.' ],
            [ 'status' => 'planned', 'title' => 'wp-config preservation', 'message' => 'Keep destination database credentials. wp-config.php is blocked from file restore.' ],
            [ 'status' => 'planned', 'title' => 'URL replacement plan', 'message' => 'Keep the destination site URL and rewrite supported backup URLs to the current site URL.' ],
            [ 'status' => 'planned', 'title' => 'Files restore staging area', 'message' => 'Prepare files in a staging area before swapping anything.' ],
            [ 'status' => 'planned', 'title' => 'Verification', 'message' => 'Check frontend, wp-admin, media, plugins, theme, and permalinks.' ],
            [ 'status' => 'planned', 'title' => 'Rollback route', 'message' => 'Keep rollback available until verification passes.' ],
        ];

        Logger::info( 'restore_dry_run_generated', 'Restore dry-run plan generated.', [
            'snapshot_key' => $snapshot_key,
            'blockers'     => count( $blockers ),
        ] );

        return [
            'ok'               => empty( $blockers ),
            'message'          => empty( $blockers ) ? 'Dry run passed. Real restore is still locked in this build.' : 'Dry run found blockers. No restore action was performed.',
            'real_restore'     => [
                'enabled'       => false,
                'staging_like'  => $staging_like,
                'environment'   => $environment_type,
                'release_lock'  => 'v0.5.0 keeps real restore disabled even when dry-run and preparation pass.',
            ],
            'snapshot_key'     => $snapshot_key,
            'blockers'         => $blockers,
            'plan'             => $plan,
            'validation'       => $validation,
            'preview'          => $preview,
        ];
    }

    private function is_staging_like( array $site, string $environment_type ): bool {
        if ( in_array( $environment_type, [ 'local', 'development', 'staging' ], true ) ) {
            return true;
        }

        $url = strtolower( (string) ( $site['site']['url'] ?? '' ) );
        foreach ( [ '.test', '.local', 'localhost', 'staging', 'stage', 'dev.', '.dev', 'sandbox' ] as $needle ) {
            if ( false !== strpos( $url, $needle ) ) {
                return true;
            }
        }

        return false;
    }
}
