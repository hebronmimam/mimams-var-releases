<?php

namespace VE\Modules\Recovery\Restore;

use VE\Modules\Recovery\Backup\PackageValidator;
use VE\Modules\Recovery\Backup\SiteScanner;
use VE\Modules\Recovery\Storage\LocalStorage;

defined( 'ABSPATH' ) || exit;

final class RestoreReadiness {
    public function assess( string $snapshot_key = '', array $workspace = [], string $passphrase = '', bool $for_production = false ): array {
        $validation = ( new PackageValidator() )->validate_snapshot( $snapshot_key, $passphrase );
        $dry_run = ( new RestoreDryRun() )->run( $snapshot_key, $passphrase, $for_production );
        $site = ( new SiteScanner() )->scan();
        $env = function_exists( 'wp_get_environment_type' ) ? wp_get_environment_type() : 'production';
        $staging_like = self::is_staging_like( $site, $env );
        $disk = $this->disk_space( $workspace );

        $checks = [];
        $checks[] = $this->check( ! empty( $validation['ok'] ) ? 'ok' : 'danger', 'Package validation', ! empty( $validation['ok'] ) ? 'Package passed validation.' : 'Package validation has blockers.' );
        // For a deliberate production restore, targeting a live site is the intent,
        // not a fault — so it does not count against the readiness score. The
        // strong "RESTORE PRODUCTION" confirmation is the real gate for that risk.
        $checks[] = $this->check(
            ( $staging_like || $for_production ) ? 'ok' : 'danger',
            'Environment',
            $staging_like ? 'This site looks like staging, development, or local.'
                : ( $for_production ? 'Production restore explicitly confirmed for this live site.' : 'This site looks like production. Staging restore execution is locked.' )
        );
        $checks[] = $this->check( ! empty( $disk['ok'] ) ? 'ok' : 'warn', 'Workspace disk space', (string) $disk['message'] );

        $dry_blockers = isset( $dry_run['blockers'] ) && is_array( $dry_run['blockers'] ) ? count( $dry_run['blockers'] ) : 0;
        $checks[] = $this->check( 0 === $dry_blockers ? 'ok' : 'danger', 'Dry-run blockers', 0 === $dry_blockers ? 'No dry-run blockers were reported.' : $dry_blockers . ' dry-run blocker(s) must be resolved.' );

        $danger = 0;
        $warn = 0;
        foreach ( $checks as $check ) {
            if ( 'danger' === $check['level'] ) {
                $danger++;
            }
            if ( 'warn' === $check['level'] ) {
                $warn++;
            }
        }

        $score = max( 0, 100 - ( $danger * 35 ) - ( $warn * 10 ) );

        return [
            'ok'           => 0 === $danger,
            'score'        => $score,
            'status'       => 0 === $danger ? ( $warn ? 'ready_with_warnings' : 'ready' ) : 'blocked',
            'environment'  => $env,
            'staging_like' => $staging_like,
            'disk'         => $disk,
            'checks'       => $checks,
            'validation'   => $validation,
            'dry_run'      => $dry_run,
        ];
    }

    public static function is_staging_like( array $site, string $environment_type = '' ): bool {
        if ( in_array( $environment_type, [ 'local', 'development', 'staging' ], true ) ) {
            return true;
        }

        $url = strtolower( (string) ( $site['site']['url'] ?? site_url() ) );
        $host = (string) wp_parse_url( $url, PHP_URL_HOST );

        if ( $host && false === strpos( $host, '.' ) ) {
            return true;
        }

        foreach ( [ '.test', '.local', 'localhost', '127.0.0.1', 'staging', 'stage', 'dev.', '.dev', 'sandbox', 'pluginnow' ] as $needle ) {
            if ( false !== strpos( $url, $needle ) ) {
                return true;
            }
        }

        return (bool) apply_filters( 'restorebase_staging_restore_allowed', false, $site, $environment_type );
    }

    private function disk_space( array $workspace ): array {
        $path = isset( $workspace['path'] ) && $workspace['path'] ? (string) $workspace['path'] : LocalStorage::workspaces_dir();
        $free = function_exists( 'disk_free_space' ) ? @disk_free_space( $path ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged
        $total = function_exists( 'disk_total_space' ) ? @disk_total_space( $path ) : false; // phpcs:ignore WordPress.PHP.NoSilencedErrors.Discouraged

        if ( false === $free ) {
            return [ 'ok' => true, 'free_bytes' => 0, 'total_bytes' => 0, 'message' => 'Disk space could not be measured on this host.' ];
        }

        $ok = (int) $free > 104857600;
        return [
            'ok'          => $ok,
            'free_bytes'  => (int) $free,
            'total_bytes' => false === $total ? 0 : (int) $total,
            'message'     => $ok ? 'Workspace has more than 100MB free.' : 'Workspace has less than 100MB free. Restore execution should stay blocked.',
        ];
    }

    private function check( string $level, string $title, string $message ): array {
        return [
            'level'   => sanitize_key( $level ),
            'title'   => sanitize_text_field( $title ),
            'message' => sanitize_text_field( $message ),
        ];
    }
}
