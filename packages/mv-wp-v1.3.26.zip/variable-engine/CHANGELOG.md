# CHANGELOG.md

## v1.3.26

### Changed
- Migration waits for the latest variable reload and opens the affected namespace before confirming completion.
- Namespace tabs identify themselves as name-derived namespaces on hover.

### Fixed
- Stale concurrent reload responses can no longer hide newly migrated variables until a page refresh.

## v1.3.25

### Changed
- Migration Apply uses the exact prepared payload shown in Preview and reports the actual number of writes.

### Fixed
- A zero-write migration is no longer reported as successful.
- Post-apply verification restores the safety snapshot if reviewed changes remain unapplied.
- External migration uses one shared non-deletion change filter across preview, apply, verification, metrics, and tests.

## v1.3.24

### Changed
- Rebuilt Migrate Variables with an MV-dark, icon-led card and callout hierarchy based on the supplied reference.
- Migration counts now come from one server-owned model shared by the summary and Apply action.
- New and touched product controls use Phosphor duotone icons wherever they add meaning.

### Fixed
- In-panel updates restore site or network activation after installation.
- External migration moves only newly added colors into the imported palette and preserves existing palette memberships.
- Preview and Apply loading labels remain independent.

## v1.3.23

### Changed
- Improved the visual aesthetics of the Migrate Variables sub-panel: added a dark, glassmorphic layout for source cards and callouts, replaced loud background colors with premium callouts/alerts, and added distinct, styled badges for migration actions and statuses.
- The preview summary math now includes type changes, relationship changes, and repairs in the "changed" count, perfectly aligning the summary count with the Apply button count.

### Fixed
- External migrations now tolerate and skip CSS custom property conflicts (e.g., when two different names map to the same CSS custom property like `text.base` and `size.text.base`) and report them as warnings, preventing a single clash from failing the entire migration.
- Fixed the button loading states sharing the same boolean variable, ensuring the Scan button shows "Scanning..." and the Apply button shows "Applying..." independently and cleanly.

## v1.3.22

### Added
- Plugin updates can now be installed directly inside Mimam's Var through WordPress's native plugin upgrader.
- After an in-panel update succeeds, a branded confirmation dialog offers **Refresh Now** or **Later** so the newly installed runtime is loaded intentionally.
- External migration previews now report unresolved source aliases as explicit skipped warnings.

### Changed
- Long-operation progress now appears inside the header of the active MV panel, with a stable operation label, staged percentage, waiting ceiling, and clear 100% completion state inspired by the RestoreBase panel pattern.

### Fixed
- A stale Bricks or Advanced Themer alias whose source no longer exists no longer blocks hundreds of otherwise valid migration rows.
- Alias chains that depend on an unresolved external alias are skipped together, while resolvable aliases continue through preview and apply normally.
- The Settings update action and shared update notices no longer redirect away to the WordPress updater screen.

## v1.3.21

### Changed
- Long-operation progress now tracks only known time-consuming work instead of every Mimam's Var API request.
- The progress bar advances once toward a waiting point, holds calmly while server work continues, then fills to completion without restarting or repeatedly sweeping.

### Fixed
- Post-operation refresh requests no longer replace the active progress label or restart the progress animation.
- External migration treats a safe base or static variable becoming an alias with an explicit source as a LINK change instead of blocking it as a manual type change.
- Generated variables remain protected from direct type conversion and still require manual review when an import attempts to turn one into an alias.

## v1.3.20

### Added
- Added a shared branded progress bar for Mimam's Var API work that lasts longer than a brief interaction.
- Progress feedback identifies common operations such as scanning or importing external variables, preparing or restoring a System Bundle, creating or restoring snapshots, generating variables, and updating Themes or Color Palettes.
- Quick requests complete without flashing the progress surface; longer requests show an honest indeterminate bar and a short completion state.

### Changed
- Successful external migration, token import, System Bundle apply, and snapshot restore now refresh builder variable stylesheets and runtime consumers immediately.
- System Bundle LINK guidance now covers both alias and generated source relationships.

### Fixed
- External migration carries public CSS names through reconciliation, preventing alternate stored forms such as `color.color.2` and `color.color-2` from being imported as conflicting custom properties.
- External migration preserves detected alias rows with empty stored values and deduplicates scanned variables by their public CSS identity.
- System Bundle LINK application now preserves generated relationships instead of attempting to convert or edit generated variables through the locked normal update path.
- Generated value updates carry their explicit source and generator type, avoiding name-derived parent guesses during apply.

## v1.3.19

### Added
- External migration from Bricks / Advanced Themer, Core Framework, and Automatic.css now creates a new source-named Color Palette and places imported color variables and resolved color aliases inside it.
- External `var(--token-name)` values are imported as real alias relationships instead of static text values.
- External migration now creates a complete safety snapshot even when token values already match and only Palette ownership changes.

### Changed
- System Bundle and token import preview rows now use a readable two-line layout with wrapping names, values, and relationship details.
- LINK rows show the complete old and new source names, while UPDATE rows show the complete old and new values without hard character truncation.

### Fixed
- System Bundle generated-child repairs now use the bundle's explicit source variable instead of guessing a parent from the child's name.
- Snapshot recovery now accepts semantic aliases such as `design.*` as Color Palette members when their source chain resolves to a Color variable.
- The failed-recovery combination reported in v1.3.18—generated variable conflict followed by invalid color-palette membership—no longer follows those incorrect repair paths.

## v1.3.18

### Added
- Added the MV System Bundle as the complete portable WordPress-to-WordPress handoff format.
- System Bundles preserve variables, generated children, aliases, generator configurations, Themes, active Theme, Color Palettes, memberships, ordering, and generated CSS behavior without carrying source-site database IDs.
- Added dedicated System Bundle export, preview, and apply REST routes plus automatic bundle detection in Sync import.
- Added preview rows for generator, Theme, and Palette changes alongside existing ADD, UPDATE, LINK, and DELETE variable changes.

### Changed
- Sync export now distinguishes the complete System Bundle from interoperability exports such as DTCG, Flat, Figma JSON, and CSS.
- Portable imports reconnect relationships by stable variable names, create a complete safety snapshot first, and automatically restore it if a later import phase fails.
- Skip deletions now also preserves destination-only generators, Themes, Color Palettes, and memberships during System Bundle updates.
- Release packaging now excludes local `.bak` and `.tmp` development artifacts.

### Fixed
- Generated children are applied before aliases, allowing aliases that point to generated tokens to transfer safely between installations.
- Portable bundle validation rejects duplicate Palette memberships, invalid relationship sources, unsupported generator ownership, empty Palette state, and generated-child Palette membership.

## v1.3.17

### Fixed
- Fixed batch actions overlay background color by changing it to `#1b1b1b` (replacing the blueish slate shade) to match the native dark glassmorphic MV product identity.
- Oriented the batch actions target palette dropdown menu to open upwards instead of downwards, ensuring it remains fully visible within the panel viewport and doesn't collide with the status bar.
- Added custom button border-radius overrides for the upward-opening dropdown when active to maintain geometric layout integrity.

## v1.3.16

### Fixed
- Fixed HTML5 drag-and-drop reordering for both variables and palettes in sandboxed environments (like Bricks Builder) by reading the active drag state variables (`draggingVarId` and `draggingPaletteId`) rather than relying on browser `dataTransfer` APIs.
- Resolved batch actions overlay (`.ve-studio-batch-overlay`) design and alignment bugs by overriding standard centering translations (`transform: none!important`), enforcing non-wrapping text (`white-space: nowrap!important`), and assigning an explicit layout width and responsive padding to the target palette dropdown SelectMenu.

## v1.3.15

### Fixed
- Fixed variable drag-and-drop reordering persistence by sorting the `bases` array by position first in the client-side `useMemo` block.
- Implemented the missing floating batch actions overlay (`.ve-studio-batch-overlay`) inside the main panel, appearing at the bottom when checkboxes are checked.
- Added a batch delete confirmation modal (`ConfirmModal`) to prevent accidental mass deletion of variables.
- Fixed Theme/Palette switcher pill styling by setting `width: 100%` and `display: flex` centering on switcher buttons so they span the container width symmetrically.

## v1.3.14

### Added
- Implemented HTML5 drag-and-drop reordering for variables in the tree list, preserving positions via the new `position` database column and POST `/variables/reorder` REST API endpoint.
- Implements HTML5 drag-and-drop reordering for color palettes in the palette manager, calling POST `/color-palettes/reorder` to serialize palette positions.
- Added bulk selection checkboxes next to variable rows in the tree view and a select-all header bar.
- Added a floating batch actions overlay (`.ve-studio-batch-overlay`) at the bottom of the panel showing selected count with batch delete (with confirmation) and batch move (with target palette selector).

### Changed
- Redesigned the Theme/Palette switcher into a capsule pill control (`.ve-color-kind-switch`).
- Removed dropdown labels (`Theme` and `Palette` text span) from select rows to allow selectors to span the full width.
- Styled the active palette/theme current banner to be transparent (`.ve-palette-current` with `padding: 4px 0` and no background/border).

### Fixed
- Removed the header palette shortcut icon button from the header action buttons row (`.ve-hdr-a`).

## v1.3.13

### Changed
- Replaced the stacked Theme and Palette selectors with a compact two-mode switch so only the active Theme or Palette control is shown at a time.
- Theme and Palette selectors now share a fixed label column and begin at the same horizontal position.
- Standardized normal product inputs and branded select controls on the shared 38px control height across the Variable panel and standalone product surfaces.
- Theme and Palette create/rename fields, License Key, search, transfer dialogs, and their adjacent primary action buttons now use the standard control rhythm.

### Fixed
- Removed remaining 24px and 30px inline input-height overrides that bypassed the product control token.
- Preserved specialized heights for checkboxes, radios, color sliders, file inputs, icon controls, and multiline textareas.

## v1.3.12

### Changed
- Color Palette management now expands inline beneath the Palette selector, matching the established Theme manager interaction instead of sliding into a separate panel.
- The header Color Palettes shortcut now opens the Color tab and expands the inline manager.

### Fixed
- Semantic aliases such as `design.*` that resolve through a Color source are now recognized as palette-eligible colors.
- Color aliases appear in the Color tab for palette organization and gain Move to Palette, Copy to Palette, and palette-aware Duplicate actions without changing their stored name, CSS custom property, or source relationship.
- Upgrade membership repair now assigns existing semantic color aliases to Palette One and removes only genuinely invalid memberships.

## v1.3.11

### Added
- Added true user-created Color Palettes as organizational containers for actual Color variables.
- Existing installations migrate their current root colors and aliases into a renameable `Palette One`; generated children inherit their base variable's palette.
- Added an `All Colors` view plus palette filtering under the Color tab.
- Added palette-aware Color creation, Move to Palette, Copy to Palette, palette duplication with independent color copies, inline rename, and safe deletion previews.
- Populated palette deletion can move colors to another palette or explicitly delete the palette and its color/dependency tree through custom confirmation UI.
- Snapshot state version 3 now preserves themes, palettes, memberships, variables, generators, and dependencies together.

### Changed
- Corrected the previous value-layer feature to **Themes** while preserving its existing WordPress options and legacy `/palettes` REST routes for compatibility.
- Added correctly named `/themes` routes and separate `/color-palettes` routes.
- Theme switching continues to affect CSS, Bricks, Code2Bricks, and exports; palette selection affects organization only.

### Fixed
- Imported, migrated, and cleanup-repaired Color variables are assigned to a valid palette without giving generated children independent memberships.
- Color duplication preserves custom-theme values and optional generated children.

### Pending
- Palette drag-and-drop, bulk selection, and manual color ordering remain later interaction phases.

## v1.3.10

### Added
- Added a variable duplication confirmation modal popup (confirmDuplicate) before duplicating a variable to prevent accidental copy creations.

### Changed
- Redesigned active palette and theme card styles with premium duotone palette icon and clean dark card styling, removing the old gradient dot and olive background.

### Fixed
- Fixed input field height alignment for General Settings License Key input (30px), palette sub-panel creation input (30px), and palette sub-panel inline rename input (24px) to align with their action buttons.

## v1.3.09

### Added
- Integrated the full Color Palettes manager inline inside the Color namespace tab. Clicking the sliders/caret toggle next to the palette dropdown expands the palette creation, list, duplication, inline renaming, and deletion interface directly under the tabs.

### Fixed
- Fixed variable row actions (Edit, Duplicate, Delete) in the variable tree list by declaring all the missing handler functions (`hDup`, `hDel`, `cfmDel`, `hCreated`, `tgExp`, `allCats`) in the main `Panel()` component, resolving the console reference errors.

## v1.3.08

### Fixed
- Fixed variable row click handler (`hSel` ReferenceError) so clicking any variable or child variable shows its details card at the bottom.
- Fixed Color namespace tab switching by implementing the `activatePalette` handler and resolving the `ReferenceError: activatePalette is not defined` during Preact render.
- Modifies the `Detail` component to display basic variable metadata immediately rather than blocking render while dependencies are loaded.
- Styled the General Settings "License key" input field (Image 1) to match the dark premium input styling instead of defaulting to a native white box.
- Implemented real-time cross-frame synchronization: any variable change (CRUD) or settings update is automatically broadcast to all frames/windows via `builderRuntimeWindows()` so all open panels refresh instantly without page reload.

## v1.3.07

### Added
- Added a General setting option to show/hide the "All" tab in the variables list.

### Fixed
- Fixed the Preact rendering crash when switching to the **Color** namespace tab by properly declaring the palettesData state and activatePalette handler in the parent panel component.
- Aligned the header action icons row to the left (matching the search input and tabs) by changing the left padding offset from `48px` to `16px`.

## v1.3.06

### Added
- Added a quick palette switcher dropdown inside the Color namespace tab. This allows the user to switch the active color palette instantly from the main view.

### Fixed
- Styled the palette creation and rename inputs in the Palette panel to match the premium dark theme instead of defaulting to white native inputs.

## v1.3.05

### Added
- Added Color Palettes phase 1 under the new palette toolbar action.
- Added palette creation from the active color set, instant activation, duplication, inline renaming, and confirmed deletion.
- Custom palettes keep public token names stable while overriding effective color values in the variable API, generated CSS, Bricks mirroring, Code2Bricks, and DTCG/Flat/Figma/CSS exports.
- Editing a Color variable while a custom palette is active updates that palette instead of overwriting Default; existing generated color children are recalculated from the edited palette base.
- Palette overrides follow base/generated variable renames and are removed with deleted variables.

### Fixed
- Rebuilt variable row actions around explicit open state and the toolbar panel control's 220ms hover-intent close behavior, with the menu anchored at the far-right edge.

### Pending
- Palette snapshot/import payload support and selector-scoped frontend palette switching remain later phases.

## v1.3.04

### Changed
- Variable actions now appear when hovering or keyboard-focusing anywhere on the variable row and remain anchored to the row's right edge.
- Snapshot entries now use descriptive labels such as “Manual backup,” “Before import,” “Before database cleanup,” and “Before snapshot restore,” with the snapshot number and timestamp shown separately.

## v1.3.03

### Added
- Added a clear JSON/CSS import drop zone that displays “Drop file here” while a compatible file is held over it and previews the dropped file before applying anything.
- Added concise import guidance for DTCG, Flat, Figma JSON, and CSS files.

### Fixed
- Restored generated children to a single indented tree beneath their base variable instead of allowing the list to split into a second column.
- Confined variable row actions to the visible swatch/icon hover boundary, keeping them hidden over empty row space while preserving a clickable action bridge.
- Changed JSON and CSS export filenames to include the current WordPress site name, export format, and date.
- Displays alias source changes as explicit old-source to new-source LINK rows and applies supported relationship changes transactionally.

### Planned
- Defined palettes as alternate value layers over stable color-token identities; implementation is intentionally reserved for a dedicated module phase.

## v1.3.02

### Added
- Added unsaved color previewing in the Bricks canvas while editing a color variable; closing the editor without saving removes the temporary preview.

### Fixed
- Recursively discovers nested builder iframe runtimes, reapplies the runtime variable layer after iframe loads, and keeps retrying even when Code2Bricks is already available so custom-property values resolve on the canvas.
- Marks the builder-only runtime variable layer as authoritative so stale Bricks styles cannot mask the current Mimam's Var value.
- Automatically recognizes exact `var(--token)` and `--token` static values as aliases in WordPress, while resolving string and numeric database IDs consistently in the builder.
- Hides the category selector while editing a static variable because the existing namespace is retained.
- Reveals variable row actions only after the pointer enters the variable swatch/icon, instead of activating from the hidden action area.

## v1.3.01

### Added
- Added Tab key autocomplete support to `VarRefInput` in the static value field.
- Added recursive `resolvedVariableValue` helper to fully resolve colors, sizes, swatches, and values for alias variables in lists and autocomplete.

### Fixed
- Added `_nc` cache-buster query parameters to variable list REST requests to ensure value updates propagate to the builder canvas instantly on save.
- Automatically closes the Media Studio panel upon successful asset selection and insertion into Bricks controls.
- Propagates click intent to `createFrame` inside the `wp.media` wrapper to ensure picking state resolves correctly.
- Pre-filled inline editor and full editor in `EditSub` with `css_value` instead of empty string for alias variables, and auto-detects type updates on inline edit save.

## v1.3.00

### Added
- Merged the separate "Alias" mode into "Static" mode. Typing `--` or `var(` in the static value field triggers autocomplete suggestions of existing variables, which automatically transitions the variable's type to `alias` on save.
- Dynamically injects a `:root` style tag on mutation into both the main document and iframe canvas window so newly created variable values resolve instantly in Code2Bricks and Bricks without editor reloads.

### Fixed
- Replaced the timeout polling wrapper with a property getter/setter wrapper on `runtime.wp.media` to immediately intercept Bricks image selectors without race conditions.
- Simplified pointerdown click tracking to register media selection intent for any element outside the Vengine panel and native media modal, bypassing fragile class guessing.
- Corrected the fluid scale generator trigger bug by removing the automatic popup showing when fixed/static variables are created.
- Extended the PHP `VariableManager::update()` method to accept and write `type` and `source_id` edits and correctly register/deregister relations in the dependency graph.

## v1.2.129

### Added
- Added an Alias mode to the variable creation panel with an explicit source-variable selector and a preview of the resulting `var(--token)` reference.
- Added builder UI tokens for the shared accent, surfaces, borders, text, danger state, and 38px control-height rhythm.

### Fixed
- Reconciled MV variables into every accessible Bricks/Code2Bricks runtime at builder startup and after mutations, including direct provider population so autocomplete does not depend on a stylesheet scan or a later focus refresh.
- Rebuilt the Media Studio replacement around Bricks' actual `wp.media` request and selection callback, allowing Bricks to receive the selected attachment through its native control path while leaving navigation clicks untouched.
- Forced search, variable-name, fixed-value, and related single-line controls to the shared 38px product input height.
- Prevented small fluid scales from producing duplicate rounded child names such as two `import-delete.2` rows.

## v1.2.128

### Fixed
- Mirrored MV-owned public tokens into Bricks global variables through the Bricks adapter so Code2Bricks can discover them, while preserving external variable ownership and removing only stale MV mirror rows.
- Refreshed the in-memory Bricks variable list and Code2Bricks provider immediately after variable mutations.
- Restored Media Studio replacement behavior for media-specific Bricks controls without reintroducing sidebar-navigation interception.
- Matched the HEX and channel value fields to the standard 38px input height.

## v1.2.127

### Fixed
- Normalized user-entered variable-name spaces to hyphens, allowed CSS-safe hyphens in stored variable segments, and kept internal dot separators out of the variable-name UI.
- Added horizontal padding to the HEX/RGB/HSL/OKLCH format controls.
- Refreshed the selected variable immediately after inline value saves instead of requiring the user to leave and reselect it.
- Reloaded generated `variables.css` after variable mutations so already-open Bricks tools such as Code2Bricks can discover newly created variables.
- Narrowed the Bricks Media Studio trigger bridge to explicit media controls so sidebar navigation icons no longer open Media Studio.
- Changed snapshots to capture variables, stable IDs, dependencies, and generator configuration as one versioned state.
- Made snapshot rollback transactional, recovery-snapshot-backed, and explicit about legacy snapshots that cannot restore generated relationships safely.
- Marked incomplete legacy snapshots as unavailable in the Snapshots UI instead of offering a misleading Restore action.
- Prevented imports from applying when their required pre-import safety snapshot cannot be created.
- Rejected duplicate names before variable rename writes and stopped recording rename history when the database update fails.
- Made generated variable CSS writes atomic and deduplicated declarations by public CSS name.
- Rejected create/rename operations that would make two stored variables resolve to the same public CSS custom property.
- Added CSS-name collision diagnostics and deduplicated legacy JSON/Figma exports by the newest stored variable row.
- Preserved valid single-segment tokens in DTCG export instead of silently omitting them.
- Made import application transactional: any failed change, CSS write, or sync-log write rolls the complete import back.
- Blocked unsupported type-change imports before mutation and added a custom confirmation before applying import deletions.
- Prevented generators from converting unrelated existing variables into generated children when names or public CSS names collide.
- Added checked generator database writes, duplicate-generator prevention, transactional attach/detach, and explicit regeneration failures.
- Made variable create, update, and delete operations transactional, including dependency, generator-regeneration, and generated-CSS writes.
- Replaced the delete-then-create generator UI flow with one transactional generator replacement, preserving the old scale if the new configuration fails.
- Surfaced generator, duplicate, and delete API failures instead of showing false success messages.
- Preserved generated-variable IDs during generator replacement and blocked removal of generated tokens that still have downstream alias/dependency usage.
- Made forced variable deletion traverse the complete dependency tree instead of leaving grandchildren with missing sources.
- Added a complete pre-cleanup snapshot and one transaction around duplicate/orphan/stale-variable cleanup, generator recovery, regeneration, and CSS export.
- Preserved alias source names in flat and DTCG exports and restored alias relationships when importing into a new variable set.
- Normalized flat import metadata instead of passing unvalidated relationship fields straight through.
- Added import preflight validation for duplicate names, public CSS collisions, missing/self-referencing alias sources, and conflicts with existing variables.
- Made source-relationship changes visible in import diffs and blocked them for explicit manual review instead of silently relinking variables.
- Changed rename propagation from substring replacement to exact CSS custom-property token matching, preventing a rename such as `--brand` from altering `--brand-alt`.
- Surfaced rename-propagation warnings after a successful variable rename.
- Prevented database read or JSON encoding failures from being stored as successful snapshots.
- Added pre-rollback snapshot structure checks for duplicate identities, invalid dependency rows, and malformed generator rows while still allowing an exact safety capture of a database that needs cleanup.
- Prevented alias relationship round trips from producing false value updates and exported an alias source's resolved value to Figma.
- Separated manually resolved CSS-name conflicts from automatic cleanup issues and stopped cleanup failures from showing a false success toast.
- Converted unexpected rename-propagation failures into visible warnings while keeping the successful core rename intact.
- Remapped source IDs, generators, and dependency edges to the kept row before database cleanup removes older duplicate variable records.
- Added diagnostics for broken alias sources, missing dependency links, and orphan dependency rows.
- Extended cleanup to repair valid alias/generated dependency links, remove generated rows whose source is gone, and delete orphan dependency records while leaving ambiguous aliases for manual relinking.
- Prevented cleanup from deleting orphan generated variables that still serve downstream dependents; those cases are now flagged for manual review.
- Added a recoverable backup-swap fallback for atomic generated-CSS replacement on hosts where `rename()` cannot overwrite an existing file directly.
- Corrected existing dependency edges when their stored relation type is stale and required imported generated-variable edge registration to succeed.
- Extended snapshot structure validation to reject duplicate dependency and generator IDs before rollback.
- Preserved generated child IDs across base-variable renames by matching owned color/scale children through stable generator suffixes and renaming those rows in place.
- Rejected snapshots whose alias/generated sources, dependency edges, or generator owners do not exist in the captured variable state, and stopped rollback before mutation when its database transaction cannot start.
- Refreshed alias CSS references inside variable rename transactions so source and generated-token renames cannot leave `var(--old-name)` declarations behind.
- Made viewport-driven fluid-variable recompilation transactional and surfaced database, CSS-write, and commit failures without retaining the new viewport settings.
- Made CSS import previews reconcile public CSS names back to unambiguous stored variable identities and infer simple `var(--token)` alias relationships.
- Expanded import previews to show and block unsupported type/source relationship changes before application.
- Surfaced direct sync-log database write failures instead of returning false success.
- Applied identity validation to legacy base-only snapshots and surfaced failures when stale generated dependency edges cannot be removed.

## v1.2.126

### Fixed
- Synchronized every fresh MV update check into WordPress's native `update_plugins` site transient so the first refresh no longer merely primes a later update display.
- Added a pre-render fresh manifest check on the WordPress Plugins and Updates screens, preventing stale six-hour manifest data from requiring a second refresh.
- Removed the 120ms restore gate and the additional panel entrance animation from hidden floating Elements/Structure restoration; the panel now rebuilds immediately at its validated saved geometry.

## v1.2.125

### Fixed
- Applied pending floating-panel restore geometry synchronously during shell creation, before the browser can paint the temporary reconstructed position.
- Removed the early delayed position correction that allowed the panel to flash near the bottom before moving to its saved location; retained a later fallback only for unusually delayed Bricks mounts.

## v1.2.124

### Fixed
- Kept an immutable hide-time geometry snapshot for floating Elements and Structure panels so shell reconstruction and width-preset initialization cannot overwrite the position and size that restore must use.
- Preserved pending restore metadata during normal floating-panel persistence, then cleared the one-time snapshot only after the rebuilt shell successfully receives it.

## v1.2.123

### Fixed
- Positioned the compact Bricks panel-preference control immediately before Undo instead of leaving it detached after Save.
- Added hover intent and a cursor bridge to the compact panel-control popover so it remains open while the pointer moves from the toolbar icon into the dialog.
- Saved floating Elements and Structure geometry at hide time and reapplied it on restore, clamping oversized or off-screen positions into the current viewport.

## v1.2.122

### Added
- Added account-backed UI preference storage through WordPress user meta so panel modes, positions, Builder Tools settings, CSS Studio preferences, Media Studio view preferences, and update skips can follow the logged-in account across browser sessions.
- Added the update-available notice to the main panel, its nested views, all standalone Studio panels, Settings, Help, and Mimam's Bar.

### Changed
- Consolidated the Bricks toolbar Elements and Structure controls into one compact MV panel-control icon with a branded hover/focus popover for dock, float, and hide actions.
- Corrected the WordPress plugin author name to `Hebronmimam`.

### Fixed
- Preserved whether Elements or Structure was floating or docked before hiding, so its restore icon returns it to the same mode.
- Kept toolbar control popovers stable instead of rebuilding their DOM while the panel state is unchanged.

## v1.2.121

### Changed
- Made the release workflow stricter by documenting the Notion Release Notes page as a required release step and backfill target.
- Recorded the fixed `left`/`top` floating-panel drag model as the default pattern for future MV floating surfaces.

### Fixed
- Made floating shell Wide and Max presets expand the inner Bricks panel subtree instead of leaving empty shell space beside a fixed-width panel.
- Moved floating shell header tooltips below the size/dock/hide controls so they no longer sit directly on top of the hovered icon.
- Changed Elements and Structure hide behavior to create separate restore icons near the MV control area, so hidden panels can animate down to a small icon and restore from their own icon.

## v1.2.120

### Changed
- Replaced the floating shell S/M/L/XL size language with MV-owned Narrow, Balanced, Wide, and Max presets.
- Updated floating shell dock, float, and hide icons so the controls read as Mimam's Var UI instead of mirroring the reference floating-panel plugin.

### Fixed
- Made Wide and Max floating shell presets apply larger real widths and persist those widths.
- Added Structure-specific floating shell spacing and toggle visibility rules so Bricks row expand/caret controls can remain visible and clickable while floating.

## v1.2.119

### Fixed
- Fixed Builder Tools floating Elements and Structure shells so the active shell wrapper is not removed by the stale-panel cleanup pass immediately after toggling float.
- Tightened vertical centering for the Bricks toolbar MV Elements and Structure mode controls.
- Reverted Media Studio collection context menus to Studio-relative row anchoring and refined lower-row clamping so menus stay attached to the clicked collection without drifting across the viewport.

## v1.2.118

### Changed
- Reworked Builder Tools floating Elements and Structure into MV-owned floating shells with custom headers, S/M/L/XL width presets, dock/hide controls, and Bricks toolbar panel mode controls.
- Set floating panel opacity default to 100% and migrated the old 78% default once for existing installs that had not changed it manually.

### Fixed
- Kept native Bricks Structure markup inside the floating shell so row expand/caret controls remain visible and clickable without opening Media Studio.
- Restored floating panels through the shell cleanup path so dock/hide state changes do not leave orphan wrappers or stale inline styles.
- Improved Media Studio collection context menus by anchoring them with viewport-fixed row geometry and a pointer that follows the clicked row, including lower sidebar rows.

## v1.2.117

### Fixed
- Stabilized Builder Tools floating Structure/Elements cleanup by removing inactive float root classes before restoring docked panel styles.
- Stopped floating Structure from wrapping Bricks internals in an MV layout wrapper, reducing dock-restore glitches.
- Scoped floating-panel button layout overrides to panel headers so Structure row expand/caret controls are not affected.
- Broadened floating Structure expand/caret visibility rules while keeping them scoped to Structure rows.
- Re-centered Media Studio collection context-menu pointers around the clicked row, including lower sidebar rows.

## v1.2.116

### Changed
- CSS Studio keeps the Variable Panel surface, but the stylesheet settings area is more compact and the CSS editor fills the remaining panel height.
- Media Studio collection menus now anchor inside the Studio layout context instead of relying on an unpositioned ancestor.

### Fixed
- Kept Bricks Structure expand/caret controls visible and clickable while the Structure panel is floating.
- Added targeted cleanup for disabled floating Structure/Elements panels so disabling one panel can restore its Bricks docked state even if another Builder Tools panel remains active.
- Further softened floating Structure/Elements shadows to avoid a glowing/pulsing feel.
- Made Rank Math internal links processed, Rank Math analytic object ID, and Rank Math SEO score read-only in Content Studio.

## v1.2.115

### Changed
- Added named UI surface styles to the AI UI rules so future work can refer to Variable Panel, Wide Studio, Medium Studio, and Sidecar Editor consistently.
- Changed CSS Studio back to the narrow Variable Panel style instead of the wide Studio modal style.

### Fixed
- Prevented Bricks Structure panel clicks from being captured by the Media Studio picker interceptor.
- Fixed CSS variable autocomplete so bare `--token` completions wrap as `var(--token)` unless the cursor is already inside `var(...)`.
- Improved Media Studio collection context menu anchoring by positioning from the clicked collection row instead of centering the menu over nearby rows.
- Added floating-panel style snapshot/restore cleanup so disabling floating Structure or Elements can return Bricks panels closer to their native docked state.
- Restored MV-created floating header wrappers during cleanup so Structure/Elements headers do not keep altered markup after disabling float.
- Repositioned the Elements floating drag handle inside the panel header and kept the Structure minimize control in the header row.
- Kept Structure expand/caret controls visible while floating and removed animated shadow transitions that made floating panels feel like they were pulsing.

## v1.2.114

### Added
- Added safe Content Studio REST endpoints to preview and apply a JetEngine-to-ACF mirror migration without deleting JetEngine data.
- Added local Figma dev sync documentation for using a reachable HTTPS tunnel URL instead of `localhost`.

### Changed
- Content Studio now separates Rank Math custom fields into their own section so SEO metadata is not mixed into general custom fields.
- Content Studio preserves richer custom-field/meta values for editing, including JSON-friendly complex values.
- CSS Studio now combines the stylesheet settings and editor into one studio panel instead of using the old detached sidecar layout.
- CSS autocomplete now wraps bare `--token` completions in `var(...)` unless the cursor is already inside a `var()` context.
- Studio input heights were tightened toward the shared 38px rhythm.

### Fixed
- Tightened CSS Recipes editor/form spacing and kept recipe actions below the editor.
- Reworked CSS Studio sizing overrides so it no longer inherits stale compact sidecar CSS.
- Improved Media Studio context-menu anchoring so menus align from the clicked collection row instead of the row above.
- Further stabilized floating Structure/Elements panel manual positions after drag/drop and kept the Structure shortcut rail hidden.
- Centered the Elements panel floating drag handle vertically in its header and moved the Structure minimize control to the far header edge.

## v1.2.113

### Changed
- Lowered floating Bricks Structure and Elements panels beneath Advanced Themer popovers while keeping MV Studio panels above normal admin/builder surfaces.
- Added common logical CSS properties to CSS Studio validation and autocomplete support.
- Content Studio now hides the WordPress content editor when a post type does not support default content and surfaces detected custom fields/meta in the in-studio editor.

### Fixed
- Reworked floating Structure/Elements dragging to update fixed `left`/`top` during drag instead of applying a temporary transform and snapping on drop.
- Prevented active CSS and rich-content editors from re-syncing external values while typing, reducing cursor jumps to the start of the editor.
- Tightened CSS Recipes layout so shortcode prefix/input spacing is clean and recipe action buttons sit directly under the editor.
- Centered the Media Studio collection context-menu pointer on the clicked row and kept the menu clamped inside the Studio panel.
- Added a settings-panel fallback so Settings no longer stays on a permanent loading state if the settings request fails.
- Refined floating Structure/Elements handle sizing, spacing, and z-index so the handles feel less intrusive.

## v1.2.112

### Changed
- Upgraded Content Studio's in-studio content field to a lightweight WordPress-like rich editor with paragraph, heading, list, bold/italic, and quote controls.
- Made Media Studio reopen faster by reusing an in-memory media/folder cache while refreshing data in the background.

### Fixed
- Tightened CSS Recipes form/editor sizing so recipe preview and new-recipe states use the full available editor width consistently.
- Re-anchored Media Studio collection context menus to the clicked collection row edge while keeping the menu clamped inside the Studio viewport.
- Replaced the floating Builder Tools drag handle icon with an inline SVG handle and removed the unwanted handle tooltip pseudo-element.
- Persisted floating panel width and clamped Structure restore/drag positions to reduce jumping and prevent panels from leaving the viewport.
- Scoped Bricks panel styling overrides to MV floating-panel states so Builder Tools CSS does not leak into unrelated Bricks/site UI.
- Applied the requested floating Structure spacing of `2rem` padding and `2rem` gap.

## v1.2.111

### Changed
- Removed the temporary MV Structure shortcut rail from the active Builder Tools UI and settings until the shortcut system is redesigned later.
- Moved CSS Studio's Save & Compile action to the code editor sidecar so compiling stays attached to the stylesheet being edited.
- Upgraded CSS Recipes editing to use the same CSS editor surface as CSS Studio, including recipe edit/cancel state and autocomplete sources.
- Reworked Content Studio's in-studio editor to use the full available workspace with sticky actions and an Advanced WordPress fields section.

### Fixed
- Added cleanup for MV Structure wrappers so docking the Structure panel can restore Bricks' default layout more reliably.
- Improved floating Structure and Elements drag handle styling and placement.
- Anchored Media Studio collection context menus inside the Studio panel so transformed panel positioning no longer pushes menus away from the clicked collection row.
- Reduced 1Password/autofill interference on CSS recipe name and shortcode fields.

## v1.2.110

### Changed
- Moved CSS recipe discovery out of CSS Studio so the stylesheet editor no longer shows recipe shortcode rows or recipe scope controls.
- Changed CSS Recipes Studio to list shortcodes only; clicking a shortcode loads its generated CSS into the recipe editor.
- Auto-prefixes new recipe shortcodes with `@` so users type only the shortcode name.
- Reworked Builder Tools Structure shortcut handling to use MV's owned fixed rail instead of moving external Bricks or Advanced Themer rails.

### Fixed
- Expanded Content Studio "Edit in Studio" so it can save core WordPress edit fields including title, slug, status, content, excerpt, parent/order, featured image ID, comments, pings, and template metadata.
- Re-anchored Media Studio collection context menus beside the clicked collection row and clamped them to the viewport.
- Added a local settings backup write for Builder Tools panel preferences to reduce future update-related settings loss.

## v1.2.109

### Fixed
- Removed CSS Studio from the large Studio modal sizing rules so the compact settings panel and code editor sidecar stay beside each other.
- Added explicit CSS Recipes centering and width rules so the Recipes Studio no longer opens stretched or clipped offscreen.
- Fixed Content Studio "Edit in Studio" by moving its save handler back into the Content Studio scope.
- Anchored Media Studio collection context menus to the actual pointer position and clamped them inside the viewport.
- Made MV-owned Media Studio collections draggable from the row as well as the handle, while detected folder-plugin collections now show a read-only lock affordance.
- Stabilized the Builder Tools Structure shortcut rail by mounting it to the Structure panel instead of positioning it as a separate fixed element during drag.

## v1.2.108

### Fixed
- Restored CSS Studio to the compact MV panel sizing with the code editor sidecar placed beside the main settings panel.
- Fixed Media Studio folder-plugin collection counts so detected folders show the same item count as the filtered gallery.
- Changed Media Studio sub-collection creation from an inline bottom-of-list form to a focused modal.
- Made Media Studio Bricks picker mode close after a successful insert or copy fallback.
- Scoped Media Studio conversion progress to the selected asset so another asset no longer inherits the converting state.
- Made Content Studio input heights match action buttons and made Edit in Studio start from pointer-down for more reliable in-panel editing.
- Stabilized Builder Tools floating handles and Structure shortcut rail visibility while dragging.
- Smoothed the toast countdown ring animation and prevented older toast timers from hiding newer messages.

### Changed
- Media Studio collection rows now label MV-owned collections versus detected folder-plugin collections, show sub-collection indentation, and expose drag only through an explicit handle.
- CSS Recipes now uses a centered studio width instead of stretching to the full available viewport.
- Added an agent UI-memory rule for clearly labelling MV-owned data versus adapter-detected data.

## v1.2.107

### Added
- Added an MV-styled right-click context menu for Media Studio collections.
- Added local Media Studio collection rename, remove, sub-collection creation, drag-to-reorder, and Shift-drop nesting.

### Fixed
- Fixed CSS Studio panel placement by excluding CSS Studio and CSS Recipes from the generic standalone-panel transform override.

### Changed
- Kept the update ZIP filename short as `mv-wp-v1.2.107.zip` while preserving the internal `variable-engine` plugin folder required by WordPress updates.

## v1.2.106

### Added
- Added a dedicated CSS Recipes Studio panel for managing reusable CSS shortcodes that autocomplete inside CSS Studio.

### Fixed
- Restored the floating Elements panel drag handle even when no Bricks element is selected.
- Lowered Builder Tools floating Elements, Structure, rail, tooltip, and minimized-restore layers below MV Studio overlays.
- Stabilized Structure shortcut rail dragging by clearing rail transforms and transitions after drag.
- Added a Bricks media-selection handoff so Media Studio can insert the chosen media URL into the originating Bricks control, with a copy fallback when no writable control is exposed.
- Changed Media Studio file conversion to show converting/converted toasts without switching the full Studio into a loading state.
- Made Content Studio clear stale rows immediately when switching sections and made Edit in Studio open the inline edit form more reliably.

### Changed
- Clarified the General setting label for single-panel versus multiple-panel behavior.

## v1.2.105

### Fixed
- Added file type metadata to Media Studio attachment details beside dimensions and size.
- Reworked Plugin Directory result cards so grid and list views align consistently.
- Fixed Plugin Studio navigation so installed-plugin filters switch back from Plugin Directory content instead of only changing the header.
- Fixed Content Studio navigation races so slower previous requests cannot repaint Pages after clicking another type.
- Reset Content Studio transient row/edit state when switching content groups.
- Changed Content Studio edit links to use server-provided Bricks links when available.
- Clamped floating Builder Tools panels to the viewport after drag, resize, and settings changes.
- Prevented dragging the floating Elements panel from moving the Structure shortcut rail.

## v1.2.104

### Added
- Plugin Directory browsing now has its own Plugin Studio sidebar section with preloaded popular plugins.
- Plugin Directory results now support grid/list views and display plugin icons when WordPress.org provides them.

### Fixed
- Restored CSS Studio to the slimmer MV panel sizing so the code editor area is visible again.
- Filtered duplicate default Pages/Posts out of the Content Studio custom post type list.
- Hid Advanced Themer/options-page field groups from Content Studio field-group lists.
- Made Content Studio field rows editable in Studio instead of only deletable.
- Improved branded focus styling so Studio inputs do not show the browser's blue focus ring.
- Broadened Bricks image/SVG/media/background click detection so Media Studio opens from more Bricks selector controls.
- Reduced Structure/Elements hide-versus-float conflicts by applying builder panel state classes to both document roots.

### Changed
- Plugin Studio directory search now fills the available result height and uses more readable plugin card text.
- The multiple-panel option is now labelled as Panel behavior with helper text in General settings.

## v1.2.103

### Added
- Plugin Studio can now search the WordPress.org plugin directory and install plugins directly from Studio.
- Plugin Studio can now upload plugin ZIP files from Studio.
- Added a General setting to allow either one MV panel at a time or multiple Studio panels at once.
- Added toast countdown ring animation so temporary messages show their remaining display time.

### Fixed
- Improved Plugin Studio text contrast so plugin descriptions and authors remain readable in the dark UI.
- Lowered MV panel and Builder Tools z-index layers so native WordPress/Bricks modals can appear above MV panels.
- Broadened the Bricks media-control bridge so common image, SVG, media, and background selectors open Media Studio instead of the default media library.
- Prevented Structure/Elements panel hide settings from hiding panels that are also configured to float.
- Improved Content Studio labels so in-Studio editing and Bricks editing are clearly separated.
- Expanded Content Studio metadata detection for ACF and JetEngine CPT definitions that are not exposed through normal registered post types.

### Changed
- Shortened the update package filename to the `mv-wp-vX.Y.Z.zip` format while keeping the internal WordPress plugin folder as `variable-engine`.

## v1.2.102

### Fixed
- Fixed Plugin Studio and CSS Studio standalone centering by excluding both Studio panels from the older utility-panel transform rule and including them in the center-screen Studio CSS block.
- Added outside-click closing behavior for Plugin Studio so it behaves like the other Studio panels.
- Replaced remaining native Settings and Modules checkboxes with the shared MV checkbox component for consistent styling across admin and builder.
- Added a lightweight Bricks media-control bridge that opens Media Studio from common Bricks image/media controls without mutating Bricks save state directly.

### Changed
- The v1.2.102 package includes the v1.2.101 Studio polish pass plus the final centering, checkbox, and media-control bridge fixes.

## v1.2.101

### Added
- Added Plugin Studio as a Builder Tools module for plugin listing, filtering, activation/deactivation, auto-update toggles, native update links, and inactive plugin deletion.
- Media Studio now supports batch deselect, in-modal new collection creation from a selection, and selected-asset collection membership display with an explicit add-to-collection action.
- Media Studio now has a branded media rename confirmation flow with title-only and file-URL rename options.
- Content Studio now supports in-studio title, slug, and status editing for content rows.

### Fixed
- Hardened Media Studio grid rendering with fixed grid tracks and stable media card dimensions to prevent asset overlap.
- Fixed folder collection membership refresh by including detected folder data in the collection filter dependencies.
- Preserved FileBird parent-folder relationships when detected, allowing sub-collections to appear instead of flattening all folders.
- Improved Content Studio grouping so default content, true custom post types, plugin/system types, and field groups are separated and can be hidden or shown.
- Replaced remaining native selects and checkbox lists in Studio forms with MV-styled controls.
- Restored CSS Studio workspace sizing inside the large studio shell.
- Rebuilt the MV-owned structure shortcut rail to use Phosphor icon classes and readable tooltip labels instead of copied shortcut letters.

### Changed
- Applied lean MV-styled scrollbars and consistent control heights across Studio surfaces.
- Clarified Media Studio replace/convert action labels and tooltips.

## v1.2.100

### Added
- Media Studio now loads media through paginated WordPress media requests instead of stopping at the first 60 items.
- Media Studio now reads supported media-folder plugin data through the existing folder endpoint and exposes detected folders as system collections.
- Media Studio now supports Ctrl/Cmd-click toggling and Shift-click range selection in grid and list views.
- Media Studio batch "Add to Collection" now opens a branded chooser and can route items into existing local collections or detected folder-plugin collections.
- Media Studio collection names can use slash paths for sub-collections, and the icon picker now loads the full local Phosphor duotone catalog for searchable icon selection.
- Media Studio now has replace-file and image-conversion actions for selected assets.
- Builder Tools adds a setting to use an MV-owned shortcut rail beside the floated Structure panel.

### Fixed
- Content Studio route calls now use the registered `variable-engine/v1` namespace, fixing empty/slow content loading caused by the old `ve/v1` path.
- Removed the redundant Content Hub title in Content Studio.
- Media Studio grid cards now use fixed grid tracks, internal selection rings, and no hover scaling to prevent overlap.
- Media Studio type/sort controls now use the branded custom select menu instead of native dropdowns.
- Media Studio file-name fields, font-file previews, dropzone behavior, and full-screen drag/drop feedback were restyled to match the product UI.
- Builder Tools delays Structure floating until Bricks loading/preloader screens are gone.
- Structure panel handle/resize tooltips now render above the panel chrome instead of being clipped below it.
- Figma pairing state is now stamped to the current Figma file identity so older/shared storage cannot make unrelated files appear paired to the same site.
- Dark UI surfaces were pulled back toward the product's black/charcoal palette instead of drifting blue.

## v1.2.99

### Added
- Media Studio: Added dynamic collection creation with a Phosphor duotone icon picker grid, allowing custom-defined collections instead of hardcoded defaults.
- Media Studio: Added MIME type filter dropdown (`all`, `image`, `video`, `audio`, `application`) next to search, along with persistent sort dropdown (Newest, A-Z, Largest).
- Media Studio: Implemented a transparency grid background (`.ve-checker-bg`) for images with transparent backgrounds in the gallery, list view, and attachment details preview.
- Media Studio: Replaced browser `confirm()` calls for deleting media and batch deletes with custom `ConfirmModal` overlays.
- Content Studio: Replaced browser `confirm()` calls for deleting posts, CPTs, field groups, and fields with custom `ConfirmModal` overlays.

### Fixed
- Media Studio: Removed the redundant "Asset Manager" sidebar title.
- Media Studio: Removed hardcoded "Testimonials" and "Team" collections, migrating any existing client lists to dynamic keys.
- Media Studio: Fixed preview pane switching latency (keyed details sidebar on selected item ID to force re-mount).
- Media Studio: Fixed selection highlight styling to prevent grid item overlap in gallery mode.
- Media Studio: Aligned file name field height, padding, and font family in the details sidebar.

## v1.2.98

### Added
- Content Studio: Guarded CPT and Field creation triggers and dropdown selections by provider activity (ACF/JetEngine) and set active provider defaults dynamically on load.

### Fixed
- Drag Freeze: Stabilized structure panel dragging by removing pointerup/mouseup propagation swallowing in `settings-manager.js`, allowing standard browser and builder drag cleanup to complete correctly.
- Centering: Fixed widescreen centering offsets for Content Studio and Media Studio by excluding them from the runtime injected `transform: none` rule in `builder-panel.js` and raising selector specificity in `builder.css`.
- Performance: Optimized the `globalPanelDOMObserver` MutationObserver by implementing a fast pre-filter to bypass queries on routine/minor builder DOM changes.

### Documentation
- Hardened the Antigravity/Codex operating layer with explicit agent quality, UI quality, validation, and release-runbook rules.
- Added canonical docs for agent quality gates, UI standards, and release packaging.
- Updated the setup script to prefer the current checked-in docs instead of regenerating stale weaker templates.

## v1.2.97

### Added
- Reintroduced post-v1.2.93 feature work in a syntax-valid state.
- Modules settings panel deactivation tab to turn off CSS Studio, Mimam's Bar, Content Studio, and Media Studio.
- Speed-dial FAB menu visibility logic: hides the FAB completely when any panel is open.
- Centered widescreen layouts (max-width: 1920px, height: 80dvh) for Content Studio CPT categories and Media Studio 3-column designs.
- Alt-text auto-save on blur, image dimensions, insert URL, and Copy HTML tag features in Media Studio.
- Multi-select batch actions (Add to collection, Compress, Delete) in Media Studio.

### Fixed
- Fixed settings reset on plugin update using robust direct `localStorage` fallbacks in `settings-manager.js`.
- Configured Mimam's Bar module to completely bypass asset enqueuing when deactivated.

## v1.2.96

### Fixed
- Recovery release based on the last confirmed working `v1.2.93` codebase.
- Removed the broken `v1.2.94`/`v1.2.95` JavaScript package line from the stable update path.
- Restored a syntax-valid WordPress panel package while keeping Content Studio and Media Studio at their last verified `v1.2.93` behavior.

### Notes
- The `v1.2.94` Content/Media Studio redesign and `v1.2.95` Modules settings work are intentionally held back for re-implementation in smaller verified slices.

## v1.2.95

### Added
- Added a "Modules" settings tab inside the Unified Settings Panel to let users deactivate individual tools (CSS Studio, Mimam's Bar, Content Studio, and Media Studio).
- Deactivating a tool immediately hides its icon/item from the speed-dial FAB menu and auto-closes any of its open panels.
- Configured Mimam's Bar to completely bypass asset enqueuing when deactivated.
- Organized the workspace root by moving utility script files (`update_notion_*.js`, `read_roadmap.py`, etc.) into a dedicated `scripts/` directory.

### Fixed
- Fixed FAB speed-dial visibility: the floating FAB menu icon now hides completely when any panel (Settings, Help, CSS Studio, Content Studio, Media Studio, or the main bar) is open.

## v1.2.94

### Added
- Upgraded Content Studio and Media Studio layouts to centered widescreen layouts (max-width: 1920px, height: 80dvh) that disable drag/float/dock controls.
- Added Content Studio sidebar navigation categories (Default CPTs, Custom Post Types, and Custom Field Groups) with a detailed tabular list displaying ID, Title, Slug, Status Badge (clickable to toggle), and dates.
- Added Media Studio three-column design layout (left sidebar collections, middle gallery/list layout modes, and right attachment details sidecar).
- Integrated Alt Text auto-save on blur, image dimensions, insert URL copy, and HTML tag copy in Media Studio sidecar.
- Added multi-select batch actions bar (Add to collection, Compress, and Delete) at the bottom of Media Studio.
- Styled all studio inputs, textareas, and dropdown selects with dark glassmorphic styling.

### Fixed
- Fixed settings reset on update by writing direct localStorage fallbacks in `settings-manager.js` storage functions.

## v1.2.93

### Fixed
- Fixed a bug in the Content Studio where selecting the "Content Type" (Page or Post) in the dropdown immediately redirected the user away and defaulted the created type to Post. It now uses a dedicated local state `contentType` and functions correctly.

## v1.2.92

### Added
- Implemented **Content Studio** floating panel to manage pages and posts, support search, quick-toggle status (Publish/Draft), and quick-create new pages/posts with a direct "Edit in Bricks" setup.
- Implemented **Media Studio** floating panel functioning as a premium, glassmorphic WordPress Media Gallery replacement with search, drag-and-drop file uploading, attachment details, and link/HTML copies.
- Added dedicated speed-dial FAB tray icons for the new Content Studio (`ph-file-text`) and Media Studio (`ph-image`).

### Fixed
- Fixed floated structure panel disappearing bug by bypassing bounding client rect height checks on exact matches, maintaining floating state when minimized or natively toggled.
- Fixed shortcut rail positioning by locking width to `44px` with compact padding, and attaching a style MutationObserver to shield positioning from Advanced Themer script overrides.

## v1.2.91

### Added
- Styled Advanced Themer shortcut tooltip balloons (`.brxc-shortcut-balloon`) to match the dark glassmorphic theme and elevated their `z-index` to `2147483015` to prevent rendering behind floated panels.
- Upgraded floated panels' resize indicators (`.mimams-bar-float-resize`) to render as a fully rounded centered pill handle that dynamically expands and glows with `#baf400` color on hover.

### Fixed
- Implemented a DOM `MutationObserver` on `document.body` to listen for additions of structure panel or shortcut rail nodes and synchronize them in real-time, preventing misalignment when Bricks or Advanced Themer detaches and re-appends them.

## v1.2.90

### Fixed
- Hotfixed a critical browser freezing and lag issue affecting standard WordPress Admin screens and the Bricks builder, caused by an infinite MutationObserver loop in the speed-dial FAB repositioning effect (`useEffect` inside `builder-panel.js`).
- Optimized the FAB position MutationObserver to run only when at least one side panel is open, completely bypassing body element observation on standard closed-state dashboard pages.
- Configured the observer to ignore mutations triggered on the speed-dial FAB itself (`fab.contains(m.target)`), ensuring layout mutations do not trigger recursive observer callbacks.

## v1.2.89

### Added
- Moved CSS Studio settings (SCSS Mode toggle, priority drag-and-drop sources list, index rebuild operations, and instructions) to a dedicated **"CSS Studio"** tab inside the main unified settings panel.
- Implemented real-time synchronization between the main settings panel and the CSS Studio editor using a custom event-driven observer pattern (`ve-css-settings-changed`).
- Implemented dynamic positioning for the speed-dial FAB wrap: it now remains visible when panels are open and automatically slides to the left edge of the active panel (or to the right edge if the panel is docked left), adjusting sub-menu and tooltip alignments accordingly.
- Speed-dial FAB icon now toggles the main panel on click (`sO(prev => !prev)` instead of `sO(true)`).

### Fixed
- Repaired floated structure panel detection in `isReasonableSidePanel`: exact class/ID selectors bypass size and position checks, ensuring the panel is correctly recognized, cached, and floated even when temporarily collapsed to `width: 0 !important` by CSS rules.

## v1.2.88

### Added
- Minimize button tooltip text updated to `"Minimize structure panel"`.

### Fixed
- Fixed macOS Genie minimization transition by capturing active panel coordinates right before minimization and adding transition delays to `visibility: hidden` (prevents instant opacity cutoffs and glitches).
- Fixed floating structure panel self-disappearing bug by enhancing `MutationObserver` checks to detect inline `display: none` resets and missing coordinate properties while ignoring active drag/resize operations.
- Fixed shortcut rail sync by dynamically querying the rail element in drag listeners if the node is detached/re-created by Bricks/Advanced Themer.
- Aligned shortcut rail position margin to a consistent `16px` everywhere.
- Fixed custom tooltip clipping and stacking by elevating the rail `z-index` to `2147483005` (with tooltips at `2147483010`) and applying `overflow: visible !important` to the rail and all of its descendants.

## v1.2.87

### Added
- Caches the shortcut rail DOM reference when dragging starts rather than querying the DOM repeatedly.
- Sets custom tooltip attribute `data-tooltip` to say "Minimize structure panel" on the minimize button.

### Fixed
- Fixed macOS Genie minimization transition by removing inline `transform: none !important` locking styles when minimized and drag-end cleans up.
- Fixed floating panel glitching/disappearing-on-own behavior by simplifying MutationObserver style loops (observes only `position`).
- Fixed custom tooltips display order by elevating shortcut rail z-index to `2147483004` (higher than structure panel `2147483002`).
- Fixed clipping of custom tooltips inside container components by setting `overflow: visible !important` on `[data-tooltip]` elements.

## v1.2.86

### Added
- Implemented smooth macOS-style Genie minimization scale and translate transitions for the floating structure panel and the rail.
- Added custom HTML tooltips (`data-tooltip`) styled like the bottom speed-dial tooltips to replace browser-default ones.
- Added drag transition bypass on the shortcut rail to prevent layout lag or misalignment during drag.

### Fixed
- Fixed stuck standalone panels (Settings, Help, CSS Studio) by styling their closed state (opacity 0, visibility hidden, pointer-events none, scale 0.9).
- Synchronized dragging offsets and aligned spacing margin to a consistent 16px between the structure panel and the shortcut rail.
- Increased default visibility and contrast of shortcut rail icons for better readability.

## v1.2.85

### Fixed
- Hotfixed a syntax error in settings-manager.js (removed extra closing brace at line 442) which broke JavaScript execution and caused settings to reset to default on reload.

## v1.2.84

### Fixed
- Fixed floating structure panel minimize/restore button functionality so it collapses and restores reliably on click.
- Stopped pointerdown event propagation on the minimize button to prevent builder drag handlers from intercepting the action.
- Enforced high-specificity CSS overrides targeting ID selectors (e.g. `#bricks-structure.mimams-bar-structure-minimized`) and the floating structure rail to prevent style resets during element inspection.

## v1.2.83

### Added
- Added lazy-mounted keep-alive state tracking for panels.
- Added mutual exclusion behavior between all open panels so that opening one closes another.
- Added scale-in/out visual transitions for standalone panels.
- Disabled standalone panel draggability while retaining handles.
- Styled standalone panel float handles to match the Variable panel, and applied a modern dot-pattern radial resize gripper.
- Applied brand color `#baf400` to Advanced Themer shortcut icons and hid empty shortcut wrappers in floating mode.
- Added dynamic semantic `ul` wrapper correction for Advanced Themer shortcut items.

### Fixed
- Clamped docked layout heights and positions on WP Admin load to prevent offscreen/misplaced panels.
- Resolved settings close button container height overflow via `flex: 1; min-height: 0`.
- Optimized query/variable name lowercasing for improved fuzzy search performance.
- Implemented a `MutationObserver` on floated panels to restore layout styles dynamically under inspector mutations.
- Intercepted pointerdown, mousedown, and click events on `.mimams-bar-toggle-button` in the capture phase to toggle Mimam's Bar and prevent duplicate open triggers.

## v1.2.82

### Fixed
- Fixed standalone panel heights (Settings, Help, CSS Studio) to dynamically match the Variable panel state (docked vs. floating) down to the pixel, removing hardcoded important heights.
- Repaired the structure panel minimize button SVG coordinates and attributes, resolving the malformed diagonal slash.
- Resolved Bricks and Advanced Themer shortcut rail positioning overlap and synchronization issues by applying explicit physical positioning and sizing overrides (`left`, `right: auto`, `top`, `bottom: auto`, `height` with `!important`).

## v1.2.81

### Fixed
- Matched Settings, Help, and CSS Studio standalone panel heights with the Variable panel exactly down to the pixel.
- Fixed CSS Studio editor sidecar visibility and layout clipping by removing nested scrollable containment.
- Fixed mutual exclusion of open panels so that multiple standalone panels can remain open at the same time.
- Synchronized BricksExtras and Advanced Themer shortcut rails in real-time on structure panel drag and resize.
- Fixed broken structure panel drag handle grab icon and positioned the minimize button as a header sibling.

## v1.2.80

### Added
- Implemented structure panel minimize/restore button interactions. Clicking the minimize button collapses the panel to a tree icon next to the bottom-right speed-dial, and clicking the restore button restores it.
- Enabled responsive sidecar placement for the CSS Studio sidecar (renders direct sibling outside scrollable `.ve-body`).

### Fixed
- Matched standalone panel heights (Settings, Help, CSS Studio) with the Variable panel.
- Fixed CSS Studio settings layout overlap and duplicate headers.
- Fixed BricksExtras shortcut container overlap by dynamically positioning it with a 16px space gap on the side of the structure panel, extracting it to the document body to prevent container containment clipping.
- Raised structure panel z-index to `2147483002` to render above canvas components.
- Fixed update transient caching by unsetting the stale response key in the updater cache.

## v1.2.79

### Fixed
- Restored pointer interaction (`pointer-events: auto !important`) on all standalone panels (Settings, Help, CSS Studio), allowing click, drag, and scroll operations instead of clicking through.
- Fixed the sticky "update available" notification issue by hooking into `upgrader_process_complete` and purging WordPress's plugin updates cache transient immediately after updates complete.

## v1.2.78

### Fixed
- Fixed bug where standalone panels (Settings, Help, CSS Studio) opened outside the viewport boundaries to the right.
- Excluded WordPress update pages (`update.php`, `update-core.php`) from loading the speed-dial menu assets to prevent centered floating icon visual issues.

## v1.2.77

### Added
- Consolidated settings: General/Vengine and Mimam's Bar settings are now unified inside a single standalone Settings panel using tabbed navigation.
- Extracted CSS Studio from the main command console into a standalone premium floating panel, toggled directly by the code icon in the bottom-right speed-dial menu.
- Enabled the speed-dial FAB menu and all floating panels (Settings, Help, CSS Studio) to render and function on standard WordPress Admin screens in addition to the Bricks builder.
- Implemented global click-outside-to-close behavior: clicking outside any standalone panel or command console automatically closes it.

### Fixed
- Fixed scrolling inside the floated Bricks structure panel by establishing correct flexbox height inheritance rules on nested panels.
- Standardized settings label text to "Undock Mimam's Bar and remember position".

## v1.2.76

### Added
- Extracted Settings and Help panels from the main Mimam's Bar command console into standalone floating windows.
- Added a Help icon (`ph('question')`) to the bottom-right speed-dial menu.
- Connected speed-dial menu clicks to directly toggle Settings and Help standalone panels.
- Enabled drag position management on standalone panels independently of the main bar's docking settings.
## v1.2.75

### Added
- Implemented a 'Deselect Element' shortcut for Bricks Builder, defaulting to Esc or Shift+D via settings.
- Refined the bottom-right hub into an intentional speed-dial menu that expands on hover.
- Added new settings to hide or show Vengine and Mimam's Bar icons from the Bricks top toolbar, dynamically clearing clutter.

## v1.2.74

### Fixed
- Replaced the hardcoded pixel-based initialization height for floating panels with a dynamic `70dvh` CSS value to keep the interface deeply responsive without constant recalibrations.
- Injected a dedicated `.mimams-bar-structure-wrapper` directly into the DOM to seamlessly group `#bricks-panel-header`, `.panel-content`, and `#brxcStructureTopContainer` within the Structure panel to maintain clean flex and grid behavior.
- Disabled transitions completely (`transition: none !important`) on floating host wrappers to outright kill any remaining native FOUC animations from Bricks.
- Scoped `#bricks-panel-header` `nowrap` explicitly to `#bricks-panel-elements` to ensure the structure panel continues to correctly wrap its header elements down.

### Fixed
- Enforced 70% window height explicitly for the floating structure panel to match the elements panel identically.
- Overhauled the early FOUC prevention script to instantly inject classes directly onto `<html>` before the body even paints, completely eliminating the brief docked flash on page load.
- Grouped the panel drag handle and `.title` element together in the DOM, forcing `.actions` underneath via flex wrapping for a cleaner header layout.
- Standardized the `#bricks-panel-search` input height so it strictly matches the height of its placeholder, resolving awkward vertical sizing.

### Fixed
- Eliminated the FOUC (Flash of Unstyled Content) where panels glitched in docked mode before switching to float on page load. A MutationObserver early script now seamlessly applies the floating classes as the body renders.
- Corrected `#bricks-panel-header` padding to ensure consistent spacing and aligned the drag handle perfectly horizontally on the same line as the header content.
- Ensured the Structure panel respects its native content height when floating instead of erroneously expanding to full screen height.
- Added a 2rem spacing gap before the BricksExtras shortcut container in the structure panel and aligned its items to the center.

### Fixed
- Fixed elements panel initializing with a short height by using window.innerHeight minus 100px.
- Unhid the structure panel header when floated, making the drag handle visible again.
- Removed the "Elements" and "Structure" text from the drag handles to prevent redundant "mimams bar floating panel" labels.
- Removed the 38px padding block start from floating panels and reset BricksExtras shortcut container padding to zero.

## v1.2.70

### Fixed

- Resolved the elements panel glitching on hide/unhide while floating by fixing the wrapper detection logic (`findPanelFromNode`) in `findElementsPanel`.
- Prevented the structure panel from losing its floating height when the browser resizes (e.g., opening Inspector) by explicitly setting `height` and `max-height` inline properties.
- Relocated the float drag handle inside the native Bricks panel headers.
- Replaced the online Phosphor icon with the local duotone SVG `dots-six-vertical-duotone.svg` for better styling.

## v1.2.69

### Fixed

- Resolved UI "freezes and lags" by removing forced heavy DOM scans during panel state retries in `settings-manager.js`.
- Fixed panel toggle glitches where Bricks panel widths would fall to 0, causing the detector to lose track and flicker.
- Re-introduced a safe wrapper bounding box logic (`markSafeHosts`) to collapse intermediate Bricks host wrappers, fixing "ghost background" when floating panels.

## v1.2.68

### Changed

- Re-wrote `builder.css` panel logic to use native Bricks ID selectors instead of tracking dynamic classes with JS.
- Replaced JS bounds-checking logic (`markFloatingHostChain`) with CSS-only visibility states based on `body` classes.

### Fixed

- Fixed floating panel bounds issues causing visual ghosting/flicker.
- Fixed the update manifest to resolve WordPress infinite update loop (bumped from v1.2.64 to v1.2.65, now correctly pointing to v1.2.68).

## Unreleased

### Added

- Added Vengine Agent OS folder structure and documentation files.

### Changed

- Updated `build.py` and manifest to `v1.2.66`.
- Redesigned floating panel UI drag handle to properly match the visual design of the main `.baqa-panel` header, adding left alignment, padding, and neon green panel titles (c01 fix).

### Fixed

- Hiding the Elements panel now correctly collapses its native wrapper completely (c02 fix). Fixed the `markFloatingHostChain` loop logic that was un-marking hidden elements due to `width: 0`, and added `opacity: 0`/`overflow: hidden` to ensure no grey background remains.
- **HOTFIX (v1.2.65)**: `VE_VERSION` constant on line 17 was still `1.2.64` while the header said `1.2.65`, causing an infinite WordPress update loop. Both now read `1.2.65`.

### Notes

- Future Antigravity agents should update this file after implementation work.
