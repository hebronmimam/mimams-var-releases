<?php
namespace VE\Sync;

use VE\Core\VariableManager;
use VE\Core\CssExporter;
use VE\Core\DependencyGraph;
use VE\Core\ThemeManager;
use VE\Core\ColorPaletteManager;
use VE\Database\Schema;

defined('ABSPATH') || exit;

/**
 * SyncEngine — orchestrates synchronization between Variable Engine and external sources.
 *
 * Current: JSON import/export (works with any Figma plan via plugins).
 * Future:  Figma REST API (Enterprise) can be wired in via FigmaClient.
 */
class SyncEngine {

    private VariableManager $manager;
    private DiffEngine $diff_engine;
    private SnapshotManager $snapshots;

    public function __construct() {
        $this->manager     = new VariableManager();
        $this->diff_engine = new DiffEngine();
        $this->snapshots   = new SnapshotManager();
    }

    /* ================================================================
     *  EXPORT: WordPress → JSON (for Figma import via plugin)
     * ================================================================ */

    /**
     * Export all base variables as Figma-compatible JSON.
     *
     * Output format matches DTCG (Design Token Community Group) spec:
     * {
     *   "color": {
     *     "primary": { "$value": "oklch(...)", "$type": "color" }
     *   },
     *   "space": {
     *     "md": { "$value": "clamp(...)", "$type": "dimension" }
     *   }
     * }
     *
     * @param string $format 'dtcg' | 'flat' | 'figma'
     * @return array
     */
    public function export( string $format = 'dtcg', bool $include_generated = false ): array {
        $variables = $this->dedupe_latest_by_name( ( new ThemeManager() )->apply_to_variables( $this->manager->get_all() ) );

        switch ( $format ) {
            case 'flat':
                return $this->export_flat( $variables, $include_generated );
            case 'figma':
                return $this->export_figma( $variables );
            default:
                return $this->export_dtcg( $variables );
        }
    }

    /**
     * DTCG format (Design Tokens Community Group, W3C draft).
     * Most widely supported by tools like Tokens Studio, Style Dictionary, etc.
     */
    private function export_dtcg( array $variables ): array {
        $output = [];

        foreach ( $variables as $v ) {
            // Skip generated variables — they regenerate from base.
            if ( ( $v['type'] ?? '' ) === 'generated' ) continue;

            $parts = explode( '.', $v['name'] );
            $ns    = $parts[0];
            // Resolve DTCG $type from namespace.
            $type = $this->ns_to_dtcg_type( $ns );

            $source_name = '';
            if ( 'alias' === ( $v['type'] ?? '' ) && ! empty( $v['source_id'] ) ) {
                $source = $this->manager->get( (int) $v['source_id'] );
                $source_name = (string) ( $source['name'] ?? '' );
            }
            $export_value = $source_name ? '{' . $source_name . '}' : $v['value'];

            // Build nested structure.
            $ref = &$output;
            foreach ( $parts as $i => $segment ) {
                if ( $i === count( $parts ) - 1 ) {
                    $ref[ $segment ] = [
                        '$value' => $export_value,
                        '$type'  => $type,
                    ];
                    if (
                        ! empty( $v['css_value'] )
                        && $v['css_value'] !== $v['value']
                        || 'alias' === ( $v['type'] ?? '' )
                    ) {
                        $ref[ $segment ]['$extensions'] = [
                            'com.variable-engine' => [
                                'css_value' => $v['css_value'],
                                'wp_id'     => (int) $v['id'],
                                'var_type'  => $v['type'] ?? 'base',
                                'source_name' => $source_name,
                            ],
                        ];
                    }
                } else {
                    if ( ! isset( $ref[ $segment ] ) || ! is_array( $ref[ $segment ] ) ) {
                        $ref[ $segment ] = [];
                    }
                    $ref = &$ref[ $segment ];
                }
            }
            unset( $ref );
        }

        return $output;
    }

    /**
     * Flat format — simple name/value pairs.
     */
    private function export_flat( array $variables, bool $include_generated = false ): array {
        $output = [];
        $seen   = [];

        // Keep one current row per variable name. This protects Figma sync from
        // duplicate DB rows left by older development builds or repeated tests.
        usort( $variables, static function ( $a, $b ) {
            return (int) ( $b['id'] ?? 0 ) <=> (int) ( $a['id'] ?? 0 );
        } );

        foreach ( $variables as $v ) {
            if ( !$include_generated && ( $v['type'] ?? '' ) === 'generated' ) continue;

            $name = $v['name'] ?? '';
            if ( ! $name || isset( $seen[ $name ] ) ) continue;
            $seen[ $name ] = true;

            $val = $v['value'] ?? '';
            // Fallback to css_value if value is empty
            if ( empty( $val ) && ! empty( $v['css_value'] ) ) {
                $val = $v['css_value'];
            }
            $css_name = $this->manager->to_css_name( $name );
            $public_name = ltrim( $css_name, '-' );
            $id = (int) ( $v['id'] ?? 0 );
            $source_id = (int) ( $v['source_id'] ?? 0 );
            $generator_type = $v['generator_type'] ?? '';
            $type = $v['type'] ?? 'base';
            $source = $source_id > 0 ? $this->manager->get( $source_id ) : null;
            $source_name = (string) ( $source['name'] ?? '' );
            $previous_public_names = $this->previous_public_names_for_export( $id, $source_id, $public_name, $type );

            $output[] = [
                'id'          => $id,
                'source_id'   => $source_id,
                'source_name' => $source_name,
                'generator_type' => $generator_type,
                'identity_key' => $this->identity_key_for_export( $id, $source_id, $generator_type, $public_name, $type ),
                'name'        => $name,
                'public_name' => $public_name,
                'previous_public_names' => $previous_public_names,
                'css_name'    => $css_name,
                'value'       => $val,
                'namespace'   => $v['namespace'] ?? '',
                'type'        => $type,
            ];
        }

        usort( $output, static function ( $a, $b ) {
            return strcmp( $a['name'] ?? '', $b['name'] ?? '' );
        } );

        return $output;
    }

    /**
     * Figma-like format — grouped by collection (namespace).
     * Useful for Figma plugin import.
     */
    private function export_figma( array $variables ): array {
        $collections = [];
        $seen = [];
        $variables_by_id = [];
        foreach ( $variables as $candidate ) {
            $variables_by_id[ (int) ( $candidate['id'] ?? 0 ) ] = $candidate;
        }

        foreach ( $variables as $v ) {
            if ( ( $v['type'] ?? '' ) === 'generated' ) continue;
            $name = (string) ( $v['name'] ?? '' );
            if ( '' === $name || isset( $seen[ $name ] ) ) continue;
            $seen[ $name ] = true;
            $figma_value = (string) ( $v['value'] ?? '' );
            if ( 'alias' === ( $v['type'] ?? '' ) && ! empty( $v['source_id'] ) ) {
                $source = $variables_by_id[ (int) $v['source_id'] ] ?? null;
                if ( $source ) {
                    $figma_value = (string) ( $source['value'] ?? $source['css_value'] ?? '' );
                }
            }

            $ns = $v['namespace'] ?? explode('.', $name)[0];
            if ( ! isset( $collections[ $ns ] ) ) {
                $collections[ $ns ] = [
                    'name'      => ucfirst( $ns ),
                    'modes'     => [ 'default' ],
                    'variables' => [],
                ];
            }

            // Figma variable name uses / separator, not dots.
            $fig_name = str_replace( '.', '/', $name );
            $resolved = $this->resolve_figma_type( $ns, $figma_value );

            $collections[ $ns ]['variables'][] = [
                'name'         => $fig_name,
                'resolvedType' => $resolved['type'],
                'valuesByMode' => [
                    'default' => $resolved['value'],
                ],
            ];
        }

        return [ 'collections' => array_values( $collections ) ];
    }

    /* ================================================================
     *  IMPORT: JSON → WordPress (preview + apply)
     * ================================================================ */

    /**
     * Parse an imported JSON file and normalize to VE flat format.
     *
     * Accepts:
     *   - DTCG format (nested with $value/$type)
     *   - VE flat format (array of name/value objects)
     *   - Figma plugin export (collections with variables)
     *   - Tokens Studio format
     *
     * @param array|string $data Decoded JSON array or JSON string
     * @return array Normalized flat variable list
     */
    public function normalize_import( $data ): array {
        if ( is_string( $data ) ) {
            $data = json_decode( $data, true );
        }
        if ( ! is_array( $data ) ) {
            return [];
        }

        // Detect format.
        // 1. VE flat format: array of objects with 'name' and 'value'.
        if ( isset( $data[0]['name'] ) && isset( $data[0]['value'] ) ) {
            return $this->normalize_flat_rows( $data );
        }

        // 2. Figma collections format.
        if ( isset( $data['collections'] ) ) {
            return $this->parse_figma_collections( $data['collections'] );
        }

        // 3. DTCG / Tokens Studio nested format.
        return $this->parse_dtcg( $data );
    }

    /**
     * Preview an import — returns the diff without applying.
     *
     * @param array $imported Normalized variable list from normalize_import()
     * @return array { changes: [...], summary: {...} }
     */
    public function preview_import( array $imported ): array {
        $current = $this->manager->get_all();
        $imported = $this->resolve_public_import_names( $imported, $current );
        $changes = $this->diff_engine->diff( $imported, $current );
        $summary = $this->diff_engine->summary( $changes );

        return [
            'changes' => $changes,
            'summary' => $summary,
        ];
    }

    public function prepare_import_rows( array $imported ): array {
        return $this->resolve_public_import_names( $imported, $this->manager->get_all() );
    }

    /**
     * Keep resolvable rows from a detected external source while reporting
     * orphan aliases separately. External stores may retain references to
     * variables that no longer exist; one such row must not block every valid
     * variable in a migration.
     *
     * Normal file and System Bundle imports still use validate_import_rows()
     * and remain strict.
     *
     * @param array      $imported Prepared import rows.
     * @param array|null $current  Optional current rows for deterministic tests.
     * @return array { variables: array, warnings: array, skipped_aliases: int }
     */
    public function partition_resolvable_external_rows( array $imported, ?array $current = null ): array {
        $current = null === $current ? $this->manager->get_all() : $current;
        $available = [];

        foreach ( $current as $variable ) {
            $name = strtolower( trim( (string) ( $variable['name'] ?? '' ) ) );
            if ( '' !== $name ) {
                $available[ $name ] = true;
            }
        }
        foreach ( $imported as $variable ) {
            $name = strtolower( trim( (string) ( $variable['name'] ?? '' ) ) );
            if ( '' !== $name ) {
                $available[ $name ] = true;
            }
        }

        $kept = array_values( $imported );
        $skipped = [];
        do {
            $changed = false;
            $next = [];
            foreach ( $kept as $variable ) {
                $type = strtolower( trim( (string) ( $variable['type'] ?? 'base' ) ) );
                $name = strtolower( trim( (string) ( $variable['name'] ?? '' ) ) );
                $source_name = strtolower( trim( (string) ( $variable['source_name'] ?? '' ) ) );
                if ( 'alias' === $type && ( '' === $source_name || ! isset( $available[ $source_name ] ) ) ) {
                    $skipped[ $name ] = [
                        'name'        => $name,
                        'source_name' => $source_name,
                    ];
                    unset( $available[ $name ] );
                    $changed = true;
                    continue;
                }
                $next[] = $variable;
            }
            $kept = $next;
        } while ( $changed );

        $warnings = [];
        foreach ( $skipped as $row ) {
            $source = $row['source_name'] ?: 'an unidentified source';
            $warnings[] = "Skipped external alias '{$row['name']}' because source '{$source}' was not found.";
        }

        return [
            'variables'       => $kept,
            'warnings'        => $warnings,
            'skipped_aliases' => count( $skipped ),
        ];
    }

    public function validate_import_rows( array $imported ): array {
        $errors = [];
        $names = [];
        $css_names = [];
        $current = $this->manager->get_all();
        $current_by_name = [];

        foreach ( $current as $variable ) {
            $current_by_name[ (string) ( $variable['name'] ?? '' ) ] = $variable;
        }

        foreach ( $imported as $index => $variable ) {
            $name = (string) ( $variable['name'] ?? '' );
            $type = (string) ( $variable['type'] ?? 'base' );
            $source_name = (string) ( $variable['source_name'] ?? '' );

            if ( ! preg_match( VariableManager::NAME_PATTERN, $name ) ) {
                $errors[] = 'Row ' . ( $index + 1 ) . " has an invalid variable name '{$name}'.";
                continue;
            }
            if ( isset( $names[ $name ] ) ) {
                $errors[] = "Import contains duplicate variable name '{$name}'.";
            }
            $names[ $name ] = true;

            $css_name = $this->manager->to_css_name( $name );
            if ( isset( $css_names[ $css_name ] ) && $css_names[ $css_name ] !== $name ) {
                $errors[] = "Import variables '{$css_names[$css_name]}' and '{$name}' both resolve to {$css_name}.";
            }
            $css_names[ $css_name ] = $name;

            if ( 'alias' === $type ) {
                if ( '' === $source_name ) {
                    $errors[] = "Alias '{$name}' does not identify its source variable.";
                } elseif ( $source_name === $name ) {
                    $errors[] = "Alias '{$name}' cannot reference itself.";
                }
            }
        }

        foreach ( $imported as $variable ) {
            $name = (string) ( $variable['name'] ?? '' );
            $type = (string) ( $variable['type'] ?? 'base' );
            $source_name = (string) ( $variable['source_name'] ?? '' );
            if ( 'alias' === $type && $source_name && ! isset( $names[ $source_name ] ) && ! isset( $current_by_name[ $source_name ] ) ) {
                $errors[] = "Alias '{$name}' references missing source '{$source_name}'.";
            }

            $css_name = $this->manager->to_css_name( $name );
            foreach ( $current as $existing ) {
                $existing_name = (string) ( $existing['name'] ?? '' );
                if ( $existing_name !== $name && $this->manager->to_css_name( $existing_name ) === $css_name ) {
                    $errors[] = "Imported variable '{$name}' conflicts with existing variable '{$existing_name}' at {$css_name}.";
                    break;
                }
            }
        }

        return array_values( array_unique( $errors ) );
    }

    /**
     * Apply a set of diff changes.
     * Creates a snapshot first.
     *
     * @param array $changes Output from preview_import()['changes']
     * @param array $options  'skip_deletes' => bool
     * @return array { applied: int, snapshot_id: int, errors: [] }
     */
    public function apply_changes( array $changes, array $options = [] ): array {
        $skip_deletes = $options['skip_deletes'] ?? false;
        $preflight_errors = $this->validate_changes( $changes );
        if ( ! empty( $preflight_errors ) ) {
            return [
                'applied'     => 0,
                'snapshot_id' => 0,
                'rolled_back' => false,
                'errors'      => $preflight_errors,
            ];
        }

        // Snapshot before applying, unless a broader portable import already
        // created the complete recovery point.
        $snapshot_id = isset( $options['snapshot_id'] ) ? (int) $options['snapshot_id'] : 0;
        if ( $snapshot_id <= 0 ) {
            $snapshot_id = $this->snapshots->create('pre_import');
            if ( is_wp_error( $snapshot_id ) ) {
                return [
                    'applied'     => 0,
                    'snapshot_id' => 0,
                    'errors'      => [ $snapshot_id->get_error_message() ],
                ];
            }
        }

        $applied = 0;
        $errors  = [];
        $handled = [];
        $changes_by_name = [];
        global $wpdb;

        foreach ( $changes as $candidate ) {
            if ( ! empty( $candidate['name'] ) ) {
                $changes_by_name[ (string) $candidate['name'] ] = $candidate;
            }
        }

        if ( false === $wpdb->query( 'START TRANSACTION' ) ) {
            return [
                'applied'     => 0,
                'snapshot_id' => $snapshot_id,
                'rolled_back' => false,
                'errors'      => [ $wpdb->last_error ?: 'Could not start the import transaction.' ],
            ];
        }

        try {
            foreach ( $changes as $c ) {
                $action = $c['action'] ?? '';
                $name   = $c['name'] ?? '';

                if ( '' !== $name && isset( $handled[ $name ] ) ) {
                    continue;
                }

                $error_count = count( $errors );
                switch ( $action ) {
                    case 'add':
                        $create = [
                            'name'  => $name,
                            'value' => $c['value'] ?? '',
                            'type'  => $c['type'] ?? 'base',
                        ];
                        $source_name = (string) ( $c['source_name'] ?? '' );
                        if ( 'alias' === $create['type'] ) {
                            $source = $this->ensure_named_import_source( $source_name, $changes_by_name, $handled, $applied, $errors );
                            if ( ! $source ) {
                                $errors[] = "Add '{$name}': alias source '{$source_name}' was not found.";
                                break;
                            }
                            $create['source_id'] = (int) $source['id'];
                        } else {
                            $base = $source_name
                                ? $this->ensure_named_import_source( $source_name, $changes_by_name, $handled, $applied, $errors )
                                : $this->ensure_imported_variant_base( $name, $changes_by_name, $handled, $applied, $errors, (string) ( $c['value'] ?? '' ) );
                        }
                        if ( ! empty( $base ) ) {
                            $create['type']           = 'generated';
                            $create['source_id']      = (int) $base['id'];
                            $create['generator_type'] = (string) ( $c['generator_type'] ?? $this->generator_type_for_name( $name ) );
                        }
                        $result = $this->manager->create( $create );
                        if ( is_wp_error( $result ) ) {
                            $errors[] = "Add '{$name}': " . $result->get_error_message();
                        } else {
                            $applied++;
                        }
                        break;

                    case 'update':
                        $existing = $this->manager->get_by_name( $name );
                        if ( $existing ) {
                            $source_name = strtolower( trim( (string) ( $c['source_name'] ?? '' ) ) );
                            $base = $source_name
                                ? $this->ensure_named_import_source( $source_name, $changes_by_name, $handled, $applied, $errors )
                                : $this->ensure_imported_variant_base( $name, $changes_by_name, $handled, $applied, $errors, (string) ( $c['new_value'] ?? '' ) );
                            if ( $base ) {
                                $result = $this->update_imported_generated_variable(
                                    $existing,
                                    (string) ( $c['new_value'] ?? '' ),
                                    (int) $base['id'],
                                    (string) ( $c['generator_type'] ?? $this->generator_type_for_name( $name ) )
                                );
                            } else {
                                $result = $this->manager->update( (int)$existing['id'], [
                                    'value' => $c['new_value'] ?? '',
                                ]);
                            }
                            if ( is_wp_error( $result ) ) {
                                $errors[] = "Update '{$name}': " . $result->get_error_message();
                            } else {
                                $applied++;
                            }
                        }
                        break;

                    case 'repair_generated':
                        $existing = $this->manager->get_by_name( $name );
                        if ( $existing ) {
                            $source_name = (string) ( $c['source_name'] ?? $c['base_name'] ?? '' );
                            $base = $source_name
                                ? $this->ensure_named_import_source( $source_name, $changes_by_name, $handled, $applied, $errors )
                                : $this->ensure_imported_variant_base( $name, $changes_by_name, $handled, $applied, $errors, (string) ( $c['value'] ?? $existing['value'] ?? '' ) );
                            if ( $base ) {
                                $result = $this->update_imported_generated_variable(
                                    $existing,
                                    (string) ( $c['value'] ?? $existing['value'] ?? '' ),
                                    (int) $base['id'],
                                    (string) ( $c['generator_type'] ?? $this->generator_type_for_name( $name ) )
                                );
                                if ( is_wp_error( $result ) ) {
                                    $errors[] = "Repair '{$name}': " . $result->get_error_message();
                                } else {
                                    $applied++;
                                }
                            } else {
                                $errors[] = "Repair '{$name}': base variable not found.";
                            }
                        }
                        break;

                    case 'delete':
                        if ( $skip_deletes ) continue 2;
                        $existing = $this->manager->get_by_name( $name );
                        if ( $existing ) {
                            $result = $this->manager->delete( (int)$existing['id'], true );
                            if ( is_wp_error( $result ) ) {
                                $errors[] = "Delete '{$name}': " . $result->get_error_message();
                            } else {
                                $applied++;
                            }
                        }
                        break;

                    case 'relationship_change':
                        $existing = $this->manager->get_by_name( $name );
                        $source_name = strtolower( trim( (string) ( $c['source_name'] ?? '' ) ) );
                        if ( ! $existing ) {
                            $errors[] = "Relink '{$name}': variable was not found.";
                            break;
                        }
                        $source = $this->ensure_named_import_source( $source_name, $changes_by_name, $handled, $applied, $errors );
                        if ( ! $source ) {
                            $errors[] = "Relink '{$name}': source '{$source_name}' was not found.";
                            break;
                        }
                        $relationship_type = (string) ( $c['relationship_type'] ?? $existing['type'] ?? 'alias' );
                        if ( 'generated' === $relationship_type ) {
                            $result = $this->update_imported_generated_variable(
                                $existing,
                                (string) ( $c['value'] ?? $existing['value'] ?? '' ),
                                (int) $source['id'],
                                (string) ( $c['generator_type'] ?? $existing['generator_type'] ?? $this->generator_type_for_name( $name ) )
                            );
                        } else {
                            $result = $this->manager->update( (int) $existing['id'], [
                                'type'      => 'alias',
                                'source_id' => (int) $source['id'],
                                'value'     => '',
                            ] );
                        }
                        if ( is_wp_error( $result ) ) {
                            $errors[] = "Relink '{$name}': " . $result->get_error_message();
                        } else {
                            $applied++;
                        }
                        break;

                    case 'type_change':
                        throw new \RuntimeException( "Type change '{$name}' requires manual review." );
                }

                if ( count( $errors ) > $error_count ) {
                    throw new \RuntimeException( end( $errors ) );
                }
            }

            ( new ColorPaletteManager() )->repair_memberships();

            if ( ! ( new CssExporter() )->export() ) {
                throw new \RuntimeException( 'The generated CSS file could not be written.' );
            }

            if ( empty( $options['skip_log'] ) ) {
                $logged = $wpdb->insert(
                    Schema::table('sync_logs'),
                    [
                        'source'      => 'json_import',
                        'author'      => wp_get_current_user()->user_login ?? 'system',
                        'diff'        => wp_json_encode( $changes ),
                        'snapshot_id' => $snapshot_id,
                    ],
                    ['%s','%s','%s','%d']
                );
                if ( false === $logged ) {
                    throw new \RuntimeException( $wpdb->last_error ?: 'Could not write the import log.' );
                }
            }

            if ( false === $wpdb->query( 'COMMIT' ) ) {
                throw new \RuntimeException( $wpdb->last_error ?: 'Could not commit the import transaction.' );
            }
        } catch ( \Throwable $e ) {
            $wpdb->query( 'ROLLBACK' );
            ( new CssExporter() )->export();
            $message = $e->getMessage();
            if ( empty( $errors ) || end( $errors ) !== $message ) {
                $errors[] = $message;
            }

            return [
                'applied'     => 0,
                'snapshot_id' => $snapshot_id,
                'rolled_back' => true,
                'errors'      => $errors,
            ];
        }

        return [
            'applied'     => $applied,
            'snapshot_id' => $snapshot_id,
            'rolled_back' => false,
            'errors'      => $errors,
        ];
    }

    private function validate_changes( array $changes ): array {
        $errors = [];
        $allowed = [ 'add', 'update', 'delete', 'repair_generated', 'relationship_change' ];

        foreach ( $changes as $index => $change ) {
            if ( ! is_array( $change ) ) {
                $errors[] = 'Change #' . ( $index + 1 ) . ' is invalid.';
                continue;
            }

            $action = (string) ( $change['action'] ?? '' );
            $name = (string) ( $change['name'] ?? '' );
            if ( 'type_change' === $action ) {
                $errors[] = "Type change '{$name}' requires manual review before import.";
                continue;
            }
            if ( ! in_array( $action, $allowed, true ) ) {
                $errors[] = "Unsupported import action '{$action}'.";
            }
            if ( ! preg_match( VariableManager::NAME_PATTERN, $name ) ) {
                $errors[] = "Invalid variable name '{$name}' in import.";
            }
        }

        return array_values( array_unique( $errors ) );
    }

    /**
     * Figma sends generated-ish color variants as names like
     * color.brand.primary.d.4 or color.brand.primary.20. Treat those as
     * generated children of color.brand.primary on import.
     */
    private function imported_variant_base_name( string $name, array $changes_by_name = [] ): string {
        $candidate = '';
        if ( preg_match( '/^(.*)\.(d|l|t)\.\d+$/', $name, $m ) ) {
            $candidate = (string) $m[1];
        } elseif ( preg_match( '/^(.*)\.\d+$/', $name, $m ) ) {
            $candidate = (string) $m[1];
        } else {
            $parts = explode( '.', $name );
            $leaf  = strtolower( (string) end( $parts ) );
            if ( count( $parts ) > 1 && $this->is_variant_leaf( $leaf ) ) {
                array_pop( $parts );
                $candidate = implode( '.', $parts );
            }
        }

        if ( '' === $candidate ) {
            return '';
        }

        if ( $this->manager->get_by_name( $candidate ) || isset( $changes_by_name[ $candidate ] ) ) {
            return $candidate;
        }

        return $candidate . '.base';
    }

    private function is_variant_leaf( string $leaf ): bool {
        return (bool) preg_match( '/^(?:\d+(?:\.\d+)?|[2-9]xl|xl|l|m|s|xs|[2-9]xs|full|none|thin|extra-light|light|regular|normal|medium|semibold|semi-bold|bold|extra-bold|black)$/', $leaf );
    }

    private function ensure_imported_variant_base( string $name, array $changes_by_name, array &$handled, int &$applied, array &$errors, string $fallback_value = '' ): ?array {
        $base_name = $this->imported_variant_base_name( $name, $changes_by_name );
        if ( '' === $base_name ) {
            return null;
        }

        $existing = $this->manager->get_by_name( $base_name );
        if ( $existing ) {
            return $existing;
        }

        $base_change = $changes_by_name[ $base_name ] ?? null;
        $base_value  = is_array( $base_change ) ? (string) ( $base_change['value'] ?? '' ) : $fallback_value;
        $result = $this->manager->create([
            'name'  => $base_name,
            'value' => $base_value,
            'type'  => 'base',
        ]);

        if ( is_wp_error( $result ) ) {
            $errors[] = "Add '{$base_name}': " . $result->get_error_message();
            return null;
        }

        $handled[ $base_name ] = true;
        $applied++;

        return is_array( $result ) ? $result : $this->manager->get_by_name( $base_name );
    }

    private function ensure_named_import_source( string $source_name, array $changes_by_name, array &$handled, int &$applied, array &$errors ): ?array {
        if ( '' === $source_name ) {
            return null;
        }

        $existing = $this->manager->get_by_name( $source_name );
        if ( $existing ) {
            return $existing;
        }

        $source_change = $changes_by_name[ $source_name ] ?? null;
        if ( ! is_array( $source_change ) || 'add' !== ( $source_change['action'] ?? '' ) ) {
            return null;
        }

        $result = $this->manager->create( [
            'name'  => $source_name,
            'value' => (string) ( $source_change['value'] ?? '' ),
            'type'  => 'base',
        ] );
        if ( is_wp_error( $result ) ) {
            $errors[] = "Add '{$source_name}': " . $result->get_error_message();
            return null;
        }

        $handled[ $source_name ] = true;
        $applied++;
        return $result;
    }

    private function generator_type_for_name( string $name ): string {
        $ns = explode( '.', $name )[0] ?? '';
        if ( 'color' === $ns ) {
            return 'color';
        }
        if ( in_array( $ns, [ 'font', 'heading', 'text', 'typography' ], true ) ) {
            return 'typography';
        }
        if ( 'radius' === $ns ) {
            return 'radius';
        }
        if ( 'size' === $ns ) {
            return 'size';
        }
        return 'spacing';
    }

    private function update_imported_generated_variable( array $existing, string $value, int $source_id, string $generator_type = 'color' ) {
        global $wpdb;

        $value = sanitize_text_field( $value );
        $generator_type = sanitize_key( $generator_type ?: 'color' );
        $updated = $wpdb->update(
            Schema::table( 'variables' ),
            [
                'type'           => 'generated',
                'value'          => $value,
                'css_value'      => $value,
                'source_id'      => $source_id,
                'generator_type' => $generator_type,
            ],
            [ 'id' => (int) $existing['id'] ],
            [ '%s', '%s', '%s', '%d', '%s' ],
            [ '%d' ]
        );

        if ( false === $updated ) {
            return new \WP_Error( 've_update_failed', $wpdb->last_error, [ 'status' => 500 ] );
        }

        $graph = new DependencyGraph();
        if ( ! empty( $existing['source_id'] ) && (int) $existing['source_id'] !== $source_id ) {
            if ( ! $graph->remove( (int) $existing['source_id'], (int) $existing['id'] ) ) {
                return new \WP_Error( 've_dependency_failed', 'Could not remove the previous generated-variable dependency.', [ 'status' => 500 ] );
            }
        }
        if ( ! $graph->register( $source_id, (int) $existing['id'], 'generated' ) ) {
            return new \WP_Error( 've_dependency_failed', 'Could not register the imported generated-variable dependency.', [ 'status' => 500 ] );
        }

        return $this->manager->get( (int) $existing['id'] );
    }

    /* ================================================================
     *  FORMAT PARSERS
     * ================================================================ */

    /**
     * Parse DTCG / Tokens Studio nested format into flat variables.
     */
    private function parse_dtcg( array $data, string $prefix = '' ): array {
        $result = [];

        foreach ( $data as $key => $val ) {
            if ( 0 === strpos( $key, '$' ) ) continue; // Skip meta keys.

            $name = $prefix ? "{$prefix}.{$key}" : $key;

            if ( isset( $val['$value'] ) ) {
                // Leaf token.
                $value = $val['$value'];
                $extension = is_array( $val['$extensions']['com.variable-engine'] ?? null )
                    ? $val['$extensions']['com.variable-engine']
                    : [];
                $raw_var_type = (string) ( $extension['var_type'] ?? 'base' );
                $var_type = in_array( $raw_var_type, [ 'base', 'alias' ], true )
                    ? $raw_var_type
                    : 'base';
                $source_name = sanitize_text_field( (string) ( $extension['source_name'] ?? '' ) );
                if ( 'alias' === $var_type && ! $source_name && is_string( $value ) && preg_match( '/^\{([^}]+)\}$/', $value, $match ) ) {
                    $source_name = strtolower( trim( $match[1] ) );
                }
                if ( is_array( $value ) ) {
                    // Color object { r, g, b, a }.
                    $value = $this->color_obj_to_string( $value );
                }
                $result[] = [
                    'name'      => strtolower( $name ),
                    'value'     => (string) $value,
                    'namespace' => explode( '.', strtolower( $name ) )[0],
                    'type'      => $var_type,
                    'source_name' => $source_name,
                ];
            } elseif ( is_array( $val ) ) {
                // Nested group — recurse.
                $result = array_merge( $result, $this->parse_dtcg( $val, $name ) );
            }
        }

        return $result;
    }

    private function normalize_flat_rows( array $rows ): array {
        $normalized = [];
        foreach ( $rows as $row ) {
            if ( ! is_array( $row ) ) {
                continue;
            }
            $name = strtolower( trim( (string) ( $row['name'] ?? '' ) ) );
            $type = in_array( ( $row['type'] ?? 'base' ), [ 'base', 'generated', 'alias' ], true )
                ? (string) $row['type']
                : 'base';
            $normalized[] = [
                'name'           => $name,
                'value'          => (string) ( $row['value'] ?? '' ),
                'namespace'      => (string) ( $row['namespace'] ?? explode( '.', $name )[0] ),
                'type'           => $type,
                'source_name'    => strtolower( trim( (string) ( $row['source_name'] ?? '' ) ) ),
                'generator_type' => sanitize_key( (string) ( $row['generator_type'] ?? '' ) ),
                'public_css_name'=> strtolower( trim( (string) ( $row['public_css_name'] ?? '' ) ) ),
                'source_css_name'=> strtolower( trim( (string) ( $row['source_css_name'] ?? '' ) ) ),
            ];
        }
        return $normalized;
    }

    /**
     * Parse Figma collections format.
     */
    private function parse_figma_collections( array $collections ): array {
        $result = [];

        foreach ( $collections as $col ) {
            $vars = $col['variables'] ?? [];
            foreach ( $vars as $v ) {
                $name  = $v['name'] ?? '';
                // Convert Figma slash-separated to dot-separated.
                $name  = str_replace( '/', '.', strtolower( $name ) );
                // Get default mode value.
                $modes = $v['valuesByMode'] ?? [];
                $value = reset( $modes );

                if ( is_array( $value ) ) {
                    $value = $this->color_obj_to_string( $value );
                }

                $result[] = [
                    'name'      => $name,
                    'value'     => (string) $value,
                    'namespace' => explode('.', $name)[0],
                    'type'      => 'base',
                ];
            }
        }

        return $result;
    }

    /* ================================================================
     *  HELPERS
     * ================================================================ */

    /**
     * Convert Figma RGBA object to CSS string.
     * Figma colors are { r: 0-1, g: 0-1, b: 0-1, a: 0-1 }
     */
    private function color_obj_to_string( array $c ): string {
        $r = isset( $c['r'] ) ? round( $c['r'] * 255 ) : 0;
        $g = isset( $c['g'] ) ? round( $c['g'] * 255 ) : 0;
        $b = isset( $c['b'] ) ? round( $c['b'] * 255 ) : 0;
        $a = $c['a'] ?? 1;

        if ( $a < 1 ) {
            return "rgba({$r},{$g},{$b}," . round( $a, 2 ) . ')';
        }

        return '#' . str_pad( dechex( $r ), 2, '0', STR_PAD_LEFT )
                    . str_pad( dechex( $g ), 2, '0', STR_PAD_LEFT )
                    . str_pad( dechex( $b ), 2, '0', STR_PAD_LEFT );
    }

    /**
     * Map VE namespace to DTCG $type.
     */
    private function ns_to_dtcg_type( string $ns ): string {
        switch ( $ns ) {
            case 'color':
                return 'color';
            case 'space':
            case 'size':
            case 'font':
            case 'radius':
                return 'dimension';
            case 'shadow':
                return 'shadow';
            case 'opacity':
                return 'number';
            case 'motion':
                return 'duration';
            default:
                return 'dimension';
        }
    }

    /**
     * Resolve Figma variable type from namespace + value.
     */
    private function resolve_figma_type( string $ns, string $value ): array {
        if ( $ns === 'color' || preg_match( '/^(#|rgb|hsl|oklch)/i', $value ) ) {
            // Parse to Figma RGBA object.
            $hex = $value;
            if ( 0 === strpos( $value, '#' ) ) {
                $hex = ltrim( $value, '#' );
                if ( strlen( $hex ) === 3 ) {
                    $hex = $hex[0].$hex[0].$hex[1].$hex[1].$hex[2].$hex[2];
                }
                return [
                    'type'  => 'COLOR',
                    'value' => [
                        'r' => round( hexdec( substr($hex,0,2) ) / 255, 4 ),
                        'g' => round( hexdec( substr($hex,2,2) ) / 255, 4 ),
                        'b' => round( hexdec( substr($hex,4,2) ) / 255, 4 ),
                        'a' => 1,
                    ],
                ];
            }
            // Non-hex colors: pass as string (Figma can't handle oklch natively).
            return [ 'type' => 'STRING', 'value' => $value ];
        }

        // Numeric values.
        if ( preg_match( '/^[\d.]+/', $value, $m ) ) {
            return [ 'type' => 'FLOAT', 'value' => (float) $m[0] ];
        }

        return [ 'type' => 'STRING', 'value' => $value ];
    }

    private function dedupe_latest_by_name( array $variables ): array {
        usort( $variables, static function ( $a, $b ) {
            return (int) ( $b['id'] ?? 0 ) <=> (int) ( $a['id'] ?? 0 );
        } );

        $seen = [];
        $deduped = [];
        foreach ( $variables as $variable ) {
            $name = (string) ( $variable['name'] ?? '' );
            if ( '' === $name || isset( $seen[ $name ] ) ) {
                continue;
            }
            $seen[ $name ] = true;
            $deduped[] = $variable;
        }

        usort( $deduped, static function ( $a, $b ) {
            return strnatcasecmp( (string) ( $a['name'] ?? '' ), (string) ( $b['name'] ?? '' ) );
        } );

        return $deduped;
    }

    private function resolve_public_import_names( array $imported, array $current ): array {
        $current_css_names = [];
        foreach ( $current as $variable ) {
            $name = (string) ( $variable['name'] ?? '' );
            if ( '' === $name ) {
                continue;
            }
            $css_name = $this->manager->to_css_name( $name );
            if ( ! isset( $current_css_names[ $css_name ] ) ) {
                $current_css_names[ $css_name ] = $name;
            } elseif ( $current_css_names[ $css_name ] !== $name ) {
                $current_css_names[ $css_name ] = '';
            }
        }

        foreach ( $imported as &$variable ) {
            $css_name = (string) ( $variable['public_css_name'] ?? '' );
            if ( $css_name && ! empty( $current_css_names[ $css_name ] ) ) {
                $variable['name'] = $current_css_names[ $css_name ];
                $variable['namespace'] = explode( '.', $variable['name'] )[0];
            }
        }
        unset( $variable );

        $imported_css_names = [];
        foreach ( $imported as $variable ) {
            $css_name = (string) ( $variable['public_css_name'] ?? '' );
            $name = (string) ( $variable['name'] ?? '' );
            if ( $css_name && $name ) {
                $imported_css_names[ $css_name ] = $name;
            }
        }

        foreach ( $imported as &$variable ) {
            if ( 'alias' !== (string) ( $variable['type'] ?? '' ) ) {
                continue;
            }
            $source_css_name = (string) ( $variable['source_css_name'] ?? '' );
            if ( ! $source_css_name ) {
                continue;
            }
            if ( ! empty( $current_css_names[ $source_css_name ] ) ) {
                $variable['source_name'] = $current_css_names[ $source_css_name ];
            } elseif ( ! empty( $imported_css_names[ $source_css_name ] ) ) {
                $variable['source_name'] = $imported_css_names[ $source_css_name ];
            }
        }
        unset( $variable );

        return $imported;
    }



    /**
     * Build a stable identity key for external sync clients.
     * Base variables use their WordPress ID. Generated variables use the source
     * base ID + generator type + generated suffix so they can survive base renames.
     */
    private function identity_key_for_export( int $id, int $source_id, string $generator_type, string $public_name, string $type ): string {
        if ( 'generated' === $type && $source_id > 0 ) {
            $suffix = $this->generated_suffix_for_export( $public_name, $source_id );
            return 'wpgen:' . $source_id . ':' . ( $generator_type ?: 'generated' ) . ':' . $suffix;
        }

        if ( $id > 0 ) {
            return 'wp:' . $id;
        }

        return 'name:' . sanitize_key( $public_name );
    }

    /**
     * Return previous public names for rename-aware sync.
     */
    private function previous_public_names_for_export( int $id, int $source_id, string $public_name, string $type ): array {
        $history = get_option( 've_variable_rename_history', [] );
        if ( ! is_array( $history ) ) {
            return [];
        }

        $names = [];

        // Direct/base variable history.
        $key = (string) $id;
        if ( isset( $history[ $key ] ) && is_array( $history[ $key ] ) ) {
            $names = array_merge( $names, $history[ $key ] );
        }

        // Generated variable history inherited from its source/base variable.
        if ( 'generated' === $type && $source_id > 0 ) {
            $source_key = (string) $source_id;
            if ( isset( $history[ $source_key ] ) && is_array( $history[ $source_key ] ) ) {
                $suffix = $this->generated_suffix_for_export( $public_name, $source_id );
                foreach ( $history[ $source_key ] as $old_base_public ) {
                    $old_base_public = trim( (string) $old_base_public );
                    if ( '' === $old_base_public ) {
                        continue;
                    }
                    $names[] = $old_base_public . ( $suffix ? '-' . $suffix : '' );
                }
            }
        }

        $names = array_values( array_unique( array_filter( array_map( 'strval', $names ) ) ) );
        $names = array_values( array_filter( $names, static function ( $n ) use ( $public_name ) {
            return $n !== $public_name;
        } ) );

        return array_slice( $names, 0, 20 );
    }

    /**
     * Extract the generated part of a public generated token name.
     * Examples: space-20 => 20, color-primary-d-1 => d-1.
     */
    private function generated_suffix_for_export( string $public_name, int $source_id ): string {
        $public_name = trim( $public_name );
        if ( '' === $public_name ) {
            return '';
        }

        try {
            $source = $source_id > 0 ? $this->manager->get( $source_id ) : null;
            if ( is_array( $source ) && ! empty( $source['name'] ) ) {
                $base_public = ltrim( $this->manager->to_css_name( (string) $source['name'] ), '-' );
                if ( $base_public && 0 === strncmp( $public_name, $base_public . '-', strlen( $base_public ) + 1 ) ) {
                    return substr( $public_name, strlen( $base_public ) + 1 );
                }
            }
        } catch ( \Throwable $e ) {
            // Fall through to generic suffix detection.
        }

        if ( preg_match( '/(?:^|-)([ldt]-\d+)$/', $public_name, $m ) ) {
            return $m[1];
        }
        if ( preg_match( '/(?:^|-)(\d+(?:-\d+)?)$/', $public_name, $m ) ) {
            return $m[1];
        }

        $parts = explode( '-', $public_name );
        return end( $parts ) ?: $public_name;
    }

    /**
     * Get sync history.
     */
    public function get_logs( int $limit = 20 ): array {
        global $wpdb;

        $rows = $wpdb->get_results(
            $wpdb->prepare(
                'SELECT id, source, author, diff, synced_at, snapshot_id FROM ' . Schema::table('sync_logs') .
                ' ORDER BY id DESC LIMIT %d',
                $limit
            ),
            ARRAY_A
        ) ?: [];

        foreach ( $rows as &$row ) {
            $decoded = json_decode( $row['diff'] ?? '[]', true );
            $summary = [];

            if ( is_array( $decoded ) && isset( $decoded['summary'] ) && is_array( $decoded['summary'] ) ) {
                $summary = $decoded['summary'];
                $row['client_time'] = sanitize_text_field( $decoded['client_time'] ?? '' );
                $row['client_timezone'] = sanitize_text_field( $decoded['client_timezone'] ?? '' );
            } elseif ( is_array( $decoded ) ) {
                $changes = isset( $decoded['changes'] ) && is_array( $decoded['changes'] ) ? $decoded['changes'] : $decoded;
                $summary = [ 'total' => count( $changes ) ];
            }

            $row['summary'] = $summary;
            unset( $row['diff'] );
        }

        return $rows;
    }
}
