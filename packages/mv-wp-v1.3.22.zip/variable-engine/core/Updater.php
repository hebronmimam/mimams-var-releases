<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

class Updater {

    const SLUG = 'variable-engine';
    const LEGACY_FEED_URL = 'https://raw.githubusercontent.com/hebronmimam/mimams-var-releases/main/updates/mimams-var-wp.json';
    const DEFAULT_FEED_URL = 'https://api.github.com/repos/hebronmimam/mimams-var-releases/contents/updates/mimams-var-wp.json?ref=main';
    const CHANNEL_FEEDS = [
        'stable' => self::DEFAULT_FEED_URL,
        'beta'   => 'https://api.github.com/repos/hebronmimam/mimams-var-releases/contents/updates/mimams-var-wp-beta.json?ref=main',
        'dev'    => 'https://api.github.com/repos/hebronmimam/mimams-var-releases/contents/updates/mimams-var-wp-dev.json?ref=main',
    ];

    public static function feed_url_for_channel( string $channel ): string {
        $channel = sanitize_key( $channel );
        return self::CHANNEL_FEEDS[ $channel ] ?? self::DEFAULT_FEED_URL;
    }

    public function register(): void {
        if ( ! is_admin() ) {
            return;
        }

        if ( function_exists( 'add_filter' ) ) {
            add_filter( 'pre_set_site_transient_update_plugins', [ $this, 'inject_update' ] );
            add_filter( 'site_transient_update_plugins', [ $this, 'inject_update' ] );
            add_filter( 'plugins_api', [ $this, 'plugin_info' ], 10, 3 );
            add_filter( 'auto_update_plugin', [ $this, 'auto_update' ], 10, 2 );
            add_action( 'delete_site_transient_update_plugins', [ $this, 'clear_cache' ] );
            add_action( 'upgrader_process_complete', [ $this, 'upgrader_complete' ], 10, 2 );
            add_action( 'admin_init', [ $this, 'prime_native_update_screen' ], 2 );
        }
    }

    public function clear_cache(): void {
        delete_transient( 've_update_manifest' );
    }

    public function check_now(): array {
        delete_transient( 've_update_manifest' );
        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
            wp_clean_plugins_cache();
        }

        $manifest = $this->fetch_manifest( true );
        if ( is_wp_error( $manifest ) ) {
            return [
                'configured'        => false,
                'current_version'   => VE_VERSION,
                'latest_version'    => VE_VERSION,
                'update_available'  => false,
                'message'           => $manifest->get_error_message(),
            ];
        }

        $latest = isset( $manifest['version'] ) ? (string) $manifest['version'] : VE_VERSION;
        $this->sync_native_update_transient( $manifest );

        return [
            'configured'        => true,
            'current_version'   => VE_VERSION,
            'latest_version'    => $latest,
            'update_available'  => version_compare( $latest, VE_VERSION, '>' ),
            'download_url'      => isset( $manifest['download_url'] ) ? (string) $manifest['download_url'] : '',
            'details_url'       => isset( $manifest['details_url'] ) ? (string) $manifest['details_url'] : '',
            'update_admin_url'  => $this->update_admin_url(),
            'message'           => version_compare( $latest, VE_VERSION, '>' ) ? 'Update available.' : 'Already up to date.',
        ];
    }

    public function install_available_update() {
        if ( function_exists( 'current_user_can' ) && ! current_user_can( 'update_plugins' ) ) {
            return new \WP_Error( 've_update_forbidden', 'You do not have permission to update plugins.', [ 'status' => 403 ] );
        }

        $manifest = $this->fetch_manifest( true );
        if ( is_wp_error( $manifest ) ) {
            return $manifest;
        }

        $latest = (string) ( $manifest['version'] ?? VE_VERSION );
        if ( ! version_compare( $latest, VE_VERSION, '>' ) ) {
            return [
                'updated'          => false,
                'refresh_required' => false,
                'version'          => VE_VERSION,
                'message'          => 'Mimam\'s Var is already up to date.',
            ];
        }
        if ( empty( $manifest['download_url'] ) ) {
            return new \WP_Error( 've_update_missing_package', 'The update manifest does not include a package URL.', [ 'status' => 500 ] );
        }

        if ( ! function_exists( 'request_filesystem_credentials' ) ) {
            require_once ABSPATH . 'wp-admin/includes/file.php';
        }
        if ( ! class_exists( '\Plugin_Upgrader' ) ) {
            require_once ABSPATH . 'wp-admin/includes/class-wp-upgrader.php';
        }
        if ( ! function_exists( 'get_plugin_data' ) ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $this->sync_native_update_transient( $manifest );
        $skin = new \Automatic_Upgrader_Skin();
        $upgrader = new \Plugin_Upgrader( $skin );
        $result = $upgrader->upgrade( $this->plugin_file() );

        if ( is_wp_error( $result ) ) {
            return $result;
        }
        if ( false === $result ) {
            $errors = $skin->get_errors();
            if ( is_wp_error( $errors ) && $errors->has_errors() ) {
                return $errors;
            }
            return new \WP_Error( 've_update_failed', 'WordPress could not install the plugin update.', [ 'status' => 500 ] );
        }

        $this->clear_cache();
        if ( function_exists( 'wp_clean_plugins_cache' ) ) {
            wp_clean_plugins_cache( true );
        }

        $installed_version = $latest;
        if ( file_exists( VE_FILE ) ) {
            $plugin_data = get_plugin_data( VE_FILE, false, false );
            if ( ! empty( $plugin_data['Version'] ) ) {
                $installed_version = (string) $plugin_data['Version'];
            }
        }

        return [
            'updated'          => true,
            'refresh_required' => true,
            'version'          => $installed_version,
            'message'          => "Mimam's Var v{$installed_version} was installed successfully.",
        ];
    }

    public function prime_native_update_screen(): void {
        global $pagenow;

        if ( ! in_array( (string) $pagenow, [ 'plugins.php', 'update-core.php' ], true ) ) {
            return;
        }
        if ( function_exists( 'current_user_can' ) && ! current_user_can( 'update_plugins' ) ) {
            return;
        }

        $manifest = $this->fetch_manifest( true );
        if ( ! is_wp_error( $manifest ) ) {
            $this->sync_native_update_transient( $manifest );
        }
    }

    public function inject_update( $transient ) {
        if ( ! is_object( $transient ) ) {
            $transient = new \stdClass();
        }
        if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
            $transient->response = [];
        }
        if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
            $transient->no_update = [];
        }

        $manifest = $this->fetch_manifest();
        if ( is_wp_error( $manifest ) ) {
            return $transient;
        }

        $item = $this->update_item( $manifest );
        $file = $this->plugin_file();
        if ( ! isset( $transient->checked ) || ! is_array( $transient->checked ) ) {
            $transient->checked = [];
        }
        $transient->checked[ $file ] = VE_VERSION;

        if ( version_compare( (string) $manifest['version'], VE_VERSION, '>' ) ) {
            $transient->response[ $file ] = $item;
            if ( isset( $transient->no_update[ $file ] ) ) {
                unset( $transient->no_update[ $file ] );
            }
        } else {
            $transient->no_update[ $file ] = $item;
            if ( isset( $transient->response[ $file ] ) ) {
                unset( $transient->response[ $file ] );
            }
        }

        return $transient;
    }

    public function plugin_info( $result, $action, $args ) {
        if ( 'plugin_information' !== $action || empty( $args->slug ) || self::SLUG !== $args->slug ) {
            return $result;
        }

        $manifest = $this->fetch_manifest();
        if ( is_wp_error( $manifest ) ) {
            return $result;
        }

        return (object) [
            'name'          => "Mimam's Var - WP",
            'slug'          => self::SLUG,
            'version'       => (string) $manifest['version'],
            'author'        => '<a href="https://hebronmimam.com">Hebronmimam</a>',
            'homepage'      => isset( $manifest['details_url'] ) ? (string) $manifest['details_url'] : '',
            'requires'      => isset( $manifest['requires'] ) ? (string) $manifest['requires'] : '6.0',
            'tested'        => isset( $manifest['tested'] ) ? (string) $manifest['tested'] : '',
            'requires_php'  => isset( $manifest['requires_php'] ) ? (string) $manifest['requires_php'] : '7.4',
            'download_link' => isset( $manifest['download_url'] ) ? (string) $manifest['download_url'] : '',
            'sections'      => isset( $manifest['sections'] ) && is_array( $manifest['sections'] ) ? $manifest['sections'] : [ 'changelog' => '' ],
        ];
    }

    public function auto_update( $update, $item ) {
        if ( empty( $item->plugin ) || $this->plugin_file() !== $item->plugin ) {
            return $update;
        }

        $settings = $this->settings();
        return ! empty( $settings['auto_update'] );
    }

    public function fetch_manifest( bool $force = false ) {
        $settings = $this->settings();
        $url = trim( isset( $settings['update_url'] ) ? (string) $settings['update_url'] : '' );
        $channel = sanitize_key( (string) ( $settings['update_channel'] ?? 'stable' ) );

        if ( '' === $url || self::LEGACY_FEED_URL === $url ) {
            $url = self::feed_url_for_channel( $channel );
        }

        if ( ! $force ) {
            $cached = get_transient( 've_update_manifest' );
            if ( is_array( $cached ) && ! empty( $cached['version'] ) ) {
                return $cached;
            }
        }

        $request_url = $force ? $this->cache_bust_url( $url ) : $url;
        $accept = false !== strpos( $request_url, 'api.github.com/repos/hebronmimam/mimams-var-releases/contents/' ) ? 'application/vnd.github.raw' : 'application/json';

        $response = wp_remote_get( $request_url, [
            'timeout' => 12,
            'headers' => [
                'Accept'     => $accept,
                'User-Agent' => "Mimam's Var - WP/" . VE_VERSION . '; ' . home_url(),
            ],
        ] );

        if ( is_wp_error( $response ) ) {
            return $response;
        }

        $code = (int) wp_remote_retrieve_response_code( $response );
        if ( $code < 200 || $code >= 300 ) {
            return new \WP_Error( 've_update_http_error', 'Update feed returned HTTP ' . $code . '.' );
        }

        $body_raw = wp_remote_retrieve_body( $response );
        $body = json_decode( $body_raw, true );
        if ( is_array( $body ) && isset( $body['content'], $body['encoding'] ) && 'base64' === $body['encoding'] ) {
            $decoded = base64_decode( (string) $body['content'], true );
            if ( false !== $decoded ) {
                $body = json_decode( $decoded, true );
            }
        }
        if ( ! is_array( $body ) || empty( $body['version'] ) ) {
            return new \WP_Error( 've_update_bad_manifest', 'Update feed JSON must include a version.' );
        }

        $manifest = [
            'version'       => sanitize_text_field( (string) $body['version'] ),
            'download_url'  => esc_url_raw( isset( $body['download_url'] ) ? (string) $body['download_url'] : ( isset( $body['package'] ) ? (string) $body['package'] : '' ) ),
            'details_url'   => esc_url_raw( isset( $body['details_url'] ) ? (string) $body['details_url'] : ( isset( $body['url'] ) ? (string) $body['url'] : '' ) ),
            'requires'      => sanitize_text_field( isset( $body['requires'] ) ? (string) $body['requires'] : '6.0' ),
            'tested'        => sanitize_text_field( isset( $body['tested'] ) ? (string) $body['tested'] : '' ),
            'requires_php'  => sanitize_text_field( isset( $body['requires_php'] ) ? (string) $body['requires_php'] : '7.4' ),
            'sections'      => isset( $body['sections'] ) && is_array( $body['sections'] ) ? $body['sections'] : [ 'changelog' => wp_kses_post( isset( $body['changelog'] ) ? (string) $body['changelog'] : '' ) ],
        ];

        set_transient( 've_update_manifest', $manifest, 6 * HOUR_IN_SECONDS );

        return $manifest;
    }

    private function settings(): array {
        $defaults = [
            'vw_min'              => 320,
            'vw_max'              => 1440,
            'delete_on_uninstall' => false,
            'update_url'          => self::DEFAULT_FEED_URL,
            'update_channel'      => 'stable',
            'auto_update'         => false,
            'license_server_url'  => '',
        ];

        $settings = get_option( 've_settings', $defaults );
        return wp_parse_args( is_array( $settings ) ? $settings : [], $defaults );
    }

    private function cache_bust_url( string $url ): string {
        $separator = false === strpos( $url, '?' ) ? '?' : '&';
        return $url . $separator . 've_t=' . rawurlencode( (string) time() );
    }

    private function plugin_file(): string {
        return plugin_basename( VE_FILE );
    }

    private function update_admin_url(): string {
        if ( ! function_exists( 'wp_nonce_url' ) || ! function_exists( 'self_admin_url' ) ) {
            return '';
        }

        $file = $this->plugin_file();
        $url = wp_nonce_url(
            self_admin_url( 'update.php?action=upgrade-plugin&plugin=' . urlencode( $file ) ),
            'upgrade-plugin_' . $file
        );

        return html_entity_decode( $url, ENT_QUOTES, 'UTF-8' );
    }

    private function update_item( array $manifest ): \stdClass {
        return (object) [
            'id'            => isset( $manifest['details_url'] ) ? (string) $manifest['details_url'] : '',
            'slug'          => self::SLUG,
            'plugin'        => $this->plugin_file(),
            'new_version'   => (string) $manifest['version'],
            'url'           => isset( $manifest['details_url'] ) ? (string) $manifest['details_url'] : '',
            'package'       => isset( $manifest['download_url'] ) ? (string) $manifest['download_url'] : '',
            'requires'      => isset( $manifest['requires'] ) ? (string) $manifest['requires'] : '6.0',
            'tested'        => isset( $manifest['tested'] ) ? (string) $manifest['tested'] : '',
            'requires_php'  => isset( $manifest['requires_php'] ) ? (string) $manifest['requires_php'] : '7.4',
        ];
    }

    private function sync_native_update_transient( array $manifest ): void {
        $transient = get_site_transient( 'update_plugins' );
        if ( ! is_object( $transient ) ) {
            $transient = new \stdClass();
        }
        if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
            $transient->response = [];
        }
        if ( ! isset( $transient->no_update ) || ! is_array( $transient->no_update ) ) {
            $transient->no_update = [];
        }
        if ( ! isset( $transient->checked ) || ! is_array( $transient->checked ) ) {
            $transient->checked = [];
        }

        $file = $this->plugin_file();
        $item = $this->update_item( $manifest );
        $transient->checked[ $file ] = VE_VERSION;
        $transient->last_checked = time();

        if ( version_compare( (string) $manifest['version'], VE_VERSION, '>' ) ) {
            $transient->response[ $file ] = $item;
            unset( $transient->no_update[ $file ] );
        } else {
            $transient->no_update[ $file ] = $item;
            unset( $transient->response[ $file ] );
        }

        set_site_transient( 'update_plugins', $transient );
    }

    public function upgrader_complete( $upgrader, $options ): void {
        if ( is_array( $options ) && isset( $options['action'], $options['type'], $options['plugins'] ) && 'plugin' === $options['action'] && 'update' === $options['type'] ) {
            foreach ( (array) $options['plugins'] as $plugin ) {
                if ( $plugin === $this->plugin_file() ) {
                    $this->clear_cache();
                    if ( function_exists( 'wp_clean_plugins_cache' ) ) {
                        wp_clean_plugins_cache();
                    }
                    break;
                }
            }
        }
    }
}
