<?php

$root = dirname( __DIR__ );
$routes_path = $root . '/api/Routes.php';
$panel_path = $root . '/assets/js/builder-panel.js';
$routes = file_get_contents( $routes_path );
$panel = file_get_contents( $panel_path );

if ( false === $routes || false === $panel ) {
    fwrite( STDERR, "Could not read Content Studio import sources.\n" );
    exit( 1 );
}

$assertions = 0;
$failures = [];
$expect = static function( $condition, $message ) use ( &$assertions, &$failures ) {
    $assertions++;
    if ( ! $condition ) {
        $failures[] = $message;
    }
};

$expect( false !== strpos( $routes, "'/content-studio/import/preview'" ), 'Preview route is registered.' );
$expect( false !== strpos( $routes, "'/content-studio/import/apply'" ), 'Apply route is registered.' );
$expect( substr_count( $routes, "'permission_callback' => [ \$this, 'can_write' ]" ) >= 2, 'Import routes require write permission.' );
$expect( false !== strpos( $routes, 'count( $rows ) > 5000' ), 'Server enforces the 5,000-row limit.' );
$expect( substr_count( $routes, 'prepare_studio_content_import' ) >= 3, 'Preview and apply recompute prepared import data.' );
$expect( false !== strpos( $routes, "hash_equals( \$prepared['confirmation'], \$confirmation )" ), 'Apply requires the exact server confirmation.' );
$expect( false !== strpos( $routes, 'validate_media_import_url( $url )' ), 'Remote media reuses the protected URL validator.' );
$expect( false !== strpos( $routes, "get_option( 've_content_studio_import_reports'" ), 'Import reports are retained.' );
$expect( false !== strpos( $routes, "array_slice( \$reports, 0, 10 )" ), 'Retained reports are bounded.' );
$expect( false !== strpos( $routes, "'_' !== substr( \$meta_key, 0, 1 )" ), 'Protected underscore-prefixed metadata cannot be mapped.' );
$expect( false !== strpos( $routes, "current_user_can( 'edit_post', \$existing->ID )" ), 'Matched updates require per-post permission.' );

$preview_start = strpos( $routes, 'public function preview_studio_content_import' );
$preview_end = strpos( $routes, 'private function studio_content_import_featured_image', $preview_start );
$preview_block = false !== $preview_start && false !== $preview_end ? substr( $routes, $preview_start, $preview_end - $preview_start ) : '';
$expect( '' !== $preview_block, 'Preview callback can be isolated.' );
$expect( false === strpos( $preview_block, 'wp_insert_post' ) && false === strpos( $preview_block, 'wp_update_post' ), 'Preview performs no post writes.' );

$expect( false !== strpos( $panel, 'function parseContentImportText' ), 'Client has a quote-aware CSV/TSV parser.' );
$expect( false !== strpos( $panel, "['csv','tsv'].includes(extension)" ), 'Client restricts source extensions.' );
$expect( false !== strpos( $panel, '10*1024*1024' ), 'Client enforces the 10 MB file limit.' );
$expect( false !== strpos( $panel, "api.p('content-studio/import/preview'" ), 'Client calls the preview contract.' );
$expect( false !== strpos( $panel, "api.p('content-studio/import/apply'" ), 'Client calls the apply contract.' );
$expect( false !== strpos( $panel, "['Upload','Map','Review','Import']" ), 'Client exposes the approved four steps.' );
$expect( false !== strpos( $panel, "contentImportConfirmation.trim()!==String(contentImportPreview.confirmation||'')" ), 'Client also blocks a mismatched confirmation.' );
$expect( false !== strpos( $panel, '.ve-cs-light .ve-content-editor-topbar .ve-content-theme-toggle' ), 'Light mode owns an adaptive theme capsule.' );
$expect( false !== strpos( $panel, '.ve-cs-dark .ve-content-editor-topbar-title strong' ), 'Dark mode uses the quieter title treatment.' );

if ( $failures ) {
    foreach ( $failures as $failure ) {
        fwrite( STDERR, 'FAIL: ' . $failure . "\n" );
    }
    fwrite( STDERR, sprintf( "Content import contract checks failed: %d/%d.\n", count( $failures ), $assertions ) );
    exit( 1 );
}

echo sprintf( "Content import contract checks passed: %d assertions.\n", $assertions );
