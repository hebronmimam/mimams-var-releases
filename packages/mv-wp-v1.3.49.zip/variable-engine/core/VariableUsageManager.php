<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

class VariableUsageManager {

    public function inspect( array $variable ): array {
        $id       = (int) ( $variable['id'] ?? 0 );
        $name     = (string) ( $variable['name'] ?? '' );
        $css_name = ( new VariableManager() )->to_css_name( $name );
        $groups   = [
            'aliases'    => [],
            'themes'     => [],
            'css_studio' => [],
            'wordpress'  => [],
        ];

        foreach ( ( new DependencyGraph() )->get_dependents( $id ) as $dependent ) {
            if ( 'alias' !== (string) ( $dependent['type'] ?? '' ) && 'alias' !== (string) ( $dependent['relation'] ?? '' ) ) {
                continue;
            }
            $groups['aliases'][] = [
                'type'    => 'variable',
                'id'      => (int) ( $dependent['id'] ?? 0 ),
                'name'    => (string) ( $dependent['name'] ?? '' ),
                'label'   => (string) ( $dependent['name'] ?? '' ),
                'matches' => 1,
            ];
        }

        $themes = get_option( 've_color_palettes', [] );
        if ( is_array( $themes ) ) {
            foreach ( $themes as $slug => $theme ) {
                $values = isset( $theme['values'] ) && is_array( $theme['values'] ) ? $theme['values'] : [];
                if ( ! array_key_exists( $name, $values ) ) {
                    continue;
                }
                $groups['themes'][] = [
                    'type'    => 'theme',
                    'id'      => sanitize_key( (string) $slug ),
                    'name'    => (string) ( $theme['name'] ?? $slug ),
                    'label'   => (string) ( $theme['name'] ?? $slug ),
                    'matches' => 1,
                ];
            }
        }

        $advanced_css = ( new AdvancedCssManager() )->get();
        foreach ( (array) ( $advanced_css['stylesheets'] ?? [] ) as $sheet ) {
            $css = (string) ( $sheet['css'] ?? '' );
            $matches = $this->count_token( $css, $css_name );
            if ( $matches < 1 ) {
                continue;
            }
            $groups['css_studio'][] = [
                'type'    => 'css_studio',
                'id'      => (string) ( $sheet['id'] ?? '' ),
                'name'    => (string) ( $sheet['name'] ?? $sheet['id'] ?? 'Stylesheet' ),
                'label'   => (string) ( $sheet['name'] ?? $sheet['id'] ?? 'Stylesheet' ),
                'matches' => $matches,
            ];
        }

        if ( $css_name ) {
            $sentinel = '--ve-usage-preview-' . $id;
            $storage  = ( new RenamePropagationManager( [
                [ 'old' => $css_name, 'new' => $sentinel ],
            ] ) )->preview();
            foreach ( (array) ( $storage['locations'] ?? [] ) as $location ) {
                $groups['wordpress'][] = [
                    'type'    => (string) ( $location['type'] ?? 'wordpress' ),
                    'id'      => (int) ( $location['id'] ?? 0 ),
                    'name'    => (string) ( $location['label'] ?? 'WordPress storage' ),
                    'label'   => (string) ( $location['label'] ?? 'WordPress storage' ),
                    'matches' => max( 1, (int) ( $location['matches'] ?? 1 ) ),
                    'note'    => (string) ( $location['note'] ?? '' ),
                ];
            }
        }

        $total = 0;
        foreach ( $groups as $items ) {
            foreach ( $items as $item ) {
                $total += max( 1, (int) ( $item['matches'] ?? 1 ) );
            }
        }

        return [
            'variable' => [
                'id'       => $id,
                'name'     => $name,
                'css_name' => $css_name,
                'type'     => (string) ( $variable['type'] ?? 'base' ),
            ],
            'groups'   => $groups,
            'total'    => $total,
            'unused'   => 0 === $total,
        ];
    }

    private function count_token( string $content, string $css_name ): int {
        if ( '' === $content || '' === $css_name ) {
            return 0;
        }
        preg_match_all(
            '/(?<![A-Za-z0-9_-])' . preg_quote( $css_name, '/' ) . '(?![A-Za-z0-9_-])/',
            $content,
            $matches
        );
        return count( $matches[0] ?? [] );
    }
}
