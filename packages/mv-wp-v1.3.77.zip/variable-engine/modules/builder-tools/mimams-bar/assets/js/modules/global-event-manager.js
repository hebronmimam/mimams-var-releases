(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarGlobalEvents) return;

  function bind(app) {
    if (!app || app._globalEventsBound) return;
    app._globalEventsBound = true;

    window.addEventListener('keydown', function (event) { onKeydown(app, event); }, true);
    document.addEventListener('pointerdown', function (event) { onPointerDown(app, event); }, true);
    window.addEventListener('message', function (event) { onMessage(app, event); });

    function handleToggleBtnEvent(event) {
      var btn = event.target && event.target.closest && event.target.closest('.mimams-bar-toggle-button');
      if (btn) {
        event.preventDefault();
        event.stopPropagation();
        if (event.stopImmediatePropagation) event.stopImmediatePropagation();
        if (event.type === 'click') {
          if (isMimamsBarDisabled()) return;
          app.toggle();
        }
      }
    }
    document.addEventListener('pointerdown', handleToggleBtnEvent, true);
    document.addEventListener('mousedown', handleToggleBtnEvent, true);
    document.addEventListener('click', handleToggleBtnEvent, true);

    var recover = makeRecoveryHandler(app);
    document.addEventListener('visibilitychange', recover, true);
    window.addEventListener('pageshow', recover, true);
    window.addEventListener('focus', recover, true);
  }

  function makeRecoveryHandler(app) {
    var timer = null;
    return function () {
      if (!app) return;
      if (document.visibilityState && document.visibilityState !== 'visible') return;
      if (timer) window.clearTimeout(timer);
      timer = window.setTimeout(function () {
        timer = null;
        try {
          if (app.settings && typeof app.settings.applyUiState === 'function') app.settings.applyUiState();
          if (app.isOpen && app.isOpen() && app.targetManager) app.targetManager.scheduleRefresh(app);
        } catch (e) {}
      }, 180);
    };
  }

  function onMessage(app, event) {
    if (!event || !event.data || event.data.type !== 'baqa:toggle') return;
    if (event.origin && event.origin !== window.location.origin) return;
    if (isMimamsBarDisabled()) return;
    app.toggle();
  }

  function isMimamsBarDisabled() {
    try {
      var raw = window.localStorage ? window.localStorage.getItem('ve_deactivated_tools') : '';
      var surfaceRaw = window.localStorage ? window.localStorage.getItem('ve_deactivated_tool_surfaces') : '';
      var list = raw ? JSON.parse(raw) : [];
      var surfaces = surfaceRaw ? JSON.parse(surfaceRaw) : {};
      var builderList = surfaces && Array.isArray(surfaces.builder) ? surfaces.builder : [];
      var adminList = surfaces && Array.isArray(surfaces.admin) ? surfaces.admin : [];
      var legacy = Array.isArray(list) ? list : [];
      var legacyWithoutSurfaceChoice = legacy.filter(function (id) {
        return adminList.indexOf(id) === -1 && builderList.indexOf(id) === -1;
      });
      return builderList.indexOf('mimams_bar') !== -1 || legacyWithoutSurfaceChoice.indexOf('mimams_bar') !== -1;
    } catch (e) {
      return false;
    }
  }

  function bindCanvasFrames(app) {
    // v1.2.49: intentionally disabled. Binding pointer listeners inside the
    // Bricks canvas iframe can be expensive on complex builder pages and was
    // one likely source of freeze while the bar remained open.
    return;
  }

  function onCanvasPointerDown(app, event) {
    if (!app || !app.isOpen()) return;
    app.targetManager.scheduleRefresh(app);
  }

  function clickedInside(node, event, path) {
    if (!node || !event) return false;
    return path ? path.indexOf(node) !== -1 : node.contains(event.target);
  }

  function shouldRefreshFromTopDocumentClick(app, target) {
    if (!target || !target.closest) return false;
    // Structure/tree clicks are cheap enough to use for target refresh. Canvas
    // iframe clicks are deliberately ignored in this release for freeze safety.
    return !!target.closest('#bricks-structure, #bricks-structure-resizable, .bricks-structure, .brx-structure, #brx-structure, [data-panel="structure"], [data-control="structure"], [data-id], .bricks-draggable-item');
  }

  function onPointerDown(app, event) {
    if (!app || !app.isOpen()) return;

    var path = typeof event.composedPath === 'function' ? event.composedPath() : null;
    if (app.dialogs.clickInside(app.confirmOverlay, event, path) || app.dialogs.clickInside(app.bulkOverlay, event, path)) return;
    if (clickedInside(app.panel, event, path)) return;

    if (shouldRefreshFromTopDocumentClick(app, event.target)) {
      app.targetManager.scheduleRefresh(app);
      return;
    }

    // Clicks inside Bricks UI panels should not close the bar. This keeps the
    // bar usable without forcing expensive canvas scanning.
    if (event.target && event.target.closest && event.target.closest('#bricks-panel, #brx-panel, .bricks-panel, .brx-panel, #bricks-toolbar, #brx-toolbar')) {
      return;
    }

    app.close();
  }

  function isDeselectShortcut(event, app) {
    if (!app || !app.Core || !app.Core.readStoredSettings) return false;
    var conf = app.Core.readStoredSettings().deselectShortcut || 'escape';
    if (conf === 'none') return false;
    if (conf === 'escape' && event.key === 'Escape') return true;
    if (conf === 'shift-d' && event.key.toLowerCase() === 'd' && event.shiftKey && !event.ctrlKey && !event.metaKey && !event.altKey) return true;
    if (conf === 'alt-d' && event.key.toLowerCase() === 'd' && event.altKey && !event.ctrlKey && !event.metaKey && !event.shiftKey) return true;
    return false;
  }

  function onKeydown(app, event) {
    if (event.__mimamsBarHandledKeydown) return;

    var confirmOpen = app.confirmOverlay && app.confirmOverlay.classList.contains('is-open');

    if (event.key === 'Escape' && confirmOpen) {
      event.__mimamsBarHandledKeydown = true;
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
      app.closeConfirmDialog();
      return;
    }

    if (event.key === 'Escape' && app.isOpen()) {
      event.__mimamsBarHandledKeydown = true;
      event.preventDefault();
      app.close();
      return;
    }

    var inInput = (event.target && event.target.closest && event.target.closest('input, textarea, select'));

    if (app.isOpen() && !inInput) {
      if (app.handleModeKeys(event)) {
        event.__mimamsBarHandledKeydown = true;
        return;
      }
    }

    if (!inInput && isDeselectShortcut(event, app)) {
      if (app.Core && app.Core.adapter && app.Core.adapter.deselectElement) {
        app.Core.adapter.deselectElement();
        event.__mimamsBarHandledKeydown = true;
        event.preventDefault();
        return;
      }
    }

    if (app.matchesShortcut(event)) {
      event.__mimamsBarHandledKeydown = true;
      event.preventDefault();
      event.stopPropagation();
      if (event.stopImmediatePropagation) event.stopImmediatePropagation();
      if (isMimamsBarDisabled()) return;
      app.toggle();
    }
  }

  window.MimamsBarGlobalEvents = {
    bind: bind,
    bindCanvasFrames: bindCanvasFrames,
    onMessage: onMessage,
    onCanvasPointerDown: onCanvasPointerDown,
    onPointerDown: onPointerDown,
    onKeydown: onKeydown
  };
})();
