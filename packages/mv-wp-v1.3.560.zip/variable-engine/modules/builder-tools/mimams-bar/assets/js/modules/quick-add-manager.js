(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarQuickAdd) return;

  var Core = window.MimamsBarCore || {};
  var config = Core.config || window.baqaConfig || {};
  var log = Core.log || function () {};

  // The Element Tray is chrome over someone else's canvas, so it only exists in the
  // builder, and only while the setting says so.
  if ((config.surface || 'admin') !== 'builder') return;

  var STORE_KEY = 'mvQuickAddBar';
  var DEFAULT_SLOTS = ['el:section', 'el:container', 'el:block', 'el:heading', 'el:text', 'el:image'];

  var state = {
    slots: DEFAULT_SLOTS.slice(),
    enabled: true,
    sheet: false,      // the Edit Element Tray list
    query: '',
    arranging: false,  // O: pick up, then place
    lifted: null,
    catalog: null,     // built once Bricks has told us what exists
    catalogAt: 0
  };

  var root = null;

  /* ── Storage ──────────────────────────────────────────────────────────
     The WordPress user preference is authoritative, so one account gets the
     same tray in every browser. localStorage remains as a fast local echo and
     as a migration source for trays saved before account sync existed. */
  function normalizeSlots(slots) {
    if (!Array.isArray(slots)) return [];
    var seen = {};
    return slots.filter(function (key) {
      if (typeof key !== 'string' || !/^(?:el|cmp):[A-Za-z0-9_.:-]{1,190}$/.test(key) || seen[key]) return false;
      seen[key] = true;
      return true;
    }).slice(0, 60);
  }
  function persistAccountSlots(attempt) {
    attempt = attempt || 0;
    if (typeof window.vePersistUserPreference === 'function') {
      window.vePersistUserPreference(STORE_KEY, { slots: state.slots.slice() });
      return;
    }
    // builder-panel.js owns the merged user-preference writer. It can finish
    // booting after this small module, so wait for it instead of posting a
    // partial preference object that could erase another setting.
    if (attempt < 20) {
      window.setTimeout(function () { persistAccountSlots(attempt + 1); }, 250);
    }
  }
  function read() {
    var legacySlots = null;
    try {
      var raw = window.localStorage ? window.localStorage.getItem(STORE_KEY) : '';
      var parsed = raw ? JSON.parse(raw) : null;
      if (parsed && Array.isArray(parsed.slots)) legacySlots = normalizeSlots(parsed.slots);
    } catch (e) {}
    var hasAccountPreference = !!(config.quickAdd && config.quickAdd.hasPreference);
    if (hasAccountPreference && Array.isArray(config.quickAdd.slots)) {
      state.slots = normalizeSlots(config.quickAdd.slots);
    } else if (legacySlots !== null) {
      state.slots = legacySlots;
      window.setTimeout(function () { persistAccountSlots(0); }, 0);
    }
    var setting = config.quickAdd && typeof config.quickAdd.enabled !== 'undefined'
      ? !!config.quickAdd.enabled
      : true;
    state.enabled = setting;
  }
  function write() {
    try {
      if (window.localStorage) {
        window.localStorage.setItem(STORE_KEY, JSON.stringify({ slots: state.slots }));
      }
    } catch (e) {}
    persistAccountSlots(0);
  }

  /* ── What can be added ────────────────────────────────────────────────
     Both halves come from Bricks itself: the element configs it registered,
     and the components this site has. Nothing here is a hand-kept list. */
  function adapter() {
    return window.MimamsBarBricksAdapter || null;
  }
  function catalog(options) {
    options = options || {};
    var now = Date.now ? Date.now() : new Date().getTime();
    if (!options.fresh && state.catalog && now - state.catalogAt < 4000) return state.catalog;

    var api = adapter();
    var items = [];
    if (api) {
      try {
        (api.getBricksElementConfigs() || []).forEach(function (element) {
          if (!element || !element.name) return;
          items.push({
            key: 'el:' + element.name,
            kind: 'element',
            name: element.name,
            label: element.label || element.name,
            category: element.category || '',
            icon: element.icon || ''
          });
        });
      } catch (e0) { log('quick add: element configs failed', e0); }
      try {
        (api.getBricksComponents() || []).forEach(function (component) {
          if (!component || !component.id) return;
          items.push({
            key: 'cmp:' + component.id,
            kind: 'component',
            componentId: component.id,
            label: component.label || component.id,
            category: component.category || 'Components',
            icon: '',
            config: component
          });
        });
      } catch (e1) { log('quick add: components failed', e1); }
    }
    if (items.length) {
      state.catalog = items;
      state.catalogAt = now;
    }
    return items;
  }
  function byKey(key) {
    var list = catalog();
    for (var i = 0; i < list.length; i++) {
      if (list[i].key === key) return list[i];
    }
    // A slot can outlive the thing it points at — a deleted component, a
    // plugin that stopped registering its element. Show it, do not crash.
    var parts = String(key || '').split(':');
    return {
      key: key,
      kind: parts[0] === 'cmp' ? 'component' : 'element',
      name: parts[1] || '',
      label: parts[1] || 'Unknown',
      missing: true,
      icon: ''
    };
  }

  /* ── Markup ───────────────────────────────────────────────────────────── */
  function escapeHtml(value) {
    return String(value == null ? '' : value)
      .replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }
  // One mark for every component. Bricks gives its elements an icon class and
  // gives components nothing, and a letter each turned the bar into an
  // alphabet — the dot already says which are yours, so the glyph only has to
  // say "component".
  var ICON_COMPONENT = '<svg viewBox="0 0 24 24" aria-hidden="true" class="mvqa-svg">' +
    '<rect x="3" y="3" width="8" height="8" rx="1.5"/><rect x="13" y="3" width="8" height="8" rx="1.5"/>' +
    '<rect x="3" y="13" width="8" height="8" rx="1.5"/><path d="M17 13v8M13 17h8"/></svg>';
  var ICON_UNKNOWN = '<svg viewBox="0 0 24 24" aria-hidden="true" class="mvqa-svg">' +
    '<rect x="4" y="4" width="16" height="16" rx="2" stroke-dasharray="3 3"/></svg>';
  function glyph(item) {
    if (item.missing) return ICON_UNKNOWN;
    if (item.kind === 'component') return ICON_COMPONENT;
    // Bricks names the icon class in its own element config, so an element
    // shows the same glyph the element panel does.
    if (item.icon) return '<i class="' + escapeHtml(item.icon) + '" aria-hidden="true"></i>';
    var initial = String(item.label || '?').trim().charAt(0).toUpperCase();
    return '<span class="mvqa-initial" aria-hidden="true">' + escapeHtml(initial) + '</span>';
  }
  function slotButton(key, extraClass) {
    var item = byKey(key);
    var kindWord = item.kind === 'component' ? 'component' : 'element';
    return '<button type="button" class="mvqa-slot' + (extraClass ? ' ' + extraClass : '') +
      (item.missing ? ' is-missing' : '') + '" data-key="' + escapeHtml(key) + '" ' +
      'aria-label="' + escapeHtml(item.label) + ', ' + kindWord + '">' +
      glyph(item) +
      '<span class="mvqa-kind mvqa-kind-' + kindWord + '" aria-hidden="true"></span>' +
      '<span class="mvqa-tip">' + escapeHtml(item.label) +
        ' <em>· ' + (item.missing ? 'missing' : kindWord) + '</em></span>' +
      '</button>';
  }
  var ICON_EDIT = '<svg viewBox="0 0 24 24" aria-hidden="true" class="mvqa-svg">' +
    '<path d="M5 6h14M5 12h14M5 18h14"/><circle cx="9" cy="6" r="2"/><circle cx="15" cy="12" r="2"/>' +
    '<circle cx="8" cy="18" r="2"/></svg>';
  var ICON_ARRANGE = '<svg viewBox="0 0 24 24" aria-hidden="true" class="mvqa-svg">' +
    '<path d="M7 6h13M7 12h13M7 18h13"/><path d="M3 5l1.5 1.5L3 8M3 11l1.5 1.5L3 14M3 17l1.5 1.5L3 20"/></svg>';
  var ICON_TICK = '<svg viewBox="0 0 24 24" aria-hidden="true" class="mvqa-svg">' +
    '<path d="M5 12.5l4.5 4.5L19 7.5"/></svg>';

  function barHtml() {
    var parts = [];
    if (state.arranging) parts.push('<span class="mvqa-mode">arrange</span>');

    state.slots.forEach(function (key, index) {
      // While something is lifted, every place it could go is a gap you can
      // press. Nothing is dragged and nothing has to be aimed at.
      if (state.arranging && state.lifted && index === 0) {
        parts.push(gapHtml(0));
      }
      parts.push(slotButton(key, state.lifted === key ? 'is-lifted' : ''));
      if (state.arranging && state.lifted) parts.push(gapHtml(index + 1));
    });

    if (!state.slots.length) {
      parts.push('<span class="mvqa-empty">Nothing in the Element Tray yet</span>');
    }

    parts.push('<span class="mvqa-sep"></span>');
    if (state.arranging) {
      parts.push('<button type="button" class="mvqa-tail mvqa-tick" data-arrange-done ' +
        'aria-label="Done arranging">' + ICON_TICK + '<span class="mvqa-tip">Done</span></button>');
    } else {
      parts.push('<button type="button" class="mvqa-tail' + (state.sheet ? ' is-on' : '') + '" ' +
        'data-sheet aria-label="Edit Element Tray">' + ICON_EDIT + '<span class="mvqa-tip">Edit tray</span></button>');
      parts.push('<button type="button" class="mvqa-tail" data-arrange aria-label="Arrange the Element Tray">' +
        ICON_ARRANGE + '<span class="mvqa-tip">Arrange</span></button>');
    }
    return parts.join('');
  }
  function gapHtml(index) {
    return '<button type="button" class="mvqa-gap" data-gap="' + index + '" ' +
      'aria-label="Put it here"></button>';
  }

  function sheetHtml() {
    var query = state.query.toLowerCase();
    var list = catalog().filter(function (item) {
      return !query || String(item.label).toLowerCase().indexOf(query) !== -1;
    });
    var elements = list.filter(function (item) { return item.kind === 'element'; });
    var components = list.filter(function (item) { return item.kind === 'component'; });

    function row(item) {
      var inBar = state.slots.indexOf(item.key) !== -1;
      return '<button type="button" class="mvqa-row' + (inBar ? ' is-on' : '') + '" ' +
        'data-pick="' + escapeHtml(item.key) + '">' +
        '<span class="mvqa-row-icon">' + glyph(item) + '</span>' +
        '<span class="mvqa-row-name">' + escapeHtml(item.label) + '</span>' +
        '<span class="mvqa-row-kind"><i class="mvqa-kind mvqa-kind-' +
          (item.kind === 'component' ? 'component' : 'element') + '"></i>' + item.kind + '</span>' +
        '<span class="mvqa-tick-box">✓</span></button>';
    }

    return '<div class="mvqa-sheet">' +
      '<h6>What sits in the Element Tray</h6>' +
      '<p class="mvqa-note">Ticked items are in the tray, in this order. Search reaches every element ' +
        'and every component on this site.</p>' +
      '<input class="mvqa-find" type="search" placeholder="Search elements and components…" ' +
        'value="' + escapeHtml(state.query) + '" autocomplete="off" spellcheck="false">' +
      '<div class="mvqa-list">' +
        (list.length
          ? (elements.length ? '<div class="mvqa-group">Elements</div>' + elements.map(row).join('') : '') +
            (components.length ? '<div class="mvqa-group">Components · this site</div>' +
              components.map(row).join('') : '')
          : '<div class="mvqa-none">Nothing on this site matches that.</div>') +
      '</div>' +
      '<div class="mvqa-foot"><span>' + state.slots.length + ' in the tray · ' + list.length + ' of ' +
        catalog().length + ' shown</span>' +
        '<button type="button" class="mvqa-done" data-sheet-close>Done</button></div>' +
      '</div>';
  }

  /* ── Placement ────────────────────────────────────────────────────────
     The bar belongs over the canvas, not over the Bricks panel, so it is
     centred on the canvas frame when there is one and on the window when
     there is not. */
  function canvasFrame() {
    return document.getElementById('bricks-builder-iframe') ||
      document.getElementById('brx-iframe') ||
      document.querySelector('iframe#bricks-builder-iframe, iframe.bricks-builder-iframe');
  }
  function canvasRect() {
    var frame = canvasFrame();
    if (frame && frame.getBoundingClientRect) {
      var rect = frame.getBoundingClientRect();
      if (rect && rect.width > 120) return rect;
    }
    return null;
  }

  /* The builder has to exist before its chrome does. Bricks shows a splash for
     a second or two, and a bar floating over that is MV talking before it has
     been spoken to. */
  function builderReady() {
    var frame = canvasFrame();
    if (!frame) return false;
    var rect = frame.getBoundingClientRect();
    return !!(rect && rect.width > 120 && rect.height > 120);
  }

  /* Preview hides the builder's own chrome, and MV's chrome goes with it. */
  function inPreview() {
    var body = document.body;
    if (body && body.classList &&
      (body.classList.contains('brx-preview') || body.classList.contains('bricks-preview'))) return true;
    var panel = document.getElementById('bricks-panel') || document.getElementById('brx-panel') ||
      document.querySelector('#bricks-panel, .bricks-panel, #brx-panel');
    if (!panel) return false;
    var rect = panel.getBoundingClientRect();
    // Bricks slides the panel out rather than removing it.
    return rect.width < 40 || rect.right < 10;
  }

  /* The Element Tray belongs to the builder canvas, not MV's blocking layer.
     Its z-index deliberately clears third-party builder docks, so relying on
     numeric stacking alone would let it pierce Media Studio and other MV
     dialogs. Remove it while any visible MV backdrop or modal owns the page;
     it is restored by sync as soon as that surface closes. Mimam's Bar is not
     blocking and is handled separately by the placement clearance below. */
  function blockingMvSurfaceOpen() {
    var nodes = document.querySelectorAll(
      '.ve-studio-backdrop, .ve-modal, .ve-update-refresh-modal'
    );
    for (var i = 0; i < nodes.length; i++) {
      var node = nodes[i];
      if (!node || !node.isConnected || !node.getBoundingClientRect) continue;
      var st;
      try { st = window.getComputedStyle(node); } catch (e) { continue; }
      if (!st || st.display === 'none' || st.visibility === 'hidden' ||
        parseFloat(st.opacity || '1') < .05 || st.pointerEvents === 'none') continue;
      var rect = node.getBoundingClientRect();
      if (rect && rect.width > 20 && rect.height > 20) return true;
    }
    return false;
  }

  /* What the bar has to clear. The canvas floor is usually it, because a bottom
     dock shrinks the canvas — but Code2Bricks resizes with a transition, and at
     some heights it overlaps rather than shrinks, so the docks themselves are
     measured too and whichever reaches highest wins. */
  var GAP = 12;
  function floorY() {
    var vh = window.innerHeight || 0;
    var floor = vh;
    var rect = canvasRect();
    if (rect && rect.bottom < floor) floor = rect.bottom;

    var nodes = document.body ? document.body.children : [];
    var frame = canvasFrame();
    for (var i = 0; i < nodes.length; i++) {
      var el = nodes[i];
      if (!el || !el.getBoundingClientRect) continue;
      if (el.classList && el.classList.contains('mvqa-root')) continue;
      if (el.id === 've-panel-root') continue;
      /* The canvas is not a dock. When a dock overlays rather than resizes, the
         canvas still reaches the floor and matches every test below — which
         pushed the bar to the top of the canvas instead of above the dock. */
      if (frame && (el === frame || (el.contains && el.contains(frame)))) continue;
      var st;
      try { st = window.getComputedStyle(el); } catch (e) { continue; }
      if (!st || (st.position !== 'fixed' && st.position !== 'absolute')) continue;
      if (st.display === 'none' || st.visibility === 'hidden') continue;
      var r = el.getBoundingClientRect();
      // A bottom dock: wide, tall enough to matter, sitting on the floor.
      if (r.width < (window.innerWidth || 0) * 0.5) continue;
      if (r.height < 60) continue;
      if (r.bottom < vh - 4) continue;
      if (r.top < floor) floor = r.top;
    }
    return floor;
  }
  function place() {
    if (!root) return;
    var rect = canvasRect();
    var centre = rect ? rect.left + (rect.width / 2) : (window.innerWidth / 2);
    var clearance = Math.max(0, (window.innerHeight || 0) - floorY());
    var bottom = clearance + GAP;
    // Mimam's Bar is an overlay, not a canvas dock. Opening it must not move
    // the Element Tray; the tray remains anchored to the canvas/dock floor.
    // Through custom properties, not `style.left`: the stylesheet has to say
    // !important to survive Bricks, and !important beats an inline value.
    var placement = Math.round(centre) + '|' + Math.round(bottom);
    if (placement === lastPlacement) return;
    lastPlacement = placement;
    root.style.setProperty('--mvqa-left', Math.round(centre) + 'px');
    root.style.setProperty('--mvqa-bottom', Math.round(bottom) + 'px');
  }

  /* The canvas is resized when C2B is dragged open or shut, and a resize of an
     iframe raises no window event, so the frame itself is watched — and so is
     the body, because a dock that overlaps rather than resizes changes nothing
     about the canvas at all. A dock animates, so each change is followed for a
     few frames rather than measured once. */
  var frameWatcher = null;
  var bodyWatcher = null;
  var overlayWatcher = null;
  var settleUntil = 0;
  function followFor(ms) {
    settleUntil = Math.max(settleUntil, Date.now() + ms);
    if (followFor.running) return;
    followFor.running = true;
    (function tick() {
      sync();
      if (Date.now() < settleUntil) window.requestAnimationFrame(tick);
      else followFor.running = false;
    })();
  }
  function watchCanvas() {
    if (!window.ResizeObserver) return;
    var frame = canvasFrame();
    if (frame && frame !== frameWatcher) {
      frameWatcher = frame;
      try {
        new window.ResizeObserver(function () { followFor(420); }).observe(frame);
      } catch (e) { log('quick add: cannot watch the canvas', e); }
    }
    if (!bodyWatcher && document.body) {
      bodyWatcher = true;
      try {
        new window.ResizeObserver(function () { followFor(420); }).observe(document.body);
      } catch (e0) {}
      try {
        var watch = { childList: true, attributes: true, attributeFilter: ['class', 'style'] };
        var observer = new window.MutationObserver(function () { followFor(420); });
        observer.observe(document.body, watch);
        // Preview and dock height are as often written on <html> as on <body>.
        observer.observe(document.documentElement, { attributes: true, attributeFilter: ['class', 'style'] });
      } catch (e1) {}
      /* And a heartbeat, because a dock can move in more ways than can be
         enumerated — a transition ending, a plugin animating its own height,
         a canvas that never resizes because the dock lies over it. Two rect
         reads twice a second, and it only writes when the answer changed. */
      try { window.setInterval(sync, 500); } catch (e2) {}
    }
    var panelRoot = document.getElementById('ve-panel-root');
    if (panelRoot && (!overlayWatcher || overlayWatcher.node !== panelRoot)) {
      if (overlayWatcher) {
        try { overlayWatcher.observer.disconnect(); } catch (e3) {}
      }
      overlayWatcher = { node: panelRoot, observer: null };
      try {
        overlayWatcher.observer = new window.MutationObserver(function () { sync(); });
        overlayWatcher.observer.observe(panelRoot, { childList: true, subtree: true });
      } catch (e4) {}
    }
  }

  /* ── Render ───────────────────────────────────────────────────────────── */
  function ensureRoot() {
    if (root && root.isConnected) return root;
    root = document.createElement('div');
    root.className = 'mvqa-root';
    root.setAttribute('role', 'toolbar');
    root.setAttribute('aria-label', 'Element Tray');
    document.body.appendChild(root);
    return root;
  }
  function shouldShow() {
    return state.enabled && builderReady() && !inPreview() && !blockingMvSurfaceOpen();
  }

  /* The one entry point. Whether the bar belongs on screen is a question about
     the builder's state, not about anything the bar did, so something has to
     keep asking — and when the answer has not changed, the only work left is
     to put the bar where the floor is now. */
  var lastPlacement = null;
  function sync() {
    watchCanvas();
    var wanted = shouldShow();
    if (wanted !== !!root) { render(); return; }
    if (!root) return;
    place();
  }

  function render() {
    watchCanvas();
    if (!shouldShow()) {
      if (root && root.parentNode) root.parentNode.removeChild(root);
      root = null;
      lastPlacement = null;
      return;
    }
    ensureRoot();
    var caret = null;
    var open = root.querySelector('.mvqa-find');
    if (open) caret = { value: open.value, start: open.selectionStart };

    root.innerHTML =
      (state.sheet ? sheetHtml() : '') +
      '<div class="mvqa-bar' + (state.arranging ? ' is-arranging' : '') + '">' + barHtml() + '</div>';
    place();

    // Rebuilding the sheet must not take the caret away mid-word.
    if (caret) {
      var field = root.querySelector('.mvqa-find');
      if (field) {
        field.focus();
        try { field.setSelectionRange(caret.start, caret.start); } catch (e) {}
      }
    }
  }

  /* ── Inserting ────────────────────────────────────────────────────────── */
  function toast(message, type) {
    try {
      if (window.MimamsBarToast && typeof window.MimamsBarToast.show === 'function') {
        window.MimamsBarToast.show(message, type || 'info');
        return;
      }
    } catch (e) {}
    log('quick add: ' + message);
  }
  function insert(key) {
    var api = adapter();
    if (!api) { toast('Bricks is not ready yet.', 'error'); return; }
    var item = byKey(key);
    if (item.missing) {
      toast(item.label + ' is no longer registered on this site.', 'error');
      return;
    }
    var result;
    try {
      result = item.kind === 'component'
        ? api.addBricksComponent(item.config || { componentId: item.componentId }, {})
        : api.addBricksElement(item.name, {});
    } catch (e) {
      log('quick add: insert threw', e);
      result = { ok: false, reason: 'threw' };
    }
    if (result && result.ok) {
      toast(item.label + ' added. Save in Bricks to keep it.', 'success');
    } else {
      toast('Could not add ' + item.label + ((result && result.reason) ? ' (' + result.reason + ')' : '') + '.', 'error');
    }
  }

  /* ── Events ───────────────────────────────────────────────────────────── */
  function closest(target, selector) {
    return target && target.closest ? target.closest(selector) : null;
  }
  document.addEventListener('click', function (event) {
    if (!state.enabled || !root) return;
    var inside = closest(event.target, '.mvqa-root');
    if (!inside) {
      if (state.sheet || state.arranging) {
        state.sheet = false;
        state.arranging = false;
        state.lifted = null;
        render();
      }
      return;
    }

    if (closest(event.target, '[data-sheet]')) {
      state.sheet = !state.sheet;
      state.query = '';
      state.arranging = false;
      state.lifted = null;
      render();
      return;
    }
    if (closest(event.target, '[data-sheet-close]')) {
      state.sheet = false;
      render();
      return;
    }
    if (closest(event.target, '[data-arrange]')) {
      state.arranging = true;
      state.sheet = false;
      state.lifted = null;
      render();
      return;
    }
    if (closest(event.target, '[data-arrange-done]')) {
      state.arranging = false;
      state.lifted = null;
      render();
      return;
    }

    var pick = closest(event.target, '[data-pick]');
    if (pick) {
      var key = pick.getAttribute('data-key') || pick.dataset.pick;
      var at = state.slots.indexOf(key);
      if (at !== -1) state.slots.splice(at, 1);
      else state.slots.push(key);           // a new pick lands at the end
      write();
      render();
      return;
    }

    var gap = closest(event.target, '[data-gap]');
    if (gap && state.lifted) {
      var to = parseInt(gap.getAttribute('data-gap'), 10) || 0;
      var from = state.slots.indexOf(state.lifted);
      if (from !== -1) {
        var next = state.slots.slice();
        next.splice(from, 1);
        if (to > from) to -= 1;
        next.splice(to, 0, state.lifted);
        state.slots = next;
        write();
      }
      state.lifted = null;
      render();
      return;
    }

    var slot = closest(event.target, '.mvqa-slot');
    if (slot) {
      var slotKey = slot.getAttribute('data-key');
      if (state.arranging) {
        state.lifted = state.lifted === slotKey ? null : slotKey;
        render();
      } else {
        insert(slotKey);
      }
    }
  }, true);

  document.addEventListener('input', function (event) {
    if (!root || !event.target || !event.target.classList) return;
    if (!event.target.classList.contains('mvqa-find')) return;
    state.query = String(event.target.value || '').trim();
    render();
  });

  document.addEventListener('keydown', function (event) {
    if (!state.enabled || event.key !== 'Escape') return;
    if (!state.sheet && !state.arranging) return;
    state.sheet = false;
    state.arranging = false;
    state.lifted = null;
    render();
  });

  window.addEventListener('resize', sync);

  // MV's settings panel lives in the same window; when the switch moves there,
  // the bar appears or leaves without a reload.
  window.addEventListener('ve-quick-add-changed', function (event) {
    state.enabled = !!(event && event.detail);
    render();
  });

  /* Bricks fires nothing MV can rely on when preview is toggled, and the
     keyboard shortcut for it does not touch the DOM until afterwards. */
  document.addEventListener('click', function () { followFor(500); }, true);

  /* ── Start ────────────────────────────────────────────────────────────── */
  function boot() {
    read();
    render();
    // Bricks fills window.bricksData after its own boot; the first catalog
    // read that succeeds is the one that sticks.
    var tries = 0;
    var timer = window.setInterval(function () {
      tries += 1;
      watchCanvas();
      sync();
      // Bricks fills window.bricksData after its own boot, and shows a splash
      // until the canvas exists. Waiting for both is what keeps the bar off
      // the loading screen.
      if ((builderReady() && catalog({ fresh: true }).length) || tries > 60) {
        window.clearInterval(timer);
        render();
      }
    }, 250);
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', boot);
  } else {
    boot();
  }

  window.MimamsBarQuickAdd = {
    render: render,
    state: state,
    setEnabled: function (value) { state.enabled = !!value; render(); }
  };
})();
