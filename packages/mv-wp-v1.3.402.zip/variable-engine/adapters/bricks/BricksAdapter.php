<?php
namespace VE\Adapters;
defined('ABSPATH') || exit;

class BricksAdapter {
    public function __construct() { add_action('wp', [$this, 'init']); }
    public function init(): void {
        if (!isset($_GET['bricks']) || $_GET['bricks'] !== 'run') return;
        ( new \VE\Adapters\Bricks\VariablesMirror() )->sync();
        add_action('wp_enqueue_scripts', [$this, 'enqueue'], 9999);
    }
    public function enqueue(): void {
        // All runtime vendor assets are bundled with the plugin, not loaded from a CDN, so
        // the builder works offline, under strict CSP, and on privacy-strict hosts. GSAP was
        // enqueued but never referenced by the panel; it has been removed.
        $ver = VE_VERSION;
        wp_enqueue_style('ve-ph', VE_URL.'assets/phosphor/style.css', [], $ver.'.'.filemtime(VE_DIR.'assets/phosphor/style.css'));
        wp_enqueue_style('ve-components', VE_URL.'assets/components.css', [], $ver.'.'.filemtime(VE_DIR.'assets/components.css'));
        // CodeMirror's editor CSS is pre-scoped to `.ve-cm-host` (codemirror.scoped.css), so it
        // styles only MV's own editors and never bleeds into — or gets neutralized against —
        // other plugins' code editors (Advanced Themer Style Manager, Code2Bricks Quick Import).
        wp_enqueue_style('ve-codemirror', VE_URL.'assets/vendor/codemirror/codemirror.scoped.css', [], '5.65.16');
        wp_enqueue_style('ve-codemirror-hint', VE_URL.'assets/vendor/codemirror/show-hint.css', ['ve-codemirror'], '5.65.16');
        wp_enqueue_script('ve-p', VE_URL.'assets/vendor/preact.umd.js', [], '10', true);
        wp_enqueue_script('ve-ph', VE_URL.'assets/vendor/preact-hooks.umd.js', ['ve-p'], '10', true);
        wp_enqueue_script('ve-codemirror', VE_URL.'assets/vendor/codemirror/codemirror.js', [], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-css', VE_URL.'assets/vendor/codemirror/mode-css.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-closebrackets', VE_URL.'assets/vendor/codemirror/closebrackets.js', ['ve-codemirror'], '5.65.16', true);
        wp_enqueue_script('ve-codemirror-hint', VE_URL.'assets/vendor/codemirror/show-hint.js', ['ve-codemirror'], '5.65.16', true);
        $app_dependencies = array_merge(
            ['ve-p','ve-ph','ve-codemirror-css','ve-codemirror-closebrackets','ve-codemirror-hint'],
            \VE\Core\RankMathAnalysisBridge::enqueue()
        );
        wp_enqueue_script('ve-app', VE_URL.'assets/js/builder-panel.js', $app_dependencies, $ver.'.'.filemtime(VE_DIR.'assets/js/builder-panel.js'), true);
        $preferences = get_user_meta( get_current_user_id(), 've_user_preferences', true );
        wp_localize_script('ve-app', 'vePanel', ['apiRoot'=>esc_url_raw(rest_url()),'ajaxUrl'=>esc_url_raw(admin_url('admin-ajax.php')),'nonce'=>wp_create_nonce('wp_rest'),'version'=>VE_VERSION,'mode'=>'builder','siteTitle'=>sanitize_text_field(get_bloginfo('name')),'logoUrl'=>esc_url_raw(VE_URL.'assets/hebronmimam-logo-icon.png'),'assetUrl'=>esc_url_raw(VE_URL.'assets/'),'fontToolsScript'=>esc_url_raw(VE_URL.'assets/vendor/fonteditor-core/fonteditor-core.iife.js'),'fontToolsWasm'=>esc_url_raw(VE_URL.'assets/vendor/fonteditor-core/woff2.wasm'),'userPreferences'=>is_array($preferences)?$preferences:[]]);
        if (class_exists('\VE\Modules\BuilderTools\MimamsBarModule')) {
            (new \VE\Modules\BuilderTools\MimamsBarModule())->enqueue('builder');
        }
    }
}
