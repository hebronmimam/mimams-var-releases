<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

class MigrationScanner {

    public function sources(): array {
        return [
            [
                'id'          => 'bricks',
                'name'        => 'Bricks / Advanced Themer',
                'available'   => (bool) get_option( 'bricks_global_variables', false ) || (bool) get_option( 'bricks_theme_styles', false ),
                'description' => 'Reads Bricks global variables and theme-style CSS variables. Advanced Themer stores much of its variable work there.',
            ],
            [
                'id'          => 'core-framework',
                'name'        => 'Core Framework',
                'available'   => $this->core_framework_available(),
                'description' => 'Scans Core Framework options, colors, selected preset backup, and preset table CSS.',
            ],
            [
                'id'          => 'acss',
                'name'        => 'Automatic.css',
                'available'   => (bool) get_option( 'automatic_css_settings', false ),
                'description' => 'Scans Automatic.css settings for token-like scalar values and CSS custom properties.',
            ],
        ];
    }

    public function scan( string $source = 'all' ): array {
        $vars = [];

        if ( 'all' === $source || 'bricks' === $source || 'advanced-themer' === $source ) {
            $vars = array_merge( $vars, $this->scan_bricks() );
        }
        if ( 'all' === $source || 'core-framework' === $source ) {
            $vars = array_merge( $vars, $this->scan_core_framework() );
        }
        if ( 'all' === $source || 'acss' === $source ) {
            $vars = array_merge( $vars, $this->scan_acss() );
        }

        return $this->dedupe( $vars );
    }

    public function source_name( string $source ): string {
        foreach ( $this->sources() as $candidate ) {
            if ( (string) $candidate['id'] === $source ) {
                return (string) $candidate['name'];
            }
        }
        return 'External Sources';
    }

    private function scan_bricks(): array {
        $vars = [];
        $vars = array_merge( $vars, $this->parse_variable_list( get_option( 'bricks_global_variables', [] ), 'bricks' ) );
        $vars = array_merge( $vars, $this->parse_any( get_option( 'bricks_theme_styles', [] ), 'bricks.theme' ) );
        return $vars;
    }

    private function scan_core_framework(): array {
        global $wpdb;

        $vars = [];
        foreach ( [ 'core_framework_main', 'core_framework_colors', 'core_framework_selected_preset_backup', 'core_framework_editor_prefixed_css' ] as $option ) {
            $vars = array_merge( $vars, $this->parse_any( get_option( $option, [] ), 'core' ) );
        }

        $table = $wpdb->prefix . 'core_framework_presets';
        if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table ) {
            $rows = $wpdb->get_results( "SELECT * FROM {$table} LIMIT 20", ARRAY_A ) ?: [];
            foreach ( $rows as $row ) {
                $vars = array_merge( $vars, $this->parse_any( $row, 'core' ) );
            }
        }

        return $vars;
    }

    private function scan_acss(): array {
        return $this->parse_any( get_option( 'automatic_css_settings', [] ), 'acss' );
    }

    private function parse_variable_list( $data, string $fallback_ns ): array {
        if ( is_string( $data ) ) {
            $decoded = json_decode( $data, true );
            if ( is_array( $decoded ) ) {
                $data = $decoded;
            }
        }
        if ( ! is_array( $data ) ) {
            return [];
        }

        $out = [];
        foreach ( $data as $item ) {
            if ( ! is_array( $item ) ) {
                continue;
            }

            $name  = (string) ( $item['name'] ?? $item['label'] ?? $item['id'] ?? '' );
            $value = (string) ( $item['value'] ?? $item['raw'] ?? $item['color'] ?? '' );
            if ( '' === $name || '' === $value ) {
                $out = array_merge( $out, $this->parse_any( $item, $fallback_ns ) );
                continue;
            }
            $token = $this->token_name( $name, $fallback_ns );
            if ( '' !== $token && $this->looks_like_value( $value ) ) {
                $out[] = $this->variable( $token, $value );
            }
        }

        return $out;
    }

    private function parse_any( $data, string $fallback_ns, string $path = '' ): array {
        if ( is_string( $data ) ) {
            $vars = $this->parse_css_vars( $data, $fallback_ns );
            $decoded = json_decode( $data, true );
            if ( is_array( $decoded ) ) {
                $vars = array_merge( $vars, $this->parse_any( $decoded, $fallback_ns, $path ) );
            }
            return $vars;
        }

        if ( ! is_array( $data ) ) {
            return [];
        }

        $out = [];
        foreach ( $data as $key => $value ) {
            $key = is_string( $key ) ? $key : '';
            $next_path = '' === $path ? $key : $path . '.' . $key;

            if ( is_array( $value ) ) {
                if ( isset( $value['name'] ) && ( isset( $value['value'] ) || isset( $value['color'] ) ) ) {
                    $name = $this->token_name( (string) $value['name'], $fallback_ns );
                    $val  = (string) ( $value['value'] ?? $value['color'] ?? '' );
                    if ( '' !== $name && $this->looks_like_value( $val ) ) {
                        $out[] = $this->variable( $name, $val );
                    }
                }
                $out = array_merge( $out, $this->parse_any( $value, $fallback_ns, $next_path ) );
                continue;
            }

            $str = (string) $value;
            $out = array_merge( $out, $this->parse_css_vars( $str, $fallback_ns ) );
            if ( '' !== $key && $this->looks_like_value( $str ) ) {
                $name = $this->token_name( $next_path, $fallback_ns );
                if ( '' !== $name ) {
                    $out[] = $this->variable( $name, $str );
                }
            }
        }

        return $out;
    }

    private function parse_css_vars( string $text, string $fallback_ns ): array {
        $out = [];
        if ( ! preg_match_all( '/--([a-zA-Z0-9_-]+)\s*:\s*([^;}{]+);/', $text, $matches, PREG_SET_ORDER ) ) {
            return $out;
        }

        foreach ( $matches as $match ) {
            $name = $this->token_name( '--' . $match[1], $fallback_ns );
            $val  = trim( (string) $match[2] );
            if ( '' !== $name && '' !== $val ) {
                $out[] = $this->variable( $name, $val );
            }
        }

        return $out;
    }

    private function variable( string $name, string $value ): array {
        $manager = new VariableManager();
        $external_css_name = strtolower( $manager->to_css_name( $name ) );
        $name = $this->semantic_name( $name, $value );
        $variable = [
            'name'            => $name,
            'value'           => sanitize_text_field( $value ),
            'namespace'       => explode( '.', $name )[0],
            'type'            => 'base',
            'public_css_name' => strtolower( $manager->to_css_name( $name ) ),
            'external_css_name' => $external_css_name,
        ];
        $source_css_name = VariableManager::alias_css_name_from_value( $value );
        if ( '' !== $source_css_name ) {
            $source_name = $this->token_name( $source_css_name, explode( '.', $name )[0] );
            $source_name = $this->semantic_name( $source_name, '' );
            if ( '' !== $source_name && $source_name !== $name ) {
                $variable['value'] = '';
                $variable['type'] = 'alias';
                $variable['source_name'] = $source_name;
                $variable['source_css_name'] = strtolower( $source_css_name );
            }
        }
        return $variable;
    }

    private function semantic_name( string $name, string $value ): string {
        $parts = array_values( array_filter( explode( '.', strtolower( trim( $name ) ) ), static function ( string $part ): bool {
            return '' !== $part;
        } ) );
        $source_wrappers = [ 'base', 'bricks', 'brickstheme', 'advanced-themer', 'advancedthemer', 'core', 'acss', 'automatic-css', 'automaticcss' ];
        while ( count( $parts ) > 1 && in_array( $parts[0], $source_wrappers, true ) ) {
            array_shift( $parts );
        }
        if ( empty( $parts ) ) {
            return $name;
        }

        $families = [
            'color', 'background', 'bg', 'border', 'stroke', 'shadow',
            'font', 'typography', 'heading', 'text', 'weight',
            'space', 'spacing', 'gap', 'radius', 'size', 'grid',
            'opacity', 'motion', 'breakpoint', 'layout', 'container', 'z',
            'design', 'status',
        ];
        $looks_color = $this->looks_like_color( $value );
        if ( ! in_array( (string) $parts[0], $families, true ) && $looks_color ) {
            array_unshift( $parts, 'color' );
        }

        // Color is the only automatic top-level category. External non-color
        // paths are flattened into one portable token; users can add their own
        // category later without inheriting framework storage structure.
        $semantic = 'color' === (string) $parts[0] ? implode( '.', $parts ) : implode( '-', $parts );
        return preg_match( VariableManager::NAME_PATTERN, $semantic ) ? $semantic : $name;
    }

    private function looks_like_color( string $value ): bool {
        return ColorPaletteManager::is_css_color_value( $value );
    }

    private function token_name( string $name, string $fallback_ns ): string {
        $name = strtolower( trim( $name ) );
        $name = preg_replace( '/^--/', '', $name );
        $name = preg_replace( '/[^a-z0-9._-]+/', '.', $name );
        $name = str_replace( [ '_', '-' ], '.', $name );
        $name = preg_replace( '/\.+/', '.', $name );
        $name = trim( (string) $name, '.' );

        if ( '' === $name ) {
            return '';
        }

        $first = explode( '.', $name )[0];
        if ( ! in_array( $first, [ 'color', 'space', 'spacing', 'font', 'typography', 'heading', 'text', 'radius', 'size', 'shadow', 'opacity', 'motion', 'grid', 'stroke', 'weight', 'design', 'base', 'status' ], true ) ) {
            $name = sanitize_key( $fallback_ns ) . '.' . $name;
        }

        return preg_match( VariableManager::NAME_PATTERN, $name ) ? $name : '';
    }

    private function looks_like_value( string $value ): bool {
        $value = trim( $value );
        if ( '' === $value || strlen( $value ) > 220 ) {
            return false;
        }
        if ( ColorPaletteManager::is_css_color_value( $value ) ) {
            return true;
        }
        return (bool) preg_match( '/^(#|rgb|hsl|oklch|var\(|clamp\(|calc\(|-?\d+(?:\.\d+)?(?:px|rem|em|%|vh|vw)?$)/i', $value );
    }

    private function dedupe( array $vars ): array {
        $seen = [];
        foreach ( $vars as $var ) {
            $name = (string) ( $var['name'] ?? '' );
            $type = (string) ( $var['type'] ?? 'base' );
            $has_value = '' !== (string) ( $var['value'] ?? '' );
            $has_source = 'alias' === $type && '' !== (string) ( $var['source_name'] ?? '' );
            if ( '' === $name || ( ! $has_value && ! $has_source ) ) {
                continue;
            }
            $identity = strtolower( (string) ( $var['public_css_name'] ?? '' ) );
            if ( '' === $identity ) {
                $identity = $name;
            }
            $seen[ $identity ] = $var;
        }
        $deduped = array_values( $seen );
        usort( $deduped, static function ( array $a, array $b ): int {
            return strnatcasecmp( (string) ( $a['name'] ?? '' ), (string) ( $b['name'] ?? '' ) );
        } );
        return $deduped;
    }

    private function core_framework_available(): bool {
        global $wpdb;
        $table = $wpdb->prefix . 'core_framework_presets';
        return (bool) get_option( 'core_framework_main', false )
            || (bool) get_option( 'core_framework_colors', false )
            || ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table );
    }
}
