<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

final class SettingsTransferManager {
    public const SCHEMA_VERSION = 1;

    private const MV_CORE_KEYS = [
        'vw_min',
        'vw_max',
        'delete_on_uninstall',
        'update_channel',
        'auto_update',
        'allow_multi_panels',
        'show_all_tab',
        'media_replace_wp_library',
        'media_auto_sync_external_folders',
    ];

    private const MV_MODULE_KEYS = [
        'deactivated_tools',
        'deactivated_tool_surfaces',
    ];

    private const MV_STUDIO_PREFERENCE_KEYS = [
        've_css_scss',
        've_css_source_order',
        've_css_disabled_sources',
        've_content_visible_groups',
        've_media_layout',
        've_media_filter',
        've_media_sort',
        've_media_collection_sort',
        've_media_collections',
        've_media_replace_wp_library',
        've_media_auto_sync_external_folders',
        've_plugin_directory_view',
        've_fab_order',
    ];

    private const BRICKS_OPTIONS = [
        'bricks_site' => [
            'bricks_global_settings',
        ],
        'bricks_classes' => [
            'bricks_global_classes',
            'bricks_global_classes_names_ids',
            'bricks_global_classes_namesIds',
        ],
        'bricks_variables' => [
            'bricks_global_variables',
            'bricks_global_variables_categories',
        ],
        'bricks_theme_styles' => [
            'bricks_theme_styles',
        ],
        'bricks_global_elements' => [
            'bricks_global_elements',
        ],
    ];

    public function group_definitions(): array {
        return [
            [ 'id' => 'mv_core', 'product' => 'mv', 'label' => 'Core settings', 'description' => 'Viewport, update channel, panel behavior, and shared runtime preferences.' ],
            [ 'id' => 'mv_modules', 'product' => 'mv', 'label' => 'Modules & surfaces', 'description' => 'Admin and Builder module availability.' ],
            [ 'id' => 'mv_bar', 'product' => 'mv', 'label' => "Mimam's Bar", 'description' => 'Modes, shortcuts, panel behavior, and toolbar preferences.' ],
            [ 'id' => 'mv_studio', 'product' => 'mv', 'label' => 'Studio preferences', 'description' => 'CSS, Content, Media, and Plugin Studio preferences.' ],
            [ 'id' => 'bricks_site', 'product' => 'bricks', 'label' => 'Site settings', 'description' => 'Global Bricks builder and site settings.' ],
            [ 'id' => 'bricks_classes', 'product' => 'bricks', 'label' => 'Global classes', 'description' => 'Bricks global class definitions and name maps.' ],
            [ 'id' => 'bricks_variables', 'product' => 'bricks', 'label' => 'Global variables', 'description' => 'Bricks variables and variable categories.' ],
            [ 'id' => 'bricks_theme_styles', 'product' => 'bricks', 'label' => 'Theme styles', 'description' => 'Bricks global theme style definitions.' ],
            [ 'id' => 'bricks_global_elements', 'product' => 'bricks', 'label' => 'Global elements', 'description' => 'Reusable Bricks global elements.' ],
        ];
    }

    public function export_bundle( array $requested_groups, int $user_id ): array {
        $group_ids = $this->normalize_group_ids( $requested_groups );
        $groups = [];
        foreach ( $group_ids as $group_id ) {
            $groups[ $group_id ] = $this->read_group( $group_id, $user_id );
        }

        return [
            'product'        => 'mimams-var-settings',
            'schema_version' => self::SCHEMA_VERSION,
            'plugin_version' => defined( 'VE_VERSION' ) ? VE_VERSION : '',
            'bricks_version' => defined( 'BRICKS_VERSION' ) ? BRICKS_VERSION : (string) get_option( 'bricks_version', '' ),
            'site_name'      => sanitize_text_field( (string) get_bloginfo( 'name' ) ),
            'site_url'       => esc_url_raw( (string) home_url( '/' ) ),
            'created_at'     => gmdate( 'c' ),
            'groups'         => $groups,
        ];
    }

    public function preview_bundle( array $bundle, array $requested_groups ) {
        $validated = $this->validate_bundle( $bundle, $requested_groups );
        if ( is_wp_error( $validated ) ) {
            return $validated;
        }

        $rows = [];
        foreach ( $validated['groups'] as $group_id ) {
            $definition = $this->definition_for( $group_id );
            $rows[] = [
                'id'           => $group_id,
                'label'        => $definition['label'],
                'product'      => $definition['product'],
                'items'        => $this->count_payload_items( $bundle['groups'][ $group_id ] ),
                'will_replace' => $this->group_has_existing_data( $group_id ),
            ];
        }

        return [
            'compatible'     => true,
            'schema_version' => (int) $bundle['schema_version'],
            'plugin_version' => sanitize_text_field( (string) ( $bundle['plugin_version'] ?? '' ) ),
            'bricks_version' => sanitize_text_field( (string) ( $bundle['bricks_version'] ?? '' ) ),
            'site_name'      => sanitize_text_field( (string) ( $bundle['site_name'] ?? '' ) ),
            'created_at'     => sanitize_text_field( (string) ( $bundle['created_at'] ?? '' ) ),
            'groups'         => $rows,
            'fingerprint'    => $this->fingerprint( $bundle, $validated['groups'] ),
        ];
    }

    public function apply_bundle( array $bundle, array $requested_groups, string $fingerprint, int $user_id ) {
        $validated = $this->validate_bundle( $bundle, $requested_groups );
        if ( is_wp_error( $validated ) ) {
            return $validated;
        }
        if ( ! hash_equals( $this->fingerprint( $bundle, $validated['groups'] ), $fingerprint ) ) {
            return new \WP_Error( 've_transfer_preview_expired', 'The import changed after preview. Review it again before applying.', [ 'status' => 409 ] );
        }

        $applied = [];
        foreach ( $validated['groups'] as $group_id ) {
            $this->write_group( $group_id, $bundle['groups'][ $group_id ], $user_id );
            $definition = $this->definition_for( $group_id );
            $applied[] = [ 'id' => $group_id, 'label' => $definition['label'] ];
        }

        return [
            'success'         => true,
            'applied'         => $applied,
            'reload_required' => true,
            'message'         => count( $applied ) . ' settings group(s) imported. Reload this surface to use the restored settings.',
        ];
    }

    private function validate_bundle( array $bundle, array $requested_groups ) {
        if ( 'mimams-var-settings' !== ( $bundle['product'] ?? '' ) ) {
            return new \WP_Error( 've_transfer_invalid_product', "This is not a Mimam's Var settings package.", [ 'status' => 400 ] );
        }
        if ( self::SCHEMA_VERSION !== (int) ( $bundle['schema_version'] ?? 0 ) ) {
            return new \WP_Error( 've_transfer_schema_mismatch', 'This settings package uses an unsupported schema version.', [ 'status' => 400 ] );
        }
        if ( ! isset( $bundle['groups'] ) || ! is_array( $bundle['groups'] ) ) {
            return new \WP_Error( 've_transfer_missing_groups', 'The settings package does not contain any groups.', [ 'status' => 400 ] );
        }

        $group_ids = $this->normalize_group_ids( $requested_groups );
        $group_ids = array_values( array_filter( $group_ids, static function ( string $group_id ) use ( $bundle ): bool {
            return array_key_exists( $group_id, $bundle['groups'] );
        } ) );
        if ( [] === $group_ids ) {
            return new \WP_Error( 've_transfer_empty_selection', 'Choose at least one available settings group.', [ 'status' => 400 ] );
        }
        return [ 'groups' => $group_ids ];
    }

    private function normalize_group_ids( array $requested_groups ): array {
        $allowed = array_column( $this->group_definitions(), 'id' );
        $clean = [];
        foreach ( $requested_groups as $group_id ) {
            $group_id = sanitize_key( (string) $group_id );
            if ( in_array( $group_id, $allowed, true ) && ! in_array( $group_id, $clean, true ) ) {
                $clean[] = $group_id;
            }
        }
        return $clean;
    }

    private function definition_for( string $group_id ): array {
        foreach ( $this->group_definitions() as $definition ) {
            if ( $definition['id'] === $group_id ) {
                return $definition;
            }
        }
        return [ 'id' => $group_id, 'label' => $group_id, 'product' => 'mv' ];
    }

    private function read_group( string $group_id, int $user_id ) {
        $settings = get_option( 've_settings', [] );
        $settings = is_array( $settings ) ? $settings : [];
        $preferences = get_user_meta( $user_id, 've_user_preferences', true );
        $preferences = is_array( $preferences ) ? $preferences : [];

        if ( 'mv_core' === $group_id ) {
            return [ 'settings' => array_intersect_key( $settings, array_flip( self::MV_CORE_KEYS ) ) ];
        }
        if ( 'mv_modules' === $group_id ) {
            return [ 'settings' => array_intersect_key( $settings, array_flip( self::MV_MODULE_KEYS ) ) ];
        }
        if ( 'mv_bar' === $group_id ) {
            return [ 'preferences' => [ 'mimamsBarSettings' => $preferences['mimamsBarSettings'] ?? [] ] ];
        }
        if ( 'mv_studio' === $group_id ) {
            return [ 'preferences' => array_intersect_key( $preferences, array_flip( self::MV_STUDIO_PREFERENCE_KEYS ) ) ];
        }

        $options = [];
        foreach ( self::BRICKS_OPTIONS[ $group_id ] ?? [] as $option_name ) {
            $options[ $option_name ] = get_option( $option_name, [] );
        }
        return [ 'options' => $options ];
    }

    private function write_group( string $group_id, $payload, int $user_id ): void {
        $payload = is_array( $payload ) ? $this->sanitize_payload( $payload, 0 ) : [];
        if ( 'mv_core' === $group_id || 'mv_modules' === $group_id ) {
            $allowed = 'mv_core' === $group_id ? self::MV_CORE_KEYS : self::MV_MODULE_KEYS;
            $incoming = isset( $payload['settings'] ) && is_array( $payload['settings'] ) ? array_intersect_key( $payload['settings'], array_flip( $allowed ) ) : [];
            $current = get_option( 've_settings', [] );
            $current = is_array( $current ) ? $current : [];
            update_option( 've_settings', array_merge( $current, $incoming ) );
            if ( array_key_exists( 'delete_on_uninstall', $incoming ) ) {
                update_option( 've_delete_on_uninstall', ! empty( $incoming['delete_on_uninstall'] ) );
            }
            if ( 'mv_core' === $group_id && class_exists( '\\VE\\Core\\Updater' ) ) {
                ( new Updater() )->clear_cache();
                delete_site_transient( 'update_plugins' );
            }
            return;
        }

        if ( 'mv_bar' === $group_id || 'mv_studio' === $group_id ) {
            $allowed = 'mv_bar' === $group_id ? [ 'mimamsBarSettings' ] : self::MV_STUDIO_PREFERENCE_KEYS;
            $incoming = isset( $payload['preferences'] ) && is_array( $payload['preferences'] ) ? array_intersect_key( $payload['preferences'], array_flip( $allowed ) ) : [];
            $current = get_user_meta( $user_id, 've_user_preferences', true );
            $current = is_array( $current ) ? $current : [];
            update_user_meta( $user_id, 've_user_preferences', array_merge( $current, $incoming ) );
            return;
        }

        $incoming_options = isset( $payload['options'] ) && is_array( $payload['options'] ) ? $payload['options'] : [];
        foreach ( self::BRICKS_OPTIONS[ $group_id ] ?? [] as $option_name ) {
            if ( array_key_exists( $option_name, $incoming_options ) ) {
                update_option( $option_name, $incoming_options[ $option_name ], false );
            }
        }
    }

    private function sanitize_payload( array $value, int $depth ): array {
        if ( $depth >= 10 ) {
            return [];
        }
        $clean = [];
        $count = 0;
        foreach ( $value as $key => $item ) {
            if ( $count >= 20000 ) {
                break;
            }
            $safe_key = is_int( $key ) ? $key : substr( (string) $key, 0, 255 );
            if ( is_array( $item ) ) {
                $clean[ $safe_key ] = $this->sanitize_payload( $item, $depth + 1 );
            } elseif ( is_bool( $item ) || is_int( $item ) || is_float( $item ) || null === $item ) {
                $clean[ $safe_key ] = $item;
            } else {
                $clean[ $safe_key ] = substr( (string) $item, 0, 1000000 );
            }
            $count++;
        }
        return $clean;
    }

    private function count_payload_items( $payload ): int {
        if ( ! is_array( $payload ) ) {
            return 1;
        }
        $count = 0;
        foreach ( $payload as $item ) {
            $count += is_array( $item ) ? max( 1, count( $item ) ) : 1;
        }
        return $count;
    }

    private function group_has_existing_data( string $group_id ): bool {
        if ( 0 === strpos( $group_id, 'mv_' ) ) {
            return true;
        }
        foreach ( self::BRICKS_OPTIONS[ $group_id ] ?? [] as $option_name ) {
            if ( false !== get_option( $option_name, false ) ) {
                return true;
            }
        }
        return false;
    }

    private function fingerprint( array $bundle, array $group_ids ): string {
        return hash( 'sha256', (string) wp_json_encode( [ $bundle, array_values( $group_ids ) ] ) );
    }
}
