(function () {
  'use strict';

  if (window.MimamsBarFrameBridge || window.MimamsBarEverythingManager) return;

  // Phase A scopes. Plugins / Settings / Bricks arrive with the everything-index
  // REST endpoint (Phase B); their pills are added then.
  var SCOPES = [
    { key: 'all', label: 'All' },
    { key: 'page', label: 'Pages' }
  ];

  var COMMANDS = [
    { type: 'action', cat: 'command', title: 'Direct mode', meta: 'Edit the selected element', icon: 'sliders-horizontal', mode: 'default', keywords: 'attributes classes id direct' },
    { type: 'action', cat: 'command', title: 'Search page', meta: 'Find and select an element', icon: 'magnifying-glass', mode: 'elements', keywords: 'navigate select element find' },
    { type: 'action', cat: 'command', title: 'Add element', meta: 'Search Bricks or use Emmet', icon: 'plus', mode: 'add-elements', keywords: 'insert bricks emmet new' },
    { type: 'action', cat: 'command', title: "Open Mimam's Var settings", meta: 'Settings', icon: 'gear-six', action: 'settings', keywords: 'preferences configure options' },
    { type: 'action', cat: 'command', title: "Open Mimam's Bar help", meta: 'Help', icon: 'question', action: 'help', keywords: 'shortcuts commands guide' }
  ];

  var CAT = {
    command: { label: 'command', color: '#c9c9c9' },
    page: { label: 'page', color: '#ffcf8a' }
  };

  var pageCache = {};   // query -> [page items]
  var pageFetching = {}; // query -> true

  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c];
    });
  }

  function fuzzy(title, q) {
    if (!q) return { score: 0, html: esc(title) };
    var t = String(title).toLowerCase(), ql = q.toLowerCase();
    var idx = t.indexOf(ql);
    if (idx > -1) {
      return { score: idx === 0 ? 100 : 60, html: esc(title.slice(0, idx)) + '<mark>' + esc(title.slice(idx, idx + ql.length)) + '</mark>' + esc(title.slice(idx + ql.length)) };
    }
    var ti = 0, out = '';
    for (var qi = 0; qi < ql.length; qi++) {
      var f = t.indexOf(ql[qi], ti);
      if (f === -1) return null;
      out += esc(title.slice(ti, f)) + '<mark>' + esc(title[f]) + '</mark>';
      ti = f + 1;
    }
    return { score: 20, html: out + esc(title.slice(ti)) };
  }

  function cfg() { return window.baqaConfig || (window.MimamsBarCore && window.MimamsBarCore.config) || {}; }

  function fetchPages(app, query) {
    if (pageCache[query] || pageFetching[query]) return;
    var c = cfg();
    var root = String(c.apiRoot || (window.vePanel && window.vePanel.apiRoot) || '').replace(/\/?$/, '/');
    if (!root || !window.fetch) { pageCache[query] = []; return; }
    pageFetching[query] = true;
    var headers = {};
    var nonce = c.nonce || (window.vePanel && window.vePanel.nonce) || '';
    if (nonce) headers['X-WP-Nonce'] = nonce;
    var url = root + 'wp/v2/search?search=' + encodeURIComponent(query) + '&per_page=8&subtype=page,post';
    window.fetch(url, { headers: headers, credentials: 'same-origin' })
      .then(function (res) { return res && res.ok ? res.json() : []; })
      .then(function (list) {
        pageCache[query] = (Array.isArray(list) ? list : []).map(function (r) {
          return { type: 'page', cat: 'page', id: r.id, title: String(r.title || '(untitled)'), url: r.url || '', subtype: r.subtype || 'page', icon: 'file-text' };
        });
        pageFetching[query] = false;
        // Re-render if still relevant.
        if (app && app.mode === 'everything' && app.input && String(app.input.value || '').trim().toLowerCase() === query) {
          if (typeof app.renderElementResults === 'function') app.renderElementResults();
        }
      })
      .catch(function () { pageCache[query] = []; pageFetching[query] = false; });
  }

  function getMatches(app) {
    var query = app && app.input ? String(app.input.value || '').trim() : '';
    var ql = query.toLowerCase();
    var scope = (app && app.everythingScope) || 'all';

    if (!query) {
      // Browse state — commands only (original vibe). Clearing the box snaps scope back to All.
      if (app) app.everythingScope = 'all';
      return COMMANDS.map(function (c) { return Object.assign({ _html: esc(c.title), q: '' }, c); });
    }

    var pool = [];
    if (scope === 'all' || scope === 'command') pool = pool.concat(COMMANDS);
    if (scope === 'all' || scope === 'page') {
      if (pageCache[ql]) pool = pool.concat(pageCache[ql]);
      else fetchPages(app, ql);
    }

    var scored = [];
    pool.forEach(function (item) {
      var m = fuzzy(item.title, query);
      if (m) scored.push(Object.assign({}, item, { _html: m.html, _score: m.score, q: query }));
    });
    scored.sort(function (a, b) { return b._score - a._score || a.title.length - b.title.length; });
    return scored.slice(0, 8);
  }

  function scopeBarHtml(app) {
    var active = (app && app.everythingScope) || 'all';
    return '<div class="baqa-ev-scopes">' + SCOPES.map(function (s) {
      return '<button type="button" class="baqa-ev-scope' + (s.key === active ? ' is-on' : '') + '" data-ev-scope="' + s.key + '">' + esc(s.label) + '</button>';
    }).join('') + '</div>';
  }

  function catTag(cat) {
    var c = CAT[cat] || { label: cat, color: '#8a8a8a' };
    return '<span class="baqa-ev-cat"><span class="baqa-ev-lbl">' + esc(c.label) + '</span><span class="baqa-ev-dot" style="background:' + c.color + '"></span></span>';
  }

  function rowHtml(item, index, active) {
    var ic = '<span class="baqa-ev-ic"><i class="ph-duotone ph-' + (item.icon || 'file-text') + '"></i></span>';
    var right = item.type === 'action' && !item.q
      ? '<em class="baqa-ev-meta">' + esc(item.meta || '') + '</em>'
      : catTag(item.cat);
    return '<button type="button" class="baqa-ev-row' + (index === active ? ' is-active' : '') + '" data-ev-index="' + index + '">' +
      ic + '<span class="baqa-ev-title">' + item._html + '</span>' + right + '</button>';
  }

  function openTargetHtml(app) {
    var newTab = !!(app && app.everythingNewTab);
    return '<div class="baqa-ev-foot">' +
      '<span class="baqa-ev-hint"><kbd>⇥</kbd> scope</span>' +
      '<span class="baqa-ev-hint"><kbd>↑↓</kbd> results</span>' +
      '<button type="button" class="baqa-ev-toggle" data-ev-toggle="1"><kbd>↵</kbd> opens in <b>' + (newTab ? 'new tab' : 'current tab') + '</b> ⇄</button>' +
      '<span class="baqa-ev-hint"><kbd>⌘/Ctrl ↵</kbd> opens in <b>' + (newTab ? 'current tab' : 'new tab') + '</b></span>' +
      '</div>';
  }

  function render(container, items, callbacks) {
    if (!container) return;
    callbacks = callbacks || {};
    var app = callbacks.app || null;
    var query = app && app.input ? String(app.input.value || '').trim() : '';
    var active = Math.max(0, Math.min((items || []).length - 1, Number(callbacks.activeIndex) || 0));

    if (!items || !items.length) {
      container.innerHTML = (query ? scopeBarHtml(app) : '') +
        '<div class="baqa-ev-empty">' + (query ? 'No matches for “' + esc(query) + '”. Press ⇥ to widen the scope.' : 'Type to search pages and commands…') + '</div>';
      wire(container, items, callbacks);
      return;
    }

    var body;
    if (!query) {
      body = '<div class="baqa-ev-group">Commands</div>' + items.map(function (it, i) { return rowHtml(it, i, active); }).join('');
      container.innerHTML = '<div class="baqa-ev">' + body + '</div>';
    } else {
      body = items.map(function (it, i) { return rowHtml(it, i, active); }).join('');
      container.innerHTML = '<div class="baqa-ev">' + scopeBarHtml(app) + '<div class="baqa-ev-list">' + body + '</div>' + openTargetHtml(app) + '</div>';
    }
    wire(container, items, callbacks);
    var activeEl = container.querySelector('.baqa-ev-row.is-active');
    if (activeEl && activeEl.scrollIntoView) activeEl.scrollIntoView({ block: 'nearest' });
  }

  function wire(container, items, callbacks) {
    callbacks = callbacks || {};
    var app = callbacks.app;
    container.querySelectorAll('.baqa-ev-row').forEach(function (row) {
      var i = Number(row.getAttribute('data-ev-index'));
      row.addEventListener('mouseenter', function () { if (callbacks.activate) callbacks.activate(i); });
      row.addEventListener('click', function () { if (callbacks.execute) callbacks.execute(items[i]); });
    });
    container.querySelectorAll('.baqa-ev-scope').forEach(function (btn) {
      btn.addEventListener('click', function () {
        if (app) { app.everythingScope = btn.getAttribute('data-ev-scope'); app.activeElementResultIndex = 0; if (app.renderElementResults) app.renderElementResults(); if (app.input) app.input.focus(); }
      });
    });
    var toggle = container.querySelector('.baqa-ev-toggle');
    if (toggle) toggle.addEventListener('click', function () {
      if (app) { app.everythingNewTab = !app.everythingNewTab; if (app.renderElementResults) app.renderElementResults(); if (app.input) app.input.focus(); }
    });
  }

  function cycleScope(app, dir) {
    if (!app) return;
    var cur = app.everythingScope || 'all';
    var idx = 0;
    for (var i = 0; i < SCOPES.length; i++) { if (SCOPES[i].key === cur) { idx = i; break; } }
    idx = (idx + (dir < 0 ? SCOPES.length - 1 : 1)) % SCOPES.length;
    app.everythingScope = SCOPES[idx].key;
    app.activeElementResultIndex = 0;
    if (app.renderElementResults) app.renderElementResults();
  }

  function openUrl(url, newTab) {
    if (!url) return;
    try { window.open(url, newTab ? '_blank' : '_self'); } catch (e) { window.location.href = url; }
  }

  function execute(app, item, opts) {
    if (!app || !item) return;
    opts = opts || {};
    if (item.type === 'page') {
      var newTab = opts.forceOther ? !app.everythingNewTab : !!app.everythingNewTab;
      // Phase A default page action: open in the Bricks builder. (3-way Edit-in-Bricks /
      // Edit-in-WP / View sub-actions land in Phase A2.)
      var url = item.url || '';
      if (url) url += (url.indexOf('?') > -1 ? '&' : '?') + 'bricks=run';
      openUrl(url, newTab);
      return;
    }
    if (item.mode === 'default') return app.enterDefaultMode();
    if (item.mode === 'elements') return app.enterElementMode();
    if (item.mode === 'add-elements') return app.enterAddElementMode();
    if (item.action === 'settings') return app.toggleSettingsPanel();
    if (item.action === 'help') return app.toggleHelpPanel();
  }

  window.MimamsBarEverythingManager = {
    getMatches: getMatches,
    execute: execute,
    render: render,
    cycleScope: cycleScope,
    SCOPES: SCOPES
  };
})();
