'use strict';

const fs = require('fs');
const path = require('path');

const root = path.resolve(__dirname, '..');
const panel = fs.readFileSync(path.join(root, 'assets/js/builder-panel.js'), 'utf8');
const routes = fs.readFileSync(path.join(root, 'api/Routes.php'), 'utf8');
const assert = (condition, message) => {
  if (!condition) {
    console.error('FAIL:', message);
    process.exitCode = 1;
  }
};

assert(!panel.includes("title: 'Click ⧉ in the side panel to bring it back here'"), 'The docked placeholder must not leave a native tooltip behind.');
assert(panel.includes("--ve-code-popout-left', popLeft + 'px"), 'The rail should follow the measured pop-out edge.');
assert(panel.includes('.ve-code-popout .cpb{width:100%;flex:1 1 0;min-height:0'), 'The pop-out editor body should own bounded remaining height.');
assert(panel.includes('.ve-code-popout .cpf{position:relative;z-index:2;min-height:38px'), 'The pop-out save-state footer should remain visible.');
assert(panel.includes("class: 've-media-video-detail-card'"), 'Attachment Details should render video in a dedicated wrapper.');
assert(panel.includes('.ve-media-video-detail-card .ve-video-player-controls'), 'Video detail controls should have their own row below the media.');
assert(panel.includes('.ve-content-focus-keywords .ve-seo-keywords{display:grid!important'), 'Focus keywords should use one clean row per keyword.');
assert(panel.includes('const seoScoreForDisplay = post =>'), 'SEO score display should select the authoritative score source.');
assert(panel.includes("Rank Math score loaded from WordPress"), 'The SEO panel should explain the Rank Math-owned score.');
assert(panel.includes("const savedResponse=res;"), 'The client must preserve the API returned score after save.');
assert(routes.includes('private function studio_rank_math_active(): bool'), 'Rank Math availability should be centralized.');
assert(routes.includes("'score_source'         => $rank_math_active ? 'rank_math' : 'content_studio'"), 'The score source should be explicit in the REST response.');
assert(!routes.includes("update_post_meta( $post_id, 'rank_math_seo_score', $score )"), 'Content Studio must never overwrite Rank Math score meta.');

if (!process.exitCode) console.log('v1.3.401 layout, video detail, keyword, and Rank Math authority contracts passed.');
