<?php

namespace VE\API;

defined( 'ABSPATH' ) || exit;

class Routes {

    public function register(): void {
        add_action( 'rest_api_init', [ $this, 'register_routes' ] );
    }

    public function register_routes(): void {
        $ns         = VE_API_NAMESPACE;
        $controller = new VariableController();

        // ── Variables CRUD ──────────────────────────────────────────
        register_rest_route( $ns, '/variables', [
            [
                'methods'             => 'GET',
                'callback'            => [ $controller, 'list_variables' ],
                'permission_callback' => [ $this, 'can_read' ],
                'args'                => [
                    'namespace' => [ 'type' => 'string', 'sanitize_callback' => 'sanitize_text_field' ],
                    'type'      => [ 'type' => 'string', 'enum' => [ 'base', 'generated', 'alias' ] ],
                    'dedupe'    => [ 'type' => 'boolean', 'default' => false ],
                ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $controller, 'create_variable' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );


        register_rest_route( $ns, '/variables/stats', [
            'methods'             => 'GET',
            'callback'            => [ $controller, 'stats_variables' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/variables/cleanup', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'cleanup_variables' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/variables/(?P<id>\d+)', [
            [
                'methods'             => 'GET',
                'callback'            => [ $controller, 'get_variable' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'PUT',
                'callback'            => [ $controller, 'update_variable' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $controller, 'delete_variable' ],
                'permission_callback' => [ $this, 'can_write' ],
                'args'                => [
                    'force' => [ 'type' => 'boolean', 'default' => false ],
                ],
            ],
        ] );

        register_rest_route( $ns, '/variables/(?P<id>\d+)/rename-preview', [
            'methods'             => 'POST',
            'callback'            => [ $controller, 'rename_preview' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Generators ────────────────────────────────────────────────
        $gen_controller = new GeneratorController();

        register_rest_route( $ns, '/variables/(?P<variable_id>\d+)/generators', [
            [
                'methods'             => 'GET',
                'callback'            => [ $gen_controller, 'list_generators' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $gen_controller, 'attach' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/variables/(?P<variable_id>\d+)/generators/regenerate', [
            'methods'             => 'POST',
            'callback'            => [ $gen_controller, 'regenerate' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/generators/(?P<generator_id>\d+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $gen_controller, 'detach' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Search ──────────────────────────────────────────────────
        register_rest_route( $ns, '/search', [
            'methods'             => 'GET',
            'callback'            => [ $controller, 'search_variables' ],
            'permission_callback' => [ $this, 'can_read' ],
            'args'                => [
                'q'     => [ 'type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_text_field' ],
                'limit' => [ 'type' => 'integer', 'default' => 50 ],
            ],
        ] );

        // ── Settings ────────────────────────────────────────────────
        register_rest_route( $ns, '/settings', [
            [
                'methods'             => 'GET',
                'callback'            => function () {
                    $defaults = [
                        'vw_min'              => 320,
                        'vw_max'              => 1440,
                        'delete_on_uninstall' => false,
                        'update_url'          => \VE\Core\Updater::DEFAULT_FEED_URL,
                        'update_channel'      => 'stable',
                        'auto_update'         => false,
                        'license_server_url'  => '',
                        'deactivated_tools'   => [],
                    ];
                    $settings = get_option( 've_settings', $defaults );
                    $out = wp_parse_args( $settings, $defaults );
                    $out['site_title'] = get_bloginfo( 'name' );
                    $out['license'] = ( new \VE\Core\LicenseManager() )->status();
                    return new \WP_REST_Response( $out, 200 );
                },
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => function ( \WP_REST_Request $request ) {
                    $data = $request->get_json_params();
                    $defaults = [
                        'vw_min'              => 320,
                        'vw_max'              => 1440,
                        'delete_on_uninstall' => false,
                        'update_url'          => \VE\Core\Updater::DEFAULT_FEED_URL,
                        'update_channel'      => 'stable',
                        'auto_update'         => false,
                        'license_server_url'  => '',
                        'deactivated_tools'   => [],
                    ];
                    $previous = get_option( 've_settings', $defaults );
                    $update_channel = sanitize_key( (string) ( $data['update_channel'] ?? ( $previous['update_channel'] ?? 'stable' ) ) );
                    if ( ! in_array( $update_channel, [ 'stable', 'beta', 'dev' ], true ) ) {
                        $update_channel = 'stable';
                    }
                    $update_url = isset( $data['update_url'] ) ? esc_url_raw( (string) $data['update_url'] ) : $defaults['update_url'];
                    if ( '' === $update_url || \VE\Core\Updater::LEGACY_FEED_URL === $update_url || \VE\Core\Updater::DEFAULT_FEED_URL === $update_url ) {
                        $update_url = \VE\Core\Updater::feed_url_for_channel( $update_channel );
                    }
                    $license_server_url = isset( $data['license_server_url'] ) ? esc_url_raw( (string) $data['license_server_url'] ) : '';
                    $deactivated_tools = isset( $data['deactivated_tools'] ) && is_array( $data['deactivated_tools'] )
                        ? array_map( 'sanitize_key', $data['deactivated_tools'] )
                        : [];
                    $settings = [
                        'vw_min'              => isset( $data['vw_min'] ) ? absint( $data['vw_min'] ) : 320,
                        'vw_max'              => isset( $data['vw_max'] ) ? absint( $data['vw_max'] ) : 1440,
                        'delete_on_uninstall' => ! empty( $data['delete_on_uninstall'] ),
                        'update_url'          => $update_url,
                        'update_channel'      => $update_channel,
                        'auto_update'         => ! empty( $data['auto_update'] ),
                        'license_server_url'  => $license_server_url,
                        'deactivated_tools'   => $deactivated_tools,
                    ];
                    update_option( 've_settings', $settings );
                    update_option( 've_delete_on_uninstall', $settings['delete_on_uninstall'] );

                    // If the fluid viewport range changed, every fluid variable's
                    // clamp() output is now stale — recompile them.
                    $vw_changed = ( (int) ( $previous['vw_min'] ?? 320 ) !== $settings['vw_min'] )
                               || ( (int) ( $previous['vw_max'] ?? 1440 ) !== $settings['vw_max'] );
                    $recompiled = 0;
                    if ( $vw_changed ) {
                        $recompiled = ( new \VE\Core\VariableManager() )->recompile_fluid();
                    }

                    $response = $settings;
                    $response['fluid_recompiled'] = $recompiled;
                    $response['license'] = ( new \VE\Core\LicenseManager() )->status();
                    return new \WP_REST_Response( $response, 200 );
                },
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/license/status', [
            'methods'             => 'GET',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->status(), 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/license/activate', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                $data = $request->get_json_params();
                $key  = isset( $data['license_key'] ) ? (string) $data['license_key'] : '';
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->activate( $key ), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/license/check', [
            'methods'             => 'POST',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->check(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/license/deactivate', [
            'methods'             => 'POST',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\LicenseManager() )->deactivate(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/update/check', [
            'methods'             => 'POST',
            'callback'            => function () {
                $updater = new \VE\Core\Updater();
                return new \WP_REST_Response( $updater->check_now(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/advanced-css', [
            [
                'methods'             => 'GET',
                'callback'            => function () {
                    return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->get(), 200 );
                },
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => function ( \WP_REST_Request $request ) {
                    $data = $request->get_json_params();
                    $sheets = is_array( $data ) && isset( $data['stylesheets'] ) && is_array( $data['stylesheets'] )
                        ? $data['stylesheets']
                        : [];
                    return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->save( $sheets ), 200 );
                },
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/advanced-css/compile', [
            'methods'             => 'POST',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->compile(), 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/advanced-css/suggestions', [
            'methods'             => 'GET',
            'callback'            => function ( \WP_REST_Request $request ) {
                $refresh = rest_sanitize_boolean( $request->get_param( 'refresh' ) );
                return new \WP_REST_Response( ( new \VE\Core\AdvancedCssManager() )->suggestions( $refresh ), 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/migration/sources', [
            'methods'             => 'GET',
            'callback'            => function () {
                return new \WP_REST_Response( ( new \VE\Core\MigrationScanner() )->sources(), 200 );
            },
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/migration/preview', [
            'methods'             => 'POST',
            'callback'            => function ( \WP_REST_Request $request ) {
                $data = $request->get_json_params();
                $source = sanitize_key( (string) ( $data['source'] ?? 'all' ) );
                $scanner = new \VE\Core\MigrationScanner();
                $vars = $scanner->scan( $source ?: 'all' );
                $sync = new \VE\Sync\SyncEngine();
                $preview = $sync->preview_import( $vars );
                $preview['variables'] = $vars;
                $preview['variable_count'] = count( $vars );
                return new \WP_REST_Response( $preview, 200 );
            },
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Sync ──────────────────────────────────────────────────────
        $sync = new SyncController();

        register_rest_route( $ns, '/sync/export', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'export' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
            'args'                => [
                'format' => [ 'type' => 'string', 'default' => 'dtcg', 'enum' => [ 'dtcg', 'flat', 'figma' ] ],
            ],
        ] );

        register_rest_route( $ns, '/sync/export-css', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'export_css' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/preview', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'preview' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/apply', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'apply' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/snapshots', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'list_snapshots' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/sync/snapshot', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'create_snapshot' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/rollback/(?P<snapshot_id>\d+)', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'rollback' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/logs', [
            [
                'methods'             => 'GET',
                'callback'            => [ $sync, 'list_logs' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $sync, 'write_log' ],
                'permission_callback' => [ SyncController::class, 'can_sync' ],
            ],
        ] );

        register_rest_route( $ns, '/diagnostics/logs', [
            [
                'methods'             => 'GET',
                'callback'            => [ $sync, 'diagnostics' ],
                'permission_callback' => [ $this, 'can_read' ],
                'args'                => [
                    'lines' => [ 'type' => 'integer', 'default' => 200 ],
                ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $sync, 'clear_diagnostics' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        // ── Pairing ─────────────────────────────────────────────────
        register_rest_route( $ns, '/sync/pair/generate', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'generate_pair' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/pair/validate', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'validate_pair' ],
            'permission_callback' => '__return_true', // Open — code is the auth
        ] );

        register_rest_route( $ns, '/sync/pair/register', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'register_figma_pair' ],
            'permission_callback' => '__return_true', // Open — Figma sends its code
        ] );

        register_rest_route( $ns, '/sync/pair/complete-figma', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'complete_figma_pair' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/sync/pair/status', [
            'methods'             => 'GET',
            'callback'            => [ $sync, 'pair_status' ],
            'permission_callback' => [ SyncController::class, 'can_sync' ],
        ] );

        register_rest_route( $ns, '/sync/pair/disconnect', [
            'methods'             => 'POST',
            'callback'            => [ $sync, 'disconnect' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        // ── Content Studio ─────────────────────────────────────────
        register_rest_route( $ns, '/content-studio/meta', [
            'methods'             => 'GET',
            'callback'            => [ $this, 'get_content_studio_meta' ],
            'permission_callback' => [ $this, 'can_read' ],
        ] );

        register_rest_route( $ns, '/content-studio/posts', [
            [
                'methods'             => 'GET',
                'callback'            => [ $this, 'list_studio_posts' ],
                'permission_callback' => [ $this, 'can_read' ],
            ],
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'create_studio_post' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/content-studio/posts/(?P<id>\d+)', [
            [
                'methods'             => 'POST',
                'callback'            => [ $this, 'update_studio_post' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
            [
                'methods'             => 'DELETE',
                'callback'            => [ $this, 'delete_studio_post' ],
                'permission_callback' => [ $this, 'can_write' ],
            ],
        ] );

        register_rest_route( $ns, '/content-studio/cpts', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_or_update_studio_cpt' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/cpts/(?P<name>[a-zA-Z0-9_\-]+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_studio_cpt' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/fields', [
            'methods'             => 'POST',
            'callback'            => [ $this, 'create_or_update_studio_fields' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );

        register_rest_route( $ns, '/content-studio/fields/(?P<id>[a-zA-Z0-9_\-]+)', [
            'methods'             => 'DELETE',
            'callback'            => [ $this, 'delete_studio_fields' ],
            'permission_callback' => [ $this, 'can_write' ],
        ] );
    }

    /* ── Permission callbacks ─────────────────────────────────────── */

    public function can_read( ?\WP_REST_Request $request = null ): bool {
        // Allow the paired Figma plugin to read VE data with X-VE-Key.
        if ( $request && SyncController::can_sync( $request ) ) {
            return true;
        }

        return current_user_can( 'edit_posts' );
    }

    public function can_write( ?\WP_REST_Request $request = null ): bool {
        // Allow the paired Figma plugin to create/update/delete VE data with X-VE-Key.
        if ( $request && SyncController::can_sync( $request ) ) {
            return true;
        }

        return current_user_can( 'manage_options' );
    }

    public function get_content_studio_meta(): \WP_REST_Response {
        $cpts = [];
        $field_groups = [];

        $post_types = get_post_types( [], 'objects' );
        $exclude = [
            'attachment', 'revision', 'nav_menu_item', 'custom_css', 'customize_changeset',
            'oembed_cache', 'user_request', 'wp_block', 'wp_template', 'wp_template_part',
            'acf-field-group', 'acf-field', 'wp_navigation', 'wp_global_styles', 'wp_font_family',
            'wp_font_face', 'action_scheduler', 'bricks_template'
        ];

        $acf_cpts = [];
        if ( function_exists( 'acf_get_post_types' ) ) {
            $acf_cpts = acf_get_post_types();
        }
        $jet_cpts = get_option( 'jet_engine_cpt', [] );
        if ( ! is_array( $jet_cpts ) ) {
            $jet_cpts = [];
        }

        foreach ( $post_types as $pt ) {
            if ( in_array( $pt->name, $exclude, true ) ) {
                continue;
            }

            $source = 'wp';
            foreach ( $acf_cpts as $ac ) {
                if ( ( $ac['post_type'] ?? '' ) === $pt->name ) {
                    $source = 'acf';
                    break;
                }
            }
            if ( $source === 'wp' ) {
                foreach ( $jet_cpts as $jc ) {
                    if ( ( $jc['slug'] ?? '' ) === $pt->name ) {
                        $source = 'jet';
                        break;
                    }
                }
            }

            $counts = wp_count_posts( $pt->name );
            $total_count = (int) ( $counts->publish ?? 0 ) + (int) ( $counts->draft ?? 0 ) + (int) ( $counts->pending ?? 0 ) + (int) ( $counts->private ?? 0 );

            $cpts[] = [
                'name'         => $pt->name,
                'label'        => $pt->label ?: $pt->name,
                'singular'     => $pt->labels->singular_name ?: $pt->name,
                'show_in_rest' => ! empty( $pt->show_in_rest ),
                'rest_base'    => $pt->rest_base ?: $pt->name,
                'count'        => $total_count,
                'source'       => $source,
                'is_builtin'   => ! empty( $pt->_builtin ),
            ];
        }

        if ( function_exists( 'acf_get_field_groups' ) ) {
            $acf_groups = acf_get_field_groups();
            foreach ( $acf_groups as $group ) {
                $fields = [];
                $raw_fields = acf_get_fields( $group['ID'] ) ?: acf_get_fields( $group['key'] ) ?: [];
                foreach ( $raw_fields as $f ) {
                    $fields[] = [
                        'name'  => $f['name'] ?? '',
                        'label' => $f['label'] ?? ($f['name'] ?? ''),
                        'type'  => $f['type'] ?? 'text',
                    ];
                }

                $post_types_rules = [];
                if ( isset( $group['location'] ) && is_array( $group['location'] ) ) {
                    foreach ( $group['location'] as $rule_group ) {
                        foreach ( $rule_group as $rule ) {
                            if ( ( $rule['param'] ?? '' ) === 'post_type' && ( $rule['operator'] ?? '' ) === '==' ) {
                                $post_types_rules[] = $rule['value'];
                            }
                        }
                    }
                }

                $field_groups[] = [
                    'id'         => 'acf-' . $group['ID'],
                    'key'        => $group['key'],
                    'title'      => $group['title'] ?? 'ACF Field Group',
                    'fields'     => $fields,
                    'post_types' => array_values( array_unique( $post_types_rules ) ),
                    'source'     => 'acf',
                ];
            }
        }

        $jet_groups = [];
        if ( function_exists( 'jet_engine' ) && isset( jet_engine()->meta_boxes ) ) {
            $boxes = [];
            if ( method_exists( jet_engine()->meta_boxes, 'get_meta_boxes' ) ) {
                $boxes = jet_engine()->meta_boxes->get_meta_boxes();
            } elseif ( isset( jet_engine()->meta_boxes->data ) && method_exists( jet_engine()->meta_boxes->data, 'get_items' ) ) {
                $boxes = jet_engine()->meta_boxes->data->get_items();
            }
            foreach ( (array) $boxes as $box ) {
                $box_id = '';
                $box_title = '';
                $args = [];
                if ( is_object( $box ) ) {
                    $box_id = $box->id ?? '';
                    $box_title = $box->name ?? ($box->title ?? '');
                    $args = (array) ($box->args ?? []);
                } elseif ( is_array( $box ) ) {
                    $box_id = $box['id'] ?? '';
                    $box_title = $box['name'] ?? ($box['title'] ?? '');
                    $args = $box['args'] ?? [];
                }
                $allowed_posts = $args['allowed_post_types'] ?? [];

                $fields = [];
                $raw_fields = [];
                if ( is_object( $box ) && method_exists( $box, 'get_meta_fields' ) ) {
                    $raw_fields = $box->get_meta_fields();
                } elseif ( is_array( $box ) && isset( $box['meta_fields'] ) ) {
                    $raw_fields = $box['meta_fields'];
                } elseif ( is_object( $box ) && isset( $box->meta_fields ) ) {
                    $raw_fields = $box->meta_fields;
                }

                foreach ( (array) $raw_fields as $f ) {
                    $f_name = '';
                    $f_title = '';
                    $f_type = 'text';
                    if ( is_object( $f ) ) {
                        $f_name = $f->name ?? '';
                        $f_title = $f->title ?? '';
                        $f_type = $f->type ?? 'text';
                    } elseif ( is_array( $f ) ) {
                        $f_name = $f['name'] ?? '';
                        $f_title = $f['title'] ?? '';
                        $f_type = $f['type'] ?? 'text';
                    }
                    if ( $f_name ) {
                        $fields[] = [
                            'name'  => $f_name,
                            'label' => $f_title ?: $f_name,
                            'type'  => $f_type,
                        ];
                    }
                }

                if ( $box_id && ! empty( $fields ) ) {
                    $jet_groups[ $box_id ] = [
                        'id'         => 'jet-' . $box_id,
                        'key'        => $box_id,
                        'title'      => $box_title ?: 'JetEngine Field Group',
                        'fields'     => $fields,
                        'post_types' => (array) $allowed_posts,
                        'source'     => 'jet',
                    ];
                }
            }
        }

        $jet_options = get_option( 'jet_engine_meta_boxes', [] );
        if ( is_array( $jet_options ) ) {
            foreach ( $jet_options as $box ) {
                $box_id = $box['id'] ?? '';
                if ( ! $box_id || isset( $jet_groups[ $box_id ] ) ) {
                    continue;
                }
                $box_title = $box['name'] ?? ($box['title'] ?? '');
                $args = $box['args'] ?? [];
                $allowed_posts = $args['allowed_post_types'] ?? [];
                $raw_fields = $box['meta_fields'] ?? [];
                $fields = [];
                foreach ( (array) $raw_fields as $f ) {
                    $f_name = $f['name'] ?? '';
                    if ( $f_name ) {
                        $fields[] = [
                            'name'  => $f_name,
                            'label' => $f['title'] ?? ($f['label'] ?? $f_name),
                            'type'  => $f['type'] ?? 'text',
                        ];
                    }
                }
                if ( ! empty( $fields ) ) {
                    $jet_groups[ $box_id ] = [
                        'id'         => 'jet-' . $box_id,
                        'key'        => $box_id,
                        'title'      => $box_title ?: 'JetEngine Field Group',
                        'fields'     => $fields,
                        'post_types' => (array) $allowed_posts,
                        'source'     => 'jet',
                    ];
                }
            }
        }

        $field_groups = array_merge( $field_groups, array_values( $jet_groups ) );

        return new \WP_REST_Response( [
            'cpts'         => $cpts,
            'field_groups' => $field_groups,
            'acf_active'   => function_exists( 'acf_get_field_groups' ),
            'jet_active'   => function_exists( 'jet_engine' ) || ! empty( $jet_options ),
        ], 200 );
    }

    public function list_studio_posts( \WP_REST_Request $request ): \WP_REST_Response {
        $post_type = sanitize_key( $request->get_param( 'post_type' ) ?: 'post' );
        $search = sanitize_text_field( $request->get_param( 'search' ) ?: '' );

        $args = [
            'post_type'      => $post_type,
            'posts_per_page' => 100,
            'post_status'    => [ 'publish', 'draft', 'pending', 'private' ],
            'orderby'        => 'modified',
            'order'          => 'DESC',
        ];

        if ( $search ) {
            $args['s'] = $search;
        }

        $query = new \WP_Query( $args );
        $posts = [];

        foreach ( $query->posts as $post ) {
            $posts[] = [
                'id'            => $post->ID,
                'title'         => [ 'rendered' => $post->post_title ],
                'slug'          => $post->post_name,
                'status'        => $post->post_status,
                'date'          => $post->post_date_gmt,
                'modified'      => $post->post_modified_gmt,
                'link'          => get_permalink( $post->ID ) ?: '#',
            ];
        }

        return new \WP_REST_Response( $posts, 200 );
    }

    public function create_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $post_type = sanitize_key( $params['post_type'] ?? 'post' );
        $title = sanitize_text_field( $params['title'] ?? '' );
        $status = sanitize_key( $params['status'] ?? 'draft' );

        if ( empty( $title ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_title', 'message' => 'Post title is required.' ], 400 );
        }

        $post_id = wp_insert_post([
            'post_type'   => $post_type,
            'post_title'  => $title,
            'post_status' => $status,
        ]);

        if ( is_wp_error( $post_id ) ) {
            return new \WP_REST_Response( [ 'code' => 'create_failed', 'message' => $post_id->get_error_message() ], 500 );
        }

        if ( ! $post_id ) {
            return new \WP_REST_Response( [ 'code' => 'create_failed', 'message' => 'Could not create post.' ], 500 );
        }

        $post = get_post( $post_id );
        return new \WP_REST_Response( [
            'id'            => $post->ID,
            'title'         => [ 'rendered' => $post->post_title ],
            'slug'          => $post->post_name,
            'status'        => $post->post_status,
            'date'          => $post->post_date_gmt,
            'modified'      => $post->post_modified_gmt,
            'link'          => get_permalink( $post->ID ) ?: '#',
        ], 200 );
    }

    public function update_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $id = absint( $request->get_param( 'id' ) );
        $params = $request->get_json_params() ?: [];
        $status = sanitize_key( $params['status'] ?? '' );

        if ( ! $id || ! get_post( $id ) ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'Post not found.' ], 404 );
        }

        if ( $status ) {
            wp_update_post([
                'ID'          => $id,
                'post_status' => $status,
            ]);
        }

        $post = get_post( $id );
        return new \WP_REST_Response( [
            'id'            => $post->ID,
            'title'         => [ 'rendered' => $post->post_title ],
            'slug'          => $post->post_name,
            'status'        => $post->post_status,
            'date'          => $post->post_date_gmt,
            'modified'      => $post->post_modified_gmt,
            'link'          => get_permalink( $post->ID ) ?: '#',
        ], 200 );
    }

    public function delete_studio_post( \WP_REST_Request $request ): \WP_REST_Response {
        $id = absint( $request->get_param( 'id' ) );
        $force = rest_sanitize_boolean( $request->get_param( 'force' ) );

        if ( ! $id || ! get_post( $id ) ) {
            return new \WP_REST_Response( [ 'code' => 'not_found', 'message' => 'Post not found.' ], 404 );
        }

        $res = wp_delete_post( $id, $force );
        if ( $res ) {
            return new \WP_REST_Response( [ 'id' => $id ], 200 );
        }

        return new \WP_REST_Response( [ 'code' => 'delete_failed', 'message' => 'Could not delete post.' ], 500 );
    }

    public function create_or_update_studio_cpt( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $name = sanitize_key( $params['name'] ?? '' );
        $singular = sanitize_text_field( $params['singular'] ?? '' );
        $plural = sanitize_text_field( $params['plural'] ?? '' );
        $source = sanitize_key( $params['source'] ?? 'acf' );

        if ( empty( $name ) || empty( $singular ) || empty( $plural ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_params', 'message' => 'Name, singular label, and plural label are required.' ], 400 );
        }

        if ( $source === 'jet' ) {
            $cpts = get_option( 'jet_engine_cpt', [] );
            if ( ! is_array( $cpts ) ) {
                $cpts = [];
            }
            $found = false;
            foreach ( $cpts as &$c ) {
                if ( ( $c['slug'] ?? '' ) === $name ) {
                    $c['labels']['name'] = $plural;
                    $c['labels']['singular_name'] = $singular;
                    $found = true;
                    break;
                }
            }
            if ( ! $found ) {
                $cpts[] = [
                    'slug'   => $name,
                    'labels' => [
                        'name'          => $plural,
                        'singular_name' => $singular,
                    ],
                    'args'   => [
                        'public'       => true,
                        'show_in_rest' => true,
                    ],
                ];
            }
            update_option( 'jet_engine_cpt', $cpts );
        } else {
            if ( function_exists( 'acf_update_post_type' ) ) {
                acf_update_post_type([
                    'post_type' => $name,
                    'title'     => $plural,
                    'labels'    => [
                        'name'          => $plural,
                        'singular_name' => $singular,
                    ],
                    'active'    => true,
                    'show_in_rest' => true,
                ]);
            } else {
                $cpts = get_option( 'jet_engine_cpt', [] );
                if ( ! is_array( $cpts ) ) {
                    $cpts = [];
                }
                $found = false;
                foreach ( $cpts as &$c ) {
                    if ( ( $c['slug'] ?? '' ) === $name ) {
                        $c['labels']['name'] = $plural;
                        $c['labels']['singular_name'] = $singular;
                        $found = true;
                        break;
                    }
                }
                if ( ! $found ) {
                    $cpts[] = [
                        'slug'   => $name,
                        'labels' => [
                            'name'          => $plural,
                            'singular_name' => $singular,
                        ],
                        'args'   => [
                            'public'       => true,
                            'show_in_rest' => true,
                        ],
                    ];
                }
                update_option( 'jet_engine_cpt', $cpts );
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function delete_studio_cpt( \WP_REST_Request $request ): \WP_REST_Response {
        $name = sanitize_key( $request->get_param( 'name' ) );

        $jet_cpts = get_option( 'jet_engine_cpt', [] );
        if ( is_array( $jet_cpts ) ) {
            $filtered = [];
            $found = false;
            foreach ( $jet_cpts as $c ) {
                if ( ( $c['slug'] ?? '' ) === $name ) {
                    $found = true;
                } else {
                    $filtered[] = $c;
                }
            }
            if ( $found ) {
                update_option( 'jet_engine_cpt', $filtered );
            }
        }

        if ( function_exists( 'acf_delete_post_type' ) ) {
            acf_delete_post_type( $name );
        } else {
            $acf_posts = get_posts([
                'post_type'   => 'acf-post-type',
                'name'        => $name,
                'post_status' => 'any',
                'numberposts' => 1,
            ]);
            if ( ! empty( $acf_posts ) ) {
                wp_delete_post( $acf_posts[0]->ID, true );
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function create_or_update_studio_fields( \WP_REST_Request $request ): \WP_REST_Response {
        $params = $request->get_json_params() ?: [];
        $title = sanitize_text_field( $params['title'] ?? '' );
        $post_types = is_array( $params['post_types'] ?? null ) ? array_map( 'sanitize_key', $params['post_types'] ) : [ 'post' ];
        $fields = is_array( $params['fields'] ?? null ) ? $params['fields'] : [];
        $source = sanitize_key( $params['source'] ?? 'acf' );

        if ( empty( $title ) ) {
            return new \WP_REST_Response( [ 'code' => 'missing_title', 'message' => 'Title is required.' ], 400 );
        }

        $sanitized_fields = [];
        foreach ( $fields as $f ) {
            $f_name = sanitize_key( $f['name'] ?? '' );
            if ( $f_name ) {
                $sanitized_fields[] = [
                    'name'  => $f_name,
                    'label' => sanitize_text_field( $f['label'] ?? $f_name ),
                    'type'  => sanitize_key( $f['type'] ?? 'text' ),
                ];
            }
        }

        if ( $source === 'jet' ) {
            $boxes = get_option( 'jet_engine_meta_boxes', [] );
            if ( ! is_array( $boxes ) ) {
                $boxes = [];
            }
            $key = sanitize_key( $title );
            $meta_fields = [];
            foreach ( $sanitized_fields as $f ) {
                $meta_fields[] = [
                    'name'  => $f['name'],
                    'title' => $f['label'],
                    'type'  => $f['type'],
                ];
            }
            $new_box = [
                'id'           => $key,
                'name'         => $title,
                'args'         => [
                    'allowed_post_types' => $post_types,
                ],
                'meta_fields'  => $meta_fields,
            ];
            $found = false;
            foreach ( $boxes as &$b ) {
                if ( ( $b['id'] ?? '' ) === $key ) {
                    $b = $new_box;
                    $found = true;
                    break;
                }
            }
            if ( ! $found ) {
                $boxes[] = $new_box;
            }
            update_option( 'jet_engine_meta_boxes', $boxes );
        } else {
            if ( function_exists( 'acf_update_field_group' ) ) {
                $key = 'group_cs_' . sanitize_key( $title );
                $field_group = [
                    'key'      => $key,
                    'title'    => $title,
                    'location' => [],
                    'active'   => true,
                ];
                foreach ( $post_types as $pt ) {
                    $field_group['location'][] = [
                        [
                            'param'    => 'post_type',
                            'operator' => '==',
                            'value'    => $pt,
                        ]
                    ];
                }
                $group = acf_update_field_group( $field_group );
                if ( $group && isset( $group['ID'] ) ) {
                    $existing = acf_get_fields( $group['ID'] ) ?: [];
                    foreach ( $existing as $ef ) {
                        acf_delete_field( $ef['ID'] );
                    }
                    foreach ( $sanitized_fields as $f ) {
                        $f_key = 'field_' . sanitize_key( $group['key'] . '_' . $f['name'] );
                        acf_update_field([
                            'key'          => $f_key,
                            'parent'       => $group['ID'],
                            'name'         => $f['name'],
                            'label'        => $f['label'],
                            'type'         => $f['type'],
                        ]);
                    }
                }
            } else {
                $boxes = get_option( 'jet_engine_meta_boxes', [] );
                if ( ! is_array( $boxes ) ) {
                    $boxes = [];
                }
                $key = sanitize_key( $title );
                $meta_fields = [];
                foreach ( $sanitized_fields as $f ) {
                    $meta_fields[] = [
                        'name'  => $f['name'],
                        'title' => $f['label'],
                        'type'  => $f['type'],
                    ];
                }
                $new_box = [
                    'id'           => $key,
                    'name'         => $title,
                    'args'         => [
                        'allowed_post_types' => $post_types,
                    ],
                    'meta_fields'  => $meta_fields,
                ];
                $found = false;
                foreach ( $boxes as &$b ) {
                    if ( ( $b['id'] ?? '' ) === $key ) {
                        $b = $new_box;
                        $found = true;
                        break;
                    }
                }
                if ( ! $found ) {
                    $boxes[] = $new_box;
                }
                update_option( 'jet_engine_meta_boxes', $boxes );
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }

    public function delete_studio_fields( \WP_REST_Request $request ): \WP_REST_Response {
        $id = sanitize_key( $request->get_param( 'id' ) );

        if ( 0 === strpos( $id, 'jet-' ) ) {
            $key = substr( $id, 4 );
            $boxes = get_option( 'jet_engine_meta_boxes', [] );
            if ( is_array( $boxes ) ) {
                $filtered = [];
                foreach ( $boxes as $b ) {
                    if ( ( $b['id'] ?? '' ) !== $key ) {
                        $filtered[] = $b;
                    }
                }
                update_option( 'jet_engine_meta_boxes', $filtered );
            }
        } elseif ( 0 === strpos( $id, 'acf-' ) ) {
            $acf_id = (int) substr( $id, 4 );
            if ( function_exists( 'acf_delete_field_group' ) ) {
                acf_delete_field_group( $acf_id );
            } else {
                wp_delete_post( $acf_id, true );
            }
        } else {
            $boxes = get_option( 'jet_engine_meta_boxes', [] );
            if ( is_array( $boxes ) ) {
                $filtered = [];
                $found = false;
                foreach ( $boxes as $b ) {
                    if ( ( $b['id'] ?? '' ) === $id ) {
                        $found = true;
                    } else {
                        $filtered[] = $b;
                    }
                }
                if ( $found ) {
                    update_option( 'jet_engine_meta_boxes', $filtered );
                }
            }

            if ( function_exists( 'acf_delete_field_group' ) ) {
                acf_delete_field_group( $id );
            } else {
                $acf_id = (int) $id;
                if ( $acf_id ) {
                    wp_delete_post( $acf_id, true );
                }
            }
        }

        return new \WP_REST_Response( [ 'success' => true ], 200 );
    }
}
