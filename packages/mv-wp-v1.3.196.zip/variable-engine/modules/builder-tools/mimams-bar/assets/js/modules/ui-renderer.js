(function () {
  'use strict';

  if (window.MimamsBarUIRenderer) return;

  function escapeCommandValue(value) {
    return String(value == null ? '' : value)
      .replace(/\\/g, '\\\\')
      .replace(/"/g, '\\"');
  }

  function attributeToSetCommand(attr) {
    if (!attr || !attr.name) return '';
    if (attr.value === '') return attr.name;
    return attr.name + '="' + escapeCommandValue(attr.value) + '"';
  }

  function attributeToRenameCommand(attr) {
    if (!attr || !attr.name) return '';
    return attr.name + ' -> ' + attr.name;
  }

  function loadTextCommand(input, command, selectStart, selectEnd, hideError) {
    if (!input) return;
    input.value = command || '';
    if (typeof hideError === 'function') hideError();
    if (window.MimamsBarHighlight && typeof window.MimamsBarHighlight.update === 'function') window.MimamsBarHighlight.update(input);
    input.focus();
    if (typeof selectStart === 'number' && typeof selectEnd === 'number') {
      input.setSelectionRange(selectStart, selectEnd);
    } else {
      input.setSelectionRange(input.value.length, input.value.length);
    }
  }

  function loadAttributeCommand(input, attr, mode, selectAll, hideError) {
    if (!input || !attr) return;

    var command = mode === 'rename'
      ? attributeToRenameCommand(attr)
      : attributeToSetCommand(attr);

    input.value = command;
    if (typeof hideError === 'function') hideError();
    if (window.MimamsBarHighlight && typeof window.MimamsBarHighlight.update === 'function') window.MimamsBarHighlight.update(input);
    input.focus();

    if (selectAll) {
      input.setSelectionRange(0, input.value.length);
      return;
    }

    if (mode === 'rename') {
      var arrowIndex = command.indexOf('->');
      var start = arrowIndex >= 0 ? arrowIndex + 3 : command.length;
      input.setSelectionRange(start, command.length);
      return;
    }

    if (attr.value !== '') {
      var closingQuote = command.length - 1;
      input.setSelectionRange(closingQuote, closingQuote);
      return;
    }

    input.setSelectionRange(command.length, command.length);
  }

  // Swap a value element for an inline text input, edited in place. On Enter/blur it
  // commits (onCommit re-renders the chips); Escape restores the original element.
  function beginInlineEdit(valueEl, initialText, onCommit) {
    if (!valueEl || !valueEl.parentNode) return;
    var input = document.createElement('input');
    input.type = 'text';
    input.className = 'baqa-chip-edit';
    input.value = initialText;
    input.setAttribute('spellcheck', 'false');
    valueEl.parentNode.replaceChild(input, valueEl);
    input.focus();
    input.select();
    var settled = false;
    function finish(commit) {
      if (settled) return;
      settled = true;
      var next = input.value.trim();
      if (commit && next && next !== initialText) {
        if (typeof onCommit === 'function') onCommit(next);
      } else if (input.parentNode) {
        input.parentNode.replaceChild(valueEl, input);
      }
    }
    input.addEventListener('keydown', function (event) {
      if (event.key === 'Enter') { event.preventDefault(); finish(true); }
      else if (event.key === 'Escape') { event.preventDefault(); finish(false); }
    });
    input.addEventListener('blur', function () { finish(true); });
    input.addEventListener('click', function (event) { event.stopPropagation(); });
  }

  function renderIdentity(container, element, adapter, callbacks) {
    if (!container || !adapter) return;
    callbacks = callbacks || {};
    container.textContent = '';

    if (!element) {
      var none = document.createElement('div');
      none.className = 'baqa-existing-empty';
      none.textContent = 'Select an element to view ID and classes.';
      container.appendChild(none);
      return;
    }

    var identity = adapter.getElementIdentity(element);

    var idRow = document.createElement('div');
    idRow.className = 'baqa-existing-row baqa-identity-row';

    var idClicker = document.createElement('button');
    idClicker.type = 'button';
    idClicker.className = 'baqa-existing-clicker';
    idClicker.setAttribute('title', 'Click to edit the CSS ID');

    var idName = document.createElement('code');
    idName.className = 'baqa-existing-name';
    idName.textContent = 'CSS ID';

    var idValue = document.createElement('span');
    idValue.className = 'baqa-existing-value';
    idValue.textContent = identity.id ? '#' + identity.id : 'none';
    idValue.classList.toggle('is-empty-value', !identity.id);

    idClicker.appendChild(idName);
    idClicker.appendChild(idValue);
    idRow.appendChild(idClicker);
    idClicker.addEventListener('click', function (event) {
      event.preventDefault();
      beginInlineEdit(idValue, identity.id || '', function (newId) {
        newId = String(newId).replace(/^#+/, '').trim();
        if (typeof callbacks.setId === 'function') callbacks.setId(newId);
      });
    });
    container.appendChild(idRow);

    if (!identity.classes.length) {
      var noClasses = document.createElement('div');
      noClasses.className = 'baqa-existing-empty';
      noClasses.textContent = 'No manual/global classes detected.';
      container.appendChild(noClasses);
      return;
    }

    identity.classes.forEach(function (className) {
      var row = document.createElement('div');
      row.className = 'baqa-existing-row baqa-identity-row';

      var clicker = document.createElement('button');
      clicker.type = 'button';
      clicker.className = 'baqa-existing-clicker';
      clicker.setAttribute('title', 'Click to load class. Shift+click to rename class on this element.');

      var name = document.createElement('code');
      name.className = 'baqa-existing-name';
      name.textContent = 'class';

      var value = document.createElement('span');
      value.className = 'baqa-existing-value';
      value.textContent = '.' + className;

      clicker.appendChild(name);
      clicker.appendChild(value);
      row.appendChild(clicker);

      clicker.addEventListener('click', function (event) {
        event.preventDefault();
        beginInlineEdit(value, className, function (newName) {
          newName = String(newName).replace(/^\.+/, '').trim();
          if (newName && typeof callbacks.renameClass === 'function') callbacks.renameClass(className, newName);
        });
      });

      var del = document.createElement('button');
      del.type = 'button';
      del.className = 'baqa-existing-delete';
      del.setAttribute('title', 'Remove class from this element');
      del.textContent = '×';
      del.addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();
        if (typeof callbacks.deleteClass === 'function') callbacks.deleteClass(className);
      });
      row.appendChild(del);

      container.appendChild(row);
    });
  }

  function renderExistingAttributes(options) {
    options = options || {};
    var list = options.list;
    var adapter = options.adapter;
    var element = options.element;
    var callbacks = options.callbacks || {};

    if (!list || !adapter) return { count: 0, collapse: true };

    var attrs = adapter.getElementAttributes(element);
    list.textContent = '';

    if (!attrs.length) {
      var empty = document.createElement('div');
      empty.className = 'baqa-existing-empty';
      empty.textContent = element ? 'No custom attributes on this element yet.' : 'Select an element to view its attributes.';
      list.appendChild(empty);
      return { count: 0, collapse: true };
    }

    attrs.forEach(function (attr) {
      var row = document.createElement('div');
      row.className = 'baqa-existing-row';

      var clicker = document.createElement('button');
      clicker.type = 'button';
      clicker.className = 'baqa-existing-clicker';
      clicker.setAttribute('title', 'Click to edit value. Shift+click to rename.');

      var name = document.createElement('code');
      name.className = 'baqa-existing-name';
      name.textContent = attr.name;

      var value = document.createElement('span');
      value.className = 'baqa-existing-value';
      value.textContent = attr.value === '' ? 'boolean / empty' : attr.value;
      value.classList.toggle('is-empty-value', attr.value === '');

      clicker.appendChild(name);
      clicker.appendChild(value);
      row.appendChild(clicker);

      var deleteBtn = document.createElement('button');
      deleteBtn.type = 'button';
      deleteBtn.className = 'baqa-existing-delete';
      deleteBtn.setAttribute('title', 'Delete attribute');
      
      var trashSvg = '<svg viewBox="0 0 256 256" width="13" height="13"><path fill="currentColor" d="M216,48H180V40a24,24,0,0,0-24-24H100A24,24,0,0,0,76,40v8H40a8,8,0,0,0,0,16h8V208a16,16,0,0,0,16,16H192a16,16,0,0,0,16-16V64h8a8,8,0,0,0,0-16ZM92,40a8,8,0,0,1,8-8h56a8,8,0,0,1,8,8v8H92Zm100,168H64V64H192ZM112,104v64a8,8,0,0,1-16,0V104a8,8,0,0,1,16,0Zm48,0v64a8,8,0,0,1-16,0V104a8,8,0,0,1,16,0Z"/></svg>';
      var checkSvg = '<svg viewBox="0 0 256 256" width="13" height="13" style="color: #ff4d4d;"><path fill="currentColor" d="M128,24A104,104,0,1,0,232,128,104.11,104.11,0,0,0,128,24Zm0,192a88,88,0,1,1,88-88A88.1,88.1,0,0,1,128,216ZM173.66,98.34a8,8,0,0,1,0,11.32l-56,56a8,8,0,0,1-11.32,0l-24-24a8,8,0,0,1,11.32-11.32L112,148.69l50.34-50.35A8,8,0,0,1,173.66,98.34Z"/></svg>';
      
      deleteBtn.innerHTML = trashSvg;
      row.appendChild(deleteBtn);

      var deleteTimer = null;
      var deleteState = 'idle';

      function resetDeleteState() {
        deleteState = 'idle';
        deleteBtn.classList.remove('is-confirm');
        deleteBtn.setAttribute('title', 'Delete attribute');
        deleteBtn.innerHTML = trashSvg;
        if (deleteTimer) {
          clearTimeout(deleteTimer);
          deleteTimer = null;
        }
      }

      deleteBtn.addEventListener('click', function (event) {
        event.preventDefault();
        event.stopPropagation();

        if (deleteState === 'idle') {
          deleteState = 'confirm';
          deleteBtn.classList.add('is-confirm');
          deleteBtn.setAttribute('title', 'Click again to confirm delete');
          deleteBtn.innerHTML = checkSvg;
          deleteTimer = setTimeout(function () {
            resetDeleteState();
          }, 5000);
        } else {
          resetDeleteState();
          if (typeof callbacks.deleteAttribute === 'function') {
            callbacks.deleteAttribute(attr);
          }
        }
      });

      clicker.addEventListener('click', function (event) {
        event.preventDefault();
        if (event.shiftKey) {
          if (typeof callbacks.loadAttributeCommand === 'function') callbacks.loadAttributeCommand(attr, 'rename', false);
          return;
        }
        beginInlineEdit(value, attr.value === '' ? '' : attr.value, function (newValue) {
          if (typeof callbacks.editAttribute === 'function') callbacks.editAttribute(attr, newValue);
        });
      });

      list.appendChild(row);
    });

    return { count: attrs.length, collapse: false };
  }

  window.MimamsBarUIRenderer = {
    escapeCommandValue: escapeCommandValue,
    attributeToSetCommand: attributeToSetCommand,
    attributeToRenameCommand: attributeToRenameCommand,
    loadTextCommand: loadTextCommand,
    loadAttributeCommand: loadAttributeCommand,
    renderIdentity: renderIdentity,
    renderExistingAttributes: renderExistingAttributes
  };
})();
