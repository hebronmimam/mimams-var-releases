<?php

namespace VE\Core;

defined( 'ABSPATH' ) || exit;

class Logger {
    private const MAX_BYTES = 1048576;

    private static bool $registered = false;

    /**
     * Should this level actually touch the disk?
     *
     * Every request used to append a JSON line here — `Logger::info('plugins_loaded')`
     * fires on plugins_loaded, so a public page view cost an is_dir(), a filesize()
     * and a LOCK_EX file_put_contents before WordPress had rendered anything. On a
     * busy site that is a measurable slowdown and it is the main reason deactivating
     * MV made the site feel faster.
     *
     * Errors and fatals still always log — those are rare and worth the write.
     * Informational events only log when debugging is deliberately switched on, via
     * `define( 'VE_DEBUG_LOG', true )` in wp-config.php or WP_DEBUG.
     */
    private static function should_log( string $level ): bool {
        if ( 'info' !== $level ) {
            return true;
        }
        if ( defined( 'VE_DEBUG_LOG' ) ) {
            return (bool) VE_DEBUG_LOG;
        }
        return defined( 'WP_DEBUG' ) && WP_DEBUG;
    }

    public static function register_fatal_handler(): void {
        if ( self::$registered ) {
            return;
        }

        self::$registered = true;

        register_shutdown_function( static function (): void {
            $error = error_get_last();
            if ( ! is_array( $error ) ) {
                return;
            }

            $fatal_types = [ E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR ];
            if ( ! in_array( (int) ( $error['type'] ?? 0 ), $fatal_types, true ) ) {
                return;
            }

            $file = (string) ( $error['file'] ?? '' );
            /* Whose file it is decides what this is CALLED, not whether it is
             * recorded.
             *
             * R30 and C81, 2026-09-09. This returned early for any fatal outside
             * VE_DIR, which is most of them - and the owner met two on one day:
             * a "critical error" toast in Media Studio, and an article that
             * answers HTTP 500. Neither was in MV, so MV recorded nothing, and
             * the only way to see what died was `wp-content/debug.log`. Asked to
             * turn that on, the owner said: "what if I can't get there?"
             *
             * They should not have to. A fatal is one line - file, line,
             * message - and MV is already running a shutdown handler at the
             * moment it happens. Recording somebody else's fatal is not
             * MV claiming it: `fatal_elsewhere` says exactly whose it is, and
             * the log is capped, so a site failing on every request cannot fill
             * a disk with it. */
            $is_ours = $file && defined( 'VE_DIR' )
                && false !== strpos( wp_normalize_path( $file ), wp_normalize_path( VE_DIR ) );

            self::error( $is_ours ? 'fatal_shutdown' : 'fatal_elsewhere', [
                'type'    => (int) ( $error['type'] ?? 0 ),
                'message' => (string) ( $error['message'] ?? '' ),
                'file'    => $file,
                'line'    => (int) ( $error['line'] ?? 0 ),
                /* Which request died. A fatal on one article and a fatal on a
                 * REST call read identically without it, and "which page" is the
                 * first thing anybody asks. */
                'url'     => isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( (string) wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '',
                'mv'      => $is_ours,
            ] );
        } );
    }

    public static function info( string $event, array $context = [] ): void {
        self::write( 'info', $event, $context );
    }

    public static function error( string $event, array $context = [] ): void {
        self::write( 'error', $event, $context );
    }

    public static function path(): string {
        return self::dir() . '/mimams-var.log';
    }

    public static function read( int $lines = 200 ): array {
        $path = self::path();
        if ( ! file_exists( $path ) ) {
            return [
                'path'    => $path,
                'entries' => [],
            ];
        }

        $rows = file( $path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES );
        if ( ! is_array( $rows ) ) {
            $rows = [];
        }

        $rows = array_slice( $rows, -1 * max( 1, $lines ) );
        $entries = [];
        foreach ( $rows as $row ) {
            $decoded = json_decode( $row, true );
            $entries[] = is_array( $decoded ) ? $decoded : [ 'raw' => $row ];
        }

        return [
            'path'    => $path,
            'entries' => $entries,
        ];
    }

    public static function clear(): bool {
        $path = self::path();
        if ( file_exists( $path ) ) {
            return (bool) @unlink( $path );
        }
        return true;
    }

    private static function write( string $level, string $event, array $context ): void {
        if ( ! self::should_log( $level ) ) {
            return;
        }

        $dir = self::dir();
        if ( ! is_dir( $dir ) ) {
            if ( function_exists( 'wp_mkdir_p' ) ) {
                wp_mkdir_p( $dir );
            } else {
                @mkdir( $dir, 0755, true );
            }
        }

        $path = self::path();
        if ( file_exists( $path ) && filesize( $path ) > self::MAX_BYTES ) {
            @rename( $path, $path . '.1' );
        }

        $entry = [
            'time'    => gmdate( 'c' ),
            'level'   => $level,
            'event'   => $event,
            'version' => defined( 'VE_VERSION' ) ? VE_VERSION : '',
            'context' => $context,
        ];

        @file_put_contents( $path, wp_json_encode( $entry ) . "\n", FILE_APPEND | LOCK_EX );
    }

    private static function dir(): string {
        return trailingslashit( WP_CONTENT_DIR ) . 'mimams-var-logs';
    }
}
