<?php

/**

 * Plugin Name: Mimam's Var - WP

 * Description: A powerful system for managing CSS variables, generating utilities, and streamlining your workflow in WordPress and Bricks Builder.

 * Version: 1.3.292
 * Author: Hebronmimam
 * Author URI: https://hebronmimam.com

 * Text Domain: variable-engine

 * Requires PHP: 7.4

 * Requires at least: 6.0

 */



defined( 'ABSPATH' ) || exit;



// ── Constants ──────────────────────────────────────────────────────────

define( 'VE_VERSION', '1.3.292' );
define( 'VE_FILE', __FILE__ );

define( 'VE_DIR', plugin_dir_path( __FILE__ ) );

define( 'VE_URL', plugin_dir_url( __FILE__ ) );

define( 'VE_CSS_OUTPUT_DIR', wp_upload_dir()['basedir'] . '/variable-engine/' );

define( 'VE_CSS_OUTPUT_URL', wp_upload_dir()['baseurl'] . '/variable-engine/' );

define( 'VE_API_NAMESPACE', 'variable-engine/v1' );

define( 'VE_IS_BRICKS', isset( $_GET['bricks'] ) );



// ── Autoload core classes ──────────────────────────────────────────────

require_once VE_DIR . 'core/Logger.php';

\VE\Core\Logger::register_fatal_handler();

require_once VE_DIR . 'database/Schema.php';

require_once VE_DIR . 'database/Migrations.php';

require_once VE_DIR . 'core/FluidValue.php';

require_once VE_DIR . 'core/Generators/GeneratorInterface.php';

require_once VE_DIR . 'core/Generators/ColorGenerator.php';

require_once VE_DIR . 'core/Generators/FluidScaleGenerator.php';

require_once VE_DIR . 'core/VariableManager.php';
// ThemeManager first: PaletteManager is now a deprecated alias that extends it.
require_once VE_DIR . 'core/ThemeManager.php';
require_once VE_DIR . 'core/PaletteManager.php';
require_once VE_DIR . 'core/ColorPaletteManager.php';

require_once VE_DIR . 'core/GeneratorEngine.php';

require_once VE_DIR . 'core/DependencyGraph.php';
require_once VE_DIR . 'core/FamilyRelationshipManager.php';

require_once VE_DIR . 'core/RenamePropagationManager.php';
require_once VE_DIR . 'core/VariableUsageManager.php';
require_once VE_DIR . 'core/MediaCollectionManager.php';

require_once VE_DIR . 'core/CssExporter.php';

require_once VE_DIR . 'core/Updater.php';

require_once VE_DIR . 'core/LicenseManager.php';

require_once VE_DIR . 'core/AdvancedCssManager.php';

require_once VE_DIR . 'core/MigrationScanner.php';
require_once VE_DIR . 'core/SettingsTransferManager.php';
require_once VE_DIR . 'core/VariableCategoryManager.php';

require_once VE_DIR . 'api/Routes.php';

require_once VE_DIR . 'api/VariableController.php';
require_once VE_DIR . 'api/PaletteController.php';
require_once VE_DIR . 'api/ThemeController.php';
require_once VE_DIR . 'api/ColorPaletteController.php';
require_once VE_DIR . 'api/VariableCategoryController.php';

require_once VE_DIR . 'api/GeneratorController.php';

require_once VE_DIR . 'api/SyncController.php';

require_once VE_DIR . 'sync/DiffEngine.php';

require_once VE_DIR . 'sync/SnapshotManager.php';

require_once VE_DIR . 'sync/SyncEngine.php';

require_once VE_DIR . 'sync/PortableBundleManager.php';

require_once VE_DIR . 'sync/PairingManager.php';
require_once VE_DIR . 'sync/DriftManager.php';

require_once VE_DIR . 'modules/builder-tools/MimamsBarModule.php';
// Do not load the bundled Recovery module if the standalone Recovery Studio test
// harness is already active: both declare VE\Modules\Recovery\* and require_once
// only de-duplicates by file path, so PHP fatals on the duplicate class. Mirrors the
// MimamsBarModule / BAQA_VERSION guard.
if ( ! class_exists( '\VE\Modules\Recovery\RecoveryModule', false ) ) {
    require_once VE_DIR . 'modules/recovery/RecoveryModule.php';
}
require_once VE_DIR . 'adapters/bricks/VariablesMirror.php';
require_once VE_DIR . 'adapters/bricks/BricksAdapter.php';
require_once VE_DIR . 'adapters/AdminAdapter.php';



// ── Activation / Deactivation ──────────────────────────────────────────

register_activation_hook( VE_FILE, function () {

    \VE\Core\Logger::info( 'activation_start' );

    try {

        \VE\Database\Migrations::run();

        \VE\Core\Logger::info( 'activation_complete' );

    } catch ( \Throwable $e ) {

        \VE\Core\Logger::error( 'activation_exception', [

            'message' => $e->getMessage(),

            'file'    => $e->getFile(),

            'line'    => $e->getLine(),

        ] );

        throw $e;

    }

} );



// ── Init ───────────────────────────────────────────────────────────────

add_action( 'plugins_loaded', function () {

    \VE\Core\Logger::info( 'plugins_loaded' );

    \VE\Database\Migrations::maybe_run();

    ( new \VE\Core\Updater() )->register();

    ( new \VE\Core\MediaCollectionManager() )->register();



    // Boot REST API routes.

    ( new \VE\API\Routes() )->register();



    // Boot adapters — mutually exclusive.

    if ( VE_IS_BRICKS ) {

        new \VE\Adapters\BricksAdapter();

    } else if ( is_admin() ) {

        new \VE\Adapters\AdminAdapter();

    }

} );



// ── Enqueue generated CSS on frontend ──────────────────────────────────

add_action( 'wp_enqueue_scripts', function () {

    $css_file = VE_CSS_OUTPUT_DIR . 'variables.css';

    if ( file_exists( $css_file ) ) {

        wp_enqueue_style(

            've-variables',

            VE_CSS_OUTPUT_URL . 'variables.css',

            [],

            filemtime( $css_file )

        );

    }

    $advanced_file = VE_CSS_OUTPUT_DIR . 'advanced.css';

    if ( file_exists( $advanced_file ) ) {

        wp_enqueue_style(

            've-advanced-css',

            VE_CSS_OUTPUT_URL . 'advanced.css',

            [],

            filemtime( $advanced_file )

        );

    }

}, 1 ); // Priority 1 — load before everything else.



// ── Also load in the editor/builder ────────────────────────────────────

add_action( 'admin_enqueue_scripts', function () {

    if ( ! isset( $_GET['page'] ) || $_GET['page'] !== 'variable-engine' ) {

        return;

    }

    $css_file = VE_CSS_OUTPUT_DIR . 'variables.css';

    if ( file_exists( $css_file ) ) {

        wp_enqueue_style(

            've-variables-admin',

            VE_CSS_OUTPUT_URL . 'variables.css',

            [],

            filemtime( $css_file )

        );

    }

    $advanced_file = VE_CSS_OUTPUT_DIR . 'advanced.css';

    if ( file_exists( $advanced_file ) ) {

        wp_enqueue_style(

            've-advanced-css-admin',

            VE_CSS_OUTPUT_URL . 'advanced.css',

            [],

            filemtime( $advanced_file )

        );

    }

} );



// ── Security plugin compatibility for VE REST API ────────────────────

// Ensures Variable Engine API works regardless of security plugin restrictions.



// 1. Handle CORS preflight BEFORE anything else (must be earliest hook).

add_action( 'plugins_loaded', function () {

    $uri = $_SERVER['REQUEST_URI'] ?? '';

    if ( strpos( $uri, 'variable-engine' ) === false ) return;

    if ( strpos( $uri, '/wp-json/' ) === false && strpos( $uri, 'rest_route' ) === false ) return;



    $origin = $_SERVER['HTTP_ORIGIN'] ?? '';

    // SECURITY: never combine a reflected/wildcard origin with Allow-Credentials — that
    // lets any website make cookie-authenticated requests to a logged-in admin's VE API.
    // Only the first-party origin(s) may send credentials (cookies); everyone else (the
    // Figma plugin authenticates with X-VE-Key, not cookies) gets a credential-less
    // wildcard, and the routes still enforce their own auth.
    $ve_cors_allowed_hosts = array_values( array_filter( array_map( static function ( $url ) {
        return $url ? wp_parse_url( $url, PHP_URL_HOST ) : '';
    }, apply_filters( 've_cors_allowed_origins', [ home_url(), site_url() ] ) ) ) );
    $origin_host = $origin ? wp_parse_url( $origin, PHP_URL_HOST ) : '';

    if ( '' !== $origin && '' !== (string) $origin_host && in_array( $origin_host, $ve_cors_allowed_hosts, true ) ) {
        header( 'Access-Control-Allow-Origin: ' . $origin );
        header( 'Access-Control-Allow-Credentials: true' );
        header( 'Vary: Origin' );
    } else {
        header( 'Access-Control-Allow-Origin: *' );
    }

    header( 'Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS' );

    header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-VE-Key' );

    header( 'Access-Control-Max-Age: 86400' );



    if ( isset( $_SERVER['REQUEST_METHOD'] ) && $_SERVER['REQUEST_METHOD'] === 'OPTIONS' ) {

        status_header( 200 );

        exit;

    }

}, 0 ); // Priority 0 = before security plugins



// 2. Whitelist VE namespace for Solid Security / iThemes Security.

//    This tells Solid Security to allow unauthenticated access to our routes.

add_filter( 'itsec_rest_api_restricted', function ( $is_restricted, $route ) {

    if ( strpos( $route, '/variable-engine/v1/' ) !== false ) {

        return false; // Not restricted

    }

    return $is_restricted;

}, 10, 2 );



// 3. Allow VE API key authenticated requests through WordPress REST auth.

//    This intercepts BEFORE security plugins reject the request.

add_filter( 'rest_authentication_errors', function ( $result ) {

    // Only handle VE API requests.

    $uri = $_SERVER['REQUEST_URI'] ?? '';

    if ( strpos( $uri, 'variable-engine' ) === false ) return $result;



    // Check for X-VE-Key header.

    $key = '';

    if ( isset( $_SERVER['HTTP_X_VE_KEY'] ) ) {

        $key = $_SERVER['HTTP_X_VE_KEY'];

    }



    if ( $key ) {

        $stored = get_option( 've_sync_api_key' );

        if ( $stored && hash_equals( $stored, $key ) ) {

            // Valid API key — grant admin access for this request.

            wp_set_current_user( 1 );

            // Auto-mark as paired if not already.

            if ( ! get_option( 've_sync_paired' ) ) {

                update_option( 've_sync_paired', true );

                if ( ! get_option( 've_sync_source' ) ) {

                    update_option( 've_sync_source', 'wordpress' );

                }

            }

            return true;

        }

    }



    return $result;

}, 1 ); // Priority 1 = before security plugins (they typically use 10+)



// 4. Also whitelist for Wordfence (uses a different filter).

add_filter( 'wordfence_ls_require_captcha', function ( $require, $action ) {

    $uri = $_SERVER['REQUEST_URI'] ?? '';

    if ( strpos( $uri, 'variable-engine' ) !== false ) return false;

    return $require;

}, 10, 2 );



// 5. Ensure CORS headers on actual REST responses too.

add_action( 'rest_api_init', function () {

    remove_filter( 'rest_pre_serve_request', 'rest_send_cors_headers' );

    add_filter( 'rest_pre_serve_request', function ( $value ) {

        $origin = $_SERVER['HTTP_ORIGIN'] ?? '';

        // SECURITY: same rule as the preflight handler — a reflected origin may never be
        // paired with Allow-Credentials. Only first-party origins get credentialed access;
        // API-key callers (Figma) get a credential-less wildcard.
        $ve_cors_allowed_hosts = array_values( array_filter( array_map( static function ( $url ) {
            return $url ? wp_parse_url( $url, PHP_URL_HOST ) : '';
        }, apply_filters( 've_cors_allowed_origins', [ home_url(), site_url() ] ) ) ) );
        $origin_host = $origin ? wp_parse_url( $origin, PHP_URL_HOST ) : '';

        if ( '' !== $origin && '' !== (string) $origin_host && in_array( $origin_host, $ve_cors_allowed_hosts, true ) ) {
            header( 'Access-Control-Allow-Origin: ' . $origin );
            header( 'Access-Control-Allow-Credentials: true' );
            header( 'Vary: Origin' );
        } else {
            header( 'Access-Control-Allow-Origin: *' );
        }

        header( 'Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS' );

        header( 'Access-Control-Allow-Headers: Authorization, Content-Type, X-WP-Nonce, X-VE-Key' );

        return $value;

    });

}, 15 );



// 6. Whitelist for WP Cerber (another common security plugin).

add_filter( 'cerber_exception', function ( $allow, $uri ) {

    if ( strpos( $uri, 'variable-engine' ) !== false ) return true;

    return $allow;

}, 10, 2 );

// Recovery module (backup / restore / migrate). Self-gates on capability and the
// ve_settings deactivated-tools list, so it stays inert until enabled.
add_action( 'plugins_loaded', function () {
    if ( class_exists( '\VE\Modules\Recovery\RecoveryModule' ) ) {
        \VE\Modules\Recovery\RecoveryModule::init( VE_FILE );
    }
}, 20 );

// 7. Add extra links to plugin row meta
add_filter( 'plugin_row_meta', function ( $plugin_meta, $plugin_file ) {
    if ( strpos( $plugin_file, 'variable-engine.php' ) !== false ) {
        $user_guide_url = 'https://www.notion.so/Mimam-s-Bar-Complete-User-Documentation-3797562bd31a811188d1d81512267a2b';
        $plugin_meta[] = '<a href="' . esc_url( $user_guide_url ) . '" target="_blank">' . __( 'User Guide', 'variable-engine' ) . '</a>';
        $plugin_meta[] = '<a href="https://hebronmimam.com" target="_blank">' . __( 'Support', 'variable-engine' ) . '</a>';
        $plugin_meta[] = '<a href="https://hebronmimam.com" target="_blank">' . __( 'FAQs', 'variable-engine' ) . '</a>';
        $plugin_meta[] = '<a href="https://hebronmimam.com" target="_blank">' . __( 'Cheat Sheet', 'variable-engine' ) . '</a>';
    }
    return $plugin_meta;
}, 10, 2 );
