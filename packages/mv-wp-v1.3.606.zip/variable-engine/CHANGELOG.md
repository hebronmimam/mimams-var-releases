## v1.3.606 - Another plugin's suggestion list comes out from under the toolbar

- **Code2Bricks' autocomplete was being painted under Bricks' element tray.**
  Their list is CodeMirror's stock one, which sits very low in the stacking
  order, and the tray sits well above it - so wherever the two overlapped, half
  of what you were choosing from was behind a toolbar.
- MV raises that one list, as it appears, and nothing else. No stylesheet rule
  is involved: a rule for this would reach every code editor on the page -
  Bricks' own, Advanced Themer's, WPCodeBox's - and staying out of those is
  deliberate. Outside the builder nothing runs at all.
- It checks that it worked rather than assuming. If the list is still covered it
  goes higher, and only if no height can win - because the list is trapped
  inside something else that loses - is it moved, and then it is pinned exactly
  where it was already drawn.
- MV's own suggestions are untouched and still sit above everything.

## v1.3.605 - A save writes what is in the box

- **Saving a class rule saved the rule as it was before you edited it.** The
  code editor commits its text a moment after you stop typing, and flushes it
  when it loses focus. Clicking Save takes focus away first, so the flush and
  the click happen in the same instant - and the button was already holding the
  text from before. The rule that reached the site was the old one. Everything
  downstream then worked perfectly on the wrong text, which is why "Saved where
  it lives" kept appearing over a rule that had not changed, in Code Studio and
  in Bricks' own Custom CSS alike.
- **The Code Studio code editor had the same fault** and is fixed with it: the
  last thing typed before pressing Save is no longer dropped.
- **Switching between code items can no longer write the previous item's code
  into the one you opened.**

## v1.3.604 — Pasted posts stop asking to be recovered

- **Editor artefacts no longer become part of a block.** The post the owner
  copied out of the editor carried 24 `data-start`, 3 `data-section-id`, empty
  `class` attributes and two nested selection-marker spans. WordPress decides a
  block is valid by regenerating what `save()` would have written and comparing
  it to what is stored, and it never writes any of that - so every affected
  block offered "Attempt Block Recovery".
- Content arriving from a paste is scrubbed before anything becomes a block,
  and a post already published carrying them is repaired on the next save.
  Nested markers take more than one pass, so the strip repeats until it settles.
- **Classes are kept, not dropped.** A class on the markup with nothing in the
  delimiter to explain it fails validation the same way, so it is recorded as
  the block’s own `className`, and an `id` as its `anchor`. A class core
  generates from another attribute - `has-text-align-center` from
  `{"align":"center"}` - is already explained and is left alone.
- Proved against the reported post itself, kept as a fixture: 20 blocks in,
  20 out, every artefact gone, the writing untouched, and repairing a repaired
  post changes nothing.

## v1.3.603 — A saved class rule reaches Bricks, and survives the builder

- **Saving a rule now writes Bricks' own dialect.** Reading a Bricks global
  class translated its `%root%` placeholder into the class selector so the
  owner saw a whole rule; the save wrote that expansion straight back. Bricks'
  Custom CSS box and Code Studio therefore held the same rule in two
  spellings, which is what "saved here, not showing over there" was. The
  translation now runs both ways, and skips strings and comments so a class
  name inside `content: ".card"` is left as content.
- **An edit made while the builder is open is no longer lost on reload.**
  Bricks reads its global classes once at boot and saves the whole option back
  from memory, so MV's database write was overwritten by the builder's next
  save - the edit was there, then gone. Code Studio now updates the same store
  Bricks' class panel edits, by reference so the canvas repaints, and tells the
  owner to reload the builder if it cannot find that store rather than
  reporting a save that will not survive.
- Moving a rule into a stylesheet clears the builder's copy as well as the
  database one, so an adopted class has a single owner.

## v1.3.602 — Site tokens without plugin chrome

- **Autocomplete no longer treats a loaded plugin or theme stylesheet as an
  authored token registry.** The C5 source map proved that Gravity Forms'
  `admin-components.min.css` supplied the `--gform-admin-*` suggestions while
  Automatic.css was not loaded on that wp-admin screen at all.
- Browser CSSOM discovery now accepts MV's authored runtime nodes and generated
  site CSS under uploads, while shipped plugin/theme assets are excluded.
- Automatic.css registered settings remain supported, and its narrowly
  identified compiled public CSS is now indexed server-side. Its real public
  variables therefore remain available in Code Studio and CSS Studio even when
  the editor document does not load ACSS. WordPress, Gutenberg, Bricks, MV,
  Mimam's Bar and Gravity Forms implementation prefixes stay excluded.

## v1.3.601 — Selector text is not a CSS variable

- **False `SHEET` suggestions no longer hide real framework variables.** The
  stylesheet fallback scanner was reading selector fragments such as
  `.gform-button--primary:active` as though they declared `--primary`, then
  displaying the rest of the selector as its value.
- Custom properties are now accepted only where a declaration can begin: at
  the start of declaration text or after `{` / `;`. Real declarations from
  Automatic.css, Core Framework, Advanced Themer and authored stylesheets stay
  eligible while BEM/state selectors are ignored.

## v1.3.600 — Bricks interface variables stay out of suggestions

- **Bricks' shipped interface tokens no longer appear in Code Studio on ordinary
  WordPress admin screens.** Its theme asset stylesheets were still being treated
  as authored site CSS outside the builder canvas.
- MV now excludes only Bricks' shipped `/themes/bricks/assets/` CSS and the
  `--bricks-` internal namespace. Generated Bricks site CSS and user-authored
  variables from Automatic.css, Core Framework and Advanced Themer remain
  eligible for suggestions.

## v1.3.599 — Mimam's Var Dark and Light syntax themes

- **Mimam's Var now has its own first-party Dark and Light editor themes.** The
  approved semantic palette is shared across CSS, JavaScript, PHP, HTML and JSON,
  while the surrounding MV interface remains dark.
- MV-owned custom properties use the MV lime treatment. Comments, selection,
  cursor and errors keep their approved semantic states.
- The two MV themes lead the shared picker. Existing saved choices remain
  unchanged, and One Dark Pro stays the default for accounts without a choice.

## v1.3.598 — Only your variables, not MV's

- **MV's own interface tokens are no longer suggested.** Variables belonging to
  Mimam's Bar and to the Bricks builder were appearing in the suggestion list
  alongside your site's. Only your site's own stylesheets contribute now.
- Inside the builder, suggestions come from the page being edited rather than
  from the builder's own interface.

## v1.3.597 — Suggestions for your site's own variables

- **Variable suggestions work on sites that do not use MV's variables.** If your
  design tokens come from Automatic.css, Core Framework or your theme, they are
  suggested now — MV reads the stylesheets on the page. WordPress's own admin
  tokens are still kept out, so the list stays short and useful.
- **The launcher stays at the bottom-right in the WordPress editor.** It was
  being pushed to the top of the screen, over the Save button, by the editor's
  own full-height layout. It still lifts clear of a real docked editor.

## v1.3.596 — History on your code items

- **Every Code Studio item keeps a history.** Press **History** in the footer to
  see every save that changed it, read any version, and restore one. Restoring
  keeps the current code in history too, so you can come straight back.
- **Stylesheets that came from CSS Studio bring their history with them** — the
  ids were preserved for exactly that.
- **CSS Studio has been retired from the rail and the launcher.** Code Studio
  reads the same stylesheets and now does everything CSS Studio did, so there is
  one place for code instead of two.

## v1.3.595 — Variable suggestions from the first dash

- **Typing `var(-` offers your variables.** It used to need both dashes before
  it recognised what you were doing, and until then it answered with value
  keywords that happened to contain a hyphen.
- **Editing a class rule is syntax highlighted**, in whichever theme you chose,
  with the same suggestions as every other MV editor.
- The built-in autocomplete inspector now reports what there was to suggest
  from, not just whether a popup was on screen.

## v1.3.594 — Variable suggestions, a usable rule editor, and older posts repaired

- **Variable suggestions are back.** A variable whose value MV could not resolve
  was being dropped from autocomplete silently, which removed every MV variable
  at once. Your variables are now always offered.
- **Editing a class rule gives a real editor** — about twelve lines rather than
  a single-line strip.
- **The “no suggestions” note** appears under the code as one line, instead of
  a tall box beside it.
- **Posts that still ask to “Attempt recovery” can be repaired**: re-save one
  from Content Studio and the prompt goes. Only quotes and headings MV wrote
  wrongly are corrected — nothing else in the post is touched.

## v1.3.593 — PHP highlighting, and CSS that stops being called wrong

- **PHP items are syntax highlighted.** Code Studio has always offered PHP and
  asked the editor for it; the mode was never loaded, so PHP showed as plain
  text. It is highlighted now, including HTML around the PHP tags.
- **Modern CSS is no longer marked as a mistake.** `inline-size`,
  `container-type`, `scrollbar-gutter` and their neighbours were being flagged
  as errors by the editor's built-in property list, which predates them. The
  editor now knows every property MV's own autocomplete knows — and
  autocomplete gained about two dozen it was missing too.
- **CSS functions look like functions.** `var()`, `clamp()` and `oklch()` are
  coloured as function calls rather than as plain variables, in every theme.

## v1.3.592 — Seventeen real syntax themes

- **The code editor theme setting now actually works, everywhere.** Choosing a
  theme changes every open MV editor at once, keeps your code, cursor, selection
  and undo history, and is remembered against your account rather than one
  browser.
- **Seventeen themes, and they look like the themes they are named after**:
  One Dark Pro (the new default), Dracula, Tokyo Night, Catppuccin Mocha,
  Gruvbox Dark Medium, Nord, Monokai, GitHub Dark, GitHub Light, Ayu Mirage,
  Kanagawa Wave, Rosé Pine, Night Owl, Material Palenight, Solarized Dark,
  Solarized Light and Everforest Dark. The colours come from each theme's own
  published definition. See THIRD-PARTY-THEMES.md for sources and licences.
- **GitHub Light and Solarized Light are genuine light editors** — the editor
  goes light while the rest of MV stays dark.
- **MV no longer restyles other plugins' code editors.** MV was shipping
  CodeMirror's suggestion-popup stylesheet unscoped, which repainted every code
  editor popup on the page — Bricks, Advanced Themer, Code2Bricks, WPCodeBox.
  Everything MV loads is now scoped to MV's own editors. Their suggestions are
  untouched.
- Syntax colouring covers every kind of token the editor produces, not the
  handful it used to, and errors are marked with an underline as well as a
  colour.

## v1.3.591 — Blocks WordPress accepts

- **“Block contains unexpected or invalid content” is fixed.** Quotes written in
  Content Studio now hold their paragraphs as blocks, the way WordPress writes
  them, and every heading carries the class core gives it. Posts open without
  the **Attempt recovery** prompt.
- **The Classes lane is readable again.** Hundreds of utility classes from
  Automatic.css and the builder — ones nothing styles and nothing uses — are
  hidden behind a line that counts them. Searching still finds every class.
- **Editing a class rule gives you a real editor**, about twelve lines tall,
  growing into the panel rather than a two-line strip.
- The gear in Code Studio is square, like the buttons beside it.

## v1.3.590 — The Classes lane, corrected

- **The usage counts were wrong.** Every class on a page read the same number
  because saved revisions of that page were being counted too. They count live
  pages now, once each, and hovering a number says what it counts.
- **Automatic.css classes no longer read “Unstyled”.** Classes that come from
  Automatic.css, Core Framework or Advanced Themer are marked **Framework** and
  are not offered a move — a copy in your own CSS would only fight the framework
  for the same class.
- **Editing a rule shows the whole rule.** Bricks stores some rules without a
  selector, so the editor was being handed a fragment; and the box was too short
  to read. It shows a complete rule now, with room for it.
- **The Classes lane no longer re-reads your whole site** every time you switch
  back to it. There is a refresh button when you want it re-read.
- CSS Recipes and Code Studio no longer share a rail icon, and the save buttons
  just say **Save**.

## v1.3.589 — The Classes lane, and code that stops disappearing

- **Code Studio has a Classes lane.** Every class on your site, how many
  elements wear it, and where its rule actually lives: on the Bricks class,
  inside one element's own CSS, in one of your stylesheets, or nowhere at all.
  A Bricks rule can be edited where it is or moved into a stylesheet, and a
  class nothing styles yet can be started in one.
- **Unsaved code no longer disappears.** Closing Code Studio without saving used
  to lose what was in the editor, because closing the panel takes the editor
  with it. Your work is kept as you type and comes back when you return, with
  the footer saying so. Switching between items keeps each one's work too.
- **The controls in Code Studio are the size of a form field.** They were all
  the same as each other last build, but smaller than every other field in MV.
  They match now.

## v1.3.588 — The rail comes back, and one control height

- **The studio rail vanished whenever Code Studio was open.** The rail sits
  beside whichever panel is open, and the list of open panels had been written
  out twice — once as the tools, once as the things that make it recalculate —
  and Code Studio was missing from the second. Opening it on its own recalculated
  nothing, so the rail had no panel to sit beside and drew nothing at all. There
  is one list now, so it cannot disagree with itself.
- **Code Studio's controls are all the same height.** The name field, the
  destination menu and the gear were 26, 24 and 30 pixels; the hook field and the
  page menu were different again. They all read one setting now, so a dropdown is
  the same height as the field beside it — which is what the Component Library
  has always said.

## v1.3.587 — Code Studio CSS actually loads, and One page names its page

- **Code Studio was writing files nothing loaded.** The panel compiled your CSS
  correctly and no page ever asked for it. The compiled files are enqueued now:
  everywhere and site-only on the front end, builder-only inside Bricks, and a
  page file only on its own page.
- **"One page" now names the page.** Choosing it offers a searchable list of your
  pages, and until you pick one the panel says plainly that the CSS is written
  nowhere. Each page gets its own file, so page CSS never leaks onto the rest of
  the site.
- **The autocomplete list was bigger than the code.** It renders outside the
  panel, where MV's sizes are not defined, so its font size was thrown away and
  it fell back to the browser default. It matches the editor now.
- **The item browser closes** on a click outside it or on Escape, and there is
  proper space between the list of items and the New buttons.
- Every editor applies your chosen theme as it mounts, rather than relying on the
  panel having set it earlier.

## v1.3.586 — Code Studio in the speed dial, and a tray that stays behind the Bar

- **Code Studio in the floating menu did nothing.** The rail opened it; the speed
  dial did not, because that menu keeps its own list of what each button does and
  Code Studio was not in it. Any studio in the speed dial now opens whether it is
  listed or not — the list is for the two tools that need something unusual.
- **The Element Tray no longer covers Mimam's Bar.** The tray sits at a very high
  layer so it can clear Code2Bricks, which put it over the command palette. While
  the palette is open the tray drops behind it — without moving, which is the rule
  that matters — and comes back on top when the palette closes.
- **The tray shortcut can be changed.** Settings — *Element Tray shortcut*: click,
  press the combination you want, done. Alt+T remains the default. A bare key is
  refused, because it belongs to whatever you are typing in, and every modifier is
  compared, so Alt+T no longer fires when you press Ctrl+Alt+T.

## v1.3.585 — Code Studio opens, and Alt+T hides the tray

- **Clicking Code Studio in the rail did nothing.** The panel shipped in v1.3.584
  and the rail knew about it, but the code that actually opens a panel had never
  been told the new id, so the rail marked it active and no panel appeared. It
  opens now, closes with the others in single-panel mode, and takes its turn like
  every other studio.
- **Alt+T shows and hides the Element Tray.** Alt because a bare letter belongs to
  Bricks and to whatever field has focus, and the shortcut stays silent while you
  are typing in one. It moves the same setting the switch in Settings moves, so
  the two never disagree and the choice survives a reload.

## v1.3.584 — Code Studio, part two: the panel

- **Code Studio opens.** It is in the studio rail beside CSS Studio, 430px wide,
  and it edits code items rather than four fixed stylesheets.
- **The strip reads left to right:** a language chip, the name (click to rename),
  where it goes, then the two controls that act on it — the on/off toggle and the
  gear. For CSS "where it goes" is a real destination: everywhere, site only,
  builder only, or one page. For PHP, JS and HTML it is a hook.
- **The gear is an item browser.** Every item with its language, its name, and a
  mark if it is switched off or was switched off by an error — plus **New** in all
  four languages.
- **An item in a language nothing runs yet says so**, in the panel, rather than
  looking active and doing nothing. CSS compiles today; the rest are stored.
- **Save & Compile writes the files**, and switching to another item while you
  have unsaved work asks first instead of throwing it away.
- CSS Studio is untouched and still there. Nothing has been taken away.

## v1.3.583 — The theme colours the code, not the panel

- **Picking a theme changed the background and left the syntax colours alone.**
  MV draws code through two highlighters — CodeMirror's, and its own — and only the
  first was themed. Both read the theme now, so the colours actually change.
- **And the background no longer changes at all.** A theme recolours the code;
  the editor's background, gutter, selection and cursor stay MV's, whichever
  theme is picked.
- Punctuation gets its own tone in each theme, sitting between the comment
  colour and the body text so it is present without being loud.
- Measured against MV's one background, every theme now reads better than it did
  on its own: the lowest token across all six is 3.5:1, and MV's own default
  stays above 4.5:1 throughout.

## v1.3.582 — Code Studio, part one: the store

- **Code Studio keeps code items, not stylesheets.** An item has a language, and
  what it means to run depends on that: CSS has a real **destination**, while
  PHP, JavaScript and HTML have a hook and a priority.
- **CSS compiles to four separate files** rather than one — global (site and
  builder), frontend, builder, and page — so a rule meant for the builder stops
  being served to visitors. The old single file is still written, so anything
  that already loads it keeps working while the change lands.
- **Your stylesheets come across on first load**, keeping their ids so their
  saved history still points at them, keeping their content, and keeping a
  disabled sheet paused rather than losing it. The old data is left untouched.
- **PHP, JS and HTML are stored and not executed.** That is deliberate: running
  stored PHP is the half that can white-screen a site, and it ships with a
  fatal-error guard or it does not ship. Storing the fields now means the model
  will not change underneath that work.
- Nothing in the panel has changed yet — this is the store and the compiler the
  new panel needs. The panel is next.

## v1.3.581 — Pick your code editor theme

- **Six themes, one picker.** Settings — *Code editor theme*: Mimam's Var,
  **Nord**, **Catppuccin Mocha**, **Tokyo Night**, **One Dark Pro** and
  **Solarized Dark**. The choice applies to every MV code editor at once — Theme
  Styles, Code Studio, custom CSS, anywhere MV shows code — and follows your
  WordPress account rather than one browser.
- Each palette is the theme's own published set, with one deliberate change:
  four of them ship comment colours below 4:1 against their own background, and
  since the point of this picker is eye strain, those comments are lifted enough
  to read. Every other colour is the theme's.
- The theme applies before the panel draws, so no editor flashes the wrong
  colours first, and the builder canvas gets it too.

## v1.3.580 — Content Studio writes real blocks

- **A post written in Content Studio opened in WordPress as one Classic block**
  asking to be converted before anything could be edited. It is stored as blocks
  now: headings, paragraphs, lists, images, quotes, code and separators each
  become the block WordPress would have made, so the post opens as itself and
  every block is editable straight away.
- **The image that broke out of its column** was a symptom of the same thing: an
  image inside a Classic block is laid out by the theme, not by the editor. As a
  real image block it carries `wp-block-image` and its attachment id, and the
  editor lays it out.
- **Anything unrecognised becomes an HTML block** rather than being dropped or
  mangled, so it renders exactly as written and stays editable.
- **Content that is already blocks is left alone.** Converting twice would strip
  the settings that live in the block delimiters — alignment, font size — so a
  post touched by the WordPress editor keeps everything it gained there.
- This changes new saves only. A post written before this update keeps whatever
  is stored until it is saved from Content Studio again.

## v1.3.579 — Enter after a closing brace, and a launcher that keeps looking

- **Pressing enter after `}` tabbed in.** A line ending in a closing brace is
  finished, so the next line belongs at the same indent as that brace — but the
  rule only recognised `{` and `;`, and everything else indented one level
  deeper. A comma at the end of a selector list and a finished comment hold
  their indent too now. A line that is genuinely unfinished still indents.
- **The launcher stopped looking for docks too early.** It polls for other
  plugins' floating buttons after load, and it used to stop the moment it found
  anything. Since v1.3.576 a docked editor counts as a dock, so the first find is
  usually Code2Bricks — and a launcher that mounts later, like Automatic.css
  inside its shadow root, was never looked for again. The poll now runs its whole
  window, and a slow heartbeat keeps measuring afterwards, because docks open,
  close and resize all day rather than once at load.

## v1.3.578 — Kinder syntax colours, and Format that actually tidies

- **The editor colours were doing too much.** Five fully saturated hues, with
  comments at 2.84:1 against the editor background — below anything readable — and
  values at 12.44:1 shouting over everything else. The new set sits in a narrow
  7.5—7.6:1 band with saturation held down, and comments lifted to 4.88:1 so they
  recede without vanishing. MV green stays for `var()`, only muted.
- **Format now tidies alignment.** A hand-aligned rule like `position:
  relative;` with the value pushed out to line up kept its padding, so pressing
  Format appeared to do nothing. Runs of spaces collapse to one, and a property
  colon gets exactly one space after it.
- What it still refuses to touch: a colon inside a string or inside brackets, so
  `@import url("https://...")` and `url(data:...;base64,...)` come through
  exactly as written. A selector like `a:hover` is never a declaration and is
  never spaced.

## v1.3.577 — MV loads again (fixes a break in v1.3.574—576)

- **Mimam's Var did not load at all in v1.3.574, v1.3.575 and v1.3.576.** No
  floating button, no panels, nothing — in the builder and in wp-admin alike. The
  panel's script threw `ReferenceError: ts is not defined` on load and stopped
  before it drew anything.
- **The cause was a comment.** The panel keeps its entire stylesheet in one
  JavaScript template literal, and a comment added in v1.3.574 wrote a class name
  in code quotes. A backtick **ends** that literal: everything after it was read
  as JavaScript, and `ts` — a fragment of a class name — became an undefined
  variable. The stylesheet, and every line of code after it, never ran.
- One line removed. MV loads normally again, with the launcher, the panels and
  everything else those three releases were shipping.
- **This is why it got through:** the file was still valid JavaScript, so every
  syntax check passed. A new guard reads the stylesheet region directly and fails
  on a backtick, an interpolation, unbalanced braces, or a literal that stops
  being CSS — the things a syntax check cannot see.

## v1.3.576 — The launcher clears Code2Bricks

- **The MV button was inside the Code2Bricks editor, behind it.** MV lifts its
  launcher above other plugins' floating buttons by measuring them, and that
  measurement only looked at launcher-sized things — 240px at most in each
  direction. An editor docked across the whole bottom of the screen is nothing
  like that shape, so it was skipped entirely, the launcher stayed in the corner,
  and Code2Bricks drew over it.
- A dock along the bottom that reaches the right-hand edge now lifts the launcher
  clear of it, keeping its usual right-hand position — a full-width editor has no
  centre line to stack with. Small corner launchers are unchanged: MV still
  stacks in a column with those.
- A full-screen overlay, a hairline bar, a hidden dock and a dock on the far side
  are all still ignored, so a modal backdrop cannot throw the launcher up the
  screen.

## v1.3.575 — The MV launcher comes back after Theme Styles

- **The floating MV button disappeared and stayed gone.** It hides while an MV
  panel is open and returns when the panel closes — but the code that does that
  only runs when one of the panels it watches changes, and **Theme Styles and
  Bricks Settings were not among them**. Open either one, then anything else that
  did trigger it, and the launcher was hidden with nothing left to bring it back.
  Both are watched now.
- Guarded by comparing the two lists rather than by naming today's panels: any
  panel added to the condition in future has to be watched too, and the guard
  says which one is missing.

## v1.3.574 — Update goes straight to the newest build

- **Being several builds behind meant updating one at a time.** The Update
  button sent the version it had cached, which pins the install to exactly that
  build — so you landed one step forward and were told there was another update.
  On Dev that cache is five minutes old, which during a busy day is easily three
  builds. **Update** now means the newest there is, in one go, from the builder
  notice, Mimam's Bar and Settings alike.
- A version is still sent when you choose one: a rollback, or a specific release
  from the history. That was always the only case that should pin anything.
- **The stylesheet format button moved to the right** of the group heading, with
  undo, redo and clear, instead of sitting beside the title.

## v1.3.573 — Renaming a theme style, and a format button for its CSS

- **A renamed theme style went back to its old name.** Type the new name, press
  enter, and the switcher showed what it said before. The rename was not lost — it
  was written into the draft, while the switcher above reads the list of styles,
  which still held the old label. Both are updated now, and the name you typed
  is what you see.
- **The rename field takes focus.** It was asking for it with `autofocus`, which
  browsers honour when a page loads, not when a field appears on a click. It
  focuses and selects the name, so you can type straight over it.
- **Escape puts the old name back**, and enter or clicking away commits.
- **The stylesheet group has a format button.** One declaration per line,
  indented by nesting, a blank line between rules. It only moves whitespace:
  comments, strings and `url(data:...;base64,...)` are copied through exactly as
  written, and nothing is renamed, reordered or removed.

## v1.3.572 — Two people in the same post

- **Content Studio told nobody, and the last save won.** Two people could open
  the same post, neither was warned, and whoever pressed Update second replaced
  the other's work with no message. WordPress has had an answer to this for
  years — the post lock — and MV walked straight past it, so even the WordPress
  editor's own "so-and-so is editing" never appeared for an MV save.
- **You are warned when you open it.** If someone else has the post open, a line
  at the top of the editor says who, and since when. It does not stop you: they
  may have wandered off hours ago.
- **You are stopped when it actually matters.** The panel remembers the version
  it loaded, and a save is refused if the post has moved on since — with the name
  of whoever changed it. Then it is your call: **Open theirs** loads their
  version, **Overwrite theirs** saves yours anyway. Nothing is lost either way,
  and nothing is decided for you.
- MV uses WordPress's own lock and modified stamp, not private state, so the
  WordPress editor and MV can see each other. The lock is refreshed while you
  type and released when you leave the post.
- New guard `check-content-studio-concurrency.php` runs both routes against a
  stubbed WordPress with two users: 13 checks, seven mutations, seven caught,
  plus six panel contracts, six mutations, six caught.

## v1.3.571 — Media Studio picks the site icon; WordPress only crops it

- **Choosing a site icon opens Media Studio again.** v1.3.570 handed the whole
  control back to WordPress, which fixed the pick going nowhere but put
  WordPress's library in front of you. The two halves are split at the seam that
  matters now: **choosing** is a library job and Media Studio does it;
  **cropping** stays with WordPress, because that step is what writes the site
  icon's own image sizes.
- So: press *Choose a Site Icon*, pick in Media Studio, and WordPress's crop
  screen opens on your image with the library step already done.
- The same applies to any cropped-image control, including the customizer's.
- **If anything on that path is not what MV expects** — a WordPress version that
  names its states differently, an attachment that will not load — the control
  opens exactly as WordPress built it rather than leaving you with nothing. With
  Media Studio switched off it is WordPress's own control throughout.

## v1.3.570 — Every dropdown gets its own design tokens back

- **The search field in a menu had no rounded corners and its text was 16px.**
  v1.3.569 set the radius and nothing changed, because the rule was never the
  problem: menus render into a portal appended to `document.body`, which is
  outside `#ve-panel-root` where MV defines its design tokens. Every declaration
  in a portal that reads a token was dropped by the browser — the radius went to
  nothing and the search field and "no matches" text fell back to the browser
  default 16px instead of MV's 11px.
- The tokens are defined for the portal as well, so the rules that use them
  finally apply: 6px corners on the search field, 11px text, and MV's pill
  scrollbars inside long menus. This affects every MV dropdown, not only the
  taxonomy one.

## v1.3.569 — The Site Icon picker actually applies your pick

- **Choosing a site icon did nothing.** The library opened and the selection was
  accepted, then the icon never changed. WordPress's Site Icon is a **cropper**:
  it picks an image, hands it to a crop step, and expects the frame to carry the
  states it declared. MV's bridge frame answers a selection and nothing else, so
  the pick reached a dead end.
- **MV now only takes over the frames it can finish.** A plain select frame goes
  to Media Studio as before; anything that brings its own states, asks for a crop
  or belongs to a customizer control opens WordPress's own modal, which is what
  the bridge was always meant to fall back to. Site Icon, and cropped-image
  controls generally, work again.
- **The search field in a dropdown is 6px, not 4px** — the control radius MV uses
  everywhere else, including the chips and the + add button beside it.
- The picker guard grew from 14 to 19 checks and now executes the bridge test as
  well; five mutations, five caught, plus a static contract for the call site the
  executed guard cannot see.

## v1.3.568 — Search and create in one menu

- **The separate "+ new" button is gone.** The **+ add** menu searches now, and
  when what you have typed is not already there it offers **Create "your text"**
  at the bottom of the list. Press enter and the term is created and attached to
  the post — one control for finding and for adding.
- The offer appears whenever there is no **exact** match, not only when the list
  comes back empty, because a name that is part of a longer one would otherwise
  be impossible to create: typing "Crypto" always matches "Crypto Basics".
- The menu is there even when every existing term is already on the post, which
  is exactly when a new one is wanted.
- Any MV dropdown can do this now: `SelectMenu` takes `onCreate`, `createLabel`
  and `emptyLabel`, with the create row reachable by arrow keys and enter.

## v1.3.567 — The Site Icon picker opens on images, not SVGs

- **Choosing a Site Icon opened a library filtered to SVG only.** MV routes
  WordPress's own pickers to Media Studio and guesses the file type from the
  control that was clicked — and that guess read the word **icon** as "vector".
  The button says "Choose a Site Icon", so the library showed SVGs, which is the
  one thing a site icon can never be: WordPress crops it from a PNG or JPG.
- **"Icon" now means different things on the two surfaces**, which is what it
  really does: in Bricks it is the icon control and still opens on SVGs; in
  wp-admin it is a picture, so the word no longer filters anything. The Site Icon
  is named outright as an image.
- **The host's own frame is read properly.** `wp.media` usually passes a Query
  rather than a plain object — the Site Icon frame does — and its type sits in
  Backbone props, so MV was ignoring the one authoritative answer available and
  falling back to guessing.
- New guard `check-media-picker-filter.js` lifts both inference functions out of
  the panel and runs them against stub controls on both surfaces: 14 checks, four
  mutations, four caught.

## v1.3.566 — The Element Tray goes under the update card

- **The tray stayed sharp on top of the update card's blur.** Everything else in
  the builder dimmed and the tray sat over it, looking like it belonged to the
  card rather than to the page behind it.
- The tray sits at z-index 1000000 so it can clear third-party bottom docks, and
  the update scrim blurs at 140009. That elevation is safe only because the tray
  removes itself whenever a blocking MV surface owns the page — Media Studio, an
  MV modal, the refresh modal, a Bricks popup. The update card's scrim was simply
  missing from that list. It is in it now, and the tray returns the moment the
  card is dismissed.
- The Element Tray harness gained an update-card fixture, and the focused guard
  now reports the number of checks it actually ran rather than the 49 that had
  been written into it by hand for the last three builds.

## v1.3.565 — The editor fills its height, and + add matches + new

- **The writing area now reaches the bottom of the panel.** The canvas carried
  80px of bottom padding, which was breathing room for the end of a scrolling
  canvas. Since v1.3.564 the canvas no longer scrolls while editing, so that was
  simply empty space under the text. It matches the top gap now, and the writing
  area is about 55px taller at every window size. Preview keeps its own padding.
- **The + add menu is the same height as + new and the category chips.** It asked
  for 26px and rendered at 38: a height on its own cannot beat a minimum, and the
  shared control it is built from sets both a minimum and a maximum of 38px. It
  states all three now.
- Both measured in `scripts/harness-content-editor.html` against the shipped
  stylesheet rather than adjusted by eye.

## v1.3.564 — One scrollbar in the Content Studio editor

- **The writing column had two scrollbars side by side.** The canvas scrolled and
  so did the writing surface inside it, so on a shorter window you got one bar for
  the surface and a second, 38px away, for the canvas.
- **Why:** the surface is a flex item carrying a 470px floor and a 680px ceiling,
  and the shell and workspace around it were sized by their content. Below about
  760px of canvas the paper grew taller than the canvas, so the canvas scrolled
  too. Bounding the shell and workspace to the paper and letting the surface flex
  inside them leaves exactly one scroller at every height, and the surface now
  grows and shrinks with the window instead of stopping at 680px.
- The toolbar stays where it was, and preview mode is untouched — there the canvas
  is deliberately the only scroller.
- Measured, not reasoned about: `scripts/harness-content-editor.html` puts the
  shipped stylesheet around the editor's real DOM and counts the scroll containers
  in the writing column. Two before at every height from 500 to 820px; one after,
  from 500 to 900px.

## v1.3.563 — Make a category without leaving Content Studio

- **The taxonomy picker can create a term now.** It could only ever offer what
  already existed, because MV had a route for creating a *taxonomy* and none
  for creating a *term* inside one — so a new category meant going to the
  WordPress editor. **+ new** beside **+ add** takes a name, creates it and
  selects it on the post you are writing.
- **The add row no longer disappears.** It was hidden as soon as every existing
  term was already assigned, which is precisely the moment you need a new one.
- **A name that already exists selects that term** instead of returning an
  error and leaving you to find it in the list yourself.
- **It respects who you are.** Creating a term needs the taxonomy's own
  `edit_terms` capability, which writing a post does not grant, and only the
  taxonomies the studio actually lists can be written to.
- New guard `check-content-studio-terms.php` executes the real route against a
  stubbed WordPress: 13 checks covering creation, duplicates, refusals and
  parent handling, each behaviour mutation-tested. The stubbed WordPress both
  Content Studio guards use now lives in one shared `wp-stub-env.php`.

## v1.3.562 — Publishing from Content Studio takes Rank Math with it

- **A post no longer goes public before its SEO fields exist.** The publish
  transition is what Rank Math, sitemaps and redirections react to, and it
  happens once — a post made public first was seen with no SEO data at all.
  Saving again in the WordPress editor fired that transition a second time,
  which is why doing that appeared to repair it.
- **Creating a post from Content Studio now stores its SEO fields at all.**
  The create route accepted the whole payload — SEO, custom fields, featured
  image, terms — and wrote only the post columns.
- **Clearing an SEO field removes it rather than storing a blank.** To Rank
  Math a stored empty is an explicit blank, so it suppresses the site's own
  title and description templates instead of falling back to them.
- **A post with no robots setting of its own keeps it.** The panel shows the
  inherited `index` default, and saving wrote that back as a per-post choice,
  quietly overriding the site setting for that post type.
- New guard `check-content-studio-seo.php` executes the real REST methods
  against a stubbed WordPress and asserts the write order and the
  delete-on-empty rule; 11 checks, all four fixes mutation-tested.

## v1.3.561 — Element Tray respects the Bricks template browser

- The Element Tray is removed while a visible native Bricks popup owns the
  builder and returns to its canvas/dock floor after the popup closes.
- The high z-index needed to clear Code2Bricks no longer lets the tray paint
  over Bricks' template browser.
- Added a Bricks popup fixture to the Element Tray harness and raised the
  focused contract to 49 checks.

## v1.3.560 — Account-owned Element Tray and security boundaries

- The Element Tray no longer jumps above Mimam's Bar. Mimam's Bar is an
  overlay; the tray remains anchored to the Bricks canvas/dock floor while real
  bottom docks such as Code2Bricks still move it.
- Element Tray choices and order now live in the logged-in WordPress user's
  preferences and therefore follow that account across browser sessions. A
  legacy browser-only tray migrates when the account has no saved tray.
- Tray preference input is limited to 60 unique, validated Bricks element or
  component keys at the REST boundary.

- Integration keys no longer assume WordPress user ID 1 and are accepted only
  on the exact MV REST namespace; route callbacks restrict the key to token
  model and sync operations.
- Pairing registration is administrator-only, codes are origin-bound, metadata
  updates require the active key, and existing pairings cannot be overwritten.
- Plugin Studio actions require their own capabilities; destructive Recovery
  routes require `update_core` and a super administrator on multisite.
- Recovery backups are encrypted before persistence, untrusted portable
  plaintext packages are rejected, and restored SQL is limited to temporary
  table DROP/CREATE/INSERT statements from the bundled exporter.
- Content/media reads now enforce object authorization; remote downloads are
  redirect-safe and bounded; media ZIPs are inspected before extraction.
- Maintenance preview keys are generated instead of falling back to `bypass`.
- Added a 12-contract security regression guard. Release package signature
  verification remains pending a publisher key and signed manifest format.

## v1.3.559 — Element Tray: ready immediately, with no morph

- **The complete Element Tray is always ready.** Its 42px control is visible and interactive as soon as it belongs on the builder canvas; nobody has to hover over a resting line or wait for controls to reveal.
- **The line-to-tray morph is gone.** The 64 × 5px resting state, decorative core, hover/focus expansion, hidden-child state and 160–400ms stagger have been removed.
- **Placement and actions stay intact.** Insertion, Edit, Arrange, canvas/dock positioning, Mimam’s Bar clearance, preview hiding and yielding to blocking MV surfaces continue to use the existing tray contracts.
- The focused guard still carries **43 checks** and now rejects any return of the collapsed or staggered morph behavior.

## v1.3.558 — Element Tray: resting line R and correct builder layers

- **The two tools have distinct names.** The insertion strip is the **Element Tray**; the centered command palette remains **Mimam’s Bar**. Existing internal `mvqa` selectors and storage remain compatible.
- **Approved direction R ships.** The tray rests as a weighted **64 × 5px** line, fans from its centre on hover or keyboard focus, then rises to the 42px control with a left-to-right reveal. Edit and Arrange hold it open, and reduced-motion users get the same states without the transition.
- **The tray clears Mimam’s Bar.** When the command palette opens or moves, the tray occupies the lane **12px above it** and returns to its normal canvas floor when the palette closes.
- **The tray yields to blocking MV surfaces.** It is removed while Media Studio, its file-drop backdrop, or another MV modal owns the page, then restored when that surface closes. Its elevated Code2Bricks layer can no longer pierce an MV studio.
- The harness carries Mimam’s Bar and blocking-studio fixtures; the guard now covers **43 contracts**.

## v1.3.557 — The quick add bar, on a real site

- **It no longer appears before the builder does.** The bar was drawn over Bricks’ loading screen. It now waits for the canvas to exist and for Bricks to have registered its elements.
- **It hides in preview.** Preview puts the builder’s own chrome away, and MV’s goes with it — the bar is removed, not faded.
- **The gap above Code2Bricks holds at every height.** It was measured from the canvas floor, which works while a dock pushes the canvas smaller and fails the moment one lies over it instead. The bar measures the docks themselves as well now and clears whichever reaches highest, always by the same **12px** — and it follows a dock while it animates rather than measuring once.
- **The Edit bar sheet stopped squashing itself.** With a long list, the flex column shrank the caption and the search field until the text ran over the input.
- **MV’s floating button treats the bar as its own.** MV lifts its button to clear other plugins’ docks, and the quick add bar was not excluded — so MV could lift its button to clear MV, and stop looking before Automatic.css had even mounted its launcher. That is why the button was sitting on the ACSS icon again.

## v1.3.556 — The quick add bar sits on the canvas floor

- **It follows Code2Bricks.** The bar was pinned to the bottom of the window, so a bottom-docked editor sat over it. It is measured from the **bottom edge of the Bricks canvas** now — 20px above whatever the canvas floor is — which puts it exactly above Code2Bricks and keeps it there as C2B is dragged taller or shorter. MV needs to know nothing about C2B for this: the canvas is what shrinks, so the canvas is what is measured.
- The canvas is watched directly, because resizing an iframe raises no window event — drag the dock and the bar moves with it, without a reload or a click.

## v1.3.555 — The quick add bar, after using it

- **It sits above Code2Bricks now.** The bar was drawn under the C2B editor, which made it useless whenever that panel was open.
- **Every component carries the same mark.** Bricks names an icon for each of its elements and names nothing for a component, so components were falling back to their first letter and the bar read as an alphabet. One component glyph for all of them; the dot already says which ones are yours. Something in the bar that has since been deleted gets a dashed mark of its own.
- **The caption above the search field is smaller**, and shorter, so the list under it leads.
- **The arrange label stopped shouting** — it reads *arrange*, not ARRANGE.
- **Fixed underneath: every text size in the bar was being thrown away.** The stylesheet wrote sizes as `font: 700 9.5px/1 inherit`, which is not valid CSS — the shorthand’s last value has to be a font family — so browsers dropped the whole declaration and the bar inherited 13px everywhere. Ten of those. The sizes are written out now and the tooltip, the list, the groups and the labels are the sizes they were designed at.

## v1.3.554 — A quick add bar in the Bricks canvas

- **Adding something no longer means leaving the canvas.** A small bar sits at the bottom of the Bricks canvas holding the things you actually place. Press one and it is inserted and selected — elements through Bricks’ own add, components through the same door, so nothing here is a copy of Bricks’ behaviour.
- **Icons, with a tooltip.** Every button is a 30px square that never changes size, and the name appears above it on hover, so nothing shifts as you run along the bar. A **filled dot marks one of your components**; a **ring marks a Bricks element** — the same two marks appear in the list.
- **Edit bar** — the last button but one — opens the whole catalogue above the bar with a search field: every element Bricks registered and every component on this site, in two groups. Tick to add, untick to remove; a new pick lands at the end of the bar, and the list keeps its place while you work.
- **Arrange** puts the bar in arrange mode: press a button and it lifts, every place it could go opens as a gap between the others, and a second press drops it there. No dragging and no holding — two ordinary clicks, with every legal destination visible while you decide.
- **It can be turned off.** Settings → *Quick add bar*. Off, MV puts nothing on the Bricks canvas at all, and the switch takes effect without a reload.
- The bar centres itself on the canvas rather than the window, so it never sits over the Bricks panel, and what sits in it is remembered per browser. A slot pointing at something that has since been deleted says so instead of failing quietly.

## v1.3.553 — CSS Studio keeps a history

- **Every save that changes a stylesheet is kept.** Until now Save & Compile overwrote the previous content and that was the end of it — there was nothing to go back to. Each sheet now carries its own history: what changed, when, how large it was and who saved it. The first time a sheet is edited its previous content is stored too, because that is exactly the edit people want back.
- **History is in the panel.** A **History** button beside Save & Compile lists the versions of the stylesheet you are editing, newest first. Pick one to read it, and **Restore this version** puts it back — into the editor and the compiled file together.
- **Restoring is itself undoable.** The current content is written to history before it is replaced, so pressing restore twice walks back out again. A save that changes nothing writes no version, and each sheet keeps its last 25, pruned per sheet so a busy stylesheet never crowds out a quiet one.
- The history table is created by the normal database migration, which runs on update.

## v1.3.552 — The parent picker lists every page

- **It was offering only the pages Content Studio had already loaded** — 150, newest by modified date. That is right for a working list and wrong for a parent picker, because the page you want to nest under is usually an old one nobody has touched in months. The picker asks for id, title and parent across the whole type now, read straight from the posts table so a few thousand pages cost one small query rather than a few thousand hydrated objects. Trash and auto-drafts are left out, a type that cannot nest gets nothing, and the list is capped at 5,000 with the cut-off stated rather than hidden.
- **A page more than six levels deep was never offered at all.** The six was meant to cap the indentation and was capping the walk, so a deep branch and everything under it silently disappeared from the list. Depth now limits only how far a row is indented. A page whose own parent has been deleted is offered too, instead of being unreachable.

## v1.3.551 — The sentence under a control is set in MV's own type

- **“This sits under …” came out as the builder's paragraph text**, because the class it was written with had no rule at all. Two more sentences had the same fault: the note when the shortcut registry fails to load, and the line above the plugin directory list. All three are small grey notes in MV's own face now, stating their size, leading and colour outright — anything left unstated in here belongs to whatever MV is running inside.

## v1.3.550 — The parent menu lands where the button is, and pages can have a parent

- **The organiser's parent menu opened in the wrong place.** v1.3.549 moved it to `fixed` so it would stop adding scroll space to the list, and that was right about the space and wrong about the position: MV's panel sits inside a transformed ancestor, and a transform makes that ancestor the containing block for anything `fixed` inside it, so viewport coordinates landed somewhere else. The menu now hangs off the dialog itself and is measured against it — outside the scrolling list, so it still adds no height there, and immune to whatever is transformed above.
- **Content Studio can set a page's parent.** WordPress offers Parent on any hierarchical type and MV never did, although the save has always sent one — the field was the only piece missing. A **Page attributes** card appears on hierarchical types only, listing that type's pages indented by depth, and never offering the page itself or anything beneath it.
- **The release notes are about the plugin.** This card was showing entries for mock prototypes and archived design files — how the work gets done, not part of what you installed. Those stay in the repository's own changelog now, and the release check fails if an internal note reaches the card.

## v1.3.549 — The parent menu stops stretching the list

- **The empty space under the organiser's list was the open menu.** An absolutely-positioned child still counts toward its scroll container's scrollable area, so the menu — which lived inside the scrolling list — added its own height below the last row, and would have been clipped on that row anyway. It hangs off the dialog now, flipping above the button when there is no room below, and scrolling the list closes it rather than stranding it. The list is only ever as tall as its rows.

## v1.3.548 — The token rows stop blanking, and the parent picker is MV's own

- **Editing a class emptied the bar for a second.** Bricks rebuilds the element when a class changes, and for a frame or two in the middle of that the selection reads as nothing at all. The bar took that literally and cleared the class and attribute rows, which then refilled themselves with exactly what had been there. A selection that has just gone empty is now treated as *not settled yet*: the rows are left alone and looked at again 140ms later. Only a re-check that still finds nothing clears them, so clicking off an element still empties the bar.
- **The organiser's parent list was the browser's, not MV's** — a white system dropdown over a dark panel, and there is no styling one. MV draws the menu itself now, with the values `.ve-context-menu` has always used: bordered, `#1b1b1b`, lime on hover, Top level first. It opens from its own button and closes on a click anywhere else.
- `scripts/check-v1-3-548-token-rows.js` **runs the real refresh** against an adapter that goes empty and comes back, which is the only way to tell this fix from a hopeful comment: eight checks, mutation-tested both ways — the flicker returning, and a real deselection never clearing.

## v1.3.547 — The install card, the organiser, and MV's own typefaces

- **The card ran off the top of the screen when there was a lot to read.** It grows upward from the launcher and nothing bounded it, so a long release note pushed its own heading past the top. The dock is capped at the room it has, the card lays out as a column, and the **notes are the part that scrolls** — heading, confirmation, hold note and both buttons stay on screen however long the list is.
- **The folded card was unstyled, and that was my mistake.** v1.3.545 shipped the two-stage card's markup without its stylesheet: the swap carrying the CSS was in a script run that aborted before writing, and the check afterwards looked for class names in the package — which are markup, so it passed. An unstyled bare button renders as whatever the builder gives it, and the section label was an `<h5>`, which the builder sets at heading size. The stylesheet is in, the label is a div that states its own type, **Show steps** is a bordered control, and the release notes are set as prose at 11px with room between the items. `check-v1-3-547-card-and-type.js` now fails if any class the card renders has no rule.
- **The organiser's parent picker did nothing.** The whole row was draggable, and a `<select>` inside a draggable element cannot be opened and picked from — the press starts a drag instead. Only the grip is draggable now, the way the rail has always done it, so **Top level** and every other parent work. And because every move applies as you make it, there is now **Undo all changes**, which puts back the arrangement the board opened with.
- **The rail's new-child field takes the caret.** `autofocus` only applies when the document parses the element, so a field added by a re-render never got focus and you had to click it first.
- **MV is set in Plus Jakarta Sans and JetBrains Mono** — the pairing from the calm pass, which is the part of it worth keeping. Both are **bundled in the plugin** (92 KB, latin subsets, OFL), not fetched from Google: every other asset here is bundled so the builder works offline, under a strict CSP, and on privacy-strict hosts. Scoped to MV's own surfaces, so the builder's chrome is untouched, and both fall back to the system stack if the file is blocked.

## v1.3.546 — Sub-collections: A and C, on one model

- **Renaming a parent no longer loses its children.** A child is a separate entry whose key and label carry its parent's name, and rename rewrote one key — so every child was left pointing at a parent that no longer existed and disappeared from the rail. Rename now rewrites the whole subtree, in the map's existing order so the rail does not reshuffle, and says how many children moved. Deleting had the same shape: it now removes the subtree and the confirm names the count first.
- **A · a sub-collection is made in the rail.** “New subfolder” opens a field under the parent, one level in, that says *Name it, inside Fonts*. You type the child's name only — no modal, and no “Parent / ” sitting in the field to type around, which is the part the owner rejected. Enter creates, Escape cancels, and a collapsed parent opens first so the new child is not created out of sight.
- **C · an organiser for moving them.** **Organise collections** under the rail opens a board: drag a row onto another to put it inside, or pick its parent from a list that includes **Top level**. Children come along. A collection cannot take itself or its own children as a parent — the drop is refused and they are not offered in the list.
- Both surfaces end in one `moveCollectionToParent`, and rename, delete and move all read one definition of what a subtree is. `scripts/check-v1-3-546-subcollections.js` **lifts those functions out of the panel and runs them** against the rail from the owner's screenshot — 28 checks, mutation-tested against every way the fix could be undone.

## v1.3.545 — Media Studio gets its padding back, and the install card folds

- **The media area lost its padding, and I took it.** v1.3.540 said it had restored Media Studio to v1.3.502 and had not. Where a selector is written more than once — which is most of this stylesheet, since every release appends its overrides — the **last** body is the one that renders. That pass rewrote 32 of those last bodies with the *earlier* body of the same selector, undoing overrides that had nothing to do with the calm pass. `.ve-studio-main` lost `padding:20px`; the overview grid fell from five columns to four, so the fifth card wrapped onto its own row; the list scroller lost its frame; the colour popover lost its layout; the toolbar lost `flex-wrap`. Rule counts never changed, which is exactly why the checks at the time reported “zero appearance rules differ”.
- **All 32 are restored** and `scripts/check-media-studio-restore.js` now compares what actually *wins* against the shipped v1.3.502 package, rule by rule — 544 selectors, zero drift. It blanks comments before scanning, because the commentary in this stylesheet quotes CSS with braces and counting those as code hid half the rules from my first repair pass.
- **The install card is the approved two-stage card.** Direction C of docs/mocks/tools/2026-08-17-update-card-spacing.html: while the install runs you watch the eight steps; once it lands they fold into one confirmed line with **Show steps** to open them again, and the room goes to what changed and the decision — 26px before the notes heading, 26px before the buttons. A **failure keeps its steps open**, because that is the build where the list is the whole point, and a new install unfolds them again. The section label now sits outside the recess instead of inside it, which is where the room above it comes from.

## v1.3.544 — An attribute is findable by its value

- **Typing `slant` finds `data-section-edge="slant"`.** It did not before, for two reasons that had to be fixed together. The ranking scored the attribute **name** only, so a value could never match — the attribute was on the page, was indexed, and still could not be found. And the site index deduped by name and kept the first value it saw, so a second setting of the same attribute was never indexed at all. Values are indexed now, most used first, and a suggestion is scored against every string that identifies it.
- **A value hit ranks under a name hit, never instead of it.** Typing a name still leads with that name and still lists it once, not once per value it has ever carried; the other values appear only when the query actually names them. The matched value is marked in the row, the way a matched name is.
- Held by `scripts/check-bar-value-search.js`, which **runs the real module** against a stub of the page in the report rather than reading its source — a search either finds the thing or it does not. Ten checks, mutation-tested against all three ways the fix could be undone.
- **Four more mocks archived** — Media Studio — the calm pass, Theme Styles — icon rail, Button surface shade and Bricks Theme Styles — and the **sub-collections mock restyled** to MV's own look. It never inherited the calm block; it was written in the calm idiom, so there was nothing to cut. Panels, cards, the dialog, the mini rail and every field and button are bordered on the product's palette now.

## v1.3.543 — The calm pass is gone from everything that still carried it

- **What was actually left, measured rather than guessed.** Comparing v1.3.502 — the last build before the pass — with v1.3.511 rule by rule shows the pass only ever touched `.ve-media-studio` selectors, the media right-click menu and the update scrim. Those went back in v1.3.539/540, v1.3.541 and v1.3.542. My own v1.3.539 note claimed the pass had “removed borders across other surfaces”; that was wrong, and the diff says so.
- **What remained was styling born calm.** The shortcuts feature (v1.3.497/498) and the update dock (v1.3.499/500) were written while the pass was in force, so they never had an edge to lose. The chord chip and the cheat sheet are bordered surfaces now, on `#1b1b1b` with `0 18px 42px rgba(0,0,0,.55)` — the values `.ve-context-menu` has always used. A rejected chord reddens its edge.
- **Settings → Shortcuts reads as rows and controls again.** Each row carries a hairline, a clashing row tints it amber, the key caps are drawn the way the product draws a cap (1px edge on `#282828`), capture lights the edge lime, and the foot is divided by a rule instead of an inset shadow.
- **The two documents that decide the next port are back to their originals.** The component library carried the whole pass as an appended override layer plus a depth block written to compensate for its flatness; both are gone, so the library is the bordered original again and is the source of truth. The same inherited block was cut from **19 mocks**. The two mocks that propose the calm pass itself are left as they are — they are the record of what was rejected.
- The removed layer is kept in full at `docs/mocks/.snapshots/2026-08-17-pre-calm-revert/`, and the update mock now defines `--err-ink` and `--info-ink`, which it used but never declared.

## v1.3.542 — The update UI goes back to its approved mock

- **The pill and the ledger are bordered panels again.** Direction D of the approved mock draws both as `#1c1c1c` under a 1px edge with one soft shadow. The calm pass took that edge off and put an inset highlight in its place, which is the flat look the owner rejected. The edge is back, the highlight is gone, and on the pill the edge is also the state: it lightens on hover, greens on success, reddens on failure.
- **The tinted blocks carry a tinted edge again.** The amber “this will disturb your work” note, the red failure note and the blue hold note each sit on a matching border at the mock's 5px radius instead of a borderless wash.
- **The two hairlines came back as hairlines.** The ledger foot and the actions row were separated by inset shadows; they are 1px rules again, and the release notes sit in a bordered recess rather than a black well.
- **Two buttons, one height.** `.ve-btn-g` sets no size of its own, so “Dismiss” and “Later” stood 38px tall next to a 30px primary. Both are 30px now.
- **The mock itself is back to the approved design.** It had inherited the calm block and then a depth block written to compensate for it. Both are gone, so the reference the plugin is checked against is the one that was approved. The reverted state is kept at `docs/mocks/.snapshots/2026-08-17-pre-calm-revert/`.
- Positioning is untouched: the v1.3.531 clearance and the v1.3.533 centring on the launcher are both held by contract.

## v1.3.541 — Chip delete, the doubled chip, and the menu in MV's own style

- **Deleting a token chip does something now.** The two-press confirm kept its state on the button element, and `renderExistingAttributes` rebuilds the whole list on every refresh — so anything that refreshed between the two presses handed back a brand-new button in the idle state, and the second press only re-armed the confirm. Delete could never be reached. The pending state is keyed by name now and survives the row being rebuilt.
- **`delete class` no longer fails silently.** The delete parser consumed the word `class` as its global-class marker and then reported “Missing name to delete.” It only takes that branch when a name actually follows, so `delete class` removes an attribute named class while `delete class my-class` still means the global class.
- **The doubled chip text is gone.** `beginInlineEdit` left its input in the DOM on commit, trusting the re-render to replace the row. Where that re-render did not reach the row, the stale input sat on top of the value it had just set. The input is now always swapped back before committing.
- **The media right-click menu matches MV's own menus.** It carried the calm-pass palette — `#2e2e2e`, no edge, 11.5px at 400 — while everything else went back. It now matches `.ve-context-menu`, the collection menu that has always been in the product: `#1b1b1b` on a 1px edge, `--ve-radius-lg`, 30px rows at `--ve-font-xs`/600, the accent on hover and red on the destructive row. Positioning is untouched.

## v1.3.540 — Media Studio is back to its pre-calm design

- Compared against **v1.3.502**, the last build before the calm pass began, rule by rule rather than by eye. Of the Media Studio rules that had changed since: **52 added by the calm pass are removed** and **53 restored to their v1.3.502 bodies**. Verified afterwards: zero Media Studio appearance rules still differ from v1.3.502.
- Kept deliberately, because they are function rather than styling: the right-click target ring, the masonry layout generations, the layout guard that stops the details panel being clipped, the grid template that makes tiles fill the width, and the floating-dock offsets. 140 rules in total were classified as function and left alone.
- Nothing was deleted that v1.3.502 did not have — the diff showed no rules removed between 502 and here, so this is a restoration rather than a strip.

## v1.3.539 — The flat styling is reverted

- At the owner's request: the new style read too flat, so it is gone. Two things were removed.
- **The v1.3.528/529 Media Studio alignment block** — 4.3 KB that set the panel levels, body text colour, field fills, and a border default-with-keep-list that stripped outlines from everything in the studio. Outlines, tones and radii return to what they were.
- **The v1.3.511 type blanket** — it forced 11.5px at 400 on everything in the studio and named a handful of sizes back. That blanket is what flattened the type; the original ramp's own rules were never deleted and apply again now. v1.3.527's specificity fix is therefore moot and came out with it.
- **Not reverted:** the earlier calm-pass builds, v1.3.503–511, which also removed borders across other surfaces. Those are woven through the stylesheet rather than sitting in one block, so they are a separate job — say the word and they go too.
- Both removals are recoverable from git history or the `mv-wp-v1.3.529` package if any single piece is wanted back.

## v1.3.538 — The launcher stacks in a column with the ACSS icon

- MV sat above the Automatic.css icon but not in line with it. ACSS is at `right:10` and 35 wide, so its centre is 27.5px in; MV at `right:16` and 36 wide is 34px in — a 6.5px offset, close enough to read as a mistake rather than a choice.
- The launcher now takes the detected dock's own centre line via `--ve-fab-right`, so the two stack as a column. Measured in a real browser: ACSS centre 27.5px from the right, MV 28px — aligned within rounding, MV above with a gap.
- With no dock present it returns to 16px and does not shift sideways, and a dock hugging the edge cannot push the launcher off screen.
- The update pill now keeps its clearance from wherever the launcher ended up, rather than from a hardcoded 68px.

## v1.3.537 — The dock scan stopped before it reached the dock

- Fourth attempt, and the first one with the actual cause. The scan capped itself at **4000 nodes**. A Bricks builder page is far larger than that, and a plugin's dock is appended near the **end** of `<body>` — so the walk gave up before it ever reached `<acss-dashboard>`.
- Every test I wrote passed because my test pages had a handful of nodes and never reached the cap. Reproduced in a real browser on a 6,500-element page with the dock appended last: the old scan walked 4,001 nodes and returned `16px`, which is exactly what the owner's console showed. Without the cap, scanning from the end, it returns `57px` in **one** read, in 22ms.
- The cap is gone. The scan now collects references (which costs no layout), reads **from the end backwards** — where a late-appended dock actually is — and bounds itself by a 40ms budget instead of by giving up on nodes. Shadow roots are always followed.
- The three earlier attempts blamed shadow DOM (v1.3.533, real but not sufficient), then observer timing (v1.3.534), then poll timing (v1.3.536). All three were shipped on reasoning rather than a reproduction. This one was reproduced first.

## v1.3.536 — MV finally floats above the ACSS icon

- Third attempt, and this time from the owner's measurements rather than my assumptions. `.acss-dashboard-icon` is 35×35 at `right:10 bottom:10`, pointer-events auto, visible — it passes every filter the scan applies. And `--ve-fab-bottom` read `16px`, which means the scan had already run and the element was not there yet.
- **A MutationObserver on `document.body` cannot fix that**, which is why v1.3.534 did not. `<acss-dashboard>` is in the body early, so the observer fires while its shadow root is still empty, and the later mutation that fills the shadow root never crosses the boundary — shadow mutations do not reach an observer watching the document.
- Replaced the timing guess with a bounded poll: every 1.2s for 30s, stopping the moment a dock is found. Twenty-five scans of a capped node list is cheap, and unlike a timing guess it cannot miss a dock that mounts whenever it likes. The observer stays for the light-DOM case.
- Verified against the owner's exact viewport and corner, including the empty-then-filled shadow root, and against the three other floating elements in that corner which must keep being ignored: MV's own launcher, its off-screen panel, and a click-through toast.

## v1.3.535 — Reload the builder is never a silent no-op

- Cancel Bricks' unsaved-changes prompt, save, then press **Reload the builder** again and nothing happened — the second reload was dropped somewhere between the click and the navigation, with no prompt and no error.
- Three steps now, each covering the previous one's failure: the reload leaves the click frame (Bricks runs its unload guards synchronously inside it), then a plain navigation to the same URL, and if the page is still there the ledger says so and names Ctrl+R. A button that does nothing twice is worse than one that explains itself.
- I have not found *why* the browser drops the second reload. This makes the button honest rather than claiming the cause is understood.

## v1.3.534 — Enter edits a chip, and a late dock is still found

- **Enter on a token chip opens it for editing.** It called `app.apply()` instead — and the input is empty when focus is on a chip, so applying could only fail with “Type at least one attribute.” There was no keyboard route into edit mode at all. Enter now dispatches the chip's own click, which is what its tooltip promises and keeps the two from drifting apart.
- **A foreign dock that mounts late is now found.** The re-measure timings in v1.3.531/533 were a guess, and the guess was wrong: Automatic.css mounts its dashboard as a Svelte app and can attach its shadow root after the last check had already run, so MV measured an empty corner and stopped looking. It watches for added nodes instead, debounced, stopping as soon as it finds something and giving up after a minute so a busy builder is not re-measured forever.

## v1.3.533 — Pasted classes, the ACSS icon, and one centre line

- **Pasting `class="section-shell__surface"` now adds the class.** Parsed literally it read as an attribute assignment, so the bar would have SET the class attribute — clobbering the element's existing classes and storing the whole string as one name. A pasted class attribute is rewritten into the bar's own syntax before parsing, so `class="a b c"` adds three classes. Only a class attribute is rewritten; `data-x="y"` still means an attribute.
- **MV's launcher now clears the Automatic.css icon.** v1.3.531 measured nothing because ACSS puts its launcher inside `<acss-dashboard>`'s open shadow root, and `querySelectorAll` does not pierce shadow DOM. The scan descends into shadow roots now. Measured from the owner's inspector: `.acss-dashboard-icon`, fixed, `right:10px` `bottom:10px`, 35×35 — MV settles at 57px.
- **The update pill and the launcher share one centre line.** They were bottom-aligned, and the launcher is 36px while the pill is taller, so their centres never matched. The pill is centred with a translate on a percentage of its own height, so it stays centred whatever it grows to.

## v1.3.532 — Reload the builder works

- **Reload the builder and Later did nothing.** `handleOutsideClick` runs on `pointerdown` in the capture phase, and the update dock renders outside every panel — so pressing a button in the ledger counted as clicking *outside*. The handler closed whatever studio was open, Preact re-rendered, and both buttons were unmounted between `pointerdown` and `click`. The click had nothing left to land on.
- The dock is on the exemption list now, alongside the toasts and the WordPress media frame. That list already existed for exactly this reason — its own comment says a surface sitting outside a panel must be excluded or interacting with it silently closes whatever is open. The dock was missing from it.
- The scrim still collapses the ledger; it has its own handler and is unaffected.

## v1.3.531 — The floating docks stop colliding

- The update pill sat at `right:20px`, directly over the 36px launcher at `right:16px`, so while an update was pending the launcher could not be reached. It now sits at `right:68px` — clear of the launcher with a gap the same size as its own offset.
- **MV's launcher now steps above another plugin's dock instead of covering it.** Automatic.css parks its own launcher in the same corner. No vendor class is matched, because guessing one breaks the next time a plugin renames something: MV measures instead. Anything fixed, visible, clickable, parked in that corner and small enough to be a launcher rather than a panel counts, and MV clears the tallest of them.
- Re-measured twice after boot, since a dock mounted by another plugin can appear after MV does, and on resize. A measurement that would push the launcher more than 60% up the viewport is discarded rather than sending it somewhere unreachable.
- Verified against ten synthetic corners, including the six it must **not** react to: MV's own launcher, a full-screen overlay, a bottom-left dock, a hidden one, a click-through decoration, and an absurd measurement.

## v1.3.530 — Enter applies a suggestion in Mimam's Bar

- Pressing Enter on an autocomplete suggestion filled the input and stopped there; the Apply button was the only way to finish the command, while the bar's own hint row promises apply on Enter.
- `handleCommandSuggestions` treated Tab and Enter identically — both called `accept()` and then `return true`, which consumed the event before it could reach the `app.apply()` branch a few lines below. Tab now completes, Enter completes **and** applies.
- One exception, deliberately: a suggestion that hands back a selected placeholder — an attribute's `=""` with the caret inside it — is not a finished command, so Enter completes that one and waits instead of applying half of it.

## v1.3.529 — The outlines actually go this time

- v1.3.528 named five classes and reached almost nothing: the search fields, the toolbar selects, the Collection Details buttons, the metadata fields and the file rows all kept their outlines. Naming classes cannot finish the job — the borders come from around forty rules written across two years, most of them global and many with `!important`.
- Replaced with what rule 1 actually is: **a default with an explicit keep-list**. Everything inside Media Studio loses its border; the keep-list is the point, and it survives — spinners, check boxes and radios, the checkerboard, colour swatches, the upload bar, the drop zone's dashed edge, table rules, artwork, every `:focus` ring, and anything in an on/active/selected state where the accent *is* the edge.
- Fields and buttons take a `rgba(255,255,255,.05)` fill so they stay findable without an edge, and the accent returns on focus.
- Carried on `#ve-panel-root` so it outranks the global `!important` rules it has to beat, with `:where()` keeping the exclusions free so any rule naming an element specifically can still put an edge back.

## v1.3.528 — Media Studio matches the calm mock

- **Depth is right way up.** The tile was `#101010` on a `#0e0e0e` well — darker than the surface it sat on, so tiles sank into the grid. They are `#242424` now and rise out of it, which is what the mock has and why the calm pass kept reading flat.
- **Levels:** well `#0e0e0e` < panel `#1a1a1a` < raised `#242424`. The shell, the rail and the details panel all sit at panel level; the build had them at `#151515`.
- **Body text** `#dedede`, not `#f1f1f1`. Named greys (meta `#6f6f6f`, dim `#9a9a9a`) keep their own values.
- **Fields are fills, not outlines.** Inputs and menu buttons take `rgba(255,255,255,.05)` at 6px radius, and the accent returns on focus — the one state where an edge means something.
- **The decorative edges are gone.** 633 non-accent solid borders were measured on the running panel; the icon buttons, list dividers, overview and metadata cards lose theirs. **Borders that ARE the component are deliberately kept**: spinners, check boxes, the drop zone's dashed edge, anything on the accent, and every focus ring — v1.3.511 erased the spinners doing exactly this sweep.
- Every selector is scoped to `.ve-media-studio`. Nothing here can reach Content Studio, Theme Styles or the Bricks panels.

## v1.3.527 — Media Studio uses its type ramp (1 of several)

- The studio has rendered **one size and one weight** — 11.5px at 400 for everything — so none of the 13px titles or 10px meta labels the calm mock specifies have been showing. Measured on the running panel: 859 elements, one size, one weight.
- The blanket rule excluded icons with `*:not(i):not(svg):not(path):not([class*="ph-"])…`, and every `:not()` contributes its argument's specificity, so the chain scored (0,4,3) against the (0,2,0) rules that name 13px and 10px back. Both carry `!important`, so the blanket outranked the exceptions it was written to yield to.
- Moving the exclusions into `:where()` costs no specificity, matches exactly the same elements, and puts the blanket at (0,1,0). The exceptions now win.
- **Only this changed.** The remaining gaps to the mock — panel tone, text colour, tile background, input fill, and 633 outlined controls — are each their own build.

## v1.3.526 — The grid columns fill the width

- Measured on the running panel: nine tracks of 126px with a 10px gap in a 1288px content box, leaving 74px that `justify-content:start` parked against the right edge. 126px is the tile plus its 1px borders — the tracks were sizing to their content instead of to `1fr`, so something outranked the base template.
- Re-declared the template at Media Studio scope so it wins. The leftover now goes to the columns.

## v1.3.525 — The grid fills the width on All media

- Fixed the empty strip down the right of the grid. `.ve-studio-main` carried no `flex-grow`, so in the studio's flex row it sized to its content and could not expand. With no file selected on All media there is no details panel, and the width it would have used was left blank instead of going to the tiles.
- One rule, scoped to Media Studio. Nothing else changed.

## v1.3.524 — Reverted to the last good Media Studio

- **This is v1.3.516's code, shipped forward.** Everything structural from v1.3.517 to v1.3.523 is reverted: the CSS extraction, the lazy studio split, the masonry change and the type-ramp specificity change. Media Studio returns to the state it was in before that work.
- What is kept, because it predates the restructure: the right-click menu (v1.3.512–515), the release webhook and the conditional update check (v1.3.516).
- What is lost: the admin-page weight reduction. Every wp-admin page parses the full 1.8 MB bundle again. That is the price of the revert and it is the right price — the work traded a slow page for a broken studio.
- The code editor is styled correctly again as a side effect: it broke because the CSS became a separate stylesheet enqueued before CodeMirror's, and that stylesheet no longer exists.

## v1.3.523 — shipped, then reverted in v1.3.524

- This build corrected the type-ramp specificity. Media Studio regressed across v1.3.517–523 — masonry, the details pane and the type ramp — so v1.3.524 returns to v1.3.516’s code. Recorded because it shipped.

## v1.3.522 — shipped, then reverted in v1.3.524

- This build changed masonry tile sizing. Media Studio regressed across v1.3.517–523 — masonry, the details pane and the type ramp — so v1.3.524 returns to v1.3.516’s code. Recorded because it shipped.

## v1.3.521 — shipped, then reverted in v1.3.524

- This build restored the code editor styling and removed the studio open delay. Media Studio regressed across v1.3.517–523 — masonry, the details pane and the type ramp — so v1.3.524 returns to v1.3.516’s code. Recorded because it shipped.

## v1.3.520 — shipped, then reverted in v1.3.524

- This build repaired the panel, which v1.3.519 stopped from loading at all. Media Studio regressed across v1.3.517–523 — masonry, the details pane and the type ramp — so v1.3.524 returns to v1.3.516’s code. Recorded because it shipped.

## v1.3.519 — shipped, then reverted in v1.3.524

- This build split the studios into a lazily-loaded bundle. Media Studio regressed across v1.3.517–523 — masonry, the details pane and the type ramp — so v1.3.524 returns to v1.3.516’s code. Recorded because it shipped.

## v1.3.518 — shipped, then reverted in v1.3.524

- This build made the update check conditional so it stops re-downloading the manifest. Media Studio regressed across v1.3.517–523 — masonry, the details pane and the type ramp — so v1.3.524 returns to v1.3.516’s code. Recorded because it shipped.

## v1.3.517 — shipped, then reverted in v1.3.524

- This build moved the panel CSS out of the JavaScript into its own stylesheet. Media Studio regressed across v1.3.517–523 — masonry, the details pane and the type ramp — so v1.3.524 returns to v1.3.516’s code. Recorded because it shipped.

/* Two findings from that run still stand and are NOT fixed in v1.3.524: the studio
   type blanket’s :not() chain outranks the 13px/10px exceptions it names, and masonry
   carries three generations of layout. Both should be addressed one at a time,
   measured on the running panel, rather than as a restructure. */

## v1.3.516 — Updates arrive when they are published, not when the cache expires

- Added a release webhook. GitHub POSTs to `variable-engine/v1/release-ping` on push, the site clears its update cache and re-reads the manifest within seconds. Polling could only ever shorten the gap; this closes it.
- The endpoint is public because GitHub carries no WordPress cookie, so the signature is the only thing guarding it: inert until a secret exists, HMAC-SHA256 over the raw body verified against GitHub's `X-Hub-Signature-256`, compared with `hash_equals`, rate-limited to one refresh per ten seconds, and able to do nothing except make the site re-read its own manifest. The secret is read from `VE_RELEASE_WEBHOOK_SECRET` in `wp-config.php` first so it need never touch the database.
- The manifest cache is now per channel: Dev falls to 5 minutes, Beta and Stable keep 6 hours. Dev is the channel builds are verified on, and a six-hour cache there meant a build could be published and invisible for most of a working day. This is the floor for sites without a webhook, or that missed a delivery.
- Fixed wp-admin keeping MV's layout after MV had let go of it. The Media Library replacement sets `padding-top` and `margin-top` on `#wpbody-content` and its cleanup put the panel back without restoring them.

## v1.3.515 — Right-click aims the menu, it does not select

- Right-clicking a file no longer ticks its checkbox, opens the batch bar or fills the details panel. Three side effects nobody asked for, and the third made "Open in the side panel" a row that had already happened before you could read it.
- The tile the menu belongs to now carries a dashed ring instead — which is what the approved mock specified all along (`.tile.ctx`, outline 2px dashed). The build had substituted selection for it, and the mock alignment pass in v1.3.513 checked the rows without checking this.
- Right-clicking inside an existing selection still acts on all of it, so the plural labels stay truthful. Right-clicking outside it acts on that one file and leaves your selection exactly as you left it.

## v1.3.514 — The right-click menu was throwing, not hiding

- `ctxRows()` called `collectionLabel()`, which has never existed anywhere in the codebase. Building the "Add to collection" submenu threw a ReferenceError, the Preact render died with it, and the menu never reached the DOM. This is the real reason right-click did nothing, and it was there from the first build. The correct function is `collLabel()`, three lines away in the same component.
- It stayed invisible for five builds because the throw surfaced only as an unhandled promise rejection inside Preact — no red error at the point of failure, no missing element to inspect, and nothing wrong in the source when read line by line. It took a console probe on the running panel to see it.
- v1.3.513's positioning work was a real defect and is kept: `position:fixed` inside a transformed panel was re-based and then clipped, and it would have bitten the moment the throw was fixed. But it was not what was blocking the menu, and this build corrects that claim.
- The contract check now resolves every identifier `ctxRows` calls against a definition in the file, so an invented helper fails the build instead of failing silently at runtime.

## v1.3.513 — The right-click menu was never missing, only off screen

- Fixed the media right-click menu properly. It has rendered correctly since v1.3.512, at the coordinates the cursor reported, and was then drawn inside a panel that had quietly become its frame of reference. Media Studio is excluded from the `transform:none` reset, so its panel keeps a transform; a transform makes an element the containing block for every `position:fixed` descendant inside it; and v1.3.509 gave the studio `overflow:hidden`. A menu placed at x 1180 landed 1180px inside an 880px panel and was clipped away.
- It worked in fullscreen the whole time, because fullscreen sets `transform:none`. That is what made four builds read as intermittent rather than wrong, and why reading the source kept concluding the fix was already in — each of those builds was correct about the thing it changed and silent about the frame it was drawing in.
- The menu is now absolute against the studio box, the frame the collection menu has always used and the one part of this area that never broke. Flip, clamp and the submenu all measure in that frame; mixing client rects with `window.innerWidth` was half of how this survived so long.
- Right-click answers only in the studio it belongs to. Media Studio is mounted more than once — the Content Studio picker and the standalone panel — so a listener on `document` meant one click opened a menu in each.

## v1.3.512 — Right-click actually reaches Media Studio

- Fixed the media context menu never opening. The listener sat on document in the bubble phase, and Media Studio’s own collection menus — plus several WP-admin and Bricks handlers — call stopPropagation on contextmenu, so it was being silenced before it was ever reached. It now listens in the capture phase, which runs on the way down before anything can stop it.
- Guarded the target as well: a right-click can land on a text node or the document, where closest() does not exist. That threw inside the listener and killed it silently for the rest of the session.

## v1.3.511 — The Media Studio type ramp, in one sweep

- Replaced four builds of per-class type fixes with a single rule. Most of what was still off the ramp reported no class at all, so no targeted selector could ever reach it — chasing them one at a time could not finish.
- Rule 4 is a default with exceptions, so it is written that way now: everything in the studio takes 11.5px at 400, then 13px is named back for titles and the overview numbers, 10px for meta, and 600 for emphasis and for what is on.
- Icons are excluded by name rather than left to luck. A glyph is artwork standing in for a control and needs its pixel size — 10, 14, 15 and 18 are all deliberate — and rule 0 warns that a blanket sweep is unsafe wherever the thing being swept is sometimes load-bearing.

## v1.3.510 — The last of the Media Studio type ramp

- Closed out the type ramp using a computed-style sweep of the running panel rather than the stylesheet. Reading the source had said the pass was finished twice; the render disagreed both times. Remaining sizes were 9, 10.5, 11, 12 and 14 at weights 400, 600, 650, 700 and 800.
- COLLECTIONS and the remaining uppercase labels are sentence case. The MV collection badge keeps its capitals — it is an acronym, which rule 5 exempts — but comes off 9px/650 and loses its letter-spacing.
- Inputs, menu buttons, small buttons, the list preview, the dropzone and the sidebar actions all move onto 11.5px. A blanket text-transform and letter-spacing reset covers the labels that carry no class of their own and so could not be reached any other way.

## v1.3.509 — Collection details no longer pushed outside the modal

- Fixed the Collection details panel being clipped by the right edge of Media Studio. Measured in the live studio, the layout ran to 2039px against a modal edge at about 1789 — 250px of the third column outside the window.
- The middle column was already able to shrink (min-width 0, overflow hidden) but the layout around it was not: a grid child defaults to min-width auto and refuses to go below its content width, so the overflow was pushed onto the last column instead of being absorbed by the middle one. The layout is now guarded, which is what lets the file list give up width when details opens.

## v1.3.508 — List view headers and the alt-text field

- Styled the three list header cells the pass had missed. Only .ve-list-meta had been targeted, so PREVIEW, FILENAME and ALT TEXT (AUTO-SAVES ON BLUR) stayed 9px/800/uppercase sitting beside sentence-case neighbours in the same row.
- The inline alt-text field in list view is a field rather than a pill: it takes a fill instead of an outline, and the accent only on focus.

## v1.3.507 — Media Studio: the rest of the calm pass

- Completed the Media Studio pass across the surfaces v1.3.506 did not reach: masonry cards, the collection-details panel and its status cards, the filter builder and saved filters, the list column chooser, collection chips and the empty state. All of these already existed; what was missing was the pass reaching them, so the shell had moved while they had not.
- Collection details keeps its accent because the hero marks a state, but the fill stops shouting and its status cards recess into the panel holding them rather than sitting outlined on it.
- Filter pills, choices and the search field lose their outlines for fills; the active choice takes the accent, which is the one thing in that row that means state.
- The empty state is no longer the dimmest thing on screen — it is the one place with nothing else to look at.

## v1.3.506 — Media Studio shell to the UI rules

- Media Studio’s shell now follows docs/UI-RULES.md, completing what v1.3.503 started on the tiles and metadata cards. The rail and details panel sit at panel level while the grid recesses to a well beneath them, so the studio has a floor and things standing on it rather than one flat plane.
- Overview cards rise out of the grid instead of sinking into it. They were dropping 0.9 L* while the tiles beside them rose 10.2 — the same container moving two directions at once, which is what made that band read flat.
- Cut the shell to three type sizes at two weights, and replaced the uppercase letter-spaced micro-labels (Collections, Total media, Alt text, Metadata, Shortcode) with sentence case.
- Lifted the dim text colours, which measured 2.8–3.8 against a 4.5 contrast floor. Filter and column popovers now step above the panel they float over instead of matching its tone.

## v1.3.505 — The update dock speaks the surface it is on

- The update dock no longer says “Reload the builder” in wp-admin, where there is no builder. Five strings now follow the surface: the button reads Reload the page, and the ledger says this page rather than the builder is running the previous files.

## v1.3.504 — Update scrim, and right-click in every Media Studio view

- The update ledger now dims and blurs the page behind it once an install has finished or failed, so the decision it is asking for stops competing with everything else. A running install still leaves the page usable, which is the whole point of the corner pill.
- Right-click now works in all three Media Studio views. The menu was attached to the grid containers, so the list table — rendered by a different function — never answered. The listener now sits on the document while the studio is mounted, and list rows carry their id.

## v1.3.503 — Media Studio right-click, and the calm pass

- Right-click a file in Media Studio. Twelve rows reaching every per-item action MV has: open in the panel or the WP editor, copy the URL, copy as file path or HTML tag, insert into a Bricks control, replace, convert, add to or remove from a collection, download, delete.
- The primary verb stays flat and its variants fold — Copy URL is visible with File path and HTML tag behind Copy as, and Convert to holds the three formats. Nothing is reachable only by guessing.
- Right-clicking outside the selection takes it over; right-clicking inside keeps it, so a plural label is always truthful. Delete keeps its confirmation dialog. Text fields keep the browser’s own menu, where Paste and spellcheck live.
- The menu flips rather than clips near a viewport edge, and caps its height so the full list stays reachable in a short builder window.
- Media Studio now follows the MV UI rules: tile outlines became lifts so depth comes from lightness, cards recess inside the panels holding them, and the type came down from six sizes and weights up to 900 to three sizes at 400 and 600.

## v1.3.502 — One shortcut registry and a Shortcuts settings page

- Every rebindable key now comes from one registry (assets/js/shortcut-registry.js) instead of being decided inline where it fires. Settings → Shortcuts lists all thirteen, each with its keys, scope and on/off switch on one line.
- Click a shortcut’s keys and press what you want. Chords take a single letter, modifier shortcuts take the combination you hold. The leader key and the chord window are editable, and one button restores every default.
- Chords are now a single state machine rather than a timestamp field per shortcut. R R renames and U U unlinks as before; ? ? opens a cheat sheet; G plus a letter opens a panel and ships off, so a new install claims no letter you did not ask for.
- Enabling a chord claims its letter: the lone press is swallowed so Bricks cannot act on it. Letters Bricks already uses are marked amber on the settings page while you choose, rather than being blocked outright.
- An armed chord shows a chip at the bottom of the screen naming the key it is waiting for. After the leader, a letter bound to nothing is shown as rejected; a lone letter that leads nowhere is simply forgotten.
- Each shortcut carries its own Builder / Admin / Both scope, so the selection chords stay in the builder while the panel ones can work in wp-admin.

## v1.3.501 — Upload failure toast dismissal

- Dismissing a failed upload no longer depends on CSS :has(). The failure toast stops auto-hiding so its reason can be read, so the close button has to work everywhere the builder runs.

## v1.3.500 — Update dock visual pass and Media Studio font uploads

- Rebuilt the update install dock to the approved Variant D visual pass: depth comes from surface lightness rather than outlines, so the pill and ledger sit above the builder canvas instead of reading flat against it.
- Cut the dock to three type sizes and two weights, and left edges only on the eight step dots, where the border is the control.
- Success and failure now read from the progress ring alone, so the accent marks state and nothing else. The final install stage is "Finishing up".
- Font files (WOFF2, WOFF, TTF, OTF) can be uploaded through Media Studio. WordPress allows no font type in the media library, so every font dropped on a Fonts collection was rejected. Scoped to Media Studio uploads by a user who may already upload files, with a format-signature check on each file.
- A failed upload states its reason instead of reporting only a count, and stays until dismissed.

## v1.3.499 — Update decision dock and contained Quiet cross

- Routine plugin installs stay in a corner progress pill; failures and successful installs open the named step ledger when a decision is needed.
- Successful installs show current release notes and require an explicit Reload the builder or Later choice.
- Theme Styles T/R/B/L fields now share one responsive width and stay inside narrow panels.

## v1.3.498 — Complete Quiet cross interaction

- Restored equal edge inputs, separate resting number/unit presentation, focus editing, unit-aware scrubbing, fill, explicit units and linked propagation.

## v1.3.497 — Quiet cross and Calendar Unscheduled rail

- Added the approved Theme Styles Quiet cross and Content Studio Calendar's draggable Unscheduled rail.

## v1.3.496 — Delayed module-state responses stay stale

- Prevented older Settings responses from restoring a module after a newer toggle.

## v1.3.495 — Immediate module state and Site Visibility handoff

- Applied module switches immediately and repaired the Bricks Settings Site Visibility handoff.

## v1.3.494 — CSS Studio can close and the shared picker stays canonical

- CSS Studio's unsaved-change confirmation now sits above the Studio backdrop and panel, keeping its discard/keep-editing actions clickable from both backdrop and header-close requests.
- Content Studio no longer overrides the shared colour picker's format buttons; the selected format, dimensions and light/dark styling match the canonical component.

## v1.3.493 — Shared autocomplete and reliable module switches

- Every MV CSS editor shares one preloaded autocomplete index that refreshes after variable changes without duplicate concurrent requests.
- Admin and Builder module switches apply an explicit atomic surface update, so enabling CSS Recipes or another module does not overwrite the other rail.

## v1.3.492 — Public framework variables return to autocomplete

- Variables explicitly registered in Bricks/Advanced Themer, Core Framework and Automatic.css are suggested alongside MV and CSS Studio variables.
- Provider variables preserve their literal CSS names and do not collapse together through migration family normalization.
- Arbitrary provider settings and internal plugin/theme styles remain excluded.

## v1.3.491 — Autocomplete and migration use separate indexes

- Normal CSS suggestions now contain MV variables and CSS Studio declarations, not framework variables registered by Bricks, Advanced Themer or migration providers.
- Advanced Themer framework classes are excluded by their structured provenance flag while user-authored Bricks global classes remain available.
- CSS Studio custom-property names retain their first character during normalization.

## v1.3.490 — Bricks suggestions use explicit authored stores

- Server autocomplete reads only Bricks global classes, global variables and theme styles rather than every `bricks_%` option.
- Unrelated Bricks settings can no longer contribute implementation variable, class or ID names.

## v1.3.489 — Autocomplete indexes authored site names only

- Live page CSS still resolves the effective value of a known authored variable, but it can no longer contribute new variable names.
- WordPress admin, theme, Bricks and MV interface classes/IDs are no longer collected from the current DOM or loaded stylesheets.
- Server suggestions no longer scan generated framework CSS, theme/plugin source files, templates, taxonomy slugs, generic plugin options or third-party snippet tables.

## v1.3.488 — Autocomplete stays inside the editor and suggests usable variables

- Suggestion menus now clamp to the owning CodeMirror rectangle rather than the full browser viewport.
- MV interface styling variables are excluded from the site/design-variable pool.
- Reference-only and unresolved names are removed, so variable rows have an actual authored or live value.

## v1.3.487 — Autocomplete is stable, contextual, and viewport-safe

- Active completion updates are no longer reopened on each keystroke, removing the visible jump and double refresh.
- Property/value/variable lists share one width, remain inside the viewport, flip above when needed, and never scroll horizontally.
- Variables appear only after `--`, `var`, or `var(`; ordinary value typing stays focused on CSS values.
- MV and detected external variable values/sources now come from the suggestion endpoint, with live computed values filling remaining gaps and defined variables ranked first.

## v1.3.486 — Hidden autocomplete lists are restored

- Live Firefox console evidence showed the correct hint node had `display:none` and a 0×0 rectangle; the backdrop warning was only the result of probing that empty rectangle at `(0,0)`.
- The active list now forces `display:block!important`, clears stale popover state, and is measured only after it is displayable.
- Hidden and zero-size states are reported directly instead of being misclassified as stacking overlap.

## v1.3.485 — Autocomplete uses a root-level viewport portal

- Removed the Popover API path that still failed in the live Theme Styles panel.
- Suggestion lists now render in one direct-body fixed portal, outside transformed panel coordinate systems and above MV's studio backdrop.
- Placement targets the active CodeMirror widget's own list, keeps that list hit-testable, and exposes `mimamVarInspectAutocomplete()` for live console evidence.

## v1.3.484 — Autocomplete suggestions appear beside the caret

- The top-layer suggestion list now applies caret coordinates at the same cascade priority as its `inset:auto!important` reset, so it no longer collapses into a thin strip at the top of the viewport.
- The list remains above MV's studio backdrop and is hit-testable beside the editor caret.
- MV no longer blames another plugin when its own suggestion display audit reports a failure.

## v1.3.483 — The suggestion list renders in the browser top layer

- The list is promoted to the top layer, which paints above every stacking context regardless of z-index, ancestry or filters.
- It is placed at the caret in viewport terms, since the top layer is positioned against the viewport.
- Browsers without the top layer fall back to the previous behaviour.

## v1.3.482 — The suggestion list moves inside the panel

- The list is hosted by the panel that owns the editor instead of the page body, so MV's blurred studio backdrop can no longer paint over it.
- The container stays hit-testable, so the visibility check reports the truth.

## v1.3.481 — Lift the suggestion list clear of whatever covers it

- The list is raised to the top of the stacking range and moved to the end of the body, so a tie or an ancestor stacking context cannot bury it.
- If something still covers it, the panel names that element instead of describing it vaguely.

## v1.3.480 — The suggestion list can no longer hide behind the panel

- Visibility is confirmed by asking what is painted on top, not by position alone.
- A covered list is lifted clear, and reported if it stays covered.
- The list outranks every MV surface by default.

## v1.3.479 — A suggestion request can no longer end in silence

- Every empty suggestion list now names its cause in the panel instead of looking like nothing happened.
- A list that opens outside the viewport is pulled back to the caret.
- Producing suggestions that never reach the page is reported rather than swallowed.

## v1.3.478 — MV pins its own CodeMirror

- MV keeps a reference to the CodeMirror build it verified, so another plugin taking over window.CodeMirror can no longer leave the editor without autocomplete.
- A suggestion list that cannot open now says so in the panel instead of failing silently inside a timer.

## v1.3.477 — Every code editor is MV’s own CodeMirror

- MV loads its bundled CodeMirror when the page has none, instead of sniffing for a link tag and degrading to a textarea.
- Another plugin's unscoped CodeMirror stylesheet no longer counts as MV's own.
- If the plain textarea is ever reached, the panel says so instead of impersonating the real editor.

## v1.3.476 — Module toggles apply immediately

- A module switch no longer reverses when an in-flight settings request finishes with older data.
- Each MV runtime derives its own surface list from a complete snapshot instead of the sender guessing.

## v1.3.475 — Suggestions in wp-admin, box control at any width

- The CodeMirror hint container is pinned to the viewport, so suggestions appear in wp-admin, not only in the Bricks builder.
- The theme style box control is a grid, so a pinned group rail can no longer squash it or push a field outside the band.
- The box centre names the element instead of showing the internal "all" token.

## v1.3.474 — Box control, picker card, shared suggestions

- Theme style box controls draw the spacing as a band around the element, with each field on the band it controls.
- The highlight colour picker has its card back; every picker host now shows exactly one.
- Every CodeMirror in MV shares the same suggestion pool.

## v1.3.473 — Light mode reaches the whole colour picker

- Every colour picker element now has a light-mode counterpart, including both alpha checkerboards and the alpha percentage box.
- The Content Studio swatch border override now matches the !important it competes with.
- A regression check enumerates the whole picker instead of spot-checking one rule.

## v1.3.472 — Suggestion values and per-control history

- CSS Studio suggestions show each variable's preview, resolved value and source instead of the bare name.
- Alias chains resolve to their final value; cycles and undefined tokens are reported rather than guessed.
- Bricks Theme Styles: undo, redo and clear on every control, and on each group as a whole.
- Typing collapses into one undo step instead of one per keystroke.

## v1.3.471 — Variable menu stacking

- An open ⚡ variable menu now sits above the colour rows beneath it. The row wrapper's own z-index made it a stacking context, capping the menu inside that row.

## v1.3.470
- The selected recent-colour ring is no longer clipped. It was a `box-shadow` painted 2px outside the swatch, and the picker core clips (`overflow:hidden`, with its padding removed inside a popover), so the outer edge was cut off. It is now an `outline` with a negative offset, drawn inside the swatch's own box — impossible to clip and costing no layout — with an inset hairline so it stays visible on a swatch close to the brand colour.

## v1.3.469
- Defined when a colour becomes "recent", and fixed what shipped. It was recorded only when a hex was typed and committed — so dragging the map, the hue or the alpha, or editing a channel field, recorded nothing at all, which is most of how the picker is used. It is now recorded **on close, once per picker session, and only if the colour changed**: not on every edit, because a drag emits hundreds of intermediate colours nobody chose, and not only on a typed hex, because that is the rarest way anyone picks. The stored value keeps its alpha, so a translucent colour comes back translucent.
- The rule is written into the Component Library entry so the next picker host does not have to guess it.

## v1.3.468
- The hue slider keeps its rainbow while you drag it. Exempting ranges from the control-height rules missed two more: a plain `.ve-row input` background and, more to the point, `.ve-row input:focus` — a slider takes focus on pointer-down, which is exactly why it only greyed mid-drag. Ranges are now exempt from those too, and the hue and alpha gradients carry `!important` so no host rule can repaint them. The codebase had already solved this once for an older picker with `.ve-hue`; the shared track now does the same.
- The colour popover stays inside the panel as it grows. The clamp was writing `el.style.top`, but the host renders `left`/`top` from state, so every re-render — changing the colour, typing in the VAR search — wiped the correction and it slid back off the bottom. It now nudges with `transform`, which the host does not manage.

## v1.3.467
- The colour popover now re-clamps as it grows. It was measured once when it opened, so switching to VAR — which adds a variable list — made it taller after the decision had been taken, and it hung off the bottom of the Media Studio panel again. A shared `keepInsideBounds` helper clamps on open and re-clamps on every resize, and scrolls internally when it is taller than its container. The Theme Styles popover had the same staleness deciding which way to open, and uses it too.
- The Variables colour picker closes on an outside click or Escape. It only ever toggled from its own swatch, so once open the only way out was to click the swatch again.

## v1.3.466
- Found the real cause of the oversized colour sliders. `.ve-sr input`, `.ve-row input` and `.ve-ren input` force every descendant input to the 38px control height with `!important` — correct for text and number fields, wrong for a range. The Variables panel is the only host that wraps the picker in `.ve-row`, which is why its two sliders rendered at 38px while every other picker looked right, and why the track's own `height:14px` never applied: it carried no `!important` and lost on specificity.
- Ranges are now exempt from those three blanket rules, and the picker track asserts its own height so a future host cannot override it the same way.
- Three checks pin it, including one that fails if the exemption is removed.

## v1.3.465
- Reworked the alpha slider after measuring it instead of eyeballing it. Two separate causes: the % readout was 20px while the hue row is 18px (its thumb, not its 14px track, sets the height), and the track carried the same 10px / 20%-contrast checkerboard as the 34px swatches — which in a 14px bar is 1.4 rows of loud squares, reading as a block rather than a slider. The readout is now 18px, so both rows match exactly, and the track checker is 6px at 4% contrast: texture instead of pattern. Light mode gets the same treatment.
- Two checks pin both: the readout may not be the tallest item in its row, and the thin track may not reuse the swatch checker.

## v1.3.464
- Connected the transparency slider in Theme Styles. It was passed `alpha:1` with a no-op `onAlphaChange`, so it rendered and moved but reported nothing and always snapped back to 100%. Alpha is now read from and written to the stored value as an eight-digit hex, which Bricks resolves straight into CSS.
- The Theme Styles swatch now shows translucency, layering the colour over a checkerboard instead of replacing it — so a half-transparent colour is distinguishable from an opaque one.
- Added two checks rejecting a no-op `onAlphaChange` or a hard-coded `alpha:1` in any picker host, since every host that shows the picker shows the slider.

## v1.3.463
- Fixed the colour popover overflowing the Theme Styles panel. It was a fixed 316px, which fitted the old full-width body but not the 270px left once the new group rail is pinned (468 − 150 − padding), so the panel scrolled sideways. The popover now anchors to its field row and is exactly as wide as the space available, at any rail width.

## v1.3.462
- Fixed the rail icons properly. A Phosphor icon is a font glyph drawn on a `::before` pseudo-element; I had put `display:grid` on the `<i>`, which turns that pseudo into a grid item and lets the default line-height inflate the box — so every glyph rendered low and read as two marks stacked above its label. The existing studio tool rail already had this right: flex-centre the button and give the `<i>` nothing but a size and `line-height:1`. The rail now matches it.
- Contract check extended to reject `display:grid` on the glyph and require `line-height:1`, so this cannot come back.

## v1.3.461
- Fixed the rail's stray squares. The set-dot is rendered as an `<i>`, and the rail's icon rule targeted every `<i>` in a button — so each dot was being sized as a 19px icon box. The rule is now scoped to the Phosphor glyph.
- Removed the native tooltip on rail buttons, which duplicated the label the rail already reveals on hover.
- Hovering the rail now fits the longest group name instead of truncating at 150px. Overlaying costs nothing underneath, so hover can be as wide as the text needs; only the pinned width stays fixed, because that one is taken out of the fields — pinned truncates rather than widening the panel.

## v1.3.460
- Theme Styles groups are a left rail instead of a tab strip across the top (id14, mock option D). Ten groups never fitted across 410px, so six were always scrolled out of sight — including the set-dots you were looking for. The rail shows all ten at once in 52px.
- Hovering the rail slides the labels out as an overlay, so the fields underneath never reflow; the pin reserves 150px permanently for anyone who would rather always read the names. The pin state is remembered per user, like the last group already was. It defaults to collapsed.
- Added the rail to the Component Library as `Panel group rail` before porting it, including the note that the collapsed label must be `flex:0 0 0` — `flex-grow` makes it consume the free space even at zero width, which is what pushed the icons off centre in the mock.
- Three contract checks cover it: every group has an icon, the collapsed label cannot grow, and the rail overlays on hover while only the pin reserves width. All three verified to fail when the bug is reintroduced.

## v1.3.459
- Fixed the transparency slider, broken by v1.3.458. Pinning the slider height with `flex:0 0 14px` set its *width* instead, because it sits in a flex row — it collapsed to a dot. The same change had also overridden the alpha row from its intended grid to flex. Both reverted; the base rule already pinned the height.
- Fixed the height that was reported twice: the alpha row was 30px because of the percentage readout, against a 14px hue bar above it, so the block read as twice the height. The readout is now 20px and the two rows share one rhythm.
- Fixed the Media Studio colour popover clipping, made worse by v1.3.458. The popover is `position:fixed` but a `backdrop-filter` ancestor makes the studio its containing block, so it cannot escape the panel — clamping it to the window pushed it under the panel edge. It clamps inside the panel again, using its measured height, and scrolls internally when taller than the panel.
- Added three regression checks covering exactly these mistakes: no flex-basis on the alpha range, the alpha row keeps its grid, and the popover clamps to the panel rather than the window. All three verified to fail when the bug is reintroduced.

## v1.3.458
- Replaced the fixed preset row in the colour picker with recently used colours, shared across every picker and stored locally. When there is no history the row is not rendered at all, so it can never be the line of empty boxes it was in the Content Studio.
- Removed the double frame: the popover drew a border and the picker drew another inside it. The core is now borderless wherever a host already supplies the frame.
- Colour pickers no longer run off the bottom of the screen. The Media Studio popover was positioned from a hard-coded height estimate that VAR and the recent row invalidated; it now measures itself after render and moves back into view. The Theme Styles picker opens upward when there is no room below.
- Pinned the hue and alpha slider heights so they cannot stretch in the wider Variables panel, and stopped the VAR list and its value column overflowing the picker.
- Deleted 31 dead CSS rules targeting a colour picker that no longer exists (`.ve-color-panel`, `.ve-color-map`, `.ve-color-fields`, `.ve-format-tabs`, `.ve-color-dot`, `.ve-rich-popover-title` — all CSS-only, never rendered).

## v1.3.457
- Restored the VAR format in the colour picker. It was dropped on the reasoning that the ⚡ picker replaced it, which was wrong: ⚡ is a shortcut on a field, VAR is a mode of the picker itself. Selecting it swaps the channel fields for a searchable list of MV variables and stores `var(--token)` instead of a literal, with the bound token shown above the search and an unbind control beside it.
- VAR is offered only where the host can store a reference, which is now all four pickers — media collection colours previously accepted six- or eight-digit HEX only and now take a variable reference too.
- Added a shared variable cache so a picker host only has to declare that it can store a reference, rather than fetching its own copy of the variable list.

## v1.3.456
- Fixed the canvas flicker properly. The debounce in v1.3.455 only slowed it down; the cause was double delivery — MV wrote Bricks' store AND posted the same payload to the iframe, and Bricks mirrors every store write to the iframe by itself, so the canvas CSS regenerated twice per keystroke. MV now writes the store only, skips identical payloads, and defers the panel re-render until the value settles.
- Added OKLAB alongside OKLCH in every colour picker. It is derived from the existing OKLCH conversion rather than implemented separately — the same colour in Cartesian instead of polar coordinates — so the two can never disagree.
- Built the Component Library's preset swatch row, which the library had specified for a long time and no picker had.
- Moved "Backdrop behind panels" out of the CSS Studio settings tab into Settings → General beside Studio defaults. It governs nine modules and had no business living under CSS Studio.
- Gave the product one segmented control (`.ve-seg`) matching the Component Library's, and moved the backdrop intensity control onto it. It was inline-styled with its own geometry.
- Reconciled the Component Library colour picker entry with what ships, and recorded why the one remaining difference is deliberate: `VAR` is not a format tab because variables are bound with the ⚡ picker, which searches — a tab cannot.

## v1.3.455
- Theme Styles remembers the group you were last in, and switching between styles no longer throws you back to General.
- Closing MV with unsaved theme style edits no longer leaves them applied in Bricks. The live preview writes to Bricks' store, so an abandoned edit stayed on the canvas and in Bricks' own panel while MV had already discarded it; the saved state is now restored on close, on Reset, and on unmount.
- Stopped the canvas flickering while typing. Every keystroke replaced the whole theme-styles map and stamped `rerenderControls`, re-rendering Bricks' entire panel; pushes now coalesce to the pause between keystrokes.
- Withdrew the Elements / Structure dock-float-hide menu from the Bricks toolbar pending a redesign, and it is removed from installs that already rendered it. The same settings remain in MV Settings → Builder Panels.
- Checklist audit: removed two rows confirmed working, one that outlived the feature it tested (minimum canvas), and one superseded by a later row testing the same thing.

## v1.3.454
- Bricks' own Theme Styles panel now updates with MV instead of showing stale values until it was closed and reopened. The canvas was repainting, but the panel keeps per-control state; Bricks refreshes it by stamping `rerenderControls` on the store, which MV now does after every push.
- Every colour picker is one component again. The map, sliders, OKLCH fields and format tabs were already shared, but each host built its own footer and sized its own popover, which is why the Variables, Theme Styles, Content Studio and Media Studio pickers looked like four designs. Footers are now declared as actions on the shared core, and all hosts size from one `--ve-picker-width` token.
- Added light-mode theming to the colour picker. It had none, so inside the Content Studio's light canvas it rendered dark chrome — including the alpha checkerboard, which now uses light squares.
- Swatches keep a 1:1 ratio and take the height of the field beside them. `.ve-cp` pinned its first grid column to 42px, so the swatch could never track the field; that column is now sized by the square.
- The ⚡ variable control opens a searchable dropdown listing MV variables with their resolved values, plus Unbind when one is already set. It previously just seeded `var(--` into the field, and rendered a second redundant lightning icon beside the first.
- Removed the minimum canvas viewport setting and its REST route, runtime and stored option. Parked, not abandoned — the finding worth keeping is that Bricks' `previewWidthLocked` watcher only persists the number, and `previewWidth` is recomputed solely when `previewWrapperWidth` changes, so any future version must mirror the width itself.
- Rewrote the Component Library's colour picker entry, which had drifted from what ships: it documented HEX/HSL/OKLAB/VAR tabs and a preset swatch row that no longer exist.

## v1.3.453
- Theme style edits now show in the builder immediately, without a reload. Saving only wrote the `bricks_theme_styles` option; the builder generated its canvas CSS at boot and never re-read it, so nothing MV changed here was visible. MV now writes the builder store the way Bricks' own panel does — the styles map first, then the active style's settings, which is the watcher the iframe uses to regenerate (`$_generateCss("themeStyles")`). Every value is a fresh clone because those watchers compare by reference, and the message is posted to the canvas with `ignoreOrigin` so Bricks cannot drop it.
- The canvas repaints on every field change, not only on Save, matching how Bricks previews its own theme style edits. Conditions are live too: the server recomputes which styles apply to the previewed post on each read and write.
- Minimum canvas now actually moves the canvas. Bricks' watcher on `previewWidthLocked` only persists the number over AJAX — `previewWidth` is recomputed solely when `previewWrapperWidth` changes, so setting a width saved it and moved nothing until the next panel resize or reload. Bricks never hit this because its own lock button locks to the *current* width. MV now mirrors the locked width onto `previewWidth` on desktop, and restores the wrapper width when the lock is turned off.
- Colour picker: added a footer with breathing room above the Done button, a Clear command that removes the colour so the Bricks default applies again, and dismissal by clicking outside or pressing Escape.
- Any colour or text field in Theme Styles now has a ⚡ that opens the MV variable list. The suggestions only appeared once the text already looked like a variable reference, which was not discoverable.
- Branded the scrollbar on the CSS editor's variable-suggestion list; it was still the browser default.

## v1.3.452
- Theme Styles now write into the group Bricks reads them from. Bricks resolves a style as `settings[group][key]` (`Theme_Styles::get_setting_by_key`); MV wrote every key flat at the top of `settings`, so outside conditions nothing MV saved was ever applied. Values written by earlier builds are lifted into their real group the first time a style is opened.
- Saving from MV no longer deletes per-element theme styles. The save replaced the whole settings array, wiping Bricks' ~40 element groups (Section, Button, Heading…); it now merges, and the Elements tab names the groups a style is carrying.
- Completed all nine whole-style groups — 107 controls. Group ids, keys, labels, placeholders, option tokens, `exclude` lists and `required` show/hide rules are generated from Bricks' own `includes/theme-styles/controls/*.php` rather than transcribed.
- Replaced every JSON textarea with a typed control: a 15-field typography panel, border as width/style/colour, box-shadow as X/Y/blur/spread/colour/inset, spacing as the four-side box, multi-selects that accept custom tags, and a repeater for contextual-spacing targets.
- Stored stylesheets, link CSS selectors and the contextual-spacing selector list verbatim; `sanitize_textarea_field` strips `%xx` octets and tag-shaped text, which corrupts CSS.
- Regenerated Bricks' `theme-style-*.min.css` explicitly on save, since Bricks' own hook only fires when the stored value changed, and suffixed duplicate style labels because Bricks names that file after the label.
- Added `scripts/check-theme-styles-contracts.js` (10 checks) and `scripts/gen-theme-styles-spec/`, which diff MV's spec against Bricks' control files so a rename cannot silently turn saves into no-ops.

## v1.3.405
- Replaced the v1.3.404 per-editor listener with one broker registered before the Preact panel mounts, so the handler exists before editor effects and later Bricks window listeners.
- Routed standard `wheel`, Firefox `DOMMouseScroll`, and legacy `mousewheel` through the same bounded editor path, suppressing compatibility duplicates only while an MV editor consumes the input.
- Made the native CodeMirror scroller's `scrollTop`, `scrollHeight`, and `clientHeight` authoritative instead of relying only on CodeMirror's calculated range.
- Exposed `mimamVarInspectCodeEditors()` immediately in the current and same-origin top-frame console, before any editor mounts.
- Verified physical wheel input in Firefox 153.0.1 and Chromium: inline and pop-out editors reached their native final line, inline boundary scrolling moved the Settings panel, and the pop-out footer remained visible.

## v1.3.404
- Captured CodeMirror wheel input at the window boundary so Bricks document/panel handlers cannot cancel it before inline or pop-out editors scroll.
- Added `mimamVarInspectCodeEditors()` for on-demand console reporting of every live editor's measured and native scroll range plus its last wheel decision.
- Kept Execution, Styles, and Scripts fully expanded in Custom Code instead of turning the editing workspace into accordion toggles; calmer accordions remain unchanged in the other Bricks Settings groups.
- Continued inline wheel movement into the Bricks Settings panel after the editor reaches either boundary, while keeping the pop-out isolated above its accepted visible footer.
- Added a faithful browser harness that installs a cancelling document-capture listener before CodeMirror, then verifies both editors reach their measured final line.

## v1.3.403
- Routed physical mouse-wheel input through bounded inline and pop-out CodeMirror editors, while releasing the wheel to the surrounding panel at the first and final line.
- Added Bricks-native Theme Styles Phase 1: create, rename, duplicate, guarded delete, conditions, whole-style General/Colors/Typography/Links/Spacing/Content controls, and Custom CSS all read and write the existing `bricks_theme_styles` option.
- Reorganized Bricks Settings into calm collapsible subsections with optional descriptions while preserving global search and native Bricks saves.
- Vendored CodeMirror 5.65.16 XML, JavaScript, and HTML Mixed modes so Bricks header/body script fields receive real HTML/JS/CSS syntax highlighting inline and in the pop-out.
- Added a focused 21-check contract suite and a bundled-CodeMirror browser harness that verifies physical wheel movement, the final line, visible pop-out footer, and HTML Mixed mode.

## v1.3.402

- **CodeMirror remeasures instead of losing its bottom edge.** Inline and popped-out Bricks editors now observe their real host geometry, refresh after layout/font changes, and keep the final line plus scrollbar inside the visible editor.
- **Bricks Settings matches the Settings panel.** Its docked and floating panel width now uses the same 468px product width; the purpose-built 410px code pop-out remains unchanged.
- **Content Studio uses Rank Math's live analyzer.** When Rank Math is active, edits to SEO-relevant content are passed through Rank Math's own analyzer, configured tests, locale data, and score weighting before save. The stored `rank_math_seo_score` remains Rank Math-owned.
- Added a focused v1.3.402 contract and a real bundled-CodeMirror browser harness for editor bounds, panel width, analyzer wiring, and score ownership.

## v1.3.401

- **Bricks code editing reaches the real bottom.** Inline CodeMirror stays inside its fixed-height box; the pop-out body is bounded above its visible save-state footer; the studio rail sits immediately beside the pop-out and follows it after resize or drag; and the stale native dock-back tooltip is removed.
- **Attachment video layout is independent from image previews.** Video media, hover/focus seekbar, and Play/Sound/Volume controls render in a dedicated intrinsic-ratio card before Metadata, including portrait video.
- **Focus keywords are calmer and readable.** Each keyword now uses one compact full-width row with wrapped text instead of uneven bubble widths.
- **Rank Math owns its SEO score.** Content Studio reads the score Rank Math stored in WordPress, reports N/A when Rank Math has not produced one, and no longer writes over `rank_math_seo_score`; MV analysis remains the fallback only when Rank Math is inactive.
- Added a focused v1.3.401 contract plus a browser layout harness for the editor/rail/footer geometry.

## v1.3.400

- **All Bricks code fields use the shared editor.** Custom CSS, header scripts, and body scripts mount the CSS Studio CodeMirror shell; inline instances are fixed-height and the rail clears a popped-out field.

## v1.3.399

- **One editor and minimal pop-out.** Custom CSS gained the shared CSS Studio highlighting/suggestion engine and any Bricks code field can open in a 410px full-height side panel with keyboard saving.

## v1.3.398

- **Everything feedback stays visible.** Selection/opening toasts choose space above or below Mimam's Bar and clamp to the viewport instead of rendering off-screen.
- **Video Attachment Details no longer breaks its layout.** Playable and failed previews reserve their own bounded space, controls remain below the media, and a seekbar appears on hover or keyboard focus.
- **Masonry uses true video geometry.** Video tiles report intrinsic dimensions to the column balancer, so portrait, square, and landscape assets render at their real aspect and rebalance the columns.
- **Long focus keywords show in full.** Keyword text wraps inside the pill without ellipsis or horizontal overflow.
- **SEO score persistence is explicit.** All SEO edits mark the editor dirty, and the SEO tab now has a dedicated Save SEO & score action with saved/unsaved feedback.
- Added a focused v1.3.398 contract for viewport-safe feedback, video layout/geometry/seeking, keyword wrapping, and SEO score persistence.

## v1.3.397

- **Visible Everything selection feedback.** Opening a result now announces what was selected and whether it is opening here or in a new tab; same-tab navigation pauses briefly so the confirmation can paint.
- **Video previews now follow the media.** Portrait videos use their intrinsic aspect ratio, all controls sit below the media, and Play/Pause plus Sound use compact accessible icons.
- **Metadata fields are easier to edit.** Caption and Description have dedicated taller multi-line areas.
- **Content SEO acceptance fixes.** Meta-description textareas escape the global one-line clamp, focus-keyword pills wrap instead of shrinking into one line, and Content Studio persists its own computed SEO score while still writing the Rank Math score for compatibility.
- **Upload feedback no longer collides.** While Media Studio progress is visible, the global toast reserves space above it.
- **Approved Output unit clarity design shipped.** The default for new tokens is a clear four-card choice; converting existing tokens is a separate optional flow with an inline review step.
- Added focused contracts for Everything feedback, responsive video layout, icon controls, metadata sizing, toast spacing, SEO persistence/wrapping, and the approved output-unit flow.

## v1.3.396

- **Media Studio opens with media already waiting.** The library now warms in the background, survives reloads in a short-lived session cache, paints the first REST page immediately, and refreshes stale data without replacing the usable gallery with an empty loading state. Media requests also drop the unused embedded-author expansion.
- **Videos now look and behave like videos.** MP4, WEBM, MOV, M4V, and OGV tiles lazily capture a real frame only when near the viewport. Selecting one opens an in-panel player with Play/Pause, explicit Sound on/off, and a Volume control.
- Added focused contracts for the cache/prefetch path, progressive paint, removal of the expensive request shape, real video previews, and accessible playback controls.

## v1.3.395

- **Media Studio scrolls again in every launch mode.** The normal Studio bridge now fills the remaining panel height instead of expanding with all media content, so Collections, the gallery/list, attachment details, and batch actions receive bounded scroll areas while Bricks picker mode keeps its existing context-preserving layout.
- Added a focused Media Studio regression contract for the complete flex-height chain and corrected the archived ACF mock path used by the v1.3.340 contract gate.

## v1.3.394

- Added explicit flex and overflow ownership to the Media Studio collection list. Live acceptance showed the outer normal-mode bridge was still unconstrained, so the complete height-chain correction follows in v1.3.395.

## v1.3.386

- **Backdrop behind studio panels, per module (#18).** While a studio is open you can blur/dim the page behind it. Settings → Studio preferences adds an intensity picker (Blur + dim / Soft / Dim only / None) and per-module switches (Content, Media, Plugin, CSS Studio, CSS Recipes, Font Manager, Documentation). Defaults: Blur + dim, on for those studios, off for the docked Variables panel and Settings. The wide studios already dimmed; this makes it consistent and controllable.

## v1.3.385

- **Drag a field's right edge to set its Presentation width (#17).** In the field-group builder each field now renders at its wrapper width; a handle on the right edge resizes it (snapping to 5%, 15–100%) and shows a live percentage. The drawer's width field stays in sync.

## v1.3.384

- **Documentation module (#14).** The Help speed-dial (now "Docs") opens a full documentation hub: a rail of modules (Variables, Media Studio, Content Studio, Builder Tools, Recovery), a home with search, module cards, Quick answers and "What's new", per-module article lists, and a rich article reader (callouts, numbered steps, command lists, keyboard chips). Built from the approved v4 mock; the Bar command reference is now an article.

## v1.3.383

- **ACF Options Pages editor (#13).** The Options Pages section now has a **+** to register a page and pencil/delete controls per row; the tabbed editor covers **Placement** (page/menu title, stable slug, parent, position, icon, description), **Access** (capability, redirect parent, autoload), and **Field Groups** (which groups target the page). Everything saves through ACF's own `acf_update_ui_options_page`, merging into the existing record.
- **The category list's Autoload toggle is now live** for options pages, saving through ACF, and options rows gained Edit/Delete actions.

## v1.3.382

- **Image pickers across wp-admin now open Media Studio** (Site Icon, featured image, ACF image fields, etc.), not just inside the builder. The wp.media bridge is active on every admin page whenever the Media Studio tool is enabled, and falls back to the native WordPress library when Media Studio can't handle a request. Disable the Media Studio tool to restore native pickers everywhere.

## v1.3.381

- **Pressing Enter in the Bar's Direct mode now applies the command** even when a class/attribute token chip is focused — previously Enter only triggered the chip's own click, so the change was lost until you clicked Apply. Editing a token's value inline still commits on Enter as before.

## v1.3.380

- **Focus keywords now wrap instead of overflowing.** Long focus-keyword pills flow onto multiple rows and truncate cleanly rather than spilling out of the box.
- **The SEO score updates live as you type**, computed from the on-page analysis checks, instead of only showing the last saved Rank Math score.
- **A notice shows when Rank Math isn't active**, making clear the SEO analysis is Content Studio's own.

## v1.3.379

- **The featured image now shows its actual thumbnail** in the content editor rail instead of a generic icon (the server now sends the thumbnail URL, and picking a new one updates it live).
- **Taller meta-description field** in the SEO preview editor.

## v1.3.378

- **Custom post types are reliably tagged as ACF-editable**, so the category-list status cells render as working toggle switches (not read-only pills) and the row/edit actions open the editor. Source detection now uses ACF's UI-created post-type definitions and tolerates both array and string shapes.

## v1.3.377

- **The category list now matches the reference prototype.** Each category shows the full column set (Singular, Slug, Description, Front prefix, Post-type badges, etc.), the status cells for post types and taxonomies are **inline toggle switches that save through ACF**, and there's a search box, an "Add [type]", and Edit / Duplicate / Delete row actions. Default content types stay read-only (labelled WordPress).

## v1.3.376

- **Clicking a Content Studio section header lists that category's items (#8).** Default Content Types, Custom Post Types, Taxonomies, Options Pages and Custom Field Groups each open a table of their items (with public/hierarchical/archive status and Edit/Delete actions); the caret icon alone now toggles collapse. Clicking a row opens that item.
- **Options Pages hides externally-registered pages.** Only options pages created through ACF's own UI are listed; ones registered in code by plugins/themes (e.g. Advanced Themer's Theme Settings) are hidden.

## v1.3.375

- **The Taxonomies list no longer shows internal plumbing.** MV's own media-collection taxonomy and Bricks' template Tag/Bundle taxonomies are hidden from the Content Studio Taxonomies list — it shows only real content-model taxonomies.
- **Creating a child collection reliably opens it.** The server re-keys nested collections, so MV now re-selects the new collection by its label once the sync returns instead of trusting the locally guessed key (which the fallback then reset to All).

## v1.3.374

- **Custom Taxonomies editor (#8).** Content Studio has a Taxonomies section listing custom taxonomies; the **+** registers a new one and clicking a taxonomy opens a tabbed ACF editor — General (plural/singular/key, description, public, hierarchical, assigned post types), Labels, Visibility, Permalinks, and REST API. Everything saves through ACF's own `acf_update_taxonomy`, merging into the existing record; delete removes the definition (terms are kept).
- **The upload success toast no longer overlaps the upload progress card.** The sticky toast now sits above the progress indicator instead of on top of it.

## v1.3.373

- **Uploaded media keep spaces in their names.** The upload path percent-encoded the filename into the Content-Disposition header, so WordPress stripped the `%` and left "20" (`campaign monitoring` → `campaign20monitoring`). The filename is now sent header-safe with spaces intact.
- **Bar suggestions are faster again.** Reduced the command/element-search debounce from ~220–240 ms to ~120–150 ms.
- **Creating a child collection opens it.** Sub-collections now select and expand their parent branch on creation, matching top-level collections.

## v1.3.372

- **Selecting an image for a component instance now applies on the first try.** The component's image control sometimes mounts its writable field a frame after the picker confirms, so the first insert found nothing and you had to select twice. The insert lock is released on that miss and the insert retries once automatically.

## v1.3.371

- **Safe Add no longer pauses custom/third-party elements.** Adding an element like Slot from the Bar inserts it directly, the same as a core Bricks element.
- **Imported media keep spaces in their names.** A source name with `%20` (e.g. `high%20visibility%20image`) is now decoded before sanitising, so it reads "high visibility image" instead of "high20visibility20image". Applies to URL, content-disposition, and ZIP imports.
- **Typing `//` closes the Bar.** Pressing `/` while the field already holds a single `/` clears and closes it.
- **The Bar's suggestions are snappier.** Command and element-search results were debounced at 620–760 ms; they now respond in ~200–240 ms.
- **The "Use Selected Media" button sits above the metadata when picking.** When Media Studio is opened by a media picker, the confirm action is pinned to the top of the detail panel instead of below a long detail list.
- **Creating a collection in Media Studio opens it.** The new collection is selected immediately so you can start adding to it.

## v1.3.370

- **The multi-select option grids are now toggle switches.** The field-group Presentation → "Hide on screen" list and the post-type editor's "Editor supports" and "Taxonomy assignments" grids used square checkboxes; each option is now a labelled toggle switch, matching the rest of MV's controls.

## v1.3.369

- **Removed the stray horizontal scrollbar along the bottom of the ACF field-group and post-type editors.** The settings panes are meant to fit their width, so a sideways scrollbar there was always wrong; they now scroll vertically only, and the post-type editor's two-column rows can shrink instead of overflowing.

## v1.3.368

- **The floating settings speed dial only opens from the gear now.** Hovering anywhere in the button's column — including the empty space above the gear where the tool icons sit — used to reveal the whole speed dial. The tools now appear only when you hover the gear itself, and still stay open while you move up onto them.

## v1.3.367

- **The Custom Post Types editor is now a full ACF registration screen (#20).** Editing or registering a post type opens a tabbed editor — **General** (plural/singular/key, menu icon, description, public, hierarchical, editor supports, taxonomy assignments), **Labels** (the eight override labels ACF generates), **Visibility** (publicly queryable, show in UI/menu/admin bar/nav menus, menu position/icon, exclude from search), **Permalinks** (rewrite slug, query var, front prefix, feeds, pagination, archive), **Capabilities** (capability type, can export, delete with user) and **REST API** (show in REST, base, namespace, controller). Previously only the post type's labels could be changed.
- Every value saves through ACF's own `acf_update_post_type`, merging into the existing record so its key and any settings the editor does not expose stay attached.
- Editing an older-ACF or JetEngine post type keeps the labels-only behaviour; the settings tabs apply to ACF post types.

## v1.3.366

- **Dropdown menus scroll properly again.** Hovering an option re-anchored the list to that option, so every wheel notch snapped the menu back where it started. The list now only follows the highlight when you move it with the keyboard, and long menus (rule types, field types) get more height before they scroll.
- **Controls in the field-group editor match the chrome around them.** Selects and inputs sat at a 4px radius while the cards, pills and buttons beside them are 8-12px, so they read as squared-off.
- **The field-group editor fills the panel height.** It was capped at a fixed height and left dead space below the drawer.
- **The preview title bar says what it is.** The fake WordPress "Add title" field is now labelled as the post editor preview, so it is not mistaken for a group setting.

## v1.3.365

- **Field-group panes now have real padding and spacing.** The tab row, Location Rules, Presentation and Group Settings all sat flush against the panel edge with no breathing room between controls.
- **The field drawer fills the panel height** instead of stopping partway down and leaving dead space beneath it.
- **Dropdowns in the ACF editor are MV-styled.** Rule type, operator, rule value and field type used native selects, so their menus rendered in the operating system's styling; they use MV's own dropdown now, with search on the long lists.

## v1.3.364

- **Fixed the Presentation tab collapsing onto one line.** Content Studio styles labels inline, so Style, Position, Label placement, Instruction placement and Order all ran together; each setting is its own stacked row again.
- **Download ZIP no longer renders as a blue link.** wp-admin colours anchors, and the Release manager action is an anchor styled as a button.
- **Location rule values are now dropdowns** where MV knows the options — post types (from the site's registered types), post status, page type and user roles — instead of a free-text box you had to guess at.

## v1.3.363

- **Made clear that creating a field group is only the first step.** The create screen now says the group opens in the builder straight after, where fields and the full ACF settings live; its post-type list is relabelled as the starting location rule rather than the only way to target content.

## v1.3.362

- **Field groups now expose everything ACF's own screen does.** The editor gained the Settings ACF ships with, as tabs beside the field builder: **Location Rules** (a real rule builder with all 21 rule types, AND rules and OR rule groups — not just a post-type checklist), **Presentation** (style, position, label placement, instruction placement, order number, and the full Hide-on-screen list) and **Group Settings** (active, show in REST API, description, display title). All of it saves through ACF, so groups edited in MV match groups edited natively.

## v1.3.361

- **An empty field group can now be built.** A group with no fields hit the generic "No items found." state, so a newly created group had no way to add its first field. Field groups always render the builder now, with an "Add the first field" prompt when empty.
- **Creating a field group opens it.** You land straight in the builder instead of having to find the new group in the sidebar.
- **The Latest release card is gone from Release manager.** Removing only its Update button still left a duplicate of the Check-update block above it; the pending build is listed in one place. Installed and rollback rows are unchanged.

## v1.3.360

- **ACF field groups now use the approved Live Preview builder.** Opening a field group in Content Studio shows the edit screen your writers actually see instead of a plain table: click a field to edit it in the side drawer (General / Validation / Presentation), hover between fields to insert, and reorder, duplicate or delete inline. Changing a field type re-renders its real control — image drop zone, repeater rows, true/false switch, and so on. **Save fields** writes back through ACF, updating fields in place so keys and stored content survive.

## v1.3.359

- **Release manager entries show their own version again.** Every row was labelled with the same old version because the release script copied the previous entry's label instead of deriving it; all existing entries have been repaired.
- **Removed the duplicate Update button** from the Release manager's Latest row — updating to the newest build is already offered by the Check-update block directly above it.
- **The font relink picker now lists font files only**, instead of the whole media library.

## v1.3.358

- **ACF content-model API (Content Studio groundwork).** New endpoints read every ACF model in one call — field groups with their fields, post types, taxonomies and options pages — and save a field group back through ACF's own API, updating fields in place, appending new ones and deleting removed ones so keys and stored values survive. Reports cleanly when ACF is not active. This backs the approved Live Preview builder; the UI lands next.

## v1.3.357

- **The Media Studio picker now works in wp-admin, not just the Bricks builder.** The media bridge effect returned early outside the builder, so the direct picker MV panels rely on was never defined there — Font Manager fell back to the WordPress library. Only the wp.media hooking is builder-specific now.

## v1.3.356

- **The font relink picker now opens Media Studio instead of the WordPress library.** MV already swaps `wp.media` for a Media-Studio-backed frame, but only when a recent Bricks control intent exists — a call from Font Manager had none and fell straight through to the native library. MV panels can now open the picker directly.

## v1.3.355

- **Updates fixed — the feed was rate-limited, not blocked.** The primary feed pointed at `api.github.com`, whose unauthenticated limit is 60 requests per hour per IP; a normal day of checks exhausted it and GitHub returned `403 API rate limit exceeded`, which surfaced as "Update feed blocked". `raw.githubusercontent.com` serves the same manifest with no auth and no limit, so it is now the primary feed and the API endpoints are the fallback. (Verified live: API → 403, raw → 200.)
- **Pages and Bricks templates can now be opened in the WordPress editor** from Everything mode with `⇧↵`, instead of always going straight to Bricks.

## v1.3.354

- **Updates work again — the real cause this time.** Removing the "Update feed URL" field left its old value in the database, and the updater still read that stored value as a fallback. It was a bare repository URL with no manifest path, so every check failed. The stored value is now ignored entirely: only a `wp-config` constant can override the built-in per-channel feed.
- **Dismissing a toast (or using the media frame) no longer closes the open studio.** The outside-click watcher runs in the capture phase, so it fired before the toast's own handler could stop it; toasts and the WordPress media frame are now excluded at the watcher itself.
- **Adding an element with nothing selected no longer errors.** Only Section could be added without a target; anything else was refused. Elements are appended to the canvas root instead.
- **Everything mode now finds Bricks templates** — headers, footers, single templates — and opens them straight in the builder.

## v1.3.353

- **Fixed the General settings tab doing nothing when clicked (regression in 1.3.352).** The per-module tooltip switches were rendered in the Settings component but their state was declared in the app shell, so the tab threw on render. The stored list is now read through a shared helper: Settings owns the switches, the tooltip engine mirrors them via an event.

## v1.3.352

- **Tooltips can now be turned off per module** — Settings ▸ Modules lists every studio plus the speed dial/rail, each with its own switch. The tooltip engine checks the hovered element's `data-panel` before showing anything.
- **The speed dial no longer closes before you reach an icon.** It used to close the instant the pointer left the wrapper, so any diagonal travel dismissed it; it now waits ~320ms and cancels that timer when the pointer returns.
- **Fixed core Bricks elements being rejected by Safe Add.** The core allowlist used reversed keys (`basic-text`) while Bricks names them `text-basic`, so "Basic Text", "Rich Text" and "Text link" were treated as third-party and blocked.

## v1.3.351

- **Fixed updates being unreachable ("Update feed blocked") in 1.3.349–1.3.350.** Moving the feed URL into a constant hard-coded a bare repository URL, which both lacked the manifest path (`/contents/updates/…json?ref=main`) and overrode the Stable/Beta/Dev channel selection, so no channel could resolve. `VE_UPDATE_FEED_URL` and `VE_LICENSE_SERVER_URL` now default to empty — meaning "use the built-in per-channel feed" exactly as before — and only take effect when deliberately defined in `wp-config.php`.

## v1.3.350

- **Dismissing a toast no longer closes the studio behind it.** The toast is rendered outside every panel, so its clicks reached the document and read as "clicked outside" — closing Font Manager along with the message. Toast pointer events are now contained.
- **The media picker no longer closes Font Manager.** The WordPress media frame renders at `<body>`, so clicks inside it counted as outside the panel; those events are now swallowed while the frame is open.

## v1.3.349

- **"Relink all" no longer disappears after the first fix.** It lived inside the family's "no preview" warning, so the moment one variant healed the family regained its preview and the button vanished with 8 still broken. It now sits in its own strip that stays while any variant lacks a file, and reports the count.
- **Added "Browse media library" to the relink drawer** so a variant with no automatic match can still be pointed at a file by hand.
- **Unsaved-changes text no longer clips the Close button** — the footer shows a compact dot + "Unsaved" instead of a full sentence; results are toasts.
- **Removed the Update feed URL and License server URL fields.** They are infrastructure, not user settings: a customer editing them silently breaks updates or licensing. They now live in code as `VE_UPDATE_FEED_URL` / `VE_LICENSE_SERVER_URL`, each overridable from `wp-config.php`.

## v1.3.348

- **Fixed Relink all failing when the right files were sitting in the media library.** Matching only knew one name per weight, so a family like Lato — which calls weight 100 "Hairline", not "Thin" — scored every file below the auto-relink threshold. Weights now match on numerals *and* foundry synonyms (thin/hairline, extralight/ultralight, semibold/demibold, black/heavy…), italics must agree in both directions so an upright variant can never take an italic file, a different family is rejected outright, and unsuffixed regulars (`Lato.woff2`, `Lato-Italic.woff2`) are understood. All nine Lato variants now resolve to the correct file.
- **Long toasts wait for you.** Messages over ~70 characters drop the countdown ring and stay put with a × to dismiss, so there's time to read them.
- **Visibility save result is now a toast** instead of a cramped footer strip that squeezed the Close button.

## v1.3.347

- **Relink all now reports what it did.** Progress runs on the button itself ("Scanning 3/9…") instead of only in the far-away footer status, and the result is announced as a toast — including the previously silent case where no media-library match was found for any variant.
- **Settings footer really stops clipping Close.** The actions group had no `min-width:0`, so it overflowed the footer instead of letting the status text truncate.

## v1.3.346

- **Fixed the broken Relink button.** The variant action row forces 27×27 icon buttons, which crushed the labelled pill so its icon and text overlapped; the pill now sizes to its content.
- **Added "Relink all"** to a family's warning row — it scans once per broken variant and relinks every confident match in a single pass, then reports how many still need a file.
- **Settings footer no longer clips Close** when a long status message shows: the buttons stop shrinking and the status truncates instead.
- **Toggle On/Off label is properly centred** — it now stretches between the track edges and centres with flex instead of relying on a fixed height and line-height.

## v1.3.345

- **Broken font variants can now be recovered in place.** A variant whose Bricks attachment no longer resolves gets a **Relink** action: MV scans the media library and ranks replacements (exact filename → same stem → family/weight/style match), and one click repoints the variant and rebuilds the Bricks font-face rules. If nothing matches, the panel says so and points at re-upload or removal. New endpoints: `font-manager/relink-candidates` and `font-manager/relink`.

## v1.3.344

- **Restored the Direct row's inline padding.** Zeroing `padding-inline-start` to let tokens wrap under the mode control left every *wrapped* row running flush to the panel edge; the row keeps its 16px inset again (the mode pill no longer needs its compensating margin).

## v1.3.342

- Fixed both Font Manager launchers so the Studio rail and builder speed dial open the same Bricks-backed panel.
- Added an explicit return path from Import/Add variant, matched the shared panel width, removed the redundant Import action and external Bricks-admin handoff, and guarded variant removal with MV confirmation.
- Normalized Bricks font-face sources stored as attachment IDs, source arrays, or URLs so existing family/variant files resolve instead of silently appearing missing.
- Registered per-family preview faces from the actual Bricks font URLs, weights, and styles; unavailable sources now show an explicit recovery state.
- Refined Mimam's Bar so Direct and the opening tokens share the first row while later rows use the full rail, and made class/attribute suggestion focus, spacing, match emphasis, and scrollbar gutter calmer.
- Added prototype-only three-direction ACF UX comparison, product Documentation v2, and type-aware Variables List/Visual/Groups views for review.

## v1.3.341

- Added a Bricks-backed Font Manager that reads and writes Bricks Custom Fonts, imports browser-converted WOFF2 files as WordPress attachments, refreshes Bricks font rules, and keeps every family editable through Bricks without MV.
- Added family search, real family/weight previews, family rename, variant weight/style editing, add-variant import, variant removal, and recoverable family trash.
- Kept Direct at the Bar's top-left while wrapped tokens align beneath the token rail, reserved the top-right Saved Attributes action, and made its Settings deep link durable.
- Replaced saved-list removal with Unstar, clarified which Bar settings are surface-specific versus shared, and quieted attribute suggestion rows and match highlighting.
- Reframed the Help prototype as full product Documentation and replaced duplicate Variables view controls with type-aware Color palette, Typography specimen, Spacing scale, and Layout diagram views.

## v1.3.340

- Added spatial Arrow Up/Down navigation across wrapped Direct tokens and Backspace/Delete removal for a focused ID, class, or attribute while preserving native keys inside inline editors.
- Moved the saved-attributes library action to the Bar's top-right corner, let tokens fill beside the Direct selector, and deep-linked Settings to the Saved Attributes section with visible focus when opening or editing.
- Made visitor preview-key access opt-in, added Bricks-compatible role-based maintenance bypass controls, and kept administrators on Bricks' always-bypass behavior.
- Preserved Bricks' transient direct component-property editor while Media Studio selects an image default.

## v1.3.339

- Added the approved Attribute Suggestions v2 runtime with grouped suggestions, site-level saved names/values, star-to-save actions, suggestion value prefill, and add/edit/remove/bulk-paste management in Unified Settings.
- Restored focus to the token just saved through inline editing so keyboard traversal can continue immediately.
- Polished Site Visibility's numbered sections, mode selector, rendering switches, and shared Save/Close footer.

## v1.3.338

- Added Site Visibility to Unified Settings with live Bricks maintenance/coming-soon mode, template rendering, searchable exclusions, a WordPress-owned read-only site URL, and an MV-managed visitor preview key/link.
- Completed global class rename propagation into Bricks custom-CSS selector fields and refreshed Code2Bricks’ selector index, selector UI, and active editor buffer.
- Fixed Direct token editing so Left/Right moves the caret while editing and added a clearer keyboard focus state when traversing class and attribute tokens.
- Cleared Add Element search and highlight state after a Bricks element or Component is inserted.
- Matched the Bar update-banner actions to MV’s normal button height and rounded border rhythm.

## v1.3.337

- Refreshed Bricks selection consumers after an in-place global class rename so Code2Bricks and other selected-element integrations receive the new selector immediately without creating a replacement class.
- Replaced Direct mode's boxed ID, class, and attribute pills with a flat editable token rail, including Arrow Left/Right traversal between tokens and the trailing command field.
- Extended Add Element search to index native Bricks Components and insert a linked component instance through Bricks' add-element pipeline while retaining existing Safe Add restrictions for third-party elements.

## v1.3.336

- Fixed Bricks-triggered Media Studio picking so the current collection preselects its first item on first use, remembers the last picked attachment on later opens, and suppresses the redundant open/insert success toasts.
- Fixed Mimam's Bar class editing so global classes rename in place without losing their ID, styles, or references; manual classes still rename locally, and duplicate global names are rejected.

## v1.3.305

- Hardened Content Studio and Media Studio reopen synchronization with a pre-paint layout effect on both close and open, so a default changed while the Studio is hidden is applied without a stale-view flash.

## v1.3.304

- Fixed the Content Studio and Media Studio close/reopen flash by preloading each configured Normal or Full screen default while the Studio is hidden.
- Standardized Variable, Content highlight, and Media collection color editing on the approved shared visual core, including the compact map, tracks, channel fields, and format tabs.
- Simplified Media collection color editing by removing its unrelated preset grid and retaining the collection context, shared picker, and Cancel/Clear/Apply actions.

## v1.3.303

- Fixed the remaining Content Studio and Media Studio fullscreen cascade failure. The late shared open-panel centering transform can no longer shift half of a viewport-sized Studio offscreen.

## v1.3.302

- Corrected the shared color picker's Escape path so a cancelled valid draft is restored without the subsequent blur event committing it.

## v1.3.301

- Fixed Content Studio and Media Studio Full screen so shared panel geometry cannot preserve normal-view offsets, transforms, or size caps.
- Fixed Content Studio list requests on plain-permalink WordPress sites, including the return path after structured Import, by separating `rest_route` from endpoint query parameters.
- Removed the obsolete first-release explainer from Import and repaired shared color-picker typing, keyboard commit/cancel, and pointer dragging.

## v1.3.335

- **Everything mode Phase B — Plugins · Settings · Bricks scopes are live.** A new `everything-index` endpoint serves every wp-admin destination (captured from the admin menu on each admin load, so plugin pages like ACF, Settings ▸ *, Tools ▸ *, Bricks ▸ * are all included), cap-filtered per user, plus the installed plugins. Typing now returns real destinations — "acf", "permalinks", "site health", a plugin name, "bricks performance" — and `↵`/`⌘·Ctrl ↵` opens them in your chosen tab. The `⇥` scope control now cycles All · Pages · Plugins · Settings · Bricks.

## v1.3.334

- **Fixed the class/attribute suggestion icon chips** looking broken — the glyph is now sized and centred cleanly inside its chip.
- **Update-available banner in the Bar now matches Settings** — rounded corners and a more compact height (the Bar context was dropping the base radius).

## v1.3.333

- **Everything mode reimagined (Phase A).** The approved calm palette is now live: one ranked list (best match first, fuzzy), quiet category tags on the right, muted icons, faded scroll edges. It searches **commands + your pages/posts live** (Pages via WP REST). A keyboard-first segmented scope control — **`⇥` / `⇧⇥`** cycles All · Pages (wraps), clearing the box snaps back to All. `↵` opens a page in the Bricks builder in your chosen tab; **`⌘/Ctrl ↵`** opens in the other; the footer toggle sets the default. Elements/add-element left Everything (they have their own modes). *Plugins / WP settings / Bricks settings scopes land in Phase B with the everything-index endpoint.*

## v1.3.332

- **RR rename inside the component editor no longer kicks you out to the instance.** The deselect→reselect (needed for live structure refresh on normal elements) exited component-editing mode; inside a component it now refreshes the row in place without changing selection.

## v1.3.331

- **RR rename now reflects in the structure panel instantly, and works on component roots.** The rename replays Bricks' own deselect→reselect after writing the label (what clicking out and back in did), so the structure row updates live. Components need no special handling — a component root is just an element with a `label`.

## v1.3.330

- **RR rename now updates the structure panel immediately** (no more click-out/click-in). The shallow elements ref is nudged so Vue re-renders the row live.

## v1.3.329

- **Fixed RR rename not taking effect.** The label now writes to the element's top-level `label` (the key Bricks renders the structure-panel name from), in addition to `settings._label`. (Note: a component root may still display its component name rather than a per-instance label.)

## v1.3.328

- **Rename an element's label with a double-tap of `R`.** With an element selected in Bricks (and not typing in a field), tap `R` `R` to open a rename bar — the Bar in a Rename mode: the label comes pre-selected, the element's id / classes / attributes show as read-only pills, and the builder behind blurs. `↵` renames, `Esc`/click-out cancels. First of the planned double-letter shortcut family.

## v1.3.327

- **Everything mode results now actually run.** Clicking or pressing Enter on a result did nothing because the execute path was still guarded on the lost manager reference; it now resolves at call time, so Direct/Search/Add/Settings commands, page-element select, and add-element all fire.
- **Arrow-key navigation scrolls the highlighted result into view** in Everything mode and in the class/attribute suggestion list, so the active row is never hidden below the fold.
- **Suggestion list height increased to 2×** (was 1.5×) so more matches show at once.
- **Suggestion rows no longer bleed to the panel edge in Direct mode** — the results now inset to align with the input field.
- **Suggestion icons get a rounded background chip** (lime-tinted when the row is active), matching the mock.

## v1.3.326

- **Fixed Everything mode doing nothing.** It was throwing on every keystroke because its manager reference was lost during startup; the reference now resolves at call time, so on-page element search, add-element search, and the mode/settings shortcuts work again.
- **Bar suggestion polish.** Removed the lime left-accent bar on the active suggestion, widened the horizontal padding, and increased the suggestion list height by ~1.5× so more matches are visible at once.

## v1.3.325

- **Bar class suggestions now match the mock's design.** Each row has an icon (a selection glyph for on-element classes, a globe for site classes) and the matched part of the class name is highlighted in lime, alongside the existing group headers and badges.

## v1.3.324

- **Bulk "review selected" bar matches the mock.** The count is now an inline `40 selected` chip on the left (the old floating "REVIEW 40 SELECTED" pill sat on its own row above the actions), and the whole bar hugs into one row — Move-to · Move · Family (icon) · │ · ✕ · 🗑. Clicking the count still expands the selected-variables review list.
- **New Variable form uses the same type selector as the edit form** — the clean labels-only Color/Fixed/Fluid/Static segmented control.

## v1.3.323

- **Mimam's Bar class suggestions: fuzzy match + all site classes** (approved mock). Typing a class now matches fuzzily (`.splmed` finds `.split-content__media`), and suggestions include **every global class defined on the site**, not just the ones already on the selected element — so you can apply an existing class you aren't using yet. Results are grouped ("On this element" / "All classes on the site") with badges (on element · global · fuzzy).

## v1.3.322

- **Edit form type selector cleaned up.** The Color/Fixed/Fluid/Static row is now a clean labels-only segmented control (the small icons rendered washed-out) — clearer and on-brand.
- **Color swatch matches the value field height.** In the color editor the swatch was a fixed 42px while the value field is 38px; it's now sized to the control height so the box and input line up.

## v1.3.321

- **Variable edit form redesigned** (approved mock). The flat stack is now four clear sections — **Type** (a connected Color/Fixed/Fluid/Static segmented control), **Identity** (name with a live `--css-name` preview, plus category), **Value** (the per-type editor), and **Impact** (a card that only appears on rename — green "safe" when unused, amber otherwise, with the update-usages toggle and Preview impact). Same fields and behavior, just grouped and legible, with a proper Cancel / Save changes footer.

## v1.3.320

- **Bar shortcut now keeps focus when opened from a code editor.** Confirmed the editor (Code2Bricks) was refocusing its own textarea the instant it lost focus, so plain re-focus just ping-ponged back. MV now briefly disables the editor field so it can't reclaim focus, moves the caret into the Bar, then restores the field — no more bouncing back to C2B.
- **Class-chip badges have hover feedback.** Hovering the duplicate or remove badge now pops it (slight scale + brighten + glow) so they read as interactive, not decorative.

## v1.3.319

- **Duplicate-class icon is now a corner badge, matching the remove ×.** It floats on the pill's top-right corner just to the left of the × (same 20×20 size, shape, and hover scale-reveal) instead of sitting inline inside the pill.
- **Bar shortcut focus, harder try.** When opened from a code editor, MV now blurs the editor field and pulls focus back to the Bar input across a short window (30/90/180/320 ms), to beat editors that reclaim focus after open.

## v1.3.318

- **New/duplicated classes now show their real name immediately** in the Bar, not a raw id like `.hkszmp`. The Bar caches the class id→name map for 650 ms, so a just-created class rendered as its id until the cache expired and you reopened. Creating or duplicating a class now invalidates that cache, so the next render resolves the name. (Item 6.)
- **Copy icon now reveals on hover, exactly like the remove ×** — opacity-only (it keeps its slot, so the pill never resizes under the cursor), sitting right next to the ×.
- **Bar shortcut reliably moves focus off the code editor** — it now blurs the editor field and re-focuses the Bar input after open, so opening from Code2Bricks lands the caret in the Bar.

## v1.3.317

- **Bar shortcut now moves focus into the command field** when opened from a code editor. Opening the Bar from the Code2Bricks textarea worked, but the caret stayed in C2B; focus now follows into the Bar's input.
- **Fixed the duplicate-class icon flickering on hover.** The icon revealed itself by animating its width, which resized the pill under the cursor and caused a hover-flicker loop. It's now always visible next to the remove ×, styled the same way (dim, brightens on hover) — no reveal animation, no flicker.

## v1.3.316

- **Mimam's Bar: duplicate a class with its styles.** Hovering an existing-class chip now reveals a duplicate icon next to the remove ×. Clicking it clones the global class — a new `{name}-copy` class whose styles are a deep copy of the original — and applies it to the current element, so its chip appears ready to rename/edit. (Approved mock; the clone copies styles, per the chosen behavior.)

## v1.3.315

- **Bulk "review selected" bar cleaned up** (approved mock). Cancel and Delete are now compact icon buttons (× and trash) separated from the primary Move-to / Move / Family group by a divider, so the destructive Delete reads as clearly distinct instead of a flat cluster of text buttons.

## v1.3.314

- **Figma connection screen redesigned** (approved mock). It now opens with a clear connection-status header (● Not connected / Connected), then two numbered steps: 1) generate credentials with the pairing code and API key each in their own copyable field (one-click copy buttons), or 2) enter a code shown in the Figma plugin. Same actions, clearer flow.

## v1.3.313

- **Export formats are now a clear list, not ambiguous tabs.** The old export row looked like selectable tabs, so it wasn't obvious a click downloads. Each format is now a row with an icon, a one-line description, and an explicit **Download** button — System Bundle featured as the complete/primary format, with DTCG, Flat, Figma, and CSS as interoperability exports. (First of the approved review-pass redesigns.)

## v1.3.312

- **Mimam's Bar shortcut now opens from inside code editors.** When focus was in a text field — notably the Code2Bricks editor textarea — the Bar's open shortcut was ignored, so you had to click a canvas element first. A shortcut that uses a modifier (Ctrl/Cmd/Alt) now fires even from within an input/textarea (a plain-key shortcut still won't hijack typing).
- **Selected media tiles now show their checkmark.** The checked checkbox on media thumbnails resolved to `background-image: none`, so selected items were just a solid lime square. The checkmark SVG is now forced on the media selection state.

## v1.3.311

- **Variable changes now reflect on the site without a manual refresh.** The server already regenerated `variables.css` on every create/edit/delete, but the stylesheet `<link>` already loaded in the admin page and the Bricks canvas iframe still pointed at the stale file — so deleting a used variable (and other edits) only showed after reloading. MV now cache-busts those generated CSS links across the admin document and the canvas iframe whenever the variable set actually changes, so the change is live. Signature-gated so the background 30-second/focus refresh doesn't re-fetch needlessly.

## v1.3.310

- **Content Studio list no longer gets stuck on "Loading…".** Re-selecting the already-active content type (e.g. clicking Pages again after an import) bumped the load sequence and showed the spinner, but because the active nav hadn't changed the load effect never re-fired — so it spun forever with "0 items" until you closed and reopened the studio. Same-nav reselection now loads directly.

## v1.3.309

- **New setting: "Media Studio as Bricks media picker" (Settings → Studio defaults).** MV replaces the Bricks builder's media control with Media Studio; this toggle (default on) lets you turn that off so media controls open the native WordPress media library instead. The interception now checks the preference before taking over the `wp.media` frame.

## v1.3.308

- **The "Delete variable?" impact dialog no longer traps you.** With many affected consumers the box grew past the screen, pushing the Keep/Delete buttons off-screen with no way to scroll or dismiss — a full page refresh was the only escape. The dialog is now a fixed-height flex column (capped at 86vh): the header and action buttons always stay visible, the consumer list scrolls inside, and clicking the backdrop closes it.

## v1.3.307

- **Media Studio remembers the last collection you were in.** Reopening it (from Bricks or anywhere) returns to that collection instead of resetting to All media; if the remembered collection was deleted since, it falls back to All rather than opening empty.
- **Imported media titles no longer turn spaces into `20`.** A URL space is `%20`, and `sanitize_file_name()` stripped the `%` and kept the `20`, so `lagos image` imported as `lagos20image`. Percent-encoding is now decoded before sanitizing.

## v1.3.306

- **Unitless variables (font-weight, line-height, z-index, opacity, …) are no longer converted to `rem` on import.** The dimension normalizer applied the project's 10px-rem conversion to the whole `font` namespace, so a Figma `font-weight: 100` came through as `1rem`/`10rem` instead of `100`. Normalization now gates on the token *family*, not the namespace: weight/line-height/z-index/opacity/order/flex families pass through untouched, while real length tokens (font-size, space, radius, …) still convert as before.
- **New content defaults its author to the logged-in user.** Creating a page/post or opening the content importer now pre-selects the current user as author instead of the first author in the site list (you can still change it). Uses a new `current_user_id` field on the Content Studio meta endpoint.

## v1.3.294

- Content Studio now has a proper light/dark mode for the **whole studio**, not just the editor text. Previously the canvas toggle only recolored the writing surface, leaving the structure panel, toolbar, Publish/SEO/Block rail, and window header dark — so "light" looked half-broken. The theme is now lifted to the studio root and mirrored onto the panel frame, so one toggle themes the title bar, the STRUCTURE outline, the editor toolbar and paper, and the entire right rail together. The lime brand (`#baf400`) is kept for buttons, active pills, and fills; where lime would be text or an icon on a light surface it steps down to a readable dark‑olive (`#557a00`) so nothing is illegible. Dark mode is unchanged. The canvas control is now a segmented **Light / Dark** toggle (with sun/moon icons) instead of a single icon button, and your choice persists.

## v1.3.293

- Recovery no longer shows a "session expired" 403 or a frozen/"skipped" step after a guarded restore's database swap — the admin now refreshes itself cleanly through the swap. Root cause: the restore's job status lives in a database table, so the moment the destructive "Swap DB Tables" step replaces the live database with the backup's, the in-flight job row briefly vanishes (status 403 / "job not found") until RestoreBase re-seeds it. The status poller gave up after just 4 failed polls during that blackout, so it never observed the final "completed" status — which is what triggers the automatic admin refresh — and the last-seen step stayed painted as unfinished. The poller is now swap-aware: once it sees the restore enter the destructive swap zone it keeps polling patiently through the expected blackout, so it reaches "completed" and fires the clean auto-refresh (with a forced reload as a fallback if the row is slow to re-seed). Any nonce request that still races the swap now shows a calm "reconnecting after database swap" notice instead of the alarming 403. No restore/swap logic changed — this is entirely in the panel's polling and messaging.

## v1.3.292

- Recovery can now run a guarded restore on a live/production site, not just staging. The production restore path was blocking itself: after you typed the "RESTORE PRODUCTION" confirmation, the readiness assessment still counted "this site is production" as two danger checks (the environment check and the dry-run's "not staging" blocker), dropping the score to ~30 and failing at the ≥ 65 gate. The readiness/dry-run are now production-aware — when a production restore is explicitly confirmed, targeting a live site is treated as the intended condition, not a fault, while every real safeguard stays: the typed "RESTORE PRODUCTION" confirmation, package validation, disk-space check, danger-preview and WooCommerce-merge checks, and the pre-restore rollback snapshot. The staging ladder and the readiness UI keep their strict production-is-danger behavior. (Note: releases v1.3.289–v1.3.291 were shipped from another session and are not itemized in this source changelog.)

## v1.3.288

- Fixed MV darkening other plugins' code editors in the Bricks builder. MV loaded CodeMirror's stylesheet globally and then neutralized `.CodeMirror` to a transparent background across the whole page — which made Advanced Themer's Style Manager "Framework" CSS editor (and any other CodeMirror instance) go transparent/dark instead of keeping its own background. MV's CodeMirror CSS is now pre-scoped to its own `.ve-cm-host` editors (`codemirror.scoped.css`), and the global neutralization is removed, so foreign editors are left completely untouched — AT's editor keeps its light background whether MV is active or not. Resolves the recurring CodeMirror-bleed class of bug at the root (scoping, not counter-overrides).

## v1.3.287

- Snapshot Restore/Delete are now compact icon buttons (a counter-clockwise arrow and a trash icon, side by side) instead of stacked text buttons, so the Snapshots list reads cleaner. Hover/disabled states and tooltips retained.

## v1.3.286

- Snapshots are now manageable. Each snapshot has a **Delete** button (with a confirm), the list **auto-prunes** to the 20 most recent so recovery points can't grow unbounded, and creating a snapshot whose captured state is identical to the newest one **reuses it instead of stacking a duplicate** — which collapses the back-to-back "Before import" points. Added a `DELETE /sync/snapshot/{id}` route, `SnapshotManager::delete()` and `::prune()`.
- The migration **Preview** button now reads **"Re-preview"** once a preview exists, making clear it refreshes the scan rather than starting over.

## v1.3.285

- Fixed an imported scale family being wholesale skipped when its base collides on CSS name with an existing variable stored under a wrapper namespace. Concretely: an imported `space` family (base `space` → `--space`) unified with an existing `size.space` (which also resolves to `--space`, since `size` is a storage wrapper). `resolve_public_import_names` renamed the imported base `space → size.space` to merge them, but left the children's `source_name` pointing at the old `space`, so all 15 `space-*` steps plus their aliases were skipped as "source 'space' was not found" (22 items). The rename is now propagated to every child/alias `source_name`, so the family attaches to the unified base and imports cleanly. Reproduced the exact 22-item skip against the real registry+state and confirmed 0 after.

## v1.3.284

- Variable migration now imports base scale steps whose value is a long fluid `clamp()` formula. The scanner's "looks like a value" check rejected anything over 220 characters, but Advanced Themer's fluid `clamp()` values (with the full min-viewport/base-font math) run ~400–450 chars — so the base steps `font-size-s`, `radius-s`, and the entire `space-*` scale were silently dropped, which in turn orphaned every alias pointing at them (`font-size-caption`, `radius-default`, `section-content-title`, `space-grid-gap`, etc. → "source not found"). The cap is raised to 2000 chars (still guarding against whole-CSS blobs), so those steps import and their aliases resolve. Verified against the real registry: reproduced the exact skip list at 220 and confirmed 0 skips at 2000.

## v1.3.283

- Variable migration no longer lists **Core Framework** as a source when its plugin is uninstalled. Removing Core Framework leaves its options and the `core_framework_presets` table behind, which made MV keep showing it as an available source (a "ghost") and scan its orphaned tokens. The scanner now gates on the plugin being **active** (checks the active-plugins list for single-site and network, with a class/constant fallback); a removed framework stops appearing, and its leftovers are ignored — those tokens are read from Bricks/Advanced Themer instead. No data is deleted; the orphan rows are simply no longer surfaced.

## v1.3.282

- Imported color shades now sort in a sensible order inside each color family: all light steps first (`-l-1…8`), then dark (`-d-1…8`), then transparent (`-t-1…8`), instead of interleaving by step number (`-d-1, -l-1, -t-1, -d-2, …`). Matches the Advanced Themer Color Manager grouping. Display-only — no re-migration needed. Spacing/size (t-shirt) families are unaffected.

## v1.3.281

- Color migration now also brings across each color's **shade children** (the `-l-1…8`, `-d-1…8`, `-t-1…8` light/dark/transparent steps), not just the base colors. They import with their own stored values and nest as generated children under each base color, mirroring the Advanced Themer Color Manager. (v1.3.280 deliberately excluded them; this makes the import complete.)

## v1.3.280

- Variable migration now imports the **full** Advanced Themer color palette (all 14 base colors), not just the 6 theme-level ones. The complete palette lives in the `bricks_color_palette` option (v1.3.279 only read `bricks_theme_styles`), where the base colors sit alongside 252 auto-generated light/dark/transparent shades. The scanner now reads both options and skips any entry flagged `isShade`, so the semantic colors (`color-bg-body`, `color-bg-surface`, `color-text-body`, `color-text-body-reverse`, `color-text-title`, `color-text-title-reverse`, `color-border-primary`, `color-shadow-primary`) migrate in with their real values while the regenerable shades are left out. Verified against the real 266-entry palette export.

## v1.3.279

- Variable migration now imports the Advanced Themer / Bricks color palette. AT's Color Manager stores its palette in the `bricks_theme_styles` option — not in `bricks_global_variables` — so the migration scanner never saw it and imported zero colors even though the palette was populated. A new reader walks `bricks_theme_styles`, and for every color takes its portable CSS name from `raw` (`var(--color-primary)`) and its value from `rawValue.light` (`hsla(…)`), so the base palette (primary, neutral-light/dark, success, warning, error) now migrates into MV as color variables. Verified against a real exported palette.

## v1.3.278

- Fixed the styled tooltip still rendering ~350px wide in the Bricks builder. Once the native title was eliminated in v1.3.277, the remaining wide bubble was the styled card itself: a live console read showed computed `width:350px` while its own `max-width` was `220px` — which is only possible when an external `min-width` (set by Bricks/Advanced Themer) overrides the max-width. MV now forces `min-width:0` on the tooltip card (and `!important` on the compact variant), so nothing external can inflate it and compact tooltips hug their text in the builder exactly as they do in wp-admin.

## v1.3.277

- Actually fixed the raw, over-wide browser tooltip in the Bricks builder. v1.3.276 broadened the styled handler to match any MV surface, but that still relied on the mouseover handler intercepting before the browser painted its native `title` box — which it does not do reliably in the builder. This release removes the race entirely: an observer strips `title` off every MV surface the moment it is painted and mirrors it into `data-ve-tip` (which the browser cannot show natively and the styled tooltip reads). The browser therefore has nothing to render on its own — worst case is no tip, never the wide native one — and it runs in whatever frame the panel mounts in, so it is frame-independent.

## v1.3.276

- Fixed tooltips showing as the raw, over-wide browser title inside the Bricks builder. The styled-tooltip handler only intercepted elements inside #ve-panel-root; in the builder that lookup does not resolve to the hovered node's root, so the browser's own title tooltip showed instead. The handler now matches any MV surface, so styled tooltips render in the builder as they do in wp-admin.

## v1.3.275

- Fixed variable families not collapsing when a source filter (e.g. AT, CF) is active. The rows were force-expanded under a selected source, so the collapse toggle did nothing; the toggle now works in every view, defaulting to expanded in a source view and collapsed in All.
- Long tooltips now wrap to multiple lines within a moderate width instead of forming one over-wide, truncated bar; short tooltips still size to their text.

## v1.3.274

- Variable migration no longer aborts when a generated variable's source is missing ("Migration failed Add 'space-2xl': Generated variables require a valid source variable"). Preview's transitive skip now covers generated variables (not just aliases), so a generated variable whose source was itself skipped is removed with a warning and the remaining changes apply cleanly.
- The plugin's front-end runtime (Preact, CodeMirror) is now bundled with the plugin instead of loaded from a CDN, so the builder works offline, under strict CSP, and on privacy-strict hosts — the same reliability fix already applied to the Phosphor icons. GSAP, which was loaded but never used, has been removed.
- Fixed compact tooltips rendering too wide inside the Bricks builder; the bubble now sizes to its text regardless of the builder's global styles.

## v1.3.273

- Security (completes v1.3.272): the credentialed-CORS fix now also covers the REST response handler, not just the preflight handler. v1.3.272 hardened the OPTIONS preflight but the `rest_pre_serve_request` filter still reflected an arbitrary Origin with Allow-Credentials on actual responses (and it applies to all REST routes). Both paths now gate credentials to first-party origins only.

## v1.3.272

- Security: the VE REST API no longer reflects an arbitrary request Origin together with Access-Control-Allow-Credentials. That combination let any website make cookie-authenticated requests to a logged-in admin's API. Credentials are now sent only to the site's own first-party origin(s) (filterable via `ve_cors_allowed_origins`); all other callers — including the Figma plugin, which authenticates with an API key, not cookies — receive a credential-less wildcard.
- Security: the public pairing endpoint is now brute-force resistant. A wrong pairing code costs the pending code one of eight attempts before it is burned (turning a ~16.7M-guess search into an 8-guess one), attempts are throttled per IP, and the code comparison is timing-safe.

## v1.3.271

- Variable migration no longer aborts wholesale when a single alias cannot resolve its source at apply time ("Migration failed Add 'X': alias source 'Y' was not found"). One orphaned alias used to throw inside the apply transaction and roll back every other reviewed change. It is now skipped with a named warning — matching how the preview already treats unresolvable aliases — and the remaining changes apply, verify, and persist normally.
- Compact tooltips now size to their text. The JS width estimate is used only for positioning; forcing it as the bubble's width made short labels render as too-wide bubbles.

## v1.3.270

- Fixed the Migrate Variables preview collapsing into a thin bar. The preview list is a scrollable flex child, which lets flex shrink it to zero height when the panel content overflows; it now keeps its own height (min 96px, max 210px) and the panel scrolls instead.
- Fixed compact tooltips rendering as long caret-less pills. The bubble's own overflow:hidden — needed for text ellipsis — was clipping the caret, which sits just outside the bubble's edge. The ellipsis now clips an inner text element, so every tooltip keeps its caret.

## v1.3.267

- The "Pretty URLs are not active" warning no longer shows when everything actually works. The server-side probe requests its own domain, which false-negatives on local sites; the check is now advisory and the browser re-verifies it directly — the row shows "confirmed from this browser" on success and only warns (with instructions) when the browser cannot reach /wp-json either. An unreachable self-probe also no longer downgrades a clean restore to "passed with notes".

## v1.3.266

- The rewrite-rule repair now actually lands. Two silent no-ops defeated the v1.3.265 version: when several restore steps run in one request the rewrite engine still holds the pre-swap plain-permalink state (writing empty rules), and WordPress' own writer quietly refuses under PHP-FPM where it cannot detect mod_rewrite. The repair now re-initializes the rewrite engine from the restored permalink option and writes the rules block directly, so a manual Settings → Permalinks save should no longer be needed.
- If pretty URLs still do not answer, the post-restore verification report now says so in its own row with the exact action: "open Settings → Permalinks and click Save Changes once."
- "View restore steps" now renders as status dots with plain text in all report containers (the previous styling missed one), matching the job-card design.

## v1.3.265

- Found via console debugging: after a restore, the destination site could be fully restored yet look broken — the restored database brings pretty permalinks, but the destination's protected .htaccess had no WordPress rewrite rules, so every /wp-json request 404'd at the web server before WordPress ran. All Studios showed "WordPress returned an error while loading data" against a perfectly restored site.
- MV's panel now falls back automatically to the query-string REST route (?rest_route=), which needs no rewrite rules, whenever /wp-json 404s — and remembers the working form.
- The restore now repairs the rewrite rules itself: post-restore hardening loads the admin file helpers (flush_rewrite_rules cannot write .htaccess during AJAX without them), writes the standard rules, and probes /wp-json until it answers JSON, reporting a warning if the server still refuses.

## v1.3.264

- Fixed the last silent truncation point: the restore reads workspace copies of the package, and a partial extraction could leave a short files.restorebase that the bundle reader treated as a clean end — so a restore completed green while the site was missing its tail files. Prepare Workspace now verifies every extracted copy against the package's recorded checksums (re-streaming a bad copy once) and refuses the workspace with exact byte counts if it still mismatches — before anything destructive runs. The file-restore step is additionally held to the file count recorded at backup time and fails with "read X of Y" if the bundle ends early.
- "View restore steps" now matches the job-card design: a status dot and plain text per step instead of filled pills.

## v1.3.263

- Import now verifies bundle completeness: the file entries actually present in files.restorebase are counted and compared against the count recorded when the backup was built. A truncated package — the class that restored half a site while passing every checksum — is rejected at import with the exact counts ("holds 20,000 of 47,000 recorded files") instead of restoring silently.
- Fixed the footer status dot floating detached from its message when the text wraps to two lines.

## v1.3.262

- Fixed backups silently shipping only the first ~20,000 files. The bundler re-reads the file inventory on every batched request; if that read ever failed it came back empty, and the bundler finalized the truncated bundle as a success — which then passed every checksum, imported as "Verified", and restored half a site whose broken plugins turned Studio requests into HTML errors. The bundler now fails loudly when the inventory is empty or changes size mid-bundle, so an incomplete package can never be produced.
- The restore now runs WordPress' silent database upgrade when the restored database carries a different db_version, so wp-admin is no longer intercepted by the "Database Update Required" screen after a restore.
- Backup ages now show hours and minutes ("1h 22m ago") instead of rounding to the hour, and the Recovery footer gives its status message proper spacing instead of cramming it against the version text.

## v1.3.261

- A MV settings verification miss can no longer abort the restore. The settings step runs after the database swap but before files are copied and the site is finalized, so failing it left a half-restored site — files never copied, rewrite rules never flushed, Studios reading no content — which is the exact outcome it was guarding against. The step now always completes; a read-back mismatch stays visible in the step report and names the affected groups.

## v1.3.260

- Recovery backup creation now waits for current MV browser preferences to persist before its manifest is built. The portable Bar and Studio preference allowlists include the live panel, editor, media, and position settings, and restored server preferences replace stale local browser copies.
- Portable MV writes invalidate both direct and aggregate WordPress option caches plus user caches. Every carried group is read back, and a mismatch fails the restore task instead of being marked successful.
- The shared Studio API refreshes an expired WordPress REST nonce and retries once after a restore. Content Studio and Media Studio retain their current data and show the actual error if access still fails rather than displaying a false zero-item site.
- Post-restore hardening reloads the destination administrator's role/capability runtime.

## v1.3.257

- Fixed a restore being marked failed at the final "Restore MV Settings" step even though the database and files restored correctly. The MV settings verification read stale option values after the raw database swap (the autoloaded 'alloptions' cache was not cleared), so it wrongly reported the just-written settings as unverifiable. The cache is now cleared correctly, and — as a safeguard — MV settings portability can no longer fail a restore whose core work already completed; a verification miss is reported as a note and names the affected groups.

## v1.3.256

- Fixed backup import rejection ("incomplete or corrupted (files.restorebase)") for good, including on hosts where the v1.3.255 file lock was silently ignored. Two things now guarantee a package matches its own checksums: the backup job is serialized with a database advisory lock so two overlapping requests can no longer finalize the bundle at once, and the component checksums are recomputed from the files on disk in the same step that packages them, so the recorded size can never disagree with the shipped bytes. New backups made on this version import and restore correctly; backups built by earlier versions must be re-created.

## v1.3.255

- Fixed the backup-import "incomplete or corrupted (files.restorebase)" rejection at its real root. When a slow finalize outlasts the client's request timeout, the client re-issues the job and two executions finalize the bundle at once; the v1.3.254 guard still had a check-then-write race that let the end marker be written more than once. Finalization is now made atomic with an exclusive file lock, so exactly one end marker is written no matter how the requests overlap. New backups made on this version import and restore correctly.
- Fixed backup timestamps showing a wrong relative age (e.g. every backup reading "1h ago" the moment it was made) when the site timezone differs from the viewer's. The site's UTC offset is now used to compute the age.

## v1.3.254

- Fixed backups being rejected on import as "incomplete or corrupted (files.restorebase)". Under concurrent job polling the file bundle's end marker could be written twice, leaving the packaged bundle a few bytes larger than its recorded checksum. Finalization is now idempotent, so the recorded size always matches the packaged bundle. New backups made on this version import and restore correctly; backups built by earlier versions must be re-created.

## v1.3.253

- Backup filenames now use the Mimam's Var plugin version (e.g. v1.3.253) instead of the Recovery module's internal version (v1.0.0-rcNN).
- Import errors now state exactly why a package was rejected — whether a component is the wrong size (truncated) or fails its checksum (altered) — instead of a generic "download did not finish."

## v1.3.252

- Gave CSS Recipes its own Studio rail entry, so it shows the rail and stays reachable while other Studios are open, and stopped it being force-closed when CSS Studio is disabled.
- Bundled the Phosphor duotone icon set (MIT) with the plugin instead of loading it from jsDelivr, so icons no longer depend on a third-party CDN being reachable.
- Fixed Media Studio icons that silently fell back to a generic file glyph (Save metadata, Import, Restore, Insert Media URL, safety notes, and most of the collection icon picker).
- Replaced two icon names that are not in the Phosphor set (`bricks`, `wordpress-logo`), which rendered nothing on the Content Studio editor links.
- Replacing a content image now carries the new attachment's alt text across; it previously read a field the REST attachment does not have and kept the old alt.
- Fixed dynamic tooltips showing the previous label until the element was hovered twice, and made a tooltip repaint in place when its label changes under a stationary pointer (canvas theme toggle).
- Recovery now says a reload is needed when it is re-enabled after the page loaded, instead of appearing to do nothing.
- Fixed post-restore MV settings verification reporting a false failure. It compared the package against the destination outright, but the write is a merge: key order and destination-only keys both read as mismatches, which failed the step for Mimam's Bar and Studio preferences even though every value transferred.

## v1.3.176

- Optimized Media Studio collection query performance by implementing `ve_media_collections_list` Transient caching inside `MediaCollectionManager`, preventing N+1 taxonomy queries during REST lookups.
- Added dynamic WP taxonomy hooks (`created_mv_media_collection`, `edited_mv_media_collection`, `delete_mv_media_collection`, `set_object_terms`) to automatically invalidate the cached collections transient.
- Hardened SVG masonry previews by injecting min-width/height fallbacks to prevent raw SVG files lacking intrinsic dimensions or viewBox definitions from collapsing.

## v1.3.175

- Fixed SVG previews in Media Studio Masonry view by forcing SVG assets to use the original attachment URL before generated thumbnail sizes, preventing SVG helper/plugin placeholder stripes from appearing as line previews.
- Added final masonry SVG containment rules so vector previews sit inside stable card boxes without affecting the working image masonry layout, builder picker insert flow, or AT/Code2Bricks suggestions.

## v1.3.174

- Tightened Media Studio builder picker behavior after v1.3.173 QA.
- Improved builder Masonry view with safer image-first picker filtering, larger/steadier masonry cards, fewer cramped columns, and cover-based thumbnail filling for non-SVG images.
- Made media double-click insertion independent of browser `dblclick` reliability by tracking two close clicks on the same media item, while disabling media dragging in picker mode so drag behavior cannot swallow the insert action.
- Preserved the restored Advanced Themer and Code2Bricks suggestion behavior from v1.3.173.

## v1.3.173
- Fixed Media Studio Masonry view inside Bricks Builder by forcing stable masonry card boxes in nested builder overlays, including SVG/line-art assets that were collapsing into thin strips.
- Changed the Masonry toolbar/dropdown icon to the clearer Columns icon instead of the previous custom masonry icon.
- Fixed double-click media insertion by detecting browser click detail and adding double-click event aliases, so draggable media cards still insert in builder picker mode.
- Restored Mimam's Var's CodeMirror runtime/addons so Advanced Themer, Code2Bricks, and Bricks code editors keep their autocomplete/suggestion behavior. MV's hint styling remains scoped to CSS Studio only, so suggestion styles should no longer leak into other editors.

## v1.3.172
- Reworked the Masonry view icon to a clearer uneven-column masonry symbol.
- Hardened Media Studio masonry cards inside Bricks so very wide/tall assets cannot collapse into thin line cards.
- Fixed the picker insert button so it no longer receives the click event as the media item.
- Fixed the WordPress media-frame bridge callback context so Bricks receives selected media from both Use Selected Media and double-click selection.
- Stopped the picker flow from falling back to copying the media URL when Bricks insertion fails.
- Removed Mimam's Var's global CodeMirror CDN enqueue so CSS Studio no longer overrides Code2Bricks, Advanced Themer, or other builder code editor styling/suggestions. CSS Studio still uses its own fallback editor and will use an existing complete CodeMirror instance when another tool already provides one.

## v1.3.171
- Fixed Media Studio URL import history Clear button styling so it no longer inherits the compact icon-button sizing.
- Stabilized Media Studio Masonry view with explicit media aspect placeholders so thumbnails do not collapse into a thin line before images load.
- Added a dedicated Masonry view icon instead of reusing the grid icon.
- Added builder picker double-click support: double-clicking a media item now inserts/uses the selected media immediately when Media Studio is opened for picking.
- Scoped CSS Studio CodeMirror hint styling and hint containers to the CSS Studio editor so Bricks/native builder code editors and suggestion popups are not affected.

## v1.3.170

### Fixed

- Contained Content Studio rich-editor images so inserted media cannot break the editor/SEO layout.
- Reverted the editor theme control to a compact text toggle.
- Improved Content Studio media picker collection rendering with parent/child indentation and faster prepaint from cached media when switching collections.
- Hid the extra editor note strip and added safer scroll padding above the fixed action area.
- Added final Content Studio layout overrides for toolbar centering, action bar consistency, code blocks, and editor image sizing.


## v1.3.169 - Content Studio Picker + SEO Polish Regression Fix
- Normalized Media Studio masonry SVG sizing and gap handling.
- Restored Content Studio media picker collection list from WP-backed collection maps.
- Tightened Content Studio editor/metadata/SEO layout so sections do not create stray empty bands.
- Improved keyword pill styling, light/dark editor toggle styling, centered editor utility buttons, and SEO check labels.

# v1.3.168 — Content Studio Picker + SEO Editor Refinement

- Fixed Media Studio masonry SVG sizing so small SVG assets fill their masonry column width while preserving natural aspect ratio.
- Upgraded the Content Studio media chooser toward the Media Studio experience with collections, default masonry view, grid/list switching, refresh, search, drag/drop upload, and upload button support.
- Tightened Content Studio editor layout so the content editor remains on the left, meta fields stay on the right, and SEO sections no longer overlap during scroll.
- Centered Clear/Undo/Redo in the content editor toolbar and changed the Light/Dark control to a compact icon toggle.
- Improved focus keyword pills: better contrast, equal padding, and full-height alignment inside the keyword input row.
- Added visible code-block styling for the rich editor.
- Improved SEO check rows with live pass/fail wording and stronger pass/fail styling.
- Calmed the SEO field surface background while keeping the SERP/social previews distinct.

# v1.3.167 — Content Studio Layout + Picker Cleanup

### Fixed

- Tightened SVG masonry cards so SVG previews no longer carry extra visual wrappers or artificial card height/width.
- Reworked Content Studio edit layout so the content editor sits on the left and the post meta panel sits on the right.
- Removed the sticky meta-panel overlap while scrolling the edit form.
- Converted the writing theme control into a real compact toggle.
- Centered Clear/Undo/Redo in the editor toolbar.
- Improved focus keyword pill/input height alignment.
- Polished the MV media picker grid so image cards use consistent usable preview sizes.
- Normalized Content Studio border radius and replaced the dark action-footer block with a quieter panel footer.

## v1.3.166 - Content Studio Media Picker + Editor Layout Polish

### Fixed
- Equalized Media Studio masonry spacing again and removed the dark card background from SVG previews.
- Replaced browser prompt dialogs in the Content Studio rich editor with MV inline dialogs.
- Replaced the default WordPress media chooser in Content Studio SEO/social image fields with a native MV Media Studio picker so Content Studio stays open.
- Added a split Content Studio edit layout with title/status/slug/excerpt on the left and the writing editor on the right.

### Added
- Added a light/dark mode toggle to the Content Studio writing editor.

### Changed
- Tightened oversized SEO/social image URL inputs and focus keyword input height.
- Moved rich-editor utility actions to the far right of the toolbar.

# 1.3.165 - Content Studio Scroll + Masonry Gap Fix

- Fixed Media Studio Masonry spacing so row and column gaps use the same masonry gap token.
- Removed conflicting masonry item margins so vertical spacing is controlled by the masonry column gap only.
- Fixed Content Studio edit mode so the form has a real internal scroll area instead of compressing all sections to fit the modal height.
- Kept the action bar fixed outside the scroll area while the content/SEO/custom-field sections scroll naturally.

# 1.3.162 - Content Studio Writing + SEO Polish

## v1.3.164 — Masonry row gap + Content Studio spacing polish

- Restored visible row spacing in Media Studio Masonry by applying the gap directly to the JS masonry columns and individual cards.
- Reworked the Content Studio edit screen into a roomier structure: metadata panel, larger writing editor, larger SEO workspace, and more breathing space between sections.
- Increased rich editor height and padding so writing no longer feels squeezed.
- Enlarged the Rank Math-style SEO workspace with wider field/preview columns while keeping the live preview/checks on the side.


## v1.3.163 — Content Studio Rank Math workspace + masonry restore

- Restored real Media Studio masonry by using medium/large natural-ratio previews instead of square thumbnails.
- Fixed Media Studio collection expand/collapse persistence so stable collection keys are not overridden by old label-based state.
- Restored the Content Studio rich writing surface even when a post type reports editor support inconsistently.
- Rebuilt the Rank Math area into a two-column SEO workspace with live SERP/social previews, focus keyword pills, checks, social image controls, robots options, schema type, and advanced placeholders that respect free/pro limits.
- General SEO values now update live previews immediately, including slug/permalink changes; Facebook and Twitter previews fall back to general values unless edited directly.


- Optimized Media Studio previews so Masonry no longer asks for full/original image files and images use lazy/async loading outside detail preview.
- Restored visible row spacing in the JS Masonry columns.
- Hardened Media Studio collection tree collapse persistence with stable collection-key storage plus legacy path fallback.
- Replaced the large Content Studio dashboard cards with compact status pills that include counts.
- Added Content Studio table column visibility controls, similar to Media Studio list metadata controls.
- Strengthened Content Studio action icons so the right-side action buttons do not render as empty boxes.
- Hid noisy analytics/plugin meta such as view counters from editable custom fields.
- Expanded the Content Studio rich content editor with H4, underline, strikethrough, code, link, image URL, divider, clear formatting, undo, and redo controls.
- Added editable Rank Math SEO, canonical, robots, Facebook/Open Graph, and Twitter fields inside the Content Studio edit form.
- Added first-pass ACF Options Page discovery and editing under a dedicated Options Pages section in Content Studio.

# 1.3.161 - Content Studio Cleanup + Masonry Stability Polish

- Rebuilt Media Studio Masonry view into JS-distributed columns so the full result set renders vertically instead of showing only the visible slice.
- Made the Media Studio view switcher easier to use with delayed hover close, click toggle, and outside-click dismissal.
- Cleaned Content Studio edit forms by hiding noisy Rank Math internal fields and removing the Advanced WordPress Fields panel from the main Studio flow.
- Hid Plugin/System Types from the Content Studio sidebar for now so the panel stays focused on real content records and custom field groups.
- Increased Content Studio sidebar width to better match the Media Studio adjustment/sidebar feel.
- Forced Content Studio rich-editor text and heading colors to stay readable inside the dark MV UI.
- Restyled Content Studio table actions into primary actions and compact icon actions for a calmer right-side area.

# 1.3.160 - Default Content Types Polish + Masonry Ratio Fix

- Fixed Media Studio Masonry view to preserve image aspect ratios and avoid horizontal scrolling.
- Polished Content Studio default Pages/Posts area with MV-style sidebar groups, dashboard cards, table rows, hover actions, and form inputs.
- Added Rank Math SEO summary data for Pages/Posts in Content Studio.
- Added Bricks post type support detection so Edit in Bricks only appears for post types enabled in Bricks settings.
- Kept WP editor access visible for block/plugin-specific editing.

# v1.3.159 — Media Studio View Fixes + Content CRUD Layer

- Fixed the Media Studio view dropdown so Grid, Masonry, and List render as clear MV-styled menu rows.
- Reworked Masonry View away from CSS multi-column layout so it scrolls top-to-bottom instead of creating horizontal scroll.
- Added richer Content Studio content CRUD: create with title/status/slug/excerpt/content, edit core fields, duplicate as draft, move to Trash, restore from Trash, and permanently delete from Trash.
- Added Content Studio status dashboard cards and status tabs for Active, All, Published, Drafts, Pending, Private, and Trash.
- Added CPT label editing for MV-created ACF/Jet post types, while keeping existing CPT create/delete behavior.
- Added a REST duplicate endpoint for Content Studio posts/CPT entries and strengthened content create/update handling.

# v1.3.158 — Media Studio Filter/Masonry Cleanup

- Cleaned the Media Studio filter popover so search results are visible first and diagnostics no longer cover filtered results.
- Restyled the diagnostics Rescan action as a proper MV button and hid diagnostics while typing in filter search.
- Removed the extra sidebar overview note now that dashboard cards own those stats.
- Added Masonry View as the third media view alongside Grid and List.
- Kept collection tree collapsed/expanded state persisted through the existing Media Studio local preference store.

# v1.3.157 — Media Studio Dashboard Summary Cleanup

- Removed the duplicate bottom-left Total Assets / Storage Used stats card from the Media Studio sidebar.
- Left the top dashboard overview as the single source for total media, storage, missing alt text, unused media, large files, and recent uploads.
- Added a small sidebar note so the sidebar no longer looks like a second dashboard.

# v1.3.156 — Media Studio Safety, Export, Diagnostics

- Fixed the attached collection context menu placement so the Delete row stays inside the rounded menu box.
- Added Media Studio diagnostics endpoint for total size, missing alt, large files, recent uploads, missing files, empty titles, and duplicate filenames.
- Added selected-media ZIP export from the bulk action bar.
- Added usage-aware delete and replace confirmation checks, with detected references shown before destructive action.
- Added rollback history for replace, convert, compress, and rename operations, with restore support from Media Studio.
- Added URL import history storage with success/failure entries and a small recent-imports panel in the URL import preview.

## 1.3.155 - Media Studio tooltip placement fix
- Reworked MV global tooltip positioning so long tooltips are measured/estimated before placement.
- Tooltips now sit fully outside the hovered control, avoid the cursor, and fall back to side placement when there is not enough room above or below.
- Native browser title bubbles continue to be converted into MV-styled tooltips inside the panel.

## 1.3.154 - Media Studio feedback polish

- Removed the duplicate Total Media overview card because total assets and storage already live in the sidebar summary.
- Replaced blocking media-loading whitespace with a non-blocking toast so grid/list content does not jump.
- Added a robust 5-second auto-dismiss for completed Media Studio progress toasts, including unused-image scan completion.
- Improved collection context-menu bottom padding and kept attached-menu arrow support.
- Clarified the bulk Compress tooltip: it rewrites supported selected image files through the WordPress image editor to reduce size, then refreshes metadata.

## 1.3.153 - Media Studio list, filters, bulk actions, and overview polish
- Media Studio: added a compact dashboard/overview strip for total media, missing alt text, unused images, large files, and recent uploads; overview cards activate the matching quality filter.
- Media Studio: polished the filter panel with active filter chips, a save-current-filter flow, and saved custom filter presets stored per browser.
- Media Studio: refined list/table view with sticky headers, selected/checked row states, stronger title/meta cells, thumbnail previews, and drag support from list rows.
- Media Studio: polished bulk actions into a clearer action bar with grouped Add to collection, Compress, Convert, Remove from collection, and Delete actions plus progress toasts.
- Media Studio: added a server-side image compression endpoint for selected image bulk compression.

## 1.3.152 - Media Studio color picker compact polish
- Media Studio: removed the internal scroll from the collection color picker and clamped the full compact popover into view instead.
- Media Studio: cleaned the selected color state so it uses a simple MV-style active ring instead of the dirty double/boxy mark.
- Media Studio: tightened the picker spacing and map height so the color popover fits without feeling unnecessarily tall.
- Native WordPress Media Library replacement remains paused.

## 1.3.151 - Media Studio positioning, scan timeout, and toast polish
- Media Studio: fixed the collection color picker so it opens inside the visible Media Studio panel instead of dropping to the floor/edge.
- Media Studio: fixed the Unused Images scan timeout guard so it actually stops the visible scan state after 35 seconds instead of staying stuck.
- Media Studio: restored the collection context-menu caret and added bottom breathing room so lower menus no longer sit tight against the edge.
- Media Studio: extended MV toast/progress completion visibility to 5 seconds so feedback is readable.

## 1.3.150 - Media Studio scan, color, menu, and ZIP polish
- Media Studio: restyled the collection color picker fields to stay on MV's dark input style instead of using light native-looking inputs.
- Media Studio: removed the dirty check badge from active collection color swatches and replaced it with a cleaner active ring.
- Media Studio: hardened the Unused Images scanner with a frontend stop guard, clearer timeout messaging, and a faster server-side scan path.
- Media Studio: clamped collection context menus with a taller measured height and scroll guard so lower menus no longer get cropped.
- Media Studio: changed ZIP import progress so upload progress caps before extraction, preventing the toast from claiming 99% too early.

## 1.3.149 - Media Studio filter and color picker polish

- Media Studio: polished the collection color picker toward the MV Variable Panel style and removed the duplicate/odd clear swatch, leaving one clear action in the footer.
- Media Studio: added multi-rule quality filters so Missing Alt Text, Unused Images, Recent Uploads, Large Files, shape filters, and size filters can be combined instead of being limited to one active rule.
- Media Studio: stopping/removing the Unused Images filter now clears the visible scan state and ignores stale scan responses, so the UI no longer keeps scanning after the filter is removed.
- Media Studio: added a safety timeout for long unused scans with a useful message to narrow collection/search/type filters and rescan.
- Media Studio: improved ZIP import progress feedback with Uploading ZIP percentage, Extracting ZIP busy state, and final completion feedback.
- Media Studio: refined Usage & replace impact hover styling and added a clearer open affordance on detected usage rows.
- Native WordPress Media Library replacement remains paused.

## 1.3.148 - Media Studio feedback polish

- Media Studio: restored clean metadata panel styling in both admin and builder surfaces, with stronger scoped input/textarea/button rules.
- Media Studio: fixed the collection color popover so it opens beside the clicked action and no native browser/OS color picker is used in this flow.
- Media Studio: moved Delete filter to the top of the filter panel and removed the duplicate shortcode card from Collection Details.
- Media Studio: changed Missing Alt Text and Unused Images long-running operations to use toast/progress feedback instead of replacing the media grid with a large empty busy block.
- Media Studio: optimized the Unused Images scan by batching reference detection across featured images, content, post meta, and options instead of doing one heavy scan per attachment.
- Media Studio: made the Unused Images rescan button disabled while a scan is already running.
- Media Studio: improved replace-file progress with upload/proccessing states and broadcast replaced media updates to other open Media Studio tabs.
- Media Studio: added clearer usage-impact helper copy and padded replace-history layout.
- Native WordPress Media Library replacement remains paused.

## 1.3.147 - Media Studio unused scanner, ZIP import, metadata polish

- Media Studio: replaced the collection custom color browser input with an MV-native color panel, opened beside the clicked menu/action instead of the OS picker.
- Media Studio: added an Unused Images filter backed by a server-side usage scan across featured images, content, post meta, and options.
- Media Studio: added ZIP import into a selected MV collection, with imported files assigned immediately to that collection.
- Media Studio: improved the Missing Alt Text workflow with inline saving and a bulk fill from clean filenames/titles.
- Media Studio: added a collection detail side panel with count, storage size, shortcode, lock/star/color status, quick actions, ZIP import, and collection preview.
- Media Studio: polished attachment details with caption/description editing, explicit save state, URL/tag copy actions, file-size data, and replace history.
- Native WordPress Media Library replacement remains paused.

## v1.3.146

- Media Studio: made starred collections meaningful by pinning them above normal collections and showing a visible star indicator on the collection row.
- Media Studio: replaced the random color-cycling action with a proper color picker modal, preset swatches, custom color input, Apply, Clear, and Cancel actions.
- Media Studio: added explanatory copy to the color picker so collection color is understood as a Media Studio accent only.
- Native WordPress Media Library replacement remains paused and was not touched.
- Plugin version bumped to 1.3.146.

## v1.3.145

- Made the MV media collection taxonomy more explicitly internal/private so SEO plugins should stop treating collection terms as public URLs.
- Persisted locked/starred/color collection metadata to WordPress-backed MV collections.
- Hardened locked collections: lock state now survives refresh/server sync and blocks rename, delete, move, add media, and remove media until unlocked from the context menu.
- Added collection context menu items for Star, Change color, Download all, and Copy gallery shortcode.
- Added Recent Uploads to the Media Studio filter list and renamed Missing Alt to Missing Alt Text.
- Plugin version bumped to 1.3.145.

## v1.3.144
- Media Studio: improved collection drag labels so reorder states now show “Before [collection]” and “After [collection]”.
- Media Studio: made the make-child/nest drop zone easier to reach, so users no longer need to drag far to the right.
- Media Studio: locked collection icons are now static and cannot unlock/open/move the collection by accidental click. Unlock remains available from the right-click menu.
- Plugin version bumped to 1.3.144.

## v1.3.143
- Fixed stale Add Media hover state after cancelled or incomplete media drags.
- Improved collection drag/drop state separation with clear Move Before, Move After, Make Child, and Add Media states.
- Added collection drop-after handling so children can be promoted back to parent level more reliably.
- Fixed nesting insertion so parent/child tree order stays intact after moving collections.
- Made collection list ordering tree-aware so expanded parent children render under their parent instead of breaking when object order changes.
- Kept Media Library replacement paused and full-area MV upload behavior intact.
- Plugin version bumped to 1.3.143.

## v1.3.142
- Locked page/background scrolling while the MV Settings panel is open in admin surfaces.
- Refined Media Studio add-media drop styling: rounded MV-style row, no thick left border, cleaner action pill.
- Fixed collection drag detection so collection reorder/nest states no longer fall back to the add-media drop state.
- Cleared stale media-drag state when starting a collection drag so selected media does not confuse collection reordering.
- Removed native cursor-covering tooltips from collection drag handles.
- Plugin version bumped to 1.3.142.

## v1.3.141
- Media Studio: removed the native browser tooltip from the collection drag handle so the drag hint no longer sits on top of the cursor.
- Media Studio: updated add-media, reorder, and nest drop indicators so each state has a distinct MV-styled visual treatment using the MV green accent instead of the blue temporary styling.
- Media Studio: fixed collection tree movement so dragging a parent into another collection moves the whole subtree, and dragging a child before a top-level collection promotes it back to that level.
- Media Studio: kept full-area MV file upload behavior from v1.3.140 and kept native WordPress Media Library replacement paused.
- Plugin version bumped to 1.3.141.

## v1.3.140
- Restored Media Studio full-area custom upload drop design while keeping native WordPress Media Library replacement paused.
- Removed the capture-phase drag guard that blocked React collection/media drag handlers, restoring collection dragging and drop styling.
- Replaced the aggressive event-blocking WordPress uploader suppression with a passive overlay hider so MV drag interactions can continue working.
- Kept WordPress core blue uploader overlay hidden while Media Studio is open, but allowed MV's own dark upload overlay for real OS file uploads.
- Fixed click-only drag candidates so simple collection clicks do not leave internal drag flags stuck.
- Plugin version bumped to 1.3.140.

## v1.3.139
- Paused native Media Library replacement remains enforced.
- Fixed Media Studio internal drag issue by suppressing WordPress core uploader overlay while Media Studio is open and during MV internal drags.
- Kept upload support restricted to the explicit Media Studio dropzone.
- Hid the auto-sync external folders setting unless an external folder plugin/folder source is detected.
- Removed the extra footer divider line in Settings → Modules.
- Plugin version bumped to 1.3.139.

## v1.3.138
- Paused the native WordPress Media Library replacement again so Media → Library stays on the default WordPress media screen while this flow is rebuilt safely later.
- Removed the runtime setting toggle for native Media Library replacement and replaced it with a paused status badge.
- Disabled the full-page blue file-drop overlay in Media Studio; uploads now rely on the explicit dropzone/upload control while collection/media drag behavior is stabilized.
- Kept drag/drop upload support available through the dropzone, without allowing internal media/collection drags to trigger the full-screen overlay.
- Plugin version bumped to 1.3.138.

## v1.3.137
- Fixed Media Studio runtime setting saves so toggling the native Media Library replacement no longer resets module enable/disable states.
- Hardened Media Studio internal drag detection so collection/media drags do not trigger the full-screen file upload overlay.
- Restored accurate expand/collapse tooltip copy for collection tree toggles.
- Plugin version bumped to 1.3.137.

## v1.3.136
- Fixed Media Studio regression where internal collection/media dragging could still trigger the full-screen “Drop files to upload” overlay.
- Preserved media selections across collection navigation so users can select media from multiple collections before taking batch actions.
- Restored the collection batch bar inside MV collection views by adding the missing `Remove from Collection` handler.
- Added safer removal logic that removes only selected media belonging to the currently open collection and keeps selections from other collections.
- Changed collection branch hover copy to neutral “Toggle children” to avoid wrong expand/collapse tooltips.
- Made the native Media Library replacement legacy switch safer by removing the active class and reloading the Media Library page after switching back.
- Added stronger internal drag detection with custom dataTransfer markers and capture-phase marking.
- Plugin version bumped to 1.3.136.

## v1.3.135
- Fixed Media Studio file-drop overlay so internal collection/media dragging no longer triggers the full-screen upload overlay.
- Restored SEO notices; MV no longer hides Rank Math/SEO notices for internal media collection taxonomy actions.
- Improved collection switching while media is selected: switching collections now clears selection and opens the requested collection with a notice.
- Fixed batch action bar reliability inside individual MV collections and kept Remove from Collection available there.
- Added safer native Media Library replacement close/legacy handling and a close button in the native replacement header.
- Reworked Mimam’s Bar Quick Help into a cleaner flat layout with no gradients, better alignment, and command rows that do not collide.
- Added stronger separation for collection reorder, nesting, and media-add drag states.
- Plugin version bumped to 1.3.135.

## v1.3.134
- Added URL import preview before server download so users can review filename, host, content type, and known file size before importing.
- Kept the 50 MB URL import limit, but now oversized files are blocked at preview when the remote server exposes Content-Length.
- Fixed Media Studio collection manual reordering by switching the collection sort to Manual after drag reorder.
- Improved collection drag/drop indicators with separate states for reorder, make-child/nest, and add-media drops.
- Added right-side drag hover behavior: dragging a collection toward the right side of another collection now previews dropping it as a child.
- Added “Remove from Collection” to the selected-media batch action bar when viewing an MV collection.
- Cleaned the Media Studio collection sidebar separator so the New Collection area no longer appears with double divider lines.
- Added autofocus/select behavior for collection name fields when creating collections.
- Hid external SEO redirect notices generated for the internal mv_media_collection taxonomy after collection rename/delete.
- Improved native Media Library replacement positioning so Media Studio scrolls into view immediately on Media → Library.
- Removed gradients from the MV Quick Help panel and tightened its visual language.
- Plugin version bumped to 1.3.134.

## v1.3.133
- Moved Media Studio URL import into the main toolbar beside Search media so it stays on the same row as search and filters.
- Restyled the URL import input with stronger admin-safe styles so WordPress admin input defaults do not make it appear unstyled.
- Changed the URL import action icon to a Phosphor `cloud-arrow-up` icon and kept the button aligned with MV toolbar controls.
- Added clearer URL import feedback for protected page links such as Pexels video/photo pages and forbidden remote downloads.
- Plugin version bumped to 1.3.133.

## v1.3.132
- Added WordPress-backed MV Media Collections using a dedicated attachment taxonomy so Media Studio collections are no longer only browser/localStorage data.
- Added REST endpoints for listing, creating, updating, deleting, syncing, assigning, and querying Media Studio collections.
- Added automatic migration/sync from existing local Media Studio collections into the WordPress-backed collection system.
- Added loopable media collection output through the `[mv_media_collection]` shortcode and a Bricks-friendly query hook for `mv_media_collection` object-type experiments.
- Re-enabled the native WordPress Media Library replacement toggle and added an instant “Use legacy library” switch inside the Media Studio replacement page.
- Added optional URL-import-to-open-collection support so imported media can land inside the current MV collection.
- Plugin version bumped to 1.3.132.

## v1.3.131
- Antigravity package handoff build. Media Studio work continued from the v1.3.130 state.

## v1.3.130
- **Improved Bulk Targeting Accuracy:** Hardened bulk selection logic by combining results from both Bricks data and canvas DOM. This ensures that mixed elements (e.g. Basic Text set to custom tag `li` vs native list items) are correctly unioned and targeted at the same time without omitting any matches.
- Plugin version bumped to 1.3.130 and Mimam’s Bar module version bumped to 0.3.28.

## v1.3.129
- Added a Mimam’s Bar setting to skip the bulk preview confirmation from Settings → Mimam’s Bar. Bulk commands still use the guarded matching/apply path and still stop above the safety limit.
- Fixed combined selector matching for commands like `all li.bulk-lab__item => data-anim="fade-up"` when Bricks exposes the element type as Basic Text instead of the rendered custom tag.
- Added a safe DOM fallback for class/comma/combined bulk selectors when Bricks element data does not expose enough selector information.
- Updated MV Quick Help again with the new skip-preview setting and clearer combined selector examples.
- Plugin version bumped to 1.3.129 and Mimam’s Bar module version bumped to 0.3.27.

## v1.3.128
- Added combined bulk target support in Mimam’s Bar: `all li.card-item`, `.card.is-featured`, comma groups like `all h2, all p`, and mixed class groups like `.card,.panel-card`.
- Kept bulk matching safe by using Bricks element data first and bounded canvas fallback only where needed.
- Updated the bulk preview wording for combined targets so it describes tag/class/ID combinations clearly.
- Updated the Quick Help panel with clearer Direct Mode, Bulk target, Combined selector, and mode-switch examples.
- Updated the inline example chips in Mimam’s Bar to include combined selector bulk commands.
- Mimam’s Bar module version bumped to 0.3.26.

## v1.3.127
- Improved Mimam’s Bar bulk confirmation wording with clear Target, Action, Scope, and Safety rows.
- Redesigned the bulk confirmation modal with a cleaner premium card layout, stronger visual hierarchy, and clearer primary action label.
- Mimam’s Bar module version bumped to 0.3.25.

## v1.3.126

- Fixed Mimam’s Bar bulk parser getting stuck on commands like `all li => data-anim="fade-up"`, which caused Firefox/Bricks to throw repeated out-of-memory errors before apply could finish.
- Bulk commands now consume the full input after parsing once instead of re-parsing the same `=>` command forever.
- Bulk tag matching now checks Bricks element data before touching the canvas DOM, and the DOM fallback uses a streaming TreeWalker instead of `querySelectorAll` to reduce memory pressure.
- Mimam’s Bar module version bumped to 0.3.24.

## v1.3.125

- Bulk syntax now forces Mimam’s Bar back into Direct mode without clearing the input.
- Page Search/Add Element live search is suspended immediately when the input looks like a bulk command.
- Pending element-search timers are cleared before opening/applying bulk confirmation.
- Bulk commands can now be applied with Enter even if the bar was previously in Search Page mode.
- Reduced the chance of Search Page scans fighting the console-proven bulk writer and causing Firefox/Bricks memory pressure.
- Mimam’s Bar module version bumped to 0.3.23.

## v1.3.124

- Rebuilt bulk apply from the console method that worked on Ahlfigh Bricks page.
- Bulk tag matching now uses canvas rendered `li` IDs and resolves them through the safe Bricks dynamic elements root.
- Removed Vue `toRaw` usage from the bulk ID lookup and light write path.
- Removed automatic full page element pre-scan when Mimam’s Bar opens.
- Disabled command suggestions while typing bulk syntax so Direct mode does not do unrelated selected-element suggestion work.
- Skips target refresh after successful bulk apply to avoid unnecessary selected-element attribute re-rendering.
- Mimam’s Bar module version bumped to 0.3.22.

## v1.3.124
- Hotfixed bulk apply memory path again for `all li => data-anim="fade-up"`.
- Bulk confirmation no longer scans/counts Bricks elements before the user confirms.
- Tag-based bulk matching now tries a canvas DOM ID lookup first, then resolves only those Bricks element IDs.
- Added bounded iterative fallback scanning with a hard guard instead of full cached tree scans.
- Light bulk writer now works on raw element/settings data where possible to reduce Vue reactive setter pressure.

## v1.3.122
- Hotfixed bulk tag matching and bulk attribute writes for commands such as `all li => data-anim="fade-up"`.
- Added lightweight bulk tag matching so `li` targets use Bricks settings/default tags instead of iframe DOM/Vue helper calls.
- Added a lightweight bulk attribute/id writer for simple bulk commands to avoid cloning/stringifying full element settings.
- Bulk apply now marks changed elements once after the batch instead of doing heavy per-element commit work.
- Reduced memory pressure in Firefox/Bricks during bulk preview/apply.

## v1.3.121
- Hotfixed Mimam's Bar bulk apply performance for commands like `all li => data-anim="fade-up"`.
- Removed verbose per-element bulk console logging that could retain large Bricks/Vue objects and exhaust browser memory.
- Stopped forcing a fresh full Bricks tree scan for every bulk preview/apply step.
- Reworked bulk commits to avoid iframe Vue-state crawling and deep equality checks per target.
- Batch invalidates caches and requests Bricks refresh once after bulk apply.

# CHANGELOG.md

## v1.3.82 — Dev

### Fixed
- Fixed the main MV panel boot crash caused by the toast helper being referenced before it was initialized during early module guard setup.
- Restored the normal floating MV launcher and admin-bar launcher target after confirming the panel boots in a real browser engine without falling back to the emergency MV button.

## v1.3.81 — Dev

### Fixed
- Hardened the WordPress admin-bar MV launcher so it binds immediately and through delegated click handling, even when admin footer scripts run after `DOMContentLoaded`.
- Added direct app-side `veToggleVariables` / `veOpenSettings` entry points so the toolbar and emergency controls can open MV without relying only on custom event timing.
- Added a small emergency MV boot button if the panel runtime fails before rendering, including a pre-boot guard for missing Preact/runtime dependencies.

## v1.3.80 — Dev

### Fixed
- Restored the MV floating launcher/speed dial after the native Media Library replacement could leave Media Studio marked open while the popup was not rendered.
- Scoped native Media Library replacement CSS so it no longer treats the whole MV root/backdrop as embedded page content, keeping the settings gear available as the global escape hatch.
- Preserved the embedded Media → Library page replacement while keeping Settings and the speed dial accessible.

## v1.3.79 — Dev

### Fixed
- Reworked Media Studio Masonry to use a direct natural-proportion column flow instead of the manual lane renderer, preventing square-grid fallback, empty guide columns, and non-scrollable masonry panels.
- Strengthened Admin/Builder module deactivation propagation so disabled CSS Studio, Media Studio, Plugin Studio, and Mimam’s Bar states are saved, rebroadcast, and refused/closed across shortcuts, speed dial, global toggles, Mimam’s Bar, and builder media interception.
- Tightened the opt-in native WordPress Media Library replacement so Media → Library embeds MV Media Studio inside the normal admin content area rather than behaving like a popup overlay.
- Corrected tall image preview wrappers so Fit width, Actual size, and Pan/zoom use the full image surface from the real top-left.
- Preserved the working media drag-to-collection path while keeping internal media drags separate from upload drop overlays.

## v1.3.65 — Dev

### Fixed
- Folder-plugin parent folders now count and filter media from all descendant folders, so a parent like `Project Files / Brands` reflects child assets instead of showing `0`.
- Detected folder-plugin rows no longer display the `MV` pill; only MV-owned local collections show `MV`.
- The folder migration modal now uses proper compact MV buttons for Select all and Clear actions instead of tiny link-style controls.

### Changed
- Settings and Media Studio use the same descendant-aware folder counting logic so sidebar counts, settings counts, filtering, and migration previews stay consistent.

## v1.3.64 — Dev

### Changed
- Redesigned the Media Studio folder-plugin integration settings card as a real nested MV tree with leaf-only labels, line guides, folder icons, counts, and quiet `MV` badges.
- Shared Media Studio folder expand/collapse state between the sidebar and Modules settings so the same hierarchy state persists locally after reload.
- Replaced the old external-folder badge language with `MV` across local and external folder rows so migrated and MV-shown folders use one product vocabulary.

### Fixed
- Fixed Modules settings only showing a detected-folder count by making the actual folder hierarchy visible and manageable before migration.
- Removed leftover browser-default/small-text risk in the touched folder migration surfaces.

## v1.3.63 — Dev

### Changed
- Polished Media Studio folder migration layouts so setting rows, action controls, and helper text follow the current MV height and spacing rhythm.
- Added visual line guides to the nested Media Studio sidebar hierarchy tree so sub-collections read as a clear structure rather than a flat list.
- Persisted Media Studio sidebar and Modules settings folder expand/collapse state locally so the tree stays where the user left it after reloads.
- Changed external folder badges to `MV` to match the current product language for MV-managed or migrated folder data.

### Fixed
- Fixed sidebar list node parsing and layout regressions that could break nested folder display.

## v1.3.62 — Dev

### Added
- Folder Hierarchy Display: Render nested collections in a visual hierarchy tree in the sidebar, showing only the leaf names for nested collections, with tree caret toggles to expand/collapse sub-collections and a compact "EXT" badge for external folders to avoid text overlap.
- Folder-Plugin-to-MV Migration UI: Added a folder-plugin migration section under Media Studio settings in Modules settings. Added a clean warning confirmation modal to migrate all detected folders to local collections, toggle hiding of external folders in the sidebar, and confirm action.
- State Synchronization: Real-time event communication between the settings panel and Media Studio for seamless layout updates without page reload.

## v1.3.61 — Dev

### Removed
- Completely removed the codebase languages distribution bar from the settings General tab.


## v1.3.60 — Dev

### Fixed
- Reverted builder panel user interface styling from rem back to px, resolving the 1.6x layout enlargement caused by the WordPress Admin root font-size.
- Fixed settings panel tab container class name and layout to prevent squishing, restoring visibility to all tabs (General, Mimam's Bar, CSS Studio, Modules).
- Relocated codebase languages bar from the Sync sub-panel to the General Settings tab.
- Corrected Notion integration active checks and release notes.


## v1.3.59 — Dev

### Added
- Integrated a GitHub-style languages distribution bar (PHP 78.5%, JS 18.2%, CSS 3.3%) into the builder settings panel to visualize codebase distribution.

### Changed
- Redesigned snapshot cards in the builder panel to look like proper UI cards: Restore and Delete/Archive buttons look like proper clickable actions, spacing is structured, and metadata (Snapshot number, exact timestamp, affected counts) is clear and readable.
- Refactored builder UI styling to use the centralized variable system instead of hardcoded static values.
- Implemented a 10px = 1rem grid rhythm with rem-based margins, padding, and font-sizing, enforcing an 11px (1.1rem) minimum text size boundary.
- Converted the database cleanup action to be unconditionally visible in the Database settings section.

### Fixed
- Fixed category and palette name isolation during Figma/file imports to prevent leakage into fallback options when origin data is empty or generic.

## v1.3.58 — Dev

### Fixed
- Snapshot titles and descriptions are now correctly decoded and rendered in the UI even when the snapshot is flagged as "Unavailable" due to warnings or validation failures.
- Converted the inline "Create recovery point" form into a clean dialog modal shown only when clicking "+ New Snapshot".
- Stale or orphaned generator rows referencing deleted or non-base variables are now automatically identified and deleted during database cleanup to prevent snapshot validation failures.
- General `/sync/apply` and `/sync/drift/apply` imports (from Figma or files) now correctly isolate variables under their own source-named categories and color palettes instead of fallback AT/CF options.
- Fixed empty Description tab in WordPress 'View details' modal by providing explicit HTML sections in the dev manifest.
- Updated plugin row metadata links to display: `Version | By Hebronmimam | View details | User Guide | Support | FAQs | Cheat Sheet`, pointing Hebronmimam to `hebronmimam.com` and User Guide to Notion documentation.

### Reliability
- Updated the verification checklists and ensured all PHP 7.4 compatibility rules are fully validated.

## v1.3.57 — Dev

### Added
- Provenance pills now act as source filters for MV, FILE, Figma, AT, CF, and ACSS.
- Source counts and a source-wide selection action now compose with Category, Color Palette, and text search.
- Sync Drift compares Mimam's Var with the paired Figma collection or Bricks global-variable registry.
- Sync Drift supports previewed Pull and Push plans, explicit conflict rows, snapshot-protected pulls, adapter-owned Bricks pushes, and queued paired-Figma pushes.
- Manual snapshots now support a meaningful title and optional description.

### Changed
- Snapshot cards now explain what each recovery point protects and show the snapshot number, time, source file, and reviewed change count where available.
- JSON, DTCG, Flat, CSS, System Bundle, and Sync Drift imports attach readable context to their automatic pre-import snapshots.
- The Figma companion now publishes a current collection report and processes partial queued Drift pushes without replacing its full WordPress-to-Figma identity map.

### Reliability
- Expanded the core reliability suite to 158 assertions covering snapshot context, composable provenance filtering, source-wide selection, Drift preview/apply contracts, Bricks adapter ownership, and paired Figma reporting.

## v1.3.56 — Dev

### Added
- Native variables now display a compact `MV` provenance pill.
- Generic JSON, DTCG, Flat, and CSS file imports now display a `FILE` provenance pill.

### Changed
- Provenance pills use a quieter neutral surface, softer border, restrained text color, and lower font weight so they support scanning without competing with variable names and values.
- File provenance now follows imported value updates, generated-family repairs, and alias relinks instead of being limited to newly created rows.
- Existing AT, CF, ACSS, and Figma provenance remains distinct and explicit.

### Reliability
- Expanded the core reliability suite to 152 assertions with coverage for DTCG, Flat, Figma collection, Figma handoff, explicit-origin preservation, update propagation, alias relinks, and MV/FILE UI labels.

## v1.3.55 — Dev

### Fixed
- Figma, flat JSON, and framework imports now decide generated-child editability from the active MV generator registry instead of unreliable historical `generator_type` labels.
- Imported/manual family children such as `text-2xl` update in place while preserving their parent, exact token name, value, relationship metadata, and source tag.
- True calculated generator children no longer roll back an otherwise valid import when an external file contains a different child value.

### Changed
- Import Preview now shows calculated child differences as `LOCK` rows with a direct explanation that the base variable or generator settings own the value.
- Protected calculated rows are excluded from the Apply count and safely skipped during normal imports and external migrations.

### Reliability
- Expanded the core reliability suite to 144 assertions with an import scenario matrix covering unchanged rows, base updates, alias relinks, editable imported families, calculated-family protection, repeat-import idempotency, and external verification.

## v1.3.54 — Dev

### Fixed
- Applying an UPDATE to an existing imported generated child no longer routes through the normal editor that blocks generated-variable edits.
- Figma and flat imports now preserve the existing parent relationship and `imported` generator type when updating generated children such as `radius-l`.
- Calculated Color and Fluid generator children remain protected from direct imported-value edits.

### Reliability
- Added regression coverage for parent preservation, imported generator-type preservation, and calculated-family protection.

## v1.3.53 — Dev

### Fixed
- Import Preview no longer proposes `ADD` for an exact generated variable that already exists, including T-shirt family children such as `radius-l` and `text-xl`.
- Applying a Figma handoff or flat import containing existing generated children no longer rolls the complete import back with a duplicate-variable error.
- Explicitly imported generated children still remain excluded from deletion when omitted from a partial import, while changed children preview as updates.

### Reliability
- Added regression coverage for unchanged and changed hyphenated T-shirt generated children.

## v1.3.52 — Dev

### Fixed
- Sync/import validation errors where different dot-notation names (such as `size.text.2xl` and `text.2xl`) would map to the same public CSS custom property (`--text-2xl`) and crash validation.
- Figma plugin exports now calculate and include `public_css_name` and `external_css_name` to enable rename matching during WordPress import.
- WordPress importer now computes robust default fallbacks for `public_css_name` and `external_css_name` if they are missing or empty in flat sync or handoff files.

## v1.3.51 — Dev

### Added
- Direct Figma local-file handoff using a dedicated companion format (`mimams-var-figma-handoff` JSON) exported from the Figma plugin for offline imports.
- Re-styled Figma pairing panel to include an option to export the local handoff file.

### Fixed
- Sync/import now preserves variable alias relationships, mapping incoming Figma variable aliases (which point to parent variables) correctly as `type: 'alias'` and resolving their source links.
- Set imported Figma variables' origin metadata explicitly to `'figma'` to display a clean origin badge.

## v1.3.50 — Dev

### Fixed
- Usage & Impact no longer counts the `bricks_global_variables` definition registry as a real consumer.
- Persisted Bricks references are separated from the currently open Bricks document and display the saved post title plus post ID.
- Generic saved references now appear under Other WordPress storage instead of being mixed with Bricks content.

### Changed
- Single and batch deletion now use a wider MV-styled impact dialog with a clear destructive header, readable token name, contained consumer list, and balanced Keep/Delete actions.
- Navigating from an affected consumer closes the delete confirmation before opening the destination.

### Reliability
- Added regression coverage for registry exclusion, saved Bricks labeling, usage-source separation, and the redesigned delete confirmation.

## v1.3.49 — Dev

### Added
- Variable detail now shows a unified Usage & Impact view covering aliases, Themes, CSS Studio stylesheets, custom CSS Recipes, current Bricks elements, and matching WordPress storage.
- Usage rows navigate directly to the referenced variable, Theme manager, exact CSS Studio stylesheet, CSS Recipe, or Bricks element where supported.
- Variables with no detected consumers are clearly marked Unused.
- Rename, type-change, family relationship, single-delete, and batch-delete surfaces now show affected consumers before changes are applied.

### Changed
- Searchable Family selectors rank exact and prefix token matches above broad substring matches.
- Arrow Up/Down, Home/End, and Enter now navigate and select the highlighted Family option.

### Reliability
- Bricks and CSS Recipe usage scans are lazy and run only when a Usage or Impact surface is opened.
- Added regression coverage for keyboard selection, relevance ranking, usage navigation, unused status, and mutation impact previews.

## v1.3.48 — Dev

### Changed
- Family Destination root, Current family root, and New root selectors now span the full available panel width.
- Family root and child dropdowns now include token-name search with an explicit no-results state.

### Reliability
- Searchable behavior is opt-in to the Family selectors, preserving the dimensions and behavior of compact dropdowns elsewhere.

## v1.3.47 — Dev

### Fixed
- Shift-range checkbox selection no longer highlights variable names and values between the selected rows.
- Family root detection now derives the current family from the selected generated children when they share one parent, instead of falling back to the first family in the dataset.
- Selecting children such as `text-xl` through `text-7xl` now opens Change Root against their actual `text` family.

### Reliability
- Added regression coverage for non-selectable variable rows and selected-child common-parent inference.

## v1.3.46 — Dev

### Fixed
- Select All now visibly checks every matching root and expanded generated-child checkbox instead of updating only the batch count.
- Individual and Shift selection now use the same normalized numeric identity as Select All, preventing string-versus-number ID mismatches.

### Reliability
- All checkbox rendering, selected-row styling, range checks, and Select All state now read from one normalized selected-ID set.
- Regression coverage rejects direct mixed-type row-ID comparisons.

## v1.3.45 — Dev

### Fixed
- The selected-variable review tray now opens automatically when one or more selected variables move outside the current visible list.
- Closing the automatically opened tray remains respected until the hidden selection set changes.

### Changed
- The batch control now says `Review … selected` and shows a hidden-selection count, making its purpose and the missing rows explicit.

## v1.3.44 — Dev

### Fixed
- Variable, generated-child, and Select All checkboxes now render their checked mark through MV-owned styling, preventing Bricks builder CSS from hiding the selected state.
- The selected-count review control now sits above the batch actions instead of consuming horizontal action space.
- The review tray opens above the relocated selected-count control without overlapping it.

### Changed
- Move, Family, Cancel, and Delete now receive the full batch-action row width in narrow panels.

## v1.3.43 — Dev

### Fixed
- Selected root variables and generated children now use a clear MV-accent row state instead of relying on the checkbox alone.
- Batch selection no longer becomes mysterious when selected variables are filtered, collapsed, unloaded, or outside the viewport.
- Stale selections are removed automatically when their variables no longer exist.

### Added
- The selected-count control now opens a review tray listing every selected token.
- The review tray identifies selections outside the current view and supports individual removal or Clear all.

## v1.3.42 — Dev

### Fixed
- Hides the floating batch action bar while the Family subpanel is open.
- Adds checkboxes to expanded generated children so Ungroup and Reparent operate on the intended child rather than its root.
- Opens row-level Manage Family directly in the current family context and limits new-root choices to that family’s children.
- Preselects a clicked child as the candidate new root.

### Added
- Shift-click range selection across the exact visible order of roots and expanded children.
- Focused helper text and checkbox tooltips explaining Shift-range selection.

### Changed
- A selection containing only imported/manual children defaults to Ungroup; Reparent remains available through the Action selector.
- Family-context actions use the current family’s children instead of passing unrelated variables into the operation.

## v1.3.41 — Dev

### Added
- Added previewed manual family management for grouping, ungrouping, reparenting, and changing a family root without re-importing.

### Changed
- Variable names, exact values, CSS names, aliases, source pills, and Theme values remain untouched during relationship changes.
- Color Palette ownership follows the selected family root, while generated children continue inheriting membership.
- The Category tabs strip now reads as one balanced control with an aligned fixed manager lane and contained MV-styled scrollbar.
- Routine update-reactivation and Bricks save/reload checks are now risk-based instead of repeated for unrelated releases.

### Safety
- Added safety snapshots, stale-preview protection, transactional dependency updates, CSS export rollback, and calculated-generator protection.

## v1.3.40 — Dev

### Changed
- Imported T-shirt scales such as `text-xs`, `text-m`, `text-2xl`, `space-*`, `shadow-*`, and `radius-*` now group beneath a clean imported root like generated families while preserving every original token and value.
- Rootless T-shirt families use the `m` child as the initial clean-root value when available and remain manually selectable in Migration Preview.
- Imported T-shirt children display in logical size order from the smallest `xs` step through the largest `xl` step.
- The Category manager action now occupies a fixed area beside the scrollable Category tabs instead of floating over the final tab.

### Fixed
- Dropdown scrollbars now use the shared MV dark track and accent thumb instead of the platform-native scrollbar.
- Category tabs now clip and begin horizontal scrolling before the fixed Category manager action.
- Lone variables ending in `-s`, `-m`, or another recognized scale suffix are not grouped unless sibling evidence confirms a family.

### Documentation
- Added the MV scrollbar rule to the permanent agent and UI quality guidance.

## v1.3.39 — Dev

### Added
- Update checks now report and obey the site's selected Stable, Beta, or Dev channel across both the branded updater and WordPress's native Plugins screen.
- Repeat migration previews with no applicable changes keep a disabled “No changes to apply” control visible.

### Changed
- Development releases now publish to the Dev manifest only; Beta and Stable remain untouched until explicitly promoted.
- Migration Preview uses the panel's main scrollbar instead of a second scrollbar inside Imported family base values.
- Migration actions and the detected-variable summary remain together in a sticky bottom surface.
- Select menus render in a viewport-level layer and automatically open upward when there is not enough room below.
- Imported generated-family children sort naturally by numeric token step rather than by their converted value.

### Fixed
- Update manifests are cached independently by channel and feed URL, preventing one release lane from leaking into another.
- Changing the update channel immediately clears Mimam's Var and WordPress native update caches.
- Imported family roots inherit the AT, CF, or ACSS source pill from their imported children.
- Long imported-family selector labels remain on one line without breaking the card layout.

### Documentation
- Persisted the Dev-first release policy in the agent operating rules, architecture decisions, and release runbook.
- Added/updated tester-facing Mimam's Var onboarding documentation in Notion.

## v1.3.38

### Added
- Migration Preview now shows an Imported family base values section for rootless imported scales. Users can choose which original child supplies the clean root value before Apply.
- Manual imported-family base choices are remembered per source and reused on later migrations.

### Changed
- Rootless imported scales now create a clean root such as `color.mellow-apricot` instead of a synthetic `color.mellow-apricot.base`.
- The `500` child is selected automatically as the initial root value when available; otherwise the closest numbered step is used.
- Imported children remain generated-style organizational children while retaining their exact external names and values.
- Trailing external `base` labels are removed from semantic token names and normalized alias sources, so `color-error-base` imports publicly as `color-error`.

### Fixed
- Diff and Apply no longer recreate `.base` fallback variables when repairing or importing numbered families.
- Repeated migrations preserve the user's selected family root value instead of resetting it to the automatic default.

### Packaging
- The latest verified Figma plugin ZIP is now kept in the Vengine root alongside the latest WordPress install ZIP, with prior root Figma packages archived in `old/`.

## v1.3.37

### Changed
- External migration now derives Color Palette ownership from the selected scanner and AT/CF/ACSS origin metadata instead of trusting only the normalized preview category.
- Imported generated-family rows resolve to their persisted root color before Palette assignment, so the base owns the family while every supplied child value remains unchanged.
- Reusable source Palettes are found by stable name as well as slug, preventing an existing `Bricks / Advanced Themer` Palette from being missed because of earlier slug history.

### Fixed
- Bricks / Advanced Themer migrations no longer allow reviewed root colors to remain in or fall back to Palette One when preview metadata has been normalized.
- Migration Apply now verifies source Palette membership after the final repair pass and rolls back with an explicit error instead of reporting a false success.

## v1.3.36

### Changed
- Color and protected Uncategorized tabs now expose the same right-click Category menu as user Categories, with Rename and Remove shown in a disabled state to communicate that system organization cannot be changed.
- Advanced Themer colors use the stable reusable Color Palette name `Bricks / Advanced Themer`; an earlier `Advanced Themer` source Palette is reused and relabeled instead of duplicated.

### Fixed
- Category context menus now render in a viewport-level layer, clamp within the visible window, and no longer clip against the horizontally scrolling tab strip.
- The global pointer handler no longer removes the Category menu before Rename or Remove receives its click event.
- Category Rename and Remove use dedicated POST actions, restoring reliable operation on WordPress environments that interfere with PUT or DELETE requests.
- External migration now reconciles Palette ownership for every reviewed incoming root color, including unchanged, updated, and newly imported rows, instead of considering only rows represented in the variable diff.

## v1.3.35

### Added
- Right-click (context) menu on user Category tabs in the builder panel with quick Rename and Remove actions (system-protected tabs like Uncategorized are excluded).
- Modals for renaming and deleting Categories directly from the tabs bar.

### Fixed
- Color migration palette placement attempted to include imported/updated colors in their source-named Color Palette; v1.3.36 completes this by reconciling every reviewed incoming root color.

## v1.3.34

### Added
- Non-color variables now use independent user-managed Categories instead of token-derived namespace tabs. Existing variables start in protected `Uncategorized`, while users can create, rename, delete, and batch-assign categories without changing token names or CSS.
- External migrations create source categories for Advanced Themer, Core Framework, and Automatic.css, and imported rows display compact `AT`, `CF`, or `ACSS` origin pills.
- Snapshots now have a dedicated header action and preserve variable Categories and source-origin metadata.

### Changed
- Snapshots have been removed from Sync so backup and rollback are available directly from the main Variable Engine toolbar.
- The migration source cards, callout, badges, result cards, and actions no longer use decorative icons.
- MV System Bundles now carry Categories and origin labels alongside variables, generators, Themes, and Color Palettes.

### Fixed
- Imported colors are assigned to a reusable source-named Color Palette before general Palette repair can claim them for Palette One.
- Multi-source migration creates separate source Palettes and Categories instead of collapsing imported variables into a generic destination.
- Full variable editing no longer references a removed namespace-prefix field.

## v1.3.33

### Changed
- Bricks / Advanced Themer migration now reads only the registered global-variable collection and no longer harvests Bricks theme-style settings as fake variables such as `general-settings-*`.
- Registered Mimam's Var mirrors are always excluded from Bricks migration. Core Framework and Automatic.css registry mirrors are excluded when their owning engines are detected, while an orphaned registry copy remains available as a fallback when its engine is absent.
- Imported numeric and dark/light/tint families such as `bg-body-5`, `bg-body-10`, and `bg-body-d-1` are grouped beneath their detected base variable like generated children.

### Fixed
- Imported family children retain the exact values supplied by Advanced Themer instead of being recalculated from the base.
- Previously imported flat family rows can be repaired into nested imported-child relationships without a blocking TYPE change.

## v1.3.32

### Fixed
- Imported CSS color values now appear in Color even when their semantic names are dotless families such as `bg-body-*`, `bg-surface-*`, or `border-primary`.
- Color Palette eligibility now recognizes strict hex, RGB/RGBA, HSL/HSLA, HWB, LAB/LCH, OKLAB/OKLCH, `color()`, and `color-mix()` values without relying only on the `color` namespace.
- Updating to this version repairs Palette membership for previously imported unowned color-valued variables.

## v1.3.31

### Fixed
- External migration now creates missing imported alias and generated sources recursively with their reviewed relationship type instead of temporarily storing them as base variables.
- Alias chains such as `section-title-to-content` → `space-grid-gap` → its source now survive post-Apply verification without a false type mismatch rollback.
- New imported aliases can no longer inherit stale generated-base state from a previous change in the same migration loop.
- Circular imported source relationships are stopped with a specific error instead of recursing indefinitely.

## v1.3.30

### Changed
- External migration verifies the reviewed rows directly against stored variables after Apply, checking canonical values, alias/generated types, and source relationships.
- Verification errors now identify the exact affected token and expected versus stored state inside the migration panel.

### Fixed
- Post-migration verification no longer reuses the broad general import diff, which could treat destination-only variables or acceptable inferred generated topology as an unresolved reviewed change and roll back a valid import.
- The generic repeated migration rollback now has actionable diagnostics if any genuine persistence mismatch remains.

## v1.3.29

### Changed
- MV interface text now has a 10px minimum across the Variable Panel, migration UI, studios, helper text, badges, metadata, and Mimam's Bar styling. This follows the product's 10px = 1rem design convention.
- External migration Preview canonicalizes incoming dimension values through the same 10px-root rem conversion used by variable storage.

### Fixed
- A reviewed value such as external `10` now previews and verifies as `1rem` instead of being stored as `1rem` and then falsely compared against `10`.
- Large Advanced Themer migrations no longer roll back with “imported variables did not match the reviewed preview” solely because of expected px/rem normalization.

## v1.3.28

### Changed
- Color is now the only category automatically retained during external migration. Non-color framework paths are flattened into portable tokens in the general Base line, such as `bricks.border.primary` becoming `border-primary`; users can add their own categories later.
- Dotless variables display under Base instead of creating a tab named after each token.
- Long migration requests continue server-side if the builder panel closes and receive the WordPress admin memory allowance plus a bounded execution window.

### Fixed
- External migration defers per-variable generated CSS writes and performs one final verified export, removing hundreds of redundant full-file rewrites from large imports.
- Migration success now requires every reviewed affected name to exist after the transaction.
- Network/server failures are caught and shown in the migration panel; the header progress state says Failed instead of falsely saying Complete.
- The migration panel closes as soon as a verified successful response arrives, before the variable list refresh begins.

## v1.3.27

### Changed
- External Bricks, Advanced Themer, Core Framework, and Automatic.css imports now remove storage/source wrappers and derive semantic names from the variable itself. Examples include `base.font` becoming `font`, `bricks.border.primary` becoming `border.primary`, and a color-valued `brickstheme.brand.primary` becoming `color.brand.primary`.
- Imported aliases retain a mapping to their original external CSS custom-property names so source normalization does not break `var()` relationships.
- Variable rows, generated children, detail panels, edit panels, and generator panels now show the complete public CSS token name without dot notation or a leading `--`.
- Large variable namespaces render in batches of 100 with an explicit Load More action.

### Fixed
- Builder variable mirroring now coalesces overlapping refreshes, skips unchanged frame/provider updates, and avoids repeated multi-stage retries.
- Variable refresh events are debounced and background polling is less aggressive, reducing panel lag and freezes on large installations.

## v1.3.26

### Changed
- After external migration, the panel waits for the authoritative variable reload, opens the namespace containing the first affected variable, and only then reports completion.
- Namespace tabs now explain on hover that they come from the first segment of variable names.

### Fixed
- Concurrent cross-frame variable refresh requests can no longer let an older response overwrite newer imported data in the panel.
- External migrations now appear in Mimam's Var immediately without requiring a page reload.

### Clarified
- Variable tabs are derived namespaces, not separately stored folders. A namespace is added through a variable's category, and it disappears automatically when no variables remain in it.

## v1.3.25

### Changed
- External migration Apply now uses the exact prepared variable payload that the user reviewed instead of discarding it and rescanning the source independently.
- Successful migration feedback includes the number of changes actually written.

### Fixed
- External migration can no longer report success when it wrote zero variables.
- After Apply, the server re-diffs the reviewed payload against Mimam's Var. If intended changes remain, the safety snapshot is restored and the operation reports a verification failure instead of a false success.
- External migration preview, apply, verification, metrics, and tests now share one definition of applicable non-deletion changes.

## v1.3.24

### Changed
- Rebuilt Migrate Variables around a stronger MV-dark visual hierarchy inspired by the supplied reference: framed information callout, icon medallions, source-specific Phosphor duotone icons, compact status badges, icon-led actions, reconciled result cards, warning callout, and a clearer change list.
- Migration preview now uses one server-owned count model for detected, ready, new, changed, skipped, and unchanged rows. The Apply button uses the exact same ready count.
- Phosphor duotone icons are the default icon language for new and touched MV controls, badges, callouts, statuses, and actions wherever a meaningful icon exists.

### Fixed
- In-panel updates now preserve and explicitly restore the plugin's previous activation scope after installation, including normal site activation and multisite network activation.
- External migration assigns only newly added colors to the source-named imported palette. Existing colors and aliases keep their current palette ownership.
- Preview and Apply maintain independent loading labels and never show the other action's loading state.

## v1.3.23

### Changed
- Improved the visual aesthetics of the Migrate Variables sub-panel: added a dark, glassmorphic layout for source cards and callouts, replaced loud background colors with premium callouts/alerts, and added distinct, styled badges for migration actions and statuses.
- The preview summary math now includes type changes, relationship changes, and repairs in the "changed" count, perfectly aligning the summary count with the Apply button count.

### Fixed
- External migrations now tolerate and skip CSS custom property conflicts (e.g., when two different names map to the same CSS custom property like `text.base` and `size.text.base`) and report them as warnings, preventing a single clash from failing the entire migration.
- Fixed the button loading states sharing the same boolean variable, ensuring the Scan button shows "Scanning..." and the Apply button shows "Applying..." independently and cleanly.

## v1.3.22

### Added
- Plugin updates can now be installed directly inside Mimam's Var through WordPress's native plugin upgrader.
- After an in-panel update succeeds, a branded confirmation dialog offers **Refresh Now** or **Later** so the newly installed runtime is loaded intentionally.
- External migration previews now report unresolved source aliases as explicit skipped warnings.

### Changed
- Long-operation progress now appears inside the header of the active MV panel, with a stable operation label, staged percentage, waiting ceiling, and clear 100% completion state inspired by the RestoreBase panel pattern.

### Fixed
- A stale Bricks or Advanced Themer alias whose source no longer exists no longer blocks hundreds of otherwise valid migration rows.
- Alias chains that depend on an unresolved external alias are skipped together, while resolvable aliases continue through preview and apply normally.
- The Settings update action and shared update notices no longer redirect away to the WordPress updater screen.

## v1.3.21

### Changed
- Long-operation progress now tracks only known time-consuming work instead of every Mimam's Var API request.
- The progress bar advances once toward a waiting point, holds calmly while server work continues, then fills to completion without restarting or repeatedly sweeping.

### Fixed
- Post-operation refresh requests no longer replace the active progress label or restart the progress animation.
- External migration treats a safe base or static variable becoming an alias with an explicit source as a LINK change instead of blocking it as a manual type change.
- Generated variables remain protected from direct type conversion and still require manual review when an import attempts to turn one into an alias.

## v1.3.20

### Added
- Added a shared branded progress bar for Mimam's Var API work that lasts longer than a brief interaction.
- Progress feedback identifies common operations such as scanning or importing external variables, preparing or restoring a System Bundle, creating or restoring snapshots, generating variables, and updating Themes or Color Palettes.
- Quick requests complete without flashing the progress surface; longer requests show an honest indeterminate bar and a short completion state.

### Changed
- Successful external migration, token import, System Bundle apply, and snapshot restore now refresh builder variable stylesheets and runtime consumers immediately.
- System Bundle LINK guidance now covers both alias and generated source relationships.

### Fixed
- External migration carries public CSS names through reconciliation, preventing alternate stored forms such as `color.color.2` and `color.color-2` from being imported as conflicting custom properties.
- External migration preserves detected alias rows with empty stored values and deduplicates scanned variables by their public CSS identity.
- System Bundle LINK application now preserves generated relationships instead of attempting to convert or edit generated variables through the locked normal update path.
- Generated value updates carry their explicit source and generator type, avoiding name-derived parent guesses during apply.

## v1.3.19

### Added
- External migration from Bricks / Advanced Themer, Core Framework, and Automatic.css now creates a new source-named Color Palette and places imported color variables and resolved color aliases inside it.
- External `var(--token-name)` values are imported as real alias relationships instead of static text values.
- External migration now creates a complete safety snapshot even when token values already match and only Palette ownership changes.

### Changed
- System Bundle and token import preview rows now use a readable two-line layout with wrapping names, values, and relationship details.
- LINK rows show the complete old and new source names, while UPDATE rows show the complete old and new values without hard character truncation.

### Fixed
- System Bundle generated-child repairs now use the bundle's explicit source variable instead of guessing a parent from the child's name.
- Snapshot recovery now accepts semantic aliases such as `design.*` as Color Palette members when their source chain resolves to a Color variable.
- The failed-recovery combination reported in v1.3.18—generated variable conflict followed by invalid color-palette membership—no longer follows those incorrect repair paths.

## v1.3.18

### Added
- Added the MV System Bundle as the complete portable WordPress-to-WordPress handoff format.
- System Bundles preserve variables, generated children, aliases, generator configurations, Themes, active Theme, Color Palettes, memberships, ordering, and generated CSS behavior without carrying source-site database IDs.
- Added dedicated System Bundle export, preview, and apply REST routes plus automatic bundle detection in Sync import.
- Added preview rows for generator, Theme, and Palette changes alongside existing ADD, UPDATE, LINK, and DELETE variable changes.

### Changed
- Sync export now distinguishes the complete System Bundle from interoperability exports such as DTCG, Flat, Figma JSON, and CSS.
- Portable imports reconnect relationships by stable variable names, create a complete safety snapshot first, and automatically restore it if a later import phase fails.
- Skip deletions now also preserves destination-only generators, Themes, Color Palettes, and memberships during System Bundle updates.
- Release packaging now excludes local `.bak` and `.tmp` development artifacts.

### Fixed
- Generated children are applied before aliases, allowing aliases that point to generated tokens to transfer safely between installations.
- Portable bundle validation rejects duplicate Palette memberships, invalid relationship sources, unsupported generator ownership, empty Palette state, and generated-child Palette membership.

## v1.3.17

### Fixed
- Fixed batch actions overlay background color by changing it to `#1b1b1b` (replacing the blueish slate shade) to match the native dark glassmorphic MV product identity.
- Oriented the batch actions target palette dropdown menu to open upwards instead of downwards, ensuring it remains fully visible within the panel viewport and doesn't collide with the status bar.
- Added custom button border-radius overrides for the upward-opening dropdown when active to maintain geometric layout integrity.

## v1.3.16

### Fixed
- Fixed HTML5 drag-and-drop reordering for both variables and palettes in sandboxed environments (like Bricks Builder) by reading the active drag state variables (`draggingVarId` and `draggingPaletteId`) rather than relying on browser `dataTransfer` APIs.
- Resolved batch actions overlay (`.ve-studio-batch-overlay`) design and alignment bugs by overriding standard centering translations (`transform: none!important`), enforcing non-wrapping text (`white-space: nowrap!important`), and assigning an explicit layout width and responsive padding to the target palette dropdown SelectMenu.

## v1.3.15

### Fixed
- Fixed variable drag-and-drop reordering persistence by sorting the `bases` array by position first in the client-side `useMemo` block.
- Implemented the missing floating batch actions overlay (`.ve-studio-batch-overlay`) inside the main panel, appearing at the bottom when checkboxes are checked.
- Added a batch delete confirmation modal (`ConfirmModal`) to prevent accidental mass deletion of variables.
- Fixed Theme/Palette switcher pill styling by setting `width: 100%` and `display: flex` centering on switcher buttons so they span the container width symmetrically.

## v1.3.14

### Added
- Implemented HTML5 drag-and-drop reordering for variables in the tree list, preserving positions via the new `position` database column and POST `/variables/reorder` REST API endpoint.
- Implements HTML5 drag-and-drop reordering for color palettes in the palette manager, calling POST `/color-palettes/reorder` to serialize palette positions.
- Added bulk selection checkboxes next to variable rows in the tree view and a select-all header bar.
- Added a floating batch actions overlay (`.ve-studio-batch-overlay`) at the bottom of the panel showing selected count with batch delete (with confirmation) and batch move (with target palette selector).

### Changed
- Redesigned the Theme/Palette switcher into a capsule pill control (`.ve-color-kind-switch`).
- Removed dropdown labels (`Theme` and `Palette` text span) from select rows to allow selectors to span the full width.
- Styled the active palette/theme current banner to be transparent (`.ve-palette-current` with `padding: 4px 0` and no background/border).

### Fixed
- Removed the header palette shortcut icon button from the header action buttons row (`.ve-hdr-a`).

## v1.3.13

### Changed
- Replaced the stacked Theme and Palette selectors with a compact two-mode switch so only the active Theme or Palette control is shown at a time.
- Theme and Palette selectors now share a fixed label column and begin at the same horizontal position.
- Standardized normal product inputs and branded select controls on the shared 38px control height across the Variable panel and standalone product surfaces.
- Theme and Palette create/rename fields, License Key, search, transfer dialogs, and their adjacent primary action buttons now use the standard control rhythm.

### Fixed
- Removed remaining 24px and 30px inline input-height overrides that bypassed the product control token.
- Preserved specialized heights for checkboxes, radios, color sliders, file inputs, icon controls, and multiline textareas.

## v1.3.12

### Changed
- Color Palette management now expands inline beneath the Palette selector, matching the established Theme manager interaction instead of sliding into a separate panel.
- The header Color Palettes shortcut now opens the Color tab and expands the inline manager.

### Fixed
- Semantic aliases such as `design.*` that resolve through a Color source are now recognized as palette-eligible colors.
- Color aliases appear in the Color tab for palette organization and gain Move to Palette, Copy to Palette, and palette-aware Duplicate actions without changing their stored name, CSS custom property, or source relationship.
- Upgrade membership repair now assigns existing semantic color aliases to Palette One and removes only genuinely invalid memberships.

## v1.3.11

### Added
- Added true user-created Color Palettes as organizational containers for actual Color variables.
- Existing installations migrate their current root colors and aliases into a renameable `Palette One`; generated children inherit their base variable's palette.
- Added an `All Colors` view plus palette filtering under the Color tab.
- Added palette-aware Color creation, Move to Palette, Copy to Palette, palette duplication with independent color copies, inline rename, and safe deletion previews.
- Populated palette deletion can move colors to another palette or explicitly delete the palette and its color/dependency tree through custom confirmation UI.
- Snapshot state version 3 now preserves themes, palettes, memberships, variables, generators, and dependencies together.

### Changed
- Corrected the previous value-layer feature to **Themes** while preserving its existing WordPress options and legacy `/palettes` REST routes for compatibility.
- Added correctly named `/themes` routes and separate `/color-palettes` routes.
- Theme switching continues to affect CSS, Bricks, Code2Bricks, and exports; palette selection affects organization only.

### Fixed
- Imported, migrated, and cleanup-repaired Color variables are assigned to a valid palette without giving generated children independent memberships.
- Color duplication preserves custom-theme values and optional generated children.

### Pending
- Palette drag-and-drop, bulk selection, and manual color ordering remain later interaction phases.

## v1.3.10

### Added
- Added a variable duplication confirmation modal popup (confirmDuplicate) before duplicating a variable to prevent accidental copy creations.

### Changed
- Redesigned active palette and theme card styles with premium duotone palette icon and clean dark card styling, removing the old gradient dot and olive background.

### Fixed
- Fixed input field height alignment for General Settings License Key input (30px), palette sub-panel creation input (30px), and palette sub-panel inline rename input (24px) to align with their action buttons.

## v1.3.09

### Added
- Integrated the full Color Palettes manager inline inside the Color namespace tab. Clicking the sliders/caret toggle next to the palette dropdown expands the palette creation, list, duplication, inline renaming, and deletion interface directly under the tabs.

### Fixed
- Fixed variable row actions (Edit, Duplicate, Delete) in the variable tree list by declaring all the missing handler functions (`hDup`, `hDel`, `cfmDel`, `hCreated`, `tgExp`, `allCats`) in the main `Panel()` component, resolving the console reference errors.

## v1.3.08

### Fixed
- Fixed variable row click handler (`hSel` ReferenceError) so clicking any variable or child variable shows its details card at the bottom.
- Fixed Color namespace tab switching by implementing the `activatePalette` handler and resolving the `ReferenceError: activatePalette is not defined` during Preact render.
- Modifies the `Detail` component to display basic variable metadata immediately rather than blocking render while dependencies are loaded.
- Styled the General Settings "License key" input field (Image 1) to match the dark premium input styling instead of defaulting to a native white box.
- Implemented real-time cross-frame synchronization: any variable change (CRUD) or settings update is automatically broadcast to all frames/windows via `builderRuntimeWindows()` so all open panels refresh instantly without page reload.

## v1.3.07

### Added
- Added a General setting option to show/hide the "All" tab in the variables list.

### Fixed
- Fixed the Preact rendering crash when switching to the **Color** namespace tab by properly declaring the palettesData state and activatePalette handler in the parent panel component.
- Aligned the header action icons row to the left (matching the search input and tabs) by changing the left padding offset from `48px` to `16px`.

## v1.3.06

### Added
- Added a quick palette switcher dropdown inside the Color namespace tab. This allows the user to switch the active color palette instantly from the main view.

### Fixed
- Styled the palette creation and rename inputs in the Palette panel to match the premium dark theme instead of defaulting to white native inputs.

## v1.3.05

### Added
- Added Color Palettes phase 1 under the new palette toolbar action.
- Added palette creation from the active color set, instant activation, duplication, inline renaming, and confirmed deletion.
- Custom palettes keep public token names stable while overriding effective color values in the variable API, generated CSS, Bricks mirroring, Code2Bricks, and DTCG/Flat/Figma/CSS exports.
- Editing a Color variable while a custom palette is active updates that palette instead of overwriting Default; existing generated color children are recalculated from the edited palette base.
- Palette overrides follow base/generated variable renames and are removed with deleted variables.

### Fixed
- Rebuilt variable row actions around explicit open state and the toolbar panel control's 220ms hover-intent close behavior, with the menu anchored at the far-right edge.

### Pending
- Palette snapshot/import payload support and selector-scoped frontend palette switching remain later phases.

## v1.3.04

### Changed
- Variable actions now appear when hovering or keyboard-focusing anywhere on the variable row and remain anchored to the row's right edge.
- Snapshot entries now use descriptive labels such as “Manual backup,” “Before import,” “Before database cleanup,” and “Before snapshot restore,” with the snapshot number and timestamp shown separately.

## v1.3.03

### Added
- Added a clear JSON/CSS import drop zone that displays “Drop file here” while a compatible file is held over it and previews the dropped file before applying anything.
- Added concise import guidance for DTCG, Flat, Figma JSON, and CSS files.

### Fixed
- Restored generated children to a single indented tree beneath their base variable instead of allowing the list to split into a second column.
- Confined variable row actions to the visible swatch/icon hover boundary, keeping them hidden over empty row space while preserving a clickable action bridge.
- Changed JSON and CSS export filenames to include the current WordPress site name, export format, and date.
- Displays alias source changes as explicit old-source to new-source LINK rows and applies supported relationship changes transactionally.

### Planned
- Defined palettes as alternate value layers over stable color-token identities; implementation is intentionally reserved for a dedicated module phase.

## v1.3.02

### Added
- Added unsaved color previewing in the Bricks canvas while editing a color variable; closing the editor without saving removes the temporary preview.

### Fixed
- Recursively discovers nested builder iframe runtimes, reapplies the runtime variable layer after iframe loads, and keeps retrying even when Code2Bricks is already available so custom-property values resolve on the canvas.
- Marks the builder-only runtime variable layer as authoritative so stale Bricks styles cannot mask the current Mimam's Var value.
- Automatically recognizes exact `var(--token)` and `--token` static values as aliases in WordPress, while resolving string and numeric database IDs consistently in the builder.
- Hides the category selector while editing a static variable because the existing namespace is retained.
- Reveals variable row actions only after the pointer enters the variable swatch/icon, instead of activating from the hidden action area.

## v1.3.01

### Added
- Added Tab key autocomplete support to `VarRefInput` in the static value field.
- Added recursive `resolvedVariableValue` helper to fully resolve colors, sizes, swatches, and values for alias variables in lists and autocomplete.

### Fixed
- Added `_nc` cache-buster query parameters to variable list REST requests to ensure value updates propagate to the builder canvas instantly on save.
- Automatically closes the Media Studio panel upon successful asset selection and insertion into Bricks controls.
- Propagates click intent to `createFrame` inside the `wp.media` wrapper to ensure picking state resolves correctly.
- Pre-filled inline editor and full editor in `EditSub` with `css_value` instead of empty string for alias variables, and auto-detects type updates on inline edit save.

## v1.3.00

### Added
- Merged the separate "Alias" mode into "Static" mode. Typing `--` or `var(` in the static value field triggers autocomplete suggestions of existing variables, which automatically transitions the variable's type to `alias` on save.
- Dynamically injects a `:root` style tag on mutation into both the main document and iframe canvas window so newly created variable values resolve instantly in Code2Bricks and Bricks without editor reloads.

### Fixed
- Replaced the timeout polling wrapper with a property getter/setter wrapper on `runtime.wp.media` to immediately intercept Bricks image selectors without race conditions.
- Simplified pointerdown click tracking to register media selection intent for any element outside the Vengine panel and native media modal, bypassing fragile class guessing.
- Corrected the fluid scale generator trigger bug by removing the automatic popup showing when fixed/static variables are created.
- Extended the PHP `VariableManager::update()` method to accept and write `type` and `source_id` edits and correctly register/deregister relations in the dependency graph.

## v1.2.129

### Added
- Added an Alias mode to the variable creation panel with an explicit source-variable selector and a preview of the resulting `var(--token)` reference.
- Added builder UI tokens for the shared accent, surfaces, borders, text, danger state, and 38px control-height rhythm.

### Fixed
- Reconciled MV variables into every accessible Bricks/Code2Bricks runtime at builder startup and after mutations, including direct provider population so autocomplete does not depend on a stylesheet scan or a later focus refresh.
- Rebuilt the Media Studio replacement around Bricks' actual `wp.media` request and selection callback, allowing Bricks to receive the selected attachment through its native control path while leaving navigation clicks untouched.
- Forced search, variable-name, fixed-value, and related single-line controls to the shared 38px product input height.
- Prevented small fluid scales from producing duplicate rounded child names such as two `import-delete.2` rows.

## v1.2.128

### Fixed
- Mirrored MV-owned public tokens into Bricks global variables through the Bricks adapter so Code2Bricks can discover them, while preserving external variable ownership and removing only stale MV mirror rows.
- Refreshed the in-memory Bricks variable list and Code2Bricks provider immediately after variable mutations.
- Restored Media Studio replacement behavior for media-specific Bricks controls without reintroducing sidebar-navigation interception.
- Matched the HEX and channel value fields to the standard 38px input height.

## v1.2.127

### Fixed
- Normalized user-entered variable-name spaces to hyphens, allowed CSS-safe hyphens in stored variable segments, and kept internal dot separators out of the variable-name UI.
- Added horizontal padding to the HEX/RGB/HSL/OKLCH format controls.
- Refreshed the selected variable immediately after inline value saves instead of requiring the user to leave and reselect it.
- Reloaded generated `variables.css` after variable mutations so already-open Bricks tools such as Code2Bricks can discover newly created variables.
- Narrowed the Bricks Media Studio trigger bridge to explicit media controls so sidebar navigation icons no longer open Media Studio.
- Changed snapshots to capture variables, stable IDs, dependencies, and generator configuration as one versioned state.
- Made snapshot rollback transactional, recovery-snapshot-backed, and explicit about legacy snapshots that cannot restore generated relationships safely.
- Marked incomplete legacy snapshots as unavailable in the Snapshots UI instead of offering a misleading Restore action.
- Prevented imports from applying when their required pre-import safety snapshot cannot be created.
- Rejected duplicate names before variable rename writes and stopped recording rename history when the database update fails.
- Made generated variable CSS writes atomic and deduplicated declarations by public CSS name.
- Rejected create/rename operations that would make two stored variables resolve to the same public CSS custom property.
- Added CSS-name collision diagnostics and deduplicated legacy JSON/Figma exports by the newest stored variable row.
- Preserved valid single-segment tokens in DTCG export instead of silently omitting them.
- Made import application transactional: any failed change, CSS write, or sync-log write rolls the complete import back.
- Blocked unsupported type-change imports before mutation and added a custom confirmation before applying import deletions.
- Prevented generators from converting unrelated existing variables into generated children when names or public CSS names collide.
- Added checked generator database writes, duplicate-generator prevention, transactional attach/detach, and explicit regeneration failures.
- Made variable create, update, and delete operations transactional, including dependency, generator-regeneration, and generated-CSS writes.
- Replaced the delete-then-create generator UI flow with one transactional generator replacement, preserving the old scale if the new configuration fails.
- Surfaced generator, duplicate, and delete API failures instead of showing false success messages.
- Preserved generated-variable IDs during generator replacement and blocked removal of generated tokens that still have downstream alias/dependency usage.
- Made forced variable deletion traverse the complete dependency tree instead of leaving grandchildren with missing sources.
- Added a complete pre-cleanup snapshot and one transaction around duplicate/orphan/stale-variable cleanup, generator recovery, regeneration, and CSS export.
- Preserved alias source names in flat and DTCG exports and restored alias relationships when importing into a new variable set.
- Normalized flat import metadata instead of passing unvalidated relationship fields straight through.
- Added import preflight validation for duplicate names, public CSS collisions, missing/self-referencing alias sources, and conflicts with existing variables.
- Made source-relationship changes visible in import diffs and blocked them for explicit manual review instead of silently relinking variables.
- Changed rename propagation from substring replacement to exact CSS custom-property token matching, preventing a rename such as `--brand` from altering `--brand-alt`.
- Surfaced rename-propagation warnings after a successful variable rename.
- Prevented database read or JSON encoding failures from being stored as successful snapshots.
- Added pre-rollback snapshot structure checks for duplicate identities, invalid dependency rows, and malformed generator rows while still allowing an exact safety capture of a database that needs cleanup.
- Prevented alias relationship round trips from producing false value updates and exported an alias source's resolved value to Figma.
- Separated manually resolved CSS-name conflicts from automatic cleanup issues and stopped cleanup failures from showing a false success toast.
- Converted unexpected rename-propagation failures into visible warnings while keeping the successful core rename intact.
- Remapped source IDs, generators, and dependency edges to the kept row before database cleanup removes older duplicate variable records.
- Added diagnostics for broken alias sources, missing dependency links, and orphan dependency rows.
- Extended cleanup to repair valid alias/generated dependency links, remove generated rows whose source is gone, and delete orphan dependency records while leaving ambiguous aliases for manual relinking.
- Prevented cleanup from deleting orphan generated variables that still serve downstream dependents; those cases are now flagged for manual review.
- Added a recoverable backup-swap fallback for atomic generated-CSS replacement on hosts where `rename()` cannot overwrite an existing file directly.
- Corrected existing dependency edges when their stored relation type is stale and required imported generated-variable edge registration to succeed.
- Extended snapshot structure validation to reject duplicate dependency and generator IDs before rollback.
- Preserved generated child IDs across base-variable renames by matching owned color/scale children through stable generator suffixes and renaming those rows in place.
- Rejected snapshots whose alias/generated sources, dependency edges, or generator owners do not exist in the captured variable state, and stopped rollback before mutation when its database transaction cannot start.
- Refreshed alias CSS references inside variable rename transactions so source and generated-token renames cannot leave `var(--old-name)` declarations behind.
- Made viewport-driven fluid-variable recompilation transactional and surfaced database, CSS-write, and commit failures without retaining the new viewport settings.
- Made CSS import previews reconcile public CSS names back to unambiguous stored variable identities and infer simple `var(--token)` alias relationships.
- Expanded import previews to show and block unsupported type/source relationship changes before application.
- Surfaced direct sync-log database write failures instead of returning false success.
- Applied identity validation to legacy base-only snapshots and surfaced failures when stale generated dependency edges cannot be removed.

## v1.2.126

### Fixed
- Synchronized every fresh MV update check into WordPress's native `update_plugins` site transient so the first refresh no longer merely primes a later update display.
- Added a pre-render fresh manifest check on the WordPress Plugins and Updates screens, preventing stale six-hour manifest data from requiring a second refresh.
- Removed the 120ms restore gate and the additional panel entrance animation from hidden floating Elements/Structure restoration; the panel now rebuilds immediately at its validated saved geometry.

## v1.2.125

### Fixed
- Applied pending floating-panel restore geometry synchronously during shell creation, before the browser can paint the temporary reconstructed position.
- Removed the early delayed position correction that allowed the panel to flash near the bottom before moving to its saved location; retained a later fallback only for unusually delayed Bricks mounts.

## v1.2.124

### Fixed
- Kept an immutable hide-time geometry snapshot for floating Elements and Structure panels so shell reconstruction and width-preset initialization cannot overwrite the position and size that restore must use.
- Preserved pending restore metadata during normal floating-panel persistence, then cleared the one-time snapshot only after the rebuilt shell successfully receives it.

## v1.2.123

### Fixed
- Positioned the compact Bricks panel-preference control immediately before Undo instead of leaving it detached after Save.
- Added hover intent and a cursor bridge to the compact panel-control popover so it remains open while the pointer moves from the toolbar icon into the dialog.
- Saved floating Elements and Structure geometry at hide time and reapplied it on restore, clamping oversized or off-screen positions into the current viewport.

## v1.2.122

### Added
- Added account-backed UI preference storage through WordPress user meta so panel modes, positions, Builder Tools settings, CSS Studio preferences, Media Studio view preferences, and update skips can follow the logged-in account across browser sessions.
- Added the update-available notice to the main panel, its nested views, all standalone Studio panels, Settings, Help, and Mimam's Bar.

### Changed
- Consolidated the Bricks toolbar Elements and Structure controls into one compact MV panel-control icon with a branded hover/focus popover for dock, float, and hide actions.
- Corrected the WordPress plugin author name to `Hebronmimam`.

### Fixed
- Preserved whether Elements or Structure was floating or docked before hiding, so its restore icon returns it to the same mode.
- Kept toolbar control popovers stable instead of rebuilding their DOM while the panel state is unchanged.

## v1.2.121

### Changed
- Made the release workflow stricter by documenting the Notion Release Notes page as a required release step and backfill target.
- Recorded the fixed `left`/`top` floating-panel drag model as the default pattern for future MV floating surfaces.

### Fixed
- Made floating shell Wide and Max presets expand the inner Bricks panel subtree instead of leaving empty shell space beside a fixed-width panel.
- Moved floating shell header tooltips below the size/dock/hide controls so they no longer sit directly on top of the hovered icon.
- Changed Elements and Structure hide behavior to create separate restore icons near the MV control area, so hidden panels can animate down to a small icon and restore from their own icon.

## v1.2.120

### Changed
- Replaced the floating shell S/M/L/XL size language with MV-owned Narrow, Balanced, Wide, and Max presets.
- Updated floating shell dock, float, and hide icons so the controls read as Mimam's Var UI instead of mirroring the reference floating-panel plugin.

### Fixed
- Made Wide and Max floating shell presets apply larger real widths and persist those widths.
- Added Structure-specific floating shell spacing and toggle visibility rules so Bricks row expand/caret controls can remain visible and clickable while floating.

## v1.2.119

### Fixed
- Fixed Builder Tools floating Elements and Structure shells so the active shell wrapper is not removed by the stale-panel cleanup pass immediately after toggling float.
- Tightened vertical centering for the Bricks toolbar MV Elements and Structure mode controls.
- Reverted Media Studio collection context menus to Studio-relative row anchoring and refined lower-row clamping so menus stay attached to the clicked collection without drifting across the viewport.

## v1.2.118

### Changed
- Reworked Builder Tools floating Elements and Structure into MV-owned floating shells with custom headers, S/M/L/XL width presets, dock/hide controls, and Bricks toolbar panel mode controls.
- Set floating panel opacity default to 100% and migrated the old 78% default once for existing installs that had not changed it manually.

### Fixed
- Kept native Bricks Structure markup inside the floating shell so row expand/caret controls remain visible and clickable without opening Media Studio.
- Restored floating panels through the shell cleanup path so dock/hide state changes do not leave orphan wrappers or stale inline styles.
- Improved Media Studio collection context menus by anchoring them with viewport-fixed row geometry and a pointer that follows the clicked row, including lower sidebar rows.

## v1.2.117

### Fixed
- Stabilized Builder Tools floating Structure/Elements cleanup by removing inactive float root classes before restoring docked panel styles.
- Stopped floating Structure from wrapping Bricks internals in an MV layout wrapper, reducing dock-restore glitches.
- Scoped floating-panel button layout overrides to panel headers so Structure row expand/caret controls are not affected.
- Broadened floating Structure expand/caret visibility rules while keeping them scoped to Structure rows.
- Re-centered Media Studio collection context-menu pointers around the clicked row, including lower sidebar rows.

## v1.2.116

### Changed
- CSS Studio keeps the Variable Panel surface, but the stylesheet settings area is more compact and the CSS editor fills the remaining panel height.
- Media Studio collection menus now anchor inside the Studio layout context instead of relying on an unpositioned ancestor.

### Fixed
- Kept Bricks Structure expand/caret controls visible and clickable while the Structure panel is floating.
- Added targeted cleanup for disabled floating Structure/Elements panels so disabling one panel can restore its Bricks docked state even if another Builder Tools panel remains active.
- Further softened floating Structure/Elements shadows to avoid a glowing/pulsing feel.
- Made Rank Math internal links processed, Rank Math analytic object ID, and Rank Math SEO score read-only in Content Studio.

## v1.2.115

### Changed
- Added named UI surface styles to the AI UI rules so future work can refer to Variable Panel, Wide Studio, Medium Studio, and Sidecar Editor consistently.
- Changed CSS Studio back to the narrow Variable Panel style instead of the wide Studio modal style.

### Fixed
- Prevented Bricks Structure panel clicks from being captured by the Media Studio picker interceptor.
- Fixed CSS variable autocomplete so bare `--token` completions wrap as `var(--token)` unless the cursor is already inside `var(...)`.
- Improved Media Studio collection context menu anchoring by positioning from the clicked collection row instead of centering the menu over nearby rows.
- Added floating-panel style snapshot/restore cleanup so disabling floating Structure or Elements can return Bricks panels closer to their native docked state.
- Restored MV-created floating header wrappers during cleanup so Structure/Elements headers do not keep altered markup after disabling float.
- Repositioned the Elements floating drag handle inside the panel header and kept the Structure minimize control in the header row.
- Kept Structure expand/caret controls visible while floating and removed animated shadow transitions that made floating panels feel like they were pulsing.

## v1.2.114

### Added
- Added safe Content Studio REST endpoints to preview and apply a JetEngine-to-ACF mirror migration without deleting JetEngine data.
- Added local Figma dev sync documentation for using a reachable HTTPS tunnel URL instead of `localhost`.

### Changed
- Content Studio now separates Rank Math custom fields into their own section so SEO metadata is not mixed into general custom fields.
- Content Studio preserves richer custom-field/meta values for editing, including JSON-friendly complex values.
- CSS Studio now combines the stylesheet settings and editor into one studio panel instead of using the old detached sidecar layout.
- CSS autocomplete now wraps bare `--token` completions in `var(...)` unless the cursor is already inside a `var()` context.
- Studio input heights were tightened toward the shared 38px rhythm.

### Fixed
- Tightened CSS Recipes editor/form spacing and kept recipe actions below the editor.
- Reworked CSS Studio sizing overrides so it no longer inherits stale compact sidecar CSS.
- Improved Media Studio context-menu anchoring so menus align from the clicked collection row instead of the row above.
- Further stabilized floating Structure/Elements panel manual positions after drag/drop and kept the Structure shortcut rail hidden.
- Centered the Elements panel floating drag handle vertically in its header and moved the Structure minimize control to the far header edge.

## v1.2.113

### Changed
- Lowered floating Bricks Structure and Elements panels beneath Advanced Themer popovers while keeping MV Studio panels above normal admin/builder surfaces.
- Added common logical CSS properties to CSS Studio validation and autocomplete support.
- Content Studio now hides the WordPress content editor when a post type does not support default content and surfaces detected custom fields/meta in the in-studio editor.

### Fixed
- Reworked floating Structure/Elements dragging to update fixed `left`/`top` during drag instead of applying a temporary transform and snapping on drop.
- Prevented active CSS and rich-content editors from re-syncing external values while typing, reducing cursor jumps to the start of the editor.
- Tightened CSS Recipes layout so shortcode prefix/input spacing is clean and recipe action buttons sit directly under the editor.
- Centered the Media Studio collection context-menu pointer on the clicked row and kept the menu clamped inside the Studio panel.
- Added a settings-panel fallback so Settings no longer stays on a permanent loading state if the settings request fails.
- Refined floating Structure/Elements handle sizing, spacing, and z-index so the handles feel less intrusive.

## v1.2.112

### Changed
- Upgraded Content Studio's in-studio content field to a lightweight WordPress-like rich editor with paragraph, heading, list, bold/italic, and quote controls.
- Made Media Studio reopen faster by reusing an in-memory media/folder cache while refreshing data in the background.

### Fixed
- Tightened CSS Recipes form/editor sizing so recipe preview and new-recipe states use the full available editor width consistently.
- Re-anchored Media Studio collection context menus to the clicked collection row edge while keeping the menu clamped inside the Studio viewport.
- Replaced the floating Builder Tools drag handle icon with an inline SVG handle and removed the unwanted handle tooltip pseudo-element.
- Persisted floating panel width and clamped Structure restore/drag positions to reduce jumping and prevent panels from leaving the viewport.
- Scoped Bricks panel styling overrides to MV floating-panel states so Builder Tools CSS does not leak into unrelated Bricks/site UI.
- Applied the requested floating Structure spacing of `2rem` padding and `2rem` gap.

## v1.2.111

### Changed
- Removed the temporary MV Structure shortcut rail from the active Builder Tools UI and settings until the shortcut system is redesigned later.
- Moved CSS Studio's Save & Compile action to the code editor sidecar so compiling stays attached to the stylesheet being edited.
- Upgraded CSS Recipes editing to use the same CSS editor surface as CSS Studio, including recipe edit/cancel state and autocomplete sources.
- Reworked Content Studio's in-studio editor to use the full available workspace with sticky actions and an Advanced WordPress fields section.

### Fixed
- Added cleanup for MV Structure wrappers so docking the Structure panel can restore Bricks' default layout more reliably.
- Improved floating Structure and Elements drag handle styling and placement.
- Anchored Media Studio collection context menus inside the Studio panel so transformed panel positioning no longer pushes menus away from the clicked collection row.
- Reduced 1Password/autofill interference on CSS recipe name and shortcode fields.

## v1.2.110

### Changed
- Moved CSS recipe discovery out of CSS Studio so the stylesheet editor no longer shows recipe shortcode rows or recipe scope controls.
- Changed CSS Recipes Studio to list shortcodes only; clicking a shortcode loads its generated CSS into the recipe editor.
- Auto-prefixes new recipe shortcodes with `@` so users type only the shortcode name.
- Reworked Builder Tools Structure shortcut handling to use MV's owned fixed rail instead of moving external Bricks or Advanced Themer rails.

### Fixed
- Expanded Content Studio "Edit in Studio" so it can save core WordPress edit fields including title, slug, status, content, excerpt, parent/order, featured image ID, comments, pings, and template metadata.
- Re-anchored Media Studio collection context menus beside the clicked collection row and clamped them to the viewport.
- Added a local settings backup write for Builder Tools panel preferences to reduce future update-related settings loss.

## v1.2.109

### Fixed
- Removed CSS Studio from the large Studio modal sizing rules so the compact settings panel and code editor sidecar stay beside each other.
- Added explicit CSS Recipes centering and width rules so the Recipes Studio no longer opens stretched or clipped offscreen.
- Fixed Content Studio "Edit in Studio" by moving its save handler back into the Content Studio scope.
- Anchored Media Studio collection context menus to the actual pointer position and clamped them inside the viewport.
- Made MV-owned Media Studio collections draggable from the row as well as the handle, while detected folder-plugin collections now show a read-only lock affordance.
- Stabilized the Builder Tools Structure shortcut rail by mounting it to the Structure panel instead of positioning it as a separate fixed element during drag.

## v1.2.108

### Fixed
- Restored CSS Studio to the compact MV panel sizing with the code editor sidecar placed beside the main settings panel.
- Fixed Media Studio folder-plugin collection counts so detected folders show the same item count as the filtered gallery.
- Changed Media Studio sub-collection creation from an inline bottom-of-list form to a focused modal.
- Made Media Studio Bricks picker mode close after a successful insert or copy fallback.
- Scoped Media Studio conversion progress to the selected asset so another asset no longer inherits the converting state.
- Made Content Studio input heights match action buttons and made Edit in Studio start from pointer-down for more reliable in-panel editing.
- Stabilized Builder Tools floating handles and Structure shortcut rail visibility while dragging.
- Smoothed the toast countdown ring animation and prevented older toast timers from hiding newer messages.

### Changed
- Media Studio collection rows now label MV-owned collections versus detected folder-plugin collections, show sub-collection indentation, and expose drag only through an explicit handle.
- CSS Recipes now uses a centered studio width instead of stretching to the full available viewport.
- Added an agent UI-memory rule for clearly labelling MV-owned data versus adapter-detected data.

## v1.2.107

### Added
- Added an MV-styled right-click context menu for Media Studio collections.
- Added local Media Studio collection rename, remove, sub-collection creation, drag-to-reorder, and Shift-drop nesting.

### Fixed
- Fixed CSS Studio panel placement by excluding CSS Studio and CSS Recipes from the generic standalone-panel transform override.

### Changed
- Kept the update ZIP filename short as `mv-wp-v1.2.107.zip` while preserving the internal `variable-engine` plugin folder required by WordPress updates.

## v1.2.106

### Added
- Added a dedicated CSS Recipes Studio panel for managing reusable CSS shortcodes that autocomplete inside CSS Studio.

### Fixed
- Restored the floating Elements panel drag handle even when no Bricks element is selected.
- Lowered Builder Tools floating Elements, Structure, rail, tooltip, and minimized-restore layers below MV Studio overlays.
- Stabilized Structure shortcut rail dragging by clearing rail transforms and transitions after drag.
- Added a Bricks media-selection handoff so Media Studio can insert the chosen media URL into the originating Bricks control, with a copy fallback when no writable control is exposed.
- Changed Media Studio file conversion to show converting/converted toasts without switching the full Studio into a loading state.
- Made Content Studio clear stale rows immediately when switching sections and made Edit in Studio open the inline edit form more reliably.

### Changed
- Clarified the General setting label for single-panel versus multiple-panel behavior.

## v1.2.105

### Fixed
- Added file type metadata to Media Studio attachment details beside dimensions and size.
- Reworked Plugin Directory result cards so grid and list views align consistently.
- Fixed Plugin Studio navigation so installed-plugin filters switch back from Plugin Directory content instead of only changing the header.
- Fixed Content Studio navigation races so slower previous requests cannot repaint Pages after clicking another type.
- Reset Content Studio transient row/edit state when switching content groups.
- Changed Content Studio edit links to use server-provided Bricks links when available.
- Clamped floating Builder Tools panels to the viewport after drag, resize, and settings changes.
- Prevented dragging the floating Elements panel from moving the Structure shortcut rail.

## v1.2.104

### Added
- Plugin Directory browsing now has its own Plugin Studio sidebar section with preloaded popular plugins.
- Plugin Directory results now support grid/list views and display plugin icons when WordPress.org provides them.

### Fixed
- Restored CSS Studio to the slimmer MV panel sizing so the code editor area is visible again.
- Filtered duplicate default Pages/Posts out of the Content Studio custom post type list.
- Hid Advanced Themer/options-page field groups from Content Studio field-group lists.
- Made Content Studio field rows editable in Studio instead of only deletable.
- Improved branded focus styling so Studio inputs do not show the browser's blue focus ring.
- Broadened Bricks image/SVG/media/background click detection so Media Studio opens from more Bricks selector controls.
- Reduced Structure/Elements hide-versus-float conflicts by applying builder panel state classes to both document roots.

### Changed
- Plugin Studio directory search now fills the available result height and uses more readable plugin card text.
- The multiple-panel option is now labelled as Panel behavior with helper text in General settings.

## v1.2.103

### Added
- Plugin Studio can now search the WordPress.org plugin directory and install plugins directly from Studio.
- Plugin Studio can now upload plugin ZIP files from Studio.
- Added a General setting to allow either one MV panel at a time or multiple Studio panels at once.
- Added toast countdown ring animation so temporary messages show their remaining display time.

### Fixed
- Improved Plugin Studio text contrast so plugin descriptions and authors remain readable in the dark UI.
- Lowered MV panel and Builder Tools z-index layers so native WordPress/Bricks modals can appear above MV panels.
- Broadened the Bricks media-control bridge so common image, SVG, media, and background selectors open Media Studio instead of the default media library.
- Prevented Structure/Elements panel hide settings from hiding panels that are also configured to float.
- Improved Content Studio labels so in-Studio editing and Bricks editing are clearly separated.
- Expanded Content Studio metadata detection for ACF and JetEngine CPT definitions that are not exposed through normal registered post types.

### Changed
- Shortened the update package filename to the `mv-wp-vX.Y.Z.zip` format while keeping the internal WordPress plugin folder as `variable-engine`.

## v1.2.102

### Fixed
- Fixed Plugin Studio and CSS Studio standalone centering by excluding both Studio panels from the older utility-panel transform rule and including them in the center-screen Studio CSS block.
- Added outside-click closing behavior for Plugin Studio so it behaves like the other Studio panels.
- Replaced remaining native Settings and Modules checkboxes with the shared MV checkbox component for consistent styling across admin and builder.
- Added a lightweight Bricks media-control bridge that opens Media Studio from common Bricks image/media controls without mutating Bricks save state directly.

### Changed
- The v1.2.102 package includes the v1.2.101 Studio polish pass plus the final centering, checkbox, and media-control bridge fixes.

## v1.2.101

### Added
- Added Plugin Studio as a Builder Tools module for plugin listing, filtering, activation/deactivation, auto-update toggles, native update links, and inactive plugin deletion.
- Media Studio now supports batch deselect, in-modal new collection creation from a selection, and selected-asset collection membership display with an explicit add-to-collection action.
- Media Studio now has a branded media rename confirmation flow with title-only and file-URL rename options.
- Content Studio now supports in-studio title, slug, and status editing for content rows.

### Fixed
- Hardened Media Studio grid rendering with fixed grid tracks and stable media card dimensions to prevent asset overlap.
- Fixed folder collection membership refresh by including detected folder data in the collection filter dependencies.
- Preserved FileBird parent-folder relationships when detected, allowing sub-collections to appear instead of flattening all folders.
- Improved Content Studio grouping so default content, true custom post types, plugin/system types, and field groups are separated and can be hidden or shown.
- Replaced remaining native selects and checkbox lists in Studio forms with MV-styled controls.
- Restored CSS Studio workspace sizing inside the large studio shell.
- Rebuilt the MV-owned structure shortcut rail to use Phosphor icon classes and readable tooltip labels instead of copied shortcut letters.

### Changed
- Applied lean MV-styled scrollbars and consistent control heights across Studio surfaces.
- Clarified Media Studio replace/convert action labels and tooltips.

## v1.2.100

### Added
- Media Studio now loads media through paginated WordPress media requests instead of stopping at the first 60 items.
- Media Studio now reads supported media-folder plugin data through the existing folder endpoint and exposes detected folders as system collections.
- Media Studio now supports Ctrl/Cmd-click toggling and Shift-click range selection in grid and list views.
- Media Studio batch "Add to Collection" now opens a branded chooser and can route items into existing local collections or detected folder-plugin collections.
- Media Studio collection names can use slash paths for sub-collections, and the icon picker now loads the full local Phosphor duotone catalog for searchable icon selection.
- Media Studio now has replace-file and image-conversion actions for selected assets.
- Builder Tools adds a setting to use an MV-owned shortcut rail beside the floated Structure panel.

### Fixed
- Content Studio route calls now use the registered `variable-engine/v1` namespace, fixing empty/slow content loading caused by the old `ve/v1` path.
- Removed the redundant Content Hub title in Content Studio.
- Media Studio grid cards now use fixed grid tracks, internal selection rings, and no hover scaling to prevent overlap.
- Media Studio type/sort controls now use the branded custom select menu instead of native dropdowns.
- Media Studio file-name fields, font-file previews, dropzone behavior, and full-screen drag/drop feedback were restyled to match the product UI.
- Builder Tools delays Structure floating until Bricks loading/preloader screens are gone.
- Structure panel handle/resize tooltips now render above the panel chrome instead of being clipped below it.
- Figma pairing state is now stamped to the current Figma file identity so older/shared storage cannot make unrelated files appear paired to the same site.
- Dark UI surfaces were pulled back toward the product's black/charcoal palette instead of drifting blue.

## v1.2.99

### Added
- Media Studio: Added dynamic collection creation with a Phosphor duotone icon picker grid, allowing custom-defined collections instead of hardcoded defaults.
- Media Studio: Added MIME type filter dropdown (`all`, `image`, `video`, `audio`, `application`) next to search, along with persistent sort dropdown (Newest, A-Z, Largest).
- Media Studio: Implemented a transparency grid background (`.ve-checker-bg`) for images with transparent backgrounds in the gallery, list view, and attachment details preview.
- Media Studio: Replaced browser `confirm()` calls for deleting media and batch deletes with custom `ConfirmModal` overlays.
- Content Studio: Replaced browser `confirm()` calls for deleting posts, CPTs, field groups, and fields with custom `ConfirmModal` overlays.

### Fixed
- Media Studio: Removed the redundant "Asset Manager" sidebar title.
- Media Studio: Removed hardcoded "Testimonials" and "Team" collections, migrating any existing client lists to dynamic keys.
- Media Studio: Fixed preview pane switching latency (keyed details sidebar on selected item ID to force re-mount).
- Media Studio: Fixed selection highlight styling to prevent grid item overlap in gallery mode.
- Media Studio: Aligned file name field height, padding, and font family in the details sidebar.

## v1.2.98

### Added
- Content Studio: Guarded CPT and Field creation triggers and dropdown selections by provider activity (ACF/JetEngine) and set active provider defaults dynamically on load.

### Fixed
- Drag Freeze: Stabilized structure panel dragging by removing pointerup/mouseup propagation swallowing in `settings-manager.js`, allowing standard browser and builder drag cleanup to complete correctly.
- Centering: Fixed widescreen centering offsets for Content Studio and Media Studio by excluding them from the runtime injected `transform: none` rule in `builder-panel.js` and raising selector specificity in `builder.css`.
- Performance: Optimized the `globalPanelDOMObserver` MutationObserver by implementing a fast pre-filter to bypass queries on routine/minor builder DOM changes.

### Documentation
- Hardened the Antigravity/Codex operating layer with explicit agent quality, UI quality, validation, and release-runbook rules.
- Added canonical docs for agent quality gates, UI standards, and release packaging.
- Updated the setup script to prefer the current checked-in docs instead of regenerating stale weaker templates.

## v1.2.97

### Added
- Reintroduced post-v1.2.93 feature work in a syntax-valid state.
- Modules settings panel deactivation tab to turn off CSS Studio, Mimam's Bar, Content Studio, and Media Studio.
- Speed-dial FAB menu visibility logic: hides the FAB completely when any panel is open.
- Centered widescreen layouts (max-width: 1920px, height: 80dvh) for Content Studio CPT categories and Media Studio 3-column designs.
- Alt-text auto-save on blur, image dimensions, insert URL, and Copy HTML tag features in Media Studio.
- Multi-select batch actions (Add to collection, Compress, Delete) in Media Studio.

### Fixed
- Fixed settings reset on plugin update using robust direct `localStorage` fallbacks in `settings-manager.js`.
- Configured Mimam's Bar module to completely bypass asset enqueuing when deactivated.

## v1.2.96

### Fixed
- Recovery release based on the last confirmed working `v1.2.93` codebase.
- Removed the broken `v1.2.94`/`v1.2.95` JavaScript package line from the stable update path.
- Restored a syntax-valid WordPress panel package while keeping Content Studio and Media Studio at their last verified `v1.2.93` behavior.

### Notes
- The `v1.2.94` Content/Media Studio redesign and `v1.2.95` Modules settings work are intentionally held back for re-implementation in smaller verified slices.

## v1.2.95

### Added
- Added a "Modules" settings tab inside the Unified Settings Panel to let users deactivate individual tools (CSS Studio, Mimam's Bar, Content Studio, and Media Studio).
- Deactivating a tool immediately hides its icon/item from the speed-dial FAB menu and auto-closes any of its open panels.
- Configured Mimam's Bar to completely bypass asset enqueuing when deactivated.
- Organized the workspace root by moving utility script files (`update_notion_*.js`, `read_roadmap.py`, etc.) into a dedicated `scripts/` directory.

### Fixed
- Fixed FAB speed-dial visibility: the floating FAB menu icon now hides completely when any panel (Settings, Help, CSS Studio, Content Studio, Media Studio, or the main bar) is open.

## v1.2.94

### Added
- Upgraded Content Studio and Media Studio layouts to centered widescreen layouts (max-width: 1920px, height: 80dvh) that disable drag/float/dock controls.
- Added Content Studio sidebar navigation categories (Default CPTs, Custom Post Types, and Custom Field Groups) with a detailed tabular list displaying ID, Title, Slug, Status Badge (clickable to toggle), and dates.
- Added Media Studio three-column design layout (left sidebar collections, middle gallery/list layout modes, and right attachment details sidecar).
- Integrated Alt Text auto-save on blur, image dimensions, insert URL copy, and HTML tag copy in Media Studio sidecar.
- Added multi-select batch actions bar (Add to collection, Compress, and Delete) at the bottom of Media Studio.
- Styled all studio inputs, textareas, and dropdown selects with dark glassmorphic styling.

### Fixed
- Fixed settings reset on update by writing direct localStorage fallbacks in `settings-manager.js` storage functions.

## v1.2.93

### Fixed
- Fixed a bug in the Content Studio where selecting the "Content Type" (Page or Post) in the dropdown immediately redirected the user away and defaulted the created type to Post. It now uses a dedicated local state `contentType` and functions correctly.

## v1.2.92

### Added
- Implemented **Content Studio** floating panel to manage pages and posts, support search, quick-toggle status (Publish/Draft), and quick-create new pages/posts with a direct "Edit in Bricks" setup.
- Implemented **Media Studio** floating panel functioning as a premium, glassmorphic WordPress Media Gallery replacement with search, drag-and-drop file uploading, attachment details, and link/HTML copies.
- Added dedicated speed-dial FAB tray icons for the new Content Studio (`ph-file-text`) and Media Studio (`ph-image`).

### Fixed
- Fixed floated structure panel disappearing bug by bypassing bounding client rect height checks on exact matches, maintaining floating state when minimized or natively toggled.
- Fixed shortcut rail positioning by locking width to `44px` with compact padding, and attaching a style MutationObserver to shield positioning from Advanced Themer script overrides.

## v1.2.91

### Added
- Styled Advanced Themer shortcut tooltip balloons (`.brxc-shortcut-balloon`) to match the dark glassmorphic theme and elevated their `z-index` to `2147483015` to prevent rendering behind floated panels.
- Upgraded floated panels' resize indicators (`.mimams-bar-float-resize`) to render as a fully rounded centered pill handle that dynamically expands and glows with `#baf400` color on hover.

### Fixed
- Implemented a DOM `MutationObserver` on `document.body` to listen for additions of structure panel or shortcut rail nodes and synchronize them in real-time, preventing misalignment when Bricks or Advanced Themer detaches and re-appends them.

## v1.2.90

### Fixed
- Hotfixed a critical browser freezing and lag issue affecting standard WordPress Admin screens and the Bricks builder, caused by an infinite MutationObserver loop in the speed-dial FAB repositioning effect (`useEffect` inside `builder-panel.js`).
- Optimized the FAB position MutationObserver to run only when at least one side panel is open, completely bypassing body element observation on standard closed-state dashboard pages.
- Configured the observer to ignore mutations triggered on the speed-dial FAB itself (`fab.contains(m.target)`), ensuring layout mutations do not trigger recursive observer callbacks.

## v1.2.89

### Added
- Moved CSS Studio settings (SCSS Mode toggle, priority drag-and-drop sources list, index rebuild operations, and instructions) to a dedicated **"CSS Studio"** tab inside the main unified settings panel.
- Implemented real-time synchronization between the main settings panel and the CSS Studio editor using a custom event-driven observer pattern (`ve-css-settings-changed`).
- Implemented dynamic positioning for the speed-dial FAB wrap: it now remains visible when panels are open and automatically slides to the left edge of the active panel (or to the right edge if the panel is docked left), adjusting sub-menu and tooltip alignments accordingly.
- Speed-dial FAB icon now toggles the main panel on click (`sO(prev => !prev)` instead of `sO(true)`).

### Fixed
- Repaired floated structure panel detection in `isReasonableSidePanel`: exact class/ID selectors bypass size and position checks, ensuring the panel is correctly recognized, cached, and floated even when temporarily collapsed to `width: 0 !important` by CSS rules.

## v1.2.88

### Added
- Minimize button tooltip text updated to `"Minimize structure panel"`.

### Fixed
- Fixed macOS Genie minimization transition by capturing active panel coordinates right before minimization and adding transition delays to `visibility: hidden` (prevents instant opacity cutoffs and glitches).
- Fixed floating structure panel self-disappearing bug by enhancing `MutationObserver` checks to detect inline `display: none` resets and missing coordinate properties while ignoring active drag/resize operations.
- Fixed shortcut rail sync by dynamically querying the rail element in drag listeners if the node is detached/re-created by Bricks/Advanced Themer.
- Aligned shortcut rail position margin to a consistent `16px` everywhere.
- Fixed custom tooltip clipping and stacking by elevating the rail `z-index` to `2147483005` (with tooltips at `2147483010`) and applying `overflow: visible !important` to the rail and all of its descendants.

## v1.2.87

### Added
- Caches the shortcut rail DOM reference when dragging starts rather than querying the DOM repeatedly.
- Sets custom tooltip attribute `data-tooltip` to say "Minimize structure panel" on the minimize button.

### Fixed
- Fixed macOS Genie minimization transition by removing inline `transform: none !important` locking styles when minimized and drag-end cleans up.
- Fixed floating panel glitching/disappearing-on-own behavior by simplifying MutationObserver style loops (observes only `position`).
- Fixed custom tooltips display order by elevating shortcut rail z-index to `2147483004` (higher than structure panel `2147483002`).
- Fixed clipping of custom tooltips inside container components by setting `overflow: visible !important` on `[data-tooltip]` elements.

## v1.2.86

### Added
- Implemented smooth macOS-style Genie minimization scale and translate transitions for the floating structure panel and the rail.
- Added custom HTML tooltips (`data-tooltip`) styled like the bottom speed-dial tooltips to replace browser-default ones.
- Added drag transition bypass on the shortcut rail to prevent layout lag or misalignment during drag.

### Fixed
- Fixed stuck standalone panels (Settings, Help, CSS Studio) by styling their closed state (opacity 0, visibility hidden, pointer-events none, scale 0.9).
- Synchronized dragging offsets and aligned spacing margin to a consistent 16px between the structure panel and the shortcut rail.
- Increased default visibility and contrast of shortcut rail icons for better readability.

## v1.2.85

### Fixed
- Hotfixed a syntax error in settings-manager.js (removed extra closing brace at line 442) which broke JavaScript execution and caused settings to reset to default on reload.

## v1.2.84

### Fixed
- Fixed floating structure panel minimize/restore button functionality so it collapses and restores reliably on click.
- Stopped pointerdown event propagation on the minimize button to prevent builder drag handlers from intercepting the action.
- Enforced high-specificity CSS overrides targeting ID selectors (e.g. `#bricks-structure.mimams-bar-structure-minimized`) and the floating structure rail to prevent style resets during element inspection.

## v1.2.83

### Added
- Added lazy-mounted keep-alive state tracking for panels.
- Added mutual exclusion behavior between all open panels so that opening one closes another.
- Added scale-in/out visual transitions for standalone panels.
- Disabled standalone panel draggability while retaining handles.
- Styled standalone panel float handles to match the Variable panel, and applied a modern dot-pattern radial resize gripper.
- Applied brand color `#baf400` to Advanced Themer shortcut icons and hid empty shortcut wrappers in floating mode.
- Added dynamic semantic `ul` wrapper correction for Advanced Themer shortcut items.

### Fixed
- Clamped docked layout heights and positions on WP Admin load to prevent offscreen/misplaced panels.
- Resolved settings close button container height overflow via `flex: 1; min-height: 0`.
- Optimized query/variable name lowercasing for improved fuzzy search performance.
- Implemented a `MutationObserver` on floated panels to restore layout styles dynamically under inspector mutations.
- Intercepted pointerdown, mousedown, and click events on `.mimams-bar-toggle-button` in the capture phase to toggle Mimam's Bar and prevent duplicate open triggers.

## v1.2.82

### Fixed
- Fixed standalone panel heights (Settings, Help, CSS Studio) to dynamically match the Variable panel state (docked vs. floating) down to the pixel, removing hardcoded important heights.
- Repaired the structure panel minimize button SVG coordinates and attributes, resolving the malformed diagonal slash.
- Resolved Bricks and Advanced Themer shortcut rail positioning overlap and synchronization issues by applying explicit physical positioning and sizing overrides (`left`, `right: auto`, `top`, `bottom: auto`, `height` with `!important`).

## v1.2.81

### Fixed
- Matched Settings, Help, and CSS Studio standalone panel heights with the Variable panel exactly down to the pixel.
- Fixed CSS Studio editor sidecar visibility and layout clipping by removing nested scrollable containment.
- Fixed mutual exclusion of open panels so that multiple standalone panels can remain open at the same time.
- Synchronized BricksExtras and Advanced Themer shortcut rails in real-time on structure panel drag and resize.
- Fixed broken structure panel drag handle grab icon and positioned the minimize button as a header sibling.

## v1.2.80

### Added
- Implemented structure panel minimize/restore button interactions. Clicking the minimize button collapses the panel to a tree icon next to the bottom-right speed-dial, and clicking the restore button restores it.
- Enabled responsive sidecar placement for the CSS Studio sidecar (renders direct sibling outside scrollable `.ve-body`).

### Fixed
- Matched standalone panel heights (Settings, Help, CSS Studio) with the Variable panel.
- Fixed CSS Studio settings layout overlap and duplicate headers.
- Fixed BricksExtras shortcut container overlap by dynamically positioning it with a 16px space gap on the side of the structure panel, extracting it to the document body to prevent container containment clipping.
- Raised structure panel z-index to `2147483002` to render above canvas components.
- Fixed update transient caching by unsetting the stale response key in the updater cache.

## v1.2.79

### Fixed
- Restored pointer interaction (`pointer-events: auto !important`) on all standalone panels (Settings, Help, CSS Studio), allowing click, drag, and scroll operations instead of clicking through.
- Fixed the sticky "update available" notification issue by hooking into `upgrader_process_complete` and purging WordPress's plugin updates cache transient immediately after updates complete.

## v1.2.78

### Fixed
- Fixed bug where standalone panels (Settings, Help, CSS Studio) opened outside the viewport boundaries to the right.
- Excluded WordPress update pages (`update.php`, `update-core.php`) from loading the speed-dial menu assets to prevent centered floating icon visual issues.

## v1.2.77

### Added
- Consolidated settings: General/Vengine and Mimam's Bar settings are now unified inside a single standalone Settings panel using tabbed navigation.
- Extracted CSS Studio from the main command console into a standalone premium floating panel, toggled directly by the code icon in the bottom-right speed-dial menu.
- Enabled the speed-dial FAB menu and all floating panels (Settings, Help, CSS Studio) to render and function on standard WordPress Admin screens in addition to the Bricks builder.
- Implemented global click-outside-to-close behavior: clicking outside any standalone panel or command console automatically closes it.

### Fixed
- Fixed scrolling inside the floated Bricks structure panel by establishing correct flexbox height inheritance rules on nested panels.
- Standardized settings label text to "Undock Mimam's Bar and remember position".

## v1.2.76

### Added
- Extracted Settings and Help panels from the main Mimam's Bar command console into standalone floating windows.
- Added a Help icon (`ph('question')`) to the bottom-right speed-dial menu.
- Connected speed-dial menu clicks to directly toggle Settings and Help standalone panels.
- Enabled drag position management on standalone panels independently of the main bar's docking settings.
## v1.2.75

### Added
- Implemented a 'Deselect Element' shortcut for Bricks Builder, defaulting to Esc or Shift+D via settings.
- Refined the bottom-right hub into an intentional speed-dial menu that expands on hover.
- Added new settings to hide or show Vengine and Mimam's Bar icons from the Bricks top toolbar, dynamically clearing clutter.

## v1.2.74

### Fixed
- Replaced the hardcoded pixel-based initialization height for floating panels with a dynamic `70dvh` CSS value to keep the interface deeply responsive without constant recalibrations.
- Injected a dedicated `.mimams-bar-structure-wrapper` directly into the DOM to seamlessly group `#bricks-panel-header`, `.panel-content`, and `#brxcStructureTopContainer` within the Structure panel to maintain clean flex and grid behavior.
- Disabled transitions completely (`transition: none !important`) on floating host wrappers to outright kill any remaining native FOUC animations from Bricks.
- Scoped `#bricks-panel-header` `nowrap` explicitly to `#bricks-panel-elements` to ensure the structure panel continues to correctly wrap its header elements down.

### Fixed
- Enforced 70% window height explicitly for the floating structure panel to match the elements panel identically.
- Overhauled the early FOUC prevention script to instantly inject classes directly onto `<html>` before the body even paints, completely eliminating the brief docked flash on page load.
- Grouped the panel drag handle and `.title` element together in the DOM, forcing `.actions` underneath via flex wrapping for a cleaner header layout.
- Standardized the `#bricks-panel-search` input height so it strictly matches the height of its placeholder, resolving awkward vertical sizing.

### Fixed
- Eliminated the FOUC (Flash of Unstyled Content) where panels glitched in docked mode before switching to float on page load. A MutationObserver early script now seamlessly applies the floating classes as the body renders.
- Corrected `#bricks-panel-header` padding to ensure consistent spacing and aligned the drag handle perfectly horizontally on the same line as the header content.
- Ensured the Structure panel respects its native content height when floating instead of erroneously expanding to full screen height.
- Added a 2rem spacing gap before the BricksExtras shortcut container in the structure panel and aligned its items to the center.

### Fixed
- Fixed elements panel initializing with a short height by using window.innerHeight minus 100px.
- Unhid the structure panel header when floated, making the drag handle visible again.
- Removed the "Elements" and "Structure" text from the drag handles to prevent redundant "mimams bar floating panel" labels.
- Removed the 38px padding block start from floating panels and reset BricksExtras shortcut container padding to zero.

## v1.2.70

### Fixed

- Resolved the elements panel glitching on hide/unhide while floating by fixing the wrapper detection logic (`findPanelFromNode`) in `findElementsPanel`.
- Prevented the structure panel from losing its floating height when the browser resizes (e.g., opening Inspector) by explicitly setting `height` and `max-height` inline properties.
- Relocated the float drag handle inside the native Bricks panel headers.
- Replaced the online Phosphor icon with the local duotone SVG `dots-six-vertical-duotone.svg` for better styling.

## v1.2.69

### Fixed

- Resolved UI "freezes and lags" by removing forced heavy DOM scans during panel state retries in `settings-manager.js`.
- Fixed panel toggle glitches where Bricks panel widths would fall to 0, causing the detector to lose track and flicker.
- Re-introduced a safe wrapper bounding box logic (`markSafeHosts`) to collapse intermediate Bricks host wrappers, fixing "ghost background" when floating panels.

## v1.2.68

### Changed

- Re-wrote `builder.css` panel logic to use native Bricks ID selectors instead of tracking dynamic classes with JS.
- Replaced JS bounds-checking logic (`markFloatingHostChain`) with CSS-only visibility states based on `body` classes.

### Fixed

- Fixed floating panel bounds issues causing visual ghosting/flicker.
- Fixed the update manifest to resolve WordPress infinite update loop (bumped from v1.2.64 to v1.2.65, now correctly pointing to v1.2.68).

## Unreleased

### Added

- Added Vengine Agent OS folder structure and documentation files.

### Changed

- Updated `build.py` and manifest to `v1.2.66`.
- Redesigned floating panel UI drag handle to properly match the visual design of the main `.baqa-panel` header, adding left alignment, padding, and neon green panel titles (c01 fix).

### Fixed

- Hiding the Elements panel now correctly collapses its native wrapper completely (c02 fix). Fixed the `markFloatingHostChain` loop logic that was un-marking hidden elements due to `width: 0`, and added `opacity: 0`/`overflow: hidden` to ensure no grey background remains.
- **HOTFIX (v1.2.65)**: `VE_VERSION` constant on line 17 was still `1.2.64` while the header said `1.2.65`, causing an infinite WordPress update loop. Both now read `1.2.65`.

### Notes

- Future Antigravity agents should update this file after implementation work.
