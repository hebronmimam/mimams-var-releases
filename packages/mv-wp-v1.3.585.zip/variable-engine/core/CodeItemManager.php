<?php
namespace VE\Core;

defined( 'ABSPATH' ) || exit;

/**
 * The store behind Code Studio.
 *
 * CSS Studio kept a list of stylesheets and compiled all of them into one file.
 * Code Studio keeps **code items**, and the thing in the editor is no longer
 * always CSS: an item has a language, and what it means to "run" depends on
 * that language.
 *
 *   * **CSS** has a real destination. Four of them, each a file this class
 *     writes and something else enqueues: `global` (site and builder),
 *     `frontend` (site only), `builder` (builder only), and `page` (one post,
 *     which the panel will address later). The old single `advanced.css` is
 *     still written, so anything already enqueueing it keeps working while the
 *     transition finishes.
 *
 *   * **PHP, JavaScript and HTML** have a hook and a priority instead. Those
 *     are **stored and never executed** - deliberately, and the panel says so.
 *     Running stored PHP is the half that can white-screen a site, and it does
 *     not ship until it ships with a fatal-error guard that switches the item
 *     off and says which one it was. Storing the fields now means the model
 *     does not change underneath that work.
 *
 * Migration from `ve_advanced_css` runs once, is idempotent, and keeps every id
 * so the version history written against those ids still points at the right
 * item.
 */
class CodeItemManager {

    private const OPTION    = 've_code_items';
    private const MIGRATED  = 've_code_items_migrated_from_css_studio';
    private const LEGACY    = 've_advanced_css';

    /** The languages an item can be. */
    public const LANGUAGES = [ 'css', 'php', 'js', 'html' ];

    /** Where compiled CSS can land. Each one is a real file. */
    public const DESTINATIONS = [ 'global', 'frontend', 'builder', 'page' ];

    /** What an item can be doing. `error` is set by the runtime, never by hand. */
    public const STATUSES = [ 'active', 'paused', 'error' ];

    /** Everything, oldest first, migrated if this is the first look. */
    public function all(): array {
        $this->migrate_once();
        $stored = get_option( self::OPTION, null );
        if ( ! is_array( $stored ) || ! isset( $stored['items'] ) || ! is_array( $stored['items'] ) ) {
            return $this->defaults();
        }
        return array_values( array_map( [ $this, 'normalize' ], $stored['items'] ) );
    }

    /** One item by id, or null. */
    public function find( string $id ): ?array {
        foreach ( $this->all() as $item ) {
            if ( $item['id'] === $id ) {
                return $item;
            }
        }
        return null;
    }

    /**
     * Write the whole set, then compile.
     *
     * Whole-set rather than per-item because order matters to CSS: the sequence
     * items are written in is the sequence they are compiled in, and that is what
     * decides which rule wins.
     */
    public function save( array $items ): array {
        $clean = [];
        foreach ( $items as $item ) {
            if ( is_array( $item ) ) {
                $clean[] = $this->normalize( $item );
            }
        }
        if ( ! $clean ) {
            $clean = $this->defaults();
        }
        update_option( self::OPTION, [ 'items' => $clean ], false );
        $this->compile();
        return $clean;
    }

    /** Add one item and return it, already saved. */
    public function create( array $item ): array {
        $items   = $this->all();
        $created = $this->normalize( $item );
        // A new id every time, so creating never overwrites by accident.
        $created['id'] = $this->fresh_id( $created['language'], $items );
        $items[]       = $created;
        $this->save( $items );
        return $created;
    }

    /** Change one item. Unknown keys are ignored; unknown ids return null. */
    public function update( string $id, array $changes ): ?array {
        $items = $this->all();
        $found = null;
        foreach ( $items as $index => $item ) {
            if ( $item['id'] !== $id ) {
                continue;
            }
            $merged = array_merge( $item, $changes );
            // The id is the one thing a change cannot move.
            $merged['id']  = $id;
            $items[ $index ] = $this->normalize( $merged );
            $found = $items[ $index ];
        }
        if ( ! $found ) {
            return null;
        }
        $this->save( $items );
        return $found;
    }

    /** Remove one item. Returns whether it was there. */
    public function delete( string $id ): bool {
        $items = $this->all();
        $kept  = array_values( array_filter( $items, static fn( $item ) => $item['id'] !== $id ) );
        if ( count( $kept ) === count( $items ) ) {
            return false;
        }
        $this->save( $kept );
        return true;
    }

    /**
     * Write the CSS files.
     *
     * One file per destination, holding the active CSS items for it in the order
     * they are stored. A destination with nothing in it is written empty rather
     * than left behind, so a stale file cannot outlive the item that made it.
     */
    public function compile(): array {
        $items   = $this->all();
        $written = [];

        foreach ( self::DESTINATIONS as $destination ) {
            if ( 'page' === $destination ) {
                continue;   // per-post files are addressed by the page they belong to
            }
            $parts = [ $this->file_header( $destination ) ];
            foreach ( $items as $item ) {
                if ( 'css' !== $item['language'] || 'active' !== $item['status'] ) {
                    continue;
                }
                if ( $item['destination'] !== $destination ) {
                    continue;
                }
                if ( '' === trim( $item['code'] ) ) {
                    continue;
                }
                $parts[] = '/* === ' . $item['name'] . ' === */';
                $parts[] = rtrim( $item['code'] );
                $parts[] = '';
            }
            $written[ $destination ] = $this->write( $this->file_name( $destination ), implode( "\n", $parts ) );
        }

        // The old single file, still written so anything enqueueing it keeps
        // working until the transition is finished and it can be retired.
        $legacy = [ $this->file_header( 'legacy' ) ];
        foreach ( $items as $item ) {
            if ( 'css' !== $item['language'] || 'active' !== $item['status'] || 'page' === $item['destination'] ) {
                continue;
            }
            if ( '' === trim( $item['code'] ) ) {
                continue;
            }
            $legacy[] = '/* === ' . $item['name'] . ' (' . $item['destination'] . ') === */';
            $legacy[] = rtrim( $item['code'] );
            $legacy[] = '';
        }
        $written['legacy'] = $this->write( 'advanced.css', implode( "\n", $legacy ) );

        return [ 'compiled' => ! in_array( false, $written, true ), 'files' => $written ];
    }

    /** Where a destination's file lives, for whoever enqueues it. */
    public function file_url( string $destination ): string {
        return VE_CSS_OUTPUT_URL . $this->file_name( $destination );
    }

    /* -- the shape of an item --------------------------------------------- */

    /**
     * Fill in what is missing and refuse what is not allowed.
     *
     * Every unknown value falls back rather than being stored: an item with a
     * language nobody recognises is an item that will never run and never say
     * why.
     */
    public function normalize( array $item ): array {
        $language = sanitize_key( (string) ( $item['language'] ?? 'css' ) );
        if ( ! in_array( $language, self::LANGUAGES, true ) ) {
            $language = 'css';
        }

        $destination = sanitize_key( (string) ( $item['destination'] ?? 'global' ) );
        if ( ! in_array( $destination, self::DESTINATIONS, true ) ) {
            $destination = 'global';
        }

        $status = sanitize_key( (string) ( $item['status'] ?? 'active' ) );
        if ( ! in_array( $status, self::STATUSES, true ) ) {
            $status = 'active';
        }

        $id = sanitize_key( (string) ( $item['id'] ?? '' ) );
        if ( '' === $id ) {
            $id = $this->fresh_id( $language, [] );
        }

        $name = sanitize_text_field( (string) ( $item['name'] ?? '' ) );
        if ( '' === $name ) {
            $name = 'untitled.' . ( 'js' === $language ? 'js' : $language );
        }

        return [
            'id'          => $id,
            'name'        => $name,
            'language'    => $language,
            // CSS lands somewhere; everything else hangs off a hook it does not
            // yet run on, so the destination is not its business.
            'destination' => 'css' === $language ? $destination : 'global',
            'status'      => $status,
            'code'        => (string) ( $item['code'] ?? '' ),
            'folder'      => sanitize_text_field( (string) ( $item['folder'] ?? '' ) ),
            // Stored, never evaluated. See the note at the top of this class.
            'hook'        => sanitize_text_field( (string) ( $item['hook'] ?? '' ) ),
            'priority'    => (int) ( $item['priority'] ?? 10 ),
            'run_context' => sanitize_key( (string) ( $item['run_context'] ?? 'everywhere' ) ),
            // Written by whatever discovers the failure, so the panel can show
            // which item was switched off and what it said.
            'last_error'  => sanitize_text_field( (string) ( $item['last_error'] ?? '' ) ),
        ];
    }

    private function fresh_id( string $language, array $existing ): string {
        $taken = [];
        foreach ( $existing as $item ) {
            $taken[ $item['id'] ?? '' ] = true;
        }
        do {
            $id = $language . '_' . substr( md5( uniqid( (string) wp_rand(), true ) ), 0, 8 );
        } while ( isset( $taken[ $id ] ) );
        return $id;
    }

    private function defaults(): array {
        return [
            $this->normalize( [ 'id' => 'global', 'name' => 'global.css', 'language' => 'css', 'destination' => 'global' ] ),
        ];
    }

    /* -- coming from CSS Studio -------------------------------------------- */

    /**
     * Bring the old stylesheets across, once.
     *
     * Ids are kept, because the version history is written against them: change
     * the id and every saved version of that sheet becomes unreachable. The old
     * option is left exactly as it was, so this can be re-run and so nothing is
     * destroyed if the transition is reversed.
     */
    public function migrate_once(): array {
        if ( get_option( self::MIGRATED, '' ) ) {
            return [ 'migrated' => 0, 'already' => true ];
        }
        if ( is_array( get_option( self::OPTION, null ) ) ) {
            update_option( self::MIGRATED, gmdate( 'c' ), false );
            return [ 'migrated' => 0, 'already' => true ];
        }

        $legacy = get_option( self::LEGACY, [] );
        $sheets = is_array( $legacy ) && isset( $legacy['stylesheets'] ) && is_array( $legacy['stylesheets'] )
            ? $legacy['stylesheets']
            : [];

        $items = [];
        foreach ( $sheets as $sheet ) {
            if ( ! is_array( $sheet ) ) {
                continue;
            }
            $items[] = $this->normalize( [
                'id'          => (string) ( $sheet['id'] ?? '' ),
                'name'        => (string) ( $sheet['name'] ?? '' ),
                'language'    => 'css',
                'destination' => $this->destination_for_scope( (string) ( $sheet['scope'] ?? 'global' ) ),
                'status'      => ( ! isset( $sheet['enabled'] ) || ! empty( $sheet['enabled'] ) ) ? 'active' : 'paused',
                'code'        => (string) ( $sheet['css'] ?? '' ),
            ] );
        }

        if ( ! $items ) {
            $items = $this->defaults();
        }

        update_option( self::OPTION, [ 'items' => $items ], false );
        update_option( self::MIGRATED, gmdate( 'c' ), false );
        $this->compile();

        return [ 'migrated' => count( $items ), 'already' => false ];
    }

    /**
     * The old scopes were about where a sheet was written, not where it lands.
     * `page` is the one that means the same thing in both.
     */
    private function destination_for_scope( string $scope ): string {
        $scope = sanitize_key( $scope );
        if ( 'page' === $scope ) {
            return 'page';
        }
        return 'global';
    }

    /* -- files -------------------------------------------------------------- */

    private function file_name( string $destination ): string {
        return 'code-studio-' . sanitize_key( $destination ) . '.css';
    }

    private function file_header( string $what ): string {
        return "/*\n * Mimam's Var - Code Studio (" . $what . ")\n"
            . ' * Version: ' . ( defined( 'VE_VERSION' ) ? VE_VERSION : '' ) . "\n"
            . ' * Compiled: ' . gmdate( 'Y-m-d H:i:s' ) . " UTC\n */\n";
    }

    private function write( string $file, string $contents ): bool {
        if ( ! is_dir( VE_CSS_OUTPUT_DIR ) ) {
            wp_mkdir_p( VE_CSS_OUTPUT_DIR );
        }
        return false !== file_put_contents( VE_CSS_OUTPUT_DIR . $file, $contents );
    }
}
