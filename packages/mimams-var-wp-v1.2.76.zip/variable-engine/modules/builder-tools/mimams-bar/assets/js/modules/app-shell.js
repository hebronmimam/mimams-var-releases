(function () {
  'use strict';

  if (window.MimamsBarFrameBridge) return;
  if (window.MimamsBarAppShell) return;

  function create(labels) {
    labels = labels || {};
    var panel = document.createElement('div');
    panel.className = 'baqa-panel';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', labels.title || "Mimam's Bar");
    panel.innerHTML = '' +
      '<div class="baqa-head">' +
        '<span class="baqa-mark">M</span>' +
        '<div class="baqa-title">' + (labels.title || "Mimam's Bar") + '</div>' +
        '<button type="button" class="baqa-close" aria-label="Close">×</button>' +
      '</div>' +
      '<div class="baqa-body">' +
        '<div class="baqa-target"><span>Target</span><strong class="baqa-target-name">No element selected</strong></div>' +
        '<div class="baqa-existing is-collapsed" aria-live="polite"><button type="button" class="baqa-existing-toggle"><span>Attributes</span><strong class="baqa-existing-count">0</strong><em>Show</em></button><div class="baqa-existing-meta">Click rows to edit · Shift-click to rename</div><div class="baqa-existing-list"><div class="baqa-existing-empty">No custom attributes on this element yet.</div></div></div>' +
        '<div class="baqa-mode-line"><span class="baqa-mode-label">Direct mode</span><em></em></div>' +
        '<input class="baqa-field" type="text" autocomplete="off" spellcheck="false" placeholder="' + (labels.placeholder || 'data-anim=&quot;fade-up&quot; data-delay=&quot;200&quot;') + '">' +
        '<div class="baqa-command-suggestions" hidden></div>' +
        '<div class="baqa-element-results" hidden></div>' +
        '<div class="baqa-helper"><span>Examples:</span> <code>data-anim="fade-up"</code> <code>.hero</code> <code>#hero</code> <code>-.hero</code> <code>delete data-anim</code> <code>all h2 =&gt; data-anim="text-lines"</code></div><div class="baqa-tab-hint" aria-live="polite"></div>' +
        '<div class="baqa-error"></div>' +
      '</div>' +
      '<div class="baqa-actions">' +
        '<button type="button" class="baqa-btn baqa-cancel">Close</button>' +
        '<button type="button" class="baqa-btn baqa-btn-primary baqa-apply">Apply</button>' +
      '</div>';

    document.body.appendChild(panel);
    return panel;
  }

  function createSettingsPanel(labels) {
    labels = labels || {};
    var panel = document.createElement('div');
    panel.className = 'baqa-panel baqa-panel-standalone baqa-settings-standalone';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', 'Settings');
    panel.style.display = 'none';
    panel.innerHTML = '' +
      '<div class="baqa-head">' +
        '<span class="baqa-mark">⚙</span>' +
        '<div class="baqa-title">Settings</div>' +
        '<button type="button" class="baqa-close" aria-label="Close">×</button>' +
      '</div>' +
      '<div class="baqa-body">' +
        '<div class="baqa-settings-panel">' +
          '<label class="baqa-setting-row"><span>Auto-close after apply</span><input type="checkbox" data-setting="autoClose"></label>' +
          '<label class="baqa-setting-row"><span>Undock and remember position</span><input type="checkbox" data-setting="undocked"></label>' +
          '<label class="baqa-setting-row"><span>Hide Bricks structure panel</span><input type="checkbox" data-setting="hideStructure"></label>' +
          '<label class="baqa-setting-row"><span>Hide Bricks elements panel</span><input type="checkbox" data-setting="hideElements"></label>' +
          '<label class="baqa-setting-row"><span>Float Bricks elements panel</span><input type="checkbox" data-setting="floatElements"></label>' +
          '<label class="baqa-setting-row"><span>Float Bricks structure panel</span><input type="checkbox" data-setting="floatStructure"></label>' +
          '<label class="baqa-setting-row"><span>Floating panels opacity</span><select data-setting="floatOpacity"><option value="1">100%</option><option value="0.9">90%</option><option value="0.78">78%</option><option value="0.65">65%</option><option value="0.5">50%</option></select></label>' +
          '<label class="baqa-setting-row"><span>Shortcut</span><select data-setting="shortcut"><option value="alt-q">Alt + Q</option><option value="ctrl-k">Ctrl + K</option><option value="ctrl-alt-a">Ctrl + Alt + A</option></select></label>' +
          '<label class="baqa-setting-row"><span>Deselect Shortcut</span><select data-setting="deselectShortcut"><option value="escape">Escape</option><option value="shift-d">Shift + D</option><option value="alt-d">Alt + D</option><option value="none">None</option></select></label>' +
          '<label class="baqa-setting-row"><span>Show Mimam\'s Bar in Top Toolbar</span><input type="checkbox" data-setting="showTopBarIcon"></label>' +
          '<label class="baqa-setting-row"><span>Show Vengine in Top Toolbar</span><input type="checkbox" data-setting="showVengineTopBarIcon"></label>' +
          '<label class="baqa-setting-row"><span>Density</span><select data-setting="density"><option value="compact">Compact</option><option value="comfortable">Comfortable</option></select></label>' +
        '</div>' +
      '</div>';
    document.body.appendChild(panel);
    return panel;
  }

  function createHelpPanel(labels) {
    labels = labels || {};
    var panel = document.createElement('div');
    panel.className = 'baqa-panel baqa-panel-standalone baqa-help-standalone';
    panel.setAttribute('role', 'dialog');
    panel.setAttribute('aria-label', 'Help');
    panel.style.display = 'none';
    panel.innerHTML = '' +
      '<div class="baqa-head">' +
        '<span class="baqa-mark">?</span>' +
        '<div class="baqa-title">Quick help</div>' +
        '<button type="button" class="baqa-close" aria-label="Close">×</button>' +
      '</div>' +
      '<div class="baqa-body">' +
        '<div class="baqa-help-panel">' +
          '<div class="baqa-help-grid">' +
            '<div><strong>Direct</strong><span><code>data-anim="fade-up"</code> · <code>.hero</code> · <code>#hero</code> · <code>-hero</code> · <code>delete data-anim</code></span></div>' +
            '<div><strong>Modes</strong><span><code>1</code> Direct · <code>2</code> Search page · <code>3</code> Add element</span></div>' +
            '<div><strong>Emmet</strong><span><code>cont</code> + Tab → <code>container</code> · <code>section&gt;cont</code> + Tab → <code>container</code></span></div>' +
            '<div><strong>Bulk</strong><span><code>.card =&gt; data-anim="fade-up"</code></span></div>' +
            '<div><strong>Mimam\'s Var</strong><span><code>var </code> or <code>--</code> suggests saved tokens where available</span></div>' +
          '</div>' +
        '</div>' +
      '</div>';
    document.body.appendChild(panel);
    return panel;
  }

  function refs(panel) {
    return {
      input: panel.querySelector('.baqa-field'),
      error: panel.querySelector('.baqa-error'),
      tabHint: panel.querySelector('.baqa-tab-hint'),
      target: panel.querySelector('.baqa-target-name'),
      attrList: panel.querySelector('.baqa-existing-list'),
      existingBox: panel.querySelector('.baqa-existing'),
      attrCount: panel.querySelector('.baqa-existing-count'),
      attrToggleLabel: panel.querySelector('.baqa-existing-toggle em'),
      identityList: panel.querySelector('.baqa-identity-list'),
      elementResults: panel.querySelector('.baqa-element-results'),
      commandSuggestions: panel.querySelector('.baqa-command-suggestions'),
      elementModeLabel: panel.querySelector('.baqa-mode-label'),
      head: panel.querySelector('.baqa-head'),
      closeButton: panel.querySelector('.baqa-close'),
      cancelButton: panel.querySelector('.baqa-cancel'),
      applyButton: panel.querySelector('.baqa-apply'),
      attrsToggle: panel.querySelector('.baqa-existing-toggle')
    };
  }

  window.MimamsBarAppShell = {
    create: create,
    createSettingsPanel: createSettingsPanel,
    createHelpPanel: createHelpPanel,
    refs: refs
  };
})();
